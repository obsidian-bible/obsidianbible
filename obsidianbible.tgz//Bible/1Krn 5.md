# 1Krn 5 BT5
###### **1Krn 5,1**
 Synowie Rubena, pierworodnego Izraela. Wprawdzie był on pierworodnym, lecz ponieważ skalał łoże swego ojca, pierworodztwo jego dane było synom Józefa, syna Izraela, więc nie podawało się rodowodów według pierworodztwa.
###### **1Krn 5,2**
 Chociaż Juda był najpotężniejszy z braci swoich i z niego miał pochodzić władca, jednak pierworodztwo należało do Józefa.
###### **1Krn 5,3**
 Synowie Rubena, pierworodnego Izraela: Henoch, Pallu, Chesron i Karmi.
###### **1Krn 5,4**
 Synowie Joela: jego synem Szemajasz, jego synem Gog, jego synem Szimei,
###### **1Krn 5,5**
 jego synem Mika, jego synem Reajasz, jego synem Baal,
###### **1Krn 5,6**
 jego synem Beera, którego król Asyrii, Tiglat-Pileser, uprowadził do niewoli; był on naczelnikiem Rubenitów.
###### **1Krn 5,7**
 Braćmi ich według ich rodów, kiedy spisywano rodowody ich pokoleń, byli: naczelnik Jejel, Zachariasz,
###### **1Krn 5,8**
 Bela, syn Azaza, syna Szemy, syna Joela, który zamieszkiwał Aroer aż do Nebo i Baal-Meon.
###### **1Krn 5,9**
 Ku wschodowi zaś zamieszkiwał aż po wejście na pustynię [ciągnącą się] od rzeki Eufrat, gdyż pomnożyły się ich trzody w ziemi Gilead.
###### **1Krn 5,10**
 Za czasów Saula prowadzili wojnę z Hagrytami, którzy wpadli w ich ręce, zamieszkali więc w ich namiotach w całej wschodniej okolicy Gileadu.
###### **1Krn 5,11**
 Synowie Gada zamieszkiwali naprzeciwko nich w ziemi Baszan aż do Salka.
###### **1Krn 5,12**
 Joel pierwszy, drugi Szafan, potem Janaj i Szafat w Baszanie.
###### **1Krn 5,13**
 Braćmi ich są według ich rodów: Mikael, Meszullam, Szeba, Joraj, Jakan, Zija i Eber – siedmiu.
###### **1Krn 5,14**
 A ci byli synami Abichaila: Ben-Churi, Ben-Jaroach, Ben-Gilead, Ben-Mikael, Ben-Jesziszaj, Ben-Jechdo, Ben-Buz.
###### **1Krn 5,15**
 Achi, syn Abdiela, syna Guniego, był główą ich rodów.
###### **1Krn 5,16**
 Zamieszkiwali oni w Gileadzie, Baszanie i przynależnych miejscowościach, na wszystkich pastwiskach Szaronu, leżących aż po ich krańce.
###### **1Krn 5,17**
 Wszystkie ich rodowody zostały sporządzone za czasów Jotama, króla Judy, i Jeroboama, króla Izraela.
###### **1Krn 5,18**
 Synów Rubena i synów Gada oraz połowy pokolenia Manassesa, ludzi walecznych, mężów noszących tarczę i miecz, strzelających z łuku i wyszkolonych w rzemiośle wojennym było czterdzieści cztery tysiące siedemset sześćdziesięciu, gdy udawali się na wojnę.
###### **1Krn 5,19**
 A rozpoczęli wojnę z Hagrytami, Jetur zaś, Nafisz i Nadab
###### **1Krn 5,20**
 przyszli im z pomocą przeciwko nim. Dostali się więc w ich ręce Hagryci i wszyscy, którzy z nimi byli, albowiem podczas walki wzywali Boga, który ich wysłuchał, bo pokładali w Nim ufność.
###### **1Krn 5,21**
 Uprowadzili zaś z ich stad: pięćdziesiąt tysięcy wielbłądów, dwieście pięćdziesiąt tysięcy owiec, dwa tysiące osłów i sto tysięcy ludzi.
###### **1Krn 5,22**
 Rzeczywiście padło mnóstwo zabitych, albowiem była to wojna Boża. I zamieszkali na ich miejscu aż do niewoli.
###### **1Krn 5,23**
 Synowie połowy pokolenia Manassesa osiedlili się w tym kraju, od Baszanu aż do Baal-Hermonu, Seniru i góry Hermon. Byli oni liczni.
###### **1Krn 5,24**
 Oto naczelnicy ich rodów: Efer, Jiszi, Eliel, Azriel, Jeremiasz, Hodawiasz i Jachdiel, dzielni wojownicy, ludzie sławni, naczelnicy swoich rodów.
###### **1Krn 5,25**
 Lecz sprzeniewierzyli się Bogu swych ojców i dopuszczali się nierządu z bogami ludów tamtego kraju, które Bóg wytracił przed nimi.
###### **1Krn 5,26**
 Bóg Izraela pobudził ducha Pula, króla asyryjskiego, ducha Tiglat-Pilesera, króla asyryjskiego, i uprowadził do niewoli Rubenitów, Gadytów oraz połowę pokolenia Manassesa. Przyprowadził on ich do Chalach, Chabor, Hara i do rzeki Gozan, gdzie przebywają aż do dnia dzisiejszego.
###### **1Krn 5,27**
 Synowie Lewiego: Gerszon, Kehat i Merari.
###### **1Krn 5,28**
 Synowie Kehata: Amram, Jishar, Chebron i Uzzjel.
###### **1Krn 5,29**
 Dzieci Amrama: Aaron, Mojżesz i Miriam. Synowie Aarona: Nadab, Abihu, Eleazar i Itamar.
###### **1Krn 5,30**
 Eleazar był ojcem Pinchasa, a Pinchas – Abiszuy.
###### **1Krn 5,31**
 Abiszua był ojcem Bukkiego, a Bukki – Uzziego.
###### **1Krn 5,32**
 Uzzi był ojcem Zerachiasza, a Zerachiasz – Merajota.
###### **1Krn 5,33**
 Merajot był ojcem Amariasza, a Amariasz – Achituba.
###### **1Krn 5,34**
 Achitub był ojcem Sadoka, a Sadok – Achimaasa.
###### **1Krn 5,35**
 Achimaas był ojcem Azariasza, a Azariasz – Jochanana.
###### **1Krn 5,36**
 Jochanan był ojcem Azariasza – tego, co sprawował urząd kapłański w świątyni, którą zbudował Salomon w Jerozolimie.
###### **1Krn 5,37**
 Azariasz był ojcem Amariasza, a Amariasz – Achituba.
###### **1Krn 5,38**
 Achitub był ojcem Sadoka, a Sadok – Szalluma.
###### **1Krn 5,39**
 Szallum był ojcem Chilkiasza, a Chilkiasz – Azariasza.
###### **1Krn 5,40**
 Azariasz był ojcem Serajasza, a Serajasz – Josadaka.
###### **1Krn 5,41**
 Josadak poszedł na wygnanie, gdy Pan uprowadził Judę i Jerozolimę ręką Nabuchodonozora.
# 1Krn 5 PAU
###### **1Krn 5,1**
 Oto potomkowie Rubena, pierworodnego syna Izraela. Był on synem pierworodnym, lecz skalał łoże swego ojca i dlatego jego pierworództwo przeszło na synów Józefa, syna Izraela. Dlatego spisów rodowych nie podano zgodnie z pierworództwem.
###### **1Krn 5,2**
 Pierworództwo należało do Józefa, chociaż Juda był najpotężniejszy z braci i spośród jego potomków miał pochodzić władca.
###### **1Krn 5,3**
 Synami Rubena, pierworodnego Izraela, byli Henoch, Pallu, Chesron i Karmi.
###### **1Krn 5,4**
 Potomkami Joela byli: Szemajasz, jego syn Gog, jego syn Szimei,
###### **1Krn 5,5**
 jego syn Mika, jego syn Reajasz, jego syn Baal,
###### **1Krn 5,6**
 jego syn Beera, przywódca Rubenitów, wzięty do niewoli przez króla Asyrii Tiglat-Pilesera.
###### **1Krn 5,7**
 Ich braćmi, umieszczonymi zgodnie z przynależnością rodową w spisach plemion, byli: Jejel jako zwierzchnik, następnie Zachariasz
###### **1Krn 5,8**
 oraz Bela, syn Azaza, syn Szemy, syn Joela, a mieszkali w Aroerze aż po Nebo i Baal-Meon.
###### **1Krn 5,9**
 Na wschodzie mieszkali aż po przełęcz prowadzącą do pustyni sięgającej Eufratu, bo bardzo rozmnożyły się ich trzody w Gileadzie.
###### **1Krn 5,10**
 Za panowania Saula prowadzili oni wojnę z Hagrytami, pokonali ich i zajęli ich osiedla w całym wschodnim Gileadzie.
###### **1Krn 5,11**
 Potomkowie Gada mieszkali w ich sąsiedztwie, w ziemi Baszanu aż po Salka.
###### **1Krn 5,12**
 Ich przywódcą był Joel, drugim co do ważności - Szafan, a następnie Janaj i Szafat w Baszanie.
###### **1Krn 5,13**
 Ich braćmi zgodnie z przynależnością rodową byli: Mikael, Meszullam, Szeba, Joraj, Jakan, Zija i Eber - razem siedmiu.
###### **1Krn 5,14**
 Byli oni potomkami Abichaila, syna Chura, syna Jaroacha, syna Gileada, syna Mikaela, syna Jesziszaja, syna Jechdy, syna Buza.
###### **1Krn 5,15**
 Achi, syn Abdiela, syna Guniego, był przywódcą ich rodów.
###### **1Krn 5,16**
 Zamieszkiwali oni Gilead, Baszan oraz osiedla wokół niego. Zajmowali również bogaty w pastwiska Szaron położony na ich pograniczu.
###### **1Krn 5,17**
 Wszystkie ich spisy rodowe zostały sporządzone za czasów Jotama, króla Judy, i Jeroboama, króla Izraela.
###### **1Krn 5,18**
 Gdy Rubenici, Gadyci oraz połowa plemienia Manassesa wyruszali na wojnę, mieli czterdzieści cztery tysiące siedmiuset sześćdziesięciu dzielnych wojowników, uzbrojonych w tarcze i miecze, strzelających z łuku i doskonale wyszkolonych w wojennym rzemiośle.
###### **1Krn 5,19**
 Wyruszyli na wojnę przeciwko Hagrytom, Jeturowi, Nafiszowi i Nadabowi.
###### **1Krn 5,20**
 Podczas walki wzywali Boga, a On ich wysłuchał, bo Mu zaufali. Gdy otrzymali pomoc, pokonali Hagrytów i ich sojuszników.
###### **1Krn 5,21**
 Uprowadzili z ich stad pięćdziesiąt tysięcy wielbłądów, dwieście pięćdziesiąt tysięcy owiec, dwa tysiące osłów, a także sto tysięcy jeńców.
###### **1Krn 5,22**
 Wielu poległo w walce, była to bowiem wojna Boża. Zamieszkali na ich ziemi aż do przesiedlenia.
###### **1Krn 5,23**
 Połowa plemienia Manassesa osiedliła się w Zajordaniu, od Baszanu po Baal-Hermon, Senir i górę Hermon, ponieważ było ich bardzo dużo.
###### **1Krn 5,24**
 Przywódcami ich rodów byli: Efer, Jeszi, Eliel, Azriel, Jeremiasz, Hodawiasz i Jachdiel. Odznaczali się oni odwagą i cieszyli sławą we wszystkich rodach.
###### **1Krn 5,25**
 Nie byli jednak wierni Bogu swych ojców, dopuścili się nierządu z bogami ludów zamieszkujących ten kraj przed nimi, które Bóg wypędził.
###### **1Krn 5,26**
 Bóg Izraela wysłał przeciwko nim ducha Pula, króla asyryjskiego oraz Tiglat-Pilesera, króla asyryjskiego. Przesiedlił on Rubenitów, Gadytów i zajordańską część plemienia Manassesa i osadził w Chalach, Chabor, Harai nad rzeką Gozan, gdzie przebywają po dziś dzień.
###### **1Krn 5,27**
 Synowie Lewiego: Gerszon, Kehat, Merari.
###### **1Krn 5,28**
 Synowie Kehata: Amram, Ishar, Chebron i Uzzjel.
###### **1Krn 5,29**
 Dzieci Amrama: Aaron, Mojżesz i Miriam. Synowie Aarona: Nadab, Abihu, Eleazar i Itamar.
###### **1Krn 5,30**
 Eleazar był ojcem Pinchasa, a Pinchas - Abiszuy.
###### **1Krn 5,31**
 Abiszua był ojcem Bukkiego, Bukki - Uzziego,
###### **1Krn 5,32**
 Uzzi - Zerachiasza, a Zerachiasz - Merajota.
###### **1Krn 5,33**
 Merajot był ojcem Amariasza, a Amariasz - Achituba.
###### **1Krn 5,34**
 Achitub był ojcem Sadoka, a Sadok - Achimaasa.
###### **1Krn 5,35**
 Achimaas był ojcem Azariasza, Azariasz - Jochanana.
###### **1Krn 5,36**
 Jochanan był ojcem Azariasza. Sprawował on urząd kapłana w domu zbudowanym przez Salomona w Jerozolimie.
###### **1Krn 5,37**
 Azariasz był ojcem Amariasza, Amariasz - Achituba.
###### **1Krn 5,38**
 Achitub był ojcem Sadoka, Sadok zaś ojcem Szalluma.
###### **1Krn 5,39**
 Szallum był ojcem Chilkiasza, Chilkiasz zaś ojcem Azariasza.
###### **1Krn 5,40**
 Azariasz był ojcem Serajasza, a Serajasz - Josadaka.
###### **1Krn 5,41**
 Josadak z woli PANA został uprowadzony do niewoli przez Nabuchodonozora wraz z Judejczykami i mieszkańcami Jerozolimy.
# 1Krn 5 BP
###### **1Krn 5,1**
 Synowie Rubena, pierworodnego Izraela. Istotnie był on pierworodnym, ponieważ jednak zbezcześcił łoże swego ojca, prawa jego pierworodztwa zostały przekazane synom Józefa, który był synem Izraela. Przy rodowodach nie uwzględniono więc praw pierworodztwa.
###### **1Krn 5,2**
 Chociaż bowiem Juda stał się potężniejszy od braci swoich i z jego rodu wyszedł władca, to jednak prawa pierworodztwa należały do Józefa.
###### **1Krn 5,3**
 Synami Rubena, pierworodnego Izraela, byli: Chanok, Pallu, Checron i Karmi.
###### **1Krn 5,4**
 Potomkami Joela byli: jego syn Szemaja, którego synem był Gog, a tego znów synem był Szum,
###### **1Krn 5,5**
 jego synem był Mika, który znów miał syna Reaję, a ten miał syna Baala.
###### **1Krn 5,6**
 Synem [Baala] był Beera, którego Tiglat Pileser, król Asyrii, uprowadził do niewoli. On to był księciem Rubenitów.
###### **1Krn 5,7**
 Braćmi jego według ich rodów, zapisanych w ich rodowodach, byli: Jeiel, który był zwierzchnikiem, a następnie Zekarjahu,
###### **1Krn 5,8**
 Bela, syn Azaza, który był synem Szemy, a ten znów synem Joela; zamieszkiwał on [Bela] Aroer aż po Nebo i Baal-Meon.
###### **1Krn 5,9**
 A ku wschodowi zamieszkiwał aż do wejścia na pustynię, [która rozciąga się] od rzeki Eufratu, ponieważ trzody ich pomnożyły się w ziemi Gilead.
###### **1Krn 5,10**
 Za czasów Saula prowadzili wojnę z Hagrytami, pokonali ich i zamieszkali w ich namiotach w całej wschodniej części Gileadu.
###### **1Krn 5,11**
 Potomkowie Gada mieszkali naprzeciw nich w ziemi Baszan aż do Salka.
###### **1Krn 5,12**
 Pierwszym był Joel, drugim Szafan, następnymi: Janaj i Szafat w Baszanie
###### **1Krn 5,13**
 oraz ich bracia według rodów: Mikael, Meszullam, Szeba, Joraj, Jakan, Zia i Eber, razem siedmiu.
###### **1Krn 5,14**
 A ci są synami Abichajila, syna Churiego, który był synem Jaroacha, syna Gileada, syna Mikaela, syna Jesziszaja, syna Jachdo, który był synem Buza.
###### **1Krn 5,15**
 Achi, syn Abdiela, syn Guniego, był głową ich rodów.
###### **1Krn 5,16**
 Mieszkali oni w Gileadzie, w Baszanie i zależnych od nich miejscowościach oraz na wszystkich pastwiskach Szaronu aż po ich krańce.
###### **1Krn 5,17**
 Wszyscy oni zostali zapisani w rodowodach w czasach Jotama, króla Judy, oraz w czasach Jeroboama, króla Izraela.
###### **1Krn 5,18**
 Potomków Rubena, Gada i połowy pokolenia Manassego, dzielniejszych spośród nich, mężów noszących tarczę i miecz, napinających łuk i wyćwiczonych do boju, którzy mogli wyruszyć w pole, było 44 760.
###### **1Krn 5,19**
 Prowadzili oni wojnę z Hagrytami, z Jeturem, Nafiszem i Nodabem.
###### **1Krn 5,20**
 Doznali oni pomocy przeciw nim i Hagryci wraz z wszystkimi sprzymierzeńcami wpadli w ich ręce. Wołali bowiem w czasie walki do Boga i wysłuchał ich, bo w Nim położyli nadzieję.
###### **1Krn 5,21**
 Zajęli tedy ich mienie: 50 000 wielbłądów, 250 000 owiec, 2000 osłów i 100 000 ludzi.
###### **1Krn 5,22**
 Wielu bowiem padło zabitych, gdyż była to wojna z woli Boga. I mieszkali na ich miejscu aż do uproadzenia w niewolę.
###### **1Krn 5,23**
 Potomkowie połowy pokolenia Manassego zamieszkiwali ziemie od Baszanu aż do Baal-Chermon, do Seniru i do góry Chermon; a byli oni liczni.
###### **1Krn 5,24**
 A oto naczelnicy ich rodów: Efer, Jiszi, Eliel, Azriel, Jirmeja, Hodawja i Jachdiel, mężowie dzielni, ludzie sławni, wodzowie swych rodów.
###### **1Krn 5,25**
 Sprzeniewierzyli się jednak Bogu swych ojców i cudzołożyli idąc za bogami mieszkańców owego kraju, który Bóg wyniszczył przed nimi.
###### **1Krn 5,26**
 Wówczas Bóg Izraela pobudził ducha Pula, króla Asyrii, i ducha Tiglat Pilesera, króla Asyrii, i uprowadził Rubenitów, Gadytów i połowę pokolenia Manassego i przywiódł ich do Chalach, do Chabor, do Hara i nad rzekę Gozan, gdzie przebywają aż po dzień dzisiejszy.
###### **1Krn 5,27**
 Potomkami Lewiego byli: Gerszom, Kehat i Merari.
###### **1Krn 5,28**
 Synami Kehata byli: Amram, Jishar, Chebron i Uzziel.
###### **1Krn 5,29**
 Potomkami zaś Amrama byli: Aaron, Mojżesz i Mir jam. Synami Aarona byli: Nadab, Abihu, Eleazar oraz Itamar.
###### **1Krn 5,30**
 Eleazar był ojcem Pinchasa, a Pinchas był ojcem Abiszuy.
###### **1Krn 5,31**
 Abiszua był ojcem Bukkiego, Bukki zaś był ojcem Uzziego.
###### **1Krn 5,32**
 Uzzi był ojcem Zerachji, Zerachja zaś był ojcem Merajota.
###### **1Krn 5,33**
 Merajot był ojcem Amarji, Amarja znów był ojcem Achituba.
###### **1Krn 5,34**
 Achitub był ojcem Cadoka, a Cadok był ojcem Achimaaca.
###### **1Krn 5,35**
 Achimaac był ojcem Azarji, Azarja znów był ojcem Jochanana.
###### **1Krn 5,36**
 Jochanan był ojcem Azarji; on to sprawował urząd kapłański w Świątyni zbudowanej przez Salomona w Jeruzalem.
###### **1Krn 5,37**
 Azarja był ojcem Amarji, a Amarja był ojcem Achituba.
###### **1Krn 5,38**
 Achitub był ojcem Cadoka, a Cadok był ojcem Szalluma.
###### **1Krn 5,39**
 Szallum był ojcem Chilkijji, a Chilkijja był ojcem Azarji.
###### **1Krn 5,40**
 Azarja był ojcem Seraj i, a Seraj a był ojcem Jehocadaka.
###### **1Krn 5,41**
 Jehocadak poszedł na wygnanie, gdy Jahwe przez Nebukadnezara uprowadził w niewolę Judę i Jeruzalem.
# 1Krn 5 BR
###### **1Krn 5,1**
 Oto synowie Rubena, pierworodnego Izraela: Ruben był pierworodnym Izraela, ponieważ jednak skalał łoże swojego ojca, prawo pierworództwa zostało mu odjęte i przeniesione na synów Józefa, syna Izraela. Ale listy rodowodów nie podaje się według tak rozumianego pierworództwa.
###### **1Krn 5,2**
 Juda był wprawdzie najpotężniejszy wśród swoich braci i z jego łona miał wyjść późniejszy władca, lecz prawo pierworództwa zostało przyznane Józefowi.
###### **1Krn 5,3**
 Tak więc synami Rubena, pierworodnego Izraela, byli: Henoch, Pallu, Chesron i Karmi.
###### **1Krn 5,4**
 Joel był ojcem Szemajasza, Szemajasz ojcem Goga, Gog ojcem Szimeiego,
###### **1Krn 5,5**
 Szimei ojcem Miki, Mika ojcem Reajasza, Reajasz ojcem Baala,
###### **1Krn 5,6**
 Baal ojcem Beera, którego król Asyrii Tiglat-Pileser uprowadził do niewoli. Beer był naczelnikiem rodu Rubenitów.
###### **1Krn 5,7**
 Braćmi jego, zgodnie z ich rodowodami, do których weszli przy spisie ich pokoleń, byli Jejel, naczelnik rodu, i Zamariasz.
###### **1Krn 5,8**
 Bela był synem Azaza, syna Szemy, syna Joela, do którego należało miasto Aroer i okolice aż po Nebo i Baal-Meon.
###### **1Krn 5,9**
 Od strony wschodniej jego posiadłości ciągnęły się aż do pustyni, zaczynającej się od rzeki Eufrat. Tak pomnożyły się bardzo ich trzody w Gileadzie.
###### **1Krn 5,10**
 W czasach Saula prowadzili oni wojnę z Hagrytami, którzy dostali się w ich ręce. Zamieszkali więc w ich namiotach we wschodniej części Gileadu.
###### **1Krn 5,11**
 Naprzeciw nich mieszkali synowie Gada, zajmując cały obszar Baszanu aż do miasta Salka.
###### **1Krn 5,12**
 Naczelnikiem rodu był Joel, potem Szafan oraz Janaj i Szafat w Baszanie.
###### **1Krn 5,13**
 Ich braćmi według rodowodów byli: Mikael, Meszullam, Szeba, Joraj, Jakan, Zija i Eber - razem siedmiu.
###### **1Krn 5,14**
 A oto synowie Abichaila: Ben-Churi, Ben-Jaroach, Ben-Gilead, Ben-Mikael, Ben-Jesziszaj, Ben-Jecholo, Ben-Buz.
###### **1Krn 5,15**
 Naczelnikiem tego rodu był Achi, syn Abdiela, syna Guniego.
###### **1Krn 5,16**
 Mieszkali oni w Gileadzie, w Baszanie oraz w okolicznych miastach. Do nich należały wszystkie pastwiska Sirionu, aż po ich krańce.
###### **1Krn 5,17**
 Wszyscy ci potomkowie Gada zostali zapisani w swoich rodowodach za czasów Jotama, króla Judy, i Jeroboama, króla Izraela.
###### **1Krn 5,18**
 Wśród synów Rubena, Gada i połowy pokolenia Manassesa ludzi zdolnych do noszenia tarczy i miecza, umiejących posługiwać się łukiem i wyszkolonych w sztuce wojowania było czterdzieści cztery tysiące siedmiuset sześćdziesięciu.
###### **1Krn 5,19**
 W takiej liczbie wyruszyli na wojnę z Hagrytami, z Jeturem, z Nafiszem i z Nadabem.
###### **1Krn 5,20**
 Zdobyli nad nim przewagę i tak dostali się w ich ręce Hagryci oraz ich sprzymierzeńcy. [Synowie Rubena] bowiem w czasie walki wzywali Boga na pomoc, a Bóg ich wysłuchał, gdyż zaufali Mu całkowicie.
###### **1Krn 5,21**
 Zagarnęli wtedy wszystkie ich trzody w liczbach następujących: pięćdziesiąt tysięcy wielbłądów, dwieście pięćdziesiąt tysięcy owiec, dwa tysiące osłów. Wzięli też do niewoli sto tysięcy ludzi.
###### **1Krn 5,22**
 Zabitych pozostało [na polu walki] bardzo wielu, ponieważ sam Bóg prowadził tę wojnę. I osiedlili się na ich ziemiach, pozostając tam aż do czasu niewoli.
###### **1Krn 5,23**
 Synowie połowy pokolenia Manassesa zajmowali tę część kraju, która się ciągnęła od Baszanu aż do Baal-Hermonu, Seniru i góry Hermon. Było ich dość dużo.
###### **1Krn 5,24**
 Oto naczelnicy ich rodów: Efer, Jiszi, Eliel, Azriel, Jeremiasz, Hodawiasz i Jachdiel - wszyscy dzielni wojownicy, okryci już sławą, przywódcy rodów.
###### **1Krn 5,25**
 Jednakże nie okazali się wierni Bogu swych ojców i zaczęli uprawiać nierząd, służąc bogom tych ludów, których ziemie Bóg dał im w posiadanie.
###### **1Krn 5,26**
 Dlatego Bóg Izraela podsunął królowi asyryjskiemu Pulowi oraz królowi asyryjskiemu Tiglat-Pileserowi wrogie względem nich zamiary. I tak uprowadził on do niewoli wszystkich Rubenitów, Gadytów i połowę pokolenia Manassesa. Osiedlił ich w Chalach, w Chabor, w Hara i na okolicznych ziemiach aż do rzeki Gozan. Tam też przebywają aż do dnia dzisiejszego.
###### **1Krn 5,27**
 A oto synowie Lewiego: Gerszom, Kehat i Merari.
###### **1Krn 5,28**
 Synowie Kehata zaś to Amram, Jishar, Chebron, Uzzjel.
###### **1Krn 5,29**
 Dziećmi Amrama byli: Aaron, Mojżesz i Miriam, synowie Aarona zaś to: Nadab, Abihu, Eleazar oraz Itamar.
###### **1Krn 5,30**
 Eleazar był ojcem Pinchasa, Pinchas ojcem Abiszuy,
###### **1Krn 5,31**
 Abiszua ojcem Bukkiego, a Bukki ojcem Uzziego.
###### **1Krn 5,32**
 Uzzi był ojcem Zerachiasza, a Zerachiasz ojcem Merajota,
###### **1Krn 5,33**
 Merajot ojcem Amariasza, Amariasz zaś ojcem Achituba.
###### **1Krn 5,34**
 Achitub był ojcem Sadoka, a Sadok ojcem Achimaasa.
###### **1Krn 5,35**
 Achimaas był ojcem Azariasza, a Azariasz ojcem Jochanana.
###### **1Krn 5,36**
 Jochanan był ojcem Azariasza, tego, który sprawował urząd kapłana w świątyni zbudowanej w Jerozolimie przez Salomona.
###### **1Krn 5,37**
 Azariasz był ojcem Amariasza, Amariasz zaś ojcem Achituba.
###### **1Krn 5,38**
 Achitub był ojcem Sadoka, a Sadok ojcem Szalluma.
###### **1Krn 5,39**
 Szallum był ojcem Chilkiasza, a Chilkiasz ojcem Azariasza.
###### **1Krn 5,40**
 Azariasz był ojcem Serajasza, a Serajasz ojcem Josadaka.
###### **1Krn 5,41**
 Josadak dostał się do niewoli Nabuchodonozora, zesłanej przez Jahwe na całą Judę i Jerozolimę.
# 1Krn 5 WUJ
###### **1Krn 5,1**
 Synowie też Ruben pierworodnego syna Izraelowego (ten bowiem był pierworodny jego): ale gdy zgwałcił łoże ojca swego, dano pierworodztwo jego synom Józefa syna Izraelowego, a onego nie poczytano za pierworodnego.
###### **1Krn 5,2**
 Lecz Judas, który był namocniejszy między bracią swą, z plemienia jego książęta się rodziły: ale pierworodztwo było poczytane Józefowi.
###### **1Krn 5,3**
 Synowie tedy Ruben pierworodnego Izraelowego: Enoch, i Phallu, Esron, i Karmi.
###### **1Krn 5,4**
 Synowie Joel: Samia syn jego, Gog syn jego, Semei syn jego.
###### **1Krn 5,5**
 Micha syn jego, Reja syn jego, Baal syn jego,
###### **1Krn 5,6**
 Beera syn jego, którego wziął w niewolą Thelgathphalnasar król Assyryjski, a był książęciem w pokoleniu Ruben.
###### **1Krn 5,7**
 A bracia jego, i wszystek ród jego, gdy ich policzano według familiiej ich, mieli książęta Jehiela, i Zacharyasza.
###### **1Krn 5,8**
 A Bala syn Azaz, syna Samma, syna Joel, ten mieszkał w Aroer aż do Neba i Beelmeon.
###### **1Krn 5,9**
 Na wschodnią też stronę mieszkał aż do weścia w puszczą, i do rzeki Euphrates. Bo wielką liczbę mieli dobytków w ziemi Galaad.
###### **1Krn 5,10**
 A za czasów Saula walczyli z Agarejczykami i pobili je, i mieszkali miasto nich w ich przybytkach, na wszystkiej stronie, która patrzy na wschód słońca Galaad.
###### **1Krn 5,11**
 A synowie Gad mieszkali przeciwko im w ziemi Bazan, aż do Selcha.
###### **1Krn 5,12**
 Joel na przodku, a Saphan wtóry: a Janai i Saphat w Bazan.
###### **1Krn 5,13**
 A bracia ich według domów rodzajów ich, Michael i Mosollam, i Sebei, i Jorai, Jachan, i Zie, i Heber, siedm.
###### **1Krn 5,14**
 Ci synowie Abihail, syna Huri, syna Jara, syna Galaad, syna Michael, syna Jesesi, syna Jeddo, syna Buz.
###### **1Krn 5,15**
 Bracia też syna Abdiel, syna Guni książę domu w familiach ich.
###### **1Krn 5,16**
 I mieszkali w Galaad, i w Bazan, i w miasteczkach jego, i we wszech przedmieściach Saron, aż do granic.
###### **1Krn 5,17**
 Ci wszyscy byli policzeni za dni Joathana króla Judzkiego, i za dni Jeroboama króla Izraelskiego.
###### **1Krn 5,18**
 Synowie Ruben, i Gad, i pół pokolenia Manasse mężowie waleczni, noszący tarcze i miecze, i ciągnący łuk, i wyćwiczeni ku bojowi, czterdzieści i cztery tysiące i siedm set i sześćdziesiąt wychodzących ku bitwie.
###### **1Krn 5,19**
 Wiedli wojnę przeciw Agarejczykom: a Iturejczycy, i Naphis, i Nodab
###### **1Krn 5,20**
 Dodali im pomocy. I przyszli w ręce ich Agarejczycy, i wszyscy, którzy z nimi byli, bo wzywali Boga, gdy się potykali: i wysłuchał ich przeto, iż wierzyli weń.
###### **1Krn 5,21**
 I pobrali wszystko co mieli, wielbłądów pięćdziesiąt tysięcy, a owiec dwa kroć sto tysięcy i pięćdziesiąt tysięcy, i osłów dwa tysiąca, i dusz człowieczych sto tysięcy.
###### **1Krn 5,22**
 Wiele też rannych poległo: bo była Pańska wojna. I mieszkali miasto nich aż do przeniesienia.
###### **1Krn 5,23**
 Synowie też pół pokolenia Manasse posiedli ziemię od granic Bazan aż do Baal, Hermon, i Sanir, i góry Hermon, bo wielka liczba była.
###### **1Krn 5,24**
 I te były książęta domu rodu ich: Epher, i Jesi, i Eliel, i Ezriel, i Jeremia, i Odoja, i Jediel mężowie barzo mocni i możni, i sławni wodzowie w familiach ich.
###### **1Krn 5,25**
 A opuścili Boga ojców swych, i cudzołożyli z bogami ludzi ziemie, które zniósł Bóg przed nimi.
###### **1Krn 5,26**
 I pobudził Bóg Izraelów ducha Phula króla Assyryjskiego, i ducha Thelgathphalnasara króla Assur, i przeniósł Ruben, i Gad, i pół pokolenia Manasse, i zaprowadził je do Lahela, i do Habor, i do Ara, i rzeki Gozan, aż do dnia tego.
