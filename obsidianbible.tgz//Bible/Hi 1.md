# Hi 1 BT5
###### **Hi 1,1**
 Żył w ziemi Us człowiek imieniem Hiob. Był to mąż sprawiedliwy, prawy, bogobojny i unikający zła.
###### **Hi 1,2**
 Miał siedmiu synów i trzy córki.
###### **Hi 1,3**
 Majętność jego stanowiło siedem tysięcy owiec, trzy tysiące wielbłądów, pięćset jarzm wołów, pięćset oślic oraz wielka liczba służby. Był najwybitniejszym człowiekiem spośród wszystkich ludzi Wschodu.
###### **Hi 1,4**
 Synowie jego mieli zwyczaj udawania się na ucztę, którą każdy z nich urządzał po kolei we własnym domu w dniu oznaczonym. Zapraszali też swoje trzy siostry, by jadły i piły z nimi.
###### **Hi 1,5**
 Gdy mijał czas ucztowania, Hiob dbał o to, by dokonywać ich oczyszczenia. Wstawał wczesnym rankiem i składał całopalenie stosownie do ich liczby. Bo mówił Hiob do siebie: «***Może moi synowie zgrzeszyli i złorzeczyli Bogu w sercach?***» Hiob zawsze tak postępował.
###### **Hi 1,6**
 Pewnego dnia, gdy synowie Boży przyszli stawić się przed Panem, szatan też przyszedł z nimi.
###### **Hi 1,7**
  I rzekł Bóg do szatana: «***Skąd przychodzisz?***» Szatan odrzekł Panu: «***Przemierzałem ziemię i wędrowałem po niej***».
###### **Hi 1,8**
 Mówi Pan do szatana: «***A zwróciłeś uwagę na sługę mego, Hioba? Bo nie ma na całej ziemi drugiego, kto by tak był prawy, sprawiedliwy, bogobojny i unikający grzechu jak on***».
###### **Hi 1,9**
 Szatan na to do Pana: «***Czyż za darmo Hiob czci Boga?***
###### **Hi 1,10**
 ***Czyż Ty nie ogrodziłeś zewsząd jego samego, jego domu i całej majętności? Pracy jego rąk pobłogosławiłeś, jego dobytek na ziemi się mnoży.***
###### **Hi 1,11**
 ***Wyciągnij, proszę, rękę i dotknij jego majątku! Na pewno Ci w twarz będzie złorzeczył***».
###### **Hi 1,12**
 Rzekł Pan do szatana: «***Oto cały majątek jego w twej mocy. Tylko na niego samego nie wyciągaj ręki***». I odszedł szatan sprzed oblicza Pańskiego.
###### **Hi 1,13**
 Pewnego dnia, gdy synowie i córki jedli i pili w domu najstarszego brata,
###### **Hi 1,14**
 przyszedł posłaniec do Hioba i rzekł: «***Woły orały, a oślice pasły się tuż obok.***
###### **Hi 1,15**
 ***Wtem napadli Sabejczycy, porwali je, a sługi mieczem pozabijali,***
###### **Hi 1,16**
 ***ja sam uszedłem, by ci o tym donieść***». Gdy ten jeszcze mówił, przyszedł inny i rzekł: «***Ogień Boży spadł z nieba, zapłonął wśród owiec oraz sług i pochłonął ich. Ja sam uszedłem, by ci o tym donieść***».
###### **Hi 1,17**
 Gdy ten jeszcze mówił, przyszedł inny i rzekł: «***Chaldejczycy zstąpili z trzema oddziałami, napadli na wielbłądy, a sługi ostrzem miecza zabili. Ja sam uszedłem, by ci o tym donieść***».
###### **Hi 1,18**
 Gdy ten jeszcze mówił, przyszedł inny i rzekł: «***Twoi synowie i córki jedli i pili wino w domu najstarszego brata.***
###### **Hi 1,19**
 ***Wtem powiał szalony wicher z pustyni, poruszył czterema węgłami domu, zawalił go na dzieci, tak iż poumierały. Ja sam uszedłem, by ci o tym donieść***».
###### **Hi 1,20**
 Hiob wstał, rozdarł szaty, ogolił głowę, upadł na ziemię, oddał pokłon
###### **Hi 1,21**
 i rzekł :«***Nagi wyszedłem z łona matki i nagi tam wrócę. Dał Pan i zabrał Pan. Niech będzie imię Pańskie błogosławione!***»
###### **Hi 1,22**
 W tym wszystkim Hiob nie zgrzeszył i nie przypisał Bogu nieprawości.
# Hi 1 PAU
###### **Hi 1,1**
 Żył w ziemi Uz człowiek o imieniu Hiob, doskonały i prawy, bogobojny i stroniący od zła.
###### **Hi 1,2**
 Urodziło mu się siedmiu synów i trzy córki.
###### **Hi 1,3**
 Posiadał siedem tysięcy owiec, trzy tysiące wielbłądów, pięćset par wołów zaprzęgowych, pięćset oślic i bardzo liczną służbę. Był bogatszy od wszystkich ludzi Wschodu.
###### **Hi 1,4**
 Jego synowie zbierali się i urządzali uczty kolejno u każdego z nich, w ustalonym z góry dniu. Zapraszali także swoje trzy siostry, aby jadły i piły wraz z nimi.
###### **Hi 1,5**
 Kiedy dobiegały końca dni ucztowania, Hiob wzywał ich, aby dokonać obrzędu oczyszczenia. Wstawał wczesnym rankiem i składał ofiarę całopalną za każdego z nich, ponieważ mówił: „Może moi synowie zgrzeszyli i obrazili Boga w swoich sercach”. Hiob zawsze tak postępował.
###### **Hi 1,6**
 Zdarzyło się któregoś dnia, że synowie Boży przybyli, aby się stawić przed PANEM. Przybył także szatan i stanął pośród nich.
###### **Hi 1,7**
 PAN powiedział do szatana: „Skąd przychodzisz?”. Szatan odpowiedział PANU: „Okrążyłem ziemię i przemierzyłem ją wzdłuż i wszerz”.
###### **Hi 1,8**
 Wtedy PAN rzekł do szatana: „Czy zwróciłeś uwagę na mojego sługę Hioba? Nie ma przecież na ziemi drugiego człowieka tak doskonałego i prawego, bogobojnego i stroniącego od zła”.
###### **Hi 1,9**
 Szatan odpowiedział PANU: „Czy Hiob czci Boga bez powodu?
###### **Hi 1,10**
 Czy to nie Ty sam wzniosłeś ogrodzenie, aby go ochraniać wraz z jego domem i wszystkim, co do niego należy? Błogosławisz jego przedsięwzięciom, a jego dobytek w kraju ciągle się pomnaża.
###### **Hi 1,11**
 Ale wyciągnij tylko rękę i dotknij wszystkiego, co posiada. Na pewno będzie Ci w twarz złorzeczył!”.
###### **Hi 1,12**
 Na to PAN rzekł do szatana: „Oto wszystko, co do niego należy, jest w twojej mocy. Ale nie podnoś ręki na niego samego”. I odszedł szatan od PANA.
###### **Hi 1,13**
 Zdarzyło się któregoś dnia, że synowie i córki Hioba jedli i pili wino w domu najstarszego brata.
###### **Hi 1,14**
 Wtedy przyszedł do Hioba posłaniec i powiedział: „Woły były przy pługach, a oślice pasły się obok.
###### **Hi 1,15**
 Nagle wpadli Sabejczycy, zabrali je, a służbę pozabijali mieczem. Tylko ja ocalałem, aby ci o tym donieść”.
###### **Hi 1,16**
 Gdy on jeszcze mówił, przyszedł następny i powiedział: „Ogień Boży spadł z nieba, ogarnął owce oraz służbę i pochłonął ich. Tylko ja ocalałem, aby ci o tym donieść”.
###### **Hi 1,17**
 Gdy on jeszcze mówił, przyszedł następny i powiedział: „Trzy oddziały Chaldejczyków napadły na wielbłądy i uprowadziły je, zabijając służbę mieczem. Tylko ja ocalałem, aby ci o tym donieść”.
###### **Hi 1,18**
 Gdy on jeszcze mówił, przyszedł następny i powiedział: „Twoi synowie i córki jedli i pili wino w domu najstarszego brata.
###### **Hi 1,19**
 Nagle od strony pustyni nadciągnął gwałtowny wicher, wstrząsnął czterema narożnikami domu, zawalił go na dzieci i wszystkie zginęły. Tylko ja ocalałem, aby ci o tym donieść”.
###### **Hi 1,20**
 Wtedy Hiob wstał, na znak rozpaczy rozdarł ubranie i ogolił głowę, rzucił się na ziemię i tak pozostał.
###### **Hi 1,21**
 Potem powiedział: „Nagi wyszedłem z łona matki i nagi tam odejdę. PAN dał i PAN wziął, niech imię PANA będzie błogosławione”.
###### **Hi 1,22**
 Wszystkie te wydarzenia nie doprowadziły Hioba do grzechu. Nie poczynił Bogu żadnego zarzutu.
# Hi 1 BP
###### **Hi 1,1**
 Żył niegdyś w ziemi Uc człowiek imieniem Job. Był to mąż nieskazitelny, prawy, bojący się Boga i unikający zła.
###### **Hi 1,2**
 Urodziło mu się siedmiu synów i trzy córki.
###### **Hi 1,3**
 Posiadał on siedem tysięcy owiec, trzy tysiące wielbłądów, pięćset par wołów, pięćset oślic i oprócz tego miał bardzo liczną służbę. Był najznakomitszą osobistością spośród wszystkich ludzi Wschodu.
###### **Hi 1,4**
 Synowie jego mieli zwyczaj schodzić się na uczty, które każdy z nich kolejno urządzał w swoim domu w ustalonym dniu. Posyłali też po trzy swoje siostry i zapraszali je, aby jadły i piły z nimi.
###### **Hi 1,5**
 A kiedy kolejność dni biesiadnych się zamknęła, Job posyłał po nich, aby ich oczyścić. Potem wstawał wczesnym rankiem i składał za każdego z nich całopalną ofiarę, tak sobie mówiąc: Może synowie moi zgrzeszyli i obrazili Boga w sercu swoim. Tak Job postępował zawsze.
###### **Hi 1,6**
 Pewnego dnia synowie Boży przybyli, by się stawić przed Jahwe. Stawił się także z nimi i szatan.
###### **Hi 1,7**
 Wtedy Jahwe rzekł do szatana: Skąd przybywasz? A szatan odpowiedział Jahwe: Krążyłem po ziemi i wędrowałem po niej.
###### **Hi 1,8**
 Na to Jahwe zapytał szatana: Czyś dostrzegł tam sługę mojego Joba? Bo nie ma na ziemi nikogo podobnego jemu. Jest to mąż nieskazitelny, prawy, bojący się Boga i unikający zła.
###### **Hi 1,9**
 A szatan odpowiedział na to Jahwe: Czy to tak bezinteresownie Job czci Boga?
###### **Hi 1,10**
 Czyś Ty nie postawił płotu wokół niego i jego domu, i całej jego posiadłości? Pobłogosławiłeś dziełom rąk jego, a trzody jego rozmnażają się szeroko po kraju.
###### **Hi 1,11**
 Ale wyciągnij tylko rękę swoją i dotknij wszystkiego, co do niego należy, a przekonasz się, że w oczy będzie Ci złorzeczył.
###### **Hi 1,12**
 Na to Jahwe rzekł do szatana: Oto wszystko, co do niego należy, jest w twojej mocy, ale przeciw niemu samemu nie wyciągaj ręki. I odszedł szatan sprzed oblicza Jahwe.
###### **Hi 1,13**
 I stało się pewnego dnia, gdy synowie jego i córki ucztowali i pili wino w domu najstarszego brata,
###### **Hi 1,14**
 że przyszedł posłaniec do Joba i powiedział: Woły twoje ciągnęły pługi, a oślice pasły się przy nich.
###### **Hi 1,15**
 Wtedy Sabejczycy nagle napadli na nie i uprowadzili je. Ludzi zaś twoich pozabijali mieczem. Ja jeden tylko uszedłem, by cię o tym powiadomić.
###### **Hi 1,16**
 A gdy ten jeszcze mówił, nadbiegł inny i zawołał: Ogień Boży spadł z nieba, ogarnął twoje owce i sługi i spalił je. Ja jeden tylko zdołałem ujść, aby cię o tym powiadomić.
###### **Hi 1,17**
 A gdy ten jeszcze mówił, nadbiegł inny i zawołał: Chaldejczycy podzieleni na trzy oddziały napadli na twoje wielbłądy i uprowadzili je, a sługi twoje pozabijali mieczem. Ja jeden tylko zdołałem ujść, aby cię o tym powiadomić.
###### **Hi 1,18**
 Jeszcze ten nie skończył mówić, a już nadbiegł inny wołając: Synowie twoi i córki jedli i pili wino w domu najstarszego brata,
###### **Hi 1,19**
 gdy nagle gwałtowny wicher powiał z drugiej strony pustyni i uderzył w cztery węgły domu, który zwalił się na młodych ludzi, i wszyscy zginęli. Ja jeden tylko zdołałem ujść, aby cię o tym powiadomić.
###### **Hi 1,20**
 Wówczas Job wstał, rozdarł szatę swoją, ogolił głowę, rzucił się na ziemię i tak pozostał.
###### **Hi 1,21**
 po czym rzekł: Nagi wyszedłem z łona matki mojej i nagi tam powrócę. Jahwe dał i Jahwe wziął, niech będzie błogosławione imię Jahwe.
###### **Hi 1,22**
 Z okazji tego wszystkiego Job nie zgrzeszył ani nie uskarżał się na Boga.
# Hi 1 BR
###### **Hi 1,1**
 Żył kiedyś w ziemi Us człowiek imieniem Hiob. Był to mąż szlachetny i sprawiedliwy. Żył bogobojnie, unikając wszelkiego zła.
###### **Hi 1,2**
 Urodziło mu się siedmiu synów i trzy córki.
###### **Hi 1,3**
 Miał on siedem tysięcy owiec, trzy tysiące wielbłądów, pięćset jarzm wołów, pięćset osłów; do tego ogromną liczbę służby. Uchodził za człowieka najznakomitszego wśród wszystkich mieszkańców Wschodu.
###### **Hi 1,4**
 Jego synowie urządzali uczty kolejno - każdego dnia w domu jednego z nich. Zapraszali wtedy również swoje trzy siostry, z którymi razem jedli i pili.
###### **Hi 1,5**
 Kiedy mijały dni uczty, Hiob pamiętał zawsze o tym, żeby dokonać oczyszczenia. Wstawał wczesnym rankiem i składał tyle ofiar całopalenia, ile miał dzieci. Mawiał bowiem zawsze: Może któreś z moich dzieci zgrzeszyło i obraziło Boga w swoim sercu? Tak postępował Hiob zawsze.
###### **Hi 1,6**
 Lecz oto pewnego razu zdarzyło się, że gdy przyszli, aby stanąć przed Panem, synowie Boga, pojawił się także wśród nich szatan.
###### **Hi 1,7**
 I zapytał Pan szatana: Skąd przychodzisz? A szatan odpowiedział Panu: Przemierzyłem całą ziemię wzdłuż i wszerz.
###### **Hi 1,8**
 Powiedział tedy Pan do szatana: Czy zwróciłeś uwagę na sługę mojego, Hioba? Drugiego takiego nie ma nigdzie na ziemi. Jest to mąż niezwykle szlachetny i sprawiedliwy, żyje bogobojnie, unikając wszelkiego zła.
###### **Hi 1,9**
 Szatan zaś odpowiedział Panu mówiąc: A czy to tak bez powodu żyje Hiob bojaźnią Bożą?
###### **Hi 1,10**
 Czyż nie dlatego jest taki, że otaczasz opieką cały jego dom i wszystko, co posiada? To Ty błogosławieństwem darzysz wszystkie dzieła rąk jego i sprawiasz, że jego posiadłości rozciągają się na cały kraj.
###### **Hi 1,11**
 Ale spróbuj tylko podnieść Twoją rękę na niego, spróbuj dotknąć tego, co posiada, a zapewne będzie Ci w oczy złorzeczył.
###### **Hi 1,12**
 Powiedział tedy Pan do szatana: Dobrze! Daję ci władzę nad całą jego majętnością. Tylko jego samego nie wolno ci dotknąć! Wtedy odszedł szatan sprzed oblicza Pana.
###### **Hi 1,13**
 I oto zdarzyło się, że pewnego dnia synowie i córki Hioba siedzieli w domu pierworodnego brata, jedząc i pijąc.
###### **Hi 1,14**
 Nagle przybiegł do Hioba jeden z jego ludzi i powiedział: Woły twoje jarzemne orały, a obok pasły się osły.
###### **Hi 1,15**
 Wtedy wpadli Sabejczycy, pochwycili bydło, a sługi pozabijali mieczami. Tylko ja jeden zdołałem uciec, żeby ci o tym donieść.
###### **Hi 1,16**
 Jeszcze nie skończył mówić, gdy nadbiegł inny i powiedział: Ogień Boży spadł na ziemię, przeniósł się na stado owiec oraz sługi i zniszczył wszystko. Ocalałem ja jeden i przychodzę, żeby ci o tym powiedzieć.
###### **Hi 1,17**
 Jeszcze to mówił, gdy pojawił się następny spośród jego ludzi i powiedział: Chaldejczycy nadciągnęli trzema silnymi oddziałami, napadli na nasze wielbłądy i uprowadzili je, zabijając przedtem wszystkie sługi. Tylko ja jeden uratowałem się i przychodzę, żeby ci o tym powiedzieć.
###### **Hi 1,18**
 Jeszcze to mówił, gdy oto znów nadbiegł jeden z jego ludzi i powiedział: Twoi synowie i córki byli razem jedząc i pijąc w domu ich pierworodnego brata.
###### **Hi 1,19**
 I oto zerwał się gwałtowny wicher od pustyni, uderzył we wszystkie cztery rogi domu, a ten zwalił się na ludzi zabijając wszystkich. Tylko ja jeden uratowałem się i przychodzę, żeby cię o tym powiadomić.
###### **Hi 1,20**
 Powstał wtedy z miejsca Hiob, rozdarł szaty, ostrzygł sobie głowę, padł na ziemię i zaczął się modlić.
###### **Hi 1,21**
 Potem powiedział: Nagi wyszedłem z łona matki mojej i nagi również tam wrócę. Pan dał, Pan wziął. Niech imię Pańskie będzie pochwalone
###### **Hi 1,22**
 Znosząc to wszystko nie dopuścił się Hiob żadnego grzechu i wcale nie szemrał przeciwko Bogu.
# Hi 1 WUJ
###### **Hi 1,1**
 Mąż był w ziemi Hus, imieniem Job, a był to mąż szczery i prosty i bojący się Boga, odstępujący od złego,
###### **Hi 1,2**
 I urodziło mu się siedm synów, a trzy córki.
###### **Hi 1,3**
 A majętność jego była, siedm tysięcy owiec, i trzy tysiące wielbłądów, pięć set też jarzm wołów, i pięć set oślic, i czeladzi barzo wiele: i był to mąż wielki między wszystkimi wschodnimi.
###### **Hi 1,4**
 I chadzali synowie jego, i sprawowali uczty wedle domów każdy dnia swego. I posławszy wzywali trzech sióstr swoich, aby z nimi jadały i piły.
###### **Hi 1,5**
 A gdy się w koło obeszły dni biesiady, posyłał do nich Job, i poświęcał je, a wstawszy rano, ofiarował całopalenia za każdego z nich. Bo mówił: By snadź nie zgrzeszyli synowie moi, a nie błogosławili Bogu w sercach swoich. Tak czynił Job po wszystkie dni.
###### **Hi 1,6**
 A niektórego dnia, gdy przyszli synowie Boży, aby stali przed Panem, był też między nimi i szathan.
###### **Hi 1,7**
 Któremu rzekł Pan: Zkąd idziesz? który odpowiedając rzekł: Zkrążyłem ziemię, i schodziłem ją
###### **Hi 1,8**
 I rzekł Pan do niego: A baczyłżeś Joba sługę mego, że mu niemasz na ziemi podobnego, człowiek szczery, i prosty, a bojący się Boga, i odstępujący od złego?
###### **Hi 1,9**
 Któremu szathan odpowiadając rzekł: Aza się Job darmo Boga boi?
###### **Hi 1,10**
 Azażeś go ty nie ogrodził, i dom jego, i wszystkę majętność w około zewsząd: błogosławiłeś uczynkom rąk jego, i dobytek jego rozrósł się na ziemi?
###### **Hi 1,11**
 Ale ściągni trochę rękę twoję, a dotkni wszystkiego co ma, jeślić w oczy błogosławić nie będzie.
###### **Hi 1,12**
 I rzekł Pan do szathana: Oto wszystko co ma, jest w ręce twojej: jedno na niego nie ściągaj ręki twej. I odszedł szathan od oblicza Pańskiego.
###### **Hi 1,13**
 A gdy dnia jednego synowie i córki jego jedli i pili wino w domu brata swego pierworodnego,
###### **Hi 1,14**
 Przybieżał poseł do Joba, któryby powiedział: Woły orały, a oślice pasiono podle nich,
###### **Hi 1,15**
 I przypadli Sabejczycy i zabrali wszystko, i czeladź mieczem pozabijali, i uszedłem ja sam, abychci oznajmił.
###### **Hi 1,16**
 A gdy ten jeszcze mówił, przyszedł drugi i rzekł: Ogień Boży spadł z nieba, i uderzywszy na owce i sługi spalił je, i wybiegałem się ja sam, abymci oznajmił.
###### **Hi 1,17**
 Ale gdy i ten jeszcze mówił, przyszedł inny, i rzekł: Chaldejczycy uczynili trzy hufy i rzucili się na wielbłądy, i zabrali je, i pachołki pozabijali mieczem: a tylkom ja sam uciekł, abychci oznajmił.
###### **Hi 1,18**
 Jeszcze ten mówił, ali drugi wszedł, i rzekł: Gdy synowie twoi i córki jedli i pili wino w domu brata swego pierworodnego,
###### **Hi 1,19**
 Znagła wiatr gwałtowny przypadł od strony pustynie, i zatrząsł czterema węgłami domu, który obaliwszy się przytłukł dzieci twoje i pomarły, i wybiegałem się ja sam, abychci oznajmił.
###### **Hi 1,20**
 Tedy Job wstał, i rozdarł szaty swoje, i ogoliwszy głowę upadszy na ziemię pokłonił się,
###### **Hi 1,21**
 I rzekł: Nagom wyszedł z żywota matki mojej, i nago się tam wrócę: Pan dał, Pan odjął: jako się Panu upodobało, tak się stało: niech będzie imię Pańskie błogosławione.
###### **Hi 1,22**
 W tem wszystkiem nie zgrzeszył Job usty swemi, i nic głupiego nie wyrzekł przeciw Bogu.
