# 1Krn 3 BT5

###### **1Krn 3,1**
  Oto synowie Dawida, którzy urodzili mu się w Hebronie: pierworodny Amnon z Achinoam, Jizreelitki, drugi Daniel z Abigail pochodzącej z Karmelu;
###### **1Krn 3,2**
 trzeci Absalom, syn Maaki, córki Talmaja, króla Geszuru; czwarty Adoniasz, syn Chaggity;
###### **1Krn 3,3**
 piąty Szefatiasz z Abitali; szósty Jitream z jego żony Egli.
###### **1Krn 3,4**
 Sześciu mu się urodziło w Hebronie, gdzie królował siedem lat i sześć miesięcy. Potem królował on trzydzieści trzy lata w Jerozolimie.
###### **1Krn 3,5**
 A synowie, którzy urodzili mu się w Jerozolimie: Szimea, Szobab, Natan, Salomon, czterej z Batszeby, córki Ammiela.
###### **1Krn 3,6**
 Potem Jibchar, Eliszua, Elifelet,
###### **1Krn 3,7**
 Nogah, Nefeg, Jafia,
###### **1Krn 3,8**
 Eliszama, Eliada, Elpalet, dziewięciu.
###### **1Krn 3,9**
 Wszyscy ci byli synami Dawida, nie licząc synów żon drugorzędnych. A siostrą ich była Tamar.
###### **1Krn 3,10**
 Synem Salomona był Roboam, synem Roboama – Abiasz, synem Abiasza – Asa, synem Asy – Jozafat,
###### **1Krn 3,11**
 synem Jozafata – Joram, synem Jorama – Ochozjasz, synem Ochozjasza – Joasz,
###### **1Krn 3,12**
 synem Joasza – Amazjasz, synem Amazjasza – Azariasz, synem Azariasza – Jotam,
###### **1Krn 3,13**
 synem Jotama – Achaz, synem Achaza – Ezechiasz, synem Ezechiasza – Manasses,
###### **1Krn 3,14**
 synem Manassesa – Amon, synem Amona – Jozjasz.
###### **1Krn 3,15**
 Synowie Jozjasza: pierworodny Jochanan, drugi Jojakim, trzeci Sedecjasz, czwarty Szallum.
###### **1Krn 3,16**
 Synowie Jojakima: jego syn Jechoniasz, jego syn Sedecjasz.
###### **1Krn 3,17**
 Synowie Jechoniasza uprowadzonego do niewoli: jego syn Szealtiel,
###### **1Krn 3,18**
 Malkiram, Pedajasz, Szeneassar, Jekamiasz, Hoszama i Nedabiasz.
###### **1Krn 3,19**
 Synowi Pedajasza: Zorobabel i Szimei. Synami Zorobabela: Meszullam i Chananiasz oraz ich siostra Szelomit.
###### **1Krn 3,20**
 [Synowie Meszullama]: Chaszuba, Chaszuba, Ohel, Berekiasz, Chasadiasz i Juszab-Chesed, pięciu.
###### **1Krn 3,21**
 Synowie Chananiasza: Pelatiasz i Izajasz; syn jego Refajasz, syn jego Arnan, syn jego Obadiasz, syn jego Szekaniasz.
###### **1Krn 3,22**
 Synowie Szekaniasza: Szemajasz, Chattusz, Jigeal, Bariach, Neariasz i Szafat, sześciu.
###### **1Krn 3,23**
 Synowie Neariasza: Elioenaj, Ezechiasz i Azrikam, trzej.
###### **1Krn 3,24**
 Synowie Elioenaja: Hodawiasz, Eliaszib, Pelajasz, Akkub, Jochanan, Delajasz i Anani, siedmiu.
# 1Krn 3 PAU
###### **1Krn 3,1**
 Oto synowie Dawida, którzy urodzili mu się w Hebronie: pierworodnym był Amnon, którego matką była Achinoam z Jezreel; drugim był Daniel, którego urodziła mu Abigail pochodząca z Karmelu;
###### **1Krn 3,2**
 trzecim był Absalom, syn Maaki, córki Talmaja, króla Geszuru; czwartym był Adoniasz, syn Chaggity.
###### **1Krn 3,3**
 Piątego, Szefatiasza, urodziła Abitala, a szóstego, Jetreama - Egla.
###### **1Krn 3,4**
 Przez siedem lat i sześć miesięcy, gdy panował w Hebronie, urodziło mu się sześciu synów. Przez następne trzydzieści trzy lata panował on w Jerozolimie.
###### **1Krn 3,5**
 Batszeba, córka Ammiela, urodziła mu w Jerozolimie czterech synów: Szimeia, Szobaba, Natana i Salomona.
###### **1Krn 3,6**
 Miał on jeszcze innych dziewięciu: Jebchara, Eliszuę, Elifeleta,
###### **1Krn 3,7**
 Nogaha, Nefega, Jafię,
###### **1Krn 3,8**
 Eliszamę, Eliadę, Elpaleta.
###### **1Krn 3,9**
 Wszyscy oni byli synami Dawida, nie licząc synów, których urodziły mu drugorzędne żony. Ich siostrą była Tamar.
###### **1Krn 3,10**
 Synem Salomona był Roboam, a synem Roboama - Abiasz, synem Abiasza - Asa, synem Asy - Jozafat.
###### **1Krn 3,11**
 Synem Jozafata - Joram, synem Jorama - Ochozjasz, synem Ochozjasza - Joasz.
###### **1Krn 3,12**
 Synem Joasza - Amazjasz, synem Amazjasza - Azariasz, synem Azariasza - Jotam.
###### **1Krn 3,13**
 Synem Jotama - Achaz, synem Achaza - Ezechiasz, synem Ezechiasza - Manasses.
###### **1Krn 3,14**
 Synem Manassesa - Amon, synem Amona - Jozjasz.
###### **1Krn 3,15**
 A oto synowie Jozjasza: pierworodny Jochanan, drugi Jojakim, trzeci Sedecjasz, czwarty Szallum.
###### **1Krn 3,16**
 Synami Jojakima byli Jechoniasz i Sedecjasz.
###### **1Krn 3,17**
 Synami Jechoniasza, uprowadzonego do niewoli, byli: Szealtiel,
###### **1Krn 3,18**
 Malkiram, Pedajasz, Szeneassar, Jekamiasz, Hoszama i Nedabiasz.
###### **1Krn 3,19**
 Synami Pedajasza byli: Zorobabel i Szimei. Synami Zorobabela: Meszullam i Chananiasz. Ich siostrą była Szelomit.
###### **1Krn 3,20**
 Meszullam miał pięciu synów: Chaszuba, Ohela, Berekiasza, Chasadiasza i Juszab-Cheseda.
###### **1Krn 3,21**
 Synami Chananiasza byli Pelatiasz i Izajasz, którego synem był Refajasz, którego synem był Arnan, którego synem był Obadiasz, którego synem był Szekaniasz.
###### **1Krn 3,22**
 Szekaniasz miał sześciu synów: Szemajasza, Chattusza, Igaala, Bariacha, Neariasza i Szafata.
###### **1Krn 3,23**
 Neariasz miał trzech synów: Elioenaja, Ezechiasza i Azrikama.
###### **1Krn 3,24**
 Elioenaj miał siedmiu synów: Hodawiasza, Eliasziba, Pelajasza, Akkuba, Jochanana, Delajasza i Ananiego.
# 1Krn 3 BP
###### **1Krn 3,1**
 A oto synowie Dawida, którzy mu się urodzili w Chebronie: pierworodny Amnon [zrodzony] z Achinoam Jizreelitki, drugi Daniel z Abigail, pochodzącej z Karmelu,
###### **1Krn 3,2**
 trzeci Abszalom, syn Maaki, córki Talmaja, króla Geszuru, czwarty Adonijja, syn Chaggity,
###### **1Krn 3,3**
 piąty Szefatja z Abital i szósty Itream z jego żony Egii.
###### **1Krn 3,4**
 Tych sześciu [synów] urodziło mu się w Chebronie. Królował tam siedem lat i sześć miesięcy, a w Jeruzalem królował trzydzieści trzy lata.
###### **1Krn 3,5**
 W Jeruzalem urodzili mu się: Szima, Szobab, Natan i Salomon, ci czterej z Bat-Szuy córki Ammiela.
###### **1Krn 3,6**
 Następnie Ibchar, Eliszua,
###### **1Krn 3,7**
 Nefeg, Jafia,
###### **1Krn 3,8**
 Eliszama, Eljada i Elifelet, [razem] siedmiu.
###### **1Krn 3,9**
 Wszyscy oni byli synami Dawida, nie licząc synów z żon drugorzędnych, a siostrą ich była Tamar.
###### **1Krn 3,10**
 Synem Salomona był Roboam, a jego synem Abia, jego synem Asa, jego synem Jozafat,
###### **1Krn 3,11**
 jego synem Joram, jego synem Ochozjasz, jego synem Joas,
###### **1Krn 3,12**
 jego synem Amazjasz, jego synem Azariasz, jego synem Jotam,
###### **1Krn 3,13**
 jego synem Achaz, jego synem Ezechiasz, jego synem Manasse,
###### **1Krn 3,14**
 jego synem Amon, a jego synem Jozjasz.
###### **1Krn 3,15**
 Synami Jozjasza byli: pierworodnym Jochanan, drugim Jojakim, trzecim Sedecjasz, czwartym Szallum.
###### **1Krn 3,16**
 Potomkami Jojakima byli: jego syn Jechoniasz i jego syn Sedecjasz.
###### **1Krn 3,17**
 Synami uprowadzonego do niewoli Jechoniasza byli: Szealtiel,
###### **1Krn 3,18**
 Malkiram, Pedaja, Szenaccar, Jekamija, Hoszama i Nedabja.
###### **1Krn 3,19**
 Synami Pedai byli: Zerubbabel i Szimi. Synami Zerubbabela byli: Meszullam i Chananja, a siostrą ich była Szelomit.
###### **1Krn 3,20**
 [Synami Maszullama byli]: Chaszuba, Ohel, Berekja, Chasadja i Juszab-Chesed [razem] pięciu.
###### **1Krn 3,21**
 Synami Chananji byli: Pelatja i Joszaja, jego synem był Refaja, jego synem Arnan, jego synem Obadja i jego synem Szekanja.
###### **1Krn 3,22**
 Synem Szekanji był Szemajasz, a synami Szemajasza byli: Chattusz, Jigal, Bariach, Nearia i Szafat [razem] sześciu.
###### **1Krn 3,23**
 Synami Nearji byli: Eljoenaj, Ezechiasz i Azrikam [razem] trzech.
###### **1Krn 3,24**
 Synami Eljoenaja byli: Hodawjahu, Eljaszib, Pelaja, Akkub, Jochanan, Delaja i Anani [razem] siedmiu.
# 1Krn 3 BR
###### **1Krn 3,1**
 A oto synowie Dawida, którzy przyszli na świat w Hebronie. Jego synem pierworodnym był Ammon, urodzony z Izraelitki Achinoam; matką drugiego, Daniela, była Abigail z Karmelu;
###### **1Krn 3,2**
 trzeci, Absalom, był synem Maaki, córki Talmaja, króla Geszuru; czwarty, Adoniasz, był synem Chaggity;
###### **1Krn 3,3**
 matką piątego, czyli Szefatiasza, była Abital, a szóstego, czyli Jitreama - Egla.
###### **1Krn 3,4**
 Tych sześciu synów urodziło się Dawidowi w Hebronie, gdzie królował przez siedem lat i sześć miesięcy. Potem przez lat trzydzieści sprawował władzę w Jerozolimie.
###### **1Krn 3,5**
 A oto synowie Dawida, którzy przyszli na świat w Jerozolimie: Szimea, Szobab, Natan, Salomon - wszystkich czterech urodziła mu Batszeba, córka Ammiela.
###### **1Krn 3,6**
 Potem kolejno przyszło na świat dziewięciu synów: Jibchar, Eliszua, Elifelet,
###### **1Krn 3,7**
 Nogah, Nefeg, Jafia,
###### **1Krn 3,8**
 Eliszama, Eliada, Elpalet.
###### **1Krn 3,9**
 Oto synowie Dawida. Poza tym miał Dawid synów, których matkami były jego nałożnice. Miał też Dawid jedną córkę imieniem Tamar.
###### **1Krn 3,10**
 Salomon był ojcem Roboama, Roboam ojcem Abiasza, Abiasz ojcem Asy, Asa ojcem Jozafata,
###### **1Krn 3,11**
 Jozafat ojcem Jorama, Joram ojcem Ochozjasza, Ochozjasz ojcem Joasza,
###### **1Krn 3,12**
 Joasz ojcem Amazjasza, Amazjasz ojcem Azariasza, Azariasz ojcem Jotama,
###### **1Krn 3,13**
 Jotam ojcem Achaza, Achaz ojcem Ezechiasza, Ezechiasz ojcem Manassesa,
###### **1Krn 3,14**
 Manasses ojcem Amona, Amon ojcem Jozjasza.
###### **1Krn 3,15**
 A oto synowie Jozjasza: Jochanan jako pierworodny, drugi Jojakim, trzeci Sedecjasz, czwarty Szallum.
###### **1Krn 3,16**
 Synami Jojakima byli: Jojachin i Sedecjasz,
###### **1Krn 3,17**
 natomiast synami Jechoniasza, uprowadzonego do niewoli, byli: Szealtiel,
###### **1Krn 3,18**
 Malkiram, Pedajasz, Szeneassar, Jekamiasz, Hoszama i Nedabiasz.
###### **1Krn 3,19**
 Synami Pedajasza byli Zorobabel i Szimei, a synami Zorobabela Meszullam i Chananiasz. Siostra ich nazywała się Szelomit.
###### **1Krn 3,20**
 A oto synowie Meszullama: Chaszuba, Ohel, Berekiasz, Chasadiasz oraz Juszab-Chesed - razem pięciu.
###### **1Krn 3,21**
 Potomkami Chananiasza byli: Pelatiasz, Izajasz, Refajasz, Arnan, Obadiasz i Szekaniasz.
###### **1Krn 3,22**
 Synami zaś Szekaniasza byli: Szemajasz, Chattusz, Jigeal, Bariach, Neriasz i Szafat - razem sześciu.
###### **1Krn 3,23**
 Synami Neariasza byli: Elioenaj, Ezechiasz i Azrikam - ci trzej.
###### **1Krn 3,24**
 Elioenaj miał siedmiu synów. Oto oni: Hodawiasz, Eliaszib, Pelajasz, Akkub, Jochanan, Delajasz i Anani.
# 1Krn 3 WUJ
###### **1Krn 3,1**
 A Dawid miał te syny, którzy się mu urodzili w Hebron: pierworodnego Amnona z Achinoam Jezrahelitki, wtórego Daniela z Abigail Karmelitki.
###### **1Krn 3,2**
 Trzeciego Absaloma syna Maacha córki Tholmaja króla Gessur: czwartego Adoniasza syna Aggithy,
###### **1Krn 3,3**
 Piątego Sapharyasza z Abitale: szóstego Jethrahama z Egle żony jego.
###### **1Krn 3,4**
 A tak sześć mu się urodziło w Hebronie, gdzie królował siedm lat i sześć miesięcy. A trzydzieści i trzy lata królował w Jeruzalem.
###### **1Krn 3,5**
 A w Jeruzalem urodzili mu się synowie, Simmaa, i Sobab, i Nathan, i Salomon, czterzej z Bethsabee córki Amielowej.
###### **1Krn 3,6**
 Jebaar też, i Elisama.
###### **1Krn 3,7**
 I Eliphaleth, i Noge, i Nepheg, i Japhia,
###### **1Krn 3,8**
 I EHsama, i Eliada, i Elipheleth, dziewięć:
###### **1Krn 3,9**
 Ci wszyscy synowie Dawidowi, oprócz synów nałożnic, a mieli siostrę Thatnar.
###### **1Krn 3,10**
 A syn Salomonów, Roboam, którego syn Abia zrodził Asę. Z tego też zrodził się Jozaphat,
###### **1Krn 3,11**
 Ociec Joram: który Joram zrodził Ochoziasza, z którego poszedł Joas:
###### **1Krn 3,12**
 A tego syn Amazyasz zrodził Azaryasza. A Joathan syn Azaryaszów
###### **1Krn 3,13**
 Zrodził Achaza ojca Ezechiaszowego, z którego uradził się Manasses.
###### **1Krn 3,14**
 Ale i Manasses zrodził Amona ojca Joziaszowego,
###### **1Krn 3,15**
 A synowie Joziaszowi byli, pierworodny Johanan, wtóry Joakim, trzeci Sedecyasz, czwarty Sellum.
###### **1Krn 3,16**
 Z Joakim urodził się Jechoniasz, i Sedecyasz.
###### **1Krn 3,17**
 Synowie Jechoniaszowi byli, Asir, Salathiel,
###### **1Krn 3,18**
 Melchiram, Phadaja, Senneser, i Jecemia, Sama, i Nadabia.
###### **1Krn 3,19**
 Z Phadaja poszli Zorobabel, i Samei. Zorobabel zrodził Mosollama, Hananiasza, i Salomitę siostrę ich:
###### **1Krn 3,20**
 Hasabana też, i Ohola, i Barachiana, i Hasadiana, i Josabheseda, piąci.
###### **1Krn 3,21**
 A syn Hananiaszów, Phaltias ociec Jesejaszów, którego syn Raphaja. Tego też syn, Arnan, z którego poszedł Obdia, którego syn był Secheniasz.
###### **1Krn 3,22**
 Syn Secheniaszów, Semeia: którego synowie Hattus, i Jegaal, i Baria, i Naaria, i Saphat, liczbą sześć.
###### **1Krn 3,23**
 Syn Naariaszów, Elioenai, i Ezechiasz, i Erikzelea trzej.
###### **1Krn 3,24**
 Synowie Elioenai, Odwia, i Eliasub, i Pheleja, i Akkub, i Johanan, i Dalaja: i Anani, siedm.
