# 2Mch 4 BT5
###### **2Mch 4,1**
 Wspomniany już Szymon, który był zdrajcą skarbów i ojczyzny, oskarżył Oniasza, jakoby on działał przeciwko Heliodorowi i był sprawcą tych nieszczęść.
###### **2Mch 4,2**
 Dobroczyńcę miasta oraz tego, który wspomagał swych rodaków i gorliwie zachowywał Prawo, śmiał on nazywać wrogiem ładu.
###### **2Mch 4,3**
 Nienawiść doszła do tego stopnia, że jeden ze zwolenników Szymona zaczął dopuszczać się zabójstw.
###### **2Mch 4,4**
 Oniasz zaś widząc, jak trudne byłoby współzawodnictwo i że Apoloniusz, syn Menesteusa, wódz wojsk Celesyrii i Fenicji, podnieca złość Szymona,
###### **2Mch 4,5**
 udał się do króla. Nie po to, aby być oskarżycielem rodaków, ale by zwrócić uwagę na dobro ogólne, a zwłaszcza całego narodu.
###### **2Mch 4,6**
 Wiedział bowiem, że bez zarządzenia królewskiego nie będzie możliwe osiągnięcie pokoju publicznego i że Szymon nie zaprzestanie swego szaleństwa.
###### **2Mch 4,7**
 Kiedy Seleukos zakończył życie, a władzę objął Antioch mający przydomek Epifanes, w niegodziwy sposób dostał się na arcykapłańskie stanowisko Jazon, brat Oniasza.
###### **2Mch 4,8**
 W czasie spotkania obiecywał on królowi trzysta sześćdziesiąt talentów w srebrze, a z innych jakichś dochodów osiemdziesiąt talentów.
###### **2Mch 4,9**
 Ponadto zobowiązał się do wypłacenia jeszcze stu pięćdziesięciu, jeżeli mu będzie dozwolone urządzić własnym kosztem gimnazjum i efebion, a mieszkańców Jerozolimy zapisać do antiocheńczyków.
###### **2Mch 4,10**
 Król zgodził się, a kiedy on objął władzę, zaraz zaczął narzucać swym rodakom grecki sposób życia.
###### **2Mch 4,11**
 Zniósł humanitarne przywileje królewskie, z jakich korzystali Żydzi dzięki staraniom Jana, ojca Eupolemosa, tego, który udał się w poselstwie, aby z Rzymianami zawrzeć traktat przyjaźni i przymierza wojskowego. Burząc Prawem uświęcone ustalenia, wprowadzał zwyczaje przeciwne Prawu.
###### **2Mch 4,12**
 Umyślnie bowiem pod samym zamkiem wybudował gimnazjum i najlepszych młodzieńców zachęcił do włożenia kapelusza.
###### **2Mch 4,13**
 Nastąpiło tak wielkie rozkrzewienie hellenizmu i taka moda na obce obyczaje, pod wpływem Jazona, niezwykłej nikczemności bezbożnika, a wcale nie arcykapłana,
###### **2Mch 4,14**
 tak iż kapłani nie okazywali już żadnej gorliwości w służbie ołtarza, ale gardząc świątynią i zaniedbując ofiary, zaraz na sygnał [do rzucania] dyskiem śpieszyli się, aby wziąć udział w niezgodnych z Prawem ćwiczeniach palestry.
###### **2Mch 4,15**
 Za nic sobie mając zaszczyty ojczyste, za najpiękniejsze uważali greckie odznaczenia.
###### **2Mch 4,16**
 Oto dlaczego znaleźli się w trudnym położeniu; w tych, których życie chcieli naśladować i do których chcieli się upodobnić, znaleźli nieprzyjaciół i ciemiężycieli.
###### **2Mch 4,17**
 Występowanie bowiem przeciwko Bożym prawom nie ujdzie bezkarnie, ale to się okaże w chwili, która nastanie.
###### **2Mch 4,18**
 Gdy w Tyrze wobec króla obchodzono co pięć lat urządzane igrzyska,
###### **2Mch 4,19**
 bezecny Jazon wysłał jako widzów rzekomych przedstawicieli Jerozolimy, będących antiocheńczykami. Zabrali oni ze sobą trzysta drachm w srebrze na ofiarę dla [boga] Heraklesa. Sami jednak ci, którzy je zabrali, uznali, że nie można, bo nie godzi się ich złożyć na ofiarę, ale że [należy] je przeznaczyć na inny wydatek.
###### **2Mch 4,20**
 Tak więc to, co wysyłający przeznaczył na ofiarę dla Heraklesa, dzięki przewożącym poszło na budowę trójrzędowców.
###### **2Mch 4,21**
 Gdy Apoloniusz, syn Menesteusa, został posłany do Egiptu na uroczystość wstąpienia na tron króla Filometora, Antioch dowiedział się, że ten [król] stał się wrogiem jego panowania, zatroszczył się więc o własne bezpieczeństwo. Dlatego też, znalazłszy się w Jafie, udał się do Jerozolimy,
###### **2Mch 4,22**
 gdzie bardzo uroczyście został przyjęty przez Jazona i miasto, przy świetle pochodni i wśród okrzyków. Później tak samo z wojskiem udał się do Fenicji.
###### **2Mch 4,23**
 Po upływie trzech lat Jazon posłał po Menelaosa, brata wspomnianego Szymona, aby odwiózł pieniądze dla króla i przedstawił memoriał dotyczący ważnych spraw.
###### **2Mch 4,24**
 On zaś, przedstawiony królowi, olśnił go pozorami wpływów, zdobył więc dla siebie godność arcykapłańską, ofiarowując o trzysta talentów więcej niż Jazon.
###### **2Mch 4,25**
 Zaopatrzony w listy królewskie, zjawił się, nie posiadając wcale cech godnych stanowiska arcykapłana, bo tylko dyszał zawziętością okrutnego tyrana i złością dzikiego zwierza.
###### **2Mch 4,26**
 Tak więc Jazon, który wygnał podstępnie własnego brata, sam został przez drugiego wygnany i zmuszony, by uciekać do kraju Ammonitów.
###### **2Mch 4,27**
 Menelaos zaś objął władzę, nic jednak nie wypłacał z pieniędzy obiecanych królowi,
###### **2Mch 4,28**
 choć domagał się ich Sostratos, dowódca zamku. Do niego bowiem należało pobieranie podatków. Z tego powodu obydwaj zostali wezwani przed króla.
###### **2Mch 4,29**
 Wtedy Menelaos zostawił w swoim zastępstwie na stanowisku arcykapłańskim Lizymacha, własnego brata, Sostratos zaś Kratesa, dowódcę Cypryjczyków.
###### **2Mch 4,30**
 Po tych wydarzeniach mieszkańcy Tarsu i Mallos zbuntowali się, dlatego że zostali podarowani królewskiej nałożnicy, Antiochis.
###### **2Mch 4,31**
 Król więc natychmiast wyruszył, aby przywrócić ład, pozostawiając w swoim zastępstwie Andronika, jednego z dostojników.
###### **2Mch 4,32**
 Menelaos zaś w przekonaniu, że nadeszła odpowiednia chwila, przywłaszczył sobie i podarował Andronikowi niektóre złote naczynia świątynne. Inne zaś udało mu się sprzedać w Tyrze i w okolicznych miastach.
###### **2Mch 4,33**
 Przekonawszy się o tym, Oniasz ostro go upomniał, a sam usunął się na miejsce azylu do Dafne, które leży koło Antiochii.
###### **2Mch 4,34**
 Na skutek tego Menelaos wziął na bok Andronika i namawiał go, by zgładził Oniasza. Ten więc przybył do Oniasza, namawiał go podstępnie do wyjścia i składając przysięgę, podał mu swoją prawicę. Chociaż budził podejrzenia, przekonał go do wyjścia z miejsca azylu. Natychmiast też zamordował go bez żadnych względów na sprawiedliwość.
###### **2Mch 4,35**
 Z tej to przyczyny nie tylko Żydzi oburzeni byli i zasmuceni niesprawiedliwym zamordowaniem tego męża, ale również wielu spomiędzy innych narodów.
###### **2Mch 4,36**
 Kiedy król powrócił z miast Cylicji, udali się do niego Żydzi z miasta oraz niektórzy Grecy, oburzeni tym, że Oniasz został zamordowany wbrew prawu.
###### **2Mch 4,37**
 Antioch zaś, do głębi zasmucony oraz poruszony współczuciem aż do łez nad zmarłym, ze względu na jego roztropność i wielką łagodność,
###### **2Mch 4,38**
 zapłonąwszy gniewem, natychmiast zdarł z Andronika purpurowy płaszcz i podarł jego szaty oraz kazał go prowadzić przez całe miasto aż na to miejsce, na którym okazał wobec Oniasza swoją bezbożność. Tam mordercę kazał zgładzić ze świata. Tak Pan wymierzył mu zasłużoną karę.
###### **2Mch 4,39**
 Gdy Lizymach za zgodą Menelaosa popełnił wiele świętokradztw w mieście, a wieść o tym rozeszła się na zewnątrz, ludność zbuntowała się przeciw Lizymachowi. Wiele jednak złotych przedmiotów było już roztrwonionych.
###### **2Mch 4,40**
 Kiedy zaś tłumy podniosły się, a ich gniew doszedł do szczytu, Lizymach uzbroił blisko trzy tysiące ludzi i rozpoczął niesprawiedliwe, gwałtowne postępowanie. Dowódcą był pewien Auranos, podeszły w latach i nie mniej posunięty w głupocie.
###### **2Mch 4,41**
 Widząc gwałtowne postępowanie Lizymacha, jedni pochwycili za kamienie, drudzy za grube kije, niektórzy zaś brali leżący tam piasek i jeden przez drugiego rzucali na ludzi Lizymacha.
###### **2Mch 4,42**
 Skutkiem tego wielu z nich poranili, niektórych nawet zabili, wszystkich zaś zmusili do ucieczki. Samego świętokradcę zamordowali koło skarbca.
###### **2Mch 4,43**
 W tych sprawach zostało wszczęte dochodzenie przeciwko Menelaosowi.
###### **2Mch 4,44**
 Trzech mężów z rady starszych wniosło oskarżenie przeciw niemu, gdy król przybył do Tyru.
###### **2Mch 4,45**
 Menelaos, jako już przegrany, obiecał Ptolemeuszowi, synowi Dorymenesa, wielką sumę, aby ułagodzić króla.
###### **2Mch 4,46**
 Ptolemeusz zaś wziął ze sobą króla do perystylu, niby po to, aby się ochłodzić, i wpłynął na zmianę poglądów króla.
###### **2Mch 4,47**
 Uwolnił on Menelaosa, winnego wszystkiego zła, o jakie był oskarżony, nieszczęśliwych zaś, którzy byliby uniewinnieni, nawet gdyby ich oskarżono przed Scytami, skazał na śmierć.
###### **2Mch 4,48**
 Zaraz też niesprawiedliwą karę ponieśli ci, którzy wstawili się za miastem, narodem i świętymi naczyniami.
###### **2Mch 4,49**
 Z tej też przyczyny oburzeni mieszkańcy Tyru urządzili im uroczysty pogrzeb.
###### **2Mch 4,50**
 Menelaos zaś pozostał na stanowisku dzięki chciwości tych, którzy mieli władzę, będąc zaś głównym prześladowcą rodaków, umacniał się w złu.
# 2Mch 4 PAU
###### **2Mch 4,1**
 Wspomniany Szymon, który doniósł o skarbach i zdradził ojczyznę, oczerniał Oniasza, że to on spowodował pobicie Heliodora i był sprawcą tych nieszczęść.
###### **2Mch 4,2**
 Dobroczyńcę miasta i obrońcę rodaków oraz gorliwego stróża praw ośmielił się nazwać zdrajcą spraw publicznych.
###### **2Mch 4,3**
 Wrogość Szymona wzmogła się tak bardzo, że ktoś z jego zwolenników dopuścił się morderstw.
###### **2Mch 4,4**
 Oniasz widział, że spór jest zaciekły oraz że Apoloniusz, syn Menesteosa, wódz Celesyrii i Fenicji, wspiera Szymona w złym postępowaniu.
###### **2Mch 4,5**
 Udał się więc do króla, lecz nie po to, aby oskarżać obywateli, ale mając na względzie wspólne dobro - całego ludu i własne.
###### **2Mch 4,6**
 Zrozumiał bowiem, że bez królewskiej decyzji nie można osiągnąć pokoju w sprawach publicznych ani położyć kresu szaleństwu Szymona.
###### **2Mch 4,7**
 Gdy po śmierci Seleukosa królestwo przejął Antioch, zwany Epifanesem, Jazon, brat Oniasza, w nieprawy sposób przejął urząd najwyższego kapłana,
###### **2Mch 4,8**
 obiecując królowi podczas spotkania trzysta sześćdziesiąt talentów srebra i osiemdziesiąt talentów z innych dochodów.
###### **2Mch 4,9**
 Ponadto przyrzekł, że przekaże królowi jeszcze sto pięćdziesiąt, jeśli otrzyma pozwolenie na budowę gimnazjonu i efebejonu oraz na wpisanie mieszkańców Jerozolimy na listę Antiocheńczyków.
###### **2Mch 4,10**
 Gdy król się na to zgodził, Jazon po zdobyciu władzy natychmiast zaczął wprowadzać wśród swoich rodaków grecki styl życia.
###### **2Mch 4,11**
 Zniósł korzystne przywileje królewskie udzielone Żydom za wstawiennictwem Jana, ojca Eupolemosa, który potem został posłem do Rzymian w sprawie przyjaźni i przymierza. Tak więc Jazon zniósł obowiązujące zwyczaje, a wprowadził nowe, sprzeczne z Prawem.
###### **2Mch 4,12**
 Z radością wybudował gimnazjon u stóp samego akropolu i najlepszych młodzieńców nakłonił do noszenia greckiego kapelusza.
###### **2Mch 4,13**
 Z powodu przekraczającej wszelkie granice przewrotności bezbożnego Jazona, nie najwyższego kapłana, doszło do takiego rozkwitu hellenizmu i panoszenia się obcych obyczajów,
###### **2Mch 4,14**
 że nawet kapłani przestali być gorliwi w służbie ołtarza. Pogardzając świątynią i zaniedbując ofiary, spieszyli, aby na wezwanie do rzutu dyskiem wziąć udział w przeciwnych Prawu zawodach na stadionie.
###### **2Mch 4,15**
 Nie szanowali ojczystych godności, lecz za najpiękniejsze uważali greckie zaszczyty.
###### **2Mch 4,16**
 Z tego powodu przyszedł na nich ciężki kryzys. Właśnie ci, których styl życia pragnęli żarliwie naśladować i do których chcieli się upodobnić, stali się ich wrogami i narzędziami kary.
###### **2Mch 4,17**
 Wykraczanie bowiem przeciwko Bożym prawom nie jest rzeczą błahą. Lecz ukaże to chwila, która nadejdzie.
###### **2Mch 4,18**
 Kiedy król przybył do Tyru na urządzane tam co pięć lat zawody,
###### **2Mch 4,19**
 podły Jazon wysłał tam delegację jerozolimskich Antiocheńczyków, aby zanieśli trzysta drachm srebra na ofiarę dla Herkulesa. Posłańcy jednakże uznali, że nie godzi się przekazać tych pieniędzy na ofiarę, ale lepiej wydać je na inny cel.
###### **2Mch 4,20**
 Dlatego to, co przesłano na ofiarę dla Herkulesa, za ich przyczyną przekazano na budowę trójrzędowców.
###### **2Mch 4,21**
 Od Apoloniusza, syna Menesteosa, wysłanego do Egiptu na uroczystość do króla Filometora, Antioch dowiedział się, że król ten nie jest mu przychylny. Postanowił więc zatroszczyć się o swoje bezpieczeństwo. Z tego powodu udał się do Jafy, a potem do Jerozolimy.
###### **2Mch 4,22**
 Jazon i mieszkańcy miasta przywitali go uroczyście, paląc pochodnie i wiwatując. Stamtąd wyruszył z wojskiem do Fenicji.
###### **2Mch 4,23**
 Po trzech latach Jazon posłał Menelaosa, brata wspomnianego już Szymona, aby zawiózł pieniądze królowi i załatwił kilka pilnych spraw publicznych.
###### **2Mch 4,24**
 Ten zaś, przedstawiony królowi, oczarował go pozorem swej potęgi i zdobył dla siebie urząd najwyższego kapłana, dając o trzysta talentów srebra więcej niż Jazon.
###### **2Mch 4,25**
 Kiedy otrzymał królewskie rozkazy i powrócił, okazał się niegodny urzędu najwyższego kapłana. Był raczej okrutnym tyranem i miał usposobienie dzikiej bestii.
###### **2Mch 4,26**
 Tak to Jazon, który oszukał własnego brata, sam został oszukany i musiał uciekać do kraju Ammonitów.
###### **2Mch 4,27**
 Menelaos tymczasem przejął władzę, ale nie wpłacił pieniędzy obiecanych królowi.
###### **2Mch 4,28**
 Wtedy Sostratos, dowódca akropolu, zaczął się ich domagać, ponieważ do niego należało ściąganie podatków. Obaj więc zostali wezwani do króla.
###### **2Mch 4,29**
 Menelaos zostawił zatem Lizymacha, swego brata, jako zastępcę na urzędzie najwyższego kapłana, a Sostratos - Kratesa, dowódcę Cypryjczyków.
###### **2Mch 4,30**
 W tym samym czasie mieszkańcy Tarsu i Mallos zbuntowali się, ponieważ podarowano ich królewskiej konkubinie Antiochis.
###### **2Mch 4,31**
 Król wyruszył więc natychmiast, aby uregulować sprawy, pozostawiając w zastępstwie Andronika, jednego z wyższych urzędników.
###### **2Mch 4,32**
 Menelaos, sądząc, że jest to odpowiedni moment, ukradł niektóre złote przedmioty ze świątyni i podarował je Andronikowi. Inne udało mu się sprzedać w Tyrze i w okolicznych miastach.
###### **2Mch 4,33**
 Kiedy Oniasz upewnił się co do tych faktów, schronił się w pobliżu Antiochii, w Dafne, które było miejscem azylu, i stamtąd upomniał Menelaosa.
###### **2Mch 4,34**
 Wtedy Menelaos, rozmawiając z Andronikiem na osobności, nakłonił go do zabicia Oniasza. Andronik udał się więc do Oniasza i podstępem chciał zdobyć jego zaufanie. Podał mu nawet prawą rękę i złożył przysięgę. Chociaż Oniasz był ciągle nieufny, Andronik przekonał go do wyjścia z miejsca azylu. Zaraz też zamordował go, nie bacząc na sprawiedliwość.
###### **2Mch 4,35**
 Nie tylko Żydzi, ale wiele innych ludów oburzyło się i zmartwiło z powodu niesprawiedliwości, jaką było zabójstwo tego człowieka.
###### **2Mch 4,36**
 Kiedy król powrócił z okolic Cylicji, udali się do niego Żydzi mieszkający w tym mieście oraz Grecy, którzy także nienawidzili zła, jakim było zabicie Oniasza bez powodu.
###### **2Mch 4,37**
 Antioch pogrążył się w smutku i pełen współczucia płakał, wspominając jego mądrość i wielką łagodność.
###### **2Mch 4,38**
 Rozpalony gniewem, natychmiast kazał zdjąć z Andronika purpurę, zedrzeć z niego ubranie i tak prowadzić go przez całe miasto aż do miejsca, gdzie popełniono niegodziwość na Oniaszu. Tam kazał zabić mordercę. W ten sposób PAN wymierzył mu zasłużoną karę.
###### **2Mch 4,39**
 Wiele świętokradztw popełnił w mieście Lizymach za przyzwoleniem Menelaosa. Gdy stało się to jawne, lud wystąpił przeciwko Lizymachowi, ale liczne złote przedmioty były już roztrwonione.
###### **2Mch 4,40**
 Ponieważ tłum był wzburzony i przepełniony gniewem, Lizymach uzbroił około trzy tysiące ludzi i wysłał ich do niegodziwego ataku. Dowodził nimi niejaki Auranos, podeszły w latach i nie mniej podeszły w głupocie.
###### **2Mch 4,41**
 Kiedy ludzie zdali sobie sprawę z ataku Lizymacha, jedni chwycili za kamienie, inni za grube kije, a jeszcze inni chwytali garściami leżący piasek i chaotycznie rzucali się na sługi Lizymacha.
###### **2Mch 4,42**
 Wielu z nich zranili, niektórych nawet zabili, a pozostałych zmusili do ucieczki. Świętokradcę zaś zabili w pobliżu skarbca.
###### **2Mch 4,43**
 Z powodu tych wydarzeń wszczęto proces przeciwko Menelaosowi.
###### **2Mch 4,44**
 Kiedy król przybył do Tyru, trzej ludzie wysłani przez radę starszych wnieśli przeciwko niemu oskarżenie.
###### **2Mch 4,45**
 Menelaos, mając świadomość swojej przegranej, obiecał Ptolemeuszowi, synowi Dorymenesa, dużo pieniędzy, aby przekonał do niego króla.
###### **2Mch 4,46**
 Ptolemeusz więc poszedł z królem na dziedziniec, jakoby dla zaczerpnięcia powietrza, i tak na niego wpłynął,
###### **2Mch 4,47**
 że król uwolnił oskarżonego o wszelkie zło Menelaosa. Skazał natomiast na śmierć tych nieszczęśników, którzy nawet gdyby przemawiali do Scytów, zostaliby uwolnieni jako niewinni.
###### **2Mch 4,48**
 Tak więc teraz ci, którzy wstawiali się za miastem, ludem i świętymi naczyniami, ponieśli niesprawiedliwą karę.
###### **2Mch 4,49**
 Oburzyło to nawet mieszkańców Tyru, którzy wyprawili im wspaniały pogrzeb.
###### **2Mch 4,50**
 Menelaos zaś pozostał przy władzy z powodu chciwości panujących. Coraz bardziej pogrążał się w złu i był wielkim prześladowcą obywateli.
# 2Mch 4 BP
###### **2Mch 4,1**
 Wspomniany Szymon, zdrajca skarbów i ojczyzny, oczernił Oniasza, jakoby to on pobił Heliodora i był sprawcą całego nieszczęścia.
###### **2Mch 4,2**
 Dobroczyńcę miasta, obrońcę rodaków i gorliwego stróża Prawa ośmielił się nazwać przeciwnikiem władzy [królewskiej].
###### **2Mch 4,3**
 Wrogość zaś posunęła się tak daleko, że jeden z zaufanych Szymona dopuszczał się mordów.
###### **2Mch 4,4**
 Oniasz rozumiejąc, że walka byłaby niebezpieczna i że Apoloniusz, syn Menesteusa, wódz Celesyrii i Fenicji, stara się podsycić złość Szymona,
###### **2Mch 4,5**
 odniósł się do króla nie po to, by oskarżać swoich rodaków, lecz mając na względzie dobro publiczne i prywatne całego narodu.
###### **2Mch 4,6**
 Wiedział bowiem, że bez pośrednictwa króla nie nastąpi pokój w życiu publicznym i że Szymon nie porzuci swych niecnych zamiarów.
###### **2Mch 4,7**
 Po śmierci Seleukosa, gdy władzę w państwie objął Antioch, mający przydomek Epifanes, Jazon, brat Oniasza, zagarnął nieprawnie urząd arcykapłana.
###### **2Mch 4,8**
 Spotkawszy się z królem przyrzekł mu trzysta sześćdziesiąt talentów srebra oraz osiemdziesiąt talentów z innych źródeł.
###### **2Mch 4,9**
 Nadto obiecał przekazać jeszcze sto pięćdziesiąt talentów, jeżeli na podstawie własnego rozporządzenia będzie mógł urządzić plac sportowy i miejsce ćwiczeń dla młodzieży oraz nadawać obywatelstwo Antiochii mieszkańcom Jerozolimy.
###### **2Mch 4,10**
 Ponieważ król zgodził się, zaraz po objęciu władzy rozpoczął [Jazon] wprowadzać wśród rodaków zwyczaje greckie.
###### **2Mch 4,11**
 Zniósł przywileje, jakie królowie przyznali Żydom za sprawą Jana, ojca Eupolemosa, tego, który sprawował poselstwo do Rzymu, aby zawrzeć układ przyjaźni i przymierza. Znosił także obowiązujące postanowienia prawne, a wprowadził zwyczaje nowe, przeciwne Prawu.
###### **2Mch 4,12**
 Umyślnie pod tym samym zamkiem wybudował gimnazjon i najznakomitszych młodzieńców nakłonił do noszenia [greckiego] kapelusza.
###### **2Mch 4,13**
 Upodobanie do greczyzny i moda przyjmowania obcych zwyczajów osiągnęły szczyt przez niespotykaną niegodziwość Jazona, bezbożnika, który nie miał w sobie nic z arcykapłana,
###### **2Mch 4,14**
 tak że kapłani nie troszczyli się wcale o służbę przy ołtarzu, a gardząc Świątynią i zaniedbując ofiary spieszyli wziąć udział w zakazanych przez Prawo ćwiczeniach na boisku, skoro tylko ogłoszono rzut dyskiem.
###### **2Mch 4,15**
 Stare, rodzime zaszczyty mieli za nic, a najwyżej cenili sobie godności greckie.
###### **2Mch 4,16**
 Z tego powodu znaleźli się w ciężkim położeniu, albowiem ci, których sposób życia tak gorliwie naśladowali i do których całkowicie chcieli się upodobnić, okazali się ich wrogami i ciemięzcami.
###### **2Mch 4,17**
 Nie gwałci się bowiem bezkarnie praw Bożych, jak okażą przyszłe dzieje.
###### **2Mch 4,18**
 Gdy w Tyrze w obecności króla odbywały się rozgrywane co pięć lat igrzyska,
###### **2Mch 4,19**
 jako delegację Jerozolimy wysłał bezbożny Jazon Antiocheńczyków, aby w nich uczestniczyli. Mieli oni zabrać z sobą trzysta srebrnych drachm na ofiarę dla Heraklesa. Ci, którzy zawieźli pieniądze, uznali jednak, że nie godzi się przeznaczyć ich na ofiarę, lecz trzeba wydać je na coś innego.
###### **2Mch 4,20**
 Tak więc pieniądze, które według woli ofiarodawcy miały pójść na ofiarę dla Heraklesa, obrócili na budowę trier.
###### **2Mch 4,21**
 Po wysłaniu Apoloniusza, syna Menesteusa, do Egiptu z okazji wstąpienia na tron króla [Ptolemeusza] Filometora, Antioch dowiedział się, że [Filometor] sprzeciwia się jego polityce. Zaczął więc myśleć o zapewnieniu sobie bezpieczeństwa. Udał się zatem do Joppy, a stamtąd podążył do Jerozolimy.
###### **2Mch 4,22**
 Jazon wraz z całym miastem przyjął go bardzo okazale; wjechał przy świetle pochodni i wśród wiwatujących okrzyków. Następnie wyruszył z wojskiem do Fenicji.
###### **2Mch 4,23**
 W trzy lata później wysłał Jazon Menelaosa, brata wspomnianego już Szymona, aby przekazał królowi pieniądze i doprowadził do końca wszczęte już pilne sprawy państwowe.
###### **2Mch 4,24**
 Nawiązał przyjazne stosunki z królem, a schlebiał mu [w tym sensie], jakoby był człowiekiem wpływowym, i zwracając się do niego z prośbą o godność arcykapłańską ofiarował [za nią] trzysta talentów srebra więcej niż Jazon.
###### **2Mch 4,25**
 Zaopatrzony w królewskie rozkazy powrócił [do Jerozolimy]. Nie miał w sobie nic, co byłoby godne arcykapłana, a tylko namiętności okrutnego tyrana i wściekłość dzikiego zwierzęcia.
###### **2Mch 4,26**
 Tak więc Jazon, który [chytrze] podkupił własnego brata, sam podkupiony przez innego jako zbieg schronił się w kraju Ammonitów.
###### **2Mch 4,27**
 Tymczasem Menelaos objął wprawdzie władzę, nie wypłacił jednak królowi przyrzeczonych pieniędzy
###### **2Mch 4,28**
 pomimo upomnień dowódcy zamku Sostratesa, który zajmował się zbieraniem podatków. To właśnie było powodem, że obydwaj wezwani zostali przez króla.
###### **2Mch 4,29**
 Menelaos zostawił brata swojego Lizymacha jako zastępcę na urzędzie arcykapłana, Sostrates zaś Kratesa, dowódcę Cypryjczyków.
###### **2Mch 4,30**
 Gdy się to działo, doszło do powstania mieszkańców Tarsu i Mallos, ponieważ [miasta te] podarowano nałożnicy królewskiej imieniem Antiochis.
###### **2Mch 4,31**
 Król przybył więc bezzwłocznie, aby przywrócić porządek. Zastępcą swym wyznaczył Andronika, jednego z wysokich urzędników.
###### **2Mch 4,32**
 Menelaos sądząc, że nadarzyła się dogodna okazja, przywłaszczył sobie ze Świątyni część złotych naczyń i [niektóre z nich] podarował Andronikowi, resztę zaś sprzedał w Tyrze i okolicznych miastach.
###### **2Mch 4,33**
 Oniasz, dowiedziawszy się całej prawdy, ostro zganił Menelaosa, po czym usunął się na miejsce azylu do Dafne, leżącej w pobliżu Antiochii.
###### **2Mch 4,34**
 Menelaos zatem przyjął Andronika na osobności i usilnie namawiał go, aby zgładził Oniasza. Gdy ten przybył do Oniasza, zaczął go podstępnie namawiać [do wyjścia] i przysięgając podał mu prawicę. W ten sposób dał się on nakłonić do wyjścia z azylu, mimo że podejrzewał go o nieszczerość. Zaraz potem - nie licząc się ze sprawiedliwością - zamordował go.
###### **2Mch 4,35**
 Niesprawiedliwa śmierć tego człowieka była powodem oburzenia i smutku nie tylko wśród Żydów, lecz także wśród wielu pogan.
###### **2Mch 4,36**
 Skoro król powrócił z miast Cylicji, Żydzi ze stolicy wraz z Grekami, którzy również byli wrogami gwałtu, udali się [do niego] ze skargą, z powodu niezgodnej z prawem śmierci Oniasza.
###### **2Mch 4,37**
 Antioch był głęboko zasmucony i przejęty współczuciem. Płakał nawet na wspomnienie roztropności i wielkiej łagodności zamordowanego.
###### **2Mch 4,38**
 Uniesiony gniewem kazał natychmiast zdjąć z Andronika purpurę i zedrzeć [z niego] szaty. Polecił, aby go tak poprowadzono przez całe miasto na miejsce, gdzie dokonał on na Oniaszu swego bezbożnego czynu. Tam zgładził skrytobójcę. W ten sposób wymierzył mu Pan sprawiedliwą karę.
###### **2Mch 4,39**
 Ponieważ Lizymach dopuścił się w mieście za zgodą Menelaosa wielu czynów świętokradzkich i wieść o nich przedostała się na zewnątrz, ludność powstała przeciwko Lizymachowi, ale wiele złotych naczyń zostało już zagrabionych.
###### **2Mch 4,40**
 Skoro wzburzony tłum uniósł się gniewem, uzbroił Lizymach około trzech tysięcy ludzi i uciekł się do krzywdzącej przemocy. Dowodził niejaki Auranos, który miał już wiele lat, lecz mało rozumu.
###### **2Mch 4,41**
 Skoro spostrzegli, że Lizymach ma zamiar uderzyć, jedni pochwycili kamienie, drudzy drągi, inni zbierali popiół, który się tam znajdował, i w nieładzie ciskali tym w żołnierzy Lizymacha.
###### **2Mch 4,42**
 W ten sposób wielu z nich zranili, kilku zabili, a wszystkich zmusili do ucieczki. Samego zaś świętokradcę zabili obok skarbca.
###### **2Mch 4,43**
 W związku z tymi sprawami rozpoczęto dochodzenie sądowe przeciwko Menelaosowi.
###### **2Mch 4,44**
 Gdy król zjawił się w Tyrze, trzech ludzi z Rady Starszych wniosło przeciwko [Menelaosowi] oskarżenie.
###### **2Mch 4,45**
 Menelaos, przewidując swą zgubę, przyrzekł znaczną sumę [pieniędzy] Ptolemeuszowi, synowi Dorymenesa, aby ułagodził króla.
###### **2Mch 4,46**
 Przeto Ptolemeusz odprowadził króla do jednego z krużganków pod pozorem ochłodzenia się i namówił go do zmiany zdania.
###### **2Mch 4,47**
 I tak uwolnił on od oskarżenia Menelaosa, sprawcę całego nieszczęścia, skazał zaś na śmierć biedaków, którzy byliby uwolnieni, nawet jeśliby bronili swej sprawy przed Scytami.
###### **2Mch 4,48**
 Ponieśli więc niezasłużoną karę ci, którzy podjęli się obrony miasta, ludu i świętych naczyń.
###### **2Mch 4,49**
 Oburzeni na to Tyryjczycy wspaniałomyślnie urządzili im pogrzeb.
###### **2Mch 4,50**
 Menelaos zaś z powodu chciwości będących u władzy utrzymywał się przy rządach; zacięty nieprzyjaciel obywateli coraz bardziej okazywał im swą wrogość.
# 2Mch 4 BR
###### **2Mch 4,1**
 Wspomniany przed chwilą Szymon, ten, który wydał skarby świątyni i dopuścił się zdrady ojczystego kraju, teraz zaczął opowiadać, że to Oniasz wystąpił przeciwko Heliodorowi i sprowadził na niego wszystkie te nieszczęścia.
###### **2Mch 4,2**
 Ośmielił się zatem nazywać przeciwnikiem władzy [królewskiej] tego, który był dobroczyńcą całego miasta, troskliwym opiekunem współbraci i gorliwym wyznawcą prawa.
###### **2Mch 4,3**
 Nienawiść z tego powodu stała się tak wielka, że jeden ze stronników Szymona dopuścił się nawet kilku zabójstw.
###### **2Mch 4,4**
 Oniasz zrozumiał, że dłużej nie zdoła przeciwstawiać się Szymonowi. Widział bowiem, że także Apoloniusz, syn Menesteuesa, wódz wojsk Celesyrii i Fenicji, wspiera przewrotność Szymona.
###### **2Mch 4,5**
 Dlatego udał się do króla, ale nie po to, żeby uskarżać się na braci, lecz powodowany troską o wspólne dobro całego ludu.
###### **2Mch 4,6**
 Wiedział bowiem dobrze, że nie da się przywrócić publicznego spokoju ani Szymon nie zaprzestanie swego szaleństwa, dopóki król nie podejmie odpowiednich postanowień.
###### **2Mch 4,7**
 Po śmierci Seleukosa władzę po nim objął Antioch, zwany Epifanesem. Urząd najwyższego kapłana zagarnął wtedy dla siebie Jazon, brat Oniasza.
###### **2Mch 4,8**
 Podczas jednej z rozmów z królem obiecał mu, że wpłaci do skarbca królewskiego trzysta sześćdziesiąt talentów srebra oraz osiemdziesiąt talentów srebra z innych wpływów.
###### **2Mch 4,9**
 Ponadto zobowiązał się na piśmie wpłacić dodatkowo sto pięćdziesiąt talentów, jeśli tylko otrzyma zezwolenie na zbudowanie gimnazjonu i placów ćwiczeń dla młodych ludzi - bardzo mu na tym zależało - a mieszkańcy Jerozolimy będą mogli nazywać się Antiocheńczykami.
###### **2Mch 4,10**
 Król zgodził się na wszystko. Kiedy zaś tylko Jazon objął swój urząd, zaczął zmuszać swoich rodaków, żeby żyli według obyczajów greckich.
###### **2Mch 4,11**
 Pozbawił również Żydów wszystkich przywilejów, które uzyskali od króla za pośrednictwem Jana, ojca Eupolemosa, który brał udział w poselstwie do Rzymu, mającym zawrzeć przymierze pokoju z Rzymianami. Tak więc Jazon poznosił stare, uświęcone prawem zwyczaje, a wprowadził nowe, sprzeczne z prawem.
###### **2Mch 4,12**
 Rozmyślnie zbudował tuż koło twierdzy gimnazjon i zachęcał synów najznakomitszych rodzin żydowskich, żeby zaczęli nosić greckie kapelusze.
###### **2Mch 4,13**
 Wszystko co greckie, zyskiwało uznanie; sztukę rodzimą zarzucono i to za sprawą nikczemnego bezbożnika Jazona, który, jak na ironię, posługiwał się tytułem najwyższego kapłana.
###### **2Mch 4,14**
 W końcu kapłani całkiem przestali się troszczyć o posługę ołtarza; świątynia nic już nie znaczyła w ich oczach, a na składanie ofiar po prostu nie mieli już czasu. Udawali się pospiesznie na stadion, gdy tylko posłyszeli sygnał, że urządza się zawody rzucania dyskiem, i brali czynny udział w igrzyskach, których zabraniało prawo [żydowskie].
###### **2Mch 4,15**
 Za nic sobie mieli odznaczenia ojczyste, natomiast ubiegali się o wyrazy uznania ze strony władz greckich.
###### **2Mch 4,16**
 Dlatego znaleźli się w położeniu bardzo trudnym. Właśnie ci, których tak usilnie naśladowali i którym chcieli dorównać we wszystkim, stali się ich wrogami i ciemiężycielami.
###### **2Mch 4,17**
 Nigdy bowiem nie uchodzi bezkarnie takie świadome lekceważenie praw Bożych. I na nich też miało się to z czasem dokładnie sprawdzić.
###### **2Mch 4,18**
 Kiedy król przybył do Tyru na odbywające się tam co pięć lat igrzyska,
###### **2Mch 4,19**
 Jazon, niegodziwiec, wysłał na nie pięciu ludzi jako przedstawicieli Antiocheńczyków jerozolimskich. Dał im trzysta drachm srebrnych na ofiarę dla Heraklesa. Wysłannicy ci jednak sami uznali, że pieniędzy tych nie wypada zużyć na taką ofiarę. Postanowili więc przeznaczyć je na inne cele.
###### **2Mch 4,20**
 Według życzenia Jazona pieniądze miały być zużyte na ofiarę dla Heraklesa, ale ci, co je otrzymali, wydali je wszystkie na budowę łodzi o trzech rzędach wioseł.
###### **2Mch 4,21**
 Na uroczystość objęcia władzy w Egipcie przez króla Filometora wysłał tam Antioch Apoloniusza, syna Menesteusa. Przekonał się wówczas, że król egipski jest wrogo nastawiony do niego i że powinien on zatroszczyć się o swoje bezpieczeństwo. Udał się więc Antioch najpierw do Jafy, a potem do Jerozolimy,
###### **2Mch 4,22**
 gdzie Jazon i mieszkańcy miasta przygotowali mu wspaniałe przyjęcie, oświetlając ulice pochodniami i wznosząc radosne okrzyki. Potem zebrał swoje oddziały i przybył do Fenicji, gdzie też stanął na jakiś czas obozem.
###### **2Mch 4,23**
 W trzy lata później Jazon wysłał Menelaosa, brata wspomnianego już Szymona, do króla, żeby mu przekazał pieniądze i doprowadził do końca wszystkie sprawy państwa nie znoszące zwłoki.
###### **2Mch 4,24**
 Tymczasem Menelaos postarał się o odpowiednie polecenie do króla, przez co wydał się królowi postacią wysoce wpływową, tym bardziej że wręczył królowi trzysta talentów więcej srebra niż Jazon. I w taki to sposób zdobył dla siebie urząd najwyższego kapłana.
###### **2Mch 4,25**
 Mając ze sobą listy od króla powrócił [do Jerozolimy]. Nie miał on żadnych cech, które czyniłyby go godnym urzędu najwyższego kapłana. Natomiast odznaczał się zawziętością właściwą tyranom i wściekłością dzikiego zwierza.
###### **2Mch 4,26**
 Jazon, ten, który podstępnie pozbył się własnego brata, sam został przez drugiego zmuszony do opuszczenia kraju i jako wygnaniec musiał szukać schronienia w kraju Ammonitów.
###### **2Mch 4,27**
 Menelaos umacniał coraz bardziej swoją władzę, ale nic nie czynił, żeby wpłacić królowi pieniądze, które mu przyobiecał,
###### **2Mch 4,28**
 choć wielokrotnie przypominał mu o tym Sostratos, dowódca twierdzy jerozolimskiej, upoważniony do ściągania podatków. Dlatego obydwu ich wezwał król do siebie.
###### **2Mch 4,29**
 Jako swego zastępcę na urzędzie najwyższego kapłana zostawił Menelaos rodzonego brata, Lizymacha, a Sostratos mianował Kratesa głównodowodzącym oddziałów cypryjskich.
###### **2Mch 4,30**
 W tym czasie mieszkańcy miast Tarsu i Malos wypowiedzieli posłuszeństwo królowi, a to dlatego, że zostali ofiarowani w darze nałożnicy królewskiej Antiochis.
###### **2Mch 4,31**
 Z wielkim więc pośpiechem przybył na miejsce król, żeby sprawę jakoś załagodzić, a na urzędzie pozostawił jako swego zastępcę Andronika, jednego z wyższych urzędników.
###### **2Mch 4,32**
 Pomyślał sobie wtedy Menelaos, że oto nadeszła stosowna chwila. Zabrał ze świątyni kilka złotych naczyń i przekazał je w darze Andronikowi. Jeszcze inne sprzedał w Tyrze i w okolicznych miastach.
###### **2Mch 4,33**
 Gdy Oniasz się o tym dowiedział i upewnił się, że wiadomości te są prawdziwe, bardzo surowo skarcił Menelaosa, po czym sam schronił się w miejscu azylu Dafne, tuż koło Antiochii.
###### **2Mch 4,34**
 Menelaos udał się do Andronika i podczas rozmowy w cztery oczy namawiał go do zamordowania Oniasza. Odszukał tedy Andronik Oniasza i żeby go zapewnić, że nie chodzi tu o żaden podstęp, podniósł prawicę i złożył przysięgę. W ten sposób udało mu się nakłonić Oniasza, mimo że ten był trochę nieufny, do wyjścia z miejsca jego schronienia. A wtedy Andronik zamordował go, nie zważając na żadne prawo.
###### **2Mch 4,35**
 Takie bezprawie oburzyło nie tylko Żydów, lecz także inne narody. Wszystkich bardzo zasmuciło to zamordowanie niewinnego człowieka.
###### **2Mch 4,36**
 Kiedy król wrócił z miast Cylicji, natychmiast udali się do niego Żydzi, mieszkańcy miasta, żeby wyrazić swoje oburzenie. Podobnie uczynili Grecy, poruszeni tym, że wbrew wszelkiemu prawu Oniasz został zamordowany.
###### **2Mch 4,37**
 Antioch bardzo się zasmucił. Przejął go głęboki żal z powodu śmierci Oniasza i zaczął rzewnie płakać, bo zamordowany był człowiekiem bardzo roztropnym i dzielnym.
###### **2Mch 4,38**
 Potem, zapłonąwszy wielkim gniewem, kazał zedrzeć z Andronika purpurowy płaszcz, podrzeć na strzępy jego szaty i tak poprowadzić go przez całe miasto aż do miejsca, na którym dopuścił się on zbrodni wobec Oniasza. I tam rozkazał zgładzić mordercę. Tak oto wymierzył Pan Andronikowi zasłużoną karę.
###### **2Mch 4,39**
 Tymczasem w mieście Lizymach za wiedzą Menelaosa dopuszczał się licznych świętokradzkich czynów wobec skarbca świątynnego. Kiedy wieść o tym rozeszła się już dość szeroko, ludzie coraz jawniej zaczęli występować przeciwko Lizymachowi. Lecz wielu złotych naczyń już w skarbcu nie znaleziono.
###### **2Mch 4,40**
 Kiedy wzbudzony tłum podniósł się przeciwko Lizymachowi, ten uzbroił około trzech tysięcy mężczyzn i kazał im brutalnie obejść się z ludźmi. Oddziałem Lizymacha dowodził niejaki Aurranos, człowiek równie stary co głupi.
###### **2Mch 4,41**
 Kiedy ludzie zrozumieli, że Lizymach kazał na nich uderzyć, jedni chwycili za kamienie, inni za kije, jeszcze inni nabierali w garście błota, którego tam było wiele, i wszyscy razem rzucili się na ludzi Lizymacha.
###### **2Mch 4,42**
 Wielu z nich poranili, niektórych zabili, a za resztą rzucili się w pościg. Tego zaś, który obrabował świątynię, zamordowali koło skarbca świątynnego.
###### **2Mch 4,43**
 W związku z tym wszystkim zostało wszczęte dochodzenie przeciwko Menelaosowi.
###### **2Mch 4,44**
 Kiedy król przybył do Tyru, trzej mężowie, wysłani przez radę starszych, wnieśli przeciwko niemu oskarżenie.
###### **2Mch 4,45**
 Wtedy Menelaos, widząc, że jest zgubiony, przyrzekł dać dużą sumę pieniędzy Ptolemeuszowi, synowi Dorymenesa, prosząc, żeby go wziął w obronę.
###### **2Mch 4,46**
 Odprowadził więc Ptolemeusz króla nieco na bok, pod kolumnadę - jakby po to, żeby nieco odetchnął - i zdołał go przychylnie nastawić [do Menelaosa].
###### **2Mch 4,47**
 I tak uniewinnił król Menelaosa, na którym ciążyła odpowiedzialność za całą zbrodnię, owych zaś nieszczęśliwych oskarżycieli, którzy zostaliby uniewinnieni nawet wtedy, gdyby ich oskarżano wobec Scytów, skazał na śmierć.
###### **2Mch 4,48**
 Niezwłocznie tez niezasłużoną karę ponieśli ci, którzy odważyli się wystąpić w obronie swego miasta, narodu i świętego sprzętu.
###### **2Mch 4,49**
 Poruszeni tym do głębi mieszkańcy Tyru urządzili im wspaniały pogrzeb.
###### **2Mch 4,50**
 Menelaos zaś utrzymał się na swoim urzędzie, ale tylko dzięki chciwości tych, którzy byli u władzy. Jego przewrotność wzrastała z dnia na dzień, tak że stał się z czasem niebezpiecznym wrogiem swoich współbraci.
# 2Mch 4 WUJ
