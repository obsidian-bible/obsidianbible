# 1Mch 5 BT5
###### **1Mch 5,1**
 Gdy okoliczne narody dowiedziały się, że odbudowano ołtarz, a świątynię na nowo poświęcono, tak jak poprzednio, rozgniewały się bardzo
###### **1Mch 5,2**
 i postanowiły, że trzeba wytępić tych z rodu Jakuba, którzy mieszkają pomiędzy nimi. Zaczęto więc mordować i tępić tych spośród ludu.
###### **1Mch 5,3**
 Juda jednak walczył przeciwko synom Ezawa w Idumei, przeciwko Akrabattenie, bo dokoła osaczali Izraela. Zadał im wielką klęskę, wyparł ich i złupił.
###### **1Mch 5,4**
 Potem przypomniał sobie złości Bajanitów. Oni to bowiem urządzali zasadzki na drodze i przez to byli dla ludu sidłem i zawadą.
###### **1Mch 5,5**
 Zamknęli się przed nim w wieżach, ale on ich oblegał i obłożył ich klątwą, a potem spalił ich wieże razem z tymi, którzy się do nich schronili.
###### **1Mch 5,6**
 Następnie przeprawił się do Ammonitów. Tam jednak zastał wojsko mocne i lud liczny pod dowództwem Tymoteusza.
###### **1Mch 5,7**
 Stoczył z nimi wiele bitew, tak że zostali przed nim starci na proch, tak iż ich rozgromił.
###### **1Mch 5,8**
 Zdobył jeszcze Jazer i przynależne miejscowości. Potem wrócił do Judei.
###### **1Mch 5,9**
 Poganie z Gileadu zebrali się także, aby wytępić Izraelitów, którzy mieszkali na ich ziemiach. Oni jednak uciekli do warowni Datema
###### **1Mch 5,10**
 i wysłali pismo do Judy i do jego braci z prośbą: «***Poganie, którzy mieszkają wokoło nas, zebrali się przeciwko nam, aby nas wytępić.***
###### **1Mch 5,11**
 ***Przygotowują się, aby przyjść i zdobyć warownię, do której się schroniliśmy. Dowódcą ich wojska jest Tymoteusz.***
###### **1Mch 5,12**
 ***Przybądź więc i wybaw nas z ich ręki, mnóstwo nas bowiem już zginęło.***
###### **1Mch 5,13**
 ***Mordują także wszystkich naszych braci, którzy mieszkają w okolicach Tubi, uprowadzili ich żony i dzieci, a mienie im zabrali; zginęło tam około tysiąca ludzi***».
###### **1Mch 5,14**
 Jeszcze nie skończono czytać tych listów, gdy przybyli inni posłańcy z Galilei, którzy z rozdartymi szatami oznajmili tymi słowami:
###### **1Mch 5,15**
 «***Z Ptolemaidy, Tyru, Sydonu i z pogańskiej części Galilei zebrało się wielu po to, aby nas zgubić***».
###### **1Mch 5,16**
 Gdy Juda i lud dowiedzieli się o tych wydarzeniach, zwołano wielkie zgromadzenie, aby się naradzić, jak należy pomóc braciom, którzy są w ucisku, gdyż poganie walczą przeciwko nim.
###### **1Mch 5,17**
 Wtedy Juda powiedział do swego brata, Szymona: «***Wybierz sobie żołnierzy, idź i uwolnij swych braci, którzy mieszkają w Galilei. Ja zaś i mój brat, Jonatan, pójdziemy do Gileadu***».
###### **1Mch 5,18**
 W Judei na straży postawił Józefa, syna Zachariasza, i Azariasza, wodza ludu, razem z pozostałą częścią wojska.
###### **1Mch 5,19**
 Rozkazał im, mówiąc: «***Stańcie na czele tego ludu, ale bitwy z poganami nie rozpoczynajcie tak długo, aż my powrócimy***».
###### **1Mch 5,20**
 Potem podzielił wojsko: z Szymonem trzy tysiące żołnierzy w drogę do Galilei, a z Judą osiem tysięcy żołnierzy do Gileadu.
###### **1Mch 5,21**
 Szymon udał się do Galilei i wiele bitew stoczył z poganami, tak że poganie zostali przed nim starci na proch,
###### **1Mch 5,22**
 a on ścigał ich aż do bram Ptolemaidy. Spomiędzy pogan padło blisko trzy tysiące żołnierzy, a on zabrał łupy na nich zdobyte.
###### **1Mch 5,23**
 Zabrał też ze sobą ludzi, którzy mieszkali w Galilei i w Arbattach, razem z żonami i dziećmi, i ze wszystkim, co było ich własnością, i przyprowadził ich z wielką radością do Judei.
###### **1Mch 5,24**
 Juda Machabeusz zaś i jego brat, Jonatan, przeprawili się przez Jordan i trzy dni szli przez pustynię.
###### **1Mch 5,25**
 Wtedy spotkali się z Nabatejczykami. Oni jednak przyjęli ich pokojowo i opowiedzieli im o wszystkim, co się działo z ich braćmi w Gileadzie,
###### **1Mch 5,26**
 że mianowicie wielu z nich jest zamkniętych w Bosorra, w Bosor i Alema, w Kasfo, w Maked i Karnaim – a wszystko to są miasta wielkie i warowne –
###### **1Mch 5,27**
 a także w pozostałych miastach Gileadu są pozamykani. Następnego dnia poganie mają zamiar otoczyć warownie wojskiem, zdobyć je i w ciągu jednego dnia wymordować ich wszystkich.
###### **1Mch 5,28**
 Wtedy Juda razem ze swym wojskiem nagle zmienił swoją drogę [i poszedł] przez pustynię do Bosorra, zdobył miasto, wszystkich mężczyzn zabił ostrzem miecza, zabrał wszystkie łupy na nich zdobyte, a miasto spalił.
###### **1Mch 5,29**
 W nocy zaś wyruszył stamtąd, i udali się w stronę warowni.
###### **1Mch 5,30**
 Rankiem, gdy podnieśli oczy, oto [zobaczyli], jak wojsko liczne, nieprzeliczone, podprowadzało drabiny i machiny oblężnicze, aby zdobyć warownię. Już zaczynali z nimi walkę.
###### **1Mch 5,31**
 Gdy Juda zobaczył, że bitwa już zaczęta, a zgiełk z miasta od trąbienia i okrzyków wzniósł się aż do nieba,
###### **1Mch 5,32**
 powiedział do żołnierzy swego wojska: «***Walczcie dzisiaj w obronie swych braci!***»
###### **1Mch 5,33**
 Trzema oddziałami zaszedł ich od tyłu, podczas gdy grano na trąbach i głośno odmawiano modlitwy.
###### **1Mch 5,34**
 Wtedy wojsko Tymoteusza poznało, że to jest Machabeusz, i uciekło przed nim. On zaś zadał im wielką klęskę, gdyż tego dnia padło spomiędzy nich blisko osiem tysięcy żołnierzy.
###### **1Mch 5,35**
 Wtedy zwrócił się w stronę Alema, uderzył na nie i zdobył. Wszystkich mężczyzn zabił mieczem, zabrał wszystkie łupy na nich zdobyte, a [miasto] spalił.
###### **1Mch 5,36**
 Gdy odszedł stamtąd, zdobył Kasfo, Maked, Bosor i inne miasta Gileadu.
###### **1Mch 5,37**
 Po tych wypadkach Tymoteusz zebrał inne wojsko i rozłożył się obozem pod Rafon, z drugiej strony potoku.
###### **1Mch 5,38**
 Juda zaś wysłał zwiadowców, aby obejrzeli obóz, a oni mu donieśli: «***U niego zgromadziły się otaczające nas narody, wojsko bardzo liczne.***
###### **1Mch 5,39**
 ***Nawet Arabów najęto, aby im pomagali. Rozłożyli się obozem po drugiej stronie potoku i są gotowi wyjść do bitwy z tobą***». Juda wyruszył przeciwko nim.
###### **1Mch 5,40**
 Gdy Juda z wojskiem przybliżał się do potoku, Tymoteusz powiedział do dowódców swego wojska: «***Jeżeli on pierwszy przejdzie do nas, nie będziemy mogli mu się oprzeć, gdyż z pewnością nas pokona.***
###### **1Mch 5,41**
 ***Jeżeli jednak będzie się obawiał i z tamtej strony rzeki rozłoży się obozem, wtedy przeprawimy się do niego i pokonamy go***».
###### **1Mch 5,42**
 Gdy Juda przybliżył się do potoku, nad jego brzegiem postawił pisarzy i rozkazał im: «***Nie pozwalajcie, żeby ktokolwiek pozostał w obozie; wszyscy niech idą do walki!***»
###### **1Mch 5,43**
 Sam pierwszy przeprawił się na ich [brzeg], a za nim cały lud. Wszyscy poganie zostali przed nimi starci na proch, tak iż porzucili swą broń i uciekli na dziedziniec świątyni w Karnain,
###### **1Mch 5,44**
 ale oni miasto zdobyli i świątynię spalili razem z tymi, którzy w niej byli. Karnain zostało pokonane i nie mogło się już Judzie przeciwstawić.
###### **1Mch 5,45**
 Wtedy Juda zebrał wszystkich Izraelitów, którzy mieszkali w Gileadzie, od najmniejszego aż do największego, razem z żonami, dziećmi i mieniem – bardzo wielki obóz – aby się udać do ziemi judzkiej.
###### **1Mch 5,46**
 Przybyli do Efron, a było to miasto wielkie i bardzo mocne, położone w przejściu, i nie można było zboczyć ani na prawo, ani na lewo, aby je ominąć; trzeba było przejść przez jego środek.
###### **1Mch 5,47**
 Mieszkańcy miasta jednak zamknęli się i bramy zabarykadowali kamieniami.
###### **1Mch 5,48**
 Juda wysłał do nich poselstwo i przemawiał do nich przyjaznymi słowami: «***Przejdziemy przez twoją ziemię, by wrócić do swego kraju. Nikt wam nic złego nie uczyni, tylko pieszo przejdziemy***». Nie chcieli mu jednak otworzyć.
###### **1Mch 5,49**
 Juda więc polecił ogłosić wojsku rozkaz, że każdy ma iść do natarcia z tego miejsca, na którym stoi.
###### **1Mch 5,50**
 Ci więc ludzie, którzy należeli do wojska, rozpoczęli bitwę. Cały dzień i całą noc trwała walka przeciw miastu. I miasto zostało wydane w jego ręce.
###### **1Mch 5,51**
 Wtedy wszystkich mężczyzn zabił ostrzem miecza, miasto doszczętnie zburzył, zabrał łupy na nim zdobyte i przeszedł przez miasto po trupach.
###### **1Mch 5,52**
 Potem przeszli przez Jordan na wielką równinę pod Bet-Szean.
###### **1Mch 5,53**
 Juda zaś do pochodu dołączył tych, którzy pozostawali z tyłu, i przez całą drogę dodawał ludowi odwagi tak długo, aż przyszli do ziemi judzkiej.
###### **1Mch 5,54**
 Z największą radością weszli na górę Syjon i przyprowadzili [zwierzęta] na całopalenia, bo nikt z nich nie zginął, aż powrócili w pokoju.
###### **1Mch 5,55**
 W tym czasie, kiedy Juda i Jonatan byli w ziemi gileadzkiej i kiedy ich brat, Szymon, był w Galilei pod Ptolemaidą,
###### **1Mch 5,56**
 dowódcy wojska, Józef, syn Zachariasza, i Azariasz, dowiedzieli się o bohaterskich czynach, jakich [tamci] dokonali w czasie wojny.
###### **1Mch 5,57**
 Powiedzieli więc: «***My także zdobędziemy sobie sławę. Pójdźmy walczyć z okolicznymi narodami***».
###### **1Mch 5,58**
 Wtedy wydano rozkaz wojsku, które było z nimi, i wyruszyli przeciw Jamnii.
###### **1Mch 5,59**
 Ale Gorgiasz i jego żołnierze wyszli z miasta do walki przeciwko nim.
###### **1Mch 5,60**
 Józef i Azariasz zostali zmuszeni do odwrotu i ścigano ich aż do granic Judei, a tego dnia spomiędzy ludu izraelskiego padło blisko dwa tysiące żołnierzy.
###### **1Mch 5,61**
 Lud poniósł wielką klęskę, bo nie słuchali Judy i jego braci, sądząc, że się wsławią męstwem,
###### **1Mch 5,62**
 a przecież oni nie pochodzili z rodu tych mężów, przez których ręce zostało dane Izraelowi ocalenie.
###### **1Mch 5,63**
 A mężny Juda i jego bracia mieli bardzo wielką chwałę u całego Izraela i u wszystkich narodów, gdziekolwiek dowiedziano się o ich imieniu.
###### **1Mch 5,64**
 Gromadzono się dokoła nich z pochwałami.
###### **1Mch 5,65**
 Juda i jego bracia wyruszyli jeszcze i walczyli przeciwko synom Ezawa w kraju, który leży na południu. Zdobył Hebron z przynależnymi miejscowościami, zburzył jego warownie, a wieże jego dokoła spalił.
###### **1Mch 5,66**
 Potem wybrał się w drogę do ziemi Filistynów i przeszedł przez Marissę.
###### **1Mch 5,67**
 W tym czasie padli w walce kapłani, którzy chcieli się wsławić męstwem i nierozważnie poszli do walki.
###### **1Mch 5,68**
 Juda zwrócił się jeszcze w stronę Azotu, który leży na ziemi Filistynów, zburzył ich ołtarze, spalił posągi ich bogów, z miast zabrał łupy. Potem wrócił do ziemi judzkiej.
# 1Mch 5 PAU
###### **1Mch 5,1**
 Gdy okoliczne narody usłyszały, że został zbudowany ołtarz i ponownie poświęcono świątynię, bardzo się rozgniewały.
###### **1Mch 5,2**
 Postanowiły zniszczyć potomków Jakuba, którzy mieszkali pośród nich. Zaczęto więc zabijać i niszczyć tych ludzi.
###### **1Mch 5,3**
 Juda walczył w Idumei przeciwko synom Ezawa oraz w Akrabattanie, ponieważ Izrael był osaczony. Zadał im wielką klęskę, upokorzył ich i wziął łupy.
###### **1Mch 5,4**
 Potem przypomniał sobie o złości Bajanitów, którzy przygotowując zasadzki na drogach, byli dla ludu pułapką i przeszkodą.
###### **1Mch 5,5**
 Schronili się oni przed nim w wieżach, a on ich oblegał, rzucił na nich klątwę i spalił ich wieże ze wszystkimi ludźmi, którzy byli wewnątrz.
###### **1Mch 5,6**
 Następnie zwrócił się przeciwko Ammonitom. Zastał tam silną armię i liczny lud pod wodzą Tymoteusza.
###### **1Mch 5,7**
 Stoczył z nimi wiele bitew i zupełnie ich rozbił.
###### **1Mch 5,8**
 Zajął Jazer i okoliczne wioski, a potem wrócił do Judei.
###### **1Mch 5,9**
 Poganie z Gileadu zjednoczyli się przeciwko Izraelitom mieszkającym w ich granicach, aby ich zniszczyć. Ci więc uciekli do warowni Datema
###### **1Mch 5,10**
 i wysłali list do Judy i jego braci z prośbą: „Zebrali się przeciwko nam poganie żyjący wokół nas, aby nas zniszczyć.
###### **1Mch 5,11**
 Gotowi są przybyć i zdobyć warownię, do której zbiegliśmy. Ich wojskiem dowodzi Tymoteusz.
###### **1Mch 5,12**
 Przybądź więc prędko i wyrwij nas z ich rąk, ponieważ wielu już poległo.
###### **1Mch 5,13**
 Wszyscy nasi bracia mieszkający w Tubi zostali zabici. Ich żony i synów uprowadzono do niewoli, a majątek rozgrabiono. Zginęło tam około tysiąc ludzi”.
###### **1Mch 5,14**
 Gdy oni czytali ten list, przybyli jeszcze inni posłańcy z Galilei w rozdartych szatach i przekazali taką wiadomość:
###### **1Mch 5,15**
 „Zgromadzili się przeciwko nam ludzie z Ptolemaidy, Tyru i Sydonu oraz cudzoziemcy z całej Galilei, aby nas wyniszczyć”.
###### **1Mch 5,16**
 Kiedy Juda i lud usłyszeli te słowa, zwołali wielkie zgromadzenie, aby naradzić się, jak pomóc braciom będącym w ucisku, z którymi tamci walczyli.
###### **1Mch 5,17**
 Juda powiedział swemu bratu Szymonowi: „Wybierz sobie ludzi. Idź i wyzwól twoich braci, którzy mieszkają w Galilei, ja zaś i mój brat Jonatan udamy się do Gileadu”.
###### **1Mch 5,18**
 W Judei na straży pozostawił Józefa, syna Zachariasza, i dowódcę ludu Azariasza z resztą wojska.
###### **1Mch 5,19**
 Rozkazał im: „Czuwajcie nad tym ludem i nie wzniecajcie wojny przeciwko obcym narodom, dopóki my nie wrócimy”.
###### **1Mch 5,20**
 Szymon z trzema tysiącami ludzi udał się do Galilei. Juda zaś z ośmioma tysiącami miał wyruszyć do Gileadu.
###### **1Mch 5,21**
 Kiedy Szymon przybył do Galilei, prowadził liczne walki przeciwko poganom i zostali oni przez niego pokonani.
###### **1Mch 5,22**
 Ścigał ich aż do bram Ptolemaidy. Poległo około trzech tysięcy pogan, a Szymon zdobył na nich łupy.
###### **1Mch 5,23**
 Wziął tych, którzy mieszkali w Galilei i w Arbattach z żonami, dziećmi i wszystkim, co do nich należało, i z wielką radością udał się do Judei.
###### **1Mch 5,24**
 Juda Machabeusz i jego brat Jonatan przekroczyli Jordan i trzy dni szli przez pustynię.
###### **1Mch 5,25**
 Spotkali Nabatejczyków, którzy przyjęli ich pokojowo i opowiedzieli im o wszystkim, co spotkało Żydów w Gileadzie:
###### **1Mch 5,26**
 o tym, że wielu z nich jest zamkniętych w silnych i wielkich miastach. Są to Bosorra i Bosor, w regionie Chelam, oraz Kasfo, Maked i Karnain.
###### **1Mch 5,27**
 Zamknięci są również w pozostałych miastach Gileadu, a nazajutrz nieprzyjaciele postanowili zaatakować i zdobyć te twierdze, aby wybić ich wszystkich w ciągu jednego dnia.
###### **1Mch 5,28**
 Wtedy Juda wraz ze swym wojskiem szybko wrócił pustynną drogą do Bosorry. Zajął miasto i mieczem pozabijał wszystkich mężczyzn. Zdobył na nich liczne łupy, a miasto spalił.
###### **1Mch 5,29**
 W nocy wyruszył stamtąd, aby udać się do twierdzy.
###### **1Mch 5,30**
 O świcie dostrzegli wielkie mnóstwo ludzi, którzy ustawiali drabiny i machiny oblężnicze, aby zdobyć twierdzę, i już przystępowali do walki.
###### **1Mch 5,31**
 Juda zobaczył, że bitwa się rozpoczęła, i usłyszał zgiełk podnoszący się z miasta ku niebu, dźwięk trąb i wielki krzyk.
###### **1Mch 5,32**
 Powiedział do żołnierzy: „Dzisiaj będziecie walczyć za naszych braci”.
###### **1Mch 5,33**
 I z trzema oddziałami zaszedł ich od tyłu. Zadęli w trąby i głośno się modlili.
###### **1Mch 5,34**
 Wojsko Tymoteusza rozpoznało, że to Machabeusz, i uciekło przed nim. Zadał im wielką klęskę i spośród nich poległo w tym dniu około osiem tysięcy.
###### **1Mch 5,35**
 Potem skierował się do Chelam. Zaatakował ją i zdobył, zabił w niej wszystkich mężczyzn, zabrał łupy i podpalił ją.
###### **1Mch 5,36**
 Gdy stamtąd odszedł, zdobył Kasfo, Maked i Bosor oraz pozostałe miasta Gileadu.
###### **1Mch 5,37**
 Po tych wydarzeniach Tymoteusz zgromadził inne wojsko i rozbił obóz naprzeciwko Rafon, po drugiej stronie potoku.
###### **1Mch 5,38**
 Juda posłał zwiadowców, aby wybadać obóz. Oni donieśli mu: „Zgromadziło się przy nim bardzo liczne wojsko ze wszystkich obcych narodów mieszkających wokół nas.
###### **1Mch 5,39**
 Najęli sobie do pomocy Arabów, rozbili obóz po drugiej stronie potoku i są gotowi wyruszyć do bitwy przeciwko tobie”. Wtedy Juda wyszedł im naprzeciw.
###### **1Mch 5,40**
 Podczas gdy Juda wraz z wojskiem zbliżał się do potoku, Tymoteusz powiedział dowódcom swojego wojska: „Jeśli on przeprawi się do nas pierwszy, nie zdołamy go powstrzymać, gdyż będzie miał nad nami przewagę.
###### **1Mch 5,41**
 Jeśli jednak będzie się bał i rozbije obóz za potokiem, my przejdziemy do niego i go pokonamy”.
###### **1Mch 5,42**
 Kiedy Juda zbliżał się do potoku, postawił nad nim pisarzy wojskowych i rozkazał im: „Nie pozwalajcie nikomu rozbijać obozu, ale niech wszyscy idą do walki”.
###### **1Mch 5,43**
 Sam jako pierwszy przekroczył strumień, a za nim cały lud. Tak wszystkie obce narody zostały przez niego pokonane, porzuciły swoją broń i uciekły do świątyni w Karnain.
###### **1Mch 5,44**
 A on zajął miasto i spalił świątynię ze wszystkimi, którzy się w niej schronili. Karnain zostało zdobyte i nie zdołało oprzeć się Judzie.
###### **1Mch 5,45**
 Juda zgromadził wszystkich Izraelitów mieszkających w Gileadzie, od najmniejszego do największego: ich żony, dzieci i dobytek, aby z całą tą wielką rzeszą udać się do ziemi Judy.
###### **1Mch 5,46**
 Przybyli do Efron, które leżało na ich drodze. Było to miasto wielkie i dobrze umocnione. Nie można go było obejść z prawej ani z lewej strony, lecz trzeba było przejść przez sam jego środek.
###### **1Mch 5,47**
 Jego mieszkańcy jednak zamknęli się i zabarykadowali bramy kamieniami.
###### **1Mch 5,48**
 Juda przekazał im wiadomość o swoich pokojowych zamiarach: „Chcemy przejść przez waszą ziemię, aby dotrzeć do naszego kraju. Nikt nie uczyni wam nic złego. Chcemy tylko przejść”. Lecz oni nie chcieli otworzyć.
###### **1Mch 5,49**
 Juda nakazał ogłosić wojsku, aby każdy przygotował się do walki na swoim miejscu.
###### **1Mch 5,50**
 Żołnierze zajęli pozycje. Przez cały dzień i całą noc atakowali miasto, które w końcu się poddało.
###### **1Mch 5,51**
 Wtedy Juda zabił mieczem wszystkich mężczyzn, a miasto zniszczył. Zabrał łupy i przeszedł przez miasto po trupach.
###### **1Mch 5,52**
 Przekroczyli Jordan i ruszyli w stronę wielkiej równiny koło Bet-Szean.
###### **1Mch 5,53**
 Juda zbierał pozostających w tyle i przez całą drogę dodawał ludowi odwagi, aż doszli do ziemi Judy.
###### **1Mch 5,54**
 Z radością i weselem weszli na górę Syjon. Złożyli całopalenia, ponieważ powrócili szczęśliwie i nikt z nich nie poległ.
###### **1Mch 5,55**
 W czasie, gdy Juda i Jonatan byli w ziemi Gilead, a ich brat Szymon w Galilei pod Ptolemaidą,
###### **1Mch 5,56**
 dowódcy wojska: Józef, syn Zachariasza, i Azariasz usłyszeli o wojnie i o bohaterskich czynach, których tamci dokonali.
###### **1Mch 5,57**
 Powiedzieli: „Zdobądźmy i my sobie sławę i idźmy walczyć przeciwko obcym narodom, które mieszkają wokół nas”.
###### **1Mch 5,58**
 Ogłosili to swoim żołnierzom i wyruszyli przeciwko Jamnii.
###### **1Mch 5,59**
 Wówczas z miasta wyszedł do walki przeciwko nim Gorgiasz ze swymi ludźmi.
###### **1Mch 5,60**
 Józef i Azariasz zostali pokonani i ścigano ich aż do granic Judei. W tym dniu z ludu Izraela padło około dwóch tysięcy ludzi.
###### **1Mch 5,61**
 Ponieważ nie usłuchali Judy i jego braci, sądząc, że wsławią się bohaterskimi czynami, lud przez nich poniósł wielką klęskę.
###### **1Mch 5,62**
 Nie należeli oni do grona tych ludzi, za pośrednictwem których Izraelowi zostało dane ocalenie.
###### **1Mch 5,63**
 A mężny Juda i jego bracia okryli się wielką chwałą przed całym Izraelem i wszystkimi narodami, które o nich słyszały.
###### **1Mch 5,64**
 Ludzie przychodzili do nich, życząc im pomyślności.
###### **1Mch 5,65**
 Juda wraz ze swymi braćmi wyruszył na południe, aby walczyć z synami Ezawa. Zdobył Hebron i okoliczne wsie. Zburzył jego twierdze i podpalił otaczające go wieże.
###### **1Mch 5,66**
 Potem postanowił wyruszyć do kraju Filistynów i przeszedł przez Marisę.
###### **1Mch 5,67**
 W tym dniu zginęli w walce kapłani, którzy chcieli wsławić się męstwem i nierozważnie wzięli udział w bitwie.
###### **1Mch 5,68**
 Juda skierował się do Azotu, ku ziemi Filistynów. Zniszczył ich ołtarze i rzeźby, spalił ich bogów, złupił miasta i powrócił do ziemi Judy.
# 1Mch 5 BP
###### **1Mch 5,1**
 Skoro okoliczne narody dowiedziały się, że ołtarz jest znów odbudowany, a Świątynia poświęcona, rozgniewały się bardzo
###### **1Mch 5,2**
 i postanowiły wytępić tych z rodu Jakuba, którzy mieszkali pośród nich. Zaczęto lud mordować i wyniszczać.
###### **1Mch 5,3**
 Juda tymczasem walczył w Idumei z synami Ezawa i z Akrabattaną, ponieważ ze wszystkich stron niepokoili Izrael. Zadał im wielką klęskę, upokorzył ich i zabrał łupy.
###### **1Mch 5,4**
 Przypomniał sobie również krzywdy wyrządzone przez Bajańczyków, którzy urządzając zasadzki na drogach byli dla ludu jakby potrzaskiem i przeszkodą.
###### **1Mch 5,5**
 Zmusił ich do zamknięcia się w twierdzach, po czym rozpoczął oblężenie. Obłożył ich klątwą i spalił wieże oraz tych, którzy się tam schronili.
###### **1Mch 5,6**
 Potem podążył przeciw Ammonitom. Napotkał tam silne wojsko i liczną ludność. Wodzem ich był Tymoteusz.
###### **1Mch 5,7**
 Stoczył z nimi wiele bitew i pokonał upokorzywszy ich przed sobą.
###### **1Mch 5,8**
 Zdobył również Jazer i podległe mu miejscowości, po czym powrócił do Judei.
###### **1Mch 5,9**
 Poganie z Galaadu zebrali się także przeciwko Izraelitom, którzy zamieszkiwali ich ziemie, aby ich wytępić. Ci jednak schronili się do twierdzy Datema
###### **1Mch 5,10**
 i wysłali pismo do Judy i jego braci tej treści: "Okoliczni poganie zgromadzili się przeciwko nam, aby nas wyniszczyć;
###### **1Mch 5,11**
 przygotowują się, aby przybyć i zdobyć twierdzę, w której znaleźliśmy schronienie. Wojsko ich prowadzi Tymoteusz.
###### **1Mch 5,12**
 Przybądź więc zaraz i wybaw nas z ich rąk, gdyż wielu z nas już poległo.
###### **1Mch 5,13**
 Wymordowali również wszystkich naszych braci mieszkających w Tubi, uprowadzając do niewoli ich żony, dzieci i dobytek. Zginęło tam około tysiąca mężów".
###### **1Mch 5,14**
 Jeszcze nie skończono czytać listów, a już zjawili się inni posłańcy z Galilei. Rozdzierając szaty przekazali takie wieści:
###### **1Mch 5,15**
 "Z Ptolemaidy, Tyru i Sydonu oraz z całej pogańskiej Galilei zebrali się ludzie, aby nas wytracić".
###### **1Mch 5,16**
 Skoro Juda i lud usłyszeli te słowa, zwołano wielkie zgromadzenie, by się naradzić, jak pomóc uciśnionym braciom, na których napadają poganie.
###### **1Mch 5,17**
 Rzekł więc Juda do swego brata Szymona: "Wybierz sobie mężów i spiesz na ratunek braciom z Galilei. Ja i brat mój Jonatan ruszymy do Galaadu".
###### **1Mch 5,18**
 W Judei zaś pozostawił na straży jako przywódców ludu Józefa, syna Zachariasza, i Azariasza wraz z pozostałym wojskiem.
###### **1Mch 5,19**
 Wydał im taki rozkaz: "Stójcie na czele tego ludu, ale aż do naszego powrotu nie rozpoczynajcie walki z poganami".
###### **1Mch 5,20**
 Szymonowi dano trzy tysiące ludzi na wyprawę do Galilei, Juda do Galaadu otrzymał osiem tysięcy.
###### **1Mch 5,21**
 Wyruszył więc Szymon do Galilei i stoczył z poganami wiele bitew, aż zostali pokonam.
###### **1Mch 5,22**
 Ścigał ich aż do bram Ptolemaidy. Padło wtedy około trzech tysięcy pogan i zdobył na nich łupy.
###### **1Mch 5,23**
 Zebrał [Żydów] z Galilei i Arbatta wraz z żonami i dziećmi oraz całym ich dobytkiem, po czym wśród wielkiej radości przyprowadził ich do Judei.
###### **1Mch 5,24**
 A Juda Machabeusz i jego brat Jonatan przeszli Jordan i trzy dni ciągnęli przez pustynię.
###### **1Mch 5,25**
 Spotkali tam Nabatejczyków, którzy przyjęli ich przyjaźnie i opowiedzieli im o wszystkim, co spotkało ich braci w Galaadzie:
###### **1Mch 5,26**
 "Wielu z nich zamkniętych jest w Bosora, Bosor, Alema, Kasfo, Maked i Karnain - a wszystko to są miasta duże i warowne;
###### **1Mch 5,27**
 są także zamknięci w pozostałych miastach galaadzkich. Poganie gotują się uderzyć nazajutrz na twierdze, aby je zdobyć i w jednym dniu wymordować ich wszystkich".
###### **1Mch 5,28**
 Wówczas Juda zawrócił nagle z wojskiem przez pustynię do Bosora i zdobył miasto. Ostrzem miecza wygubił wszystkich mężczyzn, zagarnął wszystkie łupy i spalił miasto.
###### **1Mch 5,29**
 Oddalił się stamtąd nocą i wyruszył do twierdzy [Datema].
###### **1Mch 5,30**
 Gdy rano podnieśli oczy, [ujrzeli] niezliczone mnóstwo ludzi, którzy podciągali drabiny i machiny oblężnicze, aby zdobyć twierdzę, i przystępowali właśnie do walki.
###### **1Mch 5,31**
 Juda widząc, że walka już się rozpoczęła i ogromny krzyk jak głos trąby wojennej wzbił się z miasta ku niebu,
###### **1Mch 5,32**
 przemówił do swych żołnierzy: "Walczcie dziś za naszych braci!"
###### **1Mch 5,33**
 Następnie uderzył na tyły [wroga] trzema oddziałami wśród grania w trąby i głośnych modłów.
###### **1Mch 5,34**
 Gdy wojsko Tymoteusza poznało, że to Machabeusz, uciekło przed nim. Zadał im więc wielką klęskę, gdyż padło w tym dniu spośród nich około ośmiu tysięcy mężów.
###### **1Mch 5,35**
 Później zboczył w kierunku Alema i po walce zdobył je. Zabił w nim wszystkich mężczyzn, zabrał łupy a miasto spalił.
###### **1Mch 5,36**
 Wyruszywszy stamtąd zdobył Kasfo, Maked i Bosor oraz inne miasta Galaadu.
###### **1Mch 5,37**
 Po tych wydarzeniach Tymoteusz zebrał inne wojsko i rozbił obóz naprzeciw Rafon, po drugiej stronie potoku.
###### **1Mch 5,38**
 Juda zaś wysłał ludzi na zwiady, aby obejrzeli obóz. Donieśli mu: "Zgromadziły się wokół niego wszystkie okoliczne ludy, ogromne wojsko.
###### **1Mch 5,39**
 Najęli także Arabów do pomocy i rozbili obóz po drugiej stronie potoku, gotowi ruszyć do walki przeciw tobie." Juda wyruszył przeciwko nim.
###### **1Mch 5,40**
 Gdy Juda i jego wojsko zbliżali się do potoku, Tymoteusz rzekł do dowódców swego wojska: "Jeżeli on pierwszy przeprawi się do nas, nie zdołamy mu się oprzeć, gdyż będzie miał nad nami ogromną przewagę.
###### **1Mch 5,41**
 Jeżeli zaś przelęknie się i stanie obozem po drugiej stronie potoku, my przeprawimy się do niego i odniesiemy nad nim zwycięstwo."
###### **1Mch 5,42**
 Gdy Juda zbliżył się do strumienia, postawił na jego brzegu pisarzy ludu i rozkazał im: "Nie pozwalajcie nikomu zatrzymywać się, niech wszyscy idą do walki."
###### **1Mch 5,43**
 potem ruszył przeciwko wrogom i pierwszy przeprawił się na drugi brzeg a za nim cały lud. Pokonał wszystkich pogan, którzy rzucili broń i uciekli do świątyni w Karnain.
###### **1Mch 5,44**
 [Izraelici] zdobyli miasto i spalili świątynię wraz z wszystkimi, którzy się w niej znajdowali. W ten sposób pokonane zostało Karnain i nie mogło już stawiać Judzie oporu.
###### **1Mch 5,45**
 Juda zebrał wszystkich Izraelitów, którzy żyli w Galaadzie, od najmłodszego do najstarszego, razem z żonami, dziećmi i dobytkiem - a było ich bardzo wielu - aby wyruszyć do ziemi judzkiej.
###### **1Mch 5,46**
 Przybyli do Efron, miasta dużego, obronnego, i położonego na drodze tak, że nie można było go wyminąć ani z prawej, ani z lewej strony, lecz trzeba było przejść przez jego środek.
###### **1Mch 5,47**
 Mieszkańcy miasta nie wpuścili ich i zatarasowali bramy kamieniami.
###### **1Mch 5,48**
 Juda wysłał do nich [ludzi] w pokojowych zamiarach: "Pozwólcie nam w drodze do naszej ojczyzny przejść przez waszą ziemię. Nikt was nie skrzywdzi. Chcemy tylko przejść." Oni jednak nie chcieli otworzyć.
###### **1Mch 5,49**
 Juda dał rozkaz, który ogłoszono w obozie, aby każdy zatrzymał się w miejscu, gdzie stanął.
###### **1Mch 5,50**
 Wojsko zaś podeszło i zdobyło miasto po szturmie trwającym cały dzień i całą noc.
###### **1Mch 5,51**
 Wtedy mieczem wybił wszystkich mężczyzn, a zabrawszy łupy przeszedł po trupach przez zrównane z ziemią miasto.
###### **1Mch 5,52**
 Przeprawili się przez Jordan i [znaleźli się] na wielkiej równinie pod Betsan.
###### **1Mch 5,53**
 Juda zbierał pozostających w tyle i przez całą drogę dodawał ludowi otuchy, aż dotarli do ziemi judzkiej.
###### **1Mch 5,54**
 Z radością i weselem wstąpili na górę Syjon prowadząc zwierzęta na całopalną ofiarę, gdyż nikt spośród nich nie zginął i wszyscy powrócili szczęśliwie.
###### **1Mch 5,55**
 W tym czasie, gdy Juda i Jonatan przebywali na ziemi Galaad, a brat jego Szymon był w Galilei, pod Ptolemaidą,
###### **1Mch 5,56**
 dowódcy wojska: Józef, syn Zachariasza, i Azariasz dowiedzieli się o ich bohaterskich czynach dokonanych na wojnie.
###### **1Mch 5,57**
 Powiedzieli więc: "Rozsławmy i my nasze imię i wystąpmy do walki z okolicznymi ludami."
###### **1Mch 5,58**
 Wydali rozkazy swemu wojsku i ruszyli przeciwko Jamnii.
###### **1Mch 5,59**
 Gorgiasz zaś opuścił ze swymi ludźmi miasto, aby stanąć z nimi do walki.
###### **1Mch 5,60**
 Pokonali oni Józefa i Azariasza, po czym ścigali ich aż do granic Judei. Lud izraelski stracił w owym dniu blisko dwa tysiące mężów.
###### **1Mch 5,61**
 I tak poniósł lud wielką klęskę, ponieważ nie usłuchali Judy i jego braci, mniemając, iż dokonają bohaterskich czynów.
###### **1Mch 5,62**
 Oni bowiem nie byli z rodu tych mężów, przez ręce których miało się dokonać ocalenie Izraela.
###### **1Mch 5,63**
 Natomiast bohaterski Juda i jego bracia zdobyli wielką sławę u całego ludu izraelskiego i u wszystkich pogan: gdziekolwiek tylko usłyszano ich imię,
###### **1Mch 5,64**
 [ludzie] gromadzili się życząc im pomyślności.
###### **1Mch 5,65**
 Potem wyruszył Juda wraz z braćmi i walczyli z synami Ezawa w ziemi leżącej na południe. Zdobył Chebron i podległe mu miejscowości, zburzył mury obronne i spalił rozmieszczone dookoła wieże.
###### **1Mch 5,66**
 Następnie pociągnął do ziemi Filistynów i przeszedł przez Marisę.
###### **1Mch 5,67**
 Owego dnia padli w walce kapłani, którzy nierozważnie poszli do boju, pragnąc dokonać bohaterskich czynów.
###### **1Mch 5,68**
 Juda zawrócił jeszcze w stronę Azotu, [który znajduje się] w ziemi Filistynów. Zburzył ołtarze, spalił posągi bogów, zabrał łupy z miast i powrócił do ziemi judzkiej.
# 1Mch 5 BR
###### **1Mch 5,1**
 Kiedy okoliczne narody dowiedziały się, że Żydzi zbudowali na nowo ołtarz i poświęcili świątynię i że wszystko odbywa się znów jak dawniej, ogarnął je wielki gniew.
###### **1Mch 5,2**
 Postanowili wygubić tych wszystkich z rodu Jakuba, którzy żyją między nimi. I wkrótce zaczęli sprowadzać na cały lud śmierć i zagładę.
###### **1Mch 5,3**
 Tymczasem Juda prowadził walki z potomkami Ezawa, którzy zamieszkiwali część Idumei, zwaną Akrabattana, i zamknęli drogę wiodącą do Izraela przez ich ziemie. Zadał im Juda bardzo dotkliwą klęskę, pozwolił im odczuć swoją władzę i zagarnął całe ich mienie.
###### **1Mch 5,4**
 Potem przypomniał sobie o niecnych czynach Bajanitów, którzy urządzali na Żydów zasadzki przy drogach, zastawiając na ludzi jakby sidła i kładąc im przeszkody pod nogi.
###### **1Mch 5,5**
 Zmusił ich teraz do zamknięcia się w ich wieżach i zaczął ich oblegać, a potem rzucił na nich klątwę. W końcu podpalił wieże razem z ludźmi, którzy znajdowali się wewnątrz.
###### **1Mch 5,6**
 Następnie wyruszył na Ammonitów, którzy mu się jednak przeciwstawili, wystawiając silne i liczne wojsko, pod wodzą niejakiego Tymoteusza.
###### **1Mch 5,7**
 Stoczył z nimi Juda wiele bitew i ostatecznie zadał im dotkliwą klęskę.
###### **1Mch 5,8**
 Zdobył także miasto Jazer i podlegające mu osiedla. Potem powrócił do Judei.
###### **1Mch 5,9**
 Po jakimś czasie wszystkie ludy Gileadu wystąpiły przeciwko Izraelitom, którzy zamieszkiwali ich ziemię, i postanowiły ich zgładzić. Lecz Izraelici schronili się w twierdzy Datema.
###### **1Mch 5,10**
 Napisali też do Judy i jego braci list, w którym donosili: Ludy, wśród których mieszkamy, powstały przeciwko nam i gotują nam zagładę.
###### **1Mch 5,11**
 Są gotowe w każdej chwili ruszyć do walki i zdobyć twierdzę, w której znaleźliśmy schronienie. Ich wojskiem dowodzi Tymoteusz.
###### **1Mch 5,12**
 Pośpiesz się więc i uwolnij nas od nich, bo wielu już z nas poległo.
###### **1Mch 5,13**
 Wymordowano także naszych braci żyjących w Tubi. Uprowadzono ich kobiety i dzieci i zagrabiono całe ich mienie. Zgładzono tam około tysiąca mężów.
###### **1Mch 5,14**
 Juda i jego bracia nie skończyli jeszcze czytać tego listu, gdy oto z Galilei nadeszli wysłannicy, którzy rozdzierając swe szaty, przekazali im następującą wiadomość:
###### **1Mch 5,15**
 Ludzie z Ptolemaidy, Tyru, Sydonu oraz całej górnej Galilei, zamieszkanej przez obce narody, zmówili się przeciw nam i gotują nam zagładę.
###### **1Mch 5,16**
 Gdy Juda i cały lud dowiedzieli się o tym, zwołano wielkie zgromadzenie i zastanawiano się, co należałoby uczynić dla braci, którzy znaleźli się w ucisku z powodu napaści ze strony wrogów.
###### **1Mch 5,17**
 Wtedy powiedział Juda do swego brata Szymona: Dobierz sobie odpowiednich ludzi, udaj się do Galilei i uwolnij twoich braci. Ja zaś i mój brat Jonatan pójdziemy do Gileadu.
###### **1Mch 5,18**
 Władzę nad ludem przekazał Józefowi, synowi Zachariasza, Azariasz zaś z resztą wojska miał czuwać nad bezpieczeństwem Judei.
###### **1Mch 5,19**
 Wydał im [Juda] taki rozkaz: Czuwajcie nad ludem, ale nie wdawajcie się w żadne walki z obcymi narodami, dopóki my nie wrócimy.
###### **1Mch 5,20**
 Przydzielono Szymonowi trzy tysiące wojowników, z którymi miał on udać się do Galilei, Juda zaś z ośmioma tysiącami zamierzał wyruszyć do Gileadu.
###### **1Mch 5,21**
 Szymon udał się tedy do Galilei, gdzie stoczył wiele bitew z obcymi ludami, zadając im na oczach wszystkich dotkliwe straty.
###### **1Mch 5,22**
 Potem ścigał ich aż do bram Ptolemaidy. Poległo wtedy spośród obcych ludów około trzech tysięcy wojowników, a Szymon wziął bardzo obfite łupy.
###### **1Mch 5,23**
 Wszystkich zaś Żydów z Galilei i z Arbattach, razem z ich dziećmi i całym mieniem, wśród wielkiej radości sprowadził z powrotem do Judei.
###### **1Mch 5,24**
 Juda Machabeusz i jego brat Jonatan przeprawili się przez Jordan i wędrowali przez pustynię.
###### **1Mch 5,25**
 Po trzech dniach spotkali tam Nabatejczyków, którzy odnieśli się do nich bardzo życzliwie i opowiedzieli im o wszystkim, co przydarzyło się ich braciom w Gileadzie:
###### **1Mch 5,26**
 o tym, że wielu z nich schroniło się w twierdzach w wielkich i obwarowanych miastach, a mianowicie w Bosorra, Bosor, Alema, Kasfo, Maked i Karnaim,
###### **1Mch 5,27**
 że w pozostałych miastach Gileadu zamknęło się również wielu z nich, że jutro obce ludy chcą otoczyć te miasta twierdze, zdobyć je i wszystkich [którzy się w nich schronili] zgładzić jednego dnia.
###### **1Mch 5,28**
 [Usłyszawszy to] Juda natychmiast zmienił kierunek swego marszu i razem z całym wojskiem udał się przez pustynię do Bosorra, zdobył miasto, wyciął mieczem znajdujących się w nim mężczyzn, złupił je i spalił.
###### **1Mch 5,29**
 Jeszcze tej samej nocy wyruszyli w dalszą drogę i dotarli do twierdzy [Datema].
###### **1Mch 5,30**
 Kiedy o świtaniu się rozejrzeli, zobaczyli przed sobą ogromnie liczne wojska. Część spośród wojowników ustawiła już drabiny szturmowe i podciągnęła machiny oblężnicze, przygotowując się do zaatakowania twierdzy, aby zdobywszy ją pomordować znajdujących się w niej Żydów.
###### **1Mch 5,31**
 Juda spostrzegł też, że walka już rozgorzała, bo z miasta dochodził zgiełk, głosy trąb i przeraźliwe krzyki, unosząc się aż do nieba.
###### **1Mch 5,32**
 Wtedy zawołał do swoich ludzi: Macie dziś walczyć w obronie naszych braci!
###### **1Mch 5,33**
 I uderzył na wroga trzema oddziałami od tyłu. Jego wojownicy dęli przy tym w trąby i modlili się głośno.
###### **1Mch 5,34**
 Kiedy tylko wojownicy Tymoteusza zobaczyli, że naciera na nich Machabeusz, rzucili się do ucieczki. I ponieśli druzgoczącą klęskę. Padło ich tego dnia około ośmiu tysięcy.
###### **1Mch 5,35**
 Potem ruszył Juda w kierunku Alema. Zaatakował miasto i zdobył je, wymordował wszystkich mieszkających w mieście mężczyzn, a całe miasto kazał złupić i spalić.
###### **1Mch 5,36**
 Poszedł następnie dalej, zdobywając po drodze Kasfo, Maked, Bosor oraz inne miasta Gileadu.
###### **1Mch 5,37**
 Po tym wszystkim Tymoteusz zebrał jeszcze raz wszystkie swoje siły i rozbił obóz pod Rafon, z drugiej strony potoku.
###### **1Mch 5,38**
 Wysłał tedy Juda swoich ludzi na zwiad, aby przyjrzeli się dokładnie obozowi. Wróciwszy powiedzieli: Wszystkie otaczające nas ludy przyłączyły się do niego. Jest to bardzo potężne wojsko.
###### **1Mch 5,39**
 Są z nimi także najemne oddziały arabskie. Wszyscy rozbili obóz po drugiej stronie potoku i są gotowi w każdej chwili stanąć z tobą do walki. Wyruszył tedy Juda naprzeciw nim.
###### **1Mch 5,40**
 Kiedy zbliżył się razem ze swoim wojskiem do samego potoku, Tymoteusz powiedział do swoich dowódców: Jeżeli przeprawi się przez potok na naszą strone, wtedy już nie będziemy w stanie go powstrzymać i na pewno odniesie nad nami zwycięstwo.
###### **1Mch 5,41**
 Jeżeli jednak będzie się wahał i rozbije namioty po tamtej stronie potoku, to my uderzymy pierwsi i pokonamy go.
###### **1Mch 5,42**
 A Juda, kiedy już znalazł się nad samym potokiem, kazał zejść swoim pisarzom nad sam brzeg i pilnować, żeby nikt nie został, lecz żeby wszyscy ruszyli do walki.
###### **1Mch 5,43**
 Sam jako pierwszy przeprawił się na drugą stronę potoku wychodząc naprzeciw wrogom, a wszyscy jego wojownicy poszli za nim. I pobili na głowę wojska obcych ludów, tak że ich wojownicy rzucali broń i uciekali do świątyni w Karnain.
###### **1Mch 5,44**
 Żydzi zdobyli miasto, a świątynię spalili razem z wszystkimi, którzy znajdowali się wewnątrz. I w ten sposób Karnain zostało poniżone, a Judzie nikt nie mógł się już przeciwstawić.
###### **1Mch 5,45**
 Potem zebrał Juda wszystkich Izraelitów żyjących w Gileadzie, młodych i starych, razem z ich kobietami, dziećmi oraz całym mieniem, i z tą ogromną rzeszą postanowił wyruszyć do Judei.
###### **1Mch 5,46**
 Dotarli do Efron, wielkiego i potężnie umocnionego miasta, które leżało akurat na ich drodze, tak że nie można go było obejść ani z lewej, ani z prawej strony, lecz koniecznie trzeba było przejść przez nie.
###### **1Mch 5,47**
 Ale mieszkańcy miasta zamknęli bramy i narzucali na nie mnóstwo kamieni.
###### **1Mch 5,48**
 Posłał tedy Juda do nich swoich ludzi z następującą prośbą: Pozwólcie nam przejść tylko przez wasz kraj, żebyśmy mogli dotrzeć spokojnie na nasze ziemie. Nikt nie uczyni wam nic złego. Chcemy tylko przejść. Ale nie chciano im otworzyć bram.
###### **1Mch 5,49**
 Wydał tedy Juda swoim wojownikom rozkaz, żeby każdy ruszał do natarcia z miejsca, na którym się znajdował.
###### **1Mch 5,50**
 Stanęli zatem wojownicy do walki, a Juda kazał atakować miasto przez cały dzień i całą noc, tak długo, aż się poddało.
###### **1Mch 5,51**
 Po wejściu do miasta wymordowano mieczem wszystkich jego mężczyzn i zburzono je, złupiwszy je przedtem. Wszyscy przeszli przez miasto między ciałami pomordowanych.
###### **1Mch 5,52**
 Następnie przeprawili się przez Jordan i wyszli na wielką równinę koło Bet-Szean.
###### **1Mch 5,53**
 Juda przez całą drogę ponaglał tych, którzy nie mogli nadążyć za pochodem i dodawał ludziom odwagi, dopóki nie dotarli do ziemi judzkiej.
###### **1Mch 5,54**
 Z okrzykami szczęścia i radości weszli na górę Syjon, prowadząc zwierzęta ofiarne i złożyli na niej ofiarę całopalenia. W czasie tej długiej drogi bowiem nikt z nich nie zginął i wszyscy w dobrym zdrowiu wrócili do swej ziemi.
###### **1Mch 5,55**
 Kiedy Juda i Jonatan byli w Gileadzie, a ich brat Szymon znajdował się pod Ptolemaidą w Galilei,
###### **1Mch 5,56**
 o ich bohaterskich czynach dokonanych na wojnie dowiedzieli się dowódcy oddziałów wojskowych: Józef, syn Zachariasza, oraz Azariasz.
###### **1Mch 5,57**
 I powiedzieli sobie: My też chcemy wsławić nasze imię, walcząc z otaczającymi nas obcymi narodami.
###### **1Mch 5,58**
 I wydali swoim wojownikom rozkaz, żeby ciągnęli na Jamnię.
###### **1Mch 5,59**
 Lecz Gorgiasz i jego wojownicy wyszli naprzeciw nim z miasta i stanęli do walki.
###### **1Mch 5,60**
 Poległo tego dnia prawie dwa tysiące Izraelitów.
###### **1Mch 5,61**
 Ponieśli tę wielką klęskę dlatego, że nie posłuchali Judy i jego braci i zaczęło im się wydawać, że oni też będą mogli dokonać wielkich czynów.
###### **1Mch 5,62**
 A przecież nie należeli do tych, którym zostało powierzone dzieło ocalenia Izraela.
###### **1Mch 5,63**
 Tymczasem bohaterski Juda i jego bracia zdobyli sobie wielką sławę zarówno w całym Izraelu, jak i u tych wszystkich ludów, które cokolwiek o nich słyszały.
###### **1Mch 5,64**
 Przychodzili do nich też ludzie, żeby ich przynajmniej pozdrowić.
###### **1Mch 5,65**
 Juda i jego bracia wyruszyli także na wojnę przeciwko potomkom Ezawa, mieszkającym na południu. Zdobyli Hebron i miejscowości mu podległe, zburzyli jego obwarowania i podpalili jego wieże obronne.
###### **1Mch 5,66**
 Potem skierowali swe kroki w stronę kraju Filistynów. Kiedy wojsko przechodziło przez Marissę, wywiązała się walka,
###### **1Mch 5,67**
 podczas której zginęło kilku kapłanów. Im też udzielił ktoś złej rady, żeby wzięli udział w bitwie, i tak zyskali sobie sławę bohaterów.
###### **1Mch 5,68**
 Potem Juda zboczył jeszcze nieco z drogi i udał się do Azotu, położonego w ziemi filistyńskiej. Zniszczył tam ołtarze filistyńskie, popalił posągi bożków, złupił po drodze wszystkie miasta i wreszcie wrócił do Judei.
# 1Mch 5 WUJ
