# 1Mch 3 BT5
###### **1Mch 3,1**
 Potem w jego miejsce nastał jego syn, Juda, zwany Machabeuszem,
###### **1Mch 3,2**
 a wspierali go wszyscy jego bracia i wszyscy, którzy przystali do jego ojca. Z radością prowadzili wojnę w obronie Izraela.
###### **1Mch 3,3**
 On rozprzestrzenił chwałę swego ludu. Przywdział bowiem na siebie pancerz jak olbrzym, przypasał wojenny oręż i rozpoczął wojnę, osłaniając wojsko swym mieczem.
###### **1Mch 3,4**
 W czynach swoich był podobny do lwa, był niby lwiątko ryczące w stronę zdobyczy.
###### **1Mch 3,5**
 Ścigał bezbożnych i tropił ich, a na pastwę płomieni wydał tych, którzy niepokoili jego naród.
###### **1Mch 3,6**
 Bezbożnych strach przed nim poraził, i drżeli wszyscy, którzy bezbożnie postępowali, a dzięki niemu powiodło się dzieło wybawienia.
###### **1Mch 3,7**
 Wielu królów rozgniewał na siebie, ale Jakuba rozradował swoimi czynami, i aż na wieki błogosławiona pozostanie jego pamięć.
###### **1Mch 3,8**
 Przeszedł przez miasta ziemi Judy i wygubił z niej ludzi bezbożnych, a gniew [Boży] od Izraela odwrócił.
###### **1Mch 3,9**
 Aż na krańcach ziemi było znane jego imię, i tych zgromadził, którzy mieli zginąć.
###### **1Mch 3,10**
 Apoloniusz zebrał pogan i liczne wojsko z Samarii, żeby walczyć przeciwko Izraelowi.
###### **1Mch 3,11**
 Juda dowiedział się o tym, wyszedł mu naprzeciw, pobił go i zabił. Padło wielu zabitych, a reszta pouciekała.
###### **1Mch 3,12**
 Oni zaś zabrali łupy na nich zdobyte, a Juda wziął sobie miecz Apoloniusza i walczył nim przez całe swoje życie.
###### **1Mch 3,13**
 Seron, dowódca wojsk syryjskich, dowiedział się o tym, że Juda zebrał przy sobie ludzi i zgromadził prawowiernych, aby wyjść na wojnę.
###### **1Mch 3,14**
 Powiedział więc: «***Uczynię głośnym swoje imię i wsławię się w królestwie; będę walczył przeciwko Judzie i przeciwko tym, którzy wraz z nim lekceważą słowo króla***».
###### **1Mch 3,15**
 Tak więc wyruszył on, a z pomocą mu ruszyło także silne wojsko bezbożnych, aby na synach Izraela wykonać zemstę.
###### **1Mch 3,16**
 Gdy zbliżył się do stóp wzniesienia, na którym leży Bet-Choron, wtedy Juda z bardzo małym oddziałem wyszedł mu naprzeciw.
###### **1Mch 3,17**
 Gdy zobaczyli wojsko, które szło naprzeciw nim, powiedzieli do Judy: «***Nas jest tak mało, jakże będziemy mogli walczyć z tym tak wielkim, potężnym mnóstwem? A przecież my dzisiaj nic jeszcze nie jedliśmy i z sił opadliśmy***».
###### **1Mch 3,18**
 Juda odparł: «***Bardzo łatwo wielu można pokonać rękami małej liczby, bo Niebu nie czyni różnicy, czy ocali przy pomocy wielkiej czy małej liczby.***
###### **1Mch 3,19**
 ***Zwycięstwo bowiem w bitwie nie zależy od liczebności wojska; prawdziwą siłą jest ta, która pochodzi z Nieba.***
###### **1Mch 3,20**
 ***Oni przychodzą do nas pełni pychy i bezprawia po to, aby wytracić nas razem z żonami naszymi i dziećmi i aby nas obrabować.***
###### **1Mch 3,21**
 ***My zaś walczymy o swoje życie i o swoje obyczaje.***
###### **1Mch 3,22**
 ***On sam ich zetrze przed naszym obliczem. Wy zaś się ich nie obawiajcie!***»
###### **1Mch 3,23**
 Gdy skończył przemówienie, nagle uderzył na tamtych, tak że Seron i jego wojsko zostali przez nich pobici.
###### **1Mch 3,24**
 Ścigali ich do zejścia z Bet-Choron aż do równiny. Spośród tamtych padło blisko ośmiuset ludzi, a pozostali uciekli do ziemi Filistynów.
###### **1Mch 3,25**
 Wtedy zaczęto się bać Judy i jego braci, a strach przed nimi padł na okoliczne narody.
###### **1Mch 3,26**
 Wieść o nim doszła aż do króla, a narody opowiadały o walkach Judy.
###### **1Mch 3,27**
 Antioch, dowiedziawszy się o tych wydarzeniach, zawrzał gniewem. Rozesłał [rozkazy] i zgromadził wszystkie siły swego królestwa, armię bardzo wielką.
###### **1Mch 3,28**
 Potem otworzył swój skarbiec i na rok naprzód wydał żołd żołnierzom. Polecił także, żeby byli gotowi na wszystko.
###### **1Mch 3,29**
 Wtedy jednak zauważył, że w skarbcach brak pieniędzy. Rozruchy bowiem i utrapienia, jakie sprowadził na te okolice, gdzie kazał znieść obyczaje obowiązujące od najdawniejszych lat, sprawiły, że podatki były małe.
###### **1Mch 3,30**
 Obawiał się więc, że, jak nieraz się to już zdarzało, nie będzie miał pieniędzy na wydatki i na podarunki, które poprzednio rozdawał hojną ręką. Był bowiem bardziej rozrzutny niż inni królowie, jego poprzednicy.
###### **1Mch 3,31**
 W tych wielkich swoich kłopotach postanowił, że uda się do Persji, zbierze podatki z [tamtejszych krain] i zgromadzi wiele pieniędzy.
###### **1Mch 3,32**
 Jako wielkorządcę królewskiego od rzeki Eufrat aż po granice Egiptu zostawił Lizjasza, człowieka poważanego, pochodzącego z królewskiego rodu,
###### **1Mch 3,33**
 [i polecił mu], żeby aż do jego powrotu wychowywał jego syna, Antiocha.
###### **1Mch 3,34**
 Pozostawił mu także połowę swych wojsk razem ze słoniami i dał mu wskazówki co do wszystkich swoich zamiarów i co do mieszkańców Judei i Jerozolimy,
###### **1Mch 3,35**
 żeby mianowicie wysłał przeciwko nim wojsko, starł i zniósł całkowicie siły izraelskie i to, co pozostało z Jerozolimy, żeby wymazał nawet pamięć o nich na tym miejscu,
###### **1Mch 3,36**
 żeby obcych ludzi osiedlił na ich obszarach, a ziemię losem porozdzielał.
###### **1Mch 3,37**
 Wtedy król zabrał drugą połowę swych wojsk, w roku sto czterdziestym siódmym wyruszył z królewskiej swej stolicy, Antiochii, przeprawił się przez rzekę Eufrat i przeszedł przez górne krainy.
###### **1Mch 3,38**
 Lizjasz wybrał Ptolemeusza, syna Dorymenesa, oraz Nikanora i Gorgiasza, ludzi walecznych spomiędzy królewskich przyjaciół,
###### **1Mch 3,39**
 i posłał z nimi czterdzieści tysięcy pieszych i siedem tysięcy konnicy, żeby poszli do ziemi judzkiej i spustoszyli ją zgodnie z królewskim rozkazem.
###### **1Mch 3,40**
 Wyruszyli oni z całym swym wojskiem, przybyli w pobliże Emaus i rozłożyli się obozem na równinie.
###### **1Mch 3,41**
 Gdy kupcy z tamtejszej okolicy dowiedzieli się o tym, wzięli bardzo dużo srebra i złota oraz pęta na nogi i przybyli do obozu, aby Izraelitów wziąć sobie za niewolników. Dołączyły do nich także oddziały z Syrii i z ziemi filistyńskiej.
###### **1Mch 3,42**
 Juda razem z braćmi zobaczył, że miara nieszczęść się dopełniła, a wojska obozują już na ich ziemi. Dowiedzieli się też o rozkazach, które król wydał, żeby naród zniszczyć zupełnie.
###### **1Mch 3,43**
 Jeden więc do drugiego mówił: «***Przeciwstawmy się zniszczeniu naszego narodu. Walczmy w obronie naszego narodu i świętości!***»
###### **1Mch 3,44**
 Zgromadzili się więc wszyscy, by gotowymi być do walki, a także by się modlić i prosić o łaskę i zmiłowanie.
###### **1Mch 3,45**
 Jeruzalem było wyludnione jak jakaś pustynia; spośród jego dzieci nikt do niego nie wchodził ani nie wychodził, świątynię deptano. W zamku synowie cudzoziemców,[a miasto] gospodą dla pogan. Od Jakuba odeszła radość, nie słychać już fletu ani harfy.
###### **1Mch 3,46**
 Zgromadzili się i udali się do Mispa, naprzeciw Jerozolimy, ponieważ niegdyś Mispa było dla Izraela miejscem modlitwy.
###### **1Mch 3,47**
 Tego dnia pościli, włożyli na siebie wory, głowy posypali popiołem i porozdzierali swoje szaty.
###### **1Mch 3,48**
 Potem rozwinęli księgę Prawa w tym samym celu, w jakim poganie wypytują posągi swych bóstw.
###### **1Mch 3,49**
 Potem przynieśli kapłańskie szaty, pierwociny plonów i dziesięciny, przywołali także nazirejczyków, którzy dopełnili już dni [ślubów],
###### **1Mch 3,50**
 i wołali do Nieba słowa mi: «***Co mamy czynić z tymi? Gdzie ich zaprowadzić?***
###### **1Mch 3,51**
 ***Świątynia Twoja została podeptana i znieważona, a kapłani Twoi – w żałobie i poniżeniu.***
###### **1Mch 3,52**
 ***A oto jeszcze poganie zebrali się przeciwko nam, aby nas zniszczyć całkowicie. Ty wiesz, jakie oni mają wobec nas zamiary.***
###### **1Mch 3,53**
 ***Jak będziemy mogli ostać się przed nimi, jeżeli Ty nas nie wspomożesz?***»
###### **1Mch 3,54**
 Wtedy zaczęli grać na trąbach i podnieśli ogromny krzyk.
###### **1Mch 3,55**
 Potem Juda ustanowił dowódców nad ludem: tysiączników, setników, pięćdziesiątników i dziesiętników.
###### **1Mch 3,56**
 Powiedział też, żeby zgodnie z Prawem wrócili do domu ci, którzy budowali dom, ożenili się [właśnie], założyli winnicę lub byli bojaźliwi.
###### **1Mch 3,57**
 Wtedy wojsko wyruszyło w drogę i na południe od Emaus rozłożyło się obozem.
###### **1Mch 3,58**
 Juda zaś powiedział: «***Przepaszcie się i bądźcie waleczni! Jutro rano bądźcie gotowi walczyć z tymi poganami, którzy zeszli się przeciwko nam, żeby całkowicie zniszczyć nas i naszą świątynię.***
###### **1Mch 3,59**
 ***Lepiej nam przecież zginąć w bitwie, niż patrzeć na niedolę naszego narodu i świątyni.***
###### **1Mch 3,60**
 ***Jakakolwiek zaś będzie wola w Niebie, tak uczyni***».
# 1Mch 3 PAU
###### **1Mch 3,1**
 Zastąpił go jego syn Juda, zwany Machabeuszem.
###### **1Mch 3,2**
 Wspomagali go wszyscy jego bracia i ci, którzy przyłączyli się do jego ojca. Z zapałem walczyli w obronie Izraela.
###### **1Mch 3,3**
 On swój lud rozsławił i przywdział zbroję jak olbrzym. Przypasał sobie oręż i stanął do wojny, własnym mieczem chronił wojsko.
###### **1Mch 3,4**
 W swoich czynach był do lwa podobny, do lwiątka ryczącego nad zdobyczą.
###### **1Mch 3,5**
 Ścigał nieprawych, których wytropił, i spalił tych, którzy nękali lud jego.
###### **1Mch 3,6**
 Nieprawi przerazili się jego gniewem, zadrżeli wszyscy czyniący nieprawość. Za przyczyną jego ręki wybawienie dokonywało się pomyślnie.
###### **1Mch 3,7**
 Rozgniewał wielu królów, lecz swoimi czynami uradował Jakuba. Pamięć o nim na zawsze będzie błogosławiona.
###### **1Mch 3,8**
 Przeszedł przez miasta Judy, wytępił w nich bezbożnych i odwrócił gniew od Izraela.
###### **1Mch 3,9**
 Jego imię było sławne aż po krańce ziemi, on zgromadził tych, co mieli zginąć.
###### **1Mch 3,10**
 Tymczasem Apoloniusz zgromadził pogan i wielkie wojsko z Samarii, aby walczyć z Izraelem.
###### **1Mch 3,11**
 Juda dowiedział się o tym, wyszedł mu naprzeciw, pobił go i zabił. Padło wielu zabitych, a pozostali uciekli.
###### **1Mch 3,12**
 Zabrano ich łupy, a Juda wziął miecz Apoloniusza i odtąd zawsze nim walczył.
###### **1Mch 3,13**
 Seron, dowódca wojska Syrii, usłyszał, że Juda zebrał ludzi, zgromadził wiernych sobie i wyruszył z nimi na wojnę.
###### **1Mch 3,14**
 Powiedział wtedy: „Rozsławię swoje imię i okryję się chwałą w królestwie. Pokonam Judę i jego towarzyszy, którzy lekceważą nakaz króla”.
###### **1Mch 3,15**
 Wyruszył więc, a razem z nim poszło silne wojsko bezbożnych, aby mu pomóc zemścić się na Izraelitach.
###### **1Mch 3,16**
 Zbliżyli się aż do wzniesienia Bet-Choron, a Juda wyszedł mu naprzeciw z garstką ludzi.
###### **1Mch 3,17**
 Kiedy dostrzegli wojsko idące im naprzeciw, powiedzieli do Judy: „Jakże nas garstka może walczyć przeciwko temu potężnemu tłumowi? W dodatku jesteśmy osłabieni, bo dzisiaj pościliśmy”.
###### **1Mch 3,18**
 Juda odpowiedział: „Mały oddział może łatwo pokonać wielu. Niebu nie sprawia różnicy, czy ocala przy pomocy mnóstwa czy małego oddziału,
###### **1Mch 3,19**
 bo zwycięstwo w bitwie nie zależy od liczebności wojska, lecz od siły pochodzącej z Nieba.
###### **1Mch 3,20**
 Oni przychodzą przeciwko nam pełni pychy i bezprawia, aby wygubić nas, nasze żony i nasze dzieci oraz aby nas złupić.
###### **1Mch 3,21**
 My zaś walczymy o nasze życie i nasze prawa.
###### **1Mch 3,22**
 Nie bójcie się, bo On sam zetrze ich w naszej obecności”.
###### **1Mch 3,23**
 Skoro tylko skończył przemawiać, uderzył na nich znienacka, pokonał Serona i jego wojsko.
###### **1Mch 3,24**
 Ścigali go po zboczu Bet-Choron aż do równiny. Zabili około ośmiuset ludzi, pozostali uciekli do kraju Filistynów.
###### **1Mch 3,25**
 Tak Juda i jego bracia zaczęli budzić grozę. Przerażenie padło na okoliczne narody.
###### **1Mch 3,26**
 Jego sława dotarła do króla, a o bitwach Judy opowiadały narody.
###### **1Mch 3,27**
 Kiedy król Antioch usłyszał te opowieści, zapałał gniewem. Kazał zgromadzić wszystkie wojska swego królestwa - bardzo silną armię.
###### **1Mch 3,28**
 Otworzył swój skarbiec i wypłacił wojskom żołd za cały rok. Rozkazał im trwać w gotowości bojowej.
###### **1Mch 3,29**
 Spostrzegł jednak, że w skarbcach brakuje pieniędzy i że wpływy z podatków z kraju są małe z powodu waśni i nieszczęść, które spowodowało zniesienie praw obowiązujących od zamierzchłych czasów.
###### **1Mch 3,30**
 Przeląkł się, że nie ma - jak to się już kilka razy wydarzyło - na wydatki i dary, które poprzednio rozdawał szczodrą ręką. Był bowiem bardziej rozrzutny niż poprzedni królowie.
###### **1Mch 3,31**
 Przytłoczony tymi kłopotami postanowił udać się do Persji, aby zebrać podatki z krajów i zgromadzić wiele pieniędzy.
###### **1Mch 3,32**
 Sprawy królestwa od rzeki Eufrat aż do granic Egiptu powierzył Lizjaszowi, człowiekowi sławnemu, który pochodził z królewskiego rodu.
###### **1Mch 3,33**
 Kazał mu też aż do swojego powrotu wychowywać swojego syna Antiocha.
###### **1Mch 3,34**
 Przekazał mu połowę swych wojsk i słoni oraz wydał mu polecenia dotyczące wszystkich swoich decyzji, w tym także tych, które odnosiły się do mieszkańców Judei i Jerozolimy.
###### **1Mch 3,35**
 Miał wysłać przeciwko nim wojsko, aby doszczętnie zniszczyło siłę Izraela i to, co pozostało z Jerozolimy, by wymazać pamięć o nich z tego miejsca.
###### **1Mch 3,36**
 Całą ich krainę miał zasiedlić cudzoziemcami, przydzielając im ziemię za pomocą losów.
###### **1Mch 3,37**
 Król zabrał ze sobą pozostałą część wojsk i w roku sto czterdziestym siódmym wyruszył ze swojego królewskiego miasta Antiochii. Przekroczył Eufrat i szedł dalej przez górskie prowincje.
###### **1Mch 3,38**
 Lizjasz wybrał spośród przyjaciół króla dzielnych ludzi: Ptolemeusza, syna Dorymenesa, Nikanora i Gorgiasza.
###### **1Mch 3,39**
 Posłał z nimi czterdzieści tysięcy piechoty i siedem tysięcy jazdy, aby udali się do kraju Judy i zniszczyli go zgodnie z rozkazem króla.
###### **1Mch 3,40**
 Wyruszyli więc z całym swoim wojskiem i zatrzymali się na równinie w pobliżu Emaus.
###### **1Mch 3,41**
 Gdy tamtejsi kupcy usłyszeli o nich, wzięli bardzo wiele srebra i złota, a także kajdany, i przyszli do ich obozu, aby kupić Izraelitów jako niewolników. Do wojska zaś dołączyły też oddziały syryjskie i filistyńskie.
###### **1Mch 3,42**
 Juda i jego bracia zobaczyli, że grozi im wielkie niebezpieczeństwo, bo wrogie wojska obozują już w ich granicach. Dowiedzieli się także o tym, że król nakazał doszczętnie zniszczyć lud.
###### **1Mch 3,43**
 Mówili między sobą: „Nie pozwólmy poniżać naszego ludu. Walczmy w obronie ludu i świętości”.
###### **1Mch 3,44**
 Zwołano zgromadzenie, aby przygotować się do wojny, aby się modlić i błagać o miłosierdzie i litość.
###### **1Mch 3,45**
 Jeruzalem wyludniło się jak pustynia. Nie wchodzi ani nie wychodzi z niego żadne z jego dzieci. Podeptano świątynię, a cudzoziemcy zamieszkali w twierdzy jak obcy ludzie w gospodzie. Zabrano radość Jakubowi. Zamilkły flet i cytra.
###### **1Mch 3,46**
 Zgromadzili się i przyszli do Mispy, naprzeciwko Jeruzalem, ponieważ wcześniej Mispa była dla Izraela miejscem modlitwy.
###### **1Mch 3,47**
 Tego dnia pościli i nałożyli wory pokutne, posypali głowy popiołem i rozdarli swoje szaty.
###### **1Mch 3,48**
 Rozwinęli zwój Prawa, aby zasięgnąć rady, podobnie jak poganie zwracają się po radę do posągów swoich bożków.
###### **1Mch 3,49**
 Przynieśli szaty kapłańskie oraz pierwociny i dziesięciny. Sprowadzili też nazirejczyków, którym upłynął czas ślubów.
###### **1Mch 3,50**
 Wołali głośno do Nieba: „Co mamy z nimi uczynić? Dokąd ich zaprowadzić?
###### **1Mch 3,51**
 Podeptano i zbezczeszczono Twoje świętości. Twoi kapłani są w żałobie i w poniżeniu.
###### **1Mch 3,52**
 Bo oto obce narody zgromadziły się przeciwko nam, aby nas zniszczyć. Ty wiesz, co przeciwko nam obmyślają.
###### **1Mch 3,53**
 Jakże będziemy mogli stawić im opór, jeśli Ty nas nie wesprzesz?”.
###### **1Mch 3,54**
 Wtedy zadęli w trąby i wydali donośny okrzyk.
###### **1Mch 3,55**
 Potem Juda ustanowił dowódców ludu: tysiączników, setników, pięćdziesiątników i dziesiętników.
###### **1Mch 3,56**
 Powiedział też, aby zgodnie z Prawem powrócili do domu ci, którzy budowali dom, ożenili się, zasadzili winnicę, a także ci, którym brakło odwagi.
###### **1Mch 3,57**
 Następnie wyprowadził wojsko i rozbił obóz na południe od Emaus.
###### **1Mch 3,58**
 Juda powiedział: „Przepasajcie się i bądźcie dzielni. Rano stańcie gotowi do walki z tymi obcymi narodami, które zgromadziły się przeciwko nam, aby zniszczyć nas i naszą świętość.
###### **1Mch 3,59**
 Lepiej umrzeć w walce, niż oglądać poniżenie naszego ludu i świętości.
###### **1Mch 3,60**
 Jaka będzie wola Nieba, tak niech się dzieje!”.
# 1Mch 3 BP
###### **1Mch 3,1**
 Miejsce [Mattatiasza] zajął syn jego Juda, zwany Machabeuszem.
###### **1Mch 3,2**
 Wspierali go wszyscy bracia oraz ci, którzy walczyli u boku ojca. I tak radośnie wiedli bój w obronie Izraela.
###### **1Mch 3,3**
 On to rozsławił imię swego ludu, niczym olbrzym ubrał pancerz i przywdział wojenny oręż, i walczył osłaniając wojsko swym mieczem.
###### **1Mch 3,4**
 W czynach podobny był do lwa, do młodego lwa, który z rykiem rzuca się na zdobycz.
###### **1Mch 3,5**
 Tropił i nękał bezbożnych, palił prześladowców swego ludu.
###### **1Mch 3,6**
 Bezbożni drżeli ze strachu przed nim, pełni lęku byli też wszyscy łamiący Prawo. A on przynosił [narodowi] ratunek i szczęście mu sprzyjało.
###### **1Mch 3,7**
 Czynami swymi budził gniew wielu królów, a rozweselał Jakuba i imię jego błogosławione będzie na wieki.
###### **1Mch 3,8**
 Przeszedł przez miasta judzkie i wygubił bezbożnych, i odwrócił gniew ciążący nad Izraelem.
###### **1Mch 3,9**
 Sława jego sięgała aż po krańce ziemi i zgromadził tych, nad którymi zawisła zguba.
###### **1Mch 3,10**
 Tymczasem Apoloniusz zebrał pogan i wielkie wojsko z Samarii, aby uderzyć na Izraela.
###### **1Mch 3,11**
 Na wiadomość o tym Juda wyruszył naprzeciwko niemu, pokonał go i zabił. Padło wielu rannych, a reszta uciekła.
###### **1Mch 3,12**
 Zabrali zdobyte łupy, a miecz Apoloniusza wziął Juda i odtąd zawsze nim walczył.
###### **1Mch 3,13**
 Seron, dowódca wojsk syryjskich, dowiedział się, że Juda zebrał ludzi i zgromadził wokół siebie wiernych, którzy wyruszyli z nim na wojnę.
###### **1Mch 3,14**
 Powiedział więc: Sprawię, że imię moje stanie się głośne i zdobędę sławę w całym królestwie. Będę walczył z Judą i jego towarzyszami, którzy lekceważą rozkaz królewski.
###### **1Mch 3,15**
 Wyruszył przeto, a z nim potężne wojsko bezbożnych, aby mu pomóc w zemście nad synami Izraela.
###### **1Mch 3,16**
 Kiedy zbliżył się do wzgórza, [na którym leży miasto] Betoron, wyszedł naprzeciw niego Juda z garstką ludzi.
###### **1Mch 3,17**
 Gdy ujrzeli wojsko, idące na spotkanie, rzekli do Judy: Jakże mało nas! Czy stawimy czoła tak potężnej masie? Ponadto brak nam sił, bo nic jeszcze dzisiaj nie jedliśmy.
###### **1Mch 3,18**
 Juda odpowiedział: Łatwo może się zdarzyć, że garstka pokona wielu. Niebu nie sprawia różnicy, czy zsyła ratunek dla tysięcy, czy dla kilku.
###### **1Mch 3,19**
 Albowiem zwycięstwo w bitwie nie zależy od dużej liczby wojska, lecz od potęgi nieba.
###### **1Mch 3,20**
 Oni idą przeciw nam pełni pychy i nieprawości, aby wygubić nas wraz z żonami i dziećmi i aby nas obrabować.
###### **1Mch 3,21**
 My zaś stajemy do walki o nasze życie i prawa.
###### **1Mch 3,22**
 Nie lękajcie się. On sam zetrze ich na naszych oczach.
###### **1Mch 3,23**
 Gdy skończył mówić, uderzył na nich znienacka, tak że rozgromił Serona i jego wojsko.
###### **1Mch 3,24**
 Ścigali go po zboczu wzgórza Betoron aż na równinę. Zabili około ośmiuset ludzi. Reszta uciekła do kraju Filistynów.
###### **1Mch 3,25**
 I poczęto bać się Judy i jego braci. Strach padł nawet na okoliczne ludy.
###### **1Mch 3,26**
 Imię Judy dotarło aż do króla, a poganie opowiadali o stoczonych przez niego walkach.
###### **1Mch 3,27**
 Król Antioch na wiadomość o tych wypadkach uniósł się wielkim gniewem. Zgromadził przez posłańców wszystkie wojska swego królestwa - bardzo silną armię.
###### **1Mch 3,28**
 Potem otworzył skarbiec i zapłacił żołnierzom za cały rok z góry. Polecił też, aby byli gotowi na wszystko.
###### **1Mch 3,29**
 Wtedy spostrzegł, że wydano ze skarbca wszystkie pieniądze, a podatki z kraju zmalały z powodu rozruchów i nędzy spowodowanej próbą wykorzenienia zwyczajów przestrzeganych od niepamiętnych czasów.
###### **1Mch 3,30**
 Zaniepokoił się, że braknie mu - jak to się nieraz zdarzało - [pieniędzy] na wydatki i podarki, które poprzednio rozdawał szczodrą ręką - był bowiem bardziej hojny od swych poprzedników na tronie.
###### **1Mch 3,31**
 Będąc więc w kłopotach postanowił wyruszyć do Persji, aby ściągnąć podatki z [tamtych] krain i zebrać wiele pieniędzy.
###### **1Mch 3,32**
 Sprawy królestwa od rzeki Eufrat aż do granic Egiptu powierzył Lizjaszowi, znakomitemu mężowi, który pochodził z królewskiego rodu.
###### **1Mch 3,33**
 [Zlecił mu również] opiekę nad wychowaniem swego syna Antiocha aż do swego powrotu.
###### **1Mch 3,34**
 Jednocześnie przekazał mu połowę wojska i słoni dając wskazówki co do wszystkich swoich zamierzeń, nie wyłączając spraw mieszkańców Judei i Jerozolimy.
###### **1Mch 3,35**
 [planował mianowicie] wysłać przeciwko nim wojsko, aby doszczętnie znieść siły Izraela i zniszczyć to, co pozostało z Jerozolimy, tak aby nawet pamięć o nich nie przetrwała na tym miejscu.
###### **1Mch 3,36**
 Obszary te miały być zasiedlone przez obcych, a ziemia rozdzielona jak komu los wyznaczy.
###### **1Mch 3,37**
 Sam król zabrał z sobą pozostałą część wojska i w roku sto czterdziestym siódmym wyruszył ze swej stolicy Antiochii. Przeprawiwszy się przez Eufrat, ciągnął dalej w kierunku obszarów górzystych.
###### **1Mch 3,38**
 Lizjasz spośród przyjaciół króla wybrał dzielnych mężów: Ptolemeusza, syna Dorymenesa, Nikanora oraz Gorgiasza
###### **1Mch 3,39**
 i wysłał ich na czele czterdziestu tysięcy piechoty i siedmiu tysięcy jazdy, aby spustoszyć ziemię judzką; i wkroczyli do niej zgodnie z rozkazem króla.
###### **1Mch 3,40**
 Ruszyli więc z całą potęgą, a przybywszy w okolice Emmaus rozbili obóz na równinie.
###### **1Mch 3,41**
 Skoro tamtejsi kupcy dowiedzieli się o tym, wzięli bardzo wiele srebra i złota oraz pęta na nogi i przybyli do obozu, aby synów Izraela kupić jak niewolników. Do wojsk tych przyłączyły się nadto oddziały z Syrii i z innych sąsiednich krajów.
###### **1Mch 3,42**
 Juda i jego bracia zrozumieli, że nadchodzi jeszcze więcej nieszczęść, gdyż wojska obozują już w ich kraju. Dowiedzieli się też o rozkazie króla, który nakazał doszczętnie wyniszczyć naród.
###### **1Mch 3,43**
 Mówili więc między sobą: "Nie pozwólmy upaść naszemu narodowi i walczmy w obronie ludu i naszych świętości".
###### **1Mch 3,44**
 Zgromadzili się więc wszyscy, aby przygotować się do walki i w modlitwie błagać o łaskę i zmiłowanie.
###### **1Mch 3,45**
 Jerozolima wyludniła się jak pustynia; żadne z jej dzieci nie wchodziło ani nie wychodziło z miasta. Świątynia była podeptana, w zamku synowie cudzoziemców, [miasto] niczym zajazd dla pogan. Odjęto Jakubowi radość, zamilkły flety i cytry.
###### **1Mch 3,46**
 Zebrali się i poszli do Masfa, naprzeciw Jerozolimy, gdyż była ona niegdyś dla Izraela miejscem modlitwy.
###### **1Mch 3,47**
 Owego dnia pościli, oblekli się w wory, głowy posypali popiołem i rozdarli swe szaty.
###### **1Mch 3,48**
 Potem rozwinęli Księgę Prawa, aby zasięgnąć rady, tak jak poganie zapytują posągi swych bożków.
###### **1Mch 3,49**
 Przynieśli także szaty kapłańskie, pierwociny i dziesięciny oraz przywołali nazirejczyków, którzy wypełnili dni ślubu.
###### **1Mch 3,50**
 I tymi słowami wołali do nieba: "Cóż mamy z nimi uczynić? Dokąd ich zaprowadzić?
###### **1Mch 3,51**
 Twoja Świątynia zdeptana i zbezczeszczona, Twoi kapłani w smutku i poniżeniu.
###### **1Mch 3,52**
 Oto poganie sprzymierzyli się przeciwko nam, by nas wszystkich wygubić. Ty [jeden] wiesz, co knują przeciwko nam.
###### **1Mch 3,53**
 Jakże zdołamy oprzeć się im, jeśli Ty nie przyjdziesz nam z pomocą?"
###### **1Mch 3,54**
 Po czym zatrąbili i podnieśli ogromny krzyk.
###### **1Mch 3,55**
 Następnie ustanowił Juda naczelników ludu - dowódców nad oddziałami [składającymi się] z tysiąca, stu, pięćdziesięciu i dziesięciu ludzi.
###### **1Mch 3,56**
 Zgodnie z Prawem polecił wrócić do domu tym, którzy budowali dom, mieli zawrzeć związek małżeński, zakładali winnicę lub byli mało odważni.
###### **1Mch 3,57**
 Po czym wojsko wyruszyło i rozłożyło się obozem na południe od Emmaus.
###### **1Mch 3,58**
 I Juda przemówił: "Przepaszcie się i bądźcie dzielnymi mężami. Jutro rano stańcie gotowi do walki z poganami, którzy zebrali się przeciwko nam, aby doszczętnie zniszczyć nas i naszą Świątynię.
###### **1Mch 3,59**
 Lepiej umrzeć w walce niż patrzeć na nieszczęście naszego narodu i [poniżenie] Świątyni.
###### **1Mch 3,60**
 Jaka będzie wola nieba, tak też niechaj się stanie!"
# 1Mch 3 BR
###### **1Mch 3,16**
 I tak dotarli aż do wzniesienia, na którym jest położone Bet-Choron. Wówczas wyszedł im naprzeciw Juda z niewielkim oddziałem.
###### **1Mch 3,28**
 Potem kazał ze swoich skarbców wypłacić wojownikom żołd z góry na cały rok i polecił im przygotować się na wszystko.
###### **1Mch 3,29**
 Ale okazało się, że jego skarbce świecą pustkami. Z krajów bowiem, w których wszczął spory i rozruchy, znosząc dawne obyczaje, mało wpływało podatków.
###### **1Mch 3,17**
 Wojownicy Judy, zobaczywszy tak ogromne wojsko, które nadciągało przeciw nim, zaczęli mówić do niego: Jakże my się oprzemy tak ogromnej potędze? Jest nas przecież bardzo niewielu. Poza tym jesteśmy słabi, bo dziś jeszcze nic nie jedliśmy.
###### **1Mch 3,18**
 Odpowiedział im wtedy Juda: Z łatwością może dojść do tego, że liczni wpadną w ręce niewielu. Dla nieba nie ma bowiem różnicy, czy zsyła ono ocalenie przez licznych, czy przez bardzo niewielu.
###### **1Mch 3,19**
 Zwycięstwo w walce nie zależy bowiem od liczby wojowników, lecz od siły, która z nieba pochodzi.
###### **1Mch 3,20**
 Ludzie ci walczą z nami, bo są pełni buty i chcą wygubić nas razem z naszymi kobietami i dziećmi oraz zabrać nasze mienie.
###### **1Mch 3,21**
 A my będziemy bronili naszego życia i prawa.
###### **1Mch 3,22**
 To same niebiosa zgładzą ich na naszych oczach. Nie lękajcie się ich wcale!
###### **1Mch 3,23**
 Zaledwie to powiedział, rzucił się niespodziewanie na wrogów. Wkrótce Seron i całe jego wojsko zostało rozgromione na jego oczach.
###### **1Mch 3,24**
 Ścigali ich potem od Bet-Choron aż do równiny. I poległo wówczas około ośmiuset ludzi [Serona], a reszta schroniła się do kraju Filistynów.
###### **1Mch 3,25**
 Zaczęto się wtedy obawiać Judy i braci jego, strach padł na wszystkie ludy dokoła.
###### **1Mch 3,26**
 Nawet król posłyszał o jego imieniu, bo cały świat opowiadał o zwycięskich walkach Judy.
###### **1Mch 3,27**
 Na wieść o tym wszystkim król Antioch zapłonął wielkim gniewem. Rozesłał po całym kraju gońców i zgromadził wszystkich swoich wojowników, którzy tworzyli wielkie i potężne wojska.
###### **1Mch 3,1**
 Matatiasza zastąpił jego syn, Juda, z przydomkiem Machabeusz.
###### **1Mch 3,2**
 Poszli za nim wszyscy jego bracia oraz ci wszyscy, którzy popierali kiedyś jego ojca. Pełni zapału walczyli za Izrael.
###### **1Mch 3,3**
 Cały swój naród okrył wielką chwałą, jak wojenny bohater przywdział zbroję, broń wziął do ręki i bój rozpoczął, i własnym mieczem osłaniał walczących.
###### **1Mch 3,4**
 W walce był do lwa podobny i jak młode lwiątko rzucał się z rykiem na zdobycze.
###### **1Mch 3,5**
 Ścigał grzeszników, idąc ich tropem, ogniem nękał ciemiężców własnego narodu.
###### **1Mch 3,6**
 Bezbożnym ze strachu nie stało odwagi, wszyscy złoczyńcy drżeli z przerażenia, jego zaś prawica przynosiła wolność i szczęście mu sprzyjało.
###### **1Mch 3,7**
 Wielu królów pobudził do gniewu, lecz Jakuba uradował swoimi czynami. Pamięć o nim będą czcić na wieki.
###### **1Mch 3,8**
 I przeciągał przez miasta Judy, i mieczem zabijał bezbożnych, chroniąc Izrael przed gniewem Boga.
###### **1Mch 3,9**
 Rozprawiano o nim aż po krańce ziemi, on zaś zbierał wokół siebie to, co było stracone.
###### **1Mch 3,10**
 Wtedy to Apoloniusz utworzył z obcych narodów oddziały wojowników, a nadto zebrał wielkie wojsko Samarytan i przygotowywał się do wojny z Izraelem.
###### **1Mch 3,11**
 dowiedziawszy się o tym, Juda wyruszył mu naprzeciw, zaatakował go i zabił. Wielu wojowników Apoloniusza poległo w tej walce, reszta zaś ratowała się ucieczką.
###### **1Mch 3,12**
 Potem przystąpiono do dzielenia łupów. Juda wziął dla siebie miecz Apoloniusza. Odtąd zawsze do końca życia, używał go w walce.
###### **1Mch 3,13**
 Po jakimś czasie Seron, naczelny dowódca oddziałów syryjskich, usłyszał, że Juda zgromadził wokół siebie ludzi wiernych prawu i wyruszył do walki.
###### **1Mch 3,14**
 Pomyślał sobie wtedy: Mam okazję uczynić głośnym moje imię i stać się sławnym w całym królestwie. Podejmę walkę z Judą i jego ludźmi, którzy lekceważą sobie rozkazy króla.
###### **1Mch 3,15**
 Przyłączyła się do niego ogromna rzesza bezbożnych, którzy wyruszyli, by razem dokonać zemsty na Izraelitach.
###### **1Mch 3,30**
 Martwił się więc, że - jak to się uprzednio już zdarzało - nie będzie już mógł żyć tak dostatnio ani rozdzielać tak hojnie podarków. Dotychczas był on bowiem bardzo rozrzutny, o wiele bardziej niż jego poprzednicy na tronie.
###### **1Mch 3,31**
 Pełen takiej rozterki postanowił udać się do Persji i ze wszystkich tamtejszych prowincji ściągać podatki, i w ten sposób zgromadzić potrzebne pieniądze.
###### **1Mch 3,32**
 Jako swojego zarządcę na ziemiach między Eufratem a granicą egipską zostawił Lizjasza, męża powszechnie szanowanego, który pochodził z rodziny królewskiej.
###### **1Mch 3,33**
 Jemu też powierzył wychowanie własnego syna, Antiocha, aż do swego powrotu z wojny.
###### **1Mch 3,34**
 Pod jego władzą zostawił także połowę oddziałów wojskowych oraz bojowe słonie. Ujawnił mu również swoje zamiary co do mieszkańców Judei oraz Jerozolimy.
###### **1Mch 3,35**
 Wreszcie powiedział mu, że przygotowuje liczne wojsko, które ma uderzyć na Izrael, aby złamać jego opór, zniszczyć wszystko, co jeszcze pozostało w Jerozolimie, i w ten sposób zatrzeć wszelką pamięć [o Żydach].
###### **1Mch 3,36**
 Zamierzał on także na całym obszarze osiedlić obce narody, losami rozdzielając między nich poszczególne części kraju.
###### **1Mch 3,37**
 Drugą połowę oddziałów wojskowych zabrał król ze sobą. W roku sto czterdziestym siódmym opuścił stolicę swego królestwa, Antiochię, i ruszył w drogę. Przeprawił się przez Eufrat i skierował swe kroki ku prowincjom wschodnim.
###### **1Mch 3,38**
 Tymczasem Lizjasz wybrał Ptolemeusza, syna Dorymenesa, Nikanora i Gorgiasza, dzielnych mężów należących do grona przyjaciół króla,
###### **1Mch 3,39**
 i wyprawił ich z wojskiem liczącym czterdzieści tysięcy pieszych wojowników oraz siedem tysięcy jeźdźców. Mieli oni wkroczyć do Judei i - zgodnie z rozkazem króla spustoszyć cały kraj.
###### **1Mch 3,40**
 Ruszyli tedy z całym swoim wojskiem, dotarli aż do Emmaus i tam, na równinie, rozbili obóz.
###### **1Mch 3,41**
 Na wieść o tym zaczęli ściągać do nich okoliczni kupcy. Przynosili ze sobą dużo srebra, złota i więzy na nogi, zamierzając nabyć sobie Izraelitów jako niewolników. Do wojsk Lizjasza dołączyły także oddziały syryjskie i filistyńskie.
###### **1Mch 3,42**
 Kiedy Juda i jego bracia zobaczyli, jak wielkie zagraża im nieszczęście, kiedy się przypatrzyli namiotom wroga ustawionym już na ich ziemi, kiedy się dowiedzieli, jakie rozkazy wydał król, żeby zgładzić cały naród,
###### **1Mch 3,43**
 zaczęli mówić jedni do drugich: Nie dopuścimy do zagłady naszego narodu, będziemy walczyć o nasz naród i wszystkie jego świętości.
###### **1Mch 3,44**
 I zebrali się razem, aby stanąć do walki, także by się modlić i wypraszać sobie łaskę i zmiłowanie Boże.
###### **1Mch 3,45**
 Jeruzalem było jak pustynie bezludne, żadne z jego dzieci nie wchodziło do niego ani z niego nie wychodziło. Wszystkie jego świętości były zbezczeszczone. W twierdzy osiedli cudzoziemcy, jak obce ludy w gospodzie. Jakub nie mógł się już ratować, flety i harfy zamilkły.
###### **1Mch 3,46**
 Zebrali się tedy i ruszyli w stronę Mispy, miejscowości położonej niedaleko Jerozolimy. To właśnie w Mispa gromadzili się kiedyś Izraelici na modlitwę.
###### **1Mch 3,47**
 I pościli tego dnia ubrani w pokutne wory, z głowami posypanymi popiołem i z porozdzieranymi szatami.
###### **1Mch 3,48**
 Rozwijali zwoje prawa, szukając w nich rady, tak jak obce narody zwracają się po radę do posągów swoich bogów.
###### **1Mch 3,49**
 Przynieśli także szaty kapłańskie, owoce składane jako pierwociny oraz dziesięcinę i kazali zebrać się razem nazirejczykom, którym skończył się czas ich ślubów.
###### **1Mch 3,50**
 Wspólnie tak wołali donośnym głosem do nieba: Co mamy robić z tym wszystkim? Jak mamy postąpić z tymi ludźmi? Dokąd mamy ich skierować?
###### **1Mch 3,51**
 Bezcześci się i hańbi Twój przybytek; Twoi kapłani żyją w nędzy i poniżeniu.
###### **1Mch 3,52**
 Popatrz tylko: Przecież gromadzą się liczne obce narody żeby nam zgotować zagładę. Ty wiesz dobrze, co zamierzają z nami uczynić.
###### **1Mch 3,53**
 Jakże będziemy mogli ich powstrzymać, jeśli Ty nie przyjdziesz nam z pomocą?
###### **1Mch 3,54**
 Grali przy tym na trąbach i wołali głośno.
###### **1Mch 3,55**
 Potem wyznaczył Juda dowódców nad oddziałami liczącymi po tysiąc, sto, pięćdziesiąt i dziesięć osób.
###### **1Mch 3,56**
 Wszystkim tym, którzy dopiero co zbudowali sobie dom, poślubili żonę, założyli winnicę albo po prostu się bali, pozwolił, zgodnie z prawem, wrócić do domu.
###### **1Mch 3,57**
 W końcu całe wojsko ruszyło w drogę i po niedługim czasie rozbito obóz na południe od Emmaus.
###### **1Mch 3,58**
 A Juda powiedział: Chwyćcie za broń i bądźcie dzielni! Przygotujcie się dobrze, byśmy mogli jutro wczesnym rankiem uderzyć na te obce ludy, które nadciągnęły tu, aby zniszczyć cały nasz naród i naszą świątynię.
###### **1Mch 3,59**
 Wolimy raczej polec na wojnie niż patrzeć, jak nieszczęście spada na cały lud i na naszą świątynię.
###### **1Mch 3,60**
 Ale niech się dzieje tak, jak chcą niebiosa.
# 1Mch 3 WUJ
