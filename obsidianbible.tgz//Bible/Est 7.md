# Est 7 BT5
###### **Est 7,1**
 Przyszedł więc król z Hamanem, aby ucztować z królową Esterą.
###### **Est 7,2**
 I także w drugim dniu podczas picia wina król rzekł do Estery: «***Jakie jest twoje życzenie, królowo Estero, a będzie ci spełnione, i jaka twoja prośba? Choćby to była połowa królestwa, stanie się***».
###### **Est 7,3**
 W odpowiedzi rzekła królowa Estera: «***Królu, jeśli darzysz mnie życzliwością i jeśli król uzna za słuszne, to niech będzie darowane mi życie – oto moje życzenie, i lud mój – oto moja prośba!***
###### **Est 7,4**
 ***Albowiem sprzedano nas, mnie i mój lud, aby nas wytracić, wymordować i zniszczyć. Gdyby nas sprzedano tylko jako niewolników i niewolnice, milczałabym. A tak nigdy nie wynagrodzi ciemiężyciel szkody królowi***».
###### **Est 7,5**
 Na to odpowiedział król Aswerus i rzekł królowej Esterze: «***Któż jest ten, który zawziął się w sercu swoim, aby to uczynić, i gdzie on jest?***»
###### **Est 7,6**
 I odpowiedziała Estera: «***Tym przeciwnikiem i wrogiem jest Haman, ten niegodziwiec***». Zatrwożył się Haman wobec króla i królowej.
###### **Est 7,7**
 Król zaś w gniewie swoim wstał od picia wina i [poszedł] do pałacowego ogrodu. Haman zaś stanął przed królową Esterą, aby prosić o życie swoje, ponieważ dostrzegł, że król postanowił jego zgubę.
###### **Est 7,8**
 Potem król wrócił z pałacowego ogrodu do domu, gdzie pito wino, Haman zaś przypadł do łoża, na którym spoczywała Estera. A na to król rzekł: «***Czy jeszcze chcesz zgwałcić królową w mojej obecności, w moim domu?***» Słowo wyszło z ust króla, a twarz Hamana zakryto.
###### **Est 7,9**
 I rzekł Charbona, jeden z eunuchów, którzy pełnili służbę przy królu: «***Oto drzewo, które postawił Haman dla Mardocheusza, co radził dobrze królowi, stoi przed domem Hamana, wysokie na pięćdziesiąt łokci***». I rzekł król: «***Powieście go na nim!***»
###### **Est 7,10**
 I powieszono Hamana na drzewie, które przygotował Mardocheuszowi, a uspokoił się gniew króla.
# Est 7 PAU
###### **Est 7,1**
 Król i Haman udali się na ucztę do królowej.
###### **Est 7,2**
 W czasie uczty, drugiego dnia, król znowu zapytał Esterę: „Estero, królowo, czego pragniesz? O co prosisz? Dam ci nawet połowę mego królestwa!”.
###### **Est 7,3**
 Odpowiedziała mu: „Jeśli znalazłam łaskę u króla, to niech będzie darowane na moją prośbę moje własne życie, a na me życzenie - życie mego ludu.
###### **Est 7,4**
 Ja i mój lud zostaliśmy bowiem skazani na zagładę, grabież i niewolę. My i nasze dzieci staniemy się niewolnikami i niewolnicami. A przecież słyszałam, że oszczerca nie zasługuje na to, by przebywać na królewskim dziedzińcu”.
###### **Est 7,5**
 Wtedy król zapytał: „Kim jest ten, który ośmielił się uczynić coś takiego?”.
###### **Est 7,6**
 Estera odrzekła: „Tym nieprzyjaznym człowiekiem jest Haman. On jest tym niegodziwcem!”. Haman zląkł się króla i królowej.
###### **Est 7,7**
 Król wstał od stołu i wyszedł do ogrodu, a Haman błagał królową, gdyż zrozumiał, że jego sytuacja jest bardzo zła.
###### **Est 7,8**
 Gdy król wrócił z ogrodu, zastał Hamana leżącego na posłaniu i usilnie błagającego królową. Król zapytał: „Czyżbyś chciał jeszcze w moim domu zadać gwałt kobiecie?”. Haman zmieszał się na te słowa.
###### **Est 7,9**
 A Bugatan, jeden z eunuchów, powiedział królowi: „Oto Haman przygotował szubienicę dla Mardocheusza, dla tego, który złożył doniesienie w sprawach królestwa! Oto przed domem Hamana postawiono szubienicę wysoką na pięćdziesiąt łokci”. Król rzekł: „Niech zostanie na niej powieszony”.
###### **Est 7,10**
 Haman został powieszony na szubienicy, którą przygotował dla Mardocheusza. Wtedy ustał gniew króla.
# Est 7 BP
###### **Est 7,1**
 Król i Haman przybyli, aby ucztować u królowej Estery.
###### **Est 7,2**
 Także i drugiego dnia rzekł król do Estery, pijąc wino: Jaką masz prośbę, królowo Estero? Będzie spełniona. Jakie jest twoje życzenie? Choćbyś prosiła o połowę królestwa, stanie się to.
###### **Est 7,3**
 Wówczas odpowiedziała królowa Estera tymi słowy: Jeżelim naprawdę znalazła łaskę w oczach twoich, o królu, i jeżeli to wyda ci się słuszne, daruj mi życie. Oto moja prośba. Daruj je także ludowi memu. Oto moje życzenie.
###### **Est 7,4**
 Albowiem sprzedano nas, mnie i lud mój, aby nas zniszczyć, wymordować i wytracić. Gdybyśmy przynajmniej zostali sprzedani jak niewolnicy i niewolnice, milczałabym, chociaż wróg nie mógłby nigdy wynagrodzić szkody wyrządzonej królowi.
###### **Est 7,5**
 Zabierając głos zapytał król Achaszwerosz królową Esterę: Któż to jest i gdzież jest ten, którego serce wypełniają takie zamierzenia?
###### **Est 7,6**
 Odpowiedziała Estera: Tym wrogiem i przeciwnikiem jest niecny Haman! Hamana ogarnęło przerażenie w obliczu króla i królowej.
###### **Est 7,7**
 Uniesiony wielkim gniewem powstał król i opuszczając ucztę udał się do ogrodu pałacowego. Haman powstał także, by błagać królową Esterę o życie; zrozumiał bowiem, że ze strony króla zguba jego była przesądzona.
###### **Est 7,8**
 Gdy król powrócił z ogrodu do sali, gdzie się odbywała uczta, ujrzał, że Haman osunął się na łoże, na którym spoczywała Estera. Cóż to! - Zawołał król. - Czyż chce on jeszcze i gwałtu dokonać na królowej przy mnie i w moim domu? Zaledwie słowa te wyszły z ust królewskich, zarzucono zasłonę na twarz Hamana.
###### **Est 7,9**
 Charbona, jeden z eunuchów, pozostających na służbie u króla, rzekł: Oto szubienica, przygotowana przez Hamana dla Mardocheusza, który dobro królewskie miał na oku, stoi już przed domem Hamana, wysoka na pięćdziesiąt łokci. Rzekł król: Powieście go na niej!
###### **Est 7,10**
 I powieszono Hamana na owej szubienicy, którą przygotował dla Mardocheusza. I uciszył się gniew królewski.
# Est 7 BR
###### **Est 7,1**
 Kiedy król przybył razem z Hamanem na ucztę przygotowaną przez królową Esterę
###### **Est 7,2**
 i również drugiego dnia siedzieli wspólnie przy winie, zapytał król Esterę: Czy masz jakieś życzenie, królowo Estero? Każda twoja prośba zostanie spełniona. Powiedz tylko, czego pragniesz. Gdybyś zażądała nawet połowy mojego królestwa, uczynię zadość twojej prośbie.
###### **Est 7,3**
 Odpowiedziała na to królowa Estera: Jeśli znalazłam łaskę u króla i jeśli jest dla mnie tak dobry, to niech raczy darować życie mnie i mojemu narodowi. Taka jest moja prośba i moje największe pragnienie.
###### **Est 7,4**
 Zaprzedano mnie i mój lud po to, żeby nas zgładzić, wymordować, wyniszczyć bez reszty. Gdyby nas sprzedano jako niewolników i niewolnice, nie mówiłabym nic. Ale i tak nieprzyjaciel nasz nie będzie w stanie naprawić zła, jakie przez to wyrządza królowi.
###### **Est 7,5**
 Zapytał tedy król Aswerus królowej Estery: A któż to jest? Kim jest człowiek, który odważa się uczynić coś takiego i gdzie on jest?
###### **Est 7,6**
 Estera zaś odpowiedziała: Tym niebezpiecznym wrogiem jest obecny tu Haman. Hamana zaś ogarnęło przerażenie wobec króla i królowej.
###### **Est 7,7**
 A król powstał natychmiast z miejsca, pełen gniewu, opuścił stół biesiadny i wyszedł do ogrodu pałacowego. Haman zaś przystąpił do Estery i zaczął ją błagać o darowanie życia. Widział bowiem wyraźnie, że król postanowił już jego zgubę.
###### **Est 7,8**
 Kiedy król wrócił po pewnym czasie z ogrodu na miejsce uczty, Haman rzucił się na łoże, na którym odpoczywała Estera. Wówczas król powiedział: Tak więc tu, w mojej obecności dopuszczasz się gwałtu na królowej? Zaledwie król to powiedział, natychmiast zakryto Hamanowi twarz.
###### **Est 7,9**
 A Charbona, jeden z eunuchów królewskich, powiedział do króla: Przed domem Hamana stoi już szubienica wysoka na pięćdziesiąt łokci. Zbudował ją Haman dla Mardocheusza, który nadesłaniem wiadomości wyświadczył królowi wielkie dobrodziejstwo. Rozkazał tedy król: Powiesić na niej Hamana.
###### **Est 7,10**
 Powieszono tedy Hamana na szubienicy, którą on kazał zbudować dla Mardocheusza. Dopiero wtedy ochłonął król z gniewu.
# Est 7 WUJ
###### **Est 7,1**
 A tak wszedł król i Aman, aby pili z królową,
###### **Est 7,2**
 I rzekł jej król toż drugiego dnia, gdy się był winem zagrzał. Cóż jest za prośba twoja Esther, abyć była dana? i co chcesz, aby się stało? Abyś też prosiła pół królestwa mego, uprosisz.
###### **Est 7,3**
 Któremu ona odpowiedziała: Jeśliżem nalazła łaskę w oczach twoich o królu, i jeślić się podoba, daruj mię duszą moją, o którą proszę, i ludem moim, za którym się przyczyniam.
###### **Est 7,4**
 Abowiem wydani jesteśmy ja i lud mój, abyśmy byli skruszeni, wybici i abyśmy zginęli. A daj Boże, abyśmy byli zaprzedani za niewolniki i za niewolnice: znośne by złe było, i milczałabym wzdychając, a teraz nieprzyjaciel nasz jest, którego okrucieństwa ściąga się na króla.
###### **Est 7,5**
 A odpowiadając król Asswerus rzekł: Któż to jest, i jakiej mocy, żeby to śmiał czynić?
###### **Est 7,6**
 I rzekła Esther: Sprzeciwnik i nieprzyjaciel nasz niecnotliwy ten jest Aman. Co on usłyszawszy zaraz się zdumiał, królewskiej twarzy i królowej nie mogąc znosić.
###### **Est 7,7**
 A król rozgniewawszy się wstał i z miejsca uczty, i szedł do ogroda drzewy osadzonego. Aman też wstał, aby prosił Esther królowej o duszę swoję, bo zrozumiał, że mu nieszczęście od króla zgotowane było.
###### **Est 7,8**
 Który gdy się wrócił z ogroda gajmi osadzonego, i wszedł na miejsce uczty, nalazł Aman, a on upadł na łóżko, na którem leżała Esther, i rzekł: i królową chce zgwałcić przy mnie w domu moim! Jeszcze wyszło było słowo z ust królewskich, a wnet zakryli twarz jego.
###### **Est 7,9**
 I rzekł Harbona jeden z rzezańców, którzy stali na służbie królewskiej. Oto drzewo, które był nagotował Mardocheuszowi, który mówił za królem, stoi w domu Amanowym, mające wzwyż pięćdziesiąt łokiet. Któremu król rzekł: Obieście go na nim,
###### **Est 7,10**
 Obieszono tedy Amana na szubienicy, którą był gotował Mardocheuszowi, i uspokoił się gniew królewski.
