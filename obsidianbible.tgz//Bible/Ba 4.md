# Ba 4 BT5
###### **Ba 4,1**
 Tą mądrością jest księga przykazań Boga i Prawo trwające na wieki. Wszyscy, którzy się go trzymają, żyć będą. Którzy je zaniedbują, pomrą.
###### **Ba 4,2**
 Nawróć się, Jakubie, trzymaj się go, chodź w blasku jego światła!
###### **Ba 4,3**
 Nie dawaj chwały swojej obcemu ani innemu narodowi twych przywilejów!
###### **Ba 4,4**
 Szczęśliwi jesteśmy, o Izraelu, że znane nam to, co się Bogu podoba.
###### **Ba 4,5**
 Bądź dobrej myśli, narodzie mój, pamiątko Izraela!
###### **Ba 4,6**
 Zostaliście zaprzedani poganom, ale nie na zatracenie; dlatego zostaliście wydani nieprzyjaciołom, iż pobudziliście Boga do gniewu.
###### **Ba 4,7**
 Rozgniewaliście bowiem Stworzyciela swego ofiarami składanymi złym duchom, a nie Bogu.
###### **Ba 4,8**
 Zapomnieliście o waszym Żywicielu, Bogu wiekuistym, zasmuciliście też Jerozolimę, która was wychowała.
###### **Ba 4,9**
 Widziała bowiem przychodzący na was gniew Boży i rzekła: «***Słuchajcie, sąsiedzi Syjonu, Bóg zasmucił mnie bardzo,***
###### **Ba 4,10**
 ***widzę bowiem niewolę moich synów i córek, jaką im zesłał Przedwieczny.***
###### **Ba 4,11**
 ***Wyżywiłam ich z radością, a odesłałam z płaczem i smutkiem.***
###### **Ba 4,12**
 ***Niech nikt się nie śmieje, żem wdowa i opuszczona przez wielu. Zostałam opuszczona z powodu grzechów dzieci moich, ponieważ wyłamały się spod prawa Bożego.***
###### **Ba 4,13**
 ***Nie uznały słusznych rozporządzeń Twoich ani nie kroczyły drogami przykazań Bożych, ani nie weszły na ścieżki wychowania w Twojej sprawiedliwości.***
###### **Ba 4,14**
 ***Przyjdźcie, sąsiedzi Syjonu! Przypomnijcie sobie niewolę moich synów i córek, jaką im zesłał Przedwieczny.***
###### **Ba 4,15**
 ***Sprowadził na nich naród z daleka, naród bezczelny, obcego języka, który nie uszanował starca ani nie ulitował się nad dzieckiem.***
###### **Ba 4,16**
 ***Uprowadził umiłowanych Wdowy i pozbawił córek Opuszczoną.***
###### **Ba 4,17**
 ***Ja zaś jak wam mogę pomóc?***
###### **Ba 4,18**
 ***Ten, który zesłał na was to zło, wybawi was z rąk nieprzyjaciół.***
###### **Ba 4,19**
 ***Idźcie, dzieci, idźcie, ja zaś sama i opuszczona zostać muszę.***
###### **Ba 4,20**
 ***Zdjęłam szatę pokoju, a przyoblekłam się w wór do mojej modlitwy błagalnej i za dni moich wołać będę do Przedwiecznego.***
###### **Ba 4,21**
 ***Miejcie ufność, dzieci, wołajcie do Boga, a wyrwie was z mocy, z ręki nieprzyjaciół.***
###### **Ba 4,22**
 ***Ja zaś z ufnością powierzyłam Przedwiecznemu wybawienie wasze i rozradował mnie Święty miłosierdziem, jakie okaże wam prędko Przedwieczny, wasz Zbawca.***
###### **Ba 4,23**
 ***Wysłałam was ze smutkiem i płaczem, a Bóg odda mi was z radością i weselem na wieki.***
###### **Ba 4,24**
 ***Jak bowiem teraz sąsiedzi Syjonu widzieli wasze wygnanie, tak oglądać będą wasze od Boga zbawienie, które zstąpi na was z wielką chwałą i okazałością Przedwiecznego.***
###### **Ba 4,25**
 ***Dzieci, cierpliwie znoście gniew, jaki Bóg zesłał na was. Prześladuje cię twój nieprzyjaciel, ale wnet ujrzysz jego zagładę i staniesz na jego karku.***
###### **Ba 4,26**
 ***Delikatne moje dzieci szły drogami przykrymi, zostały uprowadzone jak stado zagrabione przez nieprzyjaciół.***
###### **Ba 4,27**
 ***Ufajcie, dzieci, wołajcie do Boga, a Ten, który dopuścił to na was, będzie o was pamiętał.***
###### **Ba 4,28**
 ***Jak bowiem, błądząc, myśleliście o odstąpieniu od Boga, tak teraz, nawróciwszy się, szukajcie Go dziesięciokrotnie.***
###### **Ba 4,29**
 ***Albowiem Ten, który zesłał na was to zło, przywiedzie radość wieczną wraz z wybawieniem waszym***».
###### **Ba 4,30**
 Nie upadaj na duchu, Jeruzalem, pocieszy cię Ten, który ci nadał imię.
###### **Ba 4,31**
 Biada tym, którzy cię skrzywdzili i cieszą się z twego nieszczęścia.
###### **Ba 4,32**
 Biada tym miastom, którym służą twe dzieci, biada temu, które przyjęło twych synów.
###### **Ba 4,33**
 Jak bowiem cieszyło się twoim zniszczeniem i radowało się twoim upadkiem, tak będzie zasmucone własnym spustoszeniem.
###### **Ba 4,34**
 Odbiorę mu radość z wielkiej liczby mieszkańców, a pycha jego przemieni się w smutek.
###### **Ba 4,35**
 Albowiem Przedwieczny ześle na nie ogień przez wiele dni i długi czas złe duchy zamieszkiwać w nim będą.
###### **Ba 4,36**
 Jerozolimo, spojrzyj na wschód i zobacz radość, która ci przychodzi od Pana.
###### **Ba 4,37**
 Oto idą synowie twoi, których wysłałaś, idą, zgromadzeni ze wschodu i zachodu na słowo Świętego, ciesząc się chwałą Boga.

# Ba 4 PAU
###### **Ba 4,1**
 To ona jest księgą przykazań Boga i Prawem trwającym na wieki. Wszyscy, którzy się jej trzymają, będą żyć, a ci, którzy ją porzucają - wyginą.
###### **Ba 4,2**
 Nawróć się, Jakubie, i pojmij ją, postępuj w blasku jej światła!
###### **Ba 4,3**
 Nie oddawaj swej chwały obcemu ani twego przywileju innemu ludowi!
###### **Ba 4,4**
 O Izraelu, jakże jesteśmy szczęśliwi, gdyż dano nam poznać, co się Bogu podoba!
###### **Ba 4,5**
 Odwagi, narodzie mój, pamiątko Izraela!
###### **Ba 4,6**
 Zostaliście sprzedani poganom, ale nie na zgubę. Zostaliście wydani nieprzyjaciołom, gdyż wywołaliście gniew Boga.
###### **Ba 4,7**
 Rozgniewaliście bowiem swego Stworzyciela, składając ofiary demonom, a nie Bogu.
###### **Ba 4,8**
 Zapomnieliście waszego żywiciela, Boga wiecznego, i zasmuciliście waszą nauczycielkę, Jeruzalem.
###### **Ba 4,9**
 Dostrzegła bowiem przychodzący na was gniew Boży i rzekła: „Słuchajcie, sąsiadki Syjonu! Bóg napełnił mnie wielkim smutkiem,
###### **Ba 4,10**
 gdyż ujrzałam niewolę mych synów i córek, jaką na nich sprowadził Przedwieczny.
###### **Ba 4,11**
 Karmiłam ich bowiem z radością, a odsyłałam z płaczem i smutkiem.
###### **Ba 4,12**
 Niech nikt się nie śmieje z tego, że jestem wdową, opuszczoną przez wszystkich! Zostałam sama z powodu grzechów mych dzieci, ponieważ odwróciły się od Prawa Bożego.
###### **Ba 4,13**
 Nie uznały Jego prawych rozporządzeń, nie postępowały drogami Bożych przykazań ani nie weszły na ścieżki Jego sprawiedliwych pouczeń.
###### **Ba 4,14**
 Przyjdźcie, sąsiadki Syjonu! Przypomnijcie sobie niewolę moich synów i córek, jaką na nich sprowadził Przedwieczny.
###### **Ba 4,15**
 Bo wysłał przeciw nim naród daleki, naród bezwstydny i mówiący nieznanym językiem, który starca nie uszanował ani dziecku nie okazał litości.
###### **Ba 4,16**
 Oni to uprowadzili ulubieńców Wdowy i Opuszczoną pozbawili córek.
###### **Ba 4,17**
 Ja zaś w jaki sposób mogę wam pomóc?
###### **Ba 4,18**
 Tylko Ten, który sprowadził na was to nieszczęście, może was wybawić z rąk nieprzyjaciół.
###### **Ba 4,19**
 Idźcie, dzieci, idźcie, a ja sama i opuszczona zostanę!
###### **Ba 4,20**
 Zdjęłam szatę wesela, włożyłam wór pokutny; wołać będę do Przedwiecznego przez całe życie.
###### **Ba 4,21**
 Odwagi, dzieci, wołajcie do Boga, a On wyrwie was z rąk nieprzyjaciół!
###### **Ba 4,22**
 Przedwiecznemu powierzyłam wasze wybawienie i już spłynęła na mnie radość od Świętego, bo wkrótce doznacie miłosierdzia od Przedwiecznego, waszego Wybawcy.
###### **Ba 4,23**
 Wysłałam was wśród smutku i płaczu, Bóg mi was zwróci na zawsze z radością i weselem.
###### **Ba 4,24**
 Jak bowiem teraz sąsiadki Syjonu widzą wasze wygnanie, tak wkrótce ujrzą wasze zbawienie, dokonane przez Boga. Przyjdzie ono w wielkiej chwale i blasku Przedwiecznego.
###### **Ba 4,25**
 Dzieci, cierpliwie znoście gniew Boży! Prześladował cię twój nieprzyjaciel, lecz wkrótce ujrzysz jego zagładę i postawisz stopę na jego karku.
###### **Ba 4,26**
 Moje dzieci, tak wypieszczone, musiały iść po kamienistych drogach jak stado bezlitośnie uprowadzone przez wrogów.
###### **Ba 4,27**
 Dzieci, miejcie odwagę i wołajcie do Boga! Wspomni o was Ten, który pozwolił was uprowadzić.
###### **Ba 4,28**
 Jak bowiem byliście bliscy odejścia od Boga, tak nawróciwszy się, szukajcie Go z dziesięciokrotnie większą żarliwością.
###### **Ba 4,29**
 Ten, który zesłał na was te nieszczęścia, wraz ze zbawieniem da wam wieczną radość”.
###### **Ba 4,30**
 Jeruzalem, nie trać odwagi! Pocieszy cię Ten, który dał ci imię!
###### **Ba 4,31**
 Biada tym, którzy cię skrzywdzili i którzy się cieszą z twojego upadku.
###### **Ba 4,32**
 Biada miastom, którym służyły twe dzieci. Biada miastu, które zabrało twych synów.
###### **Ba 4,33**
 Jak bowiem cieszyło się twoim upadkiem i radowało się twoim zniszczeniem, tak się zasmuci własnym spustoszeniem.
###### **Ba 4,34**
 Pozbawię go licznych jego mieszkańców, a jego radość przemienię w smutek.
###### **Ba 4,35**
 Przez wiele dni Przedwieczny będzie zsyłał na nie ogień, przez długi czas będą je zamieszkiwać demony.
###### **Ba 4,36**
 Spójrz ku wschodowi, Jeruzalem, i zobacz radość przychodzącą od Boga!
###### **Ba 4,37**
 Oto nadchodzą twoi synowie, których niegdyś odprawiłaś, przybywają ze wschodu i zachodu, gromadzą się na słowo Świętego, ciesząc się chwałą Boga.
# Ba 4 BP
###### **Ba 4,1**
 Oto księga Bożych przykazań i Prawo trwające na wieki. Wszyscy, co się jej trzymają, żyć będą, giną ci, którzy od niej odchodzą.
###### **Ba 4,2**
 Nawróć się, Jakubie, i obejmij ją! Postępuj w blasku jej światłości.
###### **Ba 4,3**
 Nie odstępuj swej chwały innemu ani swych przywilejów obcemu narodowi.
###### **Ba 4,4**
 Szczęśliwi jesteśmy, o Izraelu, gdyż to poznaliśmy, co Bogu się podoba!
###### **Ba 4,5**
 Miej ufność, mój ludu! Ty jesteś pamiątką Izraela!
###### **Ba 4,6**
 Nie na zagładę zostaliście zaprzedani poganom, ale zostaliście wydani wrogom, boście Boga przywiedli do gniewu.
###### **Ba 4,7**
 Albowiem pobudziliście do gniewu waszego Stworzyciela, składając ofiary demonom, a nie Bogu.
###### **Ba 4,8**
 Zapomnieliście o Tym, który was żywił, o wiecznym Bogu! Zasmuciliście tę, co was wychowała - Jeruzalem!
###### **Ba 4,9**
 (Widziała bowiem gniew Boży spadający na was i rzekła:) Słuchajcie, sąsiadki Syjonu, Bóg zesłał na mnie wielką żałobę.
###### **Ba 4,10**
 Widziałam uprowadzenie mych synów i córek, które Odwieczny zesłał na nich.
###### **Ba 4,11**
 Wyżywiłam ich w radości, a wśród łez i w żałobie patrzyłam na ich odejście.
###### **Ba 4,12**
 Niech się nikt nie raduje, żem wdowa i od wielu opuszczona! Pustkowiem stałam się z powodu grzechów mych dzieci, odstąpiły bowiem od Bożego Prawa;
###### **Ba 4,13**
 nakazów Jego nie chciały poznać, nie kroczyły drogą Bożych przykazań i nie wstąpiły na ścieżki, wiodące do przyjęcia Jego sprawiedliwości.
###### **Ba 4,14**
 Niech przyjdą sąsiadki Syjonu! Wspomnijcie na wygnanie mych synów i córek, które Odwieczny na nich zesłał.
###### **Ba 4,15**
 Oto bowiem sprowadził na nich lud z daleka, lud okrutny, mówiący barbarzyńskim językiem, który nie miał szacunku dla starca ani zmiłowania nad dzieckiem.
###### **Ba 4,16**
 I uprowadził umiłowanych wdowy, a mnie zostawił samą, pozbawioną mych córek.
###### **Ba 4,17**
 I jakżeż ja mogę wam pomóc?
###### **Ba 4,18**
 Ten jednak, który sprowadził na was te nieszczęścia, wyzwoli was z rąk waszych wrogów.
###### **Ba 4,19**
 Idźcie [moje] dzieci, idźcie, ja zaś pozostaję samotna!
###### **Ba 4,20**
 Zdjęłam szaty szczęśliwości, a przyoblekłam się w wór modlitwy. Będę głośno wołać do Odwiecznego przez wszystkie dni mego życia.
###### **Ba 4,21**
 Odwagi, dzieci moje, wzywajcie Pana, On zaś wyrwie was z przemocy i z ręki nieprzyjaciół.
###### **Ba 4,22**
 Ufam bowiem, że w Odwiecznym jest wasze wybawienie; zstąpi na mnie radość od Świętego z powodu miłosierdzia, jakie okaże wam wkrótce Odwieczny, wasz Wybawiciel.
###### **Ba 4,23**
 W żałobie i we łzach patrzyłam na wasze odejście, lecz Bóg zwróci mi was w radości i weselu na wieki.
###### **Ba 4,24**
 Bo jak sąsiadki Syjonu oglądały wasze wygnanie, tak też ujrzą wnet wasze wybawienie przez Boga, którego dostąpicie w wielkiej chwale i majestacie Odwiecznego.
###### **Ba 4,25**
 Dzieci [moje], znoście cierpliwie gniew zesłany wam przez Boga! Ciemiężył cię twój nieprzyjaciel, lecz wkrótce ujrzysz jego zagładę i postawisz nogę na ich karkach.
###### **Ba 4,26**
 Moje wypieszczone dzieci musiały kroczyć po kamienistych drogach, zagnane jak stado owiec, porwane przez wroga.
###### **Ba 4,27**
 Miejcie ufność, dzieci moje! Wołajcie do Boga! Ten bowiem, który zesłał na was [nieszczęście], będzie o was pamiętał.
###### **Ba 4,28**
 Jak niegdyś błądząc skłaniałyście się ku odstępstwu od Boga, tak nawrócone okażecie dziesięciokrotnie większą żarliwość, aby Go odszukać.
###### **Ba 4,29**
 Ten bowiem, który zesłał na was te nieszczęścia, wybawiając obdarzy was wieczystą radością.
###### **Ba 4,30**
 Miej ufność, Jeruzalem! Ten, który ci dał imię, pocieszy cię.
###### **Ba 4,31**
 Biada tym, którzy cię ciemiężyli i radowali się z twego upadku!
###### **Ba 4,32**
 Biada miastom, w których twe dzieci były w niewoli! Biada temu [miastu], które miało u siebie twych synów.
###### **Ba 4,33**
 Podobnie bowiem jak ono radowało się z twojej zguby i weseliło się z twego upadku, tak też i boleć będzie nad własnym spustoszeniem.
###### **Ba 4,34**
 Odejmę mu radość z wielkiego mnóstwa jego mieszkańców, a pycha jego zamieni się w żałobę.
###### **Ba 4,35**
 Ogień, zesłany od Odwiecznego, spadnie na nie na dni wiele i na długo zamieszkają w nim złe duchy.
###### **Ba 4,36**
 Spójrz ku Wschodowi, Jeruzalem! Oglądaj radość, którą ci Bóg zsyła!
###### **Ba 4,37**
 Oto wracają twoi synowie, na których odejście patrzyłoś, wracają zgromadzeni od Wschodu do Zachodu mocą słowa Świętego, radując się z chwały Boga.
# Ba 4 BR
###### **Ba 4,1**
 Mądrość ta - to księga przykazań Bożych, to także Prawo trwające na wieki. Wszyscy, którzy je zachowują, mają życie, ci zaś, którzy go nie zachowują, giną.
###### **Ba 4,2**
 Nawróć się więc, Jakubie, i trzymaj się tego Prawa! Idź drogą twego życia w jego blasku!
###### **Ba 4,3**
 Chwały swojej nie odstępuj żadnemu obcemu ludowi!
###### **Ba 4,4**
 Szczęśliwi jesteśmy, o ludu Izraela, bo wiemy, co podoba się Bogu.
###### **Ba 4,5**
 Ludu mój, nie trać nadziei, bo ty przecież nosisz imię Izraela.
###### **Ba 4,6**
 Zostaliście, co prawda, zaprzedani w niewolę innym narodom, ale przecież nie po to, żeby zginąć. Zostaliście wydani w ręce wrogów dlatego, że rozgniewaliście Boga waszego.
###### **Ba 4,7**
 Bo rzeczywiście doprowadziliście do gniewu waszego Stwórcę, składając wasze ofiary demonom, a nie Bogu.
###### **Ba 4,8**
 Zapomnieliście o Tym, który was żywił, o wiekuistym Bogu. Smutek sprowadziliście na Jerozolimę, która was wychowała.
###### **Ba 4,9**
 Ona była świadkiem, jak spadał na was gniew Boży. Wtedy też powiedziała: Posłuchajcie, wy wszyscy, co sąsiadujecie z Syjonem: Bóg zesłał na mnie wielkie cierpienie.
###### **Ba 4,10**
 Oto musiałam patrzeć, jak moi synowie i córki byli stąd uprowadzani, zgodnie z tym, co im Przedwieczny zapowiedział.
###### **Ba 4,11**
 Z radością wychowywałam ich kiedyś, a potem musiałam patrzeć, wśród łez i narzekania, jak ich uprowadzano.
###### **Ba 4,12**
 Niech nikt się nie cieszy, że zostałam wdową i że mnie opuścili wszyscy. Z powodu grzechów moich dzieci spotkało mnie to osamotnienie. Odeszły bowiem daleko od Prawa Bożego.
###### **Ba 4,13**
 Nie chciały uznać Jego postanowień i nie poszły drogą przykazań Bożych. Nie trzymały się ścieżek Jego sprawiedliwych pouczeń, choć je do tego zachęcał.
###### **Ba 4,14**
 Przyjdźcie, wy wszyscy, co sąsiadujecie z Syjonem! Pomyślcie o niewoli, jaką Przedwieczny zgotował moim synom i córkom.
###### **Ba 4,15**
 Dopuścił, by naród z daleka spadł na nich, naród mówiący obcym językiem, nie mający względu dla starców ani litości dla dzieci.
###### **Ba 4,16**
 Uprowadził daleko z kraju umiłowanych wdowy i opuszczoną pozbawił córek.
###### **Ba 4,17**
 Ja sama, jak mogę wam dopomóc?
###### **Ba 4,18**
 Tylko Ten, który sprowadził na was wszystkie owe nieszczęścia, tylko On może was wybawić z rąk waszych wrogów.
###### **Ba 4,19**
 Tak więc idźcie, moje dzieci, idźcie, a ja sama tu muszę pozostać.
###### **Ba 4,20**
 Zdjęłam z siebie szaty z dni radosnych i przyodziałam się w wór pokutny z czasów mojego ucisku. Wołać będę do Wiekuistego przez wszystkie dni mojego życia.
###### **Ba 4,21**
 Nie upadajcie na duchu, moje dzieci, wołajcie głośno do Boga! On tylko wyrwie was spod przemocy i z rąk wrogów.
###### **Ba 4,22**
 Zawierzyłam Wiekuistemu sprawę waszego wybawienia. I już doznałam od Świętego radości z powodu miłosierdzia, które i do was dojdzie wkrótce od Wiekuistego, Wybawcy waszego.
###### **Ba 4,23**
 Ze smutkiem i we łzach patrzyłam, jak was uprowadzano, ale odda mi was Bóg z powrotem, ku radości i weselu mojemu na zawsze.
###### **Ba 4,24**
 I jak obecnie wszyscy sąsiadujący z Syjonem patrzą na wasze uwięzienie, tak wkrótce już będą oglądać wybawienie, przychodzące od Boga waszego. Przyjdzie ono do was we wspaniałości wielkiej i w chwale Wiekuistego.
###### **Ba 4,25**
 Dzieci moje, znoście cierpliwie zagniewanie Boże! Teraz jeszcze wróg cię prześladuje, ale już niedługo będziesz oglądał jego koniec i własną stopę postawisz na jego karku.
###### **Ba 4,26**
 Moje tak wypielęgnowane dzieci musiały chodzić przykrymi drogami, uprowadzone jak stado zagarnięte przez wrogów.
###### **Ba 4,27**
 Nie traćcie nadziei, moje dzieci, lecz wołajcie głośno do Boga! Ten bowiem, który zesłał na was to wszystko, On znowu na was wejrzy.
###### **Ba 4,28**
 Jak kiedyś błądząc myśleliście o odejściu od Boga, tak teraz z gorliwością dziesięć razy większą poszukiwać Boga będziecie, aby do Niego powrócić.
###### **Ba 4,29**
 Ten, który sprowadził na was wszystkie te nieszczęścia, ześle na was nigdy nieprzemijającą radość przez to, że was uratuje.
###### **Ba 4,30**
 Jerozolimo, ty też nie trać ducha! Ten, który ci nadał imię, ześle ci też pocieszenie.
###### **Ba 4,31**
 Nieszczęście zaś spotka każdego, kto ci źle czynił, albo radował się z upadku twojego.
###### **Ba 4,32**
 Nieszczęście niech spadnie na miasta, w których dzieci twoje jako niewolnicy zostają, biada temu miastu, które już jako niewolników przyjęło waszych synów!
###### **Ba 4,33**
 Jak cieszyło się ono kiedyś z powodu twojego upadku i radowało się z twego zniszczenia, tak teraz będzie się musiało smucić patrząc na swoje własne spustoszenie.
###### **Ba 4,34**
 Przestaną się cieszyć wielkimi rzeszami ludzi, a ich przechwalanie zamieni się w lament.
###### **Ba 4,35**
 Odwieczny bowiem ześle na nich ogień, który będzie płonął przez dni wiele, a demony osiedlą się wśród nich na czas dłuższy.
###### **Ba 4,36**
 Jerozolimo, popatrz na wschód! Zobacz radość, jaka dla ciebie nadchodzi od Boga!
###### **Ba 4,37**
 Popatrz na twoich synów, których uprowadzono ongiś na twoich oczach! Oto teraz wracają do siebie. Ciągną od wschodu do zachodu słońca, zebrani razem słowem Świętego. Wszyscy radują się wspaniałością Pana.
# Ba 4 WUJ
