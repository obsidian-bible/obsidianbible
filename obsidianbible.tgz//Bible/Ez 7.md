# Ez 7 BT5
###### **Ez 7,1**
 Pan skierował do mnie to słowo:
###### **Ez 7,2**
 «***Ty zaś, synu człowieczy, powiedz: Tak mówi Pan Bóg do ziemi izraelskiej: Koniec, koniec nadchodzi dla czterech krańców ziemi.***
###### **Ez 7,3**
 ***Teraz przychodzi kres na ciebie. Wysyłam gniew mój przeciwko tobie, aby cię osądzić według twoich dróg i ciebie uczynić odpowiedzialną za wszystkie twoje obrzydliwości.***
###### **Ez 7,4**
 ***Oko moje nie okaże litości dla ciebie i nie ominę cię, ale ciebie uczynię odpowiedzialną za twoje drogi, a twoje obrzydliwości będą pośród ciebie [ujawnione], i poznacie, że Ja jestem Pan***».
###### **Ez 7,5**
 Tak mówi Pan Bóg: «***Oto nadchodzi jedno nieszczęście za drugim.***
###### **Ez 7,6**
 ***Koniec nadszedł, nadszedł koniec dla ciebie, oto nadszedł.***
###### **Ez 7,7**
 ***Nadszedł dla ciebie zgubny los, o ty, mieszkańcu ziemi! Nadszedł czas, bliski jest dzień utrapienia, a nie radosnych pląsów na wzgórzach.***
###### **Ez 7,8**
 ***Teraz wyleję mój gniew na ciebie i moją zapalczywość uśmierzę na tobie. Będę cię sądził według twoich dróg, obciążając cię wszystkimi twymi obrzydliwościami.***
###### **Ez 7,9**
 ***Oko moje nie okaże litości, nie będę oszczędzał, ale według twojego postępowania otrzymasz odpłatę, a twoje obrzydliwości będą pośród ciebie [ujawnione] i poznacie, że Ja jestem Pan, który uderza.***
###### **Ez 7,10**
 ***Oto dzień, [już] nadchodzi; wypełnia się zgubny los, rozplenia się niesprawiedliwość, pycha się rozzuchwala.***
###### **Ez 7,11**
 ***Gwałt stał się berłem niesprawiedliwości. <Nic po nich nie pozostanie, nic z ich bogactwa, nic z ich krzyków, żaden ślad po ich wspaniałości.>***
###### **Ez 7,12**
 Nadchodzi czas, zbliża się ów dzień. Kupujący niech się nie cieszy, a sprzedawca niech się nie smuci, gniew bowiem zapłonął przeciwko wszystkim.
###### **Ez 7,13**
 ***Sprzedawca bowiem nie wróci już do rzeczy sprzedanej, nawet jeśli pozostanie jeszcze przy życiu, gdyż gniew nad ogółem nie ustanie i nikt z powodu swej niegodziwości nie będzie mógł ocalić życia.***
###### **Ez 7,14**
 ***Dmijcie w surmy, chwytajcie za broń, lecz nikt do boju nie ruszy; albowiem gniew mój obejmuje wszystko.***
###### **Ez 7,15**
 ***Miecz – na zewnątrz, a mór i głód – wewnątrz. Kto znajdzie się na polu, zginie od miecza, a tego, co w mieście pozostanie, głód i mór pochłoną.***
###### **Ez 7,16**
 ***Ci, którzy będą się ratowali ucieczką, na górach staną się podobni do gołębi z dolin. Wszyscy będą jęczeć, każdy z powodu swej niegodziwości.***
###### **Ez 7,17**
 ***Wszystkie ręce opadną i wszelkie kolano rozpłynie się jak woda.***
###### **Ez 7,18**
 ***Przywdzieją wory, okryje ich strach, na wszystkich twarzach pojawi się wstyd i na wszystkich głowach włosy [będą] zgolone.***
###### **Ez 7,19**
 ***Srebro swoje wyrzucą na ulice, a złoto ich upodobni się do nieczystości. <Ich srebro i złoto nie zbawi ich w dzień gniewu Pana. < Głodu swojego tym nie nasycą ani nie napełnią swych wnętrzności, ponieważ były dla nich pobudką do grzechu.***
###### **Ez 7,20**
 ***Ich drogocenna ozdoba posłużyła im ku pysze i z niej uczynili sobie swoje ohydne obrazy, swoje bożki. Dlatego zamienię je dla nich w nieczystość.***
###### **Ez 7,21**
 ***Wydam je w ręce cudzoziemców na łup, a miejscowym złoczyńcom na grabież, aby je zbezcześcili.***
###### **Ez 7,22**
 ***I odwrócę od nich oblicze moje, mój skarb zostanie zbezczeszczony. Wtargną do niego zbójcy, aby go zbezcześcić.***
###### **Ez 7,23**
 ***Zrób sobie kajdany, ponieważ kraj ten pełen jest krwawych wyroków, a miasto pełne gwałtów.***
###### **Ez 7,24**
 ***Sprowadzę najokrutniejsze narody, aby zajęły ich domy. Położę kres pysze możnych, a świętości ich zostaną zbezczeszczone.***
###### **Ez 7,25**
 ***Nadchodzi groza. Będą szukać ratunku, a nie znajdą go.***
###### **Ez 7,26**
 ***Klęska za klęską spada, wieść okrutna nadchodzi jedna za drugą. Będą domagać się od proroka objawienia, lecz kapłanowi zabraknie nauki, a starszym rady.***
###### **Ez 7,27**
 ***Król pogrąży się w żałobie, księcia ogarnie trwoga, a ręce ludu ziemi drętwieć będą. Postąpię z nimi według ich dróg i na podstawie ich praw sądzić ich będę. I poznają, że Ja jestem Pan***».
# Ez 7 PAU
###### **Ez 7,1**
 PAN przemówił do mnie następującymi słowami:
###### **Ez 7,2**
 „Ty więc, synu człowieczy, głoś: Tak mówi PAN BÓG do ziemi izraelskiej. Nadszedł koniec. Koniec dla całego kraju.
###### **Ez 7,3**
 Teraz już koniec z tobą. Dosięgnie cię mój gniew. Będę cię sądził według twojego postępowania i ukażę ci wszystkie twoje obrzydliwości.
###### **Ez 7,4**
 Nie spojrzę ze współczuciem i nie przebaczę ci, lecz ukarzę cię sprawiedliwie za twoje postępowanie i za twoje obrzydliwości. I poznacie, że Ja jestem PANEM.
###### **Ez 7,5**
 Tak mówi PAN BÓG: Oto nadeszło zło. Jedno po drugim.
###### **Ez 7,6**
 Przyszedł koniec, nastąpił kres. Przebudził się przeciwko tobie. Oto nadszedł.
###### **Ez 7,7**
 Zły los przyszedł na tych, którzy mieszkają w tym kraju. Nadszedł czas. Blisko jest dzień klęski, a nie radosnych okrzyków na górach.
###### **Ez 7,8**
 Wkrótce wyleję na ciebie moje oburzenie i wyładuje się mój gniew na tobie. Osądzę cię według twojego postępowania i ukażę ci wszystkie twoje obrzydliwości.
###### **Ez 7,9**
 Nie spojrzę ze współczuciem i nie przebaczę ci, lecz ukarzę cię sprawiedliwie za twoje postępowanie i za twoje obrzydliwości. Wtedy przekonacie się, że Ja jestem PANEM, który karze.
###### **Ez 7,10**
 Oto ten dzień. Oto nadszedł. Zapanował zły los. Zakwitła kara. Wyrosła pycha.
###### **Ez 7,11**
 Ukazała się przemoc jak rózga nieprawości. Nikt się z nich nie ostoi. Na nic ich bogactwa. Niczym są ich okrzyki. Nie ma w nich piękna.
###### **Ez 7,12**
 Oto przyszedł ten czas. Nadszedł ten dzień. Kupujący niech się nie cieszy. Sprzedający niech się nie smuci, bo gniew dotyczy wszystkich.
###### **Ez 7,13**
 I gdyby sprzedający przeżył, nie odzyska rzeczy sprzedanej. Widzenie przeciwko nim wszystkim nie zmieni się i nikt z powodu swej nieprawości nie przeżyje.
###### **Ez 7,14**
 Zadęto w róg. Wszystko gotowe, a nikt nie ruszył na wojnę, gdyż mój gniew płonie przeciwko nim wszystkim.
###### **Ez 7,15**
 Miecz na zewnątrz, a zaraza i głód wewnątrz. Kto będzie na polu - zginie od miecza, a kto w mieście - zniszczy go głód i zaraza.
###### **Ez 7,16**
 Niewielu ich ocaleje i będą mieszkać wśród gór jak nizinne gołębie. Wszyscy będą wzdychać, każdy z powodu swojej nieprawości.
###### **Ez 7,17**
 Na wszystkich padnie blady strach, wszyscy będą mieć nogi jak z waty.
###### **Ez 7,18**
 Obleką się w wory. Ogarnie ich przerażenie. Wstyd na każdej twarzy, wszystkie głowy ogolone na znak żałoby.
###### **Ez 7,19**
 Swoje srebro porzucą na ulicach, ich złoto stanie się odrazą. Srebro i złoto nie zdoła ich ocalić w dniu gniewu PANA. Nie kupią za nie nawet jedzenia i swych brzuchów nie napełnią, bo były okazją do ich nieprawości.
###### **Ez 7,20**
 Wspaniałą ozdobę zamienili na przedmiot pychy, na swe obrzydliwe posągi. Zrobili z niej swoje ohydy, dlatego sprawię, że będzie ona w nich budzić odrazę.
###### **Ez 7,21**
 Wydam ją na pastwę cudzoziemców i bezbożnym tego kraju na łup. A oni ją zhańbią.
###### **Ez 7,22**
 Odwrócę się od nich. Mój skarbiec będzie zhańbiony. Złodzieje wejdą do niego i go zhańbią.
###### **Ez 7,23**
 Splądrowany będzie całkowicie, bo kraj pełen jest krwawych sądów, a miasto pełne przemocy.
###### **Ez 7,24**
 Sprowadzę najgorsze narody i zawładną ich domami. Sprawię, że ustanie pycha gwałtowników. Ich świątynie będą znieważone.
###### **Ez 7,25**
 Nadejdzie strach. Będą szukać pokoju, ale nadaremnie.
###### **Ez 7,26**
 Przyjdzie nieszczęście po nieszczęściu i trwoga za trwogą. Będą szukać widzenia u proroka. Kapłani przestaną nauczać, a starsi udzielać rady.
###### **Ez 7,27**
 Król będzie w żałobie. Książęta, ogarnięci trwogą, będą drżeć ze strachu. Postąpię z nimi stosownie do ich czynów i osądzę według ich sądów. I przekonają się, że Ja jestem PANEM”.
# Ez 7 BP
###### **Ez 7,1**
 Jahwe przemówił do mnie w te słowa:
###### **Ez 7,2**
 Ty tedy, synu człowieczy, [głoś]: Tak mówi Pan, Jahwe, ziemi izraelskiej: Nadszedł kres! Kres na cztery krańce kraju.
###### **Ez 7,3**
 Teraz koniec na ciebie. Spuszczę mój gniew na ciebie. Będę cię sądził według twojego postępowania i policzę ci wszystkie twe obrzydliwości.
###### **Ez 7,4**
 Oko moje nie spojrzy na ciebie z litością i nie zmiłuję się, bo twoje postępowanie obrócę przeciw tobie, a twoje obrzydliwości znajdą się pośród ciebie. I poznacie, że Ja jestem Jahwe.
###### **Ez 7,5**
 Tak mówi Pan, Jahwe: Oto nadchodzi nieszczęście, wyjątkowe nieszczęście.
###### **Ez 7,6**
 Nadszedł kres, przyszedł koniec. Przebudził się, [aby wystąpić] przeciw tobie. Oto nadchodzi.
###### **Ez 7,7**
 Mieszkańcy kraju, zły los przyszedł na ciebie. Nadszedł czas. Bliski jest dzień, [dzień] zamętu, a nie radosnych okrzyków w górach.
###### **Ez 7,8**
 Wkrótce już wyleję na ciebie moją złość i zaspokoję mój gniew na tobie. Będę cię sądził według twojego postępowania i policzę ci wszystkie twe obrzydliwości.
###### **Ez 7,9**
 Moje oko nie spojrzy z litością i nie zmiłuje się, bo twoje postępowanie obrócę przeciw tobie, a twoje obrzydliwości znajdą się pośród ciebie. I poznacie, że Ja jestem Jahwe, który karze.
###### **Ez 7,10**
 Oto dzień, oto nadchodzi. Wyruszył zły los, zakwitło bezprawie. Wyrosła zuchwałość.
###### **Ez 7,11**
 Powstała przemoc, by być rózgą nieprawości. Nikt się z nich nie ostoi. Nikt z tej rzeszy [ludzkiej], nic z ich bogactwa. Nie ma w nich wspaniałości.
###### **Ez 7,12**
 Nadszedł czas, przybliżył się dzień. Ten, kto nabywa, niech się nie raduje, a ten, kto sprzedaje, niech się nie smuci, gdyż gniew [ciąży] na całej jej rzeszy [izraelskiej].
###### **Ez 7,13**
 Albowiem ten, kto sprzedaje, nie wróci do tego, co zostało sprzedane, choćby jeszcze został żywy, albowiem widzenie dotyczące całej jej rzeszy nie będzie cofnięte i nikt, z powodu swej winy, nie zdoła zachować swego życia.
###### **Ez 7,14**
 Zagrajcie na trąbce! Wszystko jest gotowe, ale nie ma, kto by szedł na wojnę, gdyż gniew mój [zwrócił się] przeciw całej rzeszy [izraelskiej].
###### **Ez 7,15**
 Miecz na zewnątrz, a zaraza i głód wewnątrz. Kto znajdzie się na polu, polegnie od miecza, a kto będzie w mieście, tego wyniszczą głód i zaraza.
###### **Ez 7,16**
 Ujdą tylko ich niedobitki i będą [mieszkać] po górach, jak nizinne gołębie. Wszyscy będą wzdychać, każdy z powodu swej nieprawości.
###### **Ez 7,17**
 Wszystkie ręce omdleją. Wszystkie kolana zwiotczeją jak wóda.
###### **Ez 7,18**
 Obleką się w wory. Przerażenie ich ogarnie. Każda twarz okryje się wstydem. Na każdej ich głowie [pojawi się] łysina.
###### **Ez 7,19**
 Swoje srebro porzucą na ulicach, a ich złoto stanie się plugastwem. Srebro i złoto nie zdoła ich ocalić w dzień gniewu Jahwe. Nie nasycą nim swej duszy i swych wnętrzności nie napełnią, bo były okazją do ich nieprawości.
###### **Ez 7,20**
 Kosztowne ozdoby przerobili na [przedmioty] pychy, obrazy obrzydliwości. Ohydy z nich wykonali, dlatego obrócę je dla nich w plugastwo.
###### **Ez 7,21**
 Wydam je na grabież w ręce cudzoziemców i najniegodziwszym ziemi na łup. [Oni] je zbezczeszczą.
###### **Ez 7,22**
 Odwrócę od nich me oblicze i znieważę mój skarbiec. Grabieżcy dostaną się do niego i splugawią go.
###### **Ez 7,23**
 Urządzą rzeź, bo kraj pełen jest krwawych wyroków, a miasto pełne jest przemocy.
###### **Ez 7,24**
 Sprowadzę najsroższe ludy i zawładnę ich domami. Sprawię, że ustanie pycha gwałtowników, ich miejsca święte będą znieważone.
###### **Ez 7,25**
 Nadejdzie strach. Będą szukać pokoju, ale go nie będzie.
###### **Ez 7,26**
 Przyjdzie klęska po klęsce, wieść po wieści nadejdzie. Będą się domagać widzenia od proroka. Ustanie nauczanie kapłańskie i rada starszych.
###### **Ez 7,27**
 Król się zasmuci. Księcia ogarnie przerażenie. Drżeć będą ręce ludu ziemi. Uczynię im według ich postępowania i według ich sądów ich osądzę. I poznają, że Ja jestem Jahwe.
# Ez 7 BR
###### **Ez 7,1**
 Pan powiedział do mnie:
###### **Ez 7,2**
 Synu człowieczy, powiesz tak: Oto słowa Pana Boga do całej krainy izraelskiej. Nadchodzi koniec, koniec się zbliża dla wszystkich czterech krańców ziemi.
###### **Ez 7,3**
 Dla ciebie też już nadchodzi kres. Chcę, by gniew mój zapłonął nad tobą. Wydaję na ciebie wyrok według czynów twoich, karę na ciebie zsyłam za wszystkie twe złe uczynki.
###### **Ez 7,4**
 Nic nie przyprawi o litość mych oczu, wcale nie będę cię oszczędzał. Na ciebie spadnie wina za wszystkie twoje postępki, twoje niegodziwości ukażą się oczom wszystkich. Wtedy też przekonacie się, że Ja jestem Panem.
###### **Ez 7,5**
 Tak mówi Pan Bóg: Oto idą nieszczęścia, jedno za drugim.
###### **Ez 7,6**
 Koniec się zbliża, nadchodzi koniec. Zbliża się twój koniec. Popatrz, już nadchodzi.
###### **Ez 7,7**
 Kolej teraz na ciebie, mieszkańcze tego kraju. Nadszedł już czas, bliski jest twój dzień: zamieszanie już tylko, a nie radosne okrzyki na górach.
###### **Ez 7,8**
 Wkrótce już wyleję cały mój gniew na ciebie, całą moją złość na tobie wyładuję. Ogłoszę ci wyrok dokładnie taki, na jaki sobie zasłużyłeś. Na ciebie spadnie wina za wszystkie twoje występki.
###### **Ez 7,9**
 Nic nie pobudzi do litości moich oczu i wcale nie będę cię oszczędzał, lecz odpłacę ci wedle twoich uczynków. Twoje bezeceństwa staną się jawne dla wszystkich. I wtedy przekonacie się, że Ja jestem Panem, który zadaje ciosy.
###### **Ez 7,10**
 Nadszedł już dzień! Kolej teraz na ciebie. Już się rozpoczęło. Panoszy się bezprawie, pycha nad wszystkim góruje.
###### **Ez 7,11**
 Gwałt stał się berłem w ręku niegodziwca. Nic po nich nie pozostanie, nic z ich bogactw, nic z ich przepychu i wspaniałości.
###### **Ez 7,12**
 Nadchodzi już czas, bliski już jest dzień. Kupujący niech się już niczym nie cieszą, niech też nic nie zasmuca sprzedawców, bo płomień gniewu ogarnie cały naród.
###### **Ez 7,13**
 Sprzedawca nie będzie już mógł żądać zwrotu rzeczy sprzedanych, nawet jeśli ci, którym sprzedał, pozostali przy życiu, bo płomień gniewu ogarnie cały naród. Nie będzie żądał zwrotu. Ponieważ zaś nikt nie jest bez winy, nikt nie zdoła też ocalić swego życia.
###### **Ez 7,14**
 Dmijcie więc w trąby, wszystko niech będzie gotowe, i tak nikt do boju nie stanie, bo płomień mojego gniewu ogarnia cały naród.
###### **Ez 7,15**
 Na zewnątrz miecz, wewnątrz - zaraza i głód. Kto pozostał na polu, ginie od miecza, kto znajduje się w mieście, tego pożera głód i zaraza.
###### **Ez 7,16**
 Kto zdołał zbiec i uratować swoje życie, będzie się błąkać po górach jak w rozpadlinach skalnych gołębie. Każdy boleje z powodu własnych występków.
###### **Ez 7,17**
 Poopadają wszystkim bezradnie ręce, a po kolanach wszystkim będzie spływać woda.
###### **Ez 7,18**
 Włożą na siebie szaty pokutne, i wszystkich ogarnie przerażenie. Twarze wszystkich pokryją się wstydem, na głowach pojawi się łysina.
###### **Ez 7,19**
 Wyrzucą na ulice swoje srebro, a złoto będzie w nich budzić odrazę. Ani wasze srebro, ani złoto nie zdoła was uratować, gdy przyjdzie dzień gniewu Pana. Nie zaspokoicie tym waszego głodu, nie będziecie mieli czym napełnić waszych żołądków. Wszystko to było dla was tylko okazją do grzechu!
###### **Ez 7,20**
 Drogocenne ozdoby przyczyniały się tylko do wzrostu pychy, która ich też skłaniała do czynienia sobie obrzydliwych posągów swych bogów. Dlatego staną się dla nich te ozdoby odrazą.
###### **Ez 7,21**
 I wydam ich na łup cudzoziemcom, i wszyscy niegodziwcy świata będą ich grabić i bezcześcić.
###### **Ez 7,22**
 I odwrócę od nich moje oblicze i będą bezczeszczeni ci, co byli moją własnością. Nadejdą złoczyńcy i zabiorą wszystko.
###### **Ez 7,23**
 Oni to dokonają ogromnego rozlewu krwi, bo w kraju mnożą się wyroki sądu na śmierć skazujące, a w mieście panuje przemoc.
###### **Ez 7,24**
 Sprowadzę tu najokrutniejsze narody, żeby zajęły ich domostwa. I tak położę kres pysze możnowładców i wszystkie ich sanktuaria zbeszczeszczę.
###### **Ez 7,25**
 Strach was wtedy ogarnie i będziecie szukać spokoju, ale go nie znajdziecie.
###### **Ez 7,26**
 Nieszczęście będzie szło za nieszczęściem, złe wieści - jedna za drugą. Będą żądali widzeń od proroków. Kapłani nie będą potrafili już pouczać ani starsi udzielać rad jakichkolwiek.
###### **Ez 7,27**
 Króla ogarnie przygnębienie, książęta będą przerażeni, wszystkim mieszkańcom kraju opadną ręce. Postąpię z nimi tak, jak sobie na to zasłużyli swoimi uczynkami i wydam na nich wyrok zgodny z ich wyrokami. Przekonają się wtedy, że Ja jestem Panem.
# Ez 7 WUJ
###### **Ez 7,1**
 I stała się mowa Pańska do mnie, rzekąc:
###### **Ez 7,2**
 A ty synu człowieczy, to mówi Pan Bóg Izraelowej: Koniec przyszedł, przyszedł koniec na cztery strony ziemie.
###### **Ez 7,3**
 Teraz koniec na cię, i puszczę zapalczywość moję na cię: i będę cię sądził: według dróg twoich: i położę przeciwko tobie wszystkie obrzydłości twoje.
###### **Ez 7,4**
 I nie sfolguje oko moje tobie, ani się zlituje ale: drogi twoje włożę na cię, a brzydliwości twoje będą w pośrodku ciebie: i doznacie, żem ja Pan.
###### **Ez 7,5**
 To mówi Pan Bóg: Utrapienie jedno, utrapienie oto idzie:
###### **Ez 7,6**
 Koniec przychodzi, przychodzi koniec: ocknął się przeciw tobie: oto przychodzi.
###### **Ez 7,7**
 Przyszło skruszenie na cię, który mieszkasz w ziemi: przychodzi czas, blizko jest dzień zabijania, a nie sławy gór.
###### **Ez 7,8**
 Teraz z blizka wyleję gniew mój na cię, i wykonam zapalczywość moję na tobie: a osądzę cię według dróg twoich, i włożę na cię wszystkie złości twoje.
###### **Ez 7,9**
 A nie sfolguje oko moje, ani się zlituje: ale drogi twoje włożę na cię, i obrzydłości twe w pośrodku ciebie będą: a doznacie, żem ja Pan, który biję.
###### **Ez 7,10**
 Oto dzień, oto przyszedł: wyszło skruszenie, zakwitnęła laska, spłodziła pycha.
###### **Ez 7,11**
 Nieprawość urosła w laskę niezbożności: nie z nich i nie z ludu: ani z głosu ich, i nie będzie odpoczynku między nimi.
###### **Ez 7,12**
 Przyszedł czas, przybliżył się dzień: kto kupuje, niech się nie raduje: a kto przedaje, niech nie żałuje: bo gniew na wszystek lud jego.
###### **Ez 7,13**
 Bo kto przedaje, nie wróci się do tego co przedał, a jeszcze między żywymi żywot ich: bo widzenie do wszego gminu jego nie wróci się: a mąż w nie prawości żywota swego nie zmocni się.
###### **Ez 7,14**
 Trąbcie w trąbę, niech się gotują wszyscy, a niemasz ktoby szedł ku bitwie: bo gniew mój na wszystek lud jego.
###### **Ez 7,15**
 Miecz zewnątrz, a mór i głód wewnątrz: kto jest na polu, od miecza umrze: a którzy w mieście, morem i głodem pożarci będą.
###### **Ez 7,16**
 I ujdą, którzy ucieka z nich: a będą na górach jako gołębice dolin wszyscy drżący każdy w nieprawości swej.
###### **Ez 7,17**
 Wszystkie ręce zemdleją, i wszystkie kolana pocieką wodą.
###### **Ez 7,18**
 I przepaszą się włosiennicami, a okryje je lękanie, na każdej też twarzy wstyd, a na wszech głowach ich łysina.
###### **Ez 7,19**
 Srebro ich precz wyrzucać będą, a złoto ich gnojem będzie. Srebro ich i złoto nie będzie mogło wybawić w dzień zapalczywości Pańskiej. Dusze swej nie nasycą, i brzuchy ich nie będą napełnione: bo obrażenie nieprawości ich stało się.
###### **Ez 7,20**
 I ozdobę klejnotów swoich na pychę obrócili, i wyobrażenia obrzydłości swych i bałwanów z niego poczynili: dla tego dałem ją im ku nieczystości.
###### **Ez 7,21**
 I dam ją w ręce obcych na rozchwycenie, i niezbożnikom ziemskim na korzyść i splugawią ją.
###### **Ez 7,22**
 I odwrócę oblicze moje od nich, i zgwałcą tajemnicę moje, i wnidą do niego łupieżnicy i splugawią ją.
###### **Ez 7,23**
 Uczyń zamknienie: ponieważ ziemia pełna jest sądu krwie, a miasto pełne nieprawości.
###### **Ez 7,24**
 I przywiodę nagorsze z pogan, i posiędą domy ich, a uciszę pychę możnych, i posiędą świątnice ich.
###### **Ez 7,25**
 Gdy ucisk nadejdzie, będą szukać pokoju, a nie będzie.
###### **Ez 7,26**
 Trwoga na trwogę przydzie, a słuch na słuch: i będą szukać widzenia u proroka, a zakon zginie od kapłana, a rada od starców.
###### **Ez 7,27**
 Król będzie w żałobie, a książę oblecze się w smętek: i ręce ludu ziemskiego strwożą się. Według drogi ich uczynię im, a według sądów ich osądzę je: a wiedzieć będą, żem ja Pan.
