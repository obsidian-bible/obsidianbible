# Am 5 BT5
###### **Am 5,1**
 Słuchajcie tej mowy, którą jako pieśń żałobnąo was zaśpiewam, domu Izraela!
###### **Am 5,2**
 Upadła, nie będzie mogła powstać Dziewica Izra-ela;leży na ziemi, nikt jej nie podźwignie.
###### **Am 5,3**
 Gdyż tak mówi Pan Bóg:Miastu, które wysłało tysiąc [wojska], pozostanie stu; które wysłało stu, pozostanie dziesięciudla domu Izraela.
###### **Am 5,4**
 Tak mówi Pan do domu Izraela:Szukajcie Mnie, a żyć będziecie.
###### **Am 5,5**
 Nie szukajcie zaś Betel i do Gilgal nie chodźcie!I Beer-Szeby nie odwiedzajcie!Albowiem Gilgal pójdzie do niewoli, a Betel zniknie.
###### **Am 5,6**
  Szukajcie Pana, a żyć będziecie!Inaczej bowiem niby ogień nawiedzi On dom Józefa i strawi go. Nikt nie będzie mógł zagasić ognia w Betel.
###### **Am 5,7**
 Prawość obracają w piołun, a sprawiedliwość depczą po ziemi.
###### **Am 5,8**
 Twórca Plejad i Oriona, który przemienia ciemności w poranek, a dzień w noc zaciemnia, zwołuje wody morskie, żeby rozlać je na powierzchni ziemi –nazywa się Pan.
###### **Am 5,9**
 On na mocnego zsyła zniszczeniei sprowadza zniszczenie na twierdzę.
###### **Am 5,10**
 W bramie nienawidzą dowodzącego słuszności, nie cierpią tego, który mówi prawdę.
###### **Am 5,11**
 Ponieważ deptaliście biednegoi daniny w zbożu braliście od niego, możecie zbudować sobie domy z kamienia ciosa-nego, lecz nie będziecie w nich mieszkali; możecie piękne winnice zasadzić, lecz nie będziecie pili z nich wina.
###### **Am 5,12**
 Albowiem poznałem mnogie wasze złościi grzechy wasze liczne, o wy, ciemięzcy sprawiedliwego, biorący okupi uciskający w bramie ubogich!
###### **Am 5,13**
 Dlatego w tym czasie milczy człowiek roztropny, bo jest to czas niedoli.
###### **Am 5,14**
 Szukajcie dobra, a nie zła, abyście żyli. Wtedy Pan, Bóg Zastępów, będzie z wami, tak jak to mówicie.
###### **Am 5,15**
 Miejcie w nienawiści zło, a miłujcie dobro!Wymierzajcie w bramie sprawiedliwość!Może ulituje się Pan, Bóg Zastępów, nad Resztą pokolenia Józefa.
###### **Am 5,16**
 Dlatego tak mówi Pan, Bóg Zastępów, Panujący:Na wszystkich placach będzie lament, na wszystkich ulicach krzyczeć będą: «***Biada, biada!***»Wzywać będą rolnika do żałoby, do lamentowania – znających zawodzenie.
###### **Am 5,17**
 We wszystkich winnicach będzie narzekanie, bo przejdę pośród ciebie –rzekł Pan.
###### **Am 5,18**
 Biada oczekującym dnia Pańskiego. Cóż wam po dniu Pańskim?On jest ciemnością, a nie światłem.
###### **Am 5,19**
 Jakby uciekał człowiek przed lwem, a trafił na niedźwiedzia; jakby skrył się w domu i oparł się ręką o ścianę, a ukąsił go wąż.
###### **Am 5,20**
 Czyż dzień Pański nie jest ciemnością, a nie światłem jasności?
###### **Am 5,21**
 Nienawidzę waszych świąt i brzydzę się nimi. Nie będę miał upodobania w waszych uroczystych zebraniach.
###### **Am 5,22**
 Bo kiedy składacie Mi całopalenia i wasze ofiary, nie znoszę tego, a na ofiary biesiadne z tucznych wołównie chcę patrzeć.
###### **Am 5,23**
 Idź precz ode Mnie ze zgiełkiem pieśni twoich, i dźwięku twoich harf nie chcę słyszeć.
###### **Am 5,24**
 Niech sprawiedliwość wystąpi jak wodaz brzegówi prawość niech się wyleje jak nie wysychający potok!
###### **Am 5,25**
 Czy składaliście Mi żertwy i ofiary pokarmowe na pustyniprzez czterdzieści lat, domu Izraela,
###### **Am 5,26**
 i obnosiliście Sikkuta, waszego króla, i Kijjuna, wasze bożki, <gwiazdę waszego boga>,które sobie uczyniliście?
###### **Am 5,27**
 Dlatego was uprowadzę na wygnanie poza Dama-szek, mówi Pan; Bóg Zastępów – to imię Jego.
# Am 5 PAU
###### **Am 5,1**
 Słuchajcie tej mowy! Tobie, Izraelu, zaśpiewam pieśń żałobną.
###### **Am 5,2**
 Upadła dziewica Izraela i już nie powstanie, leży na ziemi, nikt jej nie podźwignie.
###### **Am 5,3**
 Gdyż tak mówi PAN BÓG do domu Izraela: Z tysiąca żołnierzy stu powróci do miasta, ze stu powróci tylko dziesięciu.
###### **Am 5,4**
 Tak mówi PAN do domu Izraela: Zwróćcie się do Mnie, a żyć będziecie.
###### **Am 5,5**
 Nie zwracajcie się do Betel, do Gilgal nie chodźcie i Beer-Szeby nie odwiedzajcie! Bo całe Gilgal pójdzie do niewoli, a Betel obróci się w ruinę!
###### **Am 5,6**
 Zwróćcie się do PANA, a będziecie żyć! Aby nie ukarał domu Józefa i nie spalił go, a nikt nie zdoła ugasić ognia w Betel.
###### **Am 5,7**
 Prawość zamieniacie w gorycz, a sprawiedliwość wdeptujecie w ziemię.
###### **Am 5,8**
 Ten, co uczynił Plejady i Oriona, przemienia ciemności w świt poranka, a dzień w noc zamienia. Ten, co przywołuje wody morskie, rozlewa je po powierzchni ziemi. Nosi On imię PAN.
###### **Am 5,9**
 On niszczy siłacza i zniszczenie sprowadza na twierdze.
###### **Am 5,10**
 Nienawidzą tego, kto w bramie dochodzi słuszności, i nie cierpią tego, który mówi prawdę.
###### **Am 5,11**
 Ponieważ deptaliście biednego i braliście od niego daniny ze zboża, chociaż zbudowaliście sobie domy z kamienia ciosanego, nie będziecie w nich mieszkali; choć zasadziliście piękne winnice, nie będziecie pili z nich wina.
###### **Am 5,12**
 Bo wiem, jak liczne są wasze występki i jak bardzo mnożą się wasze grzechy: ciemiężycie sprawiedliwego, jesteście przekupni i w bramie uciskacie ubogich!
###### **Am 5,13**
 Dlatego, kto jest roztropny, niech milczy w tym czasie, gdyż będzie to czas niedoli.
###### **Am 5,14**
 Szukajcie dobra, a nie zła, abyście żyli, wtedy PAN, Bóg Zastępów, będzie z wami, jak to mówicie.
###### **Am 5,15**
 Miejcie w nienawiści zło, a miłujcie dobro! W bramie sądźcie sprawiedliwie! Może ulituje się Pan, Bóg Zastępów, nad resztą domu Józefa.
###### **Am 5,16**
 Dlatego tak mówi PAN, Bóg Zastępów: Na wszystkich placach rozlegać się będzie skarga, na wszystkich ulicach będą krzyczeć: „Biada, biada!”. Wzywać będą rolnika do żałoby, a tych, co znają pieśni żałobne, do zawodzenia.
###### **Am 5,17**
 We wszystkich winnicach będzie narzekanie, gdy przejdę pośród ciebie - mówi PAN.
###### **Am 5,18**
 Biada wam, którzy pożądacie Dnia PANA. Dlaczego pragniecie, aby nadszedł Dzień PANA? Będzie on ciemnością, nie światłem!
###### **Am 5,19**
 To tak, jakby człowiek uciekał przed lwem, a spotkał niedźwiedzia; albo tak, jakby ukrył się w domu, a kiedy oparł rękę o ścianę, ukąsił go wąż.
###### **Am 5,20**
 Zrozumcie, że Dzień PANA będzie ciemnością, a nie światłem, mrokiem bez żadnej jasności.
###### **Am 5,21**
 Brzydzę się waszymi świętami i odrzucam je. Wasze świąteczne celebracje nie sprawiają mi przyjemności.
###### **Am 5,22**
 Kiedy składacie Mi całopalenia i ofiary pokarmowe, nie są Mi one miłe. Na wasze ofiary wspólnotowe z tuczonych wołów nie chcę nawet patrzeć.
###### **Am 5,23**
 Skończ z hałasem twoich pieśni! Nie chcę słuchać dźwięku twoich harf!
###### **Am 5,24**
 Niech sprawiedliwość rozleje się jak woda, a prawość niech będzie jak potok, który nie wysycha!
###### **Am 5,25**
 Przecież także na pustyni przez czterdzieści lat składaliście Mi, Izraelici, ofiary z cielców i pokarmów.
###### **Am 5,26**
 A zarazem obnosiliście Sikkuta jako waszego króla i posąg Kijjuna, gwiazdę waszych bogów, których sami sobie zrobiliście.
###### **Am 5,27**
 Dlatego wygnam was poza Damaszek- mówi PAN, który nosi imię Boga Zastępów.
# Am 5 BP
###### **Am 5,1**
 Słuchajcie tego słowa, które podnoszę przeciwko wam, pieśni żałobnej o was, Domu Izraela:
###### **Am 5,2**
 "Upadła, już się nie podniesie, dziewica izraelska; leży porzucona na własnej ziemi, nikt jej nie podźwignie!"
###### **Am 5,3**
 Tak bowiem mówi Jahwe-Pan do Domu Izraela: - Miasto, z którego wyruszy tysiąc [wojowników], zachowa tylko stu, a to, z którego wyruszy stu, zachowa tylko dziesięciu.
###### **Am 5,4**
 Otóż tak mówi Jahwe do Domu Izraela: - Szukajcie mnie, a będziecie żyli!
###### **Am 5,5**
 Lecz nie udawajcie się do Betel, nie przychodźcie do Gilgal i nie pielgrzymujcie do Beerszeby! Bo Gilgal pójdzie na wygnanie, a Betel obróci się w ruinę.
###### **Am 5,6**
 Szukajcie Jahwe, a będziecie żyli! W przeciwnym razie spadnie On jak ogień na Dom Józefa; strawi go, a nie będzie nikogo w Domu Izraela, kto by go gasił.
###### **Am 5,7**
 Biada wam, którzy prawo zamieniacie w piołun i obalacie sprawiedliwość.
###### **Am 5,8**
 On, który stworzył Plejady i Oriona, który zamienia ciemność w poranek, a dzień w ciemności nocne; który przyzywa wody morza i rozlewa je po powierzchni ziemi - Jahwe jest Imię Jego!
###### **Am 5,9**
 On sprowadza z nagła zgubę na mocarza, zsyła zniszczenie na twierdzę.
###### **Am 5,10**
 Nienawidzicie tego, kto w bramie broni sprawiedliwości, i odrazę czujecie do tego, kto prawdę mówi.
###### **Am 5,11**
 Dlatego właśnie, że ciemiężycie biednego i pobieracie od niego daninę ze zboża, możecie sobie wznosić domy z kamienia ciosanego, lecz mieszkać w nich nie będziecie; możecie sadzić rozkoszne winnice, lecz wina z nich pić nie będziecie.
###### **Am 5,12**
 Bo wiem, jak liczne są wasze występki i jak ogromne wasze przewinienia: zwalczacie sprawiedliwego, przyjmujecie okup, w bramie zaś odpychacie biednych.
###### **Am 5,13**
 Dlatego mądry wówczas milczy, bo czas to nieszczęśliwy.
###### **Am 5,14**
 Szukajcie zatem dobra, a nie zła, abyście mogli żyć i aby Jahwe, Bóg Zastępów, był z wami, jak to twierdzicie.
###### **Am 5,15**
 Miejcie zło w nienawiści, a ukochajcie dobro i przywróćcie w bramie poszanowanie dla prawa! Może się [wtedy] Jahwe, Bóg Zastępów, zmiłuje nad [ocalałą] resztą [potomków] Józefa.
###### **Am 5,16**
 Przeto tak mówi Jahwe-Pan, Bóg Zastępów: - Na wszystkich placach rozbrzmiewać będzie lament i na wszystkich ulicach rozlegać się będą okrzyki: "Biada, biada!" Także rolnika wzywać się będzie do żałoby, a tych, co znają pieśni żałobne, do zawodzenia;
###### **Am 5,17**
 również we wszystkich winnicach słychać będzie narzekanie, gdy Ja pośród was przejdę - mówi Jahwe.
###### **Am 5,18**
 Biada tym, którzy pragną dnia Jahwe! Czymże będzie on dla was, ów dzień Jahwe? Ciemnością będzie, a nie światłością!
###### **Am 5,19**
 To będzie tak, jak gdyby ktoś uciekał przed lwem, a natknął się na niedźwiedzia; jak gdyby powracał do domu i oparł się ręką o ścianę, a ukąsiła go żmija.
###### **Am 5,20**
 O tak, dzień Jahwe będzie ciemnością, a nie światłością, ponury on będzie i pozbawiony wszelkiego blasku.
###### **Am 5,21**
 Nienawidzę waszych świąt i gardzę nimi, czuję odrazę do waszych uroczystości.
###### **Am 5,22**
 Gdy mi składacie ofiary całopalne i ofiary z pokarmów, nie mam w nich upodobania, a na ofiary dziękczynne z waszych tucznych cielców nawet nie spoglądam.
###### **Am 5,23**
 Oddalcie ode mnie zgiełk waszych śpiewów, nie chcę słuchać brzęku waszych harf!
###### **Am 5,24**
 Ale raczej niech prawo jak woda płynie swym biegiem, a sprawiedliwość jak strumień, który niegdy nie wysycha.
###### **Am 5,25**
 Czy przez czterdzieści lat na pustyni składaliście mi ofiary całopalne i ofiary z pokarmów, o Domu Izraela?
###### **Am 5,26**
 Czy obnosiliście przy tym Sakkuta, króla waszego, i Kewana, wasze bóstwo gwiezdne, których podobizny sporządziliście sobie?
###### **Am 5,27**
 Dlatego skażę was na wygnanie poza Damaszek - mówi Jahwe; Bóg Zastępów, to jest Imię Jego.
# Am 5 BR
###### **Am 5,1**
 Posłuchajcie Mnie, wszyscy z Domu Izraela, pieśni żałobnej posłuchajcie, którą o was zaśpiewam.
###### **Am 5,2**
 Upadła i już nie powstanie Izrael-Dziewica, leży roztrzaskana na swej rodzimej ziemi i nikt już nawet nie usiłuje postawić jej na nogi.
###### **Am 5,3**
 Bo oto, co mówi Pan Bóg: Do miasta, z którego tysiąc mężów wyszło, stu zaledwie do domu powraca. Tam zaś skąd stu wychodzi, tylko dziesięciu powraca.
###### **Am 5,4**
 Zaprawdę, tak mówi Pan do domu Izraela: Szukajcie Mnie tedy, a wszyscy żyć będziecie!
###### **Am 5,5**
 Nie rozglądajcie się więc za Betel, nie podróżujcie do Gilgal, nie udawajcie się do Beer-Szeby! Bo tym, co są w Gilgal, grozi wygnanie, a nad Betel już też zagłada wisi.
###### **Am 5,6**
 Szukajcie tedy Pana, a wszyscy żyć będziecie. Bo inaczej wejdzie do domu Józefa jak ogień, który wszystko pochłania, i nikt już nie ugasi pożaru w Betel.
###### **Am 5,7**
 Biada tym, co prawo w gorzki przemieniają piołun, a sprawiedliwość wdeptują w ziemię.
###### **Am 5,8**
 To On stworzył Siedmiozbiór i Oriona, to On przemienia ciemność w jaśniejący ranek. To On także dzień przemienia w ciemność. To On wodom oceanów wydaje rozkazy. On także zsyła deszcz na ziemię. Pan jest Jego imię.
###### **Am 5,9**
 Silnego zgładzić może niespodzianie, i miasta najbardziej warowne może w proch rozsypać.
###### **Am 5,10**
 Wobec sądu okazują nienawiść tym, którzy wzywają do sprawiedliwości, i gardzą tymi, którzy mówią prawdę.
###### **Am 5,11**
 Ponieważ od bezbronnych pobieraliście haracz, a na ich zboża nakładaliście podatki, możecie budować sobie domy z ciosanych kamieni, ale w nich mieszkać nigdy nie będziecie. Możecie sobie też zakładać wspaniałe winnice, ale wina z nich pić nie będziecie.
###### **Am 5,12**
 Znam Ja bowiem dobrze wasze liczne występki i wasze niezliczone (i ciężkie) grzechy. To wy niewinnych wtrącacie w nędzę, każecie się opłacać, a przed sądem krzywdzicie ubogich.
###### **Am 5,13**
 Każdy tedy, kto rozsądny zamilknie w dni owe, bo będą to dni niedobre bardzo.
###### **Am 5,14**
 Szukajcie tedy dobra, a nie zła, to żyć będziecie, a wtedy będzie u was, jak to wy mówicie, sam Pan i Bóg Zastępów.
###### **Am 5,15**
 Starajcie się zła nienawidzieć, a miłować dobro, a gdy sądzić będziecie, usiłujcie być prawi, to może Pan i Bóg Zastępów okaże swoją łaskawość reszcie Józefa.
###### **Am 5,16**
 Dlatego Pan i Bóg Zastępów mówi: Na wszystkich placach będzie widać smutek, na każdej uliczce krzyczeć będą 'Biada!' Robotnik polny musi lamentować, śpiewaków pieśni żałobnych wzywa się do lamentacji.
###### **Am 5,17**
 Narzekanie słychać we wszystkich winnicach, bo oto Ja między wami przejdę - tak mówi Pan.
###### **Am 5,18**
 Biada tym, którzy oczekują dnia Pańskiego! A cóż wam dzień Pański pomoże? Przecież to ciemność, a nie żadne światło!
###### **Am 5,19**
 To jest tak, jakby ktoś zdołał przed lwem uciec i natychmiast dostał się w pazury niedźwiedzia, albo jakby skrył się w swoim domu i został ukąszony przez węża, gdy tylko dotknął ściany.
###### **Am 5,20**
 Dzień Pański to ciemności zaprawdę, nie światłość, nie widać w nim jasności, bo wszystko jest czarne.
###### **Am 5,21**
 Świąt waszych nienawidzę i brzydzę się nimi, nie chcę mieć nic wspólnego z waszymi obchodami.
###### **Am 5,22**
 Kiedy Mi składacie ofiary całopalenia, nie znajduję upodobania w waszych darach, a na ofiary z tucznych wołów nie chcę nawet patrzeć.
###### **Am 5,23**
 A więc pójdźcie precz z waszych pieśni wrzawą nie chcę już dłużej słuchać waszej gry na harfach.
###### **Am 5,24**
 Niech zaś sprawiedliwość popłynie jak rzeka, a prawość niech się wyleje jak nie schnący potok.
###### **Am 5,25**
 Czyż nie składaliście Mi ofiar i darów przez lat czterdzieści na pustyni wy wszyscy, synowie domu Izraela?
###### **Am 5,26**
 A przecież wtedy nosiliście boga Sakkuta jako króla waszego, i waszego boga gwiazd, Kijjuna, a także wszystkich tych bogów, których sami żeście zrobili!
###### **Am 5,27**
 Dlatego przesiedlę was daleko poza Damaszek. Tak mówi Pan, a imię Jego jest Bóg Zastępów.
# Am 5 WUJ
###### **Am 5,1**
 Słuchajcie słowa tego, które ja wznoszę na was narzekanie. Dom Izraelów upadł, a więcej nie powstanie.
###### **Am 5,2**
 Panna Izraelska porzucona jest na ziemię swoję, niemasz ktoby ją podniósł.
###### **Am 5,3**
 Bo to mówi Pan Bóg: W mieście, z którego wychodziło tysiąc, zostanie się w nim sto: a z którego wychodziło sto, zostanie w nim dziesięć w domu izraelowym.
###### **Am 5,4**
 Bo to mówi Pan domowi Izraelowemu: Szukajcie mię, a żyć będziecie.
###### **Am 5,5**
 A nie szukajcie Bethela, do Galgala nie chodźcie, i do Bersabei nie przejdziecie: bo Galgala w niewolą zaprowadzona będzie, a Bethel będzie niepożyteczną.
###### **Am 5,6**
 Szukajcie Pana, a żyjcie: aby snać nie zagorzał jako ogień dom Józefów, i pożrze, a nie będzie ktoby ugasił Bethel.
###### **Am 5,7**
 Którzy sąd w piołun obracacie, a sprawiedliwość na ziemię opuszczacie.
###### **Am 5,8**
 Tego, który uczynił wóz niebieski, i kosę, i który obraca ciemności w zaranie, i dzień w noc odmienia: który woła wód morskich, i wylewa je na oblicze ziemie, Pan imię jego.
###### **Am 5,9**
 Który się uśmiecha zburzeniu mocnego, i spustoszenie na mocarza przywodzi.
###### **Am 5,10**
 Nienawidzieli strofującego w bramie: a mówiącym doskonale brzydzili się.
###### **Am 5,11**
 Przetoż ponieważeście łupili ubogiego, a korzyść wyborna braliście od niego: domy z kamienia kwadratowego zbudujecie, a nie będziecie mieszkać w nich: winnic barzo miłych nasadzicie, a wina ich pić nie będziecie.
###### **Am 5,12**
 Bom poznał mnogie złości wasze, i mocne grzechy wasze: nieprzyjaciele sprawiedliwego biorący dar, a ubogie tłumiący w bramie:
###### **Am 5,13**
 Przeto roztropny czasu onego milczeć będzie: bo czas zły jest.
###### **Am 5,14**
 Szukajcie dobra, a nie złości, żebyście żyli: a będzie Pan Bóg zastępów z wami, jakoście mówili.
###### **Am 5,15**
 Miejcie złość w nienawiści, a miłujcie dobro, i postanówcie w bramie sąd, owa się Pan Bóg zastępów zmiłuje nad ostatkiem Józefa.
###### **Am 5,16**
 Przetoż to mówi Pan Bóg zastępów panujący: po wszech ulicach narzekanie: a po wszech miejscach, które po stronach są rzeką: Biada, biada: I będą przyzywać oracza na płacz, a do narzekania tych, którzy umieją narzekać.
###### **Am 5,17**
 I po wszech winnicach będzie narzekanie: bo pójdę przez pośród ciebie, mówi Pan.
###### **Am 5,18**
 Biada żądającym dnia Pańskiego: cóż wam po nim? dzień ten Pański ciemność, a nie światłość.
###### **Am 5,19**
 Jako gdyby uciekał mąż przede lwem, a zabiegł mu niedźwiedź: a wszedłby do domu i podparł się ręką swą na ścienie, ukąsiłby go wąż.
###### **Am 5,20**
 Izali nie ciemność dzień Pański, a nie światłość: i mrok a nie jasność w nim?
###### **Am 5,21**
 Mam w nienawiści i odrzuciłem święta wasze: ani przyjmę woni gromad waszych.
###### **Am 5,22**
 A jeśli mi ofiarować będziecie całopalenia i dary wasze nie przyjmę: i na śluby tłustych rzeczy waszych nie wejrzę.
###### **Am 5,23**
 Odejmi odemnie zgiełk pieśni twoich, i piosnek liry twojej, słuchać nie będę.
###### **Am 5,24**
 I odkryje się sąd jako woda, a sprawiedliwość jako potok gwałtowny.
###### **Am 5,25**
 Izaliście mi ofiary i obiatę ofiarowali na puszczy przez czterdzieści lat, domie Izraelski?
###### **Am 5,26**
 I nosiliście namiot Molokowi waszemu, i obraz bałwanów waszych, gwiazdę Boga waszego, któreście działali sobie.
###### **Am 5,27**
 I uczynię, że się przeprowadzicie za Damaszek, mówi Pan Bóg zastępów imię jego.
