# 2Mch 1 BT5
###### **2Mch 1,1**
 «***Braciom Żydom w Egipcie [przesyłają] pozdrowienie bracia Żydzi z Jerozolimy, a ci, którzy mieszkają w krainie judzkiej, życzą pokoju i pomyślności.***
###### **2Mch 1,2**
 ***Niech Bóg udziela wam dobra i niech pamięta o przymierzu swoim [zawartym] z Abrahamem, Izaakiem i Jakubem, wiernymi swoimi sługami;***
###### **2Mch 1,3**
 ***niech da wam wszystkim serca, abyście czcili Go i wykonywali Jego wolę sercem wielkim i duszą ochotną;***
###### **2Mch 1,4**
 ***niech otworzy wasze serca na swoje Prawo i na przykazania i niech sprawi pokój!***
###### **2Mch 1,5**
 ***Niech wysłucha waszych modlitw, niech da się wam przejednać i niech was nie opuści w złym czasie!***
###### **2Mch 1,6**
 ***A my tutaj teraz modlimy się za was.***
###### **2Mch 1,7**
 ***Za panowania Demetriusza, w roku sto sześćdziesiątym dziewiątym, my, Żydzi, napisaliśmy do was: W najsroższym utrapieniu, jakie spadło na nas w tych latach, kiedy Jazon i jego zwolennicy zdradzili Ziemię Świętą i królestwo,***
###### **2Mch 1,8**
 ***kiedy podpalono bramę i wylano krew niewinną, my modliliśmy się do Pana i zostaliśmy wysłuchani. Złożyliśmy ofiarę krwawą i ofiarę z najczystszej mąki, zapaliliśmy lampy i położyliśmy chleby.***
###### **2Mch 1,9**
 ***Teraz zaś [piszemy], abyście obchodzili Święto Namiotów miesiąca Kislew. [Pisano] w roku sto osiemdziesiątym ósmym***».
###### **2Mch 1,10**
 «***Mieszkańcy Jerozolimy i mieszkańcy Judei, starszyzna i Juda Arystobulowi, nauczycielowi króla Ptolemeusza, pochodzącemu z rodu namaszczonych kapłanów, i Żydom mieszkającym w Egipcie – życzą radości i zdrowia.***
###### **2Mch 1,11**
 ***Wybawieni przez Boga z wielkich niebezpieczeństw, gorąco Mu dziękujemy jako walczący z królem.***
###### **2Mch 1,12**
 ***Albowiem On sam wypędził tych, którzy gotowi byli do walki przeciwko Świętemu Miastu.***
###### **2Mch 1,13**
 ***Kiedy bowiem wódz udał się do Persji, a z nim razem niezwyciężone – jak się wydawało – wojsko, zostali oni pokonani w świątyni bogini Nanai dzięki podstępowi, do którego się uciekli kapłani Nanai.***
###### **2Mch 1,14**
 ***Albowiem gdy przybył na miejsce sam Antioch, a razem z nim jego przyjaciele, aby pod pozorem zaślubin z nią zabrać jako posag wielkie skarby,***
###### **2Mch 1,15**
 ***i kiedy kapłani świątyni Nanai je wyłożyli, a on wszedł z kilkoma w obręb świątyni, zamknęli przybytek, skoro tylko wszedł Antioch,***
###### **2Mch 1,16**
 ***a otworzyli drzwi ukryte w suficie i zabili wodza, zrzucając na niego kamienie. Potem pocięli ich na kawałki, a głowy odcięli i wyrzucili tym, którzy byli na zewnątrz.***
###### **2Mch 1,17**
 ***Za wszystko niech będzie błogosławiony nasz Bóg, który wydał na śmierć tych, co się dopuścili bezbożności.***
###### **2Mch 1,18**
 ***Mając obchodzić Uroczystość Oczyszczenia Świątyni dwudziestego piątego Kislew, uważaliśmy, że trzeba wam o tym donieść, abyście wy także obchodzili Święto Namiotów i ognia [na pamiątkę tego], jak Nehemiasz odbudował świątynię i ołtarz, a potem złożył ofiary.***
###### **2Mch 1,19**
 ***Gdy bowiem do ziemi perskiej byli uprowadzeni nasi ojcowie, ówcześni pobożni kapłani wzięli ogień z ołtarza i potajemnie skryli go w zagłębieniu mającym wygląd wyschłej studni. Tam zabezpieczyli go tak, że miejsce nikomu nie było znane.***
###### **2Mch 1,20**
 ***Po upływie wielu lat, gdy spodobało się Bogu, Nehemiasz, który był przysłany przez króla perskiego, posłał po ogień potomków tych kapłanów, którzy go ukryli. Jak oni opowiedzieli nam, nie znaleźli ognia, ale tylko gęstą wodę. Rozkazał więc, aby nabrali jej i przynieśli.***
###### **2Mch 1,21**
 ***Gdy zaś wszystko było przygotowane do ofiar, Nehemiasz rozkazał kapłanom, aby pokropili tą wodą zarówno drwa, jak i to, co było na nich położone,***
###### **2Mch 1,22**
 ***a kiedy to wykonali i gdy po upływie pewnego czasu zaświeciło słońce, które przedtem było za chmurami, zapłonął ogień tak wielki, że dziwili się wszyscy.***
###### **2Mch 1,23**
 ***Podczas spalania się ofiary modlili się kapłani, a wraz z kapłanami wszyscy. Rozpoczynał Jonatan, wszyscy zaś odpowiadali razem z Nehemiaszem.***
###### **2Mch 1,24**
 ***Modlitwa brzmiała w ten sposób: Panie, Panie Boże, Stwórco wszystkiego, straszliwy i mocny, sprawiedliwy i miłosierny, jedyny dobry i Królu,***
###### **2Mch 1,25**
 ***jedyny Rozdawco dóbr, jedyny sprawiedliwy, wszechmocny i wieczny, który wybawiasz Izraela ze wszystkiego zła, który ojców naszych uczyniłeś wybranymi i który uświęciłeś ich,***
###### **2Mch 1,26**
 ***przyjmij ofiarę za cały naród Twój izraelski, ustrzeż swój dział i uświęć!***
###### **2Mch 1,27**
 ***Sprowadź rozproszonych spomiędzy nas! Uwolnij tych, którzy są w niewoli u pogan. Na wyśmiewanych i wzgardzonych spojrzyj łaskawie. Niech poganie poznają, że Ty jesteś Bogiem naszym.***
###### **2Mch 1,28**
 ***Ukarz tych, którzy uciskają nas i w pysze swojej nas znieważają.***
###### **2Mch 1,29**
 ***Zaszczep lud Twój na Twoim świętym miejscu, jak powiedział Mojżesz.***
###### **2Mch 1,30**
 ***Kapłani intonowali hymny.***
###### **2Mch 1,31**
 ***Gdy spłonęło to, co złożono w ofierze, Nehemiasz kazał wylać pozostałą wodę na wielkie kamienie.***
###### **2Mch 1,32**
 **Gdy zaś to wykonano, wybuchnął płomień, który jednak pochłonięty został przez ogień z ołtarza.**
###### **2Mch 1,33**
 **Kiedy to wydarzenie stało się głośne i królowi Persów doniesiono, że na miejscu, gdzie ukryli ogień owi uprowadzeni w niewolę kapłani, ukazała się woda, którą Nehemiasz i jego ludzie poświęcili to, co było przeznaczone na ofiarę,**
###### **2Mch 1,34**
 **król zbadał sprawę, a miejsce ogrodził i uczynił świętym.**
###### **2Mch 1,35**
 **Król pobierał [stąd] wielkie dochody i rozdzielał je tym, dla których był łaskaw.**
###### **2Mch 1,36**
 **Ludzie Nehemiasza nazwali tę wodę "neftar", to znaczy oczyszczenie, u wielu jednak nazywa się ona "neftai".**
# 2Mch 1 PAU
###### **2Mch 1,1**
 „Żydzi z Jerozolimy i z kraju Judy do braci Żydów z Egiptu. Pozdrowienia i życzenia pokoju!
###### **2Mch 1,2**
 Niech Bóg obdarzy was dobrem i niech pamięta o przymierzu ze swoimi wiernymi sługami: Abrahamem, Izaakiem i Jakubem.
###### **2Mch 1,3**
 Niech da wam wszystkim pragnienie czczenia Go i pełnienia Jego postanowień całym sercem i ochotną duszą!
###### **2Mch 1,4**
 Niech otworzy wasze serca na swoje Prawo i przykazania i niech was obdarzy pokojem!
###### **2Mch 1,5**
 Niech wysłucha waszych modlitw i pojedna się z wami! Niech was nie opuści w złym czasie!
###### **2Mch 1,6**
 A my tu i teraz modlimy się za was.
###### **2Mch 1,7**
 Za panowania Demetriusza, w sto sześćdziesiątym dziewiątym roku, my Żydzi napisaliśmy do was: «W ucisku, który osiągnął swój szczyt w czasie, kiedy Jazon i jego ludzie zdradzili ziemię świętą i królestwo,
###### **2Mch 1,8**
 podpalili główną bramę i przelali niewinną krew, my modliliśmy się do Pana i zostaliśmy wysłuchani. Złożyliśmy więc ofiarę krwawą i pokarmową, zapaliliśmy lampy i wyłożyliśmy chleby».
###### **2Mch 1,9**
 Odtąd i wy obchodźcie Święto Namiotów w miesiącu Kislew. Napisano w sto osiemdziesiątym ósmym roku”.
###### **2Mch 1,10**
 „Mieszkańcy Jerozolimy i Judei, rada starszych oraz Juda do wychowawcy króla Ptolemeusza - Arystobula, z rodu namaszczonych kapłanów, oraz do Żydów z Egiptu. Pozdrowienia i życzenia zdrowia!
###### **2Mch 1,11**
 Gorąco dziękujemy Bogu za ocalenie z wielkich niebezpieczeństw. Zdołaliśmy stanąć do walki z królem,
###### **2Mch 1,12**
 bo sam Bóg wypędził tych, którzy stanęli do walki przeciwko świętemu miastu.
###### **2Mch 1,13**
 Gdy bowiem wódz udał się do Persji, a wraz z nim armia, która wydawała się niezwyciężona, zostali wycięci w pień w świątyni Nanai, wskutek podstępu kapłanów Nanai.
###### **2Mch 1,14**
 Antioch bowiem razem ze swoimi przyjaciółmi przybył do tego miejsca pod pozorem zaślubin z boginią Nanai, aby zagarnąć ogromne bogactwa z tytułu posagu.
###### **2Mch 1,15**
 Gdy kapłani Nanai wyłożyli te bogactwa, a Antioch wszedł z kilkoma ludźmi w obręb świątyni, została ona zamknięta. Tuż po jego wejściu
###### **2Mch 1,16**
 otwarto ukryty w suficie otwór, przez który ciskając kamienie niby pioruny, zabito wodza. Następnie poćwiartowali ciała, a odcięte głowy wyrzucili tym, którzy zostali na zewnątrz.
###### **2Mch 1,17**
 I za to wszystko niech będzie uwielbiony nasz Bóg, który wydał złoczyńców na śmierć!
###### **2Mch 1,18**
 Mając zamiar świętować oczyszczenie świątyni dwudziestego piątego dnia miesiąca Kislew, uznaliśmy za konieczne powiadomić was, abyście wy także obchodzili Święto Namiotów i ognia, który pojawił się, kiedy Nehemiasz po odbudowaniu świątyni i ołtarza złożył ofiary.
###### **2Mch 1,19**
 Kiedy bowiem nasi ojcowie zostali uprowadzeni do Persji, pobożni kapłani wzięli ogień z ołtarza i potajemnie ukryli go w pustej studni. Miejsce to zabezpieczyli tak, aby nikt o nim nie wiedział.
###### **2Mch 1,20**
 Po upływie wielu lat spodobało się Bogu, aby król Persji posłał Nehemiasza. Wtedy wysłał on po ogień potomków kapłanów, którzy go ukryli. Oni jednak donieśli nam, że zamiast ognia znaleźli tłustą wodę. Nehemiasz nakazał im zaczerpnąć jej i przynieść.
###### **2Mch 1,21**
 Gdy przygotowano, co konieczne do składania ofiar, rozkazał kapłanom polać tą wodą drewna i to, co na nich leżało.
###### **2Mch 1,22**
 Uczynili tak. A gdy po pewnym czasie zaświeciło słońce, uprzednio zakryte chmurami, zapłonął tak wielki ogień, że wszyscy byli zdumieni.
###### **2Mch 1,23**
 Podczas spalania się ofiary, kapłani modlili się razem ze wszystkimi. Jonatan zaczynał, a pozostali wraz z Nehemiaszem odpowiadali.
###### **2Mch 1,24**
 Modlili się tak: «PANIE, PANIE Boże, Stwórco wszystkiego, budzący trwogę, mocny, sprawiedliwy i miłosierny, jedyny Królu i Dobroczyńco!
###### **2Mch 1,25**
 Tylko Ty jesteś hojny. Tylko Ty jesteś sprawiedliwy, wszechmocny i wieczny. Ty wybawiłeś Izraela od wszelkiego zła. Ty wybrałeś naszych ojców i ich uświęciłeś.
###### **2Mch 1,26**
 Przyjmij ofiarę za twój cały lud Izraela. Strzeż swojej własności i uświęć ją.
###### **2Mch 1,27**
 Zgromadź naszą diasporę. Uwolnij tych, którzy służą innym narodom. Spójrz na wzgardzonych i wyśmiewanych. Niech poganie przekonają się, że Ty jesteś naszym Bogiem.
###### **2Mch 1,28**
 Ześlij karę na tych, którzy nas uciskają, i na tych, którzy zuchwale nas znieważają.
###### **2Mch 1,29**
 Utwierdź swój lud na twoim świętym miejscu, jak powiedział Mojżesz».
###### **2Mch 1,30**
 W tym czasie kapłani śpiewali hymny.
###### **2Mch 1,31**
 Gdy to, co było złożone w ofierze, spaliło się, Nehemiasz nakazał resztą wody polać większe kamienie.
###### **2Mch 1,32**
 Kiedy tak uczyniono, zapalił się płomień, który został pochłonięty przez jaśniejsze światło z ołtarza.
###### **2Mch 1,33**
 Wydarzenie to stało się głośne i także królowi Persów doniesiono, że w miejscu, w którym uprowadzeni kapłani ukryli ogień, pojawiła się woda, a ludzie z otoczenia Nehemiasza oczyścili nią ofiary.
###### **2Mch 1,34**
 Król po zbadaniu całej sprawy ogrodził to miejsce i wzniósł tam świątynię.
###### **2Mch 1,35**
 Przynosiła ona królowi znaczne dochody, a on rozdawał je tym, których darzył łaską.
###### **2Mch 1,36**
 Towarzysze Nehemiasza nazwali tę wodę „neftar”, co oznacza „oczyszczenie”, lecz przez wielu zwana jest też „neftai”.
# 2Mch 1 BP
###### **2Mch 1,1**
 Bracia Żydzi z Jerozolimy i z ziemi judzkiej przesyłają pozdrowienia Żydom w Egipcie życząc pomyślności i pokoju.
###### **2Mch 1,2**
 Niech Bóg zsyła na was dobrodziejstwa i niech pamięta o Przymierzu, jakie zawarł ze swymi wiernymi sługami, Abrahamem, Izaakiem i Jakubem.
###### **2Mch 1,3**
 Oby dał wam wszystkim serce, abyście Go czcili i wypełniali Jego wolę wielkim sercem i uległą duszą.
###### **2Mch 1,4**
 Niech otworzy wasze serca dla swego Prawa i przykazań i niech użyczy pokoju.
###### **2Mch 1,5**
 Oby wysłuchał waszych modlitw i pojednał się z wami, i oby nie opuścił was w chwili nieszczęścia.
###### **2Mch 1,6**
 [Tak] modlimy się tu za was obecnie.
###### **2Mch 1,7**
 Za panowania Demetriusza, w roku sto sześćdziesiątym dziewiątym, my Żydzi napisaliśmy do was w chwili największego ucisku, jaki dotknął nas w tych latach, odkąd Jazon ze swoimi zwolennikami zdradził ziemię świętą i królestwo.
###### **2Mch 1,8**
 Spalono wówczas bramę [Świątyni] i przelano niewinną krew. Błagaliśmy więc Pana i wysłuchał nas. Złożyliśmy tedy ofiarę krwawą i ofiarę z wyborowej mąki, zapaliliśmy świeczniki i złożyliśmy chleby ofiarowane [Bogu].
###### **2Mch 1,9**
 Odtąd i wy powinniście obchodzić Święto Szałasów w miesiącu Kasleu. [Pisano] w roku sto osiemdziesiątym ósmym.
###### **2Mch 1,10**
 Wszyscy [mieszkańcy] Jerozolimy i Judei, rada starszych wraz z Judą życzą radości i zdrowia Arystobulosowi - pochodzącemu z rodu namaszczonych kapłanów - nauczycielowi króla Ptolemeusza, oraz Żydom w Egipcie.
###### **2Mch 1,11**
 Wybawieni przez Boga z wielkich niebezpieczeństw składamy Mu stokrotne dzięki, że jesteśmy gotowi do walki z królem.
###### **2Mch 1,12**
 Sam bowiem [Bóg] zwyciężył tych, którzy ruszyli gotowi do boju przeciw Świętemu Miastu.
###### **2Mch 1,13**
 Skoro bowiem wódz przybył do Persji z armią, która wydawała się niezwyciężona, zostali pokonam w świątyni Nanai dzięki podstępowi, jakim posłużyli się kapłani Nanai.
###### **2Mch 1,14**
 Antioch przybył tam wraz z przyjaciółmi, aby pod pozorem poślubienia [bogini Nanai] zagarnąć wielkie bogactwa tytułem posagu.
###### **2Mch 1,15**
 Kiedy je kapłani Nanai wyłożyli, wszedł z kilkoma ludźmi do wnętrza świątyni. Skoro tylko się tam znalazł, [kapłani] zamknęli świątynię,
###### **2Mch 1,16**
 a otworzywszy tajemny otwór w suficie rzucać zaczęli kamienie i zabili wodza [wraz z jego ludźmi]. Następnie posiekali ich na kawałki, a odrąbane głowy wyrzucili tym, którzy znajdowali się na zewnątrz.
###### **2Mch 1,17**
 Za wszystko to niech będzie błogosławiony Bóg, który wydał bezbożnych na śmierć.
###### **2Mch 1,18**
 Zamierzając święcić dwudziestego piątego Kasleu oczyszczenie Przybytku, uważaliśmy za stosowne powiadomić was, abyście i wy obchodzili Święto Szałasów i Ognia [na pamiątkę tego], jak Nehemiasz, budowniczy świątyni i ołtarza, złożył ofiary.
###### **2Mch 1,19**
 Albowiem gdy uprowadzono naszych ojców do Persji, pobożni kapłani owych czasów wzięli ogień z ołtarza i ukryli go potajemnie w głębi pewnej wyschłej studni. Zabezpieczyli ją tak, że nikt nie znał tego miejsca.
###### **2Mch 1,20**
 Skoro upłynęło wiele lat i gdy się tak Bogu spodobało, Nehemiasz przysłany [do Judei] przez króla perskiego rozkazał odszukać ogień potomkom owych kapłanów, którzy go ukryli. A gdy nam donieśli, że nie znaleźli ognia, tylko gęstą wodę, rozkazał, aby zaczerpnęli jej i przynieśli.
###### **2Mch 1,21**
 Skoro wszystko, co potrzebne do ofiary, było przygotowane, rozkazał Nehemiasz kapłanom polać tą wodą drzewo i to, co na nim złożono.
###### **2Mch 1,22**
 Uczynili to i gdy po pewnym czasie zaświeciło słońce, przedtem zakryte chmurami, buchnął płomień tak wielki, że wszyscy się zdumieli.
###### **2Mch 1,23**
 Gdy się dokonała ofiara, kapłani zanosili modły a wraz z nimi i wszyscy. Rozpoczynał Jonatan, pozostali zaś powtarzali za Nehemiaszem.
###### **2Mch 1,24**
 A modlili się tak: Panie, Panie Boże, stwórco wszechrzeczy, groźny, potężny, sprawiedliwy i miłosierny, jedyny władco i dobroczyńco.
###### **2Mch 1,25**
 Tyś jeden królem szczodrobliwym, Tyś jeden sprawiedliwy, wszechwładny i wieczny. Wybawco Izraela od wszelkiego nieszczęścia, który ojców naszych uczyniłeś wybranymi i uświęciłeś ich.
###### **2Mch 1,26**
 przyjmij tę ofiarę za cały Twój naród izraelski, strzeż i uświęć Twoje dziedzictwo.
###### **2Mch 1,27**
 Zgromadź tych spośród nas, którzy są rozproszeni, uwolnij tych, którzy są w niewoli u pogan, wejrzyj łaskawie na wyśmiewanych i pogardzanych, aby poznali poganie, żeś Ty jest naszym Bogiem.
###### **2Mch 1,28**
 Ukarz naszych ciemięzców, którzy wynoszą się w swej zuchwałości,
###### **2Mch 1,29**
 zaszczep swój lud na Twoim miejscu Świętym, jak to powiedział Mojżesz.
###### **2Mch 1,30**
 Kapłani odśpiewali hymny.
###### **2Mch 1,31**
 Gdy spłonęła już cała ofiara, rozkazał Nehemiasz rozlać resztę wody na ogromne kamienie.
###### **2Mch 1,32**
 Skoro to uczynili, buchnął płomień, lecz pochłonął go blask bijący z ołtarza.
###### **2Mch 1,33**
 Wieść o tym wydarzeniu rozeszła się i królowi perskiemu doniesiono, że w miejscu, gdzie uprowadzeni kapłani ukryli ogień, ukazała się woda, którą Nehemiasz i jego ludzie oczyścili ofiarę.
###### **2Mch 1,34**
 Król zbadał sprawę, po czym ogrodził to miejsce i uznał je za święte.
###### **2Mch 1,35**
 Król szczodrze obdarzył kapłanów - sam przyjął liczne dary i wzajemnie się obdarowali.
###### **2Mch 1,36**
 Ludzie Nehemiasza nazywali [tę wodę] neftar, co znaczy oczyszczenie, większość jednak nazywa ją neftai.
# 2Mch 1 BR
###### **2Mch 1,1**
 My, bracia wasi, Żydzi z Jerozolimy i ziemi judzkiej, pozdrawiamy was, braci Żydów mieszkających w Egipcie, i życzymy wam pokoju.
###### **2Mch 1,2**
 Niech Bóg darzy was swoim dobrem i raczy pamiętać o przymierzu, które zawarł ze swoimi wiernymi sługami, Abrahamem, Izaakiem i Jakubem.
###### **2Mch 1,3**
 Niech wam wszystkim da jedno serce, abyście żyli Jego bojaźnią i zawsze byli gotowi odważnie pełnić Jego wolę.
###### **2Mch 1,4**
 Niech otworzy wasze serca na swoje prawo oraz przykazania i niech was obdarzy pokojem.
###### **2Mch 1,5**
 Niech wysłuchuje waszych modlitw, niech wam udzieli przebaczenia waszych win i nie pozostawia was w utrapieniu.
###### **2Mch 1,6**
 O to modlimy się tu dziś dla was.
###### **2Mch 1,7**
 Już za panowania Demetriusza, w roku sto sześćdziesiątym dziewiątym, my, Żydzi, napisaliśmy do was list takiej treści: Wśród największych nieszczęść, jakie na nas spadły w roku, kiedy to Jazon i jego zwolennicy zdradzili świętą ziemię i odpadli od królestwa,
###### **2Mch 1,8**
 kiedy to spalono bramy świątyni i przelano tyle niewinnej krwi, zaczęliśmy modlić się do Pana i On nas wysłuchał. Znów mogliśmy składać całopalenie i ofiary z pokarmów, zapalać światła na świeczniku i rozkładać chleby pokładne.
###### **2Mch 1,9**
 [Prosimy was tedy], żebyście również obchodzili święto Namiotów co roku w miesiącu Kislew. Piszemy ten list w roku sto osiemdziesiątym ósmym.
###### **2Mch 1,10**
 Mieszkańcy Jerozolimy oraz Judei, rada starszych i Jeuta, ślą życzenia radości i zdrowia Arystobulowi, nauczycielowi króla Ptolemeusza, pochodzącemu z rodu namaszczonych kapłanów, oraz wszystkim Żydom mieszkającym w Egipcie.
###### **2Mch 1,11**
 Z całego serca składamy dzięki Bogu za to, że nas wybawił z tak wielkich nieszczęść. Jesteśmy teraz gotowi stanąć do walki nawet z królem.
###### **2Mch 1,12**
 Sam Bóg usunął tych, którzy występowali przeciwko temu świętemu miastu.
###### **2Mch 1,13**
 Kiedy bowiem wódz z całym swoim dotąd nie pokonanym wojskiem udał się do Persji, wszyscy oni zginęli w świątyni bogini Nanai z rąk podstępnie działających jej kapłanów.
###### **2Mch 1,14**
 A było to tak: Pod pozorem zaślubin z boginią Nanają wszedł Antioch w otoczeniu swych przyjaciół do jej świątyni, żywiąc nadzieję, że wyniesie z niej - jako posag bogini - wielkie skarby.
###### **2Mch 1,15**
 Kapłani Nanai przygotowali wszystkie owe skarby jako posag bogini. Antioch z kilku swoimi przyjaciółmi wszedł na dziedziniec świątynny, a kiedy tylko znalazł się wewnątrz świątyni, kapłani natychmiast zamknęli bramy.
###### **2Mch 1,16**
 Zaraz też odsłonili otwór ukryty w stropie i zaczęli z góry zrzucać ciężkie kamienie, które roztrzaskały i wodza, i wszystkich mu towarzyszących. Potem porąbali ich ciała, odcięli im głowy i powyrzucali je tym, którzy zostali na zewnątrz.
###### **2Mch 1,17**
 Za wszystko to niech będzie błogosławiony Bóg nasz, bo to On zgotował zagładę grzesznikom.
###### **2Mch 1,18**
 Postanowiliśmy dwudziestego piątego dnia miesiąca Kislew obchodzić pamiątkę oczyszczenia świątyni. Uważamy za swój obowiązek powiadomić was o tym, żebyście wy również mogli obchodzić ten dzień jako święto Namiotów i Ognia, radując się z dokonanej przez Nehemiasza odbudowy świątyni i złożenia pierwszej ofiary na nowym ołtarzu.
###### **2Mch 1,19**
 Kiedy bowiem nasi ojcowie zostali skazani na wygnanie do Persji, wówczas pobożni kapłani wzięli nieco żaru od ołtarza i ukryli go na dnie wyschłej studni. Całe to miejsce tak zabezpieczyli, że nie było znane nikomu.
###### **2Mch 1,20**
 Upłynęło od tego czasu wiele lat. I oto spodobało się Bogu nakłonić króla perskiego, żeby zechciał wysłać tu Nehemiasza. Na jego polecenie mieli odnaleźć i przynieść znowu ten ogień kapłani, których ojcowie kiedyś go ukryli.
###### **2Mch 1,21**
 Gdy nam opowiedzieli, że nie znaleźli już żadnego ognia, tylko jakąś gęstą ciecz, powiedział im, żeby przynieśli trochę tej cieczy. Kiedy już wszystko było gotowe do złożenia ofiary, Nehemiasz polecił polać tym płynem drewno i wszystko, co było na stosie ofiarnym.
###### **2Mch 1,22**
 I zrobiono tak. Po jakimś czasie ukazało się spoza chmur słońce. Wtedy też buchnęły tak potężne płomienie,
###### **2Mch 1,23**
 że wszyscy inni, którzy byli tam obecni, zanosili do Boga modły. Jonatan rozpoczynał, a pozostali - wśród nich także Nehemiasz - dołączali się w głośnej modlitwie.
###### **2Mch 1,24**
 A oto słowa owej modlitwy: O Panie! Panie Boże i Stwórco wszechrzeczy! Boże straszny, mocny, sprawiedliwy i miłosierny. Tylko Ty jesteś królem, tylko Ty jesteś naszym dobroczyńcą.
###### **2Mch 1,25**
 Ty jeden dajesz nam wszystko! Tylko Ty jesteś sprawiedliwy, wszechmocny i wieczny! To Ty ratujesz Izraela ze wszystkich jego nieszczęść. Tyś wybrał i uświęcił naszych ojców.
###### **2Mch 1,26**
 Racz przyjąć tę ofiarę, którą składamy Ci za cały Twój lud izraelski! Strzeż Twojego dziedzictwa i zechciej je uświęcić!
###### **2Mch 1,27**
 Zbierz nas znowu razem, gdziekolwiek jesteśmy rozproszeni, uwolnij tych wszystkich, którzy dotąd jęczą w niewoli pogańskiej, wejrzyj łaskawie na wszystkich wzgardzonych i odrzuconych! Wtedy poznają narody pogańskie, że jesteś naszym Bogiem.
###### **2Mch 1,28**
 Ześlij słuszną karę na naszych zuchwałych ciemiężców!
###### **2Mch 1,29**
 Pozwól Twemu ludowi znowu zacząć wzrastać na tym świętym miejscu, jak tego pragnął Mojżesz.
###### **2Mch 1,30**
 W śpiewach hymnów pochwalnych uczestniczyli także kapłani, a śpiewom towarzyszyła muzyka.
###### **2Mch 1,31**
 Kiedy ofiara spłonęła, kazał Nehemiasz pozostały płyn wylać na wielkie kamienie.
###### **2Mch 1,32**
 I znów buchnął ku górze płomień, który jednak został wchłonięty przez ogień unoszący się znad ołtarza.
###### **2Mch 1,33**
 Wieść o tym wydarzeniu rozeszła się szeroko. Doniesiono też wkrótce królowi perskiemu, że na miejscu w którym kiedyś ci, co mieli iść na wygnanie, ukryli ogień, ukazała się ciecz, wydana następnie przez Nehemiasza i jego ludzi na ofiarę.
###### **2Mch 1,34**
 Kiedy król sam wszystko to sprawdził, kazał to miejsce ogrodzić i uznał za święte.
###### **2Mch 1,35**
 Król czerpał z owego miejsca wielkie korzyści i dzielił się nimi z tymi, którym chciał okazać życzliwość.
###### **2Mch 1,36**
 Ludzie Nehemiasza nazwali tę ciecz neftar, co znaczy oczyszczenie. Wielu nazywa ją też neftai.
# 2Mch 1 WUJ
