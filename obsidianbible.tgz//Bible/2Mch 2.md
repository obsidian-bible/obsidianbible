# 2Mch 2 BT5
###### **2Mch 2,1**
 ***W dokumentach można to znaleźć, że prorok Jeremiasz rozkazał, aby ci, którzy byli uprowadzeni do niewoli, wzięli ze sobą ogień. Tak było powiedziane***
###### **2Mch 2,2**
 ***i tak prorok przykazał tym, których uprowadzono do niewoli. Dał im Prawo, aby nie zapomnieli przykazań Pana i aby nie zamąciły się ich myśli, kiedy będą widzieli wizerunki [bóstw] złote i srebrne, a wokoło nich ozdoby.***
###### **2Mch 2,3**
 ***Tymi i podobnymi słowami upominał ich, aby nie dali usunąć Prawa ze swych serc.***
###### **2Mch 2,4**
 ***Było w tym piśmie [podane], jak na podstawie wyroczni, do niego skierowanej, prorok kazał nieść za sobą Namiot [Spotkania] i arkę, i jak wyszedł na górę, gdzie wszedłszy, Mojżesz obejrzał Boże dziedzictwo.***
###### **2Mch 2,5**
 ***Przyszedłszy tam, znalazł Jeremiasz pomieszczenie w postaci pieczary. Umieścił tam Namiot [Spotkania], arkę i ołtarz kadzenia, a wejście zarzucił kamieniami.***
###### **2Mch 2,6**
 ***Kilku z tych, którzy mu towarzyszyli, wróciło, aby zaznaczyć drogę, ale już nie mogli jej odnaleźć.***
###### **2Mch 2,7**
 ***Kiedy zaś Jeremiasz dowiedział się o tym, zganił ich i powiedział: Miejsce to pozostanie nieznane, aż Bóg na powrót zgromadzi swój lud i okaże mu miłosierdzie.***
###### **2Mch 2,8**
 ***Wtedy to Pan ponownie pokaże to [wszystko] i będzie można oglądać chwałę Pańską i obłok, podobnie jak za Mojżesza można ją było widzieć i jak wtedy, gdy Salomon modlił się, aby miejsce zostało w uroczysty sposób poświęcone.***
###### **2Mch 2,9**
 ***Wyjaśniono również, jak on pełen mądrości złożył ofiarę przy poświęceniu i zakończeniu budowy świątyni.***
###### **2Mch 2,10**
 ***Podobnie jak Mojżesz modlił się do Pana, a spadł ogień z nieba i pochłonął to, co złożono w ofierze, tak również Salomon modlił się, a ogień, który spadł, strawił całopalne żertwy.***
###### **2Mch 2,11**
 ***Mojżesz powiedział: Zostało spalone, aby nikt nie jadł tego, co jest ofiarowane za grzech.***
###### **2Mch 2,12**
 ***Podobnie również Salomon przez osiem dni świętował.***
###### **2Mch 2,13**
 ***W pismach i pamiętnikach Nehemiasza jest opowiedziane nie tylko to, ale również o tym, jak zakładając bibliotekę, zebrał on księgi o królach i księgi proroków, księgi Dawida i listy królów o ofiarach.***
###### **2Mch 2,14**
 ***Tak samo również Juda pozbierał nam wszystkie księgi, które były rozrzucone wskutek prowadzonej wojny, i mamy je u siebie.***
###### **2Mch 2,15**
 ***Jeżeli więc potrzebujecie ich, przyślijcie tych, którzy by wam je zanieśli.***
###### **2Mch 2,16**
 ***Piszemy do was, mając obchodzić Uroczystość Oczyszczenia [Świątyni]. Dobrze więc uczynicie, świętując w te dni.***
###### **2Mch 2,17**
 ***Bóg zaś jest Tym, który wybawił cały swój lud i który dał wszystkim dziedzictwo, królestwo, kapłaństwo i uświęcenie,***
###### **2Mch 2,18**
 ***zgodnie z tym, co obiecał w Prawie, albowiem w Bogu pokładamy nadzieję, że niebawem nad nami się zmiłuje i zgromadzi nas zewsząd spod nieba na miejsce święte. Wyzwolił nas bowiem z wielkich nieszczęść i miejsce to oczyścił***».
###### **2Mch 2,19**
 Opowiadanie o Judzie Machabeuszu i o jego braciach, o oczyszczeniu największej świątyni i o poświęceniu ołtarza,
###### **2Mch 2,20**
 ponadto o walkach przeciwko Antiochowi Epifanesowi i przeciw jego synowi, Eupatorowi,
###### **2Mch 2,21**
 o objawieniach pochodzących z nieba, jakie mieli ci, którzy w obronie żydowskiego obyczaju dokonywali czynów tak mężnych, że chociaż byli nieliczni, to jednak opanowali cały kraj i wypędzili barbarzyńskie wojska,
###### **2Mch 2,22**
 odzyskali ponownie słynną na cały świat świątynię, uwolnili miasto, prawom, które miały być zniesione, nadali moc obowiązującą – gdyż Pan w całej swej dobroci był dla nich łaskawy –
###### **2Mch 2,23**
 wszystko to, co Jazon Cyrenejczyk opisał w pięciu księgach, usiłowaliśmy streścić w jednym dziele.
###### **2Mch 2,24**
 Mając bowiem na uwadze mnogość liczb i trudność, jaką bogactwo materiału sprawia tym, którzy chcieliby się zagłębić w opowiadania historyczne,
###### **2Mch 2,25**
 usiłowaliśmy dać tym, którzy chcą czytać, przyjemne opowiadanie; tym, którzy w pamięci zachować [chcą wypadki], ułatwienie, a wszystkim czytelnikom – pomoc.
###### **2Mch 2,26**
 Dla nas zaś samych, którzy podjęliśmy się trudu skracania, było to niełatwe [zadanie]: dzieło wymagające znoju i niedosypiania.
###### **2Mch 2,27**
 Podobnie niełatwo jest temu, kto przygotowuje ucztę i pragnie zaspokoić upodobania innych. My również dlatego chętnie podjęliśmy się trudu, aby zasłużyć na wdzięczność wielu.
###### **2Mch 2,28**
 Troskę o dokładne zbadanie poszczególnych faktów pozostawiamy historykowi, sami zaś usiłujemy ułożyć streszczenie opowiadania.
###### **2Mch 2,29**
 Podobnie bowiem jak w nowym domu budowniczy musi się zajmować całą budowlą, a ten, kto się podejmuje enkaustycznego malowania, zajmuje się tylko tym, co dotyczy wystroju, tak samo, jak się to wydaje, jest z nami.
###### **2Mch 2,30**
 Zagłębić się i swobodnie obracać się w opowiadaniach oraz dokładnie rozpoznać się w szczegółach, to zadanie tego, który układa historię.
###### **2Mch 2,31**
 Temu zaś, kto dokonuje streszczenia, należy pozwolić, by ułożył w krótkości opowiadanie z pominięciem szczegółowego przedstawienia wydarzeń.
###### **2Mch 2,32**
 Teraz więc, po tak długim zatrzymywaniu się nad wstępem, rozpoczynamy opowiadanie. Niemądrze byłoby bowiem zbytnio się rozwodzić przed rozpoczęciem historii, a samą historię przedstawić krótko.
# 2Mch 2 PAU
###### **2Mch 2,1**
 W dokumentach można znaleźć informację, że prorok Jeremiasz nakazał wygnańcom zabrać ogień, co już zostało powiedziane.
###### **2Mch 2,2**
 Prorok, dając wygnańcom Prawo, polecił, aby nie zapominali o przykazaniach PANA i aby nie dali się zwieść widokiem posągów ze złota i srebra oraz znajdujących się wokół nich ozdób.
###### **2Mch 2,3**
 W licznych, podobnych słowach zachęcał ich, aby nie wyrzucali Prawa ze swoich serc.
###### **2Mch 2,4**
 To pismo mówi także o tym, że prorok otrzymał od Boga pouczenie, aby namiot i arka towarzyszyły mu w drodze na górę, na którą niegdyś wszedł Mojżesz, aby podziwiać dziedzictwo Boże.
###### **2Mch 2,5**
 Gdy Jeremiasz tam przyszedł, znalazł grotę i umieścił w niej namiot, arkę i ołtarz kadzielny, a wejście zabarykadował.
###### **2Mch 2,6**
 Niektórzy z jego towarzyszy przyszli później, aby oznakować drogę, ale nie mogli znaleźć groty.
###### **2Mch 2,7**
 Gdy Jeremiasz dowiedział się o tym, skarcił ich, mówiąc: «Miejsce to pozostanie nieznane, dopóki Bóg nie zgromadzi ludu i nie okaże miłosierdzia.
###### **2Mch 2,8**
 Wtedy PAN wskaże te rzeczy. Pojawi się chwała PANA i obłok, jak było za czasów Mojżesza i wtedy, gdy Salomon modlił się, aby świątynia została uroczyście poświęcona».
###### **2Mch 2,9**
 Jest tam też mowa o tym, jak Salomon, który miał dar mądrości, złożył ofiarę z okazji poświęcenia i ukończenia budowy świątyni.
###### **2Mch 2,10**
 Podobnie jak Mojżesz modlił się do PANA, a zstąpił ogień z nieba i spalił ofiary, tak też modlił się Salomon i ogień zstępujący z góry pochłonął całopalne ofiary.
###### **2Mch 2,11**
 Mojżesz powiedział: «Ofiarę za grzechy spalono, aby nie została spożyta».
###### **2Mch 2,12**
 W ten sam sposób również Salomon świętował osiem dni.
###### **2Mch 2,13**
 To samo opisują dokumenty i pamiętniki Nehemiasza. Mówią one również o tym, jak założył on bibliotekę, zebrał księgi o królach, prorokach i o Dawidzie oraz pisma królów dotyczące darów ofiarnych.
###### **2Mch 2,14**
 Podobnie też Juda zgromadził dokumenty rozproszone w wyniku wojny, która u nas była, i mamy je u siebie.
###### **2Mch 2,15**
 Jeśli więc ich potrzebujecie, przyślijcie do nas kogoś, kto wam je dostarczy.
###### **2Mch 2,16**
 Piszemy do was, przygotowując się do świętowania Oczyszczenia. Dobrze uczynicie, świętując te dni.
###### **2Mch 2,17**
 Bóg jest tym, który ocalił cały swój lud, zwrócił wszystkim dziedzictwo, królestwo, kapłaństwo i świętość,
###### **2Mch 2,18**
 jak obiecał w Prawie. Ufamy więc Bogu, że szybko zlituje się nad nami i zgromadzi nas ze wszystkich stron świata w miejscu świętym. Wybawił nas bowiem z wielkich nieszczęść i oczyścił to miejsce”.
###### **2Mch 2,19**
 Opowiadanie o Judzie Machabeuszu i jego braciach, o oczyszczeniu świątyni Najwyższego i poświęceniu ołtarza, a także
###### **2Mch 2,20**
 o wojnach przeciwko Antiochowi Epifanesowi i jego synowi Eupatorowi,
###### **2Mch 2,21**
 o pochodzących z nieba objawieniach dla tych, którzy tak mężnie walczyli o judaizm, że chociaż nieliczni, odbili cały kraj i przepędzili barbarzyńskie narody,
###### **2Mch 2,22**
 odzyskali słynną na całym świecie świątynię, uwolnili miasto oraz przywrócili prawa, które chciano znieść. Dokonali tego, ponieważ PAN darzył ich łaską z całą łagodnością.
###### **2Mch 2,23**
 Staraliśmy się streścić w jednym dziele to wszystko, co Jazon Cyrenejczyk opisał w pięciu księgach.
###### **2Mch 2,24**
 Zauważyliśmy bowiem, że ci, którzy pragną zagłębić się w opowiadania historii, napotykają na trudność z powodu bardzo wielu liczb oraz mnogości szczegółów.
###### **2Mch 2,25**
 Dlatego tym, którzy chcą ją czytać, postanowiliśmy dostarczyć przyjemności; tym, którzy pragną ją zapamiętać - pomocy; a wszystkim, którzy się z nią zetkną - pożytku.
###### **2Mch 2,26**
 Nam zaś samym, którzy podjęliśmy się dokonania niełatwego zadania streszczenia, sprawa ta przysporzyła trudu i bezsenności,
###### **2Mch 2,27**
 podobnie jak niełatwo jest temu, kto przygotowuje ucztę i pragnie zadowolić biesiadników. My jednak chętnie ponieśliśmy ten trud, aby zaskarbić sobie wdzięczność wielu.
###### **2Mch 2,28**
 Troskę o szczegóły historyczne pozostawiamy historykowi, my natomiast zajęliśmy się opracowaniem streszczenia.
###### **2Mch 2,29**
 Architekt nowego domu musi troszczyć się o całą budowlę, ten zaś, kto chce go upiększyć i ozdobić malowidłami, stara się tylko o materiały do ozdoby. Myślę, że podobnie jest również z nami.
###### **2Mch 2,30**
 Pogłębienie i uporządkowanie faktów oraz ich szczegółowa analiza - to zadanie historyka.
###### **2Mch 2,31**
 Temu zaś, kto przygotowuje streszczenie, należy pozwolić na skrócenie tekstu i pominięcie szczegółów.
###### **2Mch 2,32**
 W tym miejscu rozpoczynamy opowiadanie, nie dodając już nic do tego, co powiedzieliśmy. Byłoby bowiem nierozsądne rozwodzić się nad wstępem do historii, a skracać samą historię.
# 2Mch 2 BP
###### **2Mch 2,1**
 W dokumentach znajduje się [wiadomość] o tym, że prorok Jeremiasz rozkazał przesiedleńcom zabrać ogień, jak to było powiedziane.
###### **2Mch 2,2**
 Prorok też dał im Księgę Prawa i polecił uprowadzonym do niewoli, by nie zapomnieli o przykazaniach Pana i nie dali się zwieść w swych myślach widokiem wspaniale zdobionych bożków ze złota i srebra.
###### **2Mch 2,3**
 Pośród innych upomnień wzywał ich, aby nigdy nie wyrzucili Prawa ze swoich serc.
###### **2Mch 2,4**
 Było w tymże piśmie [zapisane], że z [Bożego] objawienia rozkazał prorok nieść za sobą namiot i Arkę, gdy udawał się na górę, na którą niegdyś wstąpił Mojżesz oglądając dziedzictwo Boga.
###### **2Mch 2,5**
 Przybywszy tam znalazł obszerną grotę, w której złożył Namiot, Arkę i ołtarz kadzenia, wejście zaś zasypał kamieniami.
###### **2Mch 2,6**
 Kilku spośród towarzyszących mu [ludzi] wróciło [potem], aby oznaczyć drogę, lecz nie mogli jej odnaleźć.
###### **2Mch 2,7**
 Skoro się o tym dowiedział Jeremiasz, zganił ich mówiąc, że miejsce to pozostanie nie znane do czasu, aż Bóg zgromadzi lud i okaże mu miłosierdzie.
###### **2Mch 2,8**
 Wówczas znowu pokaże Pan wszystkie te rzeczy i objawi się chwała pańska wraz z obłokiem, jak objawiła się za Mojżesza, i wtedy, gdy Salomon prosił, aby miejsce to zostało uroczyście poświęcone.
###### **2Mch 2,9**
 Opowiadano również [w tym piśmie], jak [król] mając dar mądrości składał ofiarę przy poświęceniu Świątyni i wykończeniu,
###### **2Mch 2,10**
 jak Mojżesz modlił się do Pana i zstąpił ogień z nieba spalając ofiarę, jak Salomon wznosił modły, a ogień pojawił się i strawił całopalną ofiarę.
###### **2Mch 2,11**
 Wówczas to rzekł Mojżesz: Ponieważ nie spożywano ofiary za grzechy, dlatego została spalona.
###### **2Mch 2,12**
 Podobnie Salomon obchodził święto przez osiem dni.
###### **2Mch 2,13**
 Pisma i wspomnienia Nehemiasza opowiadają nie tylko o tym, lecz także, jak zakładając bibliotekę zebrał księgi o królach, pisma Proroków, księgi Dawida oraz listy królów o darach ofiarnych.
###### **2Mch 2,14**
 Podobnie Juda zgromadził wszystkie [księgi] rozproszone w czasie prowadzonej przez nas wojny i mamy je u siebie.
###### **2Mch 2,15**
 Jeśli któraś z nich jest wam potrzebna, przyślijcie posłańców celem jej odebrania.
###### **2Mch 2,16**
 Zamierzając obchodzić uroczystość oczyszczenia, napisaliśmy do was. Dobrze uczynicie zatem świętując te dni.
###### **2Mch 2,17**
 Bóg ocalił cały swój naród i wszystkim przywrócił dziedzictwo, królestwo, kapłaństwo i uświęcenie,
###### **2Mch 2,18**
 jak to zapowiedział w Prawie. W Bogu więc pokładamy nadzieję, że wkrótce zlituje się nad nami i zgromadzi nas ze wszystkich krain, które są pod niebem na [to] miejsce święte, wybawił nas bowiem z wielkich nieszczęść i oczyścił [święte] miejsce.
###### **2Mch 2,19**
 Dzieje Judy Machabeusza i jego braci, oczyszczenie wspaniałej Świątyni i poświęcenie ołtarza,
###### **2Mch 2,20**
 dalej - wojny z Antiochem Epifanesem i jego synem Eupatorem,
###### **2Mch 2,21**
 objawienie zesłane z nieba tym, którzy w obronie Izraela tak dzielnie walczyli, że - chociaż nieliczni - zdobyli na nowo cały kraj, wypędzili barbarzyńców,
###### **2Mch 2,22**
 odzyskali słynną w całym świecie Świątynię, oswobodzili Miasto i - ponieważ Pan w swej wielkiej dobroci był dla nich łaskawy - przywrócili znaczenie prawom, które poczęto lekceważyć -
###### **2Mch 2,23**
 wszystko to zebrane przez Jazona Cyrenejczyka w pięciu księgach spróbujemy streścić w jednej księdze.
###### **2Mch 2,24**
 Biorąc pod uwagę znaczną ilość ksiąg i spowodowane obfitością materiału trudności, na jakie natrafiają pragnący zagłębić się w wywody historyczne,
###### **2Mch 2,25**
 zamierzamy sprawić przyjemność tym, którzy chętnie czytają, dać ułatwienie tym, którzy chcą przyswoić sobie materiał pamięciowo, a dopomóc wszystkim, którym ta księga wpadnie w ręce.
###### **2Mch 2,26**
 I dla nas podjęty trud sporządzenia skrótu nie jest łatwy - praca ta wymaga wielkiego znoju i nieprzespanych nocy.
###### **2Mch 2,27**
 Podobnie trudzi się ten, kto przygotowuje ucztę, pragnąc innym sprawić przyjemność. Jednakże chętnie podejmujemy ten ciężki trud, aby zaskarbić sobie wdzięczność wielu [czytelników].
###### **2Mch 2,28**
 Pozostawiając sprawę wiarygodności szczegółów autorowi [dzieła], sami postaramy się jedynie o sporządzenie poprawnego streszczenia.
###### **2Mch 2,29**
 Podobnie jak budowniczy nowego domu troszczyć się musi o całość budowli, a ten, kto podejmuje się ozdobić go rysunkami i malowidłami, zajmuje się tylko tym, co należy do dekoracji, tak też - moim zdaniem - ma się rzecz i z nami.
###### **2Mch 2,30**
 Zagłębienie się w fakty i wszechstronne ich zbadanie oraz skrupulatne rozpoznanie szczegółów należy do tego, kto pierwszy pisze historię.
###### **2Mch 2,31**
 Ten natomiast, kto dokonuje formalnej przeróbki, dążyć musi do zwięzłości w opowiadaniu i unikać szczegółowego przedstawiania wydarzeń.
###### **2Mch 2,32**
 Zacznijmy więc opowiadanie, gdyż zbyt długo już zatrzymujemy się nad uwagami wstępnymi. Byłoby bowiem rzeczą nieroztropną rozwodzić się zbytnio we wstępie do historii, a w samej historii czynić skróty.
# 2Mch 2 BR
###### **2Mch 2,1**
 Z dokumentów wynika, że to prorok Jeremiasz nakazał wygnańcom zabrać - jak już o tym była mowa - trochę żaru [z ołtarza całopalenia].
###### **2Mch 2,2**
 Prorok zobowiązał również wygnańców specjalnym dekretem do pamięci o przykazaniach pańskich i upomniał ich, żeby nie pobłądzili w swoich sercach, kiedy będą patrzeć na złote i srebrne podobizny bożków oraz ich różne ozdoby.
###### **2Mch 2,3**
 Wielokrotnie w podobny sposób upominał ich, żeby nie pozwolili sobie wymazać prawa wypisanego w ich sercach.
###### **2Mch 2,4**
 W dokumentach tych było też napisane, że prorok otrzymał od Boga polecenie, zgodnie z którym Żydzi mieli posiadać zawsze namiot i arkę Bożą. Prorok ów wstąpił też podobno na tę samą górę, na której był kiedyś Mojżesz i z której oglądał obiecane przez Boga dziedzictwo.
###### **2Mch 2,5**
 Otóż na górze tej znalazł Jeremiasz jaskinię, wielką jak dom. Umieścił tam namiot, arkę i ołtarz kadzenia. Potem wejście do jaskini zasypał kamieniami.
###### **2Mch 2,6**
 Kilku z jego ludzi później próbowało tam dotrzeć, żeby zaznaczyć drogę, ale jaskini już nie odnaleźli.
###### **2Mch 2,7**
 Gdy dowiedział się o tym Jeremiasz, skarcił ich, mówiąc: Miejsce to ma pozostać nieznane, dopóki Bóg ponownie nie zgromadzi całego swojego ludu i nie okaże mu swojego miłosierdzia.
###### **2Mch 2,8**
 I wtedy sam Pan ujawni to wszystko. Ukaże się też chwała Pańska i obłok, tak jak to było za dni Mojżesza oraz wtedy, kiedy Salomon modlił się, aby miejsce owo zostało poświęcone.
###### **2Mch 2,9**
 Potem jest opowiedziane w księdze o ofiarach jakie ów mądry [Salomon] złożył przy poświęceniu i ukończeniu budowy świątyni.
###### **2Mch 2,10**
 Jak kiedyś Mojżesz modlił się do Pana i spadł z nieba ogień i pochłonął ofiarę, tak modlił się również Salomon i podobnie spadł z nieba ogień i strawił całą ofiarę.
###### **2Mch 2,11**
 Mojżesz powiedział wtedy: ponieważ nie spożyto ofiary złożonej za grzechy, pochłonął ją ogień.
###### **2Mch 2,12**
 Podobnie przez osiem dni świętował także Salomon.
###### **2Mch 2,13**
 To samo jest opowiedziane w pismach i w pamiętnikach Nehemiasza. Ponadto jest w nich mowa o bibliotece, w której zgromadził on nie tylko księgi o królach i księgi proroków, lecz także pieśni [Dawida] i pouczenia królów o składaniu ofiar.
###### **2Mch 2,14**
 Również Juda zebrał wszystkie owe księgi, które podczas prowadzonych przez niego wojen zostały rozproszone. Dziś znowu wszystkie znajdują się u nas.
###### **2Mch 2,15**
 Gdyby jednak okazało się, że niektórych z nich nie macie, to sprowadźcie je od nas przez specjalnych wysłanników.
###### **2Mch 2,16**
 Piszemy wam o tym wszystkim, gdyż przystępujemy do obchodów święta Oczyszczenia świątyni. Dobrze zrobicie, jeśli te dni również będziecie obchodzili uroczyście.
###### **2Mch 2,17**
 Bóg uratował cały swój lud, całe jego dziedzictwo, jego panowanie, kapłanów i świątynię,
###### **2Mch 2,18**
 tak jak to przyobiecał w swoim prawie. Mamy zatem nadzieję, że już wkrótce Bóg także nam okaże swoje miłosierdzie i zbierze nas z całego świata, i zgromadzi na swoim świętym miejscu. On bowiem wybawił nas już od tylu nieszczęść i sam dokonał oczyszczenia miejsca świętego.
###### **2Mch 2,19**
 Opowiadanie o czynach Machabeuszy, Judy i jego braci, o tym jak dokonywali oczyszczenia wspaniałej świątyni i poświęcali na nowo zbudowany ołtarz,
###### **2Mch 2,20**
 o wojnach, jakie prowadzili z Antiochem Epifanesem i jego synem Eupatorem,
###### **2Mch 2,21**
 o objawieniach, jakich same niebiosa udzielały sławnym i walecznym obrońcom obyczajów żydowskich, dzięki czemu udało się im, choć byli nieliczni, cały kraj znów objąć w posiadanie, po usunięciu z niego licznych barbarzyńców,
###### **2Mch 2,22**
 [o tym], jak zdołali odzyskać sławną w całym świecie świątynię, uwolnić miasto, przywrócić na nowo moc obowiązującą zapomnianym prawom, bo Pan okazywał im wielkie miłosierdzie swoje -
###### **2Mch 2,23**
 niejaki Jazon z Cyreny zawarł w pięciu księgach, my zaś spróbujemy streścić jego opowieść w jednej księdze.
###### **2Mch 2,24**
 Zauważyliśmy bowiem, że jest w tych opowiadaniach bardzo dużo liczb oraz ogromne bogactwo szczegółów historycznych, co utrudnia śledzenie ich toku.
###### **2Mch 2,25**
 Dlatego postanowiliśmy przyjść z pomocą tym, którzy mieliby ochotę czytać owe opowiadania, a także tym, którzy pewnych rzeczy zapragnęliby nauczyć się na pamięć. Zresztą chcielibyśmy, żeby pewne korzyści odniósł z czytania tej księgi każdy, kto weźmie ją do ręki.
###### **2Mch 2,26**
 Nie przyszło nam łatwo opracować ten wyciąg. Kosztowało nas to wiele trudu i mnóstwo nieprzespanych nocy.
###### **2Mch 2,27**
 Niełatwe zadanie stoi przed tym, kto przygotowuje ucztę i pragnie zaspokoić upodobania wszystkich zaproszonych. Mimo to chętnie podjęliśmy się tego trudu i jesteśmy przekonani, że zaskarbimy sobie wdzięczność wielu.
###### **2Mch 2,28**
 Troskę o drobne szczegóły pozostawiamy zawodowemu dziejopisowi. My ograniczyliśmy się w naszym przedsięwzięciu do opracowania streszczenia.
###### **2Mch 2,29**
 Kiedy buduje się nowy dom, potrzebny jest budowniczy, który czuwa nad wszystkimi pracami. Natomiast ci, którzy mają ozdobić i pomalować nowy dom, troszczą się jedynie o to, co jest konieczne do jego wystroju. Podobnie rzecz się ma i z naszym zadaniem.
###### **2Mch 2,30**
 Do dziejopisarza należeć będzie ocena i zbadanie wszystkich danych.
###### **2Mch 2,31**
 Ten zaś, kto bierze się do zwięzłego streszczania [dłuższej opowieści], powinien unikać gromadzenia zbyt wielu szczegółów, nawet za cenę niepełnego przedstawienia całej sprawy.
###### **2Mch 2,32**
 A teraz przystępujemy do naszego opowiadania, gdyż i tak zbyt wiele czasu poświęciliśmy na to wprowadzenie. Nie jest przecież rzeczą słuszną wydłużać wprowadzenie, a samo opowiadanie skracać.
# 2Mch 2 WUJ
