# Dn 4 BT5
###### **Dn 4,1**
 Ja, Nabuchodonozor, zażywałem spokoju w swoim domu i radości w swoim pałacu.
###### **Dn 4,2**
 Miałem widzenie we śnie, które mnie przeraziło. Zaniepokoiły mnie myśli na moim łożu i widziadła [powstałe] w mojej głowie.
###### **Dn 4,3**
 Toteż wydałem polecenie, by sprowadzono do mnie wszystkich mędrców babilońskich, żeby mi dali wyjaśnienie snu.
###### **Dn 4,4**
 Zjawili się więc tłumaczący sny, wróżbici, Chaldejczycy i astrologowie. Opowiedziałem im sen, ale nie mogli mi podać jego wyjaśnienia.
###### **Dn 4,5**
 W końcu przybył do mnie Daniel, któremu na imię według imienia mojego boga Belteszassar, a w którym mieszka duch świętych bogów. Opowiedziałem mu sen:
###### **Dn 4,6**
 Belteszassarze, przełożony tłumaczących sny! Wiem, że w tobie mieszka duch świętych bogów i że żadna tajemnica nie stanowi dla ciebie trudności. Oto mój sen, który widziałem; wyjaśnij mi go!
###### **Dn 4,7**
 W mojej głowie, na moim łożu, widziałem takie obrazy:Patrzyłem, a oto –drzewo w środku ziemi, a jego wysokość ogromna.
###### **Dn 4,8**
 Drzewo wzrastało potężnie, wysokością swą sięgało nieba, widać je było aż po krańce ziemi.
###### **Dn 4,9**
 Liście jego były piękne, a owoce obfite, dawało ono pożywienie wszystkim. Pod nim szukały cienia dzikie zwierzęta, na jego gałęziach mieszkały ptaki podniebne,nim się żywiło wszelkie ciało.
###### **Dn 4,10**
 Patrzyłem, w moim łożu, na obrazy w moim umyśle, a oto Czuwający i Święty zstępował z nieba.
###### **Dn 4,11**
 Wołał on głośno i tak mówił:Wyrąbcie drzewo i obetnijcie gałęzie, otrząśnijcie liście i odrzućcie owoce!Zwierzęta niech uciekają spod niego, a ptaki z jego gałęzi!
###### **Dn 4,12**
 Lecz pień jego korzenipozostawcie w ziemi, i to w okowach z żelaza i brązu, wśród polnej zieleni. Niech zwilża go rosa z nieba, a trawę polną niechaj dzielize zwierzętami!
###### **Dn 4,13**
 Jego ludzkie serce niech ulegnie odmianie, a niech otrzyma serce zwierzęce; siedem okresów niech nad nim przeminie!
###### **Dn 4,14**
 Według postanowienia Czuwających [taki jest] dekret, sprawa rozstrzygnięta przez Świętych, aby wszyscy żyjący wiedzieli, że Najwyższy jest władcą nad królestwem ludzkim. Może je dać, komu zechce, może ustanowić nad nimi najniższego z ludzi.
###### **Dn 4,15**
 Taki jest sen, jaki widziałem, ja, król Nabuchodonozor. Teraz zaś, Belteszassarze, podaj mi jego znaczenie, bo wszyscy mędrcy z mojego kraju nie potrafili go wyjaśnić, ty zaś możesz, bo posiadasz ducha świętych bogów***».
###### **Dn 4,16**
 Wówczas Daniel, który nosił imię Belteszassar, popadł na chwilę w stan oszołomienia, a jego myśli zaniepokoiły go. Król zaś odezwał się i rzekł: «***Niech sen i jego wykład nie wprawiają ciebie w niepokój, Belteszassarze!***» Belteszassar odpowiedział: «*** Panie mój, oby sen [odnosił się] do twoich wrogów, a jego wyjaśnienie do twoich przeciwników!
###### **Dn 4,17**
 Drzewem, które ujrzałeś, jak rosło i stało się potężne, tak że swą wysokością sięgało nieba i było widoczne na całej ziemi,
###### **Dn 4,18**
 którego liście były piękne, a owoce obfite, na którym było pożywienie dla wszystkich, pod którym przebywały dzikie zwierzęta i na którego gałęziach gnieździły się ptaki podniebne –
###### **Dn 4,19**
 jesteś ty, o królu. Wzrosłeś i stałeś się potężny, a wielkość twoja wzrastała i sięgała aż do nieba, panowanie zaś twoje aż po krańce świata.
###### **Dn 4,20**
 To natomiast, że król widział Czuwającego i Świętego zstępującego z nieba i mówiącego: Wyrąbcie drzewo i zniszczcie je, tylko pień jego korzeni pozostawcie w ziemi, i to w żelaznych i brązowych okowach, wśród polnej zieleni; niech go zwilża rosa z nieba, niech dzieli los ze zwierzętami polnymi, aż upłynie nad nim siedem okresów –
###### **Dn 4,21**
 to jest wyjaśnienie, królu, i postanowienie Najwyższego, które dopełni się na królu, moim panu.
###### **Dn 4,22**
  Wypędzą cię spośród ludzi i będziesz przebywał wśród dzikich zwierząt. Tak jak wołom będą ci dawać trawę do jedzenia, a rosa z nieba będzie cię zwilżać. Siedem okresów upłynie nad tobą, aż uznasz, że Najwyższy panuje nad królestwem ludzkim i powierza je, komu zechce.
###### **Dn 4,23**
 To zaś, że wydano polecenie, by zostawić pień i korzenie, [oznacza, iż] pozostawią ci królestwo, gdy uznasz, że Niebo sprawuje władzę.
###### **Dn 4,24**
 Dlatego, królu, przyjmij moją radę i okup swe grzechy uczynkami sprawiedliwymi, a swoje nieprawości miłosierdziem nad ubogimi; wtedy może twa pomyślność okaże się trwała***».
###### **Dn 4,25**
 Wszystko to spełniło się na królu Nabuchodonozorze.
###### **Dn 4,26**
 Po upływie dwunastu miesięcy, gdy przechadzał się na tarasie królewskiego pałacu w Babilonie,
###### **Dn 4,27**
 król odezwał się i powiedział: «***Czy nie jest to wielki Babilon, który ja zbudowałem jako królewską siedzibę siłą mojej potęgi i chwałą mojego majestatu?***»
###### **Dn 4,28**
 Nim król wypowiedział swoje słowo, padł głos z nieba: «***Otrzymujesz zapowiedź, królu Nabuchodonozorze! Panowanie cię odstąpiło;
###### **Dn 4,29**
 zostaniesz wypędzony spośród ludzi. Będziesz mieszkał wśród dzikich zwierząt i będą ci dawać jak wołom trawę na pokarm. Siedem okresów upłynie nad tobą, aż uznasz, że Najwyższy panuje nad królestwem ludzkim***».
###### **Dn 4,30**
 Natychmiast wypełniła się zapowiedź na Nabuchodonozorze. Wypędzono go spośród ludzi, żywił się trawą jak woły, a rosa z nieba obmywała go. Włosy jego urosły niby [pióra] orła, paznokcie zaś jego jak [pazury] ptaka.
###### **Dn 4,31**
 «***Gdy zaś upłynęły oznaczone dni, ja, Nabuchodonozor, podniosłem oczy ku niebu. Wtedy powrócił mi rozumi wysławiałem Najwyższego, wielbiłem i chwaliłem Żyjącego na wieki, bo Jego władza jest władzą wieczną, panowanie Jego z pokolenia na pokolenie.
###### **Dn 4,32**
 Wszyscy mieszkańcy zieminic nie znaczą;według swojej wolipostępuje On z niebieskimi zastępami. Nie ma nikogo, kto by mógł powstrzymać Jego ramięi kto by Mu powiedział: Co czynisz?
###### **Dn 4,33**
 W tej samej chwili powrócił mi rozum i na chwałę Jego panowania powrócił mój majestat i blask. Doradcy moi i możnowładcy odszukali mnie i przywrócili mi władzę królewską, i dano mi jeszcze większy zakres władzy.
###### **Dn 4,34**
 Ja, Nabuchodonozor, wychwalam teraz, wywyższam i wysławiam Króla nieba. Bo wszystkie Jego dzieła są prawdą, a drogi Jego – sprawiedliwością, tych zaś, co postępują pysznie, może On poniżyć***».
# Dn 4 PAU
###### **Dn 4,1**
 Ja, Nabuchodonozor, żyłem spokojnie w swoim domu i byłem szczęśliwy we własnym pałacu.
###### **Dn 4,2**
 Lecz miałem sen, który mnie przestraszył. Przeraziły mnie senne mary i widzenia.
###### **Dn 4,3**
 Dlatego rozkazałem, żeby stawili się przede mną wszyscy mędrcy Babilonu i wyjaśnili, co ten sen oznacza.
###### **Dn 4,4**
 Kiedy przyszli wszyscy wróżbici, magowie, chaldejczycy i astrologowie, opowiedziałem im sen, ale oni nie potrafili powiedzieć, co oznacza.
###### **Dn 4,5**
 Potem stawił się przede mną Daniel, którego imię brzmi Belteszassar, zgodnie z imieniem mojego boga. Ma on ducha świętych bogów, więc opowiedziałem mu swój sen:
###### **Dn 4,6**
 «Belteszassarze, przełożony mędrców, wiem, że masz ducha świętych bogów i że żadna tajemnica nie jest dla ciebie zbyt trudna do odkrycia. Miałem sen, a ty powiedz, jakie jest jego znaczenie.
###### **Dn 4,7**
 Oto takie widzenie miałem na moim łożu: Pośrodku ziemi było bardzo wysokie drzewo.
###### **Dn 4,8**
 Rosło i stawało się coraz mocniejsze, wierzchołkiem sięgało nieba i było widoczne aż po krańce ziemi.
###### **Dn 4,9**
 Liście jego były piękne, a owoce wspaniałe. Było na nim pożywienie dla każdego. Pod nim miały swoje legowiska wszystkie dzikie zwierzęta, w jego gałęziach gnieździły się dzikie ptaki, a ono dawało pożywienie wszystkim.
###### **Dn 4,10**
 W widzeniu, które miałem na moim łożu, zobaczyłem, jak strażnik, święty, schodził z nieba.
###### **Dn 4,11**
 Wołał głośno i tak mówił: ‘Zwalcie drzewo i odłamcie jego gałęzie, usuńcie liście i zniszczcie jego owoce, niech zwierzęta uciekają spod niego i ptaki z jego gałęzi.
###### **Dn 4,12**
 Jednak sam jego korzeń pozostawcie w ziemi, w okowach z żelaza i brązu. Niech zarośnie polną trawą, niech zwilża go rosa z nieba, niech je trawę, jak dzikie zwierzęta.
###### **Dn 4,13**
 Jego ludzkie serce będzie mu zabrane, a otrzyma serce zwierzęce. Niech przeminie nad nim siedem lat’.
###### **Dn 4,14**
 Stało się to z wyroku strażników, sprawa ta - z rozkazu świętych, aby żyjący wiedzieli o tym, że Najwyższy panuje nad królestwem ludzkim, że może je dać, komu zechce, i że najmniejszego z ludzi może postawić nad nim.
###### **Dn 4,15**
 Taki sen miałem ja, król Nabuchodonozor, a ty, Belteszassarze, w obecności wszystkich mędrców mojego królestwa powiedz, co on oznaczał. Bo oni nie potrafili powiedzieć, jakie jest jego znaczenie. Ty jednak potrafisz, bo masz w sobie ducha świętych bogów»”.
###### **Dn 4,16**
 Wtedy Daniel, którego imię brzmi Belteszassar, zmieszał się i zląkł własnych myśli. Król powiedział: „Belteszassarze, niech cię nie przeraża mój sen i to, co on oznacza!”. Belteszassar powiedział: „Panie mój, oby ten sen dotyczył twoich wrogów, a jego znaczenie odnosiło się do twoich przeciwników!
###### **Dn 4,17**
 Drzewem, które widziałeś, które rosło i stawało się coraz mocniejsze, które swym wierzchołkiem sięgało nieba i było widoczne aż po krańce całej ziemi,
###### **Dn 4,18**
 którego liście były piękne, a owoce wspaniałe, na którym było pożywienie dla każdego i pod którym miały swoje legowiska wszystkie dzikie zwierzęta, i w którego gałęziach gnieździły się dzikie ptaki -
###### **Dn 4,19**
 jesteś ty, królu. Stałeś się wielki i mocny, twoja wielkość dosięgła nieba, a twoje panowanie - po krańce ziemi.
###### **Dn 4,20**
 Potem widział król strażnika, świętego, który schodził z nieba i mówił: «Zwalcie i porąbcie drzewo, jednak sam jego korzeń pozostawcie w ziemi w okowach z żelaza i z brązu. Niech zarośnie polną trawą, niech zwilża go rosa z nieba, niech je trawę, jak dzikie zwierzęta, aż przeminie nad nim siedem lat».
###### **Dn 4,21**
 Znaczenie tego jest następujące: Wyrok Najwyższego dotyczy mojego pana, króla.
###### **Dn 4,22**
 Zostaniesz wypędzony spośród ludzi i z dziką zwierzyną będziesz przebywał. Będziesz się żywił trawą jak bydło i rosa z nieba będzie ci ochłodą. I przejdzie nad tobą siedem lat, aż poznasz, że królestwami ludzkimi rządzi Najwyższy i On je przekazuje, komu chce.
###### **Dn 4,23**
 Rozkazano zostawić sam korzeń drzewa - twoje królestwo zostanie przy tobie, gdy uznasz, że Niebo sprawuje władzę.
###### **Dn 4,24**
 Dlatego, królu, przyjmij moją radę: okup swoje grzechy sprawiedliwością, a swoje występki - miłosierdziem dla ubogich. Może w ten sposób unikniesz nieszczęścia”.
###### **Dn 4,25**
 Wszystko to przyszło na króla Nabuchodonozora.
###### **Dn 4,26**
 Po upływie dwunastu miesięcy przechadzał się on na dachu pałacu królewskiego w Babilonie.
###### **Dn 4,27**
 Król powiedział: „Oto wielki Babilon, który zbudowałem jako królewską siedzibę, dzięki mocy mojej potęgi i dla chwały mojego majestatu”.
###### **Dn 4,28**
 Kiedy król jeszcze mówił, doszedł do niego głos z nieba: „To słowo jest o tobie, królu Nabuchodonozorze: Królestwo zostało ci odebrane.
###### **Dn 4,29**
 Zostaniesz wypędzony spośród ludzi i będziesz przebywał z dziką zwierzyną. Będziesz się żywił trawą jak bydło i przeminie nad tobą siedem lat, aż poznasz, że królestwami ludzkimi rządzi Najwyższy i On je przekazuje, komu chce”.
###### **Dn 4,30**
 Natychmiast spełniły się te słowa na Nabuchodonozorze. Został wypędzony spośród ludzi, żywił się trawą jak bydło, a rosa z nieba była mu ochłodą. Jego włosy rosły i stały się gęste jak pióra orła, a jego pazury wielkie jak szpony ptaka.
###### **Dn 4,31**
 „Kiedy minęły te dni, ja, Nabuchodonozor, podniosłem oczy ku niebu i wtedy zrozumiałem wszystko. Błogosławiłem Najwyższego, żyjącego wiecznie, chwaliłem Go i wysławiałem, bo Jego panowanie jest panowaniem wiecznym i Jego królestwo trwa z pokolenia na pokolenie.
###### **Dn 4,32**
 Wszystkie plemiona ziemi nic nie znaczą wobec Niego, On według swego upodobania włada mocami nieba i plemionami ziemi. Nikt nie może powstrzymać Jego ręki i powiedzieć Mu: «Co czynisz?».
###### **Dn 4,33**
 W tej chwili wróciła mi jasność umysłu i ku chwale mojego królestwa powrócił do mnie majestat i blask. Moi doradcy i książęta szukali mnie. Przywrócono mnie do godności królewskiej i otrzymałem jeszcze większą władzę.
###### **Dn 4,34**
 Teraz ja, Nabuchodonozor, chwalę, wywyższam i wysławiam Króla nieba, gdyż wszystkie Jego dzieła są prawdą, a Jego drogi - sprawiedliwością. On może poniżyć tych, którzy się pysznią”.
# Dn 4 BP
###### **Dn 4,1**
 Ja, Nebukadnezar, prowadziłem życie spokojne w moim domu i dobrze mi się wiodło w mym pałacu.
###### **Dn 4,2**
 Miałem sen, który mnie przeraził, myśli zaś, gdy leżałem na moim łożu, i widzenia mej głowy przestraszyły mnie.
###### **Dn 4,3**
 Wydałem więc rozkaz, aby przyprowadzono przede mnie wszystkich mędrców Babilonu, żeby mi wyjaśnili znaczenie snu.
###### **Dn 4,4**
 Przybyli tedy magowie, wróżbiarze, Chaldejczycy i astrologowie. Ja opowiedziałem im sen, ale oni nie potrafili mi dać jego wyjaśnienia.
###### **Dn 4,5**
 Na końcu przyszedł do mnie Daniel, zwany Belteszaccarem, tak jak [brzmi] imię mojego boga, a który ma ducha świętych bogów. Opowiedziałem mu sen:
###### **Dn 4,6**
 Belteszaccarze, przełożony magów, ja wiem, że duch świętych bogów jest w tobie i żadna tajemnica nie sprawia ci trudności. [Oto] widzenia snu, który miałem. Powiedz mi jego znaczenie.
###### **Dn 4,7**
 W widzeniach mojej głowy [leżąc] na łożu zobaczyłem: Oto pośrodku ziemi drzewo. Jego wysokość była ogromna.
###### **Dn 4,8**
 Drzewo rosło i stało się potężne. Jego wysokość dosięgła niebios i było widoczne aż po krańce całej ziemi.
###### **Dn 4,9**
 Liście jego były piękne, a owoc obfity. Na nim było pożywienie dla wszystkich. Pod nim znajdowały cień zwierzęta polne; na jego gałęziach mieszkały ptaki niebieskie; z niego brało pożywienie wszelkie ciało.
###### **Dn 4,10**
 Widziałem w widzeniach mojej głowy [leżąc] na mym łożu: Oto Czuwający i Święty zstąpił z nieba.
###### **Dn 4,11**
 Zawołał głośno i tak rzekł: Zetnijcie drzewo i odetnijcie jego gałęzie. Otrząśnijcie jego liście i rozrzućcie jego owoc. Niech zwierzę ucieknie spod niego, a ptaki z jego gałęzi.
###### **Dn 4,12**
 Jednakże pień jego korzeni zostawcie w ziemi w okowach żelaza i brązu, na polnej murawie, aby był skrapiany rosą niebieską i żeby ze zwierzętami [dzielił] swój los w trawie na ziemi.
###### **Dn 4,13**
 Niech się zmieni jego serce ludzkie i niech mu dadzą serce zwierzęce. Niech nad nim przejdzie siedem czasów.
###### **Dn 4,14**
 Z wyroku Czuwających [pochodzi to] postanowienie i z polecenia Świętych jest [to] zarządzenie, ażeby żyjący wiedzieli, że Najwyższy ma władzę nad królestwem ludzi i daje je, komu chce, i najniższych ludzi ustanawia nad nim.
###### **Dn 4,15**
 Taki sen miałem, ja, król Nebukadnezar. Ty zaś, Belteszaccarze, powiedz [mi jego] znaczenie, gdyż wszyscy mędrcy mojego królestwa nie potrafili dać mi wyjaśnienia. Ty zaś możesz, bo duch świętych bogów jest w tobie.
###### **Dn 4,16**
 Daniel, który miał imię Belteszaccar, przez pewien czas był jak osłupiały, a jego myśli przeraziły go. Wtedy król odezwał się i rzekł: Belteszaccarze, niech cię nie przeraża sen i wyjaśnienie. Belteszaccar odpowiadając przemówił: Panie mój! Niech sen odnosi się do tych, co cię nienawidzą, a jego wyjaśnienie dotyczy twoich wrogów.
###### **Dn 4,17**
 Drzewem, które widziałeś, a które rosło i stało się potężne, jego wysokość sięgała niebios i było je widać na całej ziemi,
###### **Dn 4,18**
 [którego] liście były piękne i owoc obfity, na którym było pożywienie dla wszystkich, pod którym mieszkało zwierzę polne, na gałęziach zaś gnieździły się ptaki niebieskie,
###### **Dn 4,19**
 jesteś ty, o królu. Rosłeś i stałeś się potężny. Rosła twoja wielkość i dosięgła niebios. Władza twoja rozciąga się po krańce ziemi.
###### **Dn 4,20**
 A [to], co król widział: Czuwającego i Świętego zstępującego z niebios, który mówił: Zetnijcie drzewo i wywróćcie je, tylko pień jego korzeni w ziemi zostawcie, w okowach żelaza i brązu, na polnej murawie, aby był skrapiany rosą niebieską i ze zwierzęciem polnym [dzielił] swój los, aż przejdzie siedem czasów nad nim -
###### **Dn 4,21**
 takie ma znaczenie królu: Oto postanowienie Najwyższego, które dotyczy pana mojego, króla:
###### **Dn 4,22**
 Usuną cię spośród ludzi i ze zwierzem polnym będziesz mieszkał. Będą cię karmić trawą jak woły i rosą niebieską będą cię poić. Siedem czasów przejdzie nad tobą, aż poznasz, że Najwyższy ma władzę nad królestwem ludzi i daje je, komu chce.
###### **Dn 4,23**
 A ponieważ rozkazano, aby został pień korzeni drzewa, królestwo twoje pozostanie przy tobie, gdy uznasz, że władzę sprawują niebiosa.
###### **Dn 4,24**
 Dlatego, królu - niech ci się spodoba moja rada - grzech twój okup sprawiedliwością a nieprawości twoje miłosierdziem nad biednymi, jeśli ma być długie twoje powodzenie.
###### **Dn 4,25**
 Wszystko to spełniło się na królu Nebukadnezarze.
###### **Dn 4,26**
 Gdy upłynęło dwanaście miesięcy, spacerował [on] po [tarasie] pałacu królewskiego w Babilonie.
###### **Dn 4,27**
 Król zaczął mówić i rzekł: Czyż nie jest to ten wielki Babilon, który ja wybudowałem jako rezydencję królewską dzięki mocy mojej potęgi dla chwały mojego majestatu?
###### **Dn 4,28**
 Jeszcze słowo [to] było w ustach króla, gdy spadł głos z niebios: Do ciebie mówię, królu Nebukadnezarze. Królestwo odchodzi od ciebie.
###### **Dn 4,29**
 Usuną cię spośród ludzi, ze zwierzem polnym będzie twoje przebywanie, będą cię karmić trawą jak woły; siedem czasów przejdzie nad tobą, aż uznasz, że Najwyższy ma władzę nad królestwem ludzi i daje je, komu chce.
###### **Dn 4,30**
 W tym samym momencie spełniło się słowo na Nebukadnezarze. Został usunięty spośród ludzi, jadł trawę jak woły; jego ciało zraszała rosa niebieska, aż włosy [na głowie] urosły jak pióra orłów, a jego paznokcie jak [szpony] ptaków.
###### **Dn 4,31**
 Pod koniec dni, ja, Nebukadnezar, podniosłem moje oczy do nieba i wrócił mi rozum mój. Błogosławiłem tedy Najwyższego oraz chwaliłem i wysławiałem Wiecznie Żyjącego, którego władanie jest wiekuistym panowaniem, a Jego królestwo trwa z pokolenia w pokolenie.
###### **Dn 4,32**
 [Wobec Niego] wszyscy mieszkańcy ziemi jakby się nie liczą. Według swojej woli postępuje z wojskiem niebieskim i mieszkańcami ziemi i nie ma, kto by wstrzymał Jego rękę lub powiedział Mu: Co czynisz?
###### **Dn 4,33**
 W tej samej chwili wrócił mi rozum mój i ku chwale mojego królestwa powrócił do mnie mój majestat i moja chwała. Moi ministrowie i moi książęta szukali [mnie]. Zostałem przywrócony [do władzy] nad moim królestwem i jeszcze bardziej wzrosła moja wielkość.
###### **Dn 4,34**
 Teraz ja, Nebukadnezar, chwalę, wynoszę i wysławiam Króla niebios, albowiem wszystkie Jego dzieła są prawdą, Jego drogi są sprawiedliwością, a tych, którzy są pyszni, ma moc upokorzyć.
# Dn 4 BR
###### **Dn 4,1**
 Ja, Nabuchodonozor, żyłem spokojnie w moim domu, zażywając szczęścia w moim pałacu.
###### **Dn 4,2**
 I oto miałem sen, który mnie przeraził. Przyszły na mnie straszne udręki, kiedy znajdowałem się jeszcze w moim łożu, w głowie zaś miałem ciągle pełno różnych widziadeł.
###### **Dn 4,3**
 Rozkazałem tedy, żeby przyszli do mnie wszyscy mędrcy babilońscy i wytłumaczyli mi, co oznacza mój sen.
###### **Dn 4,4**
 Przyszli więc tłumacze snów, wróżbici, Chaldejczycy i różni czarownicy, ale w dniu mojego snu nie wyjaśnili mi jego znaczenia.
###### **Dn 4,5**
 Wreszcie przyszedł do mnie Daniel, zwany od imienia mojego boga Belteszassarem. Temu człowiekowi - a duch świętych bogów mieszka w nim - tak oto opowiedziałem mój sen:
###### **Dn 4,6**
 Belteszassarze, przełożony tłumaczy snów! Wiem, że mieszka w tobie duch świętych bogów i że potrafisz przeniknąć wszelkie tajemnice. Chcę ci teraz opowiedzieć, co mi się śniło, a ty wyjaśnisz mi znaczenie mojego snu.
###### **Dn 4,7**
 Pozostając w łożu miałem w swojej głowie takie oto obrazy: Widziałem drzewo, które wyrastało z samego środka ziemi i było bardzo wysokie.
###### **Dn 4,8**
 I rosło drzewo coraz bardziej i potężniało, a swoim wierzchołkiem sięgało nieba i widać je było aż po krańce ziemi.
###### **Dn 4,9**
 Piękne były jego liście i bardzo obfite owoce. Każdy mógł na nim znaleźć coś do jedzenia, dostarczało ono cienia polnej zwierzynie, a na jego gałęziach zakładały gniazda ptaki powietrzne. I wszystko, co żyło, na nim znajdowało dla siebie pokarm.
###### **Dn 4,10**
 Kiedy tak, leżąc w swoim łożu, przypatrywałem się obrazom, które powstawały w mojej głowie, zobaczyłem, jak Czuwający i Święty zstępował z nieba,
###### **Dn 4,11**
 i wołał głosem bardzo donośnym: Zetnijcie to drzewo, poobcinajcie jego gałęzie, otrząśnijcie z niego liście, zerwijcie zeń wszystkie owoce; niech też zwierzęta odejdą spod jego cienia i wszelkie ptactwo zostanie wypłoszone z jego gałęzi!
###### **Dn 4,12**
 Lecz jego pień razem z korzeniami pozostawcie w ziemi, nawet otoczcie go ogrodzeniem z żelaza i brązu; niech tak pozostanie pośród roślin polnych. Niech będzie nawadniany rosą, co z nieba spada, a trawa polna niech będzie tak samo dla niego jak dla dzikich zwierząt.
###### **Dn 4,13**
 Jego serce ludzkie będzie mu zabrane, a otrzyma za to zwierzęce serce. I siedem ludzkich pokoleń ponad nim przeminie.
###### **Dn 4,14**
 Oto wyrok, jaki wydają nań Czuwający. Tak rozstrzygają całą sprawę Święci, żeby się dowiedziało wszystko, co żyje, że Najwyższy ma władzę nad wszelkim ludzkim królestwem i może je przekazać komu zechce, i wynieść na wyżyny najmniejszego z ludzi!
###### **Dn 4,15**
 Taki miałem sen ja, król Nabuchodonozor. A ty, Belteszassarze, powiedz mi, co ten sen oznacza, bo nie mógł tego powiedzieć żaden z mędrców mojego królestwa. Ale ja wiem, że ty możesz to uczynić, bo w tobie przebywa duch świętych bogów.
###### **Dn 4,16**
 Na to zmieszał się i zaniepokoił Daniel, zwany także Belteszassarem. Wtedy król powiedział: Belteszassarze, niech cię nie przeraża mój sen i to, co on oznacza! Belteszassar zaś rzekł na to: Panie mój, niech to, co ci się śniło, dotyczy twoich wrogów, a znaczenie snu twojego odnosi się do twoich przeciwników!
###### **Dn 4,17**
 Drzewo, które widziałeś, tak bardzo potężne, rozrosłe, sięgające samych niebios i widoczne aż z krańców ziemi,
###### **Dn 4,18**
 drzewo o pięknych liściach i owocach tak licznych, że dostarczało pożywienia dla wszystkich; drzewo, pod którym mają swoje legowiska polne zwierzęta, a na jego gałęziach gnieżdżą się ptaki powietrzne,
###### **Dn 4,19**
 to drzewo - to ty właśnie, o królu, który stałeś się wielki i potężny, a w swej wielkości tak wzrastałeś, że sięgałeś aż niebios, zaś twoja władza rozciągała się aż po krańce ziemi.
###### **Dn 4,20**
 Natomiast co do Czuwającego, którego król widział, jak zstępował z nieba i mówił: Zetnijcie to drzewo, zniszczcie je, ale jego pień i korzenie pozostawcie w ziemi, otaczając je ogrodzeniem z żelaza i spiżu pośrodku roślin polnych; niech będzie nawadniane rosą, co z nieba spada, a trawa polna niech będzie dla niego tak, jak dla dzikich zwierząt do czasu, aż siedem ludzkich pokoleń przeminie ponad nim
###### **Dn 4,21**
 - to znaczenie tego obrazu jest takie, o królu, taki jest dekret Najwyższego w sprawie mojego pana i króla:
###### **Dn 4,22**
 Zostaniesz wypędzony spośród ludzi i będziesz przebywał pomiędzy dzikimi zwierzętami, żywiąc się trawą jak bydło. Pragnienie będziesz gasił rosą z nieba, siedem pokoleń ludzkich przejdzie nad tobą aż w końcu zrozumiesz, że Najwyższy sprawuje władzę nad wszelkim królestwem ludzkim, które On przekaże, komu zechce.
###### **Dn 4,23**
 Słowa zaś: Pozostawcie jego pień i korzenie - oznaczają, że twoje królestwo pozostanie przy tobie, aż się przekonasz, że Niebiosa sprawują władzę nad wszystkim.
###### **Dn 4,24**
 A teraz posłuchaj, o królu, mojej rady: postaraj się dziełami sprawiedliwości okupić swoje grzechy i wszystkie swoje niegodziwości okazując miłosierdzie ubogim, żebyś mógł cieszyć się długim spokojem.
###### **Dn 4,25**
 I wszystko to przyszło na króla Nabuchodonozora.
###### **Dn 4,26**
 Dwanaście miesięcy później przechadzając się po tarasie pałacu królewskiego w Babilonie,
###### **Dn 4,27**
 król mówił sobie: Oto wielki Babilon, który zbudowałem jako siedzibę królewską dla siebie, posługując się siłą mojej potęgi ku chwale mojego majestatu.
###### **Dn 4,28**
 Kiedy on jeszcze to mówił, dał się słyszeć głos z nieba. To o tobie była mowa, królu Nabuchodonozorze: Zostanie ci odebrane twoje królestwo,
###### **Dn 4,29**
 a ty sam będziesz wypędzony spośród ludzi. Będziesz przebywał razem z dzikimi zwierzętami i będziesz się żywił trawą jak bydło. Przeminie nad tobą siedem pokoleń, aż w końcu zrozumiesz, że Najwyższy sprawuje władzę nad wszelkim ludzkim królestwem i że je przekazuje, komu zechce.
###### **Dn 4,30**
 I wkrótce spełniły się na Nabuchodonozorze wszystkie te słowa: został wypędzony spośród ludzi, żywił się trawą jak bydlęta, a pragnienie gasił rosą spadającą z nieba. Jego włosy rosnąc zamieniały się w orle pióra, a paznokcie przypominały szpony ptaków.
###### **Dn 4,31**
 A kiedy już nadszedł mój czas, wtedy ja, Nabuchodonozor, podniosłem oczy ku niebu i wróciła mi jasność umysłu. I zacząłem błogosławić Najwyższego, wychwalając Tego, który żyje na wieki. Jego królestwo i panowanie są wieczne, zaś Jego władza rozciąga się ponad wszystkie pokolenia.
###### **Dn 4,32**
 A wszyscy mieszkańcy ziemi jakby się nie liczyli wobec Niego. Wedle swego upodobania postępuje z zastępami niebios, jak i z wszystkimi mieszkańcami ziemi. Nikt nie może powstrzymać Jego ramienia lub choćby powiedzieć Mu: A cóżeś to uczynił?
###### **Dn 4,33**
 Wtedy też zrozumiałem wszystko i, ku chwale mojego królestwa, wróciły do mnie majestat i blask. Odnaleźli mnie moi doradcy i zarządcy, władzę objąłem na nowo i rosła z dniem każdym moja wielkość.
###### **Dn 4,34**
 Teraz więc ja, Nabuchodonozor, chwalę, wysławiam i uwielbiam Króla Niebieskiego. Prawdą są wszystkie Jego dzieła, sprawiedliwe są wszystkie drogi Jego. On też potrafi uniżyć tych, którzy się wywyższają.
# Dn 4 WUJ
###### **Dn 4,1**
 Nabuchodonozor król, wszem ludziom, narodom, i językom, którzy mieszkają po wszystkiej ziemi. Pokój wam niech się rozmnaża,
###### **Dn 4,2**
 Znaki i dziwy uczynił u mnie Bóg wysoki.
###### **Dn 4,3**
 A tak podobało mi się opowiadać znaki jego, bo wielkie są: i cuda jego, bo mocne: a królestwo jego królestwo wieczne, i władza jego do rodzaju i rodzaju.
###### **Dn 4,4**
 Ja Nabuchodonozor byłem spokojnym w domu moim, i kwitnący na pałacu moim:
###### **Dn 4,5**
 Widziałem sen, który mię przestraszył: i myśli moje na łożu mojem, i widzenia głowy mojej strwożyły mię.
###### **Dn 4,6**
 I przez mię wydań jest wyrok, żeby przywiedziono przed oczy moje wszystkie mędrce Babilońskie, ażeby mi wykład snu oznajmili.
###### **Dn 4,7**
 Tedy przychodzili wieszczkowie, czarnoksiężnicy i Chaldejczycy, i praktykarze, i powiedziałem sen przed nimi: a wykładu jego nie pokazali mi:
###### **Dn 4,8**
 Aż towarzysz Daniel wszedł przed oczy moje, któremu imię Balthazar, wedle Imienia Boga mego, który ma ducha bogów świętych sam w sobie, i powiedziałem przed nim sen.
###### **Dn 4,9**
 Balthazarze przedniejszy z wieszczków, gdyż ja wiem iż ducha bogów świętych masz w sobie, a wszelka tajemnica nie jest tobie nie podobna: widzenia snów moich, którem widział, i wykład ich powiedz.
###### **Dn 4,10**
 Widzenie głowy mojej na łożu mojem: Widziałem, ano drzewo na śród ziemie, a wysokość jego zbytnia.
###### **Dn 4,11**
 Wielkie drzewo i mocne: a wysokość jego dosięgająca nieba: widzenie jego było aż do granic wszystkiej ziemie.
###### **Dn 4,12**
 Liście jego barzo piękne, a owoc jego zbytni: i pokarm wszystkich na niem. Pod niem mieszkały zwierzęta i bestye, na gałęzi jego mieszkali ptacy powietrzni: a z niego jadło każde ciało.
###### **Dn 4,13**
 Widziałem w widzeniu głowy mojej na pościeli mojej, a oto czujący i święty z nieba zstąpił.
###### **Dn 4,14**
 Wołał mocno, i tak mówił: Porąbcie drzewo, a obetnicie gałęzie jego, otrzęście liście jego, a rozproszcie owoce jego: niech uciekną bestye, które pod nim są, i ptacy z gałęzią jego.
###### **Dn 4,15**
 Wszakże jednak pnia korzenia jego w ziemi zaniechajcie: a niech będzie związany łańcuchem, żelaznym i miedzianym na trawach, które na polach są, a rosą niebieską niech będzie skropiony. A z zwierzęty część jego trawie ziemnej.
###### **Dn 4,16**
 Serce jego od człowieczego niech się zmieni, a serce zwierzęce niech mu będzie dane: a niech siedm czasów odmieni się nad nim.
###### **Dn 4,17**
 W wyroku czujących postanowiono jest, a mowa świętych i żądanie: aż poznają żywiący, iż Nawyższy panuje w królestwie ludzi, a komukolwiek zechce daje, a napodlejszego człowieka stanowi nad nim.
###### **Dn 4,18**
 Ten sen widziałem ja król Nabuchodonozor: a tak ty Balthazarze powiedz co rychlej wykład: bo wszyscy mędrcy królestwa mego nie mogą mi wykładu powiedzieć ale ty możesz, bo duch bogów świętych jest w tobie.
###### **Dn 4,19**
 Tedy Daniel, którego imię Balthazar począł sam w sobie milcząc myślić jakoby przez jedne godzinę: i myśli jego trwożyły go. A odpowiadając król, rzekł: Balthazarze, sen i wykład jego niech cię nie trwoży. Odpowiedział Balthazar i rzekł: Panie mój, sen tym, którzy cię nienawidzą, a wykład jego nieprzyjaciołom twoim niech będzie.
###### **Dn 4,20**
 Drzewo, któreś widział wysokie i mocne, którego wysokość sięga aż do nieba, a widzenie jego po wszej ziemi,
###### **Dn 4,21**
 A gałęzie jego barzo piękne, i owoc jego zbytni, a pokarm wszystkich na nim, pod nim mieszkające bestye polne, a na gałęziach jego przebywający ptacy powietrzni:
###### **Dn 4,22**
 Tyś jest królu, któryś się rozwielmożył i rozmógł: a wielmożność twoja urosła, i dosięgła aż do nieba, a władza twoja do granic wszystkiej ziemie.
###### **Dn 4,23**
 A iż widział król czującego i świętego zstępującego z nieba, i mówiącego: Porąbcie drzewo, a skaźcie je: wszakoż pnia korzenia jego w ziemi zaniechajcie, a niech będzie związany żelazem i miedzią na trawie w polu, a rosą niebieską niech będzie kropiony, a z zwierzęty niech będzie pokarm jego, aż siedm czasów przemieni się nad nim:
###### **Dn 4,24**
 Ten jest wykład wyroku Nawyższego, który przyszedł na pana mego króla.
###### **Dn 4,25**
 Wyrzucą cię od ludzi, a z bydłem i z bestyami, i z zwierzem będzie mieszkanie twoje, i trawę jako wół jeść będziesz, a rosą niebieską kropion będziesz: siedm też czasów odmienia się nad tobą, aż doznasz, że Nawyższy panuje nad królestwem ludzi, a komukolwiek zechce dawa je.
###### **Dn 4,26**
 A iż rozkazał, aby zostawiono pień korzenia jego, to jest drzewa: królestwo twoje zostanie się tobie, gdy poznasz, że władza jest niebieska.
###### **Dn 4,27**
 Przeto królu niech ci się podoba rada moja, a grzechy twoje jałmużnami odkupuj: a nieprawości twe miłosierdziem nad ubogimi: podobno odpuści grzechy twoje.
###### **Dn 4,28**
 Wszystko to przyszło na Nabuchodonozora króla.
###### **Dn 4,29**
 Po skończeniu dwunastu miesięcy przechodził się na pałacu Babilońskim.
###### **Dn 4,30**
 I odpowiedział król i rzekł: Izali nie to jest Babilon wielki, którym ja zbudował na dom królestwa w sile mocy mojej, i w sławie ozdoby mojej:
###### **Dn 4,31**
 A gdy jeszcze mowa była w uściech królewskich, głos spadł z nieba: Tobie mówią Nabuchodonozorze królu: królestwo twe odejdzie od ciebie,
###### **Dn 4,32**
 I od ludzi wyrzucą cię, a z bydłem i z zwierzęty będzie mieszkanie twoje: trawę jako wół jeść będziesz, a siedm czasów odmienia się nad tobą, aż doznasz, że Nawyższy panuje w królestwie człowieczem, a komukolwiek zechce, dawa je.
###### **Dn 4,33**
 Tejże godziny wypełniła się mowa nad Nabuchodonozorem, i od ludzi wyrzucony jest, i trawę jadł jako wół, i rosą niebieską ciało jego zmoczone jest: aż włosy jego na kształt orłów urosły, a paznokcie jego jako ptaków.
###### **Dn 4,34**
 A tak po skończeniu dni ja Nabuchodonozor podniosłem w niebo oczy moje, a rozum mój był mi przywrócon: i błogosławiłem Nawyższego, a żywiącego na wieki chwaliłem i sławiłem: bo władza jego władza wieczna, a królestwo jego na naród i naród.
###### **Dn 4,35**
 I wszyscy obywatele ziemscy u niego za nic są poczytani: bo według woli swej czyni tak z wojskiem niebieskiem, jako i z obywatelmi ziemskiemi: a niemasz ktoby się sprzeciwił ręce jego, a mówił mu: Przecześ uczynił?
###### **Dn 4,36**
 Tegoż czasu zmysł mój wrócił się do mnie, i przyszedłem do czci i ozdoby królestwa mego: i osoba moja wróciła się na mię: a panowie moi, i urzędnicy moi szukali mię, i przywróconym jest na królestwo moje: i wielmożność większa mi była przydana.
###### **Dn 4,37**
 A tak teraz ja Nabuchodonozor chwalę, i wielbię, i wysławiam króla niebieskiego: bo wszystkie sprawy jego prawdziwe, a drogi jego sądy: i chodzące w pysze uniżyć może.
