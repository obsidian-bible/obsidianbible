# Dn 2 BT5
###### **Dn 2,1**
 W drugim roku swego panowania Nabuchodo-nozor miał sny; ducha jego ogarnął niepokój i nie mógł spać.
###### **Dn 2,2**
 Rozkazał więc przywołać tłumaczących sny, wróżbitów, czarnoksiężników i Chaldejczyków, by powiedzieli królowi, jakie miał sny; ci zaś przyszli i stanęli przed królem.
###### **Dn 2,3**
 Król powiedział do nich: «***Miałem sen i ducha mojego ogarnął niepokój; chciałem ten sen zrozumieć***».
###### **Dn 2,4**
 Odrzekli zaś Chaldejczycy: «***Królu, żyj wiecznie! Opowiedz sługom swoim sen, a podamy ci jego znaczenie***».
###### **Dn 2,5**
 Odpowiedział król Chaldejczykom: «***Wiedzcie o moim postanowieniu: jeśli nie przedstawicie mi snu i jego znaczenia, zostaniecie rozerwani na kawałki, a wasze domy zostaną obrócone w gruzy.
###### **Dn 2,6**
 Jeżeli zaś przedstawicie mi sen i jego znaczenie, otrzymacie ode mnie dary i nagrody oraz wielkie zaszczyty. Toteż powiedzcie mi sen i jego znaczenie!***»
###### **Dn 2,7**
 Odpowiedzieli powtórnie: «***Niech król opowie sen swoim sługom, my zaś oznajmimy mu jego znaczenie***».
###### **Dn 2,8**
 Król zaś odrzekł: «***Teraz rozumiem dobrze, że chcecie zyskać na czasie, ponieważ wiecie o niezmiennym moim postanowieniu,
###### **Dn 2,9**
 mianowicie, że jeśli nie przedstawicie mi snu, jeden może was tylko spotkać wyrok. Zmówiliście się, aby opowiadać mi kłamstwa i oszustwa, dopóki się czasy nie zmienią. Dlatego przedstawcie mi sen, bym się przekonał, iż możecie wyjaśnić mi jego znaczenie***».
###### **Dn 2,10**
 Chaldejczycy zaś odpowiedzieli królowi: «***Nie ma nikogo na ziemi, kto by mógł oznajmić to, czego domaga się król. Dlatego żaden z królów, choćby wielkich i potężnych, nie wymaga podobnej rzeczy od tłumaczącego sny, od wróżbity lub Chaldejczyka.
###### **Dn 2,11**
 Pytanie, jakie król stawia, jest trudne, i nikt nie potrafi na nie odpowiedzieć królowi z wyjątkiem bogów, którzy nie przebywają między ludźmi***».
###### **Dn 2,12**
 Wtedy ogarnął króla wielki gniew i oburzenie i rozkazał zabić wszystkich mędrców babilońskich.
###### **Dn 2,13**
 Gdy wyszedł rozkaz, by wytracić mędrców, miał także ponieść śmierć Daniel ze swymi towarzy-szami.
###### **Dn 2,14**
 Daniel zwrócił się więc z pełną rozwagi przezornością do Arioka, dowódcy gwardii królewskiej, który poszedł wytracić mędrców babilońskich.
###### **Dn 2,15**
 Powiedział do Arioka, królewskiego dowódcy: «***Dlaczego rozkaz królewski jest aż tak surowy?***» Ariok przedstawił Danielowi sprawę.
###### **Dn 2,16**
 Daniel udał się do króla, prosząc, by mu dał czas na oznajmienie znaczenia [snu].
###### **Dn 2,17**
 Następnie udał się Daniel do domu i opowiedział sprawę swym towarzyszom: Chana-niaszowi, Miszaelowi i Azariaszowi,
###### **Dn 2,18**
 aby prosili Boga nieba o miłosierdzie w tej tajemniczej sprawie, ażeby Daniel ze swymi towarzyszami nie uległ zagładzie wraz z pozostałymi mędrcami babilońskimi.
###### **Dn 2,19**
 Wtedy Daniel otrzymał objawienie tajemnicy w nocnym widzeniu. Wielbił więc Boga nieba.
###### **Dn 2,20**
 Daniel mówił tymi słowami:«***Niech będzie błogosławione imię Bogapo wszystkie wieki!Bo mądrość i mocnależą do Niego.
###### **Dn 2,21**
 On to zmienia okresy i czasy, usuwa królów i ustanawia królów,udziela mędrcom mądrości, a wiedzy rozumnym.
###### **Dn 2,22**
 On odsłania to, co niezgłębione i ukryte, i zna to, co spowite mrokiem, a światłość mieszka u Niego.
###### **Dn 2,23**
 Ciebie, Boże moich przodków, wielbię i sławię. Bo udzieliłeś mi mądrości i mocy, wyjawiłeś mi to, o co Cię błagaliśmy, sprawę królewską poznać nam dałeś***».
###### **Dn 2,24**
 Następnie Daniel udał się do Arioka, któremu król wydał polecenie, by pozabijał mędrców babilońskich, i tak powiedział do niego: «***Nie zabijaj mędrców babilońskich! Wprowadź mnie przed króla, a podam królowi znaczenie [snu]***».
###### **Dn 2,25**
 Ariok zaprowadził szybko Daniela do króla i tak powiedział do niego: «***Znalazłem męża spośród uprowadzonych z Judy, który oznajmi królowi znaczenie [snu]***».
###### **Dn 2,26**
 Król zwrócił się i powiedział do Daniela, który nosił imię Belteszassar: «***Czy możesz rzeczywiście przedstawić mi sen, jaki miałem, i jego znaczenie?***»
###### **Dn 2,27**
 Daniel odpowiedział królowi: «***Tajemnicy, o którą król pyta, nie zdołają wyjawić ani mędrcy, ani tłumaczący sny, ani wróżbici, ani astrologowie.
###### **Dn 2,28**
 Jest jednak Bóg w niebie, który odsłania tajemnice, i On oznajmia królowi Nabuchodonozorowi, co nastąpi przy końcu dni. Twój sen i widzenia, jakie miałeś na swym łożu, są następujące:
###### **Dn 2,29**
 Ciebie, królu, na twym łożu ogarnęły myśli o tym, co ma później nastąpić. Ten zaś, który odsłania tajemnice, wyjawił ci, co się stanie.
###### **Dn 2,30**
 Co do mnie zaś, tajemnica ta stała mi się wiadoma nie dlatego, jakobym był mędrszy od wszystkich ludzi, lecz aby udzielić wyjaśnienia królowi i żebyś rozumiał myśli swego serca.
###### **Dn 2,31**
 Ty, królu, przyglądałeś się: Oto posąg bardzo wielki, o nadzwyczajnym blasku, stał przed tobą, a widok jego był straszny.
###### **Dn 2,32**
 Głowa tego posągu była z czystego złota, pierś jego i ramiona ze srebra, brzuch i biodra z miedzi,
###### **Dn 2,33**
 golenie z żelaza, stopy zaś jego częściowo z żelaza, częściowo z gliny.
###### **Dn 2,34**
 Patrzyłeś, a oto odłączył się kamień, mimo że nie dotknęła go ręka ludzka, i ugodził posąg w stopy z żelaza i gliny, i połamał je.
###### **Dn 2,35**
 Wtedy natychmiast uległy skruszeniu żelazo i glina, miedź, srebro i złoto – i stały się jak plewy na klepisku w lecie; uniósł je wiatr, tak że nawet ślad nie pozostał po nich. Kamień zaś, który uderzył w posąg, rozrósł się w wielką górę i wypełnił całą ziemię.
###### **Dn 2,36**
 Taki jest sen, a jego znaczenie przedstawimy królowi.
###### **Dn 2,37**
 Ty, królu, królu królów, któremu Bóg nieba oddał panowanie, siłę, moc i chwałę,
###### **Dn 2,38**
 w którego ręce oddał w całym zamieszkanym świecie ludzi, zwierzęta polne i ptaki podniebne i którego uczynił władcą nad nimi wszystkimi – ty jesteś głową ze złota.
###### **Dn 2,39**
 Po tobie jednak powstanie inne królestwo, mniejsze niż twoje, i nastąpi trzecie królestwo – miedziane, które będzie panowało nad całą ziemią.
###### **Dn 2,40**
  Czwarte zaś królestwo będzie trwałe jak żelazo. Tak jak żelazo wszystko kruszy i rozrywa, skruszy ono i w proch zetrze wszystko razem.
###### **Dn 2,41**
 To, że widziałeś stopy i palce częściowo z gliny, częściowo zaś z żelaza, [oznacza, że] królestwo ulegnie podziałowi; będzie miało coś z trwałości żelaza. To zaś, że widziałeś żelazo zmieszane z mulistą gliną,
###### **Dn 2,42**
 a palce u nóg częściowo z żelaza, częściowo zaś z gliny, [oznacza, że] królestwo będzie częściowo trwałe, częściowo zaś kruche.
###### **Dn 2,43**
 To, że widziałeś żelazo zmieszane z mulistą gliną, [oznacza, że] zmieszają się oni przez ludzkie nasienie, ale nie będą się odznaczać spoistością, podobnie jak żelazo nie da się pomieszać z gliną.
###### **Dn 2,44**
 W czasach tych królów Bóg nieba wzbudzi królestwo, które nigdy nie ulegnie zniszczeniu, a którego władza królewska nie będzie oddana żadnemu innemu narodowi. Zetrze i zniweczy ono wszystkie te królestwa, samo zaś będzie trwało na wieki,
###### **Dn 2,45**
 jak to widziałeś, gdy kamień oderwał się od góry, mimo że nie dotknęła go ludzka ręka, i starł w proch żelazo, miedź, glinę, srebro i złoto. Wielki Bóg wyjawił królowi, co nastąpi później; prawdziwy jest sen, a wyjaśnienie jego pewne***».
###### **Dn 2,46**
 Wtedy Nabuchodonozor upadł na twarz i oddał pokłon Danielowi, rozkazując złożyć mu dary i wonne kadzidła.
###### **Dn 2,47**
 Następnie król zwrócił się do Daniela i powiedział: «***Wasz Bóg jest naprawdę Bogiem nad bogami, Panem królów, który wyjawia tajemnice, ponieważ zdołałeś wyjawić tę tajemnicę***».
###### **Dn 2,48**
 Potem wywyższył król Daniela, dał mu wiele bogatych darów i uczynił go zarządcą całej prowincji babilońskiej i zwierzchnikiem nad wszystkimi mędrcami Babilonu.
###### **Dn 2,49**
 Daniel prosił króla, by powierzył administrację prowincji babilońskiej Szadrakowi, Meszakowi i Abed-Negowi; Daniel natomiast pozostał na dworze królewskim.
# Dn 2 PAU
###### **Dn 2,1**
 W drugim roku swego panowania Nabuchodonozor miał dziwny sen. Ogarnął go wewnętrzny niepokój i nie mógł spać.
###### **Dn 2,2**
 Rozkazał wezwać wszystkich wróżbitów, magów, czarowników i chaldejczyków, żeby objaśnili znaczenie jego snu. Kiedy oni przybyli i stanęli przed królem,
###### **Dn 2,3**
 powiedział do nich: „Miałem sen i ogarnął mnie wewnętrzny niepokój, bo nie wiem, co ten sen oznacza”.
###### **Dn 2,4**
 Chaldejczycy odpowiedzieli królowi po aramejsku: „Królu, obyś żył wiecznie! Opowiedz sen swoim sługom, a my objaśnimy jego znaczenie”.
###### **Dn 2,5**
 Król powiedział do chaldejczyków: „Oto moje postanowienie: jeżeli wy nie opowiecie tego snu i nie objaśnicie jego znaczenia, zostaniecie rozerwani na kawałki, a wasze domy legną w gruzach.
###### **Dn 2,6**
 A jeżeli opowiecie sen i objaśnicie jego znaczenie, otrzymacie zapłatę, dary i wspaniałe zaszczyty. Opowiedzcie więc mój sen i objaśnijcie jego znaczenie”.
###### **Dn 2,7**
 Oni powtórzyli: „Królu, opowiedz sen swoim sługom, a my objaśnimy jego znaczenie”.
###### **Dn 2,8**
 Król powiedział: „Dobrze wiem, że chcecie zyskać na czasie, bo znacie moje postanowienie.
###### **Dn 2,9**
 Jeżeli nie opowiecie snu, jeden i tylko jeden los was czeka, bo postanowiliście okłamywać mnie i zwodzić, licząc na to, że zmienicie tym swoje położenie. Dlatego opowiedzcie mój sen i niech poznam jego znaczenie”.
###### **Dn 2,10**
 Chaldejczycy odpowiedzieli królowi: „Nie ma takiego człowieka na ziemi, który by potrafił powiedzieć to, czego chce król. Żaden wielki i możny król nie wymaga takich rzeczy nawet od największego z wróżbitów, magów czy chaldejczyków.
###### **Dn 2,11**
 Król żąda trudnej rzeczy. Nie ma nikogo, kto mógłby temu sprostać, z wyjątkiem bogów, którzy przecież nie mieszkają między ludźmi”.
###### **Dn 2,12**
 Z powodu tego wszystkiego król bardzo się rozzłościł, wpadł w wielki gniew i kazał zgładzić wszystkich mędrców Babilonu.
###### **Dn 2,13**
 Wydano więc rozkaz wymordowania mędrców. Także Daniel i jego towarzysze mieli zostać zgładzeni.
###### **Dn 2,14**
 Wtedy Daniel w swej mądrości i roztropności zwrócił się do Arioka, naczelnika przybocznej straży królewskiej, który wyruszył, aby wymordować mędrców Babilonu.
###### **Dn 2,15**
 Powiedział do oficera królewskiego Arioka: „Dlaczego rozkaz wydany przez króla jest tak surowy?”. Wówczas Ariok zapoznał Daniela z całą sprawą,
###### **Dn 2,16**
 a Daniel poszedł do króla i wyjednał u niego czas potrzebny na wyjaśnienie snu.
###### **Dn 2,17**
 Potem Daniel pobiegł do swojego domu i przedstawił sprawę swoim towarzyszom: Chananiaszowi, Miszaelowi i Azariaszowi,
###### **Dn 2,18**
 prosząc ich, aby błagali Boga nieba o łaskę w sprawie tej tajemnicy, żeby on i jego towarzysze nie zostali zabici razem z resztą mędrców Babilonu.
###### **Dn 2,19**
 I Danielowi została odkryta owa tajemnica w nocnym widzeniu. Błogosławił więc Daniel swojego Boga nieba
###### **Dn 2,20**
 i mówił: „Niech imię Boga będzie błogosławione przez wszystkie wieki, bo On jest mądry i potężny.
###### **Dn 2,21**
 On ustanawia kolejność pór i czasów, obdarza królów władzą i ją im odbiera, daje mądrość mędrcom, uczonych napełnia wiedzą.
###### **Dn 2,22**
 On objawia to, co tajemne i niepojęte, On wie, co ukryte w ciemności, w Nim mieszka światło.
###### **Dn 2,23**
 Ciebie, Boże moich ojców, wychwalam i błogosławię, bo obdarowałeś mnie mądrością i mocą, a teraz dałeś mi poznać to, o co Cię błagaliśmy: dałeś nam poznać sprawę króla”.
###### **Dn 2,24**
 Potem Daniel poszedł do Arioka, któremu król polecił zgładzić mędrców Babilonu, i powiedział: „Nie dokonuj zagłady mędrców babilońskich. Wprowadź mnie do króla, a objaśnię królowi znaczenie snu”.
###### **Dn 2,25**
 Ariok natychmiast zaprowadził Daniela do króla i tak powiedział: „Znalazłem człowieka spośród uprowadzonych z Judei, który wyjaśni królowi znaczenie snu”.
###### **Dn 2,26**
 Król odezwał się do Daniela, którego imię brzmiało Belteszassar: „Czy opowiesz mój sen i objaśnisz jego znaczenie?”.
###### **Dn 2,27**
 Daniel powiedział królowi: „Żaden z mądrych magów, wróżbitów czy astrologów nie zdoła wyjaśnić tajemnicy, o którą król pyta.
###### **Dn 2,28**
 Jednak jest w niebie Bóg, który objawia tajemnice, i teraz daje poznać królowi Nabuchodonozorowi, co ma się stać. Gdy leżałeś na swoim łożu, miałeś taki oto sen i wewnętrzne widzenie:
###### **Dn 2,29**
 Na twoim łożu, królu, naszły cię myśli o tym, co będzie potem. I została ci objawiona tajemnica, poznałeś, co nastąpi.
###### **Dn 2,30**
 Tajemnica ta została odsłonięta także przede mną, jednak nie po to, abym zdobył wiedzę większą niż wszyscy inni ludzie, ale po to, byś ty, królu, poznał znaczenie snu i myśli swojego serca.
###### **Dn 2,31**
 Ty, królu, patrzyłeś i ujrzałeś jakiś posąg. Był on bardzo wielki i bił od niego nadzwyczajny blask. Stał on przed tobą, a jego widok budził grozę.
###### **Dn 2,32**
 Głowa tego posągu była ze szczerego złota, jego pierś i ramiona - ze srebra, jego brzuch i biodra - z miedzi,
###### **Dn 2,33**
 jego golenie - z żelaza, a jego stopy - po części z żelaza, po części z gliny.
###### **Dn 2,34**
 Patrzyłeś, a wtem spadł kamień, choć nie dotknęła go ręka człowieka. Uderzył w ten posąg, w jego stopy, które były z żelaza i gliny, i skruszył je.
###### **Dn 2,35**
 Wtedy żelazo, glina, miedź, srebro i złoto rozsypały się na kawałki i stały się jak plewy w lecie na klepisku. Porywa je wiatr i nic po nich nie zostaje. Kamień, który uderzył w posąg, stał się wysoką górą i wypełnił całą ziemię.
###### **Dn 2,36**
 Taki był sen, a teraz objaśnię królowi jego znaczenie.
###### **Dn 2,37**
 Ciebie, o królu, królu nad królami, Bóg nieba obdarzył panowaniem i potęgą, mocą i sławą.
###### **Dn 2,38**
 W twoje ręce oddał wszystko, co żyje na tym świecie: ludzi, dzikie zwierzęta i ptaki, abyś panował nam nimi. Ty jesteś głową ze złota.
###### **Dn 2,39**
 Po tobie nastanie inne królestwo, słabsze niż twoje. Potem królestwo trzecie, które będzie z miedzi. Ono również będzie panowało nad całą ziemią.
###### **Dn 2,40**
 Królestwo czwarte będzie mocne jak żelazo, jak to żelazo, które kruszy i niszczy wszystko, które miażdży wszystko, co skruszyło i zniszczyło.
###### **Dn 2,41**
 To, że widziałeś stopy częściowo z garncarskiej gliny, a częściowo z żelaza, oznacza, że królestwo zostanie podzielone, lecz będzie miało w sobie coś z twardości żelaza. Dlatego widziałeś żelazo zmieszane z ziemistą gliną.
###### **Dn 2,42**
 Stopy po części z żelaza, po części z gliny - to znaczy królestwo będzie po części mocne, po części kruche.
###### **Dn 2,43**
 To, że widziałeś żelazo zmieszane z ziemistą gliną, oznacza, że zmieszają się oni przez ludzkie nasienie. Nie będą zespoleni, jak nie da się złączyć żelaza i gliny.
###### **Dn 2,44**
 Za dni tych królów Bóg nieba ustanowi królestwo, które na wieki nie zostanie zniszczone i żaden inny naród nie odbierze mu władzy. Ono zetrze i skruszy wszystkie te królestwa, lecz samo będzie trwać na wieki.
###### **Dn 2,45**
 Widziałeś, że kamień, który odpadł od góry, chociaż nie poruszyła go ręka człowieka, starł żelazo, miedź, glinę, srebro i złoto. Wielki Bóg dał poznać królowi, co ma się stać. Prawdziwy jest sen, a jego znaczenie pewne”.
###### **Dn 2,46**
 Wtedy król Nabuchodonozor upadł na twarz, oddał cześć Danielowi i kazał przed nim złożyć ofiarę z pokarmów i ofiarę z kadzidła.
###### **Dn 2,47**
 Powiedział król do Daniela: „Naprawdę wasz Bóg jest Bogiem ponad bogami i Panem królów! On naprawdę odsłania rzeczy ukryte, gdyż ty potrafiłeś objaśnić mi tę tajemnicę!”.
###### **Dn 2,48**
 Następnie król obdarował Daniela wspaniałymi podarkami i ustanowił go rządcą nad całą prowincją Babilonu oraz przełożonym wszystkich mędrców babilońskich.
###### **Dn 2,49**
 Daniel wyprosił u króla, aby zarząd prowincji Babilonu powierzył Szadrakowi, Meszakowi i Abednegowi, a jego zostawił na dworze królewskim.
# Dn 2 BP
###### **Dn 2,1**
 W drugim roku panowania miał Nebukadnezar sen. Zatrwożył się jego duch i sen go opuścił.
###### **Dn 2,2**
 Król polecił przywołać magów, wróżbiarzy, czarowników i Chaldejczyków, aby przedstawili królowi jego sen. Przybyli i stanęli przed obliczem króla.
###### **Dn 2,3**
 Król powiedział im: Miałem sen i duch mój niepokoi się, aby się dowiedzieć, [co to był za] sen.
###### **Dn 2,4**
 Chaldejczycy przemówili do króla po aramejsku: Królu, żyj na wieki. Opowiedz sen twoim sługom, a damy wyjaśnienie.
###### **Dn 2,5**
 Król odpowiadając rzekł Chaldejczykom: Rzecz postanowiłem. Jeśli mi nie oznajmicie snu i jego wyjaśnienia, zostaniecie poćwiartowani, a wasze domy będą zamienione w stos gruzów.
###### **Dn 2,6**
 Jeśli zaś oznajmicie sen i jego wyjaśnienie, otrzymacie ode mnie dary, upominki i będziecie bardzo uhonorowani. Dlatego oznajmijcie mi sen i jego wyjaśnienie.
###### **Dn 2,7**
 Oni przemówili po raz drugi i powiedzieli: Królu, opowiedz sen twoim sługom, a damy wyjaśnienie.
###### **Dn 2,8**
 Król odpowiadając rzekł: Ja wiem dobrze, że chcecie zyskać na czasie, albowiem widzicie, że moja decyzja jest nieodwołalna.
###### **Dn 2,9**
 Jeśli więc nie oznajmicie mi snu, jeden wyrok was czeka. Uzgodniliście, żeby wobec mnie mówić słowo kłamliwe i przewrotne, aż upłynie czas. Przeto powiedzcie mi sen, abym się dowiedział, że potraficie mi oznajmić jego znaczenie.
###### **Dn 2,10**
 Chaldejczycy, przemawiając do króla, powiedzieli: Nie ma na ziemi człowieka, który potrafi oznajmić to królowi. Żaden też król wielki, mający władzę, [takiej] rzeczy, jak ta, nie żąda od żadnego maga, wróżbiarza lub Chaldejczyka.
###### **Dn 2,11**
 Rzecz, której król się domaga, jest trudna i nie ma nikogo, kto by ją oznajmił królowi, wyjąwszy bogów, którzy nie przebywają między ludźmi.
###### **Dn 2,12**
 Król wpadł z tego powodu w złość, bardzo się rozgniewał i polecił wytracić wszystkich mędrców Babilonu.
###### **Dn 2,13**
 Wydał dekret, aby wymordowano mędrców. Szukano tedy Daniela i jego towarzyszów, aby [ich] zabić.
###### **Dn 2,14**
 Wówczas Daniel zwrócił się z roztropnością i mądrością do Ariocha, przełożonego przybocznej straży królewskiej, który wyszedł tracić mędrców babilońskich,
###### **Dn 2,15**
 i przemawiając do Ariocha, zwierzchnika królewskiego, rzekł: Dlaczego dekret królewski jest [tak] surowy? Wtedy Arioch zapoznał Daniela ze sprawą.
###### **Dn 2,16**
 Daniel poszedł i wyjednał u króla, aby dał mu czas na przygotowanie królowi wyjaśnienia.
###### **Dn 2,17**
 Potem Daniel udał się do swego domu i powiadomił o sprawie swoich przyjaciół: Chananiasza, Miszaela i Azariasza,
###### **Dn 2,18**
 aby prosili Boga niebios o miłosierdzie w sprawie tej tajemnicy, żeby nie zginęli Daniel i jego przyjaciele z resztą mędrców Babilonu.
###### **Dn 2,19**
 Wtedy w widzeniu nocnym została objawiona Danielowi tajemnica. Wówczas Daniel błogosławił Boga niebios.
###### **Dn 2,20**
 Daniel przemawiając powiedział: Niech Imię Boże będzie błogosławione od wieczności aż po wieczność, albowiem mądrość i moc do Niego należą.
###### **Dn 2,21**
 On zmienia czasy i okresy; usuwa królów i królów ustanawia; mędrcom daje mądrość; wiedzę tym, którzy poznają rozumem.
###### **Dn 2,22**
 On objawia to, co jest głębokie i co jest zakryte. Wie, co się znajduje w ciemności, a światło z Nim przebywa.
###### **Dn 2,23**
 Ciebie, Boże moich ojców, chwalę i sławię, bo Ty udzieliłeś mi mądrości i mocy. Teraz zaś dałeś mi poznać to, o cośmy Cię prosili. Sprawę króla nam oznajmiłeś.
###### **Dn 2,24**
 Poszedł przeto Daniel do Ariocha, tego, któremu król [polecił] wytracić mędrców Babilonu, [...] i tak mu powiedział: Nie trać mędrców babilońskich. Zaprowadź mnie przed króla, a oznajmię mu wyjaśnienie.
###### **Dn 2,25**
 Arioch z pośpiechem wprowadził Daniela przed króla i tak mu powiedział: Znalazłem męża wśród uprowadzonych z Judei, który da królowi wyjaśnienie.
###### **Dn 2,26**
 Król odzywając się rzekł Danielowi, który miał imię Belteszaccar: Czy ty potrafisz oznajmić mi sen, który miałem, i [dać] jego wyjaśnienie?
###### **Dn 2,27**
 Daniel, odpowiadając królowi, przemówił: Tajemnicy, o którą król pyta, mędrcy, wróżbiarze, magowie i astrologowie nie potrafią królowi oznajmić.
###### **Dn 2,28**
 Ale jest Bóg w niebie, [który] objawia tajemnice i dał poznać królowi Nebukadnezarowi, co się stanie przy końcu dni. Twój sen i widzenie w twojej głowie, [które miałeś leżąc] na łożu, były takie:
###### **Dn 2,29**
 Królu, na twoim łożu przychodziły ci myśli o tym, co będzie później. Ten zaś, który objawia tajemnice, oznajmił ci, co się stanie.
###### **Dn 2,30**
 I mnie została objawiona ta tajemnica, nie jakobym miał więcej mądrości niż wszyscy żyjący, ale dlatego, żeby mogło być oznajmione królowi wyjaśnienie, abyś poznał myśli twego serca.
###### **Dn 2,31**
 Ty, królu, miałeś takie widzenie: Oto przed tobą stał jeden posąg. Posąg ów był bardzo wielki, jego blask był nadzwyczajny, wygląd zaś straszliwy.
###### **Dn 2,32**
 Posąg ten [był taki]: jego głowa była ze szczerego złota, jego pierś i ramiona ze srebra, brzuch i biodra z brązu,
###### **Dn 2,33**
 golenie z żelaza, stopy zaś częściowo z żelaza, częściowo z gliny.
###### **Dn 2,34**
 Patrzyłeś, aż oderwał się kamień bez [pomocy] rąk, uderzył posąg w jego stopy z żelaza i gliny i zmiażdżył je.
###### **Dn 2,35**
 Wówczas zostały zdruzgotane razem: żelazo, glina, brąz, srebro i złoto. I stały się jak plewy z letnich klepisk, a wiatr uniósł je i nie znaleziono po nich żadnego śladu. Kamień zaś, który uderzył w posąg, stał się wielką górą i napełnił całą ziemię.
###### **Dn 2,36**
 Taki był sen, którego wyjaśnienie podamy królowi.
###### **Dn 2,37**
 Ty, królu, jesteś królem królów. Tobie dał Bóg niebios królestwo, potęgę, moc i sławę.
###### **Dn 2,38**
 w twoją rękę dał [każde miejsce], gdziekolwiek mieszkają synowie ludzcy, zwierzęta polne i ptaki niebieskie. Tobie dał władzę nad nimi. Ty jesteś głową ze złota.
###### **Dn 2,39**
 po tobie powstanie inne królestwo, mniejsze od twojego, a potem trzecie królestwo [jakby z] brązu, które będzie panowało nad całą ziemią.
###### **Dn 2,40**
 Czwarte królestwo będzie mocne, jak żelazo, dlatego że będzie miażdżyć i kruszyć wszystko. Jak żelazo wszystko łamiące będzie miażdżyć i łamać.
###### **Dn 2,41**
 A że widziałeś stopy i palce częściowo z gliny garncarskiej, częściowo zaś z żelaza, królestwo będzie podzielone. Będzie w nim siła żelaza, gdyż widziałeś żelazo dołączone do gliny garncarskiej
###### **Dn 2,42**
 palce stóp częściowo z żelaza, częściowo z gliny [oznaczają, że] część królestwa będzie silna, część zaś jego będzie krucha.
###### **Dn 2,43**
 Że widziałeś żelazo zmieszane z gliną garncarską, znaczy, iż zmieszają się one przez nasienie człowieka, ale nie złączą się one jedno z drugim, jak nie zmiesza się żelazo z gliną.
###### **Dn 2,44**
 W dniach owych królów Bóg niebios ustanowi królestwo, które nigdy nie zginie, królestwo, które nie przejdzie na inny naród. Zmiażdży i zniszczy wszystkie owe królestwa, ono zaś będzie trwać na wieki.
###### **Dn 2,45**
 Albowiem widziałeś, że z góry oderwał się kamień bez [udziału] rąk [ludzkich] i zmiażdżył żelazo, brąz, glinę, srebro i złoto. Wielki Bóg oznajmił królowi, co stanie się potem. Prawdziwy jest sen i pewne jego wyjaśnienie.
###### **Dn 2,46**
 Wówczas król Nebukadnezar padł na twarz, pokłonił się Danielowi i rozkazał, aby mu ofiarowano dary i wonności.
###### **Dn 2,47**
 Król przemówił do Daniela i rzekł: Prawdziwie, Bóg wasz jest Bogiem bogów i Panem królów, objawiającym skryte rzeczy, gdyż mogłeś wyjawić tę tajemnicę.
###### **Dn 2,48**
 Potem król wywyższył Daniela, obdarzył go licznymi, wielkimi darami, dał mu władzę nad całą prowincją babilońską i [mianował go] głównym przełożonym wszystkich mędrców Babilonu.
###### **Dn 2,49**
 Daniel jednak prosił króla, aby powierzył sprawy [zarządu] prowincji Babilonu Szadrakowi, Meszakowi i Abed Negowi. Daniel zaś pozostał na dworze króla.
# Dn 2 BR
###### **Dn 2,1**
 W drugim roku swego panowania Nabuchodonozor miał sen, który tak go zaniepokoił, że nie mógł spać.
###### **Dn 2,2**
 Kazał tedy król zwołać wróżbitów, zaklinaczy, czarnoksiężników i Chaldejczyków, żeby odgadli, jaki miał sen, i żeby mu wyjaśnili znaczenie sennych widzeń. Przyszli więc i stanęli przed królem.
###### **Dn 2,3**
 A król powiedział im: Miałem pewien sen, który sprawił, że niespokojny jest teraz mój duch, bo nie wiem, co sen ten ma znaczyć.
###### **Dn 2,4**
 Rzekli na to Chaldejczycy: Królu, obyś żył wiecznie! Racz opowiedzieć swój sen twoim sługom, a my powiemy ci, co on oznacza.
###### **Dn 2,5**
 A król tak odpowiedział Chaldejczykom: Chciałbym, żebyście już teraz wiedzieli, co was czeka: jeżeli nie odgadniecie, co mi się śniło, i nie wyjaśnicie znaczenia sennych widzeń, każę rozszarpać wasze ciała i zrównać z ziemią wasze domy.
###### **Dn 2,6**
 Jeżeli zaś powiecie, jaki był mój sen, i wyjaśnicie mi jego znaczenie, otrzymacie ode mnie różne dary, upominki i zaszczytne urzędy. Tak więc powiedzcie mi, co mi się śniło i co mój sen oznacza.
###### **Dn 2,7**
 A oni znów rzekli: Racz opowiedzieć, królu, swoim sługom sen, a my ci wyjaśnimy jego znaczenie.
###### **Dn 2,8**
 Lecz król na to: Wiem dobrze, iż zwlekacie z odpowiedzią, gdyż znacie już moje zamiary.
###### **Dn 2,9**
 Jeżeli nie powiecie sami, co mi się śniło, to będzie jasne, że postanowiliście opowiadać mi różne wykrętne kłamstwa, zyskując w ten sposób na czasie. Dlatego jeszcze raz powtarzam: powiedzcie, co mi się śniło, a wtedy przekonam się, że potraficie mi wytłumaczyć także znaczenie mojego snu.
###### **Dn 2,10**
 Na to odrzekli Chaldejczycy królowi: Nie ma nikogo na ziemi, kto by potrafił spełnić to życzenie króla. I dlatego żaden inny król, zarządca czy władca nie domaga się rzeczy podobnych od swoich czarowników, wróżbitów czy Chaldejczyków.
###### **Dn 2,11**
 Pytanie, które król nam stawia, jest bardzo trudne i nikt nie potrafi odpowiedzieć na nie królowi. Mogliby to zrobić tylko bogowie, ale oni nie przebywają wśród ludzi.
###### **Dn 2,12**
 Wtedy król uniósł się wielkim gniewem i rozkazał wytracić wszystkich mędrców babilońskich.
###### **Dn 2,13**
 Gdy wyszedł dekret skazujący na śmierć mędrców, zginąć miał także Daniel i jego towarzysze.
###### **Dn 2,14**
 Lecz Daniel w słowach pełnych ostrożności i taktu zwrócił się do Arioka, dowódcy królewskiej straży przybocznej, który już przybył, aby wygładzić mędrców babilońskich.
###### **Dn 2,15**
 Powiedział tak do Arioka, dowódcy straży królewskiej: Dlaczego król wydał aż tak surowy dekret? Wtedy Ariok opowiedział wszystko Danielowi.
###### **Dn 2,16**
 Udał się tedy Daniel do króla i prosił, żeby mu dał trochę czasu na odgadnięcie snu królewskiego i na wytłumaczenie znaczenia sennych widzeń.
###### **Dn 2,17**
 Wróciwszy do siebie, Daniel powtórzył wszystko swoim towarzyszom Chananiaszowi, Miszaelowi i Azariaszowi.
###### **Dn 2,18**
 Zachęcał ich również, aby błagali miłosierdzia Boga Niebieskiego o poznanie tajemnicy króla, bo tylko wtedy ocaleje Daniel razem ze swymi towarzyszami, a także wszyscy mędrcy babilońscy.
###### **Dn 2,19**
 I oto w widzeniu nocnym została Danielowi objawiona tajemnica. Błogosławił tedy Daniel Boga niebios
###### **Dn 2,20**
 mówiąc: Niech imię Boga będzie błogosławione przez wszystkie wieki wieków, bo jest wszechwiedzący i możny.
###### **Dn 2,21**
 To On sprawia, że zmieniają się okresy i czasy, to On usuwa jednych władców, a ustanawia drugich, to On mędrcom daje mądrość i łaskę rozeznania roztropnym.
###### **Dn 2,22**
 To On przenika głębie i sekrety, zna wszystko, co ukryte w ciemnościach, a światłość otacza Go zewsząd.
###### **Dn 2,23**
 Ciebie, Boga mych ojców, uwielbiam i sławię za to, żeś mi dał i mądrość, i rozum! Objawiłeś mi to, o co Cię błagałem. Ty nam objawiłeś tajemnicę króla.
###### **Dn 2,24**
 Potem udał się Daniel do Arioka, któremu król rozkazał wytracić mędrców babilońskich. Stanął przed nim i powiedział do niego tak: Nie zabijaj [jeszcze] mędrców babilońskich. Zaprowadź mnie do króla, a ja przedstawię królowi znaczenie jego snu.
###### **Dn 2,25**
 Zaprowadził więc Ariok Daniela co prędzej do króla mówiąc: Wśród ludzi uprowadzonych z Judy znalazłem człowieka, który wytłumaczy znaczenie snu królewskiego.
###### **Dn 2,26**
 Powiedział tedy król do Daniela [który nazywał się również Belteszassar]: Czy rzeczywiście będziesz mógł mi powiedzieć, jaki miałem sen i co ten sen oznacza?
###### **Dn 2,27**
 A Daniel rzekł na to królowi: Ani mędrcy, ani czarnoksiężnicy, ani wróżbici i tłumacze snów nie mogą odgadnąć tajemnicy króla.
###### **Dn 2,28**
 Ale jest Bóg na niebiosach, który zna wszelkie tajemnice i On to objawi królowi Nabuchodonozorowi, co zdarzy się przy końcu dni [tego świata]. Twój sen oraz widzenia, jakie miałeś w nocy, tak oto należy tłumaczyć:
###### **Dn 2,29**
 Wszystko, co widziałeś, o królu, w czasie snu dotyczy przyszłości, która cię czeka, a Ten, który zna wszystkie tajemnice, objawił ci to, co ma przyjść na ciebie.
###### **Dn 2,30**
 Mnie również, choć nie jestem mądrzejszy od innych, ta tajemnica została objawiona, lecz tylko dlatego, bym mógł jej znaczenie przedstawić królowi. W ten sposób będziesz mógł poznać najskrytsze tajniki swego serca.
###### **Dn 2,31**
 A oto widzenie, które miałeś, o królu: Ukazał ci się posąg ogromnych rozmiarów, cały błyszczący. Wznosił się naprzeciw ciebie i budził przerażenie tak wielkie, że nie mogłeś nań patrzeć.
###### **Dn 2,32**
 Głowa tego posągu była ze złota, piersi i ramiona ze srebra, brzuch i biodra z brązu,
###### **Dn 2,33**
 nogi z żelaza, a stopy częściowo z żelaza a częściowo z gliny.
###### **Dn 2,34**
 Kiedy patrzyłeś na posąg, z góry oderwał się kamień, mimo iż nikt nawet go nie dotknął ręką, runął na stopy z żelaza i gliny i zmiażdżył je.
###### **Dn 2,35**
 Równocześnie rozkruszyło się żelazo i glina, oraz części z brązu, srebra i złota. Wszystko wyglądało jak plewy w lecie na klepisku. Powiał wiatr i uniósł je w górę, tak że nawet ślad po nich nie pozostał. Kamień zaś, który ugodził w posąg, zamienił się w górę tak potężną, że wypełniła całą ziemię.
###### **Dn 2,36**
 Taki był ów sen, którego znaczenie zaraz królowi wytłumaczymy.
###### **Dn 2,37**
 Tobie, o królu, władco wszystkich królów, Bóg niebios przekazał królestwo, władzę, potęgę i chwałę.
###### **Dn 2,38**
 W twoje ręce wydał wszystkich synów ludzkich, zwierzęta polne, ptaki powietrzne. Gdziekolwiek się znajdują, wszystkie je poddał pod twoją władzę. To właśnie ty jesteś tą głową ze złota.
###### **Dn 2,39**
 Po tobie jednak powstanie inne królestwo, mniejsze od twojego, a potem jeszcze jedno, trzecie już z kolei, królestwo z brązu, obejmujące swym zasięgiem całą ziemię.
###### **Dn 2,40**
 Przyjdzie wreszcie królestwo czwarte, twarde jak żelazo tak twarde, ze kruszy wszystko na proch i miażdży. Otóż, jak żelazo kruszy wszystko i miażdży, tak za czasów tego królestwa wszystko będzie zmiażdżone i skruszone.
###### **Dn 2,41**
 Te stopy, które widziałeś, częściowo z żelaza a częściowo z gliny oznaczają, królestwo będzie podzielone; będzie częściowo trwałe jak z żelaza. A to, że żelazo jest zmieszane z gliną
###### **Dn 2,42**
 zaś palce u nóg są częściowo z żelaza a częściowo z gliny [oznacza] że całe królestwo będzie w pewnym okresie trwałe, kiedy indziej zaś kruche.
###### **Dn 2,43**
 To pomieszanie żelaza z gliną, które widziałeś, oznacza ich przemieszanie się poprzez ludzkie nasienie, ale nigdy nie będą tworzyć całości, tak jak żelazo nigdy nie da się połączyć w jedno z gliną.
###### **Dn 2,44**
 W czasach tych władców Bóg niebios da początek królestwu, które nigdy nie będzie zniszczone i które nie przejdzie na inny naród. To ono zmiażdży i zniweczy wszystkie królestwa, ale samo trwać będzie na wieki.
###### **Dn 2,45**
 Widziałeś też, jak od zbocza górskiego, choć nie tknęła go ludzka ręka, oderwał się głaz skalny i [swoim ciężarem] zamienił w pył żelazo, brąz, glinę, srebro i złoto. W taki to sposób zapowiedział ci Bóg to wszystko, co ma nadejść. Ten sen jest prawdziwy, a jego wyjaśnienie pewne.
###### **Dn 2,46**
 Wtedy król Nabuchodonozor upadł na ziemię i oddał cześć Danielowi. Rozkazał też, by złożono mu dary i wonne kadzidła.
###### **Dn 2,47**
 I powiedział król Do Daniela: Zaprawdę, wasz Bóg jest Bogiem wszystkich bogów i Panem wszystkich królów. Zna On też wszystkie tajemnice, skoro ty potrafiłeś wyjawić ten sekret.
###### **Dn 2,48**
 I powierzył król Danielowi zaszczytny urząd, i obsypał go mnóstwem wspaniałych darów. Oddał pod jego zarząd całą prowincję babilońską i uczynił go przełożonym wszystkich mędrców babilońskich.
###### **Dn 2,49**
 Lecz Daniel poprosił, żeby król zlecił Szadrakowi, Meszakowi i Abed-Negowi zajmowanie się rządami prowincji, a on sam, Daniel, pozostał przy boku króla.
# Dn 2 WUJ
###### **Dn 2,1**
 Roku wtórego królestwa Nabuchodonozora, widział Nabuchodonozor sen, i zlękł się duch jego, a sen jego odszedł od niego.
###### **Dn 2,2**
 I rozkazał król, aby przyzwano wieszczków, i czarnoksiężników, i czarowników, i Chaldejczyków, żeby oznajmili królowi sny jego: którzy gdy przyszli, stanęli przed królem.
###### **Dn 2,3**
 I rzekł do nich król: Widziałem sen: a na myśli będąc zatrwożony, nie wiem com widział.
###### **Dn 2,4**
 I odpowiedzieli Chaldejczycy królowi po Syryjsku: królu żyj na wieki: powiedz sen sługom swym, a wykład jego oznajmiemy.
###### **Dn 2,5**
 A odpowiadając król rzekł Chaldejczykom: Mowa odeszła odemnie: jeśli mi nie oznajmicie snu i wykładu jego, zginiecie wy, a domy wasze pospolite będą.
###### **Dn 2,6**
 Lecz jeśli sen i wykład jego powiecie, zapłaty, i dary, i cześć wielką odniesiecie odemnie: sen tedy i wykład jego pokażcie mi.
###### **Dn 2,7**
 Odpowiedzieli powtóre, i rzekli: król niech powie sen sługom swoim, a wykład jego pokażemy.
###### **Dn 2,8**
 Odpowiedział król i rzekł: Zaiste wiem, że czas odkupujecie, wiedząc, iż odeszła mowa odemnie.
###### **Dn 2,9**
 A tak, jeśli mi snu nie oznajmicie, jeden jest wyrok o was, żebyście wykład fałeszny i zdrady pełny złożyli, abyście mówili przedemną, ażby czas przeminął. Przeto sen powiedzcie mi, abych wiedział, że też wykład jego prawdziwy powiadacie.
###### **Dn 2,10**
 Tedy odpowiedając Chaldejczycy przed królem, rzekli: Niemasz człowieka na ziemi, któryby mowę twą królu mógł wypełnić: lecz ani żaden z królów wielki i możny, o słowo takowe nie pyta się od żadnego wieszczka, i czarownika, i Chaldejczyka.
###### **Dn 2,11**
 Bo mowa, o którą się ty pytasz królu ciężka jest: ani się najdzie żaden, ktoby ją oznajmił przed obliczem królewskiem: oprócz bogów, których obcowanie nie jest z ludźmi.
###### **Dn 2,12**
 Co usłyszawszy król w zapalczywości i w gniewie wielkim rozkazał, aby zginęli wszyscy mędrcy Babilońscy.
###### **Dn 2,13**
 A gdy wyszedł dekret, zabijano mędrce, i szukano Daniela i towarzyszów jego, aby zginęli:
###### **Dn 2,14**
 Tedy Daniel pytał się o prawie, i o wyroku, od Ariocha hetmana żołnierstwa królewskiego, który był wyszedł aby pobił mędrce Babilońskie.
###### **Dn 2,15**
 I pytał onego, który był wziął moc od króla, dla czego tak srogi wyrok od oblicza królewskiego wyszedł. Gdy tedy Arioch rzecz oznajmił Danielowi,
###### **Dn 2,16**
 Daniel wszedłszy prosił króla, żeby mu dał czas na oznajmienie wykładu królowi.
###### **Dn 2,17**
 I wszedł do domu swego, i oznajmił rzecz Ananiaszowi, i Misaelowi, i Azaryaszowi, towarzyszom swoim:
###### **Dn 2,18**
 Aby szukali miłosierdzia od oblicza Boga niebieskiego, około tej tajemnice, a nie zginęli Daniel i towarzysze jego, z innemi mędrcami Babilońskimi.
###### **Dn 2,19**
 Tedy Danielowi tajemnica przez widzenie w nocy jest objawiona: i błogosławił Daniel Boga niebieskiego,
###### **Dn 2,20**
 I mówiąc rzekł: Niech będzie imię Pańskie błogosławione od wieku aż do wieku: bo jego jest mądrość i moc.
###### **Dn 2,21**
 I on odmienia czasy i wieki: przenosi królestwa, i stanowi: daje mądrość mądrym, i umiejętność rozumiejącym naukę.
###### **Dn 2,22**
 On odkrywa głębokości i skrytości, i wie rzeczy w ciemności postanowione: a światłość z nim mieszka.
###### **Dn 2,23**
 Tobie Boże ojców naszych wyznawam, i chwalę cię, żeś mi dał mądrość i moc: i teraz oznajmiłeś mi o cośmy cię prosili, żeś nam mowę królewską otworzył.
###### **Dn 2,24**
 Potem Daniel, wszedłszy do Ariocha, którego był naznaczył król, aby wytracił mędrce Babijońskie, tak mu rzekł: Mędrców Babilońskich nie trać: wiedź mię przed oblicze królewskie, a wykład królowi powiem.
###### **Dn 2,25**
 Tedy Arioch z kwapieniem wwiódł Daniela do króla i rzekł mu: Nalazłem człowieka z synów przeprowadzenia Judzkiego, który wykład królowi oznajmi.
###### **Dn 2,26**
 Odpowiedział król, i rzekł Danielowi, któremu imię było Balthazar: Co mniemasz, możeszli mi prawdziwie oznajmić sen, którym widział, i wykład jego?
###### **Dn 2,27**
 A odpowiadając Daniel przed królem, rzekł: Tajemnice, której król pyta, mędrcy, czarnoksiężnicy, wieszczkowie, i praktykarze nie mogą oznajmić królowi.
###### **Dn 2,28**
 Ale jest Bóg na niebie, który odkrywa tajemnice, który oznajmił tobie królu Nabuchodonozorze, co ma przyjść czasów ostatecznych. Sen twój, i widzenia głowy twojej na łożu twem, takowe są.
###### **Dn 2,29**
 Ty królu począłeś myślić na pościeli twej coby miało być na potem: a który odkrywa tajemnice, pokazał tobie co ma przyjść.
###### **Dn 2,30**
 Mnie też nie mądrością, któraby była we mnie więtsza niźli we wszystkich żywiących, tajemnica ta jest objawiona: ale aby wykład królowi oznajmion był, a żebyś wiedział myśli serca twego.
###### **Dn 2,31**
 Ty królu widziałeś, a oto jakby obraz jeden wielki, obraz on wielki, i obraz wysoki stał przeciw tobie, a pojrzenie jego było straszne:
###### **Dn 2,32**
 Tego obrazu głowa była ze złota co lepszego, a piersi i ramiona ze srebra, brzuch i biodra z miedzi:
###### **Dn 2,33**
 A goleni żelazne, nóg część niektóra była żelazna, a niektóra gliniana.
###### **Dn 2,34**
 Takeś widział, aż odcięt jest kamień z góry bez rąk, uderzył obraz w nogi jego żelazne i gliniane, i skruszył je.
###### **Dn 2,35**
 Tedy skruszyło się społem żelazo, skorupa, miedź, srebro i złoto, i obróciło się jako w proch letniego bojowiska, które zaniósł wiatr: i nie nalazło się im żadne miejsce: a kamień, który był uderzył w obraz, stał się górą wielką, i napełnił wszystkę ziemię.
###### **Dn 2,36**
 Ten jest sen. Wykład też jego powiemy przed tobą królu:
###### **Dn 2,37**
 Tyś jest królem królów: a Bóg niebieski królestwo, i moc, i panowanie, i sławę dał tobie:
###### **Dn 2,38**
 I wszystko w czem mieszkają synowie ludzcy, i zwierzęta polne, ptastwo też powietrzne dał w rękę twą, a pod mocą twoją wszystko postanowił: a tak tyś jest głową złotą.
###### **Dn 2,39**
 A po tobie powstanie królestwo insze mniejsze niźli ty, srebrne, i trzecie królestwo insze miedziane, które będzie panowało po wszystkiej ziemi.
###### **Dn 2,40**
 A królestwo czwarte będzie jako żelazo: jako żelazo kruszy i kroci wszystko, tak połamie i pokruszy to wszystko.
###### **Dn 2,41**
 A iżeś widział nóg i palców część skorupy garncarskiej, a część żelazną: królestwo rozdzielone będzie, które jednak z dużości żelaza wynidzie, wedle tego jakoś widział żelazo zmieszane z skorupą z gliny.
###### **Dn 2,42**
 A palce nóg częścią żelazne, a częścią gliniane, królestwo częścią będzie mocne, a częścią skruszone.
###### **Dn 2,43**
 A żeś widział żelazo zmieszane z skorupą z gliny, pomieszają się wprawdzie nasieniem człowieczem, ale się z sobą nie spoją: jako żelazo nie może się zmieszać z skorupą.
###### **Dn 2,44**
 A we dni onych królestw wzbudzi Bóg niebieski królestwo, które się na wieki nie rozproszy: a królestwo jego nie będzie dane ludowi innemu: a połamie i zniszczy te wszystkie królestwa, a samo stać będzie na wieki.
###### **Dn 2,45**
 Wedle tego, żeś widział, że z góry odcięt jest kamień bez rąk, i pokruszył skorupę i żelazo, i miedź, i srebro, i złoto: Bóg wielki pokazał królowi co ma przyjść potem, a prawdziwy jest sen, i wierny wykład jego.
###### **Dn 2,46**
 Tedy król Nabuchodonozor padł na oblicze swe, i pokłonił się Danielowi, i ofiary i kadzenie kazał, aby mu ofiarowali.
###### **Dn 2,47**
 Mówiąc tedy król, rzekł Danielowi: Prawdziwie Bóg wasz jest Bogiem bogów, i panem królów, i odkrywaczem tajemnic: ponieważeś ty mógł otworzyć tę tajemnice.
###### **Dn 2,48**
 Tedy król wyniósł wysoko Daniela, i darów wiele i wielkich dał mu. I uczynił go książęciem nad wszystkiemi krainami Babilońskimi, i przełożonym nad urzędnikami, nad wszystkie mędrce Babilońskie.
###### **Dn 2,49**
 A Daniel prosił u króla, i przełożył nad sprawami krainy Babilońskiej, Sydraha, Misacha i Abdenaga: a sam Daniel był we drzwiach królewskich.
