# Hi 9 BT5
###### **Hi 9,1**
 Wówczas zabrał głos Hiob i rzekł:
###### **Hi 9,2**
 «***Istotnie. Ja wiem, że tak jest. Jak człowiek może być przed Bogiem prawy?***
###### **Hi 9,3**
 ***Gdyby się ktoś z Nim prawował, nie odpowie raz jeden na tysiąc.***
###### **Hi 9,4**
 ***Umysłem mądry, a potężny mocą. Któż Mu się sprzeciwi, a ocaleje?***
###### **Hi 9,5**
 ***Przesunie On góry, choć one nie wiedzą, kto je wywraca w swym gniewie.***
###### **Hi 9,6**
 ***On ziemię porusza w posadach, tak iż się trzęsą jej filary.***
###### **Hi 9,7**
 ***Słońcu daje rozkaz, a ono nie wschodzi, na gwiazdy pieczęć nakłada.***
###### **Hi 9,8**
 ***On sam rozciąga niebiosa, kroczy po morskich głębinach;***
###### **Hi 9,9**
 ***On stworzył Niedźwiedzicę, Oriona, Plejady i Strefy Południa.***
###### **Hi 9,10**
 ***On czyni cuda niezbadane, nikt nie zliczy Jego dziwów.***
###### **Hi 9,11**
 ***Oto przechodzi, ale Go nie widzę, mija, ale Go nie dostrzegam.***
###### **Hi 9,12**
 ***Porywa – któż Mu zabroni? Kto Mu powie: Co czynisz?***
###### **Hi 9,13**
 ***Bóg gniewu swego nie cofa, ugięli się przed Nim pomocnicy Rahaba.***
###### **Hi 9,14**
 ***Jakże ja zdołam z Nim mówić? [Jakich] dobiorę słów wobec Niego?***
###### **Hi 9,15**
 ***Choć słuszność mam, nie odpowiem, a przecież błagać będę o litość.***
###### **Hi 9,16**
 ***Jeśli zawołam, czy mi odpowie? Nie mam pewności, czy głos mój słyszy.***
###### **Hi 9,17**
 ***On, który w burzy na mnie naciera, bez przyczyny mnoży moje rany.***
###### **Hi 9,18**
 ***Nawet odetchnąć mi nie da, tak mnie napełni goryczą.***
###### **Hi 9,19**
 ***O siłę chodzi? To mocarz. O sąd? To kto mnie pozwie?***
###### **Hi 9,20**
 ***Choć jestem prawy, usta mnie potępią, chociaż bez skazy – winnym mnie uznają.***
###### **Hi 9,21**
 ***Czy jestem bez skazy? Nie znam sam siebie, odrzucam swe życie.***
###### **Hi 9,22**
 ***Na jedno wychodzi, więc rzekłem: Prawego z występnym On zniszczy.***
###### **Hi 9,23**
 ***Gdy nagła plaga zabija, z klęski niewinnych On szydzi.***
###### **Hi 9,24**
 ***Ziemia wydana w ręce grzesznika, jej sędziom zakrywa On oblicza. Jeśli nie On – to kto właściwie?***
###### **Hi 9,25**
 ***Szybsze me dni niźli biegacz, uciekają, nie zaznawszy szczęścia,***
###### **Hi 9,26**
 ***mkną jak łodzie z sitowia, jak orzeł, co spada na żer.***
###### **Hi 9,27**
 ***Gdy powiem: Zapomnę o męce, odmienię, rozjaśnię oblicze –***
###### **Hi 9,28**
 ***drżę na myśl o cierpieniu, wiem, że od winy mnie nie uwolnisz.***
###### **Hi 9,29**
  ***Jeśli jestem grzesznikiem, po cóż na próżno się trudzę?***
###### **Hi 9,30**
 ***Choćbym się w śniegu wykąpał, a ługiem umył swe ręce,***
###### **Hi 9,31**
 ***umieścisz mnie tam, na dole. Brzydzić się będą mną szaty.***
###### **Hi 9,32**
 ***Bo On nie człowiek, by Mu odpowiedzieć: Razem się udajmy do sądu!***
###### **Hi 9,33**
 ***Czy jest między nami rozjemca, co rękę położy na obu?***
###### **Hi 9,34**
 ***Niech zdejmie ze mnie swą rózgę i strachem mnie nie napełnia,***
###### **Hi 9,35**
 ***bym mówić zdołał bez lęku. Skoro tak nie jest, zostaję sam z sobą.***
# Hi 9 PAU
###### **Hi 9,1**
 Hiob tak odpowiedział:
###### **Hi 9,2**
 „Oczywiście, wiem, że tak jest. W sporze z Bogiem człowiek nie zdoła wykazać swej sprawiedliwości.
###### **Hi 9,3**
 Jeśli ktoś chciałby się z Nim spierać, On nie odpowie nawet raz na tysiąc.
###### **Hi 9,4**
 Jest mądry i potężny w mocy, któż Mu się sprzeciwi i pozostanie cały?
###### **Hi 9,5**
 On góry przenosi, a one nawet nie wiedzą, że przewraca je w swoim gniewie.
###### **Hi 9,6**
 Porusza ziemię z jej miejsca i trzęsą się jej fundamenty.
###### **Hi 9,7**
 Wydaje rozkaz słońcu i ono nie wschodzi, gwiazdy zamyka pieczęcią.
###### **Hi 9,8**
 On sam rozwiesza niebiosa, kroczy po powierzchni morza.
###### **Hi 9,9**
 On stworzył Niedźwiedzicę, Oriona, Plejady i Komnaty Wiatrów Południa.
###### **Hi 9,10**
 On stworzył wszystko, co wielkie, niezgłębione i przedziwne, czego zliczyć nie można.
###### **Hi 9,11**
 Oto przechodzi, a ja Go nie widzę! Mija mnie, a ja Go nie dostrzegam!
###### **Hi 9,12**
 Oto porywa, kto nakaże, by oddał? Kto mógłby spytać: «Co czynisz?».
###### **Hi 9,13**
 Bóg nie powstrzymuje swego gniewu, korzą się przed Nim nawet pomocnicy Rahaba.
###### **Hi 9,14**
 Tym bardziej ja nie mogę Mu odpowiedzieć. Czy zdołam dobrać słowa, aby się z Nim spierać?
###### **Hi 9,15**
 Choćbym miał słuszność, cóż mógłbym odpowiedzieć? Swego Sędziego musiałbym błagać o łaskę!
###### **Hi 9,16**
 Jeśli nawet mógłbym Go pozwać, On nie odpowie. Nie wierzę, że będzie słuchał mojego głosu!
###### **Hi 9,17**
 Raczej by zmiażdżył mnie burzą i pomnożył moje rany bez powodu.
###### **Hi 9,18**
 Nie dałby mi odetchnąć, raczej by mnie nasycił goryczą.
###### **Hi 9,19**
 Jeśli chodzi o moc, to On jest potężny, ale gdy chodzi o prawo, nie zdoła wykazać mi winy!
###### **Hi 9,20**
 Chociaż jestem niewinny, potępią mnie moje usta. Jestem doskonały, a On uzna mnie za przewrotnego.
###### **Hi 9,21**
 Jestem doskonały? Sam nie wiem... Gardzę swoim życiem.
###### **Hi 9,22**
 Wiem jedno i oświadczam: On niszczy zarówno doskonałego, jak i grzesznika!
###### **Hi 9,23**
 Gdy nagle bicz porazi śmiertelnie, On naśmiewa się z rozpaczy uczciwych.
###### **Hi 9,24**
 Kiedy kraj dostaje się w ręce przewrotnych, On zasłania sędziom oczy. Bo jeśli nie On, to kto właściwie?
###### **Hi 9,25**
 Moje dni biegną szybciej niż zawodnik, przemijają, ale szczęścia nie widzą.
###### **Hi 9,26**
 Mkną jak łodzie z papirusowej trzciny, jak orzeł spadający na zdobycz.
###### **Hi 9,27**
 Gdybym nawet chciał zapomnieć o swojej udręce, już się nie przejmował i chciał się weselić,
###### **Hi 9,28**
 przeraża mnie nadmiar moich cierpień, gdyż wiem, że Ty nie uznasz mej niewinności.
###### **Hi 9,29**
 A więc jestem winny! Po cóż mam się trudzić na próżno?
###### **Hi 9,30**
 Nawet gdybym umył się mydłem i sodą oczyścił swe dłonie,
###### **Hi 9,31**
 wtedy zanurzyłbyś mnie w rynsztoku i moje ubranie by się mną brzydziło.
###### **Hi 9,32**
 Bóg bowiem nie jest człowiekiem jak ja, bym mógł powiedzieć: «Chodźmy razem do sądu!».
###### **Hi 9,33**
 Nie ma między nami rozjemcy, który by swoją rękę położył na nas obu.
###### **Hi 9,34**
 Gdyby choć odsunął ode mnie swoją rózgę i nie napełniał mnie strachem i przerażeniem,
###### **Hi 9,35**
 wtedy mógłbym mówić do Niego bez lęku, bo nie mam sobie nic do zarzucenia.
# Hi 9 BP
###### **Hi 9,1**
 Job zabrał głos i [tak] odpowiedział:
###### **Hi 9,2**
 Oczywiście wiem ja, że tak jest, bo czy prawym okaże się człek wobec Boga?
###### **Hi 9,3**
 Gdyby chciał się z Nim spierać, nie odpowie mu nawet raz na tysiąc razy.
###### **Hi 9,4**
 Serce Jego jest mądre i siła potężna, kto zdoła Mu się przeciwstawić i ocalić siebie?
###### **Hi 9,5**
 On niepostrzeżenie góry przenosi i w gniewie swoim je wywraca.
###### **Hi 9,6**
 On wstrząsa ziemią w jej posadach, tak że chwieją się jej fundamenty.
###### **Hi 9,7**
 On słońcu może rozkazać, aby nie wschodziło, On gwiazdy zamyka pieczęcią.
###### **Hi 9,8**
 On sam niebiosa rozpina i przechadza się po morskiej głębi.
###### **Hi 9,9**
 On stworzył Niedźwiedzicę i Oriona, Plejady i gwiazdy południa.
###### **Hi 9,10**
 On czyni rzeczy wielkie, niezgłębione i cudowne, których zliczyć nie sposób.
###### **Hi 9,11**
 Nie dostrzegam Go, gdy obok mnie przechodzi, mija mnie, a ja Go nie widzę.
###### **Hi 9,12**
 Gdy porywa siłą, któż Go zmusi do oddania, kto Mu powie: "Co Ty czynisz?"
###### **Hi 9,13**
 Bóg gniewu swego nie odwraca, przed Nim upadają pomocnicy Rahab.
###### **Hi 9,14**
 Jakże ja mógłbym odeprzeć Jego zarzuty, jakich dobrać słów, aby z Nim rozmawiać?
###### **Hi 9,15**
 Chociaż miałbym słuszność, On nie odpowiada, mamże błagać o litość swojego sędziego?
###### **Hi 9,16**
 A chociażby nawet odpowiedział na moje wezwanie, czy mam pewność, że głosu mego wysłucha?
###### **Hi 9,17**
 On zniszczyć mnie może burzą i pomnożyć moje rany bez powodu.
###### **Hi 9,18**
 Nawet odetchnąć mi nie pozwoli, ale wciąż napełnia mnie goryczą.
###### **Hi 9,19**
 Jeśli o siłę chodzi, On najmocniejszy, jeśli o sąd, kto za mną zaświadczy?
###### **Hi 9,20**
 Choćbym miał i słuszność, usta moje mnie potępią, i choćbym niewinnym się okazał, one oświadczą, żem przewrotny.
###### **Hi 9,21**
 Czy jestem niewinny? Nie znam sam siebie, gardzę już własnym życiem.
###### **Hi 9,22**
 Dlatego to powiedziałem: "Prawdą jest jedno: On zniszczy zarówno prawego, jak i grzesznika".
###### **Hi 9,23**
 Gdy nagła powódź śmierć przynosi, On się naśmiewa z cierpień niewinnych.
###### **Hi 9,24**
 Ziemię wydał w ręce przewrotnych, sędziom zasłania oblicza. Jeśli to nie On, to kto właściwie?
###### **Hi 9,25**
 Szybsze są dni moje od [biegu] zawodnika, minęły i nie widziały szczęścia,
###### **Hi 9,26**
 przeminęły jak łodzie trzcinowe, jak orzeł, co spada na ofiarę.
###### **Hi 9,27**
 Gdy powiem sobie: "Zapomnę o mych skarbach, odmienię swoje oblicze i będę wesoły",
###### **Hi 9,28**
 zaraz przeraża mnie myśl o cierpieniach, bo wiem, że Ty mnie nie uznasz za niewinnego.
###### **Hi 9,29**
 A jeśli jestem grzesznikiem, to po cóż się dręczę na próżno?
###### **Hi 9,30**
 Chociażbym się umył w śniegu i sodą oczyścił me ręce,
###### **Hi 9,31**
 Ty i tak umieścisz mnie w dole, szaty moje nawet brzydzić się mną będą.
###### **Hi 9,32**
 Bóg nie jest człowiekiem jak ja, abym mógł powiedzieć do Niego: "Razem staniemy przed sądem".
###### **Hi 9,33**
 Czyż jest między nami rozjemca, który by rękę położył na nas obu?
###### **Hi 9,34**
 Niech zdejmie ze mnie swoją rózgę i strach Jego niech mnie już nie przeraża.
###### **Hi 9,35**
 Wtedy będę mówił i nie będę się Go lękał, a ponieważ tak nie jest, nie jestem pewny siebie.
# Hi 9 BR
###### **Hi 9,1**
 Wtedy Hiob tak odpowiedział:
###### **Hi 9,2**
 Wiem to dobrze, to prawda, że nie jest prawy przed Bogiem żaden człowiek.
###### **Hi 9,3**
 Gdyby ktoś wobec Niego chciał swych praw dochodzić, z tysiąca pytań - nie odpowie na żadne.
###### **Hi 9,4**
 Jego mądrości i sile żaden przeciwnik nie sprosta.
###### **Hi 9,5**
 Nawet góry przenosi, które nic nie wiedzą, że ściera je w swym gniewie.
###### **Hi 9,6**
 Całą ziemią potrząsa w posadach, aż jej kolumny chwieją się i trzeszczą.
###### **Hi 9,7**
 On każe słońcu, żeby się zaćmiło, i na gwiazdy nakłada pieczęcie.
###### **Hi 9,8**
 On sam rozpina niebiosa, chodzi po otchłaniach morskich.
###### **Hi 9,9**
 To On stworzył Niedźwiedzicę i Oriona, Plejady i Komnaty Południa.
###### **Hi 9,10**
 Stworzył rzeczy tak wielkie, że nikt ich nie zbada, cuda, których nikt nie policzy.
###### **Hi 9,11**
 Przechodzi obok - ja Go nie dostrzegam, mija mnie - nadal Go nie widzę.
###### **Hi 9,12**
 Kto powstrzyma Jego niszczące ramie? Kto ośmieli się spytać: Co czynisz?
###### **Hi 9,13**
 Bóg nie hamuje swych porywów gniewu, nawet córki Rahaba muszą Mu ulegać.
###### **Hi 9,14**
 Jak więc odważę się kiedyś z Nim spotkać, jakimi słowami zdołam Go przekonać?
###### **Hi 9,15**
 Choćbym miał rację, nic Mu nie powiem, tylko o litość będę błagał Sędziego.
###### **Hi 9,16**
 Nawet gdy Go zawołam, czy mi odpowie? Nie mam żadnej pewności, że słów moich słucha.
###### **Hi 9,17**
 On jak burza zwala mnie na ziemię i bez powodu pomnaża me rany.
###### **Hi 9,18**
 nie pozwala mi chwycić oddechu i bezustannie poi mnie goryczą.
###### **Hi 9,19**
 Pod względem siły On jest mocarzem, w dochodzeniu prawa nikt Mu nie sprosta.
###### **Hi 9,20**
 Choćbym nawet miał rację, moje własne usta zaczną mnie oskarżać, choćbym był bez grzechu, one same uznają mnie za winnego.
###### **Hi 9,21**
 Czym rzeczywiście niewinny - sam tego nie wiem, zbrzydło mi już całe moje życie.
###### **Hi 9,22**
 Ośmielam się więc powiedzieć, że nie ma różnicy: zagłada spotyka jednako niewinnych i winnych.
###### **Hi 9,23**
 Gdy Jego gniew nagle śmierć sprowadza, On sobie drwi ze strachu niewinnych.
###### **Hi 9,24**
 Ziemię oddał we władzę zbrodniarzom, jej sędziom zasłonił oczy. Któż więc, jeśli nie On, to wszystko czyni?
###### **Hi 9,25**
 Szybciej niż biegacz dni moje płyną i w dal uchodzą nie zaznawszy szczęścia.
###### **Hi 9,26**
 Suną naprzód niby łodzie z trzciny, podobne do orła goniącego zdobycz.
###### **Hi 9,27**
 Kiedy postanawiam: Dość już narzekań, Odmienię swój wygląd, twarz rozweselę,
###### **Hi 9,28**
 ogarnia mnie strach na myśl o cierpieniach, bo jestem pewny, że mnie nie uwolnisz.
###### **Hi 9,29**
 Skoro muszę za winnego uchodzić, po co na próżno się trudzić?
###### **Hi 9,30**
 Choćby się w śniegu oczyścił, a ręce w ługu wypłukał,
###### **Hi 9,31**
 i tak pogrążysz mnie w brudach, że nawet mym szatom obrzydnę.
###### **Hi 9,32**
 Bo Tyś nie człowiek, żeby Ci powiedzieć: Chodźmy razem do sądu!
###### **Hi 9,33**
 Bo czy jest jaki rozjemca co rękę położy na Ciebie i na mnie
###### **Hi 9,34**
 uwolni mnie od gróźb wszelakich, i przestanie napełniać strachem,
###### **Hi 9,35**
 bym mógł przemawiać niczego się nie bojąc! Lecz sam widzę jak bardzo jest wszystko inaczej.
# Hi 9 WUJ
###### **Hi 9,1**
 I odpowiadając Job, rzekł:
###### **Hi 9,2**
 Prawdziwie wiem, iż tak jest, a iż nie będzie usprawiedliwion człowiek przyrównany Bogu.
###### **Hi 9,3**
 Będzieli się z nim chciał spierać, nie będzie mu mógł odpowiedzieć jednego za tysiąc.
###### **Hi 9,4**
 Mądry jest sercem, i mocny siłą: kto się mu sprzeciwił a miał pokój?
###### **Hi 9,5**
 Który przeniósł góry, a nie wiedzieli ci, które wywrócił w zapalczywości swojej.
###### **Hi 9,6**
 Który wzrusza ziemię z miejsca jej, i słupy jej wstrzęsają się.
###### **Hi 9,7**
 Który przykazuje słońcu, i nie wschodzi: i gwiazdy zamyka jako pod pieczęcią:
###### **Hi 9,8**
 Który rozciąga niebiosa sam, i chodzi po wałach morskich.
###### **Hi 9,9**
 Który czyni Wóz niebieski, Kosy, i Baby, i gwiazdy południowe.
###### **Hi 9,10**
 Który działa wielkie rzeczy i nieogarnione, i dziwy, którym niemasz liczby.
###### **Hi 9,11**
 Jeśli przyjdzie do mnie, nie ujrzę go: jeśli odejdzie, nie zrozumiem.
###### **Hi 9,12**
 Jeśli spyta nagle, któż mu odpowie? abo kto rzec może: Przecz tak czynisz?
###### **Hi 9,13**
 Bóg, którego gniewowi żaden się oprzeć nie może, i pod którym się zginają, którzy noszą okrąg.
###### **Hi 9,14**
 Jakoż tedy wielki jestem, abych mu odpowiadał, a mówił słowy memi z nim?
###### **Hi 9,15**
 Który choćbych miał co sprawiedliwego, nie odpowiem, ale sędziego mego prosić będę.
###### **Hi 9,16**
 A gdy mię wysłucha wzywającego, nie wierzę, żeby słyszał głos mój.
###### **Hi 9,17**
 W wichrze bowiem zetrze mię, i rozmnoży rany moje i bez przyczyny.
###### **Hi 9,18**
 Nie dopuszcza odpoczynąć duchowi memu, i napełnia mię gorzkościami.
###### **Hi 9,19**
 Jeśli kto pyta o moc, namocniejszy jest: jeśli o prawość sądu, żaden nie śmie za inną dać świadectwa.
###### **Hi 9,20**
 Będęli się chciał usprawiedliwić, usta moje potępią mię: jeśli się niewinnym pokażę, dowiedzie, żem nieprawym,
###### **Hi 9,21**
 Choćbym też był prostym, tego samego nie będzie wiedzieć dusza moja, i będę sobie tęsknił z żywotem moim.
###### **Hi 9,22**
 Jedno jest com mówił, i niewinnego i niezbożnego on zniszcza.
###### **Hi 9,23**
 Jeśli biczuje, raz niech zabije, a z kaźni niewinnych niech się nie śmieje.
###### **Hi 9,24**
 Ziemia dana jest w ręce niezbożnika, oblicze sędziów jej zakrywa, a jeśli nie on jest, któż tedy jest?
###### **Hi 9,25**
 Dni moje prędsze były niż zawodnik: uciekły a nie widziały dobra.
###### **Hi 9,26**
 Minęły jako łodzie jabłka niosące, jako orzeł lecący do żeru.
###### **Hi 9,27**
 Gdy rzekę: Nie będę tak mówił: odmieniam twarz moję, a boleścią dręczon bywam.
###### **Hi 9,28**
 Obawiałem się wszystkich uczynków moich, wiedząc, że nie przepuszczasz grzeszącemu.
###### **Hi 9,29**
 A jeśli i tak niezbożny jestem, czemużem próżno pracował?
###### **Hi 9,30**
 Jeśli omyty będę jako śnieżną wodą, i lskniałyby się jako naczystsze ręce moje:
###### **Hi 9,31**
 Przecie w plugastwie omoczysz mię, i będą się mną brzydzić szaty moje.
###### **Hi 9,32**
 Bo nie człowiekowi, który mnie podobny jest odpowiadać będę: ani któryby zarówno ze mną u sądu mógł być słuchan.
###### **Hi 9,33**
 Niemasz ktoby obudwu mógł karać, i położyć rękę swą na obu.
###### **Hi 9,34**
 Niech odejmie odemnie laskę swoję, a strach jego niech mię nie straszy.
###### **Hi 9,35**
 Będę mówił, a nie będę się go bał: bo bojąc się ani odpowiadać mogę.
