# 1Krl 2 BT5
###### **1Krl 2,1**
 Kiedy zbliżył się czas śmierci Dawida, wtedy rozkazał swemu synowi, Salomonowi, mówiąc:
###### **1Krl 2,2**
 «***Ja wyruszam w drogę [przeznaczoną ludziom na] całej ziemi. Ty zaś bądź mocny i okaż się mężem!***
###### **1Krl 2,3**
 ***Będziesz strzegł zarządzeń Pana, Boga twego, idąc za Jego wskazaniami, przestrzegając Jego praw, poleceń i nakazów, jak napisano w Prawie Mojżesza, aby ci się powiodło wszystko, co zamierzysz, i wszystko, czym się zajmiesz,***
###### **1Krl 2,4**
 ***ażeby też Pan spełnił swą obietnicę, którą mi dał, mówiąc: Jeśli twoi synowie będą strzec swej drogi, postępując wobec Mnie szczerze z całego serca i z całej duszy, to wtedy nie będzie ci odjęty mąż na tronie Izraela.***
###### **1Krl 2,5**
 ***Poza tym ty wiesz, co uczynił mi Joab, syn Serui; co uczynił dwom dowódcom wojska izraelskiego – Abnerowi, synowi Nera, i Amasie, synowi Jetera, kiedy ich zabił i przelał krew w czasie pokoju, jak na wojnie, i zbroczył tą krwią wojny swój pas na biodrach i sandały na nogach.***
###### **1Krl 2,6**
 ***Uczynisz więc według twojej roztropności i nie dozwolisz, aby w sędziwym wieku spokojnie zstąpił do Szeolu.***
###### **1Krl 2,7**
 ***Synom zaś Barzillaja Gileadczyka okażesz łaskę, aby byli wśród twoich stołowników, gdyż przyszli mi z pomocą w mojej ucieczce przed twym bratem, Absalomem.***
###### **1Krl 2,8**
 ***Jest też przy tobie Szimei, syn Gery, Beniaminita z Bachurim. To on przeklinał mnie gwałtownie, gdy szedłem do Machanaim, ale potem zszedł na spotkanie ze mną nad Jordanem. Dlatego przysiągłem mu na Pana, mówiąc: Nie zabiję cię mieczem.***
###### **1Krl 2,9**
 ***Ale ty nie darujesz mu, bo jesteś człowiekiem roztropnym i będziesz wiedział, jak z nim postąpić, abyś go posłał w sędziwym wieku krwawo do Szeolu***».
###### **1Krl 2,10**
 Potem Dawid spoczął ze swymi przodkami i został pochowany w Mieście Dawidowym.
###### **1Krl 2,11**
 A czas panowania Dawida nad Izraelem wynosił czterdzieści lat. W Hebronie panował siedem lat, a w Jerozolimie panował trzydzieści trzy lata.
###### **1Krl 2,12**
 Zasiadł więc Salomon na tronie Dawida, swego ojca, a jego władza królewska została utwierdzona.
###### **1Krl 2,13**
 Lecz Adoniasz, syn Chaggity, przyszedł do Batszeby, matki Salomona. Ta zaś spytała: «***Czy przyjście twoje [oznacza] pokój?***» A on odrzekł: «***Pokój***».
###### **1Krl 2,14**
 Następnie rzekł: «***Chciałbym pomówić z tobą***». Ona zaś mu powiedziała: «***Mów!***»
###### **1Krl 2,15**
 Wtedy rzekł: «***Ty wiesz, że dla mnie była władza królewska i cały Izrael oczekiwał na to, żebym panował. Ale na kogo innego przeszła władza królewska i dostała się memu bratu, gdyż z woli Pana mu przypadła.***
###### **1Krl 2,16**
 ***Teraz więc zwracam się do ciebie z jedną prośbą. Nie odmawiaj mi!***» Ona zaś mu odrzekła: «***Mów!***»
###### **1Krl 2,17**
 Wówczas rzekł: «***Powiedz, proszę cię, królowi Salomonowi, bo on niczego tobie nie odmówi, aby mi dał za żonę Abiszag Szunemitkę***».
###### **1Krl 2,18**
 Na to odpowiedziała Batszeba: «***Dobrze, ja powiem o tobie królowi***».
###### **1Krl 2,19**
 Batszeba więc weszła do króla Salomona, aby przemówić do niego w sprawie Adoniasza. Wtedy król wstał na jej spotkanie. Oddał jej pokłon, a potem usiadł na swym tronie. Kazał postawić też tron dla matki króla, i usiadła po jego prawej ręce.
###### **1Krl 2,20**
 Ona wtedy powiedziała mu: «***Mam do ciebie jedną małą prośbę. Nie odmawiaj mi!***» A król jej odrzekł: «***Proś, moja matko, bo tobie nie odmówię***».
###### **1Krl 2,21**
 Wtedy przemówiła: «***Niech Abiszag Szunemitka będzie dana za żonę twemu bratu, Adoniaszowi!***»
###### **1Krl 2,22**
 Odpowiadając na to, król Salomon rzekł swojej matce: «***A dlaczego prosisz dla Adoniasza o Abiszag Szunemitkę? Proś raczej dla niego o władzę królewską, bo on jest moim starszym bratem i ma za sobą kapłana Abiatara i Joaba, syna Serui!***»
###### **1Krl 2,23**
 Następnie król Salomon przysiągł na Pana, mówiąc: «***Niech mi Bóg to uczyni i tamto dorzuci, jeśli Adoniasz nie na swą zgubę poruszył tę sprawę.***
###### **1Krl 2,24**
 ***Teraz więc, na życie Pana, który mnie ustanowił i osadził na tronie Dawida, mego ojca, i który, jak zapowiedział, zbuduje mi dom, na pewno dziś Adoniasz poniesie śmierć!***»
###### **1Krl 2,25**
 Wtedy król Salomon przekazał to synowi Jojady, Benajaszowi, który zadał tamtemu cios, tak że umarł.
###### **1Krl 2,26**
 Kapłanowi zaś Abiatarowi król rozkazał: «***Idź do Anatot, do posiadłości twojej, gdyż zasługujesz na karę śmierci, ale dziś ciebie nie zabiję, bo niósłeś Arkę Przymierza Pańskiego przed obliczem mego ojca, Dawida, i dotknęło cię to całe cierpienie, które dotknęło mego ojca***».
###### **1Krl 2,27**
 Tak więc Salomon odsunął Abiatara, by nie był kapłanem Pańskim, i aby wypełnić, co Pan zapowiedział rodowi Helego w Szilo.
###### **1Krl 2,28**
 Gdy wieść o tym doszła do Joaba, syna Serui, wtedy Joab umknął do Namiotu Pańskiego i uchwycił się rogów ołtarza, gdyż Joab popierał Adoniasza, a nie popierał Absaloma.
###### **1Krl 2,29**
 Gdy doniesiono królowi Salomonowi, że Joab umknął do Namiotu Pańskiego i tam jest przy ołtarzu, wtedy Salomon posłał Benajasza, syna Jojady, do Namiotu Pańskiego, rozkazując: «***Idź, zabij go!***»
###### **1Krl 2,30**
 Wszedł więc Benajasz do Namiotu Pańskiego i rzekł do niego: «***Z rozkazu króla, wyjdź!***» On zaś odpowiedział: «***Nie, bo tu chcę umierać!***» Wtedy Benajasz zdał sprawę królowi, mówiąc: «***To rzekł Joab i to mi odpowiedział***».
###### **1Krl 2,31**
 Na to odparł mu król: «***Uczyń, jak powiedział. Zabij go i pochowaj, aby zmazać ze mnie i z rodu mojego ojca niewinną krew, rozlaną przez Joaba.***
###### **1Krl 2,32**
 ***A Pan zrzuci na niego odpowiedzialność za to, że zamordował dwóch ludzi zacnych i lepszych od niego, bez wiedzy mego ojca, Dawida; zabił mieczem Abnera, syna Nera, wodza wojska izraelskiego, i Amasę, syna Jetera, wodza wojska judzkiego.***
###### **1Krl 2,33**
 ***Niech [odpowiedzialność za] ich krew spadnie znów na głowę Joaba i jego potomstwa na wieki, a dla Dawida i jego potomstwa oraz jego domu i jego tronu niech będzie pokój na wieki od Pana!***»
###### **1Krl 2,34**
 Wobec tego Benajasz, syn Jojady, poszedł i zadał mu cios śmiertelny. Potem pochowano go w jego domu na pustyni.
###### **1Krl 2,35**
 Na jego miejsce król postawił na czele wojska Benajasza, syna Jojady, a kapłanem na miejsce Abiatara ustanowił Sadoka.
###### **1Krl 2,36**
 Następnie król kazał wezwać Szimejego i rzekł mu: «***Zbuduj sobie dom w Jerozolimie. Będziesz tam mieszkał i nigdzie z niego nie będziesz wychodził.***
###### **1Krl 2,37**
 ***Dobrze wiedz o tym, że w dniu, w którym wyjdziesz i przekroczysz potok Cedron, na pewno umrzesz, i to z własnej winy***».
###### **1Krl 2,38**
 A wtedy Szimei odrzekł królowi: «***To dobre słowo! Twój sługa uczyni tak, jak powiedział pan mój, król***». Rzeczywiście Szimei długi czas mieszkał w Jerozolimie.
###### **1Krl 2,39**
 Jednak po upływie trzech lat dwaj słudzy Szimejego uciekli do Akisza, syna Maaki, króla Gat. Dano więc znać Szimejemu, mówiąc: «***Oto twoi słudzy są w Gat***».
###### **1Krl 2,40**
 Wtedy Szimei osiodłał swego osła i wyruszył do Gat, do Akisza, aby szukać swoich sług. Potem powrócił i przyprowadził z Gat swoje sługi.
###### **1Krl 2,41**
 Doniesiono Salomonowi, że Szimei poszedł z Jerozolimy do Gat i wrócił.
###### **1Krl 2,42**
 Wtedy król kazał wezwać Szimejego i rzekł do niego: «***Czyż nie zaprzysiągłem cię na Pana i nie przestrzegłem cię wyraźnie, mówiąc: Dobrze wiedz o tym, że w dniu, w którym wyjdziesz i gdziekolwiek pójdziesz, na pewno umrzesz? A ty mi odrzekłeś: Dobre słowo usłyszałem.***
###### **1Krl 2,43**
 ***Więc dlaczego nie dochowałeś przysięgi na Pana i nakazu, który ci dałem?***»
###### **1Krl 2,44**
 Następnie król rzekł Szimejemu: «***Ty wiesz o wszystkim złu, którego świadome jest serce twoje, a które wyrządziłeś mojemu ojcu, Dawidowi. Za to Pan obróci twoją złość na twoją głowę.***
###### **1Krl 2,45**
 ***A król Salomon będzie błogosławiony i tron Dawida będzie wobec Pana utwierdzony na wieki***».
###### **1Krl 2,46**
 Potem król wydał rozkaz Benajaszowi, synowi Jojady; ten wyszedł i zadał tamtemu cios, tak że umarł. Wzmocniła się więc władza królewska w ręku Salomona.
# 1Krl 2 PAU
###### **1Krl 2,1**
 Gdy życie Dawida dobiegało końca, wydał on ostatnie polecenia swojemu synowi, Salomonowi:
###### **1Krl 2,2**
 „Ja odchodzę z tego świata jak wszyscy ludzie. Okaż się mocny i bądź mężczyzną!
###### **1Krl 2,3**
 Dotrzymaj zobowiązań nałożonych przez PANA, twojego Boga. Postępuj drogami, które On wskazał, wypełniając Jego prawa, przykazania, wyroki i ustawy zapisane w Prawie Mojżesza, aby ci się powodziło we wszystkim, co będziesz robił, i wszędzie tam, dokąd pójdziesz.
###### **1Krl 2,4**
 A PAN wypełni swoją obietnicę, którą zapowiedział: «Jeśli twoi synowie z całego serca i z całej duszy będą Mi wierni w swoim postępowaniu, to nie zabraknie ci następcy na tronie Izraela».
###### **1Krl 2,5**
 Ty wiesz także, jak zachował się wobec mnie Joab, syn Serui, i jak postąpił z dwoma dowódcami izraelskimi, Abnerem, synem Nera, i Amasą, synem Jetera: zabił ich i zerwał warunki pokoju, rozlewając krew jak na wojnie. Zbroczył on przelaną krwią swój pas na biodrach i sandały na nogach.
###### **1Krl 2,6**
 Zrób, co ci podyktuje twoja mądrość, lecz nie pozwól mu, aby w sędziwej starości spokojnie zstąpił do krainy umarłych.
###### **1Krl 2,7**
 Okaż życzliwość synom Barzillaja z Gileadu, dopuszczając ich do twego stołu, gdyż dali mi wsparcie podczas mej ucieczki przed twoim bratem, Absalomem.
###### **1Krl 2,8**
 Masz też przy sobie Beniaminitę Szimeiego, syna Gery z Bachurim, który rzucał na mnie obelżywe przekleństwa, kiedy szedłem do Machanaim. Gdy potem wyszedł mi na spotkanie nad Jordanem, przysiągłem mu na PANA: «Nie skażę cię na śmierć».
###### **1Krl 2,9**
 Teraz ty jednak nie darujesz mu, gdyż jesteś człowiekiem mądrym; będziesz wiedział, jak z nim postąpić i zbroczonego krwią poślesz go do krainy umarłych w sędziwym wieku”.
###### **1Krl 2,10**
 Potem Dawid spoczął przy swoich przodkach i pochowano go w Mieście Dawida.
###### **1Krl 2,11**
 Panował on nad Izraelem czterdzieści lat: w Hebronie siedem lat, a w Jerozolimie trzydzieści trzy lata.
###### **1Krl 2,12**
 Tak Salomon zasiadł na tronie swojego ojca, Dawida, i umocnił swoją władzę królewską.
###### **1Krl 2,13**
 Adoniasz, syn Chaggity, przyszedł do Batszeby, matki Salomona. Ona zapytała: „Czy przychodzisz w przyjaznych zamiarach?”. „W przyjaznych - odpowiedział. -
###### **1Krl 2,14**
 Mam do ciebie prośbę” - zwrócił się do niej. „Mów!” - powiedziała.
###### **1Krl 2,15**
 „Sama wiesz - zaczął - że mnie się należała władza królewska i że cały Izrael we mnie widział przyszłego króla. Jednak władza królewska mnie ominęła i przeszła na mojego brata, ponieważ z woli PANA jemu przypadła.
###### **1Krl 2,16**
 Mam teraz tylko jedną prośbę do ciebie. Nie odmawiaj mi!”. „Proś!” - odpowiedziała.
###### **1Krl 2,17**
 „Wstaw się za mną do króla Salomona i poproś go, gdyż tobie nie odmówi, żeby dał mi za żonę Abiszag, Szunemitkę”.
###### **1Krl 2,18**
 „Dobrze - odpowiedziała Batszeba. - Porozmawiam z królem o tobie”.
###### **1Krl 2,19**
 Przyszła więc Batszeba do króla Salomona, żeby z nim porozmawiać o Adoniaszu. Król wyszedł jej na spotkanie i oddał jej głęboki pokłon, a potem usiadł na swoim tronie. Ustawiono również tron dla matki króla, która usiadła po jego prawej stronie.
###### **1Krl 2,20**
 Wtedy powiedziała do niego: „Mam do ciebie jedną małą prośbę. Nie odmawiaj mi!”. Król jej odpowiedział: „Proś, moja matko, gdyż tobie nie odmówię”.
###### **1Krl 2,21**
 Poprosiła więc: „Niech Szunemitka Abiszag będzie żoną twego brata, Adoniasza”.
###### **1Krl 2,22**
 Wtedy król Salomon dał swojej matce taką odpowiedź: „Dlaczego prosisz tylko o Szunemitkę Abiszag dla Adoniasza? Proś raczej o władzę królewską dla niego, ponieważ jest on moim starszym bratem i ma po swojej stronie zarówno kapłana Abiatara, jak i Joaba, syna Serui”.
###### **1Krl 2,23**
 Król Salomon przysiągł wówczas na PANA: „Niech Bóg mnie ciężko ukarze, jeśli Adoniasz nie poruszył tej sprawy na swoją zgubę.
###### **1Krl 2,24**
 Na życie PANA, który mnie ustanowił i pozwolił mi przedłużyć panowanie domu Dawida w Izraelu i który zgodnie ze swoją obietnicą wzniósł dla mnie dom: jeszcze dzisiaj Adoniasz zostanie zabity!”.
###### **1Krl 2,25**
 Król Salomon posłał syna Jojady Benajasza i ten zadał Adoniaszowi śmiertelny cios.
###### **1Krl 2,26**
 Kapłanowi zaś Abiatarowi król rozkazał: „Idź do Anatot, do swojej posiadłości, gdyż zasługujesz na śmierć. Dziś jednak nie wydam na ciebie wyroku skazującego, ponieważ niosłeś Arkę PANA, Boga, w obecności mojego ojca Dawida i dzieliłeś z nim wszystkie nieszczęścia, które na niego spadły”.
###### **1Krl 2,27**
 Tak więc Salomon usunął Abiatara z urzędu kapłana PANA i w ten sposób spełniło się słowo PANA, które wypowiedział w Szilo przeciw domowi Helego.
###### **1Krl 2,28**
 Kiedy wieść o tym doszła do Joaba - a popierał on przecież Adoniasza, choć nie był zwolennikiem Absaloma - wtedy uciekł on do Namiotu PANA i szukając ratunku, chwycił się rogów ołtarza.
###### **1Krl 2,29**
 Wówczas powiadomiono króla Salomona, że Joab uciekł do Namiotu PANA i znajduje się przy ołtarzu. Salomon wydał więc rozkaz synowi Jojady Benajaszowi: „Idź, zabij go!”.
###### **1Krl 2,30**
 Benajasz przyszedł do Namiotu PANA i rozkazał Joabowi: „Król każe ci wyjść!”. Ten odpowiedział: „Nie! Chcę umrzeć tutaj!”. Benajasz przekazał królowi odpowiedź Joaba.
###### **1Krl 2,31**
 Król polecił: „Zrób, jak powiedział. Zabij go i pochowaj! W ten sposób uwolnisz mnie i dom ojca mojego od krwi, którą Joab przelał bez powodu.
###### **1Krl 2,32**
 PAN sprawi, że Joab sam poniesie winę za swoją śmierć. Bez wiedzy mojego ojca, Dawida, zamordował przecież dwóch niewinnych i lepszych od siebie ludzi: zabił mieczem Abnera, syna Nera, naczelnego wodza armii izraelskiej, i syna Jetera, Amasę, naczelnego wodza armii judzkiej.
###### **1Krl 2,33**
 Dlatego wina za ich śmierć spadnie na Joaba i na jego potomków po wszystkie czasy. Natomiast Dawida, jego potomstwo, jego dom i tron PAN obdarzy na zawsze pokojem”.
###### **1Krl 2,34**
 Poszedł więc Benajasz, syn Jojady, i zadał Joabowi cios śmiertelny. Joab został pochowany w swojej posiadłości na pustyni.
###### **1Krl 2,35**
 Na jego miejsce na czele armii król postawił Benajasza, syna Jojady. Na miejsce zaś Abiatara król mianował kapłana Sadoka.
###### **1Krl 2,36**
 Król kazał także wezwać Szimeiego i polecił mu: „Zbuduj sobie dom w Jerozolimie i pozostań tam. Nigdzie nie będziesz stamtąd wychodził.
###### **1Krl 2,37**
 Pamiętaj jednak, że w dniu, w którym go opuścisz i przekroczysz potok Cedron, umrzesz na pewno, i to z własnej winy”.
###### **1Krl 2,38**
 Na to Szimei odpowiedział królowi: „Dobrze, twój sługa postąpi tak, jak zarządził mój pan, król”. Mieszkał więc Szimei przez długi czas w Jerozolimie.
###### **1Krl 2,39**
 Lecz po trzech latach dwaj niewolnicy Szimeiego uciekli do Akisza, syna Maaki, króla Gat. Powiadomiono więc Szimeiego: „Twoi niewolnicy są teraz w Gat”.
###### **1Krl 2,40**
 On osiodłał osła i wyruszył do Gat, do króla Akisza, w poszukiwaniu swoich niewolników. Poszedł i przyprowadził ich z Gat.
###### **1Krl 2,41**
 Kiedy król Salomon dowiedział się, że Szimei wyszedł z Jerozolimy do Gat i wrócił,
###### **1Krl 2,42**
 kazał go wezwać i powiedział: „Czyż nie przysiągłem na PANA, dając ci wyraźne ostrzeżenie: «Pamiętaj, że w dniu, w którym wyjdziesz, udając się gdziekolwiek, na pewno umrzesz»? Odpowiedziałeś mi wtedy: «Dobrze. Zrozumiałem».
###### **1Krl 2,43**
 Dlaczego zatem nie dotrzymałeś przysięgi, złożonej na PANA, i nie wypełniłeś mojego rozkazu?”.
###### **1Krl 2,44**
 Następnie król zwrócił się do Szimeiego: „Jesteś świadomy całego zła, które wyrzuca ci twoje serce, a które wyrządziłeś mojemu ojcu, Dawidowi. To PAN sprawi, że zło przez ciebie popełnione spadnie na twoją głowę.
###### **1Krl 2,45**
 Król Salomon będzie błogosławiony. Niech PAN sprawi, że dom Dawida na wieki będzie panował w Izraelu”.
###### **1Krl 2,46**
 Król wydał zatem rozkaz Benajaszowi, synowi Jojady, aby poszedł i zabił Szimeiego. Tak umarł. A Salomon umocnił swoją władzę królewską.
# 1Krl 2 BP
###### **1Krl 2,1**
 Gdy dni Dawida przybliżyły się ku śmierci, polecił Salomonowi, synowi swojemu, mówiąc:
###### **1Krl 2,2**
 Ja wstępuję na drogę, [która jest przeznaczeniem] całej ziemi. Dzielnie sobie poczynaj i bądź mężem.
###### **1Krl 2,3**
 Wypełniaj przykazania Jahwe, twojego Boga, krocząc Jego drogami, przestrzegając Jego przepisów i Jego nakazów, Jego zasad i Jego upomnień, jak jest napisane w Prawie Mojżeszowym, abyś szczęśliwie przeprowadził wszystkie swoje dzieła i wszystkie swe zamierzenia,
###### **1Krl 2,4**
 aby Jahwe wypełnił swoje słowo, które wyrzekł do mnie mówiąc: "Jeśli synowie twoi będą strzec dróg swoich, dotrzymując mi wierności całym swym sercem i z całej swej duszy, nie zabraknie ci potomka na tronie Izraela".
###### **1Krl 2,5**
 Wiesz i ty również, co mi uczynił Joab, syn Cerui, co uczynił obydwu dowódcom wojska izraelskiego, Abnerowi, synowi Nera, i Amasie, synowi Jetry. Mordując ich rozlał w czasie pokoju krew, [która mogła być wylana tylko w czasie] wojny i splamił niewinną krwią swój pas na biodrach i swoje sandały na nogach.
###### **1Krl 2,6**
 Działaj więc według swej mądrości, ale nie dopuść, aby z siwym włosem w pokoju zszedł do Szeolu.
###### **1Krl 2,7**
 Synom Barzillaja Gileadczyka okaż łaskawość, niech należą do tych, co jedzą przy twoim stole, albowiem oni właśnie wyszli naprzeciw mnie, gdy uciekałem przed bratem twoim Abszalomem.
###### **1Krl 2,8**
 A oto masz u siebie Szimiego, syna Gera, Beniaminitę z Bachurim. On złorzeczył mi bardzo złośliwie w dniu, gdy uchodziłem do Machanajim, zszedł jednak ku Jordanowi, aby się ze mną spotkać. I przysiągłem mu na Jahwe, mówiąc: Nie zabiję cię mieczem.
###### **1Krl 2,9**
 Ty jednak nie pozostawiaj go bez kary, boś jest człowiekiem mądrym i wiesz, co masz mu uczynić. Spraw, aby okryty krwią zszedł ze swoją siwizną do Szeolu.
###### **1Krl 2,10**
 I spoczął Dawid ze swymi przodkami, i został pogrzebany w Mieście Dawidowym.
###### **1Krl 2,11**
 Czas panowania Dawida nad Izraelem [wynosił] czterdzieści lat. W Chebronie panował lat siedem, a w Jerozolimie był królem przez trzydzieści trzy lata.
###### **1Krl 2,12**
 Salomon zasiadł na tronie Dawida, swego ojca. Jego władza królewska była bardzo utwierdzona.
###### **1Krl 2,13**
 Adonijja, syn Chaggity, przyszedł do Batszeby, matki Salomona. [Ta] zapytała [go]: Czy przyjście twoje [zwiastuje] pokój? Odpowiedział: Pokój.
###### **1Krl 2,14**
 I poprosił: Chcę z tobą pomówić. Powiedziała: Mów.
###### **1Krl 2,15**
 Rzekł więc: Ty wiesz, że mnie się należała godność królewska i że cały Izrael spodziewał się, iż ja będę królem. Ale władza królewska [mnie] ominęła i przypadła w udziale mojemu bratu, albowiem jemu Jahwe ją przeznaczył.
###### **1Krl 2,16**
 Teraz więc mam do ciebie jedną prośbę, nie odmawiaj mi. Powiedziała mu: Mów.
###### **1Krl 2,17**
 Rzekł: Powiedz, proszę, królowi Salomonowi - bo tobie nie odmówi - aby mi dał Abiszag Szunamitkę za żonę.
###### **1Krl 2,18**
 Batszeba odpowiedziała: Dobrze, przemówię za tobą do króla.
###### **1Krl 2,19**
 I udała się Batszeba do króla Salomona, aby z nim pomówić w sprawie Adonijji. Król powstał na jej spotkanie, pokłonił się jej głęboko, usiadł na swym tronie i polecił postawić krzesło dla królowej matki, aby usiadła po jego prawicy.
###### **1Krl 2,20**
 Wtedy rzekła: Mam jedną małą prośbę do ciebie, nie odmów mi. Król jej powiedział: Proś mię, matko moja, albowiem tobie nie odmówię.
###### **1Krl 2,21**
 Rzekła więc: Niech twój brat Adonijja otrzyma Abiszag Szunamitkę za żonę.
###### **1Krl 2,22**
 Odpowiadając król Salomon rzekł do swojej matki: Dlaczego prosisz dla Adonijji o Abiszag Szunamitkę? Proś mię raczej o królestwo dla niego, gdyż on jest moim bratem, jest starszy ode mnie, za nim stoi kapłan Ebjatar i Joab, syn Cerui.
###### **1Krl 2,23**
 I przysiągł król Salomon na Jahwe mówiąc: Niech mię Bóg ciężko ukarze, oto za cenę własnego życia wypowiedział Adonijja tę prośbę.
###### **1Krl 2,24**
 A teraz, na żyjącego Jahwe, który mnie wprowadził i osadził na tronie mego ojca Dawida i który dla mnie założył obiecaną dynastię, Adonijja dziś będzie skazany na śmierć.
###### **1Krl 2,25**
 Na rozkaz króla Salomona Benajahu, syn Jenojady, zadał mu cios, i [ten] umarł.
###### **1Krl 2,26**
 Kapłanowi Ebjatarowi król polecił: Idź do Anatot, do swojej posiadłości, bo jesteś człowiekiem [zasługującym na] śmierć. W tej chwili nie chcę pozbawić cię życia, ponieważ nosiłeś Arkę Pana, Jahwe, w obecności mego ojca Dawida i trudziłeś się w tych wszystkich [doświadczeniach], nad którymi mozolił się mój ojciec.
###### **1Krl 2,27**
 I złożył Salomon Ebjatara z urzędu kapłana Jahwe, aby spełniło się słowo Jahwe, które wyrzekł w Szilo przeciw domowi Helego.
###### **1Krl 2,28**
 Gdy wieść [o tych wydarzeniach] dotarła do Joaba - który był wprawdzie zwolennikiem Adonijji, ale nie stanął po stronie Abszaloma - schronił się Joab do Namiotu Jahwe i uchwycił się rogów ołtarza.
###### **1Krl 2,29**
 Dano znać królowi Salomonowi, że Joab uciekł do Namiotu Jahwe i oto znajduje się obok ołtarza. Posłał więc Salomon Benajahu, syna Jehojady, mówiąc: Idź, zadaj mu cios [śmiertelny].
###### **1Krl 2,30**
 Benajahu wszedł do Namiotu Jahwe i rzekł do Joaba: Tak mówi król: Wyjdź. [Joab] odpowiedział: Nie! Tu umrę. Benajahu przedstawił sprawę królowi mówiąc: Tak rzekł Joab i taką mi dał odpowiedź.
###### **1Krl 2,31**
 Król polecił mu: Zrób, jak powiedział. Zadaj mu cios i pogrzeb go. [W ten sposób] zdejmiesz ze mnie i z domu mojego ojca [odpowiedzialność] za krew niewinną, którą wylał Joab.
###### **1Krl 2,32**
 A Jahwe sprawi, że jego krew spadnie na jego głowę, iż zadał cios dwom sprawiedliwszym i lepszym niż on mężom i zamordował ich mieczem: Abnera, syna Nera, dowódcę wojska izraelskiego, oraz Amasę, syna Jetry, dowódcę wojska Judy, a Dawid, ojciec mój, nie wiedział.
###### **1Krl 2,33**
 Niech ich krew spadnie na głowę Joaba i na głowę jego potomstwa na wieki. Dawidowi zaś i jego potomstwu, jego domowi i jego tronowi niech Jahwe ześle pokój na wieki.
###### **1Krl 2,34**
 Poszedł Benajahu, syn Jehojady, i zadawszy mu cios, zabił go. I został pogrzebany w swej posiadłości na pustym.
###### **1Krl 2,35**
 Zamiast niego król postawił na czele wojska Benajahu, syna Jehojady. Kapłana zaś Cadoka król mianował na miejsce Ebjatara.
###### **1Krl 2,36**
 Król polecił wezwać Szimiego i rzekł mu: Zbuduj sobie dom w Jerozolimie, tam zamieszkaj i nigdzie się stamtąd nie oddalaj.
###### **1Krl 2,37**
 W dniu, w którym wyjdziesz i przekroczysz potok Cedron, wiedz dobrze, że na pewno umrzesz, a twoja krew spadnie na twą głowę.
###### **1Krl 2,38**
 Szimi odpowiedział królowi: Łaskawe jest to słowo. Jak pan mój, król, rozkazał, tak uczyni twój sługa. Mieszkał więc Szimi w Jerozolimie przez długi czas.
###### **1Krl 2,39**
 I zdarzyło się, że po upływie trzech lat dwaj słudzy Szimiego uciekli do Akisza, syna Maaki, króla Gat. Dano znać Szimiemu mówiąc: Oto twoi słudzy są w Gat.
###### **1Krl 2,40**
 Wstał wtedy Szimi, objuczył swego osła i wyruszył do Gat do Akisza, aby odszukać swoje sługi. Poszedł i przyprowadził ich z Gat.
###### **1Krl 2,41**
 Powiadomiono Salomona, że Szimi chodził z Jerozolimy do Gat i powrócił.
###### **1Krl 2,42**
 Król kazał zawezwać Szimiego i rzekł mu: Czyż nie zaprzysiągłem cię na Jahwe i nie zapowiedziałem ci mówiąc: Z chwilą, gdy wyjdziesz i pójdziesz dokądkolwiek, wiedz dobrze, że na pewno umrzesz? Odpowiedziałeś mi: Łaskawe słowo usłyszałem.
###### **1Krl 2,43**
 Dlaczego więc nie przestrzegałeś przysięgi na Jahwe i nakazu, jaki na ciebie nałożyłem?
###### **1Krl 2,44**
 I powiedział król Szimiemu: Ty znasz całe zło, bo wie [o nim] serce twoje, jakie wyrządziłeś Dawidowi, mojemu ojcu. Jahwe niech spuści złość twą na twoją głowę.
###### **1Krl 2,45**
 Król Salomon niech będzie błogosławiony, a tron Dawida niech się umocni przed obliczem Jahwe na wieki.
###### **1Krl 2,46**
 I polecił król Benajahu, synowi Jehojady, [wykonać wyrok]. Wyszedł więc, zadał mu cios i [Szimi] umarł.
# 1Krl 2 BR
###### **1Krl 2,1**
 Przewidując, że już wkrótce umrze, Dawid wydał takie oto polecenie swojemu synowi, Salomonowi:
###### **1Krl 2,2**
 Ja już kończę drogę [wszystkich istot ziemskich]. Bądź odważny, jak przystało na mężczyznę!
###### **1Krl 2,3**
 Pamiętaj, służ Jahwe, twojemu Bogu, chodząc Jego drogami, przestrzegając Jego praw, przykazań i zarządzeń, poleceń, tak jak to jest napisane w prawie Mojżesza, aby ci się wiodło we wszystkim, co będziesz czynił, i dokąd tylko się udasz.
###### **1Krl 2,4**
 W ten sposób wypełnią się na tobie słowa wypowiedziane do mnie przez Jahwe: Jeżeli twoi synowie będą Mi wierni z całego swojego serca i z całej swojej duszy, nigdy nie zabraknie ci potomka, zasiadającego na tronie izraelskim.
###### **1Krl 2,5**
 Sam wiesz, co uczynił mi Joab, syn Serui; co uczynił dwom dowódcom oddziałów wojskowych Izraela, Abnerowi, synowi Nera, i Amasie, synowi Jetera: jak ich pozabijał, przelewając krew w czasie pokoju, jak gdyby to było w czasie wojny; jak splamił krwią pas, którym był przepasany, i sandały, które miał na nogach.
###### **1Krl 2,6**
 Będziesz się kierował w działaniu własną roztropnością i nie dopuścisz, żeby [nie pomszczony] dożył starości i z siwą głową odszedł w zaświaty, do ojców.
###### **1Krl 2,7**
 Natomiast synom Barzillaja Gileadczyka okażesz wiele łaskawości i zaliczysz ich do tych, którzy będą zasiadać z tobą do wspólnego stołu. Oni bowiem w ten właśnie sposób też okazali mi życzliwość, gdy uciekałem przed twoim bratem Absalomem.
###### **1Krl 2,8**
 Jest tu blisko ciebie Szimei, syn Gery, Beniaminita z Bachurim. Obrzucał on mnie ohydnymi wyzwiskami, kiedy byłem w drodze do Machanaim. Ponieważ jednak wyszedł mi potem na spotkanie aż do Jordanu, przysiągłem mu na Jahwe, że nie zginie od miecza.
###### **1Krl 2,9**
 Ale ty nie musisz go oszczędzać. Jesteś rozsądny i będziesz wiedział, jak należy z nim postąpić. Niech jego bielejąca głowa zaczerwieni się krwią w dniu jego śmierci.
###### **1Krl 2,10**
 I odszedł Dawid do swoich ojców, i został pochowany w Mieście Dawidowym.
###### **1Krl 2,11**
 Czterdzieści lat rządził Dawid Izraelem: przez siedem lat przebywał w Hebronie i przez trzydzieści trzy lata w Jerozolimie.
###### **1Krl 2,12**
 Potem Salomon zasiadł na tronie swego ojca, Dawida, i umacniała się coraz bardziej jego władza.
###### **1Krl 2,13**
 Po pewnym czasie Adoniasz, syn Chaggity, odwiedził Batszebę, matkę Salomona. A ona zapytała go natychmiast: Czy w dobrych zamiarach tu przychodzisz? On zaś odpowiedział: Tak, w dobrych.
###### **1Krl 2,14**
 I zaraz dodał: Mam ci coś do powiedzenia. Na to ona: To mów!
###### **1Krl 2,15**
 Wtedy on powiedział: Ty wiesz, że całe królestwo należało do mnie, że oczy całego Izraela były skierowane w moją stronę w nadziei, iż ja będę królem. Ale została mi odebrana władza królewska i przekazana mojemu bratu, bo jemu przeznaczył ją Jahwe.
###### **1Krl 2,16**
 Proszę cię teraz o jedną jedyną rzecz, ale błagam cię, nie odmów mi.
###### **1Krl 2,17**
 Mów więc! - powiedziała. Na to on rzekł: Tak bardzo cię proszę, powiedz królowi Salomonowi - na pewno cię wysłucha - żeby mi dał za żonę Szumenitkę Abiszag.
###### **1Krl 2,18**
 Odpowiedziała Batszeba: Dobrze, powiem o tym królowi.
###### **1Krl 2,19**
 I poszła Batszeba do króla Salomona, żeby mu przedstawić prośbę Adoniasza. Król wstał, by wyjść jej naprzeciw, i skłonił się jej nisko. Potem usiadł na tronie, kazał postawić drugi tron dla matki króla. Usiadła po prawej stronie
###### **1Krl 2,20**
 i tak zaczęła mówić: Mam do ciebie małą prośbę, tylko proszę, żebyś mi nie odmawiał. Rzekł na to król: Mów, proszę, moja matko! Wysłucham cię na pewno.
###### **1Krl 2,21**
 Wtedy ona rzekła: Niech Abiszag Szumenitka zostanie dana za żonę bratu twojemu Adoniaszowi.
###### **1Krl 2,22**
 Król Salomon odpowiadając swojej matce, zapytał ją: Dlaczego ty prosisz dla Adoniasza o Szunemitkę Abiszag? Raczej proś o władzę królewską dla niego! Przecież on jest moim starszym bratem i ma za sobą kapłana Abiatara oraz Joaba, syna Serui.
###### **1Krl 2,23**
 I zaklinając się na imię Jahwe, król Salomon powiedział: Niech Bóg ześle na mnie wszystko, co najgorsze, jeśli tą prośbą Adoniasz już nie ściągnął na siebie zguby.
###### **1Krl 2,24**
 A teraz, na życie Jahwe, który obdarzył mnie mocą, posadził na tronie ojca mego, Dawida, i zbudował mi dom zgodnie ze swoją obietnicą - przysięgam, że dziś jeszcze Adoniasz wyzionie ducha.
###### **1Krl 2,25**
 I wydał król Salomon rozkaz Benajaszowi, synowi Jojady. Ten zaś zadał Adoniaszowi cios śmiertelny. I tak zginął [Adoniasz].
###### **1Krl 2,26**
 Potem powiedział król do kapłana Abiatara: Wracaj do swoich posiadłości w Anatot, bo ty też zasłużyłeś sobie na śmierć. Nie zgładzę cię jednak jeszcze dzisiaj, ponieważ to ty nosiłeś arkę Bożą przed ojcem moim, Dawidem, i uczestniczyłeś we wszystkich cierpieniach mojego ojca.
###### **1Krl 2,27**
 I usunął Salomon Abiatara, nie pozwalając mu dłużej pozostawać kapłanem Jahwe. W ten sposób wypełniły się słowa wypowiedziane przez Jahwe w Szilo o całym domu Helego.
###### **1Krl 2,28**
 Wieści o tym wszystkim dotarły z czasem do Joaba. Joab stał, jak wiadomo, po stronie Adoniasza i nie popierał Salomona. Joab również schronił się w przybytku Jahwe i chwycił się rogów ołtarza.
###### **1Krl 2,29**
 Kiedy doniesiono królowi Salomonowi, że Joab schronił się w przybytku Jahwe i trzyma się ołtarza, posłał Salomon Benajasza, syna Jojady, [do przybytku], aby go zgładził.
###### **1Krl 2,30**
 Wszedłszy do przybytku Jahwe, Benajasz powiedział do Joaba: Król rozkazuje ci, żebyś wyszedł [z przybytku]. Lecz on rzekł: Nie, nie wyjdę. Wolę tu umrzeć! Natychmiast powiadomił o tym Benajasz Salomona, powtarzając to, co mu oświadczył Joab i co odpowiedział.
###### **1Krl 2,31**
 Rzekł wtedy król do Benajasza: Niech będzie tak, jak chciał. Zadaj mu cios [śmiertelny] i pochowaj go. W ten sposób uwolnisz i mnie samego, i cały dom mojego ojca od krwi, którą bez powodu przelał Joab.
###### **1Krl 2,32**
 Jahwe sprawi, że jego krew spadnie na niego samego, czyli na tego, który zamordował dwóch ludzi sprawiedliwych i lepszych od niego. Bez wiedzy ojca mojego zgładził mieczem dowódcę wojsk izraelskich, Abnera, syna Nera, i Amasę, syna Jetera, dowódcę wojsk judzkich.
###### **1Krl 2,33**
 Ich krew spadnie na głowę Joaba i na głowy wszystkich jego potomków na wieki. Natomiast na Dawida, na jego potomków, na jego ród i tron niech zawsze już spływa pokój od Jahwe.
###### **1Krl 2,34**
 Poszedł tedy Benajasz i ugodził śmiertelnie Joaba. Został on pochowany koło własnego domu, na pustyni.
###### **1Krl 2,35**
 Na jego miejsce na dowódcę oddziałów wojskowych wyznaczył król Benajasza, syna Jojady, na miejsce Abiatara zaś mianował król kapłana Sadoka.
###### **1Krl 2,36**
 Potem kazał król przywołać do siebie Szimeiego i wydał mu taki rozkaz: Masz sobie zbudować dom w Jerozolimie. Tam osiądziesz na stałe i nie będziesz już wędrował ani w jedną stronę, ani w drugą.
###### **1Krl 2,37**
 Gdybyś zaś któregoś dnia wyszedł i przeprawił się na drugą stronę Cedronu, wiedz, że czeka cię za to śmierć. Na siebie samego bierzesz odpowiedzialność za twoją krew.
###### **1Krl 2,38**
 Rzekł na to królowi Szimei: To dobre słowa. Sługa twój uczyni wszystko, co mu rozkaże jego pan. I pozostawał Szimei przez wiele dni w Jerozolimie.
###### **1Krl 2,39**
 Lecz oto zdarzyło się, że po trzech latach dwaj jego słudzy zbiegli do Akisza, syna Maaki, króla Gat. Zaraz też doniesiono Szimejemu, że jego dwaj słudzy są w Gat.
###### **1Krl 2,40**
 Wstał tedy Szimei i osiodławszy swego osła, udał się do Gat, do Akisza, poszukując swoich sług. Potem ruszył w drogę powrotną, prowadząc swoje sługi.
###### **1Krl 2,41**
 Wkrótce też Salomon się dowiedział, że Szimei opuścił Jerozolimę, udał się do Gat i że już stamtąd powrócił.
###### **1Krl 2,42**
 Kazał tedy król wezwać do siebie Szimejego i powiedział do niego tak: Czyż nie zaklinałem cię na imię Jahwe, czyż nie ostrzegałem cię, że będziesz musiał umrzeć, jeśli któregoś dnia opuścisz miasto, by udać się w którąkolwiek stronę? Czyż mi nie odpowiedziałeś wtedy, że wydaje ci się słuszne to, co usłyszałeś?
###### **1Krl 2,43**
 Dlaczegóż więc nie dotrzymałeś przysięgi złożonej Jahwe, dlaczego nie byłeś posłuszny mojemu rozkazowi?
###### **1Krl 2,44**
 Ponadto rzekł król do Szimejego: Ty znasz przecież dobrze i nosisz w sercu swoim krzywdy, jakie wyrządziłeś mojemu ojcu, Dawidowi. Jahwe to sprawia, że całą twoją przewrotność ściągasz na własną głowę.
###### **1Krl 2,45**
 Natomiast błogosławiony będzie król Salomon, a tron Dawida będzie się utwierdzał przed obliczem Jahwe.
###### **1Krl 2,46**
 Potem wydał król rozkaz Benajaszowi, synowi Jojady, który poszedł i jednym ciosem zgładził Szimejego. A władza królewska w rękach Salomona umacniała się coraz bardziej.
# 1Krl 2 WUJ
###### **1Krl 2,1**
 I przybliżyły się dni Dawida, aby umarł, i rozkazał Salomonowi synowi swemu, mówiąc:
###### **1Krl 2,2**
 Ja idę w drogę wszystkiej ziemie: zmacniaj się, a bądź mężem,
###### **1Krl 2,3**
 Zachowaj straży Pana Boga twego, abyś chodził drogami jego: żebyś strzegł Ceremonij jego i przykazania jego, i sądów, i świadectw, jako napisano w zakonie Mojżeszowym: abyś rozumiał wszystko co czynisz, i do czego się jedno obrócisz:
###### **1Krl 2,4**
 Aby utwierdził Pan mowy swoje, które mówił o mnie, rzekąc: Jeśli będą strzedz synowie twoi dróg swych, i będą chodzić przedemną, w prawdzie ze wszystkiego serca swego, i ze wszystkiej dusze swojej, nie będzie odjęty mąż z stolice Izraelskiej.
###### **1Krl 2,5**
 Ty też wiesz, co mi uczynił Joab syn Sarwiej, co uczynił dwiema hetmanom wojska Izraelskiego, Abnerowi synowi Ner, i Amazie synowi Jether: które pozabijał, i wylał krew wojny w pokoju, i położył krew bitwy na pasie rycerskim swoim, który był około biódr jego, i na bucie swym, który był na nogach jego.
###### **1Krl 2,6**
 Uczynisz tedy według mądrości twej, a nie doprowadzisz sędziwości jego w pokoju do piekła.
###### **1Krl 2,7**
 Ale i synom Berzellai Galaadczyka łaskę oddasz, i będą jadać u stołu twego: bo mi zaszli, gdym uciekał przed Absalomem bratem twoim.
###### **1Krl 2,8**
 Masz też przy sobie Semei, syna Gera, syna Jemini z Bahurim, który mi złorzeczył złorzeczeństwem, nagorszem, gdym szedł do Obozu: ale iż mi zaszedł, gdym się przeprawiał przez Jordan, a przysiągłem mu przez Pana, rzekąc: Nie zabiję cię mieczem.
###### **1Krl 2,9**
 Ty go nie cierp, żeby był bez karania. Ale jesteś mężem mądrym, że będziesz wiedział co mu masz uczynić, i doprowadzisz sędziwość jego ze krwią do piekła.
###### **1Krl 2,10**
 Zasnął tedy Dawid z ojcy swemi, i pogrzebion jest w mieście Dawidowem.
###### **1Krl 2,11**
 A dnit których królował Dawid nad Izraelem czterdzieści lat jest: w Hebronie królował siedm lat, a w Jeruzalem trzydzieści lat i trzy.
###### **1Krl 2,12**
 A Salomon siadł na stolicy Dawida ojca swego, i zmocniło się królestwo jego barzo.
###### **1Krl 2,13**
 I wszedł Adonias syn Haggith do Bethsabee matki Salomonowej. Która mu rzekła: Spokojne li jest weście twoje? Który odpowiedział: Spokojne:
###### **1Krl 2,14**
 I przydał: mam nieco mówić z tobą. Któremu rzekła: Mów. A on rzekł:
###### **1Krl 2,15**
 Ty wiesz, iż moje było królestwo, i mnie był przełożył wszystek Izrael nad sobą za króla: lecz przeniesione jest królestwo, i dostało się bratu memu, bo mu je Pan naznaczył.
###### **1Krl 2,16**
 Teraz tedy jednej prośby proszę od ciebie: nie zawstydzaj oblicza mego. Która rzekła do niego: Powiedz.
###### **1Krl 2,17**
 A on rzekł: Proszę, abyś mówiła królowi Salomonowi (bo tobie nic odmówić nie może), aby mi dał Abisag Sunamitkę za żonę.
###### **1Krl 2,18**
 I rzekła Bethsabee: Dobrze, ja będę o cię z królem mówiła.
###### **1Krl 2,19**
 Przyszła tedy Bethsabee do króla Salomona, aby z nim mówiła za Adoniaszem: i wstał król przeciwko niej, i ukłonił się jej, i siadł na stolicy swojej: i postanowiono stolicę matce królewskiej, która siadła po prawicy jego.
###### **1Krl 2,20**
 I rzekła mu: O jednę prośbę maluczką ja cię proszę, nie zawstydzaj oblicza mego, I rzekł jej król: Proś matko moja: bo mi się niegodzi, abym odwrócił oblicza twoje.
###### **1Krl 2,21**
 Która rzekła: Niech będzie dana Abisag Sunamitka Adoniasowi bratu twemu za żonę.
###### **1Krl 2,22**
 Odpowiedział król Salomon, i rzekł matce swojej: czemu prosisz o Abisag Sunamitkę Adoniasowi? Proś mu i królestwa: bo on jest brat mój starszy niżeli ja, a ma po sobie Abiathar kapłana, i Joaba syna Sarwiej.
###### **1Krl 2,23**
 A tak przysiągł król Salomon na Pana mówiąc: To mi niech Bóg uczyni, i to niech przyczyni, że przeciw duszy swej mówił Adonias słowo to.
###### **1Krl 2,24**
 A teraz żywie Pan, który mię zmocnił, i posadził mię na stolicy Dawida ojca mego, i który mi uczynił dom jako rzekł: że dziś będzie zabit Adonias.
###### **1Krl 2,25**
 I posłał król Salomon przez rękę Banaje syna Jojady, który go zabił, i umarł.
###### **1Krl 2,26**
 Abiatharowi też kapłanowi rzekł król: Idź do Anathoth do roli twej, zaiste mężemeś śmierci: ale cię dziś nie zabiję, boś nosił skrzynię Pana Boga przed Dawidem ojcem moim, a wytrwałeś prace we wszystkiem, w czem pracował ociec mój.
###### **1Krl 2,27**
 Wyrzucił tedy Salomon Abiathara, żeby nie był kapłanem Pańskim: aby się spełniło słowo Pańskie, które mówił na dom Heli w Silo.
###### **1Krl 2,28**
 I przyszła wieść do Joaba, że Joab przestawał z Adoniaszem, a nie przestawał z Salomonem: a tak uciekł Joab do przybytku Pańskiego, i uchwycił się rogu ołtarza.
###### **1Krl 2,29**
 I oznajmiono królowi Salomonowi, że uciekł Joab do przybytku Pańskiego, a jest u ołtarza: i posłał Salomon Banaję syna Jojady, rzekąc: Idź, zabij go.
###### **1Krl 2,30**
 I przyszedł Banajas do przybytku Pańskiego, i rzekł mu: To mówi król: Wynidź. Który rzekł: Nie wynidę, ale tu umrę. I odniósł Banajas królowi mowę, mówiąc: Tak mówił Joab, i to mi od powiedział:
###### **1Krl 2,31**
 I rzekł mu król: Uczyńże jako mówił: a zabij go, i pogrzeb, a odejmiesz krew niewinną, którą wylał Joab, odemnie, i od domu ojca niego.
###### **1Krl 2,32**
 I odda Pan krew jego na głowę jego: ponieważ zabił dwu mężów sprawiedliwych i lepszych niżli sam: a zabił je mieczem, o czem nie wiedział ociec mój Dawid, Abnera syna Ner hetmana wojska Izraelskiego, i Amazę syna Jether, hetmana wojska Judzkiego:
###### **1Krl 2,33**
 I wróci się krew ich na głowę Joab, i na głowę nasienia jego na wieki. A Dawidowi i potomstwu jego, i domowi i stolicy jego niech będzie pokój aż na wieki od Pana.
###### **1Krl 2,34**
 A tak szedł Banajas syn Jojady, i rzuciwszy się nań, zabił: i pogrzebion jest w domu swym na pustyni.
###### **1Krl 2,35**
 I postanowił król Banaje syna Jojady nad wojskiem miasto niego, a Sadoka postawił kapłanem miasto Abiathara.
###### **1Krl 2,36**
 Posłał też król i wezwał Semei, i rzekł mu: Zbuduj sobie dom w Jeruzalem, a mieszkaj tam: a nie wynidziesz ztamtąd tam i sam.
###### **1Krl 2,37**
 Ale któregokolwiek dnia wynidziesz, a przejdziesz przez potok Cedron, wiedz, że zabit będziesz: krew twoja będzie na głowie twojej.
###### **1Krl 2,38**
 I rzekł Semei królowi: Dobra mowa, jako rzekł pan mój król, tak uczyni sługa twój. I mieszkał Semei w Jeruzalem przez niemały czas.
###### **1Krl 2,39**
 I przydało się po trzech leciech, że uciekli słudzy Semei do Achis syna Maacha króla Geth: i powiedziano Semei, że słudzy jego szli do Geth.
###### **1Krl 2,40**
 I wstał Semei i osiodłał osła swego, i jachał do Achis do Geth szukać sług swoich, i przywiódł je z Geth:
###### **1Krl 2,41**
 I powiedziano Salomonowi, że jeździł Semei do Geth z Jeruzalem, i wrócił się.
###### **1Krl 2,42**
 A posławszy wezwał go, i rzekł mu: Azam ci się nie oświadczył przez Pana, i opowiadałem ci: Któregokolwiek dnia wyszedszy pójdziesz tam i sam, wiedz, że umrzesz? I odpowiedziałeś mi: Dobra mowa, którąm słyszał.
###### **1Krl 2,43**
 Przecześ tedy nie strzegł przysięgi Pańskiej, i przykazania, którem ci był przykazał?
###### **1Krl 2,44**
 I rzekł król do Semei: Ty wiesz wszystko złe, którego jest świadome serce twoje, któreś uczynił Dawidowi ojcu memu: oddał Pan złość twoję na głowę twoję.
###### **1Krl 2,45**
 A król Salomon błogosławiony i stolica Dawidowa będzie utwierdzona przed Panem aż na wieki.
###### **1Krl 2,46**
 I rozkazał król Banajei synowi Jojady: który wyszedszy zabił go i umarł.
