# 1Tes 3 BT5
###### **1Tes 3,1**
 Nie mogąc przeto dłużej tego znosić, postanowiliśmy sami pozostać w Atenach,
###### **1Tes 3,2**
 a Tymoteusza, brata naszego i sługę Bożego w głoszeniu Ewangelii Chrystusa, wysłaliśmy, ażeby was utwierdził i umocnił w waszej wierze,
###### **1Tes 3,3**
 tak aby nikt się nie chwiał pośród tych ucisków. Po to bowiem, jak wiecie, zostaliśmy ustanowieni.
###### **1Tes 3,4**
 Albowiem gdyśmy pośród was przebywali, zapowiadaliśmy wam, że będziemy cierpieć ucisk, co też, jak wiecie, się stało.
###### **1Tes 3,5**
 Dlatego i ja, nie mogąc tego dłużej znosić, posłałem [go], aby zbadał wiarę waszą, czy przypadkiem nie zwiódł was kusiciel, bo wtedy nasz trud okazałby się daremny.
###### **1Tes 3,6**
 Teraz – kiedy Tymoteusz od was wrócił do nas i kiedy przyniósł nam radosną wieść o wierze i miłości waszej, a i o tym, że zawsze zachowujecie o nas dobrą pamięć i że bardzo pragniecie nas zobaczyć, podobnie jak my was –
###### **1Tes 3,7**
 doznaliśmy dzięki wam, bracia, pociechy: przez wiarę waszą we wszelkiej potrzebie i w naszym ucisku.
###### **1Tes 3,8**
 Teraz bowiem ożyliśmy, gdy wy trwacie w Panu.
###### **1Tes 3,9**
 Jakież bowiem podziękowanie możemy za was złożyć Bogu za radość, którą odczuwamy z waszego powodu przed Bogiem naszym?
###### **1Tes 3,10**
 Gorąco modlimy się we dnie i w nocy, abyśmy mogli osobiście was zobaczyć i dopełnić tego, czego brak waszej wierze.
###### **1Tes 3,11**
 Drogę naszą do was niech utoruje sam Bóg, Ojciec nasz, i Pan nasz, Jezus!
###### **1Tes 3,12**
 A Pan niech pomnoży was liczebnie i niech spotęguje miłość waszą nawzajem do siebie i do wszystkich, jaką i my mamy dla was;
###### **1Tes 3,13**
 aby serca wasze utwierdzone zostały w nienagannej świętości wobec Boga, Ojca naszego, na przyjście Pana naszego, Jezusa, wraz ze wszystkimi Jego świętymi.
# 1Tes 3 PAU
###### **1Tes 3,1**
 Nie mogąc dłużej czekać, postanowiliśmy sami co prawda pozostać w Atenach,
###### **1Tes 3,2**
 ale posłaliśmy do was Tymoteusza, naszego brata i współpracownika w głoszeniu Ewangelii Chrystusa. On miał was umocnić i zachęcić do wytrwania w wierze,
###### **1Tes 3,3**
 aby nikt się nie załamał z powodu utrapień. Sami przecież wiecie, że takie jest nasze zadanie.
###### **1Tes 3,4**
 Gdy byliśmy u was, zapowiadaliśmy wam, że będziemy musieli znosić utrapienia. Wiecie, że tak właśnie się stało.
###### **1Tes 3,5**
 Nie mogąc więc dłużej czekać, posłałem Tymoteusza, aby przyjrzał się waszej wierze, czy nie zwiódł was kusiciel i nasz trud nie poszedł na marne.
###### **1Tes 3,6**
 Teraz właśnie Tymoteusz wrócił od was i przyniósł dobre wieści o waszej wierze i miłości, o tym, że zawsze dobrze o nas myślicie, i podobnie jak my pragniecie nas zobaczyć.
###### **1Tes 3,7**
 Bracia, wasza wiara podniosła nas na duchu w całej naszej niedoli i utrapieniu.
###### **1Tes 3,8**
 Teraz dopiero żyjemy, gdy wy trwacie przy Panu.
###### **1Tes 3,9**
 Jakież bowiem dziękczynienie możemy złożyć Bogu za wszelką radość, którą dzięki wam przeżywamy przed naszym Bogiem?
###### **1Tes 3,10**
 Dniem i nocą modlimy się gorąco, abyśmy mogli spotkać się z wami osobiście i uzupełnić braki waszej wiary.
###### **1Tes 3,11**
 Sam Bóg, nasz Ojciec, i nasz Pan, Jezus, niech nam przygotuje drogę do was!
###### **1Tes 3,12**
 Niech Pan wzbogaci was we wzajemną miłość, abyście obfitowali w miłość do wszystkich, podobną do tej, jaką my was darzymy!
###### **1Tes 3,13**
 Niech Pan umocni wasze serca, abyście byli nienaganni w świętości wobec Boga, naszego Ojca, gdy przyjdzie nasz Pan, Jezus, w otoczeniu swoich świętych.
# 1Tes 3 BP
###### **1Tes 3,1**
 Ponieważ nie mogliśmy dłużej tego znosić, postanowiliśmy sami pozostać w Atenach,
###### **1Tes 3,2**
 a Tymoteusza, brata naszego i sługę Bożego w głoszeniu ewangelii Chrystusowej, wysłaliśmy z poleceniem, aby was umocnił i zachęcił do wytrwania w waszej wierze,
###### **1Tes 3,3**
 tak aby się nikt nie zachwiał w obecnych udrękach. Sami bowiem wiecie, że do tego jesteśmy wezwani.
###### **1Tes 3,4**
 Już wtedy, gdy byliśmy wśród was, zapowiadaliśmy, że będziemy cierpieć udręki, tak też - jak wiecie - się stało.
###### **1Tes 3,5**
 Nie mogąc dłużej tego znosić, posłałem go do was, aby zasięgnąć wiadomości o wierze waszej, czy przypadkiem nie zwiódł was kusiciel i czy nasz trud nie poszedł na marne.
###### **1Tes 3,6**
 Dopiero co przybył od was Tymoteusz i przyniósł nam dobre nowiny o waszej wierze i miłości wzajemnej i o tym, że zawsze macie nas we wdzięcznej pamięci i tęsknocie za naszym widokiem, podobnie jak my za waszym.
###### **1Tes 3,7**
 Wy i wasza stałość w wierze są nam pociechą w naszych przeciwnościach i udręce.
###### **1Tes 3,8**
 Ożyliśmy bowiem na wieść, że mocno stoicie przy Panu.
###### **1Tes 3,9**
 Jakże mamy dziękować Bogu za was i za całą radość, jakiej z waszego powodu przed Bogiem naszym doznajemy?
###### **1Tes 3,10**
 We dnie i w nocy modlimy się gorąco, żebyśmy mogli zobaczyć was osobiście i dopełnić tego, czego brakuje waszej wierze.
###### **1Tes 3,11**
 Drogę do was niech nam utoruje sam Bóg, nasz Ojciec, i Pan nasz Jezus.
###### **1Tes 3,12**
 Niech też Pan napełnia was coraz większą miłością do siebie nawzajem i do wszystkich ludzi, taką miłością, jaką ja was miłuję.
###### **1Tes 3,13**
 Niech też utwierdzi wasze serca w nienagannej świętości przed Bogiem i Ojcem naszym na powtórne przyjście Pana naszego Jezusa, razem ze wszystkimi Jego świętymi.
# 1Tes 3 BR
###### **1Tes 3,13**
 aby umacniały się coraz bardziej wasze serca, iżbyście byli doskonali i bez zarzutu wobec Boga Ojca naszego w dzień przyjścia Pana naszego Jezusa wraz ze wszystkimi, którzy do Niego należą.
###### **1Tes 3,1**
 Nie mogąc już dłużej przeciągać tego oczekiwania, postanowiliśmy sami pozostać [co prawda] w Atenach,
###### **1Tes 3,2**
 [ale] Tymoteusza, brata naszego i sługę w głoszeniu Ewangelii Chrystusa, wysłaliśmy do was, aby was podniósł na duchu i umocnił w wierze,
###### **1Tes 3,3**
 żeby się ktoś czasem nie załamał wśród tych ucisków. Taki jest przecież, jak wiecie, cel naszego posłannictwa.
###### **1Tes 3,4**
 Zresztą przypomnieć wypada, że kiedyśmy byli u was, mówiliśmy, że będziemy znosić prześladowanie, co też - jak wiecie - stało się wkrótce potem.
###### **1Tes 3,5**
 Dlatego też, nie mogąc już dłużej trwać w niepewności, posłałem [Tymoteusza], żeby się przyjrzał na miejscu waszej wierze, żeby stwierdził, czy przypadkiem nie uwiódł was kusiciel i czy nasze trudy wskutek tego nie poszły na marne.
###### **1Tes 3,6**
 Lecz teraz - kiedy już Tymoteusz wrócił od was i przyniósł nam wieści radosne o waszej wierze i miłości, gdy nas zapewniał o tym, że dobrze nas wspominacie i że pragniecie nas zobaczyć, tak jak my was -
###### **1Tes 3,7**
 doznaliśmy, dzięki wam, bracia, prawdziwej pociechy głównie z powodu wiary, w której trwacie mimo waszych niedostatków i naszego ucisku.
###### **1Tes 3,8**
 Teraz bowiem - gdyśmy się dowiedzieli, że jesteście wierni Panu i w nas wstąpił nowy duch.
###### **1Tes 3,9**
 Już nawet nie wiemy, jak mamy dziękować Bogu za ową radość, którą przeżywamy z powodu was przed Bogiem.
###### **1Tes 3,10**
 Nadal modlimy się gorąco we dnie i w nocy, abyśmy mogli wreszcie zobaczyć was osobiście i uzupełnić to, czego jeszcze niedostaje waszej wierze.
###### **1Tes 3,11**
 Obyż drogę do was utorował nam sam Bóg Ojciec nasz i Pan nasz Jezus!
###### **1Tes 3,12**
 Pan niech też sprawia, aby było was coraz więcej, aby miłość - ta wasza wzajemna i miłość do wszystkich ludzi - stawała się coraz większa i aby była wreszcie taka jak nasza miłość do was;
# 1Tes 3 WUJ
###### **1Tes 3,1**
 Przeto nie mogąc się więcej wstrzymać, upodobało się nam zostać w Atheniech samym:
###### **1Tes 3,2**
 A posłaliśmy Tymoteusza brata naszego, i sługę, Bożego w Ewanieliej Chrystusowej, aby was potwierdził i napominał z strony wiary waszej:
###### **1Tes 3,3**
 Aby żaden sobą nie trwożył w tych uciskach: abowiem sami wiecie, żeśmy na to postawieni.
###### **1Tes 3,4**
 Bo i gdyśmy byli u was, opowiedaliśmy wam, żeśmy mieli cierpieć uciśnienie, jako się i stało, i wiecie.
###### **1Tes 3,5**
 Dla tego i ja nie mogąc się więcej wstrzymać, posłałem, abym się dowiedział o wierze waszej, by was snać nie skusił ten co się dowiedział o wierze waszej, by was snać nie skusił ten co kusi, ażeby nie stała się daremna praca nasza.
###### **1Tes 3,6**
 Lecz teraz gdy Tymoteusz od was przyszedł od nas, i oznajmił nam wiarę i miłość waszę, a iż nas macie w dobrej pamięci zawsze, żądając nas widzieć, jako i my tez was:
###### **1Tes 3,7**
 Dla tego bracia jesteśmy pocieszeni, z was, w każdej doległości i utrapieniu naszem przez wiarę wasze:
###### **1Tes 3,8**
 Boć teraz żywiemy, jeśli wy stoicie w Panu.
###### **1Tes 3,9**
 Abowiem którąż dziękę możemy oddać Bogu za was, z wszelkiego wesela, którem się weselimy dla was przed Bogiem naszym?
###### **1Tes 3,10**
 W nocy i we dnie bardziej prosząc, abyśmy oglądali twarz waszę i dopełnili tego czego nie dostaje wierze waszej?
###### **1Tes 3,11**
 A sam Bóg i Ociec nasz, i Pan nasz Jezus Chrystus, niech prostuje drogę naszę do was.
###### **1Tes 3,12**
 A was Pan niechaj rozmnoży, i niech uczyni, aby obfitowała miłość wasza, jednego ku drugiemu, i ku wszystkim: jako i my przeciwko wam:
###### **1Tes 3,13**
 Na utwierdzenie serc waszych bez skargi w świątobliwości, przed Bogiem i Ojcem naszym, na przyście Pana naszego Jezusa Chrystusa ze wszystkiemi świętemi jego, Amen.
# 1Tes 3 STERN
###### **1Tes 3,1**
 Kiedy już zatem dłużej tego znieść nie mogliśmy, zgodziliśmy się pozostać w Atenach sami,
###### **1Tes 3,2**
 a wysłaliśmy Tymoteusza, brata naszego i współtrudzącego się w Bogu na rzecz Dobrej Nowiny o Mesjaszu, aby was ugruntował i pokrzepił w waszej ufności,
###### **1Tes 3,3**
 tak aby nikt z was nie dał się tym uciskom wytrącić z równowagi. Bo sami wiecie, że one na nas przyjść muszą
###### **1Tes 3,4**
 i nawet kiedy byliśmy u was, wciąż powtarzaliśmy wam zawczasu, że będziemy wkrótce prześladowani, i jak wiecie, rzeczywiście tak się stało.
###### **1Tes 3,5**
 Dlatego właśnie, nie mogąc znieść już tego dłużej, posłałem, aby się wywiedzieć o waszą ufność. Bałem się, że Kusiciel poddał was jakoś pokusie, a trud nasz poszedł na marne.
###### **1Tes 3,6**
 Teraz jednak przybył do nas od was Tymoteusz, niosąc dobre wieści o waszej ufności i miłości i opowiadając, że dobrze nas wspominacie i że zawsze pragniecie nas ujrzeć, jak i my pragniemy ujrzeć was.
###### **1Tes 3,7**
 Dzięki temu, bracia, pomimo wszystkich kłopotów i udręk pocieszyliśmy się wami z powodu waszej ufności,
###### **1Tes 3,8**
 tak że teraz żyjemy, bo wy nadal trwacie mocno, zjednoczeni z Panem.
###### **1Tes 3,9**
 Bo doprawdy nie możemy się nadziękować Bogu za was ani wyrazić naszemu Bogu całej radości, jaką z was mamy.
###### **1Tes 3,10**
 Noc i dzień modlimy się z całych sił, abyśmy mogli ujrzeć was osobiście i zaradzić ewentualnym niedostatkom w waszej ufności.
###### **1Tes 3,11**
 Niech Bóg, nasz Ojciec, i Pan nasz Jeszua kierują naszą drogą do was.
###### **1Tes 3,12**
 Co zaś do was, niech Pan sprawi, abyście wzrastali w miłości i obfitowali w miłość ku sobie nawzajem i ku wszystkim, jak to i my względem was czynimy,
###### **1Tes 3,13**
 ażeby dał wam On wewnętrzną siłę, tak abyście z racji swej świętości byli bez zarzutu, gdy staniecie przed Bogiem, naszym Ojcem, w chwili przyjścia naszego Pana Jeszui ze wszystkimi Jego aniołami.
# 1Tes 3 TRO
###### **1Tes 3,1**
 **διο** *dio* Dlatego [[G1352]] [[CONJ]] **μηκετι** *mēketi* już więcej nie [[G3371]] [[ADV]] **στεγοντες** *stegontes* wytrzymując – znosząc [[G4722]] WTV-PAP-NPM **ευδοκησαμεν** *eudokēsamen* znaleźliśmy upodobanie [[G2106]] WTV-AAI-1P **καταλειφθηναι** *kataleifthēnai* (by) zostać pozostawionymi – (by) zostać opuszczonymi [[G2641]] WTV-APN **εν** *en* w [[G1722]] [[PREP]] **αθηναις** *athēnais* Atenach [[G116]] WTN-DPF **μονοι** *monoi* sami [[G3441]] WTA-NPM
###### **1Tes 3,2**
 **και** *kai* I [[G2532]] [[CONJ]] **επεμψαμεν** *epempsamen* posłaliśmy [[G3992]] WTV-AAI-1P **τιμοθεον** *timotheon* Tymoteusza – [czczący Boga] [[G5095]] [[N-ASM]] **τον** *ton* [[G3588]] [[T-ASM]] **αδελφον** *adelfon* brata [[G80]] [[N-ASM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **και** *kai* i [[G2532]] [[CONJ]] **διακονον** *diakonon* sługę [[G1249]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **συνεργον** *synergon* współpracownika [[G4904]] WTA-ASM **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **ευαγγελιω** *euangeliō* dobrej nowinie [[G2098]] WTN-DSN **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **στηριξαι** *stēriksai* utwierdzić – postawić mocno [[G4741]] [[V-AAN]] **υμας** *hymas* was [[G5209]] WTP-2AP **και** *kai* i [[G2532]] [[CONJ]] **παρακαλεσαι** *parakalesai* zachęcić [[G3870]] [[V-AAN]] **υμας** *hymas* was [[G5209]] WTP-2AP **περι** *peri* odnośnie – o [[G4012]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **υμων** *hymōn* waszej [[G5216]] WTP-2GP
###### **1Tes 3,3**
 **τω** *tō* (by) [[G3588]] WTT-DSM **μηδενα** *mēdena* nikt [[G3367]] WTA-ASM **σαινεσθαι** *sainesthai* być zachwianym [[G4525]] WTV-PPN **εν** *en* wśród [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **θλιψεσιν** *thlipsesin* ucisków – utrapień [[G2347]] WTN-DPF **ταυταις** *tautais* tych [[G3778]] WTD-DPF **αυτοι** *autoi* sami [[G846]] WTP-NPM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **οιδατε** *oidate* wiecie [[G1492]] WTV-RAI-2P **οτι** *hoti* że [[G3754]] [[CONJ]] **εις** *eis* do [[G1519]] [[PREP]] **τουτο** *touto* tego [[G5124]] WTD-ASN **κειμεθα** *keimetha* jesteśmy położeni – jesteśmy umieszczeni [[G2749]] WTV-PNI-1P
###### **1Tes 3,4**
 **και** *kai* A [[G2532]] [[CONJ]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **οτε** *hote* gdy [[G3753]] [[ADV]] **προς** *pros* przy [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **ημεν** *ēmen* byliśmy [[G1510]] WTV-IXI-1P **προελεγομεν** *proelegomen* wcześniej mówiliśmy [[G4302]] WTV-IAI-1P **υμιν** *hymin* wam [[G5213]] WTP-2DP **οτι** *hoti* że [[G3754]] [[CONJ]] **μελλομεν** *mellomen* mamy [[G3195]] WTV-PAI-1P **θλιβεσθαι** *thlibesthai* być uciskani – być trapieni [[G2346]] WTV-PPN **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **εγενετο** *egeneto* stało się [[G1096]] WTV-2ADI-3S **και** *kai* i [[G2532]] [[CONJ]] **οιδατε** *oidate* wiecie [[G1492]] WTV-RAI-2P
###### **1Tes 3,5**
 **δια** *dia* Przez [[G1223]] [[PREP]] **τουτο** *touto* to [[G5124]] WTD-ASN **καγω** *kagō* i ja [[G2504]] WTP-1NS-C **μηκετι** *mēketi* już więcej nie [[G3371]] [[ADV]] **στεγων** *stegōn* wytrzymując – znosząc [[G4722]] [[V-PAP-NSM]] **επεμψα** *epempsa* posłałem [[G3992]] WTV-AAI-1S **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **γνωναι** *gnōnai* poznać [[G1097]] [[V-2AAN]] **την** *tēn* [[G3588]] WTT-ASF **πιστιν** *pistin* wiarę [[G4102]] WTN-ASF **υμων** *hymōn* waszą [[G5216]] WTP-2GP **μηπως** *mēpōs* aby czasem nie – czy nie jakoś [[G3381]] [[CONJ]] **επειρασεν** *epeirasen* wystawił na próbę – doświadczył [[G3985]] WTV-IAI-3S **υμας** *hymas* was [[G5209]] WTP-2AP **ο** *ho* [[G3588]] [[T-NSM]] **πειραζων** *peirazōn* poddający próbie – doświadczający [[G3985]] [[V-PAP-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **εις** *eis* na [[G1519]] [[PREP]] **κενον** *kenon* puste – próżne [[G2756]] WTA-ASN **γενηται** *genētai* stałby się [[G1096]] WTV-2ADS-3S **ο** *ho* [[G3588]] [[T-NSM]] **κοπος** *kopos* trud [[G2873]] [[N-NSM]] **ημων** *hēmōn* nasz [[G2257]] WTP-1GP
###### **1Tes 3,6**
 **αρτι** *arti* Teraz [[G737]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **ελθοντος** *elthontos* gdy przyszedł [[G2064]] WTV-2AAP-GSM **τιμοθεου** *timotheou* Tymoteusz – [czczący Boga] [[G5095]] [[N-GSM]] **προς** *pros* do [[G4314]] [[PREP]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **αφ** *af* od [[G575]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **και** *kai* i [[G2532]] [[CONJ]] **ευαγγελισαμενου** *euangelisamenou* gdy ogłosił dobrą nowinę [[G2097]] WTV-AMP-GSM **ημιν** *hēmin* nam [[G2254]] WTP-1DP **την** *tēn* (o) [[G3588]] WTT-ASF **πιστιν** *pistin* wierze [[G4102]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **αγαπην** *agapēn* miłości [[G26]] WTN-ASF **υμων** *hymōn* waszej [[G5216]] WTP-2GP **και** *kai* i [[G2532]] [[CONJ]] **οτι** *hoti* że [[G3754]] [[CONJ]] **εχετε** *echete* macie [[G2192]] WTV-PAI-2P **μνειαν** *mneian* wspomnienie [[G3417]] WTN-ASF **ημων** *hēmōn* (o) nas [[G2257]] WTP-1GP **αγαθην** *agathēn* dobre [[G18]] WTA-ASF **παντοτε** *pantote* każdej chwili [[G3842]] [[ADV]] **επιποθουντες** *epipothountes* pragnąc – tęskniąc [[G1971]] WTV-PAP-NPM **ημας** *hēmas* nas [[G2248]] WTP-1AP **ιδειν** *idein* zobaczyć [[G1492]] [[V-2AAN]] **καθαπερ** *kathaper* tak, jak [[G2509]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **ημεις** *hēmeis* my [[G2249]] WTP-1NP **υμας** *hymas* was [[G5209]] WTP-2AP
###### **1Tes 3,7**
 **δια** *dia* przez [[G1223]] [[PREP]] **τουτο** *touto* to [[G5124]] WTD-ASN **παρεκληθημεν** *pareklēthēmen* zostaliśmy zachęceni [[G3870]] WTV-API-1P **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **εφ** *ef* z powodu [[G1909]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **επι** *epi* w [[G1909]] [[PREP]] **παση** *pasē* każdym [[G3956]] WTA-DSF **τη** *tē* [[G3588]] WTT-DSF **θλιψει** *thlipsei* ucisku – utrapieniu [[G2347]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **αναγκη** *anagkē* potrzebie – konieczności [[G318]] [[N-DSF]] **ημων** *hēmōn* naszej [[G2257]] WTP-1GP **δια** *dia* przez [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **υμων** *hymōn* waszą [[G5216]] WTP-2GP **πιστεως** *pisteōs* wiarę [[G4102]] [[N-GSF]]
###### **1Tes 3,8**
 **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **νυν** *nyn* teraz [[G3568]] [[ADV]] **ζωμεν** *zōmen* żyjemy [[G2198]] WTV-PAI-1P **εαν** *ean* jeśli [[G1437]] WTCOND **υμεις** *hymeis* wy [[G5210]] WTP-2NP **στηκητε** *stēkēte* stalibyście – trwalibyście [[G4739]] WTV-PAS-2P **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM
###### **1Tes 3,9**
 **τινα** *tina* Jakie [[G5101]] WTI-ASF **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ευχαριστιαν** *eucharistian* dziękczynienie – wdzięczność [[G2169]] WTN-ASF **δυναμεθα** *dynametha* możemy [[G1410]] WTV-PNI-1P **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **ανταποδουναι** *antapodounai* odpłacić – oddać w zamian [[G467]] [[V-2AAN]] **περι** *peri* za [[G4012]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **επι** *epi* z powodu [[G1909]] [[PREP]] **παση** *pasē* całej [[G3956]] WTA-DSF **τη** *tē* [[G3588]] WTT-DSF **χαρα** *chara* radości [[G5479]] [[N-DSF]] **η** *hē* którą [[G3739]] WTR-DSF **χαιρομεν** *chairomen* radujemy się – cieszymy się [[G5463]] WTV-PAI-1P **δι** *di* przez [[G1223]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **εμπροσθεν** *emprosthen* przed [[G1715]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Bogiem [[G2316]] [[N-GSM]] **ημων** *hēmōn* naszym [[G2257]] WTP-1GP
###### **1Tes 3,10**
 **νυκτος** *nyktos* nocą [[G3571]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **ημερας** *hēmeras* dniem [[G2250]] [[N-GSF]] **υπερ** *hyper* ponad – bardzo [[G5228]] [[PREP]] **εκπερισσου** *ekperissou* wszelką miarę – usilnie [[G4057]] [[ADV]] **δεομενοι** *deomenoi* prosząc – modląc się [[G1189]] WTV-PNP-NPM **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **ιδειν** *idein* zobaczyć [[G1492]] [[V-2AAN]] **υμων** *hymōn* wasze [[G5216]] WTP-2GP **το** *to* [[G3588]] WTT-ASN **προσωπον** *prosōpon* oblicze [[G4383]] WTN-ASN **και** *kai* i [[G2532]] [[CONJ]] **καταρτισαι** *katartisai* uzupełnić – wydoskonalić [[G2675]] [[V-AAN]] **τα** *ta* [[G3588]] WTT-APN **υστερηματα** *hysterēmata* braki [[G5303]] WTN-APN **της** *tēs* [[G3588]] [[T-GSF]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **υμων** *hymōn* waszej [[G5216]] WTP-2GP
###### **1Tes 3,11**
 **αυτος** *autos* Sam [[G846]] WTP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **πατηρ** *patēr* Ojciec [[G3962]] [[N-NSM]] **ημων** *hēmōn* nasz [[G2257]] WTP-1GP **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **ημων** *hēmōn* nasz [[G2257]] WTP-1GP **ιησους** *iēsous* Jezus – [JHWH jest zbawieniem] [[G2424]] [[N-NSM]] **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **κατευθυναι** *kateuthynai* oby wyprostował [[G2720]] WTV-AAO-3S **την** *tēn* [[G3588]] WTT-ASF **οδον** *hodon* drogę [[G3598]] WTN-ASF **ημων** *hēmōn* naszą [[G2257]] WTP-1GP **προς** *pros* do [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP
###### **1Tes 3,12**
 **υμας** *hymas* Was [[G5209]] WTP-2AP **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **πλεονασαι** *pleonasai* oby uczynił większymi [[G4121]] WTV-AAO-3S **και** *kai* i [[G2532]] [[CONJ]] **περισσευσαι** *perisseusai* oby uczynił obfitującymi [[G4052]] WTV-AAO-3S **τη** *tē* [[G3588]] WTT-DSF **αγαπη** *agapē* miłością [[G26]] [[N-DSF]] **εις** *eis* do [[G1519]] [[PREP]] **αλληλους** *allēlous* jedni drugich [[G240]] WTC-APM **και** *kai* i [[G2532]] [[CONJ]] **εις** *eis* do [[G1519]] [[PREP]] **παντας** *pantas* wszystkich [[G3956]] WTA-APM **καθαπερ** *kathaper* tak, jak [[G2509]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **ημεις** *hēmeis* my [[G2249]] WTP-1NP **εις** *eis* do [[G1519]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP
###### **1Tes 3,13**
 **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **στηριξαι** *stēriksai* utwierdzić – postawić mocno [[G4741]] [[V-AAN]] **υμων** *hymōn* wasze [[G5216]] WTP-2GP **τας** *tas* [[G3588]] WTT-APF **καρδιας** *kardias* serca [[G2588]] WTN-APF **αμεμπτους** *amemptous* (jako) nienaganne [[G273]] WTA-APF **εν** *en* w [[G1722]] [[PREP]] **αγιωσυνη** *hagiōsynē* poświęceniu – uświęceniu [[G42]] [[N-DSF]] **εμπροσθεν** *emprosthen* przed [[G1715]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Bogiem [[G2316]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **πατρος** *patros* Ojcem [[G3962]] [[N-GSM]] **ημων** *hēmōn* naszym [[G2257]] WTP-1GP **εν** *en* podczas [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **παρουσια** *parousia* przyjście [[G3952]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **μετα** *meta* ze [[G3326]] [[PREP]] **παντων** *pantōn* wszystkimi [[G3956]] WTA-GPM **των** *tōn* [[G3588]] WTT-GPM **αγιων** *hagiōn* świętymi [[G40]] WTA-GPM **αυτου** *autou* Jego [[G846]] [[P-GSM]]
