# Dn 3 BT5
###### **Dn 3,1**
 Król Nabuchodonozor sporządził złoty po-sąg wysokości sześćdziesięciu łokci i szero-kości sześciu łokci i kazał go ustawić na równinie Dura w prowincji babilońskiej.
###### **Dn 3,2**
 Następnie król Nabuchodonozor polecił satrapom, namiestnikom, rządcom, doradcom, skarbnikom, sędziom, prawnikom i wszystkim zarządcom prowincji zebrać się i uczestniczyć w poświęceniu posągu wzniesionego przez króla Nabuchodonozora.
###### **Dn 3,3**
 Zebrali się więc satrapowie, namiestnicy, rządcy, doradcy, skarbnicy, sędziowie, prawnicy i wszyscy zarządcy prowincji na poświęcenie posągu wzniesionego przez króla Nabuchodonozora i ustawili się przed posągiem, który wzniósł król Nabuchodonozor.
###### **Dn 3,4**
 Herold zaś obwieszczał donośnie: «***Rozkaz dla was, narody, ludy, języki:***
###### **Dn 3,5**
 ***W chwili, gdy usłyszycie dźwięk rogu, fletu, lutni, harfy, psalterium, dud i wszelkiego rodzaju instrumentów muzycznych, upadniecie na twarz i oddacie pokłon złotemu posągowi, który wzniósł król Nabuchodonozor.***
###### **Dn 3,6**
 ***Kto by nie upadł na twarz i nie oddał pokłonu, zostanie natychmiast wrzucony do rozpalonego pieca«***.
###### **Dn 3,7**
 Gdy więc dał się słyszeć dźwięk rogu, fletu, lutni, harfy, psalterium, dud i wszelkiego rodzaju instrumentów muzycznych, wszystkie narody, ludy, języki padły na twarz, oddając pokłon złotemu posągowi, który wzniósł król Nabuchodonozor.
###### **Dn 3,8**
 W tej samej chwili niektórzy Chaldejczycy przyszli, by oskarżyć Żydów.
###### **Dn 3,9**
 Zwrócili się do króla Nabuchodonozora i powiedzieli: «***Królu, żyj wiecznie!
###### **Dn 3,10**
 Wydałeś, królu, rozporządzenie, by każdy, gdy usłyszy dźwięk rogu, fletu, lutni, harfy, psalterium, dud i wszelkiego rodzaju instrumentów muzycznych, upadł na twarz i oddał pokłon złotemu posągowi.
###### **Dn 3,11**
 Kto by zaś nie upadł na twarz i nie oddał pokłonu, miał być wrzucony do rozpalonego pieca.
###### **Dn 3,12**
 Są tutaj jednak mężowie żydowscy, których uczyniłeś zwierzchnikami miasta babilońskiego: Szadrak, Meszak i Abed-Nego; mężowie ci nie liczą się z tobą, królu. Nie oddają czci twemu bogu ani nie oddają pokłonu złotemu posągowi, który wzniosłeś***».
###### **Dn 3,13**
 Nabuchodonozor zapłonął gniewem i rozkazał przyprowadzić Szadraka, Meszaka i Abed-Nega. Sprowadzono więc tych mężów przed króla.
###### **Dn 3,14**
 Zwrócił się do nich Nabuchodonozor i powiedział: «***Czy jest prawdą, Szadraku, Meszaku i Abed-Nego, że nie czcicie mojego boga ani nie oddajecie pokłonu złotemu posągowi, który wzniosłem?***
###### **Dn 3,15**
 ***Czy teraz jesteście gotowi – w chwili gdy usłyszycie dźwięk rogu, fletu, lutni, harfy, psalterium, dud i wszelkiego rodzaju instrumentów muzycznych – upaść na twarz i oddać pokłon posągowi, który uczyniłem? Jeżeli nie oddacie pokłonu, zostaniecie natychmiast wrzuceni do rozpalonego pieca. Który zaś bóg mógłby was wyrwać z moich rąk?***»
###### **Dn 3,16**
 Szadrak, Meszak i Abed-Nego odpowiedzieli, zwracając się do króla Nabuchodonozora: «***Nie musimy tobie, królu, odpowiadać w tej sprawie.***
###### **Dn 3,17**
 ***Jeżeli nasz Bóg, któremu służymy, zechce nas wybawić z rozpalonego pieca, może nas wyratować z twej ręki, królu!***
###### **Dn 3,18**
 ***Jeśli zaś nie, wiedz, królu, że nie będziemy czcić twego boga ani oddawać pokłonu złotemu posągowi, który wzniosłeś***».
###### **Dn 3,19**
 Na to wpadł Nabuchodonozor w gniew, a wyraz jego twarzy zmienił się w stosunku do Szadraka, Meszaka i Abed-Nega. Wydał rozkaz, by rozpalono piec siedem razy bardziej, niż było trzeba.
###### **Dn 3,20**
 Mężom zaś najsilniejszym spośród swego wojska polecił związać Szadraka, Meszaka i Abed-Nega i wrzucić ich do rozpalonego pieca.
###### **Dn 3,21**
 Związano więc tych mężów w ich płaszczach, obuwiu, tiarach i ubra-niach, i wrzucono do rozpalonego pieca.
###### **Dn 3,22**
 Ponieważ rozkaz króla był stanowczy, a piec nadmiernie rozpalony, płomień ognia zabił tych mężów, którzy wrzucili Szadraka, Meszaka i Abed-Nega.
###### **Dn 3,23**
 Trzej zaś mężowie, Szadrak, Meszak i Abed-Nego, wpadli związani do środka rozpalonego pieca.
###### **Dn 3,24**
  I chodzili wśród płomieni, wysławiając Boga i błogosławiąc Pana.
###### **Dn 3,25**
 Powstawszy zaś, Azariasz tak się modlił, a otwarłszy usta, mówił pośród ognia:
###### **Dn 3,26**
  «***Błogosławiony jesteś, Panie, Boże naszych przodków, i pełen chwały; imię Twoje jest błogosławione na wieki.***
###### **Dn 3,27**
 ***Albowiem jesteś sprawiedliwy we wszystkim, co nam uczyniłeś, a wszystkie czyny Twoje pełne prawdy, drogi zaś Twoje prostei wszystkie wyroki pełne słuszności.***
###### **Dn 3,28**
 ***Bo wydałeś sprawiedliwe wyrokiwe wszystkim, co sprowadziłeś na nasi na Jerozolimę, święte miasto naszych przodków. Bo zgodnie ze sprawiedliwym wyrokiemsprowadziłeś to wszystko na nasz powodu naszych grzechów.***
###### **Dn 3,29**
 ***Tak, zgrzeszyliśmy i popełniliśmy nieprawości, opuszczając Ciebie. Okazaliśmy się przewrotni we wszystkim, a przykazań Twoich nie słuchaliśmy.***
###### **Dn 3,30**
 ***Nie zachowaliśmy ani nie wypełnialiśmytego, co nam nakazałeś, by się nam dobrze wiodło.***
###### **Dn 3,31**
 ***Wszystko, co na nas sprowadziłeś, i wszystko, co nam uczyniłeś, uczyniłeś według sprawiedliwego sądu.***
###### **Dn 3,32**
 ***Wydałeś nas w ręce naszych niegodziwych nie-przyjaciół, najgorszych spośród odstępców, i niesprawiedliwemu królowi, najbardziej przewrotnemu na ziemi.***
###### **Dn 3,33**
 ***Teraz zaś nie mamy odwagi otworzyć ust. Wstyd i hańba okryły Twoje sługii tych, co cześć Ci oddają.***
###### **Dn 3,34**
 ***Nie opuszczaj nas na zawsze – przez wzgląd na święte Twe imięnie zrywaj Twego przymierza.***
###### **Dn 3,35**
 ***Nie odwracaj od nas swego miłosierdzia, przez wzgląd na Twego przyjaciela, Abrahama, sługę Twego, Izaaka, i Twego świętego – Izraela.***
###### **Dn 3,36**
***Im to przyrzekłeśrozmnożyć potomstwojak gwiazdy na niebiei jak piasek nad brzegiem morza.***
###### **Dn 3,37**
 Panie, oto jesteśmy najmniejsispośród wszystkich narodów. Oto jesteśmy dziś poniżeni na całej ziemiz powodu naszych grzechów.
###### **Dn 3,38**
 ***Nie ma obecnie władcy, proroka ani wodza, ani całopalenia, ani ofiar, ani darów pokarmowych, ani kadzielnych. Nie ma gdzie ofiarować Tobie pierwocini doznać Twego miłosierdzia.***
###### **Dn 3,39**
 ***Niech jednak dusza strapiona i duch uniżonyznajdą u Ciebie upodobanie. Jak całopalenia z baranów i cielców, i z tysięcy tłustych owiec,***
###### **Dn 3,40**
 ***tak niechaj dziś będzie nasza ofiara przed Tobąi niech Ci się podoba!Ponieważ ci, co pokładają ufność w Tobie, nie mogą doznać wstydu.***
###### **Dn 3,41**
 ***Teraz zaś idziemy za Tobąz całego serca, odczuwamy lęk przed Tobąi szukamy Twego oblicza.***
###### **Dn 3,42**
 ***Nie zawstydzaj nas, lecz postępuj z namiwedług swej łagodnościi według wielkiego swego miłosierdzia.***
###### **Dn 3,43**
 ***Wybaw nas przez swe cudai uczyń swe imię sławnym, Panie!***
###### **Dn 3,44**
 ***Wszyscy ci, co wyrządzają krzywdę Twym sługom, niech doznają hańby!Niech się okryją wstydempozbawieni wszelkiej siły i mocy, a potęga ich niech zostanie skruszona!***
###### **Dn 3,45**
 ***Niech poznają, że tylko Ty jesteś Panem Bogiem, pełnym chwały na całej ziemi***».
###### **Dn 3,46**
  Słudzy królewscy, którzy ich wrzucili [do pieca], nie ustawali w podsycaniu ognia ropą naftową, smołą, pakułami i chrustem,
###### **Dn 3,47**
 tak że płomień wznosił się na wysokość czterdziestu dziewięciu łokci ponad piec
###### **Dn 3,48**
 i rozprzestrzeniając się, spalił tych Chaldejczyków, którzy znaleźli się koło pieca.
###### **Dn 3,49**
 Jednak anioł Pański zstąpił do pieca wraz z Azariaszem i jego towarzyszami i usunął płomień ognia z pieca,
###### **Dn 3,50**
 sprowadzając do środka pieca jakby orzeźwiający powiew wiatru, tak że ogień nie dosięgnął ich wcale, nie sprawił im bólu ani nie wyrządził krzywdy.
###### **Dn 3,51**
 Wtedy ci trzej jakby jednym głosem wysławiali, chwalili i błogosławili Boga, mówiąc w piecu:
###### **Dn 3,52**
 «***Błogosławiony jesteś, Panie, Boże naszych ojców – pełen chwały i wywyższony na wieki. Błogosławione niech będzie Twoje imię pełne chwały i świętości – chwalebne i wywyższone na wieki.***
###### **Dn 3,53**
 ***Błogosławiony jesteś w przybytkuświętej Twojej chwały –chwalony, sławiony przez wieki ponad wszystko.***
###### **Dn 3,54**
 ***Błogosławiony jesteś na tronie Twego królestwa –chwalony, sławiony przez wieki nade wszystko.***
###### **Dn 3,55**
 ***Błogosławiony jesteś Ty, co spoglądasz w otchłanie, co na Cherubach zasiadasz –pełen chwały i wywyższony na wieki.***
###### **Dn 3,56**
 ***Błogosławiony jesteś na sklepieniu nieba –pełen chwały i sławny na wieki.***
###### **Dn 3,57**
 ***Wszystkie Pańskie dzieła, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,58**
 ***Aniołowie Pańscy, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,59**
 ***Niebiosa, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,60**
 ***Wszystkie wody ponad niebem, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,61**
 ***Wszystkie potęgi, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,62**
 ***Słońce i księżycu, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,63**
 ***Gwiazdy nieba, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,64**
 ***Deszcze i rosy, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,65**
 ***Wszystkie wichry niebieskie, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,66**
 ***Ogniu i żarze, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,67**
 ***Chłodzie i upale, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,68**
 ***Rosy i szrony, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,69**
 ***Mrozy i zimna, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,70**
 ***Lody i śniegi, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,71**
 ***Dnie i noce, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,72**
 ***Światło i ciemności, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,73**
 ***Błyskawice i chmury, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,74**
 ***Niech ziemia błogosławi Pana, niech Go chwali i wywyższa na wieki!***
###### **Dn 3,75**
 ***Góry i pagórki, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,76**
 ***Wszystkie rośliny ziemi, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,77**
 ***Źródła, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,78**
 ***Morza i rzeki, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,79**
 ***Wieloryby i stworzenia morskie, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,80**
 ***Wszelkie ptaki podniebne, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,81**
 ***Zwierzęta dzikie i trzody, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,82**
 ***Synowie ludzcy, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,83**
 ***Izraelu, błogosław Pana, chwal i wywyższaj Go na wieki!***
###### **Dn 3,84**
 ***Kapłani Pańscy, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,85**
 ***Słudzy Pańscy, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,86**
 ***Duchy i dusze sprawiedliwych, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,87**
 ***Święci i pokornego serca, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki!***
###### **Dn 3,88**
 ***Chananiaszu, Azariaszu, Miszaelu, błogosławcie Pana, chwalcie i wywyższajcie Go na wieki, bo wybawił nas z Otchłanii z mocy śmierci ocalił nas, wyrwał nas spośród buchającego żarem ognia.***
###### **Dn 3,89**
 ***Wychwalajcie Pana, bo łaskawy, bo Jego łaska na wieki.***
###### **Dn 3,90**
 ***Wszyscy bogobojni, błogosławcie Pana, Boga bogów, chwalcie i wysławiajcie, bo na wieki Jego łaskawość***».
###### **Dn 3,91**
 (24)Król Nabuchodonozor popadł w zdumienie i nagle powstał. Zwrócił się do swych doradców, mówiąc: «***Czyż nie wrzuciliśmy trzech związanych mężów do ognia?***» Oni zaś odpowiedzieli królowi: «***Oczywiście, królu***».
###### **Dn 3,92**
 (25) On zaś w odpowiedzi rzekł: «***Lecz widzę czterech mężów rozwiązanych, przechadzających się pośród ognia, i nie dzieje się im nic złego; czwarty wyglądem przypomina anioła Bożego***».
###### **Dn 3,93**
 (26) Wtedy przystąpił Nabuchodonozor do otworu płonącego pieca i powiedział: «***Szadraku, Meszaku i Abed-Nego, słudzy Najwyższego Boga, wyjdźcie i przyjdźcie tutaj!«*** Szadrak, Meszak i Abed-Nego wyszli więc z ognia.
###### **Dn 3,94**
 (27) Satrapowie, namiestnicy, rządcy i doradcy królewscy zebrali się i spostrzegli, że ogień nie miał władzy nad ciałami tych mężów, tak że żaden włos z ich głów nie uległ spaleniu ani ich płaszcze uszkodzeniu, ani nie było czuć od nich swądu spalenizny.
###### **Dn 3,95**
 (28) Nabuchodonozor powiedział na to: «***Niech będzie błogosławiony Bóg Szadraka, Meszaka i Abed-Nega, który posłał swego anioła, by uratować swoje sługi. W Nim pokładali ufność i przekroczyli nakaz królewski, oddając swe ciała, aby nie oddawać czci ani pokłonu innemu bogu poza Nim.***
###### **Dn 3,96**
 (29)***Dlatego wydaję rozkaz, by bez względu na przynależność narodową, rodową czy język, każdy, kto by wypowiedział bluźnierstwo przeciw Bogu Szadraka, Meszaka i Abed-Nega, został rozerwany w kawałki, a dom jego żeby stał się rumowiskiem. Bo nie ma innego Boga, który mógłby zapewnić ratunek, jak Ten***».
###### **Dn 3,97**
 (30) Potem król obsypał zaszczytami Szadraka, Meszaka i Abed-Nega w prowincji Babilonu.
###### **Dn 3,98**
 (31) Król Nabuchodonozor do wszystkich narodów, pokoleń, języków, które są na całej ziemi: «***Obyście zaznawali pełni pokoju!***
###### **Dn 3,99**
 (32) ***Spodobało mi się oznajmić znaki i cuda, jakie Najwyższy Bóg dla mnie uczynił.***
###### **Dn 3,100**
 (33) ***Jak wielkie są Jego znaki, jak potężne Jego cuda!Jego królestwo jest wiecznym królestwem, a panowanie Jego z pokolenia na pokolenie.***
# Dn 3 PAU
###### **Dn 3,1**
 Król Nabuchodonozor kazał ulać posąg ze złota. Miał on sześćdziesiąt łokci wysokości i sześć łokci szerokości. Postawił go na równinie Dura w prowincji Babilonu.
###### **Dn 3,2**
 Król Nabuchodonozor rozesłał posłów, aby zwołali satrapów, przełożonych, gubernatorów, doradców, skarbników, sędziów, stróżów porządku i wszystkich wyższych urzędników tej prowincji. Mieli oni przybyć na poświęcenie postawionego przez niego posągu.
###### **Dn 3,3**
 Zeszli się więc satrapowie, przełożeni, gubernatorzy, doradcy, skarbnicy, sędziowie, stróże porządku i wszyscy wyżsi urzędnicy tej prowincji na poświęcenie posągu, który postawił król Nabuchodonozor. Kiedy stanęli przed posągiem, który postawił Nabuchodonozor,
###### **Dn 3,4**
 herold zawołał donośnym głosem: „Posłuchajcie, ludy, narody i języki!
###### **Dn 3,5**
 Gdy tylko usłyszycie głos rogu, fletu, cytry, harfy, lutni, dud i wszelkiego rodzaju instrumentów muzycznych, upadnijcie na twarz i oddajcie pokłon temu złotemu posągowi, który postawił król Nabuchodonozor.
###### **Dn 3,6**
 Kto nie upadnie na twarz i nie odda pokłonu, zostanie w tej samej godzinie wrzucony w sam środek rozpalonego pieca”.
###### **Dn 3,7**
 Członkowie wszystkich ludów, narodów i języków, w chwili, gdy usłyszeli instrumenty muzyczne, upadli na twarz i oddali pokłon złotemu posągowi, który postawił król Nabuchodonozor.
###### **Dn 3,8**
 W tym samym czasie przyszli jacyś Chaldejczycy, aby oskarżyć Żydów.
###### **Dn 3,9**
 Powiedzieli do króla Nabuchodonozora: „Królu, obyś żył wiecznie!
###### **Dn 3,10**
 Ty, królu, wydałeś rozkaz, aby każdy człowiek, który usłyszy głos rogu, fletu, cytry, harfy, lutni, dud i wszelkiego rodzaju instrumentów muzycznych, upadł na twarz i oddał pokłon złotemu posągowi.
###### **Dn 3,11**
 A kto nie upadnie na twarz i nie odda pokłonu, zostanie wrzucony w sam środek rozpalonego pieca.
###### **Dn 3,12**
 Są tu Judejczycy: Szadrak, Meszak i Abednego, którym powierzyłeś zarządzanie prowincją Babilonu. Oni, królu, nie słuchają twoich poleceń. Nie padają na twarz przed złotym posągiem, który postawiłeś, i nie oddają mu pokłonu”.
###### **Dn 3,13**
 Wtedy Nabuchodonozor w gniewie i złości kazał przyprowadzić Szadraka, Meszaka i Abednega. Gdy oni stanęli przed królem,
###### **Dn 3,14**
 Nabuchodonozor powiedział: „Czy to prawda, Szadraku, Meszaku i Abednego, że nie chcecie służyć moim bogom i oddawać pokłonu złotemu posągowi, który postawiłem?
###### **Dn 3,15**
 Czy teraz, gdy usłyszycie głos rogu, fletu, lutni, cytry, harfy, psalterium, dud i wszelkiego rodzaju instrumentów strunowych, jesteście gotowi upaść na twarz i oddać pokłon posągowi, który postawiłem? Jeżeli nie, zostaniecie wrzuceni w sam środek rozpalonego pieca. A który bóg zdoła wyrwać was z mojej ręki?”.
###### **Dn 3,16**
 Szadrak, Meszak i Abednego powiedzieli do króla Nabuchodonozora: „Nie musimy na to odpowiadać.
###### **Dn 3,17**
 Jeżeli nasz Bóg, któremu służymy, istnieje i może nas wyratować z rozpalonego pieca, wyratuje nas także z twojej ręki, królu.
###### **Dn 3,18**
 A nawet jeśli tego nie uczyni, to wiedz królu, że nie będziemy służyć twoim bogom i nie oddamy pokłonu złotemu posągowi, który postawiłeś”.
###### **Dn 3,19**
 Wtedy Nabuchodonozor bardzo się rozgniewał na Szadraka, Meszaka i Abednega i zmienił się wyraz jego twarzy. Kazał rozpalić piec siedem razy mocniej niż zwykle,
###### **Dn 3,20**
 a najsilniejszym ze swoich wojowników polecił związać Szadraka, Meszaka i Abednega i wrzucić w sam środek rozpalonego pieca.
###### **Dn 3,21**
 Wtedy związano ich i w pełnym stroju wrzucono w sam środek rozpalonego pieca.
###### **Dn 3,22**
 A że rozkaz króla był surowy i piec rozpalono ponad zwykłą miarę, ogień strawił ludzi, którzy wrzucali Szadraka, Meszaka i Abednega.
###### **Dn 3,23**
 A trzej młodzieńcy: Szadrak, Meszak i Abednego wpadli związani w sam środek rozpalonego pieca.
###### **Dn 3,24**
 Przechadzali się oni wśród płomieni, śpiewali hymny Bogu i błogosławili Pana.
###### **Dn 3,25**
 Azariasz wstał, otworzył swoje usta i tak się modlił ze środka płomieni:
###### **Dn 3,26**
 „Błogosławiony i godzien uwielbienia jesteś, Panie, Boże ojców naszych, Twoje imię jest godne chwały na wieki.
###### **Dn 3,27**
 Bo jesteś sprawiedliwy we wszystkim, co nam uczyniłeś, wszystkie dzieła rąk Twoich są prawdziwe, Twoje drogi - proste, a wszystkie Twoje sądy - słuszne.
###### **Dn 3,28**
 Osądziłeś nas sprawiedliwie we wszystkim, co sprowadziłeś na nas i na Jerozolimę, święte miasto naszych ojców. Słusznie i sprawiedliwie bowiem zesłałeś to wszystko na nas z powodu naszych grzechów.
###### **Dn 3,29**
 Zgrzeszyliśmy bowiem i postąpiliśmy źle, odchodząc od Ciebie, zawiniliśmy we wszystkim i nie słuchaliśmy Twoich poleceń.
###### **Dn 3,30**
 Nie strzegliśmy i nie wypełnialiśmy tego, co nam nakazałeś, aby się nam dobrze powodziło.
###### **Dn 3,31**
 Wszystko, co na nas sprowadziłeś, i wszystko, co nam wyrządziłeś, uczyniłeś sprawiedliwie.
###### **Dn 3,32**
 Wydałeś nas w ręce znienawidzonych wrogów, najgorszych odstępców, i w ręce niesprawiedliwego króla, najgorszego ze wszystkich na ziemi.
###### **Dn 3,33**
 Teraz lękamy się otworzyć usta, wstyd i hańba spadły na Twoje sługi i na tych, którzy się Ciebie boją.
###### **Dn 3,34**
 Przez wzgląd na Twoje imię nie opuszczaj nas na zawsze i nie zrywaj swojego przymierza.
###### **Dn 3,35**
 Nie odwracaj od nas swojego miłosierdzia przez wzgląd na Abrahama, Twojego przyjaciela, na Izaaka, Twojego sługę, i na Twojego świętego Izraela.
###### **Dn 3,36**
 Im to przyrzekłeś, że rozmnożysz ich potomstwo jak gwiazdy na niebie i jak ziarenka piasku na morskim brzegu.
###### **Dn 3,37**
 O, Władco, jesteśmy najmniejsi pośród wszystkich narodów i upokorzeni dzisiaj na całej ziemi z powodu naszych grzechów.
###### **Dn 3,38**
 Nie mamy teraz władcy, proroka ani wodza, całopaleń ani ofiar, ofiar pokarmowych i ofiar z kadzidła. Nie mamy gdzie ofiarować pierwocin i błagać o Twoje miłosierdzie.
###### **Dn 3,39**
 Niech jednak serce skruszone i duch uniżony zyskają Twoją życzliwość, jak całopalenia z baranów i cieląt, i z tysięcy dorodnych owiec!
###### **Dn 3,40**
 Taka niech będzie dzisiaj nasza ofiara przed Tobą, niech przez Ciebie będzie dopełniona, bo nie zawstydzą się ci, którzy Tobie ufają.
###### **Dn 3,41**
 Teraz całym sercem idziemy za Tobą. Odczuwamy lęk przed Tobą i szukamy Cię. Nie zawstydzaj nas,
###### **Dn 3,42**
 ale uczyń z nami według Twej łaskawości i według wielkiego Twego miłosierdzia.
###### **Dn 3,43**
 Wybaw nas przez swoje cuda, Panie, i przywróć chwałę swojemu imieniu.
###### **Dn 3,44**
 Niech doznają hańby wszyscy, którzy wyrządzają zło Twoim sługom! Niech okryją się wstydem za swe zamysły i panowanie, niech ich potęga zostanie skruszona!
###### **Dn 3,45**
 Niech się dowiedzą, że Ty jesteś Panem, Bogiem jedynym, godnym chwały na całym świecie”.
###### **Dn 3,46**
 Słudzy królewscy, którzy ich wrzucili do pieca, nie przestawali rozpalać go naftą, smołą, pakułami i chrustem.
###### **Dn 3,47**
 Płomień wznosił się czterdzieści dziewięć łokci ponad piec.
###### **Dn 3,48**
 Rozprzestrzeniając się, spalił Chaldejczyków, którzy podchodzili do pieca.
###### **Dn 3,49**
 Tymczasem anioł Pański zstąpił do pieca, w którym był Azariasz i jego przyjaciele, i odrzucił z pieca płomienie ognia.
###### **Dn 3,50**
 Sprowadził do środka pieca orzeźwiający wiatr, tak że ogień w ogóle ich nie dotykał i nie sprawiał im bólu ani nie wyrządzał krzywdy.
###### **Dn 3,51**
 Wtedy ci trzej, jakby jednym głosem, śpiewali hymny, wysławiali i błogosławili Boga:
###### **Dn 3,52**
 „Błogosławiony jesteś, Panie, Boże naszych ojców, uwielbiony i wywyższony na wieki. Błogosławione jest imię Twoje, pełne chwały i świętości, uwielbione i wywyższone na wieki.
###### **Dn 3,53**
 Błogosławiony jesteś w świątyni Twojej chwały, sławiony i pełen chwały na wieki.
###### **Dn 3,54**
 Błogosławiony jesteś, Ty, który spoglądasz w otchłanie i zasiadasz na cherubach, sławiony i wywyższony na wieki.
###### **Dn 3,55**
 Błogosławiony jesteś na tronie Twojego królestwa, uwielbiony i wywyższony na wieki.
###### **Dn 3,56**
 Błogosławiony jesteś na sklepieniu nieba, godzien sławy i chwały na wieki.
###### **Dn 3,57**
 Błogosławcie Pana, wszystkie Jego dzieła, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,58**
 Błogosławcie Pana, Jego aniołowie, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,59**
 Błogosławcie Pana, przestworza niebios, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,60**
 Błogosławcie Pana, wody w niebiosach, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,61**
 Błogosławcie Pana, wszystkie żywioły, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,62**
 Błogosławcie Pana, słońce i księżycu, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,63**
 Błogosławcie Pana, gwiazdy nieba, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,64**
 Błogosławcie Pana, deszczu i roso, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,65**
 Błogosławcie Pana, wszystkie wiatry, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,66**
 Błogosławcie Pana, ogniu i skwarze, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,67**
 Błogosławcie Pana, chłodzie i upale, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,68**
 Błogosławcie Pana, rosy i szrony, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,69**
 Błogosławcie Pana, mrozie i chłodzie, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,70**
 Błogosławcie Pana, lody i śniegi, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,71**
 Błogosławcie Pana, dnie i noce, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,72**
 Błogosławcie Pana, światło i ciemności, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,73**
 Błogosławcie Pana, błyskawice i chmury, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,74**
 Błogosław Pana, ziemio, chwal Go i wywyższaj na wieki.
###### **Dn 3,75**
 Błogosławcie Pana, góry i pagórki, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,76**
 Błogosławcie Pana, wszystkie rośliny na ziemi, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,77**
 Błogosławcie Pana, źródła, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,78**
 Błogosławcie Pana, morza i rzeki, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,79**
 Błogosławcie Pana, stworzenia wodne, wielkie i małe, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,80**
 Błogosławcie Pana, wszystkie ptaki, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,81**
 Błogosławcie Pana, wszystkie zwierzęta i trzody, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,82**
 Błogosławcie Pana, ludzie, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,83**
 Błogosławcie Pana, Izraelici, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,84**
 Błogosławcie Pana, kapłani Pańscy, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,85**
 Błogosławcie Pana, słudzy Pańscy, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,86**
 Błogosławcie Pana, duchy i dusze sprawiedliwych, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,87**
 Błogosławcie Pana, bogobojni i pokornego serca, sławcie Go i wywyższajcie na wieki.
###### **Dn 3,88**
 Błogosławcie Pana, Chananiaszu, Azariaszu i Miszaelu, sławcie Go i wywyższajcie na wieki, bo wyzwolił nas z krainy umarłych i wybawił z mocy śmierci, uwolnił nas z płonącego żarem pieca i ze środka ognia wyprowadził.
###### **Dn 3,89**
 Składajcie Panu dzięki, bo jest dobry, bo Jego łaskawość jest wieczna.
###### **Dn 3,90**
 Błogosławcie Boga nad bogami, wszyscy bojący się Pana, sławcie Go i składajcie dzięki, bo na wieki Jego zmiłowanie”.
###### **Dn 3,91**
 Wtedy król Nabuchodonozor przestraszył się, wstał szybko i zapytał swych doradców: „Czy tych trzech ludzi nie wrzucono związanych w sam środek ognia?”. Oni odpowiedzieli królowi: „Tak było, królu”.
###### **Dn 3,92**
 Król powiedział: „Widzę czterech ludzi, rozwiązanych, przechadzających się wśród płomieni. Nie ponieśli żadnej szkody! Czwarty wyglądem przypomina anioła”.
###### **Dn 3,93**
 Nabuchodonozor podszedł do otworu rozpalonego pieca i powiedział: „Szadraku, Meszaku i Abednego, słudzy Boga Najwyższego, wyjdźcie i zbliżcie się tutaj”. Szadrak, Meszak i Abednego wyszli więc z samego środka płomieni.
###### **Dn 3,94**
 Zebrani satrapowie, przełożeni, gubernatorzy i doradcy króla zobaczyli, że ogień nic nie uczynił ciałom tych trzech młodzieńców i że nawet jeden włos na ich głowach nie spłonął. Ich płaszcze nie zostały naruszone i nie unosił się od nich zapach spalenizny.
###### **Dn 3,95**
 Nabuchodonozor powiedział: „Błogosławiony Bóg Szadraka, Meszaka i Abednega! On posłał swojego anioła i uratował swoje sługi, którzy Mu ufali! Złamali rozkaz królewski, bo woleli wydać swoje ciała, niż upaść na twarz i oddawać cześć innemu bogu poza swoim.
###### **Dn 3,96**
 Dlatego wydaję taki rozkaz: Wszystkie ludy, narody i języki, które zbluźnią przeciwko Bogu Szadraka, Meszaka i Abednega, zostaną rozerwane na kawałki, a ich splądrowane domy legną w gruzach, ponieważ poza Nim nie ma żadnego innego boga, który potrafi ocalić”.
###### **Dn 3,97**
 Następnie król ustanowił Szadraka, Meszaka i Abednega przełożonymi w prowincji Babilonu.
###### **Dn 3,98**
 „Król Nabuchodonozor, do każdego ludu, narodu i języka, które są na całej ziemi: Pokój wasz niech będzie wielki!
###### **Dn 3,99**
 Chcę wam oznajmić znaki i cuda, które uczynił dla mnie Bóg Najwyższy.
###### **Dn 3,100**
 Jakże wielkie Jego znaki i jakże potężne Jego cuda! Jego królestwo - królestwem wiecznym, a Jego panowanie na wszystkie pokolenia.
# Dn 3 BP
###### **Dn 3,1**
 Król Nebukadnezar wykonał statuę ze złota. Miała ona sześćdziesiąt łokci wysokości i sześć łokci szerokości. Postawił ją na równinie Dura w prowincji babilońskiej.
###### **Dn 3,2**
 Król Nebukadnezar polecił zgromadzić satrapów, przełożonych, namiestników, radców, skarbników, prawników, sędziów i wszystkich zwierzchników prowincji, aby przyszli na poświęcenie statui, którą wzniósł król Nebukadnezar.
###### **Dn 3,3**
 Zgromadzili się tedy satrapowie, przełożeni, namiestnicy, radcy, skarbnicy, prawnicy, sędziowie i wszyscy zwierzchnicy prowincji na poświęcenie statui, którą wystawił król Nebukadnezar, i stanęli przed statuą, którą on wzniósł.
###### **Dn 3,4**
 Herold zawołał głośno: Rozkazuje się wam, ludy, narody i języki:
###### **Dn 3,5**
 Z chwilą, gdy usłyszycie głos rogu, piszczałki, cytry, sambuki, psalterionu, kobzy i wszelkiego rodzaju instrumentów muzycznych, macie paść [na twarz] i złożyć głęboki pokłon złotej statui, którą wystawił król Nebukadnezar.
###### **Dn 3,6**
 Kto nie padnie [na twarz] i nie złoży głębokiego pokłonu, zostanie natychmiast wrzucony do pieca ogniem gorejącego.
###### **Dn 3,7**
 Wobec tego, gdy posłyszały ludy głos rogu, piszczałki, cytry, sambuki, psalterionu i wszelkiego rodzaju instrumentów muzycznych, wszystkie ludy, narody i języki padły [na twarz] i oddały głęboki pokłon złotej statui, którą wystawił król Nebukadnezar.
###### **Dn 3,8**
 W tym czasie przystąpili mężowie chaldejscy i złośliwie oskarżyli Żydów.
###### **Dn 3,9**
 Zabierając głos, powiedzieli królowi Nebukadnezarowi: Królu, żyj na wieki!
###### **Dn 3,10**
 Ty, królu, wydałeś dekret, że każdy człowiek, który usłyszy głos rogu, piszczałki, cytry, sambuki, psalterionu, kobzy i wszelkiego rodzaju instrumentów muzycznych, jest obowiązany paść [na twarz] i złożyć głęboki pokłon złotej statui.
###### **Dn 3,11**
 Kto zaś nie padnie [na twarz] i nie złoży głębokiego pokłonu, będzie wrzucony do pieca ogniem gorejącego.
###### **Dn 3,12**
 [A oto] są mężowie żydowscy, których powołałeś do zarządzania prowincją Babilonu: Szadrak, Meszak i Abed Nego; ci mężowie nie usłuchali twojego dekretu, królu. Boga twojego nie uczcili i nie oddali głębokiego pokłonu złotej statui, którą wystawiłeś.
###### **Dn 3,13**
 Wówczas Nebukadnezar w gniewie i wściekłości kazał przyprowadzić Szadraka, Meszaka i Abed Nego. Przyprowadzono więc przed króla owych mężów.
###### **Dn 3,14**
 Nebukadnezar przemówił i spytał ich: Prawda to Szadraku, Meszaku i Abed Nego, że nie czcicie moich bogów i nie składacie głębokiego pokłonu złotej statui, którą postawiłem?
###### **Dn 3,15**
 Teraz więc czy jesteście gotowi, w czasie gdy usłyszycie głos rogu, piszczałki, cytry, sambuki, psalterionu, kobzy i wszelkiego rodzaju instrumentów muzycznych, paść [na twarz] i oddać głęboki pokłon statui, którą wykonałem? Jeśli nie złożycie głębokiego pokłonu, natychmiast będziecie wrzuceni w piec ogniem gorejący, a któryż jest bóg, który by mógł was wybawić z moich rąk?
###### **Dn 3,16**
 Szadrak, Meszak i Abed Nego odpowiedzieli, mówiąc królowi Nebukadnezarowi: Nie mamy potrzeby odpowiadać ci na to.
###### **Dn 3,17**
 Jeśli nasz Bóg, którego my czcimy, zechce nas wybawić, to wyrwie nas z pieca ogniem gorejącego i z rąk twoich, królu.
###### **Dn 3,18**
 Jeśli zaś nie, [mimo to] wiedz, królu, że nie będziemy czcić twoich bogów i nie oddamy głębokiego pokłonu złotej statui, którą wystawiłeś.
###### **Dn 3,19**
 Wtedy Nebukadnezar rozgniewał się. Zmienił się wyraz jego twarzy wobec Szadraka, Meszaka i Abed Nego. W odpowiedzi kazał rozpalić piec siedem razy mocniej, niż zwykle rozpalano.
###### **Dn 3,20**
 Najsilniejszym zaś mężom ze swego wojska polecił związać Szadraka, Meszaka i Abed Nego i wrzucić w piec ogniem gorejący.
###### **Dn 3,21**
 Związano więc owych mężów w ich płaszczach, tunikach, nakryciach [głowy] oraz szatach i wrzucono ich w piec ogniem gorejący.
###### **Dn 3,22**
 Dlatego że rozkaz króla był surowy, a piec był nadzwyczajnie rozpalony, mężów, którzy przyprowadzili Szadraka, Meszaka i Abed Nego, zabił płomień ognia.
###### **Dn 3,23**
 Owi trzej mężowie: Szadrak, Meszak i Abed Nego związani wpadli do pieca ogniem gorejącego.
###### **Dn 3,24**
 [Część deuterokanoniczna] I chodzili pośród płomienia chwaląc Boga i błogosławiąc Pana.
###### **Dn 3,25**
 Azariasz stojąc tak się modlił i otworzywszy swe usta mówił w środku ognia:
###### **Dn 3,26**
 Błogosławiony i godzien chwały jesteś, Panie, Boże ojców naszych, a Imię Twoje niech będzie wysławiane na wieki.
###### **Dn 3,27**
 Sprawiedliwy bowiem jesteś we wszystkim, co nam uczyniłeś. Wszystkie Twoje dzieła są prawdziwe i drogi Twoje prawe, a wszystkie Twoje wyroki są prawdą.
###### **Dn 3,28**
 Dokonałeś sądów [zgodnych z] prawdą, we wszystkim, co zesłałeś na nas i na miasto święte naszych ojców, Jeruzalem. Albowiem w prawdzie i w sądzie wymierzyłeś [nam] to wszystko z powodu naszych grzechów.
###### **Dn 3,29**
 Zgrzeszyliśmy bowiem i źle postąpiliśmy, odstępując od Ciebie. Całkiem zbłądziliśmy i nie słuchaliśmy przykazań Twojego Prawa.
###### **Dn 3,30**
 Nie strzegliśmy ani nie czyniliśmy, jak nam nakazałeś, ażeby nam było dobrze.
###### **Dn 3,31**
 Wszystkie [rzeczy], jakie na nas przywiodłeś, i wszystko to, coś nam uczynił, dokonałeś na podstawie rzetelnego sądu.
###### **Dn 3,32**
 Wydałeś nas w ręce okrutnych wrogów, obrzydliwych odstępców oraz króla niesprawiedliwego i najniegodziwszego na całej ziemi.
###### **Dn 3,33**
 Teraz więc nie mamy odwagi otworzyć ust. Wstyd i hańba stały się [udziałem] sług Twoich i tych, którzy się Ciebie boją.
###### **Dn 3,34**
 Przez wzgląd na Twoje Imię nie opuszczaj nas całkowicie; nie zrywaj Twojego Przymierza.
###### **Dn 3,35**
 Nie oddalaj od nas Twojego miłosierdzia ze względu na Abrahama, przez Ciebie umiłowanego, ze względu na Izaaka, Twojego sługę, i Izraela, Twojego świętego,
###### **Dn 3,36**
 którym przyrzekłeś, obiecując rozmnożyć ich nasienie jak gwiazdy na niebie, jak piasek, który jest na brzegu morza.
###### **Dn 3,37**
 Albowiem, Panie, staliśmy się mali w stosunku do wszystkich narodów i jesteśmy dzisiaj upokorzeni na całej ziemi z powodu naszych grzechów.
###### **Dn 3,38**
 Nie mamy obecnie księcia ni proroka, ni wodza, ani całopalenia, ani ofiary, ani obiaty, ani kadzidła, ni miejsca, aby ofiarować pierwociny przed Tobą i znaleźć miłosierdzie.
###### **Dn 3,39**
 Ale przez duszę skruszoną i ducha upokorzonego zostaniemy wysłuchani [tak], jak przez całopalenie baranów i cielców, podobnie jak przez dziesiątki tysięcy tłustych jagniąt.
###### **Dn 3,40**
 Taka niech będzie dzisiaj nasza ofiara przed Twoim obliczem. Niech Ci będzie przyjemna, aby nie byli zawstydzeni ci, którzy Tobie zaufali.
###### **Dn 3,41**
 Teraz więc całym sercem idziemy za Tobą i boimy się Ciebie. Szukamy Twojego oblicza. Nie zawstydzaj nas,
###### **Dn 3,42**
 ale postąp z nami według Twojej łaskawości i według obfitości twojego miłosierdzia.
###### **Dn 3,43**
 Wybaw nas według Twoich podziw budzących [czynów] i daj, Panie, chwałę Imieniu Twojemu.
###### **Dn 3,44**
 Niech będą zawstydzeni wszyscy, którzy wyrządzają krzywdę Twoim sługom. Niech będą pohańbieni, [pozbawieni] całej swojej siły i potęgi. Oby moc ich zniszczała.
###### **Dn 3,45**
 Niech poznają, że Ty jesteś Panem, jedynym Bogiem, sławnym po całej ziemi.
###### **Dn 3,46**
 Słudzy królewscy, którzy ich wrzucili, nie przestali rozpalać pieca naftą, smołą, pakułami i chrustem.
###### **Dn 3,47**
 I wzniósł się płomień ponad piec czterdzieści dziewięć łokci.
###### **Dn 3,48**
 Wybuchł i spalił tych Chaldejczyków, których znalazł w pobliżu pieca.
###### **Dn 3,49**
 Anioł zaś Pański zstąpił do pieca wraz z przyjaciółmi Azariasza i usunął płomień ognia z pieca.
###### **Dn 3,50**
 Wnętrze pieca uczynił jakby [miejscem, gdzie] wiał delikatny wietrzyk. Ogień nie dotknął ich w ogóle, nie wyrządził im szkody ani ich nie niepokoił.
###### **Dn 3,51**
 Ci zaś trzej, jakby jednymi ustami, sławili, wychwalali i błogosławili Boga w piecu mówiąc:
###### **Dn 3,52**
 Bądź błogosławiony, Panie, Boże ojców naszych, pochwalony i wywyższony na wieki. Niech będzie błogosławione święte Imię Twojej chwały, wychwalane i wywyższone na wieki.
###### **Dn 3,53**
 Bądź błogosławiony w Świątyni Twojej świętej chwały, wysławiony i uwielbiony na wieki.
###### **Dn 3,54**
 Bądź błogosławiony na tronie Twojego królestwa, wysławiony i wywyższony na wieki.
###### **Dn 3,55**
 Bądź błogosławiony, który patrzysz na otchłanie i siedzisz na cherubinach, pochwalony i wywyższony na wieki.
###### **Dn 3,56**
 Bądź błogosławiony na firmamencie nieba, sławiony i wielbiony na wieki.
###### **Dn 3,57**
 Błogosławcie Pana, wszystkie dzieła Pańskie, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,58**
 Błogosławcie Pana, aniołowie Pańscy, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,59**
 Błogosławcie Pana, niebiosa, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,60**
 Błogosławcie Pana, wszystkie wody nadniebne, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,61**
 Błogosławcie Pana, wszystkie moce, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,62**
 Błogosławcie Pana, słońce i księżycu, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,63**
 Błogosławcie Pana, gwiazdy niebieskie, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,64**
 Błogosławcie Pana, każdy deszczu i roso, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,65**
 Błogosławcie Pana, wszystkie wiatry, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,66**
 Błogosławcie Pana, ogniu i skwarze, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,67**
 Błogosławcie Pana, chłodzie i upale, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,68**
 Błogosławcie Pana, krople rosy i śnieżyce, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,69**
 Błogosławcie Pana, lodzie i mrozie, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,70**
 Błogosławcie Pana, szrony i śniegi, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,71**
 Błogosławcie Pana, noce i dnie, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,72**
 Błogosławcie Pana, światło i ciemności, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,73**
 Błogosławcie Pana, błyskawice i chmury, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,74**
 Niechaj ziemia błogosławi Pana, sławi i wywyższa Go na wieki.
###### **Dn 3,75**
 Błogosławcie Pana, góry i pagórki, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,76**
 Błogosławcie Pana, wszystkie rośliny ziemi, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,77**
 Źródła, błogosławcie Pana, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,78**
 Błogosławcie Pana, morza i rzeki, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,79**
 Błogosławcie Pana, potwory morskie i wszystko, co się rusza w wodach, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,80**
 Błogosławcie Pana, wszystkie ptaki niebieskie, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,81**
 Błogosławcie Pana, wszystkie zwierzęta i bydło, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,82**
 Błogosławcie Pana, synowie ludzi, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,83**
 Izraelici, błogosławcie Pana, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,84**
 Błogosławcie Pana, kapłani Pańscy, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,85**
 Błogosławcie Pana, słudzy Pańscy, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,86**
 Błogosławcie Pana, duchy i dusze sprawiedliwych, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,87**
 Błogosławcie Pana, święci i sercem pokorni, sławcie i wywyższajcie Go na wieki.
###### **Dn 3,88**
 Błogosławcie Pana, Ananiaszu, Azariaszu i Miszaelu, sławcie i wywyższajcie Go na wieki, bo wyrwał nas z otchłani i wybawił nas z ręki śmierci. Uwolnił nas spośród palącego płomienia i wyswobodził nas z ognia.
###### **Dn 3,89**
 Wykrzykujcie Panu, bo jest dobry, bo na wieki Jego miłosierdzie.
###### **Dn 3,90**
 Błogosławcie, wszyscy bojący się Pana, Boga bogów, sławcie i wyznawajcie, bo na wieki Jego miłosierdzie.
###### **Dn 3,91**
 Nabuchodonozor usłyszał ich śpiewających. [Koniec części deuterokanonicznej] 91(24) Zdumiał się król Nebukadnezar, wstał z pośpiechem i odzywając się do swych doradców, rzekł: Czyż nie trzech mężów związanych wrzuciliśmy do ognia? Odpowiadając powiedzieli królowi: Na pewno, królu!
###### **Dn 3,92**
 (25) Odzywając się rzekł: Oto widzę czterech mężów wolnych, chodzących pośród ognia i nie ponoszących szkody. Wygląd zaś czwartego podobny do syna bogów.
###### **Dn 3,93**
 (26) Wtedy przystąpił Nebukadnezar do drzwi pieca ogniem gorejącego, przemówił i zawołał: Szadraku, Meszaku, Abed Nego, słudzy Boga Najwyższego, wyjdźcie i przyjdźcie! Wówczas Szadrak, Meszak i Abed Nego wyszli z ognia.
###### **Dn 3,94**
 (27) I zebrali się satrapowie, przełożeni, namiestnicy i radcy królewscy, aby zobaczyć owych mężów, nad których ciałem ogień nie miał mocy. Włosy [na] ich głowach nie spaliły się, płaszcze się nie zmieniły i swąd ognia na nich nie przeszedł.
###### **Dn 3,95**
 (28) Zabierając głos, Nebukadnezar rzekł: Niech będzie błogosławiony Bóg Szadraka, Meszaka i Abed Nego, który posłał swojego anioła i ocalił swoje sługi, którzy Jemu zaufali i rozkaz królewski przekroczyli, ciała swoje wydali, żeby nie padać [na twarz] i nie składać głębokiego pokłonu żadnemu bogu, jak tylko ich Bogu.
###### **Dn 3,96**
 (29) Wydaję więc od siebie rozporządzenie, że każdy lud, naród i język, który wypowie coś uwłaczającego czci Boga Szadraka, Meszaka i Abed Nego, będzie poćwiartowany, a dom jego będzie zamieniony w stos gruzów. Albowiem nie ma innego Boga, który by tak potrafił ocalić.
###### **Dn 3,97**
 (30) Potem król sprawił, że Szadrakowi, Meszakowi i Abed Nego dobrze się powodziło w prowincji babilońskiej.
###### **Dn 3,98**
 (31) Król Nebukadnezar do wszystkich ludów, narodów i języków, które mieszkają na całej ziemi: Niech wasz pokój będzie wielki!
###### **Dn 3,99**
 (32) Uważałem za stosowne podać do wiadomości znaki i cuda, jakich Bóg Najwyższy dokonał względem mnie.
###### **Dn 3,100**
 (33) Jak wielkie są Jego znaki i jak potężne są Jego cuda! Jego królestwo jest królestwem wiecznym, a Jego panowanie trwa z pokolenia w pokolenie.
# Dn 3 BR
###### **Dn 3,1**
 Król Nabuchodonozor kazał wykonać posąg ze złota, wysoki na sześćdziesiąt łokci i szeroki na sześć łokci, i ustawić go na równinie Dura w prowincji babilońskiej.
###### **Dn 3,2**
 Wydał też król rozkaz, żeby się zgromadzili wszyscy satrapowie, namiestnicy, zarządcy, doradcy, skarbnicy, sędziowie, biegli w prawie i wszyscy przełożeni prowincji. Mieli oni uczestniczyć w uroczystym odsłonięciu posągu wzniesionego przez króla Nabuchodonozora.
###### **Dn 3,3**
 Kiedy więc zebrali się wszyscy satrapowie, namiestnicy, zarządcy, doradcy, skarbnicy, sędziowie, biegli w prawie i wszyscy przełożeni prowincji na uroczyste odsłonięcie posągu, wzniesionego przez króla Nabuchodonozora, i ustawili się już przed posągiem wzniesionym przez króla Nabuchodonozora,
###### **Dn 3,4**
 herold ogłosił: Rozkazuje się wam, wszystkie narody, ludy i języki:
###### **Dn 3,5**
 Gdy tylko usłyszycie głos rogu, fletu, lutni, harfy, psalterionu, dud i wszelkich innych instrumentów muzycznych, macie upaść na ziemię i oddać cześć posągowi ze złota, wzniesionemu przez króla Nabuchodonozora.
###### **Dn 3,6**
 Ci zaś, którzy nie upadną na ziemię i nie oddadzą czci posągowi, zostaną natychmiast wrzuceni do rozpalonego pieca.
###### **Dn 3,7**
 Tak więc, gdy tylko posłyszano głos rogu, fletu, lutni, harfy, psalterionu, dud i wszelkich innych instrumentów muzycznych, upadły na twarz wszelkie narody, ludy i języki, oddając cześć posągowi ze złota, wzniesionemu przez króla Nabuchodonozora.
###### **Dn 3,8**
 Tymczasem niektórzy Chaldejczycy przyszli i wnieśli skargę przeciwko Żydom,
###### **Dn 3,9**
 mówiąc tak do króla Nabuchodonozora: Królu, żyj wiecznie!
###### **Dn 3,10**
 Raczyłeś ogłosić, o królu, dekret, aby każdy na dźwięk rogu, fletu, lutni, harfy, psalterionu, dud i wszelkich innych instrumentów muzycznych, upadł na twarz i oddał cześć złotemu posągowi.
###### **Dn 3,11**
 Wszystkich zaś, którzy by nie chcieli upaść na twarz i oddać czci posągowi, dekret nakazywał wrzucić do rozpalonego pieca.
###### **Dn 3,12**
 Otóż są tu mężowie żydowscy, którym powierzyłeś sprawy całej prowincji babilońskiej. Są to Szadrak, Meszak i Abed-Nego. Mężowie ci nie słuchają twych rozkazów, o królu; nie służą twoim bogom i nie oddali czci wzniesionemu przez ciebie posągowi ze złota.
###### **Dn 3,13**
 Wtedy Nabuchodonozor, popadłszy w wielką złość, posłał natychmiast po Szadraka, Meszaka i Abed-Nego. I sprowadzono ich zaraz przed oblicze króla.
###### **Dn 3,14**
 Zapytał ich tedy Nabuchodonozor: Szadraku, Meszaku i Abed-Nego, czy to prawda, że nie chcecie służyć moim bogom i że nie oddaliście czci posągowi ze złota, który ja wzniosłem?
###### **Dn 3,15**
 Czy teraz jesteście gotowi - gdy tylko usłyszycie głos rogu, fletu, lutni, harfy, psalterionu, dud i wszelkich innych instrumentów muzycznych - upaść na ziemię i oddać cześć wzniesionemu przeze mnie posągowi? Jeżeli nie oddacie czci posągowi, zostaniecie natychmiast wrzuceni do rozpalonego pieca. I gdzie znajdziecie wtedy boga, który potrafiłby wyrwać was z rąk moich?
###### **Dn 3,16**
 Szadrak, Meszak i Abed-Nego tak odpowiedzieli królowi Nabuchodonozorowi: Nie musimy wcale odpowiadać na to, co nam mówisz, o królu.
###### **Dn 3,17**
 Jeżeli Bóg nasz, któremu służymy, zechce nas wyprowadzić z rozpalonego pieca i uwolnić z rąk twoich, to na pewno to uczyni.
###### **Dn 3,18**
 A jeśli nawet nie uczyni tego, to żebyś wiedział, o królu, że twojemu bogowi służyć nie będziemy ani też nie będziemy oddawać czci posągowi wzniesionemu przez ciebie.
###### **Dn 3,19**
 Słowa napełniły króla Nabuchodonozora wielkim gniewem. Patrząc na Szadraka, Meszaka i Abed-Nego, bardzo się zmienił na twarzy i kazał rozpalić piec płomieniem siedem razy większym niż zazwyczaj.
###### **Dn 3,20**
 Potem najsilniejszym spośród swoich wojowników rozkazał związać Szadraka, Meszaka i Abed-Nego i wrzucić ich do rozpalonego pieca.
###### **Dn 3,21**
 Wrzucono ich tedy do rozpalonego pieca, tak jak stali: w ubraniach, płaszczach, w obuwiu i w nakryciach na głowach.
###### **Dn 3,22**
 Ponieważ spieszono się z wykonaniem rozkazu królewskiego, a piec buchał ogromnymi płomieniami, zginęli od nich ludzie, którzy wrzucali do ognia Szadraka, Meszaka i Abed-Nego.
###### **Dn 3,23**
 Trzej młodzieńcy zaś, Szadrak, Meszak i Abed-Nego, związani wpadli do rozpalonego pieca.
###### **Dn 3,24**
 I chodzili pośród płomieni wielbiąc Boga i wysławiając Pana.
###### **Dn 3,25**
 Azariasz zaś powstawszy otworzył usta i tak modlił się, wołając ze środka płomieni:
###### **Dn 3,26**
 Błogosławiony jesteś, Panie, Boże ojców naszych, i pełen jesteś chwały, a imię Twoje wysławiane na wieki!
###### **Dn 3,27**
 Bo jesteś sprawiedliwy we wszystkim, co nam uczyniłeś. I pełne prawdy są wszystkie dzieła Twoje, drogi Twoje prawe a wyroki słuszne.
###### **Dn 3,28**
 Osądziłeś nas sprawiedliwie we wszystkim, co zesłałeś na nas i na Jerozolimę, święte miasto praojców. Bo uczyniłeś nam to wszystko z powodu naszych grzechów, w prawdzie i według sprawiedliwości.
###### **Dn 3,29**
 Grzeszyliśmy bowiem i popełniali nieprawości odchodząc od Ciebie daleko. Tak, grzeszyliśmy bardzo ciężko i nie słuchaliśmy nakazów twego Prawa.
###### **Dn 3,30**
 Nie przestrzegaliśmy Twego Prawa, nie wypełnialiśmy tego, co nam nakazywałeś, a Ty czyniłeś to wszystko dla dobra naszego.
###### **Dn 3,31**
 Wszystko więc, co na nas zesłałeś, wszystko, co nam uczyniłeś, uczyniłeś według sprawiedliwości.
###### **Dn 3,32**
 Wydałeś nas w ręce naszych wrogów, ludzi nie szanujących prawa i gorszych od bezbożników, pod władzę króla niegodziwego, najgorszego ze wszystkich, jacy są na ziemi.
###### **Dn 3,33**
 Teraz ust nie możemy otworzyć, wstydem i hańbą okryli się wszyscy, którzy Ci służą i cześć Ci oddają.
###### **Dn 3,34**
 Ach, nie opuszczaj nas na zawsze, przez wzgląd na Twoje Imię racz nie zrywać Przymierza Twego.
###### **Dn 3,35**
 Nie przestawaj nas darzyć miłosierdziem swoim, przez miłość do Abrahama, przyjaciela Twego, oraz Izaaka, Twojego sługi, a także Izraela, świętego Twojego,
###### **Dn 3,36**
 któremu przyrzekłeś potomstwo tak liczne, jak gwiazdy na niebie i jak piasek nad brzegiem morza.
###### **Dn 3,37**
 Jesteśmy najmniejsi, o Panie, wśród wszystkich narodów i poniżeni najbardziej ze wszystkich na ziemi, z powodu upadków naszych.
###### **Dn 3,38**
 Nie mamy teraz ni władzy, ni proroka, ni wodza, ani całopaleń, ani ofiar, ani darów z pokarmów, ni kadzideł woni, ani miejsca do składania pierwocin i dostrzegania oznak miłosierdzia Twego.
###### **Dn 3,39**
 Niech jednak serce skruszone i duch uniżony znajdą łaskawość u Ciebie. Jak całopalenia z baranów i cielców i jak tysiące tłustych owiec,
###### **Dn 3,40**
 taka niech będzie dziś nasza ofiara dla Ciebie. Racz także sprawić, byśmy szli wiernie za Tobą, bo nigdy nie będą zawstydzeni, którzy Tobie ufają.
###### **Dn 3,41**
 A teraz całym sercem trwać przy Tobie chcemy, żyć w Twojej bojaźni i zawsze szukać Ciebie.
###### **Dn 3,42**
 Racz nas nie pozostawiać w naszym pohańbieniu, lecz postąp z nami według Twej dobroci i według wielkiego miłosierdzia Twego.
###### **Dn 3,43**
 Zechciej nas wyzwolić Twym działaniem cudownym i spraw, aby Twoje Imię było uwielbione.
###### **Dn 3,44**
 Niech będą pohańbieni czyniący źle Twoim sługom, niech wszyscy się wstydem okryją! Niech będzie im wszelka moc odjęta, niech będzie ich potęga skruszona!
###### **Dn 3,45**
 Niech się dowiedzą, że tylko Ty jesteś Bogiem i Panem, pełnym chwały na całej ziemi.
###### **Dn 3,46**
 Słudzy królewscy, którzy ich wrzucili do rozpalonego pieca, nie przestawali dodawać do ognia nafty, smoły, pakuł i chrustu,
###### **Dn 3,47**
 tak iż płomienie wznosiły się czterdzieści dziewięć łokci ponad piec
###### **Dn 3,48**
 i obejmowały stopniowo wszystkich Chaldejczyków, znajdujących się wokół pieca.
###### **Dn 3,49**
 Anioł zaś Pański, zstąpiwszy do wnętrza pieca, tam gdzie znajdował się Azariasz z towarzyszami, odgarnął płomienie z pieca na zewnątrz.
###### **Dn 3,50**
 Swoim tchnieniem napełnił piec jakby orzeźwiającym powiewem wiatru, tak iż ogień nawet ich nie dotknął, nie sprawił im żadnego bólu ani nie wyrządził jakiejkolwiek krzywdy.
###### **Dn 3,51**
 Wtedy wszyscy trzej razem zaczęli w owym piecu śpiewać, chwaląc i wysławiając Boga takimi słowami:
###### **Dn 3,52**
 Błogosławiony jesteś, Panie i Boże ojców naszych, pełen chwały i uwielbienia na wieki! Błogosławione Twoje Imię chwalebne i święte, pełne chwały i uwielbienia na wieki!
###### **Dn 3,53**
 Błogosławiony jesteś w Przybytku Twojej świętej Chwały, wychwalany i uwielbiany ponad wszystko na wieki.
###### **Dn 3,54**
 Błogosławiony jesteś na Twym królewskim tronie, wychwalany i uwielbiany ponad wszystko na wieki.
###### **Dn 3,55**
 Błogosławiony jesteś Ty, który otchłanie przenikasz i na cherubach zasiadasz, pełen chwały jesteś i wywyższony na wieki!
###### **Dn 3,56**
 Błogosławiony jesteś na niebieskim sklepieniu, pełen chwały jesteś i wywyższony na wieki!
###### **Dn 3,57**
 Błogosławcie Pana, wszystkie dzieła Pańskie, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,58**
 Błogosławcie Pana, wszyscy aniołowie Pańscy, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,59**
 I wy, niebiosa, błogosławcie Pana, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,60**
 Wszystkie wody podniebne, błogosławcie Pana, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,61**
 Błogosławcie Pana, wszystkie moce Pańskie, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,62**
 Błogosławcie Pana, słońce i księżycu, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,63**
 Błogosławcie Pana, wszystkie gwiazdy nieba, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,64**
 Błogosławcie Pana, deszcze i rosy, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,65**
 Błogosławcie Pana, wszystkie wichry, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,66**
 Błogosławcie Pana wy, ogniu i żarze, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,67**
 Błogosławcie Pana, chłodzie i upale, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,68**
 Błogosławcie Pana, rosy i szrony, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,69**
 Błogosławcie Pana, mrozy i zimna, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,70**
 Błogosławcie Pana, lody i śniegi, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,71**
 Błogosławcie Pana, wszystkie dnie i noce, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,72**
 Błogosławcie Pana, światłość i mroki, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,73**
 Błogosławcie Pana, błyskawice i chmury, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,74**
 Błogosławcie Pana, cała ziemio, chwal Go i błogosław na wieki!
###### **Dn 3,75**
 Błogosławcie Pana, góry i wzniesienia, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,76**
 Błogosławcie Pana, wszystkie rośliny ziemi, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,77**
 Błogosławcie Pana, wszystkie źródła, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,78**
 Błogosławcie Pana, morza i rzeki, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,79**
 Błogosławcie Pana, wieloryby i wszystko, co porusza się w wodzie, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,80**
 Błogosławcie Pana, wszystkie ptaki powietrzne, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,81**
 Błogosławcie Pana, zwierzęta dzikie i domowe, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,82**
 Błogosławcie Pana, synowie ludzcy, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,83**
 Błogosław Pana, Izraelu cały, chwal Go i wysławiaj na wieki!
###### **Dn 3,84**
 Błogosławcie Pana, wszyscy kapłani, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,85**
 Błogosławcie Pana, wszyscy słudzy Jego, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,86**
 Błogosławcie Pana, duchy i dusze sprawiedliwych, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,87**
 Błogosławcie Pana, święci i serca pokornego, chwalcie Go i wysławiajcie na wieki!
###### **Dn 3,88**
 Błogosławcie Pana, Chananiaszu, Azariaszu i Miszaelu, chwalcie Go i wysławiajcie na wieki! On to bowiem uwolnił nas z otchłani, i wydobył spod władzy śmierci. Wyprowadził nas z płomieni pieca rozpalonego, wywiódł nas z samego środka płomieni.
###### **Dn 3,89**
 Wysławiajcie Pana, bo jest dobry, bo na wieki miłosierdzie Jego!
###### **Dn 3,90**
 Błogosławcie Boga wszystkich bogów wy, którzy Go czcicie, chwalcie Go i dzięki Mu składajcie, bo na wieki miłosierdzie Jego.
###### **Dn 3,91**
 (24) Wtedy Nabuchodonozor zdumiał się bardzo, powstał szybko z miejsca i zapytał swoich doradców: Czyż nie związanych wrzuciliśmy tych trzech młodzieńców do ognia? A oni odpowiedzieli: Z całą pewnością tak, królu!
###### **Dn 3,92**
 (25) Rzekł król na to: Otóż, wszyscy czterej młodzieńcy są uwolnieni z więzów, przechadzają się wśród płomieni ognistych i nic im to nie szkodzi, jeden zaś z nich wygląda jakby był synem bogów.
###### **Dn 3,93**
 (26) I zbliżył się Nabuchodonozor do otworu pieca ognistego i zawołał: Szadraku, Meszaku i Abed-Nego, słudzy Boga Najwyższego! Wyjdźcie i zbliżcie się tu! Szadrak, Meszak i Abed-Nego wyszli tedy spośród płomieni ognistych.
###### **Dn 3,94**
 (27) Zebrali się też satrapowie, namiestnicy, zarządcy i doradcy króla, żeby zobaczyć młodzieńców. Okazało się, że ogień nie tknął ich ciał, nie były też spalone ich włosy na głowie, nie uległo zniszczeniu ich odzienie, nie przeszli wonią spalenizny.
###### **Dn 3,95**
 (28) Zawołał tedy Nabuchodonozor: Błogosławiony jesteś, Boże Szadraka, Meszaka i Abed-Nego, za to, że posłałeś swego anioła i ocaliłeś swoje sługi, którzy Tobie całkowicie ufając nie posłuchali rozkazu króla. Woleli raczej ciała swoje skazać na zagładę niż służyć i oddawać cześć innemu bogu poza Tobą.
###### **Dn 3,96**
 (29) Rozkazuję tedy, aby bez względu na narodowość, przynależność do pokolenia i języka, każdy, kto by się ośmielił znieważyć Boga Szadraka, Meszaka i Abed-Nego, został zabity, a dom jego został zrównany z ziemią. Nie ma bowiem żadnego innego boga, który by tak jak Ten mógł pospieszyć na ratunek.
###### **Dn 3,97**
 (30) Potem obdarzył król Szadraka, Meszaka i Abed-Nego wysokimi godnościami w prowincji babilońskiej.
###### **Dn 3,98**
 (31) Król Nabuchodonozor - do wszystkich narodów, pokoleń i języków na całej ziemi, życząc wszystkim pełnego pokoju:
###### **Dn 3,99**
 (32) Uznałem za właściwe opowiedzieć wam o znakach i cudach, jakie uczynił dla mnie Bóg Najwyższy.
###### **Dn 3,100**
 (33) O, jak wielkie są Jego znaki, jak niezwykłe są Jego cuda! Królestwo Jego jest królestwem wiecznym, a Jego panowanie jest nad wszystkimi pokoleniami.
# Dn 3 WUJ
###### **Dn 3,1**
 Nabuchodonozor król uczynił bałwan złoty, na wzwyż sześćdziesiąt łokiet, a na szerzą sześć łokiet, i postawił ji na polu Dura krainy Babilońskiej:
###### **Dn 3,2**
 A tak król Nabuchodonozor posłał aby zebrano przednie pany, urzędniki, i sędzie, książęta, i tyrany, i starosty, i wszystkie przełożone krain, aby się zeszli na poświącanie bałwana, który był wystawił król Nabuchodonozor.
###### **Dn 3,3**
 Tedy się zgromadzili przedni panowie, urzędnicy, i sędziowie, książęta, i tyrani, i przedni ludzie, którzy byli na władzach postanowieni, i wszyscy przedniejszy z krain, aby się zeszli na poświęcenie bałwana, który był podniósł król Nabuchodonozor, i stali przed bałwanem, który był postawił król Nabuchodonozor.
###### **Dn 3,4**
 A woźny wołał duże: Wam mówią ludom, narodom, i językom:
###### **Dn 3,5**
 W godzinę, której usłyszycie głos trąby, i piszczałki, i cytry, fletnie, i harfy, i symphonała, i wszelakiej muzyki, padłszy pokłońcie się bałwanowi złotemu, który postawił król Nabuchodonozor.
###### **Dn 3,6**
 A ktoby upadłszy nie pokłonił się, ten tejże godziny będzie wrzucon w piec ognia pałającego.
###### **Dn 3,7**
 Potem tedy skoro usłyszeli wszyscy narodowie głos trąby, piszczałki, i cytry, fletni, i harfy, i symphonału i wszelakiej muzyki: upadłszy wszyscy narodowie, pokolenia, i języki, kłaniali się bałwanowi złotemu, który postawił król Nabuchodonozor.
###### **Dn 3,8**
 A wnet tegoż czasu przystąpiwszy mężowie Chaldejscy oskarżyli Żydy:
###### **Dn 3,9**
 I rzekli Nabuchodonozorowi królowi: Królu żyj na wieki:
###### **Dn 3,10**
 Ty królu dałeś wyrok, aby każdy człowiek, któryby usłyszał głos trąby, piszczałki, i cytry, fletni, i harfy, i symphonału, i wszelakiej muzyki, aby upadł i pokłonił się obrazowi złotemu:
###### **Dn 3,11**
 A ktoby upadłszy nie pokłonił się, żeby był wrzucon w piec ognia gorejącego.
###### **Dn 3,12**
 Są tedy mężowie Żydowie, któreś postanowił nad sprawami krain Babilońskich, Sydrach, Misach, i Abdenago: ci mężowie wzgardzili, królu, wyrokiem twoim: bogom twym nie służą: i bałwanowi złotemu, któryś podniósł nie kłaniają się.
###### **Dn 3,13**
 Tedy Nabuchodonozor w zapalczywości i gniewie rozkazał, aby byli przywiedzeni Sydrach, Misach, i Abdenago: które wnet przywiedziono przed oblicze króla.
###### **Dn 3,14**
 I mówiąc Nabuchodonozor król, rzekł im: Poprawdzieli Sydrach, Misach, i Abdenago, bogom moim nie służycie, i bałwanowi złotemu, którym postanowił nie kłaniacie się?
###### **Dn 3,15**
 Przeto teraz, jeśliście gotowi, którejkolwiej godziny usłyszycie trąby, piszczałki, cytry, fletni, i harfy, i symphonału, i wszelakiej muzyki, padnijcie i pokłońcie się bałwanowi, którym uczynił: a jeśli się nie pokłonicie, tejże godziny będziecie wrzuceni w piec ognia gorejącego: a któryż jest Bóg, który was wyrwie z ręki mojej?
###### **Dn 3,16**
 Odpowiadając Sydrach, Misach, i Abdenago, rzekli królowi Nabuchodonozorowi: Nie trzeba nam o tej rzeczy odpowiadać tobie.
###### **Dn 3,17**
 Bo oto Bóg nasz, któremu służymy, może nas wyrwać z pieca ognia pałającego, i z ręku twoich, o królu, wybawić.
###### **Dn 3,18**
 A jeśliby nie chciał, niech będzie wiadomo tobie królu, że bogom twoim nie służymy, i bałwanowi złotemu, któryś wystawił, nie kłaniamy się.
###### **Dn 3,19**
 Tedy Nabuchodonozor napełniony jest zapalczywością: i pojrzenie twarzy jego odmieniło się na Sydrach, Misach, i Abdenago: i rozkazał, żeby rozpalono piec siedmkroć więcej niźli był zwyczaj palić.
###### **Dn 3,20**
 A mężom co mocniejszym z wojska swego rozkazał, aby związawszy nogi Sydrach, Misach, i Abdenago, wrzucili je w piec ognia gorejącego.
###### **Dn 3,21**
 I natychmiast oni mężowie związani, z ubraniami swemi, i z czapkami, i butami, i szatami, wrzuceni są w pośród pieca ognia pałającego.
###### **Dn 3,22**
 Bo rozkazanie królewskie przynaglało: a piec był barzo rozpalony. Lecz męże one, którzy byli wrzucili Sydrach, Misach, i Abdenago, pobił płomień ogniowy.
###### **Dn 3,23**
 A ci trzej mężowie, to jest, Sydrach, Misach, i Abdenago wpadli w pośród pieca ognia pałającego związani.
###### **Dn 3,24**
 Tedy król Nabuchodonozor zdumiał się, i wstał prędko, i rzekł panom swoim: Izaliśmy nie trzech mężów wrzucili w pośród ognia spętanych? którzy odpowiadając królowi, rzekli: Prawdziwie królu.
###### **Dn 3,25**
 Odpowiedział, i rzekł: Oto ja widzę czterech mężów rozwiązanych i chodzących w pośrodku ognia, a żadnego naruszenia niemasz w nich: a osoba czwartego podobna synowi Bożemu.
###### **Dn 3,26**
 Tedy przystąpił Nabuchodonozor do drzwi pieca ognia pałającego, i rzekł: Sydrachu, Misachu, i Abdenagu, słudzy Boga wysokiego, wynidźcie a przydźcie. I natychmiast wyszli Sydrach, Misach, i Abdenago z pośrodku ognia.
###### **Dn 3,27**
 A zgromadziwszy się książęta, urzędnicy, i sędziowie, i możni królewscy, oględowali męże one, iż żadnej mocy nie miał ogień nad ciały ich, i włos głowy ich nie przypalił się, i szarawary ich nie odmieniły się, ani zapach ognia nie przeszedł przez nie.
###### **Dn 3,28**
 Tedy krzyknąwszy Nabuchodonozor, rzekł: Błogosławiony Bóg ich, to jest, Sydracha, Misacha, i Abdenaga, który posłał anioła swego, a wybawił sługi swe, którzy weń wierzyli, a słowo królewskie odmienili: i wydali ciała swe, aby nie służyli ani się kłaniali żadnemu Bogu, wyjąwszy Bogu swemu.
###### **Dn 3,29**
 Przetoż odemnie wydan jest ten wyrok, aby wszelki naród, pokolenie, i język, którybykolwiek mówił bluźnierstwo przeciw Bogu Sydracha, Misacha, i Abdenaga, zginął, a dom jego aby był zburzony: bo niemasz innego Boga, któryby tak mógł wybawiać.
###### **Dn 3,30**
 Tedy król podwyższył Sydracha, Misacha, i Abdenaga, w krainie Babilońskiej.
