# 2Mch 9 BT5
###### **2Mch 9,1**
 W tym czasie Antioch wracał niesławnie z miast położonych w Persji.
###### **2Mch 9,2**
 Wszedł bowiem do miasta zwanego Persepolis i miał zamiar zrabować świątynię i opanować miasto. Z tego powodu wybuchło wśród tłumów powstanie i pochwycono za broń. Antioch został przez mieszkańców tego kraju zmuszony do ucieczki i do niesławnego wycofania się.
###### **2Mch 9,3**
 Kiedy był koło Ekbatany, dowiedział się o tym, co spotkało Nikanora i żołnierzy Tymoteusza.
###### **2Mch 9,4**
 Zapłonął więc gniewem i zamierzał na Żydach pomścić zło, jakie cierpiał ze strony tych, którzy go zmusili do ucieczki. Dlatego polecił woźnicy, aby jechał bez wytchnienia i przyśpieszył koniec podroży. Jednakże sąd Nieba był już nad nim. W swoim gniewie bowiem tak się wyraził: «***Jerozolimę, skoro tylko tam się znajdę, uczynię zbiorowym grobem Żydów***».
###### **2Mch 9,5**
 Ale wszystkowidzący Pan, Bóg Izraela, dotknął go nieuleczalnym i niewidocznym cierpieniem. Zaledwie bowiem wypowiedział te słowa, pochwycił go nieznośny ból wnętrzności i straszne męki wewnątrz ciała.
###### **2Mch 9,6**
 Było to całkowicie sprawiedliwe, gdyż on wielu różnorodnymi katuszami zadawał męki wnętrznościom innych ludzi.
###### **2Mch 9,7**
 On tymczasem nie ustępował w swej nieokiełznanej pysze. W dalszym ciągu pełen zarozumiałości, dysząc ogniem gniewu na Żydów, rozkazał jeszcze przyśpieszyć podroż. Wtedy to nagle wypadł z wozu pędzącego z turkotem, a upadek jego był tak nieszczęśliwy, że doznał porażenia wszystkich części ciała.
###### **2Mch 9,8**
 I ten, który niedawno w swojej nadludzkiej pysze był przekonany, że może rozkazywać falom morskim, i wyobrażał sobie, iż na wagę może rzucić szczyty gór, znalazł się na ziemi, skąd zabrano go do lektyki, co było wyraźnym dla wszystkich przykładem mocy Bożej.
###### **2Mch 9,9**
 Doszło do tego, że z ciała bezbożnika wydobywały się robaki, a ciało jego za życia w boleściach i mękach odpadało kawałkami, na skutek zaś woni zgnilizny, jaka się od niego rozchodziła, całe wojsko cierpiało na mdłości.
###### **2Mch 9,10**
 Tego, któremu krótko przedtem wydawało się, że dotyka gwiazd na niebie, nikt nie mógł znieść, tak nieznośnie silny był zaduch.
###### **2Mch 9,11**
 Odtąd jednak, złamany, zaczął pozbywać się swojej wielkiej pychy i dochodzić do zrozumienia, że pod biczem Bożym w każdej chwili doznaje cierpień.
###### **2Mch 9,12**
 Kiedy zaś nawet on sam nie mógł znieść własnej woni, powiedział te słowa: «***Słuszną jest rzeczą poddanie się Bogu, a kto jest śmiertelny, nie powinien się uważać za równego Bogu***».
###### **2Mch 9,13**
 Modlił się też nikczemnik do Władcy, który już nad nim nie miał się zlitować, mówiąc,
###### **2Mch 9,14**
 że Miasto Święte, do którego śpieszył, aby je zrównać z ziemią i uczynić zbiorowym grobem, uzna za wolne,
###### **2Mch 9,15**
 a wszystkich Żydów, o których sądził, iż nie są warci tego, aby ich w grobie pochowano, ale że będą żerem dla ptaków razem ze swoimi dziećmi albo będą rzuceni dzikim zwierzętom, zrówna [w prawach] z Ateńczykami;
###### **2Mch 9,16**
 święty przybytek, który poprzednio ograbił, przyozdobi najpiękniejszymi darami, wszystkie różnorodne święte naczynia zwróci, a wydatki potrzebne na ofiary pokryje z własnych dochodów,
###### **2Mch 9,17**
 do tego jeszcze zostanie Żydem i obejdzie wszystkie miejsca zamieszkałe, aby rozgłaszać moc Bożą.
###### **2Mch 9,18**
 Boleści nic nie ustępowały, bo przyszedł na niego sprawiedliwy sąd Boży. Widząc, że jest w beznadziejnym stanie, napisał do Żydów list, który niżej jest załączony, a który ma cechy pokornej prośby, następującej treści:
###### **2Mch 9,19**
 «***Król i wódz Antioch Żydom, szlachetnym obywatelom – wiele pozdrowień i życzeń zdrowia i powodzenia.***
###### **2Mch 9,20**
 ***Jeżeli zdrowi jesteście razem z waszymi dziećmi, jeżeli ponadto sprawy układają się wam zgodnie z życzeniem, ja, pokładając ufność w Niebie,***
###### **2Mch 9,21**
 ***wspominam przyjaźnie waszą cześć i życzliwość. Powracając z miejscowości położonych wrsji, zapadłem na niebezpieczną chorobę. Uważam jednak za konieczne czuwać nad wspólnym dobrem wszystkich.***
###### **2Mch 9,22**
 ***Nie rozpaczam nad moim stanem, przeciwnie – mocną mam nadzieję, że wyjdę z choroby.***
###### **2Mch 9,23**
 ***Baczę jednak na to, że nawet ojciec w tym czasie kiedy wyruszył z wojskiem do górnej krainy, wyznaczył swojego następcę.***
###### **2Mch 9,24**
 ***Jeżeliby bowiem zaszło coś niespodziewanego albo opowiadano coś fałszywego, mieszkańcy prowincji powinni wiedzieć, komu jest pozostawione kierowanie sprawami, i nie powinni się niepokoić.***
###### **2Mch 9,25**
 ***Ponadto, mając na uwadze, że władcy pobliscy i sąsiadujący z królestwem szukają chwili stosownej i czekają, co nastąpi, ustanowiłem królem mego syna, Antiocha. Często wyruszając do górnych satrapii, powierzałem go i polecałem już bardzo wielu z was. Piszę zaś do niego to, co jest załączone.***
###### **2Mch 9,26**
 ***Upominam więc was i proszę, abyście pamiętali o tych dobrodziejstwach, które otrzymaliście razem ze wszystkimi oraz sami osobiście, i aby każdy tę przychylność, jaką obecnie ma wobec mnie, zachował także wobec mojego syna.***
###### **2Mch 9,27**
 ***Jestem bowiem przekonany, że on łagodnie i po ludzku będzie postępował według moich zasad i będzie z wami w dobrych stosunkach***».
###### **2Mch 9,28**
 Ten więc zabójca i bluźnierca, cierpiąc największe boleści, tak jak to dla innych postanowił, na obcej ziemi, w górach, w nędzny sposób zakończył życie.
###### **2Mch 9,29**
 Ciało jego zabrał Filip, jego serdeczny przyjaciel, który jednak w obawie przed synem Antiocha udał się do Ptolemeusza Filometora do Egiptu.
# 2Mch 9 PAU
###### **2Mch 9,1**
 W tym czasie Antioch okryty hańbą wracał z ziemi perskiej.
###### **2Mch 9,2**
 Wszedł bowiem do miasta zwanego Persepolis i próbował splądrować świątynię oraz zająć miasto. Wtedy wzburzone tłumy mieszkańców sięgnęły po broń i sprawiły, że Antioch musiał odejść ze wstydem.
###### **2Mch 9,3**
 Gdy znalazł się w pobliżu Ekbatany, dotarła do niego wiadomość o tym, co spotkało Nikanora i ludzi Tymoteusza.
###### **2Mch 9,4**
 Wpadł więc w złość i postanowił wylać swój gniew na Żydów także za upokorzenie, jakiego doświadczył, kiedy został zmuszony do ucieczki. Dlatego rozkazał woźnicy pędzić bez ustanku. Gdy on pokonywał drogę, wyrok z nieba już mu towarzyszył. Powiedział bowiem zuchwale: „Gdy dotrę do Jerozolimy, uczynię ją cmentarzem Żydów”.
###### **2Mch 9,5**
 Wszechwidzący PAN, Bóg Izraela, dotknął go więc nieuleczalną i niewidzialną chorobą. Skoro tylko wypowiedział to zdanie, chwycił go straszny ból wnętrzności i ostre boleści brzucha.
###### **2Mch 9,6**
 I było to sprawiedliwe, ponieważ dręczył on wnętrzności innych licznymi i wyszukanymi torturami.
###### **2Mch 9,7**
 Wcale jednak nie wyzbył się swojej bezczelności. Co więcej, pełen wyniosłości, dysząc zapalczywym gniewem przeciwko Żydom, nakazał jechać jeszcze szybciej. I wtedy wypadł z rydwanu pędzącego z impetem, a podczas upadku okrutnie się potłukł na całym ciele.
###### **2Mch 9,8**
 Ten, który dotąd uważał w swojej nadludzkiej zarozumiałości, że może rozkazywać falom morskim i ważyć na wadze szczyty gór, został powalony na ziemię. Niesiony w lektyce jasno ukazywał wszystkim Bożą potęgę.
###### **2Mch 9,9**
 Z ciała tego bezbożnika wychodziły robaki i wśród cierpień i boleści rozpadało się ono jeszcze za jego życia. Odór gnijącego ciała był nie do zniesienia dla wojska.
###### **2Mch 9,10**
 Jeszcze niedawno wydawało mu się, że może dotknąć gwiazd na niebie, a teraz nikt nie mógł go eskortować z powodu nieznośnie przykrego odoru.
###### **2Mch 9,11**
 Wówczas zaczął wyzbywać się ogromu swej pychy, ponieważ dochodził do przekonania, że nasilające się z każdą chwilą boleści są biczem Bożym.
###### **2Mch 9,12**
 Kiedy nawet on nie mógł znieść własnego odoru, powiedział: „Skoro jest się śmiertelnym, trzeba podporządkować się Bogu, a nie sądzić, że jest się Mu równym”.
###### **2Mch 9,13**
 Następnie modlił się ten zbrodniarz do Władcy, który nie miał okazać mu miłosierdzia. Obiecywał,
###### **2Mch 9,14**
 że ogłosi wolnym święte miasto, do którego zdążał pospiesznie, żeby zetrzeć je w proch i uczynić zbiorową mogiłą;
###### **2Mch 9,15**
 że zrówna z Ateńczykami wszystkich Żydów, których uważał za niegodnych nawet grobu, ale chciał rzucić ich razem z dziećmi na żer drapieżnym ptakom i dzikim zwierzętom;
###### **2Mch 9,16**
 że świątynię, którą uprzednio złupił, przyozdobi najpiękniejszymi darami; że odda z naddatkiem wszystkie święte naczynia, a koszty związane z ofiarami pokryje z własnych dochodów;
###### **2Mch 9,17**
 co więcej, że stanie się Żydem i obejdzie wszystkie zamieszkałe miejsca, aby ogłaszać potęgę Boga.
###### **2Mch 9,18**
 Skoro jednak jego cierpienia wcale nie ustawały, ponieważ przyszedł na niego sprawiedliwy sąd Boży, stracił wszelką nadzieję. Napisał wtedy do Żydów list, podpisując się pod prośbą o następującej treści:
###### **2Mch 9,19**
 „Król i wódz Antioch do szlachetnych obywateli Żydów. Pozdrowienia i życzenia zdrowia i wszelkiej pomyślności!
###### **2Mch 9,20**
 Pokładam nadzieję w Niebie, że wy i wasze dzieci jesteście zdrowi, a wasze sprawy układają się zgodnie z waszymi pragnieniami.
###### **2Mch 9,21**
 Przyjaźnie wspominam waszą cześć i życzliwość. Wracając z ziemi perskiej, zapadłem na ciężką chorobę. Uważam więc za konieczne pomyśleć o tym, jak zapewnić wszystkim wspólne bezpieczeństwo.
###### **2Mch 9,22**
 Nie tracę ufności co do siebie, lecz mam mocną nadzieję, że wyjdę z tej choroby.
###### **2Mch 9,23**
 Pamiętam jednak, że ilekroć mój ojciec wyruszał w górskie regiony, wyznaczał swego następcę,
###### **2Mch 9,24**
 aby mieszkańcy kraju nie niepokoili się, gdyby wydarzyło się coś nieoczekiwanego albo zaistniało jakieś niebezpieczeństwo, lecz wiedzieli, komu zostały pozostawione rządy.
###### **2Mch 9,25**
 Ponadto wiem, że okoliczni władcy i sąsiedzi królestwa czyhają na okazję, śledząc bieg wydarzeń. Dlatego ustanowiłem królem mojego syna Antiocha, którego już wcześniej przedstawiałem większości z was i którego zostawiałem, kiedy wyruszałem do górskich prowincji. Jemu również napisałem to, co piszę do was.
###### **2Mch 9,26**
 Proszę więc was i zaklinam, abyście zachowali należną życzliwość dla mnie oraz dla mojego syna, pamiętając o dobrodziejstwach, które wyświadczyłem waszej społeczności i każdemu z osobna.
###### **2Mch 9,27**
 Jestem bowiem przekonany, że on, wykonując moją wolę, będzie się do was odnosił łagodnie i życzliwie”.
###### **2Mch 9,28**
 Ten zabójca i bluźnierca zakończył życie w sposób godny pożałowania - w obcej, górskiej krainie, znosząc najgorsze cierpienia, takie jakie sam zadawał innym.
###### **2Mch 9,29**
 Jego zwłoki zabrał Filip, przyjaciel z dzieciństwa, który bojąc się syna Antiocha, udał się potem do Ptolemeusza Filometora do Egiptu.
# 2Mch 9 BP
###### **2Mch 9,1**
 W tym czasie zmuszony został Antioch do haniebnego odwrotu z ziemi perskiej.
###### **2Mch 9,2**
 Wtargnął bowiem do miasta zwanego Persepolis z zamiarem zajęcia go i splądrowania świątyni. Wzburzone tym tłumy chwyciły za oręż, aby się bronić. Doszło do tego, że Antioch został wyparty przez mieszkańców i zmuszony do sromotnego odwrotu.
###### **2Mch 9,3**
 Będąc w pobliżu Ekbatany otrzymał wiadomość o losie Nikanora i wojska Tymoteusza.
###### **2Mch 9,4**
 Uniesiony gniewem poprzysiągł pomścić na Żydach zniewagę, jaką wyrządzili mu ci, którzy go zmusili do ucieczki. Dlatego rozkazał woźnicy, by pędził bez wypoczynku, ażeby [jak najszybciej] zakończyć podróż. Tymczasem zawisł już nad nim sąd z Nieba; on jednak pełen pychy odezwał się tak: Skoro tylko stanę w Jerozolimie, uczynię z niej cmentarzysko Żydów.
###### **2Mch 9,5**
 A oto wszystkowidzący Pan, Bóg Izraela, dotknął go nieuleczalną i niewidoczną chorobą. Zaledwie bowiem wymówił te słowa, chwycił go nieznośny ból wnętrzności i straszne boleści wewnętrzne.
###### **2Mch 9,6**
 Co było zupełnie sprawiedliwe, ponieważ i on ciała innych ludzi poddawał wielu wymyślnym torturom.
###### **2Mch 9,7**
 Mimo to nie pozbył się swej zuchwałości i wciąż pełen był pychy. Dyszał ogniem wściekłości przeciwko Żydom i rozkazał jeszcze bardziej przyśpieszyć jazdę. Wówczas zdarzyło się, że wypadł z pędzącego wozu. Upadek był tak nieszczęśliwy, że [Antioch] doznał obrażeń na całym ciele.
###### **2Mch 9,8**
 Jeszcze niedawno myślał on w swej nadludzkiej pysze, że może rozkazywać falom morskim, i wyobrażał sobie, że wysokie góry potrafi położyć na szalę wagi, a oto rzucony na ziemię niesiony był w lektyce, co było dla wszystkich wyraźnym znakiem mocy Bożej.
###### **2Mch 9,9**
 Co więcej - robaki wychodziły z ciała bezbożnika, które jeszcze za jego życia rozkładało się odpadając kawałkami w boleściach i męczarniach, a smród, jaki wydawało, dokuczał całemu wojsku.
###### **2Mch 9,10**
 Z powodu nieznośnego odoru nikt nie mógł teraz wytrzymać przy tym, który niedawno jeszcze wyobrażał sobie, że dosięgnąć może gwiazd niebieskich.
###### **2Mch 9,11**
 Teraz - gdy został ciężko doświadczony - zmalała jego pycha i zaczynał pojmować, że bicz kary Bożej nieustannie zwiększa jego cierpienia.
###### **2Mch 9,12**
 A gdy już sam nie mógł znieść swego cuchnącego ciała, rzekł: Sprawiedliwą jest rzeczą, aby śmiertelny człowiek poddał się Bogu i nie sądził, że jest Mu równy.
###### **2Mch 9,13**
 Tymi słowami modlił się więc bezbożnik do Wszechwładnego, który nie chciał okazać mu zmiłowania:
###### **2Mch 9,14**
 Święte Miasto, do którego śpieszyłem, aby je zrównać z ziemią i uczynić cmentarzyskiem, ogłoszę wolnym;
###### **2Mch 9,15**
 natomiast Żydów, o których sądziłem, że niewarci są nawet grobu, i których wraz z dziećmi rzucić chciałem na pastwę ptaków i dzikich zwierząt, zrównam [w prawach] z Ateńczykami.
###### **2Mch 9,16**
 Święty Przybytek, który poprzednio splądrowałem, przyozdobię najpiękniejszymi darami i zwrócę w dwójnasób wszystkie święte naczynia. Wydatki zaś związane z ofiarami pokryję z własnych dochodów.
###### **2Mch 9,17**
 Ponadto sam chcę zostać Żydem i przemierzając wszystkie zamieszkałe krainy głosić Bożą moc.
###### **2Mch 9,18**
 Cierpienia jednak nie ustępowały bynajmniej, bo przyszedł na niego sprawiedliwy sąd Boży. Straciwszy wszelką nadzieję napisał do Żydów niżej przytoczony list w formie prośby; treść jego jest następująca:
###### **2Mch 9,19**
 "Antioch, król i wódz, przesyła dostojnym obywatelom żydowskim liczne pozdrowienia oraz życzenia zdrowia i pomyślności.
###### **2Mch 9,20**
 Jeżeli zdrowi jesteście wy i wasze dzieci, i jeżeli wszystkie sprawy układają się wam pomyślnie, [dzięki składam za to niebu], w którym nadzieję pokładam.
###### **2Mch 9,21**
 Mile wspominam okazywaną mi przez was cześć i życzliwość. Wracając z ziemi perskiej zapadłem na ciężką chorobę i uważam za konieczne zatroszczyć się o wspólne bezpieczeństwo wszystkich [poddanych].
###### **2Mch 9,22**
 Nie poddaję się jeszcze, lecz mam wszelką nadzieję, że przezwyciężę chorobę.
###### **2Mch 9,23**
 Przypominam sobie jednak, że również mój ojciec, ilekroć się wyprawiał z wojskiem do północnych krain, wyznaczał następcę,
###### **2Mch 9,24**
 aby mieszkańcy kraju wiedzieli, komu powierzono sprawy państwa i nie niepokoili się, gdyby zdarzyło się coś niezwykłego lub nadeszła jaka zła wieść.
###### **2Mch 9,25**
 Biorąc nadto pod uwagę, że zarówno okoliczni władcy, jak i sąsiedzi [naszego] królestwa wyczekują tylko na dogodną sposobność i śledzą dalszy rozwój wydarzeń, mianowałem królem mego syna Antiocha, którego już często przedstawiałem i polecałem bardzo wielu spośród was, kiedy sam udawałem się do północnych satrapii. Napisałem i do niego list, który tu załączam.
###### **2Mch 9,26**
 Proszę was zatem i zaklinam, abyście pamiętali o dobrodziejstwach, jakie otrzymaliście ode mnie wszyscy razem i każdy z osobna, oraz abyście i nadal zachowali życzliwość, jaką okazujecie teraz mnie i mojemu synowi.
###### **2Mch 9,27**
 Jestem bowiem przekonany, że z łagodnością i życzliwością będzie postępował według moich zasad i stosunki między wami dobrze się ułożą".
###### **2Mch 9,28**
 Tak to ów morderca i bluźnierca cierpiał najgorsze męki, które zadawał innym. Na obcej ziemi, w górach marnie zakończył życie.
###### **2Mch 9,29**
 Filip, który się z nim wychował od dzieciństwa - aż obawy przed synem Antiocha zbiegł do Egiptu, do Ptolemeusza, syna Filometora - zabrał ze sobą jego ciało.
# 2Mch 9 BR
###### **2Mch 9,1**
 Mniej więcej w tym samym czasie Antioch musiał - wśród przekleństw i obelg - uchodzić z Persji.
###### **2Mch 9,2**
 Znalazłszy się bowiem w mieście Persepolis, próbował ograbić tamtejszą świątynię, a miasto obsadzić własną załogą. Wówczas wszyscy mieszkańcy miasta stawili opór i chwycili za broń. Wojska Antiocha zostały pobite, a on sam musiał stamtąd chyłkiem uchodzić.
###### **2Mch 9,3**
 Wiadomość o tym, co spotkało Nikanora i oddziały Tymoteusza, dotarła do niego, kiedy znajdował się koło Ekbatany.
###### **2Mch 9,4**
 Bardzo się rozzłościł tedy bardzo, ale był przekonany, że uda mu się na Żydach wylądować cały swój gniew za to, że zmuszono do ucieczki. Dlatego polecił woźnicy swojego rydwanu zmierzać pośpiesznie i bez wytchnienia aż do celu. Ale już zawisły nad nim wyroki nieba. W swoim zadufaniu tak sobie bowiem mówił: Kiedy tylko znajdę się w Jerozolimie, uczynię to miasto wspólnym grobem tamtejszych Żydów.
###### **2Mch 9,5**
 Ale wszystkowidzący Pan, Bóg Izraela, dotknął go, zanim dokończył tych słów, chorobą, której nikt nie był w stanie rozpoznać. Oto zaledwie poczuł nagle we wnętrznościach nieznośny ból, którego żaden lekarz nie był w stanie uśmierzyć.
###### **2Mch 9,6**
 Spadło to na niego całkiem słusznie, bo on sam wielorakimi torturami sprawiał dotkliwy ból wielu ludziom.
###### **2Mch 9,7**
 Mimo to nie została złamana jego pycha, ślepa zarozumiałość owładnęła nim całkowicie. Zionąc nienawiścią do Żydów, nakazał woźnicy jechać jeszcze szybciej. Ale oto, co się nagle stało: Kiedy wóz pędził z największą szybkością, Antioch wypadł z niego tak nieszczęśliwie, że połamał sobie wszystkie kości.
###### **2Mch 9,8**
 I tak oto ten, który w swojej nieludzkiej wyniosłości sądził, że jest w stanie poskramiać fale morskie, a na szalę wagi rzucić góry, legł na ziemi, skąd zabrano go i ułożono w lektyce. I tak okazała się na nim samym moc Boża.
###### **2Mch 9,9**
 [Po jakimś czasie] z oczu tego bezbożnika zaczęły wypełzać obrzydliwe robaki i jeszcze za życia, wśród strasznych cierpień i bólu, zaczęły mu odpadać kawałki ciała, a nieznośny odór, jaki się od niego rozchodził, zatruwał cały obóz.
###### **2Mch 9,10**
 A tak jeszcze niedawno myślał, że może dosięgnąć gwiazd na niebie! Teraz zaś nikt nawet przez chwilę nie mógł przy nim wytrzymać, tak nieznośnie cuchnął.
###### **2Mch 9,11**
 Znękany cierpieniem zaczął powoli zrzucać pychę z serca, zdając sobie coraz lepiej sprawę z tego, że to z powodu gniewu Bożego jego cierpienia stają się coraz bardziej dotkliwe.
###### **2Mch 9,12**
 A kiedy już sam nie mógł znieść odoru wydawanego przez własne ciało, powiedział: Skoro jest się tylko śmiertelnym człowiekiem, nie wolno nawet próbować wynosić się nad Boga, ale trzeba być Mu całkowicie poddanym.
###### **2Mch 9,13**
 I zaczął ów zbrodniarz wołać o pomoc do Pana, ale nie znajdował już u niego zmiłowania.
###### **2Mch 9,14**
 Przyrzekł też, że uczyni wolnym Miasto Święte, o którym jeszcze nie tak dawno mówił, że zrówna je z ziemią i zamieni w jedno wielkie cmentarzysko.
###### **2Mch 9,15**
 Obiecał również, że Żydów, o których nie tak dawno mówił, że nie są godni pochowania w grobie, lecz że należy ich ciała - tak jak ciała ich niemowląt - wyrzucić na pożarcie drapieżnym ptakom i dzikim zwierzętom, zrówna we wszystkim z obywatelami Aten.
###### **2Mch 9,16**
 Ze wszystkiego ograbioną przedtem przez siebie świątynię przyrzekał teraz przyozdobić najpiękniejszymi podarkami, zwrócić w ilości wielokrotnie większej wszystkie święte naczynia, a co by było potrzebne do składania ofiar - zakupić za własne pieniądze.
###### **2Mch 9,17**
 Co więcej, mówił, że sam zostanie Żydem i pójdzie wszędzie, dokąd tylko będzie mógł się udać, aby głosić ludziom chwałę Bożą.
###### **2Mch 9,18**
 Ale bóle nie ustępowały, gdyż przyszedł na niego sprawiedliwy sąd Boży. Kiedy więc opuściła go już wszelka nadzieja, napisał do Żydów list błagalny, którego treść była następująca:
###### **2Mch 9,19**
 Antioch, król i wódz, swoim poddanym żydowskim życzy wiele radości, zdrowia i powodzenia.
###### **2Mch 9,20**
 Będę Bogu niezmiernie wdzięczny, jeśli się okaże, że jesteście zdrowi i że wszystko jest w porządku i u waszych dzieci, i z całym waszym dobytkiem. Ufam zresztą Niebiosom, że tak jest.
###### **2Mch 9,21**
 Nigdy nie zapomnę miłości, poszanowania i uznania, jakim darzyliście mnie zawsze. Wracając z Persji, nabawiłem się choroby, która mnie nadal dręczy. Dlatego za swój obowiązek uważam troszczyć się nadal o wspólne bezpieczeństwo wszystkich poddanych.
###### **2Mch 9,22**
 [Mimo choroby] nie zamierzam zrzec się mojej władzy, przeciwnie, mam nadzieję, że wkrótce powrócę do pełni sił i zdrowia.
###### **2Mch 9,23**
 Przypomniałem sobie jednak, że już mój ojciec, ilekroć udawał się na wyprawę wojenną na wschód, zawsze wyznaczał swojego następcę.
###### **2Mch 9,24**
 Na wypadek bowiem, gdyby coś nieprzewidzianego rzeczywiście się przydarzyło albo gdyby tylko doniesiono o jakimś nieszczęściu, wszyscy mieszkańcy państwa już by wiedzieli, komu została przekazana władza, i nie byłoby powodu do żadnych zamieszek.
###### **2Mch 9,25**
 Zresztą widzę też, jak różni graniczący z nami władcy, nasi sąsiedzi, tylko czyhają na stosowną chwilę i pilnie przyglądają się biegowi wydarzeń. Mając to wszystko na uwadze, całą moją władzę przekazuję mojemu synowi Antiochowi jako prawomocnemu następcy. Większości z was polecałem go już jako godnego zaufania, kiedy nagle musiałem się udawać do prowincji wschodnich. Do niego również wysłałem list, którego odpis wam załączam.
###### **2Mch 9,26**
 Proszę więc was bardzo usilnie, żebyście nigdy nie zapominali o dobrodziejstwach wyświadczonych przeze mnie zarówno całej waszej społeczności, jak i każdemu z osobna, i abyście nadal darzyli życzliwością i mnie, i mojego syna.
###### **2Mch 9,27**
 Jestem przekonany, że będzie wam okazywał, tak jak ja, wiele dobroci i serdeczności i że będzie pozostawał z wami zawsze w prawdziwej przyjaźni.
###### **2Mch 9,28**
 I tak oto ów morderca ludzi i bezbożnik kończył swój żywot w nędzny sposób z dala od własnej ojczyzny, w górzystej krainie, wśród niewymownego bólu.
###### **2Mch 9,29**
 Filip, jego przyjaciel jeszcze z czasów młodości, pogrzebał jego ciało, ale sam w obawie przed synem Antiocha udał się do Egiptu, gdzie panował Ptolemeusz Filomator.
# 2Mch 9 WUJ
