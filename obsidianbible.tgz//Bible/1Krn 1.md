# 1Krn 1 BT5
###### **1Krn 1,1**
 Adam, Set, Enosz,
###### **1Krn 1,2**
 Kenan, Mahalaleel, Jered,
###### **1Krn 1,3**
 Henoch, Metuszelach, Lamek,
###### **1Krn 1,4**
 Noe, Sem, Cham i Jafet.
###### **1Krn 1,5**
 Synowie Jafeta: Gomer, Magog, Madaj, Jawan, Tubal, Meszek i Tiras.
###### **1Krn 1,6**
 Synowie Gomera: Aszkanaz, Rifat i Togarma.
###### **1Krn 1,7**
 Synowie Jawana: Elisza i Tarszisz, Kittim i Dodanim.
###### **1Krn 1,8**
 Synowie Chama: Kusz, Misraim, Put i Kanaan.
###### **1Krn 1,9**
 Synowie Kusza: Seba, Chawila, Sabta, Rama i Sabteka. Synowie Ramy: Saba i Dedan.
###### **1Krn 1,10**
 Kusz [jeszcze] był ojcem Nimroda, który był pierwszym mocarzem na ziemi.
###### **1Krn 1,11**
 Misraim był ojcem Ludytów, Anamitów, Lehabitów, Naftuchitów,
###### **1Krn 1,12**
 Patrusytów, Kasluchitów i Kaftorytów, z których wyszli Filistyni.
###### **1Krn 1,13**
 Kanaan zaś był ojcem Sydona, swego pierworodnego, potem Cheta
###### **1Krn 1,14**
 oraz Jebusyty, Amoryty, Girgaszyty,
###### **1Krn 1,15**
 Chiwwity, Arkity, Synity,
###### **1Krn 1,16**
 Arwadyty, Semaryty i Chamatyty.
###### **1Krn 1,17**
 Synowie Sema: Elam, Aszszur, Arpachszad, Lud i Aram. [Synowie Arama]: Us, Chul, Geter i Meszek.
###### **1Krn 1,18**
 Arpachszad był ojcem Szelacha, a Szelach – Ebera.
###### **1Krn 1,19**
 Eberowi urodzili się dwaj synowie: imię jednego Peleg, gdyż za jego dni ziemia została podzielona, a imię brata jego – Joktan.
###### **1Krn 1,20**
 Joktan był ojcem Almodada, Szelefa, Chasarmaweta, Jeracha,
###### **1Krn 1,21**
 Hadorama, Uzala, Dikli,
###### **1Krn 1,22**
 Ebala, Abimaela, Saby,
###### **1Krn 1,23**
 Ofira, Chawili i Jobaba. Wszyscy ci byli synami Joktana.
###### **1Krn 1,24**
 Sem, Arpachszad, Szelach,
###### **1Krn 1,25**
 Eber, Peleg, Reu,
###### **1Krn 1,26**
 Serug, Nachor, Terach,
###### **1Krn 1,27**
 Abram, to jest Abraham.
###### **1Krn 1,28**
  Synowie Abrahama: Izaak i Izmael.
###### **1Krn 1,29**
 Oto ich rodowód: pierworodny Izmaela Nebajot, potem Kedar, Adbeel, Mibsam,
###### **1Krn 1,30**
 Miszma, Duma, Massa, Chadad, Tema,
###### **1Krn 1,31**
 Jetur, Nafisz i Kedma. Ci byli synami Izmaela.
###### **1Krn 1,32**
 Synowie Ketury, drugorzędnej żony Abrahama: urodziła ona Zimrana, Jokszana, Medana, Midiana, Jiszbaka i Szuacha. Synowie Jokszana: Saba i Dedan.
###### **1Krn 1,33**
 Synowie Midiana: Efa, Efer, Henoch, Abida i Eldaa. Wszyscy ci byli synami Ketury.
###### **1Krn 1,34**
 Abraham był ojcem Izaaka. Synowie Izaaka: Ezaw i Izrael.
###### **1Krn 1,35**
 Synowie Ezawa: Elifaz, Reuel, Jeusz, Jalam i Korach.
###### **1Krn 1,36**
 Synowie Elifaza: Teman, Omar, Sefi, Gatam, Kenaz, Timna i Amalek.
###### **1Krn 1,37**
 Synowie Reuela: Nachat, Zerach, Szamma i Mizza.
###### **1Krn 1,38**
 Synowie Seira: Lotan, Szobal, Sibeon, Ana, Diszon, Eser i Diszan.
###### **1Krn 1,39**
 Synowie Lotana: Chori i Homam. Siostra Lotana: Timna.
###### **1Krn 1,40**
 Synowie Szobala: Alian, Manachat, Ebal, Szefi i Onam. Synowie Sibeona: Aja i Ana.
###### **1Krn 1,41**
 Synowie Any: Diszon. Synowie Diszona: Chamran, Eszban, Jitran i Keran.
###### **1Krn 1,42**
 Synowie Esera: Bilhan, Zaawan i Jaakan. Synowie Diszana: Us i Aran.
###### **1Krn 1,43**
 Oto królowie, którzy panowali w kraju Edomu, zanim jakikolwiek król panował nad Izraelitami: Bela, syn Beora, a nazwa miasta jego: Dinhaba.
###### **1Krn 1,44**
 I umarł Bela, a w jego miejsce królował Jobab, syn Zeracha z Bosry.
###### **1Krn 1,45**
 Umarł Jobab i w jego miejsce królował Chuszam z kraju Temanitów.
###### **1Krn 1,46**
 Umarł Chuszam i w jego miejsce królował Hadad, syn Bedada, który poraził Madianitów na polach Moabu, a nazwa miasta jego Awit.
###### **1Krn 1,47**
 Umarł Hadad i w jego miejsce królował Samla z Masreki.
###### **1Krn 1,48**
 Umarł Samla i w jego miejsce królował Szaul z Rechobot Nadrzecznego.
###### **1Krn 1,49**
 Umarł Szaul i w jego miejsce królował Baal-Chanan, syn Akbora.
###### **1Krn 1,50**
 Umarł Baal-Chanan i w jego miejsce królował Hadad, a nazwa miasta jego Pai, imię zaś jego żony Mehetabeel, córki Matredy, córki Mezahaba.
###### **1Krn 1,51**
 Umarł też i Hadad. Naczelnikami szczepów Edomu byli: naczelnik Timna, naczelnik Alia, naczelnik Jetet,
###### **1Krn 1,52**
 naczelnik Oholibama, naczelnik Ela, naczelnik Pinon, naczelnik Kenaz, naczelnik Teman, naczelnik Mibsar,
###### **1Krn 1,53**
 naczelnik Magdiel, naczelnik Iram. Ci byli naczelnikami Edomu.
# 1Krn 1 PAU
###### **1Krn 1,1**
 Adam, Set, Enosz,
###### **1Krn 1,2**
 Kenan, Mahalaleel, Jered,
###### **1Krn 1,3**
 Henoch, Metuszelach, Lamek,
###### **1Krn 1,4**
 Noe, Sem, Cham i Jafet.
###### **1Krn 1,5**
 Synowie Jafeta: Gomer, Magog, Madaj, Jawan, Tubal, Meszek i Tiras.
###### **1Krn 1,6**
 Synowie Gomera: Aszkanaz, Rifat i Togarma.
###### **1Krn 1,7**
 Synowie Jawana: Elisza i Tarszisz, Kittim i Rodanim.
###### **1Krn 1,8**
 Synowie Chama: Kusz, Misraim, Put i Kanaan.
###### **1Krn 1,9**
 Synowie Kusza: Seba, Chawila, Sabta, Rama i Sabteka. Synowie Ramy: Saba i Dedan.
###### **1Krn 1,10**
 Ponadto Kusz był ojcem Nimroda, pierwszego mocarza na ziemi.
###### **1Krn 1,11**
 Misraim był praojcem Ludytów, Anamitów, Lehabitów, Naftuchitów,
###### **1Krn 1,12**
 Patrusytów, Kasluchitów i Kaftorytów, od których wywodzą się Filistyni.
###### **1Krn 1,13**
 Kanaan zaś był ojcem Sydona, swego pierworodnego, następnie Cheta,
###### **1Krn 1,14**
 Jebusyty, Amoryty, Girgaszyty,
###### **1Krn 1,15**
 Chiwwity, Arkity, Synity,
###### **1Krn 1,16**
 Arwadyty, Semaryty i Chamatyty.
###### **1Krn 1,17**
 Synowie Sema: Elam, Assur, Arpachszad, Lud i Aram. Synowie Arama: Us, Chul, Geter i Meszek.
###### **1Krn 1,18**
 Arpachszad był ojcem Szelacha, Szelach zaś Ebera.
###### **1Krn 1,19**
 Eberowi urodzili się dwaj synowie: pierwszy nosił imię Peleg, za jego życia bowiem ziemia została podzielona. Jego brat miał na imię Joktan.
###### **1Krn 1,20**
 Joktan był ojcem Almodada, Szelefa, Chasarmaweta, Jeracha,
###### **1Krn 1,21**
 Hadorama, Uzala, Dikli,
###### **1Krn 1,22**
 Ebala, Abimaela, Saby,
###### **1Krn 1,23**
 Ofira, Chawili i Jobaba. Wszyscy oni byli potomkami Joktana.
###### **1Krn 1,24**
 Sem, Arpachszad, Szelach,
###### **1Krn 1,25**
 Eber, Peleg, Reu,
###### **1Krn 1,26**
 Serug, Nachor, Terach,
###### **1Krn 1,27**
 Abram, czyli Abraham.
###### **1Krn 1,28**
 Synowie Abrahama: Izaak i Izmael
###### **1Krn 1,29**
 i ich potomkowie. Pierworodnym Izmaela był Nebajot, po nim Kedar, Adbeel, Mibsam,
###### **1Krn 1,30**
 Miszma, Duma, Massa, Chadad, Tema,
###### **1Krn 1,31**
 Jetur, Nafisz i Kedma. Wszyscy oni byli potomkami Izmaela.
###### **1Krn 1,32**
 Ketura, drugorzędna żona Abrahama, urodziła mu synów: Zimrana, Jokszana, Medana, Midiana, Jeszbaka i Szuacha. Synami Jokszana byli Saba i Dedan.
###### **1Krn 1,33**
 Synami Midiana zaś: Efa, Efer, Henoch, Abida i Eldaa. Wszyscy oni byli potomkami Ketury.
###### **1Krn 1,34**
 Abraham był ojcem Izaaka, a synami Izaaka byli Ezaw i Izrael.
###### **1Krn 1,35**
 Synowie Ezawa: Elifaz, Reuel, Jeusz, Jalam i Korach.
###### **1Krn 1,36**
 Synowie Elifaza: Teman, Omar, Sefi, Gatam, Kenaz, Timna i Amalek.
###### **1Krn 1,37**
 Synowie Reuela: Nachat, Zerach, Szamma i Mizza.
###### **1Krn 1,38**
 Synowie Seira: Lotan, Szobal, Sibeon, Ana, Diszon, Eser, Diszan.
###### **1Krn 1,39**
 Synowie Lotana: Chori i Homam, a siostrą Lotana była Timna.
###### **1Krn 1,40**
 Synowie Szobala: Alian, Manachat, Ebal, Szefi i Onam. Synowie Sibeona: Aja i Ana.
###### **1Krn 1,41**
 Synowie Any: Diszon. Synowie Diszona: Chamran, Eszban, Jetran i Keran.
###### **1Krn 1,42**
 Synowie Esera: Bilhan, Zaawan i Akan. Synowie Diszona: Us i Aran.
###### **1Krn 1,43**
 A oto królowie, którzy panowali w ziemi Edomu, zanim jakikolwiek król zapanował nad Izraelitami: Bela, syn Beora, a miasto jego zwało się Dinhaba.
###### **1Krn 1,44**
 Kiedy Bela umarł, władzę po nim przejął Jobab, syn Zeracha z Bosry.
###### **1Krn 1,45**
 Po śmierci Jobaba królował Chuszam z kraju Temanitów.
###### **1Krn 1,46**
 Gdy Chuszam umarł, władzę po nim objął Hadad, syn Bedada, pochodzący z miasta Awit. To on rozgromił Madianitów na równinach Moabu.
###### **1Krn 1,47**
 Po śmierci Hadada władzę przejął Samla z Masreki.
###### **1Krn 1,48**
 Kiedy on umarł, władzę po nim objął Szaul z Rechobot położonego nad Rzeką.
###### **1Krn 1,49**
 Po śmierci Szaula panował Baal-Chanan, syn Akbora.
###### **1Krn 1,50**
 Kiedy Baal-Chanan umarł, władzę po nim przejął Hadad. Jego miastem było Pai, a żoną Mehetabel, córka Matredy, córki Mezahaba.
###### **1Krn 1,51**
 Potem umarł Hadad. Wtedy przywódcami plemion Edomu zostali: Timna, Alia, Jetet,
###### **1Krn 1,52**
 Oholibama, Ela, Pinon,
###### **1Krn 1,53**
 Kenaz, Teman, Mibsar,
###### **1Krn 1,54**
 Magdiel, Iram. Wszyscy oni byli przywódcami Edomu.
# 1Krn 1 BP
###### **1Krn 1,1**
 Adam, Set, Enosz,
###### **1Krn 1,2**
 Kenan, Mahalalel, Jared,
###### **1Krn 1,3**
 Chenok, Metuszelach, Lemek,
###### **1Krn 1,4**
 Noe, Sem, Cham i Jafet.
###### **1Krn 1,5**
 Synami Jafeta byli: Gomer, Magog, Madaj, Jawan, Tubal, Meszek i Tiras.
###### **1Krn 1,6**
 Synami zaś Gomera byli: Aszkanaz, Difaf i Togarma.
###### **1Krn 1,7**
 Synami Jawana byli: Elisza, Tarszisz, Kittim i Rodanim.
###### **1Krn 1,8**
 Synami Chama byli: Kusz, Micraim, Put i Kenaan.
###### **1Krn 1,9**
 Synami Kusza byli: Seba, Chawila, Sabta, Rama i Sabteka, a synami Ramy byli: Szeba i Dedan.
###### **1Krn 1,10**
 Kusz był [także] ojcem Nimroda, ten zaś stał się pierwszym mocarzem na ziemi.
###### **1Krn 1,11**
 Micraim był ojcem Ludytów, Anamitów, Lehabitów, Naftuchitów,
###### **1Krn 1,12**
 Patrusytów i Kasluchitów, z których powstali Filistyni, oraz Kaftorytów.
###### **1Krn 1,13**
 Kenaan był ojcem Sydona swego pierworodnego oraz Cheta,
###### **1Krn 1,14**
 a także Jebuzytów, Amorytów, Girgaszytów,
###### **1Krn 1,15**
 Chiwwitów, Arkitów, Synitów,
###### **1Krn 1,16**
 Arwadytów, Cemarytów i Chamatytów.
###### **1Krn 1,17**
 Synami Sema byli: Elam, Aszszur, Arpakszed, Lud i Aram, a synami Arama byli: Uc, Chul, Geter i Meszek.
###### **1Krn 1,18**
 Arpakszed był ojcem Szelacha, a Szelach znów - Ebera.
###### **1Krn 1,19**
 Eberowi urodziło się dwóch synów; jeden miał na imię Peleg, gdyż za jego czasów ziemia została podzielona, a brat jego miał na imię Joktan.
###### **1Krn 1,20**
 Joktan był ojcem Almodada, Szelefa, Chacarmaweta, Jaracha,
###### **1Krn 1,21**
 Hadorama, Uzala, Dikll,
###### **1Krn 1,22**
 Ebela, Abimaela, Szeby,
###### **1Krn 1,23**
 Ofira, Chawili i Jobaba. Ci wszyscy byli synami Joktana.
###### **1Krn 1,24**
 Sem, Arpakszed, Szelach,
###### **1Krn 1,25**
 Eber, Peleg, Reu,
###### **1Krn 1,26**
 Serug, Nachor, Tarach,
###### **1Krn 1,27**
 Abram, to jest Abraham. Potomkowie Abrahama
###### **1Krn 1,28**
 Synami Abrahama byli: Izaak i Ismael.
###### **1Krn 1,29**
 A oto ich potomkowie: pierworodnym Ismaela był Nebajot, a następnie Kedar, Adbeel, Mibsam,
###### **1Krn 1,30**
 Miszma, Duma, Massa, Chadad, Tema,
###### **1Krn 1,31**
 Jetur, Nafisz i Kedma; ci byli synami Ismaela.
###### **1Krn 1,32**
 Synami, których zrodziła Ketura, drugorzędna żona Abrahama, byli: Zimran, Jokszan, Medan, Midian, Iszbak i Szuach. Synami Jokszana byli: Szeba i Dedan.
###### **1Krn 1,33**
 Synami zaś Midiana byli: Efa, Efer, Chanok, Abida i Eldaa. Oni wszyscy byli synami Ketury.
###### **1Krn 1,34**
 Abraham był ojcem Izaaka, a synami Izaaka byli: Ezaw i Izrael.
###### **1Krn 1,35**
 Synami Ezawa byli: Elifaz, Reuel, Jeusz, Jałam i Korach.
###### **1Krn 1,36**
 Synami Elifaza byli: Teman, Omar, Cefi, Gatam, Kenaz, Timna i Amalek.
###### **1Krn 1,37**
 Synami Reuela byli: Nachat, Zerach, Szamma i Mizza.
###### **1Krn 1,38**
 Synami Seira byli: Lotan, Szobal, Cibon, Ana, Diszon, Ecer i Diszan.
###### **1Krn 1,39**
 Synami Lotana byli: Chori i Homam, a siostrą Lotana była Timna.
###### **1Krn 1,40**
 Synami Szobala byli: Alian, Manachat, Ebal, Szefi i Onam, a synami Cibona byli: Ajja i Ana.
###### **1Krn 1,41**
 Synem Any był Diszon, synami zaś Diszona: Chamran, Eszban, Itran i Keran.
###### **1Krn 1,42**
 Synami Ecera byli: Bilhan, Zaawan i Jaakan. Synami Diszona byli: Uc i Aran.
###### **1Krn 1,43**
 A oto królowie, którzy panowali w ziemi Edom, zanim jeszcze król zaczął panować nad Izraelem: Bela, syn Beora, a jego miasto nazywało się Dinhaba.
###### **1Krn 1,44**
 Po śmierci Beli panował po nim Jobab, syn Zeracha z Bocry.
###### **1Krn 1,45**
 Po śmierci Jobaba panował po nim Chuszam z ziemi Temanitów.
###### **1Krn 1,46**
 Po śmierci Chuszama panował po nim Hadad, syn Bedada, który pokonał Midianitów na polach Moabu, a miasto jego nazywało się Awit.
###### **1Krn 1,47**
 Po śmierci Hadada panował po nim Sarnia z Masreki.
###### **1Krn 1,48**
 Po śmierci Samli panował po nim Szaul z Rechobot nad Rzeką.
###### **1Krn 1,49**
 Po śmierci Szaula panował Baal-Chanan, syn Akbora.
###### **1Krn 1,50**
 Po śmierci Baal-Chanana panował po nim Hadad. Miasto jego nazywało się Pei, a żona jego miała na imię Mehetabel. Była ona córką Matredy, a wnuczką Mezahaba.
###### **1Krn 1,51**
 Po śmierci Hadada książętami Edomu byli: książę z Timny, książę z Alii, książę z Jetet,
###### **1Krn 1,52**
 książę z Oholibamy, książę z Eli, książę z Pinonu,
###### **1Krn 1,53**
 książę z Kenazu, książę z Temanu, książę z Mibcaru,
###### **1Krn 1,54**
 książę z Magdiel i książę z Iramu. Oni to byli książętami Edomu.2
# 1Krn 1 BR
###### **1Krn 1,1**
 Adam, Set, Enosz,
###### **1Krn 1,2**
 Kenan, Mahalaleel, Jered,
###### **1Krn 1,3**
 Henoch, Metuszelach, Lamek,
###### **1Krn 1,4**
 Noe, Sem, Cham i Jafet.
###### **1Krn 1,5**
 A oto synowie Jafeta: Gomer, Magog, Madaj, Jawan, Tubal, Meszek i Tiras.
###### **1Krn 1,6**
 Synami Gomera zaś byli: Aszkanaz, Rifat, Togarma.
###### **1Krn 1,7**
 Od Jawana pochodzili: Elisza i Tarszisz oraz Kittim i Dodanim.
###### **1Krn 1,8**
 Synami Chama byli: Kusz, Misraim, Put i Kanaan,
###### **1Krn 1,9**
 synami Kusza zaś Seba, Chawila, Sabta, Rama, Sabteka, a synami Ramy - Saba i Dedan.
###### **1Krn 1,10**
 Kusz [jeszcze] był ojcem Nimroda, który był pierwszym mocarzem na ziemi.
###### **1Krn 1,11**
 Od Misraima pochodzą Ludyci, Anamici, Lehabici, Naftuchici,
###### **1Krn 1,12**
 Patrusyci, Kasluchici oraz Kaftoryci; od których wywodzą się Filistyni.
###### **1Krn 1,13**
 Kanaan był ojcem Sydona, swego pierworodnego, i Cheta; ponadto do niego wywodzą się
###### **1Krn 1,14**
 Jebuzyci, Amoryci, Girgaszyci,
###### **1Krn 1,15**
 Chiwwici, Arkici, Synici,
###### **1Krn 1,16**
 Arwadyci, Semaryci i Chamatyci.
###### **1Krn 1,17**
 A oto synowie Sema: Elam, Aszszur, Arpachszad, Lud i Aram; [synami zaś Arama byli]: Us, Chul, Geter i Meszek.
###### **1Krn 1,18**
 Arpachszad był ojcem Szelacha, a Szelach - Ebera,
###### **1Krn 1,19**
 Eber zaś miał dwóch synów: jeden nazywał się Peleg [to znaczy: podział], bo za jego czasów została podzielona cała ziemia, a jego brat miał na imię Joktan.
###### **1Krn 1,20**
 Joktan był ojcem Almodada, Szelefa, Chasarmaweta, Jeracha,
###### **1Krn 1,21**
 Hadorama, Uzala, Dikli,
###### **1Krn 1,22**
 Ebala, Abimaela, Saby,
###### **1Krn 1,23**
 Ofira, Chawili i Jobaba. Wszyscy oni byli synami Joktana.
###### **1Krn 1,24**
 Potem byli: Sem, Arpachszad, Szelach,
###### **1Krn 1,25**
 Eber, Peleg, Reu,
###### **1Krn 1,26**
 Serug, Nachor, Terach,
###### **1Krn 1,27**
 Abram, czyli Abraham.
###### **1Krn 1,28**
 Synami Abrahama byli Izaak oraz Izmael.
###### **1Krn 1,29**
 A oto synowie Izmaela: pierworodny Nebajot, potem Kedar, Adbeel, Mibsam,
###### **1Krn 1,30**
 Miszma, Duma, Massa, Chadad, Tema,
###### **1Krn 1,31**
 Jetur, Nafisz i Kedma. Wszyscy ci byli synami Izmaela.
###### **1Krn 1,32**
 Ketura, nałożnica Abrahama, urodziła Abrahamowi Zimrana, Jokszana, Medana, Midiana, Jiszbaka i Szuacha. Synami zaś Jokszana byli Saba i Dedan,
###### **1Krn 1,33**
 a synami Midiana - Efa, Efer, Henoch, Abida i Eldaa. Matką ich wszystkich była Ketura.
###### **1Krn 1,34**
 Abraham był ojcem Izaaka, a synami Izaaka byli Ezaw oraz Izrael.
###### **1Krn 1,35**
 A oto synowie Ezawa: Elifaz, Reuel, Jeusz, Jalam i Korach,
###### **1Krn 1,36**
 synami Elifaza zaś byli: Teman, Omar, Sefi, Gatam, Kenaz, Timna i Amalek.
###### **1Krn 1,37**
 Synowie Reuela: Nachat, Zerach, Szamma i Mizza.
###### **1Krn 1,38**
 A oto synowie Seira: Lotan, Szobal, Sibeon, Ana, Diszon, Eser i Dziszan,
###### **1Krn 1,39**
 synami Lotana zaś byli Chori i Homam, a siostrą Lotana była Timna.
###### **1Krn 1,40**
 Synami Szobala byli: Alian, Manachat, Ebal, Szefi i Onam, a synami Sibeona - Aja i Ana.
###### **1Krn 1,41**
 Ana był ojcem Diszona, a Diszon ojcem Chamrana, Eszbana, Jitrana i Kerana.
###### **1Krn 1,42**
 Eser był ojcem Bilhana, Zaawana i Akana, a synami Diszana byli Us i Aran.
###### **1Krn 1,43**
 Zanim Izraelici mieli jakiegokolwiek króla, w Edomie panowali już następujący królowie: Bela, syn Beora, ze stolicą w Dinbaha.
###### **1Krn 1,44**
 Gdy Bela umarł, władzę po nim objął Jobab, syn Zeracha z Bosry.
###### **1Krn 1,45**
 Po śmierci Jobaba zaś tron królewski po nim objął Chuszam z kraju Temanitów.
###### **1Krn 1,46**
 Gdy Chuszam umarł, władzę po nim objął Hadad, syn Bedada, tego, który pokonał Madianitów na równinach Moabu. Siedzibą jego było miasto Awit.
###### **1Krn 1,47**
 Po śmierci Hadada królem został Samla z Masreki,
###### **1Krn 1,48**
 kiedy zaś zmarł Samla, królem został po nim Szaul z Rechobot, położonego nad Rzeką.
###### **1Krn 1,49**
 Po śmierci Szaula wstąpił na tron Baal-Chanan, syn Akbora.
###### **1Krn 1,50**
 Kiedy umarł Baal-Chanan, władzę po nim objął Hadad. Jego siedzibą było miasto Pai. Miał on żonę Mehetabel, która była córką Matredy, córki Mezahaba.
###### **1Krn 1,51**
 Po śmierci Hadada rządzili Edomem naczelnicy rodów. Oto oni: naczelnik Timna, naczelnik Alia, naczelnik Jetet,
###### **1Krn 1,52**
 naczelnik Oholibama, naczelnik Ela, naczelnik Pinon, naczelnik Kenar, naczelnik Teman, naczelnik Mibsar,
###### **1Krn 1,53**
 naczelnik Magdiel, naczelnik Iram. Wszyscy oni byli naczelnikami poszczególnych rodów w Edomie.
# 1Krn 1 WUJ
###### **1Krn 1,1**
 Adam, Seth, Enos,
###### **1Krn 1,2**
 Kainan, Malaleel, Jared,
###### **1Krn 1,3**
 Henoch, Mathusale, Lamech,
###### **1Krn 1,4**
 Noe, Sem, Cham i Japhet.
###### **1Krn 1,5**
 Synowie Japhet: Gomer i Magog, i Madai, i Jawan, Thubal, Mosoch, Thiras.
###### **1Krn 1,6**
 A synowie Gomer: Ascenes, i Riphat, i Thogorma.
###### **1Krn 1,7**
 A synowie Jawan: Eliza, i Tharsis, Cethim, i Dodanim.
###### **1Krn 1,8**
 Synowie Cham: Chus i Mesraim, i Phut, i Chanaan.
###### **1Krn 1,9**
 A synowie Chus: Saba, i Hewila, Sabbatha, i Regina, i Sabbathacha. A synowie Regmo: Saba, i Dadan.
###### **1Krn 1,10**
 Chus lepak zrodził Nemrod: ten począł być możny na ziemi.
###### **1Krn 1,11**
 A Mesraim zrodził Ludim, i Ananim, i Laabim, i Nephtuim,
###### **1Krn 1,12**
 Phetrusim też i Kasluim: z których wyszli Philistynowie, i Kaphtorimowie.
###### **1Krn 1,13**
 Chanaan zaś zrodził Sidona pierworodnego swego: Hetejczyka też,
###### **1Krn 1,14**
 I Jebuzejczyka, i Amorrhejczyka, i Gergezejczyka,
###### **1Krn 1,15**
 I Hewejczyka, i Aracejczyka, i Synejczyka.
###### **1Krn 1,16**
 Aradiczyka też, i Samarajczyka, i Hamathejczyka.
###### **1Krn 1,17**
 Synowie Sem: Aelam, i Assur, i Arphaxad, i Lud, i Aram, i Hus, i Hul, i Gether, i Mosoch.
###### **1Krn 1,18**
 A Arphaxad zrodził Sale, który też zrodził Heber.
###### **1Krn 1,19**
 A Heberowi urodzili się dwa synowie, imię jednemu Phaleg, iż za czasów jego rozdzielona jest ziemia, a imię brata jego Jektan.
###### **1Krn 1,20**
 A Jektan zrodził Elmodad, i Saleph, i Asarmoth, i Jare,
###### **1Krn 1,21**
 Adoram też, i Huzal, i Dekla,
###### **1Krn 1,22**
 Hebal też i Abimael, i Saba,
###### **1Krn 1,23**
 I Ophir, i Hewila, i Jobab. Ci wszyscy synowie Jektan.
###### **1Krn 1,24**
 Sem, Arphaxad, Sale,
###### **1Krn 1,25**
 Heber, Phaleg, Ragau,
###### **1Krn 1,26**
 Serug, Nachor, Thare,
###### **1Krn 1,27**
 Abram, ten jest Abraham.
###### **1Krn 1,28**
 A synowie Abrahamowi, Izaak i Ismahel.
###### **1Krn 1,29**
 A te rodzaje ich. Pierworodny Ismahelów. Nabaioth, i Cedar, i Adbeel, i Mabsan,
###### **1Krn 1,30**
 I Masma, i Duma, Massa, Hadad, i Thema.
###### **1Krn 1,31**
 Jetur, Naphis, Cedma. Ci są synowie Ismahelowi.
###### **1Krn 1,32**
 A synowie Cetury nałożnice Abrahamowej, które porodziła: Zamanr, Jeksan, Madan, Madian, Jesobo i Sue. A synowie Jeksanowi: Saba, i Dadan. A synowie Dadan: Assurim, i Latusim, i Laomim.
###### **1Krn 1,33**
 Synowie lepak Madian: Epha, i Epher, i Henoch, i Abida, i Eldaa. Ci wszyscy synowie Cezury.
###### **1Krn 1,34**
 A zrodził Abraham Izaaka: którego byli synowie: Ezaw, i Izrael.
###### **1Krn 1,35**
 Synowie Ezawowi: Eliphaz, Rahuel, Jehus, Ihelom, i Kore.
###### **1Krn 1,36**
 Synowie Eliphaz: Theman, Omar, Sephi, Gathan, Cenez, Thamna, Amalek.
###### **1Krn 1,37**
 Synowie Rahuelowi: Nahath, Zara, Samma, Meza.
###### **1Krn 1,38**
 Synowie Seir: Lotan, Sobal, Sebeon, Ana, Dison, Eser, Disan,
###### **1Krn 1,39**
 Synowie Lotan: Hory, Homam. A siostra Lotan była Thamna.
###### **1Krn 1,40**
 Synowie Sobal: Alian, i Manahath, i Ebal, Sephi, i Onam. Synowie Sebeon: Aia, i Ana. Synowie Ana: Dison.
###### **1Krn 1,41**
 Synowie Dison: Hamram, i Eseban, i Jethran, i Charan.
###### **1Krn 1,42**
 Synowie Eser: Balaan, i Zawan, i Jakan. Synowie Disan: Hus, i Aran.
###### **1Krn 1,43**
 Ci są królowie, którzy rozkazowali w ziemi Edom, przedtem niźli był król nad synmi Izrael: Bale syn Beor: a imię miasta jego Denaba.
###### **1Krn 1,44**
 A umarł Bale, i królował miasto niego Jobab syn Zare z Bosra.
###### **1Krn 1,45**
 A gdy i Jobab umarł, królował miasto niego Husam z ziemie Themanów.
###### **1Krn 1,46**
 Umarł też i Husam, a królował miasto niego Adad syn Badad, który poraził Madian w ziemi Moab, a imię miasta jego Avith:
###### **1Krn 1,47**
 A gdy i Adad umarł, królował po nim Semla z Masrek.
###### **1Krn 1,48**
 Ale i Semla umarł, i królował miasto niego Saul z Rohoboth, który leży nad rzeką.
###### **1Krn 1,49**
 A gdy umarł Saul, królował miasto niego Balanan syn Achobor.
###### **1Krn 1,50**
 Ale i ten umarł, i królował miasto niego Adad, którego miasta imię było Phau, a żonę jego zwano Meetabel, córka Matred, córki Mezaab.
###### **1Krn 1,51**
 Lecz po śmierci Adad, książęta miasto królów w Edom być poczęli: książę Thamna, książę Alua, książę Jethet,
###### **1Krn 1,52**
 Książę Oolibama, książę Ela, książę Phinon,
###### **1Krn 1,53**
 Książę Cenez, książę Theman, książę Mabsar,
###### **1Krn 1,54**
 Książę Magdiel, książę Hiram: te książęta Edom.
