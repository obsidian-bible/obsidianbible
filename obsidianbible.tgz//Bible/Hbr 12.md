# Hbr 12 BT5
###### **Hbr 12,1**
 I my zatem, mając dokoła siebie takie mnóstwo świadków, zrzuciwszy wszelki ciężar, [a przede wszystkim] grzech, który nas łatwo zwodzi, biegnijmy wytrwale w wyznaczonych nam zawodach.
###### **Hbr 12,2**
 Patrzmy na Jezusa, który nam w wierze przewodzi i ją wydoskonala. On to zamiast radości, którą Mu obiecywano, przecierpiał krzyż, nie bacząc na [jego] hańbę, i zasiadł po prawicy na tronie Boga.
###### **Hbr 12,3**
 Zważcie więc na Tego, który ze strony grzeszników tak wielką wycierpiał wrogość wobec siebie, abyście nie ustawali, załamani na duchu.
###### **Hbr 12,4**
 Jeszcze nie opie- raliście się aż do krwi, walcząc przeciw grzechowi,
###### **Hbr 12,5**
 a zapomnieliście o napomnieniu, z jakim się zwraca do was jako do synów:Synu mój, nie lekceważ karcenia Pana, nie upadaj na duchu, gdy On cię doświadcza.
###### **Hbr 12,6**
 Bo kogo miłuje Pan, tego karci, chłoszcze zaś każdego, którego za syna przyjmuje.
###### **Hbr 12,7**
 Trwajcie w karności! Bóg obchodzi się z wami jak z dziećmi. Jakiż to bowiem syn, którego by ojciec nie karcił?
###### **Hbr 12,8**
 Jeśli jesteście pozbawieni karcenia, którego uczestnikami stali się wszyscy, nie jesteście synami, ale dziećmi nieprawymi.
###### **Hbr 12,9**
 Zresztą, jeśliśmy cenili i szanowali ojców naszych według ciała, mimo że nas karcili, czyż nie bardziej winniśmy posłuszeństwo Ojcu dusz, a żyć będziemy?
###### **Hbr 12,10**
 Tamci karcili nas według swej woli przez niewiele dni. Ten zaś czyni to dla naszego dobra, aby nas uczynić uczestnikami swojej świętości.
###### **Hbr 12,11**
 Wszelkie karcenie na razie nie wydaje się radosne, ale smutne, potem jednak przynosi tym, którzy go doświadczyli, błogi plon sprawiedliwości.
###### **Hbr 12,12**
 Dlatego wyprostujcie opadłe ręce i osłabłe kolana!
###### **Hbr 12,13**
 Proste ślady czyńcie nogami, aby kto chromy, nie zbłądził, ale był raczej uzdrowiony.
###### **Hbr 12,14**
 Starajcie się o pokój ze wszystkimi i o uświęcenie, bez którego nikt nie zobaczy Pana.
###### **Hbr 12,15**
 Baczcie, aby nikt nie pozbawił się łaski Bożej, aby jakiś korzeń gorzki, który wyrasta do góry, nie spowodował zamieszania, a przez to nie skalali się inni,
###### **Hbr 12,16**
 i aby się nie znalazł jakiś rozpustnik i bezbożnik, jak Ezaw, który za jedną potrawę sprzedał swoje pierworodztwo.
###### **Hbr 12,17**
 A wiecie, że później, gdy chciał otrzymać błogosławieństwo, został odrzucony, nie znalazł bowiem sposobności do nawrócenia, choć go szukał ze łzami.
###### **Hbr 12,18**
  Nie przyszliście bowiem do namacalnego i płonącego ognia, do mgły, do ciemności i burzy
###### **Hbr 12,19**
 ani też do grzmiących trąb i do takiego dźwięku słów, iż wszyscy, którzy go usłyszeli, prosili, aby do nich nie mówił.
###### **Hbr 12,20**
 Nie mogli bowiem znieść tego rozkazu: Jeśliby nawet tylko zwierzę dotknęło się góry, winno być ukamienowane.
###### **Hbr 12,21**
 A tak straszne było to zjawisko, iż Mojżesz powiedział: Zatrwożony jestem i drżę.
###### **Hbr 12,22**
 Wy natomiast przyszliście do góry Syjon, do miasta Boga żywego – Jeruzalem niebieskiego, do niezliczonej liczby aniołów, na uroczyste zgromadzenie,
###### **Hbr 12,23**
 i do Kościoła pierworodnych, którzy są zapisani w niebiosach, do Boga, który sądzi wszystkich, do duchów [ludzi] sprawiedliwych, którzy już doszli do celu,
###### **Hbr 12,24**
 do Pośrednika Nowego Testamentu – Jezusa, do pokropienia krwią, która przemawia mocniej niż [krew] Abla.
###### **Hbr 12,25**
 Baczcie, abyście nie odrzucili Tego, który [do was] przemawia. Jeśli bowiem tamci nie uniknęli kary, ponieważ odrzucili Tego, który na ziemi mówił, to o ileż bardziej my, jeśli odwrócimy się od Tego, który z nieba przemawia.
###### **Hbr 12,26**
 Głos Jego wstrząsnął wówczas ziemią, a teraz obiecuje, mówiąc: Jeszcze raz wstrząsnę nie tylko ziemią, ale i niebem.
###### **Hbr 12,27**
 Te zaś słowa jeszcze raz wskazują, że nastąpi zniszczenie tego, co zniszczalne, a więc tego, co zostało stworzone, aby pozostało to, co jest niewzruszone.
###### **Hbr 12,28**
 Dlatego też otrzymując niewzruszone królestwo, trwajmy w łasce, a przez nią służmy Bogu z czcią i bojaźnią.
###### **Hbr 12,29**
 Bóg nasz bowiem jest ogniem pochłaniającym.
# Hbr 12 PAU
###### **Hbr 12,1**
 Skoro więc mamy wokół siebie tak wspaniały zastęp świadków, zrzućmy z siebie wszystko, co nam przeszkadza, i grzech, który tak łatwo przylega! Wytrwale biegnijmy w wyznaczonych nam zawodach!
###### **Hbr 12,2**
 Wpatrujmy się w Jezusa, który jest dawcą naszej wiary i jej celem. On zamiast należnej Mu radości wolał przyjąć krzyż, nie bojąc się jego hańby. Teraz zasiada po prawej stronie tronu Boga.
###### **Hbr 12,3**
 Rozważcie więc dobrze, jak wielkiej wrogości doznał On ze strony grzeszników, abyście nie upadli na duchu, ulegając zniechęceniu.
###### **Hbr 12,4**
 Jeszcze bowiem nie stawiliście oporu grzechowi, walcząc aż do krwi!
###### **Hbr 12,5**
 Nie zapominajcie o zachęcie, jaką Bóg kieruje do was jako synów: Nie gardź, mój synu, karceniem Pana i nie zniechęcaj się Jego upomnieniem,
###### **Hbr 12,6**
 bo kogo Pan miłuje, tego karci, wymierza karę każdemu, kogo uznaje za syna!
###### **Hbr 12,7**
 Jeśli cierpicie, to dla waszego wychowania! Bóg traktuje was jak synów. Cóż to byłby za syn, którego ojciec by nie wychowywał?
###### **Hbr 12,8**
 Jeśliby was omijało karcenie, będące udziałem wszystkich, znaczyłoby to, że nie jesteście Jego prawdziwymi dziećmi, nie jesteście synami!
###### **Hbr 12,9**
 Jeśli bowiem szanowaliśmy naszych ziemskich rodziców za to, że nas karcili, to tym bardziej bądźmy ulegli Ojcu duchów, aby osiągnąć życie!
###### **Hbr 12,10**
 Tamci tylko przez krótki czas wychowywali nas, jak umieli. Ten zaś czyni to dla naszego dobra, dając nam udział we własnej świętości.
###### **Hbr 12,11**
 Żadne karcenie początkowo nie wydaje się przyjemne, lecz jest bolesne. Później jednak pięknie owocuje w wychowankach pokojem i sprawiedliwością.
###### **Hbr 12,12**
 Dlatego: Wyprostujcie omdlałe ręce i osłabione kolana!
###### **Hbr 12,13**
 Wyrównajcie ścieżki, po których kroczycie! Oby potykający się nie zbłądził, lecz odzyskał zdrowie!
###### **Hbr 12,14**
 Dążcie do pokoju ze wszystkimi oraz do uświęcenia, bo bez niego nikt nie będzie oglądał Pana.
###### **Hbr 12,15**
 Czuwajcie, aby nikt nie pozbawił się łaski Bożej, aby jakiś gorzki korzeń, wyrastając, nie rozplenił się i nie zatruł wielu;
###### **Hbr 12,16**
 aby nie zjawił się jakiś rozpustnik czy bezbożnik, jak Ezaw, który za miskę jedzenia sprzedał swoje pierworództwo.
###### **Hbr 12,17**
 Wiecie przecież, że gdy potem chciał odzyskać błogosławieństwo, został odrzucony. Nie miał już możliwości odmiany, chociaż ze łzami jej szukał.
###### **Hbr 12,18**
 Rzeczywistość, do której otrzymaliście dostęp, nie jest dotykalna. To nie tamten ogień płonący, gęsty obłok i wicher,
###### **Hbr 12,19**
 dźwięk trąby i grzmiące słowa. Ci, którzy to słyszeli, prosili Boga, aby do nich nie mówił,
###### **Hbr 12,20**
 bo nie mogli znieść tego rozkazu: Choćby nawet zwierzę zbliżyło się do tej góry, będzie ukamienowane!
###### **Hbr 12,21**
 A było to tak straszne zjawisko, że Mojżesz powiedział: Drżę cały z przerażenia!
###### **Hbr 12,22**
 Wy natomiast otrzymaliście dostęp do góry Syjonu, do miasta Boga żywego, niebiańskiego Jeruzalem; do niezliczonej rzeszy świętujących aniołów;
###### **Hbr 12,23**
 na zgromadzenie pierworodnych, zapisanych w niebie; do Boga, sędziego wszystkich; do duchów sprawiedliwych, które już osiągnęły doskonałość;
###### **Hbr 12,24**
 do Jezusa, pośrednika Nowego Przymierza; do pokropienia krwią, która przemawia mocniej niż krew Abla.
###### **Hbr 12,25**
 Uważajcie, abyście nie sprzeciwili się Mówiącemu! Jeśli bowiem tamci nie uniknęli kary za to, że sprzeciwili się przemawiającemu na ziemi, to o ileż bardziej my jej nie unikniemy, jeśli odwrócimy się od Tego, który przemawia z nieba!
###### **Hbr 12,26**
 Jego głos wówczas wstrząsnął ziemią, a teraz zapowiada: Jeszcze raz poruszę nie tylko ziemię, ale i niebo!
###### **Hbr 12,27**
 Słowa jeszcze raz zapowiadają przemianę stworzeń podległych zmienności, aby trwało to, co jest niezmienne.
###### **Hbr 12,28**
 A ponieważ otrzymujemy trwałe królestwo, trwajmy w tej łasce! Tak najlepiej oddamy cześć Bogu, służąc Mu z pobożnością i bojaźnią.
###### **Hbr 12,29**
 Nasz Bóg jest przecież ogniem pożerającym!
# Hbr 12 BP
###### **Hbr 12,1**
 Dlatego też i my, otoczeni tak wielkim zastępem świadków, zrzuciwszy z siebie wszystko, co krępuje swobodę ruchów, a zwłaszcza obciążający nas grzech, biegnijmy wytrwale do czekającej nas walki.
###### **Hbr 12,2**
 Spoglądajmy na Jezusa, który wprowadził nas na drogę wiary i przewodzi na niej aż do końca, który wolał raczej przyjąć krzyż aniżeli ofiarowaną Mu radość, nie lękał się niesławy i zasiadł na tronie po prawicy Boga.
###### **Hbr 12,3**
 Rozważcie, że On tak wiele wycierpiał od zbuntowanych przeciwko Niemu grzeszników, abyście nie osłabli i nie upadli na duchu.
###### **Hbr 12,4**
 Jeszcze bowiem nie opieraliście się aż do krwi, gdybyście przeciwstawiali się grzechowi,
###### **Hbr 12,5**
 nie zapomnieliście też zachęty skierowanej do was jak do synów: "Synu mój, nie lekceważ sobie karcenia Pańskiego ani też karcony nie załamuj się.
###### **Hbr 12,6**
 Kogo bowiem Pan miłuje, tego wychowuje w karności, biczuje zaś każdego, kogo uznaje za syna".
###### **Hbr 12,7**
 Przyjmujcie cierpliwie to, co służy waszemu wychowaniu. Bóg was traktuje jak synów. Czy jest syn, którego ojciec nie karci?
###### **Hbr 12,8**
 Gdyby was nie karcono jak karci się wszystkich, bylibyście potomstwem nieprawym a nie synami.
###### **Hbr 12,9**
 Poza tym mieliśmy za wychowawców naszych ojców i nie wstydziliśmy się, kiedy nas karcili. Czyż tym bardziej nie będziemy ulegli Ojcu dusz, aby żyć?
###### **Hbr 12,10**
 Oni przecież na krótkie dni wychowywali nas tak, jak potrafili. On zaś [czyni to] dla naszego dobra, abyśmy uczestniczyli w Jego świętości.
###### **Hbr 12,11**
 Każde zaś karcenie z początku nie wydaje się przyjemne, lecz raczej przykre, ale potem przynosi wyćwiczonym w karności słodki owoc sprawiedliwości.
###### **Hbr 12,12**
 Przeto "wyprostujcie znowu zwiotczałe ręce i osłabione kolana"
###### **Hbr 12,13**
 i "stawiajcie proste kroki", aby kulejący nie upadł, lecz został uleczony.
###### **Hbr 12,14**
 Starajcie się o pokój ze wszystkimi i o uświęcenie, bez którego nikt nie będzie oglądał Boga.
###### **Hbr 12,15**
 Strzeżcie się, aby nikt z was nie był opieszały wobec łaski Bożej, aby jakiś gorzki korzeń wypuszczający pęd w górę nie wywołał zamieszania i aby nie zaraził wielu,
###### **Hbr 12,16**
 aby nie było rozpustnego lub lekkomyślnego jak Ezaw, który za miskę strawy sprzedał swoje pierworodztwo.
###### **Hbr 12,17**
 Wiecie przecież, że i potem, kiedy chciał uzyskać błogosławieństwo, został odrzucony, chociaż ze łzami dopraszał się o nie, bo nie mógł już nic zmienić.
###### **Hbr 12,18**
 Nie przystąpiliście bowiem do góry, której można dotknąć, i do ognia, który płonie, do ciemności, chmury, burzy, [nie słyszeliście]
###### **Hbr 12,19**
 brzmienia trąby i dźwięku słów. Ci, którzy to słyszeli, prosili, aby [Bóg] więcej do nich nie przemawiał.
###### **Hbr 12,20**
 Nie mogli bowiem znieść tego, co było nakazane: "Nawet jeśliby zwierzę dotknęło góry, ma być ukamienowane".
###### **Hbr 12,21**
 A tak straszliwe było to widowisko, że Mojżesz rzekł: "Przerażony jestem" i drżę z bojaźni.
###### **Hbr 12,22**
 Wy jednak przystąpiliście do góry Syjonu i do miasta Boga żywego, do niebieskiej Jerozolimy i do wielkiej liczby aniołów, do uroczystego zebrania
###### **Hbr 12,23**
 i do zgromadzenia pierworodnych zapisanych w niebie, i do sędziego, Boga wszystkich, i do duchów (ludzi) sprawiedliwych udoskonalonych w pełni,
###### **Hbr 12,24**
 i do Jezusa pośrednika Nowego Przymierza, i do pokropienia krwią wołającą głośniej niż Abel.
###### **Hbr 12,25**
 Strzeżcie się, żebyście nie odtrącili Przemawiającego do was. Jeśli bowiem oni nie uszli kary, odtrąciwszy tego, który mówił do nich na ziemi, to tym bardziej my nie ujdziemy kary, wzgardziwszy Przemawiającym do nas z nieba,
###### **Hbr 12,26**
 którego głos wstrząsnął wtedy ziemią, a teraz zapowiedział tymi słowy: "Jeszcze raz wstrząsnę" nie tylko "ziemią", lecz także "niebem".
###### **Hbr 12,27**
 Owo zaś "jeszcze raz" wskazuje na przemienienie stworzeń, które podlegają zmianom, aby trwało to, co zmianom nie podlega.
###### **Hbr 12,28**
 Dlatego otrzymując trwałe królestwo, bądźmy wdzięczni. Tak najlepiej służyć będziemy Bogu z czcią i bojaźnią Boga,
###### **Hbr 12,29**
 bo przecież nasz "Bóg jest ogniem trawiącym".
# Hbr 12 BR
###### **Hbr 12,1**
 Oto jaka rzesza świadków wiary otacza nas zewsząd. Pozbądźmy się tedy wszystkiego, co jest nam ciężarem, uwolnijmy się przede wszystkim od grzechu, który zwodzi nas tak łatwo, i zmierzajmy wytrwale do celu naszych zmagań.
###### **Hbr 12,2**
 Wpatrujmy się w Jezusa, który nas przywiódł do wiary, czyniąc ją coraz doskonalszą. On to, gdy przedkladano Mu radość, wybrał śmierć krzyżową, nie zważając wcale na jej hańbę. Teraz zasiada za to po prawej stronie tronu Bożego.
###### **Hbr 12,3**
 Skierujcie swe myśli ku Temu, któremu grzesznicy do samego końca okazywali tak bardzo wielką wrogość, a wtedy i wam nie zabraknie sił i nie będziecie upadali na duchu.
###### **Hbr 12,4**
 W waszych zmaganiach się z grzechem nie musieliście bowiem cierpieć aż do przelewu krwi,
###### **Hbr 12,5**
 a już chyba zapomnieliście o słowach, z którymi zwrócił się do was jak do swoich dzieci Pan mówiąc: Synu mój, staraj się nie lekceważyć karania Pańskiegoi nie upadaj na duchu, gdy Pan pocznie cię doświadczać.
###### **Hbr 12,6**
 Miłuje bowiem Pan tego, kogo karze, zsyła chłostę na wszystkich, których przyjmuje za swe dzieci.
###### **Hbr 12,7**
 Zechciejcie tedy znosić kary, jakie Bóg na was zsyła. Traktuje was bowiem jak dzieci. A czy można sobie wyobrazić dziecko, którego nie karciłby rodzony ojciec?
###### **Hbr 12,8**
 Jeżeli więc jesteście pozbawieni karania, to właściwie nie możecie uchodzić za synów, lecz raczej za dzieci nieprawego łoża.
###### **Hbr 12,9**
 A jeśli szanowaliśmy naszych ziemskich ojców, mimo że nas niejednokrotnie karcili, to czyż nie tym większy szacunek powinniśmy okazywać Ojcu dusz naszych, aby sobie przez to zasłużyć na życie?
###### **Hbr 12,10**
 Tamci karcili nas według swego uznania, by nas wychować na czas krótkich dni doczesnego życia. Ten zaś czyni to dla waszego dobra, w trosce o to, abyśmy byli uczestnikami Jego świętości.
###### **Hbr 12,11**
 Wszelkie karcenie z początku nie sprawia radości, przeciwnie - smutek, potem jednak tym, którzy go doświadczyli, przynosi błogi owoc sprawiedliwości.
###### **Hbr 12,12**
 Dlatego podnieście opadłe ręce i wyprostujcie kolana mocno drżące,
###### **Hbr 12,13**
 kroczcie zdecydowanie drogami waszego życia, ażeby ci, którzy się słaniają idąc za wami, nie zbłądzili, lecz powrócili do pełnego zdrowia.
###### **Hbr 12,14**
 Strajcie się też o zachowanie pokoju ze wszystkimi i o świętość, bez której nikt nie będzie mógł zobaczyć Pana.
###### **Hbr 12,15**
 Pamiętajcie też i o tym, żeby nikt nie pozbawiał się dobrowolnie łaski Bożej, żeby żaden gorzki korzeń [jakiejś trucizny], pnąc się szybko ku górze, nie stał się przyczyną nieporządku zgubnego dla wielu;
###### **Hbr 12,16**
 żeby się też nie znalazł wśród was jakiś rozpustnik lub bezbożnik, niczym ów Ezaw, który za jedną potrawę sprzedał swoje pierworodztwo.
###### **Hbr 12,17**
 Wiecie przecież, że gdy potem pragnął uzyskać błogosławieństwo, nie został wysłuchany; nie zdołał już odmienić myśli ojca, choć domagał się tego ze łzami.
###### **Hbr 12,18**
 Bo nie przyszliście [jak ongiś Izraelici] do góry, której nie można dotknąć i którą ogarniają płomienie ognia, mgła, ciemności i burze,
###### **Hbr 12,19**
 z wnętrza zaś rozlega się głos brzmiących trąb i słowa tak potężne, iż wszyscy, którzy je słyszeli, pragnęli, by już zapanowała cisza.
###### **Hbr 12,20**
 Nie mogli bowiem znieść rozkazu, który brzmiał: Wszelkie stworzenie choćby to było nawet zwierzę - skoro tylko dotknie się tej góry, winno być ukamienowane.
###### **Hbr 12,21**
 Wszystko zaś razem było tak straszne, iż Mojżesz powiedział: Przerażony jestem i drżę cały.
###### **Hbr 12,22**
 Otóż wy przystąpiliście do góry Syjon, do miasta Boga żywego, do Jeruzalem niebieskiego, do niezliczonej rzeszy aniołów,
###### **Hbr 12,23**
 na uroczyste zebranie pierworodnych synów Bożych, których imiona są zapisane w niebie, do Boga, który sądzi wszystkich, do duchów sprawiedliwych, które już osiągnęły swój cel,
###### **Hbr 12,24**
 do pośrednika Nowego Testamentu - Jezusa i wreszcie do owej krwi oczyszczającej, która posiada skuteczniejszą wymowę niż [krew] Abla.
###### **Hbr 12,25**
 Uważajcie, żebyście czasem nie odtrącili Tego, który do was przemawia. Jeżeli bowiem tamci za to, że odwrócili się od przemawiającego do nich na ziemi, nie uniknęli surowej kary, to o ileż bardziej surowa kara spotka nas, jeśli zlekceważymy Tego, który przemawia z nieba.
###### **Hbr 12,26**
 Głos Jego wstrząsnął kiedyś całą ziemią, teraz zaś zwraca się do nas z takim oto ostrzeżeniem: Jeszcze raz poruszę nie tylko ziemię, ale i niebo.
###### **Hbr 12,27**
 Wyrażenie: jeszcze raz każe się domyślać, że ulegnie całkowitej zagładzie wszystko, co zostało stworzone i jest zniszczalne, pozostanie zaś nienaruszone to, co jest rzeczywiście niezniszczalne.
###### **Hbr 12,28**
 Otóż my powinniśmy być wdzięczni za to, że otrzymujemy w posiadanie królestwo niezniszczalne; powinniśmy też służyć Bogu ze czcią i bojaźnią,
###### **Hbr 12,29**
 gdyż Bóg nasz jest ogniem wszystko pochłaniającym.
# Hbr 12 WUJ
###### **Hbr 12,1**
 Przetoż tedy i my mając tak wielki nad sobą obłok świadków: złożywszy wszelaki ciężar i grzech, który nas zewsząd obstąpił, w cierpliwości bieżmy do boju nam wystawionego,
###### **Hbr 12,2**
 Patrząc na Jezusa przodka i kończyciela wiary, który mając przed sobą wesele podjął krzyż, wzgardziwszy sromotę, i siedzi na prawicy stolice Bożej.
###### **Hbr 12,3**
 Abowiem uważajcie tego, który takowe przeciwieństwo od grzeszników podejmował przeciw sobie: abyście nie ustawali, osłabiawszy na duszach waszych.
###### **Hbr 12,4**
 Boście jeszcze się aż do krwie nie zastawili, walcząc przeciwko grzechowi:
###### **Hbr 12,5**
 A zapamiętaliście pociechy, która nam jako synom mówi, rzekąc: Synu mój, nie wzgardzaj karania Pańskiego: ani osłabiaj, gdy od niego strofowan bywasz.
###### **Hbr 12,6**
 Abowiem kogo Pan miłuje, karze, a biczuje każdego syna, którego przyjmuje.
###### **Hbr 12,7**
 W karności trwajcie. Ofiarujeć się wam Bóg jako synom. Abowiem któryż syn, któregoby Ociec nie karał.
###### **Hbr 12,8**
 A jeśli jesteście bez karania, którego stali się wszyscy przaśnikami: tedyście złego łoża, a nie synami.
###### **Hbr 12,9**
 Nadto ciała naszego ojce, mieliśmy uczycielmi, i baliśmy się ich: zaż nie daleko więcej posłuszni będziem Ojcowi duchów, a żyć będziemy?
###### **Hbr 12,10**
 A onić na czas mało dni, według woli swojej nas ćwiczyli: lecz ten na to co pożyteczno jest ku przyjęciu świątobliwości jego.
###### **Hbr 12,11**
 A wszelkie karanie teraźniejszego czasu w prawdzie zda się że nie jest wesele ale smutku: ale potem naspokojniejszy owoc sprawiedliwości odda przez nię wyćwiczonym.
###### **Hbr 12,12**
 Przetoż ręce opuszczone i kolana osłabione wznieście.
###### **Hbr 12,13**
 A czyńcie kroki proste nogami waszemi, aby który chramiąc nie zabłądził, ale raczej był uzdrowion.
###### **Hbr 12,14**
 Naśladujcie pokoju ze wszystkiemi, i świątobliwości: bez której żaden nie ogląda Boga.
###### **Hbr 12,15**
 Upatrując, żeby kto nie odstąpił od łaski Bożej: aby który korzeń gorzkości wzgórę wyrastając nie przekażał, a przezeń wiele się nie pokalało.
###### **Hbr 12,16**
 By nie był kto porubnik abo niezbożny jako Ezau: który dla jednej potrawy przedał pierworodztwo swoje:
###### **Hbr 12,17**
 Bo wiedzcie, iż i potem, gdy chciał być dziedzicem błogosławieństwa, był odrzucon. Bo nie nałazł miejsca pokuty, choć jej ze łzami szukał.
###### **Hbr 12,18**
 Boście nie przystąpili do góry, której się dotknąć może, i ognia, który się zapalić może, i wichru, i mgły, i burzy,
###### **Hbr 12,19**
 I brzmienia trąby, i głodu słów, który co słyszeli, zbraniali się, aby do nich nie mówiono.
###### **Hbr 12,20**
 Abowiem nie znosili co mówiono, I jeśli się bestya dotknie góry, będzie ukamionowana.
###### **Hbr 12,21**
 A tak straszliwo było co widziane było, Mojżesz powiedział: Przestraszony jestem i drżący.
###### **Hbr 12,22**
 Aleście przystąpili do Sion góry i miasta Boga żywiącego, Jeruzalem niebieskiego, i gromady wiela tysięcy Aniołów:
###### **Hbr 12,23**
 I kościoła pierworodnych, którzy są spisani w niebie, i Boga sędziego wszystkich, i duchów sprawiedliwych doskonałych.
###### **Hbr 12,24**
 I Jezusa pośrednika nowego testamentu, i pokropienia krwie lepiej mówiącej niźli Ablowa.
###### **Hbr 12,25**
 Patrzajcież, abyście nie wzgardzili tym, który mówi. Bo jeśliż oni nie uszli, gardząc tym co na ziemi mówił: daleko więcej my, którzy odwracamy tego, który z nieba mówi.
###### **Hbr 12,26**
 Którego głos wzruszył na on czas ziemią, a teraz obiecuje, mówiąc: Jeszcze raz: a ja zatrząsnę nie tylko ziemią, ale i niebem.
###### **Hbr 12,27**
 A co mówi, Jeszcze raz: znaczy przeniesienie rzeczy ruchomych jako uczynionych, aby zostały te, które są nieruchome.
###### **Hbr 12,28**
 A tak przyjmując królestwo nieporuszone, mamy łaskę: przez którą służmy podobając się Bogu, z bojaźnią i z uczciwością.
###### **Hbr 12,29**
 Abowiem Bóg nasz jest ogniem trawiącym.
# Hbr 12 STERN
###### **Hbr 12,1**
 Skoro zatem otacza nas tak wielki obłok świadków, i my również odrzućmy wszelką przeszkodę - czyli grzech, który łatwo wstrzymuje nasz ruch do przodu - i dalej biegnijmy z wytrwałością w zawodach, jakie są przed nami,
###### **Hbr 12,2**
 spoglądając ku Temu, który zapoczątkowuje i wypełnia to ufanie, Jeszui, który z myślą o czekającej na Niego radości zniósł egzekucję na palu jak zbrodniarz, wzgardziwszy wstydem, i zasiadł po prawicy tronu Boga.
###### **Hbr 12,3**
 Tak jest, pomyślcie o Tym, który zniósł taką wrogość grzeszników względem siebie, abyście nie ustali i nie zniechęcili się.
###### **Hbr 12,4**
 Nie opieraliście się jeszcze aż do krwi w tych zmaganiach z grzechem.
###### **Hbr 12,5**
 Zapomnieliście też o radzie, która przemawia do was jak do synów: "Synu mój, nie gardź karceniem Adonai i nie zniechęcaj się, gdy cię upomina.
###### **Hbr 12,6**
 Bo Adonai kształci charakter w tych, których kocha, a smaga każdego, kogo przyjmuje za syna".
###### **Hbr 12,7**
 Uznawajcie swoje doświadczenia za kształtowanie charakteru - Bóg postępuje z wami jak z synami. Bo jakiż syn nie jest karcony przez ojca?
###### **Hbr 12,8**
 Wszyscy prawowici synowie są karceni; a jeśli ty nie jesteś, toś mamzer, a nie syn!
###### **Hbr 12,9**
 Ponadto skoro karcili nas nasi fizyczni ojcowie, a myśmy ich szanowali - o ileż bardziej powinniśmy się poddać naszemu Ojcu duchowemu i żyć!
###### **Hbr 12,10**
 Bo oni kształcili nasz charakter tylko przez krótki czas i tylko najlepiej, jak umieli - lecz On kształci nas w sposób dla nas prawdziwie pożyteczny i uzdolniający nas do udziału w Jego świętości.
###### **Hbr 12,11**
 A wszelkie karcenie w danej chwili rzeczywiście wydaje się bolesne, nieprzyjemne; lecz dla tych, którzy zostali przez nie ukształtowani, rodzi później owoc pokoju, którym jest sprawiedliwość.
###### **Hbr 12,12**
 A zatem: wzmocnijcie omdlałe ramiona i niech nie chwieją się wam kolana,
###### **Hbr 12,13**
 i: wyrównajcie ścieżkę dla swoich stóp, aby to, co zranione, nie zostało wyrwane ze stawu, lecz raczej uzdrowione.
###### **Hbr 12,14**
 Dążcie do szalomu ze wszystkimi i do świętości, bez której nikt nie ujrzy Pana.
###### **Hbr 12,15**
 Dopilnujcie, żeby nikt nie przegapił Bożej łaski, aby żaden korzeń goryczy nie wykiełkował i nie narobił szkód, kalając wielu,
###### **Hbr 12,16**
 i żeby nikt nie był rozwiązły ani bezbożny jak Esaw, który za jeden posiłek zrezygnował z praw do pierworodztwa.
###### **Hbr 12,17**
 Bo wiecie, że później, kiedy chciał otrzymać błogosławieństwo ojca, został odrzucony; w rzeczy samej, mimo że zabiegał o to ze łzami, na nic mu się nie zdała przemiana serca.
###### **Hbr 12,18**
 Bo nie podeszliście do namacalnej góry, do zapalonego ognia, do ciemności, pomruków, wichury,
###### **Hbr 12,19**
 do dźwięku szofaru i do głosu, którego słowa zmusiły słuchaczy do błagania, aby już dalej nie przekazywano im orędzia,
###### **Hbr 12,20**
 nie mogli bowiem znieść tego, co im nakazywano: "Jeśli choćby zwierzę dotknie się góry, ma być ukamienowane",
###### **Hbr 12,21**
 a tak przerażający był to widok, że Mosze rzekł: "Trzęsę się z grozy".
###### **Hbr 12,22**
 Przeciwnie, podeszliście do góry Cijon, czyli do miasta Boga żywego, niebieskiego Jeruszalaim, do miriadów aniołów zebranych uroczyście,
###### **Hbr 12,23**
 do wspólnoty pierworodnych, których imiona zapisano w niebie, do Sędziego, który jest Bogiem wszystkich, do duchów ludzi sprawiedliwych, którzy zostali doprowadzeni do celu,
###### **Hbr 12,24**
 do pośrednika nowego przymierza, Jeszui, i do pokropienia krwią, która zwiastuje lepsze rzeczy niż krew Hewla.
###### **Hbr 12,25**
 Uważajcie, żebyście nie odrzucili Tego, który przemawia! Bo jeśli nie umknęli tamci, którzy odrzucili Go, gdy udzielał Boskiego ostrzeżenia na ziemi, to pomyślcie - tym bardziej jak uciekniemy my, jeśli odwrócimy się od Niego, gdy ostrzega z Nieba?
###### **Hbr 12,26**
 Już wówczas Jego głos poruszył ziemię; lecz teraz dał On taką obietnicę: "Jeszcze raz poruszę nie tylko ziemię, ale i niebo!".
###### **Hbr 12,27**
 A to wyrażenie "jeszcze raz" nie pozostawia wątpliwości, że rzeczy, które poruszono, są usuwane, bo są rzeczami stworzonymi, tak aby pozostało to, co nieporuszone.
###### **Hbr 12,28**
 Skoro zatem otrzymaliśmy Królestwo nieporuszone, przyjmijmy łaskę, dzięki której będziemy mogli pełnić służbę miłą Bogu, z czcią i bojaźnią.
###### **Hbr 12,29**
 Bo zaiste: "Nasz Bóg jest ogniem pożerającym!".
# Hbr 12 TRO
###### **Hbr 12,1**
 **τοιγαρουν** *toigaroun* Toteż – Przeto [[G5105]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **ημεις** *hēmeis* my [[G2249]] WTP-1NP **τοσουτον** *tosouton* tak wielki [[G5118]] WTD-ASN **εχοντες** *echontes* mając [[G2192]] WTV-PAP-NPM **περικειμενον** *perikeimenon* otaczający – obejmujący [[G4029]] WTV-PNP-ASN **ημιν** *hēmin* nas [[G2254]] WTP-1DP **νεφος** *nefos* obłok – chmurę [[G3509]] WTN-ASN **μαρτυρων** *martyrōn* świadków [[G3144]] WTN-GPM **ογκον** *ogkon* ciężar [[G3591]] [[N-ASM]] **αποθεμενοι** *apothemenoi* odłożywszy [[G659]] WTV-2AMP-NPM **παντα** *panta* cały [[G3956]] WTA-ASM **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **ευπεριστατον** *euperistaton* dokładnie otaczający [[G2139]] WTA-ASF **αμαρτιαν** *hamartian* grzech [[G266]] WTN-ASF **δι** *di* z powodu [[G1223]] [[PREP]] **υπομονης** *hypomonēs* wytrwałości [[G5281]] [[N-GSF]] **τρεχωμεν** *trechōmen* bieglibyśmy [[G5143]] WTV-PAS-1P **τον** *ton* (w) [[G3588]] [[T-ASM]] **προκειμενον** *prokeimenon* który jest położony przed – który jest ustanowiony przed [[G4295]] WTV-PNP-ASM **ημιν** *hēmin* nami [[G2254]] WTP-1DP **αγωνα** *agōna* bój – walce [[G73]] [[N-ASM]]
###### **Hbr 12,2**
 **αφορωντες** *aforōntes* Spoglądając z daleka – Patrząc z daleka [[G872]] WTV-PAP-NPM **εις** *eis* na [[G1519]] [[PREP]] **τον** *ton* (Tego) [[G3588]] [[T-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **αρχηγον** *archēgon* początek i wodza – sprawcę [[G747]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **τελειωτην** *teleiōtēn* doskonałość – dojrzałość [[G5051]] [[N-ASM]] **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]] **ος** *hos* który [[G3739]] WTR-NSM **αντι** *anti* zamiast [[G473]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **προκειμενης** *prokeimenēs* która jest wyłożona przed [[G4295]] WTV-PNP-GSF **αυτω** *autō* Nim [[G846]] WTP-DSM **χαρας** *charas* radości [[G5479]] [[N-GSF]] **υπεμεινεν** *hypemeinen* zniósł – przetrzymał [[G5278]] [[V-AAI-3S]] **σταυρον** *stauron* krzyż [[G4716]] [[N-ASM]] **αισχυνης** *aischynēs* wstydu – hańbą [[G152]] [[N-GSF]] **καταφρονησας** *katafronēsas* zlekceważywszy – wzgardziwszy [[G2706]] WTV-AAP-NSM **εν** *en* na [[G1722]] [[PREP]] **δεξια** *deksia* prawej stronie – prawicy [[G1188]] WTA-DSF **τε** *te* zarówno – także [[G5037]] WTPRT **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronu [[G2362]] [[N-GSM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εκαθισεν** *ekathisen* usiadł [[G2523]] [[V-AAI-3S]]
###### **Hbr 12,3**
 **αναλογισασθε** *analogisasthe* Porównajcie – Rozważcie [[G357]] WTV-ADM-2P **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **τον** *ton* (Tego, który) [[G3588]] [[T-ASM]] **τοιαυτην** *toiautēn* taki [[G5108]] WTD-ASF **υπομεμενηκοτα** *hypomemenēkota* który zniósł – który wytrwał [[G5278]] WTV-RAP-ASM **υπο** *hypo* od [[G5259]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **αμαρτωλων** *hamartōlōn* grzeszników [[G268]] WTA-GPM **εις** *eis* względem [[G1519]] [[PREP]] **αυτον** *auton* Jego [[G846]] WTP-ASM **αντιλογιαν** *antilogian* spór – bunt [[G485]] WTN-ASF **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **καμητε** *kamēte* osłablibyście – bylibyście niepewni [[G2577]] WTV-2AAS-2P **ταις** *tais* (dla) [[G3588]] WTT-DPF **ψυχαις** *psychais* dusz [[G5590]] WTN-DPF **υμων** *hymōn* waszych [[G5216]] WTP-2GP **εκλυομενοι** *eklyomenoi* które są osłabiane – które są trudzone [[G1590]] WTV-PPP-NPM
###### **Hbr 12,4**
 **ουπω** *oupō* Jeszcze nie [[G3768]] [[ADV]] **μεχρις** *mechris* aż do [[G3360]] [[ADV]] **αιματος** *haimatos* krwi [[G129]] [[N-GSN]] **αντικατεστητε** *antikatestēte* przeciwstawialiście się – opieraliście się [[G478]] WTV-2AAI-2P **προς** *pros* przeciw [[G4314]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **αμαρτιαν** *hamartian* grzechowi [[G266]] WTN-ASF **ανταγωνιζομενοι** *antagōnizomenoi* walcząc naprzeciw [[G464]] WTV-PNP-NPM
###### **Hbr 12,5**
 **και** *kai* i [[G2532]] [[CONJ]] **εκλελησθε** *eklelēsthe* całkiem zapomnieliście [[G1585]] WTV-RPI-2P **της** *tēs* (o) [[G3588]] [[T-GSF]] **παρακλησεως** *paraklēseōs* zachęcie – pociesze [[G3874]] [[N-GSF]] **ητις** *hētis* która [[G3748]] WTR-NSF **υμιν** *hymin* wam [[G5213]] WTP-2DP **ως** *hōs* jak [[G5613]] [[ADV]] **υιοις** *hyiois* synom [[G5207]] WTN-DPM **διαλεγεται** *dialegetai* jest mówiona – jest wykładana [[G1256]] WTV-PNI-3S **υιε** *hyie* Synu [[G5207]] WTN-VSM **μου** *mou* mój [[G3450]] WTP-1GS **μη** *mē* nie [[G3361]] [[PRT-N]] **ολιγωρει** *oligōrei* lekceważ – gardź [[G3643]] WTV-PAM-2S **παιδειας** *paideias* karcenia – karności [[G3809]] [[N-GSF]] **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **μηδε** *mēde* ani [[G3366]] [[CONJ]] **εκλυου** *eklyou* bądź osłabiany – bądź trudzony [[G1590]] WTV-PPM-2S **υπ** *hyp* przez [[G5259]] [[PREP]] **αυτου** *autou* Niego [[G846]] [[P-GSM]] **ελεγχομενος** *elegchomenos* który jest upominany – który jest zawstydzany [[G1651]] [[V-PPP-NSM]]
###### **Hbr 12,6**
 **ον** *hon* którego [[G3739]] WTR-ASM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **αγαπα** *agapa* miłuje [[G25]] WTV-PAI-3S **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **παιδευει** *paideuei* koryguje – dyscyplinuje [[G3811]] WTV-PAI-3S **μαστιγοι** *mastigoi* biczuje – chłoszcze [[G3146]] WTV-PAI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **παντα** *panta* każdego [[G3956]] WTA-ASM **υιον** *hyion* syna [[G5207]] [[N-ASM]] **ον** *hon* którego [[G3739]] WTR-ASM **παραδεχεται** *paradechetai* przyjmuje [[G3858]] WTV-PNI-3S
###### **Hbr 12,7**
 **ει** *ei* Jeśli [[G1487]] WTCOND **παιδειαν** *paideian* karcenie – karność [[G3809]] WTN-ASF **υπομενετε** *hypomenete* znosicie – przetrzymujecie [[G5278]] WTV-PAI-2P **ως** *hōs* jak [[G5613]] [[ADV]] **υιοις** *hyiois* synom [[G5207]] WTN-DPM **υμιν** *hymin* wam [[G5213]] WTP-2DP **προσφερεται** *prosferetai* jest przynoszony – jest przyprowadzany [[G4374]] WTV-PPI-3S **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **τις** *tis* jakim [[G5101]] WTI-NSM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **υιος** *hyios* syn [[G5207]] [[N-NSM]] **ον** *hon* którego [[G3739]] WTR-ASM **ου** *ou* nie [[G3756]] [[PRT-N]] **παιδευει** *paideuei* koryguje – dyscyplinuje [[G3811]] WTV-PAI-3S **πατηρ** *patēr* ojciec [[G3962]] [[N-NSM]]
###### **Hbr 12,8**
 **ει** *ei* Jeśli [[G1487]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **χωρις** *chōris* bez [[G5565]] [[ADV]] **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **παιδειας** *paideias* karcenia – karności [[G3809]] [[N-GSF]] **ης** *hēs* którego [[G3739]] [[R-GSF]] **μετοχοι** *metochoi* uczestnicy – towarzysze [[G3353]] WTA-NPM **γεγονασιν** *gegonasin* stali się [[G1096]] WTV-2RAI-3P **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **αρα** *ara* zatem – dlatego [[G686]] WTPRT **νοθοι** *nothoi* bękarty – nieślubne dzieci [[G3541]] WTA-NPM **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **και** *kai* a [[G2532]] [[CONJ]] **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **υιοι** *hyioi* synowie [[G5207]] WTN-NPM
###### **Hbr 12,9**
 **ειτα** *eita* Potem [[G1534]] [[ADV]] **τους** *tous* (tych) [[G3588]] WTT-APM **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **της** *tēs* (według) [[G3588]] [[T-GSF]] **σαρκος** *sarkos* ciała [[G4561]] [[N-GSF]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **πατερας** *pateras* ojców [[G3962]] [[N-APM]] **ειχομεν** *eichomen* mieliśmy [[G2192]] WTV-IAI-1P **παιδευτας** *paideutas* (jako) karcących – (jako) wychowawców [[G3810]] [[N-APM]] **και** *kai* i [[G2532]] [[CONJ]] **ενετρεπομεθα** *enetrepometha* szanowaliśmy [[G1788]] WTV-IMI-1P **ου** *ou* nie [[G3756]] [[PRT-N]] **πολλω** *pollō* wiele [[G4183]] WTA-DSN **μαλλον** *mallon* bardziej [[G3123]] [[ADV]] **υποταγησομεθα** *hypotagēsometha* zostaniemy poddani – zostaniemy podporządkowani [[G5293]] WTV-2FPI-1P **τω** *tō* [[G3588]] WTT-DSM **πατρι** *patri* Ojcu [[G3962]] WTN-DSM **των** *tōn* [[G3588]] WTT-GPN **πνευματων** *pneumatōn* duchów [[G4151]] WTN-GPN **και** *kai* i [[G2532]] [[CONJ]] **ζησομεν** *zēsomen* będziemy żyć [[G2198]] WTV-FAI-1P
###### **Hbr 12,10**
 **οι** *hoi* [[G3588]] WTT-NPM **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **προς** *pros* na [[G4314]] [[PREP]] **ολιγας** *oligas* nieliczne [[G3641]] WTA-APF **ημερας** *hēmeras* dni [[G2250]] WTN-APF **κατα** *kata* według [[G2596]] [[PREP]] **το** *to* (tego) [[G3588]] WTT-ASN **δοκουν** *dokoun* co wydaje się [[G1380]] WTV-PAP-ASN **αυτοις** *autois* im [[G846]] WTP-DPM **επαιδευον** *epaideuon* karcili – dyscyplinowali [[G3811]] WTV-IAI-3P **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **επι** *epi* dla [[G1909]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **συμφερον** *symferon* będącej korzyścią [[G4851]] WTV-PAP-ASN **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **μεταλαβειν** *metalabein* być uczestnikami – otrzymać [[G3335]] [[V-2AAN]] **της** *tēs* [[G3588]] [[T-GSF]] **αγιοτητος** *hagiotētos* świętości [[G41]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Hbr 12,11**
 **πασα** *pasa* Każde [[G3956]] WTA-NSF **δε** *de* zaś [[G1161]] [[CONJ]] **παιδεια** *paideia* karcenie – karność [[G3809]] [[N-NSF]] **προς** *pros* względem [[G4314]] [[PREP]] **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **το** *to* (tego, co) [[G3588]] WTT-ASN **παρον** *paron* będące obecnym [[G3918]] WTV-PXP-ASN **ου** *ou* nie [[G3756]] [[PRT-N]] **δοκει** *dokei* zdaje się [[G1380]] WTV-PAI-3S **χαρας** *charas* radości [[G5479]] [[N-GSF]] **ειναι** *einai* być [[G1511]] WTV-PXN **αλλα** *alla* ale [[G235]] [[CONJ]] **λυπης** *lypēs* smutek [[G3077]] [[N-GSF]] **υστερον** *hysteron* później [[G5305]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **καρπον** *karpon* owoc [[G2590]] [[N-ASM]] **ειρηνικον** *eirēnikon* pokoju [[G1516]] WTA-ASF **τοις** *tois* (dla tych) [[G3588]] WTT-DPM **δι** *di* przez [[G1223]] [[PREP]] **αυτης** *autēs* nie [[G846]] [[P-GSF]] **γεγυμνασμενοις** *gegymnasmenois* którzy są wyćwiczeni [[G1128]] WTV-RPP-DPM **αποδιδωσιν** *apodidōsin* oddaje [[G591]] WTV-PAI-3S **δικαιοσυνης** *dikaiosynēs* sprawiedliwość [[G1343]] [[N-GSF]]
###### **Hbr 12,12**
 **διο** *dio* Dlatego [[G1352]] [[CONJ]] **τας** *tas* [[G3588]] WTT-APF **παρειμενας** *pareimenas* które są opadłe – które są opuszczone [[G3935]] WTV-RPP-APF **χειρας** *cheiras* ręce [[G5495]] WTN-APF **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **παραλελυμενα** *paralelymena* które są sparaliżowane – które są omdlałe [[G3886]] WTV-RPP-APN **γονατα** *gonata* kolana [[G1119]] WTN-APN **ανορθωσατε** *anorthōsate* wyprostujcie [[G461]] WTV-AAM-2P
###### **Hbr 12,13**
 **και** *kai* i [[G2532]] [[CONJ]] **τροχιας** *trochias* ścieżki [[G5163]] WTN-APF **ορθας** *orthas* proste – wyprostowane [[G3717]] WTA-APF **ποιησατε** *poiēsate* uczyńcie [[G4160]] WTV-AAM-2P **τοις** *tois* [[G3588]] WTT-DPM **ποσιν** *posin* stopami [[G4228]] WTN-DPM **υμων** *hymōn* waszymi [[G5216]] WTP-2GP **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **το** *to* [[G3588]] WTT-NSN **χωλον** *chōlon* kulawy – chromy [[G5560]] WTA-NSN **εκτραπη** *ektrapē* zostałby odwrócony [[G1624]] WTV-2APS-3S **ιαθη** *iathē* zostałby uzdrowiony – zostałby uleczony [[G2390]] WTV-APS-3S **δε** *de* zaś [[G1161]] [[CONJ]] **μαλλον** *mallon* bardziej [[G3123]] [[ADV]]
###### **Hbr 12,14**
 **ειρηνην** *eirēnēn* Pokój [[G1515]] WTN-ASF **διωκετε** *diōkete* ścigajcie – zabiegajcie o [[G1377]] WTV-PAM-2P **μετα** *meta* ze [[G3326]] [[PREP]] **παντων** *pantōn* wszystkimi [[G3956]] WTA-GPM **και** *kai* i [[G2532]] [[CONJ]] **τον** *ton* [[G3588]] [[T-ASM]] **αγιασμον** *hagiasmon* uświęcenie – poświęcenie [[G38]] [[N-ASM]] **ου** *hou* którego [[G3739]] WTR-GSM **χωρις** *chōris* bez [[G5565]] [[ADV]] **ουδεις** *oudeis* nikt [[G3762]] [[A-NSM]] **οψεται** *opsetai* zobaczy [[G3700]] WTV-FDI-3S **τον** *ton* [[G3588]] [[T-ASM]] **κυριον** *kyrion* Pana [[G2962]] [[N-ASM]]
###### **Hbr 12,15**
 **επισκοπουντες** *episkopountes* doglądając – dozorując [[G1983]] WTV-PAP-NPM **μη** *mē* aby nie [[G3361]] [[PRT-N]] **τις** *tis* ktoś [[G5100]] WTX-NSM **υστερων** *hysterōn* mający braki [[G5302]] [[V-PAP-NSM]] **απο** *apo* z dala od [[G575]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **χαριτος** *charitos* łaski [[G5485]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **μη** *mē* aby nie [[G3361]] [[PRT-N]] **τις** *tis* jakiś [[G5100]] WTX-NSF **ριζα** *riza* korzeń [[G4491]] [[N-NSF]] **πικριας** *pikrias* goryczy – gorzkości [[G4088]] [[N-GSF]] **ανω** *anō* w górę – wzwyż [[G507]] [[ADV]] **φυουσα** *fyousa* rosnąc [[G5453]] [[V-PAP-NSF]] **ενοχλη** *enochlē* wywołałby niepokój [[G1776]] WTV-PAS-3S **και** *kai* i [[G2532]] [[CONJ]] **δια** *dia* przez [[G1223]] [[PREP]] **ταυτης** *tautēs* to [[G3778]] WTD-GSF **μιανθωσιν** *mianthōsin* zostaliby skalani – zostaliby zanieczyszczeni [[G3392]] WTV-APS-3P **πολλοι** *polloi* liczni – wielu [[G4183]] WTA-NPM
###### **Hbr 12,16**
 **μη** *mē* aby nie [[G3361]] [[PRT-N]] **τις** *tis* ktoś [[G5100]] WTX-NSM **πορνος** *pornos* rozpustnik – wszetecznik [[G4205]] [[N-NSM]] **η** *ē* lub [[G2228]] WTPRT **βεβηλος** *bebēlos* profanujący [[G952]] [[A-NSM]] **ως** *hōs* jak [[G5613]] [[ADV]] **ησαυ** *ēsau* Ezaw – [owłosiony] [[G2269]] [[N-PRI]] **ος** *hos* który [[G3739]] WTR-NSM **αντι** *anti* za [[G473]] [[PREP]] **βρωσεως** *brōseōs* pokarm [[G1035]] [[N-GSF]] **μιας** *mias* jeden [[G1520]] WTA-GSF **απεδοτο** *apedoto* oddał [[G591]] WTV-2AMI-3S **τα** *ta* [[G3588]] WTT-APN **πρωτοτοκια** *prōtotokia* pierworództwo [[G4415]] WTN-APN **αυτου** *autou* swoje [[G846]] [[P-GSM]]
###### **Hbr 12,17**
 **ιστε** *iste* Wiedzcie [[G2467]] WTV-RAM-2P **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **οτι** *hoti* że [[G3754]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **μετεπειτα** *metepeita* potem – później [[G3347]] [[ADV]] **θελων** *thelōn* chcąc [[G2309]] [[V-PAP-NSM]] **κληρονομησαι** *klēronomēsai* odziedziczyć – dostać w udziale [[G2816]] [[V-AAN]] **την** *tēn* [[G3588]] WTT-ASF **ευλογιαν** *eulogian* błogosławieństwo – wysławienie [[G2129]] WTN-ASF **απεδοκιμασθη** *apedokimasthē* został odrzucony – nie został zaakceptowany [[G593]] [[V-API-3S]] **μετανοιας** *metanoias* nawrócenia – zmiany myślenia [[G3341]] [[N-GSF]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **τοπον** *topon* miejsca [[G5117]] [[N-ASM]] **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **ευρεν** *heuren* znalazł [[G2147]] WTV-2AAI-3S **καιπερ** *kaiper* chociaż [[G2539]] [[CONJ]] **μετα** *meta* ze [[G3326]] [[PREP]] **δακρυων** *dakryōn* łzami [[G1144]] WTN-GPN **εκζητησας** *ekzētēsas* poszukawszy – (o) które zabiegał [[G1567]] WTV-AAP-NSM **αυτην** *autēn* je [[G846]] [[P-ASF]]
###### **Hbr 12,18**
 **ου** *ou* Nie [[G3756]] [[PRT-N]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **προσεληλυθατε** *proselēlythate* podeszliście do – zbliżyliście się do [[G4334]] WTV-2RAI-2P **ψηλαφωμενω** *psēlafōmenō* dającemu się dotknąć – dającemu się pomacać [[G5584]] WTV-PPP-DSN **ορει** *orei* (ku) górze [[G3735]] WTN-DSN **και** *kai* i [[G2532]] [[CONJ]] **κεκαυμενω** *kekaumenō* zapalającemu się [[G2545]] WTV-RPP-DSN **πυρι** *pyri* ogniowi [[G4442]] WTN-DSN **και** *kai* i [[G2532]] [[CONJ]] **γνοφω** *gnofō* mroku [[G1105]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **σκοτω** *skotō* ciemności [[G4655]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **θυελλη** *thyellē* nawałnicy – burzy [[G2366]] [[N-DSF]]
###### **Hbr 12,19**
 **και** *kai* i [[G2532]] [[CONJ]] **σαλπιγγος** *salpingos* trąby [[G4536]] [[N-GSF]] **ηχω** *ēchō* dźwięku [[G2279]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **φωνη** *fōnē* głosu [[G5456]] [[N-DSF]] **ρηματων** *rēmatōn* wypowiedzi [[G4487]] WTN-GPN **ης** *hēs* który [[G3739]] [[R-GSF]] **οι** *hoi* [[G3588]] WTT-NPM **ακουσαντες** *akousantes* usłyszawszy [[G191]] WTV-AAP-NPM **παρητησαντο** *parētēsanto* odrzucili od siebie – odsunęli od siebie [[G3868]] WTV-ADI-3P **μη** *mē* aby nie [[G3361]] [[PRT-N]] **προστεθηναι** *prostethēnai* zostać przedłożone – zostać dołożone [[G4369]] WTV-APN **αυτοις** *autois* im [[G846]] WTP-DPM **λογον** *logon* słowo [[G3056]] [[N-ASM]]
###### **Hbr 12,20**
 **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εφερον** *eferon* zanosili [[G5342]] WTV-IAI-3P **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **το** *to* (tego) [[G3588]] WTT-ASN **διαστελλομενον** *diastellomenon* co jest przekazane – co jest postanowione [[G1291]] WTV-PPP-ASN **καν** *kan* i jeśli [[G2579]] WTCOND-C **θηριον** *thērion* zwierzę [[G2342]] WTN-NSN **θιγη** *thigē* dotknęłoby się [[G2345]] WTV-2AAS-3S **του** *tou* [[G3588]] WTT-GSN **ορους** *orous* góry [[G3735]] [[N-GSN]] **λιθοβοληθησεται** *lithobolēthēsetai* zostanie ukamienowane [[G3036]] WTV-FPI-3S **η** *hē* albo [[G2228]] WTPRT **βολιδι** *bolidi* pociskiem – oszczepem [[G1002]] [[N-DSF]] **κατατοξευθησεται** *katatokseuthēsetai* zostanie przebite [[G2700]] WTV-FPI-3S
###### **Hbr 12,21**
 **και** *kai* i [[G2532]] [[CONJ]] **ουτως** *houtōs* tak [[G3779]] [[ADV]] **φοβερον** *foberon* straszne – napawające bojaźnią [[G5398]] WTA-NSN **ην** *ēn* było [[G2258]] [[V-IXI-3S]] **το** *to* (to) [[G3588]] WTT-NSN **φανταζομενον** *fantazomenon* które jest pokazane [[G5324]] WTV-PPP-NSN **μωσης** *mōsēs* Mojżesz – [wyciągnąć] [[G3475]] [[N-NSM]] **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **εκφοβος** *ekfobos* bardzo przestraszony – napełniony bojaźnią [[G1630]] [[A-NSM]] **ειμι** *eimi* jestem [[G1510]] WTV-PXI-1S **και** *kai* i [[G2532]] [[CONJ]] **εντρομος** *entromos* drżący [[G1790]] [[A-NSM]]
###### **Hbr 12,22**
 **αλλα** *alla* Ale [[G235]] [[CONJ]] **προσεληλυθατε** *proselēlythate* podeszliście ku – zbliżyliście się ku [[G4334]] WTV-2RAI-2P **σιων** *siōn* Syjonowi – [wysoki] [[G4622]] [[N-PRI]] **ορει** *orei* górze [[G3735]] WTN-DSN **και** *kai* i [[G2532]] [[CONJ]] **πολει** *polei* miastu [[G4172]] [[N-DSF]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ζωντος** *zōntos* żyjącego [[G2198]] WTV-PAP-GSM **ιερουσαλημ** *ierousalēm* Jeruzalem – [dziedzictwo pokoju] [[G2419]] [[N-PRI]] **επουρανιω** *epouraniō* niebiańskiemu [[G2032]] WTA-DSF **και** *kai* i [[G2532]] [[CONJ]] **μυριασιν** *myriasin* dziesiątkom tysięcy – miriad [[G3461]] WTA-DPM **αγγελων** *angelōn* zwiastunów [[G32]] WTN-GPM
###### **Hbr 12,23**
 **πανηγυρει** *panēgyrei* zgromadzenia ogólnego – zgromadzenia uroczystego [[G3831]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **εκκλησια** *ekklēsia* zgromadzenia – (społeczności) wywołanych [[G1577]] [[N-DSF]] **πρωτοτοκων** *prōtotokōn* pierworodnych [[G4416]] WTA-GPM **εν** *en* w [[G1722]] [[PREP]] **ουρανοις** *ouranois* niebiosach [[G3772]] WTN-DPM **απογεγραμμενων** *apogegrammenōn* którzy są zapisani [[G583]] WTV-RPP-GPM **και** *kai* i [[G2532]] [[CONJ]] **κριτη** *kritē* sędziemu [[G2923]] WTN-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **παντων** *pantōn* wszystkich [[G3956]] WTA-GPM **και** *kai* i [[G2532]] [[CONJ]] **πνευμασιν** *pneumasin* duchom [[G4151]] WTN-DPN **δικαιων** *dikaiōn* sprawiedliwych [[G1342]] WTA-GPM **τετελειωμενων** *teteleiōmenōn* które są uczynione doskonałymi – które są doprowadzone do doskonałości [[G5048]] WTV-RPP-GPM
###### **Hbr 12,24**
 **και** *kai* i [[G2532]] [[CONJ]] **διαθηκης** *diathēkēs* przymierza [[G1242]] [[N-GSF]] **νεας** *neas* nowego [[G3501]] WTA-GSF **μεσιτη** *mesitē* pośrednikowi [[G3316]] WTN-DSM **ιησου** *iēsou* Jezusowi – [JHWH jest zbawieniem] [[G2424]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **αιματι** *haimati* krwi [[G129]] WTN-DSN **ραντισμου** *rantismou* pokropienia [[G4473]] [[N-GSM]] **κρειττονα** *kreittona* lepiej – znaczniej [[G2909]] WTA-APN **λαλουντι** *lalounti* mówiącej [[G2980]] WTV-PAP-DSM **παρα** *para* od [[G3844]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **αβελ** *abel* Abla – [tchnienie] [[G6]] [[N-PRI]]
###### **Hbr 12,25**
 **βλεπετε** *blepete* Uważajcie – Patrzcie [[G991]] WTV-PAM-2P **μη** *mē* aby nie [[G3361]] [[PRT-N]] **παραιτησησθε** *paraitēsēsthe* odrzucilibyście od siebie – odsunęlibyście od siebie [[G3868]] WTV-ADS-2P **τον** *ton* (Tego) [[G3588]] [[T-ASM]] **λαλουντα** *lalounta* który mówi [[G2980]] WTV-PAP-ASM **ει** *ei* jeśli [[G1487]] WTCOND **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εκεινοι** *ekeinoi* oni [[G1565]] WTD-NPM **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εφυγον** *efygon* uciekli – wymknęli się [[G5343]] WTV-2AAI-3P **τον** *ton* [[G3588]] [[T-ASM]] **επι** *epi* na [[G1909]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]] **παραιτησαμενοι** *paraitēsamenoi* odrzuciwszy – odsunąwszy się od [[G3868]] WTV-ADP-NPM **χρηματιζοντα** *chrēmatizonta* który jest ostrzegającym – otrzymującego wyrocznię [[G5537]] WTV-PAP-ASM **πολλω** *pollō* wiele [[G4183]] WTA-DSN **μαλλον** *mallon* bardziej [[G3123]] [[ADV]] **ημεις** *hēmeis* my [[G2249]] WTP-1NP **οι** *hoi* [[G3588]] WTT-NPM **τον** *ton* [[G3588]] [[T-ASM]] **απ** *ap* od [[G575]] [[PREP]] **ουρανων** *ouranōn* niebios [[G3772]] WTN-GPM **αποστρεφομενοι** *apostrefomenoi* którzy odwracamy się [[G654]] WTV-PMP-NPM
###### **Hbr 12,26**
 **ου** *hou* którego [[G3739]] WTR-GSM **η** *hē* [[G3588]] [[T-NSF]] **φωνη** *fōnē* głos [[G5456]] [[N-NSF]] **την** *tēn* [[G3588]] WTT-ASF **γην** *gēn* ziemią [[G1093]] WTN-ASF **εσαλευσεν** *esaleusen* wstrząsnął – zachwiał [[G4531]] [[V-AAI-3S]] **τοτε** *tote* wtedy [[G5119]] [[ADV]] **νυν** *nyn* teraz [[G3568]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **επηγγελται** *epēngeltai* obiecał [[G1861]] WTV-RNI-3S **λεγων** *legōn* mówiąc [[G3004]] [[V-PAP-NSM]] **ετι** *eti* jeszcze [[G2089]] [[ADV]] **απαξ** *hapaks* raz [[G530]] [[ADV]] **εγω** *egō* Ja [[G1473]] WTP-1NS **σειω** *seiō* poruszę – wstrząsnę [[G4579]] WTV-PAI-1S **ου** *ou* nie [[G3756]] [[PRT-N]] **μονον** *monon* jedynie – tylko [[G3440]] [[ADV]] **την** *tēn* [[G3588]] WTT-ASF **γην** *gēn* ziemią [[G1093]] WTN-ASF **αλλα** *alla* ale [[G235]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **τον** *ton* [[G3588]] [[T-ASM]] **ουρανον** *ouranon* niebem [[G3772]] [[N-ASM]]
###### **Hbr 12,27**
 **το** *to* [[G3588]] WTT-NSN **δε** *de* zaś [[G1161]] [[CONJ]] **ετι** *eti* jeszcze [[G2089]] [[ADV]] **απαξ** *hapaks* raz [[G530]] [[ADV]] **δηλοι** *dēloi* oznajmia – ujawnia [[G1213]] WTV-PAI-3S **των** *tōn* [[G3588]] WTT-GPN **σαλευομενων** *saleuomenōn* które są wstrząśnięte – które są zachwiane [[G4531]] WTV-PPP-GPN **την** *tēn* [[G3588]] WTT-ASF **μεταθεσιν** *metathesin* przemieszczenie [[G3331]] WTN-ASF **ως** *hōs* jak [[G5613]] [[ADV]] **πεποιημενων** *pepoiēmenōn* które są uczynione [[G4160]] WTV-RPP-GPM **ινα** *hina* aby [[G2443]] [[CONJ]] **μεινη** *meinē* trwałby – pozostałby [[G3306]] WTV-AAS-3S **τα** *ta* [[G3588]] WTT-NPN **μη** *mē* nie [[G3361]] [[PRT-N]] **σαλευομενα** *saleuomena* które są wstrząśnięte – które są zachwiane [[G4531]] WTV-PPP-NPN
###### **Hbr 12,28**
 **διο** *dio* Dlatego [[G1352]] [[CONJ]] **βασιλειαν** *basileian* królestwo [[G932]] WTN-ASF **ασαλευτον** *asaleuton* niewzruszone – niezachwiane [[G761]] WTA-ASF **παραλαμβανοντες** *paralambanontes* przyjmując [[G3880]] WTV-PAP-NPM **εχωμεν** *echōmen* mielibyśmy [[G2192]] WTV-PAS-1P **χαριν** *charin* łaskę [[G5485]] WTN-ASF **δι** *di* przez [[G1223]] [[PREP]] **ης** *hēs* którą [[G3739]] [[R-GSF]] **λατρευωμεν** *latreuōmen* służylibyśmy [[G3000]] WTV-PAS-1P **ευαρεστως** *euarestōs* w sposób miły – w sposób bardzo podobający się [[G2102]] [[ADV]] **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **μετα** *meta* ze [[G3326]] [[PREP]] **αιδους** *aidous* skromnością – wstydliwością [[G127]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **ευλαβειας** *eulabeias* czcią – pobożnością [[G2124]] [[N-GSF]]
###### **Hbr 12,29**
 **και** *kai* a [[G2532]] [[CONJ]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ημων** *hēmōn* nasz [[G2257]] WTP-1GP **πυρ** *pyr* ogień [[G4442]] WTN-NSN **καταναλισκον** *katanaliskon* trawiący [[G2654]] WTV-PAP-NSN
