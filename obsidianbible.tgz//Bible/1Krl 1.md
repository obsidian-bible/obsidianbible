# 1Krl 1 BT5
###### **1Krl 1,1**
 Z biegiem czasu stary król Dawid tak się posunął w latach, że nie mógł się rozgrzać, choć okrywano go kocami.
###### **1Krl 1,2**
 Wówczas powiedzieli mu jego słudzy: «***Trzeba, aby wyszukano panu memu, królowi, młodą dziewicę, a ona będzie przy królu czuwać i mieć o niego staranie. I będzie spała na twym łonie, a przez to ogrzewała pana mego, króla***».
###### **1Krl 1,3**
 Szukano więc pięknej dziewczyny w całym kraju izraelskim, aż wreszcie znaleziono Szunemitkę Abiszag i przyprowadzono ją do króla.
###### **1Krl 1,4**
 Dziewczyna ta była nadzwyczaj piękna. Choć miała staranie o króla i obsługiwała go, król się do niej nie zbliżył.
###### **1Krl 1,5**
 Wtedy Adoniasz, syn Chaggity, zaczął się wynosić, mówiąc: «***Ja będę królować***». Dlatego zaopatrzył się w rydwan, jezdnych i pięćdziesięciu gońców, którzy go poprzedzali.
###### **1Krl 1,6**
 Jego ojciec zaś nigdy go nie karcił, mówiąc: «***Czemu tak uczyniłeś?***», gdyż był on nadzwyczajnej urody, a matka urodziła go po Absalomie.
###### **1Krl 1,7**
 Adoniasz namówił Joaba, syna Serui, i kapłana Abiatara, aby mu pomagali.
###### **1Krl 1,8**
 Ale ani kapłan Sadok, ani Benajasz, syn Jojady, ani prorok Natan, ani Szimei, ani Rei, ani bohaterowie Dawida nie sprzyjali Adoniaszowi.
###### **1Krl 1,9**
 Potem Adoniasz zabił na ofiarę owce, woły i tuczne cielce przy kamieniu Zochelet u źródła Rogel i zaprosił wszystkich swych braci, synów królewskich, oraz wszystkich ludzi z Judy, sługi króla.
###### **1Krl 1,10**
 Lecz nie zaprosił proroka Natana ani Benajasza, ani bohaterów, ani swego brata, Salomona.
###### **1Krl 1,11**
 Wtedy Natan zapytał Batszebę, matkę Salomona: «***Czy nie słyszałaś, że zaczął królować Adoniasz, syn Chaggity? A pan nasz, Dawid, o tym nie wie!***
###### **1Krl 1,12**
 ***Wobec tego działaj! Chcę ci dać radę, abyś ocaliła swoje życie i życie twego syna, Salomona:***
###### **1Krl 1,13**
 ***Idź i wejdź do króla Dawida; wtedy powiesz mu: Czy ty, panie mój, królu, nie przysiągłeś twej służebnicy, mówiąc: Twój syn, Salomon, będzie po mnie królował i on będzie zasiadał na moim tronie? Dlaczego więc króluje Adoniasz?***
###### **1Krl 1,14**
 ***Kiedy zaś jeszcze będziesz tam mówić z królem, ja za tobą wejdę i słowa twoje uzupełnię***».
###### **1Krl 1,15**
 Weszła więc Batszeba do sypialni bardzo już podeszłego w latach króla, w obecności Szunemitki Abiszag posługującej królowi.
###### **1Krl 1,16**
 Następnie Batszeba uklękła i oddała pokłon królowi, a król ją zapytał: «***Czego chcesz?***»
###### **1Krl 1,17**
 Wtedy odrzekła mu: «***Panie mój! Tyś poprzysiągł twojej służebnicy na Pana, Boga twego: Salomon, twój syn, będzie królował po mnie i on będzie zasiadał na moim tronie.***
###### **1Krl 1,18**
 ***A oto teraz Adoniasz stał się królem! A ty, panie mój, królu, nic o tym nie wiesz.***
###### **1Krl 1,19**
 ***Zabił on na ofiarę woły, tuczne cielce i mnóstwo owiec oraz zaprosił wszystkich synów królewskich, kapłana Abiatara i wodza wojska, Joaba. Salomona zaś, sługi twego, nie zaprosił.***
###### **1Krl 1,20**
 ***A tyś, panie mój, królem! Na ciebie zwrócone są oczy całego Izraela, abyś im oznajmił, kto będzie zasiadać na tronie pana mego, króla, po nim.***
###### **1Krl 1,21**
 ***Kiedy przyjdzie czas, że król, mój pan, spocznie ze swymi przodkami, wtedy ja i mój syn, Salomon, będziemy uchodzili za winowajców***».
###### **1Krl 1,22**
 A oto, gdy jeszcze mówiła z królem, przyszedł prorok Natan.
###### **1Krl 1,23**
 Natychmiast oznajmiono królowi, mówiąc: «***Oto prorok Natan***». I przyszedł on przed oblicze króla i oddał pokłon królowi aż do ziemi.
###### **1Krl 1,24**
 Po czym przemówił: «***Panie mój, królu! Ty zapewne rozkazałeś: Adoniasz będzie królował po mnie i on będzie zasiadał na moim tronie?***
###### **1Krl 1,25**
 ***Gdyż dziś poszedł i zabił na ofiarę woły, tuczne cielce i mnóstwo owiec oraz zaprosił wszystkich synów królewskich, dowódców wojska i kapłana Abiatara i oto oni jedzą i piją razem z nim oraz mówią: Niech żyje król Adoniasz!***
###### **1Krl 1,26**
 ***A mnie, twego sługi, ani kapłana Sadoka, ani Benajasza, syna Jojady, ani Salomona, twego sługi, nie zaprosił.***
###### **1Krl 1,27**
 ***Czy z woli króla, mego pana, to się stało, a nie zawiadomiłeś twego sługi, kto będzie zasiadał na tronie pana mego, króla, po nim?***»
###### **1Krl 1,28**
 Wówczas odezwał się król Dawid i rzekł: «***Zawołajcie mi Batszebę!***» A kiedy weszła do króla i stanęła przed nim,
###### **1Krl 1,29**
 przysiągł król tymi słowami: «***Na życie Pana, który wyratował mnie z wszelkiego utrapienia!***
###### **1Krl 1,30**
 ***Jak przysiągłem ci na Pana, Boga Izraela, mówiąc, że Salomon, twój syn, będzie królował po mnie i on będzie zasiadał na moim tronie po mnie, tak właśnie dziś uczynię***».
###### **1Krl 1,31**
 Wtedy Batszeba, padłszy twarzą do ziemi, oddała pokłon królowi oraz powiedziała: «***Niech żyje mój pan, król Dawid, na wieki!***»
###### **1Krl 1,32**
 Potem król Dawid rozkazał: «***Przywołajcie do mnie kapłana Sadoka, proroka Natana i Benajasza, syna Jojady***». Kiedy zaś weszli przed oblicze króla,
###### **1Krl 1,33**
 wydał im król rozkaz: «***Weźcie ze sobą sługi waszego pana, a następnie posadźcie Salomona, mego syna, na moją własną mulicę i prowadźcie go do Gichonu.***
###### **1Krl 1,34**
 ***Potem niech go tam namaszczą kapłan Sadok i prorok Natan na króla nad Izraelem. Następnie zadmijcie w róg i wołajcie: Niech żyje król Salomon!***
###### **1Krl 1,35**
 ***Potem pójdźcie za nim. On zaś, przyszedłszy, zasiądzie na moim tronie i on będzie królował po mnie, bo ja rozkazałem, aby był wodzem nad Izraelem i nad Judą***».
###### **1Krl 1,36**
 Na to Benajasz, syn Jojady, odrzekł królowi: «***Amen. Bodajby Pan Bóg to sprawił!***
###### **1Krl 1,37**
 ***Jak był Jahwe z panem moim, królem, tak niech będzie z Salomonem i niech wywyższy jego tron ponad tron króla Dawida, mego pana!***»
###### **1Krl 1,38**
 Poszedł więc kapłan Sadok i prorok Natan oraz Benajasz, syn Jojady, a także Keretyci i Peletyci, i wsadziwszy Salomona na mulicę króla Dawida, zaprowadzili go do Gichonu.
###### **1Krl 1,39**
 Tam kapłan Sadok wziął róg oliwy z Namiotu i namaścił Salomona. Wtedy zagrano na rogu, a cały lud zawołał: «***Niech żyje król Salomon!***»
###### **1Krl 1,40**
 Potem cały lud wszedł za nim na górę przy dźwięku fletów, okazując radość tak wielką, że aż ziemia drżała od ich okrzyków.
###### **1Krl 1,41**
 Usłyszał to Adoniasz oraz wszyscy zaproszeni, którzy z nim byli i właśnie przestali ucztować. Usłyszał też Joab dźwięk rogu i rzekł: «***Co znaczy ten zgiełk poruszonego miasta?***»
###### **1Krl 1,42**
 Gdy on jeszcze mówił, oto przyszedł Jonatan, syn kapłana Abiatara. Wtedy rzekł Adoniasz: «***Wejdź, boś człowiek dzielny i dobrą wieść oznajmisz***».
###### **1Krl 1,43**
 Jonatan zaś odrzekł Adoniaszowi: «***Raczej nie! Nasz pan, król Dawid, ogłosił królem Salomona***
###### **1Krl 1,44**
 ***i posłał z nim król kapłana Sadoka, proroka Natana i Benajasza, syna Jojady, oraz Keretytów i Peletytów, i wsadzili go na mulicę królewską.***
###### **1Krl 1,45**
 ***Potem kapłan Sadok i prorok Natan namaścili go na króla w Gichonie. Stamtąd wchodzili na gorę, radując się, i dlatego poruszyło się miasto, czego odgłos usłyszeliście.***
###### **1Krl 1,46**
 ***A także Salomon zasiadł już na tronie królestwa.***
###### **1Krl 1,47**
 ***Ponadto przyszli słudzy króla, aby błogosławić naszego pana, króla Dawida, mówiąc: Niech twój Bóg imię Salomona uczyni sławniejszym niż imię twoje i wywyższy jego tron ponad twój tron! Po czym król oddał pokłon na swoim łożu***
###### **1Krl 1,48**
***i również król tak rzekł: Błogosławiony Pan, Bóg Izraela, który dał dziś moim oczom oglądać następcę, zasiadającego na moim tronie***».
###### **1Krl 1,49**
 Zadrżeli więc ze strachu wszyscy zaproszeni przez Adoniasza. Wstali i każdy poszedł swoją drogą.
###### **1Krl 1,50**
 Adoniasz też zląkł się Salomona, powstał i poszedł, a następnie uchwycił za rogi ołtarza.
###### **1Krl 1,51**
 Niebawem oznajmiono Salomonowi: «***Oto Adoniasz zląkł się króla Salomona i dlatego uchwycił za rogi ołtarza, mówiąc: Niech mi teraz król Salomon przysięgnie, że swego sługi nie każe zabić mieczem***».
###### **1Krl 1,52**
 Wówczas Salomon rzekł: «***Jeśli będzie uczciwy, nie spadnie mu włos z głowy, ale jeśli znajdzie się w nim wina, to zginie***».
###### **1Krl 1,53**
 Następnie król Salomon posłał, aby go sprowadzono od ołtarza. Kiedy zaś przyszedł i oddał pokłon królowi Salomonowi, rzekł do niego Salomon: «***Idź do swego domu!***»
# 1Krl 1 PAU
###### **1Krl 1,1**
 Król Dawid był już stary i bardzo niedołężny. Mimo okryć, którymi go otulano, nie mógł się rozgrzać.
###### **1Krl 1,2**
 Jego słudzy poradzili mu wówczas: „Należy wyszukać naszemu panu, królowi, młodą dziewczynę, dziewicę, która by mu usługiwała, pielęgnowała go i spała z nim, a wtedy nasz pan, król, będzie mógł się rozgrzać”.
###### **1Krl 1,3**
 W całym Izraelu szukano pięknej dziewczyny, aż znaleziono Szunemitkę Abiszag, którą przyprowadzono do króla.
###### **1Krl 1,4**
 Dziewczyna była nadzwyczaj piękna. Pielęgnowała króla i usługiwała mu, lecz król nie współżył z nią.
###### **1Krl 1,5**
 Wtedy Adoniasz, syn Chaggity, zaczął się wywyższać i mówić: „Ja będę królem”. Sprawił sobie rydwany, konie i straż przyboczną złożoną z pięćdziesięciu ludzi, którzy mu wszędzie towarzyszyli.
###### **1Krl 1,6**
 Jego ojciec nigdy go nie upomniał: „Dlaczego tak się zachowujesz?”, ponieważ Adoniasz był wyjątkowo przystojny i urodził się zaraz po Absalomie.
###### **1Krl 1,7**
 Adoniasz przeprowadził rozmowy z Joabem, synem Serui, i Abiatarem, kapłanem, którzy udzielili mu swojego poparcia.
###### **1Krl 1,8**
 Natomiast kapłan Sadok, Benajasz, syn Jojady, i prorok Natan oraz Szimei i Rei, a także dowódcy Dawida nie przyłączyli się do Adoniasza.
###### **1Krl 1,9**
 Adoniasz złożył wtedy w ofierze owce, woły i utuczone cielce przy kamieniu Zochelet, blisko źródła Rogel. Zaprosił tam wszystkich swoich braci, synów królewskich i wszystkich przedstawicieli Judy, będących urzędnikami króla.
###### **1Krl 1,10**
 Ale proroka Natana, Benajasza i dowódców wojska oraz swojego brata Salomona nie zaprosił.
###### **1Krl 1,11**
 Wówczas prorok Natan zapytał Batszebę, matkę Salomona: „Czy nie słyszałaś, że Adoniasz, syn Chaggity, ogłosił się królem, a nasz pan, Dawid, nic o tym nie wie?
###### **1Krl 1,12**
 Chodź, udzielę ci rady, jak masz uratować siebie i swojego syna, Salomona.
###### **1Krl 1,13**
 Idź do króla Dawida i zapytaj go: «Panie mój, królu, czyż nie ty właśnie obiecałeś swojej służebnicy pod przysięgą: Salomon, twój syn, będzie po mnie królem i zasiądzie na moim tronie. Dlaczego więc zaczął królować Adoniasz?».
###### **1Krl 1,14**
 Kiedy jeszcze będziesz rozmawiać z królem, ja sam wejdę za tobą i potwierdzę twoje słowa”.
###### **1Krl 1,15**
 Batszeba poszła więc do sypialni króla. Bardzo niedołężnemu już królowi usługiwała Szunemitka Abiszag.
###### **1Krl 1,16**
 Batszeba oddała królowi głęboki pokłon, a on ją zapytał: „Czego sobie życzysz?”.
###### **1Krl 1,17**
 Odpowiedziała mu: „Panie mój, ty obiecałeś swojej służebnicy, przysięgając na PANA, twego Boga: «Salomon, twój syn, będzie po mnie królem i zasiądzie na moim tronie».
###### **1Krl 1,18**
 Teraz Adoniasz zaczął królować, a ty, panie mój, królu, nawet o tym nie wiesz.
###### **1Krl 1,19**
 Złożył on w ofierze ogromne ilości wołów, utuczonych cielców i owiec. Zaprosił wszystkich synów królewskich, kapłana Abiatara oraz Joaba, dowódcę armii; twego zaś sługi Salomona nie zaprosił.
###### **1Krl 1,20**
 A teraz na ciebie, mój panie, królu, patrzy cały Izrael, abyś sam powiedział, kto będzie następcą tronu po tobie, panie mój, królu.
###### **1Krl 1,21**
 Kiedy mój pan, król, spocznie obok swych przodków, wówczas ja i mój syn, Salomon, będziemy uznani za winnych”.
###### **1Krl 1,22**
 Gdy rozmawiała jeszcze z królem, przybył prorok Natan.
###### **1Krl 1,23**
 Powiadomiono króla: „Prorok Natan czeka”. Kiedy Natan stanął przed królem, oddał pokłon twarzą do ziemi
###### **1Krl 1,24**
 i przemówił: „Panie mój, królu, pewnie ty powiedziałeś: «Adoniasz będzie królem po mnie i zasiądzie na moim tronie», nieprawdaż?
###### **1Krl 1,25**
 Bo poszedł on dzisiaj i złożył w ofierze ogromne ilości wołów, utuczonych cielców i owiec. Co więcej, zaprosił na ucztę wszystkich synów królewskich, dowódcę armii i kapłana Abiatara. Teraz z nim ucztują i wołają: «Niech żyje król Adoniasz!».
###### **1Krl 1,26**
 Natomiast mnie, twego sługi, kapłana Sadoka i Benajasza, syna Jojady, a także Salomona, twego sługi, nie zaprosił.
###### **1Krl 1,27**
 Czy stało się to na rozkaz mojego pana, króla? Nie powiadomiłeś jednak twego sługi, kto będzie następcą tronu po tobie, panie, mój królu”.
###### **1Krl 1,28**
 Na to król Dawid odpowiedział: „Wezwijcie do mnie Batszebę”. Przyszła więc do króla i stanęła przed nim.
###### **1Krl 1,29**
 Wtedy król przysiągł: „Na życie PANA, który mnie ocalił z wszelkiego niebezpieczeństwa,
###### **1Krl 1,30**
 dzisiaj właśnie spełnię to, co ci przysiągłem na PANA, Boga Izraela, że twój syn Salomon będzie moim następcą i zasiądzie na moim tronie”.
###### **1Krl 1,31**
 Batszeba oddała królowi pokłon twarzą do ziemi i powiedziała: „Niech żyje na wieki mój Pan, król Dawid!”.
###### **1Krl 1,32**
 Zaraz potem król Dawid polecił: „Wezwijcie do mnie kapłana Sadoka, proroka Natana i Benajasza, syna Jojady”. Kiedy stawili się przed królem,
###### **1Krl 1,33**
 wydał im rozkaz: „Weźcie ze sobą gwardię królewską, posadźcie Salomona, mojego syna, na moją własną mulicę i zaprowadźcie go do źródła Gichon.
###### **1Krl 1,34**
 Tam kapłan Sadok i prorok Natan namaszczą go na króla nad Izraelem. Potem zagrajcie na trąbie i wołajcie: «Niech żyje król Salomon!».
###### **1Krl 1,35**
 Kiedy powróci z wami w orszaku, zasiądzie na moim tronie i będzie moim następcą. Jemu bowiem rozkazałem, żeby był przywódcą Izraela i Judy”.
###### **1Krl 1,36**
 Wówczas Benajasz, syn Jojady, powiedział: „Niech się tak stanie! Niech to potwierdzi sam PAN, Bóg mojego pana, króla!
###### **1Krl 1,37**
 Jak PAN był z moim panem, królem, tak niech będzie z Salomonem. Niech wyniesie jego tron ponad tron mojego pana, króla Dawida!”.
###### **1Krl 1,38**
 Kapłan Sadok, prorok Natan i Benajasz, syn Jojady, oraz Keretyci i Peletyci poszli i posadzili Salomona na mulicę króla Dawida i zaprowadzili go do źródła Gichon.
###### **1Krl 1,39**
 Kapłan Sadok wziął róg oliwy z Namiotu i namaścił Salomona. Zagrano na trąbie, a cały lud zawołał: „Niech żyje król Salomon!”.
###### **1Krl 1,40**
 Cały lud szedł za nim, a od dźwięku fletów i okrzyków radości aż ziemia drżała.
###### **1Krl 1,41**
 Usłyszał to Adoniasz razem z zaproszonymi gośćmi, gdyż właśnie zakończono ucztę. Joab zaś, słysząc głos trąby, zawołał: „Skąd te okrzyki w mieście?”.
###### **1Krl 1,42**
 Nie skończył jeszcze mówić, gdy zjawił się Jonatan, syn kapłana Abiatara. „Wejdź - zaprosił go Adoniasz. - Jesteś przecież poważnym człowiekiem i przynosisz dobrą nowinę”.
###### **1Krl 1,43**
 „Wprost przeciwnie! - odparł Jonatan Adoniaszowi. - Nasz pan, król Dawid, ustanowił królem Salomona.
###### **1Krl 1,44**
 Posłał go z kapłanem Sadokiem, prorokiem Natanem i Benajaszem, synem Jojady, z gwardią Keretytów i Peletytów. Posadzili go na mulicę króla,
###### **1Krl 1,45**
 a kapłan Sadok i prorok Natan namaścili go na króla przy źródle Gichon. Następnie wyruszyli stamtąd z okrzykami radości i powstała wrzawa w mieście. Jej odgłos usłyszeliście.
###### **1Krl 1,46**
 Co więcej, Salomon zasiadł już na tronie królewskim,
###### **1Krl 1,47**
 a królewscy urzędnicy przybyli do naszego pana, króla Dawida, złożyć mu życzenia: «Niech Bóg da większą sławę Salomonowi niż tobie, niech wyniesie jego tron ponad twój tron!». Następnie król oddał pokłon na swoim łóżku
###### **1Krl 1,48**
 i powiedział: «Błogosławiony PAN, Bóg Izraela, który pozwolił mi dzisiaj oglądać mojego następcę zasiadającego na moim tronie»”.
###### **1Krl 1,49**
 Strach ogarnął wszystkich gości Adoniasza, szybko się więc rozeszli, każdy w swoją stronę.
###### **1Krl 1,50**
 Adoniasz zląkł się Salomona i szukał ratunku, chwytając się rogów ołtarza.
###### **1Krl 1,51**
 Przekazano więc Salomonowi wiadomość: „Adoniasz, lękając się króla Salomona, chwycił się rogów ołtarza i prosi: «Niech król Salomon mi dziś przysięgnie, że nie każe zabić swojego sługi mieczem»”.
###### **1Krl 1,52**
 Salomon wtedy oświadczył: „Jeśli okaże się człowiekiem uczciwym, włos mu z głowy nie spadnie, jeśli natomiast będzie coś knuł, umrze!”.
###### **1Krl 1,53**
 Polecił zatem Salomon, żeby go sprowadzono od ołtarza. Przyszedł i oddał głęboki pokłon królowi Salomonowi, a on mu rozkazał: „Wracaj do swojego domu!”.
# 1Krl 1 BP
###### **1Krl 1,1**
 Król Dawid był starcem w podeszłym wieku. Okrywano go szatami, ale mimo to nie było mu ciepło.
###### **1Krl 1,2**
 Rzekli mu więc jego słudzy: Trzeba, aby poszukano dla króla pana młodą dziewczynę, dziewicę, ażeby służyła królowi i aby go pielęgnowała. Będzie się kłaść na twoim łonie i będzie ciepło królowi panu.
###### **1Krl 1,3**
 Szukano więc pięknego dziewczęcia po całej ziemi izraelskiej i znaleziono Abiszag Szunamitkę. Wprowadzono ją do króla.
###### **1Krl 1,4**
 Dziewczę to było bardzo piękne. Pielęgnowała tedy króla i służyła mu. A król jej nie poznał.
###### **1Krl 1,5**
 Adonijja, syn Chaggity, przechwalał się mówiąc: Ja zostanę królem. Nabył sobie rydwan i jeźdźców oraz pięćdziesięciu ludzi, którzy biegli przed nim.
###### **1Krl 1,6**
 Ojciec za swego życia nie zganił go i nie powiedział: "Dlaczego tak postąpiłeś?" On także miał bardzo piękną postawę. [Chaggita] urodziła go po Abszalomie.
###### **1Krl 1,7**
 Przeprowadził on rozmowy z Joabem, synem Cerui, oraz kapłanem Ebjatarem i [ci] opowiedzieli się za Adonijja.
###### **1Krl 1,8**
 Ale kapłan Cadok, Benajahu, syn Jehojady, prorok Natan, Szimi, Rei i bohaterzy Dawida nie popierali Adonijji.
###### **1Krl 1,9**
 [Toteż gdy] Adonijja składał ofiary z trzody, bydła i tuczonych cielców przy kamieniu Zochelet, w pobliżu źródła Rogel, sprosił wszystkich swych braci, synów królewskich i wszystkich mężów Judy, dworzan królewskich.
###### **1Krl 1,10**
 Natomiast proroka Natana, Benajahu, bohaterów i brata swego Salomona nie zaprosił.
###### **1Krl 1,11**
 Natan powiedział do Batszeby, matki Salomona, te słowa: Czy nie słyszałaś, że Adonijja, syn Chaggity, został królem, a pan nasz Dawid [nic o tym] nie wie?
###### **1Krl 1,12**
 Chodź więc teraz. Pragnę udzielić ci rady, abyś mogła ocalić życie swoje i życie Salomona, twego syna.
###### **1Krl 1,13**
 Idź, udaj się do króla Dawida i powiedz mu: Panie mój, królu, czyż ty nie przysiągłeś służebnicy twojej mówiąc: "Salomon, syn twój, będzie królem po mnie i on zasiądzie na tronie moim". Dlaczegóż więc Adonijja został królem?
###### **1Krl 1,14**
 A oto, gdy ty tam będziesz jeszcze rozmawiała z królem, ja wejdę po tobie i potwierdzę twoje słowa.
###### **1Krl 1,15**
 Weszła więc Batszeba do komnaty królewskiej. Król był bardzo stary. Abiszag Szunamitka obsługiwała króla.
###### **1Krl 1,16**
 Batszeba uklękła i głęboko pokłoniła się królowi. Król zapytał: Czego żądasz?
###### **1Krl 1,17**
 Rzekła mu: Panie mój, ty przysiągłeś służebnicy twojej na Jahwe, twojego Boga: "Salomon, syn twój, będzie królem po mnie i on zasiądzie na moim tronie".
###### **1Krl 1,18**
 A oto teraz Adonijja jest królem, a ty, panie mój, królu, nie wiesz o tym.
###### **1Krl 1,19**
 Zabił na ofiarę woły, tuczone cielce i mnóstwo owiec oraz zaprosił wszystkich synów królewskich, kapłana Ebjatara, dowódcę wojska Joaba, ale sługi twojego Salomona nie zaprosił.
###### **1Krl 1,20**
 Tymczasem na ciebie, panie mój, królu [są zwrócone] oczy całego Izraela, abyś im oznajmił, kto będzie następcą tronu pana mojego, króla.
###### **1Krl 1,21**
 Gdy nadejdzie [czas], że pan mój, król, spocznie ze swoimi przodkami, ja i mój syn Salomon będziemy [uważani za] przestępców.
###### **1Krl 1,22**
 Gdy ona jeszcze rozmawiała z królem, przybył prorok Natan.
###### **1Krl 1,23**
 Oznajmiono więc królowi mówiąc: Oto prorok Natan. [Natan] wszedł przed oblicze króla i pokłonił się królowi głęboko twarzą ku ziemi
###### **1Krl 1,24**
 i zapytał: Panie mój, królu, [czy] ty zarządziłeś: "Adonijja będzie królem po mnie i on zasiądzie na moim tronie?"
###### **1Krl 1,25**
 Albowiem zstąpił dzisiaj, ofiarował woły, tuczone cielce oraz mnóstwo owiec i zaprosił wszystkich synów królewskich, dowódców wojska oraz kapłana Ebjatara. Oto jedzą oni i piją u niego i wznoszą okrzyki: Niech żyje król Adonijja.
###### **1Krl 1,26**
 Mnie, [który] jestem twoim sługą, kapłana Cadoka, Benajahu, syna Jehojady, i Salomona, twojego sługi, nie zaprosił.
###### **1Krl 1,27**
 Czyżby rzecz ta działa się za wiedzą pana mojego, króla. A [tylko] twojemu słudze nie chciałeś oznajmić, kto zasiądzie na tronie po panu moim, królu?
###### **1Krl 1,28**
 Odpowiadając król Dawid rzekł: Przywołajcie do mnie Batszebę. Weszła przed oblicze króla i stanęła przed królem.
###### **1Krl 1,29**
 Król przysiągł i rzekł: Na żyjącego Jahwe, który wyzwolił duszę moją od wszelkich utrapień.
###### **1Krl 1,30**
 Jak ci przysiągłem na Jahwe, Boga Izraela, mówiąc: Salomon, twój syn, będzie królem po mnie i on zasiądzie na moim tronie zamiast mnie, tak uczynię to dzisiaj.
###### **1Krl 1,31**
 Batszeba uklękła, głęboko pokłoniła się królowi twarzą ku ziemi i powiedziała: Niech żyje pan mój, król Dawid, na wieki.
###### **1Krl 1,32**
 Król Dawid rozkazał: Wezwijcie do mnie kapłana Cadoka, proroka Natana i Benajahu, syna Jehojady. Weszli przed oblicze króla,
###### **1Krl 1,33**
 a król polecił im: Weźcie z sobą dworzan pana waszego, posadźcie Salomona, syna mojego, na moją mulicę i sprowadźcie go do [źródła] Gichon.
###### **1Krl 1,34**
 Kapłan Cadok i prorok Natan niech go tam namaszczą na króla nad Izraelem. [Potem] zadmijcie w róg i wznieście okrzyk: Niech żyje król Salomon,
###### **1Krl 1,35**
 i idźcie za nim. Niech przyjdzie i usiądzie na moim tronie. On będzie królem po mnie. Jego ustanawiam, aby był zwierzchnikiem nad Izraelem i nad Judą.
###### **1Krl 1,36**
 Na to odpowiedział Benajahu, syn Jehojady, królowi i rzekł: Amen. Tak mówi Jahwe, Bóg pana mojego, króla.
###### **1Krl 1,37**
 Jak Jahwe był z panem moim, królem, tak niech będzie z Salomonem i niech [jeszcze] świetniejszym uczyni jego tron od tronu pana mojego, króla Dawida.
###### **1Krl 1,38**
 Kapłan Cadok, prorok Natan, Benajahu, syn Jehojady, Kereci i Peleci poszli, wsadzili Salomona na mulicę króla Dawida i sprowadzili go do [źródła] Gichon.
###### **1Krl 1,39**
 Kapłan Cadok wziął róg oliwy z Namiotu i namaścił Salomona. Zadęto w róg, a wszystek lud wydał okrzyk: Niech żyje król Salomon.
###### **1Krl 1,40**
 I szedł cały naród za nim. Ludzie grali na fletach i bardzo się radowali, [aż] ziemia drżała od ich okrzyków.
###### **1Krl 1,41**
 Usłyszeli [te okrzyki] Adonijja i wszyscy zaproszeni, którzy byli u niego, a skończyli właśnie ucztować. Joab posłyszał głos rogu i zapytał: Skąd ta wrzawa i poruszenie w mieście?
###### **1Krl 1,42**
 Gdy on jeszcze mówił, oto nadszedł Jonatan, syn kapłana Ebjatara. Zawołał więc Adonijja: Wejdź, boś jest mąż prawy i [zapewne] dobrą wieść przynosisz.
###### **1Krl 1,43**
 Odpowiadając Jonatan, rzekł do Adonijji: Niestety, pan nasz, król Dawid, ustanowił królem Salomona.
###### **1Krl 1,44**
 Król posłał z nim kapłana Cadoka, proroka Natana, Benajahu, syna Jehojady, Keretów i Peletów i wsadzili go na mulicę królewską.
###### **1Krl 1,45**
 [Następnie] kapłan Cadok i prorok Natan namaścili go na króla przy [źródle] Gichon i ciesząc się udali się stamtąd na górę. Miasto zaś jest poruszone [z radości]. Tę to właśnie wrzawę słyszeliście.
###### **1Krl 1,46**
 Salomon zasiadł już także na tronie królestwa.
###### **1Krl 1,47**
 Przyszli również dworzanie królewscy, aby błogosławić panu naszemu, królowi Dawidowi, mówiąc: "Niech Bóg twój sławniejszym uczyni imię Salomona, niż [było] imię twoje, i niech [jeszcze] świetniejszym uczyni jego tron od tronu twojego". A król głęboko się skłonił na swoim łożu.
###### **1Krl 1,48**
 Również sam król tak rzekł: "Niech będzie błogosławiony Jahwe, Bóg Izraela, który dał dziś następcę mojego tronu i [dozwolił, że] moje oczy [go] widzą".
###### **1Krl 1,49**
 Przerazili się wszyscy goście Adonijji. Powstali i poszli każdy w swoją stronę.
###### **1Krl 1,50**
 Adonijja zaś bojąc się Salomona wstał, poszedł i uchwycił się rogów ołtarza [całopalenia].
###### **1Krl 1,51**
 Doniesiono [o tym] Salomonowi mówiąc: Oto Adonijja boi się króla Salomona. Uchwycił się on rogów ołtarza, mówiąc: "Niech mi przysięgnie dzisiaj król Salomon, że nie zabije sługi swego mieczem".
###### **1Krl 1,52**
 Odpowiedział Salomon: Jeśli się okaże człowiekiem prawym, nie spadnie mu [jeden] włos [z głowy] na ziemię, ale jeśli znajdzie się w nim zło, umrze.
###### **1Krl 1,53**
 Król Salomon posłał, aby go sprowadzono od ołtarza. Wszedł i głęboko pokłonił się królowi Salomonowi. Salomon zaś rzekł mu: Idź do domu swego.
# 1Krl 1 BR
###### **1Krl 1,1**
 Król Dawid był już stary, w podeszłym wieku. Nawet gdy go okrywano, odczuwał zimno.
###### **1Krl 1,2**
 Jego słudzy mówili: Trzeba będzie poszukać dla króla jakiejś młodej dziewczyny, niech będzie zawsze przy królu, niech dba o niego, niech w razie potrzeby śpi na jego łonie, rozgrzewając w ten sposób naszego pana i króla.
###### **1Krl 1,3**
 I szukano po całym Izraelu dziewczyny, która byłaby dostatecznie piękna. Znaleziono w końcu pewną Szunemitkę, imieniem Abiszag, i przyprowadzono ją do króla.
###### **1Krl 1,4**
 Dziewczyna ta była rzeczywiście bardzo piękna. Troszczyła się o wszystko dla króla i obsługiwała go. Król jednak nie zbliżał się do niej.
###### **1Krl 1,5**
 Od pewnego czasu Adoniasz, syn Chaggity, powodowany jakimiś mrzonkami, zaczął rozpowiadać, że on będzie królem. Zakupił sobie rydwany i konie i polecił, żeby pięćdziesięciu ludzi biegło zawsze przed nim.
###### **1Krl 1,6**
 Jego ojciec nie skarcił go nigdy ani nawet nie zapytał, po co uczynił to czy tamto. [Adoniasz] był to mężczyzna bardzo piękny, a jego matka wydała go na świat po Absalomie.
###### **1Krl 1,7**
 Rozmawiał [w sprawie swoich zamierzeń] z Joabem, synem Serui, oraz z kapłanem Abiatarem i obydwu przeciągnął na swoją stronę.
###### **1Krl 1,8**
 Natomiast nie poszli za Adoniaszem: kapłan Sadok, Benajasz, syn Jojady, prorok Natan, Szimei i Rei oraz co dzielniejsi wojownicy Dawida.
###### **1Krl 1,9**
 Adoniasz złożył ofiarę z owiec, wołów i tłustych cielców przy kamieniu Zochelet koło źródła Rogel, zapraszając tam wszystkich swoich braci, synów królewskich, oraz wszystkich ludzi z pokolenia Judy, sługi króla.
###### **1Krl 1,10**
 Nie zaprosił jednak ani proroka Natana, ani Benajasza, ani najdzielniejszych wojowników, ani swego brata Salomona.
###### **1Krl 1,11**
 Zapytał wtedy Natan Batszebę, matkę Salomona: Czy słyszałaś o tym, że Adoniasz, syn Chaggity, został królem bez wiedzy pana naszego, Dawida?
###### **1Krl 1,12**
 Przyjdź zatem do mnie, chcę ci poradzić, co powinnaś uczynić, abyś mogła ocalić siebie samą i twojego syna, Salomona.
###### **1Krl 1,13**
 Idź do króla Dawida i powiedz mu tak: O królu i panie mój, czy nie poprzysiągłeś, że królem będzie po tobie Salomon i że to on właśnie zasiądzie na twoim tronie? Dlaczegóż więc teraz Adoniasz został królem?
###### **1Krl 1,14**
 Gdy ty będziesz jeszcze rozmawiała z królem, zaraz po tobie ja wejdę [do króla] i potwierdzę twoje słowa.
###### **1Krl 1,15**
 Udała się tedy Batszeba do króla, który - w bardzo już podeszłym wieku - znajdował się w swej komnacie. Była tam również Szunemitka Abiszag, która obsługiwała króla.
###### **1Krl 1,16**
 Batszeba skłoniła się królowi aż do ziemi i upadła na twarz, a król ją zapytał: Czego chcesz?
###### **1Krl 1,17**
 Ona zaś odpowiedziała: Panie mój, na imię Jahwe, twojego Boga, złożyłeś twojej służebnicy przysięgę, że mój syn, Salomon, zostanie po tobie królem, że to on właśnie zasiądzie na twoim tronie.
###### **1Krl 1,18**
 Tymczasem Adoniasz już został królem, o czym ty, królu mój i panie, nic nie wiesz!
###### **1Krl 1,19**
 Złożył on już w ofierze wiele wołów, tłustych cielców i owiec, zapraszając na tę uroczystość wszystkich synów królewskich, kapłana Abiatara, Joaba, dowódcę oddziałów wojskowych. Nie poprosił tylko sługi twojego Salomona.
###### **1Krl 1,20**
 A teraz oczy całego Izraela, królu mój i panie, zwrócone są na ciebie w oczekiwaniu, że ty sam powiesz, kto powinien zasiąść po tobie na twoim tronie, królu mój i panie.
###### **1Krl 1,21**
 W przeciwnym bowiem razie, kiedy mój król i pan odejdzie do swoich ojców, ja i mój syn, Salomon, będziemy musieli znosić [jakby zasłużone] udręki.
###### **1Krl 1,22**
 Kiedy ona jeszcze rozmawiała z królem, przyszedł prorok Natan. Jego przybycie tak zapowiedziano królowi:
###### **1Krl 1,23**
 Oto prorok Natan! Kiedy prorok znalazł się przed królem, skłonił się nisko i upadł na twarz.
###### **1Krl 1,24**
 Potem powiedział: O królu i panie mój. Czy ogłosiłeś, że Adoniasz będzie po tobie królował i zasiądzie na twoim tronie?
###### **1Krl 1,25**
 Bo on dziś przyszedł, złożył ofiarę z wielu wołów, tłustych cielców i owiec, zapraszając na tę uroczystość wszystkich synów królewskich, dowódców wojskowych i kapłana Abiatara. Jedzą teraz z nim i piją, wołając przy tym: Niech żyje król Adoniasz!
###### **1Krl 1,26**
 Nie zaprosił jednak ani mnie, twojego sługi, ani kapłana Sadoka, ani Benajasza, syna Jojady, ani twojego sługi Salomona.
###### **1Krl 1,27**
 Czy wszystko to stało się zgodnie z wolą mojego pana i króla? Czy rzeczywiście nie chciałeś ujawnić twoim sługom, kto ma zasiąść po naszym panu na jego królewskim tronie?
###### **1Krl 1,28**
 Na to rzekł król Dawid: Wezwijcie mi tu Batszebę. Weszła i stanęła przed królem.
###### **1Krl 1,29**
 A król złożył jej takie przyrzeczenie: Na życie Jahwe, który mnie uratował od tylu nieszczęść!
###### **1Krl 1,30**
 Przyrzekam, że dziś wypełnię to, co poprzysiągłem na imię Jahwe, Boga Izraela, mówiąc, iż Salomon, twój syn, będzie po mnie królował i że to on zajmie moje miejsce na tronie.
###### **1Krl 1,31**
 Batszeba skłoniła się nisko i upadła na twarz przed królem. Potem zawołała: Mój pan i król Dawid niech żyje na wieki!
###### **1Krl 1,32**
 Wtedy powiedział król: Przywołajcie mi tu kapłana Sadoka, proroka Natana i Benajasza, syna Jojady. Gdy wszyscy stanęli przed królem,
###### **1Krl 1,33**
 ten zwrócił się do nich ze słowami: Weźcie ze sobą sługi waszego pana, posadźcie Salomona, syna mojego, na mojej mulicy i zaprowadźcie go do Gichonu.
###### **1Krl 1,34**
 Tam kapłan Sadok i prorok Natan namaszczą go na króla izraelskiego. A wy zaczniecie dąć w rogi, wołając: Niech żyje król Salomon!
###### **1Krl 1,35**
 Potem pójdziecie za nim, on zaś zasiądzie na moim tronie i po mnie będzie sprawował władzę królewską. To jego bowiem ustanowiłem głową Izraela i Judy.
###### **1Krl 1,36**
 Benajasz zaś, syn Jojady, powiedział do króla: Amen! Obyż taka była wola Jahwe, Boga mojego pana i króla!
###### **1Krl 1,37**
 Jak był Jahwe z moim panem i królem, tak niech też będzie z Salomonem i niech jego tron wywyższy ponad tron Dawida, mojego pana i króla.
###### **1Krl 1,38**
 Poszli tedy: kapłan Sadok i prorok Natan, Benajasz, syn Jojady, oraz Keretyci i Peletyci, pomogli Salomonowi wsiąść na mulicę króla Dawida i zaprowadzili go do Gichonu.
###### **1Krl 1,39**
 Kapłan Sadok wziął z przybytku róg napełniony oliwą i namaścił Salomona. Kiedy zabrzmiały trąby, cały lud zawołał: Niech żyje król Salomon!
###### **1Krl 1,40**
 Potem wszyscy ludzie udali się za Salomonem. Grano na fletach i radowano się tak bardzo, że aż ziemia drżała.
###### **1Krl 1,41**
 Do Adoniasza i do tych, którzy z nim biesiadowali, odgłosy te doszły, kiedy kończyli swoją ucztę. Usłyszawszy głos trąby, odezwał się [jako pierwszy] Joab: Co to za krzyki słychać z miasta?
###### **1Krl 1,42**
 Kiedy on jeszcze mówił, nadbiegł Jonatan, syn kapłana Abiatara. Powiedział do niego Adoniasz: Chodź no tu! Jesteś dzielny i zawsze przynosisz dobre wieści. Jonatan odpowiedział Adoniaszowi:
###### **1Krl 1,43**
 Niestety! Oto nasz pan i król, Dawid, ustanowił królem Salomona.
###### **1Krl 1,44**
 Wysłał król z nim kapłana Sadoka, proroka Natana, Benajasza, syna Jojady, Keretytów oraz Peletytów. Oni to posadzili Salomona na mulicy królewskiej,
###### **1Krl 1,45**
 a kapłan Sadok i prorok Natan namaścili go na króla w Gichonie. Odeszli stamtąd radując się, tak że całe miasto zostało poruszone. Stąd te odgłosy dochodzące aż do was.
###### **1Krl 1,46**
 Salomon zasiadł już na królewskim tronie.
###### **1Krl 1,47**
 Przybyli także słudzy królewscy, którzy wychwalali naszego pana i króla, Dawida, mówiąc: Niech Bóg twój uczyni imię Salomona sławniejszym od twojego imienia, a tron jego niech będzie wyższy od twojego tronu! A król skłonił się głęboko na swoim [królewskim] łożu.
###### **1Krl 1,48**
 I przemówił w te słowa: Niech będzie błogosławiony Jahwe, Bóg Izraela, za to, że mi dziś ustanowił następcę na moim tronie, abym go mógł oglądać własnymi oczyma.
###### **1Krl 1,49**
 Wszystkich biesiadujących z Adoniaszem ogarnęło przerażenie; powstali [od stołu] i rozeszli się każdy w swoją stronę.
###### **1Krl 1,50**
 Sam Adoniasz zaś, bojąc się Salomona, też wstał, wyszedł, [dobiegł do ołtarza] i uchwycił się jego rogów.
###### **1Krl 1,51**
 Salomonowi doniesiono o tym w takich słowach: Adoniasz, drżąc ze strachu przed Salomonem, trzyma się rogów ołtarza i mówi: Oby zechciał mi dziś przyrzec król Salomon, że nie zgładzi mieczem swego sługi!
###### **1Krl 1,52**
 Powiedział tedy Salomon: Jeżeli się okaże, że jest to uczciwy człowiek, nawet jeden włos nie spadnie mu z głowy; lecz jeśli udowodnią mu winę, będzie musiał umrzeć.
###### **1Krl 1,53**
 I posłał król Salomon swoich ludzi, którzy sprowadzili go od ołtarza. Upadł Adoniasz na twarz przed Salomonem, a Salomon rzekł mu: Wracaj do swego domu!
# 1Krl 1 WUJ
###### **1Krl 1,1**
 A król Dawid zstarzał się był, i miał wiele dni wieku: a gdy go odziewano szatami, nie zagrzewał się.
###### **1Krl 1,2**
 Rzekli mu tedy słudzy jego: Poszukajmy królowi panu naszemu młodej panienki, i niech stoi przed królem, i okrywa go, i śpi na łonie jego, a zagrzewa króla pana naszego.
###### **1Krl 1,3**
 A tak szukali panienki pięknej we wszystkich granicach Izraelskich, i naleźli Abizag Sunamitkę, i przywiedli ją do króla.
###### **1Krl 1,4**
 A była panienka barzo piękna, i sypiała z królem, i służyła mu, ale jej król nie uznał.
###### **1Krl 1,5**
 Lecz Adonias syn Haggith podnosił się, mówiąc: Ja będę królował. I nasprawował sobie wozów i jezdnych i pięćdziesiąt mężów, którzyby biegali przed nim.
###### **1Krl 1,6**
 A nie karał go nigdy ociec jego, mówiąc: Przecześ to uczynił? A był i ten barzo piękny, wtóry syn po Absalomie.
###### **1Krl 1,7**
 A miał zmowę z Joabem synem Sarwiej, i z Abiatharem kapłanem, którzy pomagali stronie Adoniasowej.
###### **1Krl 1,8**
 Lecz Sadok kapłan i Banajas syn Jojadi, i Nathan prorok, i Semei, i Rey, i moc wojska Dawidowego nie z Adoniasem.
###### **1Krl 1,9**
 A tak narzezawszy Adonias baranów i cielców i wszego bydła tłustego u kamienia Zoheleth, który był blizko źródła Rogel, wezwał wszystkich braciej swych synów królewskich i wszystkich mężów Judzkich sług królewskich,
###### **1Krl 1,10**
 Lecz Nathana proroka, i Banaje, i wszelkich mocarzów, i Salomona brata swego nie wezwał.
###### **1Krl 1,11**
 I rzekł Nathan do Bethsabee matki Salomonowej: A słyszałaś, że króluje Adonias syn Haggith, a pan nasz Dawid o tem nie wie?
###### **1Krl 1,12**
 Przetoż teraz pódź, weźmi radę odemnie, a zachowaj duszę swoję, i syna twego Salomona.
###### **1Krl 1,13**
 Idź a wnidź do króla Dawida i rzecz mu: Azażeś nie ty panie mój królu przysiągł mnie słudze twojej rzekąc: Salomon syn twój będzie królował po mnie, i on będzie siedział na stolicy mojej? Przeczże tedy króluje Adonias?
###### **1Krl 1,14**
 A gdy jeszcze tam będziesz mówić z królem, ja przyjdę za tobą i dopełnię słów twoich.
###### **1Krl 1,15**
 A tak weszła Bethsabee do króla na pokój: a król się był barzo starzał, a Abisag Sunamitka posługowała mu.
###### **1Krl 1,16**
 Nachyliła się Bethsabee i pokłoniła się królowi. Do której król: Czego, pry, chcesz?
###### **1Krl 1,17**
 Która odpowiadając rzekła: Panie mój tyś przysiągł przez Pana Boga twego słudze twojej, Salomon syn twój będzie królował po mnie, i on siedzieć będzie na stolicy mojej.
###### **1Krl 1,18**
 A teraz oto Adonias króluje, o czem ty królu panie mój nie wiesz.
###### **1Krl 1,19**
 Nabił wołów i bydła tłustego, i baranów barzo wiele i wezwał wszystkich synów królewskich, i Abiathara kapłana i Joaba hetmana rycerstwa: Lecz Salomona sługi twego nie wezwał.
###### **1Krl 1,20**
 Ale jednak panie mój królu na cię się oglądają oczy wszystkiego Izraela, żebyś im oznajmił kto ma siedzieć na stolicy twojej królu panie mój po tobie.
###### **1Krl 1,21**
 I stanie się, gdy zaśnie pan mój król z ojcy swemi będziemy ja i Salomon syn mój grzesznymi.
###### **1Krl 1,22**
 A gdy ona jeszcze mówiła z królem, Nathan prorok przyszedł.
###### **1Krl 1,23**
 I oznajmili królowi rzekąc: Idzie Nathan prorok. A gdy wszedł przed oczy królewskie i pokłonił się mu twarzą ku ziemi,
###### **1Krl 1,24**
 Rzekł Nathan: Panie mój królu tyś rzekł: Adonias niech króluje po mnie, a ten niechaj siedzi na stolicy mojej?
###### **1Krl 1,25**
 Dziś bowiem szedł i nabił wołów i tłustego bydła i baranów wiele, i wezwał wszystkich synów królewskich, i hetmanów, i Abiathara kapłana: a gdy oni jedzą i piją przed nim i mówią: Niech żywie Król Adonias,
###### **1Krl 1,26**
 Mnie sługi twego i Sadoka kapłana, i Banaję syna Jojady, i Salomona sługi twego nie wezwał.
###### **1Krl 1,27**
 Izali od pana mego króla wyszło to słowo, a nie oznajmiłeś mnie słudze twemu kto ma siedzieć na stolicy pana mego króla po nim?
###### **1Krl 1,28**
 I odpowiedział król Dawid rzekąc: Wzówcie do mnie Bethsabee. Która gdy weszła przed króla i stanęła przed nim,
###### **1Krl 1,29**
 Przysiągł król i rzekł: Żywie Pan, który wyrwał duszę moję ze wszystkiego ucisku,
###### **1Krl 1,30**
 Iż jakomci przysiągł przez Pana Boga Izraelowego, rzekąc: Salomon syn twój królować będzie po mnie, i ten będzie siedział na stolicy mojej miasto mnie: tak uczynię dzisia.
###### **1Krl 1,31**
 I spuściwszy Bethsabee twarz ku ziemi, pokłoniła się królowi, rzekąc: Niech żywie Pan mój Dawid na wieki.
###### **1Krl 1,32**
 Rzekł też król Dawid: Wzówcie mi Sadoka kapłana, i Nathana proroka, i Banaję syna Jojadowego. Którzy, gdy weszli przed króla,
###### **1Krl 1,33**
 Rzekł do nich: Weźmicie z sobą sługi pana waszego, a wsadźcie Salomona syna mego na mulicę moję, i prowadźcie go do Gihon.
###### **1Krl 1,34**
 Tamże go niech pomaże kapłan Sadok i Nathan prorok za króla nad Izraelem: i będziecie trąbić w trąbę, a rzeczecie: Niech żyje król Salomon.
###### **1Krl 1,35**
 I pójdziecie za nim, i przyjdzie a siędzie na stolicy mojej, a on będzie królował miasto mnie: i jemu rozkażę, aby był wodzem nad Izraelem i nad Judą.
###### **1Krl 1,36**
 I odpowiedział Banajas syn Jojady królowi, mówiąc: Amen. Tak niech mówi Pan Bóg pana mego króla.
###### **1Krl 1,37**
 Jako był Pan z panem moim królem, tak niech będzie z Salomonem, a niech wywyższy stolicę jego nad stolicę króla pana mego Dawida.
###### **1Krl 1,38**
 Poszedł tedy Nathan prorok i Sadok kapłan, i Banajas syn Jojady, i Cerethy i Phelethy, i wsadzili Salomona na mulicę króla Dawida, i doprowadzili go do Gihon.
###### **1Krl 1,39**
 I wziąwszy Sadok kapłan róg oliwy z przybytku pomazał Salomona: i trąbili w trąbę, i mówił wszystek lud: Niech żyje król Salomon.
###### **1Krl 1,40**
 I szedł za nim wszystek gmin, i lud grających na piszczałkach i weselących się weselem wielkiem, brzmiała ziemia od krzyku ich.
###### **1Krl 1,41**
 I usłyszał Adonias i wszyscy zaproszeni od niego, a biesiada już się była skończyła: lecz i Joab, usłyszawszy głos trąby, rzekł: Co to za krzyk miasta huczącego?
###### **1Krl 1,42**
 A gdy on jeszcze mówił, Jonathas syn Abiathara kapłana przyszedł: któremu rzekł Adonias: Wnidź, bo mąż mocny, i dobrą nowinę niosąc.
###### **1Krl 1,43**
 Odpowiedział Jonathas, Adoniasowi: Nie: bo pan nasz król Dawid postanowił królem Salomona:
###### **1Krl 1,44**
 I posłał z nim kapłana Sadoka, i Nathana proroka, i Banaję syna Jojady, i Cerethy i Phelethy, i wsadzili go na mulicę królewską:
###### **1Krl 1,45**
 I pomazali go kapłan Sadok i Nathan prorok za króla w Gihon: i pojachali ztamtąd weseląc się, i zabrzmiało miasto: ten jest głos, któryście słyszeli.
###### **1Krl 1,46**
 Lecz i Salomon siedzi na stolicy królestwa.
###### **1Krl 1,47**
 I wszedszy słudzy królewscy błogosławili panu naszemu królowi Dawidowi mówiąc: Niech rozszerzy Bóg imię Salomonowe nad imię twoje, a niech wielmożną uczyni stolicę jego nad stolicę twoję. I pokłonił się król na łożu swojem:
###### **1Krl 1,48**
 I mówił: Błogosławiony Pan Bóg Izraelów, który dał dzisia siedzącego na stolicy mojej, na co patrzą oczy moje.
###### **1Krl 1,49**
 Zlękli się tedy, i wstali wszyscy, których był naprosił Adonias, i poszedł każdy w drogę swoję.
###### **1Krl 1,50**
 A Adonias bojąc się Salomona, wstał i poszedł i uchwycił się rogu ołtarza.
###### **1Krl 1,51**
 I powiedzieli Salomonowi, rzekąc: Oto Adonias, bojąc się króla Salomona, uchwycił się rogu ołtarza, mówiąc: Niech mi dziś przysięże król Salomon, że nie zabije sługi swego mieczem.
###### **1Krl 1,52**
 I rzekł Salomon: Będzieli dobrym mężem, nie spadnie i jeden włos głowy jego na ziemię: ale jeśli się w nim najdzie co złego, umrze.
###### **1Krl 1,53**
 Posłał tedy król Salomon i wywiódł go od ołtarza: a wszedszy pokłonił się królowi Salomonowi: i rzekł mu Salomon: Idź do domu swego.
