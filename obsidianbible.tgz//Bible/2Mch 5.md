# 2Mch 5 BT5
###### **2Mch 5,1**
 W tym czasie Antioch przygotowywał drugą wyprawę przeciwko Egiptowi.
###### **2Mch 5,2**
 Wtedy nad całym miastem przez blisko czterdzieści dni widać było biegnących w powietrzu jeźdźców ubranych w szaty haftowane złotem, podzielone na kohorty wojsko uzbrojone we włócznie, dobywanie mieczy,
###### **2Mch 5,3**
 oddziały jeźdźców w bojowym szyku, natarcia i napady prowadzone z obydwóch stron, poruszanie tarczami, przeliczne drzewca, miotania strzał, blask złotych ozdób i różnorodne pancerze.
###### **2Mch 5,4**
 Wszyscy zaś modlili się, aby to zjawisko było znakiem czegoś dobrego.
###### **2Mch 5,5**
 Tymczasem rozeszła się fałszywa pogłoska, że Antioch zakończył życie. Jazon więc dobrał sobie nie mniej niż tysiąc [ludzi] i niespodziewanie napadł na miasto. Gdy już wdarli się na mury i kiedy na koniec miasto było zdobyte, Menelaos uciekł do zamku.
###### **2Mch 5,6**
 Jazon zaś dokonał bezlitosnej rzezi własnych obywateli. Nie baczył na to, że zwycięstwo nad własnymi krewnymi jest największą klęską, przekonany, że zdziera łupy z nieprzyjaciół, a nie z rodaków.
###### **2Mch 5,7**
 Władzy jednak nie osiągnął, a ostatecznie przez ten zamach okrył się hańbą i ponownie jako zbieg uszedł do kraju Ammonitów.
###### **2Mch 5,8**
 Tam spotkał go wreszcie kres nieszczęśliwy. Oskarżony przed Aretasem, władcą Arabów, z jednego miasta uciekał do drugiego, ścigany przez wszystkich. Znienawidzony jako odstępca od praw i wzgardzony jako kat ojczyzny i rodaków, uciekł do Egiptu.
###### **2Mch 5,9**
 Ten, który rodaków wypędził z ojczyzny, na obcej ziemi zakończył życie. Poszedł do Lacedemończyków niby to ze względu na pokrewieństwo. Miał nadzieję, że tam znajdzie schronienie.
###### **2Mch 5,10**
 A po nim, który tylu ludzi pozostawił bez pogrzebu, nikt nie płakał, nikt nie oddał mu ostatniej posługi, a w rodzinnym grobie nie było dla niego miejsca.
###### **2Mch 5,11**
 Kiedy wieść o tym, co się stało, dotarła do króla, nabrał on przekonania, że Judea od niego odpada. Opuścił więc Egipt, a w duszy podobny do dzikiego zwierza zbrojną ręką wziął miasto.
###### **2Mch 5,12**
 żołnierzom swoim rozkazał wycinać bez litości tych, którzy wpadną im w ręce, i zabijać tych, którzy uciekną do domów.
###### **2Mch 5,13**
 Dokonano więc rzezi młodych i starych, zagłady młodzieży, kobiet i dzieci, mordowania dziewic i niemowląt.
###### **2Mch 5,14**
 W ciągu tych trzech dni padło ofiarą osiemdziesiąt tysięcy: czterdzieści tysięcy w toku akcji, nie mniej zaś ofiar zostało sprzedanych w niewolę.
###### **2Mch 5,15**
 Nie zaspokojony tym, odważył się wkroczyć nawet do najświętszej na całym świecie świątyni, mając za przewodnika Menelaosa, zdrajcę praw i ojczyzny,
###### **2Mch 5,16**
 i w swe nieczyste ręce chwycił święte naczynia. Co inni królowie złożyli celem powiększenia chwały tego miejsca i uczczenia go, on zrabował bezecnymi rękoma.
###### **2Mch 5,17**
 Antioch triumfował w swoim przekonaniu, nie wiedział jednak tego, że wskutek grzechów mieszkańców miasta rozgniewał się na krótki czas Władca, i dlatego nie wejrzał na [święte] miejsce.
###### **2Mch 5,18**
 Gdyby nie popadli w wiele grzechów, to nie inaczej, ale tak samo jak Heliodor, którego król Seleukos posłał, aby przejrzał skarbiec, i on byłby zaraz po swoim wtargnięciu ubiczowany i tak odwiedziony od swojego zuchwalstwa.
###### **2Mch 5,19**
 Pan jednak nie wybrał ludu ze względu na świątynię, ale świątynię ze względu na lud.
###### **2Mch 5,20**
 Oto właśnie dlaczego ta świątynia uczestniczyła w nieszczęściach narodu, a potem w jego szczęściu. Opuszczona wskutek gniewu Wszechmocnego, ponownie była przywrócona do pełnej chwały, gdy wielki Władca został przebłagany.
###### **2Mch 5,21**
 Antioch zabrał ze świątyni tysiąc osiemset talentów i szybko oddalił się do Antiochii, wierząc w swej pysze i wyniosłości serca, że ziemię uczyni spławną, a morze dostępne dla podroży pieszych.
###### **2Mch 5,22**
 Pozostawił jednak zarządców, aby oni znęcali się nad narodem; w Jerozolimie Filipa, który z pochodzenia był Frygijczykiem, sposób zaś jego postępowania był bardziej barbarzyński aniżeli tego, który go ustanowił;
###### **2Mch 5,23**
 na Garizim – Andronika, a oprócz nich jeszcze Menelaosa, który gorzej od innych wynosił się ponad obywateli, do obywateli Żydów odnosząc się ze szczególną wrogością.
###### **2Mch 5,24**
 Posłał też dowódcę Mizyjczyków, Apoloniusza, na czele wojska liczącego dwadzieścia dwa tysiące ludzi, z rozkazem, aby wymordował wszystkich dorosłych mężczyzn, kobiety zaś i młodzież, by sprzedał [w niewolę].
###### **2Mch 5,25**
 Przybył on do Jerozolimy i udawał takiego, który przynosi pokój. Przeczekał aż do świętego dnia szabatu, kiedy to korzystając z tego, że Żydzi nic nie robią, rozkazał swoim żołnierzom chwycić za broń.
###### **2Mch 5,26**
 Wszystkich tych, którzy wyszli na widowisko, kazał wymordować, a potem wpadł z bronią do miasta i wielu położył trupem.
###### **2Mch 5,27**
 Wtedy Juda Machabeusz wraz z około dziesięciu innymi wycofał się na pustynię i tam na sposób dzikich zwierząt żył w górach razem ze swoimi ludźmi. żywili się oni tylko roślinami, aby się nie splamić.
# 2Mch 5 PAU
###### **2Mch 5,1**
 W tym czasie Antioch przygotowywał drugą wyprawę przeciwko Egiptowi.
###### **2Mch 5,2**
 Wtedy to przez prawie czterdzieści dni w całym mieście miały miejsce wizje: jeźdźcy galopujący w powietrzu w przetykanych złotem szatach; piechota z włóczniami formująca się w oddziały; dobywanie mieczy;
###### **2Mch 5,3**
 oddziały jazdy ustawiające się w szyku; szturm i szarża z obu stron; ruch tarcz, las włóczni, uderzenia broni, świst strzał, błysk złotych ozdób i wszelkiego rodzaju zbroi.
###### **2Mch 5,4**
 Wszyscy błagali, aby te wizje zwiastowały coś dobrego.
###### **2Mch 5,5**
 Gdy rozeszła się fałszywa pogłoska, że Antioch umarł, Jazon wziął ze sobą nie mniej niż tysiąc ludzi i niespodziewanie przypuścił atak na miasto. Kiedy pokonał tych, którzy byli na murach, i niemal całkiem opanował miasto, Menelaos schronił się w akropolu.
###### **2Mch 5,6**
 Jazon zaś dopuścił się rzezi własnych obywateli, sądząc, że odnosi zwycięstwo nad nieprzyjaciółmi, a nie nad rodakami. Nie zdawał sobie sprawy, że zwycięstwo nad krewnymi jest największą klęską.
###### **2Mch 5,7**
 Nie zdobył jednak władzy, lecz okrył się hańbą zdrady i musiał znów uciekać do Ammonitów.
###### **2Mch 5,8**
 A kres jego był tragiczny. Oskarżony przed Aretasem, władcą Arabów, uciekał z miasta do miasta. Ścigany przez wszystkich, znienawidzony jako odstępca od praw, budzący obrzydzenie jako nieprzyjaciel ojczyzny i narodu, został wygnany do Egiptu.
###### **2Mch 5,9**
 Tak więc ten, który wielu ludzi wypędził z ojczyzny, zginął jako wygnaniec u Lacedemończyków, wśród których się schronił, powołując się na wspólne pochodzenie.
###### **2Mch 5,10**
 Ten, który wielu ludzi porzucił bez pogrzebu, sam nie był opłakiwany; nie miał pogrzebu ani nie znalazł miejsca w rodzinnym grobie.
###### **2Mch 5,11**
 Gdy wiadomości o tych wydarzeniach dotarły do króla, odebrał to jako bunt Judei. Wycofał się więc z Egiptu i rozwścieczony zdobył miasto szturmem.
###### **2Mch 5,12**
 Rozkazał żołnierzom zabijać bez litości wszystkich napotkanych i wyrżnąć tych, którzy chronili się w domach.
###### **2Mch 5,13**
 Mordowano młodych i starych, zabijano młodzieńców, kobiety i dzieci, dokonano rzezi dziewcząt i niemowląt.
###### **2Mch 5,14**
 W ciągu trzech dni zginęło osiemdziesiąt tysięcy ludzi, z czego czterdzieści tysięcy w walce wręcz. Co najmniej tyle samo sprzedano w niewolę.
###### **2Mch 5,15**
 Jakby tego było jeszcze mało, odważył się wejść do najświętszej na ziemi świątyni, mając za przewodnika Menelaosa, zdrajcę praw i ojczyzny.
###### **2Mch 5,16**
 Nieczystymi rękami wziął święte naczynia, skalanymi rękami splugawił to, co ofiarowali inni królowie dla pomnożenia chwały i czci tego miejsca.
###### **2Mch 5,17**
 Antioch wbił się w pychę, nie biorąc pod uwagę tego, że Władca rozgniewał się tylko na krótki czas z powodu grzechów mieszkańców miasta i dlatego był obojętny dla tego miejsca.
###### **2Mch 5,18**
 Gdyby bowiem nie pogrążyli się w licznych grzechach, wówczas tak jak Heliodor posłany przez króla Seleukosa, aby dokonać przeglądu skarbca, tak i on po swoim przybyciu zostałby natychmiast wychłostany i odwiedziony od zuchwalstwa.
###### **2Mch 5,19**
 PAN bowiem nie wybrał narodu ze względu na miejsce, lecz miejsce ze względu na naród.
###### **2Mch 5,20**
 Z tego powodu to miejsce miało udział w niedoli narodu, a potem w jego pomyślności. W swoim gniewie Wszechmocny je opuścił, ale gdy dał się ze sobą pojednać, wielki Władca ponownie odbudował je z całą chwałą.
###### **2Mch 5,21**
 Następnie Antioch zabrał tysiąc osiemset talentów ze świątyni i szybko odjechał do Antiochii, wierząc w swojej pysze, że potrafi sprawić, aby po ziemi można było pływać, a po morzu chodzić. Tak wyniosłe stało się jego serce!
###### **2Mch 5,22**
 Pozostawił jednak zwierzchników, aby uciskali naród: w Jerozolimie Filipa, który był z pochodzenia Frygijczykiem, ale z charakteru jeszcze większym barbarzyńcą od swego mocodawcy;
###### **2Mch 5,23**
 na Garizim - Andronika; oprócz nich Menelaosa, który bardziej niż inni wynosił się ponad obywateli i był wrogo usposobiony wobec Żydów.
###### **2Mch 5,24**
 Król posłał ponadto dowódcę Mizyjczyków Apoloniusza razem z dwudziestodwutysięcznym wojskiem, nakazując mu zabić wszystkich dorosłych, a kobiety i nieletnich sprzedać.
###### **2Mch 5,25**
 Kiedy przybył on do Jerozolimy, udawał pokojowo usposobionego aż do świętego dnia szabatu. Podczas gdy Żydzi odpoczywali, rozkazał swoim żołnierzom urządzić ćwiczenia.
###### **2Mch 5,26**
 Następnie kazał zabić wszystkich, którzy przyszli na oglądanie, wtargnął z bronią do miasta i pobił wielki tłum.
###### **2Mch 5,27**
 Wtedy Juda Machabeusz zebrał około dziesięciu ludzi i uciekł na pustynię. Tam na sposób dzikich zwierząt mieszkał w górach razem ze swoimi towarzyszami. Żywili się tylko roślinami, aby się nie skalać.
# 2Mch 5 BP
###### **2Mch 5,1**
 W tym czasie Antioch przygotowywał drugą wyprawę do Egiptu.
###### **2Mch 5,2**
 I wydarzyło się, że widziano przez czterdzieści niemal dni, jak ukazywali się po całym mieście cwałujący w powietrzu jeźdźcy, odziani w złote szaty, a wszyscy uzbrojeni byli w lance i dobyte miecze.
###### **2Mch 5,3**
 Hufce jeźdźców w szyku bojowym to kolejno nacierały na siebie, to wycofywały się wśród szczęku tarcz, lasu włóczni, mnóstwa oszczepów i miotanych pocisków. Błyszczały złote zbroje i najrozmaitsze pancerze.
###### **2Mch 5,4**
 Wszyscy przeto modlili się, aby to zjawisko było pomyślną wróżbą.
###### **2Mch 5,5**
 Tymczasem rozeszła się fałszywa pogłoska, jakoby Antioch zakończył życie. Wówczas Jazon, zebrawszy nie mniej niż tysiąc ludzi, znienacka zaatakował miasto. Skoro wyparto [obrońców] z murów i w końcu zdobyto miasto, Menelaos schronił się do zamku.
###### **2Mch 5,6**
 Jazon zaś urządził bezlitosną rzeź własnych obywateli, nie zdając sobie sprawy z tego, że zwycięstwo nad rodakami jest największym nieszczęściem; sądził bowiem, że pobił nieprzyjaciół, a nie własny naród.
###### **2Mch 5,7**
 Mimo to nie zdołał objąć władzy, ale ostatecznie ściągnął na siebie wskutek tego napadu hańbę i musiał znowu szukać schronienia w kraju Ammonitów.
###### **2Mch 5,8**
 I tam doczekał się marnego końca. Oskarżony sądownie przez władcę Arabów Aretasa uciekać musiał z miasta do miasta i zbiegł do Egiptu, ścigany przez wszystkich, znienawidzony jako odstępca od Prawa, przeklęty jako kat ojczyzny i obywateli.
###### **2Mch 5,9**
 Ten, który tak wielu wygnał z ojczyzny, sam musiał zakończyć życie na obczyźnie. Udał się bowiem do Lacedemończyków, mając nadzieję, że ze względu na pokrewieństwo znajdzie tam schronienie.
###### **2Mch 5,10**
 Ten, który mnóstwo ludzi pozabijał i nie pogrzebał, nie był ani żałowany, ani opłakiwany i nie doczekał się pogrzebu ani grobu wśród ojców.
###### **2Mch 5,11**
 Kiedy wieści o tych wydarzeniach dotarły do króla, sądził, że Judea dąży do oderwania się. Wyruszył więc z Egiptu z dziką wściekłością w duszy i zdobył miasto przemocą.
###### **2Mch 5,12**
 Rozkazał żołnierzom zabijać bezlitośnie wszystkich, którzy wpadną im w ręce, oraz wyciąć tych, którzy ratowaliby się ucieczką do domów.
###### **2Mch 5,13**
 Rozpoczęła się zagłada młodych i starych, rzeź kobiet i dzieci, mord dziewcząt i niemowląt.
###### **2Mch 5,14**
 Straty w owych trzech dniach wynosiły osiemdziesiąt tysięcy ludzi. Czterdzieści tysięcy zginęło w walce, nie mniej sprzedano [w niewolę].
###### **2Mch 5,15**
 Tym jeszcze nienasycony odważył się wtargnąć do Świątyni najświętszej na całym świecie, mając za przewodnika Menelaosa, zdrajcę praw i ojczyzny.
###### **2Mch 5,16**
 Splamionymi rękoma zrabował i wziął w swoje nie poświęcone ręce święte naczynia i ofiary, które inni królowie złożyli dla pomnożenia świetności i czci tego miejsca.
###### **2Mch 5,17**
 Antioch w swej wielkiej zarozumiałości nie pojął, że Wszechwładny na krótki czas rozgniewał się z powodu grzechów mieszkańców miasta, i dlatego to odwrócił spojrzenie od Miejsca.
###### **2Mch 5,18**
 Gdyby nie pogrążyli się w tylu grzechach, to podobnie jak Heliodor, wysłany przez króla Seleukosa w celu dokonania przeglądu skarbca, również i ten zostałby natychmiast po wejściu wychłostany i odwiedziony od zuchwałego zamierzenia.
###### **2Mch 5,19**
 Albowiem Pan nie wybrał ludu dla miejsca Świętego, lecz dla swego ludu wybrał Miejsce.
###### **2Mch 5,20**
 Dlatego Miejsce to dzieliło nieszczęścia, jakie spotykały lud, potem zaś uczestniczyło w udzielonych mu dobrodziejstwach. Opuszczone w gniewie przez Wszechmocnego odzyskało znowu całą swą chwałę, gdy Wszechwładny został przejednany.
###### **2Mch 5,21**
 Antioch zabrał ze Świątyni tysiąc osiemset talentów i z wielkim pośpiechem wrócił do Antiochii. Wyobrażał sobie, że w swej pysze i zarozumiałości sprawi, iż po ziemi można będzie pływać [okrętami], a po morzu chodzić.
###### **2Mch 5,22**
 Pozostawił jednak zarządców, aby lud krzywdzili: w Jerozolimie Filipa - był to Frygijczyk z pochodzenia, jeszcze większy barbarzyńca niż ten, który go mianował;
###### **2Mch 5,23**
 na [górze] Garizim Andronika, a do tego jeszcze Menelaosa, który gorzej niż inni gnębił obywateli i bardzo wrogo usposobiony był do Żydów.
###### **2Mch 5,24**
 Okrytego hańbą Apoloniusza wysłał z wojskiem w liczbie dwudziestu dwóch tysięcy żołnierzy, nakazawszy, aby wymordował wszystkich dorosłych [mężczyzn], kobiety zaś i młodzież sprzedał [w niewolę].
###### **2Mch 5,25**
 Ten przybył do Jerozolimy i udając, że [zjawia się] w pokojowych zamiarach, powstrzymał się aż do świętego dnia szabatu. Kiedy już się upewnił, że Żydzi świętują, kazał swoim żołnierzom stanąć pod bronią.
###### **2Mch 5,26**
 Tych wszystkich, którzy wyszli przyjrzeć się pokazowi, kazał wyciąć. Potem wpadł do miasta z uzbrojonymi żołnierzami i wymordował mnóstwo ludzi.
###### **2Mch 5,27**
 Wówczas Juda Machabeusz uszedł na pustynię z dziewięcioma mężami. Żył tam ze swymi ludźmi jak dzikie zwierzęta w górach. Żywili się tylko roślinami, aby umknąć wszelkiej nieczystości.
# 2Mch 5 BR
###### **2Mch 5,1**
 W tym czasie Antioch przygotował swoją drugą wyprawę wojenną przeciwko Egiptowi.
###### **2Mch 5,2**
 Wtedy prawie przez czterdzieści dni zaczęli się ukazywać w powietrzu na terenie całego królestwa jeźdźcy przybrani w szaty przetykane złotem, uformowani w oddziały uzbrojone we włócznie i miecze.
###### **2Mch 5,3**
 Owo mnóstwo jeźdźców ustawiało się w szyku bojowym, nacierało na siebie nawzajem, z obydwu stron uderzali jedni na drugich. Widać było ruchy tarcz, las włóczni, mnóstwo dobytych mieczy. Powietrze przeszywały strzały, błyszczała w słońcu złotem zdobiona broń, pojawiały się coraz to inne zbroje.
###### **2Mch 5,4**
 Wszyscy się modlili, żeby obrazy te oznaczały coś dobrego.
###### **2Mch 5,5**
 Tymczasem rozeszła się fałszywa wieść, że Antioch umarł. Wtedy Jazon, wziąwszy ze sobą nie mniej niż tysiąc wojowników, dokonał niespodziewanego napadu na miasto. Szybko zepchnięto obrońców z murów i kiedy już niemal całe miasto było zdobyte, Menelaos schronił się w twierdzy.
###### **2Mch 5,6**
 Jazon urządził bezlitosną, krwawą rzeź, i to pośród własnych współbraci. Nie pomyślał nawet przez chwilę, że zwycięstwo odniesione nad własnym ludem będzie jego największym nieszczęściem. Zachowywał się tak, jakby gromił i łupił nie własnych rodaków, lecz wrogów.
###### **2Mch 5,7**
 Jednakże władzy mimo wszystko nie zdołał zagarnąć dla siebie. Dzieło, którego dokonał, okryło go jedynie hańbą. Ostatecznie po raz drugi musiał szukać schronienia w kraju Ammonitów.
###### **2Mch 5,8**
 A skończył bardzo źle. Aretas, władca Arabów, kazał go pojmać. Uciekał tedy Jazon z miasta do miasta, ścigany przez wszystkich, znienawidzony jako odstępca od prawa, pogardzany jako zdrajca własnej ojczyzny i własnych rodaków, aż zdołał wreszcie schronić się w Egipcie.
###### **2Mch 5,9**
 I tak oto ten, który kiedyś wypędził wielu ludzi z ich własnego kraju, teraz zakończył życie na obczyźnie, wśród obcych, mianowicie wśród Lacedemończyków, do których dotarł, by żyć pod ich osłoną. Liczył bowiem na łączące ich więzy krwi z Żydami.
###### **2Mch 5,10**
 Gdy umarł, nikt po nim nie płakał, nikt nie urządził mu pogrzebu, bo i z jego powodu wielu nie miało własnego grobu, i nie pochowano go w grobie obok jego ojców.
###### **2Mch 5,11**
 Kiedy do uszu króla doszła wieść o tym wszystkim, co się stało, pomyślał, że Judea chce odłączyć się od niego. Rozwścieczony tedy jak dziki zwierz przybył na czele swojego wojska z Egiptu i siłą zajął miasto.
###### **2Mch 5,12**
 Wydał też swoim wojownikom rozkaz, żeby bez litości zabijali wszystkich, i tych, których dopadną na ulicach, i tych, którzy schronią się na dachach swoich domów.
###### **2Mch 5,13**
 Krwawa rzeź nie ominęła nikogo, ani młodych, ani starych. Ginęli młodzi mężczyźni, padały kobiety i dzieci, mordowano dorastające dziewczynki i niemowlęta.
###### **2Mch 5,14**
 W ciągu trzech dni miasto straciło osiemdziesiąt tysięcy swoich mieszkańców. Czterdzieści tysięcy poległo z rąk zabójców, a do niewoli sprzedano tyle, ile wymordowano.
###### **2Mch 5,15**
 Ale to jeszcze nie wystarczyło królowi. W swoim szaleństwie odważył się postawić nogę w świątyni będącej największą świętością na całej ziemi. Towarzyszył mu Menelaos, ten odstępca od prawa i zdrajca własnej ojczyzny.
###### **2Mch 5,16**
 Wówczas też król wyciągnął swoje zbrukane krwią ręce ku świętym naczyniom i wszystko to, co inni królowie przynieśli tu w darze, żeby przydać piękna i godności temu miejscu, on teraz swoimi nieczystymi rękami zagrabił.
###### **2Mch 5,17**
 W ślepej zarozumiałości Antioch nie przypuszczał nawet, że Pan tylko na krótki czas rozgniewał się na miasto z powodu grzechów jego mieszkańców i nie tylko dlatego nie ujął się za tym świętym miejscem.
###### **2Mch 5,18**
 Gdyby Żydzi nie byli wówczas uwikłani w liczne grzechy, to bez wątpienia i zuchwalstwo króla zostałoby poskromione biczami zaraz po jego wtargnięciu do świątyni, tak jak kiedyś biczami został przepędzony Heliodor, którego król Seleukos wysłał, aby przetrząsnął skarbiec świątynny.
###### **2Mch 5,19**
 Ale Pan nie wybrał ludu ze względu na miejsce, lecz miejsce ze względu na lud.
###### **2Mch 5,20**
 Dlatego od nieszczęść, które spadły na lud, ucierpiało także to miejsce, podobnie jak później miało uczestniczyć w jego szczęściu. Gdy Wszechmocny się gniewał, miejsce to pustoszało. Kiedy jednak wielki Pan pozwalał się przebłagać, przywracano je znowu do dawnej wspaniałości.
###### **2Mch 5,21**
 Antioch kazał tedy zabrać ze świątyni tysiąc osiemset talentów i pośpiesznie udał się do Antiochii. W swojej pysze marzył, że kiedyś po lądach będą pływały okręty, a po morzu będzie się chodzić suchą nogą - taki był zarozumiały.
###### **2Mch 5,22**
 Odchodząc pozostawił w kraju wielu zarządców, którzy mieli nadal uciskać lud. W Jerozolimie takim zarządcą był niejaki Filip, z pochodzenia Frygijczyk, ze sposobu bycia zaś - barbarzyńca, i to dzikszy, niż ten, który go na tym urzędzie ustanowił.
###### **2Mch 5,23**
 Na górze Garizim urzędował Andronik. Oprócz nich Menelaos, który wynosił się ponad mieszkańców kraju i był bardziej okrutny niż pozostali, a Żydów nienawidził.
###### **2Mch 5,24**
 Poza tym przysłał król dowódcę Mizyjczyków, Apoloniusza, z wojskiem liczącym dwadzieścia dwa tysiące ludzi. Otrzymał on rozkaz wymordowania wszystkich zdolnych do noszenia broni mężczyzn, a zaprzedania w niewolę wszystkich kobiet i dzieci.
###### **2Mch 5,25**
 Znalazłszy się w Jerozolimie, Apoloniusz obłudnie zapewniał, że pragnie żyć w pokoju ze wszystkimi. Czekał aż do świętego dnia szabatu. Ponieważ wiedział, że w tym dniu Żydzi powstrzymują się od wszelkiego zajęcia, kazał swoim ludziom chwycić za broń i rzucić się do nich.
###### **2Mch 5,26**
 Polecił wymordować wszystkich, którzy przybyli na uroczystą służbę Bożą. Potem przeszli zbrojni przez miasto i zabili bardzo wielu ludzi.
###### **2Mch 5,27**
 Tymczasem Juda, noszący przydomek Machabeusz, z gronem dziewięciu przyjaciół wycofał się na pustynię, gdzie żyli na sposób dzikich zwierząt, błąkając się po górach. Żywili się przez cały ten czas tylko roślinami w obawie, żeby się czymś nie splamić.
# 2Mch 5 WUJ
