# 1Krn 6 BT5
###### **1Krn 6,1**
 Synowie Lewiego: Gerszom, Kehat, Merari.
###### **1Krn 6,2**
 Oto imiona synów Gerszoma: Libni i Szimei.
###### **1Krn 6,3**
 Synowie Kehata: Amram, Jishar, Chebron i Uzzjel.
###### **1Krn 6,4**
 Synowie Merariego: Machli i Muszi. Oto są rody Lewiego według ich ojców:
###### **1Krn 6,5**
 Gerszoma: syn jego Libni, syn jego Jachat, syn jego Zimma,
###### **1Krn 6,6**
 syn jego Joach, syn jego Iddo, syn jego Zerach, syn jego Jeatraj.
###### **1Krn 6,7**
 Synowie Kehata: syn jego Amminadab, syn jego Korach, syn jego Assir,
###### **1Krn 6,8**
 syn jego Elkana, syn jego Ebiasaf, syn jego Assir,
###### **1Krn 6,9**
 syn jego Tachat, syn jego Uriel, syn jego Ozjasz, syn jego Saul.
###### **1Krn 6,10**
 Synowie Elkany: Amasaj i Achimot.
###### **1Krn 6,11**
 Syn jego Elkana, syn jego Sofaj, syn jego Nachat,
###### **1Krn 6,12**
 syn jego Eliab, syn jego Jerocham, syn jego Elkana.
###### **1Krn 6,13**
 Synowie Samuela: pierworodny Joel i drugi Abiasz.
###### **1Krn 6,14**
 Synowie Merariego: syn jego Machli, syn jego Libni, syn jego Szimei, syn jego Uzza,
###### **1Krn 6,15**
 syn jego Szimea, syn jego Chaggiasz, syn jego Asajasz.
###### **1Krn 6,16**
 Tych ustanowił Dawid dla prowadzenia śpiewu w domu Bożym, odkąd spoczęła tam arka.
###### **1Krn 6,17**
 I byli na służbie śpiewaczej przed przybytkiem Namiotu Spotkania, dopóki Salomon nie zbudował domu Pańskiego w Jerozolimie. Stawali zaś do służby zgodnie z ustalonym porządkiem.
###### **1Krn 6,18**
 Ci więc stawali wraz z synami swoimi: spośród synów Kehata: Heman, śpiewak, syn Joela, syna Samuela,
###### **1Krn 6,19**
 syna Elkany, syna Jerochama, syna Eliela, syna Toacha,
###### **1Krn 6,20**
 syna Sufa, syna Elkany, syna Machata, syna Amasaja,
###### **1Krn 6,21**
 syna Elkany, syna Joela, syna Azariasza, syna Sefaniasza,
###### **1Krn 6,22**
 syna Tachata, syna Assira, syna Ebiasafa, syna Koracha,
###### **1Krn 6,23**
 syna Jishara, syna Kehata, syna Lewiego, syna Izraela.
###### **1Krn 6,24**
 Brat jego, Asaf, stał po jego prawej stronie: Asaf, syn Berekiasza, syna Szimei,
###### **1Krn 6,25**
 syna Mikaela, syna Baasejasza, syna Malkiasza,
###### **1Krn 6,26**
 syna Etniego, syna Zeracha, syna Adajasza,
###### **1Krn 6,27**
 syna Etana, syna Zimmy, syna Szimejego,
###### **1Krn 6,28**
 syna Jachata, syna Gerszoma, syna Lewiego.
###### **1Krn 6,29**
 Synowie Merariego, ich bracia, stawali po lewej stronie: Etan, syn Kisziego, syna Abdiego, syna Malluka,
###### **1Krn 6,30**
 syna Chaszabiasza, syna Amazjasza, syna Chilkiasza,
###### **1Krn 6,31**
 syna Amsjego, syna Baniego, syna Szemera,
###### **1Krn 6,32**
 syna Machliego, syna Musziego, syna Merariego, syna Lewiego.
###### **1Krn 6,33**
 Bracia ich, lewici, byli przeznaczeni do wszelkich usług w przybytku domu Bożego.
###### **1Krn 6,34**
 Aaron zaś i jego synowie zamieniali w dym ofiary na ołtarzu całopalenia i na ołtarzu kadzenia, zgodnie z całą posługą w Miejscu Najświętszym, aby dokonywać przebłagania za Izraela, według tego wszystkiego, co nakazał sługa Boży, Mojżesz.
###### **1Krn 6,35**
 Oto są synowie Aarona: synem jego Eleazar, synem jego Pinchas, synem jego Abiszua,
###### **1Krn 6,36**
 synem jego Bukki, synem jego Uzzi, synem jego Zerachiasz,
###### **1Krn 6,37**
 synem jego Merajot, synem jego Amariasz, synem jego Achitub,
###### **1Krn 6,38**
 synem jego Sadok, synem jego Achimaas.
###### **1Krn 6,39**
 A oto miejsca ich zamieszkania, według ich siedzib w wyznaczonych dla nich granicach. Synom Aarona z rodu Kehata – taki bowiem dział wyznaczono im przez losowanie –
###### **1Krn 6,40**
 dano Hebron w ziemi judzkiej wraz z otaczającymi go pastwiskami.
###### **1Krn 6,41**
 Pola zaś miejskie i ich osiedla dano Kalebowi, synowi Jefunnego.
###### **1Krn 6,42**
 Synom Aarona dano także miasta ucieczki: Hebron i Libnę wraz z ich pastwiskami, Jattir i Esztemoa z ich pastwiskami,
###### **1Krn 6,43**
 Chilaz z jego pastwiskami, Debir z jego pastwiskami,
###### **1Krn 6,44**
 Aszan z jego pastwiskami i Bet-Szemesz z jego pastwiskami.
###### **1Krn 6,45**
 Od pokolenia Beniamina: Geba z jej pastwiskami, Alemet z jego pastwiskami i Anatot z jego pastwiskami; wszystkich miast trzynaście według ich rodzin.
###### **1Krn 6,46**
 Pozostałym synom Kehata, spośród rodzin tegoż pokolenia, przypadło losem dziesięć miast od pokolenia < Efraima, pokolenia Dana i > od połowy pokolenia Manassesa.
###### **1Krn 6,47**
 Synom Gerszoma, według ich rodzin, od pokolenia Issachara, od pokolenia Asera, od pokolenia Neftalego i od pokolenia Manassesa w Baszanie: trzynaście miast.
###### **1Krn 6,48**
 Synom Merariego, według ich rodzin, przypadło losem od pokolenia Rubena, od pokolenia Gada i od pokolenia Zabulona: dwanaście miast.
###### **1Krn 6,49**
 Izraelici dali lewitom te miasta wraz z ich pastwiskami.
###### **1Krn 6,50**
 Dali oni przez losowanie z ziem należących do pokolenia synów Judy, do pokolenia synów Symeona i do pokolenia synów Beniamina te miasta, którym nadali ich imiona.
###### **1Krn 6,51**
 Niektóre rodziny synów Kehata miały miasta wylosowane od pokolenia Efraima.
###### **1Krn 6,52**
 Dano im miasta ucieczki: Sychem z jego pastwiskami na gorze Efraima, Gezer z jego pastwiskami,
###### **1Krn 6,53**
 Jokmeam z jego pastwiskami, Bet-Choron z jego pastwiskami,
###### **1Krn 6,54**
 Ajjalon z jego pastwiskami i Gat-Rimmon z jego pastwiskami.
###### **1Krn 6,55**
 A od połowy pokolenia Manassesa – dla pozostałych rodzin Kehata: Aner z jego pastwiskami i Bileam z jego pastwiskami.
###### **1Krn 6,56**
 Synom Gerszoma dano od połowy pokolenia Manassesa: Golan w Baszanie z jego pastwiskami i Asztarot z jego pastwiskami.
###### **1Krn 6,57**
 Od pokolenia Issachara: Kedesz z jego pastwiskami, Dobrat z jego pastwiskami,
###### **1Krn 6,58**
 Ramot z jego pastwiskami i Anem z jego pastwiskami.
###### **1Krn 6,59**
 Od pokolenia Asera: Maszal z jego pastwiskami, Abdon z jego pastwiskami,
###### **1Krn 6,60**
 Chukok z jego pastwiskami i Rechob z jego pastwiskami.
###### **1Krn 6,61**
 Od pokolenia Neftalego: Kadesz w Galilei z jego pastwiskami, Chammon z jego pastwiskami i Kiriataim z jego pastwiskami.
###### **1Krn 6,62**
 Pozostałym synom Merariego od pokolenia Zabulona: Rimmono z jego pastwiskami i Tabor z jego pastwiskami.
###### **1Krn 6,63**
 A za Jordanem, koło Jerycha, na wschód od Jordanu, od pokolenia Rubena: Beser w pustyni z jego pastwiskami, Jahsę z jej pastwiskami,
###### **1Krn 6,64**
 Kedemot z jego pastwiskami i Mefaat z jego pastwiskami.
###### **1Krn 6,65**
 Od pokolenia Gada: Ramot w Gileadzie z jego pastwiskami, Machanaim z jego pastwiskami,
###### **1Krn 6,66**
 Cheszbon z jego pastwiskami i Jazer z jego pastwiskami.
# 1Krn 6 PAU
###### **1Krn 6,1**
 Synami Lewiego byli: Gerszom, Kehat i Merari.
###### **1Krn 6,2**
 A oto imiona synów Gerszoma: Libni i Szimei.
###### **1Krn 6,3**
 Synami Kehata byli Amram, Ishar, Chebron i Uzzjel.
###### **1Krn 6,4**
 Synami Merariego byli Machli i Muszi. To są rody Lewitów według ich przodków.
###### **1Krn 6,5**
 Potomkowie Gerszoma: jego syn Libni, jego syn Jachat, jego syn Zimma,
###### **1Krn 6,6**
 jego syn Joach, jego syn Iddo, jego syn Zerach, jego syn Jeatraj.
###### **1Krn 6,7**
 Potomkowie Kehata: jego syn Amminadab, jego syn Korach, jego syn Assir,
###### **1Krn 6,8**
 jego syn Elkana, jego syn Ebiasaf, jego syn Assir,
###### **1Krn 6,9**
 jego syn Tachat, jego syn Uriel, jego syn Ozjasz, jego syn Saul.
###### **1Krn 6,10**
 Oto synowie Elkany: Amasaj i Achimot,
###### **1Krn 6,11**
 jego syn Elkana, jego syn Sofaj, jego syn Nachat,
###### **1Krn 6,12**
 jego syn Eliab, jego syn Jerocham, jego syn Elkana.
###### **1Krn 6,13**
 Synowie Samuela: pierworodny Joel, drugi Abiasz.
###### **1Krn 6,14**
 Potomkowie Merariego: jego syn Machli, jego syn Libni, jego syn Szimei, jego syn Uzza,
###### **1Krn 6,15**
 jego syn Szimea, jego syn Chaggiasz, jego syn Asajasz.
###### **1Krn 6,16**
 Dawid ustanowił tych, którzy mieli prowadzić śpiew w domu PANA, gdy zostanie w nim umieszczona arka.
###### **1Krn 6,17**
 Posługiwali oni w Jego obecności, śpiewając w świętym mieszkaniu, w Namiocie Spotkania, dopóki Salomon nie zbudował domu PANA w Jerozolimie. Stawali do służby zgodnie z ustalonym porządkiem.
###### **1Krn 6,18**
 Oto ci, którzy stawali do służby wraz ze swymi synami. Spośród Kehatytów: Heman, śpiewak, syn Joela, syna Samuela,
###### **1Krn 6,19**
 syna Elkany, syna Jerochama, syna Eliela, syna Toacha,
###### **1Krn 6,20**
 syna Sufa, syna Elkany, syna Machata, syna Amasaja,
###### **1Krn 6,21**
 syna Elkany, syna Joela, syna Azariasza, syna Sefaniasza,
###### **1Krn 6,22**
 syna Tachata, syna Assira, syna Ebiasafa, syna Koracha,
###### **1Krn 6,23**
 syna Jeshara, syna Kehata, syna Lewiego, syna Izraela.
###### **1Krn 6,24**
 Po prawej stronie Hemana stał jego rodak Asaf, syn Berekiasza, syna Szimeiego,
###### **1Krn 6,25**
 syna Mikaela, syna Baasejasza, syna Malkiasza,
###### **1Krn 6,26**
 syna Etniego, syna Zeracha, syna Adajasza,
###### **1Krn 6,27**
 syna Etana, syna Zimmy, syna Szimeiego,
###### **1Krn 6,28**
 syna Jachata, syna Gerszoma, syna Lewiego.
###### **1Krn 6,29**
 Po lewej stronie stali ich bracia, potomkowie Merariego: Etan, syn Kisziego, syna Abdiego, syna Malluka,
###### **1Krn 6,30**
 syna Chaszabiasza, syna Amazjasza, syna Chilkiasza,
###### **1Krn 6,31**
 syna Amsjego, syna Baniego, syna Szemera,
###### **1Krn 6,32**
 syna Machliego, syna Musziego, syna Merariego, syna Lewiego.
###### **1Krn 6,33**
 Pozostali bracia Lewici byli przeznaczeni do wszystkich posług w mieszkaniu domu Bożego.
###### **1Krn 6,34**
 Aaron i jego synowie składali ofiary na ołtarzu całopalenia i na ołtarzu kadzielnym, dokonując obrzędu zadośćuczynienia za Izraela. Składając ofiary, przestrzegali przepisów kultu w miejscu najświętszym i wszystkich nakazów sługi Bożego Mojżesza.
###### **1Krn 6,35**
 Oto potomkowie Aarona: jego syn Eleazar, jego syn Pinchas, jego syn Abiszua,
###### **1Krn 6,36**
 jego syn Bukki, jego syn Uzzi, jego syn Zerachiasz,
###### **1Krn 6,37**
 jego syn Merajot, jego syn Amariasz, jego syn Achitub,
###### **1Krn 6,38**
 jego syn Sadok, jego syn Achimaas.
###### **1Krn 6,39**
 Oto ich osiedla stosownie do obozów w granicach, jakie im wyznaczono. Aaronitom z rodu Kehata, na których padł pierwszy los,
###### **1Krn 6,40**
 dano Hebron w ziemi judzkiej wraz z okolicznymi pastwiskami,
###### **1Krn 6,41**
 pola zaś należące do miasta i ich osiedla przekazano Kalebowi, synowi Jefunnego.
###### **1Krn 6,42**
 Aaronitom dano również miasta azylu: Hebron i Libnę wraz z pastwiskami, Jattir i Esztemoa wraz z pastwiskami,
###### **1Krn 6,43**
 Chilaz i Debir wraz z pastwiskami,
###### **1Krn 6,44**
 Aszan wraz z pastwiskami i Bet-Szemesz wraz z pastwiskami.
###### **1Krn 6,45**
 Otrzymali również od Beniaminitów Geba wraz z pastwiskami, Alemet wraz z pastwiskami, Anatot wraz z ich pastwiskami. Razem trzynaście miast dla poszczególnych rodzin.
###### **1Krn 6,46**
 Pozostali potomkowie Kehata otrzymali w drodze losowania dziesięć miast, od połowy ich rodów, to jest od połowy plemienia Manasessa.
###### **1Krn 6,47**
 Potomkowie Gerszona otrzymali, według wielkości ich rodzin, trzynaście miast na ziemiach należących do plemion Issachara, Asera i Neftalego oraz w Baszanie - od plemienia Manassesa.
###### **1Krn 6,48**
 Potomkom Merariego, według ich rodów, przypadło w drodze losowania dwanaście miast od plemion Rubena, Gada i Zabulona.
###### **1Krn 6,49**
 Izraelici przekazali Lewitom te miasta wraz z ich pastwiskami.
###### **1Krn 6,50**
 Wyżej wymienione miasta, którym nadali nazwy, zostały im przekazane w drodze losowania przez plemię Judy, plemię Symeona oraz plemię Beniamina.
###### **1Krn 6,51**
 Niektóre z rodów należących do potomków Kehata otrzymały od Efraimitów miasta graniczne.
###### **1Krn 6,52**
 Przekazano im również miasta azylu: Sychem na górach Efraima z pastwiskami oraz Gezer wraz z pastwiskami,
###### **1Krn 6,53**
 Jokmeam i Bet-Choron wraz z pastwiskami,
###### **1Krn 6,54**
 Ajjalon wraz z pastwiskami i Gat-Rimmon wraz z pastwiskami.
###### **1Krn 6,55**
 Inni potomkowie Kehata otrzymali od połowy plemienia Manassesa Aner i Bileam wraz z pastwiskami.
###### **1Krn 6,56**
 Potomkowie Gerszoma otrzymali od połowy plemienia Manassesa Golan w Baszanie wraz z pastwiskami i Asztarot wraz z pastwiskami.
###### **1Krn 6,57**
 Od plemienia Issachara otrzymali Kedesz i Dobrat wraz z pastwiskami,
###### **1Krn 6,58**
 Ramot wraz z pastwiskami i Anem z pastwiskami.
###### **1Krn 6,59**
 Od plemienia Asera otrzymali Maszal i Abdon wraz z pastwiskami,
###### **1Krn 6,60**
 Chukok wraz z pastwiskami i Rechob wraz z pastwiskami.
###### **1Krn 6,61**
 Od plemienia Neftalego przypadły im w udziale Kadesz w Galilei wraz z pastwiskami oraz Chammon i Kiriataim wraz z pastwiskami.
###### **1Krn 6,62**
 Pozostali potomkowie Merariego otrzymali od plemienia Zabulona Rimmono wraz z pastwiskami i Tabor z pastwiskami.
###### **1Krn 6,63**
 Na Zajordaniu zaś, na wschód od Jerycha, otrzymali od plemienia Rubena Beser na pustyni wraz z pastwiskami i Jahsę z pastwiskami
###### **1Krn 6,64**
 oraz Kedemot i Mefaat wraz z pastwiskami.
###### **1Krn 6,65**
 Od plemienia Gada otrzymali Ramot w Gileadzie wraz z pastwiskami, Machanaim wraz z pastwiskami
###### **1Krn 6,66**
 oraz Cheszbon i Jazer z pastwiskami.
# 1Krn 6 BP
###### **1Krn 6,1**
 Synami Lewiego byli: Gerszom, Kehat i Merari.
###### **1Krn 6,2**
 Synom Gerszoma było na imię Libni i Szimi.
###### **1Krn 6,3**
 Synami Kehata byli: Amram, Ishar, Chebron i Uzziel.
###### **1Krn 6,4**
 Synami Merariego byli: Machli i Muszi. To są rody Lewiego według ich ojców.
###### **1Krn 6,5**
 Od Gerszoma pochodzi jego syn Libni, jego syn Jachat, jego syn Zimma,
###### **1Krn 6,6**
 jego syn Joach, jego syn Iddo, jego syn Zerach, jego syn Jeatraj.
###### **1Krn 6,7**
 Potomkiem Kehata był jego syn Amminadab, jego syn Korach, jego syn Assir,
###### **1Krn 6,8**
 jego syn Elkana, jego syn Ebjasaf, jego syn Assir,
###### **1Krn 6,9**
 jego syn Tachat, jego syn Uriel, jego syn Uzzijja i jego syn Szaul.
###### **1Krn 6,10**
 Synami Elkany byli: Amasaj i Achimot.
###### **1Krn 6,11**
 Jego synem był Elkana, jego synem Cofaj, jego synem Nachat,
###### **1Krn 6,12**
 jego synem Eliab, jego synem Jerocham, jego synem Elkana.
###### **1Krn 6,13**
 Synami Szemuela byli: pierworodny Joel i drugi: Abijja.
###### **1Krn 6,14**
 Synem Merariego był Machli, jego synem Libni, jego synem Szimi, jego synem Uzza;
###### **1Krn 6,15**
 jego synem Szima, jego synem Chaggijja, jego synem Asaja.
###### **1Krn 6,16**
 To są ci, którym Dawid powierzył troskę o śpiew w Domu Jahwe, odkąd spoczęła tam Arka.
###### **1Krn 6,17**
 I pełnili obowiązki śpiewaków przed Przybytkiem Namiotu Zjednoczenia, dopóki Salomon nie wzniósł Domu Jahwe w Jeruzalem. Pełnili zaś swoją służbę zgodnie z przepisami.
###### **1Krn 6,18**
 A oto ci, którzy pełnili służbę razem ze swymi synami: spośród Kehatytów śpiewak Heman, syn Joela, który był synem Samuela;
###### **1Krn 6,19**
 ten był synem Elkany, syna Jerochama, syna Eliela, syna Toacha;
###### **1Krn 6,20**
 syna Cufa, syna Elkany, syna Machata, syna Amasaja;
###### **1Krn 6,21**
 syna Elkany, syna Joela, syna Azarji, syna Cefanji;
###### **1Krn 6,22**
 syna Tachata, syna Assira, syna Ebiasafa, syna Koracha;
###### **1Krn 6,23**
 syna Ishara, syna Kehata, syna Lewiego, syna Izraela.
###### **1Krn 6,24**
 Jego bratem był Asaf, który stał po jego prawej stronie. Asaf był synem Berekjahu, syna Szimi,
###### **1Krn 6,25**
 syna Mikaela, syna Baasei, syna Malkijji;
###### **1Krn 6,26**
 syna Etniego, syna Zeracha, syna Adaji;
###### **1Krn 6,27**
 syna Etana, syna Zimmy, syna Szimiego;
###### **1Krn 6,28**
 syna Jachata, syna Gerszoma, syna Lewiego.
###### **1Krn 6,29**
 Synowie Merariego, ich bracia, po lewej stronie: Etan, syn Kisziego, syna Abdiego, syna Malluka;
###### **1Krn 6,30**
 syna Chaszabji, syna Amacji, syna Chilkijji;
###### **1Krn 6,31**
 syna Amcjego, syna Baniego, syna Szamera,
###### **1Krn 6,32**
 syna Machliego, syna Musziego, syna Merariego, syna Lewiego.
###### **1Krn 6,33**
 Bracia ich, lewici, byli przeznaczeni do pełnienia wszelkich prac w Przybytku Domu Bożego.
###### **1Krn 6,34**
 Aaron zaś i jego synowie składali ofiary na ołtarzu całopalenia i na ołtarzu kadzielnym, byli odpowiedzialni za wszystko, co dotyczyło Świętego Świętych oraz za dokonywanie przebłagania w imieniu Izraela według wszystkiego, co nakazał Sługa Boga, Mojżesz.
###### **1Krn 6,35**
 Potomkami Aarona byli: syn jego Eleazar, jego syn Pinchas, jego syn Abiszua,
###### **1Krn 6,36**
 jego syn Bukki, jego syn Uzzi, jego syn Zerachja,
###### **1Krn 6,37**
 jego syn Merajot, jego syn Amarja, jego syn Achitub,
###### **1Krn 6,38**
 jego syn Cadok, jego syn Achimaac.
###### **1Krn 6,39**
 A te są miasta ich zamieszkania według ich siedzib na wyznaczonym dla nich obszarze: potomkom Aarona z rodu Kehatytów, dla nich bowiem padł pierwszy dział przy losowaniu,
###### **1Krn 6,40**
 oddano Chebron w ziemi judzkiej razem z pastwiskami, które są wokół niego.
###### **1Krn 6,41**
 Należącą jednak do miasta ziemię uprawną razem z osiedlami oddano Kalebowi, synowi Jefunnego.
###### **1Krn 6,42**
 Potomkom Aarona dano nadto miasta ucieczki Chebron i Libnę oraz ich pastwiska, Jattir i Esztemoę oraz ich pastwiska,
###### **1Krn 6,43**
 Chilez i jego pastwiska, Debir i jego pastwiska,
###### **1Krn 6,44**
 Aszan i jego pastwiska oraz Bet-Szemesz i jego pastwiska.
###### **1Krn 6,45**
 Z pokolenia Beniamina przydzielono im Gebę wraz z jej pastwiskami, Alemet wraz z jego pastwiskami, Anatot wraz z jego pastwiskami, razem trzynaście miast dla ich rodów.
###### **1Krn 6,46**
 Pozostali synowie Kehata odpowiednio do swych rodów otrzymali losem dziesięć miast od pokolenia Efraima, od pokolenia Dana i od połowy pokolenia Manassego.
###### **1Krn 6,47**
 Synowie Gerszoma otrzymali odpowiednio do swych rodów trzynaście miast od pokolenia Issachara, Aszera, Neftalego i od pokolenia Manassego w Baszanie.
###### **1Krn 6,48**
 Synowie Merariego odpowiednio do swych rodów otrzymali losem dwanaście miast od pokolenia Rubena, Dana i Zebulona.
###### **1Krn 6,49**
 Dali więc synowie Izraela Lewitom miasta wraz z ich pastwiskami.
###### **1Krn 6,50**
 Przydzielili im przez losowanie od pokolenia Judy, od pokolenia Symeona i od pokolenia Beniamina te miasta i nadali im nazwy.
###### **1Krn 6,51**
 Innym rodom Kehatytów przypadły losem miasta w granicach pokolenia Efraima.
###### **1Krn 6,52**
 Dano im jako miasta ucieczki: Sychem wraz z jego pastwiskami w górach Efraim, Gezer wraz z jego pastwiskami,
###### **1Krn 6,53**
 Jokmeam wraz z pastwiskami, Bet-Choron wraz z pastwiskami,
###### **1Krn 6,54**
 Ajjalon wraz z pastwiskami i Gat-Rimmon wraz z pastwiskami.
###### **1Krn 6,55**
 A od połowy pokolenia Manassego (otrzymali) Aner wraz z pastwiskami i Bilam wraz z pastwiskami; (te miasta otrzymały) pozostałe rody Kehatytów.
###### **1Krn 6,56**
 Synom Gerszoma przydzielono od rodów połowy pokolenia Manassego Golan w Baszanie wraz z pastwiskami i Asztarot wraz z pastwiskami.
###### **1Krn 6,57**
 Od pokolenia Issachara (otrzymali) Kedesz wraz z pastwiskami i Deberat wraz z pastwiskami,
###### **1Krn 6,58**
 dalej Ramot wraz z pastwiskami i Anem wraz z pastwiskami,
###### **1Krn 6,59**
 od pokolenia Aszera-Maszal wraz z pastwiskami i Abdon wraz z pastwiskami,
###### **1Krn 6,60**
 Chukok wraz z pastwiskami i Rechob wraz z pastwiskami,
###### **1Krn 6,61**
 od pokolenia Neftalego: Kedesz w Galilei wraz z pastwiskami, Chammon wraz z pastwiskami i Kirjatajim wraz z pastwiskami.
###### **1Krn 6,62**
 Pozostali synowie Merariego otrzymali od pokolenia Zebulona Rimmon wraz z pastwiskami i Tabor wraz z pastwiskami.
###### **1Krn 6,63**
 Po drugiej stronie Jordanu, w okolicy Jerycha na wschód od Jordanu (otrzymali) od pokolenia Rubena: Becer na pustym wraz z pastwiskami i Jahcę wraz z pastwiskami,
###### **1Krn 6,64**
 Kedemot wraz z pastwiskami i Mefaat wraz z pastwiskami.
###### **1Krn 6,65**
 Od pokolenia Gada: Ramot w Gileadzie wraz z pastwiskami i Machanajim wraz z pastwiskami
###### **1Krn 6,66**
 oraz Cheszbon wraz z pastwiskami i Jazer wraz z pastwiskami.
# 1Krn 6 BR
###### **1Krn 6,1**
 A oto synowie Lewiego: Gerszom, Kehat, Merari.
###### **1Krn 6,2**
 Synami Gerszoma byli Libni i Szimei,
###### **1Krn 6,3**
 a synami Kehata - Amram, Jishan, Chebron i Uzzjel.
###### **1Krn 6,4**
 Synami Merariego byli Machli i Muszi. A oto rody Lewiego według przywódców poszczególnych rodów.
###### **1Krn 6,5**
 Gerszom był ojcem Libniego, Libni ojcem Jachata, a Jachat ojcem Zimmy,
###### **1Krn 6,6**
 Zimma zaś ojcem Joacha, Joach ojcem Iddo, Iddo ojcem Zeracha, a Zerach ojcem Jeatraja.
###### **1Krn 6,7**
 Kehat był ojcem Amminadaba, Amminadab ojcem Koracha, Korach ojcem Assira,
###### **1Krn 6,8**
 Assir ojcem Elkany, Elkana ojcem Ebiasafa, Ebiasaf ojcem Assira,
###### **1Krn 6,9**
 Assir ojcem Tachata, Tachat ojcem Uriela, Uriel ojcem Ozjasza, a Ozjasz ojcem Saula.
###### **1Krn 6,10**
 Elkana miał dwóch synów: Amasaja i Achimota.
###### **1Krn 6,11**
 Elkana był również ojcem Elkany, który miał syna Sofaja. A Sofaj był ojcem Nachata,
###### **1Krn 6,12**
 Nachat zaś był ojcem Eliaba, Eliab ojcem Jerochama, a Jerocham ojcem Elkany.
###### **1Krn 6,13**
 Synami Samuela byli Joel jako pierworodny oraz Abiasz.
###### **1Krn 6,14**
 Merari był ojcem Machliego, Machli był ojcem Libniego, Libni ojcem Szimeiego, a Szimei ojcem Uzzy.
###### **1Krn 6,15**
 Uzza ojcem Szimei, Szimea ojcem Chaggiasza, a Chaggiasz ojcem Asajasza.
###### **1Krn 6,16**
 A oto ci, których Dawid wyznaczył, aby przewodzili śpiewom w świątyni Jahwe, odkąd złożono w niej arkę.
###### **1Krn 6,17**
 Swoją służbę kantorów pełnili przed przybytkiem Namiotu Spotkania, dopóki Salomon nie wzniósł świątyni Jahwe w Jerozolimie. Pełnili swoją służbę według ustalonego porządku.
###### **1Krn 6,18**
 A oto ci, którzy razem ze swymi synami byli odpowiedzialni za służbę w świątyni. Spośród synów Kehata: Heman, śpiewak, syn Joela, syna Samuela,
###### **1Krn 6,19**
 syna Elkany, syna Jerochama, syna Eliela, syna Toacha,
###### **1Krn 6,20**
 syna Sufa, syna Elkany, syna Machata, syna Amasaja,
###### **1Krn 6,21**
 syna Elkany, syna Joela, syna Azariasza, syna Sefaniasza,
###### **1Krn 6,22**
 syna Tachata, syna Assira, syna Ebiasafa, syna Koracha,
###### **1Krn 6,23**
 syna Jishara, syna Kehata, syna Lewiego, syna Izraela.
###### **1Krn 6,24**
 Po jego prawej stronie stał jego brat Asaf, którego ojcem był Berekiasz, a ojcem Berekiasza był Szimea,
###### **1Krn 6,25**
 Szimea zaś był synem Mikaela, Mikael synem Baasejasza, a Baasejasz synem Malkiasza.
###### **1Krn 6,26**
 Malkiasz był synem Etniego, Etni był synem Zeracha, Zerach był synem Adajasza,
###### **1Krn 6,27**
 Adajasz był synem Etana, Etan był synem Zimmy, Zimma zaś był synem Szimeiego,
###### **1Krn 6,28**
 Szimei był synem Jachata, Jachat synem Gerszoma, a Gerszom synem Lewiego.
###### **1Krn 6,29**
 Po lewej stronie stali ich bracia, synowie Merariego: Etan syn Kisziego, syna Abdiego, syna Malluka,
###### **1Krn 6,30**
 syna Chaszabisza, syna Amazjasza, syna Chilkiasza,
###### **1Krn 6,31**
 syna Amsjego, syna Baniego, syna Szemera,
###### **1Krn 6,32**
 syna Machliego, syna Musziego, syna Merariego, syna Lewiego.
###### **1Krn 6,33**
 Ich bracia, lewici, byli wyznaczeni do obsługi przybytku w domu Jahwe.
###### **1Krn 6,34**
 Natomiast Aaron i jego synowie składali ofiary całopalenia na ołtarzu całopaleń, a kadzidła palili na ołtarzu kadzenia. Oni też pełnili wszystkie posługi w Świętym Świętych i dokonywali przebłagania za cały Izrael, zgodnie ze wskazaniami sługi Bożego Mojżesza.
###### **1Krn 6,35**
 A oto potomkowie Aarona: Eleazar był synem Aarona, Pinchas synem Eleazara, Abiszua synem Pinchasa,
###### **1Krn 6,36**
 Bukki synem Abiszui, Uzzi synem Bukkiego, Zerachiasz synem Uzziego,
###### **1Krn 6,37**
 Merajot synem Zerachiasza, Amariasz synem Merajota, Achitub synem Amariasza,
###### **1Krn 6,38**
 Sadok synem Achituba, Achimaas synem Sadoka.
###### **1Krn 6,39**
 Takie zaś są posiadłości, których granice wyznaczono dla ich obozowisk: Synom Aarona z rodu Kehatytów
###### **1Krn 6,40**
 przydzielono jako pierwszym na mocy losowania miasto Hebron w ziemi judzkiej, razem z okolicznymi pastwiskami.
###### **1Krn 6,41**
 Pola uprawne zaś oraz osiedla podlegające miastu [Hebron] przyznano Kalebowi, synowi Jefunnego.
###### **1Krn 6,42**
 Synom Aarona przekazano również miasta ucieczki Hebron i Libnę wraz z okolicznymi pastwiskami, Jattir i Esztemoa z ich pastwiskami,
###### **1Krn 6,43**
 Chilaz z jego pastwiskami, Debir z jego pastwiskami,
###### **1Krn 6,44**
 Aszan z jego pastwiskami oraz Bet-Szemesz z jego pastwiskami.
###### **1Krn 6,45**
 Z posiadłości pokolenia Beniamina przydzielono [synom Aarona] miasta: Geba z jej pastwiskami, Alemet z jego pastwiskami i Anatot z jego pastwiskami. W sumie przekazano [synom Aarona] trzynaście miast, stosownie do liczby ich rodów.
###### **1Krn 6,46**
 Pozostałym Kehatytom przyznano losem dziesięć miast z posiadłości rodów tego pokolenia, to jest z połowy pokolenia Manassesa.
###### **1Krn 6,47**
 Potomkowie Gerszoma otrzymali stosownie do liczby ich rodów, w sumie trzynaście miast, wydzielonych z posiadłości pokoleń Issachara, Asera, Neftalego i Manassesa w ziemi Baszanu.
###### **1Krn 6,48**
 Synom Merariego wyznaczono losem, stosownie do liczby ich rodów, dwanaście miast, wziętych z posiadłości pokoleń Rubena, Gada i Zabulona.
###### **1Krn 6,49**
 W ten sposób synowie Izraela przekazali lewitom pewne miasta i przylegające do nich pastwiska.
###### **1Krn 6,50**
 Drogą losowania wydzielali miasta, wymienione według ich nazw, [i pastwiska] z [posiadłości] pokoleń Judy, Symeona i Beniamina.
###### **1Krn 6,51**
 Jeszcze innym rodom Kehatytów przydzielono pewne miasta przynależące do pokolenia Efraima.
###### **1Krn 6,52**
 Były to - jako miasto ucieczki - Sychem z okolicznymi pastwiskami położonymi w górach Efraima, Gezer z jego pastwiskami,
###### **1Krn 6,53**
 Jokmeam z jego pastwiskami, Bet-Choron z jego pastwiskami,
###### **1Krn 6,54**
 Ajjalon z jego pastwiskami i Gat-Rimmon z jego pastwiskami.
###### **1Krn 6,55**
 Z [posiadłości] zaś połowy pokolenia Manassesa wydzielono - dla pewnych rodów kehatyckich - miasto Aner z przylegającymi pastwiskami oraz Bileam z jego pastwiskami.
###### **1Krn 6,56**
 Synom Gerszoma zaś przydzielono: od połowy pokolenia Manassesa: Golan w Baszanie z okolicznymi pastwiskami i Asztarot z jego pastwiskami;
###### **1Krn 6,57**
 od pokolenia Issachara: Kedesz z jego pastwiskami, Dobrat z jego pastwiskami,
###### **1Krn 6,58**
 Ramot z jego pastwiskami i Anem z jego pastwiskami;
###### **1Krn 6,59**
 od pokolenia Asera: Maszal z jego pastwiskami, Abdon z jego pastwiskami,
###### **1Krn 6,60**
 Chukok z jego pastwiskami i Rechob z jego pastwiskami;
###### **1Krn 6,61**
 wreszcie od pokolenia Neftalego: Kadesz w Galilei z okolicznymi pastwiskami, Chammon z jego pastwiskami i Kiriataim z jego pastwiskami.
###### **1Krn 6,62**
 Pozostałym synom Merariego przyznano z [posiadłości] pokolenia Zabulona: Rimmono z jego pastwiskami i Tabor z jego pastwiskami.
###### **1Krn 6,63**
 Od pokolenia Rubena, za Jordanem, po wschodniej stronie Jerycha, wydzielono: Beser, położone już na pustyni, razem z najbliższymi pastwiskami, Jahsę z jej pastwiskami,
###### **1Krn 6,64**
 Kedemot z jego pastwiskami i Mefaat z jego pastwiskami.
###### **1Krn 6,65**
 Od pokolenia Gada wydzielono: Ramot w Gileadzie z jego pastwiskami, Machanaim z jego pastwiskami,
###### **1Krn 6,66**
 Cheszbon z jego pastwiskami i Jazer z jego pastwiskami.
# 1Krn 6 WUJ
###### **1Krn 6,1**
 Synowie Lewi: Gerson, Kaath, i Merari.
###### **1Krn 6,2**
 Synowie Kaath: Amram, Isaar, Hebron, i Oziel.
###### **1Krn 6,3**
 Synowie Amramowi: Aaron, Mojżesz i Marya. Synowie Aaronowi: Nadab i Abiu, Eleazar, i Ithamar.
###### **1Krn 6,4**
 Eleazar zrodził Phinees, a Phinees zrodził Abisue,
###### **1Krn 6,5**
 A Abisue zaś zrodził Bokci, a Bokci zrodził Ozy.
###### **1Krn 6,6**
 Ozy zrodził Zaraję, a Zarajas zrodził Merajoth.
###### **1Krn 6,7**
 Merajoth lepak zrodził Amaryasza, Amaryasz zrodził Achitoba.
###### **1Krn 6,8**
 Achitob zrodził Sadoka, a Sadok zrodził Achimasa.
###### **1Krn 6,9**
 Achimaas zrodził Azaryasza, Azaryasz zrodził Johanana,
###### **1Krn 6,10**
 Johanan zrodził Azaryasza, tenci jest, który kapłański urząd odprawował w domu, który zbudował Salomon w Jeruzalem.
###### **1Krn 6,11**
 A Azaryasz zrodził Amaryasza, a Amaryasz zrodził Achitoba,
###### **1Krn 6,12**
 Achitob zrodził Sadoka, a Sadok zrodził Selluma.
###### **1Krn 6,13**
 Sellum zrodził Helkiasza, a Helkiasz zrodził Azaryasza.
###### **1Krn 6,14**
 Azaryasz zrodził Sarajasza, a Sarajasz zrodził Josedeka.
###### **1Krn 6,15**
 Josedek lepak wyszedł, kiedy Pan przeniósł Judę i Jeruzalem przez ręce Nabuchodonozora.
###### **1Krn 6,16**
 A tak synowie Lewi: Gerson, Kaath i Merari.
###### **1Krn 6,17**
 A te imiona synów Gersonowych: Lobni i Semei.
###### **1Krn 6,18**
 Synowie Kaathowi: Amram, i Isaar, i Hebron, i Oziel.
###### **1Krn 6,19**
 Synowie Merarego: Moholi i Musi. A te są rodzaje Lewi, według domów ich.
###### **1Krn 6,20**
 Gersom, Lobni syn jego, Jahath syn jego, Zamma syn jego,
###### **1Krn 6,21**
 Joah syn jego, Addo syn jego, Zara syn jego, Jetrai syn jego.
###### **1Krn 6,22**
 Synowie Kaathowi: Aminadab syn jego, Kore syn jego, Asir syn jego,
###### **1Krn 6,23**
 Elkana syn jego, Abiasach syn jego, Asir syn jego.
###### **1Krn 6,24**
 Thahath syn jego, Uriel syn jego, Oziasz syn jego, Saul syn jego.
###### **1Krn 6,25**
 Synowie Elkanowi, Amasai, i Achimoth,
###### **1Krn 6,26**
 I Elkana: Synowie Elkanowi: Sophai syn jego, Nahath syn jego.
###### **1Krn 6,27**
 Eliab syn jego, Jeroham syn jego, Elkana syn jego.
###### **1Krn 6,28**
 Synowie Samuelowi, pierworodni Vasseni, i Abia.
###### **1Krn 6,29**
 A synowie Merarego Moholi: Lobni syn jego, Semei syn jego, Oza syn jego,
###### **1Krn 6,30**
 Sammaa syn jego, Haggia syn jego, Asaja syn jego.
###### **1Krn 6,31**
 Ci są, które postanowił Dawid nad śpiewaki domu Pańskiego, od tego czasu, gdy tam była skrzynia postawiona:
###### **1Krn 6,32**
 I służyli przed przybytkiem świadectwa śpiewając, aż Salomon zbudował dom Pański w Jeruzalem: a stali według rzędu swego na służbie.
###### **1Krn 6,33**
 A którzy stali z synmi swojemi ci są, z synów Kaatowych, Hemam śpiewak syn Johela, syna Samtielowego,
###### **1Krn 6,34**
 Syna Elkana, syna Jerohama, syna Eliela, syna Thohu,
###### **1Krn 6,35**
 Syna Suph, syna Elkana, syna Mahatha, syna Amasai,
###### **1Krn 6,36**
 Syna Elkana, syna Johela, syna Azaryasza, syna Sophoniasza,
###### **1Krn 6,37**
 Syna Thahata, syna Asira, syna Abiasapha, syna Korego, syna Isaara, syna Kaatha, syna Lewiego, syna Izraelowego.
###### **1Krn 6,38**
 A brat jego Asaph, który stał po prawicy jego, Asaph syn Barachiasza, syna Samaa.
###### **1Krn 6,39**
 Syna Michaelowego, syna Basajowego, syna Melchie.
###### **1Krn 6,40**
 Syna Athanai, syna Zare, syna Adai.
###### **1Krn 6,41**
 Syna Ethan, syna Zamma, syna Semei.
###### **1Krn 6,42**
 Syna Jetho, syna Gersom, syna Lewi.
###### **1Krn 6,43**
 A synowie Merari bracia ich, po lewej stronie,
###### **1Krn 6,44**
 Ethan syn Kusi, syna Abdi, syna Maloch,
###### **1Krn 6,45**
 Syna Hasabie, syna Amasiego, syna Helkiego,
###### **1Krn 6,46**
 Syna Amasai, syna Boni, syna Somer,
###### **1Krn 6,47**
 Syna Moholi, syna Musi, syna Merari, syna Lewi.
###### **1Krn 6,48**
 Bracia też ich Lewitowie, którzy postawieni są do wszelakiej służby przybytku domu Pańskiego.
###### **1Krn 6,49**
 Aaron lepak i synowie jego zapalili kadzidło na ołtarzu całopalenia, i na ołtarzu kadzenia, ku wszystkiej posłudze świętego świętych: ażeby się modlili za Izraela, wedle wszego co rozkazał Mojżesz sługa Boży.
###### **1Krn 6,50**
 A synowie Aaronowi ci są: Eleazar syn jego, Phinees syn jego, Abisue syn jego,
###### **1Krn 6,51**
 Bokci syn jego, Ozy syn jego, Zarahia syn jego,
###### **1Krn 6,52**
 Merajoth syn jego, Amaryasz syn jego, Achitob syn jego,
###### **1Krn 6,53**
 Sadok syn jego, Achimmaas syn jego.
###### **1Krn 6,54**
 A te mieszkania ich po wsiach i granicach, to jest synów Aaronowych, według rodów Kaathitów: bo się im były losem dostały.
###### **1Krn 6,55**
 A tak dali im Hebron w ziemi Judzkiej, i przedmieścia jego w około:
###### **1Krn 6,56**
 A pola miejskie i wsi, dali Kalebowi synowie Jephone,
###### **1Krn 6,57**
 A synom Aaronowym dali miasta na ucieczkę Hebron i Lobna, i przedmieścia jej.
###### **1Krn 6,58**
 Jether też, i Esthemo, z przedmieściami ich,
###### **1Krn 6,59**
 Asan też i Bethsemes i przedmieścia ich.
###### **1Krn 6,60**
 A z pokolenia Benjamin, Gabee i przedmieścia jej, i Almathę z przedmieściami jej, i Anathoth z przedmieściami sweini, wszystkich miast trzynaście, według rodzajów ich.
###### **1Krn 6,61**
 A drugim synom Kaathowym z rodzaju swego, dali od połowice pokolenia Manasse w osiadłość miast dziesięć.
###### **1Krn 6,62**
 A synom Gersomowym według rodzajów ich od pokolenia Issachar, i od pokolenia Aser, i od pokolenia Nephtali, i od pokolenia Manasse w Bazan miast trzynaście.
###### **1Krn 6,63**
 A synom zaś Merari według rodzajów ich od pokolenia Ruben, i od pokolenia Gad, i od pokolenia Zabulon, dali losem miast dwanaście.
###### **1Krn 6,64**
 Dali też synowie Izraelowi Lewitom miasta J przedmieścia ich:
###### **1Krn 6,65**
 A dali losem z pokolenia synów Juda, i z pokolenia synów Symeon, i z pokolenia synów Benjamin te miasta, które nazwali imiony swemi,
###### **1Krn 6,66**
 I tym, którzy byli z rodu synów Kaath i były miasta w granicach ich od pokolenia Ephraim.
###### **1Krn 6,67**
 A tak dali im miasta do ucieczki, Sichem z przedmieściami jego na górze Ephraim, i Gazer z przedmieściami jego,
###### **1Krn 6,68**
 Jekmaę też z przedmieściami jej, i Bethoron także,
###### **1Krn 6,69**
 Ktemu Helon z przedmieściami jego, i Gethremmon tymże sposobem.
###### **1Krn 6,70**
 A od połowice pokolenia Manasse, Aner i przedmieścia jego, Balaam i przedmieścia jego; to jest tymi którzy z rodu synów Kaath zostawali.
###### **1Krn 6,71**
 A synom Gersom od rodu pół pokolenia Manasse, Gaulon w Bazan, i przedmieścia jego, i Astharoth z przedmieściami jego.
###### **1Krn 6,72**
 Z pokolenia Isahar, Cedes i przedmieścia jego, i Dabereth z przedmieściami jego,
###### **1Krn 6,73**
 Ramoth też i przedmieścia jego, i Anem z przedmieściami jego.
###### **1Krn 6,74**
 A od pokolenia Aser: Masal z przedmieściami jego, i Abdon także,
###### **1Krn 6,75**
 Hukak też z przedmieściami jego, i Rohob z przedmieściami jego.
###### **1Krn 6,76**
 A od pokolenia Nephtali, Cedes w Galileiej i przedmieścia jego, Harnon z przedmieściami jego, i Kariathaim i przedmieścia jego.
###### **1Krn 6,77**
 A ostatkowi synom Merari: z pokolenia Zabulon, Remmono i przedmieścia jego, i Thabor z przedmieściami jego.
###### **1Krn 6,78**
 Za Jordanem też przeciw Jerycho na wschód słońca Jordana, od pokolenia Ruben Bozor w pustyni z przedmieściami jego, i Jassa z przedmieściami jej,
###### **1Krn 6,79**
 Kademoth też i przedmieścia jego, i Mephaat z przedmieściami jego.
###### **1Krn 6,80**
 Ktemu i od pokolenia Gad, Ramoth w Galaad i przedmieścia jego, i Manaim z przedmieściami jego.
###### **1Krn 6,81**
 Ale i Hesebon z przedmieściami jego, i Jezer z przedmieściami jego.
