# 2Krl 9 BT5
###### **2Krl 9,1**
 Prorok Elizeusz wezwał jednego z synów prorockich i powiedział mu: «***Przepasz biodra, weź ze sobą to naczyńko z oliwą i idź do Ramot w Gileadzie.***
###### **2Krl 9,2**
 ***Przyszedłszy tam, rozejrzyj się za Jehu, synem Jozafata, syna Nimsziego. Wejdź i nakłoń go, by podniósł się z grona swoich towarzyszy i zaprowadź go do najskrytszej izby.***
###### **2Krl 9,3**
 ***Wtedy weźmiesz naczyńko z oliwą i wylejesz ją na jego głowę, mówiąc: Tak mówi Pan: Namaściłem cię na króla nad Izraelem. Następnie otworzysz drzwi i uciekniesz bezzwłocznie***».
###### **2Krl 9,4**
 Młodzieniec więc, <młody prorok >, udał się do Ramot w Gileadzie.
###### **2Krl 9,5**
 Kiedy przyszedł, oto dowódcy wojska siedzieli razem. A on powiedział: «***Mam ci powiedzieć słowo, wodzu!***» Jehu zapytał: «***Komu spośród nas wszystkich?***» Odpowiedział: «***Tobie, wodzu!***»
###### **2Krl 9,6**
 Wtedy [Jehu] podniósł się i wszedł do domu. Tamten zaś wylał mu na głowę oliwę, mówiąc do niego: «***Tak mówi Pan, Bóg Izraela: Namaściłem cię na króla nad ludem Pańskim, nad Izraelem.***
###### **2Krl 9,7**
 ***Wytracisz rod Achaba, twego władcy, a ja pomszczę krew sług moich, proroków, i krew wszystkich sług Pańskich na Izebel.***
###### **2Krl 9,8**
  ***Zginie cała rodzina Achaba. Wytępię Achabowi nawet malca, niewolnika i wolnego w Izraelu.***
###### **2Krl 9,9**
 ***I postąpię z rodziną Achaba jak z rodziną Jeroboama, syna Nebata, i jak z domem Baszy, syna Achiasza.***
###### **2Krl 9,10**
 ***Izebel zaś pożrą psy na polu Jizreel, a nikt [jej] nie pochowa***». Następnie otworzył drzwi i uciekł.
###### **2Krl 9,11**
 Jehu wyszedł do sług swego władcy, którzy go zapytali: «***Czy wszystko idzie dobrze? Po co ten szaleniec przyszedł do ciebie?***» Odpowiedział im: «***Wy znacie człowieka i jego gadaninę***».
###### **2Krl 9,12**
 Lecz oni powiedzieli: «***Kłamstwo! Opowiedz, proszę, nam!***» Wtedy rzekł: «***Tak a tak powiedział do mnie: Tak mówi Pan: Namaściłem cię na króla Izraela***».
###### **2Krl 9,13**
 Wtedy pośpiesznie zdjęli swoje okrycia, rozesłali je pod jego stopami, na samych stopniach, zatrąbili i ogłosili: «***Jehu jest królem!***»
###### **2Krl 9,14**
 Jehu, syn Jozafata, syna Nimsziego, uknuł spisek przeciw Joramowi. Otóż Joram wraz z całym Izraelem strzegł Ramot w Gileadzie przed Chazaelem, królem Aramu.
###### **2Krl 9,15**
 Jednakże król Joram wycofał się do Jizreel, aby leczyć się z ran, które mu zadali Aramejczycy, gdy walczył przeciw Chazaelowi, królowi Aramu. Jehu powiedział: «***Jeżeli taki jest wasz zamiar, niech nie wyjdzie z miasta zbieg, aby zanieść wieść do Jizreel***».
###### **2Krl 9,16**
 Następnie Jehu wsiadł na rydwan i wyruszył do Jizreel, ponieważ Joram tam leżał chory. A Ochozjasz, król judzki, przybył odwiedzić Jorama.
###### **2Krl 9,17**
 Kiedy stojący na czatach na wieży w Jizreel ujrzał zdążający orszak Jehu, zawołał: «***Widzę orszak!***» Joram zaś rozkazał: «***Weź jeźdźca, poślij naprzeciw nich i niech zapyta, czy [to oznacza] pokój?***»
###### **2Krl 9,18**
 Więc jeździec na koniu ruszył naprzeciw Jehu i powiedział: «***Tak mówi król: Czy [to oznacza] pokój?***» Odpowiedział Jehu: «***Co ciebie obchodzi pokój? Jedź za mną!***» Stojący zaś na czatach oznajmił: «***Posłaniec przybył do nich, lecz nie wraca***».
###### **2Krl 9,19**
 Wysłał więc król drugiego jeźdźca na koniu, który podjechał do nich i powiedział: «***Tak mówi król: Czy [to oznacza] pokój?***» Odpowiedział Jehu: «***Co ciebie obchodzi pokój? Jedź za mną!***»
###### **2Krl 9,20**
 Stojący zaś na czatach oznajmił: «***Dotarł aż do nich, lecz nie wraca. A sposób jazdy tamtego jest podobny do jeżdżenia Jehu, syna Nimsziego, ponieważ jeździ szaleńczo***».
###### **2Krl 9,21**
 Wtedy Joram kazał zaprzęgać. Zaprzężono więc jego rydwan. Zatem Joram, król izraelski, i Ochozjasz, król judzki – każdy na swoim rydwanie – wyruszyli naprzeciw Jehu; spotkali go na polu Nabota z Jizreel.
###### **2Krl 9,22**
 Kiedy Joram ujrzał Jehu, zapytał: «***Czy [to oznacza] pokój, Jehu?***» Ten zaś odpowiedział: «***Jaki pokój? Gdy jeszcze trwają czyny nierządne twojej matki, Izebel, i liczne jej czary!***»
###### **2Krl 9,23**
 Wtedy Joram zawrócił i rzucił się do ucieczki, wołając do Ochozjasza: «***Zdrada, Ochozjaszu!***»
###### **2Krl 9,24**
 Lecz Jehu chwycił za łuk i trafił Jorama między ramiona, tak iż strzała przeszyła jego serce, a on opadł na swój rydwan.
###### **2Krl 9,25**
 Wtedy [Jehu] rzekł do Bidkara, swego tarczownika: «***Zabierz go i rzuć na rolę Nabota z Jizreel. Bo przypomnij sobie: ja i ty jechaliśmy konno we dwóch za jego ojcem, Achabem, kiedy Pan wypowiedział przeciw niemu ten wyrok:***
###### **2Krl 9,26**
 ***"Naprawdę, widziałem wczoraj wieczorem krew Nabota i krew synów jego – wyrocznia Pana. I odpłacę tobie na tym polu – wyrocznia Pana". Teraz więc zabierz go i rzuć na pole – według słowa Pańskiego***».
###### **2Krl 9,27**
 Kiedy Ochozjasz, król judzki, zobaczył to, uciekł drogą w stronę Bet-Haggan. Lecz Jehu ścigał go i rozkazał: «***Także jego zabijcie!***» Zranili go więc na jego rydwanie u podejścia do Gur, które leży w pobliżu Jibleam. A on uciekał dalej do Megiddo, gdzie umarł.
###### **2Krl 9,28**
 Słudzy jego przewieźli go do Jerozolimy i pochowali w grobie jego, razem z przodkami, w Mieście Dawidowym.
###### **2Krl 9,29**
 W jedenastym roku [panowania] Jorama, syna Achaba, Ochozjasz został królem judzkim.
###### **2Krl 9,30**
 Kiedy Jehu wszedł do Jizreel, a Izebel się o tym dowiedziała, poczerniła sobie powieki, ustroiła głowę i wyglądała z góry przez okno.
###### **2Krl 9,31**
 Gdy Jehu wchodził przez bramę, zawołała: «***Czy dobrze ci się wiedzie, Zimri, zabójco swego pana?***»
###### **2Krl 9,32**
 On zaś podniósł głowę w stronę okna i zawołał: «***Kto jest ze mną? Kto?***» I spojrzeli ku niemu z góry dwaj lub trzej eunuchowie.
###### **2Krl 9,33**
 Wtedy rozkazał: «***Wyrzućcie ją!***» I wyrzucili ją, a jej krew obryzgała mur i konie, które ją roztratowały.
###### **2Krl 9,34**
 Następnie wszedł, a kiedy najadł się i napił, powiedział: «***Zajmijcie się tą przeklętą i pochowajcie ją, ponieważ jest córką króla***».
###### **2Krl 9,35**
 Wyszli, aby ją pogrzebać, lecz znaleźli po niej tylko czaszkę, nogi i dłonie.
###### **2Krl 9,36**
 Kiedy wrócili i oznajmili mu, powiedział: «***Oto słowo Pana, które wypowiedział przez sługę swego, Eliasza z Tiszbe: Na polu Jizreel psy będą żarły ciało Izebel.***
###### **2Krl 9,37**
 ***A trup Izebel będzie jak gnój na polu w obrębie Jizreel, tak że nie będzie można powiedzieć: To jest Izebel***».
# 2Krl 9 PAU
###### **2Krl 9,1**
 Prorok Elizeusz wezwał jednego z uczniów proroków i polecił mu: „Przygotuj się do drogi! Weź z sobą to naczynie z oliwą i idź do Ramot w Gileadzie.
###### **2Krl 9,2**
 Kiedy tam przybędziesz, rozejrzyj się za Jehu, synem Jozafata, syna Nimsziego. Podejdź do niego i wywołaj go z grona jego współtowarzyszy. Potem zaprowadź go do osobnego pomieszczenia,
###### **2Krl 9,3**
 a następnie weź naczynie z oliwą i wylej mu ją na głowę, oświadczając: «Tak mówi PAN: Namaszczam cię na króla Izraela». Zaraz potem otwórz drzwi i natychmiast uciekaj”.
###### **2Krl 9,4**
 Tak więc młody prorok wyruszył do Ramot w Gileadzie.
###### **2Krl 9,5**
 Kiedy przybył, dowódcy wojska siedzieli właśnie razem. Przemówił więc: „Mam do ciebie słowo, wodzu”. Odezwał się Jehu: „Do kogo z nas?”. Odpowiedział: „Do ciebie, wodzu”.
###### **2Krl 9,6**
 Jehu wstał i wszedł do domu. On zaś wylał oliwę na jego głowę, oświadczając mu: „Tak mówi PAN, Bóg Izraela: «Namaszczam cię na króla nad ludem PANA, Izraelem.
###### **2Krl 9,7**
 Zniszczysz dom Achaba, twojego pana; w ten sposób pomszczę krew moich sług, proroków - krew wszystkich sług PANA, przelaną przez Izebel.
###### **2Krl 9,8**
 Zginie cały dom Achaba: wytępię Achabowi w Izraelu każdego męskiego potomka aż do ostatniego.
###### **2Krl 9,9**
 Postąpię z domem Achaba podobnie jak z domem Jeroboama, syna Nebata, i jak z domem Baszy, syna Achiasza.
###### **2Krl 9,10**
 A ciało Izebel rozszarpią psy na polu w Jezreel i nikt jej nie pochowa»”. Zaraz potem otworzył drzwi i uciekł.
###### **2Krl 9,11**
 Jehu zaś wyszedł do podwładnych swojego pana. Któryś odezwał się do niego: „Czy wszystko w porządku? Po co ten szaleniec przyszedł do ciebie?”. Odpowiedział im: „Wiecie przecież, co to za człowiek i jakie jest jego gadanie”.
###### **2Krl 9,12**
 Odparli: „Nie wykręcaj się! Powiedz nam!”. Rzekł więc: „Dobrze, oznajmił mi takie słowa: «Tak mówi PAN: Namaszczam cię na króla Izraela»”.
###### **2Krl 9,13**
 Natychmiast każdy z nich zdjął swój płaszcz i rozpostarł pod nim na samych stopniach. Zadęli w trąby i ogłosili: „Jehu jest królem!”.
###### **2Krl 9,14**
 W ten sposób Jehu, syn Jozafata, syna Nimsziego, zawiązał spisek przeciw Joramowi, który w tym czasie wraz z całym wojskiem izraelskim bronił Ramot w Gileadzie przed Chazaelem, królem Aramu.
###### **2Krl 9,15**
 Tymczasem król Joram wycofał się do Jezreela, aby wyleczyć się z ran, które mu zadali Aramejczycy podczas bitwy z Chazaelem, królem Aramu. Jehu zatem powiedział: „Jeśli zgadzacie się ze mną, niech nikt nie opuszcza miasta, aby zanieść wiadomość do Jezreel”.
###### **2Krl 9,16**
 Następnie Jehu wsiadł na rydwan i wyruszył do Jezreel. Tam bowiem wypoczywał Joram, a Ochozjasz, król Judy, również tam przybył, aby go odwiedzić.
###### **2Krl 9,17**
 Kiedy strażnik stojący na wieży w Jezreel dostrzegł zbliżający się oddział Jehu, zawołał: „Widzę oddział żołnierzy!”. Joram rozkazał: „Weź jeźdźca i wyślij go do nich. Niech się dowie, czy wszystko w porządku”.
###### **2Krl 9,18**
 Jeździec więc wyruszył im na spotkanie i powiedział: „Król pyta, czy wszystko w porządku”. Odparł mu Jehu: „A co tobie do tego? Jedź za mną!”. Strażnik zawołał: „Posłaniec przybył do nich, ale nie wraca”.
###### **2Krl 9,19**
 Wysłał więc drugiego jeźdźca. Kiedy podjechał do nich, dowiadywał się: „Król pyta, czy wszystko w porządku”. Odparł Jehu: „A co tobie do tego? Jedź za mną!”.
###### **2Krl 9,20**
 Znowu strażnik zawołał: „Posłaniec przybył do nich, ale nie wraca. Powożenie podobne jest do jazdy Jehu, wnuka Nimsziego, gdyż jedzie jak szaleniec”.
###### **2Krl 9,21**
 Wtedy Joram rozkazał: „Zaprzęgaj!”. Kiedy zaprzężono jego rydwan, Joram, król Izraela, i Ochozjasz, król Judy, każdy na swoim rydwanie wyruszyli naprzeciw Jehu. Spotkali go na polu Nabota z Jezreel.
###### **2Krl 9,22**
 Gdy tylko Joram zobaczył Jehu, zawołał: „Czy wszystko w porządku, Jehu?”. On zaś odparł: „Czyż może być wszystko w porządku, gdy twoja matka, Izebel, uprawia bałwochwalstwo i mnoży czary?”.
###### **2Krl 9,23**
 Joram natychmiast zawrócił i rzucił się do ucieczki, krzycząc do Ochozjasza: „Zdrada, Ochozjaszu!”.
###### **2Krl 9,24**
 Wtedy Jehu chwycił za łuk i trafił Jorama między ramiona. Strzała przeszyła jego serce i osunął się w swoim rydwanie.
###### **2Krl 9,25**
 A Jehu rzekł do Bidkara, swojego przybocznego żołnierza: „Podnieś go i rzuć na pole Nabota z Jezreel. Przypomnij sobie, jak ty i ja jechaliśmy razem za jego ojcem Achabem. Wówczas to PAN ogłosił przeciw niemu taki właśnie wyrok:
###### **2Krl 9,26**
 «Naprawdę, wczoraj widziałem krew Nabota i krew jego synów, wyrocznia PANA, dlatego odpłacę tobie na tym polu, wyrocznia PANA». A teraz podnieś go i rzuć na pole, zgodnie ze słowem PANA”.
###### **2Krl 9,27**
 Widząc to, Ochozjasz uciekał drogą w kierunku Bet-Haggan. Jehu ruszył za nim w pościg, wołając: „Jego także zabić!”. Zranili go w jego rydwanie na drodze prowadzącej do Gur, niedaleko Jebleam. On jednak zdołał uciec do Megiddo, ale tam zmarł.
###### **2Krl 9,28**
 Jego słudzy przewieźli go do Jerozolimy i pochowali w jego grobie, u boku przodków, w Mieście Dawida.
###### **2Krl 9,29**
 W jedenastym roku rządów Jorama, syna Achaba, Ochozjasz został królem Judy.
###### **2Krl 9,30**
 Jehu przybył do Jezreel. Kiedy Izebel dowiedziała się o tym, pomalowała sobie oczy, upiększyła włosy i patrzyła przez okno.
###### **2Krl 9,31**
 Jehu właśnie wjeżdżał do bramy, kiedy zawołała: „Czy wszystko w porządku, Zimri, zabójco swojego pana?”.
###### **2Krl 9,32**
 On zaś spojrzał w górę, w stronę okna i krzyknął: „Kto jest za mną? Kto?”. Wychylili się ku niemu dwaj albo trzej eunuchowie.
###### **2Krl 9,33**
 Rozkazał więc: „Zrzućcie ją!”. Wyrzucili ją, a jej krew obryzgała mur i konie, które ją stratowały.
###### **2Krl 9,34**
 Kiedy Jehu już zjadł i napił się, rozkazał: „Zajmijcie się tą przeklętą i pochowajcie ją, gdyż jest córką króla”.
###### **2Krl 9,35**
 Poszli więc pochować ją, ale znaleźli po niej tylko czaszkę, stopy i dłonie.
###### **2Krl 9,36**
 Wrócili i powiedzieli mu o tym. On zaś odparł: „Takie właśnie było słowo PANA, które wypowiedział przez swojego sługę, Eliasza z Tiszbe: «Na polu w Jezreel psy będą żarły ciało Izebel.
###### **2Krl 9,37**
 Trup Izebel będzie jak gnój leżący na polu w Jezreel, tak że nikt nie zdoła powiedzieć: To jest Izebel»”.
# 2Krl 9 BP
###### **2Krl 9,1**
 Prorok Elizeusz wezwał jednego z synów prorockich i rzekł mu: Przepasz swoje biodra, weź do swej ręki to naczyńko oliwy i idź do Ramot Gilead.
###### **2Krl 9,2**
 Gdy tam przybędziesz, staraj się zobaczyć Jehu, syna Jehoszafata, syna Nimsziego. Podejdziesz, wywołasz go spośród jego braci i wprowadzisz go do wewnętrznej izby.
###### **2Krl 9,3**
 Weźmiesz naczyńko oliwy, wylejesz na jego głowę i powiesz: "Tak mówi Jahwe: Namaszczam cię na króla nad Izraelem". [Potem] otworzysz drzwi i uciekniesz, a nie będziesz zwlekał.
###### **2Krl 9,4**
 Poszedł więc młodzieniec - młody prorok - do Ramot Gilead.
###### **2Krl 9,5**
 Wszedł, a oto dowódcy wojska siedzieli, i rzekł: Wodzu. Mam do ciebie sprawę. Jehu spytał: Do kogo z nas? Odrzekł: Do ciebie, wodzu.
###### **2Krl 9,6**
 Wstał tedy i wszedł do domu. [Prorok] wylał na jego głowę oliwę i rzekł mu: Tak mówi Jahwe, Bóg Izraela: Namaszczam cię na króla, nad ludem Jahwe, nad Izraelem.
###### **2Krl 9,7**
 Wygubisz dom Achaba, pana twojego. [Tak] pomszczę krew moich sług Proroków i krew wszystkich sług Jahwe, [którzy zginęli] z ręki Jezabel.
###### **2Krl 9,8**
 Zginie cały dom Achaba. Zgładzę męskich potomków Achaba, niewolników i wolnych w Izraelu.
###### **2Krl 9,9**
 Dom Achaba spotka los domu Jeroboama, syna Nebata, i domu Baszy, syna Achijji.
###### **2Krl 9,10**
 Psy zjedzą Jezabel w posiadłości Jizreel i nikt [jej] nie pogrzebie. Otworzył drzwi i uciekł.
###### **2Krl 9,11**
 Jehu wyszedł do poddanych swego pana. I spytali go: Czy pokój [zwiastował]? W jakim celu przyszedł ten szaleniec do ciebie? Odpowiedział im: Wy znacie [tego] człowieka i jego gadaninę.
###### **2Krl 9,12**
 Rzekli: Nieprawda. Powiedz nam. Odrzekł: Przemówił do mnie tak a tak tymi słowami: "Tak mówi Jahwe: Namaszczam cię na króla nad Izraelem".
###### **2Krl 9,13**
 Wtedy każdy spiesznie wziął swoją szatę i rozesłali pod jego [stopami] na najwyższym stopniu. Zadęli w róg i zawołali: Jehu jest królem!
###### **2Krl 9,14**
 Jehu, syn Jehoszafata, syna Nimsziego, uknuł spisek przeciw Joramowi. Joram i cały Izrael bronili Ramot Gilead przed Chazaelem, królem Aramu.
###### **2Krl 9,15**
 Ale król Joram powrócił do Jizreel leczyć się z ran, które mu zadali Aramejczycy w walce z Chazaelem, królem Aramu. Jehu rzekł: Jeśli duszą waszą jesteście [ze mną], niech nikt nie opuszcza miasta, aby pójść dać znać do Jizreel.
###### **2Krl 9,16**
 Jehu dosiadł rydwanu i pojechał do Jizreel, bo Joram tam leżał, Ochozjasz zaś, król Judy, zstąpił, aby zobaczyć Jorama.
###### **2Krl 9,17**
 Strażnik, który stał na wieży w Jizreel, zauważył zbliżający się oddział Jehu i zawołał: Widzę oddział! Joram rzekł: Weź jeźdźca i poślij naprzeciw nich, niech zapyta: Czy [przynosisz] pokój?
###### **2Krl 9,18**
 Ruszył jeździec naprzeciw niego i zapytał: Tak pyta król: Czy pokój [przynosisz]? Jehu odpowiedział: Co cię pokój obchodzi? Wracaj za mną. Strażnik oznajmił mówiąc: Posłaniec dotarł do nich, ale nie wraca.
###### **2Krl 9,19**
 [Król] wysłał drugiego jeźdźca. Przybył do nich i rzekł: Tak pyta król: Czy pokój [niesiesz]? Jehu odpowiedział: Co cię pokój obchodzi? Wracaj za mną.
###### **2Krl 9,20**
 Strażnik oznajmił mówiąc: Dotarł do nich, ale nie wraca. [Sposób] jazdy jest podobny do powożenia Jehu, syna Nimsziego, bo jedzie jak szalony.
###### **2Krl 9,21**
 Wówczas Joram rozkazał: Zaprzęgaj. Zaprzągł jego rydwan. I wyruszyli Joram, król izraelski, i Ochozjasz, król Judy, każdy na swoim rydwanie. Wyjechali naprzeciw Jehu i spotkali go w posiadłości Nabota Jizreelczyka.
###### **2Krl 9,22**
 Gdy Joram ujrzał Jehu, zapytał: Czy pokój [zwiastujesz], Jehu? Odpowiedział: Co za pokój, dopóki [trwają] cudzołóstwa Jezabel, twojej matki, i jej liczne czary?
###### **2Krl 9,23**
 Joram zawrócił, zaczął uciekać i wołać do Ochozjasza: Ochozjaszu! Zdrada!
###### **2Krl 9,24**
 Ale Jehu chwycił łuk w swą rękę i ugodził [strzałą] Jorama między łopatki. Strzała przeszyła jego serce i padł na swój rydwan.
###### **2Krl 9,25**
 Wtedy [Jehu] rzekł do Bidkara, swego giermka: Weź i porzuć go na polu posiadłości Nabota Jizreelity, bo pamiętasz, jak jechaliśmy razem, ja i ty, za Achabem, jego ojcem, i Jahwe wypowiedział przeciw niemu tę oto przepowiednię:
###### **2Krl 9,26**
 Zaiste wczoraj widziałem krew Nabota i krew jego synów - wyrocznia Jahwe - zapłacę [za nią] na tej posiadłości - wyrocznia Jahwe. - Teraz więc weź i porzuć go na [tej] posiadłości, według słowa Jahwe.
###### **2Krl 9,27**
 Gdy [to] zobaczył Ochozjasz, król Judy, zaczął uciekać drogą [ku] Bet ha-Gan. Jehu wszczął za nim pościg i polecił: Jego także zgładźcie. [Zraniono go] na rydwanie na wzniesieniu Gur, które [leży] koło Jibleam. Uciekł do Megiddo i tam umarł.
###### **2Krl 9,28**
 Jego słudzy zawieźli go do Jerozolimy. Pogrzebano go w grobie z jego ojcami w Mieście Dawidowym.
###### **2Krl 9,29**
 Ochozjasz został królem Judy w jedenastym roku [panowania] Jorama, syna Achaba.
###### **2Krl 9,30**
 Jehu wkroczył do Jizreel. Gdy Jezabel usłyszała o tym, podmalowała swe oczy, upiększyła swoją głowę i wyglądała przez okno,
###### **2Krl 9,31**
 a kiedy Jehu wszedł w bramę, spytała: Czy pokój [przynosisz], Zimri, morderco swojego pana?
###### **2Krl 9,32**
 Podniósł swoją twarz ku oknu i zawołał: Kto jest ze mną? Kto? A gdy [z okna] wyjrzeli ku niemu dwaj czy trzej eunuchowie,
###### **2Krl 9,33**
 rzekł: Zrzućcie ją. I zrzucili ją. Krew jej zbryzgała ścianę i konie, [które] ją stratowały.
###### **2Krl 9,34**
 Wszedł, jadł i pił [a potem] rzekł: Zajmijcie się - proszę - tą przeklętą i pogrzebcie ją, bo jest córką królewską.
###### **2Krl 9,35**
 Poszli, aby ją pogrzebać, ale nie znaleźli jej, tylko czaszkę, nogi i dłonie rąk.
###### **2Krl 9,36**
 Wrócili więc i oznajmili mu. [On] zaś powiedział: [Spełniło się zatem] to słowo, które Jahwe wypowiedział przez swojego sługę Eliasza Tiszbitę mówiąc: Psy pożrą ciało Jezabel w posiadłości Jizreel.
###### **2Krl 9,37**
 Trup Jezabel będzie jak nawóz na polu posiadłości Jizreel, tak że nie powiedzą: To jest Jezabel.
# 2Krl 9 BR
###### **2Krl 9,1**
 Prorok Elizeusz wezwał do siebie jednego z uczniów prorockich i powiedział mu tak: Przepasz swoje biodra, weź ze sobą naczynie z oliwą i idź do Ramot w Gileadzie.
###### **2Krl 9,2**
 Gdy przyjdziesz na miejsce, odszukaj Jehu, syna Jozafata, syna Nimsziego. Kiedy go odnajdziesz, niech pozostawi swoich braci i uda się z tobą do innego pomieszczenia.
###### **2Krl 9,3**
 Wówczas weźmiesz naczynie z oliwą, wylejesz mu oliwę na głowę i powiesz: Oto, co mówi Jahwe: Namaszczam cię na króla izraelskiego. Potem otworzysz drzwi, oddalisz się z stamtąd jak najprędzej.
###### **2Krl 9,4**
 I wyruszył młody człowiek, sługa proroka, do Ramot w Gileadzie.
###### **2Krl 9,5**
 Kiedy przybył na miejsce, zastał siedzących wszystkich dowódców wojskowych. Powiedział tedy do nich: Wodzu, mam ci coś do powiedzenia. Rzekł na to Jehu: Do którego spośród nas mówisz? A on odpowiedział: Do ciebie, wodzu.
###### **2Krl 9,6**
 Wstał więc Jehu i wszedł do wnętrza domu, a sługa proroka [poszedł za nim i] wylał mu na głowę oliwę, mówiąc: Oto, co mówi Jahwe, Bóg Izraela: Namaszczam cię na króla ludu Bożego, izraelskiego.
###### **2Krl 9,7**
 Uderzysz w dom Achaba, twojego pana, a na Izebel Ja sam pomszczę krew moich sług, proroków, oraz krew wszystkich sług Jahwe.
###### **2Krl 9,8**
 Ulegnie zagładzie cały ród Achaba. Wytracę wszystkich mężczyzn z rodu Achaba, zarówno niewolników, jak i wolnych w całym Izraelu.
###### **2Krl 9,9**
 I uczynię ród Achaba podobnym do rodu Jeroboama, syna Nebata, oraz do domu Baszy, syna Achiasza.
###### **2Krl 9,10**
 Psy będą rozszarpywały na polach Jizreel ciało Izebel i nie znajdzie się nikt, kto zechciałby ją pochować. Potem sługa proroka otworzył drzwi i szybko się stamtąd oddalił.
###### **2Krl 9,11**
 Wyszedł wtedy Jehu, aby [ponownie] przyłączyć się do sług swojego pana. A oni go zapytali: Czy wszystko w porządku? Po co ten szaleniec przyszedł do ciebie? On im odpowiedział: Sami znacie przecież tego człowieka i wiecie, co mówi.
###### **2Krl 9,12**
 Lecz oni odrzekli: To nieprawda! Opowiedz nam wszystko! Wtedy on powiedział: Mówił mi tak a tak, oświadczając, iż Jahwe kazał mi donieść: Namaszczam cię na króla izraelskiego.
###### **2Krl 9,13**
 Natychmiast wszyscy chwycili swoje płaszcze i rozkładali je przed Jehu, zaczynając od najwyższych stopni. Potem zabrzmiały trąby, a oni wszyscy wołali: Jehu jest królem!
###### **2Krl 9,14**
 Jehu, syn Jozafata, syna Nimsziego, uknuł spisek przeciw Joramowi, który razem z całym Izraelem bronił się wtedy w Ramot w Gileadzie przed Chazaelem, królem Aramejczyków.
###### **2Krl 9,15**
 Król Joram musiał jednak wrócić do Jizreel, aby leczyć rany, jakie mu zadali Aramejczycy, gdy walczył przeciwko Chazaelowi, królowi Aramu. Jehu wówczas powiedział: Jeżeli się zgadzacie, to niech nikomu nie uda się uciec z miasta, żeby zanieść jakieś wieści do Jizreel.
###### **2Krl 9,16**
 Potem, wsiadłszy na swój rydwan, ruszył Jehu do Jizreel, gdzie przebywał już Joram, a Ochozjasz, król judzki, przybył tam, żeby odwiedzić Jorama.
###### **2Krl 9,17**
 Strażnik na wieży obronnej miasta Jizreel, zobaczywszy orszak Jechu, powiedział: Widzę oddział wojska. A Joram na to: Każ wysłać im na spotkanie jednego jeźdźca. Niech ich zapyta, czy przynoszą nam pokój.
###### **2Krl 9,18**
 Wkrótce znalazł się ów jeździec przed Jehu i rzekł: Król pyta, czy przychodzisz zwiastować nam pokój. Jehu zaś odpowiedział: A cóż ci tak zależy na pokoju? Jedź za mną! A wtedy strażnik oznajmił, że posłaniec minął ich, pojechał dalej i nie wraca.
###### **2Krl 9,19**
 Posłał więc król drugiego jeźdźca, który dotarłszy do nich, powiedział: Król pyta, czy przychodzisz zwiastować nam pokój. A Jehu znów odpowiedział: A cóż ci tak zależy na pokoju? Jedź za mną!
###### **2Krl 9,20**
 I znów strażnik dał znać, że wysłannik minął ich, pojechał dalej i nie wraca. [Ponadto dodał], że ten, który prowadzi cały oddział, sposobem jazdy bardzo przypomina Jehu, wnuka Nimsziego, który zwykle jeździ jak szalony.
###### **2Krl 9,21**
 Wtedy Joram rozkazał: Zaprzęgać! Kiedy zaprzężono konie do rydwanów, ruszył Joram, król izraelski, a z nim Ochozjasz, król judzki, każdy na swoim rydwanie. Jechali naprzeciw Jehu, którego spotkali na polu Nabota z Jizreel.
###### **2Krl 9,22**
 Zobaczywszy Jehu, Joram powiedział: Czy przynosisz nam pokój, Jehu? A Jehu mu odpowiedział: O jakimże pokoju może być mowa, skoro dotąd rozpuście oddaje się Izebel, twoja matka, uprawiając przy tym różne czary?
###### **2Krl 9,23**
 Zawrócił tedy Joram i zaczął uciekać, wołając do Ochozjasza: Ochozjaszu, zdrada!
###### **2Krl 9,24**
 Jehu jednak chwycił łuk, a strzała ugodziła Jorama między łopatki, przeszywając serce. Joram osunął się martwy na swym rydwanie.
###### **2Krl 9,25**
 Jehu zaś powiedział do swego tarczownika Bidkara: Zabierz go i rzuć na pole Nabota z Jizreel. I przypomnij sobie teraz to, co Jahwe powiedział o nim, gdyśmy się skradali na koniach za jego ojcem, Achabem:
###### **2Krl 9,26**
 Naprawdę widziałem wczoraj krew Nabota i krew jego synów! - wyrocznia Jahwe. Odpłacę ci się podobnie na tym samym polu - wyrocznia Jahwe. Zabierz go więc i rzuć na to pole, zgodnie z przepowiednią Jahwe.
###### **2Krl 9,27**
 Widząc to Ochozjasz, król judzki, rzucił się do ucieczki w stronę Bet-Haggan. Jehu zaś ruszył w pościg za nim, wydając jednocześnie rozkaz: Jego również zgładzić na tym rydwanie! Ruszyli więc zanim, dopadli go i zranili u wejścia do Gur, niedaleko Jibleam. Zdołał im jeszcze uciec i dotrzeć do Megiddo, gdzie jednak zmarł.
###### **2Krl 9,28**
 Jego słudzy przewieźli go na rydwanie do Jerozolimy i pochowali w grobowcu jego przodków w Mieście Dawidowym.
###### **2Krl 9,29**
 Królem judzkim w jedenastym roku panowania Jorama, syna Achaba, został Ochozjasz.
###### **2Krl 9,30**
 Jehu wkroczył do Jizreel. Kiedy dowiedziała się o tym Izebel, pomalowała sobie powieki, upięła włosy i wyglądała przez okno na górze.
###### **2Krl 9,31**
 Gdy Jehu wkraczał w bramę miasta, zawołała do niego: Czy wszystko w porządku, Zimri, morderco swego pana?
###### **2Krl 9,32**
 A on spojrzał w stronę tego okna i zapytał: Kto jest ze mną? Kto? Kiedy zaś w oknie ukazało się dwóch czy trzech eunuchów,
###### **2Krl 9,33**
 zawołał: Zrzućcie ją na dół! I zrzucili ją, tak iż krew obryzgała mury miejskie i konie, a Jehu stratował ją [kopytami końskimi].
###### **2Krl 9,34**
 Potem, wszedłszy do środka, jadł i pił, a w końcu powiedział: Idźcie, weźcie tę wiedźmę i pochowajcie ją, bo to jednak córka królewska.
###### **2Krl 9,35**
 Poszli, żeby ją pochować, ale znaleźli tylko czaszkę, nogi i dłonie.
###### **2Krl 9,36**
 Kiedy wrócili i donieśli o tym Jehu, on rzekł: Oto, co przepowiedział Jahwe przez usta swego sługi Eliasza z Tiszbe: Na polu w Jizreel psy rozszarpią ciało Izebel.
###### **2Krl 9,37**
 Trup Izebel będzie jak gnój użyźniający pole koło Jizreel. Nikt już nie będzie mógł powiedzieć, że to Izebel.
# 2Krl 9 WUJ
###### **2Krl 9,1**
 A Elizeusz Prorok zawołał jednego z synów prorockich, i rzekł mu: Przepasz biodra twoje, a weźmi bańkę oliwy tę w rękę twą, a idź do Ramoth Galaad.
###### **2Krl 9,2**
 A gdy tam przyjdziesz. Ujrzysz Jehu syna Jozaphata, syna Namsi: a wszedszy każesz mu wstać z pośrodku braciej jego i wwiedziesz do wnętrznej komory.
###### **2Krl 9,3**
 A dzierżąc bańkę oliwy wlejesz na głowę jego, i rzeczesz: To mówi Pan, Pomazałem cię królem nad Izraelem. I otworzysz drzwi i ucieczesz, i nie zastanowisz się tam.
###### **2Krl 9,4**
 A tak poszedł młodzieniec pacholę proroka do Ramoth Galaad.
###### **2Krl 9,5**
 I wszedł tam: a oto hetmanowie wojska siedzieli, i rzekł: Mam słowo do ciebie, o hetmanie. I rzekł Jehu; Do kogo z nas wszystkich? A on rzekł: Do ciebie o hetmanie.
###### **2Krl 9,6**
 I wstał, i wszedł do komory, a on wylał oliwę na głowę jego i rzekł: To mówi Pan Bóg Izraelów: Pomazałem cię królem nad ludem Pańskim Izraelem.
###### **2Krl 9,7**
 I wytracisz dom Achaba pana twego, i pomszczę się krwie sług moich proroków, i krwie wszystkich sług Pańskich. z ręki Jezabel.
###### **2Krl 9,8**
 I wytracę wszystek dom Achabów: i zabiję z Achab mokrzącego na ścianę i zamknionego i ostatecznego w Izraelu.
###### **2Krl 9,9**
 I dam dom Achabów jako dom Jeroboama syna Nabat, i jako dom Baasy syna Ahia.
###### **2Krl 9,10**
 Jezabelę też zjedzą psy na polu Jezrahelskim, a nie będzie, ktoby ją pogrzebł. I otworzył drzwi i uciekł.
###### **2Krl 9,11**
 A Jehu wyszedł do sług pana swego: którzy mu rzekli: Dobrzeli jest wszystko? Po cóż przyszedł ten szalony do ciebie? Który im rzekł: Znacie człowieka, i co mówił.
###### **2Krl 9,12**
 A oni odpowiedzieli: Fałsz ci to, ale raczej nam powiedz. Który im rzekł: To a to mi mówił, i rzekł: To mówi Pan: Pomazałem cię królem nad Izraelem.
###### **2Krl 9,13**
 Pospieszyli się tedy, a wziąwszy każdy płaszcz swój położyli pod nogi jego na podobieństwo majestatu, i zatrąbili w trąbę, i mówili: Króluje Jehu.
###### **2Krl 9,14**
 Sprzysiągł się tedy Jehu syn Jozaphata syna Namsi na Jorama, a Joram był obiegł Ramoth Galaad, sam i wszystek Izrael przeciw Hazaelowi królowi Syryjskiemu.
###### **2Krl 9,15**
 A wrócił się był, aby się leczył w Jezrahelu na rany, bo go byli zranili Syryjczykowie walczącego przeciw Hazaelowi królowi Syryjskiemu, I rzekł Jehu: Jeśli się wam podoba, niechaj żaden zbieg nie wychodzi z miasta, żeby nie szedł, a nie oznajmił w Jezrahelu.
###### **2Krl 9,16**
 I wsiadł i jachał do Jezrahela: bo tam chorował Joram, a Ochoziasz król Judzki przyjechał był, nawiedzać Jorama.
###### **2Krl 9,17**
 Stróż tedy, który stał na wieży Jezrahelskiej, ujrzał poczet Jehu przyjeżdżającego, i rzekł: Widzę ja poczet. I rzekł Joram: Weźmi wóz, a pośli przeciwko nim, a niech spyta ten, który jedzie: Dobrzeli jest wszystko?
###### **2Krl 9,18**
 A tak jachał, który był wsiadł na wóz przeciw niemu i rzekł: To mówi król: Spokojneli jest wszystko? I rzekł Jehu: Co tobie i pokojowi? mijaj, a jedź za mną. Powiedział też stróż, rzekąc: Przyjachał poseł do nich, a nie wraca się
###### **2Krl 9,19**
 Posłał też drugi wóz z końmi: i przyjachał do nich i rzekł: To mówi król: Pokój li jest? I rzekł Jehu: Co tobie i pokojowi? miń a jedź za mną.
###### **2Krl 9,20**
 I powiedział stróż, rźekąc: Przyjachał aż do nich, a nie wraca się: a jazda jest jakoby jazda Jehu syna Hamsi, bo szalenie jedzie
###### **2Krl 9,21**
 I rzekł Jorain: Zaprzęgaj wóz. I zaprzęgli wóz jego, i wyjachał Joram król Izraelski i Ochoziasz król Judzki, każdy na swym wozie, i wyjachali na przeciwko Jehu, i naleźli go na polu Nabota Jezrahelitczyka.
###### **2Krl 9,22**
 A gdy ujrzał Joram Jehu rzekł: A pokój Jehu? A on odpowiedział: Co za pokój? Jeszcze cudzołóstwa Jezabel matki twojej i czary jej mnogie trwają.
###### **2Krl 9,23**
 I nawrócił Joram rękę swą i uciekając rzekł do Ochoziasza Zdrada Ochoziaszu.
###### **2Krl 9,24**
 A Jehu wyciągnął łuk ręką, i postrzelił Jorama między plecy: i wyszła strzała przez serce jego, i wnet upadł na wozie swoim.
###### **2Krl 9,25**
 I rzekł Jehu do Badacera hetmana: Weźmi, a porzuć go na roli Nabotha Jezrahelitczyka: bo pamiętam kiedy ja i ty siedząc na wozie jachaliśmy za Achabem ojcem tego, że Pan to brzemię podniósł nań, mówiąc:
###### **2Krl 9,26**
 Jeśli nie za krew Nabotha i za krew synów jego, którąm wczora widział, mówi Pan, oddam tobie, na tej roli, mówi Pan. A tak teraz weźmi i porzuć go na roli według słowa Pańskiego.
###### **2Krl 9,27**
 A Ochoziasz król Judzki widząc to, uciekał drogą domu ogrodowego: i gonił go Jehu, i rzekł: I tego też zabijcie na wozie jego. I zranili go na wstępie Gauer, który jest w Jeblaam: który uciekł do Magedda, i tam umarł.
###### **2Krl 9,28**
 A słudzy jego włożyli go na wóz jego i wieźli do Jeruzalem: i pogrzebli go w grobie z ojcy jego w mieście Dawidowem.
###### **2Krl 9,29**
 Roku jedenastego Jorama syna Achabowego, królował Ochoziasz nad Juda.
###### **2Krl 9,30**
 I przyjachał Jehu do Jezrahela. A Jezabel, usłyszawszy o wjeździe jego, pofarbowała oczy swe bielidłem, i ochędożyła głowę swoję i spojrzała oknem
###### **2Krl 9,31**
 Na Jehu wjeżdzącego w bramę i rzekła: I możesz być pokój Zambremu, który zabił pana swego?
###### **2Krl 9,32**
 I podniósł Jehu twarz swoję ku oknu, I rzekł: Która to jest? I wychylili się do niego dwa abo trzej rzezańcy.
###### **2Krl 9,33**
 A on im rzekł: Zrzućcie ją na dół, i zrzucili ją, i pokropiła się ściana krwią, a kopyta końskie podeptały ją.
###### **2Krl 9,34**
 A gdy wszedł, żeby jadł i pił, rzekł. Idźcie a oglądajcie przeklętą onę, a pogrzebcie ją: bo jest córka królewska.
###### **2Krl 9,35**
 A gdy szli, aby ją pogrzebli, nie naleźli jedno trupi łeb a nogi i końce rąk.
###### **2Krl 9,36**
 A wróciwszy się powiedzieli mu. I rzekł Jehu: Mowa Pańska jest, którą mówił przez sługę swego Eliasza Tesbytczyka, rzekąc: Na roli Jezrahelskiej zjedzą psy ciało Jezabel,
###### **2Krl 9,37**
 A będzie ciało Jezabel, jako gnój na ziemi na roli Jezrahel, tak iż będą mówić mimo idący: Taż to ona jest Jezabel?
