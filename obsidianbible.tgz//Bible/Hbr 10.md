# Hbr 10 BT5
###### **Hbr 10,1**
 Prawo bowiem, posiadając tylko cień przyszłych dóbr, a nie sam obraz rzeczy, przez te same ofiary, corocznie ciągle składane, nie może nigdy udoskonalić tych, którzy przystępują [do Boga].
###### **Hbr 10,2**
 Czyż bowiem nie przestano by ich składać, gdyby składający je, raz na zawsze oczyszczeni, nie mieli już żadnej świadomości grzechów?
###### **Hbr 10,3**
 Ale przez nie każdego roku następuje przypomnienie grzechów.
###### **Hbr 10,4**
 Niemożliwe jest bowiem, aby krew cielców i kozłów usuwała grzechy.
###### **Hbr 10,5**
 Przeto, przychodząc na świat, mówi: Ofiary ani daru nie chciałeś, ale Mi utworzyłeś ciało;
###### **Hbr 10,6**
 całopalenia i ofiary za grzechnie podobały się Tobie.
###### **Hbr 10,7**
 Wtedy rzekłem: Oto idę – w zwoju księgi napisano o Mnie – aby spełnić wolę Twoją, Boże.
###### **Hbr 10,8**
 Wyżej powiedział: Ofiar, darów, całopaleń i ofiar za grzech nie chciałeś i nie podobały się Tobie, choć składane są zgodnie z Prawem.
###### **Hbr 10,9**
 Następnie powiedział: Oto idę, aby spełnić wolę Twoją. Usuwa jedną [ofiarę], aby ustanowić inną.
###### **Hbr 10,10**
 Na mocy tej woli uświęceni jesteśmy przez ofiarę ciała Jezusa Chrystusa raz na zawsze.
###### **Hbr 10,11**
 Wprawdzie każdy kapłan staje codziennie do wykonywania swej służby i wiele razy składa te same ofiary, które żadną miarą nie mogą zgładzić grzechów.
###### **Hbr 10,12**
 Ten przeciwnie, złożywszy raz na zawsze jedną ofiarę za grzechy, zasiadł po prawicy Boga,
###### **Hbr 10,13**
 oczekując tylko, aż nieprzyjaciele Jego staną się podnóżkiem pod Jego stopy.
###### **Hbr 10,14**
 Jedną bowiem ofiarą udoskonalił na wieki tych, którzy są uświęcani.
###### **Hbr 10,15**
 Daje nam zaś świadectwo Duch Święty, skoro powiedział:
###### **Hbr 10,16**
  Takie jest przymierze, które zawrę z nimipo owych dniach, mówi Pan:Nadam prawa moje w ich sercach, także w myśli ich je wypiszę.
###### **Hbr 10,17**
 A na ich grzechy oraz ich nieprawościwięcej już nie wspomnę.
###### **Hbr 10,18**
 Gdzie zaś jest ich odpuszczenie, tam już więcej nie zachodzi potrzeba ofiary za grzechy.
###### **Hbr 10,19**
  Mamy więc, bracia, pewność, iż wejdziemy do Miejsca Świętego przez krew Jezusa.
###### **Hbr 10,20**
 On nam zapoczątkował drogę nową i żywą, przez zasłonę, to jest przez ciało swoje.
###### **Hbr 10,21**
 Mając zaś kapłana wielkiego, który jest nad domem Bożym,
###### **Hbr 10,22**
 przystąpmy z sercem prawym, z wiarą pełną, oczyszczeni na duszy od wszelkiego zła świadomego i obmyci na ciele wodą czystą.
###### **Hbr 10,23**
 Trzymajmy się niewzruszenie nadziei, którą wyznajemy, bo godny jest zaufania Ten, który dał obietnicę.
###### **Hbr 10,24**
 Troszczmy się o siebie wzajemnie, by się zachęcać do miłości i do dobrych uczynków.
###### **Hbr 10,25**
 Nie opuszczajmy naszych wspólnych zebrań, jak się to stało zwyczajem niektórych, ale zachęcajmy się nawzajem, i to tym bardziej, im wyraźniej widzicie, że zbliża się dzień.
###### **Hbr 10,26**
 Jeśli bowiem dobrowolnie grzeszymy po otrzymaniu pełnego poznania prawdy, to już nie ma dla nas ofiary przebłagalnej za grzechy,
###### **Hbr 10,27**
 ale jedynie jakieś przerażające oczekiwanie sądu i żar ognia, który ma trawić opornych.
###### **Hbr 10,28**
 Kto przekracza Prawo Mojżeszowe, ponosi śmierć bez miłosierdzia na podstawie [zeznania] dwóch albo trzech świadków.
###### **Hbr 10,29**
 Pomyślcie, o ileż surowszej kary stanie się winien ten, kto by podeptał Syna Bożego i zbezcześcił krew Przymierza, przez którą został uświęcony, i obelżywie zachował się wobec Ducha łaski.
###### **Hbr 10,30**
 Znamy przecież Tego, który powiedział: Do Mnie [należy] pomsta i Ja odpłacę. I znowu: Sam Pan będzie sądził lud swój.
###### **Hbr 10,31**
 Straszna to rzecz wpaść w ręce Boga żywego.
###### **Hbr 10,32**
 Przypomnijcie sobie dawniejsze dni, kiedy to po oświeceniu wytrzymaliście wielkie zmaganie, to jest udręki,
###### **Hbr 10,33**
 już to wystawieni publicznie na szyderstwa i prześladowania, już to stawszy się towarzyszami tych, którzy to przeżywali.
###### **Hbr 10,34**
 Albowiem współcierpieliście z uwięzionymi, z radością przyjęliście rabunek waszego mienia, wiedząc, że sami posiadacie majątek lepszy i trwały.
###### **Hbr 10,35**
 Nie wyzbywajcie się więc waszej ufności, która znajduje wielką odpłatę.
###### **Hbr 10,36**
 Potrzebujecie bowiem wytrwałości, abyście po wypełnieniu woli Bożej dostąpili [spełnienia] obietnicy.
###### **Hbr 10,37**
 Jeszcze bowiem krótka, bardzo krótka chwila, i przyjdzie Ten, który ma nadejść, i nie spóźni się.
###### **Hbr 10,38**
 A mój sprawiedliwy dzięki wierze żyć będzie, jeśli się cofnie, nie znajdzie dusza moja w nim upodobania.
###### **Hbr 10,39**
 My zaś nie należymy do odstępców, którzy idą na zatracenie, ale do wiernych, którzy zbawiają duszę.
# Hbr 10 PAU
###### **Hbr 10,1**
 Skoro więc Prawo obejmowało tylko cień przyszłych dóbr, a nie samą rzeczywistość, to znaczy, że nie mogło udoskonalić tych, którzy co roku składali ustawicznie te same ofiary.
###### **Hbr 10,2**
 Czy nie zaprzestano by ich składać, gdyby uczestnicy kultu, raz oczyszczeni, nie mieli już świadomości grzechów?
###### **Hbr 10,3**
 A jednak przez te ofiary co roku przywołuje się na pamięć grzechy.
###### **Hbr 10,4**
 Niemożliwe bowiem, aby krew wołów i kozłów gładziła grzechy.
###### **Hbr 10,5**
 Toteż, przychodząc na świat, Chrystus mówi: Ofiary i daru nie chciałeś, ale przygotowałeś Mi ciało.
###### **Hbr 10,6**
 Nie podobały się Tobie całopalenia ani ofiary za grzechy.
###### **Hbr 10,7**
 Wtedy powiedziałem: Oto przychodzę! W zwoju księgi napisano o Mnie: Chcę wypełniać Twoją wolę, Boże.
###### **Hbr 10,8**
 Najpierw mówi: Ofiar, darów, całopaleń ani ofiar za grzechy nie chciałeś, nie podobały się Tobie - choć składa się je zgodnie z Prawem.
###### **Hbr 10,9**
 Następnie powiedział: Oto przychodzę! Chcę wypełniać Twoją wolę. Znosi to, co pierwsze, aby ustanowić drugie!
###### **Hbr 10,10**
 Mocą tej woli zostaliśmy uświęceni przez ofiarę ciała Jezusa Chrystusa raz na zawsze.
###### **Hbr 10,11**
 Każdy kapłan staje codziennie do służby, składając wielokrotnie te same ofiary, które nigdy nie mogą zgładzić grzechów.
###### **Hbr 10,12**
 Ten zaś, po złożeniu jednej ofiary za grzechy, na zawsze zasiadł po prawej stronie Boga,
###### **Hbr 10,13**
 czekając odtąd, aż On położy Jego wrogów jako podnóżek pod Jego stopy.
###### **Hbr 10,14**
 Przez tę jedną ofiarę uczynił bowiem na zawsze doskonałymi tych, którzy dostępują uświęcenia.
###### **Hbr 10,15**
 A poświadcza nam to i Duch Święty. Po słowach bowiem:
###### **Hbr 10,16**
 Takie będzie przymierze, które zawrę z nimi po tych dniach - mówi Pan: Moje prawa umieszczę w ich sercach i wypiszę je w ich umysłach...
###### **Hbr 10,17**
 a ich grzechów ani nieprawości nie będę już pamiętał.
###### **Hbr 10,18**
 Otóż gdzie jest odpuszczenie grzechów, tam nie potrzeba już składać za nie ofiary.
###### **Hbr 10,19**
 Mamy więc pewność, bracia, że wejdziemy do miejsca świętego dzięki krwi Jezusa.
###### **Hbr 10,20**
 On otworzył dla nas nową, życiodajną drogę przez zasłonę, którą jest Jego ciało.
###### **Hbr 10,21**
 On jest wielkim kapłanem nad domem Bożym.
###### **Hbr 10,22**
 Zbliżmy się więc do Niego ze szczerym sercem i pełnym zaufaniem, skoro jesteśmy oczyszczeni ze złych skłonności serc i obmyci na ciele czystą wodą.
###### **Hbr 10,23**
 Trzymajmy się niewzruszenie wyznawanej nadziei, gdyż wierny jest dawca obietnicy!
###### **Hbr 10,24**
 Bądźmy wzajemnie za siebie odpowiedzialni, dążąc do gorliwej miłości i dobrych uczynków.
###### **Hbr 10,25**
 Nie zaniedbujmy wspólnych zgromadzeń, jak się to stało zwyczajem niektórych. Natomiast zachęcajmy się wzajemnie, im bardziej widzimy, że zbliża się Dzień Pana.
###### **Hbr 10,26**
 Gdybyśmy bowiem świadomie grzeszyli po otrzymaniu pełnego poznania prawdy, to już nie byłoby dla nas ofiary za grzechy,
###### **Hbr 10,27**
 zostałoby nam tylko okropne oczekiwanie na sąd i na żar ognia, który pochłonie buntowników.
###### **Hbr 10,28**
 Kto łamie prawo Mojżeszowe, ten bez litości ma być zabity na podstawie zeznania dwóch albo trzech świadków.
###### **Hbr 10,29**
 Rozważcie, na ile większą karę zasługuje ktoś, kto by zdeptał Syna Bożego, lekceważąc krew przymierza, która go uświęciła, i gardząc Duchem łaski!
###### **Hbr 10,30**
 Znamy przecież Tego, który powiedział: Do Mnie należy pomsta i Ja dokonam odpłaty! Oraz: Pan sam swój lud osądzi.
###### **Hbr 10,31**
 Straszna to rzecz wpaść w ręce Boga żywego!
###### **Hbr 10,32**
 Przypomnijcie sobie dawne dni. Tuż po otrzymaniu światła przetrwaliście liczne zmagania z cierpieniem,
###### **Hbr 10,33**
 czy to publicznie wystawieni na pośmiewisko i prześladowania, czy też uczestnicząc w nich z tymi, którzy ich doznawali.
###### **Hbr 10,34**
 Współcierpieliście przecież z uwięzionymi, przyjęliście z radością grabież waszego mienia, wiedząc, że sami posiadacie lepsze, trwałe dobra.
###### **Hbr 10,35**
 Nie pozbywajcie się więc tej pewności, bo wielka czeka was za nią nagroda!
###### **Hbr 10,36**
 Musicie tylko być wytrwali, abyście, pełniąc wolę Bożą, zasłużyli na spełnienie obietnicy:
###### **Hbr 10,37**
 Jeszcze bowiem bardzo krótka chwila, a przyjdzie Ten, który ma nadejść, i nie będzie zwlekać.
###### **Hbr 10,38**
 A mój sprawiedliwy będzie żył dzięki wierze, lecz gdyby się wycofał, moja dusza nie upodoba go sobie.
###### **Hbr 10,39**
 A przecież my nie należymy do odstępców, którzy mają zginąć, lecz do wiernych, którzy mają ocalić życie.
# Hbr 10 BP
###### **Hbr 10,1**
 Skoro zatem Prawo dotyczyło cienia dóbr przyszłych a nie ich samych, nigdy nie potrafi doprowadzić do doskonałości tych, którzy co roku przynoszą ofiary bezustannie składane.
###### **Hbr 10,2**
 Czyż nie zaprzestanoby ich składać, gdyby uczestnicy tych obrzędów raz oczyszczeni nie mieli już świadomości grzechów?
###### **Hbr 10,3**
 Ale przez nie corocznie przypomina się grzechy.
###### **Hbr 10,4**
 Niemożliwe jest przecież, żeby krew cieląt i koźląt gładziła grzechy.
###### **Hbr 10,5**
 Dlatego też wchodząc na świat powiada: "Ofiary krwawej czy bezkrwawej nie chciałeś, lecz ciało mi przysposobiłeś.
###### **Hbr 10,6**
 Ofiary całopalne i składane za grzech nie spodobały ci się.
###### **Hbr 10,7**
 Zatem rzekłem: Oto przyszedłem - napisano o mnie w zwoju księgi - żeby spełniać, o Boże, wolę Twoją".
###### **Hbr 10,8**
 Najpierw mówi: "Ofiar krwawych i bezkrwawych ani całopalnych i składanych za grzech nie chciałeś, bo nie podobały Ci się" - a takie składa się zgodnie z Prawem.
###### **Hbr 10,9**
 Następnie powiada: "Oto przychodzę, aby spełniać Twoją wolę" - znosi więc owo pierwsze, aby zaprowadzić to drugie.
###### **Hbr 10,10**
 Dzięki tej woli zostaliśmy uświęceni przez ofiarę z ciała Jezusa Chrystusa raz na zawsze złożoną.
###### **Hbr 10,11**
 Wszak każdy kapłan spełnia codziennie służbę Bożą i składa wciąż swoje ofiary, które jednak nigdy nie mogą zgładzić grzechów.
###### **Hbr 10,12**
 Ten natomiast raz na zawsze złożył jedną ofiarę krwawą za grzech i "zasiadł po prawicy Bożej".
###### **Hbr 10,13**
 Odtąd oczekuje, "aż jego nieprzyjaciele zostaną rzuceni jak podnóżek pod jego stopy".
###### **Hbr 10,14**
 Przez tę jedną ofiarę uczynił doskonałymi na zawsze tych, którzy mają być uświęceni.
###### **Hbr 10,15**
 Daje nam przecież świadectwo i Duch Święty, skoro powiedział:
###### **Hbr 10,16**
 "To jest przymierze, które zawrę z nimi po owych dniach, powiada Pan; włożę moje prawa w ich serca i wypiszę je w ich myślach,
###### **Hbr 10,17**
 a ich grzechów i nieprawości nie będę już więcej pamiętał".
###### **Hbr 10,18**
 A gdzie jest darowanie wszystkiego, tam nie ma już ofiary za grzechy.
###### **Hbr 10,19**
 Mając zatem, bracia, radosną ufność, że wejdziemy do sanktuarium dzięki krwi Jezusa -
###### **Hbr 10,20**
 a to wejście poza zasłonę otworzył nam przez drogę nową i żywą, to jest przez ciało swoje,
###### **Hbr 10,21**
 [mając] też wielkiego kapłana nad domem Bożym -
###### **Hbr 10,22**
 przystąpmy z czystymi sercami i pełnym zaufaniem, skorośmy przez pokropienie oczyścili serca ze świadomych grzechów i obmyli ciało oczyszczającą wodą.
###### **Hbr 10,23**
 Trwajmy niewzruszenie w nadziei, którą żyjemy, wierny jest bowiem Ten, który dał obietnicę!
###### **Hbr 10,24**
 Troszczmy się wspólnie o to, jak się zachęcać wzajemnie do miłości i dobrych uczynków!
###### **Hbr 10,25**
 Nie opuszczajmy wspólnego zgromadzenia, jak niektórzy mają w zwyczaju, dodawajmy sobie otuchy i to tym bardziej, im bliższy, jak widzicie, jest ów dzień.
###### **Hbr 10,26**
 Jeśli bowiem grzeszylibyśmy dobrowolnie, kiedy już otrzymaliśmy jasne poznanie prawdy, to nie ma dla nas nawet ofiary za grzechy,
###### **Hbr 10,27**
 lecz jakieś przerażające oczekiwanie sądu i żar ognia, który ma pożreć przeciwników.
###### **Hbr 10,28**
 Jeśli ktoś przekroczył Prawo Mojżeszowe "w oparciu o zeznanie dwóch albo trzech świadków, ponosi śmierć" bez miłosierdzia.
###### **Hbr 10,29**
 Jak myślicie? O ileż większej kary wart jest ten, kto zdeptał Syna Bożego i poczytał za rzecz bezwartościową krew Przymierza, przez którą został uświęcony, i odniósł się ze wzgardą do Ducha miłości?
###### **Hbr 10,30**
 Znamy przecież Tego, który mówi: "Do mnie należy pomsta, ja odpłacę!" I znowu: "Pan będzie sądził swój lud".
###### **Hbr 10,31**
 Straszną jest rzeczą wpaść w ręce Boga żyjącego!
###### **Hbr 10,32**
 Przypomnijcie sobie owe pierwsze dni, w których, gdy już zostaliście oświeceni, znosiliście cierpliwie częste zmagania z cierpieniem,
###### **Hbr 10,33**
 czy to publicznie wyszydzani i poniewierani, czy to jako współtowarzysze żyjących w takich warunkach.
###### **Hbr 10,34**
 Przecież i uwięzionym okazaliście współczucie i z radością znieśliście grabież waszego mienia, wiedząc, że sami posiadacie dobra lepsze i trwałe.
###### **Hbr 10,35**
 Nie traćcie więc cierpliwości, która otrzymuje wielką nagrodę.
###### **Hbr 10,36**
 Potrzeba wam przecież wytrwania, abyście wypełniając wolę Bożą osiągnęli to, co wam było obiecane.
###### **Hbr 10,37**
 Jeszcze bowiem "bardzo mała chwilka, Ten, który ma przyjść, nadejdzie i nie będzie zwlekał,
###### **Hbr 10,38**
 a mój sprawiedliwy dzięki wierze żyć będzie, a jeśli bojaźliwie odstąpi, nie będzie mi się podobał".
###### **Hbr 10,39**
 My jednak nie należymy do bojaźliwych, którzy mają zginąć, lecz do wierzących, którzy mają żyć.
# Hbr 10 BR
###### **Hbr 10,1**
 Prawo jest tylko cieniem przyszłych dóbr, a nie ich rzeczywistym wyrazem, i dlatego mimo corocznie składanych, ciągle tych samych ofiar nie jest w stanie udoskonalić tych, którzy przychodzą z owymi ofiarami [do Boga].
###### **Hbr 10,2**
 Czyżby bowiem nie przestano ich składać, gdyby ci, którzy je składają, oczyszczeni raz na zawsze, doszli do przeświadczenia, że już zostali oczyszczeni od wszelkiego grzechu?
###### **Hbr 10,3**
 Tymczasem rzecz się ma zgoła inaczej: to właśnie owe ofiary odnawiają co roku pamięć o ludzkich grzechach.
###### **Hbr 10,4**
 Bo krew wołów i kozłów nie jest w stanie zgładzić ludzkich grzechów.
###### **Hbr 10,5**
 Dlatego [Chrystus] przychodząc na świat powiedział [do Boga]: Nie chciałeś ofiary ani daru, lecz utworzyłeś mi ciało.
###### **Hbr 10,6**
 Nie znalazłeś upodobania w całopaleniach i w ofierze za grzechy.
###### **Hbr 10,7**
 Wtedy powiedziałem: Oto idę, aby - zgodnie z tym, co napisano o Mnie w księdze [Prawa] - pełnić, Boże, Twoją wolę.
###### **Hbr 10,8**
 Tak więc powiedział naprzód: Nie chciałeś ofiar ani darów, ani całopaleń, ani obrzędów oczyszczających; nie znalazłeś w nich upodobania, choć składa się je zgodnie z nakazami Prawa.
###### **Hbr 10,9**
 Potem dodał: Oto idę... aby pełnić Twoją wolę. W ten sposób znosi [Bóg dawne ofiary], aby na ich miejsce wprowadzić nową.
###### **Hbr 10,10**
 Na mocy tego postanowienia zostaliśmy [rzeczywiście i] raz na zawsze uświęceni przez złożenie w ofierze ciała Jezusa Chrystusa.
###### **Hbr 10,11**
 Podczas gdy każdy kapłan spełniając codziennie swą posługę składa wiele razy te same ofiary, nie będące jednak w stanie zgładzić naszych grzechów,
###### **Hbr 10,12**
 to Jezus złożył tylko raz jeden jedyną ofiarę za grzechy, a potem zasiadł na zawsze po prawicy Boga
###### **Hbr 10,13**
 oczekując już tylko na moment, gdy Jego nieprzyjaciele legną jako podnóżek u stóp Jego.
###### **Hbr 10,14**
 Jedną, jedyną ofiarą uczynił doskonałymi tych, którzy zostali oczyszczeni z grzechów.
###### **Hbr 10,15**
 Potwierdza to zresztą sam Duch Święty w słowach.
###### **Hbr 10,16**
 Oto przymierze, które zawrę z nimi po owych dniach - mówi Pan. W sercach ich umieszczę moje prawo, wypiszę je w ich umysłach.
###### **Hbr 10,17**
 I nie będę już wspominał ich grzechów oraz nieprawości.
###### **Hbr 10,18**
 Skoro zaś grzechy zostały już odpuszczone, nie zachodzi potrzeba składania ofiar za grzechy.
###### **Hbr 10,19**
 Tak więc, bracia, przez krew Jezusa mamy już zapewnione wejście do Miejsca Świętego.
###### **Hbr 10,20**
 Jest to nowa droga i nowe życie, które nam ukazał poprzez [jakby świątynną] zasłonę, to jest przez swoje własne ciało.
###### **Hbr 10,21**
 Mamy więc wielkiego kapłana, takiego, który sprawuje pieczę nad całym domem Bożym.
###### **Hbr 10,22**
 Zechciejmy przeto zbliżyć się do Niego ze szczerym sercem i niezachwianą wiarą, oczyszczeni uprzednio na duszy od zła wszelkiego i obmyci na ciele wodą czystą.
###### **Hbr 10,23**
 Trwajmy niewzruszenie przy nadziei, którą żyjemy, bo prawdziwie godny jest zaufania Ten, który nam dał obietnicę.
###### **Hbr 10,24**
 Okazujmy staranie jedni o drugich, zachęcajmy się do wzajemnej miłości i do spełniania dobrych uczynków.
###### **Hbr 10,25**
 Nie opuszczajmy naszych wspólnych zebrań, jak to już niektórzy zwykli czynić, ale zachęcajmy się wzajemnie [do udziału w nich], i to tym bardziej, im bardziej jesteśmy przekonani, że zbliża się dzień [Pański].
###### **Hbr 10,26**
 Jeżeli bowiem, doszedłszy już do pełnego poznania prawdy, znów z całą świadomością dopuszczamy się nowych występków, to nie ma już ofiary, która mogłaby zmazać nasze grzechy.
###### **Hbr 10,27**
 Nie pozostaje nam już wtedy nic innego, jak oczekiwać z przerażeniem na dzień sądu i na żar ognia, który strawi buntowników.
###### **Hbr 10,28**
 Kto przekracza Prawo Mojżeszowe, ten - na podstawie [zeznania] dwóch albo trzech świadków zasługuje bez żadnego miłosierdzia na karę śmierci.
###### **Hbr 10,29**
 Zastanówcie się zatem, jak surowa kara spotka tego, kto znieważa Syna Bożego, bezcześci uświęcającą nas Krew Przymierza i zachowuje się w sposób karygodny wobec Ducha, który jest dawcą łaski.
###### **Hbr 10,30**
 Wiemy przecież, kim jest Ten, który powiedział: Do Mnie należy pomsta, i Ja [za wszystko] odpłacę. Lub gdzie indziej: Sam Pan będzie sądził swój lud.
###### **Hbr 10,31**
 Straszna to rzecz wpaść w ręce Boga Żywego.
###### **Hbr 10,32**
 Przypomnijcie sobie minione dni waszego życia, kiedy to [zaraz] po otrzymanym oświeceniu musieliście znieść tyle utrapień.
###### **Hbr 10,33**
 Przecież albo sami byliście wystawieni na publiczne szyderstwa i prześladowania, albo współuczestniczyliście w cierpieniach tych, którzy znosili takie uciski.
###### **Hbr 10,34**
 Współcierpieliście z uwięzionymi, pogodziliście się w pogodzie ducha z tym, że was z wszystkiego ograbiono, pamiętając o tym, że posiadacie dobra o wiele cenniejsze i bardziej trwałe.
###### **Hbr 10,35**
 Nie pozwólcie więc wydrzeć sobie nadziei, dzięki której oczekujecie na wielką zapłatę.
###### **Hbr 10,36**
 Potrzebna wam wytrwałość, bo tylko dzięki niej, poddając się woli Bożej, dostąpicie spełnienia się w was obietnicy Bożej.
###### **Hbr 10,37**
 Już niedługo, bardzo niedługo przyjdzie Ten, który ma przyjść; nie opóźni się na pewno.
###### **Hbr 10,38**
 Sprawiedliwy będzie żył dzięki swej wierze. Gdyby zaś cofnł się, przestanę mieć w nim upodobanie.
###### **Hbr 10,39**
 Lecz my nie należymy do tych, którzy cofają się tchórzliwie idąc dobrowolnie na wieczną zgubę; jesteśmy ludźmi wiary, zatroskanymi o zbawienie własnej duszy.
# Hbr 10 WUJ
###### **Hbr 10,1**
 Abowiem zakon, mając cień przyszłych dóbr, nie sam obraz rzeczy: na każdy rok temiż samemi ofiarami, które ofiarują ustawicznie, nigdy nie może doskonałemi uczynić przystępujące:
###### **Hbr 10,2**
 Inaczej przestanoby je było ofiarować, dla tego, iżby więcej nie mieli żadnego sumnienia o grzech Boga chwalących raz oczyścieni.
###### **Hbr 10,3**
 Lecz w nich bywa przypominanie grzechów na każdy rok.
###### **Hbr 10,4**
 Abowiem nie podobna rzecz jest aby krwią wołów i kozłów miały być zgładzone grzechy.
###### **Hbr 10,5**
 Przetoż wchodząc na świat mówi: Nie chciałeś ofiary i obiaty: aleś mi ciało sposobił.
###### **Hbr 10,6**
 Całopalenia, i za grzech, nie upodobałyć się.
###### **Hbr 10,7**
 Tedym rzekł: Oto idę: na początku ksiąg napisano jest o mnie: Abym czynił Boże wolą twoję.
###### **Hbr 10,8**
 Wyżej powiedziawszy, Żeś nie chciał anić się podobały ofiary, i obiaty, i całopalenia za grzech, które wedle zakonu bywają ofiarowane:
###### **Hbr 10,9**
 Tedym rzekł: Otóż idę, abym czynił o Boże wolą twoję: Odejmuje pierwsze, aby wtóre postawił.
###### **Hbr 10,10**
 Przez którą wolą jesteśmy poświęceni przez ofiarę ciała Jezusa Chrystusa raz.
###### **Hbr 10,11**
 A każdy jednak kapłan stoi co dzień urząd odprawując, i też ofiary częstokroć ofiarując, które nigdy nie mogą grzechu znieść.
###### **Hbr 10,12**
 Lecz ten ofiarowawszy jednę ofiarę za grzechy, na wieki siedzi na prawicy Bożej.
###### **Hbr 10,13**
 Nakoniec czekając, ażby nieprzyjaciele jego położeni byli podnóżkiem nóg jego.
###### **Hbr 10,14**
 Abowiem jedną ofiarą, doskonałymi uczynił na wieki poświęcone.
###### **Hbr 10,15**
 A świadczy nam i Duch święty. Abowiem gdy powiedział:
###### **Hbr 10,16**
 Tenci jest testament, który postanowię z niemi po onych dniach, mówi Pan: Podając prawa moje w serca ich, i napiszę na umysłach ich:
###### **Hbr 10,17**
 I pamiętać już więcej nie będę grzechów i nieprawości ich.
###### **Hbr 10,18**
 A gdzieć odpuszczenie tych: jużci ofiary nie masz za grzech.
###### **Hbr 10,19**
 Mając tedy bracia ufność do weszcia Świątynie we krwi Chrystusowej.
###### **Hbr 10,20**
 Którą drogę nam poświęcił nową i żywą przez zasłonę, to jest ciało swoje:
###### **Hbr 10,21**
 I kapłana wielkiego nad domem Bożym:
###### **Hbr 10,22**
 Przystąpmy z prawdziwem sercem w zupełności wiary, pokropieni na sercach od sumnienia złego, i omyci na ciele czystą wodą:
###### **Hbr 10,23**
 Trzymajmy wyznanie nadzieje naszej nie chwiejące się (boć wierny jest, który obiecał).
###### **Hbr 10,24**
 I przypatrzajmy się jedni drugim ku pobudzaniu miłości i dobrych uczynków:
###### **Hbr 10,25**
 Nie opuszczając zgromadzenia naszego, jako mają obyczaj niektórzy: ale ciesząc, a tem więcej im barziej obaczycie przybliżający się dzień.
###### **Hbr 10,26**
 Bo jeślibyśmy umyślnie grzeszyli po wzięciu znajomości prawdy, już nie zostawa ofiara za grzech:
###### **Hbr 10,27**
 Lecz straszliwe jakieś oczekawanie sądu i żarliwość ognia, która pożrzeć ma przeciwniki.
###### **Hbr 10,28**
 Ktoby zakon Mojżeszów wzgardził: bez wszelkiego miłosierdzia za świadectwem dwu abo trzech umiera.
###### **Hbr 10,29**
 Jakoż mniemacie daleko sroższe zasłuży karania, któryby Syna Bożego podeptał, i krew testamentu, przez którą był poświęcony, pokalaną być rozumiał, i Ducha łaski zelżył?
###### **Hbr 10,30**
 Abowiem wiemy kto powiedział: Mnie pomsta, a ja oddam. I zasię: Iż Pan sądzić będzie lud swój.
###### **Hbr 10,31**
 Strasznoć jest wpaść w ręce Boga żywego.
###### **Hbr 10,32**
 Rozpominajcież dni dawne, w których będąc oświeceni, wytrwaliście wielką potyczkę trapienia.
###### **Hbr 10,33**
 Częścią gdy lekkościami i uciski dziwowiskiemeście się stali: a, częścią gdyście się stali towarzyszmi tak się mających.
###### **Hbr 10,34**
 Abowiemeście i z więźniami społu utrapieni byli: złupienie majętności waszych przyjęliście z weselem, wiedząc iż wy macie majętność w niebie lepszą i trwającą.
###### **Hbr 10,35**
 Nie traćcież tedy ufania waszego, które ma wielką zapłatę.
###### **Hbr 10,36**
 Abowiem cierpliwość wam jest potrzebna: abyście czyniąc wolą Bożą, odnieśli obietnicę.
###### **Hbr 10,37**
 Boć jeszcze trochę nieco, który ma przyść przydzie, i nie omieszka:
###### **Hbr 10,38**
 A sprawiedliwy mój z wiary żywię. A jeśli się schroni: nie będzie się podobał duszy mojej.
###### **Hbr 10,39**
 Lecz my nie jesteśmy synowie schraniania ku zginieniu: ale wiary ku otrzymaniu dusze.
# Hbr 10 STERN
###### **Hbr 10,1**
 Bo Tora zawiera cień dóbr, które mają przyjść, nie zaś faktyczne objawienie się pierwowzorów. Dlatego nigdy za sprawą samych ofiar powtarzanych bez końca rok w rok nie może doprowadzić do celu tych, którzy przychodzą je składać do Miejsca Świętego.
###### **Hbr 10,2**
 W przeciwnym razie czyż nie ustałoby składanie tych ofiar? Bo gdyby ludzie pełniący tę służbę zostali oczyszczeni raz na zawsze, więcej już nie mieliby grzechów na sumieniu.
###### **Hbr 10,3**
 Nie, jest wręcz przeciwnie - w ofiarach tych jest przypomnienie grzechów, rok w rok.
###### **Hbr 10,4**
 Bo niemożliwe jest, aby krew cielców i kozłów gładziła grzechy.
###### **Hbr 10,5**
 Dlatego przychodząc na świat, powiada: "Nie była Twoją wolą ofiara zwierzęca i ofiara z pokarmów; lecz przygotowałeś dla mnie ciało.
###### **Hbr 10,6**
 Nie, całopaleń ani ofiar za grzechy nie upodobałeś sobie.
###### **Hbr 10,7**
 Wtedy rzekłem: "Patrzcie! W zwoju księgi napisano o mnie. Przybyłem, aby czynić Twoją wolę"".
###### **Hbr 10,8**
 Mówiąc najpierw: "Nie były Twoją wolą ani nie upodobałeś sobie ofiar zwierzęcych, ofiar z pokarmów, całopaleń ani ofiar za grzechy" rzeczy, które składa się na ofiarę zgodnie z Torą,
###### **Hbr 10,9**
 a następnie: "Oto przybyłem, aby czynić Twoją wolę" usuwa On pierwszy system, aby ustanowić drugi.
###### **Hbr 10,10**
 Właśnie w związku z tą wolą zostaliśmy oddzieleni dla Boga i uświęceni, raz na zawsze, przez ofiarę ciała Jeszui Mesjasza.
###### **Hbr 10,11**
 A każdy kohen codziennie wykonuje swą służbę, raz po raz składając te same ofiary, które nigdy nie mogą zgładzić grzechów.
###### **Hbr 10,12**
 Lecz Ten, złożywszy raz na zawsze jedną jedyną ofiarę za grzechy, zasiadł po prawicy Boga,
###### **Hbr 10,13**
 aby odtąd oczekiwać, aż Jego nieprzyjaciele zostaną uczynieni podnóżkiem dla Jego stóp.
###### **Hbr 10,14**
 Bo przez jedną ofiarę doprowadził On na wieki do celu tych, którzy zostają zastrzeżeni dla Boga i uświęceni.
###### **Hbr 10,15**
 A również Ruach Ha-Kodesz składa nam świadectwo; bo powiedziawszy:
###### **Hbr 10,16**
 "Takie oto przymierze zawrę z nimi po tych dniach, mówi Adonai: Włożę moją Torę w ich umysły i wypiszę ją na ich sercach",
###### **Hbr 10,17**
 dodaje On następnie: "A o ich grzechach i niegodziwościach nie będę już pamiętał".
###### **Hbr 10,18**
 A gdzie jest przebaczenie za nie, tam nie jest już potrzebna ofiara za grzechy.
###### **Hbr 10,19**
 Mamy zatem, bracia, ufność, że skorzystamy z drogi do Miejsca Najświętszego otwartej przez krew Jeszui.
###### **Hbr 10,20**
 On otworzył ją nam poprzez swoje ciało jako nową i żywą drogę przez parochet.
###### **Hbr 10,21**
 Mamy również wielkiego kohena ponad domem Bożym.
###### **Hbr 10,22**
 Dlatego zbliżmy się do Miejsca Najświętszego ze szczerym sercem, w całkowitym przekonaniu, które wypływa z ufności - z sercami oczyszczonymi przez pokropienie od złego sumienia i ciałami obmytymi wodą czystą.
###### **Hbr 10,23**
 Wytrwale trzymajmy się nadziei, jaką wyznajemy, niezachwianie; bo godny zaufania jest Ten, który dał obietnicę.
###### **Hbr 10,24**
 I nieustannie uważajmy jeden na drugiego, żeby się wzajemnie pobudzać do miłości i dobrych czynów,
###### **Hbr 10,25**
 nie zaniedbując spotykania się w naszych zgromadzeniach, jak to weszło niektórym w zwyczaj, lecz zachęcając się nawzajem. A czyńmy to wszystko tym bardziej, gdy widzicie, że zbliża się ów Dzień.
###### **Hbr 10,26**
 Bo jeśli otrzymawszy poznanie prawdy, rozmyślnie trwamy w grzeszeniu, to nie ma już więcej ofiary za grzechy,
###### **Hbr 10,27**
 lecz tylko przerażająca perspektywa Sądu, ognia pożerającego, który strawi nieprzyjaciół.
###### **Hbr 10,28**
 Kto nie przestrzega Tory Moszego, zostaje zgładzony bez miłosierdzia na podstawie słowa dwóch lub trzech świadków.
###### **Hbr 10,29**
 Pomyślcie, o ileż gorsza będzie kara, na jaką zasłuży ten, kto zdeptał Syna Bożego, kto jak coś pospolitego potraktował tę krew przymierza która go uświęciła, i kto ubliżył Duchowi, dawcy łaski Bożej!
###### **Hbr 10,30**
 Bo Ten, którego znamy, jest też Tym, który powiedział: "Pomsta do mnie należy, ja odpłacę", a następnie rzekł: "Adonai będzie sądził swój lud".
###### **Hbr 10,31**
 Rzecz to przerażająca: wpaść w ręce Boga żywego!
###### **Hbr 10,32**
 Przypomnijcie sobie jednak wcześniejsze dni, gdy otrzymawszy światło, wytrwaliście w ciężkich zmaganiach z cierpieniami.
###### **Hbr 10,33**
 Czasami publicznie was znieważano i prześladowano, innymi razy wiernie staliście przy tych, których tak traktowano.
###### **Hbr 10,34**
 Bo dzieliliście cierpienia tych, których uwięziono. Również gdy zagrabiono wasze mienie, przyjęliście to radośnie, wiedząc, że to, co posiadacie, lepsze jest i będzie trwać na wieki.
###### **Hbr 10,35**
 Nie odrzucajcie więc tej swojej odwagi, która niesie z sobą tak wielką nagrodę.
###### **Hbr 10,36**
 Bo trzeba wam wytrwać, abyście uczyniwszy to, czego chce Bóg, otrzymali to, co On obiecał.
###### **Hbr 10,37**
 Gdyż: "Czas jest tak krótki! Nadchodzący zaiste nadejdzie, nie będzie zwlekał.
###### **Hbr 10,38**
 Lecz człowiek sprawiedliwy żył będzie przez ufanie, a jeśli się cofnie, nie będę miał w nim upodobania".
###### **Hbr 10,39**
 My jednak nie z tych, którzy się cofają i giną; przeciwnie - wytrwale ufamy i w ten sposób ocalimy swe życie!
# Hbr 10 TRO
###### **Hbr 10,1**
 **σκιαν** *skian* Cień [[G4639]] WTN-ASF **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εχων** *echōn* mając [[G2192]] [[V-PAP-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **νομος** *nomos* Prawo [[G3551]] [[N-NSM]] **των** *tōn* [[G3588]] WTT-GPN **μελλοντων** *mellontōn* mających nastąpić [[G3195]] WTV-PAP-GPN **αγαθων** *agathōn* dobrych [[G18]] WTA-GPN **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **αυτην** *autēn* sam [[G846]] [[P-ASF]] **την** *tēn* [[G3588]] WTT-ASF **εικονα** *eikona* obraz [[G1504]] WTN-ASF **των** *tōn* [[G3588]] WTT-GPN **πραγματων** *pragmatōn* spraw [[G4229]] WTN-GPN **κατ** *kat* co [[G2596]] [[PREP]] **ενιαυτον** *eniauton* rok [[G1763]] [[N-ASM]] **ταις** *tais* [[G3588]] WTT-DPF **αυταις** *autais* tymi samymi [[G846]] WTP-DPF **θυσιαις** *thysiais* ofiarami [[G2378]] WTN-DPF **ας** *has* które [[G3739]] WTR-APF **προσφερουσιν** *prosferousin* przynoszą – ofiarowują [[G4374]] WTV-PAI-3P **εις** *eis* na [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **διηνεκες** *diēnekes* ciągłe – nieprzerwane [[G1336]] WTA-ASN **ουδεποτε** *oudepote* nigdy [[G3763]] [[ADV]] **δυναται** *dynatai* może [[G1410]] WTV-PNI-3S **τους** *tous* [[G3588]] WTT-APM **προσερχομενους** *proserchomenous* podchodzących – zbliżających się [[G4334]] WTV-PNP-APM **τελειωσαι** *teleiōsai* uczynić doskonałymi – zostać doprowadzonymi do doskonałości [[G5048]] [[V-AAN]]
###### **Hbr 10,2**
 **επει** *epei* skoro – jako, że [[G1893]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **αν** *an* (kiedy)kolwiek [[G302]] WTPRT **επαυσαντο** *epausanto* powstrzymywali – zaprzestali [[G3973]] WTV-AMI-3P **προσφερομεναι** *prosferomenai* które są przynoszone – które są ofiarowywane [[G4374]] WTV-PPP-NPF **δια** *dia* dla- [[G1223]] [[PREP]] **το** *to* (tego) [[G3588]] WTT-ASN **μηδεμιαν** *mēdemian* żadnej [[G3367]] WTA-ASF **εχειν** *echein* mieć [[G2192]] WTV-PAN **ετι** *eti* już [[G2089]] [[ADV]] **συνειδησιν** *syneidēsin* sumienia – świadomości [[G4893]] WTN-ASF **αμαρτιων** *hamartiōn* grzechów [[G266]] WTN-GPF **τους** *tous* [[G3588]] WTT-APM **λατρευοντας** *latreuontas* pełniący służbę [[G3000]] WTV-PAP-APM **απαξ** *hapaks* raz [[G530]] [[ADV]] **κεκαθαρμενους** *kekatharmenous* którzy są oczyszczonymi [[G2508]] WTV-RPP-APM
###### **Hbr 10,3**
 **αλλ** *all* Ale [[G235]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **αυταις** *autais* nich [[G846]] WTP-DPF **αναμνησις** *anamnēsis* przypomnienie – pamiątka [[G364]] [[N-NSF]] **αμαρτιων** *hamartiōn* grzechów [[G266]] WTN-GPF **κατ** *kat* co [[G2596]] [[PREP]] **ενιαυτον** *eniauton* rok [[G1763]] [[N-ASM]]
###### **Hbr 10,4**
 **αδυνατον** *adynaton* niemożliwe [[G102]] WTA-NSN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **αιμα** *haima* krew [[G129]] WTN-NSN **ταυρων** *taurōn* byków – wołów [[G5022]] WTN-GMP **και** *kai* i [[G2532]] [[CONJ]] **τραγων** *tragōn* kozłów [[G5131]] WTN-GPM **αφαιρειν** *afairein* zabrać – oddzielać [[G851]] WTV-PAN **αμαρτιας** *hamartias* grzechy [[G266]] WTN-APF
###### **Hbr 10,5**
 **διο** *dio* Dlatego [[G1352]] [[CONJ]] **εισερχομενος** *eiserchomenos* wchodząc [[G1525]] WTV-PNP-NSM **εις** *eis* na [[G1519]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **κοσμον** *kosmon* świat [[G2889]] [[N-ASM]] **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **θυσιαν** *thysian* ofiary [[G2378]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **προσφοραν** *prosforan* daru [[G4376]] WTN-ASF **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ηθελησας** *ēthelēsas* chciałeś [[G2309]] WTV-AAI-2S **σωμα** *sōma* ciało [[G4983]] WTN-ASN **δε** *de* zaś [[G1161]] [[CONJ]] **κατηρτισω** *katērtisō* wydoskonaliłeś [[G2675]] WTV-AMI-2S **μοι** *moi* mi [[G3427]] WTP-1DS
###### **Hbr 10,6**
 **ολοκαυτωματα** *holokautōmata* (w) całopaleniach [[G3646]] WTN-APN **και** *kai* i [[G2532]] [[CONJ]] **περι** *peri* za [[G4012]] [[PREP]] **αμαρτιας** *hamartias* grzech [[G266]] [[N-GSF]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ευδοκησας** *eudokēsas* znalazłeś upodobania [[G2106]] WTV-AAI-2S
###### **Hbr 10,7**
 **τοτε** *tote* Wtedy [[G5119]] [[ADV]] **ειπον** *eipon* powiedziałem [[G2036]] WTV-2AAI-1S **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **ηκω** *hēkō* przychodzę [[G2240]] WTV-PAI-1S **εν** *en* w [[G1722]] [[PREP]] **κεφαλιδι** *kefalidi* głowicy [[G2777]] [[N-DSF]] **βιβλιου** *bibliou* zwoju [[G975]] [[N-GSN]] **γεγραπται** *gegraptai* jest napisane [[G1125]] WTV-RPI-3S **περι** *peri* o [[G4012]] [[PREP]] **εμου** *emou* mnie [[G1700]] WTP-1GS **του** *tou* (by) [[G3588]] WTT-GSM **ποιησαι** *poiēsai* uczynić [[G4160]] [[V-AAN]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Boże [[G2316]] [[N-NSM]] **το** *to* [[G3588]] WTT-ASN **θελημα** *thelēma* wolę [[G2307]] WTN-ASN **σου** *sou* Twoją [[G4675]] WTP-2GS
###### **Hbr 10,8**
 **ανωτερον** *anōteron* Powyżej – Najpierw [[G511]] WTA-ASN **λεγων** *legōn* mówiąc [[G3004]] [[V-PAP-NSM]] **οτι** *hoti* że [[G3754]] [[CONJ]] **θυσιαν** *thysian* ofiary [[G2378]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **προσφοραν** *prosforan* daru [[G4376]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **ολοκαυτωματα** *holokautōmata* całopaleń [[G3646]] WTN-APN **και** *kai* i [[G2532]] [[CONJ]] **περι** *peri* za [[G4012]] [[PREP]] **αμαρτιας** *hamartias* grzechy [[G266]] [[N-GSF]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ηθελησας** *ēthelēsas* chciałeś [[G2309]] WTV-AAI-2S **ουδε** *oude* ani [[G3761]] [[ADV]] **ευδοκησας** *eudokēsas* znalazłeś upodobania [[G2106]] WTV-AAI-2S **αιτινες** *haitines* które [[G3748]] WTR-NPF **κατα** *kata* według [[G2596]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **νομον** *nomon* Prawa [[G3551]] [[N-ASM]] **προσφερονται** *prosferontai* są przynoszone – są ofiarowywane [[G4374]] WTV-PPI-3P
###### **Hbr 10,9**
 **τοτε** *tote* Wtedy [[G5119]] [[ADV]] **ειρηκεν** *eirēken* powiedział [[G2046]] WTV-RAI-3S-ATT **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **ηκω** *hēkō* przychodzę [[G2240]] WTV-PAI-1S **του** *tou* [[G3588]] WTT-GSM **ποιησαι** *poiēsai* uczynić [[G4160]] [[V-AAN]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Boże [[G2316]] [[N-NSM]] **το** *to* [[G3588]] WTT-ASN **θελημα** *thelēma* wolę [[G2307]] WTN-ASN **σου** *sou* Twoją [[G4675]] WTP-2GS **αναιρει** *anairei* znosi – zabiera [[G337]] WTV-PAI-3S **το** *to* [[G3588]] WTT-ASN **πρωτον** *prōton* pierwsze [[G4413]] WTA-ASN **ινα** *hina* aby [[G2443]] [[CONJ]] **το** *to* [[G3588]] WTT-ASN **δευτερον** *deuteron* drugie [[G1208]] WTA-ASN **στηση** *stēsē* postawiłby – ustanowiłby [[G2476]] WTV-AAS-3S
###### **Hbr 10,10**
 **εν** *en* w [[G1722]] [[PREP]] **ω** *hō* tej [[G3739]] WTR-DSN **θεληματι** *thelēmati* woli [[G2307]] WTN-DSN **ηγιασμενοι** *hēgiasmenoi* którzy są uświęceni – którzy są poświęceni [[G37]] WTV-RPP-NPM **εσμεν** *esmen* jesteśmy [[G2070]] WTV-PXI-1P **δια** *dia* przez [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **προσφορας** *prosforas* ofiarę [[G4376]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSN **σωματος** *sōmatos* ciała [[G4983]] [[N-GSN]] **του** *tou* [[G3588]] WTT-GSM **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **εφαπαξ** *efapaks* raz na zawsze [[G2178]] [[ADV]]
###### **Hbr 10,11**
 **και** *kai* I [[G2532]] [[CONJ]] **πας** *pas* każdy [[G3956]] [[A-NSM]] **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **ιερευς** *hiereus* kapłan [[G2409]] [[N-NSM]] **εστηκεν** *hestēken* stawał [[G2476]] WTV-IAI-3S **καθ** *kath* co [[G2596]] [[PREP]] **ημεραν** *hēmeran* dzień [[G2250]] WTN-ASF **λειτουργων** *leitourgōn* pełniąc publiczną służbę – pełniąc społeczne dzieło [[G3008]] [[V-PAP-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **τας** *tas* [[G3588]] WTT-APF **αυτας** *autas* te same [[G846]] WTP-APF **πολλακις** *pollakis* wielokrotnie – częstokroć [[G4178]] [[ADV]] **προσφερων** *prosferōn* przynosząc – ofiarowując [[G4374]] [[V-PAP-NSM]] **θυσιας** *thysias* ofiary [[G2378]] WTN-APF **αιτινες** *haitines* które [[G3748]] WTR-NPF **ουδεποτε** *oudepote* nigdy [[G3763]] [[ADV]] **δυνανται** *dynantai* mogą [[G1410]] WTV-PNI-3P **περιελειν** *perielein* zdjąć – zrzucić [[G4014]] [[V-2AAN]] **αμαρτιας** *hamartias* grzechów [[G266]] WTN-APF
###### **Hbr 10,12**
 **αυτος** *autos* Ten [[G846]] WTP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **μιαν** *mian* jeden [[G1520]] WTA-ASF **υπερ** *hyper* za [[G5228]] [[PREP]] **αμαρτιων** *hamartiōn* grzechy [[G266]] WTN-GPF **προσενεγκας** *prosenegkas* przyniósłszy – ofiarowawszy [[G4374]] WTV-AAP-NSM **θυσιαν** *thysian* ofiarę [[G2378]] WTN-ASF **εις** *eis* na [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **διηνεκες** *diēnekes* ciągłe – nieprzerwane [[G1336]] WTA-ASN **εκαθισεν** *ekathisen* usiadł [[G2523]] [[V-AAI-3S]] **εν** *en* po [[G1722]] [[PREP]] **δεξια** *deksia* prawej stronie – prawicy [[G1188]] WTA-DSF **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **Hbr 10,13**
 **το** *to* [[G3588]] WTT-ASN **λοιπον** *loipon* W końcu [[G3063]] WTA-ASN **εκδεχομενος** *ekdechomenos* czekając [[G1551]] WTV-PNP-NSM **εως** *heōs* aż do – dopóki [[G2193]] [[CONJ]] **τεθωσιν** *tethōsin* zostaliby położeni [[G5087]] WTV-APS-3P **οι** *hoi* [[G3588]] WTT-NPM **εχθροι** *echthroi* wrogowie – nieprzyjaciele [[G2190]] WTA-NPM **αυτου** *autou* Jego [[G846]] [[P-GSM]] **υποποδιον** *hypopodion* podnóżkiem [[G5286]] WTN-ASN **των** *tōn* [[G3588]] WTT-GPM **ποδων** *podōn* stóp [[G4228]] WTN-GPM **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Hbr 10,14**
 **μια** *mia* (w) jednej [[G1520]] WTA-DSF **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **προσφορα** *prosfora* ofierze [[G4376]] [[N-DSF]] **τετελειωκεν** *teteleiōken* uczynił doskonałymi – doprowadził do doskonałości [[G5048]] WTV-RAI-3S **εις** *eis* na [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **διηνεκες** *diēnekes* ciągłe – nieprzerwane [[G1336]] WTA-ASN **τους** *tous* [[G3588]] WTT-APM **αγιαζομενους** *hagiazomenous* którzy są uświęcani – którzy są poświęcani [[G37]] WTV-PPP-APM
###### **Hbr 10,15**
 **μαρτυρει** *martyrei* Świadczy [[G3140]] WTV-PAI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **ημιν** *hēmin* nam [[G2254]] WTP-1DP **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **πνευμα** *pneuma* Duch [[G4151]] WTN-NSN **το** *to* [[G3588]] WTT-NSN **αγιον** *hagion* Święty [[G40]] WTA-NSN **μετα** *meta* po [[G3326]] [[PREP]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **το** *to* [[G3588]] WTT-ASN **προειρηκεναι** *proeirēkenai* przewidzieć – powiedzieć wpierw [[G4280]] WTV-RAN
###### **Hbr 10,16**
 **αυτη** *hautē* To [[G3778]] WTD-NSF **η** *hē* [[G3588]] [[T-NSF]] **διαθηκη** *diathēkē* przymierze [[G1242]] [[N-NSF]] **ην** *hēn* które [[G3739]] WTR-ASF **διαθησομαι** *diathēsomai* zawrę – ułożę sobie [[G1303]] WTV-FDI-1S **προς** *pros* względem [[G4314]] [[PREP]] **αυτους** *autous* nich [[G846]] [[P-APM]] **μετα** *meta* po [[G3326]] [[PREP]] **τας** *tas* [[G3588]] WTT-APF **ημερας** *hēmeras* dniach [[G2250]] WTN-APF **εκεινας** *ekeinas* tych [[G1565]] WTD-APF **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **διδους** *didous* dając [[G1325]] [[V-PAP-NSM]] **νομους** *nomous* Prawa [[G3551]] [[N-APM]] **μου** *mou* moje [[G3450]] WTP-1GS **επι** *epi* do [[G1909]] [[PREP]] **καρδιας** *kardias* serc [[G2588]] WTN-APF **αυτων** *autōn* ich [[G846]] WTP-GPM **και** *kai* i [[G2532]] [[CONJ]] **επι** *epi* na [[G1909]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPF **διανοιων** *dianoiōn* myśli – umysły [[G1271]] WTN-GPF **αυτων** *autōn* ich [[G846]] WTP-GPM **επιγραψω** *epigrapsō* napiszę [[G1924]] WTV-FAI-1S **αυτους** *autous* je [[G846]] [[P-APM]]
###### **Hbr 10,17**
 **και** *kai* i [[G2532]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPF **αμαρτιων** *hamartiōn* grzechów [[G266]] WTN-GPF **αυτων** *autōn* ich [[G846]] WTP-GPM **και** *kai* i [[G2532]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPF **ανομιων** *anomiōn* bezprawia – nieprawości [[G458]] WTN-GPF **αυτων** *autōn* ich [[G846]] WTP-GPM **ου** *ou* nie [[G3756]] [[PRT-N]] **μη** *mē* [[G3361]] [[PRT-N]] **μνησθω** *mnēsthō* zostałyby mi przypomniane [[G3415]] WTV-APS-1S **ετι** *eti* już [[G2089]] [[ADV]]
###### **Hbr 10,18**
 **οπου** *hopou* Gdzie – Dokąd [[G3699]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **αφεσις** *afesis* uwolnienie – wyzwolenie [[G859]] [[N-NSF]] **τουτων** *toutōn* (od) tych [[G5130]] WTD-GPF **ουκετι** *ouketi* już nie [[G3765]] [[ADV]] **προσφορα** *prosfora* ofiara [[G4376]] [[N-NSF]] **περι** *peri* za [[G4012]] [[PREP]] **αμαρτιας** *hamartias* grzech [[G266]] [[N-GSF]]
###### **Hbr 10,19**
 **εχοντες** *echontes* Mając [[G2192]] WTV-PAP-NPM **ουν** *oun* więc [[G3767]] [[CONJ]] **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **παρρησιαν** *parrēsian* śmiałość [[G3954]] WTN-ASF **εις** *eis* do [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **εισοδον** *eisodon* wejścia [[G1529]] WTN-ASF **των** *tōn* (tych) [[G3588]] WTT-GPN **αγιων** *hagiōn* świętych [[G39]] WTA-GPN **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **αιματι** *haimati* krwi [[G129]] WTN-DSN **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]]
###### **Hbr 10,20**
 **ην** *hēn* które [[G3739]] WTR-ASF **ενεκαινισεν** *enekainisen* poświęcił – odnowił [[G1457]] [[V-AAI-3S]] **ημιν** *hēmin* (dla) nas [[G2254]] WTP-1DP **οδον** *hodon* drogę [[G3598]] WTN-ASF **προσφατον** *prosfaton* nową [[G4372]] WTA-ASF **και** *kai* i [[G2532]] [[CONJ]] **ζωσαν** *zōsan* żyjącą [[G2198]] WTV-PAP-ASF **δια** *dia* przez [[G1223]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **καταπετασματος** *katapetasmatos* zasłonę [[G2665]] [[N-GSN]] **τουτ** *tout* to [[G5124]] WTD-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **της** *tēs* [[G3588]] [[T-GSF]] **σαρκος** *sarkos* ciało [[G4561]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Hbr 10,21**
 **και** *kai* i [[G2532]] [[CONJ]] **ιερεα** *hierea* kapłana [[G2409]] [[N-ASM]] **μεγαν** *megan* wielkiego [[G3173]] WTA-ASM **επι** *epi* nad [[G1909]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **οικον** *oikon* domem [[G3624]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **Hbr 10,22**
 **προσερχωμεθα** *proserchōmetha* Podchodzilibyśmy – Zbliżalibyśmy się [[G4334]] WTV-PNS-1P **μετα** *meta* z [[G3326]] [[PREP]] **αληθινης** *alēthinēs* prawdziwym [[G228]] WTA-GSF **καρδιας** *kardias* sercem [[G2588]] [[N-GSF]] **εν** *en* w [[G1722]] [[PREP]] **πληροφορια** *plēroforia* pełni [[G4136]] [[N-DSF]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **ερραντισμενοι** *errantismenoi* które są pokropione – które są skropione [[G4472]] WTV-RPP-NPM **τας** *tas* [[G3588]] WTT-APF **καρδιας** *kardias* serca [[G2588]] WTN-APF **απο** *apo* z [[G575]] [[PREP]] **συνειδησεως** *syneidēseōs* sumienia [[G4893]] [[N-GSF]] **πονηρας** *ponēras* niegodziwego – złego [[G4190]] WTA-GSF **και** *kai* i [[G2532]] [[CONJ]] **λελουμενοι** *leloumenoi* które są umyte [[G3068]] WTV-RPP-NPM **το** *to* [[G3588]] WTT-ASN **σωμα** *sōma* ciało [[G4983]] WTN-ASN **υδατι** *hydati* wodą [[G5204]] WTN-DSN **καθαρω** *katharō* czystą [[G2513]] WTA-DSN
###### **Hbr 10,23**
 **κατεχωμεν** *katechōmen* trzymalibyśmy – zachowywalibyśmy [[G2722]] WTV-PAS-1P **την** *tēn* [[G3588]] WTT-ASF **ομολογιαν** *homologian* wyznanie – przyznanie [[G3671]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **ελπιδος** *elpidos* nadziei [[G1680]] [[N-GSF]] **ακλινη** *aklinē* niewzruszonej – nieodchylającej się [[G186]] WTA-ASF **πιστος** *pistos* wierny [[G4103]] [[A-NSM]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **επαγγειλαμενος** *epangeilamenos* który obiecał [[G1861]] WTV-ADP-NSM
###### **Hbr 10,24**
 **και** *kai* i [[G2532]] [[CONJ]] **κατανοωμεν** *katanoōmen* dostrzegalibyśmy – zauważalibyśmy [[G2657]] WTV-PAS-1P **αλληλους** *allēlous* jedni drugich [[G240]] WTC-APM **εις** *eis* ku [[G1519]] [[PREP]] **παροξυσμον** *paroksysmon* pobudzaniu – wyostrzaniu [[G3948]] [[N-ASM]] **αγαπης** *agapēs* miłości [[G26]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **καλων** *kalōn* dobrych – pięknych [[G2570]] WTA-GPN **εργων** *ergōn* dzieł – uczynków [[G2041]] WTN-GPN
###### **Hbr 10,25**
 **μη** *mē* nie [[G3361]] [[PRT-N]] **εγκαταλειποντες** *egkataleipontes* opuszczając – pozostawiając [[G1459]] WTV-PAP-NPM **την** *tēn* [[G3588]] WTT-ASF **επισυναγωγην** *episynagōgēn* zgromadzenia się – zebrania się [[G1997]] WTN-ASF **εαυτων** *heautōn* swoich [[G1438]] WTF-3GPM **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **εθος** *ethos* zwyczaj [[G1485]] WTN-NSN **τισιν** *tisin* niektórym – jakimś [[G5100]] WTX-DPM **αλλα** *alla* ale [[G235]] [[CONJ]] **παρακαλουντες** *parakalountes* zachęcając [[G3870]] WTV-PAP-NPM **και** *kai* i [[G2532]] [[CONJ]] **τοσουτω** *tosoutō* o tak wiele – o tyle [[G5118]] WTD-DSN **μαλλον** *mallon* bardziej [[G3123]] [[ADV]] **οσω** *hosō* ile – jak [[G3745]] WTK-DSN **βλεπετε** *blepete* patrzycie – widzicie [[G991]] WTV-PAI-2P **εγγιζουσαν** *engizousan* zbliżający się – będący blisko [[G1448]] WTV-PAP-ASF **την** *tēn* [[G3588]] WTT-ASF **ημεραν** *hēmeran* dzień [[G2250]] WTN-ASF
###### **Hbr 10,26**
 **εκουσιως** *hekousiōs* chętnie – dobrowolnie [[G1596]] [[ADV]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **αμαρτανοντων** *hamartanontōn* grzesząc [[G264]] WTV-PAP-GPM **ημων** *hēmōn* nam [[G2257]] WTP-1GP **μετα** *meta* po [[G3326]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **λαβειν** *labein* otrzymać [[G2983]] [[V-2AAN]] **την** *tēn* [[G3588]] WTT-ASF **επιγνωσιν** *epignōsin* poznanie [[G1922]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **αληθειας** *alētheias* prawdy [[G225]] [[N-GSF]] **ουκετι** *ouketi* już nie [[G3765]] [[ADV]] **περι** *peri* za [[G4012]] [[PREP]] **αμαρτιων** *hamartiōn* grzechy [[G266]] WTN-GPF **απολειπεται** *apoleipetai* jest pozostawiona – jest opuszczona [[G620]] WTV-PPI-3S **θυσια** *thysia* ofiara [[G2378]] [[N-NSF]]
###### **Hbr 10,27**
 **φοβερα** *fobera* straszne – napawające bojaźnią [[G5398]] WTA-NSF **δε** *de* zaś [[G1161]] [[CONJ]] **τις** *tis* jakieś [[G5100]] WTX-NSF **εκδοχη** *ekdochē* czekanie [[G1561]] [[N-NSF]] **κρισεως** *kriseōs* sądu [[G2920]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **πυρος** *pyros* ognia [[G4442]] [[N-GSN]] **ζηλος** *zēlos* żarliwość – zapał [[G2205]] WTN-NSN **εσθιειν** *esthiein* jeść [[G2068]] WTV-PAN **μελλοντος** *mellontos* mającego przyjść – mającego nastąpić [[G3195]] WTV-PAP-GSN **τους** *tous* [[G3588]] WTT-APM **υπεναντιους** *hypenantious* przeciwnych [[G5227]] WTA-APM
###### **Hbr 10,28**
 **αθετησας** *athetēsas* Odrzuciwszy [[G114]] WTV-AAP-NSM **τις** *tis* ktoś [[G5100]] WTX-NSM **νομον** *nomon* Prawo [[G3551]] [[N-ASM]] **μωσεως** *mōseōs* Mojżesza – [wyciągnąć] [[G3475]] [[N-GSM]] **χωρις** *chōris* bez [[G5565]] [[ADV]] **οικτιρμων** *oiktirmōn* okazów miłosierdzia – okazów litości [[G3628]] WTN-GPM **επι** *epi* przez [[G1909]] [[PREP]] **δυσιν** *dysin* dwóch [[G1417]] WTA-DPM **η** *ē* lub [[G2228]] WTPRT **τρισιν** *trisin* trzech [[G5140]] WTA-DPM **μαρτυσιν** *martysin* świadków [[G3144]] WTN-DPM **αποθνησκει** *apothnēskei* umiera [[G599]] WTV-PAI-3S
###### **Hbr 10,29**
 **ποσω** *posō* ile więcej – jak wielce [[G4214]] WTQ-DSN **δοκειτε** *dokeite* uważacie [[G1380]] WTV-PAI-2P **χειρονος** *cheironos* gorszego [[G5501]] WTA-GSF **αξιωθησεται** *aksiōthēsetai* zostanie uznany za godnego [[G515]] WTV-FPI-3S **τιμωριας** *timōrias* kary – karania [[G5098]] [[N-GSF]] **ο** *ho* [[G3588]] [[T-NSM]] **τον** *ton* [[G3588]] [[T-ASM]] **υιον** *hyion* Syna [[G5207]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **καταπατησας** *katapatēsas* który podeptał – który rozdeptał [[G2662]] WTV-AAP-NSM **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-ASN **αιμα** *haima* krew [[G129]] WTN-ASN **της** *tēs* [[G3588]] [[T-GSF]] **διαθηκης** *diathēkēs* przymierza [[G1242]] [[N-GSF]] **κοινον** *koinon* pospolitą [[G2839]] WTA-ASN **ηγησαμενος** *hēgēsamenos* który uznał [[G2233]] WTV-ADP-NSM **εν** *en* przez [[G1722]] [[PREP]] **ω** *hō* którą [[G3739]] WTR-DSN **ηγιασθη** *hēgiasthē* został uświęcony – został poświęcony [[G37]] [[V-API-3S]] **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-ASN **πνευμα** *pneuma* Ducha [[G4151]] WTN-ASN **της** *tēs* [[G3588]] [[T-GSF]] **χαριτος** *charitos* łaski [[G5485]] [[N-GSF]] **ενυβρισας** *enybrisas* który znieważył [[G1796]] WTV-AAP-NSM
###### **Hbr 10,30**
 **οιδαμεν** *oidamen* Znamy [[G1492]] WTV-RAI-1P **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **τον** *ton* (Tego) [[G3588]] [[T-ASM]] **ειποντα** *eiponta* który powiedział [[G2036]] WTV-2AAP-ASM **εμοι** *emoi* Mnie [[G1698]] WTP-1DS **εκδικησις** *ekdikēsis* ukaranie – pomsta [[G1557]] [[N-NSF]] **εγω** *egō* Ja [[G1473]] WTP-1NS **ανταποδωσω** *antapodōsō* odpłacę – oddam w zamian [[G467]] WTV-FAI-1S **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **παλιν** *palin* znów [[G3825]] [[ADV]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **κρινει** *krinei* osądzi [[G2919]] WTV-FAI-3S **τον** *ton* [[G3588]] [[T-ASM]] **λαον** *laon* lud [[G2992]] [[N-ASM]] **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Hbr 10,31**
 **φοβερον** *foberon* Straszne – Napawające bojaźnią [[G5398]] WTA-NSN **το** *to* [[G3588]] WTT-NSN **εμπεσειν** *empesein* wpaść [[G1706]] [[V-2AAN]] **εις** *eis* w [[G1519]] [[PREP]] **χειρας** *cheiras* ręce [[G5495]] WTN-APF **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ζωντος** *zōntos* żyjącego [[G2198]] WTV-PAP-GSM
###### **Hbr 10,32**
 **αναμιμνησκεσθε** *anamimnēskesthe* Przypominajcie sobie [[G363]] WTV-PMM-2P **δε** *de* zaś [[G1161]] [[CONJ]] **τας** *tas* (te) [[G3588]] WTT-APF **προτερον** *proteron* wcześniej [[G4386]] WTA-ASN **ημερας** *hēmeras* dni [[G2250]] WTN-APF **εν** *en* w [[G1722]] [[PREP]] **αις** *hais* których [[G3739]] WTR-DPF **φωτισθεντες** *fōtisthentes* którzy zostaliście oświeceni [[G5461]] WTV-APP-NPM **πολλην** *pollēn* wielką [[G4183]] WTA-ASF **αθλησιν** *athlēsin* atletyczną walką – atletycznym konfliktem [[G119]] WTN-ASF **υπεμεινατε** *hypemeinate* znieśliście – przetrzymaliście [[G5278]] WTV-AAI-2P **παθηματων** *pathēmatōn* cierpienia [[G3804]] WTN-GPN
###### **Hbr 10,33**
 **τουτο** *touto* To [[G5124]] WTD-NSN **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **ονειδισμοις** *oneidismois* zniewagom – obelgom [[G3680]] WTN-DPM **τε** *te* zarówno – także [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **θλιψεσιν** *thlipsesin* uciskom – utrapieniom [[G2347]] WTN-DPF **θεατριζομενοι** *theatrizomenoi* którzy są uczynieni widowiskiem [[G2301]] WTV-PPP-NPM **τουτο** *touto* to [[G5124]] WTD-NSN **δε** *de* zaś [[G1161]] [[CONJ]] **κοινωνοι** *koinōnoi* wspólnicy [[G2844]] WTA-NPM **των** *tōn* (tych) [[G3588]] WTT-GPM **ουτως** *houtōs* tak [[G3779]] [[ADV]] **αναστρεφομενων** *anastrefomenōn* przechodząc przez te – którzy są obracani [[G390]] WTV-PPP-GPM **γενηθεντες** *genēthentes* które stały się [[G1096]] WTV-AOP-NPM
###### **Hbr 10,34**
 **και** *kai* i [[G2532]] [[CONJ]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **τοις** *tois* (z) [[G3588]] WTT-DPM **δεσμοις** *desmois* więzami [[G1199]] WTN-DPM **μου** *mou* moimi [[G3450]] WTP-1GS **συνεπαθησατε** *synepathēsate* współodczuliście [[G4834]] WTV-AAI-2P **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **αρπαγην** *harpagēn* grabież [[G724]] WTN-ASF **των** *tōn* [[G3588]] WTT-GPN **υπαρχοντων** *hyparchontōn* które są dobytkiem – które są mieniem [[G5224]] WTV-PAP-GPN **υμων** *hymōn* waszym [[G5216]] WTP-2GP **μετα** *meta* z [[G3326]] [[PREP]] **χαρας** *charas* radością [[G5479]] [[N-GSF]] **προσεδεξασθε** *prosedeksasthe* przyjęliście [[G4327]] WTV-ADI-2P **γινωσκοντες** *ginōskontes* wiedząc [[G1097]] WTV-PAP-NPM **εχειν** *echein* (że) mieć [[G2192]] WTV-PAN **εν** *en* w [[G1722]] [[PREP]] **εαυτοις** *heautois* siebie samych [[G1438]] WTF-3DPM **κρειττονα** *kreittona* lepszy – znaczniejszy [[G2909]] WTA-ASF **υπαρξιν** *hyparksin* majątek [[G5223]] WTN-ASF **εν** *en* w [[G1722]] [[PREP]] **ουρανοις** *ouranois* niebiosach [[G3772]] WTN-DPM **και** *kai* i [[G2532]] [[CONJ]] **μενουσαν** *menousan* trwający – pozostający [[G3306]] WTV-PAP-ASF
###### **Hbr 10,35**
 **μη** *mē* Nie [[G3361]] [[PRT-N]] **αποβαλητε** *apobalēte* zrzucilibyście – odrzucilibyście [[G577]] WTV-2AAS-2P **ουν** *oun* więc [[G3767]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **παρρησιαν** *parrēsian* śmiałości [[G3954]] WTN-ASF **υμων** *hymōn* waszej [[G5216]] WTP-2GP **ητις** *hētis* która [[G3748]] WTR-NSF **εχει** *echei* ma [[G2192]] WTV-PAI-3S **μισθαποδοσιαν** *misthapodosian* odpłatę – zapłatę [[G3405]] WTN-ASF **μεγαλην** *megalēn* wielką [[G3173]] WTA-ASF
###### **Hbr 10,36**
 **υπομονης** *hypomonēs* wytrwałości [[G5281]] [[N-GSF]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εχετε** *echete* macie [[G2192]] WTV-PAI-2P **χρειαν** *chreian* potrzebę [[G5532]] WTN-ASF **ινα** *hina* aby [[G2443]] [[CONJ]] **το** *to* [[G3588]] WTT-ASN **θελημα** *thelēma* wolę [[G2307]] WTN-ASN **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ποιησαντες** *poiēsantes* uczyniwszy [[G4160]] WTV-AAP-NPM **κομισησθε** *komisēsthe* dostalibyście – odebralibyście [[G2865]] WTV-AMS-2P **την** *tēn* [[G3588]] WTT-ASF **επαγγελιαν** *epangelian* obietnicę [[G1860]] WTN-ASF
###### **Hbr 10,37**
 **ετι** *eti* Jeszcze [[G2089]] [[ADV]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **μικρον** *mikron* chwila – mała [[G3397]] WTA-ASN **οσον** *hoson* jak wiele [[G3745]] WTK-ASN **οσον** *hoson* jak wiele [[G3745]] WTK-ASN **ο** *ho* [[G3588]] [[T-NSM]] **ερχομενος** *erchomenos* przychodzący [[G2064]] WTV-PNP-NSM **ηξει** *hēksei* przyjdzie [[G2240]] WTV-FAI-3S **και** *kai* i [[G2532]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **χρονιει** *chroniei* będzie zwlekał [[G5549]] WTV-FAI-3S
###### **Hbr 10,38**
 **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **δικαιος** *dikaios* sprawiedliwy [[G1342]] [[A-NSM]] **εκ** *ek* z [[G1537]] [[PREP]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **ζησεται** *zēsetai* będzie żyć [[G2198]] WTV-FDI-3S **και** *kai* i [[G2532]] [[CONJ]] **εαν** *ean* jeśli [[G1437]] WTCOND **υποστειληται** *hyposteilētai* cofnąłby się – odłączyłby się [[G5288]] WTV-AMS-3S **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ευδοκει** *eudokei* znajduje upodobania [[G2106]] WTV-PAI-3S **η** *hē* [[G3588]] [[T-NSF]] **ψυχη** *psychē* dusza [[G5590]] [[N-NSF]] **μου** *mou* moja [[G3450]] WTP-1GS **εν** *en* w [[G1722]] [[PREP]] **αυτω** *autō* nim [[G846]] WTP-DSM
###### **Hbr 10,39**
 **ημεις** *hēmeis* My [[G2249]] WTP-1NP **δε** *de* zaś [[G1161]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εσμεν** *esmen* jesteśmy [[G2070]] WTV-PXI-1P **υποστολης** *hypostolēs* (do) wycofania się [[G5289]] [[N-GSF]] **εις** *eis* ku [[G1519]] [[PREP]] **απωλειαν** *apōleian* zgubie – zatraceniu [[G684]] WTN-ASF **αλλα** *alla* ale [[G235]] [[CONJ]] **πιστεως** *pisteōs* wierze [[G4102]] [[N-GSF]] **εις** *eis* ku [[G1519]] [[PREP]] **περιποιησιν** *peripoiēsin* pozyskaniu – nabyciu [[G4047]] WTN-ASF **ψυχης** *psychēs* duszy – życia [[G5590]] [[N-GSF]]
