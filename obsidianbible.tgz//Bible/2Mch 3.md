# 2Mch 3 BT5
###### **2Mch 3,1**
 Gdy w Świętym Mieście panował całkowity spokój, a Prawo najściślej zachowywano dzięki temu, że arcykapłan Oniasz był pobożny i nienawidził zła,
###### **2Mch 3,2**
 bywało, że nawet sami królowie okazywali szacunek temu miejscu, a świątynię czcili najwspanialszymi darami.
###### **2Mch 3,3**
 Nawet sam Seleukos, król Azji, z własnych dochodów pokrywał wszystkie wydatki, których wymagało składanie ofiar.
###### **2Mch 3,4**
 Pewien jednak Szymon z rodu Bilgi, którego ustanowiono przełożonym świątyni, posprzeczał się z arcykapłanem o nadzór nad targowiskiem.
###### **2Mch 3,5**
 Nie mogąc zaś wziąć góry nad Oniaszem, udał się do Apoloniusza, syna Trazeasza, będącego w tym czasie wodzem wojsk Celesyrii i Fenicji,
###### **2Mch 3,6**
 i doniósł o tym, że skarbiec w Jerozolimie jest pełen nieopisanych bogactw, do tego stopnia, iż ilość pieniędzy jest tam nie do obliczenia i nie pozostaje w żadnym stosunku do wydatków, jakich wymaga składanie ofiar, i że jest możliwość, aby to wszystko przeszło pod władzę królewską.
###### **2Mch 3,7**
 Apoloniusz udał się do króla i wtajemniczył go w swoje wiadomości o skarbach. On zaś wybrał wielkorządcę Heliodora i posłał go, dając mu rozkazy, jak ma postępować, aby wspomniane skarby zagarnąć.
###### **2Mch 3,8**
 Heliodor więc natychmiast udał się w podroż, pod pozorem odwiedzenia miast Celesyrii i Fenicji, w rzeczywistości zaś, aby wykonać zamiary króla.
###### **2Mch 3,9**
 Kiedy przybył do Jerozolimy i życzliwie został przyjęty przez arcykapłana i miasto, powiedział o doniesieniu, które zostało złożone, i wyjawił powód, dla którego przybył. Dopytywał się przy tym, czy w rzeczywistości tak właśnie jest.
###### **2Mch 3,10**
 Arcykapłan wyjaśnił mu wtedy, że są to depozyty wdów i sierot,
###### **2Mch 3,11**
 część zaś jest własnością Hirkana, syna Tobiasza, męża zajmującego bardzo wysokie stanowisko. Sprawa zatem nie przedstawia się tak, jak to zmyślił bezbożny Szymon. Wszystkiego zaś jest w srebrze czterysta talentów, w złocie zaś dwieście.
###### **2Mch 3,12**
 Byłoby zaś w ogóle niemożliwą rzeczą uczynić krzywdę tym, którzy zawierzyli świętości miejsca oraz powadze i azylowi świątyni szanowanej na całym świecie.
###### **2Mch 3,13**
 Heliodor jednak powołał się na królewskie rozkazy i wyraźnie powiedział, że musi to być oddane do królewskiego skarbca.
###### **2Mch 3,14**
 Wyznaczonego dnia zamierzał wejść, aby przygotować spis tych skarbów. Niemały zaś w całym mieście był niepokój.
###### **2Mch 3,15**
 Kapłani, padłszy w kapłańskich szatach przed ołtarzem, wołali do nieba, do Tego, który ustanowił prawo o depozycie, aby te skarby nienaruszone zachował dla tych, którzy je złożyli w depozyt.
###### **2Mch 3,16**
 Temu, kto spojrzał na oblicze arcykapłana, krajało się serce. Wygląd bowiem i zmiana jego cery zdradzały duchowe męczarnie.
###### **2Mch 3,17**
 Męża tego bowiem opanowały strach i drżenie ciała, przez co ból będący w sercu był widoczny dla patrzących.
###### **2Mch 3,18**
 Ludzie gromadnie wychodzili z domów, by razem się modlić, gdyż miejsce [święte] miało być zhańbione.
###### **2Mch 3,19**
 Kobiety przepasane worami poniżej piersi zapełniły ulice. Zamknięte dotychczas dziewczęta jedne pobiegły do bram, inne na mury, inne wreszcie wychylały się przez okna.
###### **2Mch 3,20**
 Wszystkie zaś, wyciągając ręce do nieba, zanosiły błaganie.
###### **2Mch 3,21**
 Litość brała na widok tego, jak tłum między sobą pomieszany padał na kolana, a arcykapłan oczekiwał w wielkich męczarniach ducha.
###### **2Mch 3,22**
 Oni więc modlili się do wszechmocnego Pana, aby powierzone pieniądze zachował nienaruszone dla tych, którzy zawierzyli.
###### **2Mch 3,23**
 A Heliodor próbował wykonać postanowienie.
###### **2Mch 3,24**
 Razem ze swoją strażą był on już obok skarbca, kiedy Władający duchami i wszelką potęgą dokonał wielkiego objawienia, do tego stopnia, że wszyscy, którzy odważyli się tam przyjść, uderzeni mocą Bożą padali bezsilni i strwożeni.
###### **2Mch 3,25**
 Ukazał się im bowiem jakiś koń przybrany najozdobniejszym czaprakiem, niosący na sobie strasznego jeźdźca, rzucając się gwałtownie, zawisł nad Heliodorem przednimi kopytami; a jeździec ukazał się w złotej zbroi.
###### **2Mch 3,26**
 Ponadto ukazali się mu dwaj inni młodzieńcy o nadzwyczajnej sile, uderzającej piękności i w przepięknych szatach. Oni to stanęli z obydwóch stron i bez przerwy go biczowali, zadając mu wiele uderzeń.
###### **2Mch 3,27**
 On zaś upadł zaraz na ziemię, a gęste ciemności go otoczyły. Zabrano go więc i włożono do lektyki.
###### **2Mch 3,28**
 Tego, który dopiero co w licznym otoczeniu i z liczną strażą wszedł do skarbca, o którym była mowa poprzednio, niesiono, gdyż sam sobie nie mógł nic poradzić. Wyraźnie przy tym poznano Bożą moc.
###### **2Mch 3,29**
 Gdy więc on skutkiem działania Bożego leżał niemy oraz pozbawiony nadziei i ratunku,
###### **2Mch 3,30**
 tamci błogosławili Pana, który ponad oczekiwanie wsławił swoje miejsce. Świątynia zaś, która krótko przedtem wypełniona była przestrachem i przerażeniem, napełniła się radością i szczęściem dzięki objawieniu się wszechmocnego Pana.
###### **2Mch 3,31**
 Niektórzy z przyjaciół Heliodora zaraz poprosili Oniasza, aby wezwał Najwyższego, by darował życie temu, który już wydawał naprawdę ostatnie tchnienie.
###### **2Mch 3,32**
 W obawie więc, aby król nie podejrzewał przypadkiem Żydów, że jakąś krzywdę uczynili Heliodorowi, arcykapłan złożył ofiarę za zdrowie tego męża.
###### **2Mch 3,33**
 Kiedy zaś arcykapłan składał ofiarę przebłagalną, ci sami młodzieńcy, przybrani w te same szaty, ukazali się ponownie Heliodorowi i stanąwszy, powiedzieli: «***Wiele podziękowań złóż arcykapłanowi Oniaszowi! Dzięki niemu bowiem Pan darował ci życie.***
###### **2Mch 3,34**
 ***Ty zaś, obity [przez posłów] z nieba, opowiadaj wszystkim o wielkiej mocy Bożej!***» Powiedziawszy to, zniknęli.
###### **2Mch 3,35**
 Heliodor złożył ofiarę Panu i uczynił wielkie śluby Temu, który darował mu życie. Potem pożegnał Oniasza i razem ze swoim wojskiem powrócił do króla.
###### **2Mch 3,36**
 Wobec wszystkich składał on świadectwo o dziełach najwyższego Boga, jakie widział na własne oczy.
###### **2Mch 3,37**
 Kiedy zaś król pytał Heliodora, kto byłby odpowiedni, aby jeszcze raz go posłać do Jerozolimy, powiedział:
###### **2Mch 3,38**
 «***Jeżeli masz jakiegoś nieprzyjaciela lub wroga ładu, poślij go tam, a otrzymasz go obitego, jeżeli tylko się wyratuje, bo na tym miejscu naprawdę działa jakaś Boża moc.***
###### **2Mch 3,39**
 ***Ten bowiem, który ma swoje mieszkanie w niebie, czuwa nad tym miejscem i wspomaga je, a bije i unicestwia tych, którzy tam przychodzą w złych zamiarach***».
###### **2Mch 3,40**
 Taki oto przebieg miała sprawa Heliodora i zachowania skarbca.
# 2Mch 3 PAU
###### **2Mch 3,1**
 Najwyższy kapłan Oniasz był człowiekiem bogobojnym i nienawidził zła. Dzięki temu święte miasto cieszyło się całkowitym pokojem, a prawa były należycie przestrzegane.
###### **2Mch 3,2**
 Bywało, że nawet królowie otaczali szacunkiem to miejsce, a świątyni ofiarowywali najwspanialsze dary.
###### **2Mch 3,3**
 I tak król Azji Seleukos pokrywał z własnych dochodów wszystkie koszty związane ze składaniem ofiar.
###### **2Mch 3,4**
 Tymczasem Szymon z plemienia Beniamina, ustanowiony nadzorcą świątyni, pokłócił się z najwyższym kapłanem o nadzór nad miejskim rynkiem.
###### **2Mch 3,5**
 Ponieważ nie mógł pokonać Oniasza, udał się do Apoloniusza z Tarsu, który w tym czasie był wodzem Celesyrii i Fenicji.
###### **2Mch 3,6**
 Doniósł mu o tym, że skarbiec w Jerozolimie wypełniony jest niewysłowionymi bogactwami i że nie sposób policzyć pieniędzy, które w nim się znajdują. Jest ich więcej, niż potrzeba na wydatki związane ze składaniem ofiar, i mogłoby to przejść na własność króla.
###### **2Mch 3,7**
 Gdy Apoloniusz spotkał się z królem, opowiedział o skarbach, o których mu doniesiono. Wtedy król wybrał wielkorządcę Heliodora i dał mu rozkaz, aby udał się tam i przejął wspomniane bogactwa.
###### **2Mch 3,8**
 Heliodor wyruszył natychmiast, sprawiając wrażenie, jakby zamierzał przeprowadzić inspekcję miast Celesyrii i Fenicji, a w rzeczywistości po to, aby wypełnić wolę króla.
###### **2Mch 3,9**
 Gdy przybył do Jerozolimy, został życzliwie przyjęty przez najwyższego kapłana i miasto. Wówczas wyjawił cel swego przybycia, oznajmił to, o czym mu doniesiono, i dopytywał się, czy rzeczywiście jest to zgodne z prawdą.
###### **2Mch 3,10**
 Najwyższy kapłan wyjaśnił mu, że depozyty należą do wdów i sierot,
###### **2Mch 3,11**
 a część do Hirkana, syna Tobiasza, człowieka zajmującego wysokie stanowisko. Doniesienie bezbożnego Szymona jest fałszywe, a skarbiec zawiera tylko czterysta talentów srebra oraz dwieście złota.
###### **2Mch 3,12**
 Byłoby więc wielką niesprawiedliwością wyrządzić szkodę tym, którzy zaufali świętości miejsca oraz godności i nietykalności czczonej na całym świecie świątyni.
###### **2Mch 3,13**
 Heliodor jednak, powołując się na królewskie rozkazy, stwierdził, że musi to być przekazane do skarbca królewskiego.
###### **2Mch 3,14**
 W wyznaczonym przez siebie dniu wszedł do skarbca, aby dokonać jego przeglądu. Tymczasem w całym mieście panowało niemałe wzburzenie.
###### **2Mch 3,15**
 Kapłani ubrani w święte szaty upadli przed ołtarzem i wołali do Nieba, aby Ten, który ustanowił prawa o depozytach, w całości zachował je dla tych, którzy je złożyli.
###### **2Mch 3,16**
 Widok twarzy najwyższego kapłana poruszał do głębi, gdyż wyraz i bladość jego oblicza świadczyły o wewnętrznej udręce.
###### **2Mch 3,17**
 Strach ogarnął tego człowieka, a drżenie ciała objawiało cierpienie jego serca tym, którzy mu się przyglądali.
###### **2Mch 3,18**
 Ludzie wybiegali gromadnie z domów, aby wspólnie się modlić, gdyż świętemu miejscu zagrażała zniewaga.
###### **2Mch 3,19**
 Kobiety w żałobnych ubraniach zapełniały ulice. Dziewczęta trzymane w zamknięciu gromadziły się przy bramach, inne na murach, jeszcze inne wyglądały przez okna.
###### **2Mch 3,20**
 Wszystkie zaś, wyciągając ręce do nieba, odmawiały modlitwy.
###### **2Mch 3,21**
 Ogarniała litość na widok tego różnorodnego tłumu padającego na kolana oraz na widok najwyższego kapłana oczekującego w wielkim niepokoju.
###### **2Mch 3,22**
 Podczas gdy oni błagali wszechmocnego PANA, aby powierzone depozyty zachował nienaruszone,
###### **2Mch 3,23**
 Heliodor wykonywał to, co zostało postanowione.
###### **2Mch 3,24**
 Kiedy już przybył razem ze swoją strażą przyboczną w pobliże skarbca, Władca duchów i wszelkiej mocy okazał się tak wielki, że wszyscy, którzy ośmielili się wejść, uderzeni mocą Bożą przestraszyli się i omdleli.
###### **2Mch 3,25**
 Ukazał się im koń niosący straszliwego jeźdźca, przyozdobiony w piękny rynsztunek. Galopując, gwałtownie natarł przednimi kopytami na Heliodora. Wydawało się, że jeździec ma złotą zbroję.
###### **2Mch 3,26**
 Pojawili się jeszcze dwaj inni młodzieńcy o nadzwyczajnej sile, wspaniałej urodzie, pięknie ubrani, którzy stanęli po obu stronach Heliodora i chłostali go bez przerwy, zadając mu liczne razy.
###### **2Mch 3,27**
 Nagle upadł on na ziemię i ogarnęła go wielka ciemność. Podniesiono go więc i posadzono w lektyce.
###### **2Mch 3,28**
 Ten, który - jak to zostało wspomniane - wszedł do skarbca z licznym orszakiem i całą strażą przyboczną, został z niego wyniesiony, bo sam nie był w stanie udzielić sobie pomocy. Wszyscy uznali moc Bożą, która się ujawniła.
###### **2Mch 3,29**
 Podczas gdy on z powodu Bożej mocy stał się niemową, pozbawionym wszelkiej nadziei i ratunku,
###### **2Mch 3,30**
 oni wysławiali PANA, który swoje miejsce otoczył chwałą. Świątynia zaś, która niedawno była pełna strachu i trwogi, dzięki objawieniu się wszechmocnego PANA napełniła się radością i weselem.
###### **2Mch 3,31**
 Niektórzy z otoczenia Heliodora natychmiast prosili Oniasza, aby błagał Najwyższego o darowanie życia temu, który leżał, wydając ostatnie tchnienie.
###### **2Mch 3,32**
 Najwyższy kapłan, obawiając się, że król mógłby podejrzewać Żydów o dokonanie jakiejś zbrodni przeciwko Heliodorowi, złożył ofiarę za jego ocalenie.
###### **2Mch 3,33**
 Podczas gdy najwyższy kapłan składał ofiarę przebłagalną, Heliodorowi ponownie ukazali się ci sami młodzieńcy, przystrojeni w te same szaty. Powiedzieli mu: „Bądź bardzo wdzięczny najwyższemu kapłanowi Oniaszowi, ponieważ dzięki niemu PAN darował ci życie.
###### **2Mch 3,34**
 Ty zaś, który otrzymałeś chłostę z nieba, głoś wszystkim wielką moc Boga!”. Powiedzieli to i zniknęli.
###### **2Mch 3,35**
 Heliodor złożył PANU ofiarę i uczynił uroczyste ślubowanie Temu, który darował mu życie. Potem pożegnał Oniasza i powrócił z orszakiem do króla.
###### **2Mch 3,36**
 Wszystkim składał świadectwo o dziełach wielkiego Boga, które widział na własne oczy.
###### **2Mch 3,37**
 Kiedy król zapytał Heliodora, kogo jako najbardziej odpowiedniego mógłby ponownie wysłać do Jerozolimy, ten odpowiedział:
###### **2Mch 3,38**
 „Jeśli masz jakiegoś wroga albo spiskowca przeciwko państwu, poślij go tam, a wróci do ciebie wychłostany, jeśli ujdzie żywy, ponieważ wokół tego miejsca jest prawdziwie jakaś moc Boża.
###### **2Mch 3,39**
 Ten bowiem, który ma swoje mieszkanie w niebie, strzeże tego miejsca i je wspomaga. On bije i unicestwia tych, którzy przybywają tam w złych zamiarach”.
###### **2Mch 3,40**
 Tak wygląda sprawa Heliodora oraz ocalenia skarbca.
# 2Mch 3 BP
###### **2Mch 3,1**
 Gdy życie w Świętym Mieście upływało w całkowitym spokoju, a prawa były jak najściślej przestrzegane dzięki pobożności arcykapłana Oniasza i jego pogardy dla zła,
###### **2Mch 3,2**
 zdarzyło się nawet, że sami królowie czcili to miejsce, a Świątyni przysparzali sławy wspaniałymi darami.
###### **2Mch 3,3**
 Nawet Seleukos, król Azji, pokrywał z osobistych dochodów wszelkie wydatki związane ze składaniem ofiar.
###### **2Mch 3,4**
 Pewien Szymon jednak z rodu Beniamina, wyznaczony na zarządzającego Świątyni poróżnił się z arcykapłanem w sprawie kontroli nad targami miejskimi.
###### **2Mch 3,5**
 Nie mogąc wygrać [w tym sporze] z Oniaszem, udał się do Apoloniusza z Tarsu, ówczesnego namiestnika Celesyrii i Fenicji.
###### **2Mch 3,6**
 Powiadomił go, że skarbiec w Jerozolimie pełen jest niezmierzonych bogactw, tak że nie da się wprost policzyć olbrzymiej ilości pieniędzy, która wielokrotnie przewyższa wydatki na ofiary, oraz że istnieje możliwość, aby król wszystkim tym zawładnął.
###### **2Mch 3,7**
 Apoloniusz udał się do króla i wyjawił mu, czego się dowiedział o skarbach. Ten zaś wybrał Heliodora, który zajmował się sprawami publicznymi, i wysłał go z rozkazem, aby wymusił wydanie wspomnianych skarbów.
###### **2Mch 3,8**
 Heliodor natychmiast wyruszył w drogę pod pozorem dokonania objazdu miast Celesyrii i Fenicji, w rzeczywistości zaś by wykonać polecenie króla.
###### **2Mch 3,9**
 Skoro zjawił się w Jerozolimie, został przyjaźnie przyjęty w mieście przez arcykapłana. Oznajmił o otrzymanym doniesieniu i wyjawił [właściwy] cel przybycia. Wypytywał również, czy [wiadomości o skarbach] są prawdziwe.
###### **2Mch 3,10**
 Arcykapłan wyjaśnił mu, że skarbiec zawierał pieniądze powierzone przez wdowy i sieroty,
###### **2Mch 3,11**
 część zaś należy do Hirkana, syna Tobiasza, człowieka piastującego wysoką godność - sprawa ma się więc inaczej, niż to fałszywie przedstawił bezbożny Szymon: cały skarb to tylko czterysta talentów srebra i dwieście talentów złota.
###### **2Mch 3,12**
 Niemożliwą jest rzeczą przeto skrzywdzić tych, którzy zawierzyli świętości miejsca oraz godności i nietykalności Świątyni czczonej w całym świecie.
###### **2Mch 3,13**
 Heliodor jednak - powołując się na rozkaz króla - utrzymywał, że pieniądze te powinny być przekazane do królewskiego skarbca.
###### **2Mch 3,14**
 W wyznaczonym przez siebie dniu wszedł [do skarbca], aby dokonać przeglądu. A w całym mieście panowało wielkie poruszenie.
###### **2Mch 3,15**
 Kapłani odziani w szaty kapłańskie padli przed ołtarzem błagając niebo, aby Ten, który ustanowił Prawo o powierzonym mieniu, zachował nienaruszone dobra tym, którzy je tu złożyli.
###### **2Mch 3,16**
 Na widok oblicza arcykapłana krajało się serce wszystkich patrzących. Wygląd i bladość pokrywająca jego twarz świadczyły o cierpieniach duszy.
###### **2Mch 3,17**
 Przerażenie i drżenie ciała, jakie opanowały tego człowieka, ujawniały patrzącym ból, który owładnął jego sercem.
###### **2Mch 3,18**
 Ludzie gromadnie opuszczali domy, aby się wspólnie modlić, gdyż Świętemu miejscu groziło znieważenie.
###### **2Mch 3,19**
 Kobiety przepasane worami poniżej piersi napełniły ulice. Dziewczęta, które żyły dotąd w zamknięciu, jedne pobiegły do bram, inne na mury, niektóre zaś wychylały się z okien,
###### **2Mch 3,20**
 a wszystkie zanosiły błagania wyciągając ręce ku niebu.
###### **2Mch 3,21**
 Litość budził widok, gdy pomieszany tłum padał na ziemię, a arcykapłan oczekiwał w wielkim przerażeniu.
###### **2Mch 3,22**
 Prosili wszechwładnego Pana, aby powierzone dobra zachował nienaruszone tym, którzy je złożyli.
###### **2Mch 3,23**
 Heliodor zaś wykonywał to, co zostało postanowione.
###### **2Mch 3,24**
 Znajdował się właśnie ze swoją strażą przyboczną blisko skarbca, gdy Władca duchów panujących nad wszelką potęgą objawił się z tak niezwykłą siłą, że wszyscy, którzy ośmielili się tam wejść, przerazili się i porażeni mocą Bożą omdleli.
###### **2Mch 3,25**
 Ukazał się im mianowicie przebrany we wspaniałą uprząż koń niosący na sobie straszliwego jeźdźca. Gwałtownie pędząc natarł na Heliodora przednimi kopytami. Wydawało się, że siedzący na koniu odziany jest w złotą zbroję.
###### **2Mch 3,26**
 Ponadto ujrzał jeszcze dwóch młodzieńców, którzy wyróżniali się siłą, niezwykłą urodą i wspaniałymi szatami. Stanęli po obu stronach [Heliodora] i smagali go bez przerwy, zadając mu liczne uderzenia.
###### **2Mch 3,27**
 Padł nagle na ziemię i ogarnęły go nieprzeniknione ciemności. Podnieśli i złożyli w lektyce
###### **2Mch 3,28**
 tego, który dopiero co wszedł do wspomnianego skarbca z licznym orszakiem i całą strażą przyboczną; niesiono go pozbawionego pomocy zrozumiawszy, że tym sposobem objawiła się im moc Boża.
###### **2Mch 3,29**
 Leżał tak siłą boską pozbawiony mowy, nie mając żadnej nadziei ratunku,
###### **2Mch 3,30**
 [żydzi] zaś chwalili Pana, który okrył sławą swoje Miejsce. Świątynia, która przed chwilą ogarnięta była trwogą i przerażeniem, dzięki objawieniu wszechmocnego Pana wypełniła się weselem i radością,
###### **2Mch 3,31**
 Zaraz też niektórzy ludzie z otoczenia Heliodora poprosili Oniasza o wstawienie się do Najwyższego, aby darował życie konającemu.
###### **2Mch 3,32**
 Arcykapłan w obawie, że król mógłby podejrzewać, jakoby Żydzi targnęli się na życie Heliodora, złożył ofiarę za jego ocalenie.
###### **2Mch 3,33**
 Gdy arcykapłan składał ofiarę przebłagalną, ukazali się znowu Heliodorowi ci sami młodzieńcy, odziani w te same szaty, i stanąwszy rzekli: Stokrotnie podziękuj arcykapłanowi Oniaszowi, przez wzgląd na niego bowiem Bóg darował ci życie.
###### **2Mch 3,34**
 Ty zaś, dotknięty karą z nieba, rozpowiadaj wszystkim o wielkiej mocy Bożej. To rzekłszy zniknęli.
###### **2Mch 3,35**
 Heliodor złożył ofiarę Panu i wielkie śluby uczynił Temu, który darował mu życie. Pożegnawszy się przyjaźnie z Oniaszem powrócił ze swym wojskiem do króla.
###### **2Mch 3,36**
 Wobec wszystkich dawał świadectwo o dziełach najwyższego Boga, jakie oglądał na własne oczy.
###### **2Mch 3,37**
 A gdy król zapytał Heliodora, kto by się nadawał, aby go raz jeszcze wysłać do Jerozolimy, rzekł: -
###### **2Mch 3,38**
 Jeśli masz jakiegoś wroga lub kogoś sprzeciwiającego się twoim rządom, wyślij go tam, a powróci wy chłostany, jeśli w ogóle ujdzie z życiem, gdyż w tym Miejscu rzeczywiście objawia się Boża moc.
###### **2Mch 3,39**
 Ten bowiem, który zamieszkuje niebiosa, jest strażnikiem i obrońcą tego Miejsca. Chłoszcze On i gubi przychodzących tam w złych zamiarach.
###### **2Mch 3,40**
 To właśnie wydarzyło się Heliodorowi i tak został uratowany skarbiec Świątyni.
# 2Mch 3 BR
###### **2Mch 3,1**
 Mieszkańcy Miasta Świętego żyli w spokoju i przestrzegali prawa. Arcykapłan Oniasz był bowiem mężem bardzo pobożnym i brzydził się wszelkim złem.
###### **2Mch 3,2**
 Dlatego też i królowie otaczali to miejsce czcią, a świątynię upiększali najwspanialszymi darami.
###### **2Mch 3,3**
 Nawet Seleukos, król Azji, z własnych przychodów pokrywał wszystkie wydatki związane ze składaniem ofiar.
###### **2Mch 3,4**
 Zdarzyło się jednak, że niejaki Szymon, pochodzący z pokolenia Beniamina, a pełniący urząd przełożonego świątyni, poróżnił się z najwyższym kapłanem. Chodziło o nadzór nad miejskim targowiskiem.
###### **2Mch 3,5**
 Ponieważ sam nie mógł przeciwstawić się skutecznie Oniaszowi, udał się w tej sprawie do Apoloniusza z Tarsu, który był wtedy wodzem wojsk Celesyrii i Fenicji.
###### **2Mch 3,6**
 Opowiedział mu, że skarbiec świątyni jerozolimskiej jest pełen wprost nieprawdopodobnych kosztowności, że pieniędzy jest w nim tyle, iż nie sposób ich zliczyć, że tylko znikoma cząstka jest potrzebna na pokrycie kosztów związanych ze składaniem ofiar i że bez większej trudności król mógłby tym zawładnąć.
###### **2Mch 3,7**
 Kiedy zaś Apoloniusz spotkał się z królem, powtórzył mu wszystko, czego sam się dowiedział o pieniądzach [w świątyni]. Wysłał tedy król swego zarządcę Heliodora z poleceniem, żeby zagarnął dla króla wspomniane skarby.
###### **2Mch 3,8**
 Heliodor udał się natychmiast w drogę pozornie w tym celu, aby odwiedzić różne miasta w Celesyrii i w Fenicji, a w rzeczywistości po to, aby wypełnić polecenie króla.
###### **2Mch 3,9**
 Kiedy przybył do Jerozolimy, został bardzo życzliwie przyjęty przez najwyższego kapłana i miasto. Zaraz też powiedział o doniesieniu, jakie złożono królowi, i wyjawił rzeczywisty powód swojego przybycia, pytając, czy [z pieniędzmi w skarbcu] rzecz się ma naprawdę tak, jak im opowiadano.
###### **2Mch 3,10**
 Arcykapłan mu wyjaśnił, że kosztowności [znajdujące się w skarbcu świątynnym] to depozyty wdów i sierot,
###### **2Mch 3,11**
 a część z nich należy do Hirkana, syna Tobiasza, męża bardzo wpływowego. Wynika więc z tego, że bezbożnik Szymon dopuścił się obrzydliwego kłamstwa. W skarbcu znajduje się, dokładnie licząc, tylko czterysta talentów srebra i dwieście talentów złota.
###### **2Mch 3,12**
 W żadnym razie nie wolno jednak dopuszczać się nieuczciwości wobec tych, którzy takim zaufaniem obdarzają świętość tego miejsca oraz godność i nietykalność tej szanowanej w całym świecie świętości.
###### **2Mch 3,13**
 Lecz Heliodor powoływał się na polecenie, jakie otrzymał od króla, żeby na jego ręce przekazano wszystko do skarbca królewskiego.
###### **2Mch 3,14**
 Wyznaczonego dnia udał się więc do skarbca świątynnego, żeby dokonać przeglądu. Tymczasem coraz większy niepokój ogarniał mieszkańców miasta.
###### **2Mch 3,15**
 Kapłani, ubrani w święte szaty, rzucili się na ziemię przed ołtarzem i błagali o pomoc niebiosa, mówiąc: Ty, który sam ustanowiłeś prawa oddawania dóbr tego świata na przechowanie, spraw, aby zostało teraz nietknięte to, co ludzie zostawili pod Twoją opieką.
###### **2Mch 3,16**
 Serca krajały się tym, którzy patrzyli na oblicze najwyższego kapłana. Jego wygląd, jego pobladła twarz, świadczyły o strasznej udręce.
###### **2Mch 3,17**
 Bojaźń i trwoga przejęły męża. Cały drżał a boleści serca nie mógł ukryć przed oczyma patrzących.
###### **2Mch 3,18**
 Ludzie wychodzili ze swoich domów i tłumnie szli na wspólną modlitwę, bo świątyni groziło wielkie pohańbienie.
###### **2Mch 3,19**
 Kobiety wdziewały na siebie żałobne szaty i z piersiami odsłoniętymi przeciągały ulicami miasta. Z dziewcząt zaś, które zazwyczaj pozostawały w domu, jedne wybiegały do bram, inne wspinały się na mury, jeszcze inne wychylały się z okien.
###### **2Mch 3,20**
 Wszystkie wznosiły ręce do góry i modliły się płacząc.
###### **2Mch 3,21**
 Litość brała na widok tłumu upadającego na ziemię oraz zatroskania i śmiertelnego lęku najwyższego kapłana.
###### **2Mch 3,22**
 I tak wszyscy wołali do Pana wszechmocnego, żeby raczył bezpieczne i nietknięte zachować dobra, które Mu powierzyli ludzie.
###### **2Mch 3,23**
 Tymczasem Heliodor przystępował do urzeczywistnienia swoich zamiarów.
###### **2Mch 3,24**
 Lecz kiedy razem ze swoją przyboczną strażą znalazł się już koło skarbca [świątyni], Pan duchów i wszelkich mocy objawił swoją potęgę. Moc Boża napełniła bojaźnią wszystkich, którzy z taką pewnością siebie towarzyszyli Heliodorowi. Nagle stracili swoje poczucie siły i zaczęli drżeć ze strachu.
###### **2Mch 3,25**
 Zobaczyli bowiem olbrzymiego jeźdźca na koniu. Koń zaś, cały okryty kosztownym czaprakiem, rzucił się gwałtownie na Heliodora, wznosząc nad jego głowę przednie kopyta. Jeździec, który dosiadał konia, był okryty złotą zbroją.
###### **2Mch 3,26**
 Natychmiast też ukazali się dwaj inni młodzi mężowie, wyglądający na bardzo silnych, nadzwyczaj piękni i ubrani w kosztowne szaty. I stanęli po obydwóch stronach Heliodora, i siekli go z obydwu stron biczami, zadając mu nieustannie bolesne razy.
###### **2Mch 3,27**
 W pewnej chwili upadł on nagle na ziemię i zrobiło mu się ciemno w oczach. Podniesiono więc go natychmiast i posadzono w lektyce.
###### **2Mch 3,28**
 Oto, co się stało z tym, który przed chwilą z licznym orszakiem i z liczną strażą przyboczną przybył do skarbca, o którym dopiero co była mowa. Wynoszą go bezsilnego, prawie bez życia na zewnątrz. Wszyscy dostrzegli w tym działanie wszechmocnego Boga.
###### **2Mch 3,29**
 I tak leżał powalony mocą Bożą, nie mogąc wypowiedzieć ani jednego słowa i nie mając żadnej nadziei na ocalenie.
###### **2Mch 3,30**
 Tymczasem Żydzi wielbili Boga, który okazał tak niezwykłą moc na swoim świętym miejscu. Świątynia, wypełniona ludźmi drżącymi jeszcze przed chwilą ze strachu i przerażenia, napełniła się radością i weselem. Oto bowiem objawił się Pan wszechmocny.
###### **2Mch 3,31**
 Po jakimś czasie kilku zaufanych ludzi Heliodora przyszło do Oniasza, prosząc go, żeby zechciał wyjednać u Najwyższego darowanie życia temu, który już ledwie oddychał.
###### **2Mch 3,32**
 Obawiając się, że król mógłby pomyśleć, iż to Żydzi podstępnie uczynili coś złego Heliodorowi, arcykapłan złożył ofiarę za jego powrót do zdrowia.
###### **2Mch 3,33**
 Kiedy arcykapłan był jeszcze zajęty składaniem ofiary przebłagalnej, pojawili się przed Heliodorem znów ci sami co przedtem, tak samo odziani młodzi ludzie i przystępując do niego, powiedzieli mu: Pamiętaj, żebyś nie tylko jeden raz podziękował za to arcykapłanowi Oniaszowi, bo to ze względu na niego Pan darował ci łaskawie twoje życie.
###### **2Mch 3,34**
 Skarciły cię same niebiosa, żebyś wszystkim teraz opowiadał, jak potężna jest moc Boga! To powiedziawszy, zniknęli.
###### **2Mch 3,35**
 Wtedy Heliodor kazał złożyć Panu ofiarę, a sam uczynił uroczysty ślub Temu, który darował mu życie. Potem w przyjaźni pożegnał Oniasza i ruszył ze swym wojskiem z powrotem do króla.
###### **2Mch 3,36**
 Wszystkim ludziom po drodze opowiadał o tym, czego dokonał Najwyższy Bóg, a co widział na własne oczy.
###### **2Mch 3,37**
 Kiedy zaś król zapytał go, kogo można by ponownie posłać do Jerozolimy, Heliodor odpowiedział:
###### **2Mch 3,38**
 Jeśli znasz jakiegoś wroga albo groźnego przestępcę, to jego poślij! Możesz być pewny, że wróci - jeśli w ogóle będzie mu darowane - surowo skarcony. Tam działają naprawdę jakieś Boże moce.
###### **2Mch 3,39**
 Ten, który mieszka na niebiosach, sam bowiem pilnuje i strzeże tego miejsca. Razi On każdego, kto przychodzi tam w złych zamiarach.
###### **2Mch 3,40**
 Oto dzieje Heliodora i ocalenia skarbca świątynnego.
# 2Mch 3 WUJ
