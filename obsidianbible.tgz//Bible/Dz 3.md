# Dz 3 BT5
###### **Dz 3,1**
 Gdy Piotr i Jan wchodzili do świątyni na modlitwę o godzinie dziewiątej,
###### **Dz 3,2**
 wnoszono właśnie pewnego człowieka, chromego od urodzenia. Umieszczano go codziennie przy bramie świątyni, zwanej Piękną, aby wchodzących do świątyni prosił o jałmużnę.
###### **Dz 3,3**
 Ten, zobaczywszy Piotra i Jana, gdy mieli wejść do świątyni, prosił ich o jałmużnę.
###### **Dz 3,4**
 Lecz Piotr, przypatrzywszy się mu wraz z Janem, powiedział:
###### **Dz 3,5**
 «***Spójrz na nas!***» A on patrzył na nich, oczekując od nich jałmużny.
###### **Dz 3,6**
 «***Nie mam srebra ani złota***» – powiedział Piotr – «***ale co mam, to ci daję: w imię Jezusa Chrystusa Nazarejczyka, chodź!***»
###### **Dz 3,7**
 I ująwszy go za prawą rękę, podniósł go. A on natychmiast odzyskał władzę w nogach i stopach.
###### **Dz 3,8**
 Zerwał się i stanął na nogach, i chodził, i wszedł z nimi do świątyni, chodząc, skacząc i wielbiąc Boga.
###### **Dz 3,9**
 A cały lud zobaczył go chodzącego i chwalącego Boga.
###### **Dz 3,10**
 I rozpoznawali w nim tego człowieka, który siedział przy Pięknej Bramie świątyni, aby żebrać, i ogarnęło ich zdumienie i zachwyt z powodu tego, co go spotkało.
###### **Dz 3,11**
 A gdy on trzymał się Piotra i Jana, cały lud zdumiony zbiegł się do nich w krużganku, który zwano Salomonowym.
###### **Dz 3,12**
 Na ten widok Piotr przemówił do ludu: «***Mężowie izraelscy! Dlaczego dziwicie się temu? i dlaczego także patrzycie na nas, jakbyśmy własną mocą lub pobożnością sprawili, że on chodzi?***
###### **Dz 3,13**
 ***Bóg Abrahama, Izaaka i Jakuba, Bóg ojców naszych wsławił Sługę swego, Jezusa, wy jednak wydaliście Go i zaparliście się Go przed Piłatem, gdy postanowił Go uwolnić.***
###### **Dz 3,14**
 ***Zaparliście się Świętego i Sprawiedliwego, a wyprosiliście ułaskawienie dla zabójcy.***
###### **Dz 3,15**
 ***Zabiliście Dawcę życia, ale Bóg wskrzesił Go z martwych, czego my jesteśmy świadkami.***
###### **Dz 3,16**
 ***I przez wiarę w Jego imię temu człowiekowi, którego oglądacie i którego znacie, imię to przywróciło siły. Wiara [wzbudzona] przez niego dała mu tę pełnię sił, którą wszyscy widzicie.***
###### **Dz 3,17**
 ***Lecz teraz wiem, bracia, że działaliście w nieświadomości, tak samo jak zwierzchnicy wasi.***
###### **Dz 3,18**
 ***A Bóg w ten sposób spełnił to, co zapowiedział przez usta wszystkich proroków, że Jego Mesjasz będzie cierpiał.***
###### **Dz 3,19**
 ***Pokutujcie więc i nawróćcie się, aby grzechy wasze zostały zgładzone,***
###### **Dz 3,20**
 ***aby nadeszły od Pana dni ochłody, aby też posłał wam zapowiedzianego Mesjasza, Jezusa,***
###### **Dz 3,21**
 ***którego niebo musi zatrzymać aż do czasu odnowienia wszystkich rzeczy, co od wieków przepowiedział Bóg przez usta swoich świętych proroków.***
###### **Dz 3,22**
 ***Powiedział przecież Mojżesz: Proroka jak ja wzbudzi wam Pan, Bóg nasz, spośród braci waszych. Słuchajcie Go we wszystkim, co wam powie.***
###### **Dz 3,23**
 ***A każdy, kto nie posłucha tego Proroka, zostanie usunięty z ludu.***
###### **Dz 3,24**
 ***Zapowiadali te dni także wszyscy prorocy, którzy przemawiali od czasów Samuela i jego następców.***
###### **Dz 3,25**
 ***Wy jesteście synami proroków i przymierza, które Bóg zawarł z waszymi ojcami, kiedy rzekł do Abrahama: Błogosławione będą w potomstwie twoim wszystkie narody ziemi.***
###### **Dz 3,26**
 ***Dla was najpierw wskrzesił Bóg Sługę swego i posłał Go, aby błogosławił każdemu z was w odwracaniu się od grzechów***».
# Dz 3 PAU
###### **Dz 3,1**
 O godzinie dziewiątej Piotr i Jan wchodzili do świątyni, aby się modlić.
###### **Dz 3,2**
 Wnoszono właśnie mężczyznę, który nie chodził od urodzenia. Kładziono go codziennie przy bramie świątyni, zwanej Piękną, żeby wchodzących do świątyni prosił o jałmużnę.
###### **Dz 3,3**
 Zobaczył on, że Piotr i Jan wchodzą do świątyni i prosił ich o jałmużnę.
###### **Dz 3,4**
 A Piotr i Jan spojrzeli na niego. Piotr powiedział: „Spójrz na nas”.
###### **Dz 3,5**
 On patrzył na nich, oczekując, że coś otrzyma.
###### **Dz 3,6**
 Wtedy Piotr powiedział: „Nie mam srebra ani złota. Daję ci jednak to, co posiadam. W imię Jezusa Chrystusa, Nazarejczyka, wstań i chodź”.
###### **Dz 3,7**
 Wziął go za prawą rękę i podniósł. A on natychmiast odzyskał władzę w nogach i stopach.
###### **Dz 3,8**
 Zerwał się, stanął na nogach i zaczął chodzić. Wszedł razem z nimi do świątyni, skacząc i wielbiąc Boga.
###### **Dz 3,9**
 A wszyscy ludzie widzieli, że chodzi i wielbi Boga.
###### **Dz 3,10**
 Poznali, że jest to ten, który siedział przy świątynnej Bramie Pięknej i prosił o jałmużnę. Dlatego zdumieli się i zachwycali tym, co się wydarzyło.
###### **Dz 3,11**
 On zaś nie opuszczał Piotra i Jana. A wszyscy ludzie, pełni zdumienia, zbiegli się do nich na krużganek zwany Salomonowym.
###### **Dz 3,12**
 Gdy Piotr to zobaczył, powiedział do ludzi: „Izraelici! Dlaczego się temu dziwicie? I dlaczego patrzycie na nas, jakbyśmy własnymi siłami albo dzięki własnej pobożności sprawili, że on chodzi?
###### **Dz 3,13**
 To Bóg naszych przodków, Bóg Abrahama, Izaaka i Jakuba wywyższył swego Sługę, Jezusa. Wy natomiast wydaliście Go i wyparliście się przed Piłatem, gdy usiłował Go uwolnić.
###### **Dz 3,14**
 Odrzuciliście świętego i sprawiedliwego, a wyprosiliście uwolnienie dla zabójcy.
###### **Dz 3,15**
 Zabiliście Dawcę życia, ale Bóg Go wskrzesił. My właśnie o tym świadczymy.
###### **Dz 3,16**
 Dzięki mocy Jego imienia i przez wiarę w to imię człowiek, na którego patrzycie i którego znacie, odzyskał siły. Wiara, która od Niego pochodzi, uzdrowiła go, co też widzicie.
###### **Dz 3,17**
 Bracia! Wiem teraz, że tak jak wasi zwierzchnicy, zrobiliście to z niewiedzy.
###### **Dz 3,18**
 Właśnie w ten sposób wypełniło się to, co wcześniej Bóg przez wszystkich proroków zapowiedział o cierpieniu Chrystusa.
###### **Dz 3,19**
 Nawróćcie się więc i powróćcie do Niego, aby zgładził wasze grzechy.
###### **Dz 3,20**
 A może Bóg sprawi, że przyjdzie czas pocieszenia i pośle wam obiecanego Chrystusa, którym jest Jezus.
###### **Dz 3,21**
 Teraz jest On w niebie aż do czasu, gdy wszystko zostanie odnowione, jak od dawna zapowiadał to Bóg przez świętych proroków.
###### **Dz 3,22**
 Mojżesz przecież powiedział: Pan, Bóg wasz, wzbudzi wam Proroka spośród was. Będzie On podobny do mnie. Jego we wszystkim słuchajcie.
###### **Dz 3,23**
 Ktokolwiek nie posłucha tego Proroka, zostanie wykluczony z ludu.
###### **Dz 3,24**
 Zapowiadali zaś te dni wszyscy prorocy, począwszy od Samuela.
###### **Dz 3,25**
 Wy jesteście następcami proroków i dziedzicami obietnicy, którą Bóg dał waszym ojcom. Powiedział bowiem do Abrahama: «Potomstwo twoje przyniesie błogosławieństwo wszystkim narodom ziemi».
###### **Dz 3,26**
 Dla was Bóg najpierw wskrzesił swego Sługę. Wysłał Go, aby każdy z was dzięki Jego błogosławieństwu odwrócił się od grzechów”.
# Dz 3 BP
###### **Dz 3,1**
 Piotr i Jan wchodzili do świątyni na modlitwę o godzinie dziewiątej.
###### **Dz 3,2**
 Codziennie przed bramę świątyni zwaną Piękną przynoszono mężczyznę bezwładnego od urodzenia, aby prosił wchodzących o jałmużnę.
###### **Dz 3,3**
 Gdy zobaczył Piotra i Jana, którzy zamierzali wejść do świątyni, poprosił ich o jałmużnę.
###### **Dz 3,4**
 Wtedy Piotr i Jan utkwili w niego wzrok i powiedzieli: "Spojrzyj na nas".
###### **Dz 3,5**
 Z zainteresowaniem skierował na nich oczy, spodziewając się, że coś otrzyma.
###### **Dz 3,6**
 Wtedy Piotr powiedział: "Nie mam złota ani srebra, ale daję ci to, co mam: w imię Jezusa Chrystusa z Nazaretu zacznij chodzić".
###### **Dz 3,7**
 Wziął go za rękę i podniósł, natychmiast nogi jego nabrały takiej siły,
###### **Dz 3,8**
 że zeskoczył, stanął, chodził, podskakiwał, wszedł razem z nimi do świątyni i wielbił Boga.
###### **Dz 3,9**
 Wszyscy ludzie wiedzieli, że chodzi i chwali Boga.
###### **Dz 3,10**
 Poznali, że to jest ten sam, który siadał przy bramie Pięknej świątyni i prosił o jałmużnę. Byli pełni najwyższego podziwu dla tego, co się zdarzyło.
###### **Dz 3,11**
 Gdy on się trzymał Piotra i Jana, wszyscy ludzie pełni podziwu zbiegli się do nich w portyku Salomona.
###### **Dz 3,12**
 Widząc to Piotr odezwał się do nich: "Izraelici, dlaczego się tak wpatrujecie w nas i dziwicie, jakbyśmy własną mocą albo pobożnością sprawili, że on chodzi?
###### **Dz 3,13**
 To Bóg Abrahama i (Bóg) Izaaka, i (Bóg) Jakuba, i Bóg Ojców naszych uwielbił Sługę swego Jezusa, którego wy wydaliście i zaparliście się wobec Piłata, gdy postanowił Go uwolnić.
###### **Dz 3,14**
 Zaparliście się więc świętego i sprawiedliwego, a zażądaliście wolności dla zabójcy.
###### **Dz 3,15**
 Zabiliście Stwórcę życia, którego Bóg wskrzesił, czego my jesteśmy świadkami.
###### **Dz 3,16**
 To właśnie wiara w imię Jego sprawiła, że ten, którego widzicie i znacie, stanął na nogi dzięki Niemu, a wiara w to imię na waszych oczach dała mu pełnię sił.
###### **Dz 3,17**
 Ale teraz wiem, bracia, że działaliście w nieświadomości, zarówno wy, jak i wasi przełożeni.
###### **Dz 3,18**
 Bóg bowiem wypełnił w ten sposób to, co zapowiedział przez wszystkich proroków, że Mesjasz będzie cierpiał.
###### **Dz 3,19**
 Starajcie się o wewnętrzną przemianę, nawróćcie się, a zostaną zgładzone wasze grzechy;
###### **Dz 3,20**
 nastanie czas, kiedy Pan was pocieszy, zsyłając zapowiedzianego wam Mesjasza Jezusa.
###### **Dz 3,21**
 Niebo zatrzyma Go aż do czasu powszechnego odnowienia, o którym od dawna mówił Bóg przez świętych proroków.
###### **Dz 3,22**
 Powiedział bowiem Mojżesz: "Pan Bóg da wam proroka, którego powoła jak mnie z waszych braci, słuchajcie, co wam powie.
###### **Dz 3,23**
 Każdy, kto nie będzie posłuszny temu prorokowi, wyłączony zostanie z tego ludu".
###### **Dz 3,24**
 Dni te zapowiadali i mówili o nich kolejno wszyscy prorocy, począwszy od Samuela.
###### **Dz 3,25**
 A wy przecież jesteście synami proroków i Przymierza, które Bóg zawarł z waszymi ojcami, kiedy mówił do Abrahama: "Przez twoje potomstwo wszyscy ludzie na ziemi zyskają błogosławieństwo".
###### **Dz 3,26**
 Jednak najpierw dla was wskrzesił Bóg swego Sługę posyłając Go wam, by dzięki Jego błogosławieństwu każdy z was odwrócił się do zła".
# Dz 3 BR
###### **Dz 3,1**
 Gdy Piotr i Jan wchodzili pewnego dnia około godziny dziewiątej na modlitwę do świątyni,
###### **Dz 3,2**
 wnoszono tam właśnie człowieka, który nie mógł chodzić od urodzenia. Kładziono go co dzień przy bramie świątynnej, zwanej Piękną, aby przychodzących do świątyni prosił o jałmużnę.
###### **Dz 3,3**
 Gdy człowiek ten zobaczył Piotra i Jana u wejścia do świątyni, zwrócił się do nich z prośbą o wsparcie.
###### **Dz 3,4**
 A Piotr [idąc] z Janem przypatrzył mu się dokładnie i powiedział:
###### **Dz 3,5**
 Spójrz na nas. Zaczął się im tedy przypatrywać, sądząc, że coś otrzyma.
###### **Dz 3,6**
 Lecz Piotr powiedział: Nie mam wprawdzie ani srebra, ani złota, ale co mam, to ci daję: W imię Jezusa z Nazaretu wstań i chodź!
###### **Dz 3,7**
 Potem ujął go za prawą rękę i podniósł go. A on natychmiast odzyskał władzę w nogach i w stopach.
###### **Dz 3,8**
 Zerwał się więc, stanął na nogach i zaczął chodzić. Potem wszedł do świątyni, chodził tu i tam, skakał [z radości] i wielbił Boga.
###### **Dz 3,9**
 Widział go też cały lud, gdy chodził i wysławiał Boga.
###### **Dz 3,10**
 Rozpoznawano w nim człowieka, który zwykle siedział przy Pięknej bramie świątyni, prosząc o jałmużnę. I ogarnęło ich przerażenie i podziw zarazem z powodu tego, co spotkało owego człowieka.
###### **Dz 3,11**
 A gdy on trzymał się jeszcze ciągle Piotra i Jana, cały lud, nie przestając się dziwić, stanął obok nich w krużganku Salomona.
###### **Dz 3,12**
 Korzystając ze sposobności, Piotr przemówił do zebranych w te słowa: Dlaczego dziwicie się, o Izraelici, i dlaczego patrzycie na nas tak, jakbyśmy to my właśnie - naszą własną mocą lub pobożnością sprawili, że człowiek ten zaczął chodzić?
###### **Dz 3,13**
 To Bóg Abrahama, Izaaka i Jakuba, Bóg ojców naszych [w ten sposób] okazał chwałę słudze swemu Jezusowi. Tymczasem wyście Go wydali i wyparliście się Go nawet wtedy, kiedy Piłat postanowił Go uniewinnić.
###### **Dz 3,14**
 Wyparliście się Świętego i Sprawiedliwego, a domagaliście się uwolnienia mordercy.
###### **Dz 3,15**
 W ten sposób zgładziliście Dawcę Życia. Lecz Bóg wskrzesił Go z martwych, czemu my dajemy świadectwo.
###### **Dz 3,16**
 To przez wiarę w Jego imię człowiekowi, którego tu widzicie i którego przecież znacie, imię owo przywróciło siły. To wiara w Jezusa sprawiła, że odzyskał siły, czego wszyscy jesteście przecież świadkami.
###### **Dz 3,17**
 Wiem jednak już teraz, bracia, że działaliście w zaślepieniu, podobnie jak wasi przełożeni.
###### **Dz 3,18**
 Bóg zaś urzeczywistnił to, co zapowiedział kiedyś przez wszystkich proroków, że mianowicie Jego Mesjasz będzie musiał cierpieć.
###### **Dz 3,19**
 Pokutujcie więc i nawróćcie się, abyście mogli dostąpić odpuszczenia waszych grzechów,
###### **Dz 3,20**
 aby i dla was przyszły od Pana dni ochłody, aby i do was mógł być posłany zapowiedziany już Mesjasz, Jezus,
###### **Dz 3,21**
 który musi jednak pozostać jeszcze w niebie aż do czasu odnowienia wszystkich rzeczy, co zresztą zapowiedział już Bóg przez swoich świętych proroków.
###### **Dz 3,22**
 Mojżesz powiedział przecież: Pan, Bóg wasz, wzbudzi wam spośród braci waszych proroka podobnego do mnie. Słuchajcie go, cokolwiek wam powie.
###### **Dz 3,23**
 Kto zaś nie będzie słuchał tego proroka, zostanie wykluczony ze wspólnoty Bożego ludu.
###### **Dz 3,24**
 Zresztą pozostali prorocy, prorokujący od czasów Samuela i jego następców, wszyscy zapowiadali również nadejście tych dni.
###### **Dz 3,25**
 Otóż wy jesteście synami proroków i przymierza, które Bóg zawarł z waszymi ojcami, kiedy powiedział do Abrahama: W twoim potomstwie błogosławieństwo spłynie na wszystkie narody ziemi.
###### **Dz 3,26**
 To właśnie dla was przede wszystkim wskrzesił Bóg swego Sługę i posłał Go po to, aby wspomagał każdego w schodzeniu z drogi
# Dz 3 WUJ
###### **Dz 3,1**
 A Piotr i Jan wstępowali do kościoła, na godzinę modlitwy dziewiątą.
###### **Dz 3,2**
 A niektóry mąż, który był chromy z żywota matki swej był noszon: którego na każdy dzień kładziono u drzwi kościelnych, które zowią ozdobne, aby prosił jałmużny u tych którzy do kościoła wchodzili.
###### **Dz 3,3**
 Ten, ujrzawszy Piotra i Jana, poczynające wchodzić do kościoła, prosił, aby wziął jałmużnę.
###### **Dz 3,4**
 A patrząc pilnie nań Piotr z Janem, rzekł mu: Wejrzy na nas.
###### **Dz 3,5**
 A on patrzył na nie, spodziewając się co wziąć od nich.
###### **Dz 3,6**
 I rzekł Piotr: Srebra i złota nie mam: lecz co mam, to tobie dawam: W imię Jezusa Chrystusa Nazareńskiego wstań, a chodź.
###### **Dz 3,7**
 A ująwszy prawą rękę jego, podniósł go i wnet były utwierdzone goleni jego i stopy.
###### **Dz 3,8**
 A wyskoczywszy stanął, i chodził: i wszedł z niemi do kościoła, chodząc i wyskakując, i chwaląc Boga.
###### **Dz 3,9**
 I widział go wszystek lud chodzącego, i Boga chwalącego.
###### **Dz 3,10**
 A znali go, iż on, był który dla jałmużny siadał u drzwi ozdobnych kościelnych: i napełnieni byli zdumienia i zapamiętania, z tego co się mu przydało.
###### **Dz 3,11**
 A gdy się trzymał Piotra i Jana, przybiegł wszystek lud do nich do krudżganku, który zową Salomonowym, zdumiawszy się.
###### **Dz 3,12**
 A ujrzawszy Piotr, odpowiedział do ludu: Mężowie Izraelscy, co się temu dziwujecie? abo przecz się nam przypatrujecie, jakobychmy naszą mocą abo władzą uczynili, że ten chodzi?
###### **Dz 3,13**
 Bóg Abrahamów, i Bóg Izaaków, i Bóg Jakóbów, i Bóg ojców naszych, uwielbił Jezusa Syna swego, któregoście wy wydali, i zaprzeliście się przed Piłatem, gdyż jego zdanie było, aby był wypuszczon.
###### **Dz 3,14**
 A wyście się zaprzeli świętego i sprawiedliwego, i prosiliście, aby wam darował męża mężobójcę:
###### **Dz 3,15**
 A zabiliście sprawcę żywota: którego Bóg wzbudził od umarłych, czego my świadkami jesteśmy.
###### **Dz 3,16**
 A w wierze imienia jego, tego którego wy widziecie i znacie umocniło imię jego: i wiara, która przezeń jest, dała to zupełnie zdrowie przed oczyma was wszystkich.
###### **Dz 3,17**
 A teraz bracia wiem, żeście z niewiadomości uczynili, jako i przełożeni waszy.
###### **Dz 3,18**
 A Bóg co przez usta wszech proroków pierwej opowiedział, iż Chrystus jego cierpieć miał, tak ziścił.
###### **Dz 3,19**
 A przetoż pokutujcie, i nawróćcie się, aby były zgładzone grzechy wasze.
###### **Dz 3,20**
 Aby gdy przydą czasy ochłody od obliczności Pańskiej, a posłałby tego, który jest opowiadany wam Jezusa Chrystusa:
###### **Dz 3,21**
 Którego potrzeba, aby niebo przyjęło aż do czasów naprawienia wszech rzeczy: które opowiedział Bóg przez usta swych świętych od wieku proroków.
###### **Dz 3,22**
 Mojżeszci mówił: Iż proroka wzbudzi wam Pan Bóg wasz z braciej waszej jako mnie: onego słuchać będziecie wedle wszystkiego cokolwiek wam mówić będzie.
###### **Dz 3,23**
 I stanie się, wszelka dusza, któraby nie słuchała proroka onego, będzie wykorzeniona z ludu.
###### **Dz 3,24**
 I wszyscy prorocy od Samuela, i po nich, którzy mówili, opowiedzieli te dni.
###### **Dz 3,25**
 Wyście są syny prorockiemi, i testamentu, który postanowił Bóg z ojcy naszemi, mówiąc do Abrahama: I w nasieniu twojem błogosławione będą wszystkie narody ziemie,
###### **Dz 3,26**
 Wam naprzód Bóg, wzbudziwszy Syna swego, posłał go błogosławiącego wam: aby się nawrócił każdy od złości swej.
# Dz 3 STERN
###### **Dz 3,1**
 Jednego razu o trzeciej po południu, o godzinie modlitw mincha, gdy Kefa i Jochanan szli w górę do Świątyni,
###### **Dz 3,2**
 wnoszono kalekę od urodzenia. Codziennie sadzano go przy Pięknej Bramie Świątyni, aby mógł żebrać od wchodzących na dziedziniec świątynny.
###### **Dz 3,3**
 Kiedy ujrzał wchodzących Kefę i Jochanana, poprosił ich o datek.
###### **Dz 3,4**
 Ale oni wpatrzyli się w niego, a Kefa rzekł: "Spójrz na nas!".
###### **Dz 3,5**
 Kaleka utkwił w nim wzrok, spodziewając się, że coś od nich dostanie.
###### **Dz 3,6**
 Kefa rzekł: "Nie mam srebra i nie mam złota, ale to, co mam, to ci daję: w imię Mesjasza, Jeszui z Naceret, chodź!".
###### **Dz 3,7**
 I chwyciwszy go za prawą rękę, Kefa pociągnął go. Od razu umocniły się jego stopy i kostki,
###### **Dz 3,8**
 tak że zerwał się, stał przez chwilę i zaczął chodzić. I wszedł z nimi na dziedziniec świątynny, chodząc i podskakując, i chwaląc Boga!
###### **Dz 3,9**
 Wszyscy widzieli, jak chodzi i chwali Boga.
###### **Dz 3,10**
 Poznali, że to ten sam człowiek, który dotąd siedział i żebrał pod Piękną Bramą Świątyni, i nie mogli wyjść ze zdziwienia i osłupienia z powodu tego, co go spotkało.
###### **Dz 3,11**
 Gdy on trzymał się Kefy i Jochanana, cały lud zbiegł się w zdumieniu do nich, do Kolumnady Szlomo.
###### **Dz 3,12**
 Widząc to, Kefa zwrócił się do ludu: "Mężowie Israela! Dlaczego tak się temu dziwicie? I czemu tak się w nas wpatrujecie, jakbyśmy jakąś naszą własną mocą czy pobożnością sprawili, że człowiek ten chodzi?
###### **Dz 3,13**
 Bóg Awrahama, Jic'chaka i Ja'akowa, Bóg ojców naszych, uwielbił sługę swego Jeszuę - tego właśnie Jeszuę, któregoście wy wydali i wyrzekli się przed Piłatem, i to kiedy ten już postanowił Go uwolnić.
###### **Dz 3,14**
 Zaparliście się świętego i niewinnego, a prosiliście o wypuszczenie mordercy!
###### **Dz 3,15**
 Zabiliście twórcę życia! Ale Bóg wskrzesił Go z martwych! Tego jesteśmy świadkami.
###### **Dz 3,16**
 A poprzez złożenie ufności w Jego imieniu imię Jego dało siłę temu człowiekowi, którego widzicie i znacie. Tak jest, to ufność, która przychodzi przez Jeszuę, dała mu to całkowite uzdrowienie na oczach was wszystkich.
###### **Dz 3,17**
 Lecz, bracia, wiem, żeście nie pojmowali wagi swoich czynów, nie pojęli jej też wasi przywódcy.
###### **Dz 3,18**
 Ale tak oto wypełnił Bóg to, co zawczasu zapowiedział, gdy przemawiał przez wszystkich proroków, mianowicie że Mesjasz miał umrzeć.
###### **Dz 3,19**
 Dlatego nawróćcie się i zwróćcie się do Boga, aby wymazane były wasze grzechy;
###### **Dz 3,20**
 aby nadeszły sprzed oblicza Pana czasy odświeżenia i aby posłał On ustanowionego dla was zawczasu Mesjasza, czyli Jeszuę.
###### **Dz 3,21**
 Musi On pozostać w niebie, aż nadejdzie czas na odnowę wszystkiego, jak to dawno temu powiedział Bóg, przemawiając przez świętych proroków.
###### **Dz 3,22**
 Bo sam Mosze powiedział: "Adonai wzbudzi wam proroka jak ja spośród braci waszych. Macie go słuchać we wszystkim, co wam powie.
###### **Dz 3,23**
 Każdy, kto proroka tego nie posłucha, usunięty będzie z ludu i zgładzony".
###### **Dz 3,24**
 Bo rzeczywiście wszyscy prorocy zapowiadali te dni, poczynając od Sz'mu'ela, przez wszystkich po nim.
###### **Dz 3,25**
 Wy jesteście synami proroków i jesteście objęci przymierzem, które Bóg zawarł z waszymi ojcami, gdy rzekł do Awrahama: "Poprzez twoje potomstwo będą błogosławione wszystkie rody ziemi".
###### **Dz 3,26**
 Do was zatem najpierw posłał Bóg swego sługę, którego wskrzesił, aby was pobłogosławił, zawracając każdego z was z jego złych dróg".
# Dz 3 TRO
###### **Dz 3,1**
 **δε** *de* Zaś [[G1161]] [[CONJ]] **πετρος** *petros* Piotr – [kamyk] [[G4074]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ιωαννης** *iōannēs* Jan – [JHWH jest łaskawy] [[G2491]] [[N-NSM]] **ανεβαινον** *anebainon* wchodzili – wstępowali [[G305]] WTV-IAI-3P **εις** *eis* do [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **ιερον** *hieron* świątyni [[G2411]] WTN-ASN **επι** *epi* na [[G1909]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **ωραν** *hōran* godzinę [[G5610]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **προσευχης** *proseuchēs* modlitwy [[G4335]] [[N-GSF]] **την** *tēn* [[G3588]] WTT-ASF **εννατην** *ennatēn* dziewiątą [[G1766]] WTA-ASF
###### **Dz 3,2**
 **και** *kai* I [[G2532]] [[CONJ]] **τις** *tis* pewien – jakiś [[G5100]] WTX-NSM **ανηρ** *anēr* mąż [[G435]] [[N-NSM]] **χωλος** *chōlos* kulawy – chromy [[G5560]] [[A-NSM]] **εκ** *ek* od [[G1537]] [[PREP]] **κοιλιας** *koilias* łona – wnętrza [[G2836]] [[N-GSF]] **μητρος** *mētros* matki [[G3384]] [[N-GSF]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **υπαρχων** *hyparchōn* będąc [[G5225]] [[V-PAP-NSM]] **εβασταζετο** *ebastazeto* był niesiony [[G941]] WTV-IPI-3S **ον** *hon* którego [[G3739]] WTR-ASM **ετιθουν** *etithoun* kładziono [[G5087]] WTV-IAI-3P **καθ** *kath* co- [[G2596]] [[PREP]] **ημεραν** *hēmeran* dziennie [[G2250]] WTN-ASF **προς** *pros* przy [[G4314]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **θυραν** *thyran* drzwiach [[G2374]] WTN-ASF **του** *tou* [[G3588]] WTT-GSN **ιερου** *hierou* świątyni [[G2411]] [[N-GSN]] **την** *tēn* [[G3588]] WTT-ASF **λεγομενην** *legomenēn* które jest nazywane (które są nazywane) [[G3004]] WTV-PPP-ASF **ωραιαν** *hōraian* Piękną [[G5611]] WTA-ASF **του** *tou* (by) [[G3588]] WTT-GSM **αιτειν** *aitein* prosić [[G154]] WTV-PAN **ελεημοσυνην** *eleēmosynēn* (o) jałmużnę [[G1654]] WTN-ASF **παρα** *para* od [[G3844]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **εισπορευομενων** *eisporeuomenōn* wchodzących [[G1531]] WTV-PNP-GPM **εις** *eis* do [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **ιερον** *hieron* świątyni [[G2411]] WTN-ASN
###### **Dz 3,3**
 **ος** *hos* Ten [[G3739]] WTR-NSM **ιδων** *idōn* zobaczywszy [[G1492]] WTV-2AAP-NSM **πετρον** *petron* Piotra – [kamyk] [[G4074]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **ιωαννην** *iōannēn* Jana – [JHWH jest łaskawy] [[G2491]] [[N-ASM]] **μελλοντας** *mellontas* zamierzających [[G3195]] WTV-PAP-APM **εισιεναι** *eisienai* wejść [[G1524]] WTV-PXN **εις** *eis* do [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **ιερον** *hieron* świątyni [[G2411]] WTN-ASN **ηρωτα** *ērōta* prosił [[G2065]] WTV-IAI-3S **ελεημοσυνην** *eleēmosynēn* (o) jałmużnę [[G1654]] WTN-ASF
###### **Dz 3,4**
 **ατενισας** *atenisas* Spojrzawszy wprost – Skierowawszy wprost wzrok [[G816]] WTV-AAP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **πετρος** *petros* Piotr – [kamyk] [[G4074]] [[N-NSM]] **εις** *eis* na [[G1519]] [[PREP]] **αυτον** *auton* niego [[G846]] WTP-ASM **συν** *syn* razem z [[G4862]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **ιωαννη** *iōannē* Janem – [JHWH jest łaskawy] [[G2491]] WTN-DSM **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **βλεψον** *blepson* popatrz [[G991]] WTV-AAM-2S **εις** *eis* na [[G1519]] [[PREP]] **ημας** *hēmas* nas [[G2248]] WTP-1AP
###### **Dz 3,5**
 **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **επειχεν** *epeichen* trzymał się – zachował [[G1907]] WTV-IAI-3S **αυτοις** *autois* ich [[G846]] WTP-DPM **προσδοκων** *prosdokōn* oczekując [[G4328]] [[V-PAP-NSM]] **τι** *ti* coś [[G5100]] WTX-ASN **παρ** *par* od [[G3844]] [[PREP]] **αυτων** *autōn* nich [[G846]] WTP-GPM **λαβειν** *labein* wziąć [[G2983]] [[V-2AAN]]
###### **Dz 3,6**
 **ειπεν** *eipen* Powiedział [[G2036]] WTV-2AAI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **πετρος** *petros* Piotr – [kamyk] [[G4074]] [[N-NSM]] **αργυριον** *argyrion* srebro [[G694]] WTN-ASN **και** *kai* i [[G2532]] [[CONJ]] **χρυσιον** *chrysion* złoto [[G5553]] WTN-ASN **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **υπαρχει** *hyparchei* jest [[G5225]] WTV-PAI-3S **μοι** *moi* mi [[G3427]] WTP-1DS **ο** *ho* co [[G3739]] WTR-ASN **δε** *de* zaś [[G1161]] [[CONJ]] **εχω** *echō* mam [[G2192]] WTV-PAI-1S **τουτο** *touto* to [[G5124]] WTD-ASN **σοι** *soi* ci [[G4671]] WTP-2DS **διδωμι** *didōmi* daję [[G1325]] WTV-PAI-1S **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **ονοματι** *onomati* imieniu [[G3686]] WTN-DSN **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **του** *tou* [[G3588]] WTT-GSM **ναζωραιου** *nazōraiou* Nazarejczyka [[G3480]] [[N-GSM]] **εγειραι** *egeirai* wstań – podnieś się [[G1453]] WTV-AMM-2S **και** *kai* i [[G2532]] [[CONJ]] **περιπατει** *peripatei* chodź [[G4043]] WTV-PAM-2S
###### **Dz 3,7**
 **και** *kai* I [[G2532]] [[CONJ]] **πιασας** *piasas* chwyciwszy – dosięgnąwszy [[G4084]] WTV-AAP-NSM **αυτον** *auton* go [[G846]] WTP-ASM **της** *tēs* [[G3588]] [[T-GSF]] **δεξιας** *deksias* prawą [[G1188]] WTA-GSF **χειρος** *cheiros* ręką [[G5495]] [[N-GSF]] **ηγειρεν** *ēgeiren* wzbudził – podniósł [[G1453]] [[V-AAI-3S]] **παραχρημα** *parachrēma* od razu – natychmiast [[G3916]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **εστερεωθησαν** *estereōthēsan* zostały wzmocnione – zostały utwierdzone [[G4732]] WTV-API-3P **αυτου** *autou* jego [[G846]] [[P-GSM]] **αι** *hai* [[G3588]] [[T-NPF]] **βασεις** *baseis* stopy – kroki [[G939]] [[N-NPF]] **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-NPN **σφυρα** *sfyra* kostki [[G4974]] WTN-NPN
###### **Dz 3,8**
 **και** *kai* I [[G2532]] [[CONJ]] **εξαλλομενος** *eksallomenos* podskakując [[G1814]] WTV-PNP-NSM **εστη** *hestē* stanął [[G2476]] WTV-2AAI-3S **και** *kai* i [[G2532]] [[CONJ]] **περιεπατει** *periepatei* chodził [[G4043]] WTV-IAI-3S **και** *kai* i [[G2532]] [[CONJ]] **εισηλθεν** *eisēlthen* wszedł [[G1525]] WTV-2AAI-3S **συν** *syn* z [[G4862]] [[PREP]] **αυτοις** *autois* nimi [[G846]] WTP-DPM **εις** *eis* do [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **ιερον** *hieron* świątyni [[G2411]] WTN-ASN **περιπατων** *peripatōn* chodząc [[G4043]] [[V-PAP-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **αλλομενος** *hallomenos* skacząc [[G242]] WTV-PNP-NSM **και** *kai* i [[G2532]] [[CONJ]] **αινων** *ainōn* chwaląc – wielbiąc [[G134]] [[V-PAP-NSM]] **τον** *ton* [[G3588]] [[T-ASM]] **θεον** *theon* Boga [[G2316]] [[N-ASM]]
###### **Dz 3,9**
 **και** *kai* I [[G2532]] [[CONJ]] **ειδεν** *eiden* zobaczył [[G1492]] WTV-2AAI-3S **αυτον** *auton* go [[G846]] WTP-ASM **πας** *pas* cały [[G3956]] [[A-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **λαος** *laos* lud [[G2992]] [[N-NSM]] **περιπατουντα** *peripatounta* chodzącego [[G4043]] WTV-PAP-ASM **και** *kai* i [[G2532]] [[CONJ]] **αινουντα** *ainounta* chwalącego – wielbiącego [[G134]] WTV-PAP-ASM **τον** *ton* [[G3588]] [[T-ASM]] **θεον** *theon* Boga [[G2316]] [[N-ASM]]
###### **Dz 3,10**
 **επεγινωσκον** *epeginōskon* Poznawali – Uznawali [[G1921]] WTV-IAI-3P **τε** *te* zarówno – także [[G5037]] WTPRT **αυτον** *auton* go [[G846]] WTP-ASM **οτι** *hoti* że [[G3754]] [[CONJ]] **ουτος** *houtos* ten [[G3778]] WTD-NSM **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **προς** *pros* do [[G4314]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **ελεημοσυνην** *eleēmosynēn* jałmużny [[G1654]] WTN-ASF **καθημενος** *kathēmenos* siedzący [[G2521]] WTV-PNP-NSM **επι** *epi* przy [[G1909]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **ωραια** *hōraia* Pięknej [[G5611]] WTA-DSF **πυλη** *pylē* bramie [[G4439]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSN **ιερου** *hierou* świątyni [[G2411]] [[N-GSN]] **και** *kai* i [[G2532]] [[CONJ]] **επλησθησαν** *eplēsthēsan* zostali napełnieni [[G4130]] WTV-API-3P **θαμβους** *thambous* zdumieniem [[G2285]] [[N-GSN]] **και** *kai* i [[G2532]] [[CONJ]] **εκστασεως** *ekstaseōs* oszołomieniem – zdumieniem [[G1611]] [[N-GSF]] **επι** *epi* z powodu [[G1909]] [[PREP]] **τω** *tō* (tego) [[G3588]] WTT-DSN **συμβεβηκοτι** *symbebēkoti* co zdarzyło się [[G4819]] WTV-RAP-DSN **αυτω** *autō* mu [[G846]] WTP-DSM
###### **Dz 3,11**
 **κρατουντος** *kratountos* Trzymając się [[G2902]] WTV-PAP-GSM **δε** *de* zaś [[G1161]] [[CONJ]] **του** *tou* (tego) [[G3588]] WTT-GSM **ιαθεντος** *iathentos* który został uzdrowiony – który został uleczony [[G2390]] WTV-APP-GSM **χωλου** *chōlou* kulawych – chromych [[G5560]] WTA-GPM **τον** *ton* [[G3588]] [[T-ASM]] **πετρον** *petron* Piotra – [kamyk] [[G4074]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **ιωαννην** *iōannēn* Jana – [JHWH jest łaskawy] [[G2491]] [[N-ASM]] **συνεδραμεν** *synedramen* zbiegł się [[G4936]] WTV-2AAI-3S **προς** *pros* do [[G4314]] [[PREP]] **αυτους** *autous* nich [[G846]] [[P-APM]] **πας** *pas* cały [[G3956]] [[A-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **λαος** *laos* lud [[G2992]] [[N-NSM]] **επι** *epi* na [[G1909]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **στοα** *stoa* portyku [[G4745]] [[N-DSF]] **τη** *tē* [[G3588]] WTT-DSF **καλουμενη** *kaloumenē* który jest nazywany – który jest zwany [[G2564]] WTV-PPP-DSF **σολομωντος** *solomōntos* Salomona – [człowiek pokoju] [[G4672]] [[N-GSM]] **εκθαμβοι** *ekthamboi* zdumiony – pełen podziwu [[G1569]] WTA-NPM
###### **Dz 3,12**
 **ιδων** *idōn* Zobaczywszy [[G1492]] WTV-2AAP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **πετρος** *petros* Piotr – [kamyk] [[G4074]] [[N-NSM]] **απεκρινατο** *apekrinato* odpowiedział [[G611]] WTV-ADI-3S **προς** *pros* do [[G4314]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **λαον** *laon* ludu [[G2992]] [[N-ASM]] **ανδρες** *andres* mężowie [[G435]] WTN-VPM **ισραηλιται** *israēlitai* Izraelici – [ten, który walczył z Bogiem] [[G2475]] WTN-VPM **τι** *ti* dlaczego [[G5101]] WTI-ASN **θαυμαζετε** *thaumazete* dziwcie się [[G2296]] WTV-PAI-2P **επι** *epi* z powodu [[G1909]] [[PREP]] **τουτω** *toutō* tego [[G5129]] WTD-DSN **η** *ē* lub [[G2228]] WTPRT **ημιν** *hēmin* (na) nas [[G2254]] WTP-1DP **τι** *ti* dlaczego [[G5101]] WTI-ASN **ατενιζετε** *atenizete* spoglądacie – kierujecie wzrok [[G816]] WTV-PAI-2P **ως** *hōs* jak [[G5613]] [[ADV]] **ιδια** *idia* własną [[G2398]] WTA-DSF **δυναμει** *dynamei* mocą [[G1411]] [[N-DSF]] **η** *ē* lub [[G2228]] WTPRT **ευσεβεια** *eusebeia* pobożnością [[G2150]] [[N-DSF]] **πεποιηκοσιν** *pepoiēkosin* czyniących [[G4160]] WTV-RAP-DPM **του** *tou* (to, że) [[G3588]] WTT-GSM **περιπατειν** *peripatein* chodzić [[G4043]] WTV-PAN **αυτον** *auton* on [[G846]] WTP-ASM
###### **Dz 3,13**
 **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **αβρααμ** *abraam* Abrahama – [ojciec wielu narodów] [[G11]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **ισαακ** *isaak* Izaaka – [śmiać się] [[G2464]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **ιακωβ** *iakōb* Jakuba – [pięta] [[G2384]] [[N-PRI]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **των** *tōn* [[G3588]] WTT-GPM **πατερων** *paterōn* ojców [[G3962]] WTN-GPM **ημων** *hēmōn* naszych [[G2257]] WTP-1GP **εδοξασεν** *edoksasen* oddał chwałę [[G1392]] [[V-AAI-3S]] **τον** *ton* [[G3588]] [[T-ASM]] **παιδα** *paida* chłopiec [[G3816]] [[N-ASM]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]] **ον** *hon* którego [[G3739]] WTR-ASM **υμεις** *hymeis* wy [[G5210]] WTP-2NP **παρεδωκατε** *paredōkate* wydaliście [[G3860]] WTV-AAI-2P **και** *kai* i [[G2532]] [[CONJ]] **ηρνησασθε** *ērnēsasthe* wyparliście się – odrzuciliście [[G720]] WTV-ADI-2P **αυτον** *auton* Go [[G846]] WTP-ASM **κατα** *kata* naprzeciw [[G2596]] [[PREP]] **προσωπον** *prosōpon* oblicza – twarzy [[G4383]] WTN-ASN **πιλατου** *pilatou* Piłata [[G4091]] [[N-GSM]] **κριναντος** *krinantos* który osądził [[G2919]] WTV-AAP-GSM **εκεινου** *ekeinou* Jego [[G1565]] WTD-GSM **απολυειν** *apolyein* uwolnić – wypuścić [[G630]] WTV-PAN
###### **Dz 3,14**
 **υμεις** *hymeis* Wy [[G5210]] WTP-2NP **δε** *de* zaś [[G1161]] [[CONJ]] **τον** *ton* [[G3588]] [[T-ASM]] **αγιον** *hagion* Świętego [[G40]] WTA-ASM **και** *kai* i [[G2532]] [[CONJ]] **δικαιον** *dikaion* sprawiedliwego [[G1342]] WTA-ASM **ηρνησασθε** *ērnēsasthe* wyparliście się – odrzuciliście [[G720]] WTV-ADI-2P **και** *kai* i [[G2532]] [[CONJ]] **ητησασθε** *ētēsasthe* prosiliście – domagaliście się [[G154]] WTV-AMI-2P **ανδρα** *andra* męża [[G435]] [[N-ASM]] **φονεα** *fonea* mordercę [[G5406]] [[N-ASM]] **χαρισθηναι** *charisthēnai* zostać darowanym [[G5483]] WTV-APN **υμιν** *hymin* wam [[G5213]] WTP-2DP
###### **Dz 3,15**
 **τον** *ton* (Tego) [[G3588]] [[T-ASM]] **δε** *de* zaś [[G1161]] [[CONJ]] **αρχηγον** *archēgon* Początek i Wodza – Sprawcę [[G747]] [[N-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **ζωης** *zōēs* życia [[G2222]] [[N-GSF]] **απεκτεινατε** *apekteinate* zabiliście [[G615]] WTV-AAI-2P **ον** *hon* którego [[G3739]] WTR-ASM **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ηγειρεν** *ēgeiren* wzbudził – podniósł [[G1453]] [[V-AAI-3S]] **εκ** *ek* z [[G1537]] [[PREP]] **νεκρων** *nekrōn* martwych [[G3498]] WTA-GPM **ου** *hou* którego [[G3739]] WTR-GSM **ημεις** *hēmeis* my [[G2249]] WTP-1NP **μαρτυρες** *martyres* świadkowie [[G3144]] WTN-NPM **εσμεν** *esmen* jesteśmy [[G2070]] WTV-PXI-1P
###### **Dz 3,16**
 **και** *kai* I [[G2532]] [[CONJ]] **επι** *epi* z powodu [[G1909]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **πιστει** *pistei* wiary [[G4102]] [[N-DSF]] **του** *tou* (w) [[G3588]] WTT-GSN **ονοματος** *onomatos* imię [[G3686]] [[N-GSN]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **τουτον** *touton* tego [[G5126]] WTD-ASM **ον** *hon* którego [[G3739]] WTR-ASM **θεωρειτε** *theōreite* widzicie [[G2334]] WTV-PAI-2P **και** *kai* i [[G2532]] [[CONJ]] **οιδατε** *oidate* znacie [[G1492]] WTV-RAI-2P **εστερεωσεν** *estereōsen* wzmocniło – utwierdziło [[G4732]] [[V-AAI-3S]] **το** *to* [[G3588]] WTT-NSN **ονομα** *onoma* imię [[G3686]] WTN-NSN **αυτου** *autou* Jego [[G846]] [[P-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **πιστις** *pistis* wiara [[G4102]] [[N-NSF]] **η** *hē* [[G3588]] [[T-NSF]] **δι** *di* przez – w [[G1223]] [[PREP]] **αυτου** *autou* Niego [[G846]] [[P-GSM]] **εδωκεν** *edōken* dała [[G1325]] [[V-AAI-3S]] **αυτω** *autō* mu [[G846]] WTP-DSM **την** *tēn* [[G3588]] WTT-ASF **ολοκληριαν** *holoklērian* pełną sprawność [[G3647]] WTN-ASF **ταυτην** *tautēn* tę [[G3778]] WTD-ASF **απεναντι** *apenanti* wobec [[G561]] [[ADV]] **παντων** *pantōn* wszystkich [[G3956]] WTA-GPM **υμων** *hymōn* was [[G5216]] WTP-2GP
###### **Dz 3,17**
 **και** *kai* I [[G2532]] [[CONJ]] **νυν** *nyn* teraz [[G3568]] [[ADV]] **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **οιδα** *oida* wiem [[G1492]] WTV-RAI-1S **οτι** *hoti* że [[G3754]] [[CONJ]] **κατα** *kata* zgodnie z [[G2596]] [[PREP]] **αγνοιαν** *agnoian* niewiedzą – nieświadomością [[G52]] WTN-ASF **επραξατε** *epraksate* uczyniliście – zrobiliście [[G4238]] WTV-AAI-2P **ωσπερ** *hōsper* tak, jak [[G5618]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **αρχοντες** *archontes* przywódcy – przełożeni [[G758]] WTN-NPM **υμων** *hymōn* wasi [[G5216]] WTP-2GP
###### **Dz 3,18**
 **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **α** *ha* co [[G3739]] WTR-APN **προκατηγγειλεν** *prokatēngeilen* przepowiedział – wcześniej ogłosił [[G4293]] [[V-AAI-3S]] **δια** *dia* przez [[G1223]] [[PREP]] **στοματος** *stomatos* usta [[G4750]] [[N-GSN]] **παντων** *pantōn* wszystkich [[G3956]] WTA-GPM **των** *tōn* [[G3588]] WTT-GPM **προφητων** *profētōn* proroków [[G4396]] WTN-GPM **αυτου** *autou* Jego [[G846]] [[P-GSM]] **παθειν** *pathein* wycierpieć [[G3958]] [[V-2AAN]] **τον** *ton* [[G3588]] [[T-ASM]] **χριστον** *christon* Pomazaniec [[G5547]] [[N-ASM]] **επληρωσεν** *eplērōsen* wypełnił [[G4137]] [[V-AAI-3S]] **ουτως** *houtōs* tak [[G3779]] [[ADV]]
###### **Dz 3,19**
 **μετανοησατε** *metanoēsate* Opamiętajcie się – Zmieńcie myślenie [[G3340]] WTV-AAM-2P **ουν** *oun* więc [[G3767]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **επιστρεψατε** *epistrepsate* nawróćcie się – zawróćcie [[G1994]] WTV-AAM-2P **εις** *eis* do [[G1519]] [[PREP]] **το** *to* (tego, by) [[G3588]] WTT-ASN **εξαλειφθηναι** *eksaleifthēnai* zostać wymazanym – zostać startym [[G1813]] WTV-APN **υμων** *hymōn* wasze [[G5216]] WTP-2GP **τας** *tas* [[G3588]] WTT-APF **αμαρτιας** *hamartias* grzechy [[G266]] WTN-APF **οπως** *hopōs* jak- [[G3704]] [[ADV]] **αν** *an* kolwiek [[G302]] WTPRT **ελθωσιν** *elthōsin* przyszłyby [[G2064]] WTV-2AAS-3P **καιροι** *kairoi* pory [[G2540]] WTN-NPM **αναψυξεως** *anapsykseōs* pokrzepienia – orzeźwienia [[G403]] [[N-GSF]] **απο** *apo* od [[G575]] [[PREP]] **προσωπου** *prosōpou* oblicza – twarzy [[G4383]] [[N-GSN]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]]
###### **Dz 3,20**
 **και** *kai* i [[G2532]] [[CONJ]] **αποστειλη** *aposteilē* wysłałby [[G649]] WTV-AAS-3S **τον** *ton* (Tego) [[G3588]] [[T-ASM]] **προκεκηρυγμενον** *prokekērygmenon* który jest ogłoszony wcześniej – który jest ogłoszony wcześniej przez herolda [[G4296]] WTV-RPP-ASM **υμιν** *hymin* wam [[G5213]] WTP-2DP **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]] **χριστον** *christon* Pomazańca [[G5547]] [[N-ASM]]
###### **Dz 3,21**
 **ον** *hon* którego [[G3739]] WTR-ASM **δει** *dei* trzeba – jest konieczne [[G1163]] WTV-PQI-3S **ουρανον** *ouranon* niebu [[G3772]] [[N-ASM]] **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **δεξασθαι** *deksasthai* przyjąć [[G1209]] WTV-ADN **αχρι** *achri* aż do [[G891]] [[PREP]] **χρονων** *chronōn* czasów [[G5550]] WTN-GPM **αποκαταστασεως** *apokatastaseōs* przywrócenia – ponownego ustanowienia [[G605]] [[N-GSF]] **παντων** *pantōn* wszystkich [[G3956]] WTA-GPN **ων** *hōn* (o) których [[G3739]] WTR-GPN **ελαλησεν** *elalēsen* powiedział [[G2980]] [[V-AAI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **δια** *dia* przez [[G1223]] [[PREP]] **στοματος** *stomatos* usta [[G4750]] [[N-GSN]] **παντων** *pantōn* wszystkich [[G3956]] WTA-GPM **αγιων** *hagiōn* świętych [[G40]] WTA-GPM **αυτου** *autou* Jego [[G846]] [[P-GSM]] **προφητων** *profētōn* proroków [[G4396]] WTN-GPM **απ** *ap* od [[G575]] [[PREP]] **αιωνος** *aiōnos* wieku [[G165]] [[N-GSM]]
###### **Dz 3,22**
 **μωσης** *mōsēs* Mojżesz – [wyciągnąć] [[G3475]] [[N-NSM]] **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **προς** *pros* do [[G4314]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **πατερας** *pateras* ojców [[G3962]] [[N-APM]] **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **οτι** *hoti* że [[G3754]] [[CONJ]] **προφητην** *profētēn* proroka [[G4396]] [[N-ASM]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **αναστησει** *anastēsei* wzbudzi – podniesie [[G450]] WTV-FAI-3S **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **υμων** *hymōn* wasz [[G5216]] WTP-2GP **εκ** *ek* z [[G1537]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **αδελφων** *adelfōn* braci [[G80]] WTN-GPM **υμων** *hymōn* waszych [[G5216]] WTP-2GP **ως** *hōs* jak [[G5613]] [[ADV]] **εμε** *eme* mnie [[G1691]] WTP-1AS **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ακουσεσθε** *akousesthe* będziecie słuchać [[G191]] WTV-FDI-2P **κατα** *kata* zgodnie ze [[G2596]] [[PREP]] **παντα** *panta* wszystkimi [[G3956]] WTA-APN **οσα** *hosa* ile- – jak- [[G3745]] WTK-APN **αν** *an* kolwiek [[G302]] WTPRT **λαληση** *lalēsē* powiedziałby [[G2980]] WTV-AAS-3S **προς** *pros* do [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP
###### **Dz 3,23**
 **εσται** *estai* Będzie [[G2071]] WTV-FXI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **πασα** *pasa* każda [[G3956]] WTA-NSF **ψυχη** *psychē* dusza – życie [[G5590]] [[N-NSF]] **ητις** *hētis* która- [[G3748]] WTR-NSF **αν** *an* kolwiek [[G302]] WTPRT **μη** *mē* nie [[G3361]] [[PRT-N]] **ακουση** *akousē* usłuchałaby [[G191]] WTV-AAS-3S **του** *tou* [[G3588]] WTT-GSM **προφητου** *profētou* proroka [[G4396]] [[N-GSM]] **εκεινου** *ekeinou* tego [[G1565]] WTD-GSM **εξολοθρευθησεται** *eksolothreuthēsetai* zostanie doszczętnie zniszczona – zostanie całkowicie wygubiona [[G1842]] WTV-FPI-3S **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **λαου** *laou* ludu [[G2992]] [[N-GSM]]
###### **Dz 3,24**
 **και** *kai* I [[G2532]] [[CONJ]] **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **προφηται** *profētai* prorocy [[G4396]] WTN-NPM **απο** *apo* od [[G575]] [[PREP]] **σαμουηλ** *samouēl* Samuela – [imię Boga] [[G4545]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPM **καθεξης** *katheksēs* kolejno – po kolei [[G2517]] [[ADV]] **οσοι** *hosoi* ilu – jacy [[G3745]] WTK-NPM **ελαλησαν** *elalēsan* powiedzieli [[G2980]] WTV-AAI-3P **και** *kai* i [[G2532]] [[CONJ]] **προκατηγγειλαν** *prokatēngeilan* zapowiadali – wcześniej głosili [[G4293]] WTV-AAI-3P **τας** *tas* [[G3588]] WTT-APF **ημερας** *hēmeras* dni [[G2250]] WTN-APF **ταυτας** *tautas* te [[G3778]] WTD-APF
###### **Dz 3,25**
 **υμεις** *hymeis* wy [[G5210]] WTP-2NP **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **υιοι** *hyioi* synowie [[G5207]] WTN-NPM **των** *tōn* [[G3588]] WTT-GPM **προφητων** *profētōn* proroków [[G4396]] WTN-GPM **και** *kai* i [[G2532]] [[CONJ]] **της** *tēs* [[G3588]] [[T-GSF]] **διαθηκης** *diathēkēs* przymierza [[G1242]] [[N-GSF]] **ης** *hēs* którego [[G3739]] [[R-GSF]] **διεθετο** *dietheto* zawarł – ułożył [[G1303]] WTV-2AMI-3S **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **προς** *pros* z [[G4314]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **πατερας** *pateras* ojcami [[G3962]] [[N-APM]] **ημων** *hēmōn* naszymi [[G2257]] WTP-1GP **λεγων** *legōn* mówiąc [[G3004]] [[V-PAP-NSM]] **προς** *pros* do [[G4314]] [[PREP]] **αβρααμ** *abraam* Abrahama – [ojciec wielu narodów] [[G11]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **τω** *tō* [[G3588]] WTT-DSN **σπερματι** *spermati* nasieniem [[G4690]] WTN-DSN **σου** *sou* twoim [[G4675]] WTP-2GS **ενευλογηθησονται** *eneulogēthēsontai* zostaną błogosławione – zostaną wysławione [[G1757]] WTV-FPI-3P **πασαι** *pasai* wszystkie [[G3956]] [[A-NPF]] **αι** *hai* [[G3588]] [[T-NPF]] **πατριαι** *patriai* rody [[G3965]] [[N-NPF]] **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]]
###### **Dz 3,26**
 **υμιν** *hymin* Wam [[G5213]] WTP-2DP **πρωτον** *prōton* najpierw [[G4412]] [[ADV]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **αναστησας** *anastēsas* wzbudziwszy – podniósłszy [[G450]] WTV-AAP-NSM **τον** *ton* [[G3588]] [[T-ASM]] **παιδα** *paida* chłopca [[G3816]] [[N-ASM]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]] **απεστειλεν** *apesteilen* wysłał [[G649]] [[V-AAI-3S]] **αυτον** *auton* Go [[G846]] WTP-ASM **ευλογουντα** *eulogounta* błogosławiąc – wysławiając [[G2127]] WTV-PAP-ASM **υμας** *hymas* was [[G5209]] WTP-2AP **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **αποστρεφειν** *apostrefein* odwracać się [[G654]] WTV-PAN **εκαστον** *hekaston* każdego [[G1538]] WTA-ASM **απο** *apo* z [[G575]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPF **πονηριων** *ponēriōn* niegodziwości [[G4189]] WTN-GPF **υμων** *hymōn* waszych [[G5216]] WTP-2GP
