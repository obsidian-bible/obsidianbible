# Est 1 BT5

###### **Est 1,1a**
 W drugim roku panowania wielkiego króla Artakserksesa, pierwszego Nisan, miał sen Mardocheusz, syn Jaira, syna Szimejego, syna Kisza z pokolenia Beniamina, 
###### **Est 1,1b**
 Żyd, mieszkający w mieście Suzie, mąż wybitny, pełniący służbę na królewskim dworze. 
###### **Est 1,1c**
Był on z liczby jeńców, których uprowadził Nabuchodonozor, król babiloński, razem z Jechoniaszem, królem judzkim. 
###### **Est 1,1d**
A sen jego był taki: Oto [słychać było] krzyki i wrzawę, grzmoty, trzęsienie i zamieszanie na ziemi. 
###### **Est 1,1e**
I oto dwa smoki wielkie przyszły i stanęły gotowe do walki ze sobą i rozległ się ich ryk ogromny. 
###### **Est 1,1f**
I na ten ryk ich przygotował się cały naród do walki, aby zwalczyć naród sprawiedliwych. 
###### **Est 1,1g**
A oto [nastał] dzień ciemności i mroku, ucisku i udręczenia, nieszczęścia i zamieszania wielkiego na ziemi. 
###### **Est 1,1h**
I wzburzył się cały naród sprawiedliwy, lękający się swego nieszczęścia i gotowy był na zagładę. I wołał do Boga. 
###### **Est 1,1i**
I na skutek tego wołania wyłoniła się jakby z małego źródła wielka rzeka, wiele wody. 
###### **Est 1,1k**
I zaświeciła światłość i słońce, a poniżeni zostali wywyższeni, i pochłonęli potężnych. 
###### **Est 1,1l**
I zbudziwszy się Mardocheusz po owym widzeniu sennym, aż do nocy rozważał je w sercu swoim i wszelkimi sposobami chciał poznać to, co Bóg zamierzał uczynić.  
###### **Est 1,1m**
A gdy Mardocheusz odpoczywał na dziedzińcu z Gabatą i Tarrą, dwoma eunuchami króla strzegącymi dziedzińca, 
###### **Est 1,1n**
posłyszał ich rozmowy i odkrył ich knowania. Przekonał się, że byli gotowi podnieść rękę na króla Artakserksesa, i doniósł o nich królowi. 
###### **Est 1,1o**
Król przeprowadził śledztwo przeciw tym dwom eunuchom, a gdy przyznali się do winy, odprowadzono ich na śmierć. 
###### **Est 1,1p**
Król zaś opisał te wydarzenia na pamiątkę, ale i Mardocheusz też napisał o tych sprawach. 
###### **Est 1,1q**
I powierzył król Mardocheuszowi służbę na dziedzińcu [królewskim], i obdarzył go za to podarunkami. 
###### **Est 1,1r**
Lecz Haman, syn Hammedaty, Bugajczyk, miał względy u króla i starał się zaszkodzić Mardocheuszowi i ludowi jego z zemsty za tamtych dwóch eunuchów królewskich.
###### **Est 1,1**
 A było to za dni Aswerusa; Aswerus ten panował od Indii aż do Etiopii nad stu dwudziestu siedmiu państwami.
###### **Est 1,2**
 W owych dniach, kiedy król Aswerus zasiadał na tronie swego królestwa, na zamku w Suzie,
###### **Est 1,3**
 w trzecim roku swego panowania wydał ucztę dla wszystkich swoich książąt i swoich sług oraz najdzielniejszych Persów i Medów, wielmoży i władców państw, którzy byli razem z nim.
###### **Est 1,4**
 Przy tym pokazywał bogactwo i przepych swego królestwa oraz blask swojej chwały i wielkości przez wiele dni, to jest przez dni sto osiemdziesiąt.
###### **Est 1,5**
 A po upływie owych dni król wydał ucztę dla całego ludu, który znajdował się na zamku w Suzie, od największych aż do najmniejszych, przez siedem dni na dziedzińcu ogrodu przy pałacu króla.
###### **Est 1,6**
 Białe tkaniny lniane i fioletowa purpura były przymocowane sznurami z bisioru i czerwonej purpury do srebrnych pierścieni na kolumnach z białego marmuru. Złote i srebrne sofy stały na posadzce z kamieni koloru szmaragdu, białego marmuru, masy perłowej i na mozaice.
###### **Est 1,7**
 Napoje zaś podawano w naczyniach złotych, a zastawa była z naczyń różnych. Wina królewskiego było wiele, zgodnie z królewską hojnością.
###### **Est 1,8**
 Picie odbywało się według takiego zalecenia: nikt nikogo nie przymuszał, bo tak nakazał król wszystkim urzędnikom swego domu: Niech każdy czyni, co mu się podoba.
###### **Est 1,9**
 Także królowa Waszti wydała ucztę dla kobiet w pałacu królewskim, który należał do króla Aswerusa.
###### **Est 1,10**
 W siódmym dniu, kiedy już rozweseliło się winem serce króla, rzekł do Mehumana, Bizzety, Charbony, Bigty, Abagty, Zetera i Karkasa, siedmiu eunuchów usługujących królowi Aswerusowi,
###### **Est 1,11**
 aby przywiedli przed oblicze króla królową Waszti w koronie królewskiej celem pokazania ludowi i książętom jej piękności; odznaczała się bowiem miłym wyglądem.
###### **Est 1,12**
 Ale królowa Waszti odmówiła przyjścia na rozkaz króla, przekazany za pośrednictwem eunuchów. Na to król bardzo się rozzłościł, i gniew w nim zapłonął.
###### **Est 1,13**
 I rozmawiał król z mędrcami znającymi czasy, bo tak sprawy króla [rozważano] wobec znających prawo i sąd.
###### **Est 1,14**
 A rozkazał przywołać do siebie Karszenę, Szetara, Admatę, Tarszisza, Meresa, Mersenę, Memukana, siedmiu książąt perskich i medyjskich, którzy byli zaufanymi doradcami króla i zajmowali w królestwie pierwsze miejsca.
###### **Est 1,15**
 [I zapytał]: «***Jak według prawa należy postąpić z królową Waszti, która nie wykonała rozkazu króla Aswerusa, jaki przekazali eunuchowie?***»
###### **Est 1,16**
 Na to odpowiedział Memukan wobec króla i książąt: «***Nie tylko przeciw samemu królowi wykroczyła królowa Waszti, lecz także przeciw wszystkim książętom i wszystkim narodom, które zamieszkują państwa króla Aswerusa.***
###### **Est 1,17**
 ***Gdy wieść o zachowaniu się królowej rozejdzie się pośród wszystkich kobiet, wtedy wzgardzą mężami swoimi w oczach swoich i powiedzą im: Król Aswerus polecił przyprowadzić królową Waszti do siebie, a ona nie przyszła.***
###### **Est 1,18**
 ***Dziś wszystkie księżniczki perskie i medyjskie będą mówiły do książąt królewskich, tak jak usłyszały, że postąpiła królowa. Wtedy będzie wiele pogardy i gniewu.***
###### **Est 1,19**
 ***Jeśli się to królowi podoba, to niech wyjdzie dekret królewski od niego i niech będzie zapisane w prawach perskich i medyjskich, a także niech będzie nieodwołalne to, że Waszti nie może już przyjść przed oblicze króla Aswerusa, a jej godność królewską niech da król jej towarzyszce, godniejszej od niej.***
###### **Est 1,20**
 ***A gdy usłyszą dekret króla, wydany dla całego królestwa – a wielkie jest ono – wszystkie kobiety oddadzą cześć swoim mężom, od największego do najmniejszego***».
###### **Est 1,21**
 Spodobała się ta rada królowi i jego książętom i uczynił król według słów Memukana.
###### **Est 1,22**
 I wysłał listy do wszystkich państw króla, do każdej krainy jej własnym pismem i do każdego narodu w jego własnym języku, aby każdy mąż był panem w swoim domu < i mówił, co mu się podoba >.
# Est 1 PAU
###### **Est 1,1**
 Zdarzyło się to za czasów Artakserksesa, który od Indii aż do Etiopii miał w swoim władaniu łącznie sto dwadzieścia siedem państw.
###### **Est 1,2**
 W czasie, gdy zasiadał na tronie w mieście Suza,
###### **Est 1,3**
 w trzecim roku swego panowania wydał on przyjęcie dla przyjaciół i dla pozostałych dworzan, dla dostojnych Persów i Medów, a także dla rządców prowincji.
###### **Est 1,4**
 Ucztowali przez sto osiemdziesiąt dni, w czasie których król pokazał im przepych swego królestwa oraz blask swojej świetności.
###### **Est 1,5**
 Kiedy minęły dni uroczystości, król urządził na dziedzińcu pałacu królewskiego sześciodniową ucztę dla wszystkich ludów przebywających w mieście.
###### **Est 1,6**
 Nad dziedzińcem rozpięto delikatne tkaniny z bisioru i lnu, które sznurami z bisioru i szkarłatu przymocowano do srebrnych i złotych pierścieni, a te do kolumn z białego marmuru. Złote i srebrne sofy ustawiono na posadzce z kamieni w kolorze szmaragdu, masy perłowej i białego marmuru, a przezroczyste, misternie tkane pokrycia ozdobiono wpiętymi dokoła kwiatami róży.
###### **Est 1,7**
 Kielichy były ze złota i srebra, a sam tylko rubinowy puchar szacowano na trzydzieści tysięcy talentów. Wina było pod dostatkiem i to takiego, jakie pił sam król.
###### **Est 1,8**
 W czasie uczty nie przestrzegano zasad biesiadowania, gdyż tak życzył sobie król, który rozkazał obsługującym spełniać wolę obecnych.
###### **Est 1,9**
 Również królowa Waszti wydała ucztę dla kobiet w pokojach królewskich, należących do króla Artakserksesa.
###### **Est 1,10**
 W siódmym dniu rozradowany król rzekł do Hamana, Bazana, Tarry, Borazego, Zatolty, Abatazy i Taraby, siedmiu eunuchów, służących króla Artakserksesa,
###### **Est 1,11**
 by przyprowadzili królową w koronie królewskiej. Chciał wszystkim książętom i ludom pokazać jej urodę, gdyż była naprawdę piękna.
###### **Est 1,12**
 Ale królowa Waszti nie posłuchała rozkazu i nie przyszła z eunuchami. Wtedy urażony król zapłonął gniewem
###### **Est 1,13**
 i rzekł do swoich przyjaciół: „Tak oto odpowiedziała Waszti! Osądźcie to i wydajcie wyrok!”.
###### **Est 1,14**
 Wtedy podeszli do niego Arkesajos, Sarsatajos i Malesear, książęta perscy i medyjscy, bliscy współpracownicy króla, zasiadający na pierwszych miejscach przy królu,
###### **Est 1,15**
 i powiedzieli mu, jak według prawa należałoby postąpić z królową Waszti, która nie spełniła królewskiego polecenia przekazanego jej przez eunuchów.
###### **Est 1,16**
 A Muchajos rzekł do króla i książąt: „Królowa Waszti zawiniła nie tylko wobec króla, ale także wobec wszystkich książąt i dostojników królestwa.
###### **Est 1,17**
 Jeżeli bowiem rozejdzie się wieść o takim zachowaniu królowej, a przecież sprzeciwiła się samemu królowi Artakserksesowi,
###### **Est 1,18**
 to małżonki książąt perskich i medyjskich, jak tylko dowiedzą się, co Waszti odpowiedziała królowi, jeszcze dzisiaj odważą się w podobny sposób wzgardzić swoimi mężami.
###### **Est 1,19**
 Jeśli więc król uzna to za słuszne, niech wyda dekret królewski, który zostanie wpisany do praw Medów i Persów, i niech w nim postanowi nieodwołalnie, że królowa nie stanie już nigdy przed królem, a jej godność królewska będzie oddana kobiecie od niej szlachetniejszej!
###### **Est 1,20**
 Jeżeli król ustanowi takie prawo królewskie, to niech zostanie ono ogłoszone w królestwie, gdyż tym sposobem wszystkie kobiety będą okazywać szacunek swoim mężom, tak ubogim, jak i bogatym”.
###### **Est 1,21**
 Mowa ta spodobała się królowi i książętom i król postąpił według słów Muchajosa.
###### **Est 1,22**
 Po całym królestwie został rozesłany dekret, do każdego okręgu w jego własnym języku, by mężowie byli panami w swoich domach.
# Est 1 BP
###### **Est 1,1**
 Według TM: 1:1 Było to za dni Achaszwerosza, tego Achaszwerosza, który panował nad stu dwudziestu siedmioma prowincjami od Indii aż do Etiopii. Według LXX: A 1.1a-1ra W drugim roku panowania wielkiego króla Artakserksesa, dnia pierwszego Nizan, Mardocheusz, syn Jaira, syna Szemei, syna Kisza, z pokolenia Beniamina, 1b mąż żydowski, który mieszkał w mieście Suza, mąż znakomity, pełniący służbę na dworze królewskim, miał sen. 1c Należał on do wygnańców, których wraz z Jechoniaszem, królem judzkim, uprowadził z Jeruzalem Nabuchodonozor, król babiloński. 1d Sen jego był następujący: Oto [rozległy się] krzyki i zgiełk, grzmoty, trzęsienia i zamęt na ziemi. 1e Równocześnie wystąpiły dwa wielkie smoki, gotowe oba do walki ze sobą. Ryk ich był bardzo donośny, 1f a na ten ryk wszystkie narody jęły się sposobić do walki, by pokonać lud sprawiedliwy. 1g Był to dzień ciemności i mroku, ucisku i prześladowania, udręki i wielkiego zamieszania na ziemi. 1h Cały lud sprawiedliwy zdjęty przerażeniem z powodu nieszczęścia, jakie nań miało spaść, gotując się do zguby wołał do Boga. 1i I oto na jego wołanie jak gdyby wielka rzeka wezbrana wodami wypłynęła z małego źródła. 1k [Wówczas] przejaśniło się i wzeszło słońce, a uciskani zostali wywyższeni i wchłonęli mocarzy. 1l Zbudziwszy się po tym śnie Mardocheusz zaczął zastanawiać się i rozważać, jakie by miały być zamiary Boże. Aż do następnej nocy usiłował go sobie na wszelkie sposoby wytłumaczyć. 1m Mardocheusz zażywał odpoczynku na dziedzińcu pałacowym z Gabatą i Tarrą, dwoma eunuchami królewskimi, którzy trzymali straż na dziedzińcu. 1n Usłyszał on o ich planach, przeniknął ich zamiary i dowiedział się, że knuli spisek przeciwko królowi Artakserksesowi, o czym doniósł królowi. 1o Król poddał obydwu eunuchów śledztwu, a gdy się przyznali, zostali straceni. 1p Polecił król spisać te wypadki ku pamięci, lecz i Mardocheusz również spisał sobie te wydarzenia. 1q Następnie król zlecił Mardocheuszowi służbę na dziedzińcu i wynagrodził go za to darami. 1r Aman zaś, syn Amadaty, Bugejczyk, cieszył się wielkimi łaskami u króla. Próbował on szkodzić Mardocheuszowi i jego ludowi mszcząc się za obydwu eunuchów królewskich.
###### **Est 1,2**
 Za dni tych, gdy Achaszwerosz panował na stolicy królewskiej w twierdzy w Suzie,
###### **Est 1,3**
 w trzecim roku swego panowania wyprawił u siebie ucztę dla wszystkich swoich książąt i dostojników [dworskich], dla zasłużonych Persów i Medów, dla szlachetnie urodzonych i zarządców prowincji.
###### **Est 1,4**
 przez wiele dni, mianowicie przez dni sto osiemdziesiąt, roztaczał przed nimi bogactwo swojego królestwa oraz blask i przepych swej wielkości.
###### **Est 1,5**
 Po upływie tych dni zgotował król na dziedzińcu ogrodowym przy pałacu królewskim siedmiodniową ucztę dla wszystkich mieszkańców twierdzy Suza, zarówno dla wielkich, jak i dla małych.
###### **Est 1,6**
 Drogocenne tkaniny białe, purpurowe i fioletowe były przymocowane do kolumn z białego marmuru za pomocą sznurów z bisioru i ze szkarłatu na srebrnych pierścieniach. Złote i srebrne łoża [biesiadne] stały na posadzce z alabastru i białego marmuru, masy perłowej i mozaiki.
###### **Est 1,7**
 Trunki zaś podawano w złotych czarach o przeróżnych kształtach; wina królewskiego było w obfitości dzięki hojności króla.
###### **Est 1,8**
 Do picia - zgodnie z poleceniem królewskim - nie przymuszano nikogo; król nakazał bowiem swym dworzanom, aby każdy z zaproszonych mógł postępować według swego upodobania.
###### **Est 1,9**
 Królowa Waszti wydała również ucztę dla niewiast w pałacu króla Achaszwerosza.
###### **Est 1,10**
 Dnia siódmego, kiedy serce króla rozweseliło się pod wpływem wina, wydał on polecenie, aby Mehuman, Bizzeta, Charbona, Bigta, Abagta, Zetar i Karkas, to jest siedmiu eunuchów, którzy pełnili służbę przy królu Achaszweroszu,
###### **Est 1,11**
 przywiedli przed oblicze królewskie królowę Waszti w koronie królewskiej, gdyż chciał on ukazać jej piękność ludowi i książętom; była bowiem bardzo piękna.
###### **Est 1,12**
 Ale królowa Waszti odmówiła przybycia na rozkaz królewski, przekazany jej przez eunuchów, co bardzo wzburzyło króla i rozpłomieniło jego gniew.
###### **Est 1,13**
 Zwołał więc na naradę mędrców, obeznanych z prawami - istniał bowiem zwyczaj, by wszystkie sprawy królewskie omawiać wspólnie ze znawcami praw i sądownictwa -
###### **Est 1,14**
 a najbliższymi jego zaufanymi byli: Karszena, Szetar, Admata, Tarszisz, Meres, Marsena, Memukan, to jest siedmiu książąt perskich i medyjskich, którzy byli dopuszczani do oglądania oblicza królewskiego i zajmowali pierwsze miejsce w królestwie, [aby omówić],
###### **Est 1,15**
 co zgodnie z prawem należy uczynić z królową Waszti, która nie zastosowała się do polecenia króla Achaszwerosza, przekazanego jej przez eunuchów.
###### **Est 1,16**
 Memukan zabrał głos wobec króla i książąt: Królowa Waszti zawiniła nie tylko w stosunku do króla, ale również w stosunku do wszystkich książąt i wszystkich ludów, które żyją we wszystkich prowincjach króla Achaszwerosza.
###### **Est 1,17**
 Postępek królowej rozniesie się bowiem wśród wszystkich żon, które znajdą w nim usprawiedliwienie, by odnosić się ze wzgardą do swych mężów. Będą bowiem mówić: "Król Achaszwerosz wydał rozkaz, by przyprowadzono do niego królową Waszti, a ona nie przyszła".
###### **Est 1,18**
 Jeszcze dziś wszystkie księżniczki perskie i medyjskie, które usłyszą o zachowaniu się królowej, powtórzą to samo wszystkim książętom króla i wyniknie stąd wiele wzgardy i gniewu.
###### **Est 1,19**
 Jeżeli wyda się to królowi rzeczą słuszną, niech zostanie wydany z jego ramienia dekret królewski i niech zostanie wpisany na zawsze do praw perskich i medyjskich, że Waszti nie ukaże się już nigdy przed obliczem króla Achaszwerosza, godność zaś jej królewską niech przekaże król innej, godniejszej od niej.
###### **Est 1,20**
 A gdy ten wyrok królewski zostanie ogłoszony w całym królestwie, które jest tak wielkie, wszystkie żony okażą szacunek swoim mężom - od najmożniejszego do najnędzniejszego.
###### **Est 1,21**
 Rada ta spodobała się królowi i książętom i król postąpił według rady Memukana.
###### **Est 1,22**
 Rozesłał więc listy do wszystkich prowincji królestwa [sporządzone] oddzielnie pismem w nich używanym i do każdego ludu w jego własnym języku [na znak], że każdy mężczyzna jest panem w swoim domu i mówi w nim swym własnym językiem.
# Est 1 BR
###### **Est 1,1**
 Działo się to w czasach Aswerusa, tego Aswerusa, którego królestwo rozciągało się od Indii aż po Etiopię i obejmowało sto dwadzieścia siedem prowincji. (a) W drugim roku panowania króla Artakserksesa, pierwszego dnia miesiąca Nisan, Mardocheusz, syn Jaira, syna Szimejego, syna Kisza z pokolenia Beniamina, miał pewien sen. (b) Mardocheusz był Żydem, mieszkał w mieście Suza i jako mąż powszechnie szanowany, pełnił służbę na dworze królewskim. (c) Należał on do tych, którzy zostali uprowadzeni z Jerozolimy podczas wojny króla babilońskiego Nabuchodonozora z królem judzkim Jechoniaszem. (d) A oto jego sen: Słychać było krzyki, płacz, grzmoty i trzęsienie ziemi oraz zamieszanie wśród wszystkich ludzi. (e) W pewnej chwili pojawiły się dwa ogromne smoki gotowe do walki. Rozległ się też zaraz ich groźny ryk, (f) który sprawił, że wszystkie narody stanęły do walki i zaczęły nękać lud sprawiedliwych. (g) Był to dzień mroków i ciemności, a na całą ziemię spadły udręczenie i ucisk, nieszczęścia i zamieszanie. (h) Przerażony nadchodzącym nieszczęściem, cały ród sprawiedliwych, pewien swojej zagłady, zaczął wołać o pomoc do Boga. (i) Na jego głos z małego źródełka wytrysnął ogromny strumień wody. (k) I znów stało się widno i zaświeciło słońce; wszystko, co było na dole, zostało wywyższone, a co było w górze, znalazło się na dole. (l) Po takim to widzeniu sennym obudził się Mardocheusz i zastanawiał się przez cały dzień, jakie są zamiary Boże, które ono ukazuje; próbował na wszelkie sposoby zrozumieć, co ten sen oznacza. (m) Pewnego razu Mardocheusz odpoczywał na dziedzińcu pałacowym razem z Gabatą i Tarrą, dwoma eunuchami, którzy pilnowali pałacu. (n) Podsłuchał, jak naradzali się nad pewnymi planami. Dokonał tedy wszelkich starań, żeby dowiedzieć się czegoś więcej o ich zamiarach, i wkrótce odkrył, że przygotowują spisek przeciwko królowi Aswerusowi. Doniósł więc o tym królowi, (o) a król kazał natychmiast przesłuchać obydwu eunuchów. Skoro tylko się przyznali, zostali skazani na śmierć. (p) Całe to wydarzenie polecił król opisać w swoich kronikach. Ze swej strony Mardocheusz także utrwalił wszystko na piśmie. (q) Król polecił tedy dopuścić Mardocheusza do służby w pałacu i cennymi podarkami wynagrodził mu jego czyn. (r) Lecz wtedy już Bugajczyk, imieniem Haman, syn Hammedaty, człowiek cieszący się dużymi względami u króla, postanowił pomścić na Mardocheuszu i jego narodzie śmierć obydwu eunuchów królewskich.
###### **Est 1,2**
 W trzecią rocznicę wstąpienia króla Aswerusa na tron w mieście Suzie i objęcia władzy nad całym tak potężnym królestwem
###### **Est 1,3**
 wydał król ucztę dla wszystkich swoich książąt i sług. Przybyli na tę ucztę najwyżsi dowódcy wojskowi Persów i Medów, a także zarządcy i namiestnicy wszystkich podległych [królów] prowincji.
###### **Est 1,4**
 Przez długi czas - dokładnie przez sto osiemdziesiąt dni - pokazywał wszystkim całe swoje bogactwo i królewski przepych,
###### **Est 1,5**
 a potem, pod koniec tych dni, wszyscy mieszkańcy Suzy, od największego do najmniejszego, na zaproszenie króla ucztowali przez siedem dni w ogrodzie pałacu królewskiego.
###### **Est 1,6**
 Na alabastrowych kolumnach rozwieszone były za pomocą srebrnych pierścieni lśniąco białe i fioletowo purpurowe [i inne] zasłony z lnu podpięte biało-czerwonymi sznurami. Na podłodze, pokrytej mozaiką z alabastru, z białego i ciemnego marmuru oraz masy perłowej, stały srebrzone i złocone sofy.
###### **Est 1,7**
 Pito ze złotych pucharów, z których żaden nie miał sobie podobnego. Wino kazał król podawać bez ograniczeń.
###### **Est 1,8**
 Unikano jakiegokolwiek przymuszania. Swojej służbie pałacowej wydał król takie polecenie: Niech każdy czyni to, na co ma ochotę.
###### **Est 1,9**
 W tym samym czasie królowa Waszti podejmowała na uczcie wszystkie kobiety, które żyły w pałacu króla Aswerusa.
###### **Est 1,10**
 Siódmego dnia król Aswerus, bardzo już rozweselony wypitym winem, swoim siedmiu eunuchom: Mehumanowi, Bizzecie, Charbonie, Bigcie, Abageke, Zeterowi i Karkasowi, pełniącym tuż przy nim służbę, wydał polecenie,
###### **Est 1,11**
 żeby mu sprowadzili królową Waszti z królewskim diademem na głowie. Zapragnął bowiem, żeby cały lud i wszyscy jego książęta podziwiali piękność królowej - a była ona rzeczywiście bardzo piękna.
###### **Est 1,12**
 Ale królowa ośmieliła się zlekceważyć rozkaz królewski, który przekazali jej eunuchowie, i nie przyszła. Obruszył się na to król i zapłonął wielkim gniewem.
###### **Est 1,13**
 I zwrócił się król do mędrców obeznanych z przepisami prawa. Miał bowiem zwyczaj o tym, co dotyczyło króla, naradzać się z biegłymi, czyli znającymi przepisy prawne.
###### **Est 1,14**
 Polecił więc, żeby przyszli do niego Karszena, Szetar, Admata, Tarszisz, Meres, Mersena, Memukan. Siedmiu tych mężów, książęta perscy i medyjscy, tworzyło grono najbliższych doradców króla i zajmowało w państwie pierwsze miejsce po królu.
###### **Est 1,15**
 Zapytał ich tedy król: Jak według prawa należy postąpić z królową Waszti, która nie wypełniła przedstawionego jej przez eunuchów rozkazu króla?
###### **Est 1,16**
 Rzekł na to do króla i do zebranych książąt Memukan: Królowa Waszti dopuściła się jawnego wykroczenia nie tylko przeciwko królowi, lecz także przeciwko książętom i wszystkim ludziom żyjącym w prowincjach króla Aswerusa.
###### **Est 1,17**
 Kiedy bowiem o zachowaniu królowej dowiedzą się inne kobiety, wszystkie zaczną lekceważyć swoich mężów mówiąc sobie, że król Aswerus kazał przyjść do siebie królowej Waszti, ale ona nie przyszła.
###### **Est 1,18**
 Poczynając od dziś księżniczki perskie i medyjskie, posłyszawszy o zachowaniu się królowej, zaczną to mówić wszystkim książętom króla. I będzie wiele wzajemnej pogardy i gniewu.
###### **Est 1,19**
 Jeśli król uzna za słuszne, to niech ukaże się dekret królewski - bez możności odwołania się do niego - obowiązujący wszystkich Persów i Medów, zabraniający królowej Waszti pokazywać się kiedykolwiek na oczy królowi Aswerusowi. Równocześnie niech król przekaże jej godność królewską innej kobiecie, zasługującej na to bardziej niż Waszti.
###### **Est 1,20**
 Kiedy zaś wieść o takim dekrecie królewskim rozejdzie się po całym państwie - a wielkie jest to państwo - znów wszystkie kobiety zaczną okazywać należny szacunek swoim mężom, od największego króla do najmniejszego.
###### **Est 1,21**
 Rada ta znalazła uznanie zarówno króla, jak i książąt. Postąpił wiec król zgodnie z radą Memukana.
###### **Est 1,22**
 Wysłał dekret do wszystkich prowincji królewskich - każda prowincja dostała ów dekret sporządzony swym własnym pismem, każdy naród w swym własnym języku - zarządzając, żeby każdy mężczyzna postępował jak rzeczywisty pan swego domu.
# Est 1 WUJ
###### **Est 1,1**
 Za dni Asswerusa, który panował od Indyiej aż do Aethyopiej nad stem dwiemadziesty i siedmią krain.
###### **Est 1,2**
 Gdy siedział na stolicy królestwa swego, Susan miasto królestwa jego początkiem było.
###### **Est 1,3**
 Trzeciego tedy roku panowania swego, sprawił wielką ucztę wszystkim książętom i służebnikom swoim, namożniejszym z Persów i nazacniejszym z Medów, i starostom krain przed sobą.
###### **Est 1,4**
 Aby okazał bogactwa chwały królestwa swego, i wielkość a chlubę możności swej, przez długi czas, to jest przez sto i ośmdziesiąt dni.
###### **Est 1,5**
 A gdy się dni uczty dokończyły, wezwał wszystkiego ludu który się nalazł w Susan, od nawiętszego aż do namniejszego: i kazał przez siedm dni ucztę nagotować w weszciu ogrodu i gaju, który królewską ozdobą i ręką był szczepiony.
###### **Est 1,6**
 I wisiały po wszystkich stronach opony białe, i zielone, i hiacyntowe, zawieszone na sznurach bisiorowych, i szarłatnych, które były przez kolca kości słoniowej przewleczone, i na słupiech marmurowych zawieszone. Łóżka też złote i srebrne rozłożone były na tle szmaragdowem i marmurowym kamieniem położonym, które dziwną rozmaitością malowanie zdobiło.
###### **Est 1,7**
 A którzy byli naproszeni, pili z kubków złotych, i na inszych i inszych naczyniach wnoszono potrawy. Wina też, tak jako wielmożności królewskiej przystało, dostatkiem a co nalepszego nalewano.
###### **Est 1,8**
 A nie był ktoby niechcących do picia przymuszał: ale jako był król postanowił, przystawując do stołów po jednemu z książąt swoich, aby każdy brał coby chciał.
###### **Est 1,9**
 Vasthi też królowa sprawiła ucztę przez białegłowy na pałacu, gdzie król Asswerus mieszkać był zwykł.
###### **Est 1,10**
 A tak dnia siódmego, gdy sobie król podweselił, a po zbytnim piciu zagrzał się winem, rozkazał Maumam i Bazatha, i Harbona, i Bagatha, i Abgatha, i Zethar, i Charchas, siedmi rzezańcom, którzy przed oczyma jego służyli.
###### **Est 1,11**
 Aby wwiedli królową Vasthi przed króla, włożywszy na głowę jej koronę, aby okazał wszystkim ludziom i książętom piękność jej, bo barzo piękna była.
###### **Est 1,12**
 Która zbraniała się, i na królewskie rozkazanie, które był przez rzezańca wskazał, przyść nie chciała. Przez co król rozgniewany, i wielką popędliwością zapalony.
###### **Est 1,13**
 Spytał mędrców, którzy według zwyczaju królewskiego zawrzdy przy nim byli, i za ich radą wszystko czynił, którzy mieli ustawy i prawa przodków:
###### **Est 1,14**
 (A byli pierwszy i nabliższy, Charsena i Sethar, i Admatha, i Tharsis, i Mares, i Marsana, i Mamuchan, siedm książąt Perskich i Medskich, którzy patrzali na oblicze królewskie, i pierwszy po nim zwykli byli siadać):
###### **Est 1,15**
 Któremu wyrokowi Vasthi królowa podległa, która rozkazania Asswerusa króla, które przez rzezańce wskazał, uczynić nie chciała.
###### **Est 1,16**
 I odpowiedział Mamuchan co król słyszał i książęta: Nie tylko króla obraziła królowa Vasthi, ale i wszystkie narody i książęta, które są po wszystkich ziemiach króla Asswerusa.
###### **Est 1,17**
 Bo wynidzie mowa królowej do wszystkich niewiast, że wzgardzą męże swe, i rzeką: król Asswerus kazał, aby królowa Vasthi weszła do niego, a ona nie chciała.
###### **Est 1,18**
 I tym przykładem wszystkie żony książąt Perskich i Medskich lekce sobie będą ważyć mężów rozkazania. Przetoż słuszny jest królewski gniew.
###### **Est 1,19**
 Jeślić się podoba, niech wynidzie wyrok od oblicza twego, a niech będzie napisan wedle prawa Persów i Medów, krórego się przestępować nie godzi, aby żadną miarą więcej Vasthi do króla nie wchodziała, ale królestwo jej insza, która jest lepsza niż ona, otrzymała.
###### **Est 1,20**
 A to po wszystkiem państwie (które jest barzo szerokie) ziem twoich niech będzie obwołano, i wszystkie żony tak wielkich jako i małych niech wyrządzają cześć małżonkom swoim.
###### **Est 1,21**
 Podobała się rada jego królowi i książętom: i uczynił król według rady Mamuchan.
###### **Est 1,22**
 I rozesłał listy po wszystkich ziemiach królestwa swego, aby każdy naród słyszeć i czytać mógł różnemi języki i pismy, że mężowie są przedniejszymi i starszymi w domiech swoich: i żeby to po wszech narodach obwołano.
