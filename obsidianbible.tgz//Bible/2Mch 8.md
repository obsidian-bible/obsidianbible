# 2Mch 8 BT5
###### **2Mch 8,1**
 Juda, zwany też Machabeuszem, i jego ludzie potajemnie przychodzili do wiosek, przywoływali do siebie i zabierali ze sobą krewnych oraz tych, którzy trwali w judaizmie. Zebrali blisko sześć tysięcy ludzi.
###### **2Mch 8,2**
 Błagali przy tym Pana, aby wejrzał na deptany przez wszystkich naród i okazał litość świątyni bezczeszczonej przez ludzi bezbożnych,
###### **2Mch 8,3**
 aby też zmiłował się nad rujnowanym miastem, które niedługo ma być zrównane z ziemią, aby wysłuchał krwi, która woła do Niego,
###### **2Mch 8,4**
 aby wspomniał na przeciwne wszelkiej sprawiedliwości mordowanie niewinnych dzieci, wreszcie na bluźnierstwa wypowiedziane przeciwko Jego imieniu, a okazał, że zła nienawidzi.
###### **2Mch 8,5**
 Kiedy Machabeusz stanął na czele oddziału, już był dla pogan niezwyciężony, gdyż gniew Pański przemienił się w miłosierdzie.
###### **2Mch 8,6**
 Nachodząc niespodziewanie miasta i wsie, palił je, a zajmując dogodne stanowiska, zmusił do ucieczki niemałą liczbę nieprzyjaciół.
###### **2Mch 8,7**
 Na takie wypady najczęściej obierał noce jako sprzymierzeńców. Opowiadania zaś o jego męstwie rozchodziły się wszędzie.
###### **2Mch 8,8**
 Widząc, że mąż ten w krótkim czasie doszedł do władzy i że coraz bardziej rośnie jego powodzenie, Filip napisał do Ptolemeusza, wodza Celesyrii i Fenicji, że powinien on wspomóc królewskie sprawy.
###### **2Mch 8,9**
 Ten zaś natychmiast wybrał Nikanora, syna Patrokla, jednego z pierwszych przyjaciół [króla], i posłał go na czele nie mniej niż dwudziestu tysięcy ludzi, pochodzących ze wszystkich narodów, aby wytępił cały naród żydowski. Dodał mu także Gorgiasza jako wodza, a był to mąż doświadczony w sprawach wojennych.
###### **2Mch 8,10**
 [Z pieniędzy uzyskanych] ze sprzedaży Żydów w niewolę Nikanor postanowił zapłacić podatek wynoszący dwa tysiące talentów, które król był winien Rzymianom.
###### **2Mch 8,11**
 Posłał więc zaraz do miast nadmorskich wezwanie, aby kupowano żydowskich niewolników, obiecując dać im dziewięćdziesięciu niewolników za jeden talent. Nie brał przy tym pod uwagę kary, która miała go spotkać ze strony Wszechmocnego.
###### **2Mch 8,12**
 Wiadomość o wyruszeniu Nikanora dotarła do Judy. Gdy zaś on swoim żołnierzom podał wiadomość o zbliżaniu się wojska,
###### **2Mch 8,13**
 małoduszni i ci, którzy nie dowierzali Bożej karze, rozbiegli się i sami opuścili to miejsce.
###### **2Mch 8,14**
 Inni zaś sprzedawali wszystko, a jednocześnie błagali Pana, aby wyratował sprzedanych przez bezbożnego Nikanora przed bitwą.
###### **2Mch 8,15**
 Jeżeli już nie ze względu na nich samych, to ze względu na przymierza zawarte z ich ojcami i ze względu na wzniosłe i pełne majestatu Jego imię, wzywane nad nimi.
###### **2Mch 8,16**
 Machabeusz zebrał swoich żołnierzy w liczbie sześciu tysięcy i upomniał ich, aby nie przerażali się [na widok] nieprzyjaciół i aby nie bali się wielkiej liczby pogan, którzy niesłusznie przeciwko nim występują, ale aby walczyli mężnie,
###### **2Mch 8,17**
 mając przed oczyma wbrew wszelkiemu prawu dokonane przez nich zbezczeszczenie świętego miejsca i poniewieranie wyszydzonym miastem, a ponadto jeszcze zniesienie obyczajów odziedziczonych po przodkach.
###### **2Mch 8,18**
 «***Oni ufność pokładają w broni, a także w śmiałości swojej***» – powiedział – «***my zaś ufamy wszechmocnemu Bogu, który może zarówno tych, co idą przeciw nam, jak i cały świat wywrócić jednym skinieniem***».
###### **2Mch 8,19**
 Wyliczył im także [przykłady] pomocy, jakiej doznali ich praojcowie, a w tym również [zwycięstwo] odniesione nad Sennacherybem, kiedy zginęło sto osiemdziesiąt pięć tysięcy;
###### **2Mch 8,20**
 a również to, co się stało w Babilonii w bitwie przeciwko Galatom: jak wszystkich do bitwy stanęło osiem tysięcy razem z czterema tysiącami Macedończyków, gdy zaś Macedończycy znaleźli się w trudnym położeniu, owe osiem tysięcy pobiło sto dwadzieścia tysięcy dzięki pomocy, którą otrzymali z Nieba, a nawet wzięli wielkie łupy.
###### **2Mch 8,21**
 Kiedy ich napełnił odwagą i sprawił, że byli gotowi złożyć życie za prawa i ojczyznę, podzielił wojsko na mniej więcej cztery części,
###### **2Mch 8,22**
 na czele każdego oddziału postawił swoich braci: Szymona, Józefa i Jonatana, a każdemu z nich powierzył dowództwo nad tysiącem pięciuset ludźmi,
###### **2Mch 8,23**
 a także Eleazara. Odczytawszy Księgę Świętą, dał hasło: «***Z Bożą pomocą!***» Sam objął dowództwo nad pierwszym oddziałem i uderzył na Nikanora.
###### **2Mch 8,24**
 Ponieważ Wszechmocny był ich sprzymierzeńcem, zabili ponad dziewięć tysięcy żołnierzy, większą część wojska Nikanora ranili i okaleczyli, wszystkich zaś zmusili do ucieczki,
###### **2Mch 8,25**
 a pieniądze tych, którzy przybyli, aby ich kupić, zabrali. Ścigali ich potem dość daleko. Zaprzestali jednak ze względu na późną godzinę.
###### **2Mch 8,26**
 Był to bowiem dzień przed szabatem i dlatego nie mogli biec za nimi zbyt daleko.
###### **2Mch 8,27**
 Kiedy broń została zgromadzona, a łupy zabrane nieprzyjaciołom, oddali się odpoczynkowi szabatowemu, bardziej niż zwykle przy tym błogosławili i wychwalali Pana, który ich wybawił, wyznaczając dla nich na ten dzień początek swojego zmiłowania.
###### **2Mch 8,28**
 Po szabacie część łupów rozdzielono pomiędzy poszkodowanych, wdowy i sieroty, resztę zaś podzielili między siebie i swoje dzieci.
###### **2Mch 8,29**
 Gdy tego dokonali i urządzili wspólną modlitwę, błagali miłosiernego Boga, ażeby swoim sługom dał się przejednać do końca.
###### **2Mch 8,30**
 W walce z żołnierzami Tymoteusza i Bakchidesa zabili ponad dwadzieścia tysięcy i opanowali nadzwyczaj wysokie warownie. Bardzo wielkie łupy podzielili na równe części, dla siebie, dla poszkodowanych, sierot, wdów, a nadto jeszcze dla starców.
###### **2Mch 8,31**
 Zabrali broń i wszystką starannie złożyli w odpowiednich miejscach, a resztę łupów zanieśli do Jerozolimy.
###### **2Mch 8,32**
 Filarchę zaś, który znajdował się w otoczeniu Tymoteusza, a który był mężem bardzo bezbożnym i sprawcą wielu krzywd wyrządzonych Żydom, zgładzili.
###### **2Mch 8,33**
 Kiedy obchodzili uroczystość zwycięstwa w swoim ojczystym mieście, spalili tych, którzy podłożyli ogień pod bramy świątyni, a także Kallistenesa, który umknął do pewnego domku. Otrzymał on godną zapłatę za bezbożność.
###### **2Mch 8,34**
 Trzykroć gorszy zaś złoczyńca Nikanor, ten, który tysiąc kupców sprowadził, aby sprzedawać Żydów,
###### **2Mch 8,35**
 z pomocą Pana upokorzony przez tych, których uważał za coś najlichszego, zrzucił swoją wspaniałą szatę, a oddaliwszy się od wszystkich, uciekał przez pola jak zbiegły niewolnik. Dzięki nadzwyczajnemu szczęściu przybył do Antiochii po zagładzie wojska.
###### **2Mch 8,36**
 Ten, który obiecał uiścić podatek Rzymianom ze sprzedaży niewolników z Jerozolimy, musiał wyznać, że Żydzi mają Obrońcę i że dlatego Żydów nie można pokonać. Postępują bowiem zgodnie z ustanowionymi przez Niego prawami.
# 2Mch 8 PAU
###### **2Mch 8,1**
 Juda Machabeusz i jego towarzysze udawali się potajemnie do wiosek, aby werbować krewnych i tych, którzy trwali w judaizmie. Zgromadzili w ten sposób około sześć tysięcy osób.
###### **2Mch 8,2**
 Wzywali PANA, aby wejrzał na lud podeptany przez wszystkich; aby okazał litość świątyni zbezczeszczonej przez bezbożnych ludzi;
###### **2Mch 8,3**
 aby zlitował się nad zniszczonym miastem, które było bliskie zrównania z ziemią; aby usłyszał krew wołającą do Niego;
###### **2Mch 8,4**
 aby pamiętał o bezprawnej masakrze niewinnych dzieci i o bluźnierstwach wypowiadanych przeciwko Jego imieniu; i aby okazał, że nienawidzi zła.
###### **2Mch 8,5**
 Gdy Machabeusz uformował oddział, stał się dla pogan niepokonany, ponieważ gniew PANA zamienił się w miłosierdzie.
###### **2Mch 8,6**
 Pojawiał się nagle, podpalał miasta i wioski, zdobywał dogodne pozycje i zmuszał do ucieczki wielu nieprzyjaciół.
###### **2Mch 8,7**
 Dokonywał tych najazdów zazwyczaj pod osłoną nocy. Sława jego męstwa rozprzestrzeniała się wszędzie.
###### **2Mch 8,8**
 Filip, widząc więc, że człowiek ten stopniowo wzrasta w siłę i coraz częściej odnosi sukcesy, napisał do Ptolemeusza, wodza Celesyrii i Fenicji, aby przyszedł z pomocą królowi.
###### **2Mch 8,9**
 Ten zaś natychmiast wybrał Nikanora, syna Patrokla, jednego z pierwszych przyjaciół króla, i posłał go na czele nie mniej niż dwudziestu tysięcy najemników ze wszystkich narodów, aby zgładził cały naród Judei. Przydzielił mu także Gorgiasza, który był wodzem i miał doświadczenie w sprawach wojennych.
###### **2Mch 8,10**
 Nikanor postanowił sprzedać Żydów w niewolę, aby pozyskać dwa tysiące talentów, które król musiał zapłacić jako daninę Rzymianom.
###### **2Mch 8,11**
 Zaraz więc wysłał do miast leżących na wybrzeżu ofertę sprzedaży niewolników żydowskich, proponując dziewięćdziesięciu niewolników za jeden talent. Nie spodziewał się, że niebawem dosięgnie go sprawiedliwość Wszechmocnego.
###### **2Mch 8,12**
 Wieść o wyprawie Nikanora dotarła do Judy. Gdy przekazał swoim towarzyszom wiadomość o nadciągającym wojsku, ci, którzy
###### **2Mch 8,13**
 się bali oraz nie wierzyli w Bożą sprawiedliwość, uciekli, porzucając to miejsce.
###### **2Mch 8,14**
 Inni sprzedawali wszystko, co im pozostało, a ponieważ bezbożny Nikanor, zanim jeszcze doszło do bitwy, sprzedał ich w niewolę, wspólnie błagali PANA o ocalenie,
###### **2Mch 8,15**
 jeśli już nie ze względu na nich samych, to przynajmniej z uwagi na przymierza z ich przodkami oraz przez wzgląd na Jego czcigodne i wspaniałe imię, wzywane nad nimi.
###### **2Mch 8,16**
 Gdy Machabeusz zgromadził swoich towarzyszy, których było sześć tysięcy, dodawał im otuchy, aby walczyli bohatersko, nie przerazili się nieprzyjaciół ani nie obawiali się mnóstwa pogan, którzy niesprawiedliwie nadchodzą przeciwko nim.
###### **2Mch 8,17**
 Niech mają przed oczami bezprawie i zniewagę, jakie wyrządzili w miejscu świętym, udrękę wyszydzonego miasta, a także obalenie odziedziczonego po przodkach porządku społecznego.
###### **2Mch 8,18**
 Mówił: „Oni pokładają nadzieję w broni i w swojej zuchwałości, my zaś w Bogu Wszechmocnym, który może jednym skinieniem powalić idących przeciwko nam, jak i cały świat”.
###### **2Mch 8,19**
 Wyliczył im przykłady, kiedy ich przodkowie otrzymali pomoc, przypominając o tym, jak w walce z Sennacherybem zostało pokonanych sto osiemdziesiąt pięć tysięcy
###### **2Mch 8,20**
 oraz o tym, jak w Babilonii osiem tysięcy Żydów i cztery tysiące Macedończyków stanęło do walki przeciwko Galatom, a kiedy Macedończycy znaleźli się w krytycznej sytuacji, osiem tysięcy Żydów pokonało sto dwadzieścia tysięcy dzięki pomocy, która nadeszła dla nich z Nieba; i zagarnęli wielkie łupy.
###### **2Mch 8,21**
 W ten sposób dodał im odwagi i sprawił, że byli gotowi umrzeć za prawa i ojczyznę. Potem podzielił wojsko na cztery części.
###### **2Mch 8,22**
 Ustanowił swoich braci: Szymona, Józefa i Jonatana dowódcami poszczególnych oddziałów, każdemu dając pod komendę tysiąc pięćset ludzi.
###### **2Mch 8,23**
 Później mianował także Eleazara. Po publicznym odczytaniu świętej księgi rzucił hasło: „Z Bożą pomocą!” i stając na czele pierwszego oddziału, rzucił się na Nikanora.
###### **2Mch 8,24**
 Ponieważ Wszechmocny był ich sprzymierzeńcem, zabili ponad dziewięć tysięcy nieprzyjaciół. Poranili lub okaleczyli większą część żołnierzy Nikanora, zmuszając ich wszystkich do ucieczki.
###### **2Mch 8,25**
 Zdobyli pieniądze tych, którzy przybyli, aby ich kupić. Ścigali ich dość długo, lecz ze względu na późną porę zaprzestali pościgu.
###### **2Mch 8,26**
 Następnego dnia był bowiem szabat i dlatego nie kontynuowali pościgu.
###### **2Mch 8,27**
 Kiedy zebrali swoją broń i zdarli z nieprzyjaciół zbroje, rozpoczęli szabat. Uwielbiali i wysławiali PANA bardziej niż zwykle, bo wybawił ich w tym dniu i znowu zaczął okazywać im miłosierdzie.
###### **2Mch 8,28**
 Po szabacie rozdzielili łupy rannym, wdowom i sierotom, a resztę wzięli dla siebie i swoich dzieci.
###### **2Mch 8,29**
 Kiedy to uczynili, urządzili wspólne modlitwy, błagając miłosiernego PANA, aby pojednał się do końca ze swoimi sługami.
###### **2Mch 8,30**
 Potem starli się w boju z ludźmi Tymoteusza i Bakchidesa, zabili spośród nich ponad dwadzieścia tysięcy i opanowali wysoko położone twierdze. Podzielili obfite łupy na równe części: dla siebie, dla rannych, dla sierot i wdów, a także dla starców.
###### **2Mch 8,31**
 Zdobytą broń starannie złożyli w przeznaczonych na to miejscach, a resztę łupów zanieśli do Jerozolimy.
###### **2Mch 8,32**
 Zabili też filarchę z otoczenia Tymoteusza, człowieka bardzo bezbożnego, który wyrządził Żydom wiele zła.
###### **2Mch 8,33**
 Gdy w ojczyźnie świętowali zwycięstwo, spalili tych, którzy podkładali ogień pod święte bramy, a także Kalistenesa, który ukrył się w pewnym domu. Otrzymał więc godną zapłatę za swoją podłość.
###### **2Mch 8,34**
 Nikanor zaś, ten największy nikczemnik, który sprowadził tysiąc handlarzy, aby im sprzedać Żydów,
###### **2Mch 8,35**
 z pomocą Pana został upokorzony przez tych, którymi gardził. Musiał porzucić swoją wspaniałą szatę i samotnie uciekać przez pola jak zbiegły niewolnik. Miał jednak tyle szczęścia, że chociaż jego wojsko zostało zniszczone, jemu udało się przedrzeć do Antiochii.
###### **2Mch 8,36**
 Ten, który obiecywał, że dzięki środkom ze sprzedaży w niewolę mieszkańców Jerozolimy zapłaci daninę należną Rzymianom, teraz ogłaszał, że Żydzi mają Obrońcę i z tego powodu są niepokonani, ponieważ kierują się ustanowionymi przez Niego prawami.
# 2Mch 8 BP
###### **2Mch 8,1**
 Juda Machabeusz i jego ludzie obchodzili potajemnie wioski i zwoływali krewnych oraz tych, którzy pozostali wierni judaizmowi. Zgromadzili tak około sześciu tysięcy ludzi.
###### **2Mch 8,2**
 Wzywali przy tym Pana, aby raczył wejrzeć na sponiewierany przez wszystkich lud i zmiłował się nad zbezczeszczoną przez bezbożników Świątynią,
###### **2Mch 8,3**
 by okazał litość ginącemu miastu, które wkrótce zniknie zrównane z ziemią, i wysłuchał krwi wołającej do Niego,
###### **2Mch 8,4**
 by wspomniał o bezprawnym mordowaniu niewinnych dzieci i bluźnierstwach miotanych przeciwko Jego Imieniu, oraz by [wreszcie] obrócił swą nienawiść przeciw złu.
###### **2Mch 8,5**
 Gdy Machabeusz ze [swoim] oddziałem wojska stał się niepokonany dla pogan, [widocznym było], że gniew Pana obrócił się w miłosierdzie.
###### **2Mch 8,6**
 Niespodziewanie wpadł do miast i wsi paląc je, zajmując dogodne miejsca, licznych nieprzyjaciół zmuszał do ucieczki.
###### **2Mch 8,7**
 Zwłaszcza noce wykorzystywał na takie wypady. Sława o jego dzielności docierała wszędzie.
###### **2Mch 8,8**
 Filip widząc, że mąż ten w krótkim czasie nie tylko osiągnął powodzenie, lecz szczęście coraz bardziej sprzyja jego poczynaniom, napisał do Ptolemeusza, zarządcy Celesyrii i Fenicji, wzywając jego pomocy w sprawach króla.
###### **2Mch 8,9**
 Ten natychmiast wybrał Nikanora, syna Patroklesa, jednego z najprzedniejszych przyjaciół [króla], i wysłał go na czele wojska złożonego z ludzi wszystkich narodowości, liczącego nie mniej niż dwadzieścia tysięcy, aby wytracił cały naród żydowski. Przydzielił mu także jego dowódcę Gorgiasza, człowieka doświadczonego w sztuce wojennej.
###### **2Mch 8,10**
 Nikanor liczył na to, że daninę dwóch tysięcy talentów, należną od króla Rzymianom, pokryje ze sprzedaży jeńców żydowskich.
###### **2Mch 8,11**
 Zaraz też wysłał do miast nadmorskich pismo zachęcające do kupowania niewolników żydowskich, przyrzekając oddać dziewięćdziesięciu ludzi za jeden talent. Nie przeczuwał jednak kary, jaka miała spaść na niego z ręki Wszechmocnego.
###### **2Mch 8,12**
 Skoro Juda dowiedział się o wymarszu Nikanora, powiadomił swoich ludzi o zbliżaniu się wojska.
###### **2Mch 8,13**
 Wówczas niektórzy zdjęci lękiem, a nie mający wiary w sprawiedliwość Bożą, uciekli i szukali nowego miejsca pobytu.
###### **2Mch 8,14**
 Inni zaś sprzedali wszystko, co im jeszcze zostało, i prosili Pana o ratunek dla tych, których bezbożny Nikanor sprzedał jeszcze przed walką.
###### **2Mch 8,15**
 Winien to uczynić, jeżeli nie przez wzgląd na nich - to przynajmniej na Przymierze zawarte z ich ojcami oraz ze względu na Jego pełne chwały i dostojeństwa Imię, wzywane przez nich.
###### **2Mch 8,16**
 Machabeusz zgromadził swoich ludzi w liczbie sześciu tysięcy i upomniał ich, aby nie lękali się nieprzyjaciół i nie przerazili się mnogości pogan, którzy napadają ich niesprawiedliwie, ale by dzielnie walczyli.
###### **2Mch 8,17**
 Niech mają przed oczyma zbrodnicze zbezczeszczenie Świętego miejsca oraz pohańbienie wyszydzonego miasta i obalenie ustanowionego przez przodków ustroju.
###### **2Mch 8,18**
 "Oni - mówił - zaufali broni i swej zuchwałości, my zaś pokładamy ufność w Bogu Wszechmogącym, zdolnym w mgnieniu oka zniszczyć jednym skinieniem nie tylko tych, którzy przeciwko nam ciągną, ale i cały świat".
###### **2Mch 8,19**
 Przypomniał im również pomoc udzielaną ojcom oraz jak zginęło sto osiemdziesiąt pięć tysięcy ludzi Sancheriba,
###### **2Mch 8,20**
 a także bitwę stoczoną w Babilonii z Galatami, kiedy to stanęło do walki ledwo osiem tysięcy Żydów wraz z czterema tysiącami Macedończyków, a gdy Macedończycy znaleźli się w trudnym położeniu, owe osiem tysięcy dzięki pomocy udzielonej im z Nieba rozgromiło sto dwadzieścia tysięcy nieprzyjaciół i zdobyło bogate łupy.
###### **2Mch 8,21**
 W ten sposób dodał im odwagi i sprawił, że gotowi byli umrzeć za prawa i ojczyznę. Wojsko podzielił na cztery oddziały.
###### **2Mch 8,22**
 Dowódcami poszczególnych oddziałów ustanowił swoich braci: Szymona, Józefa i Jonatana, przydzielając każdemu po tysiąc pięciuset ludzi.
###### **2Mch 8,23**
 Następnie polecił Eleazarowi odczytać świętą Księgę i podał hasło: "Z Bożą pomocą". Sam stanął na czele pierwszego oddziału i uderzył na Nikanora,
###### **2Mch 8,24**
 a że Wszechmocny był im sprzymierzeńcem, zabili ponad dziewięć tysięcy nieprzyjaciół, większą część żołnierzy Nikanora ranili i okaleczyli, wszystkich zaś zmusili do ucieczki.
###### **2Mch 8,25**
 Zabrali też pieniądze tym, którzy przybyli, aby ich kupić. Ścigali ich dość daleko, lecz potem musieli wracać ze względu na [późną] porę.
###### **2Mch 8,26**
 Był to bowiem dzień przed szabatem i dlatego nie mogli ich dłużej ścigać.
###### **2Mch 8,27**
 Kiedy zgromadzili broń wrogów i zabrali im łupy, świętowali szabat, błogosławiąc i wysławiając Pana za to, że aż do tego dnia wspomagał ich i znowu zaczął im okazywać miłosierdzie.
###### **2Mch 8,28**
 Po szabacie rozdali rannym, wdowom i sierotom należną im część łupów, resztę zaś rozdzielili między siebie i swoje dzieci.
###### **2Mch 8,29**
 Po dokonaniu tych czynności odprawili wspólne modły błagalne, prosząc Miłosiernego Pana, aby całkowicie pojednał się ze swymi sługami.
###### **2Mch 8,30**
 Walcząc z wojskami Tymoteusza i Bakchidesa zabili ponad dwadzieścia tysięcy [ludzi] i opanowali wysoko położone twierdze. Ogromne łupy podzielili i jednakowe części przyznali sobie samym, pokrzywdzonym przez wroga, wdowom, sierotom, a nawet starcom.
###### **2Mch 8,31**
 Zebrali broń [wroga] i złożyli starannie w dogodnych miejscach, resztę łupów zanieśli do Jerozolimy.
###### **2Mch 8,32**
 Z otoczenia Tymoteusza zabili filarchę, bardzo bezbożnego męża, który Żydom wyrządził wiele krzywd.
###### **2Mch 8,33**
 Gdy obchodzili w ojczyźnie święto zwycięstwa, spalili tych, którzy podpalili święte bramy, oraz Kallistenesa, szukającego schronienia w pewnym domu. Otrzymał więc godną zapłatę za swoją bezbożność.
###### **2Mch 8,34**
 Po trzykroć gorszy Nikanor, który sprowadził tysiąc handlarzy, aby im sprzedać Żydów,
###### **2Mch 8,35**
 został upokorzony dzięki pomocy Bożej przez tych, którymi najbardziej pogardzał. Zrzuciwszy wspaniałą szatę uchodził sam przez środek kraju bocznymi drogami niczym zbiegły niewolnik i przybył do Antiochii zgnębiony klęską swego wojska.
###### **2Mch 8,36**
 Ten, który zobowiązał się daninę należną Rzymianom pokryć z dochodów [uzyskanych ze sprzedaży] jeńców jerozolimskich, musiał przyznać, że Żydzi mają Obrońcę i dlatego są niezwyciężeni, że są posłuszni Prawom przez Niego ustanowionym.
# 2Mch 8 BR
###### **2Mch 8,1**
 Tymczasem Juda, zwany także Machabeuszem, przedostał się potajemnie razem ze swoimi ludźmi do różnych wiosek i gromadził wokół siebie swoich krewnych, a także tych, którzy pozostali wierni prawu. Z czasem zebrało się około sześciu tysięcy mężów.
###### **2Mch 8,2**
 Wołali oni o pomoc do Pana prosząc Go, żeby raczył wejrzeć na uciskany przez wszystkich naród, żeby się ulitował nad świątynią, którą zbezcześcili bezbożni,
###### **2Mch 8,3**
 żeby okazał swoje miłosierdzie nad miastem, które niszczeje i już wkrótce zostanie zrównane z ziemią, żeby zechciał wysłuchać krwi, która woła do Niego o pomstę,
###### **2Mch 8,4**
 żeby raczył wejrzeć na to, że wbrew wszelkiemu prawu mordowane są niewinne dzieci i znieważane jest Jego święte imię, żeby okazał, że nienawidzi zła.
###### **2Mch 8,5**
 Kiedy Machabeusz stanął na czele sporego oddziału wojowników, poganie nie byli w stanie go już powstrzymać, bo gniew Boży przemienił się w litość.
###### **2Mch 8,6**
 Niespodziewanie uderzał na miasta i wsie i puszczał je z dymem, a jeśli udało mu się zająć pogodną pozycję, zmuszał do ucieczki nawet wielkie oddziały wrogów.
###### **2Mch 8,7**
 Napadów dokonywał przeważnie nocą, a sława jego męstwa rozchodziła się szeroko.
###### **2Mch 8,8**
 Kiedy także Filip zauważył, że siła tego męża rośnie z dnia na dzień i że odnosi on coraz znaczniejsze zwycięstwa, napisał do Ptolemeusza, zarządcy Celesyrii i Fenicji, wyraźnie go prosząc, aby zechciał wesprzeć sprawy króla.
###### **2Mch 8,9**
 A ten natychmiast wyznaczył Nikanora, syna Patroklesa, należącego do grona najbliższych przyjaciół króla, i kazał mu objąć dowództwo nad wojskiem w liczbie co najmniej dwudziestu tysięcy ludzi pochodzących z różnych krajów i wytracić cały naród żydowski. Dodał mu także do pomocy Gorgiasza, jednego z dowódców najbardziej doświadczonych w sztuce wojennej.
###### **2Mch 8,10**
 A król musiał wypłacić Rzymianom jeszcze dwa tysiące talentów [tytułem odszkodowań wojennych]. Otóż Nikanor postanowił uzyskać tę sumę ze sprzedaży wziętych do niewoli Żydów.
###### **2Mch 8,11**
 Niezwłocznie też powiadomił różne miasta nadmorskie, że będzie w nich można zakupić żydowskich niewolników. Obiecywał dać za jeden talent dziewięćdziesięciu niewolników. Ani przez chwilę nie przeczuwał, jaką karę wypadnie mu już wkrótce ponieść z rąk Wszechmocnego.
###### **2Mch 8,12**
 Kiedy Juda usłyszał o wymarszu Nikanora i ogłosił swoim wojownikom, że Nikanor nadciąga z wojskiem,
###### **2Mch 8,13**
 tchórzliwsi i nie pokładający ufności w sprawiedliwości Boga rozbiegli się i uciekli.
###### **2Mch 8,14**
 Inni natomiast sprzedawali wszystko, co jeszcze posiadali i błagali Pana o ratunek przed bezbożnikiem Nikanorem, który sprzedał ich w niewolę, zanim z nimi stoczył bitwę.
###### **2Mch 8,15**
 Błagali Pana o ratunek - jeżeli już nie ze względu na siebie samych, to przynajmniej na przymierze, które kiedyś zawarł On z ich ojcami, oraz ze względu na wzywane nad nimi Jego święte i chwalebne imię.
###### **2Mch 8,16**
 Wszystkich wojowników zgromadzonych wokół Machabeusza było sześć tysięcy. Machabeusz upominał ich, żeby się nie przerażali samym widokiem wroga ani wielką liczbą pogan, którzy ich niesprawiedliwie napadają, i żeby dzielnie walczyli.
###### **2Mch 8,17**
 Niech pamiętają o tym, że ten wróg zuchwale i wbrew wszelkiemu prawu zbezcześcił święte miejsce, sponiewierał karygodnie całe miasto i usiłował usunąć wszystkie obyczaje odziedziczone po ojcach.
###### **2Mch 8,18**
 Dodał ponadto: Całą ufność pokładają w swojej broni i w pewności siebie, my zaś zaufaliśmy wszechmogącemu Bogu, który ma moc i naszych napastników, i cały świat unicestwić jednym skinieniem.
###### **2Mch 8,19**
 Potem przypomniał im, ile to razy Bóg wspierał ich ojców. Między innymi mówił o walce przeciwko Sennacherybowi, kiedy to poległo sto osiemdziesiąt pięć tysięcy wojowników nieprzyjacielskich,
###### **2Mch 8,20**
 i o bitwie z Galatami w Babilonie, do której przystąpiło zaledwie osiem tysięcy Żydów i cztery tysiące Macedończyków, a gdy przerażeni Macedończycy znaleźli się w trudnej sytuacji, tym ośmiu tysiącom udało się dzięki pomocy Niebios pokonać wojsko liczące sto dwadzieścia tysięcy wojowników, a nawet wziąć obfite łupy.
###### **2Mch 8,21**
 I tak oto dodał im odwagi, że byli gotowi umrzeć w obronie prawa i ojczyzny. Następnie podzielił ich na cztery oddziały.
###### **2Mch 8,22**
 Na czele każdego oddziału postawił jednego ze swoich braci, to jest Szymona, Józefa, Jonatana, przydzielając każdemu z nich tysiąc pięciuset ludzi.
###### **2Mch 8,23**
 Dowódcą podobnego oddziału był także Eleazar. On sam zaś odczytał im pewien fragment z ksiąg świętych i zawołał: Z Bożą pomocą!, i stanąwszy przed pierwszym oddziałem ruszył na Nikanora.
###### **2Mch 8,24**
 Ponieważ Wszechmocny pomagał im w walce, położyli trupem więcej niż dziewięć tysięcy wojowników nieprzyjacielskich, większość wojowników Nikanora odniosła rany i okaleczenia, reszta zaś jego wojsk zmuszona była ratować się ucieczką.
###### **2Mch 8,25**
 Przy okazji zagarnęli też jako łup wszystkie pieniądze tych, którzy przybyli, żeby ich zakupić [po przegranej bitwie] jako niewolników. Potem dość daleko ścigali resztki wrogów, ale ostatecznie musieli zaprzestać pościgu z powodu późnej pory.
###### **2Mch 8,26**
 Zbliżał się bowiem dzień szabatu i dlatego nie mogli się zapuścić zbyt daleko.
###### **2Mch 8,27**
 Zabrali wrogom wszystką broń i pościągali z zabitych zbroje. A potem obchodzili uroczyście szabat, goręcej niż zwykle wielbiąc z radością Pana i wychwalając Jego wielkie dzieła. To bowiem dzięki Jego pomocy przeżyli ten dzień w którym On znowu zaczął im okazywać łaskawość.
###### **2Mch 8,28**
 Gdy minął szabat, część łupu podzielili między rannych, wdowy i sieroty, a to, co pozostało, rozdzielili między siebie i swoje dzieci.
###### **2Mch 8,29**
 Potem odprawili wspólne modły błagalne, prosząc miłosiernego Pana, żeby dał się ostatecznie przejednać swoim sługom.
###### **2Mch 8,30**
 Prowadzili walki także z oddziałami Tymoteusza i Bakchidesa. Zabili więcej niż dwadzieścia tysięcy wojowników nieprzyjacielskich i zdobyli kilka warowni położonych wysoko w górach. Obfite łupy rozdzielili sprawiedliwie między siebie, poszkodowanych przez wojnę, a także sieroty, wdowy i ludzi starych.
###### **2Mch 8,31**
 Pobitym zabrali wszelką broń i przechowywali ją starannie w zabezpieczonych miejscach, a resztę łupów przekazywali do Jerozolimy.
###### **2Mch 8,32**
 Zabili także filarchę, wielkiego bezbożnika, jednego z otoczenia Tymoteusza; ów filarcha uczynił wiele złego Żydom.
###### **2Mch 8,33**
 Później, kiedy już w swoim rodzinnym mieście uroczyście obchodzili zwycięstwo, spalili tych, którzy podłożyli ogień pod bramy świątyni. Był między nimi także Kallistenes, który schronił się w pewnym domku. I tak otrzymali oni wszyscy sprawiedliwą zapłatę za swoją niegodziwość.
###### **2Mch 8,34**
 Natomiast trzykroć przeklęty Nikanor, ten, który przywiódł ze sobą tysiąc handlarzy mających zakupić Żydów jako niewolników,
###### **2Mch 8,35**
 został mocą Pana poniżony przez tych, których tak bardzo znieważył: musiał pozbyć się swoich bogatych szat i jak zbiegły niewolnik sam jeden przedzierać się przez cały kraj do Antiochii, upadły zupełnie na duchu z powodu utraty wszystkich swoich wojowników.
###### **2Mch 8,36**
 Ten, który przyrzekł Rzymianom, że należny im dług pokryje ze sprzedaży wziętych do niewoli jeńców jerozolimskich, był zmuszony teraz przyznać, że Żydzi mają Kogoś, kto za nich walczy, i dlatego nie można ich pokonać. Przestrzegają bowiem dokładnie praw, które On ustanowił.
# 2Mch 8 WUJ
