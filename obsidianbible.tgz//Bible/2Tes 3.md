# 2Tes 3 BT5
###### **2Tes 3,1**
 Na koniec, bracia, módlcie się za nas, by słowo Pańskie szerzyło się i rozsławiało, podobnie jak to jest pośród was,
###### **2Tes 3,2**
 abyśmy byli wybawieni od ludzi przewrotnych i złych, albowiem nie wszyscy mają wiarę.
###### **2Tes 3,3**
 Wierny jest Pan, który umocni was i ustrzeże od złego.
###### **2Tes 3,4**
 Co do was, ufamy w Panu, że to, co nakazujemy, czynicie i będziecie czynić.
###### **2Tes 3,5**
 Niechaj Pan skieruje serca wasze ku miłości Bożej i cierpliwości Chrystusowej.
###### **2Tes 3,6**
 Nakazujemy wam, bracia, w imię Pana naszego, Jezusa Chrystusa, abyście stronili od każdego brata, który postępuje wbrew porządkowi, a nie zgodnie z tradycją, którą przejęliście od nas.
###### **2Tes 3,7**
 Sami bowiem wiecie, jak należy nas naśladować, bo nie wzbudzaliśmy wśród was niepokoju
###### **2Tes 3,8**
 ani u nikogo nie jedliśmy za darmo chleba, ale pracowaliśmy w trudzie i zmęczeniu, we dnie i w nocy, aby dla nikogo z was nie być ciężarem.
###### **2Tes 3,9**
 Nie żebyśmy nie mieli do tego prawa, lecz po to, aby dać wam samych siebie za przykład do naśladowania.
###### **2Tes 3,10**
 Albowiem gdy byliśmy u was, nakazywaliśmy wam tak: Kto nie chce pracować, niech też nie je!
###### **2Tes 3,11**
 Słyszymy bowiem, że niektórzy wśród was postępują wbrew porządkowi: wcale nie pracują, lecz zajmują się rzeczami niepotrzebnymi.
###### **2Tes 3,12**
 Tym przeto nakazujemy i napominamy ich w Panu Jezusie Chrystusie, aby pracując ze spokojem, własny chleb jedli.
###### **2Tes 3,13**
 Wy zaś, bracia, nie zniechęcajcie się w czynieniu dobrze.
###### **2Tes 3,14**
 Jeżeli ktoś nie posłucha słów naszego listu, tego sobie zaznaczcie i nie przestawajcie z nim, aby się zawstydził.
###### **2Tes 3,15**
 A nie uważajcie go za nieprzyjaciela, lecz jak brata napominajcie.
###### **2Tes 3,16**
 A sam Pan pokoju niech was darzy pokojem zawsze i we wszelki sposób. Pan niech będzie z wami wszystkimi!
###### **2Tes 3,17**
 Pozdrowienie ręką moją – Pawła. Ten znak jest w każdym liście: Tak piszę.
###### **2Tes 3,18**
 Łaska Pana naszego, Jezusa Chrystusa, [niech będzie] z wami wszystkimi!
# 2Tes 3 PAU
###### **2Tes 3,1**
 Ponadto, bracia, módlcie się za nas, aby słowo Pańskie rozszerzało się i było chwalone, tak jak u was,
###### **2Tes 3,2**
 oraz abyśmy zostali ocaleni od złych i przewrotnych ludzi, bo nie wszyscy wierzą.
###### **2Tes 3,3**
 Pan jest wierny! On was umocni i uchroni od złego.
###### **2Tes 3,4**
 Co do was, jesteśmy przekonani w Panu, że to, co wam nakazaliśmy, czynicie i nadal będziecie czynić.
###### **2Tes 3,5**
 Niech Pan kieruje wasze serca ku miłości Bożej i wytrwałości na wzór Chrystusa.
###### **2Tes 3,6**
 Nakazujemy wam, bracia, w imię naszego Pana Jezusa Chrystusa: Unikajcie każdego brata, który jest nieposłuszny i nie postępuje zgodnie z tradycją, którą przejęliście od nas.
###### **2Tes 3,7**
 Sami wiecie, jak trzeba nas naśladować, bo nie próżnowaliśmy u was.
###### **2Tes 3,8**
 Chleba nie jedliśmy u nikogo za darmo, ale pracowaliśmy dniem i nocą w trudzie i znoju, aby dla nikogo z was nie być ciężarem.
###### **2Tes 3,9**
 Nie żebyśmy nie mieli do tego prawa, ale chcieliśmy dać wam samych siebie jako przykład do naśladowania.
###### **2Tes 3,10**
 Gdy bowiem byliśmy u was, nakazywaliśmy: „Kto nie chce pracować, niech też nie je!”.
###### **2Tes 3,11**
 Słyszymy bowiem, że niektórzy u was próżnują. Nie pracują, lecz udają, że pracują.
###### **2Tes 3,12**
 Nakazujemy im i upominamy ich w Panu Jezusie Chrystusie, aby pracując spokojnie, jedli własny chleb.
###### **2Tes 3,13**
 Wy zaś, bracia, nie zniechęcajcie się w czynieniu dobra.
###### **2Tes 3,14**
 Jeśli ktoś nie posłucha słów naszego listu, zapamiętajcie go sobie i nie przestawajcie z nim, aby się zawstydził.
###### **2Tes 3,15**
 Nie uważajcie go jednak za wroga, lecz upominajcie jak brata.
###### **2Tes 3,16**
 Sam Pan pokoju niech was darzy pokojem zawsze i na wszelki sposób! Pan z wami wszystkimi!
###### **2Tes 3,17**
 Pozdrowienie piszę własnoręcznie - ja, Paweł. Ten znak stawiam w każdym liście. Tak piszę.
###### **2Tes 3,18**
 Łaska naszego Pana Jezusa Chrystusa z wami wszystkimi!
# 2Tes 3 BP
###### **2Tes 3,1**
 Poza tym, bracia, módlcie się za nas, aby nauka Pańska rozszerzała się i zdobywała uznanie, jak to było i u was.
###### **2Tes 3,2**
 Módlcie się, abyśmy zostali uwolnieni od ludzi przewrotnych i złośliwych, nie wszyscy bowiem wierzą.
###### **2Tes 3,3**
 Trzeba zawierzyć Panu, który was utwierdzi i zachowa od zła.
###### **2Tes 3,4**
 Mamy do was zaufanie w Panu, że postępujecie i będziecie postępowali zgodnie z tym, co wam głosiliśmy.
###### **2Tes 3,5**
 A Pan niech serca wasze skłoni do miłości Boga i cierpliwości Chrystusowej.
###### **2Tes 3,6**
 Bracia! W imię Pana naszego Jezusa Chrystusa nakazujemy wam, unikajcie każdego brata, który narusza porządek i nie postępuje zgodnie z podaną wam przez nas nauką.
###### **2Tes 3,7**
 Sami bowiem wiecie, jak nas macie naśladować; nie wzbudzaliśmy wśród was niepokoju
###### **2Tes 3,8**
 ani u nikogo nie jedliśmy chleba za darmo, lecz pracowaliśmy dniem i nocą w trudzie i mozole, aby nikomu z was nie być ciężarem.
###### **2Tes 3,9**
 Nie dlatego, żebyśmy nie mieli do tego prawa, lecz aby dać wam przykład do naśladowania.
###### **2Tes 3,10**
 Tak wam bowiem nakazywaliśmy, będąc u was: kto nie chce pracować, niech też i nie je!
###### **2Tes 3,11**
 Słyszymy, że niektórzy z was oddają się próżniactwu, zamiast pracować tracą czas na błahostki.
###### **2Tes 3,12**
 Tych surowo napominamy w Panu Jezusie Chrystusie, żeby spokojnie pracując własny chleb jedli.
###### **2Tes 3,13**
 Wy zaś, bracia, nie zniechęcajcie się w spełnianiu dobrych uczynków,
###### **2Tes 3,14**
 a jeśli ktoś nie posłucha słów naszego listu, zapamiętajcie go sobie i nie szukajcie jego towarzystwa, niech się zawstydzi!
###### **2Tes 3,15**
 Lecz nie uważajcie go za wroga, ale upominajcie jak brata.
###### **2Tes 3,16**
 Sam Pan pokoju niech da wam pokój zawsze i wszędzie. Niech Pan będzie z wami wszystkimi.
###### **2Tes 3,17**
 Ręką moją Pawłową kreślę pozdrowienie. To jest mój znak w każdym liście. Tak piszę.
###### **2Tes 3,18**
 Łaska Pana naszego Jezusa Chrystusa z wami wszystkimi.
# 2Tes 3 BR
###### **2Tes 3,1**
 Na koniec, bracia, módlcie się za nas, aby [głoszone przez nas] słowo Pańskie rozchodziło się i było przyjmowane z szacunkiem [wśród innych], tak jak pośród was.
###### **2Tes 3,2**
 [Módlcie się również], abyśmy zostali uwolnieni od ludzi przewrotnych i złych. Wiadomo przecież, że nie wszyscy mają wiarę.
###### **2Tes 3,3**
 Ale Pan jest wierny! On wam udzieli koniecznych sił i ustrzeże was od złego.
###### **2Tes 3,4**
 W Nim również pokładamy nadzieję, że to, co wam nakazujemy, czynicie i nadal będziecie czynić.
###### **2Tes 3,5**
 Niech Pan kieruje serca wasze ku umiłowaniu Boga i ku cierpliwości, której dawcą jest Chrystus.
###### **2Tes 3,6**
 Nakazujemy wam, bracia, w imię Pana naszego Jezusa Chrystusa, abyście stronili od każdego brata, który gnuśnieje bezczynnie i lekceważy sobie pouczenia, jakie otrzymaliście od nas.
###### **2Tes 3,7**
 Wiecie przecież, jak powinniście żyć, by można było powiedzieć, że nas naśladujecie: nie byliśmy wśród was bezczynni,
###### **2Tes 3,8**
 u nikogo nie jedliśmy chleba za darmo lecz pracowaliśmy, umęczeni i utrudzeni, we dnie i w nocy, byle tylko dla nikogo spośród was nie być ciężarem.
###### **2Tes 3,9**
 Postępowaliśmy zaś tak nie dlatego, że nie mieliśmy prawa [do waszej pomocy], lecz dlatego, że pragnęliśmy dać wam samych siebie za przykład do naśladowania.
###### **2Tes 3,10**
 Przebywając bowiem wśród was mawialiśmy wam [często]: 'Kto nie chce pracować, ten niech też i nie je'.
###### **2Tes 3,11**
 Tymczasem słyszymy, że niektórzy spośród was nie liczą się wcale z ustalonym porządkiem: nie pracują w ogóle, lecz zajmują się ciągle niepotrzebnymi sprawami.
###### **2Tes 3,12**
 Otóż takich pragniemy przywołać do porządku, polecając im z całą stanowczością, w imię Pana Jezusa Chrystusa, aby zabrali się spokojnie do pracy, by mogli spożywać chleb własny.
###### **2Tes 3,13**
 Wy zaś, bracia, nie ustawajcie w czynieniu dobrze.
###### **2Tes 3,14**
 Jeżeli ktoś nie usłucha poleceń zawartych w tym liście, tego zapamiętajcie sobie dobrze i dla zawstydzenia go starajcie się nie mieć z nim nic wspólnego.
###### **2Tes 3,15**
 Nie uważajcie go zaraz za wroga, lecz raczej upominajcie go jak brata.
###### **2Tes 3,16**
 Sam zaś Pan, który jest dawcą pokoju, niech was darzy pokojem zawsze i na wszelki sposób. Pan [niech będzie] z wami wszystkimi!
###### **2Tes 3,17**
 A oto pozdrowienie, które kreślę własną rękę. W ten sposób podpisuję każdy mój list.
###### **2Tes 3,18**
 Łaska Pana naszego Jezusa Chrystusa niech będzie z wami wszystkimi!
# 2Tes 3 WUJ
###### **2Tes 3,1**
 Na ostatek bracia, módlcie się za nas, aby mowa Boża bieżała i była wsławiona, jako i u was:
###### **2Tes 3,2**
 I abyśmy byli wyzwoleni od niespokojnych i złośliwych ludzi: abowiem nie wszystkich jest wiara.
###### **2Tes 3,3**
 A wierny jest Bóg, który was utwierdzi i strzedz będzie od złego.
###### **2Tes 3,4**
 A dufamy o was w Panu, iż co rozkazujemy, i czynicie, i czynić będziecie.
###### **2Tes 3,5**
 A Pan niech prostuje serca wasze w miłości Bożej, i w cierpliwości Chrystusowej.
###### **2Tes 3,6**
 A opowiadamy wam bracia w imię Pana naszego Jezusa Chrystusa, iżbyście się odłączyli od każdego brata nieporządnie chodzącego, a nie według podania, które wzięli od nas.
###### **2Tes 3,7**
 Abowiem sami wiecie jako nas potrzeba naśladować: gdyżeśmy nie byli niespokojni między wami:
###### **2Tes 3,8**
 Aniśmy chleba darmo, od którego pożywali, ale w pracy i w utrudzeniu w nocy i we dnie robiąc, abyśmy którego z was nie obciążyli.
###### **2Tes 3,9**
 Nie jakobyśmy byli mocy nie mieli, ale żebyśmy wam sami siebie na wzór dali, abyście nas naśladowali.
###### **2Tes 3,10**
 Abowiem i gdyśmy byli u was, tośmy wam opowiadali: iż jeśli kto nie chce robić, niech też nie je.
###### **2Tes 3,11**
 Bo słyszeliśmy, iż niektórzy niespokojnie chodzą między wami, nic nie robiąc ale dwornie się sprawując.
###### **2Tes 3,12**
 A tym, którzy takowi są, opowiadamy, i prosimy przez Pana Jezusa Chrystusa, aby z milczeniem robiąc swój chleb jedli.
###### **2Tes 3,13**
 A wy bracia nie ustawajcie dobrze czyniąc.
###### **2Tes 3,14**
 A jeśli kto jest nieposłuszny słowu naszemu, przez list tego naznaczcie, a nie mieszajcie się z nim, aby się zawstydził:
###### **2Tes 3,15**
 A nie poczytajcie jako nieprzyjaciela, ale upominajcie jako brata.
###### **2Tes 3,16**
 A sam Pan pokoju niech wam da pokój wieczny na wszelkiem miejscu. Pan niechaj będzie z wami wszystkimi.
###### **2Tes 3,17**
 Pozdrowienie, ręką moją Pawłową, który jest znak w każdym liście, tak piszę.
###### **2Tes 3,18**
 Łaska Pana naszego Jezusa Chrystusa z wami wszystkimi, Amen.1
# 2Tes 3 STERN
###### **2Tes 3,1**
 W końcu, bracia, módlcie się za nas, aby orędzie Pana szerzyło się szybko i cieszyło się czcią, tak jak to się stało u was,
###### **2Tes 3,2**
 i abyśmy zostali ocaleni od niegodziwych i złych ludzi, bo nie każdy ma ufność.
###### **2Tes 3,3**
 Lecz Pan godzien jest zaufania; On was ugruntuje i będzie strzegł przed Złym.
###### **2Tes 3,4**
 Tak jest, zjednoczeni z Panem, mamy pewność co do was, że czynicie to, co wam nakazujemy, i że nadal będziecie to czynić.
###### **2Tes 3,5**
 Niech Pan kieruje wasze serca ku miłości Bożej i wytrwałości, jaką daje Mesjasz.
###### **2Tes 3,6**
 A teraz w imię Pana Jeszui Mesjasza nakazujemy wam, bracia, abyście trzymali się z dala od każdego brata, który żyje próżniaczo, nie zaś zgodnie z tradycją, jaką od nas otrzymaliście.
###### **2Tes 3,7**
 Bo sami wiecie, jak macie nas naśladować, bo będąc wśród was, nie próżnowaliśmy.
###### **2Tes 3,8**
 Nie przyjmowaliśmy od nikogo jedzenia bez zapłaty, przeciwnie, trudziliśmy się i mozolili dzień i noc, pracując po to, aby nikomu z was nie być ciężarem.
###### **2Tes 3,9**
 Nie znaczy to, że nie mieliśmy prawa do wsparcia, ale chcieliśmy być przykładem do naśladowania.
###### **2Tes 3,10**
 Bo nawet gdy byliśmy wśród was, daliśmy wam ten nakaz: jak ktoś nie chce pracować, to i nie powinien jeść!
###### **2Tes 3,11**
 Słyszymy, że niektórzy z was wiodą życie próżniaczo - zajmuje ich nie praca, ale intrygowanie!
###### **2Tes 3,12**
 Takim osobom nakazujemy - i w jedności z Panem Jeszuą Mesjaszem nalegamy - aby się uspokoiły, zabrały do roboty i same zarabiały na swój chleb.
###### **2Tes 3,13**
 Wy zaś, bracia, którzy robicie to, co należy, nie osiadajcie na laurach!
###### **2Tes 3,14**
 A zwróćcie uwagę na takiego, kto nie przestrzega tego, co mówimy w tym liście, i nie przestawajcie z nim, aby się zawstydził.
###### **2Tes 3,15**
 Ale nie miejcie go za wroga, przeciwnie, napominajcie go jak brata i starajcie się pomóc mu się zmienić.
###### **2Tes 3,16**
 A niech Pan szalomu sam zawsze daje wam szalom pod każdym względem. Niech Pan będzie z wami wszystkimi.
###### **2Tes 3,17**
 Pozdrowienie moim własnym pismem: Od Sza'ula. To jest znak autentyczności w każdym liście, tak wygląda moje pismo.
###### **2Tes 3,18**
 Łaska Pana naszego Jeszui Mesjasza niech będzie z wami wszystkimi.1
# 2Tes 3 TRO
###### **2Tes 3,1**
 **το** *to* [[G3588]] WTT-NSN **λοιπον** *loipon* W końcu [[G3063]] WTA-NSN **προσευχεσθε** *proseuchesthe* módlcie się [[G4336]] WTV-PNM-2P **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **περι** *peri* za [[G4012]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP **ινα** *hina* aby [[G2443]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **λογος** *logos* Słowo [[G3056]] [[N-NSM]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **τρεχη** *trechē* biegłoby [[G5143]] WTV-PAS-3S **και** *kai* i [[G2532]] [[CONJ]] **δοξαζηται** *doksazētai* byłoby otaczane chwałą [[G1392]] WTV-PPS-3S **καθως** *kathōs* jak [[G2531]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **προς** *pros* przy [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP
###### **2Tes 3,2**
 **και** *kai* i [[G2532]] [[CONJ]] **ινα** *hina* aby [[G2443]] [[CONJ]] **ρυσθωμεν** *rysthōmen* zostalibyśmy wybawieni – zostalibyśmy wyrwani [[G4506]] WTV-APS-1P **απο** *apo* z [[G575]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **ατοπων** *atopōn* przewrotnych – będących nie na miejscu [[G824]] WTA-GPM **και** *kai* i [[G2532]] [[CONJ]] **πονηρων** *ponērōn* niegodziwych – złych [[G4190]] WTA-GPM **ανθρωπων** *anthrōpōn* ludzi [[G444]] WTN-GPM **ου** *ou* nie [[G3756]] [[PRT-N]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **παντων** *pantōn* wszystkich [[G3956]] WTA-GPM **η** *hē* [[G3588]] [[T-NSF]] **πιστις** *pistis* wiara [[G4102]] [[N-NSF]]
###### **2Tes 3,3**
 **πιστος** *pistos* Wierny [[G4103]] [[A-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **ος** *hos* który [[G3739]] WTR-NSM **στηριξει** *stēriksei* utwierdzi – postawi mocno [[G4741]] WTV-FAI-3S **υμας** *hymas* was [[G5209]] WTP-2AP **και** *kai* i [[G2532]] [[CONJ]] **φυλαξει** *fylaksei* ustrzeże [[G5442]] WTV-FAI-3S **απο** *apo* od [[G575]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **πονηρου** *ponērou* niegodziwego – złego [[G4190]] WTA-GSM
###### **2Tes 3,4**
 **πεποιθαμεν** *pepoithamen* Jesteśmy przekonani – Pokładamy ufność [[G3982]] WTV-2RAI-1P **δε** *de* zaś [[G1161]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **εφ** *ef* do [[G1909]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **οτι** *hoti* że [[G3754]] [[CONJ]] **α** *ha* co [[G3739]] WTR-APN **παραγγελλομεν** *parangellomen* nakazujemy [[G3853]] WTV-PAI-1P **υμιν** *hymin* wam [[G5213]] WTP-2DP **και** *kai* i [[G2532]] [[CONJ]] **ποιειτε** *poieite* czynicie [[G4160]] WTV-PAI-2P **και** *kai* i [[G2532]] [[CONJ]] **ποιησετε** *poiēsete* będziecie czynić [[G4160]] WTV-FAI-2P
###### **2Tes 3,5**
 **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **κατευθυναι** *kateuthynai* oby wyprostował [[G2720]] WTV-AAO-3S **υμων** *hymōn* wasze [[G5216]] WTP-2GP **τας** *tas* [[G3588]] WTT-APF **καρδιας** *kardias* serca [[G2588]] WTN-APF **εις** *eis* ku [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **αγαπην** *agapēn* miłości [[G26]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **εις** *eis* do [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **υπομονην** *hypomonēn* wytrwałości – cierpliwości [[G5281]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **2Tes 3,6**
 **παραγγελλομεν** *parangellomen* Nakazujemy [[G3853]] WTV-PAI-1P **δε** *de* zaś [[G1161]] [[CONJ]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **εν** *en* w [[G1722]] [[PREP]] **ονοματι** *onomati* imieniu [[G3686]] WTN-DSN **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **στελλεσθαι** *stellesthai* (by) unikać – (by) odłączyć [[G4724]] WTV-PMN **υμας** *hymas* wy [[G5209]] WTP-2AP **απο** *apo* od [[G575]] [[PREP]] **παντος** *pantos* każdego [[G3956]] WTA-GSM **αδελφου** *adelfou* brata [[G80]] [[N-GSM]] **ατακτως** *ataktōs* bez trzymania się szyku [[G814]] [[ADV]] **περιπατουντος** *peripatountos* postępującego – chodzącego [[G4043]] WTV-PAP-GSM **και** *kai* i [[G2532]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **κατα** *kata* według [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **παραδοσιν** *paradosin* przekazu – tradycji [[G3862]] WTN-ASF **ην** *hēn* który [[G3739]] WTR-ASF **παρελαβεν** *parelaben* wziął – przyjął [[G3880]] WTV-2AAI-3S **παρ** *par* od [[G3844]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP
###### **2Tes 3,7**
 **αυτοι** *autoi* Sami [[G846]] WTP-NPM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **οιδατε** *oidate* wiecie [[G1492]] WTV-RAI-2P **πως** *pōs* jak [[G4459]] [[ADV]] **δει** *dei* trzeba – jest konieczne [[G1163]] WTV-PQI-3S **μιμεισθαι** *mimeisthai* naśladować [[G3401]] WTV-PNN **ημας** *hēmas* nas [[G2248]] WTP-1AP **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ητακτησαμεν** *ētaktēsamen* nieporządnie – nie utrzymaliśmy się w szyku [[G812]] WTV-AAI-1P **εν** *en* wśród [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP
###### **2Tes 3,8**
 **ουδε** *oude* ani [[G3761]] [[ADV]] **δωρεαν** *dōrean* darmo [[G1432]] [[ADV]] **αρτον** *arton* chleb [[G740]] [[N-ASM]] **εφαγομεν** *efagomen* zjedliśmy [[G5315]] WTV-2AAI-1P **παρα** *para* u [[G3844]] [[PREP]] **τινος** *tinos* kogoś [[G5100]] WTX-GSM **αλλ** *all* ale [[G235]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **κοπω** *kopō* trudzie [[G2873]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **μοχθω** *mochthō* mozole – znoju [[G3449]] WTN-DSM **νυκτα** *nykta* nocą [[G3571]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **ημεραν** *hēmeran* dniem [[G2250]] WTN-ASF **εργαζομενοι** *ergazomenoi* pracując [[G2038]] WTV-PNP-NPM **προς** *pros* ku [[G4314]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **μη** *mē* nie [[G3361]] [[PRT-N]] **επιβαρησαι** *epibarēsai* obciążyć [[G1912]] [[V-AAN]] **τινα** *tina* kogoś [[G5100]] WTX-ASM **υμων** *hymōn* (z) was [[G5216]] WTP-2GP
###### **2Tes 3,9**
 **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **οτι** *hoti* że [[G3754]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εχομεν** *echomen* mamy [[G2192]] WTV-PAI-1P **εξουσιαν** *eksousian* władzy – prawa [[G1849]] WTN-ASF **αλλ** *all* ale [[G235]] [[CONJ]] **ινα** *hina* aby [[G2443]] [[CONJ]] **εαυτους** *heautous* siebie samych [[G1438]] WTF-3APM **τυπον** *typon* (jako) przykład – (jako) wzór [[G5179]] [[N-ASM]] **δωμεν** *dōmen* dalibyśmy [[G1325]] WTV-2AAS-1P **υμιν** *hymin* wam [[G5213]] WTP-2DP **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **μιμεισθαι** *mimeisthai* naśladować [[G3401]] WTV-PNN **ημας** *hēmas* nas [[G2248]] WTP-1AP
###### **2Tes 3,10**
 **και** *kai* i [[G2532]] [[CONJ]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **οτε** *hote* gdy [[G3753]] [[ADV]] **ημεν** *ēmen* byliśmy [[G1510]] WTV-IXI-1P **προς** *pros* przy [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **τουτο** *touto* to [[G5124]] WTD-ASN **παρηγγελλομεν** *parēngellomen* nakazywaliśmy [[G3853]] WTV-IAI-1P **υμιν** *hymin* wam [[G5213]] WTP-2DP **οτι** *hoti* że [[G3754]] [[CONJ]] **ει** *ei* jeśli [[G1487]] WTCOND **τις** *tis* ktoś [[G5100]] WTX-NSM **ου** *ou* nie [[G3756]] [[PRT-N]] **θελει** *thelei* chce [[G2309]] WTV-PAI-3S **εργαζεσθαι** *ergazesthai* pracować [[G2038]] WTV-PNN **μηδε** *mēde* ani nie [[G3366]] [[CONJ]] **εσθιετω** *esthietō* niech je [[G2068]] WTV-PAM-3S
###### **2Tes 3,11**
 **ακουομεν** *akouomen* Słyszymy [[G191]] WTV-PAI-1P **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **τινας** *tinas* (o) niektórych [[G5100]] WTX-APM **περιπατουντας** *peripatountas* postępujących [[G4043]] WTV-PAP-APM **εν** *en* wśród [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **ατακτως** *ataktōs* bez trzymania się szyku [[G814]] [[ADV]] **μηδεν** *mēden* (jako) nie [[G3367]] WTA-ASN **εργαζομενους** *ergazomenous* wypracowujących [[G2038]] WTV-PNP-APM **αλλα** *alla* ale [[G235]] [[CONJ]] **περιεργαζομενους** *periergazomenous* pracujących bezużytecznie – będąc wścibskimi [[G4020]] WTV-PNP-APM
###### **2Tes 3,12**
 **τοις** *tois* [[G3588]] WTT-DPM **δε** *de* zaś [[G1161]] [[CONJ]] **τοιουτοις** *toioutois* takim [[G5108]] WTD-DPM **παραγγελλομεν** *parangellomen* nakazujemy [[G3853]] WTV-PAI-1P **και** *kai* i [[G2532]] [[CONJ]] **παρακαλουμεν** *parakaloumen* prosimy – zachęcamy [[G3870]] WTV-PAI-1P **δια** *dia* przez [[G1223]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **μετα** *meta* ze [[G3326]] [[PREP]] **ησυχιας** *hēsychias* spokojem – cichością [[G2271]] [[N-GSF]] **εργαζομενοι** *ergazomenoi* pracując [[G2038]] WTV-PNP-NPM **τον** *ton* [[G3588]] [[T-ASM]] **εαυτων** *heautōn* swój [[G1438]] WTF-3GPM **αρτον** *arton* chleb [[G740]] [[N-ASM]] **εσθιωσιν** *esthiōsin* jedliby [[G2068]] WTV-PAS-3P
###### **2Tes 3,13**
 **υμεις** *hymeis* Wy [[G5210]] WTP-2NP **δε** *de* zaś [[G1161]] [[CONJ]] **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **μη** *mē* nie [[G3361]] [[PRT-N]] **εκκακησητε** *ekkakēsēte* zniechęcalibyście się – słalibyście się słabymi [[G1573]] WTV-AAS-2P **καλοποιουντες** *kalopoiountes* dobrze czyniąc – pięknie czyniąc [[G2569]] WTV-PAP-NPM
###### **2Tes 3,14**
 **ει** *ei* Jeśli [[G1487]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **τις** *tis* ktoś [[G5100]] WTX-NSM **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **υπακουει** *hypakouei* jest posłuszny [[G5219]] WTV-PAI-3S **τω** *tō* [[G3588]] WTT-DSM **λογω** *logō* słowu [[G3056]] WTN-DSM **ημων** *hēmōn* naszemu [[G2257]] WTP-1GP **δια** *dia* przez [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **επιστολης** *epistolēs* list [[G1992]] [[N-GSF]] **τουτον** *touton* tego [[G5126]] WTD-ASM **σημειουσθε** *sēmeiousthe* zaznaczcie sobie [[G4593]] WTV-PMM-2P **και** *kai* i [[G2532]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **συναναμιγνυσθε** *synanamignysthe* mieszajcie się z [[G4874]] WTV-PMM-2P **αυτω** *autō* nim [[G846]] WTP-DSM **ινα** *hina* aby [[G2443]] [[CONJ]] **εντραπη** *entrapē* zostałby zawstydzony [[G1788]] WTV-2APS-3S
###### **2Tes 3,15**
 **και** *kai* i [[G2532]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **ως** *hōs* jak [[G5613]] [[ADV]] **εχθρον** *echthron* wroga – nieprzyjaciela [[G2190]] WTA-ASM **ηγεισθε** *hēgeisthe* uznawajcie [[G2233]] WTV-PNM-2P **αλλα** *alla* ale [[G235]] [[CONJ]] **νουθετειτε** *noutheteite* napominajcie – kładźcie do rozumu [[G3560]] WTV-PAM-2P **ως** *hōs* jak [[G5613]] [[ADV]] **αδελφον** *adelfon* bratu [[G80]] [[N-ASM]]
###### **2Tes 3,16**
 **αυτος** *autos* Sam [[G846]] WTP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **της** *tēs* [[G3588]] [[T-GSF]] **ειρηνης** *eirēnēs* pokoju [[G1515]] [[N-GSF]] **δωη** *dōē* oby dał [[G1325]] WTV-2AAO-3S **υμιν** *hymin* wam [[G5213]] WTP-2DP **την** *tēn* [[G3588]] WTT-ASF **ειρηνην** *eirēnēn* pokój [[G1515]] WTN-ASF **δια** *dia* przez [[G1223]] [[PREP]] **παντος** *pantos* wszystko [[G3956]] WTA-GSM **εν** *en* w [[G1722]] [[PREP]] **παντι** *panti* każdym [[G3956]] WTA-DSM **τροπω** *tropō* sposobie [[G5158]] WTN-DSM **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **μετα** *meta* z [[G3326]] [[PREP]] **παντων** *pantōn* wszystkimi [[G3956]] WTA-GPM **υμων** *hymōn* wami [[G5216]] WTP-2GP
###### **2Tes 3,17**
 **ο** *ho* [[G3588]] [[T-NSM]] **ασπασμος** *aspasmos* Pozdrowienie [[G783]] [[N-NSM]] **τη** *tē* [[G3588]] WTT-DSF **εμη** *emē* moją [[G1699]] WTS-1DSF **χειρι** *cheiri* ręką [[G5495]] [[N-DSF]] **παυλου** *paulou* Pawła – [mały] [[G3972]] [[N-GSM]] **ο** *ho* co [[G3739]] WTR-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **σημειον** *sēmeion* znak [[G4592]] WTN-NSN **εν** *en* w [[G1722]] [[PREP]] **παση** *pasē* każdym [[G3956]] WTA-DSF **επιστολη** *epistolē* liście [[G1992]] [[N-DSF]] **ουτως** *houtōs* tak [[G3779]] [[ADV]] **γραφω** *grafō* piszę [[G1125]] WTV-PAI-1S
###### **2Tes 3,18**
 **η** *hē* [[G3588]] [[T-NSF]] **χαρις** *charis* Łaska [[G5485]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **μετα** *meta* z [[G3326]] [[PREP]] **παντων** *pantōn* wszystkimi [[G3956]] WTA-GPM **υμων** *hymōn* wami [[G5216]] WTP-2GP **αμην** *amēn* amen – [zaprawdę] [[G281]] WTHEB **προς** *pros* do [[G4314]] [[PREP]] **θεσσαλονικεις** *thessalonikeis* Tesaloniczan [[G2331]] [[N-APM]] **δευτερα** *deutera* drugi raz [[G1208]] WTA-NSF **εγραφη** *egrafē* zostało napisane [[G1125]] WTV-2API-3S **απο** *apo* z [[G575]] [[PREP]] **αθηνων** *athēnōn* Aten [[G116]] WTN-GPF
