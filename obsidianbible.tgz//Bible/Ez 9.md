# Ez 9 BT5
###### **Ez 9,1**
 Potem donośnie, tak że ja słyszałem, wołał On: «***Zbliżcie się, straże miasta, każdy z niszczycielską bronią w ręku!***»
###### **Ez 9,2**
 I oto przybyło sześciu mężów drogą od górnej bramy, położonej po stronie północy, każdy z własną niszczycielską bronią w ręku. Wśród nich znajdował się pewien mąż, odziany w lnianą szatę, z kałamarzem pisarskim u boku. Weszli i zatrzymali się przed ołtarzem z brązu.
###### **Ez 9,3**
 A chwała Boga Izraela uniosła się znad cherubów, na których się znajdowała, do progu świątyni. Następnie, zawoławszy męża odzianego w szatę lnianą, który miał kałamarz u boku,
###### **Ez 9,4**
 Pan rzekł do niego: «***Przejdź przez środek miasta, przez środek Jerozolimy, i nakreśl ten znak Taw na czołach mężów, którzy wzdychają i biadają nad wszystkimi obrzydliwościami w niej popełnianymi***».
###### **Ez 9,5**
 Do innych zaś rzekł, tak iż słyszałem: «***Idźcie za nim po mieście i zabijajcie! Niech oczy wasze nie znają współczucia ni litości!***
###### **Ez 9,6**
 ***Starców, młodzieńców, panny, niemowlęta i kobiety wybijcie do szczętu! Nie dotykajcie jednak żadnego męża, na którym będzie ów znak. Zacznijcie od mojej świątyni!***» I tak zaczęli od owych starców, którzy stali przed świątynią.
###### **Ez 9,7**
 Następnie rzekł do nich: «***Zbezcześćcie również świątynię, dziedzińce napełnijcie trupami!***» Wyszli oni i zabijali w mieście.
###### **Ez 9,8**
 A podczas gdy oni zabijali, ja pozostałem sam, upadłem na twarz i tak wołałem: «***Ach, Panie Boże! Czy chcesz wyniszczyć całą Resztę Izraela, dając upust swemu gniewowi przeciw Jerozolimie?***»
###### **Ez 9,9**
 Rzekł do mnie: «***Nieprawość pokolenia Izraela i Judy jest wielka, niezmierna; kraj jest pełen krwi, a miasto pełne przewrotności. Mówią bowiem: Pan opuścił ten kraj, Pan nie widzi.***
###### **Ez 9,10**
 ***A więc także i moje oko nie okaże litości ani współczucia. Odpowiedzialność za ich postępowanie składam na ich głowy***».
###### **Ez 9,11**
 I oto ów mąż, odziany w lnianą szatę, z kałamarzem pisarskim u boku, oznajmił: «***Uczyniłem, jak mi rozkazałeś***».
# Ez 9 PAU
###### **Ez 9,1**
 Zawołał do mnie donośnym głosem: „Zbliżają się ci, którzy będą karać miasto. Każdy ma w swoim ręku niszczycielską broń”.
###### **Ez 9,2**
 I przyszło sześciu ludzi od strony bramy górnej, która jest zwrócona ku północy. Każdy trzymał w ręce broń zagłady. Między nimi był pewien człowiek ubrany w lnianą szatę, a przy boku miał przybory pisarskie. Ludzie ci weszli i stanęli obok ołtarza z brązu.
###### **Ez 9,3**
 Tymczasem chwała Boga Izraela przeniosła się znad cherubów, nad którymi była, do progu świątyni. Wtedy PAN zawołał do człowieka ubranego w lnianą szatę, mającego przybory pisarskie przy boku,
###### **Ez 9,4**
 i rzekł do niego: „Przejdź przez miasto, przez środek Jerozolimy, i napisz literę Taw na czołach ludzi wzdychających i bolejących z powodu wszystkich obrzydliwości, które się w niej dokonują”.
###### **Ez 9,5**
 I usłyszałem, jak powiedział do pozostałych: „Idźcie za nim przez miasto i zabijajcie. Nie spoglądajcie z litością i nie przebaczajcie.
###### **Ez 9,6**
 Mordujcie starców, młodzieńców, dziewczęta, dzieci i kobiety. Ale zostawcie każdego, kto ma literę Taw. Rozpocznijcie od mojej świątyni”. Zaczęli więc od starszych, którzy byli przed świątynią.
###### **Ez 9,7**
 Potem im polecił: „Zbezcześćcie świątynię i zapełnijcie dziedzińce pomordowanymi. Idźcie!”. Wyszli więc i zabijali w mieście.
###### **Ez 9,8**
 Gdy oni mordowali, ja zostałem sam. Upadłem na twarz i błagałem: „Ach! PANIE, BOŻE! Czy chcesz zgładzić całą Resztę Izraela, że wylewasz Twoje oburzenie na Jerozolimę?”.
###### **Ez 9,9**
 Odpowiedział mi: „Grzech ludu Izraela i Judy jest bardzo, bardzo wielki. W kraju przelewa się krew, a w mieście zapanowała przewrotność. Mówią bowiem: PAN opuścił kraj. PAN nie widzi.
###### **Ez 9,10**
 Więc Ja rzeczywiście nie spojrzę ze współczuciem i nie przebaczę. Odpowiedzą za swoje postępowanie”.
###### **Ez 9,11**
 A człowiek ubrany w lniane szaty i mający u swego boku przybory pisarskie tak oznajmił: „Uczyniłem, jak mi poleciłeś”.
# Ez 9 BP
###### **Ez 9,1**
 Po czym zawołał donośnym głosem do moich uszu, mówiąc: Nadchodzą strażnicy miasta. Każdy [dzierży] w swym ręku narzędzie jego zniszczenia.
###### **Ez 9,2**
 Oto od strony bramy Górnej, zwróconej ku północy, weszło sześciu mężów. Każdy miał w swym ręku narzędzie zniszczenia. Jeden mąż spośród nich, odziany w lnianą szatę, miał przybory pisarskie u swego boku. Weszli i stanęli obok ołtarza z brązu.
###### **Ez 9,3**
 Chwała Boga Izraela przeniosła się sponad cherubinów, na których spoczywała, w kierunku progu Świątyni. Wtedy zawołał na męża odzianego w szatę lnianą, który miał przybory pisarskie u swego boku,
###### **Ez 9,4**
 i rzekł mu Jahwe: Przejdź przez miasto, przez Jerozolimę, i naznacz tau na czołach mężów, wzdychającyh i bolejących nad wszystkimi obrzydliwościami, jakie się w niej dokonują.
###### **Ez 9,5**
 Tamtym zaś powiedział, [doszło to] moich uszu: Idźcie za nim przez miasto i zabijajcie. Niech oczy wasze nie patrzą ze współczuciem. Nie litujcie się.
###### **Ez 9,6**
 Mordujcie starców, młodzieńców, dziewczęta, dzieci i kobiety do ostatniego, ale nie przystępujcie do nikogo, kto ma [znak] tau. Rozpocznijcie od mojego sanktuarium. I rozpoczęli od mężów starszyzny, którzy byli przed Świątynią.
###### **Ez 9,7**
 I rozkazał im: Zbezcześćcie Świątynię i napełnijcie dziedzińce pomordowanymi. Wychodźcie! Wyszli i zabijali w mieście.
###### **Ez 9,8**
 I stało się, gdy oni mordowali, ja pozostałem sam i upadłem na twarz. Wołałem i prosiłem: Ach, Panie, Jahwe! Czy Ty, wylewając swój gniew na Jerozolimę, chcesz wytracić całą Resztę Izraela?
###### **Ez 9,9**
 Wtedy rzekł do mnie: Wina Domu Izraela i Judy jest bardzo, bardzo wielka. Kraj pełen jest krwi, a miasto przepełnia bezprawie. Mówią bowiem: Jahwe opuścił kraj, Jahwe nie widzi.
###### **Ez 9,10**
 Więc Ja także [zwrócę się przeciw nim]. Oko moje nie spojrzy z litością. Nie zmiłuję się. Postępowanie ich złożę na ich głowy.
###### **Ez 9,11**
 Oto mąż odziany w lniane szaty, który miał u swego boku przybory [pisarskie], zdał sprawę mówiąc: Uczyniłem tak, jak mi rozkazałeś.
# Ez 9 BR
###### **Ez 9,1**
 I zawołał głośno do mych uszu: Zbliża się już sąd nad tym miastem! Niech każdy weźmie do ręki narzędzie niszczenia!
###### **Ez 9,2**
 Wtedy nadeszło sześciu mężów od bramy Górnej, położonej po stronie północnej. Każdy z nich miał w ręku narzędzie zagłady. Był wśród nich jeden mąż ubrany w lnianą szatę, z kałamarzem przywiązanym do pasa. Weszli wszyscy do środka i stanęli obok ołtarza z brązu.
###### **Ez 9,3**
 Chwała Boga Izraela unosiła się znad cherubów, nad którymi się znajdowała, i zatrzymała się przy progu Świątyni. Potem został wywołany mąż odziany w lnianą szatę, z kałamarzem u pasa.
###### **Ez 9,4**
 I powiedział do niego Pan: Idź przez środek miasta Jeruzalem i wypisz znak Taw na czołach tych wszystkich mężów, którzy boleją i smucą się z powodu obrzydliwości wypełniających miasto.
###### **Ez 9,5**
 Słyszałem też, jak do innych powiedział: Idźcie przez miasto i zabijajcie. Nie litujcie się nad nikim, nie oszczędzajcie nikogo!
###### **Ez 9,6**
 Starych i młodych, panny, niemowlęta, kobiety i wszystkich zabijajcie, co do jednego. Ale nie wolno wam nawet dotknąć żadnego z tych, którzy mają wypisane Taw na czole. Zacznijcie od mojego przybytku. Rozpoczęli tedy od starców, stojących przed Świątynią.
###### **Ez 9,7**
 Potem powiedział do nich: Zbezcześćcie całą Świątynię, niech jej dziedzińce wypełnią się trupami! Potem wyjdźcie na zewnątrz i zabijajcie [wszystkich] w mieście.
###### **Ez 9,8**
 I pozabijali wszystkich tak, że zostałem sam. Upadłem więc na twarz i zawołałem: Ach, Panie mój i Boże! Czy cały swój gniew zamierzasz wylać na Jerozolimę i wyniszczyć nawet tę Resztę Izraela?
###### **Ez 9,9**
 A On powiedział do mnie: Wina Domu Izraela i Domu Judy jest ogromna, przeogromna. Kraj jest pełen krwawych zbrodni, a w mieście - same niegodziwości. Oni zaś pocieszają się mówiąc, że Pan tego nie widzi, że Pan już opuścił całą tę krainę.
###### **Ez 9,10**
 Dlatego nad nikim nie będzie się litować moje oko, nie będę oszczędzał nikogo. Winy wasze spadną na was samych.
###### **Ez 9,11**
 Wtedy powrócił mąż przyodziany w lnianą szatę, z kałamarzem u pasa. Przyszedł i powiedział: Wykonałem wszystko, co mi rozkazałeś.
# Ez 9 WUJ
###### **Ez 9,1**
 I wołał do uszu moich głosem wielkim, mówiąc: Przybliżyły się nawiedzenia miasta, a każdy ma naczynie zabijania w ręce swej.
###### **Ez 9,2**
 A oto sześć mężów przyszli z drogi bramy wyższej, która patrzy ku północy: a każdego naczynie zginienia w ręce swej: jeden też mąż w pośrodku ich obleczon był w płócienne szaty, a kałamarz pisarski na biodrach jego. I weszli i stanęli podłe ołtarza miedzianego:
###### **Ez 9,3**
 A chwała Pana Izraelowego wzięta jest z Cherub która była na nim do progu domu: i zawołał męża który był obleczony w płócienne szaty, a miał kałamarz pisarski na biodrach swych.
###### **Ez 9,4**
 I rzekł Pan do niego: Przejdzi przez pośrodek miasta w pół Jeruzalem: a naznacz Thau na czołach mężów wzdychających, i żałujących nad wszystkiemi obrzydłościami, które się dzieją w pośrodku jego.
###### **Ez 9,5**
 A onym rzekł, gdym ja słyszał: Idźcie po mieście za nim a zabijajcie: niech nie folguje oko wasze, ani się zmiłujcie.
###### **Ez 9,6**
 Starego, młodzieniaszka, i pannę, maluczkiego i niewiasty zabijcie aż do szczętu: a każdego, na którym ujrzycie Thau, nie zabijajcie: a od Świątynie mojej pocznicie.
###### **Ez 9,7**
 A tak poczęli od mężów starszych, którzy byli przed domem Bożym. I rzekł do nich: splugawcie dom, a napełnicie sieni zabitemi: wynidźcież i wyszli, i zabijali te, którzy byli w mieście.
###### **Ez 9,8**
 A gdy się zabijanie skończyło, zostałem ja: i upadłem na oblicze moje, i wołając rzekłem: Ach, ach, ach, Panie Boże: a więc wytracisz wszystek ostatek Izraela, wylewając zapalczywość twoję na Jeruzalem.
###### **Ez 9,9**
 I rzekł do mnie: Nieprawość domu Izraelskiego i Judzkiego wielka jest barzo wielce: i ziemia się krwie napełniła: i miasto pełne jest odwrócenia: bo mówili: Opuścił Pan ziemię i Pan nie widzi.
###### **Ez 9,10**
 Przeto też oko moje nie sfolguje, ani się zmiłuje: drogę ich na głowę ich oddam.
###### **Ez 9,11**
 A oto mąż, który był obleczony w płócienne szaty, który miał kałamarz na grzbiecie swoim, odpowiedział słowo, rzekąc: uczyniłem jakoś mi rozkazał.
