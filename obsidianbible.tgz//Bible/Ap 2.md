# Ap 2 BT5
###### **Ap 2,1**
***Aniołowi Kościoła w Efezie napisz:To mówi Ten, który trzyma siedem gwiazd w prawej ręce, Ten, który się przechadza wśród siedmiu złotych świeczników:***
###### **Ap 2,2**
***Znam twoje czyny: trud i twoją wytrwałość, i to, że złych nie możesz znieść, i że próbie poddałeś tych, którzy zwą samych siebie apostołami, a nimi nie są, i że ich znalazłeś kłamcami.***
###### **Ap 2,3**
***Ty masz wytrwałość, i zniosłeś cierpienie dla imienia mego –niezmordowany.***
###### **Ap 2,4**
***Ale mam przeciw tobie to, że odstąpiłeś od twej pierwotnej miłości.***
###### **Ap 2,5**
***Pamiętaj więc, skąd spadłeś, i nawróć się, i poprzednie czyny podejmij! Jeśli zaś nie – przyjdę do ciebiei ruszę świecznik twój z jego miejsca, jeśli się nie nawrócisz.***
###### **Ap 2,6**
***Ale masz tę [zaletę], że nienawidzisz czynów nikolaitów,których to czynów i Ja nienawidzę.***
###### **Ap 2,7**
***Kto ma uszy, niechaj posłyszy, co mówi Duch do Kościołów. Zwycięzcy dam spożyć owoc z drzewa życia, które jest w raju Boga.***
###### **Ap 2,8**
***Aniołowi Kościoła w Smyrnie napisz:To mówi Pierwszy i Ostatni, który był martwy, a ożył:***
###### **Ap 2,9**
***Znam twój ucisk i ubóstwo – ale ty jesteś bogaty – i obelgę [rzuconą] przez tych, co samych siebie zowią Żydami, a nie są nimi, lecz synagogą szatana.***
###### **Ap 2,10**
***Przestań się lękać tego, co będziesz cierpiał. Oto diabeł ma niektórych spośród was wtrącić do więzienia, abyście zostali poddani próbie, a znosić będziecie ucisk przez dziesięć dni. Bądź wierny aż do śmierci, a dam ci wieniec życia.***
###### **Ap 2,11**
***Kto ma uszy, niechaj posłyszy, co mówi Duch do Kościołów. Zwycięzcy śmierć druga na pewno nie wyrządzi szkody.***
###### **Ap 2,12**
***Aniołowi Kościoła w Pergamonie napisz: To mówi Ten, który ma miecz obosieczny, ostry.***
###### **Ap 2,13**
***Wiem, gdzie mieszkasz: tam, gdzie jest tron szatana,a trzymasz się mego imieniai wiary mojej się nie zaparłeś, nawet za dni Antypasa, wiernego świadka mojego, który został zabity u was, tam gdzie mieszka szatan.***
###### **Ap 2,14**
***Ale mam nieco przeciw tobie, bo masz tam tych, co się trzymają nauki Balaama,który pouczył Balaka, jak podsunąć synom Izraela sposobność do grzechuprzez spożycie ofiar składanych bożkom i uprawianie rozpusty.***
###### **Ap 2,15**
***Tak ty również masz tych, co się trzymają podobnie nauki nikolaitów.***
###### **Ap 2,16**
***Nawróć się zatem!Jeśli zaś nie – przyjdę do ciebie niebawemi będę z nimi walczył mieczem moich ust.***
###### **Ap 2,17**
***Kto ma uszy, niechaj posłyszy, co mówi Duch do Kościołów. Zwycięzcy dam manny ukryteji dam mu biały kamyk, a na kamyku wypisane imię nowe, którego nikt nie zna oprócz tego, kto [je] otrzymuje.***
###### **Ap 2,18**
***Aniołowi Kościoła w Tiatyrze napisz: To mówi Syn Boży: Ten, który ma oczy jak płomień ognia, a nogi Jego podobne są do drogocennego metalu.***
###### **Ap 2,19**
***Znam twoje czyny, miłość, wiarę, posługę i twoją wytrwałość, i czyny twoje ostatnie, liczniejsze od pierwszych,***
###### **Ap 2,20**
***ale mam przeciw tobie to, że pozwalasz działać niewieście Jezabel,która nazywa siebie prorokinią, a naucza i zwodzi moje sługi, by uprawiali rozpustęi spożywali ofiary składane bożkom.***
###### **Ap 2,21**
***Dałem jej czas, by się mogła nawrócić, a ona nie chce się odwrócić od swojej rozpusty.***
###### **Ap 2,22**
***Oto rzucam ją na łoże boleści, a na tych, co z nią cudzołożą, [ześlę] wielki ucisk, jeśli od czynów jej się nie odwrócą;***
###### **Ap 2,23**
***i dzieci jej porażę śmiercią. A wszystkie Kościoły poznają, że Ja jestem Ten, co przenika nerki i serca; i dam każdemu z was według waszych czynów.***
###### **Ap 2,24**
***Wam zaś, pozostałym w Tiatyrze, mówię, wszystkim, co tej nauki się nie trzymają, tym, co – jak powiadają – nie poznali "głębin szatana":nie nakładam na was nowego brzemienia,***
###### **Ap 2,25**
***to jednak, co macie, zatrzymajcie, aż przyjdę.***
###### **Ap 2,26**
***A zwycięzcy i temu, co czynów mych strzeże do końca, dam władzę nad poganami,***
###### **Ap 2,27**
***a rózgą żelazną będzie ich pasał: jak naczynie gliniane będą rozbici –***
###### **Ap 2,28**
***jak i Ja [wszystko] to otrzymałem od mojego Ojca – i dam mu gwiazdę poranną.***
###### **Ap 2,29**
***Kto ma uszy, niechaj posłyszy, co mówi Duch do Kościołów.***
# Ap 2 PAU
###### **Ap 2,1**
 Aniołowi Kościoła w Efezie napisz: To mówi Ten, który trzyma siedem gwiazd w swojej prawej ręce, który chodzi pośród siedmiu złotych świeczników.
###### **Ap 2,2**
 Znam twoje czyny, trud i twoją wytrwałość oraz to, że nie możesz znieść złych. Poddałeś próbie tych, którzy uważają się za apostołów, a nimi nie są i uznałeś ich za kłamców.
###### **Ap 2,3**
 Jesteś wytrwały. Cierpiałeś z powodu mojego imienia i nie osłabłeś.
###### **Ap 2,4**
 Mam jednak przeciw tobie to, że porzuciłeś swoją pierwszą miłość.
###### **Ap 2,5**
 Pamiętaj, skąd spadłeś. Nawróć się i postępuj jak na początku, bo jeśli nie, to przyjdę do ciebie i przesunę twój świecznik z jego miejsca.
###### **Ap 2,6**
 Tym się jednak odznaczasz, że nienawidzisz postępowania nikolaitów, którego i Ja nienawidzę.
###### **Ap 2,7**
 Kto ma uszy, niech słucha, co Duch mówi do Kościołów. Zwycięzcy pozwolę jeść z drzewa życia, które znajduje się w raju Boga.
###### **Ap 2,8**
 Aniołowi Kościoła w Smyrnie napisz: To mówi Pierwszy i Ostatni, który był umarły i ożył.
###### **Ap 2,9**
 Znam twój ucisk i ubóstwo - a mimo to jesteś bogaty! Wiem, że cię znieważają ci, którzy siebie nazywają Żydami, podczas gdy nie są nimi, lecz są synagogą szatana.
###### **Ap 2,10**
 Nie bój się tego, co masz wycierpieć. Oto diabeł zamierza wtrącić niektórych z was do więzienia, aby was wypróbować. Będziecie cierpieć ucisk przez dziesięć dni. Bądź wierny aż do śmierci, a dam ci wieniec życia.
###### **Ap 2,11**
 Kto ma uszy, niech słucha, co Duch mówi do Kościołów. Zwycięzca nie zazna śmierci po raz drugi.
###### **Ap 2,12**
 Aniołowi Kościoła w Pergamonie napisz: To mówi Ten, który trzyma ostry miecz obosieczny.
###### **Ap 2,13**
 Wiem, że mieszkasz tam, gdzie jest tron szatana, lecz trzymasz się mojego imienia. Nie wyparłeś się mojej wiary, nawet za dni mego wiernego świadka Antypasa, którego zabito u was tam, gdzie mieszka szatan.
###### **Ap 2,14**
 Mam jednak coś przeciw tobie: są u ciebie zwolennicy nauki Balaama, który uczył Balaka, jak doprowadzić do upadku Izraelitów, zachęcając ich do spożywania pokarmów składanych bożkom i do nierządu.
###### **Ap 2,15**
 Podobnie są u ciebie również zwolennicy nauki nikolaitów.
###### **Ap 2,16**
 Zmień więc swoje postępowanie, w przeciwnym zaś razie nagle przyjdę do ciebie i mieczem moich ust będę walczył z nimi.
###### **Ap 2,17**
 Kto ma uszy, niech słucha, co Duch mówi do Kościołów. Zwycięzcy dam mannę ukrytą i biały kamyk. Na kamyku wypisane będzie nowe imię, którego nie zna nikt poza tym, kto je otrzymuje.
###### **Ap 2,18**
 Aniołowi Kościoła w Tiatyrze napisz: To mówi Syn Boży, którego oczy są jak płomień ognia, a nogi podobne do drogocennego metalu.
###### **Ap 2,19**
 Znam twoje czyny, miłość, wiarę, służbę i wytrwałość. Twoje ostatnie czyny przewyższają pierwsze.
###### **Ap 2,20**
 Mam jednak to przeciw tobie, że pozwalasz działać kobiecie Jezabel, która, podając się za prorokinię, naucza i zwodzi moje sługi, tak że uprawiają nierząd i jedzą pokarmy ofiarowane bożkom.
###### **Ap 2,21**
 Dałem jej czas na zmianę postępowania, ale nie chce porzucić swego nierządu.
###### **Ap 2,22**
 Oto przykuję ją do łoża, a na uprawiających z nią nierząd sprowadzę wielki ucisk, jeśli nie odstąpią od jej czynów.
###### **Ap 2,23**
 Jej dzieci porażę śmiercią i wszystkie Kościoły poznają, że Ja jestem tym, który przenika nerki i serca, bo każdemu z was oddam według jego czynów.
###### **Ap 2,24**
 Natomiast wam pozostałym, tym w Tiatyrze, którzy nie podzielają tej nauki, którzy nie poznali tak zwanych głębin szatana, mówię: Nie nakładam na was innego ciężaru.
###### **Ap 2,25**
 Zachowujcie tylko to, co posiadacie - aż do mojego przyjścia.
###### **Ap 2,26**
 Zwycięzcy, który do końca będzie przestrzegał moich przykazań, dam władzę nad narodami.
###### **Ap 2,27**
 Będzie je pasł laską żelazną i skruszy je jak naczynia gliniane.
###### **Ap 2,28**
 Jemu dam gwiazdę poranną, tak jak sam otrzymałem ją od mego Ojca.
###### **Ap 2,29**
 Kto ma uszy, niech słucha, co Duch mówi do Kościołów.
# Ap 2 BP
###### **Ap 2,1**
 Aniołowi Kościoła w Efezie napisz: To mówi Ten, który trzyma siedem gwiazd w prawej ręce, Ten, który się przechadza wśród siedmiu złotych świeczników:
###### **Ap 2,2**
 Znam twoje czyny, trud i twoją wytrwałość, i to, że złych nie możesz znieść; próbie poddałeś tych, którzy sami nazywają się apostołami, a nimi nie są, i przekonałeś się, że są kłamcami.
###### **Ap 2,3**
 Ty masz wytrwałość i zniosłeś cierpienia dla imienia mego - niezmordowany.
###### **Ap 2,4**
 Ale mam tobie za złe, że odstąpiłeś od twej pierwotnej miłości.
###### **Ap 2,5**
 Pamiętaj więc, skąd spadłeś, i nawróć się, i pierwsze czyny podejmij! A jeśli nie, jeśli się nie nawrócisz, przyjdę do ciebie i ruszę twój świecznik z jego miejsca.
###### **Ap 2,6**
 Ale masz to do siebie, że nienawidzisz czynów nikolaitów, których [to czynów] i Ja nienawidzę.
###### **Ap 2,7**
 Kto ma uszy, niech usłyszy, co mówi Duch do Kościołów. Zwycięzcy dam spożyć owoc z drzewa życia, które jest w raju Boga.
###### **Ap 2,8**
 Aniołowi Kościoła w Smyrnie napisz: To mówi Pierwszy i Ostatni, który był martwy, a ożył.
###### **Ap 2,9**
 Znam twój ucisk i ubóstwo, ale ty jesteś bogaty, i [znam] obelgę doznaną od tych, co samych siebie zowią Żydami, a nie są nimi, lecz synagogą szatana.
###### **Ap 2,10**
 Przestań się lękać tego, co masz cierpieć. Oto diabeł ma niektórych z was wtrącić do więzienia, abyście zostali poddani próbie, i znosić będziecie ucisk przez dziesięć dni. Bądź wierny aż do śmierci, a dam ci wieniec życia.
###### **Ap 2,11**
 Kto ma uszy, niech usłyszy, co mówi Duch do Kościołów. Zwycięzcy śmierć druga na pewno nie wyrządzi szkody.
###### **Ap 2,12**
 Aniołowi Kościoła w Pergamie napisz: To mówi Ten, który ma miecz obosieczny, ostry.
###### **Ap 2,13**
 Wiem, gdzie mieszkasz: tam, gdzie jest tron szatana, a trzymasz się mego imienia i wiary mojej się nie zaparłeś nawet we dni Antypasa mojego wiernego świadka, który został zabity u was, tam gdzie mieszka szatan.
###### **Ap 2,14**
 Ale trochę mam tobie za złe, że masz tam takich, co się trzymają nauki Balaama, który pouczył Balaka, jak podsunąć synowi Izraela sposobność do grzechu przez spożycie ofiar składanych bożkom i uprawianie rozpusty.
###### **Ap 2,15**
 Tak i ty także masz tych, co się trzymają podobnie nauki nikolaitów.
###### **Ap 2,16**
 Nawróć się zatem! Bo jeśli nie - przyjdę do ciebie niebawem i będę z nimi walczył mieczem moich ust.
###### **Ap 2,17**
 Kto ma uszy, niech usłyszy, co mówi Duch do Kościołów. Zwycięzcy dam manny ukrytej i dam mu biały kamyk, a na kamyku wypisane imię nowe, którego nikt nie zna oprócz tego, kto [je] otrzymuje.
###### **Ap 2,18**
 Aniołowi Kościoła w Tiatyrze napisz: To mówi Syn Boży: Ten, który ma oczy jak płomień ognisty, a nogi jego są podobne do drogocennego metalu.
###### **Ap 2,19**
 Znam twoje czyny, miłość, wiarę, posługę i twoją wytrwałość, i czyny twoje ostatnie liczniejsze od pierwszych,
###### **Ap 2,20**
 ale mam tobie za złe, że pozwalasz działać niewieście Jezabel, która nazywa siebie prorokinią, a naucza i zwodzi moje sługi, tak że uprawiają rozpustę i spożywają ofiary składane bożkom.
###### **Ap 2,21**
 Dałem jej czas, by się mogła nawrócić, ale ona nie chce się odwrócić od swojej rozpusty.
###### **Ap 2,22**
 Oto rzucam ją na łoże boleści, a na tych, co z nią cudzołożą, ześlę wielkie utrapienie, jeśli od czynów jej się nie odwrócą,
###### **Ap 2,23**
 a dzieci jej porażę śmiercią. I poznają wszystkie Kościoły, że Ja jestem tym, który przenika nerki i serca, i oddam każdemu z was według waszych czynów.
###### **Ap 2,24**
 Wam zaś, pozostałym w Tiatyrze, mówię, wam wszystkim, co nie macie tej nauki, wam, którzyście - jak mówicie - nie poznali "głębin szatana": Nie wkładam na was nowego brzemienia,
###### **Ap 2,25**
 to jednak, co macie, zatrzymajcie, aż przyjdę.
###### **Ap 2,26**
 A zwycięzcy i temu, kto czynów mych strzeże do końca, dam władzę nad poganami,
###### **Ap 2,27**
 a będzie ich pasł żelazną laską: jak naczynie gliniane będą rozbici
###### **Ap 2,28**
 jak i Ja to wziąłem od mego Ojca - i dam mu gwiazdę poranną.
###### **Ap 2,29**
 Kto ma uszy, niech usłyszy, co mówi Duch do Kościołów.
# Ap 2 BR
###### **Ap 2,1**
 Aniołowi Kościoła efeskiego napisz: To mówi Ten, który trzyma siedem gwiazd w swej prawicy i przechodzi między siedmioma złotymi świecznikami.
###### **Ap 2,2**
 Znam wszystkie twoje uczynki, wszystkie twoje udręki i twoją wytrwałość. Wiem, że nie tolerujesz bezbożnych, że poddałeś szczególnej próbie tych, którzy podawali się za apostołów, i stwierdziłeś, że nie są apostołami, lecz zwykłymi kłamcami.
###### **Ap 2,3**
 Znana mi jest twoja wytrwałość i wiem, że niezmordowanie znosiłeś wiele dla mojego imienia.
###### **Ap 2,4**
 Mam ci jednak do zarzucenia to, że nie miłujesz Mnie już tak jak dawniej.
###### **Ap 2,5**
 Pamiętając więc o tym, skąd spadłeś, odwróć się od twoich grzechów i postępuj tak jak ongiś. Jeśli zaś się nie nawrócisz, zjawię się u ciebie i usunę twój świecznik z miejsca, na którym się znajduje.
###### **Ap 2,6**
 Pochwalam cię jednak za to, że potępiasz uczynki nikolaitów, których i Ja nienawidzę.
###### **Ap 2,7**
 Kto ma uszy do słuchania, niech słucha, co mówi Duch do Kościołów: Zwycięzcy pozwolę spożywać z drzewa życia, które jest w raju Boga.
###### **Ap 2,8**
 Aniołowi Kościoła w Smyrnie napisz tak: To mówi Pierwszy i Ostatni. Ten, który był umarły, ale oto ożył.
###### **Ap 2,9**
 Znam twoje udręki i ubóstwo - wiedz jednak, że jesteś bogaty. Wiem też, jakimi obelgami obrzucają cię ci, którzy uważają się za Żydów, ale w rzeczywistości nie są Żydami, lecz społecznością szatańską.
###### **Ap 2,10**
 Nie poddawaj się przerażeniu, gdy pomyślisz o tym, co będziesz musiał wycierpieć. [Bądź przygotowany na to, że] diabeł wtrąci niektórych spośród was do więzienia, by poddać was szczególnej próbie. Ucisk będzie trwał dziesięć dni. Jeśli wytrwasz w wierności aż do śmierci, dam ci w nagrodę wieniec życia.
###### **Ap 2,11**
 Kto ma uszy do słuchania, niech słucha, co mówi Duch do Kościołów: Zwycięzcy owa druga śmierć na pewno nie wyrządzi już żadnej szkody.
###### **Ap 2,12**
 Aniołowi Kościoła w Pergamie napisz tak: To mówi Ten, który posiada miecz ostry, obosieczny.
###### **Ap 2,13**
 Wiem, że mieszkasz tam, gdzie znajduje się tron szatana; wiem, że ty trwasz wiernie przy moim imieniu, że nie zaparłeś się mojej wiary nawet za dni Antypasa, mojego wiernego świadka, który został zabity u was, tam, gdzie znajduje się siedziba szatana.
###### **Ap 2,14**
 Mam ci jednak do wyrzucenia to, że są u ciebie wyznawcy Balaama. To właśnie Balaam mówił Balakowi, jak miał podsuwać Izraelitom okazje do grzechu przez spożywanie ofiar składanych bożkom pogańskim i przez rozpustę.
###### **Ap 2,15**
 Poza tym u ciebie również są ci, którzy słuchają nauki nikolaitów.
###### **Ap 2,16**
 Opamiętaj się więc, bo jeśli nie, to wkrótce przybędę do ciebie i sam pocznę ich zwalczać mieczem moich ust.
###### **Ap 2,17**
 Kto ma uszy do słuchania, niech słucha, co mówi Duch do Kościołów: Zwycięzcy dam mannę ukrytą oraz biały kamień z wypisanym na nim nowym imieniem. A imię to nie będzie znane nikomu prócz tego, który je otrzymuje.
###### **Ap 2,18**
 Aniołowi Kościoła w Tiatyrze napisz tak: To mówi Syn Boży, Ten, który ma oczy jak ogniste płomienie, a nogi jakby ze spiżu.
###### **Ap 2,19**
 Znane mi są twoje [szlachetne] czyny, twoja miłość, wiara, ofiarność i wytrwałość, a zwłaszcza twoje ostatnie dzieła, liczniejsze teraz niż kiedyś.
###### **Ap 2,20**
 Mam ci jednak za złe to, że tolerujesz u siebie działalność niewiasty Jezabel, podającej się za prorokinię. W rzeczywistości uwodzi ona moje sługi, skłaniając je do tego, by uprawiali rozpustę i spożywali ofiary składane idolom.
###### **Ap 2,21**
 Już wyznaczyłem jej czas na pokutę, lecz ona nie chce zejść z drogi nieprawości.
###### **Ap 2,22**
 Powalę ją więc na łoże boleści, a na tych, którzy z nią cudzołożą, sprowadzę - jeśli nie odwrócą się od jej występków - wielkie udręki.
###### **Ap 2,23**
 Na dzieci jej ześlę śmierć niespodziewaną. Wówczas poznają wszystkie Kościoły, że Ja jestem Tym, który przenika nerki i serca. I każdemu z was dam zapłatę zgodną z jego uczynkami.
###### **Ap 2,24**
 A wam, pozostałym mieszkańcom Tiatyry, wam, którzy odrzucacie tę naukę i - jak mówię - nie znacie głębin szatana, oświadczam: Nie nakładam na was żadnych nowych ciężarów.
###### **Ap 2,25**
 Trzymajcie się jednak tego, co posiadacie, aż do czasu mojego przyjścia.
###### **Ap 2,26**
 Zwycięzcy zaś i temu, który będzie czynił do końca to, co nakazuję, dam władzę nad narodami,
###### **Ap 2,27**
 by rządził nimi rózgą żelazną i mógł ich skruszyć jak gliniane naczynia.
###### **Ap 2,28**
 Taką władzę również Ja otrzymałem od Ojca mojego. I dam mu także gwiazdę poranną.
###### **Ap 2,29**
 Kto ma uszy do słuchania, niech słucha, co mówi Duch do Kościołów.
# Ap 2 WUJ
###### **Ap 2,1**
 Aniołowi Ephezkiego kościoła napisz: To mówi, który trzyma siedm gwiazd w prawicy swej, który chodzi między siedmią lichtarzów złotych:
###### **Ap 2,2**
 Wiem sprawy twoje, i pracą, i cierpliwość twoję: a iż nie możesz cierpieć złych, i doświadczałeś tych, którzy się mienią być Apostoły a nie są, i nalazłeś je kłamcami:
###### **Ap 2,3**
 I masz cierpliwość, i znaszałeś dla imienia mego: a nie ustałeś.
###### **Ap 2,4**
 Ale mam przeciw tobie, żeś miłość twoję pierwszą opuścił.
###### **Ap 2,5**
 Pamiętajże tedy zkądeś wypadł: i czyń pokutę, a uczynki pierwsze czyń. A jeśli nie, przydę tobie, a poruszę lichtarz twój z miejsca swego, jeśli nie będziesz pokuty czynił.
###### **Ap 2,6**
 Ale to masz, iż nienawidzisz uczynków Nikolaitów, których i ja nienawidzę.
###### **Ap 2,7**
 Kto ma ucho, niech słucha co Duch mówi kościołom, Zwyciężcy dam jeść z drzewa żywota, które jest w raju Boga mojego.
###### **Ap 2,8**
 A aniołowi kościoła Smyrneńskiego napisz, Toć mówi pierwszy i ostatni, który był umarł, i żywie:
###### **Ap 2,9**
 Znam ucisk twój, i ubóstwo twoje, aleś jest bogaty: i bluźnią cię ci, którzy się powiadają być Żydmi, a nie są: ale są bóżnicą szatańską.
###### **Ap 2,10**
 Nic się nie bój tego co masz cierpieć. Oto ma wrzucić djabeł niektóre z was do ciemnice, abyście byli kuszeni: i będziecie mieć ucisk przez dziesięć dni. Bądź wierny aż do śmierci: a dam ci wieniec żywota.
###### **Ap 2,11**
 Kto ma ucho, niech słucha co Duch mówi kościołom: Kto zwycięży, nie będzie obrażon od wtórej śmierci.
###### **Ap 2,12**
 A aniołowi kościoła Pergamskiego napisz: To mówi ten, który ma miecz z obudwu stron ostry.
###### **Ap 2,13**
 Wiem gdzie mieszkasz, gdzie jest stolica szatańska: i trzymasz imię moje, i nie zaprzałeś się wiary mojej. I w one dni, Antypas świadek mój wierny, który zabit jest u was, gdzie szatan mieszka.
###### **Ap 2,14**
 Ale mam przeciwko tobie trochę: iż tam masz trzymające naukę Balaamowę, który uczył Balaka, aby wrzucał zgorszenie przed syny Izraelskie, żeby jedli i porubstwo płodzili:
###### **Ap 2,15**
 Także masz i ty trzymające naukę Nikolaitów.
###### **Ap 2,16**
 Tymże sposobem pokutę czyń: A jeśli nie, przydę tobie rychło, i będę walczył z nimi mieczem ust moich.
###### **Ap 2,17**
 Kto ma ucho, niech słucha co Duch mówi kościołom: Zwycięzcy dam mannę skrytą: i dam mu kamyk biały: a na kamyku, imię nowe napisane, którego nikt nie zna, jedno który bierze.
###### **Ap 2,18**
 A aniołowi Tyatyrskiego kościoła napisz: To mówi Syn Boży, który ma oczy jako płomień ogniowy, a nogi jego podobne mosiądzowi.
###### **Ap 2,19**
 Znam uczynki twoje, i wiarę i miłość twoję, i posługowanie i cierpliwość twoję, i uczynki twoje ostatnie, których więcej niż pierwszych.
###### **Ap 2,20**
 Ale mam przeciwko tobie trochę: iż niewieście Jezabel która się mieni być prorokinią, dopuszczasz uczyć i zwodzić sługi moje, żeby porubstwo płodzili, i rzeczy bałwanom ofiarowane jedli.
###### **Ap 2,21**
 I dałem jej czas, aby pokutę czyniła: a nie chce pokutować z porubstwa swego.
###### **Ap 2,22**
 Oto porzucę ją na łoże: a którzy z nią cudzołożą, w ucisku barzo wielkim będą, jeśliby nie pokutowali z uczynków swoich:
###### **Ap 2,23**
 A syny jej pobiję śmiercią: i poznają wszystkie kościoły, iżem ja jest, który badam się nerek i serc: i dam każdemu z was według uczynków jego.
###### **Ap 2,24**
 A wam mówię, i drugim którzyście w Tyatrze którzykolwiek nie mają tej nauki, którzy nie poznali głębokości szatańskiej, jako mówią: nie włożę na was innego brzemienia.
###### **Ap 2,25**
 Wszakże to co macie, trzymajcie aż przydę.
###### **Ap 2,26**
 A ktoby zwyciężył i zachował aż do końca uczynki moje: dam mu zwierzchność nad Pogany.
###### **Ap 2,27**
 I będzie je rządził laską żelazną, a jako statek garncarski będą skruszeni:
###### **Ap 2,28**
 Jakom ja też wziął od Ojca mojego: i dam mu gwiazdę zaranna.
###### **Ap 2,29**
 Kto ma ucho, niech słucha co Duch kościołom mówi.
# Ap 2 STERN
###### **Ap 2,1**
 Aniołowi wspólnoty mesjanicznej w Efezie napisz: "Oto wiadomość od Tego, który trzyma siedem gwiazd w swej prawicy i przechadza się pomiędzy siedmioma złotymi menorami:
###### **Ap 2,2**
 'Znam twoje poczynania, ciężką pracę, wytrwanie i że nie możesz ścierpieć ludzi niegodziwych, poddałeś więc próbie tych, którzy nazywają siebie wysłannikami, ale nimi nie są, i przekonałeś się, że to kłamcy.
###### **Ap 2,3**
 Trwasz i cierpiałeś ze względu na mnie, nie poddając się.
###### **Ap 2,4**
 Ale to mam przeciwko tobie: utraciłeś miłość, jaką miałeś na początku.
###### **Ap 2,5**
 Dlatego pamiętaj, gdzie byłeś, zanim upadłeś, i odwróć się od tego grzechu, a czyń to, co czyniłeś niegdyś. W przeciwnym razie przyjdę do ciebie i usunę twą menorę z jej miejsca, jeśli nie odwrócisz się od swojego grzechu!
###### **Ap 2,6**
 Ale to mam na twoją korzyść: nienawidzisz poczynań nikolaitów - i ja ich nienawidzę.
###### **Ap 2,7**
 Ci, którzy mają uszy, niech usłyszą, co Duch mówi do wspólnot mesjanicznych. Temu, kto zwycięży, dam prawo spożywania z Drzewa Życia, które jest w Bożym Gan-'Eden'".
###### **Ap 2,8**
 Aniołowi wspólnoty mesjanicznej w Smyrnie napisz: "Oto wiadomość od Pierwszego i Ostatniego, który umarł i znów ożył:
###### **Ap 2,9**
 'Wiem, jak cierpisz i jak jesteś ubogi (choć w rzeczywistości jesteś bogaty!), i znam obelgi tych, którzy nazywają siebie Żydami, ale nimi nie są - przeciwnie, są synagogą Przeciwnika.
###### **Ap 2,10**
 Nie bój się tego, co będziesz wkrótce cierpiał. Wiedz, że Przeciwnik wtrąci niektórych z was do więzienia, aby was wypróbować, i przez dziesięć dni będziesz przechodził katusze. Pozostań wierny, i to do śmierci, a ja dam ci życie jako koronę.
###### **Ap 2,11**
 Ci, którzy mają uszy, niech słuchają, co mówi Duch do wspólnot mesjanicznych. Temu, kto zwycięży, druga śmierć nie wyrządzi żadnej szkody'".
###### **Ap 2,12**
 Aniołowi wspólnoty mesjanicznej w Pergamonie napisz: "Oto wiadomość od Tego, który ma ostry miecz obosieczny:
###### **Ap 2,13**
 'Wiem, gdzie mieszkasz - tam gdzie jest tron Przeciwnika. Mimo to trzymasz się mojego imienia. Nie wyparłeś się ufności we mnie nawet w chwili, gdy mój wierny świadek Antypas został zgładzony w twoim mieście, gdzie mieszka Przeciwnik.
###### **Ap 2,14**
 Mimo to mam przeciw tobie parę rzeczy: masz u siebie pewnych ludzi trzymających się nauki Bil'ama, który uczył Balaka, jak usidlić lud Isra'ela, tak aby spożywali pokarm złożony na ofiarę bożkom i grzeszyli rozwiązłością.
###### **Ap 2,15**
 Ty też masz u siebie ludzi, którzy trzymają się nauk nikolaitów.
###### **Ap 2,16**
 Odwróć się zatem od tych grzechów. W przeciwnym razie przyjdę do ciebie już wkrótce i będę walczył z nimi mieczem moich ust.
###### **Ap 2,17**
 Ci, którzy mają uszy, niech usłyszą, co mówi Duch do wspólnot mesjanicznych. Temu, kto zwycięży, dam nieco manny ukrytej. Dam mu też biały kamyk, a na nim wypisane nowe imię, którego nikt nie zna, z wyjątkiem tego, kto je otrzymuje".
###### **Ap 2,18**
 Aniołowi wspólnoty mesjanicznej w Tiatyrze napisz: "Oto wiadomość od Syna Bożego, którego oczy są jak ognisty płomień i którego stopy są niczym polerowany mosiądz:
###### **Ap 2,19**
 'Znam twoje poczynania, twoją miłość, ufność, służbę i wytrwanie. I wiem, że dziś robisz jeszcze więcej niż przedtem.
###### **Ap 2,20**
 Ale mam to przeciwko tobie: nadal tolerujesz tę kobietę Izewel, tę, która podaje się za prorokinię, ale naucza i zwodzi moje sługi, aby grzeszyli rozwiązłością i spożywali pokarm poświęcony bożkom.
###### **Ap 2,21**
 Dałem jej czas na odwrócenie się od jej grzechu, ale nie chce się nawrócić ze swej rozpusty.
###### **Ap 2,22**
 Rzucam ją więc na łoże boleści, a tych, którzy z nią cudzołożą, wtrącam w wielki ucisk - chyba że odwrócą się od grzechów związanych z jej poczynaniami -
###### **Ap 2,23**
 a dzieci jej pozabijam! Wtedy wszystkie wspólnoty mesjaniczne poznają, że to ja badam umysły i serca i że dam każdemu z was to, na co zasłużyły jego czyny.
###### **Ap 2,24**
 Lecz reszcie z was w Tiatyrze, tym, którzy nie trzymają się owej nauki, którzy nie poznali tego, co niektórzy zwą głębinami Przeciwnika, mówię: Nie nakładam na was kolejnego ciężaru,
###### **Ap 2,25**
 trzymajcie się tylko mocno tego, co macie, aż przyjdę.
###### **Ap 2,26**
 Temu, kto zwycięży i będzie czynił to, czego chcę, aż do osiągnięcia tego celu, dam władzę nad narodami.
###### **Ap 2,27**
 Będzie nimi rządził laską żelazną i roztrzaska je na kawałki jak gliniane naczynia,
###### **Ap 2,28**
 bo taką władzę otrzymałem od mojego Ojca. Dam mu też gwiazdę poranną.
###### **Ap 2,29**
 Ci, którzy mają uszy, niech usłyszą, co mówi Duch do wspólnot mesjanicznych'".
# Ap 2 TRO
###### **Ap 2,1**
 **τω** *tō* [[G3588]] WTT-DSM **αγγελω** *angelō* Zwiastunowi [[G32]] WTN-DSM **της** *tēs* [[G3588]] [[T-GSF]] **εφεσινης** *efesinēs* efeskiego [[G2179]] [[N-GSF]] **εκκλησιας** *ekklēsias* zgromadzenia – (społeczności) wywołanych [[G1577]] [[N-GSF]] **γραψον** *grapson* napisz [[G1125]] WTV-AAM-2S **ταδε** *tade* to [[G3592]] WTD-APN **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **κρατων** *kratōn* trzymający [[G2902]] [[V-PAP-NSM]] **τους** *tous* [[G3588]] WTT-APM **επτα** *hepta* siedem [[G2033]] WTA-NUI **αστερας** *asteras* gwiazd [[G792]] [[N-APM]] **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **δεξια** *deksia* prawicy [[G1188]] WTA-DSF **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ο** *ho* [[G3588]] [[T-NSM]] **περιπατων** *peripatōn* chodzący [[G4043]] [[V-PAP-NSM]] **εν** *en* w [[G1722]] [[PREP]] **μεσω** *mesō* środku [[G3319]] WTA-DSN **των** *tōn* [[G3588]] WTT-GPF **επτα** *hepta* siedmiu [[G2033]] WTA-NUI **λυχνιων** *lychniōn* świeczników – stojaków lamp [[G3087]] WTN-GPF **των** *tōn* [[G3588]] WTT-GPF **χρυσων** *chrysōn* złotych [[G5552]] WTA-GPF
###### **Ap 2,2**
 **οιδα** *oida* Znam [[G1492]] WTV-RAI-1S **τα** *ta* [[G3588]] WTT-APN **εργα** *erga* dzieła – czyny [[G2041]] WTN-APN **σου** *sou* twoje [[G4675]] WTP-2GS **και** *kai* i [[G2532]] [[CONJ]] **τον** *ton* [[G3588]] [[T-ASM]] **κοπον** *kopon* trud [[G2873]] [[N-ASM]] **σου** *sou* twój [[G4675]] WTP-2GS **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **υπομονην** *hypomonēn* wytrwałość [[G5281]] WTN-ASF **σου** *sou* twoją [[G4675]] WTP-2GS **και** *kai* i [[G2532]] [[CONJ]] **οτι** *hoti* że [[G3754]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **δυνη** *dynē* możesz [[G1410]] WTV-PNI-2S-C **βαστασαι** *bastasai* unieść [[G941]] [[V-AAN]] **κακους** *kakous* złych [[G2556]] WTA-APM **και** *kai* i [[G2532]] [[CONJ]] **επειρασω** *epeirasō* doświadczyłeś – poddałeś próbie [[G3985]] WTV-AMI-2S **τους** *tous* [[G3588]] WTT-APM **φασκοντας** *faskontas* zapewniających [[G5335]] WTV-PAP-APM **ειναι** *einai* być [[G1511]] WTV-PXN **αποστολους** *apostolous* wysłannikami [[G652]] [[N-APM]] **και** *kai* a [[G2532]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **και** *kai* i [[G2532]] [[CONJ]] **ευρες** *heures* znalazłeś [[G2147]] WTV-2AAI-2S **αυτους** *autous* ich [[G846]] [[P-APM]] **ψευδεις** *pseudeis* fałszywymi – kłamliwymi [[G5571]] WTA-APM
###### **Ap 2,3**
 **και** *kai* i [[G2532]] [[CONJ]] **εβαστασας** *ebastasas* zniosłeś [[G941]] WTV-AAI-2S **και** *kai* i [[G2532]] [[CONJ]] **υπομονην** *hypomonēn* wytrwałość [[G5281]] WTN-ASF **εχεις** *echeis* masz [[G2192]] WTV-PAI-2S **και** *kai* i [[G2532]] [[CONJ]] **δια** *dia* z powodu – ze względu na [[G1223]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **ονομα** *onoma* imienia [[G3686]] WTN-ASN **μου** *mou* mojego [[G3450]] WTP-1GS **κεκοπιακας** *kekopiakas* trudziłeś się [[G2872]] WTV-RAI-2S **και** *kai* a [[G2532]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **κεκμηκας** *kekmēkas* zmęczyłeś się – załamałeś się [[G2577]] WTV-RAI-2S
###### **Ap 2,4**
 **αλλ** *all* Ale [[G235]] [[CONJ]] **εχω** *echō* mam [[G2192]] WTV-PAI-1S **κατα** *kata* przeciw [[G2596]] [[PREP]] **σου** *sou* tobie [[G4675]] WTP-2GS **οτι** *hoti* że [[G3754]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **αγαπην** *agapēn* miłość [[G26]] WTN-ASF **σου** *sou* twoją [[G4675]] WTP-2GS **την** *tēn* [[G3588]] WTT-ASF **πρωτην** *prōtēn* pierwszą [[G4413]] WTA-ASF **αφηκας** *afēkas* opuściłeś – pozostawiłeś [[G863]] WTV-AAI-2S
###### **Ap 2,5**
 **μνημονευε** *mnēmoneue* Pamiętaj – Przypominaj sobie [[G3421]] WTV-PAM-2S **ουν** *oun* więc [[G3767]] [[CONJ]] **ποθεν** *pothen* skąd [[G4159]] [[ADV]]-I **εκπεπτωκας** *ekpeptōkas* wypadłeś [[G1601]] WTV-RAI-2S **και** *kai* i [[G2532]] [[CONJ]] **μετανοησον** *metanoēson* opamiętaj się – zmień myślenie [[G3340]] WTV-AAM-2S **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **πρωτα** *prōta* pierwsze [[G4413]] WTA-APN **εργα** *erga* czyny – dzieła [[G2041]] WTN-APN **ποιησον** *poiēson* uczyń [[G4160]] WTV-AAM-2S **ει** *ei* jeśli [[G1487]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **ερχομαι** *erchomai* przychodzę [[G2064]] WTV-PNI-1S **σοι** *soi* (do) ciebie [[G4671]] WTP-2DS **ταχυ** *tachy* szybko – spiesznie [[G5035]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **κινησω** *kinēsō* poruszę [[G2795]] WTV-FAI-1S **την** *tēn* [[G3588]] WTT-ASF **λυχνιαν** *lychnian* świecznik – stojak lampy [[G3087]] WTN-ASF **σου** *sou* twój [[G4675]] WTP-2GS **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **τοπου** *topou* miejsca [[G5117]] [[N-GSM]] **αυτης** *autēs* jego [[G846]] [[P-GSF]] **εαν** *ean* jeśli [[G1437]] WTCOND **μη** *mē* nie [[G3361]] [[PRT-N]] **μετανοησης** *metanoēsēs* opamiętałbyś się – zmieniłbyś myślenie [[G3340]] WTV-AAS-2S
###### **Ap 2,6**
 **αλλα** *alla* Ale [[G235]] [[CONJ]] **τουτο** *touto* to [[G5124]] WTD-ASN **εχεις** *echeis* masz [[G2192]] WTV-PAI-2S **οτι** *hoti* że [[G3754]] [[CONJ]] **μισεις** *miseis* nienawidzisz [[G3404]] WTV-PAI-2S **τα** *ta* [[G3588]] WTT-APN **εργα** *erga* uczynków – dzieł [[G2041]] WTN-APN **των** *tōn* [[G3588]] WTT-GPM **νικολαιτων** *nikolaitōn* nikolaitów – [zwycięstwo ludu] [[G3531]] WTN-GPM **α** *ha* których [[G3739]] WTR-APN **καγω** *kagō* i Ja [[G2504]] WTP-1NS-C **μισω** *misō* nienawidzę [[G3404]] WTV-PAI-1S
###### **Ap 2,7**
 **ο** *ho* [[G3588]] [[T-NSM]] **εχων** *echōn* Mający [[G2192]] [[V-PAP-NSM]] **ους** *ous* ucho [[G3775]] WTN-ASN **ακουσατω** *akousatō* niech usłyszy [[G191]] WTV-AAM-3S **τι** *ti* co [[G5101]] WTI-ASN **το** *to* [[G3588]] WTT-NSN **πνευμα** *pneuma* Duch [[G4151]] WTN-NSN **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **ταις** *tais* [[G3588]] WTT-DPF **εκκλησιαις** *ekklēsiais* zgromadzeniom – (społecznościom) wywołanych [[G1577]] WTN-DPF **τω** *tō* [[G3588]] WTT-DSM **νικωντι** *nikōnti* zwyciężającemu [[G3528]] WTV-PAP-DSM **δωσω** *dōsō* dam [[G1325]] WTV-FAI-1S **αυτω** *autō* mu [[G846]] WTP-DSM **φαγειν** *fagein* zjeść [[G5315]] [[V-2AAN]] **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **ξυλου** *ksylou* drzewa [[G3586]] [[N-GSN]] **της** *tēs* [[G3588]] [[T-GSF]] **ζωης** *zōēs* życia [[G2222]] [[N-GSF]] **ο** *ho* które [[G3739]] WTR-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **εν** *en* w [[G1722]] [[PREP]] **μεσω** *mesō* środku [[G3319]] WTA-DSN **του** *tou* [[G3588]] WTT-GSM **παραδεισου** *paradeisou* raju [[G3857]] [[N-GSM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **Ap 2,8**
 **και** *kai* A [[G2532]] [[CONJ]] **τω** *tō* [[G3588]] WTT-DSM **αγγελω** *angelō* zwiastunowi [[G32]] WTN-DSM **της** *tēs* [[G3588]] [[T-GSF]] **εκκλησιας** *ekklēsias* zgromadzenia – (społeczności) wywołanych [[G1577]] [[N-GSF]] **σμυρναιων** *smyrnaiōn* smyrneńskiego – [mirra] [[G4668]] WTN-GPM **γραψον** *grapson* napisz [[G1125]] WTV-AAM-2S **ταδε** *tade* to [[G3592]] WTD-APN **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **πρωτος** *prōtos* pierwszy [[G4413]] [[A-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **εσχατος** *eschatos* ostatni [[G2078]] [[A-NSM]] **ος** *hos* który [[G3739]] WTR-NSM **εγενετο** *egeneto* stał się [[G1096]] WTV-2ADI-3S **νεκρος** *nekros* martwy [[G3498]] [[A-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **εζησεν** *ezēsen* ożył [[G2198]] [[V-AAI-3S]]
###### **Ap 2,9**
 **οιδα** *oida* Znam [[G1492]] WTV-RAI-1S **σου** *sou* twoje [[G4675]] WTP-2GS **τα** *ta* [[G3588]] WTT-APN **εργα** *erga* czyny – dzieła [[G2041]] WTN-APN **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **θλιψιν** *thlipsin* ucisk – utrapienie [[G2347]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **πτωχειαν** *ptōcheian* ubóstwo – skrajną nędzę [[G4432]] WTN-ASF **πλουσιος** *plousios* bogaty [[G4145]] [[A-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **ει** *ei* jesteś [[G1488]] WTV-PXI-2S **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **βλασφημιαν** *blasfēmian* bluźnienie – krzywdzące mówienie [[G988]] WTN-ASF **των** *tōn* (od) [[G3588]] WTT-GPM **λεγοντων** *legontōn* mówiących [[G3004]] WTV-PAP-GPM **ιουδαιους** *ioudaious* Judejczykami – [wielbić] [[G2453]] WTA-APM **ειναι** *einai* być [[G1511]] WTV-PXN **εαυτους** *heautous* sobie samym [[G1438]] WTF-3APM **και** *kai* a [[G2532]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **αλλα** *alla* ale [[G235]] [[CONJ]] **συναγωγη** *synagōgē* zgromadzenie – synagoga [[G4864]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSM **σατανα** *satana* szatana – [przeciwnik] [[G4567]] [[N-GSM]]
###### **Ap 2,10**
 **μηδεν** *mēden* Niczego [[G3367]] WTA-ASN **φοβου** *fobou* bój się [[G5399]] WTV-PNM-2S **α** *ha* co [[G3739]] WTR-APN **μελλεις** *melleis* masz [[G3195]] WTV-PAI-2S **πασχειν** *paschein* cierpieć [[G3958]] WTV-PAN **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **μελλει** *mellei* zamierza [[G3195]] WTV-PAI-3S **βαλειν** *balein* rzucić [[G906]] [[V-2AAN]] **εξ** *eks* z [[G1537]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **ο** *ho* [[G3588]] [[T-NSM]] **διαβολος** *diabolos* oszczerca – diabeł [[G1228]] [[A-NSM]] **εις** *eis* do [[G1519]] [[PREP]] **φυλακην** *fylakēn* strażnicy – więzienia [[G5438]] WTN-ASF **ινα** *hina* aby [[G2443]] [[CONJ]] **πειρασθητε** *peirasthēte* zostalibyście wypróbowani – zostalibyście doświadczeni [[G3985]] WTV-APS-2P **και** *kai* i [[G2532]] [[CONJ]] **εξετε** *eksete* będziecie mieć [[G2192]] WTV-FAI-2P **θλιψιν** *thlipsin* ucisk – utrapienie [[G2347]] WTN-ASF **ημερων** *hēmerōn* dni [[G2250]] WTN-GPF **δεκα** *deka* dziesięć [[G1176]] WTA-NUI **γινου** *ginou* stawaj się [[G1096]] WTV-PNM-2S **πιστος** *pistos* wierny [[G4103]] [[A-NSM]] **αχρι** *achri* aż do [[G891]] [[PREP]] **θανατου** *thanatou* śmierci [[G2288]] [[N-GSM]] **και** *kai* a [[G2532]] [[CONJ]] **δωσω** *dōsō* dam [[G1325]] WTV-FAI-1S **σοι** *soi* ci [[G4671]] WTP-2DS **τον** *ton* [[G3588]] [[T-ASM]] **στεφανον** *stefanon* wieniec – koronę [[G4735]] [[N-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **ζωης** *zōēs* życia [[G2222]] [[N-GSF]]
###### **Ap 2,11**
 **ο** *ho* [[G3588]] [[T-NSM]] **εχων** *echōn* Mający [[G2192]] [[V-PAP-NSM]] **ους** *ous* ucho [[G3775]] WTN-ASN **ακουσατω** *akousatō* niech usłyszy [[G191]] WTV-AAM-3S **τι** *ti* co [[G5101]] WTI-ASN **το** *to* [[G3588]] WTT-NSN **πνευμα** *pneuma* Duch [[G4151]] WTN-NSN **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **ταις** *tais* [[G3588]] WTT-DPF **εκκλησιαις** *ekklēsiais* zgromadzeniom – (społecznościom) wywołanych [[G1577]] WTN-DPF **ο** *ho* [[G3588]] [[T-NSM]] **νικων** *nikōn* zwyciężający [[G3528]] [[V-PAP-NSM]] **ου** *ou* nie [[G3756]] [[PRT-N]] **μη** *mē* [[G3361]] [[PRT-N]] **αδικηθη** *adikēthē* doznałby niesprawiedliwości – zostałby skrzywdzony [[G91]] WTV-APS-3S **εκ** *ek* od [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θανατου** *thanatou* śmierci [[G2288]] [[N-GSM]] **του** *tou* [[G3588]] WTT-GSM **δευτερου** *deuterou* drugiej [[G1208]] WTA-GSM
###### **Ap 2,12**
 **και** *kai* A [[G2532]] [[CONJ]] **τω** *tō* [[G3588]] WTT-DSM **αγγελω** *angelō* zwiastunowi [[G32]] WTN-DSM **της** *tēs* [[G3588]] [[T-GSF]] **εν** *en* w [[G1722]] [[PREP]] **περγαμω** *pergamō* Pergamonie – [wieża] [[G4010]] [[N-DSF]] **εκκλησιας** *ekklēsias* zgromadzeniu – (społeczności) wywołanych [[G1577]] [[N-GSF]] **γραψον** *grapson* napisz [[G1125]] WTV-AAM-2S **ταδε** *tade* to [[G3592]] WTD-APN **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **εχων** *echōn* mający [[G2192]] [[V-PAP-NSM]] **την** *tēn* [[G3588]] WTT-ASF **ρομφαιαν** *romfaian* miecz [[G4501]] WTN-ASF **την** *tēn* [[G3588]] WTT-ASF **διστομον** *distomon* obosieczny [[G1366]] WTA-ASF **την** *tēn* [[G3588]] WTT-ASF **οξειαν** *okseian* ostry [[G3691]] WTA-ASF
###### **Ap 2,13**
 **οιδα** *oida* Znam [[G1492]] WTV-RAI-1S **τα** *ta* [[G3588]] WTT-APN **εργα** *erga* czyny – dzieła [[G2041]] WTN-APN **σου** *sou* twoje [[G4675]] WTP-2GS **και** *kai* i [[G2532]] [[CONJ]] **που** *pou* gdzie [[G4226]] WTPRT-I **κατοικεις** *katoikeis* zamieszkujesz [[G2730]] WTV-PAI-2S **οπου** *hopou* gdzie – dokąd [[G3699]] [[ADV]] **ο** *ho* [[G3588]] [[T-NSM]] **θρονος** *thronos* tron [[G2362]] [[N-NSM]] **του** *tou* [[G3588]] WTT-GSM **σατανα** *satana* szatana – [przeciwnik] [[G4567]] [[N-GSM]] **και** *kai* a [[G2532]] [[CONJ]] **κρατεις** *krateis* trzymasz się [[G2902]] WTV-PAI-2S **το** *to* [[G3588]] WTT-ASN **ονομα** *onoma* imienia [[G3686]] WTN-ASN **μου** *mou* mojego [[G3450]] WTP-1GS **και** *kai* i [[G2532]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ηρνησω** *ērnēsō* wyparłeś się – odrzuciłeś [[G720]] WTV-ADI-2S **την** *tēn* [[G3588]] WTT-ASF **πιστιν** *pistin* wiary [[G4102]] WTN-ASF **μου** *mou* mojej [[G3450]] WTP-1GS **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **ημεραις** *hēmerais* dniach [[G2250]] WTN-DPF **εν** *en* w [[G1722]] [[PREP]] **αις** *hais* których [[G3739]] WTR-DPF **αντιπας** *antipas* Antypas – [podobny do ojca] [[G493]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **μαρτυς** *martys* świadek [[G3144]] [[N-NSM]] **μου** *mou* mój [[G3450]] WTP-1GS **ο** *ho* [[G3588]] [[T-NSM]] **πιστος** *pistos* wierny [[G4103]] [[A-NSM]] **ος** *hos* który [[G3739]] WTR-NSM **απεκτανθη** *apektanthē* został zabity [[G615]] [[V-API-3S]] **παρ** *par* u [[G3844]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **οπου** *hopou* gdzie – dokąd [[G3699]] [[ADV]] **κατοικει** *katoikei* zamieszkuje [[G2730]] WTV-PAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **σατανας** *satanas* szatan – [przeciwnik] [[G4567]] [[N-NSM]]
###### **Ap 2,14**
 **αλλ** *all* Ale [[G235]] [[CONJ]] **εχω** *echō* mam [[G2192]] WTV-PAI-1S **κατα** *kata* przeciw [[G2596]] [[PREP]] **σου** *sou* tobie [[G4675]] WTP-2GS **ολιγα** *oliga* trochę [[G3641]] WTA-APN **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **εχεις** *echeis* masz [[G2192]] WTV-PAI-2S **εκει** *ekei* tam [[G1563]] [[ADV]] **κρατουντας** *kratountas* trzymających się [[G2902]] WTV-PAP-APM **την** *tēn* [[G3588]] WTT-ASF **διδαχην** *didachēn* nauki – nauczania [[G1322]] WTN-ASF **βαλααμ** *balaam* Balaama – [nikt jak człowiek] [[G903]] [[N-PRI]] **ος** *hos* który [[G3739]] WTR-NSM **εδιδασκεν** *edidasken* nauczał [[G1321]] WTV-IAI-3S **τον** *ton* [[G3588]] [[T-ASM]] **βαλακ** *balak* Balaka – [niszczyciel] [[G904]] [[N-PRI]] **βαλειν** *balein* rzucić [[G906]] [[V-2AAN]] **σκανδαλον** *skandalon* zgorszenie [[G4625]] WTN-ASN **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **των** *tōn* [[G3588]] WTT-GPM **υιων** *hyiōn* synów [[G5207]] WTN-GPM **ισραηλ** *israēl* Izraela – [ten, który walczył z Bogiem] [[G2474]] [[N-PRI]] **φαγειν** *fagein* zjeść [[G5315]] [[V-2AAN]] **ειδωλοθυτα** *eidōlothyta* ofiarowane bóstwom – ofiarowane wizerunkom [[G1494]] WTA-APN **και** *kai* i [[G2532]] [[CONJ]] **πορνευσαι** *porneusai* popełniać nierząd – popełniać wszeteczeństwo [[G4203]] [[V-AAN]]
###### **Ap 2,15**
 **ουτως** *houtōs* Tak [[G3779]] [[ADV]] **εχεις** *echeis* masz [[G2192]] WTV-PAI-2S **και** *kai* i [[G2532]] [[CONJ]] **συ** *sy* ty [[G4771]] WTP-2NS **κρατουντας** *kratountas* trzymających się [[G2902]] WTV-PAP-APM **την** *tēn* [[G3588]] WTT-ASF **διδαχην** *didachēn* nauki – nauczania [[G1322]] WTN-ASF **των** *tōn* [[G3588]] WTT-GPM **νικολαιτων** *nikolaitōn* nikolaitów – [zwycięstwo ludu] [[G3531]] WTN-GPM **ο** *ho* których [[G3739]] WTR-ASN **μισω** *misō* nienawidzę [[G3404]] WTV-PAI-1S
###### **Ap 2,16**
 **μετανοησον** *metanoēson* Opamiętaj się – Zmień myślenie [[G3340]] WTV-AAM-2S **ει** *ei* jeśli [[G1487]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **ερχομαι** *erchomai* przychodzę [[G2064]] WTV-PNI-1S **σοι** *soi* (do) ciebie [[G4671]] WTP-2DS **ταχυ** *tachy* szybko – spiesznie [[G5035]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **πολεμησω** *polemēsō* będę wojować [[G4170]] WTV-FAI-1S **μετ** *met* z [[G3326]] [[PREP]] **αυτων** *autōn* nimi [[G846]] WTP-GPM **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **ρομφαια** *romfaia* mieczu [[G4501]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSN **στοματος** *stomatos* ust [[G4750]] [[N-GSN]] **μου** *mou* moich [[G3450]] WTP-1GS
###### **Ap 2,17**
 **ο** *ho* [[G3588]] [[T-NSM]] **εχων** *echōn* Mający [[G2192]] [[V-PAP-NSM]] **ους** *ous* ucho [[G3775]] WTN-ASN **ακουσατω** *akousatō* niech usłyszy [[G191]] WTV-AAM-3S **τι** *ti* co [[G5101]] WTI-ASN **το** *to* [[G3588]] WTT-NSN **πνευμα** *pneuma* Duch [[G4151]] WTN-NSN **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **ταις** *tais* [[G3588]] WTT-DPF **εκκλησιαις** *ekklēsiais* zgromadzeniom – (społecznościom) wywołanych [[G1577]] WTN-DPF **τω** *tō* [[G3588]] WTT-DSM **νικωντι** *nikōnti* zwyciężającemu [[G3528]] WTV-PAP-DSM **δωσω** *dōsō* dam [[G1325]] WTV-FAI-1S **αυτω** *autō* mu [[G846]] WTP-DSM **φαγειν** *fagein* zjeść [[G5315]] [[V-2AAN]] **απο** *apo* z [[G575]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **μαννα** *manna* manny – [co to jest?] [[G3131]] WTHEB **του** *tou* [[G3588]] WTT-GSM **κεκρυμμενου** *kekrymmenou* która jest ukryta [[G2928]] WTV-RPP-GSM **και** *kai* i [[G2532]] [[CONJ]] **δωσω** *dōsō* dam [[G1325]] WTV-FAI-1S **αυτω** *autō* mu [[G846]] WTP-DSM **ψηφον** *psēfon* kamyk [[G5586]] WTN-ASF **λευκην** *leukēn* biały [[G3022]] WTA-ASF **και** *kai* a [[G2532]] [[CONJ]] **επι** *epi* na [[G1909]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **ψηφον** *psēfon* kamyku [[G5586]] WTN-ASF **ονομα** *onoma* imię [[G3686]] WTN-NSN **καινον** *kainon* nowe [[G2537]] WTA-NSN **γεγραμμενον** *gegrammenon* które jest napisane [[G1125]] WTV-RPP-ASN **ο** *ho* które [[G3739]] WTR-ASN **ουδεις** *oudeis* nikt [[G3762]] [[A-NSM]] **εγνω** *egnō* poznał [[G1097]] WTV-2AAI-3S **ει** *ei* jeśli [[G1487]] WTCOND **μη** *mē* nie [[G3361]] [[PRT-N]] **ο** *ho* [[G3588]] [[T-NSM]] **λαμβανων** *lambanōn* przyjmujący – biorący [[G2983]] [[V-PAP-NSM]]
###### **Ap 2,18**
 **και** *kai* A [[G2532]] [[CONJ]] **τω** *tō* [[G3588]] WTT-DSM **αγγελω** *angelō* zwiastunowi [[G32]] WTN-DSM **της** *tēs* [[G3588]] [[T-GSF]] **εν** *en* w [[G1722]] [[PREP]] **θυατειροις** *thyateirois* Tiatyrze [[G2363]] WTN-DPN **εκκλησιας** *ekklēsias* zgromadzeniu – (społeczności) wywołanych [[G1577]] [[N-GSF]] **γραψον** *grapson* napisz [[G1125]] WTV-AAM-2S **ταδε** *tade* to [[G3592]] WTD-APN **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **υιος** *hyios* Syn [[G5207]] [[N-NSM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ο** *ho* [[G3588]] [[T-NSM]] **εχων** *echōn* mający [[G2192]] [[V-PAP-NSM]] **τους** *tous* [[G3588]] WTT-APM **οφθαλμους** *ofthalmous* oczy [[G3788]] [[N-APM]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ως** *hōs* jak [[G5613]] [[ADV]] **φλογα** *floga* płomień [[G5395]] [[N-NSF]] **πυρος** *pyros* ognia [[G4442]] [[N-GSN]] **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **ποδες** *podes* stopy [[G4228]] WTN-NPM **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ομοιοι** *homoioi* podobne [[G3664]] WTA-NPM **χαλκολιβανω** *chalkolibanō* kadzidłu z mosiądzu – roztopionemu mosiądzu [[G5474]] WTN-DSN
###### **Ap 2,19**
 **οιδα** *oida* Znam [[G1492]] WTV-RAI-1S **σου** *sou* twoje [[G4675]] WTP-2GS **τα** *ta* [[G3588]] WTT-APN **εργα** *erga* czyny – dzieła [[G2041]] WTN-APN **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **αγαπην** *agapēn* miłość [[G26]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **διακονιαν** *diakonian* posługę – służbę [[G1248]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **πιστιν** *pistin* wiarę [[G4102]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **υπομονην** *hypomonēn* wytrwałość [[G5281]] WTN-ASF **σου** *sou* twoją [[G4675]] WTP-2GS **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **εργα** *erga* czyny – dzieła [[G2041]] WTN-APN **σου** *sou* twoje [[G4675]] WTP-2GS **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **εσχατα** *eschata* ostatnie [[G2078]] WTA-APN **πλειονα** *pleiona* większe [[G4119]] WTA-APN-C **των** *tōn* (niż) [[G3588]] WTT-GPN **πρωτων** *prōtōn* pierwsze [[G4413]] WTA-GPN
###### **Ap 2,20**
 **αλλ** *all* Ale [[G235]] [[CONJ]] **εχω** *echō* mam [[G2192]] WTV-PAI-1S **κατα** *kata* przeciw [[G2596]] [[PREP]] **σου** *sou* tobie [[G4675]] WTP-2GS **ολιγα** *oliga* trochę [[G3641]] WTA-APN **οτι** *hoti* że [[G3754]] [[CONJ]] **εας** *eas* pozwalasz – dopuszczasz [[G1439]] WTV-PAI-2S **την** *tēn* [[G3588]] WTT-ASF **γυναικα** *gynaika* kobiecie [[G1135]] WTN-ASF **ιεζαβηλ** *iezabēl* Jezebel [[G2403]] [[N-PRI]] **την** *tēn* [[G3588]] WTT-ASF **λεγουσαν** *legousan* nazywającą [[G3004]] WTV-PAP-ASF **εαυτην** *heautēn* siebie [[G1438]] WTF-3ASF **προφητιν** *profētin* prorokinią [[G4398]] WTN-ASF **διδασκειν** *didaskein* nauczać [[G1321]] WTV-PAN **και** *kai* i [[G2532]] [[CONJ]] **πλανασθαι** *planasthai* być zwodzonymi – być wprowadzanymi w błąd [[G4105]] WTV-PPN **εμους** *emous* moi [[G1699]] WTS-1APM **δουλους** *doulous* niewolnicy – słudzy [[G1401]] [[N-APM]] **πορνευσαι** *porneusai* (by) popełniać nierząd – (by) popełniać wszeteczeństwo [[G4203]] [[V-AAN]] **και** *kai* i [[G2532]] [[CONJ]] **ειδωλοθυτα** *eidōlothyta* ofiarowane bóstwom – ofiarowane wizerunkom [[G1494]] WTA-APN **φαγειν** *fagein* zjeść [[G5315]] [[V-2AAN]]
###### **Ap 2,21**
 **και** *kai* i [[G2532]] [[CONJ]] **εδωκα** *edōka* dałem [[G1325]] WTV-AAI-1S **αυτη** *autē* jej [[G846]] WTP-DSF **χρονον** *chronon* czas [[G5550]] [[N-ASM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **μετανοηση** *metanoēsē* opamiętałaby się – zmieniłaby myślenie [[G3340]] WTV-AAS-3S **εκ** *ek* z [[G1537]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **πορνειας** *porneias* nierządu – wszeteczeństwa [[G4202]] [[N-GSF]] **αυτης** *autēs* jej [[G846]] [[P-GSF]] **και** *kai* a [[G2532]] [[CONJ]] **ου** *hou* nie [[G3756]] [[PRT-N]] **μετενοησεν** *metenoēsen* opamiętała się – zmieniła myślenie [[G3340]] [[V-AAI-3S]]
###### **Ap 2,22**
 **ιδου** *idou* Oto [[G2400]] WTV-2AAM-2S **εγω** *egō* Ja [[G1473]] WTP-1NS **βαλλω** *ballō* rzucam [[G906]] WTV-PAI-1S **αυτην** *autēn* ją [[G846]] [[P-ASF]] **εις** *eis* na [[G1519]] [[PREP]] **κλινην** *klinēn* łoże – posłanie [[G2825]] WTN-ASF **και** *kai* a [[G2532]] [[CONJ]] **τους** *tous* [[G3588]] WTT-APM **μοιχευοντας** *moicheuontas* cudzołożących [[G3431]] WTV-PAP-APM **μετ** *met* z [[G3326]] [[PREP]] **αυτης** *autēs* nią [[G846]] [[P-GSF]] **εις** *eis* w [[G1519]] [[PREP]] **θλιψιν** *thlipsin* ucisk – utrapienie [[G2347]] WTN-ASF **μεγαλην** *megalēn* wielki [[G3173]] WTA-ASF **εαν** *ean* jeśli [[G1437]] WTCOND **μη** *mē* nie [[G3361]] [[PRT-N]] **μετανοησωσιν** *metanoēsōsin* opamiętaliby się – zmieniliby myślenie [[G3340]] WTV-AAS-3P **εκ** *ek* z [[G1537]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **εργων** *ergōn* uczynków – dzieł [[G2041]] WTN-GPN **αυτων** *autōn* ich [[G846]] WTP-GPM
###### **Ap 2,23**
 **και** *kai* I [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **τεκνα** *tekna* dzieci [[G5043]] WTN-APN **αυτης** *autēs* jej [[G846]] [[P-GSF]] **αποκτενω** *apoktenō* zabiję [[G615]] WTV-FAI-1S **εν** *en* w [[G1722]] [[PREP]] **θανατω** *thanatō* śmierci [[G2288]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **γνωσονται** *gnōsontai* poznają [[G1097]] WTV-FDI-3P **πασαι** *pasai* wszystkie [[G3956]] [[A-NPF]] **αι** *hai* [[G3588]] [[T-NPF]] **εκκλησιαι** *ekklēsiai* zgromadzenia – (społeczności) wywołanych [[G1577]] [[N-NPF]] **οτι** *hoti* że [[G3754]] [[CONJ]] **εγω** *egō* Ja [[G1473]] WTP-1NS **ειμι** *eimi* jestem [[G1510]] WTV-PXI-1S **ο** *ho* [[G3588]] [[T-NSM]] **ερευνων** *ereunōn* badający – zgłębiający [[G2045]] [[V-PAP-NSM]] **νεφρους** *nefrous* nerki [[G3510]] [[N-APM]] **και** *kai* i [[G2532]] [[CONJ]] **καρδιας** *kardias* serca [[G2588]] WTN-APF **και** *kai* i [[G2532]] [[CONJ]] **δωσω** *dōsō* dam [[G1325]] WTV-FAI-1S **υμιν** *hymin* wam [[G5213]] WTP-2DP **εκαστω** *hekastō* każdemu [[G1538]] WTA-DSM **κατα** *kata* według [[G2596]] [[PREP]] **τα** *ta* [[G3588]] WTT-APN **εργα** *erga* czynów – dzieł [[G2041]] WTN-APN **υμων** *hymōn* waszych [[G5216]] WTP-2GP
###### **Ap 2,24**
 **υμιν** *hymin* Wam [[G5213]] WTP-2DP **δε** *de* zaś [[G1161]] [[CONJ]] **λεγω** *legō* mówię [[G3004]] WTV-PAI-1S **και** *kai* i [[G2532]] [[CONJ]] **λοιποις** *loipois* pozostałym [[G3062]] WTA-DPM **τοις** *tois* [[G3588]] WTT-DPM **εν** *en* w [[G1722]] [[PREP]] **θυατειροις** *thyateirois* Tiatyrze [[G2363]] WTN-DPN **οσοι** *hosoi* ilu – jacy [[G3745]] WTK-NPM **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εχουσιν** *echousin* mają [[G2192]] WTV-PAI-3P **την** *tēn* [[G3588]] WTT-ASF **διδαχην** *didachēn* nauki – nauczanie [[G1322]] WTN-ASF **ταυτην** *tautēn* tej [[G3778]] WTD-ASF **και** *kai* i [[G2532]] [[CONJ]] **οιτινες** *hoitines* którzy [[G3748]] WTR-NPM **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εγνωσαν** *egnōsan* poznali [[G1097]] WTV-2AAI-3P **τα** *ta* [[G3588]] WTT-APN **βαθη** *bathē* głębokości [[G899]] WTN-APN **του** *tou* [[G3588]] WTT-GSM **σατανα** *satana* szatańskich – [przeciwnik] [[G4567]] [[N-GSM]] **ως** *hōs* jak [[G5613]] [[ADV]] **λεγουσιν** *legousin* mówią [[G3004]] WTV-PAI-3P **ου** *ou* nie [[G3756]] [[PRT-N]] **βαλω** *balō* rzucam [[G906]] WTV-FAI-1S **εφ** *ef* na [[G1909]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **αλλο** *allo* innego [[G243]] WTA-ASN **βαρος** *baros* ciężaru [[G922]] WTN-ASN
###### **Ap 2,25**
 **πλην** *plēn* Nadto – Jednakże [[G4133]] [[ADV]] **ο** *ho* co [[G3739]] WTR-ASN **εχετε** *echete* macie [[G2192]] WTV-PAI-2P **κρατησατε** *kratēsate* trzymajcie [[G2902]] WTV-AAM-2P **αχρις** *achris* aż do [[G891]] [[PREP]] **ου** *hou* kiedy- [[G3739]] WTR-GSM **αν** *an* kolwiek [[G302]] WTPRT **ηξω** *hēksō* przyszedłbym [[G2240]] WTV-AAS-1S
###### **Ap 2,26**
 **και** *kai* I [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **νικων** *nikōn* zwyciężający [[G3528]] [[V-PAP-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **τηρων** *tērōn* zachowujący – strzegący [[G5083]] [[V-PAP-NSM]] **αχρι** *achri* aż do [[G891]] [[PREP]] **τελους** *telous* końca [[G5056]] [[N-GSN]] **τα** *ta* [[G3588]] WTT-APN **εργα** *erga* uczynków – dzieł [[G2041]] WTN-APN **μου** *mou* moich [[G3450]] WTP-1GS **δωσω** *dōsō* dam [[G1325]] WTV-FAI-1S **αυτω** *autō* mu [[G846]] WTP-DSM **εξουσιαν** *eksousian* władzę [[G1849]] WTN-ASF **επι** *epi* nad [[G1909]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **εθνων** *ethnōn* poganami – narodami [[G1484]] WTN-GPN
###### **Ap 2,27**
 **και** *kai* i [[G2532]] [[CONJ]] **ποιμανει** *poimanei* będzie pasł [[G4165]] WTV-FAI-3S **αυτους** *autous* ich [[G846]] [[P-APM]] **εν** *en* w [[G1722]] [[PREP]] **ραβδω** *rabdō* lasce – rózdze [[G4464]] [[N-DSF]] **σιδηρα** *sidēra* żelaznej [[G4603]] WTA-DSF **ως** *hōs* jak [[G5613]] [[ADV]] **τα** *ta* [[G3588]] WTT-NPN **σκευη** *skeuē* naczynia [[G4632]] WTN-NPN **τα** *ta* [[G3588]] WTT-NPN **κεραμικα** *keramika* gliniane [[G2764]] WTA-NPN **συντριβεται** *syntribetai* jest kruszone (są kruszone) [[G4937]] WTV-PPI-3S **ως** *hōs* jak [[G5613]] [[ADV]] **καγω** *kagō* i Ja [[G2504]] WTP-1NS-C **ειληφα** *eilēfa* wziąłem – otrzymałem [[G2983]] WTV-RAI-1S **παρα** *para* od [[G3844]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **πατρος** *patros* Ojca [[G3962]] [[N-GSM]] **μου** *mou* mojego [[G3450]] WTP-1GS
###### **Ap 2,28**
 **και** *kai* i [[G2532]] [[CONJ]] **δωσω** *dōsō* dam [[G1325]] WTV-FAI-1S **αυτω** *autō* mu [[G846]] WTP-DSM **τον** *ton* [[G3588]] [[T-ASM]] **αστερα** *astera* gwiazdę [[G792]] [[N-ASM]] **τον** *ton* [[G3588]] [[T-ASM]] **πρωινον** *prōinon* poranną [[G4407]] WTA-ASM
###### **Ap 2,29**
 **ο** *ho* [[G3588]] [[T-NSM]] **εχων** *echōn* Mający [[G2192]] [[V-PAP-NSM]] **ους** *ous* ucho [[G3775]] WTN-ASN **ακουσατω** *akousatō* niech usłyszy [[G191]] WTV-AAM-3S **τι** *ti* co [[G5101]] WTI-ASN **το** *to* [[G3588]] WTT-NSN **πνευμα** *pneuma* Duch [[G4151]] WTN-NSN **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **ταις** *tais* [[G3588]] WTT-DPF **εκκλησιαις** *ekklēsiais* zgromadzeniom – (społecznościom) wywołanych [[G1577]] WTN-DPF
