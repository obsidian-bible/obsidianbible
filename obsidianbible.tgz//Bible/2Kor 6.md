# 2Kor 6 BT5
###### **2Kor 6,1**
 Współdziałając zaś z Nim, napominamy was, abyście nie przyjmowali na próżno łaski Bożej.
###### **2Kor 6,2**
 Mówi bowiem [Pismo]: W czasie pomyślnym wysłuchałem cię, w dniu zbawienia przyszedłem ci z pomocą. Oto teraz czas upragniony, oto teraz dzień zbawienia.
###### **2Kor 6,3**
 Nie dając nikomu sposobności do zgorszenia, aby nie wyszydzono < naszej > posługi,
###### **2Kor 6,4**
  okazujemy się sługami Boga przez wszystko: przez wielką cierpliwość, wśród utrapień, przeciwności i ucisków,
###### **2Kor 6,5**
 w chłostach, więzieniach, podczas rozruchów, w trudach, nocnych czuwaniach i w postach,
###### **2Kor 6,6**
 przez czystość i umiejętność, przez wielkoduszność i łagodność, przez [objawy] Ducha Świętego i miłość nieobłudną,
###### **2Kor 6,7**
 przez głoszenie prawdy i moc Bożą, przez oręż sprawiedliwości zaczepny i obronny,
###### **2Kor 6,8**
 wśród czci i pohańbienia, przez zniesławienie i dobrą sławę. Uchodzący za oszustów, a przecież prawdomówni, niby nieznani, a przecież dobrze znani,
###### **2Kor 6,9**
 niby umierający, a oto żyjemy, jakby karceni, lecz nie uśmiercani,
###### **2Kor 6,10**
 jakby smutni, lecz zawsze radośni, jakby ubodzy, a jednak wzbogacający wielu, jako ci, którzy nic nie mają, a posiadają wszystko.
###### **2Kor 6,11**
 Usta nasze otwarły się do was, Koryntianie, rozszerzyło się nasze serce.
###### **2Kor 6,12**
 Nie brak wam miejsca w moim sercu, lecz w waszych sercach jest ciasno.
###### **2Kor 6,13**
 Odpłacając się nam w ten sposób, otwórzcie się i wy: jak do swoich dzieci mówię.
###### **2Kor 6,14**
 Nie sprzęgajcie się z niewierzącymi do jednego jarzma. Cóż bowiem ma wspólnego sprawiedliwość z niesprawiedliwością? Albo cóż ma wspólnego światło z ciemnością?
###### **2Kor 6,15**
 Albo jakież jest współuczestnictwo Chrystusa z Beliarem lub wierzącego z niewiernym?
###### **2Kor 6,16**
 Co wreszcie łączy świątynię Boga z bożkami? Bo my jesteśmy świątynią Boga żywego – według tego, co mówi Bóg: Zamieszkam z nimi i będę chodził wśród nich, i będę ich Bogiem, a oni będą moim ludem.
###### **2Kor 6,17**
 Przeto wyjdźcie spomiędzy nich i odłączcie się od nich, mówi Pan, i nie tykajcie tego, co nieczyste, a Ja was przyjmę
###### **2Kor 6,18**
 i będę wam Ojcem, a wy będziecie moimi synami i córkami – mówi Pan wszechmogący.
# 2Kor 6 PAU
###### **2Kor 6,1**
 Jako Jego współpracownicy, zachęcamy was, abyście na próżno nie przyjmowali łaski Bożej.
###### **2Kor 6,2**
 Mówi bowiem: W czasie zmiłowania wysłuchałem ciebie, w dniu zbawienia przyszedłem ci z pomocą. Teraz właśnie jest czas łaskawości, teraz właśnie jest dzień zbawienia!
###### **2Kor 6,3**
 W niczym nikogo nie chcemy obrazić, aby to posługiwanie nie zostało wyśmiane,
###### **2Kor 6,4**
 ale we wszystkim okazujemy się sługami Boga: w wielkiej wytrwałości, w utrapieniach, w niedostatkach, w uciskach,
###### **2Kor 6,5**
 w chłostach, w więzieniach, w zamieszkach, w trudach, w czuwaniach, w postach,
###### **2Kor 6,6**
 w czystości, w poznawaniu, w cierpliwości, w dobroci, w Duchu Świętym, w nieobłudnej miłości,
###### **2Kor 6,7**
 w prawdziwej nauce, w mocy Boga; przez oręż sprawiedliwości zaczepny i obronny,
###### **2Kor 6,8**
 przez chwałę i zawstydzenie, przez oczernianie i sławienie; uznani za zwodzicieli, a jednak prawdomówni;
###### **2Kor 6,9**
 za nieznanych, a jednak znani; za umierających, a jednak żyjący; jako karani, a jednak nie uśmiercani;
###### **2Kor 6,10**
 jako zasmucani, ale zawsze radośni; jako ubodzy, a wzbogacający wielu; jako nieposiadający niczego, a posiadający wszystko.
###### **2Kor 6,11**
 Koryntianie! Nasze usta otwierają się przed wami, bo nasze serce jest dla was szeroko otwarte.
###### **2Kor 6,12**
 W nas nie jest wam za ciasno, ale ciasne jest wasze wnętrze.
###### **2Kor 6,13**
 Odpłaćcie tym samym! Mówię do was jak do dzieci: Otwórzcie i wy wasze serca!
###### **2Kor 6,14**
 Nie chodźcie z niewierzącymi w cudzym zaprzęgu. Co bowiem łączy sprawiedliwość z bezprawiem? Cóż ma wspólnego światło z ciemnością?
###### **2Kor 6,15**
 Jaka jest zgodność między Chrystusem a Beliarem? Co łączy wierzącego z niewierzącym?
###### **2Kor 6,16**
 Co ma wspólnego świątynia Boga z posągami bożków? To my jesteśmy świątynią Boga żywego, jak rzekł Bóg: Zamieszkam z nimi i wśród nich będę się przechadzał, i będę ich Bogiem, a oni będą moim ludem.
###### **2Kor 6,17**
 Dlatego wyjdźcie spośród nich i odłączcie się - mówi Pan - i nie dotykajcie tego, co nieczyste, a Ja was przyjmę
###### **2Kor 6,18**
 i będę wam Ojcem, a wy będziecie moimi synami i córkami - mówi Pan Wszechmocny.
# 2Kor 6 BP
###### **2Kor 6,1**
 Jako współpracownicy Boga napominamy was, abyście nie przyjmowali łaski Bożej na próżno.
###### **2Kor 6,2**
 Mówi bowiem [Pismo Święte]: "W czasie mojej łaskawości wysłuchałem cię, w dniu zbawienia przyszedłem ci z pomocą". Oto zaraz czas szczególnej łaskawości, oto teraz dzień zbawienia.
###### **2Kor 6,3**
 Nikomu w niczym nie dajemy powodu do zgorszenia, aby nie wyszydzono naszego posługiwania.
###### **2Kor 6,4**
 W każdej okoliczności okazujemy, że jesteśmy sługami cierpliwości i w utrapieniach, wśród przeciwności i ucisków,
###### **2Kor 6,5**
 w chłostach i w więzieniach, podczas rozruchów i wśród trudów, w czuwaniach nocnych i postach,
###### **2Kor 6,6**
 przez czystość i wiedzę, przez wielkoduszność i dobroć, przez dary Ducha Świętego i nieobłudną miłość,
###### **2Kor 6,7**
 przez słowo prawdy i objawy mocy Bożej, przez korzystanie w obronie i w natarciu z oręża, które służy sprawiedliwości,
###### **2Kor 6,8**
 czy otacza nas chwała, czy hańba, czy okrywa nas sława, czy też niesława. Uważają nas za oszustów, a my jesteśmy prawdomówni, traktują nas jak nieznanych, a przecież jesteśmy znani,
###### **2Kor 6,9**
 wyglądamy na umierających, a oto żyjemy, jesteśmy karceni, lecz nie uśmierceni,
###### **2Kor 6,10**
 wyglądamy na smutnych, a zawsze jesteśmy radośni, na ubogich, a wielu wzbogacamy, na tych, którzy niczego nie mają, a posiadamy wszystko.
###### **2Kor 6,11**
 Koryntianie! Do was otworzyły się usta nasze i dla was rozszerzyło się nasze serce.
###### **2Kor 6,12**
 Dla was w naszym sercu nie ma ograniczenia, ale wasze uczucia są ograniczone.
###### **2Kor 6,13**
 Odpłaćcie się tym samym! Mówię jak do swoich dzieci - rozszerzcie i wy swoje serca!
###### **2Kor 6,14**
 Nie wprzęgajcie się w jedno jarzmo z niewierzącymi. Co ma bowiem wspólnego sprawiedliwość z nieprawością? Albo co ma wspólnego światło z ciemnością?
###### **2Kor 6,15**
 Czy może istnieć harmonia pomiędzy Chrystusem a Belialem? Co ma wspólnego wierzący z niewierzącym?
###### **2Kor 6,16**
 Co łączy świątynię Boga z bożkami? My bowiem jesteśmy świątynią Boga żywego, zgodnie z tym, co Bóg powiedział: "Zamieszkam wśród nich i pomiędzy nimi będę się przechadzał, i będę ich Bogiem, a oni będą moim ludem.
###### **2Kor 6,17**
 Przeto wyjdźcie spośród pogan i odłączcie się od nich - mówi Pan. Nie dotykajcie się tego, co nieczyste, a Ja was przyjmę.
###### **2Kor 6,18**
 Będę wam Ojcem, a wy będziecie moimi synami i córkami. To mówi Pan wszechmogący".
# 2Kor 6 BR
###### **2Kor 6,1**
 Współdziałając zaś z Nim, napominamy was, abyście nie przyjmowali na próżno łaski Bożej.
###### **2Kor 6,2**
 Mówi bowiem [Pismo]: W czasie pomyślnym wysłuchałem cię, w dniu zbawienia przyszedłem ci z pomocą. Oto teraz czas upragniony, oto teraz dzień zbawienia.
###### **2Kor 6,3**
 Nie dając nikomu sposobności do zgorszenia, aby nie wyszydzano naszej posługi,
###### **2Kor 6,4**
 okazujemy się sługami Boga przez wszystko: przez wielką cierpliwość, wśród utrapień, przeciwności i ucisków,
###### **2Kor 6,5**
 w chłostach, więzieniach, podczas rozruchów, w trudach, nocnych czuwaniach i w postach,
###### **2Kor 6,6**
 przez czystość i umiejętność, przez wielkoduszność i łagodność, przez [objawy] Ducha Świętego i miłość nieobłudną,
###### **2Kor 6,7**
 przez głoszenie prawdy i moc Bożą, przez oręż sprawiedliwości zaczepny i obronny,
###### **2Kor 6,8**
 wśród czci i pohańbienia, przez zniesławienie i dobrą sławę. Uchodzący za kłamców, a przecież prawdomówni, niby nieznani, a przecież dobrze znani,
###### **2Kor 6,9**
 niby umierający, a oto żyjemy, jakby karceni, lecz nie uśmiercani,
###### **2Kor 6,10**
 jakby smutni, lecz zawsze radośni, jakby ubodzy, a jednak wzbogacający wielu, jako ci, którzy nic nie mają, a posiadają wszystko.
###### **2Kor 6,11**
 Usta nasze otwarły się do was, Koryntianie, rozszerzyło się nasze serce.
###### **2Kor 6,12**
 Nie brak wam miejsca w moim sercu, lecz w waszych sercach jest ciasno.
###### **2Kor 6,13**
 Odpłacając się nam w ten sposób, otwórzcie się i wy: jak do swoich dzieci mówię.
###### **2Kor 6,14**
 Nie sprzęgajcie się z niewierzącymi do jednego jarzma. Cóż bowiem ma wspólnego sprawiedliwość z niesprawiedliwością? Albo cóż ma wspólnego światło z ciemnością?
###### **2Kor 6,15**
 Albo jakaż jest wspólnota Chrystusa z Beliarem lub wierzącego z niewiernym?
###### **2Kor 6,16**
 Co wreszcie łączy świątynię Boga z bożkami? Bo my jesteśmy świątynią Boga żywego według tego, co mówi Bóg: Zamieszkam z nimi i będę chodził wśród nich, i będę ich Bogiem, a oni będą moim ludem.
###### **2Kor 6,17**
 Przeto wyjdźcie spośród nichi odłączcie się od nich, mówi Pan, i nie tykajcie tego, co nieczyste, a Ja was przyjmę
###### **2Kor 6,18**
 i będę wam Ojcem, a wy będziecie moimi synami i córkami mówi Pan wszechmocny.
# 2Kor 6 WUJ
###### **2Kor 6,1**
 A pomagając napominamy, abyście nadaremno łaski Bożej nie przyjęli.
###### **2Kor 6,2**
 (Abowiem mówi: Czasu przyjemnego wysłuchałem cię: a w dzień zbawienia ratowałem cię. Oto teraz czas przyjemny: oto teraz dzień zbawienia).
###### **2Kor 6,3**
 Nie dawając nikomu żadnego zgorszenia, aby nie było naganione posługowanie nasze.
###### **2Kor 6,4**
 Ale we wszystkiem stawmy samych siebie jako sługi Boże, w cierpliwości wielkiej, w utrapieniach, w potrzebach, w uciskach:
###### **2Kor 6,5**
 W biciu, w więzieniu, w rozruchach, w pracach, w niespaniach, w pościech:
###### **2Kor 6,6**
 W czystości, w umiejętności, w nieskwapliwośći, w łagodności, w Duchu świętym, w miłości nie obłudnej:
###### **2Kor 6,7**
 W mowie prawdy, w mocy Bożej, przez broń sprawiedliwości po prawicy, i po lewicy:
###### **2Kor 6,8**
 Przez chwałę i zelżywość, przez osławienie i dobrą sławę: jakoby zwodnicy, a prawdziwi: jako którzy nie znajomi, a znajomi:
###### **2Kor 6,9**
 Jako umierający, a oto żywiemy: jako karani, a nie umorzeni:
###### **2Kor 6,10**
 Jako smętni, lecz zawsze weseli: jako ubodzy a wielu ubogacający: jako nic nie mający, a wszystko mający.
###### **2Kor 6,11**
 Usta nasze Koryntowie otworzone ku wam, serce nasze jest rozszerzone.
###### **2Kor 6,12**
 Nie jesteście ściśnieni w nas: lecz ściśnieni jesteście w wnętrznościach waszych.
###### **2Kor 6,13**
 A mając nagrodę (mówię jako synom) rozprzestrzeńcie się i wy.
###### **2Kor 6,14**
 Nie ciągnijcie jarzma z niewiernemi. Abowiem co za uczestnictwo sprawiedliwości z nieprawością? Abo co za towarzystwo światłości z ciemnościami?
###### **2Kor 6,15**
 Abo co za zgoda Chrystusowi z Belialem. Abo co za część wiernemu z niewiernym?
###### **2Kor 6,16**
 A co za zgoda kościołowi Bożemu z bałwanami? Abowiem wy jesteście kościołem Boga żywego, jako mówi Bóg: Iż będę mieszkał i przechadzał się w nich, i będę Bogiem ich, a oni będą mi ludem.
###### **2Kor 6,17**
 Przeto wynidźcie z pośrodku ich, i oddzielcie się, mówi Pan, a nieczystego się nie dotykajcie: a ja was przyjmę.
###### **2Kor 6,18**
 I będę wam za ojca, a wy będziecie mi za syny i córki, mówi Pan wszechmogący.
# 2Kor 6 STERN
###### **2Kor 6,1**
 Jako Boży współpracownicy, nalegamy też, abyście nie przyjmowali tej łaski po to, aby później nic z nią nie robić.
###### **2Kor 6,2**
 Bo mówi On: "W czasie łaski usłyszałem cię; w dniu zbawienia wspomogłem cię". Oto teraz czas łaski, oto teraz dzień zbawienia.
###### **2Kor 6,3**
 Staramy się nie stawiać przeszkód na niczyjej drodze, aby nikt nie mógł naszej pracy nic zarzucić.
###### **2Kor 6,4**
 Przeciwnie, staramy się polecać siebie pod każdym względem jako Boży pracownicy, wciąż znosząc ucisk, trudy, niedole,
###### **2Kor 6,5**
 bicie, więzienie, zamieszki, przemęczenie, brak snu i żywności.
###### **2Kor 6,6**
 Staramy się polecać siebie poprzez naszą czystość, wiedzę, cierpliwość i dobroć, przez Ruach Ha-Kodesz, przez szczerość miłości
###### **2Kor 6,7**
 i prawdomówność, i przez moc Bożą. Polecamy siebie przez władanie sprawiedliwym orężem, albo forsując naszą sprawę, albo broniąc jej,
###### **2Kor 6,8**
 jako czczeni i poniżani, chwaleni i oskarżani, uważani za podstępnych i za uczciwych,
###### **2Kor 6,9**
 nieznani i sławni. I polecamy siebie jako pracownicy Boży idący na śmierć - lecz oto żyjemy! Jako karani - lecz nie zabijani,
###### **2Kor 6,10**
 jako mający powody do smutku, lecz zawsze pełni radości, jako ubodzy, lecz wzbogacający wielu, jako nieposiadający nic, ale posiadający wszystko!
###### **2Kor 6,11**
 Drodzy przyjaciele z Koryntu! Mówimy do was szczerze, otworzyliśmy serca szeroko.
###### **2Kor 6,12**
 Wszelki przymus, jaki odczuwacie, nie przez nas został narzucony, lecz z głębi waszego serca.
###### **2Kor 6,13**
 Żeby więc być "w porządku" (mówię językiem dzieci), i wy szeroko otwórzcie swe serca.
###### **2Kor 6,14**
 Nie wprzęgajcie się w jeden zespół z niewierzącymi. Bo jak sprawiedliwość i bezprawie mogą być wspólnikami? Jaka jest wspólnota między światłem a ciemnością?
###### **2Kor 6,15**
 Jaka może być zgodność między Mesjaszem a B'lija'alem? Co wierzący ma wspólnego z niewierzącym?
###### **2Kor 6,16**
 Jaka może być zgoda między świątynią Bożą a bałwanami? Bo my jesteśmy świątynią Boga żywego - jak rzekł Bóg: "Zamieszkam w nich [...] i będę przebywał pośród nich. Będę ich Bogiem, a oni będą moim ludem". Dlatego Adonai powiada:
###### **2Kor 6,17**
 "Wyjdźcie spośród nich, oddzielcie się, nie dotykajcie tego, co nieczyste. Wtedy ja sam was przyjmę.
###### **2Kor 6,18**
 Zaiste, będę waszym Ojcem, a wy będziecie moimi synami i córkami - mówi Adonai-Cwa'ot".
# 2Kor 6 TRO
###### **2Kor 6,1**
 **συνεργουντες** *synergountes* Współdziałając – Współpracując [[G4903]] WTV-PAP-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **παρακαλουμεν** *parakaloumen* prosimy – zachęcamy [[G3870]] WTV-PAI-1P **μη** *mē* aby nie [[G3361]] [[PRT-N]] **εις** *eis* na [[G1519]] [[PREP]] **κενον** *kenon* próżno – pusto [[G2756]] WTA-ASN **την** *tēn* [[G3588]] WTT-ASF **χαριν** *charin* łaskę [[G5485]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **δεξασθαι** *deksasthai* przyjąć [[G1209]] WTV-ADN **υμας** *hymas* wam [[G5209]] WTP-2AP
###### **2Kor 6,2**
 **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **καιρω** *kairō* porą [[G2540]] WTN-DSM **δεκτω** *dektō* przychylnym – godnym przyjęcia [[G1184]] WTA-DSM **επηκουσα** *epēkousa* wysłuchałem – dosłyszałem [[G1873]] WTV-AAI-1S **σου** *sou* cię [[G4675]] WTP-2GS **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **ημερα** *hēmera* dniu [[G2250]] [[N-DSF]] **σωτηριας** *sōtērias* zbawienia – wyzwolenia [[G4991]] [[N-GSF]] **εβοηθησα** *eboēthēsa* pomogłem [[G997]] WTV-AAI-1S **σοι** *soi* ci [[G4671]] WTP-2DS **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **νυν** *nyn* teraz [[G3568]] [[ADV]] **καιρος** *kairos* pora [[G2540]] [[N-NSM]] **ευπροσδεκτος** *euprosdektos* bardzo godna przyjęcia [[G2144]] [[A-NSM]] **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **νυν** *nyn* teraz [[G3568]] [[ADV]] **ημερα** *hēmera* dzień [[G2250]] [[N-NSF]] **σωτηριας** *sōtērias* zbawienia – wyzwolenia [[G4991]] [[N-GSF]]
###### **2Kor 6,3**
 **μηδεμιαν** *mēdemian* żadnego [[G3367]] WTA-ASF **εν** *en* w [[G1722]] [[PREP]] **μηδενι** *mēdeni* niczym [[G3367]] WTA-DSN **διδοντες** *didontes* dając [[G1325]] WTV-PAP-NPM **προσκοπην** *proskopēn* przedmiotu potknięcia się [[G4349]] WTN-ASF **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **μωμηθη** *mōmēthē* zostałaby zhańbiona – zostałaby podważona [[G3469]] WTV-APS-3S **η** *hē* [[G3588]] [[T-NSF]] **διακονια** *diakonia* posługa – służba [[G1248]] [[N-NSF]]
###### **2Kor 6,4**
 **αλλ** *all* ale [[G235]] [[CONJ]] **εν** *en* we [[G1722]] [[PREP]] **παντι** *panti* wszystkim [[G3956]] WTA-DSN **συνιστωντες** *synistōntes* stawiając – polecając [[G4921]] WTV-PAP-NPM **εαυτους** *heautous* siebie samych [[G1438]] WTF-3APM **ως** *hōs* jako [[G5613]] [[ADV]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **διακονοι** *diakonoi* słudzy [[G1249]] WTN-NPM **εν** *en* w [[G1722]] [[PREP]] **υπομονη** *hypomonē* wytrwałości [[G5281]] [[N-DSF]] **πολλη** *pollē* wielkiej [[G4183]] WTA-DSF **εν** *en* w [[G1722]] [[PREP]] **θλιψεσιν** *thlipsesin* uciskach – utrapieniach [[G2347]] WTN-DPF **εν** *en* w [[G1722]] [[PREP]] **αναγκαις** *anagkais* potrzebach – trudnościach [[G318]] WTN-DPF **εν** *en* w [[G1722]] [[PREP]] **στενοχωριαις** *stenochōriais* udrękach – uciskach [[G4730]] WTN-DPF
###### **2Kor 6,5**
 **εν** *en* w [[G1722]] [[PREP]] **πληγαις** *plēgais* ciosach – razach [[G4127]] WTN-DPF **εν** *en* w [[G1722]] [[PREP]] **φυλακαις** *fylakais* strażnicach – więzieniach [[G5438]] WTN-DPF **εν** *en* w [[G1722]] [[PREP]] **ακαταστασιαις** *akatastasiais* niepokojach – rozruchach [[G181]] WTN-DPF **εν** *en* w [[G1722]] [[PREP]] **κοποις** *kopois* trudach [[G2873]] WTN-DPM **εν** *en* w [[G1722]] [[PREP]] **αγρυπνιαις** *agrypniais* bezsennych nocach – bezsennościach [[G70]] WTN-DPF **εν** *en* w [[G1722]] [[PREP]] **νηστειαις** *nēsteiais* postach [[G3521]] WTN-DPF
###### **2Kor 6,6**
 **εν** *en* w [[G1722]] [[PREP]] **αγνοτητι** *hagnotēti* czystości – nieskalaności [[G54]] [[N-DSF]] **εν** *en* w [[G1722]] [[PREP]] **γνωσει** *gnōsei* poznaniu – wiedzy [[G1108]] [[N-DSF]] **εν** *en* w [[G1722]] [[PREP]] **μακροθυμια** *makrothymia* cierpliwości – wyrozumiałości [[G3115]] [[N-DSF]] **εν** *en* w [[G1722]] [[PREP]] **χρηστοτητι** *chrēstotēti* uprzejmości – łagodności [[G5544]] [[N-DSF]] **εν** *en* w [[G1722]] [[PREP]] **πνευματι** *pneumati* Duchu [[G4151]] WTN-DSN **αγιω** *hagiō* Świętym [[G40]] WTA-DSN **εν** *en* w [[G1722]] [[PREP]] **αγαπη** *agapē* miłości [[G26]] [[N-DSF]] **ανυποκριτω** *anypokritō* nieobłudnej [[G505]] WTA-DSF
###### **2Kor 6,7**
 **εν** *en* w [[G1722]] [[PREP]] **λογω** *logō* Słowie [[G3056]] WTN-DSM **αληθειας** *alētheias* prawdy [[G225]] [[N-GSF]] **εν** *en* w [[G1722]] [[PREP]] **δυναμει** *dynamei* mocy [[G1411]] [[N-DSF]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **δια** *dia* przez [[G1223]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **οπλων** *hoplōn* oręża [[G3696]] WTN-GPN **της** *tēs* [[G3588]] [[T-GSF]] **δικαιοσυνης** *dikaiosynēs* sprawiedliwości [[G1343]] [[N-GSF]] **των** *tōn* (z) [[G3588]] WTT-GPM **δεξιων** *deksiōn* prawa – prawych [[G1188]] WTA-GPM **και** *kai* i [[G2532]] [[CONJ]] **αριστερων** *aristerōn* lewa – lewych [[G710]] WTA-GPM
###### **2Kor 6,8**
 **δια** *dia* przez [[G1223]] [[PREP]] **δοξης** *doksēs* chwałę [[G1391]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **ατιμιας** *atimias* zniewagę – brak szacunku [[G819]] [[N-GSF]] **δια** *dia* przez [[G1223]] [[PREP]] **δυσφημιας** *dysfēmias* złą sławę – obelgę [[G1426]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **ευφημιας** *eufēmias* pochwałę [[G2162]] [[N-GSF]] **ως** *hōs* jak [[G5613]] [[ADV]] **πλανοι** *planoi* zwodziciele – oszuści [[G4108]] WTA-NPM **και** *kai* a [[G2532]] [[CONJ]] **αληθεις** *alētheis* prawdomówni – szczerzy [[G227]] WTA-NPM
###### **2Kor 6,9**
 **ως** *hōs* jak [[G5613]] [[ADV]] **αγνοουμενοι** *agnooumenoi* którzy są nieznani – którzy są niepoznawani [[G50]] WTV-PPP-NPM **και** *kai* a [[G2532]] [[CONJ]] **επιγινωσκομενοι** *epiginōskomenoi* którzy są dobrze znani – którzy są uznawani [[G1921]] WTV-PPP-NPM **ως** *hōs* jak [[G5613]] [[ADV]] **αποθνησκοντες** *apothnēskontes* umierający [[G599]] WTV-PAP-NPM **και** *kai* a [[G2532]] [[CONJ]] **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **ζωμεν** *zōmen* żyjemy [[G2198]] WTV-PAI-1P **ως** *hōs* jak [[G5613]] [[ADV]] **παιδευομενοι** *paideuomenoi* którzy są korygowani – którzy są dyscyplinowani [[G3811]] WTV-PPP-NPM **και** *kai* a [[G2532]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **θανατουμενοι** *thanatoumenoi* którzy są zabijani – którzy są uśmiercani [[G2289]] WTV-PPP-NPM
###### **2Kor 6,10**
 **ως** *hōs* jak [[G5613]] [[ADV]] **λυπουμενοι** *lypoumenoi* którzy są zasmucani [[G3076]] WTV-PPP-NPM **αει** *aei* zawsze [[G104]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **χαιροντες** *chairontes* radujący się – cieszący się [[G5463]] WTV-PAP-NPM **ως** *hōs* jak [[G5613]] [[ADV]] **πτωχοι** *ptōchoi* ubodzy [[G4434]] WTA-NPM **πολλους** *pollous* wielu [[G4183]] WTA-APM **δε** *de* zaś [[G1161]] [[CONJ]] **πλουτιζοντες** *ploutizontes* wzbogacający [[G4148]] WTV-PAP-NPM **ως** *hōs* jak [[G5613]] [[ADV]] **μηδεν** *mēden* nic [[G3367]] WTA-ASN **εχοντες** *echontes* mający [[G2192]] WTV-PAP-NPM **και** *kai* a [[G2532]] [[CONJ]] **παντα** *panta* wszystkie [[G3956]] WTA-APN **κατεχοντες** *katechontes* nabywający – trzymający [[G2722]] WTV-PAP-NPM
###### **2Kor 6,11**
 **το** *to* [[G3588]] WTT-NSN **στομα** *stoma* Usta [[G4750]] WTN-NSN **ημων** *hēmōn* nasze [[G2257]] WTP-1GP **ανεωγεν** *aneōgen* otworzył się (otworzyły się) [[G455]] WTV-2RAI-3S **προς** *pros* do [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **κορινθιοι** *korinthioi* Koryntianie [[G2881]] WTA-VPM **η** *hē* [[G3588]] [[T-NSF]] **καρδια** *kardia* serce [[G2588]] [[N-NSF]] **ημων** *hēmōn* nasze [[G2257]] WTP-1GP **πεπλατυνται** *peplatyntai* jest rozszerzone [[G4115]] WTV-RPI-3S
###### **2Kor 6,12**
 **ου** *ou* Nie [[G3756]] [[PRT-N]] **στενοχωρεισθε** *stenochōreisthe* jesteście ściśnięci – jesteście przytłoczonymi [[G4729]] WTV-PPI-2P **εν** *en* w [[G1722]] [[PREP]] **ημιν** *hēmin* nas [[G2254]] WTP-1DP **στενοχωρεισθε** *stenochōreisthe* jesteście ściśnięci – jesteście przytłoczonymi [[G4729]] WTV-PPI-2P **δε** *de* zaś [[G1161]] [[CONJ]] **εν** *en* we [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPN **σπλαγχνοις** *splagchnois* wnętrznościach – głębokich uczuciach [[G4698]] WTN-DPN **υμων** *hymōn* waszych [[G5216]] WTP-2GP
###### **2Kor 6,13**
 **την** *tēn* [[G3588]] WTT-ASF **δε** *de* zaś [[G1161]] [[CONJ]] **αυτην** *autēn* tą samą [[G846]] [[P-ASF]] **αντιμισθιαν** *antimisthian* zapłatę – nagrodę [[G489]] WTN-ASF **ως** *hōs* jak [[G5613]] [[ADV]] **τεκνοις** *teknois* dzieciom [[G5043]] WTN-DPN **λεγω** *legō* mówię [[G3004]] WTV-PAI-1S **πλατυνθητε** *platynthēte* niech zostaną rozszerzone [[G4115]] WTV-APM-2P **και** *kai* i [[G2532]] [[CONJ]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP
###### **2Kor 6,14**
 **μη** *mē* Nie [[G3361]] [[PRT-N]] **γινεσθε** *ginesthe* stawajcie się [[G1096]] WTV-PNM-2P **ετεροζυγουντες** *heterozygountes* noszącymi obce jarzmo [[G2086]] WTV-PAP-NPM **απιστοις** *apistois* (z) niewierzącymi [[G571]] WTA-DPM **τις** *tis* jakie [[G5101]] WTI-NSF **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **μετοχη** *metochē* uczestniczenie – społeczność [[G3352]] [[N-NSF]] **δικαιοσυνη** *dikaiosynē* sprawiedliwości [[G1343]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **ανομια** *anomia* bezprawia – nieprawości [[G458]] [[N-DSF]] **τις** *tis* jaka [[G5101]] WTI-NSF **δε** *de* zaś [[G1161]] [[CONJ]] **κοινωνια** *koinōnia* wspólnota [[G2842]] [[N-NSF]] **φωτι** *fōti* światła [[G5457]] WTN-DSN **προς** *pros* z [[G4314]] [[PREP]] **σκοτος** *skotos* ciemnością [[G4655]] WTN-ASN
###### **2Kor 6,15**
 **τις** *tis* Jaka [[G5101]] WTI-NSF **δε** *de* zaś [[G1161]] [[CONJ]] **συμφωνησις** *symfōnēsis* zgoda – harmonia [[G4857]] [[N-NSF]] **χριστω** *christō* Pomazańca [[G5547]] WTN-DSM **προς** *pros* z [[G4314]] [[PREP]] **βελιαλ** *belial* Belialem – [pan lasu] [[G955]] [[N-PRI]] **η** *ē* lub [[G2228]] WTPRT **τις** *tis* jaki [[G5101]] WTI-NSF **μερις** *meris* dział – udział [[G3310]] [[N-NSF]] **πιστω** *pistō* wiernemu [[G4103]] WTA-DSM **μετα** *meta* z [[G3326]] [[PREP]] **απιστου** *apistou* niewierzącym [[G571]] WTA-GSM
###### **2Kor 6,16**
 **τις** *tis* Jaka [[G5101]] WTI-NSF **δε** *de* zaś [[G1161]] [[CONJ]] **συγκαταθεσις** *sygkatathesis* zgodność [[G4783]] [[N-NSF]] **ναω** *naō* świątyni – przybytku [[G3485]] WTN-DSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **μετα** *meta* z [[G3326]] [[PREP]] **ειδωλων** *eidōlōn* bożkami – fałszywymi bogami [[G1497]] WTN-GPN **υμεις** *hymeis* wy [[G5210]] WTP-2NP **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ναος** *naos* świątynia – przybytek [[G3485]] [[N-NSM]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **ζωντος** *zōntos* żyjącego [[G2198]] WTV-PAP-GSM **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **οτι** *hoti* że [[G3754]] [[CONJ]] **ενοικησω** *enoikēsō* zamieszkam [[G1774]] WTV-FAI-1S **εν** *en* w [[G1722]] [[PREP]] **αυτοις** *autois* nich [[G846]] WTP-DPM **και** *kai* i [[G2532]] [[CONJ]] **εμπεριπατησω** *emperipatēsō* przejdę się – będę wśród chodzić [[G1704]] WTV-FAI-1S **και** *kai* i [[G2532]] [[CONJ]] **εσομαι** *esomai* będę [[G2071]] WTV-FXI-1S **αυτων** *autōn* ich [[G846]] WTP-GPM **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **αυτοι** *autoi* oni [[G846]] WTP-NPM **εσονται** *esontai* będą [[G2071]] WTV-FXI-3P **μοι** *moi* mój [[G3427]] WTP-1DS **λαος** *laos* lud [[G2992]] [[N-NSM]]
###### **2Kor 6,17**
 **διο** *dio* Dlatego [[G1352]] [[CONJ]] **εξελθετε** *ekselthete* wyjdźcie [[G1831]] WTV-2AAM-2P **εκ** *ek* z [[G1537]] [[PREP]] **μεσου** *mesou* spośród – środka [[G3319]] [[A-GSN]] **αυτων** *autōn* nich [[G846]] WTP-GPM **και** *kai* i [[G2532]] [[CONJ]] **αφορισθητε** *aforisthēte* zostańcie odłączeni – zostańcie oddzieleni [[G873]] WTV-APM-2P **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ακαθαρτου** *akathartou* nieczystego [[G169]] [[A-GSN]] **μη** *mē* nie [[G3361]] [[PRT-N]] **απτεσθε** *haptesthe* dotykajcie się [[G680]] WTV-PMM-2P **καγω** *kagō* a ja [[G2504]] WTP-1NS-C **εισδεξομαι** *eisdeksomai* przyjmę – wpuszczę [[G1523]] WTV-FDI-1S **υμας** *hymas* was [[G5209]] WTP-2AP
###### **2Kor 6,18**
 **και** *kai* i [[G2532]] [[CONJ]] **εσομαι** *esomai* będę [[G2071]] WTV-FXI-1S **υμιν** *hymin* wam [[G5213]] WTP-2DP **εις** *eis* za [[G1519]] [[PREP]] **πατερα** *patera* Ojca [[G3962]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **εσεσθε** *esesthe* będziecie [[G2071]] WTV-FXI-2P **μοι** *moi* mi [[G3427]] WTP-1DS **εις** *eis* za [[G1519]] [[PREP]] **υιους** *hyious* synów [[G5207]] [[N-APM]] **και** *kai* i [[G2532]] [[CONJ]] **θυγατερας** *thygateras* córki [[G2364]] WTN-APF **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **παντοκρατωρ** *pantokratōr* Wszechmogący – Wszechwładca [[G3841]] [[N-NSM]]
