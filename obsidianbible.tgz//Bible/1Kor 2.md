# 1Kor 2 BT5
###### **1Kor 2,1**
 Tak też i ja, przyszedłszy do was, bracia, nie przybyłem, aby błyszcząc słowem i mądrością, głosić wam świadectwo Boże.
###### **1Kor 2,2**
 Postanowiłem bowiem, będąc wśród was, nie znać niczego więcej, jak tylko Jezusa Chrystusa, i to ukrzyżowanego.
###### **1Kor 2,3**
 I stanąłem przed wami w słabości i w bojaźni, i z wielkim drżeniem.
###### **1Kor 2,4**
 A mowa moja i moje głoszenie nauki nie miały nic z uwodzących przekonywaniem słów mądrości, lecz były ukazywaniem ducha i mocy,
###### **1Kor 2,5**
 aby wiara wasza opierała się nie na mądrości ludzkiej, lecz na mocy Bożej.
###### **1Kor 2,6**
 A jednak głosimy mądrość między doskonałymi, ale nie mądrość tego świata ani władców tego świata, [zresztą] przemijających.
###### **1Kor 2,7**
 Lecz głosimy tajemnicę mądrości Bożej, mądrość ukrytą, tę, którą Bóg przed wiekami przeznaczył ku chwale naszej,
###### **1Kor 2,8**
 tę, której nie pojął żaden z władców tego świata; gdyby ją bowiem pojęli, nie ukrzyżowaliby Pana chwały;
###### **1Kor 2,9**
 lecz właśnie [nauczamy], jak zostało napisane: Ani oko nie widziało, ani ucho nie słyszało, ani serce człowieka nie zdołało pojąć, jak wielkie rzeczy przygotował Bóg tym, którzy Go miłują.
###### **1Kor 2,10**
 Nam zaś objawił to Bóg przez Ducha. Duch przenika wszystko, nawet głębokości Boga samego.
###### **1Kor 2,11**
 Kto zaś z ludzi zna to, co ludzkie, jeżeli nie duch, który jest w człowieku? Podobnie i tego, co Boskie, nie zna nikt, tylko Duch Boży.
###### **1Kor 2,12**
 Otóż my nie otrzymaliśmy ducha świata, lecz Ducha, który jest z Boga, dla poznania dobra, jakim Bóg nas obdarzył.
###### **1Kor 2,13**
 A głosimy to nie za pomocą wyszukanych słów ludzkiej mądrości, lecz korzystamy z pouczeń Ducha, przedkładając duchowe sprawy tym, którzy są z Ducha.
###### **1Kor 2,14**
 Człowiek zmysłowy bowiem nie pojmuje tego, co jest z Bożego Ducha. Głupstwem mu się to wydaje i nie może tego pojąć, bo tylko Duchem można to zrozumieć.
###### **1Kor 2,15**
 Człowiek zaś duchowy rozsądza wszystko, lecz sam przez nikogo nie jest sądzony.
###### **1Kor 2,16**
 Któż więc poznał zamysł Pana tak, by Go mógł pouczać? My właśnie znamy zamysł Chrystusowy.
# 1Kor 2 PAU
###### **1Kor 2,1**
 Bracia! Przyszedłem do was nie po to, by głosić tajemnicę Boga błyskotliwymi i uczonymi słowami.
###### **1Kor 2,2**
 Postanowiłem wśród was nie znać niczego innego, jak tylko Jezusa Chrystusa, i to ukrzyżowanego.
###### **1Kor 2,3**
 Przybyłem do was w słabości, w bojaźni i z wielkim drżeniem.
###### **1Kor 2,4**
 A moja mowa i nauczanie nie opierały się na mądrych wywodach, ale na ukazywaniu Ducha i mocy,
###### **1Kor 2,5**
 aby wasza wiara opierała się nie na mądrości ludzkiej, ale na mocy Bożej.
###### **1Kor 2,6**
 Głosimy mądrość ludziom doskonałym. Nie jest to mądrość tego świata ani władców tego świata, którzy przeminą.
###### **1Kor 2,7**
 Głosimy mądrość Bożą ukrytą w tajemnicy, którą przed wiekami Bóg przeznaczył dla naszej chwały.
###### **1Kor 2,8**
 Nie poznał jej żaden z władców tego świata, gdyby ją bowiem poznali, nie ukrzyżowaliby Pana chwały.
###### **1Kor 2,9**
 Napisano bowiem: czego oko nie widziało ani ucho nie słyszało, w serce człowieka nie wstąpiło, to przygotował Bóg tym, którzy Go miłują.
###### **1Kor 2,10**
 Bóg objawił nam to przez Ducha, a Duch przenika wszystko, nawet głębokości Boga.
###### **1Kor 2,11**
 Któż bowiem wie, co kryje się w człowieku, jeśli nie duch człowieka, który w nim jest? Tak i Boga nikt by nie poznał, gdyby nie Duch Boży.
###### **1Kor 2,12**
 My nie otrzymaliśmy ducha od świata, ale Ducha od Boga, aby poznać dary otrzymane od Boga.
###### **1Kor 2,13**
 Nie głosimy tego uczonymi słowami ludzkiej mądrości, ale dzięki pouczeniom Ducha, przedstawiamy sprawy duchowe tym, którzy są z Ducha.
###### **1Kor 2,14**
 Bo człowiek zmysłowy nie przyjmuje tego, co pochodzi od Bożego Ducha. Jest to dla niego głupstwem i nie może zrozumieć, że ocenia się to na sposób duchowy.
###### **1Kor 2,15**
 Człowiek duchowy natomiast ocenia wszystko, lecz sam nie jest przez nikogo oceniany.
###### **1Kor 2,16**
 Kto bowiem poznał myśl Pana, która mogłaby go pouczać? Oto my znamy myśl Chrystusa.
# 1Kor 2 BP
###### **1Kor 2,1**
 Bracia! I ja, kiedy przybyłem do was, aby wam oznajmić świadectwo o Bogu, nie zamierzałem zabłysnąć słowem lub mądrością.
###### **1Kor 2,2**
 Postanowiłem bowiem, że nie będę wśród was znał niczego poza Jezusem Chrystusem i to ukrzyżowanym.
###### **1Kor 2,3**
 I tak przybyłem do was ze słabością i z bojaźnią oraz z wielkim drżeniem.
###### **1Kor 2,4**
 Moja mowa i nauczanie nie opierały się na przekonywających słowach mądrości, lecz na okazaniu ducha i mocy,
###### **1Kor 2,5**
 aby wasza wiara nie wypływała z ludzkiej mądrości, ale z mocy Bożej.
###### **1Kor 2,6**
 Głosimy wprawdzie mądrość, lecz wśród dojrzałych duchowo. Nie jest to jednak mądrość zgodna z pojęciami tego świata lub jego władców, którzy przemijają.
###### **1Kor 2,7**
 Głosimy bowiem mądrość Bożą pełną tajemnic i ukrytą, którą Bóg już przed wiekami przeznaczył ku naszej chwale.
###### **1Kor 2,8**
 Tej mądrości nie pojął nikt z władców tego świata, bo gdyby ją byli pojęli, nie ukrzyżowaliby Pana chwały.
###### **1Kor 2,9**
 My głosimy mądrość, o której napisano: "Czego oko nie widziało ani ucho nie słyszało, czego serce człowieka nie zdołało pojąć, to przygotował Bóg tym, którzy Go miłują".
###### **1Kor 2,10**
 Nam zaś objawił to Bóg przez Ducha. Duch bowiem wszystko przenika, nawet głębię samego Boga.
###### **1Kor 2,11**
 Kto spośród ludzi wie, co jest w człowieku, jeśli nie duch człowieka, który w nim jest? Podobnie i tego, co w Bogu jest, nikt nie zna, oprócz Ducha Bożego.
###### **1Kor 2,12**
 Otóż my nie otrzymaliśmy ducha, którym świat się kieruje, lecz Ducha, który od Boga pochodzi. Otrzymaliśmy go zaś w tym celu, aby poznać dary, którymi Bóg nas obdarzył.
###### **1Kor 2,13**
 Nie głosimy tego słowami wypływającymi z ludzkiej mądrości, lecz słowami, których uczy Duch. Objaśniamy sprawy duchowe ludziom, którzy poddają się działaniu Ducha.
###### **1Kor 2,14**
 Człowiek kierujący się tylko zasadami naturalnymi nie pojmuje spraw Ducha Bożego. Uważa je za głupotę i nie jest w stanie tych spraw zrozumieć, ponieważ należy je rozstrzygać w sposób duchowy.
###### **1Kor 2,15**
 Człowiek zaś kierujący się Duchem rozstrzyga wszystko, natomiast jego nikt nie osądza.
###### **1Kor 2,16**
 "Któż zatem poznał myśl Pana tak, aby mógł Go pouczać?" My właśnie mamy myśl Chrystusa.
# 1Kor 2 BR
###### **1Kor 2,1**
 Tak też i ja przyszedłszy do was, bracia, nie przybyłem, by błyszcząc słowem i mądrością dawać wam świadectwo Boże.
###### **1Kor 2,2**
 Postanowiłem bowiem, będąc wśród was, nie znać niczego więcej, jak tylko Jezusa Chrystusa, i to ukrzyżowanego.
###### **1Kor 2,3**
 I stanąłem przed wami w słabości i w bojaźni, i z wielkim drżeniem.
###### **1Kor 2,4**
 A mowa moja i moje głoszenie nauki nie miały nic z uwodzących przekonywaniem słów mądrości
###### **1Kor 2,6**
 A jednak głosimy mądrość między doskonałymi, ale nie mądrość tego świata ani władców tego świata, zresztą przemijających.
###### **1Kor 2,7**
 Lecz nosimy tajemnicę mądrości Bożej, mądrość ukrytą, tę, którą Bóg przed wiekami przeznaczył ku chwale naszej,
###### **1Kor 2,8**
 tę, której nie pojął żaden z władców tego świata; gdyby ją bowiem pojęli, nie ukrzyżowaliby Pana chwały,
###### **1Kor 2,9**
 lecz właśnie nauczamy, jak zostało napisane: ani oko nie widziało, ani ucho nie słyszało, ani serce człowieka nie zdołało pojąć, jak wielkie rzeczy przygotował Bóg tym, którzy Go miłują.
###### **1Kor 2,10**
 Nam zaś objawił to Bóg przez Ducha. Duch przenika wszystko, nawet głębokości Boga samego.
###### **1Kor 2,11**
 Kto zaś z ludzi zna to, co ludzkie, jeżeli nie duch, który jest w człowieku? Podobnie i tego, co Boskie, nie zna nikt, tylko Duch Boży.
###### **1Kor 2,12**
 Otóż myśmy nie otrzymali ducha świata, lecz Ducha, który jest z Boga, ku poznaniu dobra, jakim Bóg nas obdarzył.
###### **1Kor 2,13**
 A głosimy to nie za pomocą wyszukanych słów ludzkiej mądrości, lecz korzystamy z pouczeń Ducha, przedkładając duchowe sprawy tym, którzy są z Ducha.
###### **1Kor 2,14**
 Człowiek zmysłowy bowiem nie pojmuje tego, co jest z Bożego Ducha. Głupstwem mu się to wydaje i nie jest zdolny pojąć, bo tylko Duchem można to zrozumieć.
###### **1Kor 2,15**
 Człowiek zaś duchowy rozsądza wszystko, lecz sam przez nikogo nie jest sądzony.
###### **1Kor 2,16**
 Któż więc poznał zamysł Pana, tak by Go mógł pouczać? My właśnie znamy zamysł Chrystusowy.
# 1Kor 2 WUJ
###### **1Kor 2,1**
 A ja, gdym przyszedł do was bracia, przyszedłem nie z wyniosłością mowy abo mądrości, opowiadając wam świadectwo Chrystusowe.
###### **1Kor 2,2**
 Abowiem nie rozumiałem, żebym miał co umieć między wami, jedno Jezusa Chrystusa, i tego ukrzyżowanego.
###### **1Kor 2,3**
 I byłem ja ze mdłością,. i z bojaźnią, i ze drżeniem wielkiem u was:
###### **1Kor 2,4**
 A mowa moja i przepowiadanie moje nie w przyłudzających mądrości ludzkiej słowiech, ale w okazaniu ducha i mocy:
###### **1Kor 2,5**
 Aby wiara wasza nie była w mądrości ludzkiej, ale w mocy Bożej. A powiadamy mądrość między doskonałemi.
###### **1Kor 2,6**
 A mądrość nie wieku tego, ani książąt wieku tego, którzy się każą,
###### **1Kor 2,7**
 Ale powiadamy mądrość Bożą w tajemnicy, która zakryta jest, którą Bóg przeznaczył przed wieki ku chwale naszej.
###### **1Kor 2,8**
 Której żaden z książąt wieku tego nie poznał: Bo gdyby byli poznali, nigdyby byli, Pana chwały nie ukrzyżowali.
###### **1Kor 2,9**
 Ale jako jest napisano, Czego oko nie widziało, i ucho nie słyszało, i w serce człowiecze nie wstąpiło, ca nagotował Bóg tym, którzy go miłują.
###### **1Kor 2,10**
 Lecz nam Bóg objawił przez Ducha swojego. abowiem Duch wszystko wypatruje , i głębokości Boże.
###### **1Kor 2,11**
 Bo któż z ludzi wie co jest człowieczego, jedno duch człowieczy, który w nim jest? także też co jest Bożego nikt nie wie, jedno Duch Boży.
###### **1Kor 2,12**
 A my nie wzięliśmy ducha tego świata, ale ducha, który jest z Boga: abyśmy wiedzieli co nam od Boga jest darowano.
###### **1Kor 2,13**
 Co też opowiadamy nie przez uczone słowa ludzkiej mądrości: ale przez naukę Ducha, duchownym duchowne rzeczy przystosując.
###### **1Kor 2,14**
 A człowiek cielesny nie pojmuje tego co jest Ducha Bożego: abowiem głupstwem jemu jest, i nie może rozumieć: iż duchownie bywa rozsądzon.
###### **1Kor 2,15**
 Lecz duchowny rozsądza wszystko, a sam od żadnego nie bywa rozsądzon.
###### **1Kor 2,16**
 Abowiem któż poznał umysł Pański, któryby go nauczył? lecz my umysł Chrystusów mamy.
# 1Kor 2 STERN
###### **1Kor 2,1**
 Co do mnie zaś, bracia, gdy do was przybyłem, to nie w nadzwyczajnej wymowie ani mądrości przyszedłem wam oznajmiać ukrytą przedtem prawdę o Bogu;
###### **1Kor 2,2**
 bo postanowiłem, że będąc z wami, zapomnę o wszystkim prócz Jeszui Mesjasza, i to tylko jako tego, który został stracony na palu jak zbrodniarz.
###### **1Kor 2,3**
 Byłem też wśród was jako słaby, stremowany i cały drżący z lęku,
###### **1Kor 2,4**
 a nauka moja ani przez sposób mówienia, ani w swojej treści nie była oparta na przekonujących słowach "mądrości", lecz na przejawianiu się mocy Ducha,
###### **1Kor 2,5**
 aby wasza ufność nie opierała się na ludzkiej mądrości, ale na mocy Bożej.
###### **1Kor 2,6**
 Jest jednak pewna mądrość, którą głosimy tym, co do niej dojrzeli. Nie jest to jednak mądrość tego świata ani przywódców tego świata, którzy podlegają przemijaniu.
###### **1Kor 2,7**
 Przeciwnie, przekazujemy utajoną mądrość od Boga, która aż dotąd była ukryta, lecz o której Bóg u zarania dziejów zarządził, że ma nam przynieść chwałę.
###### **1Kor 2,8**
 Nie zrozumiał jej ani jeden z przywódców tego świata; bo gdyby zrozumieli, nie uśmierciliby Pana, od którego chwała ta płynie.
###### **1Kor 2,9**
 Ale jak mówi Tanach: "Ani oko nie widziało, ani ucho nie słyszało, ani serce niczyje nie przedstawiło sobie tego wszystkiego, co przygotował Bóg tym, którzy Go miłują".
###### **1Kor 2,10**
 To nam jednak Bóg objawił te rzeczy. Jak? Przez Ducha. Bo Duch bada wszystko, nawet bezdenne głębiny Boga.
###### **1Kor 2,11**
 Bo kto wie, co dzieje się w człowieku, jeśli nie duch tego człowieka, który w nim jest? Również nikt nie wie tego, co dzieje się w Bogu, wyjąwszy Ducha Bożego.
###### **1Kor 2,12**
 A myśmy nie otrzymali ducha świata, ale Ducha Boga, abyśmy zrozumieli to, co Bóg tak łaskawie nam dał.
###### **1Kor 2,13**
 Te właśnie sprawy głosimy, gdy unikamy mówienia tak, jak nakazywałaby mądrość ludzka, a mówimy tak, jak uczy Duch, objaśniając w ten sposób sprawy Ducha ludziom, którzy mają Ducha.
###### **1Kor 2,14**
 Otóż człowiek naturalny nie przyjmuje rzeczy od Ducha Bożego - są dla niego absurdem! Zresztą nie jest w stanie ich pojąć, bo osądza się je z pomocą Ducha.
###### **1Kor 2,15**
 Ale człowiek, który ma Ducha, może osądzić wszystko, lecz nikt nie jest w stanie osądzić jego.
###### **1Kor 2,16**
 Bo "któż poznał umysł Adonai?. Kto był Jego doradcą?". Ale my mamy umysł Mesjasza!
# 1Kor 2 TRO
###### **1Kor 2,1**
 **καγω** *kagō* A ja [[G2504]] WTP-1NS-C **ελθων** *elthōn* przyszedłszy [[G2064]] WTV-2AAP-NSM **προς** *pros* do [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **ηλθον** *ēlthon* przyszedłem [[G2064]] WTV-2AAI-1S **ου** *ou* nie [[G3756]] [[PRT-N]] **καθ** *kath* według [[G2596]] [[PREP]] **υπεροχην** *hyperochēn* wzniosłości – wybitności [[G5247]] WTN-ASF **λογου** *logou* słowa [[G3056]] [[N-GSM]] **η** *ē* lub [[G2228]] WTPRT **σοφιας** *sofias* mądrości [[G4678]] [[N-GSF]] **καταγγελλων** *katangellōn* zwiastując – ogłaszając [[G2605]] [[V-PAP-NSM]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **το** *to* [[G3588]] WTT-ASN **μαρτυριον** *martyrion* świadectwo [[G3142]] WTN-ASN **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **1Kor 2,2**
 **ου** *ou* Nie [[G3756]] [[PRT-N]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εκρινα** *ekrina* osądziłem [[G2919]] WTV-AAI-1S **του** *tou* [[G3588]] WTT-GSM **ειδεναι** *eidenai* znać – wiedzieć [[G1492]] WTV-RAN **τι** *ti* coś [[G5100]] WTX-ASN **εν** *en* wśród [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **ει** *ei* jeśli [[G1487]] WTCOND **μη** *mē* nie [[G3361]] [[PRT-N]] **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]] **χριστον** *christon* Pomazańca [[G5547]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **τουτον** *touton* to [[G5126]] WTD-ASM **εσταυρωμενον** *estaurōmenon* który jest ukrzyżowany [[G4717]] WTV-RPP-ASM
###### **1Kor 2,3**
 **και** *kai* I [[G2532]] [[CONJ]] **εγω** *egō* ja [[G1473]] WTP-1NS **εν** *en* w [[G1722]] [[PREP]] **ασθενεια** *astheneia* słabości – bezsile [[G769]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **φοβω** *fobō* strachu – bojaźni [[G5401]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **τρομω** *tromō* drżeniu [[G5156]] WTN-DSM **πολλω** *pollō* wielkim [[G4183]] WTA-DSM **εγενομην** *egenomēn* stałem się [[G1096]] WTV-2ADI-1S **προς** *pros* u [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP
###### **1Kor 2,4**
 **και** *kai* a [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **λογος** *logos* słowo [[G3056]] [[N-NSM]] **μου** *mou* moje [[G3450]] WTP-1GS **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **κηρυγμα** *kērygma* ogłaszanie [[G2782]] WTN-NSN **μου** *mou* moje [[G3450]] WTP-1GS **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εν** *en* w [[G1722]] [[PREP]] **πειθοις** *peithois* przekonywujących [[G3981]] WTA-DPM **ανθρωπινης** *anthrōpinēs* ludzkiej [[G442]] WTA-GSF **σοφιας** *sofias* mądrości [[G4678]] [[N-GSF]] **λογοις** *logois* słowach [[G3056]] WTN-DPM **αλλ** *all* ale [[G235]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **αποδειξει** *apodeiksei* przejawie – pokazaniu [[G585]] [[N-DSF]] **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **και** *kai* i [[G2532]] [[CONJ]] **δυναμεως** *dynameōs* mocy [[G1411]] [[N-GSF]]
###### **1Kor 2,5**
 **ινα** *hina* aby [[G2443]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **πιστις** *pistis* wiara [[G4102]] [[N-NSF]] **υμων** *hymōn* wasza [[G5216]] WTP-2GP **μη** *mē* nie [[G3361]] [[PRT-N]] **η** *ē* byłaby [[G5600]] WTV-PXS-3S **εν** *en* w [[G1722]] [[PREP]] **σοφια** *sofia* mądrości [[G4678]] [[N-DSF]] **ανθρωπων** *anthrōpōn* ludzkiej [[G444]] WTN-GPM **αλλ** *all* ale [[G235]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **δυναμει** *dynamei* mocy [[G1411]] [[N-DSF]] **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **1Kor 2,6**
 **σοφιαν** *sofian* Mądrość [[G4678]] WTN-ASF **δε** *de* zaś [[G1161]] [[CONJ]] **λαλουμεν** *laloumen* mówimy [[G2980]] WTV-PAI-1P **εν** *en* wśród [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPM **τελειοις** *teleiois* doskonałych – dojrzałych [[G5046]] WTA-DPM **σοφιαν** *sofian* mądrość [[G4678]] WTN-ASF **δε** *de* zaś [[G1161]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **του** *tou* [[G3588]] WTT-GSM **αιωνος** *aiōnos* wieku [[G165]] [[N-GSM]] **τουτου** *toutou* tego [[G5127]] WTD-GSM **ουδε** *oude* ani [[G3761]] [[ADV]] **των** *tōn* [[G3588]] WTT-GPM **αρχοντων** *archontōn* przywódców – przełożonych [[G758]] WTN-GPM **του** *tou* [[G3588]] WTT-GSM **αιωνος** *aiōnos* wieku [[G165]] [[N-GSM]] **τουτου** *toutou* tego [[G5127]] WTD-GSM **των** *tōn* [[G3588]] WTT-GPM **καταργουμενων** *katargoumenōn* tracących na znaczeniu – uznawanych za bezużytecznych [[G2673]] WTV-PPP-GPM
###### **1Kor 2,7**
 **αλλα** *alla* ale [[G235]] [[CONJ]] **λαλουμεν** *laloumen* mówimy [[G2980]] WTV-PAI-1P **σοφιαν** *sofian* mądrość [[G4678]] WTN-ASF **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εν** *en* w [[G1722]] [[PREP]] **μυστηριω** *mystēriō* tajemnicy [[G3466]] WTN-DSN **την** *tēn* [[G3588]] WTT-ASF **αποκεκρυμμενην** *apokekrymmenēn* która jest ukryta – która jest zakryta [[G613]] WTV-RPP-ASF **ην** *hēn* którą [[G3739]] WTR-ASF **προωρισεν** *proōrisen* przeznaczył [[G4309]] [[V-AAI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **προ** *pro* przed [[G4253]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **αιωνων** *aiōnōn* wiekami [[G165]] WTN-GPM **εις** *eis* do [[G1519]] [[PREP]] **δοξαν** *doksan* chwały [[G1391]] WTN-ASF **ημων** *hēmōn* naszej [[G2257]] WTP-1GP
###### **1Kor 2,8**
 **ην** *hēn* którą [[G3739]] WTR-ASF **ουδεις** *oudeis* nikt [[G3762]] [[A-NSM]] **των** *tōn* (z) [[G3588]] WTT-GPM **αρχοντων** *archontōn* przywódców – przełożonych [[G758]] WTN-GPM **του** *tou* [[G3588]] WTT-GSM **αιωνος** *aiōnos* wieku [[G165]] [[N-GSM]] **τουτου** *toutou* tego [[G5127]] WTD-GSM **εγνωκεν** *egnōken* poznał [[G1097]] WTV-RAI-3S **ει** *ei* jeśli [[G1487]] WTCOND **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εγνωσαν** *egnōsan* poznali [[G1097]] WTV-2AAI-3P **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **αν** *an* (kiedy)kolwiek [[G302]] WTPRT **τον** *ton* [[G3588]] [[T-ASM]] **κυριον** *kyrion* Pana [[G2962]] [[N-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **δοξης** *doksēs* chwały [[G1391]] [[N-GSF]] **εσταυρωσαν** *estaurōsan* ukrzyżowali [[G4717]] WTV-AAI-3P
###### **1Kor 2,9**
 **αλλα** *alla* Ale [[G235]] [[CONJ]] **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **γεγραπται** *gegraptai* jest napisane [[G1125]] WTV-RPI-3S **α** *ha* co [[G3739]] WTR-APN **οφθαλμος** *ofthalmos* oko [[G3788]] [[N-NSM]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ειδεν** *eiden* zobaczyło – widziało [[G1492]] WTV-2AAI-3S **και** *kai* i [[G2532]] [[CONJ]] **ους** *ous* ucho [[G3775]] WTN-NSN **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ηκουσεν** *ēkousen* usłyszało [[G191]] [[V-AAI-3S]] **και** *kai* i [[G2532]] [[CONJ]] **επι** *epi* na [[G1909]] [[PREP]] **καρδιαν** *kardian* serce [[G2588]] WTN-ASF **ανθρωπου** *anthrōpou* ludzkie [[G444]] [[N-GSM]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ανεβη** *anebē* wstąpiło – weszło [[G305]] WTV-2AAI-3S **α** *ha* to [[G3739]] WTR-APN **ητοιμασεν** *hētoimasen* przygotował [[G2090]] [[V-AAI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **τοις** *tois* [[G3588]] WTT-DPM **αγαπωσιν** *agapōsin* miłującym [[G25]] WTV-PAP-DPM **αυτον** *auton* Go [[G846]] WTP-ASM
###### **1Kor 2,10**
 **ημιν** *hēmin* Nam [[G2254]] WTP-1DP **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **απεκαλυψεν** *apekalypsen* objawił [[G601]] [[V-AAI-3S]] **δια** *dia* przez [[G1223]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **το** *to* [[G3588]] WTT-NSN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **πνευμα** *pneuma* Duch [[G4151]] WTN-NSN **παντα** *panta* wszystkie [[G3956]] WTA-APN **ερευνα** *ereuna* bada [[G2045]] WTV-PAI-3S **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **βαθη** *bathē* głębokości [[G899]] WTN-APN **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **1Kor 2,11**
 **τις** *tis* Kto [[G5101]] WTI-NSM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **οιδεν** *oiden* zna [[G1492]] WTV-RAI-3S **ανθρωπων** *anthrōpōn* ludzi [[G444]] WTN-GPM **τα** *ta* (te) [[G3588]] WTT-APN **του** *tou* [[G3588]] WTT-GSM **ανθρωπου** *anthrōpou* człowieka [[G444]] [[N-GSM]] **ει** *ei* jeśli [[G1487]] WTCOND **μη** *mē* nie [[G3361]] [[PRT-N]] **το** *to* [[G3588]] WTT-NSN **πνευμα** *pneuma* duch [[G4151]] WTN-NSN **του** *tou* [[G3588]] WTT-GSM **ανθρωπου** *anthrōpou* ludzki [[G444]] [[N-GSM]] **το** *to* [[G3588]] WTT-NSN **εν** *en* w [[G1722]] [[PREP]] **αυτω** *autō* nim [[G846]] WTP-DSM **ουτως** *houtōs* tak [[G3779]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* (te) [[G3588]] WTT-APN **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ουδεις** *oudeis* nikt [[G3762]] [[A-NSM]] **οιδεν** *oiden* zna [[G1492]] WTV-RAI-3S **ει** *ei* jeśli [[G1487]] WTCOND **μη** *mē* nie [[G3361]] [[PRT-N]] **το** *to* [[G3588]] WTT-NSN **πνευμα** *pneuma* Duch [[G4151]] WTN-NSN **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **1Kor 2,12**
 **ημεις** *hēmeis* My [[G2249]] WTP-1NP **δε** *de* zaś [[G1161]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **το** *to* [[G3588]] WTT-ASN **πνευμα** *pneuma* ducha [[G4151]] WTN-ASN **του** *tou* [[G3588]] WTT-GSM **κοσμου** *kosmou* świata [[G2889]] [[N-GSM]] **ελαβομεν** *elabomen* otrzymaliśmy – wzięliśmy [[G2983]] WTV-2AAI-1P **αλλα** *alla* ale [[G235]] [[CONJ]] **το** *to* [[G3588]] WTT-ASN **πνευμα** *pneuma* Ducha [[G4151]] WTN-ASN **το** *to* [[G3588]] WTT-ASN **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **ειδωμεν** *eidōmen* znalibyśmy [[G1492]] WTV-RAS-1P **τα** *ta* (te) [[G3588]] WTT-APN **υπο** *hypo* przez [[G5259]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **χαρισθεντα** *charisthenta* które zostały darowane [[G5483]] WTV-APP-APN **ημιν** *hēmin* nam [[G2254]] WTP-1DP
###### **1Kor 2,13**
 **α** *ha* które [[G3739]] WTR-APN **και** *kai* i [[G2532]] [[CONJ]] **λαλουμεν** *laloumen* mówimy [[G2980]] WTV-PAI-1P **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εν** *en* w [[G1722]] [[PREP]] **διδακτοις** *didaktois* nauczonych – pouczonych [[G1318]] WTA-DPM **ανθρωπινης** *anthrōpinēs* ludzkiej [[G442]] WTA-GSF **σοφιας** *sofias* mądrości [[G4678]] [[N-GSF]] **λογοις** *logois* słowach [[G3056]] WTN-DPM **αλλ** *all* ale [[G235]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **διδακτοις** *didaktois* nauczonych – pouczonych [[G1318]] WTA-DPM **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **αγιου** *hagiou* Świętego [[G40]] [[A-GSN]] **πνευματικοις** *pneumatikois* duchowymi [[G4152]] WTA-DPN **πνευματικα** *pneumatika* duchowe [[G4152]] WTA-APN **συγκρινοντες** *sygkrinontes* porównując – zestawiając [[G4793]] WTV-PAP-NPM
###### **1Kor 2,14**
 **ψυχικος** *psychikos* Zmysłowy [[G5591]] [[A-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **ανθρωπος** *anthrōpos* człowiek [[G444]] [[N-NSM]] **ου** *ou* nie [[G3756]] [[PRT-N]] **δεχεται** *dechetai* przyjmuje [[G1209]] WTV-PNI-3S **τα** *ta* (tych) [[G3588]] WTT-APN **του** *tou* [[G3588]] WTT-GSN **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **μωρια** *mōria* głupota [[G3472]] [[N-NSF]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **αυτω** *autō* jemu [[G846]] WTP-DSM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **και** *kai* i [[G2532]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **δυναται** *dynatai* może [[G1410]] WTV-PNI-3S **γνωναι** *gnōnai* poznać [[G1097]] [[V-2AAN]] **οτι** *hoti* że [[G3754]] [[CONJ]] **πνευματικως** *pneumatikōs* duchowo [[G4153]] [[ADV]] **ανακρινεται** *anakrinetai* jest rozsądzane – jest osądzane [[G350]] WTV-PPI-3S
###### **1Kor 2,15**
 **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **πνευματικος** *pneumatikos* duchowy [[G4152]] [[A-NSM]] **ανακρινει** *anakrinei* rozsądza – osądza [[G350]] WTV-PAI-3S **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **παντα** *panta* wszystkie [[G3956]] WTA-APN **αυτος** *autos* sam [[G846]] WTP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **υπ** *hyp* przez [[G5259]] [[PREP]] **ουδενος** *oudenos* nikogo [[G3762]] WTA-GSM **ανακρινεται** *anakrinetai* jest rozsądzany – jest osądzany [[G350]] WTV-PPI-3S
###### **1Kor 2,16**
 **τις** *tis* Kto [[G5101]] WTI-NSM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εγνω** *egnō* poznał [[G1097]] WTV-2AAI-3S **νουν** *noun* myśl – rozum [[G3563]] [[N-ASM]] **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ος** *hos* który [[G3739]] WTR-NSM **συμβιβασει** *symbibasei* pouczy [[G4822]] WTV-FAI-3S **αυτον** *auton* Go [[G846]] WTP-ASM **ημεις** *hēmeis* my [[G2249]] WTP-1NP **δε** *de* zaś [[G1161]] [[CONJ]] **νουν** *noun* myśl – rozum [[G3563]] [[N-ASM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **εχομεν** *echomen* mamy [[G2192]] WTV-PAI-1P
