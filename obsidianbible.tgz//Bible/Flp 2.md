# Flp 2 BT5
###### **Flp 2,1**
 Jeśli więc jest jakieś napomnienie w Chrystusie, jeśli jakaś moc przekonująca Miłości, jeśli jakieś uczestnictwo w Duchu, jeśli jakieś serdeczne współczucie –
###### **Flp 2,2**
 dopełnijcie mojej radości przez to, że będziecie mieli te same dążenia: tę samą miłość i wspólnego ducha, pragnąc tylko jednego,
###### **Flp 2,3**
 a niczego nie pragnąc dla niewłaściwego współzawodnictwa ani dla próżnej chwały, lecz w pokorze oceniając jedni drugich za wyżej stojących od siebie.
###### **Flp 2,4**
 Niech każdy ma na oku nie tylko swoje własne sprawy, ale też i drugich.
###### **Flp 2,5**
 To dążenie niech was ożywia; ono też [było] w Chrystusie Jezusie.
###### **Flp 2,6**
 On to, istniejąc w postaci Bożej, nie skorzystał ze sposobności, aby na równi być z Bogiem,
###### **Flp 2,7**
 lecz ogołocił samego siebie, przyjąwszy postać sługi, stając się podobnym do ludzi. A w zewnętrznej postaci uznany za człowieka,
###### **Flp 2,8**
 uniżył samego siebie, stając się posłusznym aż do śmierci – i to śmierci krzyżowej.
###### **Flp 2,9**
 Dlatego też Bóg Go nad wszystko wywyższył i darował Mu imię ponad wszelkie imię,
###### **Flp 2,10**
 aby na imię Jezusa zgięło się każde kolano istot niebieskich i ziemskich, i podziemnych.
###### **Flp 2,11**
 I aby wszelki język wyznał, że Jezus Chrystus jest PANEM – ku chwale Boga Ojca.
###### **Flp 2,12**
 A zatem, umiłowani moi, skoro zawsze byliście posłuszni, zabiegajcie o własne zbawienie z bojaźnią i drżeniem nie tylko w mojej obecności, lecz jeszcze bardziej teraz, gdy mnie nie ma.
###### **Flp 2,13**
 Albowiem to Bóg jest w was sprawcą i chcenia, i działania zgodnie z [Jego] wolą.
###### **Flp 2,14**
 Czyńcie wszystko bez szemrań i powątpiewań,
###### **Flp 2,15**
 abyście się stali bez zarzutu i bez winy, jako nieskazitelne dzieci Boże pośród narodu zepsutego i przewrotnego. Pośród niego jawicie się jako źródła światła w świecie.
###### **Flp 2,16**
 Trzymajcie się mocno Słowa życia, abym mógł być dumny w dniu Chrystusa, że nie na próżno biegłem i nie na próżno się trudziłem.
###### **Flp 2,17**
 A jeśli nawet krew moja ma być wylana przy ofiarniczej posłudze około waszej wiary, cieszę się i dzielę radość z wami wszystkimi;
###### **Flp 2,18**
 tak samo i wy się cieszcie i dzielcie radość ze mną!
###### **Flp 2,19**
 A mam nadzieję w Panu Jezusie, że niebawem poślę do was Tymoteusza, abym i ja doznał radości, dowiedziawszy się o waszych sprawach.
###### **Flp 2,20**
 Nie mam bowiem nikogo równego mu duchem, kto by się szczerze zatroszczył o wasze sprawy:
###### **Flp 2,21**
 bo wszyscy szukają własnego pożytku, a nie – Chrystusa Jezusa.
###### **Flp 2,22**
 Wiecie zaś, że on został wypróbowany: bo jak dziecko ojcu, tak razem ze mną służył Ewangelii.
###### **Flp 2,23**
 Jego to mam nadzieję posłać do was natychmiast, skoro tylko rozejrzę się w swoich sprawach.
###### **Flp 2,24**
 Ufam zaś w Panu, że i ja sam przybędę niebawem.
###### **Flp 2,25**
 Uznałem też za konieczne posłać do was Epafrodyta, brata, mojego współpracownika i towarzysza broni, a waszego wysłannika, który miał zaradzić moim potrzebom,
###### **Flp 2,26**
 gdyż bardzo tęsknił za wami wszystkimi i dręczył się tym, że usłyszeliście o jego chorobie.
###### **Flp 2,27**
 Rzeczywiście bowiem zachorował, tak iż był bliski śmierci. Ale Bóg się nad nim zmiłował; nie tylko zresztą nad nim, lecz i nade mną, bym nie doznał smutku jednego po drugim.
###### **Flp 2,28**
 Przeto tym śpieszniej go posyłam, żebyście wy, ujrzawszy go, ponownie się uradowali, i żebym ja się mniej martwił.
###### **Flp 2,29**
 Przyjmijcie więc go w Panu z całą radością! A takich jak on otaczajcie czcią,
###### **Flp 2,30**
 bo dla sprawy Chrystusa bliski był śmierci, naraziwszy życie swoje po to, by was zastąpić przy posłudze, której wy [osobiście] nie mogliście mi oddać.
# Flp 2 PAU
###### **Flp 2,1**
 Jeśli więc coś znaczy upomnienie w Chrystusie, jeśli umacnia was miłość, jeśli łączy was ten sam Duch lub jeśli macie w sercu miłosierdzie i współczucie,
###### **Flp 2,2**
 dopełnijcie mojej radości tym, że będziecie mieli te same dążenia i będziecie żywili tę samą miłość, że będziecie trwali w jedności i myśleli podobnie;
###### **Flp 2,3**
 nie działajcie z myślą o uznaniu czy pochwałach, lecz z pokorą uważajcie jedni drugich za lepszych od siebie.
###### **Flp 2,4**
 Niech każdy troszczy się nie tylko o swoje własne sprawy, ale także o innych.
###### **Flp 2,5**
 Miejcie w sobie takie usposobienie, jakie też było w Chrystusie Jezusie.
###### **Flp 2,6**
 On, mając naturę Boga, nie uznał za stosowne korzystać ze swojej równości z Bogiem,
###### **Flp 2,7**
 lecz ogołocił siebie samego, przyjmując naturę sługi i stając się podobnym do ludzi. A z zewnętrznego wyglądu uznany za człowieka,
###### **Flp 2,8**
 uniżył siebie samego, stając się posłusznym aż do śmierci, i to śmierci na krzyżu.
###### **Flp 2,9**
 Dlatego Bóg Go wywyższył i obdarzył Go imieniem, które jest ponad wszelkie imię,
###### **Flp 2,10**
 aby na imię Jezusa zgięło się wszelkie kolano istot niebieskich i ziemskich, i podziemnych,
###### **Flp 2,11**
 i aby wszelki język wyznał, że Jezus Chrystus jest Panem na chwałę Boga Ojca.
###### **Flp 2,12**
 Umiłowani moi, skoro zawsze byliście posłuszni, to nie tylko wtedy, gdy jestem z wami, lecz tym bardziej teraz, gdy jestem nieobecny, z lękiem i drżeniem starajcie się o własne zbawienie.
###### **Flp 2,13**
 Bóg bowiem sprawia, że pragniecie i działacie zgodnie z Jego upodobaniem.
###### **Flp 2,14**
 Wszystko czyńcie bez narzekania i sprzeciwu,
###### **Flp 2,15**
 by nic wam nie można było zarzucić i abyście byli bez skazy, jako nienaganne dzieci Boże wśród narodu zepsutego i przewrotnego. Bądźcie dla nich światłem jak gwiazdy na niebie.
###### **Flp 2,16**
 Kierujcie się słowem życia, abym w dniu Chrystusa mógł być dumny, że nie biegłem na próżno i na próżno się nie trudziłem.
###### **Flp 2,17**
 A jeśli nawet składam z siebie ofiarę i służę na rzecz waszej wiary, cieszę się i swoją radością dzielę się z wami wszystkimi.
###### **Flp 2,18**
 I wy również cieszcie się i radujcie ze mną.
###### **Flp 2,19**
 Mam nadzieję w Panu Jezusie, że wkrótce będę mógł posłać do was Tymoteusza, abym i ja był spokojny, wiedząc, co się u was dzieje.
###### **Flp 2,20**
 Nie ma nikogo innego, kto by mnie rozumiał i naprawdę troszczył się o was.
###### **Flp 2,21**
 Wszyscy bowiem szukają własnych korzyści, a nie pilnują spraw Jezusa Chrystusa.
###### **Flp 2,22**
 Wiecie zresztą, że można na nim polegać, gdyż służył mi jak dziecko ojcu w szerzeniu Ewangelii.
###### **Flp 2,23**
 Mam więc nadzieję, że go poślę, gdy tylko wyjaśnią się moje sprawy.
###### **Flp 2,24**
 Pokładam ufność w Panu, że również ja sam będę mógł wkrótce przybyć.
###### **Flp 2,25**
 Uznałem także za konieczne posłać do was Epafrodyta, mego brata, współpracownika i towarzysza w boju, którego przysłaliście, aby zaradził moim potrzebom.
###### **Flp 2,26**
 Tęsknił on za wami wszystkimi i martwił się, że dowiedzieliście się o jego chorobie.
###### **Flp 2,27**
 Rzeczywiście bowiem zachorował tak, że był bliski śmierci. Bóg jednak zmiłował się nad nim; i nie tylko nad nim, lecz także nade mną, aby nie przygniatał mnie smutek jeden po drugim.
###### **Flp 2,28**
 Tym prędzej więc go posyłam, abyście znowu ucieszyli się na jego widok i abym ja też mniej się martwił.
###### **Flp 2,29**
 Przyjmijcie go w Panu z wielką radością i takim jak on okazujcie szacunek,
###### **Flp 2,30**
 gdyż był bliski śmierci, pracując dla Chrystusa, i narażał swoje życie, aby dopełnić to, czym wy nie mogliście mi usłużyć.
# Flp 2 BP
###### **Flp 2,1**
 Jeśli ma znaczenie zachęta [w imię] Chrystusa, pociecha płynąca z miłości, wspólnota w Duchu, serdeczne współczucie,
###### **Flp 2,2**
 dopełnijcie mojej radości, bądźcie jednomyślni i miejcie te same pragnienia, tę samą miłość, wspólnotę ducha, wspólne dążenia.
###### **Flp 2,3**
 Nie czyńcie niczego dla niezdrowego współzawodnictwa czy pustej chwały, lecz w pokorze stawiajcie innych wyżej od siebie.
###### **Flp 2,4**
 Niech każdy ma na uwadze nie tylko własne sprawy, ale i innych.
###### **Flp 2,5**
 Postępujcie względem siebie na wzór Chrystusa Jezusa.
###### **Flp 2,6**
 On to, istniejąc w naturze Bożej, nie skorzystał ze sposobności, aby być na równi z Bogiem,
###### **Flp 2,7**
 lecz sam siebie poniżył, przyjąwszy naturę sługi. Stał się podobny do ludzi i w zewnętrznej postaci uznany za człowieka.
###### **Flp 2,8**
 Uniżył samego siebie, stał się posłuszny aż do śmierci i to śmierci krzyżowej.
###### **Flp 2,9**
 Dlatego też Bóg wywyższył Go ponad wszystko i darował Mu imię, które jest ponad wszelkie imię,
###### **Flp 2,10**
 aby na imię Jezusa zginało się każde kolano w niebie, na ziemi i pod ziemią,
###### **Flp 2,11**
 i aby wszelki język wyznawał, że Jezus Chrystus jest Panem ku chwale Boga Ojca.
###### **Flp 2,12**
 Umiłowani moi, ponieważ zawsze byliście posłuszni, nie tylko wtedy, kiedy byłem z wami, ale jeszcze bardziej teraz pod moją nieobecność, zabiegajcie usilnie z lękiem i drżeniem o własne zbawienie.
###### **Flp 2,13**
 Bóg bowiem jest sprawcą waszych pragnień i czynów wedle [swego] upodobania.
###### **Flp 2,14**
 Czyńcie wszystko bez szemrania czy wahania,
###### **Flp 2,15**
 abyście będąc bez zarzutu i winy, stali się nienagannymi dziećmi Bożymi wśród zepsutego i przewrotnego ludu, dla którego jesteście tym, czym światło w świecie.
###### **Flp 2,16**
 Trzymajcie się mocno Słowa Życia, abym mógł chlubić się w dniu Chrystusa, że nie biegałem na próżno i nie na darmo się trudziłem.
###### **Flp 2,17**
 A jeśli nawet i krew moja ma być dolana do ofiary i świętej posługi około waszej wiary, jestem szczęśliwy i cieszę się razem z wami wszystkimi.
###### **Flp 2,18**
 Wy także się cieszcie i dzielcie radość ze mną.
###### **Flp 2,19**
 Mam nadzieję w Panu Jezusie, że wkrótce wyślę do was Tymoteusza, abym dowiedziawszy się, co u was [słychać], mógł być spokojniejszy.
###### **Flp 2,20**
 Nie mam bowiem poza nim nikogo, kto by się ze mną tak zgadzał, a zarazem tak szczerze troszczył się o was.
###### **Flp 2,21**
 Bo wszyscy zabiegają o swoje sprawy, a nie o Chrystusa Jezusa.
###### **Flp 2,22**
 Wiecie, że on już przeszedł próbę, bo jak syn ojcu służył mi w krzewieniu ewangelii.
###### **Flp 2,23**
 Mam nadzieję, że będę mógł go do was posłać zaraz, jak tylko zorientuję się w moim położeniu.
###### **Flp 2,24**
 Ufam też w Panu, że ja sam wkrótce przybędę.
###### **Flp 2,25**
 Poza tym uznałem, że powinienem odesłać wam Epafrodyta, mojego brata, który dzielił ze mną trud pracy i walki, waszego wysłannika, tego, który służył mi pomocą w moich potrzebach.
###### **Flp 2,26**
 Stęsknił się bowiem za wami wszystkimi i zadręczał myślą, że dowiedzieliście się o jego chorobie.
###### **Flp 2,27**
 Bo rzeczywiście tak się rozchorował, że był już bliski śmierci. Bóg jednak zlitował się nie tylko nad nim, ale i nade mną, abym nie miał jednego smutku po drugim.
###### **Flp 2,28**
 Dlatego też tym spieszniej go wysyłam, żebyście, ujrzawszy go, ucieszyli się znowu; ja zaś będę mniej strapiony.
###### **Flp 2,29**
 Przyjmijcie go zatem w Panu z całą radością i miejcie takich [jak on] w poszanowaniu.
###### **Flp 2,30**
 Bo dla sprawy Chrystusa był bliski śmierci i naraził swoje życie, aby zastąpić was w ofiarnej posłudze, której sami nie mogliście wypełnić.
# Flp 2 BR
###### **Flp 2,1**
 Jeżeli tedy mogę was o coś prosić przez wzgląd na jedność z Chrystusem, jeżeli [Jego] miłość posiada jakąś moc przekonywającą, jeżeli jest jakaś wspólnota w Duchu [Świętym], jeżeli istnieje jakieś współczucie jednych dla drugich,
###### **Flp 2,2**
 to [proszę was:] zechciejcie być dla mnie powodem do radości! Niech zaistnieje wśród was jedność dążeń, tożsamość miłości, wspólnota ducha i zbieżność pragnień.
###### **Flp 2,3**
 Nie poszukujcie niczego w celu wynoszenia się jedni ponad drugich, nie gońcie za próżną chwałą, lecz z całą pokorą uważajcie innych za lepszych od was samych.
###### **Flp 2,4**
 Niech nikt nie szuka tylko własnego dobra, lecz niech myśli o sprawach innych.
###### **Flp 2,5**
 Niech was ożywiają uczucia znamienne dla Jezusa Chrystusa:
###### **Flp 2,6**
 On to, istniejąc [od wieków] w postaci Boga, nie uznał za stosowne korzystać ze swej równości z Bogiem,
###### **Flp 2,7**
 lecz [przeciwnie] wyzbył się wszystkiego, co Boskie, pojawił się w postaci sługi. Stał się podobnym do ludzi i - zgodnie z tym, czym był na zewnątrz - został uznany za człowieka.
###### **Flp 2,8**
 Zgodził się dobrowolnie na stan poniżenia, stał się posłuszny aż do śmierci - i to aż do śmierci na krzyżu.
###### **Flp 2,9**
 Dlatego Bóg Go wywyższył ponad wszystko i nadał Mu imię godniejsze od wszelkiego imienia,
###### **Flp 2,10**
 po to, aby na imię Jezus zginało się wszelkie kolano: istot, które są w niebie, na ziemi i pod ziemią,
###### **Flp 2,11**
 i aby wszyscy wyznawali, że Jezus Chrystus jest Panem, ku chwale Boga Ojca.
###### **Flp 2,12**
 Tak więc, umiłowani moi, skoro zawsze byliście mi posłuszni, gdy wśród was przebywałem, tym bardziej posłuchajcie mnie teraz, gdy jestem z dala od was [proszę was]: z bojaźnią i drżeniem zabiegajcie o wasze zbawienie.
###### **Flp 2,13**
 To sam Bóg bowiem wzbudza w was [dobre] pragnienia i sprawia, że możecie działać zgodnie z Jego wolą.
###### **Flp 2,14**
 Czyńcie wszystko bez utyskiwań, zdecydowanie
###### **Flp 2,15**
 [i w taki sposób], byście byli spokojni w sumieniu i niewinni, jak przystało na nienaganne dzieci Boże, żyjące wśród ludzi zepsutych i przewrotnych. Macie być między nimi w świecie niczym gwiazdy rozświetlające przestworza.
###### **Flp 2,16**
 Trwajcie niezachwianie przy Słowie Życia, abym mógł być dumny z was w dzień Chrystusa, [widząc] że nie na próżno biegłem [do celu] i nie na próżno się trudziłem.
###### **Flp 2,17**
 A gdyby nawet krew moja miała być wylana w ofiarniczej posłudze dla dobra waszej wiary, to będę się tylko cieszył, dzieląc z wami wszystkimi moją radość.
###### **Flp 2,18**
 Wy również powinniście się cieszyć i dzielić waszą radość ze mną.
###### **Flp 2,19**
 Mam nadzieję w Panu Jezusie, że uda mi się wysłać do was wkrótce Tymoteusza, bym mógł doznać pokrzepienia wieściami, które mi od was przywiezie.
###### **Flp 2,20**
 Nie mam w tej chwili nikogo, kto byłby mu równy zapałem ducha i tak zatroskany o wasze sprawy.
###### **Flp 2,21**
 Wszyscy inni myślą tylko o własnych interesach, a nie o sprawie Chrystusa Jezusa.
###### **Flp 2,22**
 Wy sami wiecie przecież dobrze, jakie to dowody swej wierności okazał już Tymoteusz: był dla mnie w całej posłudze Ewangelii, niczym syn dla rodzonego ojca.
###### **Flp 2,23**
 Myślę, że uda mi się wysłać go do was, skoro tylko załatwi najpilniejsze sprawy własne.
###### **Flp 2,24**
 Zresztą w Panu nadzieję pokładam, że i ja również niedługo przybędę do was.
###### **Flp 2,25**
 Uznałem też za konieczne posłać do was Epafrodyta, brata, towarzysza prac moich i współbojownika mojego. Jego to przysłaliście do mnie, żeby zaradził moim potrzebom.
###### **Flp 2,26**
 Tak bardzo chciał znów zobaczyć was wszystkich i zadręczał się tym, iż dotarły do was [niepotrzebnie] wieści o jego chorobie.
###### **Flp 2,27**
 Rzeczywiście był on chory i nawet bliski śmierci. Ale Bóg ulitował się nad nim. Zresztą nie tylko nad nim, lecz i nade mną. W przeciwnym razie spadłyby na mnie utrapienia jedno po drugim.
###### **Flp 2,28**
 Dlatego też nie zwlekam już wcale z wysłaniem go do was. W ten sposób i wy, zobaczywszy go, znów się uradujecie, i ja nie będę się już tak martwił.
###### **Flp 2,29**
 Przyjmijcie go więc w Panu z całą radością. W ogóle takich jak on otaczajcie szczególną czcią,
###### **Flp 2,30**
 bo to właśnie dla sprawy Chrystusa był on już tylko o krok od śmierci. Narażał bowiem życie, by okazać mi pomoc, której wy sami nie mogliście mi osobiście wyświadczyć.
# Flp 2 WUJ
###### **Flp 2,1**
 Jeśli tedy które pocieszenie w Chrystusie, jeśli które ucieszenie miłości, jeśli które towarzystwo ducha, jeśli którewnętrzności ulitowania:
###### **Flp 2,2**
 Napełńcie wesele moje, abyście toż rozumieli, też miłość mając, jednomyślni, jednoż rozumiejąc.
###### **Flp 2,3**
 Nie przez sprzeczanie, ani przez próżną chwałę: ale w pokorze, jeden drugiego mając za wyższego nad się:
###### **Flp 2,4**
 Nie upatrując każdy co swego jest, ale tego co drugich.
###### **Flp 2,5**
 Abowiem to w sobie czujcie, co i w Chrystusie Jezusie:
###### **Flp 2,6**
 Który będąc w postaci Bożej, nie poczytał za drapieztwo, że był równym Bogu:
###### **Flp 2,7**
 Ale wyniszczył samego siebie, przyjąwszy postać sługi, stawszy się na podobieństwo ludzi, i postawą naleziony jako człowiek.
###### **Flp 2,8**
 Sam się poniżył, stawszy się posłusznym aż do śmierci: a śmierci krzyżowej.
###### **Flp 2,9**
 Dla czego i Bóg wywyższył go, i darował mu imię, które jest nad wszelakie imię:
###### **Flp 2,10**
 Aby na imię Jezusowe wszelkie kolano klękało, niebieskich, ziemskich, i podziemnych.
###### **Flp 2,11**
 A iżby wszelki język wyznawał, iż Pan Jezus Chrystus jest w chwale Boga Ojca.
###### **Flp 2,12**
 Przetoż namilszy moi (jakoście zawsze posłuszni byli): nietylko jako przy mojej bytności, ale teraz daleko więcej w niebytności mojej, z bojaźnią i ze drżeniem zbawienie wasze sprawujcie.
###### **Flp 2,13**
 Abowiem Bóg jest, który sprawuje w was i chcieć i wykonać, wedle dobrej wolej.
###### **Flp 2,14**
 A wszystko czyńcie krom szemrania i wahania,
###### **Flp 2,15**
 Abyście byli bez przygany, i szczerzy synowie Boży bez naganiania w pośrodku narodu złego i przewrotnego, między któremi świecicie jako światła na świecie:
###### **Flp 2,16**
 Zachowywając słowo żywota ku przechwalaniu mojemu na dzień Chrystusów. Iżem darmo nie bieżał, anim darmo pracował.
###### **Flp 2,17**
 Ale choć mię i zarzezą na ofiarę i posługowanie wiary waszej, weselę się i pomagam wszystkim wam wesela.
###### **Flp 2,18**
 A z tegoż i wy się weselcie i pomagajcie mi wesela.
###### **Flp 2,19**
 A spodziewam się w Panu Jezusie, iż rychło Tymotheusza poślę do was: abym i ja był dobrej myśli, dowiedziawszy się co się z wami dzieje.
###### **Flp 2,20**
 Abowiem nie mam żadnego tak jednomyślnego, któryby się z szczerej miłości o was pieczołował.
###### **Flp 2,21**
 Bo wszyscy co ich jest szukają: nie co jest Jezusa Chrystusa.
###### **Flp 2,22**
 A doświadczenie jego poznajcie, iż jako syn ojcu, zemną służył w Ewanieljej.
###### **Flp 2,23**
 Spodziewam się tedy, iż tego do was poślę, skoro obaczę co się zemną dzieje.
###### **Flp 2,24**
 Ale dufam w Panie, iż i sam rychło do was przybędę.
###### **Flp 2,25**
 A rozumiałem za potrzebną, posłać do was Epaphrodyta brata i pomocnika i spół bojownika mego, a waszego Apostoła, i sługę w potrzebie mojej.
###### **Flp 2,26**
 Abowiem pragnął was wszystkich, i frasował się, dla tego, żeście byli słyszeli, że chorował.
###### **Flp 2,27**
 Bo iście chorował aż do śmierci: ale Bóg zmiłował się nad nim: a nie tylko nad nim, ale też nademną, iżbym nie miał smutku na smutek.
###### **Flp 2,28**
 Tem rychlej tedy posłałem go, abyście go ujrzawszy, zaś się weselili, a jabym był bez smutku.
###### **Flp 2,29**
 Przymijcie go tedy w Panu z wszelakiem weselem: a takowe we czci miejcie.
###### **Flp 2,30**
 Bo dla sprawy Chrystusowej przyszedł aż do śmierci, wydawszy duszę swoję, aby wypełnił to czego z was nie dostawało do posługi mojej.
# Flp 2 STERN
###### **Flp 2,1**
 Dlatego jeśli macie dla mnie jakieś pokrzepienie z racji waszej jedności z Mesjaszem, jakąś pociechę płynącą z miłości, jakąś wspólnotę ze mną w Duchu albo jakieś współczucie i litość,
###### **Flp 2,2**
 to dopełnijcie moją radość i miejcie ten sam cel i tę samą miłość, bądźcie jedno sercem i umysłem.
###### **Flp 2,3**
 Nie czyńcie niczego z rywalizacji albo próżności, ale w pokorze uznawajcie jedni drugich za lepszych od siebie -
###### **Flp 2,4**
 starajcie się dbać o interesy innych, a nie tylko o swoje.
###### **Flp 2,5**
 Niech waszą postawą względem siebie wzajem rządzi fakt, że jesteście w jedności z Mesjaszem Jeszuą:
###### **Flp 2,6**
 Choć istniał On w postaci Bożej, nie uważał, że równość Bogu to coś, co należy posiąść siłą.
###### **Flp 2,7**
 Przeciwnie, ogołocił siebie, przybierając postać niewolnika, stawszy się takim jak ludzie. A kiedy objawił się jako człowiek,
###### **Flp 2,8**
 uniżył siebie jeszcze bardziej, stając się posłusznym aż do śmierci -śmierci na palu jak zbrodniarz!
###### **Flp 2,9**
 Dlatego Bóg wyniósł Go na miejsce najwyższe i dał Mu imię ponad wszelkie imię,
###### **Flp 2,10**
 aby dla uczczenia imienia danego Jeszui zgięło się każde kolano - w niebie, na ziemi i pod ziemią
###### **Flp 2,11**
 i aby każdy język przyznał, że Jeszua Mesjasz jest Adonai, ku chwale Boga Ojca.
###### **Flp 2,12**
 A zatem, drodzy moi przyjaciele, tak jak zawsze byliście posłuszni, kiedy przebywałem u was, tak jeszcze ważniejsze jest, abyście byli posłuszni teraz, gdy jestem daleko od was: wytrwale realizujcie swoje wyzwolenie z bojaźnią i drżeniem,
###### **Flp 2,13**
 bo to Bóg sprawia wśród was zarówno chęć, jak i czynienie tego, co się Jemu podoba.
###### **Flp 2,14**
 Róbcie wszystko bez kweczowania i sporów,
###### **Flp 2,15**
 abyście byli nieskalanymi i czystymi dziećmi Bożymi, bez skazy pośród zdeprawowanego i przewrotnego pokolenia, między którym jaśniejecie jak gwiazdy na niebie,
###### **Flp 2,16**
 trzymając się Słowa Życia. Jeśli tak uczynicie, będę mógł się szczycić, gdy nadejdzie Dzień Mesjasza, że nie biegłem i nie mozoliłem się na próżno.
###### **Flp 2,17**
 A nawet jeśli krew moja zostanie wylana jako ofiara płynna na ofiarę i służbę waszej wiary, będę się wciąż cieszył i radował z wami wszystkimi.
###### **Flp 2,18**
 Podobnie i wy powinniście się cieszyć i radować wraz ze mną.
###### **Flp 2,19**
 Mam jednak w Panu nadzieję posłać do was wkrótce Tymoteusza, tak abym i ja mógł się pokrzepić, wiedząc, jak się wam powodzi.
###### **Flp 2,20**
 Nie mam nikogo, kto by się z nim mógł równać, kto tak szczerze zatroszczy się o wasz los -
###### **Flp 2,21**
 bo wszyscy przedkładają własne interesy nad sprawy Mesjasza Jeszui.
###### **Flp 2,22**
 Ale wy znacie jego charakter, że niczym dziecko ze swym ojcem oddał się wraz ze mną w niewolę, aby szerzyć Dobrą Nowinę.
###### **Flp 2,23**
 Mam więc nadzieję wysłać go, gdy tylko się przekonam, jak się sprawy ze mną potoczą,
###### **Flp 2,24**
 a mam w Panu ufność, że w niedługim czasie i ja sam przybędę.
###### **Flp 2,25**
 Uznałem także za konieczne, aby posłać do was Epafrodyta, mojego brata, współpracownika i współbojownika, wysłannika, którego posłaliście, aby się zatroszczył o moje potrzeby;
###### **Flp 2,26**
 bo tęskni za wami wszystkimi i trapi się, że dowiedzieliście się, że chorował.
###### **Flp 2,27**
 Rzeczywiście chorował i bliski był śmierci, ale Bóg okazał mu miłosierdzie - i nie tylko jemu, ale i mnie, żeby mnie nie spotykała troska za troską.
###### **Flp 2,28**
 Dlatego tym bardziej pragnę go wysłać, abyście się uradowali, widząc go z powrotem, ja natomiast mniej się będę smucił.
###### **Flp 2,29**
 Przywitajcie go więc radośnie w Panu, czcijcie takich ludzi.
###### **Flp 2,30**
 Bo ryzykował życiem i o mało nie umarł, trudząc się dla Mesjasza, aby być mi tą pomocą, której wy nie bylibyście mi w stanie udzielić.
# Flp 2 TRO
###### **Flp 2,1**
 **ει** *ei* Jeśli [[G1487]] WTCOND **τις** *tis* jakaś [[G5100]] WTX-NSF **ουν** *oun* więc [[G3767]] [[CONJ]] **παρακλησις** *paraklēsis* zachęta [[G3874]] [[N-NSF]] **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ει** *ei* jeśli [[G1487]] WTCOND **τι** *ti* jakieś [[G5100]] WTX-NSN **παραμυθιον** *paramythion* pocieszenie [[G3890]] WTN-NSN **αγαπης** *agapēs* miłości [[G26]] [[N-GSF]] **ει** *ei* jeśli [[G1487]] WTCOND **τις** *tis* jakaś [[G5100]] WTX-NSF **κοινωνια** *koinōnia* wspólnota [[G2842]] [[N-NSF]] **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **ει** *ei* jeśli [[G1487]] WTCOND **τινα** *tina* jakieś [[G5100]] WTX-NPN **σπλαγχνα** *splagchna* głębokie uczucia – wnętrzności [[G4698]] WTN-NPN **και** *kai* i [[G2532]] [[CONJ]] **οικτιρμοι** *oiktirmoi* okazy miłosierdzia – okazy litości [[G3628]] WTN-NPM
###### **Flp 2,2**
 **πληρωσατε** *plērōsate* dopełnijcie – wypełnijcie [[G4137]] WTV-AAM-2P **μου** *mou* moją [[G3450]] WTP-1GS **την** *tēn* [[G3588]] WTT-ASF **χαραν** *charan* radość [[G5479]] WTN-ASF **ινα** *hina* aby [[G2443]] [[CONJ]] **το** *to* [[G3588]] WTT-ASN **αυτο** *auto* to samo [[G846]] WTP-ASN **φρονητε** *fronēte* myślelibyście – rozumielibyście [[G5426]] WTV-PAS-2P **την** *tēn* [[G3588]] WTT-ASF **αυτην** *autēn* tę samą [[G846]] [[P-ASF]] **αγαπην** *agapēn* miłość [[G26]] WTN-ASF **εχοντες** *echontes* mając [[G2192]] WTV-PAP-NPM **συμψυχοι** *sympsychoi* jedno-duszni [[G4861]] WTA-NPM **το** *to* [[G3588]] WTT-ASN **εν** *hen* jedno [[G1520]] WTA-ASN **φρονουντες** *fronountes* myśląc – rozumiejąc [[G5426]] WTV-PAP-NPM
###### **Flp 2,3**
 **μηδεν** *mēden* nic [[G3367]] WTA-ASN **κατα** *kata* dla [[G2596]] [[PREP]] **εριθειαν** *eritheian* niesnasek – podjudzania [[G2052]] WTN-ASF **η** *hē* lub [[G2228]] WTPRT **κενοδοξιαν** *kenodoksian* pustej chwały [[G2754]] WTN-ASF **αλλα** *alla* ale [[G235]] [[CONJ]] **τη** *tē* [[G3588]] WTT-DSF **ταπεινοφροσυνη** *tapeinofrosynē* pokorą – uniżonością [[G5012]] [[N-DSF]] **αλληλους** *allēlous* jedni drugich [[G240]] WTC-APM **ηγουμενοι** *hēgoumenoi* uznając [[G2233]] WTV-PNP-NPM **υπερεχοντας** *hyperechontas* (za) będących wyższymi od – (za) będących górującymi nad [[G5242]] WTV-PAP-APM **εαυτων** *heautōn* siebie [[G1438]] WTF-3GPM
###### **Flp 2,4**
 **μη** *mē* nie [[G3361]] [[PRT-N]] **τα** *ta* (na) [[G3588]] WTT-APN **εαυτων** *heautōn* swoje [[G1438]] WTF-3GPM **εκαστος** *hekastos* każdy [[G1538]] [[A-NSM]] **σκοπειτε** *skopeite* baczcie – przyglądajcie się [[G4648]] WTV-PAM-2P **αλλα** *alla* ale [[G235]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* (na) [[G3588]] WTT-APN **ετερων** *heterōn* innych [[G2087]] WTA-GPM **εκαστος** *hekastos* każdy [[G1538]] [[A-NSM]]
###### **Flp 2,5**
 **τουτο** *touto* To [[G5124]] WTD-ASN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **φρονεισθω** *froneisthō* bądźcie usposobionymi [[G5426]] WTV-PPM-3S **εν** *en* w [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **ο** *ho* co [[G3739]] WTR-NSN **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM
###### **Flp 2,6**
 **ος** *hos* który [[G3739]] WTR-NSM **εν** *en* w [[G1722]] [[PREP]] **μορφη** *morfē* postaci – kształcie [[G3444]] [[N-DSF]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **υπαρχων** *hyparchōn* będąc [[G5225]] [[V-PAP-NSM]] **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **αρπαγμον** *harpagmon* (za) zdobycz – (za) porywanie [[G725]] [[N-ASM]] **ηγησατο** *hēgēsato* uznał [[G2233]] WTV-ADI-3S **το** *to* [[G3588]] WTT-ASN **ειναι** *einai* być [[G1511]] WTV-PXN **ισα** *isa* równym [[G2470]] WTA-NPN **θεω** *theō* Bogu [[G2316]] WTN-DSM
###### **Flp 2,7**
 **αλλ** *all* ale [[G235]] [[CONJ]] **εαυτον** *heauton* siebie samego [[G1438]] WTF-3ASM **εκενωσεν** *ekenōsen* uczynił pustym – pozbawił znaczenia [[G2758]] [[V-AAI-3S]] **μορφην** *morfēn* postać – kształt [[G3444]] WTN-ASF **δουλου** *doulou* niewolnika – sługi [[G1401]] [[N-GSM]] **λαβων** *labōn* wziąwszy [[G2983]] WTV-2AAP-NSM **εν** *en* w [[G1722]] [[PREP]] **ομοιωματι** *homoiōmati* podobieństwie – upodobaniu [[G3667]] WTN-DSN **ανθρωπων** *anthrōpōn* ludzi [[G444]] WTN-GPM **γενομενος** *genomenos* stawszy się [[G1096]] WTV-2ADP-NSM **και** *kai* a [[G2532]] [[CONJ]] **σχηματι** *schēmati* (dla) postaci – (dla) kształtu [[G4976]] WTN-DSN **ευρεθεις** *heuretheis* został znaleziony [[G2147]] WTV-APP-NSM **ως** *hōs* jako [[G5613]] [[ADV]] **ανθρωπος** *anthrōpos* człowiek [[G444]] [[N-NSM]]
###### **Flp 2,8**
 **εταπεινωσεν** *etapeinōsen* uniżył – poniżył [[G5013]] [[V-AAI-3S]] **εαυτον** *heauton* siebie samego [[G1438]] WTF-3ASM **γενομενος** *genomenos* stawszy się [[G1096]] WTV-2ADP-NSM **υπηκοος** *hypēkoos* posłuszny [[G5255]] [[A-NSM]] **μεχρι** *mechri* aż do [[G3360]] [[ADV]] **θανατου** *thanatou* śmierci [[G2288]] [[N-GSM]] **θανατου** *thanatou* śmierci [[G2288]] [[N-GSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **σταυρου** *staurou* krzyżowej [[G4716]] [[N-GSM]]
###### **Flp 2,9**
 **διο** *dio* Dlatego [[G1352]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **αυτον** *auton* Go [[G846]] WTP-ASM **υπερυψωσεν** *hyperypsōsen* wielce wywyższył [[G5251]] [[V-AAI-3S]] **και** *kai* i [[G2532]] [[CONJ]] **εχαρισατο** *echarisato* darował [[G5483]] WTV-ADI-3S **αυτω** *autō* Mu [[G846]] WTP-DSM **ονομα** *onoma* imię [[G3686]] WTN-ASN **το** *to* [[G3588]] WTT-ASN **υπερ** *hyper* ponad [[G5228]] [[PREP]] **παν** *pan* wszelkie [[G3956]] WTA-ASN **ονομα** *onoma* imię [[G3686]] WTN-ASN
###### **Flp 2,10**
 **ινα** *hina* aby [[G2443]] [[CONJ]] **εν** *en* na [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **ονοματι** *onomati* imię [[G3686]] WTN-DSN **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **παν** *pan* każde [[G3956]] WTA-NSN **γονυ** *gony* kolano [[G1119]] WTN-NSN **καμψη** *kampsē* zgięłoby się [[G2578]] WTV-AAS-3S **επουρανιων** *epouraniōn* niebiańskich [[G2032]] WTA-GPM **και** *kai* i [[G2532]] [[CONJ]] **επιγειων** *epigeiōn* ziemskich [[G1919]] WTA-GPN **και** *kai* i [[G2532]] [[CONJ]] **καταχθονιων** *katachthoniōn* podziemnych [[G2709]] WTA-GPM
###### **Flp 2,11**
 **και** *kai* i [[G2532]] [[CONJ]] **πασα** *pasa* każdy [[G3956]] WTA-NSF **γλωσσα** *glōssa* język [[G1100]] [[N-NSF]] **εξομολογησηται** *eksomologēsētai* wyznałby [[G1843]] WTV-AMS-3S **οτι** *hoti* że [[G3754]] [[CONJ]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **ιησους** *iēsous* Jezus – [JHWH jest zbawieniem] [[G2424]] [[N-NSM]] **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **εις** *eis* ku [[G1519]] [[PREP]] **δοξαν** *doksan* chwale [[G1391]] WTN-ASF **θεου** *theou* Boga [[G2316]] [[N-GSM]] **πατρος** *patros* Ojca [[G3962]] [[N-GSM]]
###### **Flp 2,12**
 **ωστε** *hōste* Tak, że [[G5620]] [[CONJ]] **αγαπητοι** *agapētoi* umiłowani [[G27]] WTA-VPM **μου** *mou* moi [[G3450]] WTP-1GS **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **παντοτε** *pantote* zawsze – każdej chwili [[G3842]] [[ADV]] **υπηκουσατε** *hypēkousate* byliście posłuszni [[G5219]] WTV-AAI-2P **μη** *mē* nie [[G3361]] [[PRT-N]] **ως** *hōs* jak [[G5613]] [[ADV]] **εν** *en* podczas [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **παρουσια** *parousia* obecności – przyjścia [[G3952]] [[N-DSF]] **μου** *mou* mojej [[G3450]] WTP-1GS **μονον** *monon* jedynie – tylko [[G3440]] [[ADV]] **αλλα** *alla* ale [[G235]] [[CONJ]] **νυν** *nyn* teraz [[G3568]] [[ADV]] **πολλω** *pollō* wiele [[G4183]] WTA-DSN **μαλλον** *mallon* bardziej [[G3123]] [[ADV]] **εν** *en* podczas [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **απουσια** *apousia* nieobecności [[G666]] [[N-DSF]] **μου** *mou* mojej [[G3450]] WTP-1GS **μετα** *meta* ze [[G3326]] [[PREP]] **φοβου** *fobou* strachem – bojaźnią [[G5401]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **τρομου** *tromou* drżeniem [[G5156]] [[N-GSM]] **την** *tēn* [[G3588]] WTT-ASF **εαυτων** *heautōn* swoje [[G1438]] WTF-3GPM **σωτηριαν** *sōtērian* zbawienie – wyzwolenie [[G4991]] WTN-ASF **κατεργαζεσθε** *katergazesthe* sprawujcie [[G2716]] WTV-PNM-2P
###### **Flp 2,13**
 **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ο** *ho* (Tym) [[G3588]] [[T-NSM]] **ενεργων** *energōn* działającym [[G1754]] [[V-PAP-NSM]] **εν** *en* w [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-ASN **θελειν** *thelein* chcieć [[G2309]] WTV-PAN **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-ASN **ενεργειν** *energein* wykonać – działać [[G1754]] WTV-PAN **υπερ** *hyper* dla [[G5228]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **ευδοκιας** *eudokias* upodobania [[G2107]] [[N-GSF]]
###### **Flp 2,14**
 **παντα** *panta* Wszystkie [[G3956]] WTA-APN **ποιειτε** *poieite* czyńcie [[G4160]] WTV-PAM-2P **χωρις** *chōris* bez [[G5565]] [[ADV]] **γογγυσμων** *gongysmōn* szemrań – narzekań [[G1112]] WTN-GPM **και** *kai* i [[G2532]] [[CONJ]] **διαλογισμων** *dialogismōn* rozważań – zamysłów [[G1261]] WTN-GPM
###### **Flp 2,15**
 **ινα** *hina* Aby [[G2443]] [[CONJ]] **γενησθε** *genēsthe* stalibyście się [[G1096]] WTV-2ADS-2P **αμεμπτοι** *amemptoi* nienaganni [[G273]] WTA-NPM **και** *kai* i [[G2532]] [[CONJ]] **ακεραιοι** *akeraioi* prości – szczerzy [[G185]] WTA-NPM **τεκνα** *tekna* dzieci [[G5043]] WTN-NPN **θεου** *theou* Boga [[G2316]] [[N-GSM]] **αμωμητα** *amōmēta* nienaganne – niewinne [[G298]] WTA-NPN **εν** *en* w [[G1722]] [[PREP]] **μεσω** *mesō* pośrodku [[G3319]] WTA-DSN **γενεας** *geneas* pokolenia [[G1074]] [[N-GSF]] **σκολιας** *skolias* wypaczonego – wykrzywionego [[G4646]] WTA-GSF **και** *kai* i [[G2532]] [[CONJ]] **διεστραμμενης** *diestrammenēs* które jest przewrócone – które jest odwrócone [[G1294]] WTV-RPP-GSF **εν** *en* wśród [[G1722]] [[PREP]] **οις** *hois* których [[G3739]] WTR-DPM **φαινεσθε** *fainesthe* jesteście ukazani – jesteście uczynieni widocznymi [[G5316]] WTV-PPI-2P **ως** *hōs* jak [[G5613]] [[ADV]] **φωστηρες** *fōstēres* światła – lampy [[G5458]] WTN-NPM **εν** *en* w [[G1722]] [[PREP]] **κοσμω** *kosmō* świecie [[G2889]] WTN-DSM
###### **Flp 2,16**
 **λογον** *logon* Słowo [[G3056]] [[N-ASM]] **ζωης** *zōēs* życia [[G2222]] [[N-GSF]] **επεχοντες** *epechontes* trzymając – zachowując [[G1907]] WTV-PAP-NPM **εις** *eis* ku [[G1519]] [[PREP]] **καυχημα** *kauchēma* chlubie [[G2745]] WTN-ASN **εμοι** *emoi* mojej [[G1698]] WTP-1DS **εις** *eis* na [[G1519]] [[PREP]] **ημεραν** *hēmeran* dzień [[G2250]] WTN-ASF **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **οτι** *hoti* że [[G3754]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εις** *eis* na [[G1519]] [[PREP]] **κενον** *kenon* próżno – pusto [[G2756]] WTA-ASN **εδραμον** *edramon* pobiegłem [[G5143]] WTV-2AAI-1S **ουδε** *oude* ani [[G3761]] [[ADV]] **εις** *eis* na [[G1519]] [[PREP]] **κενον** *kenon* próżno – pusto [[G2756]] WTA-ASN **εκοπιασα** *ekopiasa* trudziłem się [[G2872]] WTV-AAI-1S
###### **Flp 2,17**
 **αλλ** *all* Ale [[G235]] [[CONJ]] **ει** *ei* jeśli [[G1487]] WTCOND **και** *kai* i [[G2532]] [[CONJ]] **σπενδομαι** *spendomai* jestem wylany – jestem wylany w libacji [[G4689]] WTV-PPI-1S **επι** *epi* na [[G1909]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **θυσια** *thysia* ofiarę [[G2378]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **λειτουργια** *leitourgia* publiczne dzieło – publiczną służbę [[G3009]] [[N-DSF]] **της** *tēs* [[G3588]] [[T-GSF]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **υμων** *hymōn* waszej [[G5216]] WTP-2GP **χαιρω** *chairō* raduję się – cieszę się [[G5463]] WTV-PAI-1S **και** *kai* i [[G2532]] [[CONJ]] **συγχαιρω** *sygchairō* współcieszę się ze – współraduję się ze [[G4796]] WTV-PAI-1S **πασιν** *pasin* wszystkimi [[G3956]] WTA-DPM **υμιν** *hymin* wami [[G5213]] WTP-2DP
###### **Flp 2,18**
 **το** *to* [[G3588]] WTT-ASN **δ** *d* zaś [[G1161]] [[CONJ]] **αυτο** *auto* tak samo [[G846]] WTP-ASN **και** *kai* i [[G2532]] [[CONJ]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **χαιρετε** *chairete* radujcie się – cieszcie się [[G5463]] WTV-PAM-2P **και** *kai* i [[G2532]] [[CONJ]] **συγχαιρετε** *sygchairete* współcieszcie się ze – współradujcie się ze [[G4796]] WTV-PAM-2P **μοι** *moi* mną [[G3427]] WTP-1DS
###### **Flp 2,19**
 **ελπιζω** *elpizō* Mam nadzieję [[G1679]] WTV-PAI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM **τιμοθεον** *timotheon* Tymoteusza – [czczący Boga] [[G5095]] [[N-ASM]] **ταχεως** *tacheōs* szybko [[G5030]] [[ADV]] **πεμψαι** *pempsai* posłać [[G3992]] [[V-AAN]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **ινα** *hina* aby [[G2443]] [[CONJ]] **καγω** *kagō* i ja [[G2504]] WTP-1NS-C **ευψυχω** *eupsychō* byłbym dobrej myśli [[G2174]] WTV-PAS-1S **γνους** *gnous* poznawszy [[G1097]] WTV-2AAP-NSM **τα** *ta* (te) [[G3588]] WTT-APN **περι** *peri* około [[G4012]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP
###### **Flp 2,20**
 **ουδενα** *oudena* Nikogo [[G3762]] WTA-ASM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εχω** *echō* mam [[G2192]] WTV-PAI-1S **ισοψυχον** *isopsychon* równie myślącego – podobnie myślącego [[G2473]] WTA-ASM **οστις** *hostis* który [[G3748]] WTR-NSM **γνησιως** *gnēsiōs* szczerze – prawdziwie [[G1104]] [[ADV]] **τα** *ta* (o te) [[G3588]] WTT-APN **περι** *peri* około [[G4012]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **μεριμνησει** *merimnēsei* zatroszczy się – będzie się martwił [[G3309]] WTV-FAI-3S
###### **Flp 2,21**
 **οι** *hoi* [[G3588]] WTT-NPM **παντες** *pantes* Wszyscy [[G3956]] WTA-NPM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **τα** *ta* (tych) [[G3588]] WTT-APN **εαυτων** *heautōn* swoich [[G1438]] WTF-3GPM **ζητουσιν** *zētousin* szukają [[G2212]] WTV-PAI-3P **ου** *ou* nie [[G3756]] [[PRT-N]] **τα** *ta* (tych) [[G3588]] WTT-APN **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]]
###### **Flp 2,22**
 **την** *tēn* [[G3588]] WTT-ASF **δε** *de* zaś [[G1161]] [[CONJ]] **δοκιμην** *dokimēn* wypróbowanie [[G1382]] WTN-ASF **αυτου** *autou* jego [[G846]] [[P-GSM]] **γινωσκετε** *ginōskete* znacie [[G1097]] WTV-PAI-2P **οτι** *hoti* że [[G3754]] [[CONJ]] **ως** *hōs* jak [[G5613]] [[ADV]] **πατρι** *patri* ojcu – (z) ojcem [[G3962]] WTN-DSM **τεκνον** *teknon* dziecko [[G5043]] WTN-NSN **συν** *syn* razem ze [[G4862]] [[PREP]] **εμοι** *emoi* mną [[G1698]] WTP-1DS **εδουλευσεν** *edouleusen* był niewolnikiem – służył [[G1398]] [[V-AAI-3S]] **εις** *eis* względem [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **ευαγγελιον** *euangelion* dobrej nowiny [[G2098]] WTN-ASN
###### **Flp 2,23**
 **τουτον** *touton* Tego [[G5126]] WTD-ASM **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **ουν** *oun* więc [[G3767]] [[CONJ]] **ελπιζω** *elpizō* mam nadzieję [[G1679]] WTV-PAI-1S **πεμψαι** *pempsai* posłać [[G3992]] [[V-AAN]] **ως** *hōs* jak- [[G5613]] [[ADV]] **αν** *an* kolwiek [[G302]] WTPRT **απιδω** *apidō* zobaczyłbym z dala [[G872]] WTV-2AAS-1S **τα** *ta* (te) [[G3588]] WTT-APN **περι** *peri* około [[G4012]] [[PREP]] **εμε** *eme* mnie [[G1691]] WTP-1AS **εξαυτης** *eksautēs* natychmiast [[G1824]] [[ADV]]
###### **Flp 2,24**
 **πεποιθα** *pepoitha* Jestem przekonany – Pokładam ufność [[G3982]] WTV-2RAI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **οτι** *hoti* że [[G3754]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **αυτος** *autos* sam [[G846]] WTP-NSM **ταχεως** *tacheōs* szybko [[G5030]] [[ADV]] **ελευσομαι** *eleusomai* przyjdę [[G2064]] WTV-FDI-1S
###### **Flp 2,25**
 **αναγκαιον** *anagkaion* Konieczne – Niezbędne [[G316]] WTA-ASN **δε** *de* zaś [[G1161]] [[CONJ]] **ηγησαμην** *hēgēsamēn* uznałem [[G2233]] WTV-ADI-1S **επαφροδιτον** *epafroditon* Epafrodyta – [uroczy] [[G1891]] [[N-ASM]] **τον** *ton* [[G3588]] [[T-ASM]] **αδελφον** *adelfon* brata [[G80]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **συνεργον** *synergon* współpracownika [[G4904]] WTA-ASM **και** *kai* i [[G2532]] [[CONJ]] **συστρατιωτην** *systratiōtēn* współbojownika – współżołnierza [[G4961]] [[N-ASM]] **μου** *mou* mojego [[G3450]] WTP-1GS **υμων** *hymōn* waszego [[G5216]] WTP-2GP **δε** *de* zaś [[G1161]] [[CONJ]] **αποστολον** *apostolon* wysłannika [[G652]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **λειτουργον** *leitourgon* publicznego sługę [[G3011]] [[N-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **χρειας** *chreias* potrzeby [[G5532]] [[N-GSF]] **μου** *mou* mojej [[G3450]] WTP-1GS **πεμψαι** *pempsai* posłać [[G3992]] [[V-AAN]] **προς** *pros* do [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP
###### **Flp 2,26**
 **επειδη** *epeidē* skoro zaś – jako, że [[G1894]] [[CONJ]] **επιποθων** *epipothōn* tęskniącym – pragnącym [[G1971]] [[V-PAP-NSM]] **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **παντας** *pantas* wszystkich [[G3956]] WTA-APM **υμας** *hymas* was [[G5209]] WTP-2AP **και** *kai* i [[G2532]] [[CONJ]] **αδημονων** *adēmonōn* niepokojąc się – martwiąc się [[G85]] [[V-PAP-NSM]] **διοτι** *dioti* dlatego, że [[G1360]] [[CONJ]] **ηκουσατε** *ēkousate* usłyszeliście [[G191]] WTV-AAI-2P **οτι** *hoti* że [[G3754]] [[CONJ]] **ησθενησεν** *ēsthenēsen* był słaby – był bez siły [[G770]] [[V-AAI-3S]]
###### **Flp 2,27**
 **και** *kai* I [[G2532]] [[CONJ]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ησθενησεν** *ēsthenēsen* był słaby – był bez siły [[G770]] [[V-AAI-3S]] **παραπλησιον** *paraplēsion* niemal blisko [[G3897]] [[ADV]] **θανατω** *thanatō* śmierci [[G2288]] WTN-DSM **αλλ** *all* ale [[G235]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **αυτον** *auton* (nad) nim [[G846]] WTP-ASM **ηλεησεν** *ēleēsen* zlitował się – zmiłował się [[G1653]] [[V-AAI-3S]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **αυτον** *auton* (nad) nim [[G846]] WTP-ASM **δε** *de* zaś [[G1161]] [[CONJ]] **μονον** *monon* jedynie – tylko [[G3440]] [[ADV]] **αλλα** *alla* ale [[G235]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **εμε** *eme* (nade) mną [[G1691]] WTP-1AS **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **λυπην** *lypēn* smutek [[G3077]] WTN-ASF **επι** *epi* do [[G1909]] [[PREP]] **λυπη** *lypē* smutku [[G3077]] [[N-DSF]] **σχω** *schō* miałbym [[G2192]] WTV-2AAS-1S
###### **Flp 2,28**
 **σπουδαιοτερως** *spoudaioterōs* Bardziej gorliwie – Pilniej [[G4708]] [[ADV]]-C **ουν** *oun* więc [[G3767]] [[CONJ]] **επεμψα** *epempsa* posłałem [[G3992]] WTV-AAI-1S **αυτον** *auton* go [[G846]] WTP-ASM **ινα** *hina* aby [[G2443]] [[CONJ]] **ιδοντες** *idontes* zobaczywszy [[G1492]] WTV-2AAP-NPM **αυτον** *auton* go [[G846]] WTP-ASM **παλιν** *palin* znowu [[G3825]] [[ADV]] **χαρητε** *charēte* rozradowalibyście się – cieszylibyście się [[G5463]] WTV-2AOS-2P **καγω** *kagō* i ja [[G2504]] WTP-1NS-C **αλυποτερος** *alypoteros* bardziej bez smutku [[G253]] [[A-NSM]]-C **ω** *ō* byłbym [[G5600]] WTV-PXS-1S
###### **Flp 2,29**
 **προσδεχεσθε** *prosdechesthe* Przyjmijcie [[G4327]] WTV-PNM-2P **ουν** *oun* więc [[G3767]] [[CONJ]] **αυτον** *auton* go [[G846]] WTP-ASM **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **μετα** *meta* z [[G3326]] [[PREP]] **πασης** *pasēs* całą [[G3956]] WTA-GSF **χαρας** *charas* radością [[G5479]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **τους** *tous* [[G3588]] WTT-APM **τοιουτους** *toioutous* takich [[G5108]] WTD-APM **εντιμους** *entimous* (jako) cennych – (w) poszanowaniu [[G1784]] WTA-APM **εχετε** *echete* miejcie [[G2192]] WTV-PAM-2P
###### **Flp 2,30**
 **οτι** *hoti* bo [[G3754]] [[CONJ]] **δια** *dia* z powodu [[G1223]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **εργον** *ergon* dzieła [[G2041]] WTN-ASN **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **μεχρι** *mechri* aż do [[G3360]] [[ADV]] **θανατου** *thanatou* śmierci [[G2288]] [[N-GSM]] **ηγγισεν** *ēngisen* zbliżył się – był bliski [[G1448]] [[V-AAI-3S]] **παραβουλευσαμενος** *parabouleusamenos* który naraził – który zaryzykował [[G3851]] WTV-ADP-NSM **τη** *tē* [[G3588]] WTT-DSF **ψυχη** *psychē* duszę – życie [[G5590]] [[N-DSF]] **ινα** *hina* aby [[G2443]] [[CONJ]] **αναπληρωση** *anaplērōsē* wypełniłby [[G378]] WTV-AAS-3S **το** *to* [[G3588]] WTT-ASN **υμων** *hymōn* wasz [[G5216]] WTP-2GP **υστερημα** *hysterēma* brak [[G5303]] WTN-ASN **της** *tēs* [[G3588]] [[T-GSF]] **προς** *pros* względem [[G4314]] [[PREP]] **με** *me* mnie [[G3165]] WTP-1AS **λειτουργιας** *leitourgias* publicznego dzieła – publicznej służby [[G3009]] [[N-GSF]]
