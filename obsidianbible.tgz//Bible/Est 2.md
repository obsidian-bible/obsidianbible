# Est 2 BT5
###### **Est 2,1**
 Po tych wydarzeniach, gdy minął gniew króla Aswerusa, przypomniał on sobie Waszti, to, co ona uczyniła, oraz postanowienie w jej sprawie.
###### **Est 2,2**
 I powiedzieli dworzanie króla, którzy mu usługiwali: «***Niech poszukają królowi młodych dziewic o pięknym wyglądzie***
###### **Est 2,3**
 ***i niech zamianuje król urzędników we wszystkich państwach swego królestwa, i niech zgromadzą wszystkie młode dziewice o miłym wyglądzie na zamku w Suzie, w domu kobiet, pod opieką Hegaja, eunucha królewskiego, stróża żon, i niech on da im środki upiększające!***
###### **Est 2,4**
 ***Ta dziewczyna, która się spodoba królowi, będzie królową w miejsce Waszti***». Spodobała się ta mowa królowi i postąpił zgodnie z nią.
###### **Est 2,5**
  A był na zamku w Suzie mąż imieniem Mardocheusz, syn Jaira, syna Szimejego, syna Kisza, człowiek z pokolenia Beniamina.
###### **Est 2,6**
 Ten został uprowadzony na wygnanie razem z królem judzkim, Jechoniaszem, którego uprowadził na wygnanie król babiloński, Nabuchodonozor.
###### **Est 2,7**
 A był on opiekunem Hadassy, to jest Estery, córki swego stryja, bo nie miała ona ojca ani matki. Była to panna o pięknej postaci i miłym wyglądzie; a gdy umarli jej ojciec i matka, przyjął ją Mardocheusz za córkę.
###### **Est 2,8**
 Gdy rozeszła się wieść o poleceniu królewskim i jego rozkazie i gdy zgromadzono wiele dziewcząt na zamku w Suzie pod opieką Hegaja, wzięta też została Estera do domu króla pod opiekę Hegaja, stróża żon.
###### **Est 2,9**
 Dziewczyna mu się spodobała i pozyskała sobie jego życzliwość. Pośpieszył więc, by dać jej środki upiększające i [należną] jej część [utrzymania]. Dał jej też siedem dziewcząt z domu króla za towarzyszki i przeniósł ją i jej dziewczęta do lepszego miejsca w domu kobiet.
###### **Est 2,10**
 A nie ujawniła Estera swego narodu i pochodzenia, ponieważ Mardocheusz rozkazał jej, aby nic nie mówiła.
###### **Est 2,11**
 Mardocheusz zaś przechadzał się codziennie na wprost przedsionka domu kobiet, aby dowiadywać się o zdrowie Estery i co się z nią dzieje.
###### **Est 2,12**
 A gdy przychodziła kolej na każdą dziewczynę, aby pójść do króla Aswerusa, pod koniec jej pobytu, wedle prawa kobiet, to jest po dwunastu miesiącach – ponieważ wtedy kończyły się dni ich namaszczania, sześć miesięcy olejkiem mirrowym, a sześć miesięcy balsamami i kobiecymi środkami upiększającymi –
###### **Est 2,13**
 wtedy dopiero dziewczyna szła do króla. Wszystko, czego zażądała, dawano jej, aby mogła to wziąć ze sobą do domu króla.
###### **Est 2,14**
 Wieczorem szła, a rano wracała do drugiego domu kobiet pod opiekę Szaaszgaza, eunucha królewskiego, stróża nałożnic. Nie przychodziła ona już do króla, chyba że król jej zapragnął i wezwał ją imiennie.
###### **Est 2,15**
 A gdy na Esterę, córkę Abichaila, stryja Mardocheusza, który wziął ją za córkę, przyszła kolej, aby poszła do króla, nie żądała niczego, poza tym, co polecił Hegaj, eunuch królewski, stróż żon. Estera pozyskała sobie życzliwość wszystkich, którzy na nią patrzyli.
###### **Est 2,16**
 Zabrano więc Esterę do króla Aswerusa, do jego pałacu królewskiego, w dziesiątym miesiącu, to jest w miesiącu Tebet, w siódmym roku jego panowania.
###### **Est 2,17**
 I umiłował król Esterę nad wszystkie [inne] kobiety. Pozyskała sobie u niego życzliwość i względy nad wszystkie [inne] dziewice, i włożył na jej głowę koronę królewską, i uczynił ją królową w miejsce Waszti.
###### **Est 2,18**
 Wydał [także] król wielką ucztę dla wszystkich swoich książąt i sług swoich, ucztę Estery, a państwa uwolnił od podatków, obdarował ich z hojnością królewską.
###### **Est 2,19**
 A gdy zgromadzono dziewczęta po raz drugi i Mardocheusz siedział w Bramie Królewskiej,
###### **Est 2,20**
 Estera nie powiedziała o swoim pochodzeniu i o narodzie, tak jak to polecił jej Mardocheusz. Estera postąpiła zgodnie z poleceniem Mardocheusza, tak jakby była jeszcze pod jego opieką.
###### **Est 2,21**
 Mardocheusz w owych dniach był przy Bramie Królewskiej. A dwaj niezadowoleni eunuchowie królewscy, Bigtan i Teresz, spomiędzy "stróżów progu", szukali sposobności, aby podnieść rękę na króla Aswerusa.
###### **Est 2,22**
 Doszła wiadomość o sprawie tej do Mardocheusza i powiedział o tym królowej Esterze, a Estera oznajmiła królowi w imieniu Mardocheusza.
###### **Est 2,23**
 Sprawa została wyśledzona i udowodniona, powieszono więc obu na drzewie, a zapisano to w księdze kronik w obecności króla.
# Est 2 PAU
###### **Est 2,1**
 Po tych wydarzeniach ustał gniew króla. Nie wspominał on więcej Waszti, pamiętając, co powiedziała i jak ją ukarał.
###### **Est 2,2**
 A dworzanie królewscy mówili: „Trzeba wyszukać królowi młode, nietknięte dziewczęta o pięknym wyglądzie.
###### **Est 2,3**
 Niech król mianuje urzędników we wszystkich okręgach swego królestwa, żeby w mieście Suza, w domu kobiet zgromadzili piękne dziewice i przekazali je eunuchowi królewskiemu, pilnującemu kobiet, a on niech im dostarczy olejków i innych kosmetyków.
###### **Est 2,4**
 Kobieta, która spodoba się królowi, zostanie królową w miejsce Waszti”. Myśl ta spodobała się królowi i tak postąpił.
###### **Est 2,5**
 W mieście Suza mieszkał pewien Judejczyk imieniem Mardocheusz, syn Jaira, syna Szimeiego, syna Kisza, z plemienia Beniamina.
###### **Est 2,6**
 Został on uprowadzony z Jerozolimy, którą zniewolił babiloński król Nabuchodonozor.
###### **Est 2,7**
 Był on opiekunem dziewczyny imieniem Estera, córki jego stryja Aminadaba. Po śmierci jej rodziców Mardocheusz wychowywał ją z zamiarem poślubienia jej. Była to dziewczyna niezwykłej urody.
###### **Est 2,8**
 Gdy ogłoszono zarządzenie króla, w mieście Suza zebrano pod opieką Gaja wiele dziewcząt. Również Estera udała się do Gaja, pilnującego kobiet.
###### **Est 2,9**
 Dziewczyna spodobała mu się i zyskała jego względy. Rozkazał więc dostarczyć jej kosmetyków i dać przysługujące jej utrzymanie, a z pałacu królewskiego przydzielić siedem dziewcząt. Ona i jej służące były traktowane dobrze w domu kobiet.
###### **Est 2,10**
 Estera jednak nie ujawniła swego pochodzenia ani narodowości, gdyż Mardocheusz zakazał jej o tym mówić.
###### **Est 2,11**
 Każdego dnia Mardocheusz przechadzał się w pobliżu dziedzińca domu kobiet w oczekiwaniu na to, co stanie się z Esterą.
###### **Est 2,12**
 Po dwunastu miesiącach nadchodził czas, kiedy dziewczęta szły do króla. Okres przygotowań wyglądał następująco: przez sześć miesięcy dziewczęta były namaszczane olejkiem z mirry, a przez następne sześć miesięcy wonnościami i innymi kosmetykami dla kobiet.
###### **Est 2,13**
 Dopiero wtedy dziewczyna udawała się do króla, a jeśli wcześniej poprosiła o coś, nie odmawiano jej. Następnie zabierano ją z domu kobiet do pałacu królewskiego.
###### **Est 2,14**
 Szła tam wieczorem, a rankiem przechodziła do drugiego domu, którego stróżem był również Gaj, eunuch królewski, pilnujący kobiet. I nigdy więcej nie szła do króla, chyba że wezwał ją imiennie.
###### **Est 2,15**
 Gdy na Esterę, córkę Aminadaba, stryja Mardocheusza, przyszedł czas, by udać się do króla, zrobiła tylko to, co doradził jej eunuch, strażnik kobiet. Estera znalazła też uznanie w oczach wszystkich, którzy ją wówczas widzieli.
###### **Est 2,16**
 Estera udała się do króla Artakserksesa w siódmym roku jego panowania, w miesiącu dwunastym, którym był miesiąc Adar.
###### **Est 2,17**
 Król pokochał Esterę i doznała ona życzliwości większej niż wszystkie inne dziewice. Król nałożył jej diadem królowej.
###### **Est 2,18**
 Potem król wydał siedmiodniową ucztę dla wszystkich swoich przyjaciół i możnowładców, uroczyście świętując ślub z Esterą. Ogłosił także amnestię dla poddanych swego królestwa.
###### **Est 2,19**
 A Mardocheusz usługiwał na dworze.
###### **Est 2,20**
 Natomiast Estera nie ujawniła swego pochodzenia. Mardocheusz bowiem nakazał jej oddawać cześć Bogu i postępować według Jego nakazów, jak wtedy, gdy była z nim. Estera niezmiennie tego przestrzegała.
###### **Est 2,21**
 Dwaj eunuchowie królewscy, dowódcy straży przybocznej, poczuli się dotknięci, że Mardocheusz miał szczególne względy u króla. Usiłowali oni zabić króla Artakserksesa.
###### **Est 2,22**
 Dowiedział się o tym Mardocheusz i powiadomił Esterę, a ona ujawniła ten zamiar królowi.
###### **Est 2,23**
 Król przesłuchał obydwu eunuchów i powieszono ich. Na pamiątkę tego król polecił umieścić w kronikach królewskich pochwałę lojalności Mardocheusza.
# Est 2 BP
###### **Est 2,1**
 Po tych wydarzeniach, gdy gniew króla Achaszwerosza się uspokoił, przypomniał sobie Waszti i to, co uczyniła, i to, co o niej postanowiono.
###### **Est 2,2**
 Dworzanie króla, którzy pełnili przy nim służbę, orzekli: Niech wyszukują dla króla młode dziewice, wielkiej urody.
###### **Est 2,3**
 Niech król ustanowi urzędników we wszystkich prowincjach swego królestwa, by sprowadzili wszystkie młode dziewice o wielkiej urodzie do stolicy w Suzie, do domu kobiet [znajdującego się] pod opieką Hegaji, eunucha królewskiego, stróża kobiet; on zaś niech wyposaży je we wszystko, co im do przyozdobienia potrzeba.
###### **Est 2,4**
 I niech ta dziewica, która spodoba się oczom królewskim, zostanie królową na miejsce Waszti. Spodobała się ta rada królowi i tak też postąpił.
###### **Est 2,5**
 W mieście stołecznym Suza mieszkał pewien Żyd imieniem Mardocheusz, syn Jaira, syna Szemei, syna Kisza, Beniaminita,
###### **Est 2,6**
 wysiedlony razem z wygnańcami, których wraz z królem judzkim Jechoniaszem uprowadził z Jeruzalem Nebukadnezar, król babiloński.
###### **Est 2,7**
 Był on opiekunem Hadassy, to jest Estery, córki jego stryja, która nie miała ani ojca, ani matki. Dziewczyna miała piękne kształty i wdzięczną powierzchowność, a gdy jej ojciec i matka umarli, przyjął ją Mardocheusz za córkę.
###### **Est 2,8**
 Gdy ogłoszono dekret i nakaz królewski i wiele dziewcząt zgromadziło się w twierdzy Suza pod opieką Hegaji, sprowadzono i Esterę do pałacu królewskiego pod opiekę Hegaji, stróża kobiet.
###### **Est 2,9**
 Dziewczyna spodobała mu się i zyskała sobie jego względy, tak że postarał się, by czym prędzej dano jej to, co jej było potrzebne do przyozdobienia i utrzymania, oraz przydzielił jej do usług siedem dobranych dziewcząt z pałacu królewskiego, a następnie przeniósł ją ze służebnicami do najpiękniejszej części domu kobiet.
###### **Est 2,10**
 Estera nie zdradziła ani swego pochodzenia, ani rodu, gdyż Mardocheusz zakazał jej mówić o tym.
###### **Est 2,11**
 Każdego dnia Mardocheusz przechadzał się przed dziedzińcem domu kobiet, by się dowiedzieć o zdrowiu Estery i [o tym], jak się jej powodzi.
###### **Est 2,12**
 Za każdym razem, gdy przychodziła kolej na dziewczynę, aby stanęła przed królem Achaszweroszem, po upływie dwunastu miesięcy zgodnie z przepisami dla niewiast - tyle bowiem czasu przeznaczano na pielęgnowanie ich urody: sześć miesięcy na namaszczanie olejkiem z mirry i [drugie] sześć na namaszczanie balsamem i innymi pachnidłami, jakich używają kobiety -
###### **Est 2,13**
 wtedy dziewczyna udawała się do króla; musiano jej zaś dostarczyć wszystkiego, czego zażądała, aby z tym szła z domu kobiet do pałacu królewskiego.
###### **Est 2,14**
 Wieczorem udawała się tam, nad ranem zaś przechodziła do drugiego haremu pod opiekę Szaaszgaza, eunucha królewskiego, stróża nałożnic. I nie mogła już przychodzić do króla, chyba że jej król zapragnął i sam przywołał ją po imieniu.
###### **Est 2,15**
 A gdy przyszła kolej na Esterę, córkę Abichajila, stryja Mardocheusza, który ją przyjął za córkę, aby udała się do króla, nie żądała niczego oprócz tego, co jej polecił Hegaja, eunuch królewski, stróż kobiet. Estera spodobała się wszystkim, którzy ją wówczas widzieli.
###### **Est 2,16**
 Esterę wprowadzono do króla Achaszwerosza, do pałacu królewskiego, dziesiątego miesiąca, to znaczy miesiąca Tebet, roku siódmego jego panowania.
###### **Est 2,17**
 Król umiłował Esterę bardziej aniżeli inne niewiasty; zdobyła jego łaskę i upodobanie ponad wszystkie dziewczęta. Włożył jej więc na głowę diadem królewski i ustanowił ją królową na miejsce Waszti.
###### **Est 2,18**
 Ponadto wyprawił król wielką ucztę dla wszystkich książąt i dworzan, ucztę na cześć Estery, a prowincje uwolnił od podatków oraz rozdał dary ze szczodrobliwością królewską.
###### **Est 2,19**
 A gdy dziewczęta zgromadzono w drugim domu kobiet, Mardocheusz czuwał u bramy Królewskiej.
###### **Est 2,20**
 Estera nie wyjawiła ani swego pochodzenia, ani swego rodu, tak jak to jej polecił Mardocheusz. Była posłuszna poleceniom Mardocheusza jak dawniej, kiedy znajdowała się jeszcze pod jego opieką.
###### **Est 2,21**
 W tym czasie, gdy Mardocheusz pełnił straż u bramy Królewskiej, Bigtan i Teresz, dwaj eunuchowie królewscy, stróże progu, uniesieni gniewem, postanowili podnieść rękę na króla Achaszwerosza.
###### **Est 2,22**
 Mardocheusz dowiedział się o tym i zawiadomił królową Esterę, która w imieniu Mardocheusza doniosła o tym królowi.
###### **Est 2,23**
 Kiedy tę wiadomość zbadano i okazało się, że jest prawdziwa, powieszono obydwu na szubienicy, a [zdarzenie to] wpisano do księgi kronik, przeznaczonej dla króla.
# Est 2 BR
###### **Est 2,1**
 Gdy po jakimś czasie król ochłonął nieco z gniewu, znów przypomniał sobie o Waszti, o tym, co uczyniła i co w związku z nią postanowił.
###### **Est 2,2**
 Mówili tedy najbliżsi słudzy króla: Trzeba poszukać dla króla jakiejś pięknej, młodej dziewczyny.
###### **Est 2,3**
 Król powinien rozkazać, żeby we wszystkich prowincjach jego królestwa byli wyznaczeni specjalni urzędnicy, którzy zgromadzili wszystkie co piękniejsze dziewczęta, żeby przywiedli je do pałacu Kobiet w Suzie i przekazali eunuchowi Hegajowi, mającemu pieczę nad żonami królewskimi. Tam zadbano by o ich piękny wygląd,
###### **Est 2,4**
 i ta młoda kobieta, która podobałaby się królowi najbardziej, zajęłaby miejsce królowej Waszti. Uznał król tę radę za słuszną i kazał według niej postąpić.
###### **Est 2,5**
 Był zaś na zamku w Suzie człowiek imieniem Mardocheusz, syn Jaira, syna Szimejego, syna Kisza. Pochodził on z pokolenia Beniamina
###### **Est 2,6**
 i przybył tu z Jerozolimy z wygnańcami, których uprowadził, król babiloński Nabuchodonozor.
###### **Est 2,7**
 Mardocheusz opiekował się córką swojego krewnego, Hadassa, która nosiła również imię Estera. Nie miała ona już ani ojca, ani matki. Była bardzo piękna i pełna wdzięku. Po śmierci jej ojca i matki Mardocheusz przyjął ją do siebie jak własną córkę.
###### **Est 2,8**
 Kiedy już rozeszła się wieść o zarządzeniu królewskim i sposobie wprowadzenia go w życie, zgromadzono wiele młodych kobiet na zamku w Suzie i oddano je pod opiekę Hegajowi. Sprowadzono do pałacu królewskiego także Esterę i przekazano ją Hegajowi, nadzorcy żon królewskich.
###### **Est 2,9**
 Dziewczyna spodobała się Hegajowi i pozyskała sobie jego względy, a on troszczył się o to, by dostarczono jej wszystkiego, co służy pielęgnowaniu urody. Poza tym przydzielił jej siedem wybranych z pałacu królewskiego służebnic, a nieco później kazał umieścić ją samą oraz jej służebnice w najpiękniejszej części Pałacu Kobiet.
###### **Est 2,10**
 Estera nie mówiła nic ani o swoim narodzie, ani o własnym pochodzeniu. Mardocheusz jej polecił, żeby nic o tym nie mówiła.
###### **Est 2,11**
 Codziennie przychodził Mardocheusz do przedsionka Pałacu Kobiet, żeby się dowiedzieć, jak czuje się Estera i co się z nią dzieje.
###### **Est 2,12**
 Kolejno każda z dziewcząt była przyprowadzona do Aswerusa. Przedtem jednak, zgodnie z obowiązującym przepisem poddawano te dziewczęta dwunastomiesięcznej pielęgnacji: przez sześć miesięcy stosowano do tego olejek z mirry, a przez pozostałe sześć - olejek balsamowy i różne inne środki upiększające.
###### **Est 2,13**
 Wtedy dopiero przyprowadzono kobietę do króla, dając jej przy tym z pałacu królewskiego wszystko, czego tylko sobie życzyła.
###### **Est 2,14**
 Wieczorem wchodziła tam a rano znów wracała do Pałacu Kobiet i pozostawała pod opieką Szaaszgaza, eunucha nadzorującego nałożnice królewskie. Więcej już nie wolno jej było chodzić do króla, chyba że któraś z nich szczególnie mu się podobała i wzywał ją do siebie po imieniu.
###### **Est 2,15**
 I oto pewnego dnia została wezwana do króla, według kolejności także Estera, córka Abichaila, krewnego Mardocheusza, który przyjął ją do siebie jak własną córkę. Nie chciała zabierać ze sobą niczego oprócz tego, co podsunął jej Hegaj, eunuch królewski, nadzorca kobiet. Estera podobała się każdemu, kto ją zobaczył.
###### **Est 2,16**
 Została przedstawiona Aswerusowi w jego pałacu królewskim. Działo się to w dziesiątym miesiącu - czyli miesiącu Tebet - siódmego roku panowania tego króla.
###### **Est 2,17**
 I pokochał król Esterę bardziej niż pozostałe kobiety, tak iż zyskała sobie jego życzliwość i względy większe niż wszystkie inne dziewczęta. [Pewnego dnia] król włożył jej na głowę diadem królewski i kazał zająć miejsce królowej Waszti.
###### **Est 2,18**
 Ku czci Estery wydał też król wielką ucztę i kazał zaprosić na nią wszystkich swoich książąt i dworzan. Podległe mu prowincje zwolnił od podatków i z hojnością prawdziwie królewską rozdzielał dokoła dary.
###### **Est 2,19**
 Wtedy to, gdy dziewczęta wzywano [po raz drugi] do króla, Mardocheusz znajdował się w bramie królewskiego pałacu.
###### **Est 2,20**
 Estera zaś nadal nic nie mówiła ani o własnym pochodzeniu, ani o swoim narodzie, zgodnie z poleceniem, które dostała od Mardocheusza. Trzymała się słów Mardocheusza dokładnie tak samo, jak wówczas gdy była jeszcze pod jego opieką jako przybrana córka.
###### **Est 2,21**
 W tych dniach, kiedy Mardocheusz znajdował się na swoim miejscu koło bramy pałacu królewskiego, dwaj niezadowoleni eunuchowie królewscy, Bigran i Teresz, pełniąc służbę odźwiernych, obmyślali zamach na króla Aswerusa.
###### **Est 2,22**
 Podsłuchawszy ich rozmowę, Mardocheusz powtórzył wszystko królowej Esterze, a ta, wykonując polecenie Mardocheusza, przekazała to samo królowi.
###### **Est 2,23**
 Przeprowadzono śledztwo i ujawniono winnych. Powieszono ich obydwu na drzewie, a całe zdarzenie opisano w kronice, która była prowadzona z rozkazu króla.
# Est 2 WUJ
###### **Est 2,1**
 To gdy się tak stało, gdy się uśmierzył gniew króla Asswerusa, wspomniał na Vasthi, i co była uczyniła, abo co ucierpiała:
###### **Est 2,2**
 I rzekli dworzanie królewscy i służebnicy jego: Niech szukają królowi dzieweczek panienek i nadobnych.
###### **Est 2,3**
 I niech roześlą którzyby wypatrzyli po wszystkich krainach dzieweczki piękne i panny: i niech je przywiodą do miasta Susan, i oddadzą je do domu białychgłów pod rękę Egeja rzezańca, który jest hochmistrzem i stróżem białychgłów królewskich, i niech wezmą ochędóstwa białogłowskie, i inne rzeczy do potrzeby.
###### **Est 2,4**
 A któraby się ze wszystkich oczom królewskim podobała, ta niech króluje miasto Vasthi. Podobała się mowa królowi, i tak jako byli podali uczynić rozkazał.
###### **Est 2,5**
 Był mąż Żydowin w mieście Susan, imieniem Mardocheus, syn Jair, syna Semei, syna Cis, z pokolenia Jemini,
###### **Est 2,6**
 Który był przeniesiony z Jeruzalem na on czas, gdy Nabuchodnozor król Babiloński, przeniósł był Jechoniasza króla Judzkiego:
###### **Est 2,7**
 Który wychował córkę brata swego Edissę, którą drugiem imieniem zwano Esther: i obudwu rodziców straciła, była piękna barzo i wdzięcznej twarzy. A po śmierci ojca i matki jej, przywłaszczył ją sobie Mardocheusz za córkę.
###### **Est 2,8**
 A gdy się rozgłosiło królewskie rozkazanie, a według rozkazania jego wiele pięknych panien do Susan przywodzono, i Egejowi rzezańcowi oddawano: Esther też między innemi pannami oddano mu, aby była chowana w poczecie białychgłów:
###### **Est 2,9**
 Która się jemu spodobała, i nalazła łaskę w oczach jego. I rozkazał rzezańcowi, aby jej dano co rychlej ochędóstwo białogłowskie, i dał jej część jej, i siedm panienek co napiękniejszych z domu królewskiego, i tak onę jako i służebne panny jej, przybrał i ozdobił.
###### **Est 2,10**
 Która nie chciała mu oznajmić narodu i ojczyzny swojej: bo jej był kazał Mardocheusz, aby o tej rzeczy zgoła milczała:
###### **Est 2,11**
 Który przechadzał się co dzień przed sienią domu, w którym wybrane panny chowano, starając się o zdrowiu Esther, i chcąc wiedzieć coby się z nią działo.
###### **Est 2,12**
 A gdy przyszedł czas każdej porządkiem panienki, żeby wchodziły do króla, wszystko wykonawszy co do ochędóstwa białogłowskiego przynależało, miesiąc się dwunasty toczył, wszakże tak, że przez sześć miesięcy mazały się olejkiem z mirry, a przez drugie sześć barwiczek i rzeczy wonnych używały.
###### **Est 2,13**
 A wchodząc do króla, o cokolwiek prosiły do ochędóstwa należącego brały: i jako się im podobało ubrawszy się z domu fraucymeru przechodziły do łożnice królewskiej.
###### **Est 2,14**
 A która weszła wieczór, rano zaś wychodziła, i ztamtąd do wtórego domu odprowadzona była, który był pod ręką Susagazy rzezańca, który był nad nałożnicami królewskiemi przełożony: a nie miała wolności wrócić się więcej do króla. Ażby król chciał, a mianowicie jej przyść rozkazał.
###### **Est 2,15**
 A gdy przeminął czas porządkiem, przychodził dzień, którego Esther, córka Abihail brata Mardocheuszowego, którą był sobie wziął za córkę, miała wniść do króla: która nie szukała strojów białogłowskich, ale cokolwiek chciał Egeusz rzezaniec stróż panien, to jej dał na ochędóstwo: Bo była barzo piękna, a niewymowną cudownością oczam wszystkich zdała się wdzięczną i miłą.
###### **Est 2,16**
 Wwiedziona tedy jest do pokoju króla Asswerusa miesiąca dziesiątego, który zowią Tebeth, siódmego roku królestwa jego.
###### **Est 2,17**
 I umiłował ją król więcej, niż wszystkie niewiasty, a miała przed nim łaskę i miłosierdzie nad wszystkie białegłowy, i włożył na głowę jej koronę królestwa, i uczynił, że królowała na miejscu Vasthi.
###### **Est 2,18**
 I rozkazał nagotować ucztę barzo wielką, przez wszystkie książęta i służebniki swoje, na pojęcie i na wesele Esther. I dał odpoczynienie wszystkim ziemiam, i rozdawał dary według wielmożności książęcej:
###### **Est 2,19**
 A gdy powtóre szukano i zbierano panny, Mardocheusz siadał u drzwi królewskich:
###### **Est 2,20**
 A Esther jeszcze była nie oznajmiła ojczyzny i narodu swego, według rozkazania jego. Bo cokolwiek on rozkazał, strzegła Esther: i tak wszystko czyniła jako na on czas zwykła była, gdy ją malutką wychowywał.
###### **Est 2,21**
 Tego tedy czasu, gdy Mardocheusz siedział u drzwi królewskich, rozgniewali się Bagathan i Thares dwa rzezańcy królewscy, którzy byli odźwiernymi, a u pierwszego progu pałacu siadali: i chcieli się targnąć na króla i zabić go.
###### **Est 2,22**
 Co nie było tajno Mardocheuszowi, i wnet oznajmił królowej Esther: a ona królowi imieniem Mardocheusza, który do niej przez rzecz był doniósł.
###### **Est 2,23**
 Dowiadowano się, i naleziono, i obieszono obu na szubienicy. I podano to do historyj i w kroniki wpisano przed królem.
