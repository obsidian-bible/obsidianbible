# 1Tes 2 BT5
###### **1Tes 2,1**
 Sami bowiem wiecie, bracia, że nasze przyjście do was nie okazało się daremne.
###### **1Tes 2,2**
 Chociaż ucierpieliśmy i – jak wiecie – doznaliśmy zniewagi w Filippi, odważyliśmy się w Bogu naszym głosić wam Ewangelię Bożą pośród wielkiego utrapienia.
###### **1Tes 2,3**
 Upominanie zaś nasze nie pochodzi z błędu ani z nieczystej pobudki, ani z podstępu,
###### **1Tes 2,4**
 lecz jak przez Boga zostaliśmy uznani za godnych powierzenia nam Ewangelii, tak głosimy ją, aby się podobać nie ludziom, ale Bogu, który bada nasze serca.
###### **1Tes 2,5**
 Nigdy przecież nie posługiwaliśmy się pochlebstwem w mowie – jak wiecie – ani też nie kierowaliśmy się ukrytą chciwością, czego Bóg jest świadkiem,
###### **1Tes 2,6**
 i nie szukaliśmy ludzkiej chwały ani pośród was, ani pośród innych.
###### **1Tes 2,7**
 A jako apostołowie Chrystusa mogliśmy być dla was ciężarem, my jednak stanęliśmy pośród was pełni skromności, jak matka troskliwie opiekująca się swoimi dziećmi.
###### **1Tes 2,8**
 Będąc tak pełni życzliwości dla was, chcieliśmy wam dać nie tylko Bożą Ewangelię, lecz nadto dusze nasze, tak bowiem staliście się nam drodzy.
###### **1Tes 2,9**
 Pamiętacie przecież, bracia, naszą pracę i trud. Pracowaliśmy dniem i nocą, aby nikomu z was nie być ciężarem. Tak to wśród was głosiliśmy Ewangelię Bożą.
###### **1Tes 2,10**
 Sami jesteście świadkami, i Bóg także, jak bogobojnie, sprawiedliwie i nienagannie zachowaliśmy się pośród was, wierzących.
###### **1Tes 2,11**
 Przecież wiecie, żeśmy każdego z was – jak ojciec swe dzieci – prosili, zachęcali i zaklinali,
###### **1Tes 2,12**
 abyście postępowali w sposób godny Boga, który was wzywa do swego królestwa i chwały.
###### **1Tes 2,13**
 Dlatego nieustannie dziękujemy Bogu, bo gdy przejęliście słowo Boże, usłyszane od nas, przyjęliście je nie jako słowo ludzkie, ale jako to, czym jest naprawdę – jako słowo Boga, który działa w was, wierzących.
###### **1Tes 2,14**
 Bracia, wy się staliście naśladowcami Kościołów Boga, które są w Judei, w Chrystusie Jezusie, ponieważ to samo, co one od Żydów, wyście wycierpieli od rodaków.
###### **1Tes 2,15**
 Żydzi zabili Pana Jezusa i proroków, i nas także prześladowali. A nie podobają się oni Bogu i są wrodzy wszystkim ludziom.
###### **1Tes 2,16**
 Zabraniają nam przemawiać do pogan, aby ci zostali zbawieni; tak dopełniają ciągle miary swych grzechów. Ale przyszedł na nich na koniec gniew Boży.
###### **1Tes 2,17**
 My zaś, bracia, rozłączeni z wami na krótki czas, nie sercem, ale tylko niemożnością oglądania was, bardzo gorąco pragnęliśmy ujrzeć was osobiście.
###### **1Tes 2,18**
 Dlatego chcieliśmy przybyć do was, zwłaszcza ja, Paweł, jeden raz i drugi, lecz przeszkodził nam szatan.
###### **1Tes 2,19**
 Ale jakaż jest nasza nadzieja albo radość, albo wieniec chwały – czyż nie wy również – przed Panem naszym, Jezusem Chrystusem, w chwili Jego przyjścia?
###### **1Tes 2,20**
 Wy bowiem jesteście naszą chwałą i radością.
# 1Tes 2 PAU
###### **1Tes 2,1**
 Sami wiecie, bracia, że nie przyszliśmy do was na próżno.
###### **1Tes 2,2**
 Wiecie też, że przedtem, w Filippi spotkały nas cierpienia i zniewagi, ale w Bogu naszym zdobyliśmy się na odwagę głoszenia wam Ewangelii Bożej pośród wielkich zmagań.
###### **1Tes 2,3**
 Nasze głoszenie nie pochodzi przecież z błędu ani z nieczystych pobudek, ani z podstępu.
###### **1Tes 2,4**
 Skoro Bóg uznał nas za godnych powierzenia nam Ewangelii, to głosimy ją tak, aby podobać się nie ludziom, lecz Bogu, który przenika nasze serca.
###### **1Tes 2,5**
 Nigdy bowiem nie posługiwaliśmy się pochlebstwem, o czym wiecie, ani ukrytą chęcią zysku, czego Bóg jest świadkiem.
###### **1Tes 2,6**
 Nie szukaliśmy ludzkiego uznania ani u was, ani u innych.
###### **1Tes 2,7**
 Jako apostołowie Chrystusa mogliśmy być dla was ciężarem, ale my staliśmy się pośród was jak małe dzieci. I jak matka, która tuli swoje niemowlęta,
###### **1Tes 2,8**
 byliśmy tak pełni życzliwości dla was, że chcieliśmy dać wam nie tylko Ewangelię Bożą, ale nawet nasze życie - tak bardzo staliście się nam drodzy.
###### **1Tes 2,9**
 Przypomnijcie sobie, bracia, nasz trud i udręczenie. Dniem i nocą pracowaliśmy, gdy głosiliśmy wam Ewangelię Bożą, aby dla nikogo z was nie być ciężarem.
###### **1Tes 2,10**
 Wy sami jesteście świadkami, a także Bóg, jak w świętości, w prawości i bez zarzutu postępowaliśmy wśród was, wierzących.
###### **1Tes 2,11**
 Wiecie przecież, że jak ojciec swe dzieci, tak my każdego z was
###### **1Tes 2,12**
 upominaliśmy, zachęcaliśmy i zaklinaliśmy, abyście postępowali w sposób godny wobec Boga, który was powołał do chwały swego królestwa.
###### **1Tes 2,13**
 Dlatego nieustannie dziękujemy Bogu, ponieważ przyjęliście słowo Boże usłyszane od nas nie jako słowo ludzkie, ale - jak to jest naprawdę - jako słowo Boga. Ono działa w was, wierzących.
###### **1Tes 2,14**
 Bracia, staliście się naśladowcami Kościołów Bożych Judei w Chrystusie Jezusie. Cierpieliście bowiem to samo od rodaków, co one od Żydów,
###### **1Tes 2,15**
 którzy zabili Pana Jezusa i proroków, a nas prześladowali. Nie podobają się oni Bogu i występują przeciw wszystkim ludziom.
###### **1Tes 2,16**
 Przeszkadzają nam w nauczaniu pogan, ażeby ci nie byli zbawieni, i tak wciąż dopełniają miary swych grzechów. Na koniec jednak spadł na nich gniew Boży.
###### **1Tes 2,17**
 Bracia, będąc na pewien czas oddaleni od was ciałem, lecz nie sercem, pragnęliśmy bardzo gorąco spotkać was osobiście.
###### **1Tes 2,18**
 Dlatego chcieliśmy już kilka razy przybyć do was, zwłaszcza ja, Paweł, ale przeszkodził nam szatan.
###### **1Tes 2,19**
 Któż jest więc naszą nadzieją, radością i chlubą? Czy nie wy wobec naszego Pana Jezusa, gdy przyjdzie?
###### **1Tes 2,20**
 Wy właśnie jesteście naszą chlubą i radością!
# 1Tes 2 BP
###### **1Tes 2,1**
 Bo sami wiecie o tym, bracia, że nasze przybycie do was nie było bezowocne.
###### **1Tes 2,2**
 Po cierpieniach i zniewagach doznanych w Filippi - o czym wam wiadomo - zaufawszy Bogu odważyliśmy się głosić wam, pomimo trudności, ewangelię Bożą.
###### **1Tes 2,3**
 Nauczanie nasze nie opiera się na błędzie. Nie kieruje nim nieczysta pobudka ani podstęp,
###### **1Tes 2,4**
 lecz tak głosimy ewangelię, jak Bóg, który nas uznał godnymi tego, nam ją powierzył, nie aby przypodobać się ludziom, lecz Bogu badającemu nasze serca.
###### **1Tes 2,5**
 Nigdy przecież nie posługiwaliśmy się - jak wiecie - pochlebstwami ani nie kierowaliśmy się ukrytą chciwością. Bóg tego świadkiem.
###### **1Tes 2,6**
 Nie szukaliśmy też sławy u ludzi - ani u was, ani u innych; chociaż mogliśmy występować z całą powagą apostołów Chrystusa,
###### **1Tes 2,7**
 to jednak byliśmy dla was łagodni jak matka, która troskliwie opiekuje się swoimi dziećmi.
###### **1Tes 2,8**
 Kochając was tak bardzo, pragnęliśmy dać wam nie tylko ewangelię Bożą, lecz i nasze życie, ponieważ staliście się nam drodzy.
###### **1Tes 2,9**
 Pamiętacie przecież, bracia, nasz trud i mozoły, jak pracując we dnie i w nocy głosiliśmy wam ewangelię Bożą, żeby nikomu z was nie być ciężarem.
###### **1Tes 2,10**
 I Bóg, i wy jesteście świadkami, jak święcie, sprawiedliwie i nienagannie żyliśmy wśród was, którzyście uwierzyli.
###### **1Tes 2,11**
 Wiecie i to, że prosiliśmy, zachęcaliśmy i zaklinaliśmy was tak, jak ojciec swoje dzieci,
###### **1Tes 2,12**
 żebyście postępowali w sposób godny Boga, który was wzywa do swego królestwa i swojej chwały.
###### **1Tes 2,13**
 Dlatego też nieustannie dziękujemy Bogu, że usłyszawszy słowo Boże, przez nas głoszone, przyjęliście je nie jak słowo ludzkie, lecz - jak jest w rzeczywistości - jak słowo Boże. Ono też działa w was, którzyście uwierzyli.
###### **1Tes 2,14**
 Wy zaś, bracia, staliście się naśladowcami Kościołów w Bogu na terenie Judei, złączonych z Jezusem Chrystusem, ponieważ cierpieliście to samo ze strony współmieszkańców, co one ze strony Żydów,
###### **1Tes 2,15**
 którzy zabili Pana Jezusa i proroków, a nas prześladowali. Są oni i Bogu niemili, i wszystkim ludziom przeciwni.
###### **1Tes 2,16**
 Zabraniają nam głosić naukę o zbawieniu, w ten sposób nieustannie dopełniają miary swoich grzechów. Ale spadł na nich srogi gniew Boży.
###### **1Tes 2,17**
 Bracia, my zaś pozbawieni na krótko waszego widoku, lecz nie rozłączeni sercem, bardzo tęsknimy za waszą obecnością.
###### **1Tes 2,18**
 Dlatego pragnęliśmy przybyć do was, zwłaszcza ja, Paweł, i to dwukrotnie, lecz szatan nam w tym przeszkodził.
###### **1Tes 2,19**
 Któż bowiem, jeżeli nie wy, jest naszą nadzieją, radością i wieńcem chwały,
###### **1Tes 2,20**
 z którego dumni będziemy przed Panem naszym Jezusem w chwili Jego przyjścia?
# 1Tes 2 BR
###### **1Tes 2,1**
 Sami, bracia, wiecie dobrze, że nie na próżno przybyliśmy do was.
###### **1Tes 2,2**
 I choć - jak wam wiadomo - ucierpieliśmy wiele i doznaliśmy zniewag w Filippi, to jednak Bóg nasz dodał nam sił, by mimo wielkich trudności udać się z głoszeniem Ewangelii Bożej także i do was.
###### **1Tes 2,3**
 W rzeczywistości bowiem pouczenia nasze nie rodzą się z żadnych błędów ani z pobudek nieczystych, ani z podstępu.
###### **1Tes 2,4**
 To Bogu samemu podobało się powierzyć nam głoszenie Ewangelii, my zaś ze swej strony, głosząc Ewangelię, zabiegamy o to, by się przypodobać nie ludziom, lecz Bogu, który przenika nasze serca.
###### **1Tes 2,5**
 Nigdy przecież jak wiecie - nie schlebialiśmy nikomu naszym słowem ani nie kierowaliśmy się - czego sam Bóg jest świadkiem - ukrytą chęcią zdobycia jakiegoś zysku.
###### **1Tes 2,6**
 Nie szukaliśmy też własnej chwały ani u was, ani wśród innych ludzi.
###### **1Tes 2,7**
 Jako prawdziwi apostołowie mieliśmy prawo okazać wam całą naszą władzę, tymczasem występowaliśmy wśród was pełni skromności [i dobroci], jak matka zatroskana o swe dzieci.
###### **1Tes 2,8**
 Powodowani taką miłością byliśmy gotowi dać wam nie tylko naukę Bożą, lecz także nasze życie. Tak bowiem staliście się nam drogimi.
###### **1Tes 2,9**
 Bracia, pamiętacie zapewne nasze wśród was wysiłki, trudy... [Przypominacie sobie] jak ciężko pracowaliśmy dniem i nocą, byle tylko dla nikogo spośród was nie być ciężarem. To tak właśnie głosiliśmy wśród was Ewangelię Bożą.
###### **1Tes 2,10**
 Sami możecie zaświadczyć - zresztą i Bóg także - że nasze postępowanie, gdyśmy przebywali u was, ludzi wierzących, było zgodne z wolą Bożą, ze sprawiedliwością i dobrymi obyczajami.
###### **1Tes 2,11**
 Przypominacie sobie zapewne, jak tośmy was zachęcali i upominali z całą stanowczością, niczym ojciec własne dzieci,
###### **1Tes 2,12**
 abyście postępowali w sposób godny Boga, który was wzywa do swego królestwa i chwały.
###### **1Tes 2,13**
 Dziękujemy Bogu także i za to, że gdy przyjmowaliście głoszone przez nas słowo Boże, traktowaliście je nie jak słowo ludzkie lecz - i to jest jedynie słuszne - jak rzeczywiste słowo Boga, który dokonuje swego dzieła w was, wierzących.
###### **1Tes 2,14**
 Bracia, kroczycie tą samą drogą co Kościoły Boże zjednoczone z Chrystusem Jezusem w Judei, ponieważ to samo, co one od Żydów, wyście wycierpieli od waszych współrodaków.
###### **1Tes 2,15**
 Żydzi zabili Pana Jezusa, zabijali proroków, także nas prześladowali. W ten sposób czynią to, co nie jest miłe Bogu, a poza tym występują przeciwko wszystkim ludziom.
###### **1Tes 2,16**
 Usiłują także przeszkodzić nam w głoszeniu słowa, które [z woli Bożej] ma przynieść zbawienie poganom. W ten sposób dopełniają miary swoich grzechów [których dopuszczali się kiedykolwiek]. Ale już nadciąga na nich ostateczny gniew [Boży].
###### **1Tes 2,17**
 Tymczasem my, bracia, rozłączeni z wami na krótko - nie sercem, rzecz jasna, ale niemożnością oglądania was wprost - tak bardzo pragnęliśmy was zobaczyć!
###### **1Tes 2,18**
 Mieliśmy zamiar raz i drugi - zwłaszcza ja, Paweł - przybyć do was, ale przeszkodził nam szatan.
###### **1Tes 2,19**
 Bo któż może być naszą nadzieją, radością albo chlubą? Czyż nie wy będziecie dla nas tym wszystkim przed obliczem Pana naszego Jezusa w dzień Jego przyjścia?
###### **1Tes 2,20**
 Tak, to wy [już] jesteście dla nas źródłem i chwały, i radości.
# 1Tes 2 WUJ
###### **1Tes 2,1**
 Abowiem sami wiecie bracia, o naszem weszciu do was, iż nie próżne było:
###### **1Tes 2,2**
 Ale przedtem ucierpiawszy i zelżeni będąc (jako wiecie) w Philipiech, dufnośceśmy mieli mówić do was w Bogu naszym, Ewanielią Bożą z wielkiem staraniem.
###### **1Tes 2,3**
 Abowiem napominanie nasze nie z obłędliwości, ani z nieczystości, ani w zdradzie:
###### **1Tes 2,4**
 Ale jakośmy doświadczeni byli od Boga, żeby nam była zwierzona Ewanielia, tak mówiemy: nie jako się ludziom podobając, ale Bogu, który doświadcza serc naszych.
###### **1Tes 2,5**
 Abowiem nigdyśmy nie byli w mowie pochlebstwa, jako wiecie: ani w okazje łakomstwa, Bóg świadek jest:
###### **1Tes 2,6**
 Ani szukając chwały od ludzi, ani od was, ani od inszych.
###### **1Tes 2,7**
 Mogąc być wam obciążliwi jako Apostołowie Chrystusowi: ale staliśmy się malutkimi w pośrodku was, jako gdyby mamka ogrzewała syny swoje:
###### **1Tes 2,8**
 Tak was pragnąc, chcieliśmy chętliwie, dać wam nie tylko Ewanielią Bożą, ale też dusze nasze: żeście się nam stali namilszemi.
###### **1Tes 2,9**
 Abowiem pamiętacie bracia pracą naszę i trudzenie: w nocy i we dnie robiąc, abyśmy żadnego z was nie obciążyli, przepowiadaliśmy u was Ewanielią Bożą.
###### **1Tes 2,10**
 Wyście świadkami i Bóg, jako świętobliwie, i sprawiedliwie i bez skargi byliśmy wam, którzyście uwierzyli.
###### **1Tes 2,11**
 Jako wiecie jakośmy każdego z was (jako ociec syny swoje).
###### **1Tes 2,12**
 Prosząc was i ciesząc oświadczali, abyście chodzili godnie Bogu, który was wezwał do swego królestwa i chwały.
###### **1Tes 2,13**
 Dla tego i my dziękujemy Bogu bez przestanku, iż przyjąwszy od nas słowo słuchania Bożego, przyjęliście je nie jako słowo ludzkie, ale (jako jest prawdziwie) słowo Boga, który skutecznie sprawuje w was, którzyście uwierzyli.
###### **1Tes 2,14**
 Abowiem wy bracia staliście się naśladowcami kościołów Bożych, które są w Żydowskiej ziemi, w Chrystusie Jezusie: iżeście i wy toż cierpieli od spół pokoleników waszych, jako i oni od Żydów.
###### **1Tes 2,15**
 Którzy i Pana zabili Jezusa i proroki, i nas prześladowali, i Bogu się nie podobają, i wszystkim ludziom się sprzeciwiają.
###### **1Tes 2,16**
 Broniąc nam, żebyśmy nie mówili Poganom, iżby byli zbawieni: aby zawsze wypełniali grzechy swe: abowiem na nie przyszedł gniew Boży aż do końca.
###### **1Tes 2,17**
 A my bracia, będąc opuszczonymi od was na krótki czas twarzą nie sercem: bardzieśmy się kwapili widzieć oblicze wasze z wielką chucią.
###### **1Tes 2,18**
 Abowiemeśmy chcieli przyść do was (zwłaszcza ja Paweł) i raz i drugi: ale przekaził nam szatan.
###### **1Tes 2,19**
 Abowiem któraż jest nadzieja nasza, abo wesele, abo korona przechwalania? Izali nie wy przed Panem naszym Jezusem Chrystusem jesteście na przyście jego?
###### **1Tes 2,20**
 Abowiem wy jesteście chwała nasza i wesele.
# 1Tes 2 STERN
###### **1Tes 2,1**
 Sami wiecie, bracia, że nasz pobyt wśród was nie był bezowocny.
###### **1Tes 2,2**
 Przeciwnie, choć -jak wiecie - zdążyliśmy już ucierpieć i doznać zniewagi w Filippi, to zjednoczeni z naszym Bogiem śmiało oznajmialiśmy wam Dobrą Nowinę nawet w takiej udręce.
###### **1Tes 2,3**
 Bo nawoływanie nasze nie wypływa z błędu ani z nieczystych intencji, nie usiłujemy też nikogo mamić.
###### **1Tes 2,4**
 Ponieważ zaś Bóg wypróbował nas i uznał nas za godnych powierzenia nam Dobrej Nowiny, to tak przemawiamy - nie aby sobie zaskarbić życzliwość ludzi, lecz Boga, który bada nasze serca.
###### **1Tes 2,5**
 Bo jak wiecie, nigdy nie uciekaliśmy się do pochlebstw ani nie tworzyliśmy pozorów, chcąc ukryć chciwość - Bóg nam świadkiem.
###### **1Tes 2,6**
 Nie zabiegaliśmy też o pochwały ludzkie ani u was, ani u innych.
###### **1Tes 2,7**
 Jako wysłannicy Mesjasza, mogliśmy dać wam odczuć nasz ciężar, mimo to byliśmy wśród was łagodni, jak matka karmiąca i pielęgnująca swe dzieci.
###### **1Tes 2,8**
 Byliśmy wam tak oddani, że z radością dzieliliśmy się z wami nie tylko Bożą Dobrą Nowiną, ale i życiem naszym własnym, tak bardzo staliście się nam drodzy.
###### **1Tes 2,9**
 Bo pamiętacie, bracia, nasz trud i znój, jak nocą i dniem pracowaliśmy, aby głosząc wam Dobrą Nowinę, dla nikogo z was nie być ciężarem.
###### **1Tes 2,10**
 Jesteście świadkami, tak jak i Bóg, jak sprawiedliwie i nienagannie postępowaliśmy na oczach was, wierzących,
###### **1Tes 2,11**
 bo wiecie, że każdego z was traktowaliśmy tak, jak ojciec traktuje swe dzieci - pokrzepialiśmy was i pocieszali,
###### **1Tes 2,12**
 i zaklinaliśmy was, abyście wiedli życie godne Boga, który wezwał was do swego Królestwa i chwały.
###### **1Tes 2,13**
 Regularnie dziękujemy Bogu również i dlatego, że usłyszawszy od nas Słowo Boże, przyjęliście je nie jako zwykłe słowo ludzkie, ale jako to, czym naprawdę jest - Słowo Boga, które działa w was, wierzących.
###### **1Tes 2,14**
 Gdyż, bracia, staliście się naśladowcami zgromadzeń Bożych w J'hudzie, zjednoczonych z Mesjaszem Jeszuą - cierpieliście od swoich ziomków to samo, co oni od tych Judejczyków, którzy
###### **1Tes 2,15**
 nie tylko zabili Pana Jeszuę i proroków, ale i nas prześladowali. Bogu się nie podobają i przeciwko całej ludzkości występują,
###### **1Tes 2,16**
 usiłując przeszkodzić nam w zwracaniu się do nie-Żydów, aby mogli oni zostać wyzwoleni. Widać za zadanie stawiają sobie zawsze celowanie w grzechach! Lecz Boży gniew w końcu ich dosięgnie.
###### **1Tes 2,17**
 Co zaś do nas, bracia, kiedy przez krótki czas byliśmy z dala od was - fizycznie, ale nie myślami - tęskniliśmy za wami i usilnie staraliśmy się przybyć i ujrzeć was.
###### **1Tes 2,18**
 Tak bardzo chcieliśmy przybyć do was - ja, Sza'ul, starałem się niejeden raz - ale Przeciwnik nas zatrzymał.
###### **1Tes 2,19**
 Bo co będzie naszą nadzieją, naszą radością, koroną, którą będziemy się chlubić, gdy nasz Pan Jeszua powróci? Czyż nie wy?
###### **1Tes 2,20**
 Tak, jesteście naszą chwałą i naszą radością!
# 1Tes 2 TRO
###### **1Tes 2,1**
 **αυτοι** *autoi* Sami [[G846]] WTP-NPM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **οιδατε** *oidate* wiecie [[G1492]] WTV-RAI-2P **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **την** *tēn* (o) [[G3588]] WTT-ASF **εισοδον** *eisodon* wejściu [[G1529]] WTN-ASF **ημων** *hēmōn* naszym [[G2257]] WTP-1GP **την** *tēn* [[G3588]] WTT-ASF **προς** *pros* do [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **οτι** *hoti* że [[G3754]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **κενη** *kenē* próżne – puste [[G2756]] WTA-NSF **γεγονεν** *gegonen* stało się [[G1096]] WTV-2RAI-3S
###### **1Tes 2,2**
 **αλλα** *alla* ale [[G235]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **προπαθοντες** *propathontes* wcześniej doznawszy cierpienia [[G4310]] WTV-2AAP-NPM **και** *kai* i [[G2532]] [[CONJ]] **υβρισθεντες** *hybristhentes* doznawszy zniewagi – doznawszy obrazy [[G5195]] WTV-APP-NPM **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **οιδατε** *oidate* wiecie [[G1492]] WTV-RAI-2P **εν** *en* w [[G1722]] [[PREP]] **φιλιπποις** *filippois* Filippi – [miłujący konie] [[G5375]] WTN-DPM **επαρρησιασαμεθα** *eparrēsiasametha* okazaliśmy otwartość [[G3955]] WTV-ADI-1P **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **ημων** *hēmōn* naszym [[G2257]] WTP-1GP **λαλησαι** *lalēsai* powiedzieć [[G2980]] [[V-AAN]] **προς** *pros* do [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **το** *to* [[G3588]] WTT-ASN **ευαγγελιον** *euangelion* dobrą nowinę [[G2098]] WTN-ASN **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εν** *en* w [[G1722]] [[PREP]] **πολλω** *pollō* wielkim [[G4183]] WTA-DSM **αγωνι** *agōni* boju – walce [[G73]] WTN-DSM
###### **1Tes 2,3**
 **η** *hē* [[G3588]] [[T-NSF]] **γαρ** *gar* Bowiem [[G1063]] [[CONJ]] **παρακλησις** *paraklēsis* wezwanie – zachęta [[G3874]] [[N-NSF]] **ημων** *hēmōn* nasze [[G2257]] WTP-1GP **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εκ** *ek* z [[G1537]] [[PREP]] **πλανης** *planēs* błędu – łudzenia [[G4106]] [[N-GSF]] **ουδε** *oude* ani [[G3761]] [[ADV]] **εξ** *eks* z [[G1537]] [[PREP]] **ακαθαρσιας** *akatharsias* nieczystości [[G167]] [[N-GSF]] **ουτε** *oute* ani [[G3777]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **δολω** *dolō* podstępie – oszustwie [[G1388]] WTN-DSM
###### **1Tes 2,4**
 **αλλα** *alla* ale [[G235]] [[CONJ]] **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **δεδοκιμασμεθα** *dedokimasmetha* jesteśmy wypróbowani – jesteśmy doświadczeni [[G1381]] WTV-RPI-1P **υπο** *hypo* przez [[G5259]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **πιστευθηναι** *pisteuthēnai* (by) mieć powierzoną – (by) mieć zawierzoną [[G4100]] WTV-APN **το** *to* [[G3588]] WTT-ASN **ευαγγελιον** *euangelion* dobrą nowinę [[G2098]] WTN-ASN **ουτως** *houtōs* tak [[G3779]] [[ADV]] **λαλουμεν** *laloumen* mówimy [[G2980]] WTV-PAI-1P **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **ως** *hōs* jak [[G5613]] [[ADV]] **ανθρωποις** *anthrōpois* ludziom [[G444]] WTN-DPM **αρεσκοντες** *areskontes* starający się przypodobać [[G700]] WTV-PAP-NPM **αλλα** *alla* ale [[G235]] [[CONJ]] **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **τω** *tō* [[G3588]] WTT-DSM **δοκιμαζοντι** *dokimazonti* badającemu – poddającemu próbie [[G1381]] WTV-PAP-DSM **τας** *tas* [[G3588]] WTT-APF **καρδιας** *kardias* serca [[G2588]] WTN-APF **ημων** *hēmōn* nasze [[G2257]] WTP-1GP
###### **1Tes 2,5**
 **ουτε** *oute* Ani [[G3777]] [[CONJ]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ποτε** *pote* wcześniej [[G4218]] WTPRT **εν** *en* w [[G1722]] [[PREP]] **λογω** *logō* słowie [[G3056]] WTN-DSM **κολακειας** *kolakeias* schlebiania [[G2850]] [[N-GSF]] **εγενηθημεν** *egenēthēmen* staliśmy się [[G1096]] WTV-AOI-1P **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **οιδατε** *oidate* wiecie [[G1492]] WTV-RAI-2P **ουτε** *oute* ani [[G3777]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **προφασει** *profasei* pozorze – pretekście [[G4392]] [[N-DSF]] **πλεονεξιας** *pleoneksias* chciwości – zachłanności [[G4124]] [[N-GSF]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **μαρτυς** *martys* świadek [[G3144]] [[N-NSM]]
###### **1Tes 2,6**
 **ουτε** *oute* ani [[G3777]] [[CONJ]] **ζητουντες** *zētountes* szukając [[G2212]] WTV-PAP-NPM **εξ** *eks* od [[G1537]] [[PREP]] **ανθρωπων** *anthrōpōn* ludzi [[G444]] WTN-GPM **δοξαν** *doksan* chwały [[G1391]] WTN-ASF **ουτε** *oute* ani [[G3777]] [[CONJ]] **αφ** *af* od [[G575]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **ουτε** *oute* ani [[G3777]] [[CONJ]] **απ** *ap* od [[G575]] [[PREP]] **αλλων** *allōn* innych [[G243]] WTA-GPM **δυναμενοι** *dynamenoi* mogąc [[G1410]] WTV-PNP-NPM **εν** *en* w [[G1722]] [[PREP]] **βαρει** *barei* ciężarze [[G922]] WTN-DSN **ειναι** *einai* być [[G1511]] WTV-PXN **ως** *hōs* jak [[G5613]] [[ADV]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **αποστολοι** *apostoloi* wysłannicy [[G652]] WTN-NPM
###### **1Tes 2,7**
 **αλλ** *all* ale [[G235]] [[CONJ]] **εγενηθημεν** *egenēthēmen* staliśmy się [[G1096]] WTV-AOI-1P **ηπιοι** *ēpioi* łagodni – spokojni [[G2261]] WTA-NPM **εν** *en* w [[G1722]] [[PREP]] **μεσω** *mesō* pośród [[G3319]] WTA-DSN **υμων** *hymōn* was [[G5216]] WTP-2GP **ως** *hōs* jak- [[G5613]] [[ADV]] **αν** *an* kolwiek [[G302]] WTPRT **τροφος** *trofos* żywicielka – karmicielka [[G5162]] [[N-NSF]] **θαλπη** *thalpē* otaczałaby troską – pielęgnowałaby [[G2282]] WTV-PAS-3S **τα** *ta* [[G3588]] WTT-APN **εαυτης** *heautēs* swoje [[G1438]] WTF-3GSF **τεκνα** *tekna* dzieci [[G5043]] WTN-APN
###### **1Tes 2,8**
 **ουτως** *houtōs* tak [[G3779]] [[ADV]] **ιμειρομενοι** *imeiromenoi* będąc przywiązanymi – będąc tkliwymi [[G2442]] WTV-PMP-NPM **υμων** *hymōn* (wobec) was [[G5216]] WTP-2GP **ευδοκουμεν** *eudokoumen* mamy upodobania [[G2106]] WTV-IAI-1P **μεταδουναι** *metadounai* (by) przekazać [[G3330]] [[V-2AAN]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **ου** *ou* nie [[G3756]] [[PRT-N]] **μονον** *monon* jedynie – tylko [[G3440]] [[ADV]] **το** *to* [[G3588]] WTT-ASN **ευαγγελιον** *euangelion* dobrą nowinę [[G2098]] WTN-ASN **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **αλλα** *alla* ale [[G235]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **τας** *tas* [[G3588]] WTT-APF **εαυτων** *heautōn* swoje [[G1438]] WTF-3GPM **ψυχας** *psychas* dusze [[G5590]] WTN-APF **διοτι** *dioti* dlatego, że [[G1360]] [[CONJ]] **αγαπητοι** *agapētoi* umiłowani [[G27]] WTA-NPM **ημιν** *hēmin* nam [[G2254]] WTP-1DP **γεγενησθε** *gegenēsthe* jesteście postawieni [[G1096]] WTV-RPI-2P
###### **1Tes 2,9**
 **μνημονευετε** *mnēmoneuete* Pamiętacie – Przypominacie sobie [[G3421]] WTV-PAI-2P **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **τον** *ton* (o) [[G3588]] [[T-ASM]] **κοπον** *kopon* trudzie [[G2873]] [[N-ASM]] **ημων** *hēmōn* naszym [[G2257]] WTP-1GP **και** *kai* i [[G2532]] [[CONJ]] **τον** *ton* [[G3588]] [[T-ASM]] **μοχθον** *mochthon* mozole – znoju [[G3449]] [[N-ASM]] **νυκτος** *nyktos* nocą [[G3571]] [[N-GSF]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **ημερας** *hēmeras* dniem [[G2250]] [[N-GSF]] **εργαζομενοι** *ergazomenoi* pracując [[G2038]] WTV-PNP-NPM **προς** *pros* ku [[G4314]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **μη** *mē* nie [[G3361]] [[PRT-N]] **επιβαρησαι** *epibarēsai* obciążyć [[G1912]] [[V-AAN]] **τινα** *tina* kogoś [[G5100]] WTX-ASM **υμων** *hymōn* (z) was [[G5216]] WTP-2GP **εκηρυξαμεν** *ekēryksamen* ogłosiliśmy [[G2784]] WTV-AAI-1P **εις** *eis* przed [[G1519]] [[PREP]] **υμας** *hymas* wami [[G5209]] WTP-2AP **το** *to* [[G3588]] WTT-ASN **ευαγγελιον** *euangelion* dobrą nowinę [[G2098]] WTN-ASN **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **1Tes 2,10**
 **υμεις** *hymeis* Wy [[G5210]] WTP-2NP **μαρτυρες** *martyres* świadkowie [[G3144]] WTN-NPM **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ως** *hōs* jak [[G5613]] [[ADV]] **οσιως** *hosiōs* święcie – pobożnie [[G3743]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **δικαιως** *dikaiōs* sprawiedliwie [[G1346]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **αμεμπτως** *amemptōs* nienagannie [[G274]] [[ADV]] **υμιν** *hymin* (dla) was [[G5213]] WTP-2DP **τοις** *tois* [[G3588]] WTT-DPM **πιστευουσιν** *pisteuousin* wierzących [[G4100]] WTV-PAP-DPM **εγενηθημεν** *egenēthēmen* staliśmy się [[G1096]] WTV-AOI-1P
###### **1Tes 2,11**
 **καθαπερ** *kathaper* tak, jak [[G2509]] [[ADV]] **οιδατε** *oidate* wiecie [[G1492]] WTV-RAI-2P **ως** *hōs* jak [[G5613]] [[ADV]] **ενα** *hena* jednego [[G1520]] WTA-ASM **εκαστον** *hekaston* każdego [[G1538]] WTA-ASM **υμων** *hymōn* (z) was [[G5216]] WTP-2GP **ως** *hōs* jak [[G5613]] [[ADV]] **πατηρ** *patēr* ojciec [[G3962]] [[N-NSM]] **τεκνα** *tekna* dzieci [[G5043]] WTN-APN **εαυτου** *heautou* swoje [[G1438]] WTF-3GSM **παρακαλουντες** *parakalountes* zachęcając [[G3870]] WTV-PAP-NPM **υμας** *hymas* was [[G5209]] WTP-2AP **και** *kai* i [[G2532]] [[CONJ]] **παραμυθουμενοι** *paramythoumenoi* pocieszając [[G3888]] WTV-PNP-NPM
###### **1Tes 2,12**
 **και** *kai* i [[G2532]] [[CONJ]] **μαρτυρουμενοι** *martyroumenoi* świadcząc [[G3140]] WTV-PMP-NPM **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **περιπατησαι** *peripatēsai* postępować – chodzić [[G4043]] [[V-AAN]] **υμας** *hymas* wam [[G5209]] WTP-2AP **αξιως** *aksiōs* godnie [[G516]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **του** *tou* [[G3588]] WTT-GSM **καλουντος** *kalountos* wzywającego [[G2564]] WTV-PAP-GSM **υμας** *hymas* was [[G5209]] WTP-2AP **εις** *eis* do [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **εαυτου** *heautou* swojego [[G1438]] WTF-3GSM **βασιλειαν** *basileian* Królestwa [[G932]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **δοξαν** *doksan* chwały [[G1391]] WTN-ASF
###### **1Tes 2,13**
 **δια** *dia* Dla- [[G1223]] [[PREP]] **τουτο** *touto* tego [[G5124]] WTD-ASN **και** *kai* i [[G2532]] [[CONJ]] **ημεις** *hēmeis* my [[G2249]] WTP-1NP **ευχαριστουμεν** *eucharistoumen* dziękujemy [[G2168]] WTV-PAI-1P **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **αδιαλειπτως** *adialeiptōs* nieustannie [[G89]] [[ADV]] **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **παραλαβοντες** *paralabontes* przyjąwszy [[G3880]] WTV-2AAP-NPM **λογον** *logon* Słowo [[G3056]] [[N-ASM]] **ακοης** *akoēs* wieści – posłuchu [[G189]] [[N-GSF]] **παρ** *par* od [[G3844]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP **του** *tou* (o) [[G3588]] WTT-GSM **θεου** *theou* Bogu [[G2316]] [[N-GSM]] **εδεξασθε** *edeksasthe* przyjęliście [[G1209]] WTV-ADI-2P **ου** *ou* nie [[G3756]] [[PRT-N]] **λογον** *logon* Słowo [[G3056]] [[N-ASM]] **ανθρωπων** *anthrōpōn* ludzkie [[G444]] WTN-GPM **αλλα** *alla* ale [[G235]] [[CONJ]] **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **αληθως** *alēthōs* prawdziwie [[G230]] [[ADV]] **λογον** *logon* Słowo [[G3056]] [[N-ASM]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ος** *hos* które [[G3739]] WTR-NSM **και** *kai* i [[G2532]] [[CONJ]] **ενεργειται** *energeitai* działa [[G1754]] WTV-PMI-3S **εν** *en* w [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **τοις** *tois* [[G3588]] WTT-DPM **πιστευουσιν** *pisteuousin* wierzących – którzy wierzycie [[G4100]] WTV-PAP-DPM
###### **1Tes 2,14**
 **υμεις** *hymeis* Wy [[G5210]] WTP-2NP **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **μιμηται** *mimētai* naśladowcy [[G3402]] WTN-NPM **εγενηθητε** *egenēthēte* staliście się [[G1096]] WTV-AOI-2P **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **των** *tōn* [[G3588]] WTT-GPF **εκκλησιων** *ekklēsiōn* zgromadzeń – (społeczności) wywołanych [[G1577]] WTN-GPF **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **των** *tōn* [[G3588]] WTT-GPF **ουσων** *ousōn* będących [[G5607]] WTV-PXP-GPF **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **ιουδαια** *ioudaia* Judei – [[wielbić] ziemię] [[G2449]] [[N-DSF]] **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **ταυτα** *tauta* tak samo [[G5024]] WTN-APN-C **επαθετε** *epathete* wycierpieliście [[G3958]] WTV-2AAI-2P **και** *kai* i [[G2532]] [[CONJ]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **υπο** *hypo* od [[G5259]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **ιδιων** *idiōn* własnych [[G2398]] WTA-GPM **συμφυλετων** *symfyletōn* rodaków – współziomków [[G4853]] WTN-GPM **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **αυτοι** *autoi* oni [[G846]] WTP-NPM **υπο** *hypo* od [[G5259]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **ιουδαιων** *ioudaiōn* Judejczyków – [wielbić] [[G2453]] WTA-GPM
###### **1Tes 2,15**
 **των** *tōn* (tych) [[G3588]] WTT-GPM **και** *kai* i [[G2532]] [[CONJ]] **τον** *ton* [[G3588]] [[T-ASM]] **κυριον** *kyrion* Pana [[G2962]] [[N-ASM]] **αποκτειναντων** *apokteinantōn* którzy zabili [[G615]] WTV-AAP-GPM **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **τους** *tous* [[G3588]] WTT-APM **ιδιους** *idious* własnych [[G2398]] WTA-APM **προφητας** *profētas* proroków [[G4396]] [[N-APM]] **και** *kai* i [[G2532]] [[CONJ]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **εκδιωξαντων** *ekdiōksantōn* prześladując [[G1559]] WTV-AAP-GPM **και** *kai* i [[G2532]] [[CONJ]] **θεω** *theō* Bogu [[G2316]] WTN-DSM **μη** *mē* nie [[G3361]] [[PRT-N]] **αρεσκοντων** *areskontōn* którzy się podobają [[G700]] WTV-PAP-GPM **και** *kai* i [[G2532]] [[CONJ]] **πασιν** *pasin* wszystkim [[G3956]] WTA-DPM **ανθρωποις** *anthrōpois* ludziom [[G444]] WTN-DPM **εναντιων** *enantiōn* przeciwni [[G1727]] WTA-GPM
###### **1Tes 2,16**
 **κωλυοντων** *kōlyontōn* przeszkadzając – zabraniając [[G2967]] WTV-PAP-GPM **ημας** *hēmas* nam [[G2248]] WTP-1AP **τοις** *tois* [[G3588]] WTT-DPN **εθνεσιν** *ethnesin* poganom – narodom [[G1484]] WTN-DPN **λαλησαι** *lalēsai* powiedzieć [[G2980]] [[V-AAN]] **ινα** *hina* aby [[G2443]] [[CONJ]] **σωθωσιν** *sōthōsin* zostaliby zbawieni – zostaliby uratowani [[G4982]] WTV-APS-3P **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **αναπληρωσαι** *anaplērōsai* wypełnić się – dopełnić się [[G378]] [[V-AAN]] **αυτων** *autōn* ich [[G846]] WTP-GPM **τας** *tas* [[G3588]] WTT-APF **αμαρτιας** *hamartias* grzechy [[G266]] WTN-APF **παντοτε** *pantote* każdej chwili [[G3842]] [[ADV]] **εφθασεν** *efthasen* nadszedł – pospieszył się [[G5348]] [[V-AAI-3S]] **δε** *de* zaś [[G1161]] [[CONJ]] **επ** *ep* na [[G1909]] [[PREP]] **αυτους** *autous* nich [[G846]] [[P-APM]] **η** *hē* [[G3588]] [[T-NSF]] **οργη** *orgē* gniew [[G3709]] [[N-NSF]] **εις** *eis* ku [[G1519]] [[PREP]] **τελος** *telos* końcowi [[G5056]] WTN-ASN
###### **1Tes 2,17**
 **ημεις** *hēmeis* My [[G2249]] WTP-1NP **δε** *de* zaś [[G1161]] [[CONJ]] **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **απορφανισθεντες** *aporfanisthentes* zostawszy odłączonymi – zostawszy osieroconymi [[G642]] WTV-APP-NPM **αφ** *af* od [[G575]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **προς** *pros* na [[G4314]] [[PREP]] **καιρον** *kairon* czas [[G2540]] [[N-ASM]] **ωρας** *hōras* godziny [[G5610]] [[N-GSF]] **προσωπω** *prosōpō* obliczem – twarzą [[G4383]] WTN-DSN **ου** *ou* nie [[G3756]] [[PRT-N]] **καρδια** *kardia* sercem [[G2588]] [[N-DSF]] **περισσοτερως** *perissoterōs* tym bardziej – obficiej [[G4056]] [[ADV]] **εσπουδασαμεν** *espoudasamen* postaraliśmy się – wykazaliśmy gorliwość [[G4704]] WTV-AAI-1P **το** *to* [[G3588]] WTT-ASN **προσωπον** *prosōpon* oblicze [[G4383]] WTN-ASN **υμων** *hymōn* wasze [[G5216]] WTP-2GP **ιδειν** *idein* zobaczyć [[G1492]] [[V-2AAN]] **εν** *en* w [[G1722]] [[PREP]] **πολλη** *pollē* wielkim [[G4183]] WTA-DSF **επιθυμια** *epithymia* pragnieniu – pożądaniu [[G1939]] [[N-DSF]]
###### **1Tes 2,18**
 **διο** *dio* Dlatego [[G1352]] [[CONJ]] **ηθελησαμεν** *ēthelēsamen* chcieliśmy [[G2309]] WTV-AAI-1P **ελθειν** *elthein* przyjść [[G2064]] [[V-2AAN]] **προς** *pros* do [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **εγω** *egō* ja [[G1473]] WTP-1NS **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **παυλος** *paulos* Paweł – [mały] [[G3972]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **απαξ** *hapaks* raz [[G530]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **δις** *dis* drugi [[G1364]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **ενεκοψεν** *enekopsen* przeszkodził [[G1465]] [[V-AAI-3S]] **ημας** *hēmas* nam [[G2248]] WTP-1AP **ο** *ho* [[G3588]] [[T-NSM]] **σατανας** *satanas* szatan – [przeciwnik] [[G4567]] [[N-NSM]]
###### **1Tes 2,19**
 **τις** *tis* Kto [[G5101]] WTI-NSF **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ημων** *hēmōn* nasza [[G2257]] WTP-1GP **ελπις** *elpis* nadzieja [[G1680]] [[N-NSF]] **η** *ē* czy [[G2228]] WTPRT **χαρα** *chara* radość [[G5479]] [[N-NSF]] **η** *ē* czy [[G2228]] WTPRT **στεφανος** *stefanos* wieniec – korona [[G4735]] [[N-NSM]] **καυχησεως** *kauchēseōs* chluby – chełpienia się [[G2746]] [[N-GSF]] **η** *ē* czy [[G2228]] WTPRT **ουχι** *ouchi* nie [[G3780]] WTPRT-I **και** *kai* i [[G2532]] [[CONJ]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **εμπροσθεν** *emprosthen* przed [[G1715]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Panem [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszym [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusem – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańcem [[G5547]] [[N-GSM]] **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **αυτου** *autou* Jego [[G846]] [[P-GSM]] **παρουσια** *parousia* przyjściu [[G3952]] [[N-DSF]]
###### **1Tes 2,20**
 **υμεις** *hymeis* Wy [[G5210]] WTP-2NP **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **η** *hē* [[G3588]] [[T-NSF]] **δοξα** *doksa* chwała [[G1391]] [[N-NSF]] **ημων** *hēmōn* nasza [[G2257]] WTP-1GP **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **χαρα** *chara* radość [[G5479]] [[N-NSF]]
