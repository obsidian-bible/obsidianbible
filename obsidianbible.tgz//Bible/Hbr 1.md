# Hbr 1 BT5
###### **Hbr 1,1**
 Wielokrotnie i na różne sposoby przemawiał niegdyś Bóg do ojców [naszych] przez proroków,
###### **Hbr 1,2**
 a w tych ostatecznych dniach przemówił do nas przez Syna. Jego to ustanowił dziedzicem wszystkich rzeczy, przez Niego też stworzył wszechświat.
###### **Hbr 1,3**
 Ten [Syn], który jest odblaskiem Jego chwały i odbiciem Jego istoty, podtrzymuje wszystko słowem swej potęgi, a dokonawszy oczyszczenia z grzechów, zasiadł po prawicy Majestatu na wysokościach.
###### **Hbr 1,4**
 On o tyle stał się większy od aniołów, o ile odziedziczył dostojniejsze od nich imię.
###### **Hbr 1,5**
 Do którego bowiem z aniołów powiedział [Bóg] kiedykolwiek:Ty jesteś moim Synem, Ja Cię dziś zrodziłem?I znowu:Ja będę Mu Ojcem, a On będzie Mi Synem?
###### **Hbr 1,6**
 A skoro ponownie wprowadzi Pierworodnego na świat, powie: Niech Mu oddają pokłon wszyscy aniołowie Boży.
###### **Hbr 1,7**
 Do aniołów zaś mówi: Aniołów swych czyni wichrami, sługi swe płomieniami ognia.
###### **Hbr 1,8**
 Do Syna zaś: Tron Twój, Boże, na wieki wieków, berło sprawiedliwości berłem królestwa Twego.
###### **Hbr 1,9**
 Umiłowałeś sprawiedliwość, a znienawidziłeś nieprawość, dlatego namaścił Cię, Boże, Bóg Twój olejkiem radości bardziej niż równych Ci losem.
###### **Hbr 1,10**
 Oraz: Ty, Panie, na początku osadziłeś ziemię, dziełem też rąk Twoich są niebiosa.
###### **Hbr 1,11**
 One przeminą, ale Ty zostaniesz, i wszystko jak szata się zestarzeje,
###### **Hbr 1,12**
 i jak płaszcz je zwiniesz, jak odzienie, i odmienią się. Ty zaś jesteś Ten sam, a Twoje lata się nie skończą.
###### **Hbr 1,13**
 Do którego z aniołów kiedykolwiek powiedział: Siądź po mojej prawicy, aż twych wrogów położę jako podnóżek pod Twoje stopy?
###### **Hbr 1,14**
 Czyż nie są oni wszyscy duchami służebnymi, posyłanymi na pomoc tym, którzy mają odziedziczyć zbawienie?
# Hbr 1 PAU
###### **Hbr 1,1**
 Bóg wielokrotnie i na wiele sposobów przemawiał dawniej do przodków przez proroków.
###### **Hbr 1,2**
 W tych dniach ostatnich przemówił do nas przez Syna. Jego to ustanowił dziedzicem wszystkich rzeczy i przez Niego stworzył czasy.
###### **Hbr 1,3**
 On, będąc odblaskiem chwały Boga i odbiciem Jego istoty, podtrzymuje wszystko mocą swego słowa. On, gdy dokonał oczyszczenia z grzechów, zasiadł po prawej stronie Majestatu na wysokościach.
###### **Hbr 1,4**
 O tyle wyższym stał się od aniołów, o ile wspanialsze od nich odziedziczył imię.
###### **Hbr 1,5**
 Któremu bowiem z aniołów Bóg powiedział kiedykolwiek: Ty jesteś moim Synem, Ja Ciebie dziś zrodziłem? Albo: Ja będę Mu Ojcem, a On będzie Mi Synem?
###### **Hbr 1,6**
 Natomiast wprowadzając Pierworodnego na świat, mówi: Niech Mu się kłaniają wszyscy aniołowie Boży!
###### **Hbr 1,7**
 O aniołach wprawdzie mówi: Aniołów swych czyni wichrami, a sługi swoje - płomieniami ognia.
###### **Hbr 1,8**
 O Synu jednak: Tron Twój, Boże, na wieczne czasy, berłem sprawiedliwości berło Twego królowania.
###### **Hbr 1,9**
 Miłujesz sprawiedliwość, nienawidzisz nieprawości, dlatego Twój Bóg, o Boże, namaścił Cię olejkiem wesela bardziej niż Twych towarzyszy!
###### **Hbr 1,10**
 Oraz: Panie, Ty na początku umocniłeś ziemię, a niebo jest dziełem rąk Twoich.
###### **Hbr 1,11**
 Ono przeminie, ale Ty zostaniesz. Wszystkie rzeczy zestarzeją się jak szata,
###### **Hbr 1,12**
 jak okrycie, jakby szatę je zwiniesz - i odmienią się. Lecz Ty jesteś taki sam zawsze, a Twoje lata się nie kończą.
###### **Hbr 1,13**
 O którym wreszcie z aniołów powiedział kiedykolwiek: Usiądź po mojej prawej stronie, aż położę twych wrogów jako podnóżek pod twoje stopy?
###### **Hbr 1,14**
 Czyż nie są oni wszyscy duchami posługującymi, posłanymi do pomocy tym, którzy mają odziedziczyć zbawienie?
# Hbr 1 BP
###### **Hbr 1,1**
 Bóg, który niegdyś przemawiał do ojców wielokrotnie i w różny sposób przez proroków,
###### **Hbr 1,2**
 w tych czasach ostatecznych przemówił do nas przez Syna. Jego ustanowił spadkobiercą wszystkich dóbr, przez Niego też uczynił wszystko, co jest stworzone.
###### **Hbr 1,3**
 On, jako odbicie ukazujące Jego chwałę i jako obraz Jego istoty, podtrzymuje wszystko swoim potężnym słowem. On dokonał oczyszczenia z grzechów i zasiadł w niebie po prawicy (Bożego) Majestatu.
###### **Hbr 1,4**
 Stał się tym wyższy od aniołów, że odziedziczył imię wybitniejsze niż oni.
###### **Hbr 1,5**
 Któremu to z aniołów kiedykolwiek rzekł [Bóg]: "Synem moim jesteś, jam cię dziś zrodził"? I znowu: "Ja będę dla niego ojcem, a on będzie dla mnie synem"?
###### **Hbr 1,6**
 Kiedy zaś powtórnie wprowadza pierworodnego na świat, powiada: "Niech padną przed Nim na twarz wszyscy aniołowie Boży".
###### **Hbr 1,7**
 O aniołach wprawdzie powiada: "On czyni aniołów swymi wichrami, a sługi swoje płomieniami ognistymi".
###### **Hbr 1,8**
 O synu jednak: "Tron Twój, o Boże, na wieki wieków, a berłem sprawiedliwym jest berło Twego panowania.
###### **Hbr 1,9**
 Umiłowałeś sprawiedliwość a znienawidziłeś bezprawie, dlatego namaścił Ciebie, Boże, Twój Bóg olejem wesela, a nie żadnego z Twych towarzyszy".
###### **Hbr 1,10**
 Ponadto: "Ty, Panie, na początku umocniłeś ziemię i dziełem Twoich rąk są niebiosa,
###### **Hbr 1,11**
 one przeminą, ale Ty przetrwasz, wszystkie zestarzeją się jak szata,
###### **Hbr 1,12**
 jak wierzchnie okrycie je zwiniesz jak płaszcz - zostaną zmienione. Ty sam natomiast trwasz i Twoje lata nie ustaną".
###### **Hbr 1,13**
 O kim z aniołów kiedykolwiek powiedział: "Siądź po mojej prawicy, aż położę twych nieprzyjaciół jak podnóżek pod twoje stopy"?
###### **Hbr 1,14**
 Czyż oni wszyscy nie są duchami służebnymi, przeznaczonymi do posługi tym, którzy mają uczestniczyć w zbawieniu?
# Hbr 1 BR
###### **Hbr 1,1**
 Wiele razy i na różne sposoby przemawiał Bóg kiedyś przez proroków do naszych ojców,
###### **Hbr 1,2**
 teraz zaś w dniach, które uchodzą za ostatnie, przemówił do nas przez Syna. To właśnie Jego ustanowił dziedzicem wszystkich rzeczy i przez Niego stworzył wszechświat.
###### **Hbr 1,3**
 Jest On odblaskiem chwały Boga samego i najdoskonalszym wyrazem tego, czym jest sam Bóg. On to jedynie potęgą swego słowa podtrzymuje wszystko w istnieniu. On również, dokonawszy dzieła oczyszczenia nas z grzechów, zasiadał na wysokościach niebieskich po prawicy Majestatu Bożego
###### **Hbr 1,4**
 i stał się wyższym od aniołów o tyle, o ile odziedziczył wyższe od nich imię.
###### **Hbr 1,5**
 W rzeczywistości bowiem nigdy do żadnego ze swych aniołów nie powiedział Bóg: Ty jesteś moim Synem, Ja dziś Ciebie zrodziłem. [O żadnym ze swych aniołów nie] powiedział też Bóg: Ja będę Jego ojcem, a On będzie moim synem.
###### **Hbr 1,6**
 Kiedy zaś wprowadzał swego Pierworodnego na świat, wtedy polecił: Niech Mu oddają cześć wszyscy aniołowie Boży.
###### **Hbr 1,7**
 A oto, co powiedział o swoich aniołach: Aniołów swoich uczynił Bóg wichrami, a swoje sługi - płomieniami ognia.
###### **Hbr 1,8**
 O swoim Synu powiedział: Tron Twój, Boże, został ustanowiony na wieki oraz berło sprawiedliwości [pozostanie na zawsze] berłem Twego królestwa.
###### **Hbr 1,9**
 Umiłowałeś sprawiedliwość, a znienawidziłeś nieprawość i dlatego Bóg - właśnie Twój Bóg - bardziej niż twoich przyjaciół Ciebie namaścił olejkiem sprawiedliwości.
###### **Hbr 1,10**
 Powiedział także: Ty, Panie, na samym początku dałeś fundamenty ziemi, Ty również uczyniłeś niebiosa.
###### **Hbr 1,11**
 One przeminą, lecz Ty pozostaniesz. Wszystko zestarzeje się jak odzienie,
###### **Hbr 1,12**
 zwiniesz je jak szatę i staną się całkiem inne. A Ty ciągle będziesz ten sam i lata Twoje nigdy się nie skoń-czą.
###### **Hbr 1,13**
 Do żadnego ze swych anio-łów nie powiedział Bóg: Pozostań po mej prawej stronie, dopóki wszystkich nieprzyjaciół Twoich nie uczynią podnóżkiem nóg Twoich.
###### **Hbr 1,14**
 Czyż więc wszyscy [aniołowie] nie są duchami przeznaczonymi do posługiwania? Czyż nie zostali posłani po to, aby być pomocą dla tych, którzy mają osiągnąć zbawienie?
# Hbr 1 WUJ
###### **Hbr 1,1**
 Rozmaicie i wielą sposobów mówiwszy dawno Bóg ojcom przez proroki:
###### **Hbr 1,2**
 Naostatek tych dni mówił do nas przez Syna, którego postanowił dziedzicem wszystkiego, przez którego uczynił i wieki.
###### **Hbr 1,3**
 Który gdyż jest jasnością chwały, i wyrażeniem istności jego, a nosząc wszystko słowem mocy swej, sprawiwszy oczyścienie grzechów, siedzi na prawicy majestatu na wysokościach:
###### **Hbr 1,4**
 Tym zacniejszym zostawszy nad anioły: im osobliwsze nad nie imię odziedziczył.
###### **Hbr 1,5**
 Bo któremuż kiedy z aniołów rzekł: Synem moim jesteś ty, jam ciebie dziś urodził? I zasię: Ja mu będę Ojcem: a on mnie będzie synem?
###### **Hbr 1,6**
 A gdy zasię wprowadza pierworodnego na okrąg ziemie, mówi: A niech się mu kłaniają wszyscy aniołowie Boży.
###### **Hbr 1,7**
 A do aniołówci mówi: Który czyni aniołami swymi duchy: a sługami swymi, płomień ognia.
###### **Hbr 1,8**
 A do Syna: Stolica twoja Boże na wiek wieku, laska prawości, laska królestwa twego.
###### **Hbr 1,9**
 Umiłowałeś sprawiedliwość, a nienawiedziałeś nieprawość: dla tegoż pomazał cię Boże, Bóg twój, olejkiem radości nad uczestniki twoje.
###### **Hbr 1,10**
 I, Tyś Panie na początku ugruntował ziemię: a dzieła rąk twoich są niebiosa.
###### **Hbr 1,11**
 One poginą, a ty trwać będziesz: a wszystki jako szata zwiotszeją.
###### **Hbr 1,12**
 A jako odzienie zmienisz je, i odmienią się: ale ty tenżeś jest, i lata twoje nie ustaną?
###### **Hbr 1,13**
 A do któregoż kiedy z aniołów rzekł: Siedź po prawicy mojej, aż położę nieprzyjacioły twoje podnóżkiem nóg twoich?
###### **Hbr 1,14**
 Izali wszyscy, nie są duchowie usługujący: na posługę posłani dla tych, którzy dziedzictwo zbawienia wziąć mają?
# Hbr 1 STERN
###### **Hbr 1,1**
 W dniach minionych Bóg przemawiał na wiele rozmaitych sposobów do Ojców przez proroków.
###### **Hbr 1,2**
 Teraz jednak, w acharit-hajamim, przemówił do nas przez swego Syna, któremu powierzył własność wszystkiego i przez którego stworzył wszechświat.
###### **Hbr 1,3**
 Syn ten jest jasnością Sz'chiny, wyrażeniem Bożej istoty, podtrzymującym wszystko, co istnieje, swym potężnym słowem; a kiedy już dokonał przez siebie oczyszczenia z grzechów, zasiadł po prawicy Ha-G'dula Ba-M'romim.
###### **Hbr 1,4**
 Stał się On więc kimś znacznie lepszym od aniołów, a dane Mu przez Boga imię wyższe jest niż ich imię.
###### **Hbr 1,5**
 Bo do którego z aniołów rzekł kiedykolwiek Bóg: "Jesteś moim Synem, dziś stałem się Twym Ojcem"? Również o żadnym z aniołów Bóg nie powiedział: "Ja będę Jego Ojcem, a On będzie moim Synem".
###### **Hbr 1,6**
 I znów: kiedy Bóg wprowadza swego Pierworodnego na świat, mówi: "Niech oddają Mu cześć wszyscy aniołowie Boży".
###### **Hbr 1,7**
 Zaiste, mówiąc o aniołach, powiada On: "...który czyni swych aniołów wichrami, a sługi swe płomieniami ognia",
###### **Hbr 1,8**
 lecz do Syna mówi: "Tron Twój, o Boże, będzie trwał na wieki wieków, Ty swym Królestwem władasz berłem sprawiedliwości,
###### **Hbr 1,9**
 umiłowałeś prawość, a znienawidziłeś niegodziwość. Dlatego, Boże, namaścił Cię Bóg Twój olejkiem radości szczodrzej niż Twych towarzyszy";
###### **Hbr 1,10**
 oraz: "Na początku, Panie, położyłeś fundamenty ziemi, niebo jest dziełem Twoich rąk.
###### **Hbr 1,11**
 One znikną, ale Ty pozostaniesz, jak odzienie się zestarzeją
###### **Hbr 1,12**
 i zwiniesz je jak płaszcz. Owszem, zmienią się jak odzienie, lecz Ty pozostajesz ten sam, lata Twoje nigdy się nie skończą".
###### **Hbr 1,13**
 Poza tym do którego z aniołów powiedział kiedykolwiek: "Usiądź po mojej prawicy, aż uczynię Twoich nieprzyjaciół podnóżkiem dla Twoich stóp"?
###### **Hbr 1,14**
 Czyż wszyscy oni nie są tylko duchami, które służą, posłanymi do pomocy tym, których Bóg wyzwoli?
# Hbr 1 TRO
###### **Hbr 1,1**
 **πολυμερως** *polymerōs* W wielu częściach [[G4181]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **πολυτροπως** *polytropōs* na wiele sposobów [[G4187]] [[ADV]] **παλαι** *palai* od dawna [[G3819]] [[ADV]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **λαλησας** *lalēsas* powiedziawszy [[G2980]] WTV-AAP-NSM **τοις** *tois* [[G3588]] WTT-DPM **πατρασιν** *patrasin* ojcom [[G3962]] WTN-DPM **εν** *en* w [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPM **προφηταις** *profētais* prorokach [[G4396]] WTN-DPM
###### **Hbr 1,2**
 **επ** *ep* na [[G1909]] [[PREP]] **εσχατων** *eschatōn* końcach – ostatnich [[G2078]] WTA-GPF **των** *tōn* (w) [[G3588]] WTT-GPF **ημερων** *hēmerōn* dniach [[G2250]] WTN-GPF **τουτων** *toutōn* tych [[G3778]] WTD-GPF **ελαλησεν** *elalēsen* powiedział [[G2980]] [[V-AAI-3S]] **ημιν** *hēmin* nam [[G2254]] WTP-1DP **εν** *en* w [[G1722]] [[PREP]] **υιω** *hyiō* Synu [[G5207]] WTN-DSM **ον** *hon* którego [[G3739]] WTR-ASM **εθηκεν** *ethēken* ustanowił – umieścił [[G5087]] [[V-AAI-3S]] **κληρονομον** *klēronomon* dziedzicem [[G2818]] [[N-ASM]] **παντων** *pantōn* wszystkiego [[G3956]] WTA-GPN **δι** *di* przez [[G1223]] [[PREP]] **ου** *hou* którego [[G3739]] WTR-GSM **και** *kai* i [[G2532]] [[CONJ]] **τους** *tous* [[G3588]] WTT-APM **αιωνας** *aiōnas* wieki [[G165]] [[N-APM]] **εποιησεν** *epoiēsen* uczynił [[G4160]] [[V-AAI-3S]]
###### **Hbr 1,3**
 **ος** *hos* Ten – Który [[G3739]] WTR-NSM **ων** *ōn* będąc [[G5607]] [[V-PXP-NSM]] **απαυγασμα** *apaugasma* odblask – jasność [[G541]] WTN-NSN **της** *tēs* [[G3588]] [[T-GSF]] **δοξης** *doksēs* chwały [[G1391]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **χαρακτηρ** *charaktēr* wizerunek – dokładne odwzorowanie [[G5481]] [[N-NSM]] **της** *tēs* [[G3588]] [[T-GSF]] **υποστασεως** *hypostaseōs* zrozumienia – założenia [[G5287]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **φερων** *ferōn* niosąc [[G5342]] [[V-PAP-NSM]] **τε** *te* zarówno – także [[G5037]] WTPRT **τα** *ta* [[G3588]] WTT-APN **παντα** *panta* wszystkie [[G3956]] WTA-APN **τω** *tō* [[G3588]] WTT-DSN **ρηματι** *rēmati* wypowiedzią [[G4487]] WTN-DSN **της** *tēs* [[G3588]] [[T-GSF]] **δυναμεως** *dynameōs* mocy [[G1411]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **δι** *di* przez [[G1223]] [[PREP]] **εαυτου** *heautou* samego siebie [[G1438]] WTF-3GSM **καθαρισμον** *katharismon* oczyszczenie [[G2512]] [[N-ASM]] **ποιησαμενος** *poiēsamenos* uczyniwszy [[G4160]] WTV-AMP-NSM **των** *tōn* (z) [[G3588]] WTT-GPF **αμαρτιων** *hamartiōn* grzechów [[G266]] WTN-GPF **ημων** *hēmōn* naszych [[G2257]] WTP-1GP **εκαθισεν** *ekathisen* usiadł [[G2523]] [[V-AAI-3S]] **εν** *en* po [[G1722]] [[PREP]] **δεξια** *deksia* prawej stronie – prawicy [[G1188]] WTA-DSF **της** *tēs* [[G3588]] [[T-GSF]] **μεγαλωσυνης** *megalōsynēs* wielkości – majestatu [[G3172]] [[N-GSF]] **εν** *en* na [[G1722]] [[PREP]] **υψηλοις** *hypsēlois* wysokościach [[G5308]] WTA-DPN
###### **Hbr 1,4**
 **τοσουτω** *tosoutō* o tak wiele – o tyle [[G5118]] WTD-DSM **κρειττων** *kreittōn* lepszy – znaczniejszy [[G2909]] [[A-NSM]] **γενομενος** *genomenos* który stał się [[G1096]] WTV-2ADP-NSM **των** *tōn* (od) [[G3588]] WTT-GPM **αγγελων** *angelōn* zwiastunów [[G32]] WTN-GPM **οσω** *hosō* ile – jak [[G3745]] WTK-DSN **διαφορωτερον** *diaforōteron* różniejsze [[G1313]] WTA-ASN-C **παρ** *par* od [[G3844]] [[PREP]] **αυτους** *autous* nich [[G846]] [[P-APM]] **κεκληρονομηκεν** *keklēronomēken* dziedziczy – dostaje w udziale [[G2816]] WTV-RAI-3S **ονομα** *onoma* imię [[G3686]] WTN-ASN
###### **Hbr 1,5**
 **τινι** *tini* któremu [[G5101]] WTI-DSM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **ποτε** *pote* niegdyś – dawniej [[G4218]] WTPRT **των** *tōn* (ze) [[G3588]] WTT-GPM **αγγελων** *angelōn* zwiastunów [[G32]] WTN-GPM **υιος** *hyios* Syn [[G5207]] [[N-NSM]] **μου** *mou* mój [[G3450]] WTP-1GS **ει** *ei* jesteś [[G1488]] WTV-PXI-2S **συ** *sy* Ty [[G4771]] WTP-2NS **εγω** *egō* Ja [[G1473]] WTP-1NS **σημερον** *sēmeron* dzisiaj [[G4594]] [[ADV]] **γεγεννηκα** *gegennēka* zrodziłem [[G1080]] WTV-RAI-1S **σε** *se* Ciebie [[G4571]] WTP-2AS **και** *kai* i [[G2532]] [[CONJ]] **παλιν** *palin* znów [[G3825]] [[ADV]] **εγω** *egō* Ja [[G1473]] WTP-1NS **εσομαι** *esomai* będę [[G2071]] WTV-FXI-1S **αυτω** *autō* Mu [[G846]] WTP-DSM **εις** *eis* za [[G1519]] [[PREP]] **πατερα** *patera* Ojca [[G3962]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **αυτος** *autos* On [[G846]] WTP-NSM **εσται** *estai* będzie [[G2071]] WTV-FXI-3S **μοι** *moi* Mi [[G3427]] WTP-1DS **εις** *eis* za [[G1519]] [[PREP]] **υιον** *hyion* Syna [[G5207]] [[N-ASM]]
###### **Hbr 1,6**
 **οταν** *hotan* Kiedy [[G3752]] [[CONJ]] **δε** *de* zaś [[G1161]] [[CONJ]] **παλιν** *palin* znów [[G3825]] [[ADV]] **εισαγαγη** *eisagagē* wprowadziłbyś [[G1521]] WTV-2AAS-3S **τον** *ton* [[G3588]] [[T-ASM]] **πρωτοτοκον** *prōtotokon* Pierworodnego [[G4416]] WTA-ASM **εις** *eis* na [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **οικουμενην** *oikoumenēn* świecie zamieszkałym [[G3625]] WTN-ASF **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **και** *kai* i [[G2532]] [[CONJ]] **προσκυνησατωσαν** *proskynēsatōsan* niech oddają cześć – niech się pokłonią [[G4352]] WTV-AAM-3P **αυτω** *autō* Mu [[G846]] WTP-DSM **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **αγγελοι** *angeloi* zwiastunowie [[G32]] WTN-NPM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **Hbr 1,7**
 **και** *kai* i [[G2532]] [[CONJ]] **προς** *pros* do [[G4314]] [[PREP]] **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **τους** *tous* [[G3588]] WTT-APM **αγγελους** *angelous* zwiastunów [[G32]] [[N-APM]] **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **ποιων** *poiōn* czyniący [[G4160]] [[V-PAP-NSM]] **τους** *tous* [[G3588]] WTT-APM **αγγελους** *angelous* zwiastunów [[G32]] [[N-APM]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **πνευματα** *pneumata* wiatrami – duchami [[G4151]] WTN-APN **και** *kai* i [[G2532]] [[CONJ]] **τους** *tous* [[G3588]] WTT-APM **λειτουργους** *leitourgous* publiczne sługi [[G3011]] [[N-APM]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **πυρος** *pyros* ognia [[G4442]] [[N-GSN]] **φλογα** *floga* płomieniem [[G5395]] WTN-ASF
###### **Hbr 1,8**
 **προς** *pros* Do [[G4314]] [[PREP]] **δε** *de* zaś [[G1161]] [[CONJ]] **τον** *ton* [[G3588]] [[T-ASM]] **υιον** *hyion* Syna [[G5207]] [[N-ASM]] **ο** *ho* [[G3588]] [[T-NSM]] **θρονος** *thronos* tron [[G2362]] [[N-NSM]] **σου** *sou* Twój [[G4675]] WTP-2GS **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Boże [[G2316]] [[N-NSM]] **εις** *eis* na [[G1519]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **αιωνα** *aiōna* wiek [[G165]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **αιωνος** *aiōnos* wieku [[G165]] [[N-GSM]] **ραβδος** *rabdos* laska – berło [[G4464]] [[N-NSF]] **ευθυτητος** *euthytētos* prostolinijności [[G2118]] [[N-GSF]] **η** *hē* [[G3588]] [[T-NSF]] **ραβδος** *rabdos* laska – berło [[G4464]] [[N-NSF]] **της** *tēs* [[G3588]] [[T-GSF]] **βασιλειας** *basileias* Królestwa [[G932]] [[N-GSF]] **σου** *sou* Twojego [[G4675]] WTP-2GS
###### **Hbr 1,9**
 **ηγαπησας** *ēgapēsas* umiłowałeś [[G25]] WTV-AAI-2S **δικαιοσυνην** *dikaiosynēn* sprawiedliwość [[G1343]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **εμισησας** *emisēsas* znienawidziłeś [[G3404]] WTV-AAI-2S **ανομιαν** *anomian* bezprawie – nieprawość [[G458]] WTN-ASF **δια** *dia* przez [[G1223]] [[PREP]] **τουτο** *touto* to [[G5124]] WTD-ASN **εχρισεν** *echrisen* namaścił – pomazał [[G5548]] [[V-AAI-3S]] **σε** *se* Ciebie [[G4571]] WTP-2AS **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **σου** *sou* Twój [[G4675]] WTP-2GS **ελαιον** *elaion* oliwą [[G1637]] WTN-ASN **αγαλλιασεως** *agalliaseōs* rozweselenia – radosnego uniesienia [[G20]] [[N-GSF]] **παρα** *para* od [[G3844]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **μετοχους** *metochous* uczestników – towarzyszy [[G3353]] WTA-APM **σου** *sou* Twoich [[G4675]] WTP-2GS
###### **Hbr 1,10**
 **και** *kai* i [[G2532]] [[CONJ]] **συ** *sy* Ty [[G4771]] WTP-2NS **κατ** *kat* podczas [[G2596]] [[PREP]] **αρχας** *archas* początków [[G746]] WTN-APF **κυριε** *kyrie* Panie [[G2962]] WTN-VSM **την** *tēn* [[G3588]] WTT-ASF **γην** *gēn* ziemię [[G1093]] WTN-ASF **εθεμελιωσας** *ethemeliōsas* ugruntowałeś – położyłeś fundament [[G2311]] WTV-AAI-2S **και** *kai* i [[G2532]] [[CONJ]] **εργα** *erga* dzieła [[G2041]] WTN-NPN **των** *tōn* [[G3588]] WTT-GPF **χειρων** *cheirōn* rąk [[G5495]] WTN-GPF **σου** *sou* Twoich [[G4675]] WTP-2GS **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **οι** *hoi* [[G3588]] WTT-NPM **ουρανοι** *ouranoi* niebiosa [[G3772]] WTN-NPM
###### **Hbr 1,11**
 **αυτοι** *autoi* one [[G846]] WTP-NPM **απολουνται** *apolountai* zostaną zniszczone – zginą [[G622]] WTV-FMI-3P **συ** *sy* Ty [[G4771]] WTP-2NS **δε** *de* zaś [[G1161]] [[CONJ]] **διαμενεις** *diameneis* trwasz – pozostajesz [[G1265]] WTV-PAI-2S **και** *kai* i [[G2532]] [[CONJ]] **παντες** *pantes* wszystkie [[G3956]] WTA-NPM **ως** *hōs* jak [[G5613]] [[ADV]] **ιματιον** *himation* szata – płaszcz [[G2440]] WTN-NSN **παλαιωθησονται** *palaiōthēsontai* ulegną zestarzeniu [[G3822]] WTV-FPI-3P
###### **Hbr 1,12**
 **και** *kai* i [[G2532]] [[CONJ]] **ωσει** *hōsei* jakby [[G5616]] [[ADV]] **περιβολαιον** *peribolaion* okrycie [[G4018]] WTN-NSN **ελιξεις** *helikseis* zawiniesz – zrolujesz [[G1667]] WTV-FAI-2S **αυτους** *autous* nimi [[G846]] [[P-APM]] **και** *kai* i [[G2532]] [[CONJ]] **αλλαγησονται** *allagēsontai* zostaną zmienione – zostaną przemienione [[G236]] WTV-2FPI-3P **συ** *sy* Ty [[G4771]] WTP-2NS **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **αυτος** *autos* Tym samym [[G846]] WTP-NSM **ει** *ei* jesteś [[G1488]] WTV-PXI-2S **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-NPN **ετη** *etē* lata [[G2094]] WTN-NPN **σου** *sou* Twoje [[G4675]] WTP-2GS **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εκλειψουσιν** *ekleipsousin* skończą się – ustaną [[G1587]] WTV-FAI-3P
###### **Hbr 1,13**
 **προς** *pros* Do [[G4314]] [[PREP]] **τινα** *tina* kogo [[G5101]] WTI-ASM **δε** *de* zaś [[G1161]] [[CONJ]] **των** *tōn* (ze) [[G3588]] WTT-GPM **αγγελων** *angelōn* zwiastunów [[G32]] WTN-GPM **ειρηκεν** *eirēken* powiedział [[G2046]] WTV-RAI-3S-ATT **ποτε** *pote* niegdyś – dawniej [[G4218]] WTPRT **καθου** *kathou* siądź [[G2521]] WTV-PNM-2S **εκ** *ek* po [[G1537]] [[PREP]] **δεξιων** *deksiōn* prawej strony – prawicy [[G1188]] WTA-GPM **μου** *mou* mojej [[G3450]] WTP-1GS **εως** *heōs* aż [[G2193]] [[CONJ]] **αν** *an* (kiedy)kolwiek [[G302]] WTPRT **θω** *thō* umieściłbym – położyłbym [[G5087]] WTV-2AAS-1S **τους** *tous* [[G3588]] WTT-APM **εχθρους** *echthrous* wrogów – nieprzyjaciół [[G2190]] WTA-APM **σου** *sou* Twoich [[G4675]] WTP-2GS **υποποδιον** *hypopodion* podnóżkiem [[G5286]] WTN-ASN **των** *tōn* [[G3588]] WTT-GPM **ποδων** *podōn* stóp [[G4228]] WTN-GPM **σου** *sou* Twoich [[G4675]] WTP-2GS
###### **Hbr 1,14**
 **ουχι** *ouchi* Czyż nie [[G3780]] WTPRT-I **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **λειτουργικα** *leitourgika* posługujące – służebne [[G3010]] WTA-NPN **πνευματα** *pneumata* duchy [[G4151]] WTN-NPN **εις** *eis* ku [[G1519]] [[PREP]] **διακονιαν** *diakonian* posłudze – służbie [[G1248]] WTN-ASF **αποστελλομενα** *apostellomena* którzy są wysłani [[G649]] WTV-PPP-NPN **δια** *dia* z powodu – względem [[G1223]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **μελλοντας** *mellontas* zamierzających [[G3195]] WTV-PAP-APM **κληρονομειν** *klēronomein* odziedziczać – dostawać w udziale [[G2816]] WTV-PAN **σωτηριαν** *sōtērian* zbawienie – wyzwolenie [[G4991]] WTN-ASF
