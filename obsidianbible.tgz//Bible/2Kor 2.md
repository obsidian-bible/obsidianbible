# 2Kor 2 BT5
###### **2Kor 2,1**
 Sam to sobie postanowiłem, by nie przychodzić do was ponownie w smutku.
###### **2Kor 2,2**
 Jeżeli ja was zasmucam, któż mi radość sprawi, jeśli nie ten, którego ja zasmucam?
###### **2Kor 2,3**
 A napisałem to, aby nie doznać podwójnego smutku, gdy przybędę do tych, od których winienem doznawać radości; zresztą jestem przeświadczony co do was wszystkich, że moja radość jest także waszą radością.
###### **2Kor 2,4**
 Pisałem bowiem do was, będąc w wielkiej rozterce i ucisku serca, wśród wielu łez, nie po to, aby was zasmucić, lecz żebyście wiedzieli, jak tym bardziej was miłuję.
###### **2Kor 2,5**
 Jeżeli zaś ktoś smutek sprawił, to nie mnie, lecz po części – by nie przesadzić – wam wszystkim.
###### **2Kor 2,6**
 Niech już takiemu wystarczy kara wymierzona przez większość was.
###### **2Kor 2,7**
 Raczej wypada teraz wybaczyć mu i podtrzymać go na duchu, aby nie popadł ów człowiek w rozpaczliwy smutek.
###### **2Kor 2,8**
 Dlatego napominam was, abyście z miłością rozstrzygnęli jego sprawę.
###### **2Kor 2,9**
 W tym też celu napisałem, aby was wypróbować i aby się przekonać, czy we wszystkim jesteście posłuszni.
###### **2Kor 2,10**
 Komu zaś cokolwiek wybaczyliście, ja też [mu wybaczam]. Co bowiem wybaczyłem, o ile coś miałem wybaczyć, uczyniłem to dla was wobec Chrystusa,
###### **2Kor 2,11**
 ażeby nie uwiódł nas szatan, którego knowania dobrze są nam znane.
###### **2Kor 2,12**
 Kiedy przybyłem do Troady, by głosić Ewangelię Chrystusa, a bramy były dla mnie otwarte w Panu,
###### **2Kor 2,13**
 duch mój nie zaznał spokoju, bo nie spotkałem Tytusa, brata mojego. Pożegnałem się przeto i wyruszyłem do Macedonii.
###### **2Kor 2,14**
 Lecz Bogu niech będą dzięki za to, że pozwala nam zawsze zwyciężać w Chrystusie i roznosić po wszystkich miejscach woń Jego poznania.
###### **2Kor 2,15**
 Jesteśmy bowiem miłą Bogu wonnością Chrystusa zarówno dla tych, którzy dostępują zbawienia, jak i dla tych, którzy idą na zatracenie;
###### **2Kor 2,16**
 dla jednych jest to zapach zgubny – na śmierć, dla drugich zapach ożywiający – na życie. A któż temu sprosta?
###### **2Kor 2,17**
 Nie jesteśmy bowiem jak wielu, którzy kupczą słowem Bożym, lecz ze szczerością, jak od Boga mówimy w Chrystusie przed Bogiem.
# 2Kor 2 PAU
###### **2Kor 2,1**
 Przyrzekłem sobie, by więcej ze smutkiem do was nie przychodzić.
###### **2Kor 2,2**
 Przecież kiedy was zasmucam, czy może pocieszyć mnie ten, kto smuci się przeze mnie?
###### **2Kor 2,3**
 Właśnie dlatego napisałem w ten sposób, abym nie został zasmucony przez tych, którzy powinni sprawić mi radość, gdy przybędę. Co do was wszystkich jestem bowiem przekonany, że moja radość jest radością każdego z was.
###### **2Kor 2,4**
 Pisałem do was, będąc w wielkim utrapieniu, z bólem w sercu i ze łzami nie po to, abyście się smucili, ale byście poznali, jak wielka jest moja miłość do was.
###### **2Kor 2,5**
 Jeśli jednak ktoś był powodem smutku, nie mnie zasmucił, ale - nie przesadzając - w jakiś sposób was wszystkich.
###### **2Kor 2,6**
 Ta kara, którą wymierzyła mu większość spośród was, niech już wystarczy.
###### **2Kor 2,7**
 Teraz raczej wybaczcie mu i pocieszcie go, aby nie popadł w większy smutek.
###### **2Kor 2,8**
 Zachęcam też, aby mu okazać miłość.
###### **2Kor 2,9**
 Po to przecież napisałem, by przekonać się, czy we wszystkim jesteście posłuszni.
###### **2Kor 2,10**
 Komu wy przebaczycie, temu i ja przebaczę. Zresztą, jeśli miałem coś do przebaczenia, to już przed Chrystusem przebaczyłem ze względu na was,
###### **2Kor 2,11**
 by nie wykorzystał nas szatan, którego zamysły są nam dobrze znane.
###### **2Kor 2,12**
 Gdy przyszedłem do Troady, by głosić Ewangelię Chrystusa, chociaż Pan otworzył przede mną wielkie możliwości,
###### **2Kor 2,13**
 nie zyskałem pokoju ducha, gdyż nie zastałem mojego brata Tytusa. Rozstałem się więc z nimi i wyruszyłem do Macedonii.
###### **2Kor 2,14**
 Niech będą dzięki Bogu, który pozwala nam zawsze uczestniczyć w tryumfie Chrystusa i wszędzie roztacza przez nas woń Jego poznania.
###### **2Kor 2,15**
 Dla Boga jesteśmy bowiem miłą wonią Chrystusa, zarówno wśród tych, którzy są na drodze do zbawienia, jak też wśród tych, którzy są na drodze do zagłady.
###### **2Kor 2,16**
 Dla jednych jesteśmy wonią śmierci - ku śmierci, dla drugich zaś wonią życia - ku życiu. A któż jest godny tego zadania?
###### **2Kor 2,17**
 Nie handlujemy słowem Bożym jak wielu innych, ale jako wysłani przez Boga głosimy szczerze wobec Boga w Chrystusie.
# 2Kor 2 BP
###### **2Kor 2,1**
 Postanowiłem sobie nie przybywać do was i nie sprawiać wam ponownie smutku.
###### **2Kor 2,2**
 Jeżeli was zasmucam, to któż mię rozweseli? Czy nie ten, którego ja zasmucam?
###### **2Kor 2,3**
 Napisałem o tym, aby przybywając do was nie doznać smutku od tych, którzy powinni sprawić mi radość. Jestem zaś przekonany o was wszystkich, że moja radość jest waszą radością.
###### **2Kor 2,4**
 Pisałem do was w wielkiej udręce i ucisku serca, wśród wielu łez, nie po to, aby was zasmucić, lecz abyście poznali, jak szczególną miłością was darzę.
###### **2Kor 2,5**
 Jeżeli ktoś zasmucił mnie, to właściwie nie mnie zasmucił, lecz częściowo - aby nie przesadzać - was wszystkich.
###### **2Kor 2,6**
 Niech takiemu wystarczy kara, jaką otrzymał od większości.
###### **2Kor 2,7**
 Powinniście raczej mu darować i pocieszyć go, aby nie pogrążył się w bezgranicznym smutku.
###### **2Kor 2,8**
 Dlatego błagam was, abyście jego sprawę rozstrzygnęli z miłością.
###### **2Kor 2,9**
 Napisałem do was w tym celu, aby was wypróbować, czy we wszystkim jesteście posłuszni.
###### **2Kor 2,10**
 Komu zaś cokolwiek przebaczycie, temu i ja przebaczę. A ja jeżeli coś przebaczyłem - o ile w ogóle mam coś do przebaczenia - to uczyniłem to dla was i ze względu na Chrystusa.
###### **2Kor 2,11**
 Uczyniłem to po to, aby nie oszukał was szatan, ponieważ znamy jego zamiary.
###### **2Kor 2,12**
 Kiedy przybyłem do Troady, aby głosić dobrą nowinę Chrystusa i otworzyły się przede mną możliwości pracy w Panu,
###### **2Kor 2,13**
 nie zaznałem spokoju, bo nie zastałem Tytusa, mego brata. Pożegnałem się zatem i wyruszyłem do Macedonii.
###### **2Kor 2,14**
 Bogu niech będą dzięki, Temu, który zawsze prowadzi nas do zwycięstwa w Chrystusie, Temu, który wszędzie roznosi przez nas wiedzę o Chrystusie.
###### **2Kor 2,15**
 Jesteśmy miłą Bogu wonnością Chrystusa, wśród dążących do zbawienia i zmierzających do potępienia.
###### **2Kor 2,16**
 Dla jednych jest to woń śmiercionośna, która zabija, dla drugich jest to woń ożywcza, która daje życie. Kto jest do tego zdolny?
###### **2Kor 2,17**
 Nie jesteśmy bowiem - jak wielu innych, handlarzami słowa Bożego, lecz przemawiamy w szczerości, z natchnienia Bożego i w obliczu Boga w Chrystusie.
# 2Kor 2 BR
###### **2Kor 2,1**
 Sam to sobie postanowiłem, by nie przychodzić do was ponownie w smutku.
###### **2Kor 2,2**
 Jeżeli ja was zasmucam, któż mi radość sprawi, jeśli nie ten, którego ja zasmucam?
###### **2Kor 2,3**
 A napisałem to, aby nie doznać podwójnego smutku, gdy przybędę do tych, od których winienem doznawać radości; zresztą jestem przeświadczony co do was wszystkich, że moja radość jest także waszą radością.
###### **2Kor 2,4**
 Pisałem bowiem do was będąc w wielkiej rozterce i ucisku serca, wśród wielu łez, nie po to, aby was zasmucić, lecz żebyście wiedzieli, jak tym bardziej was miłuję.
###### **2Kor 2,5**
 Jeżeli zaś ktoś smutek sprawił, to nie mnie, lecz po części - by nie przesadzać - wam wszystkim.
###### **2Kor 2,6**
 Niech już takiemu wystarczy kara wymierzona przez większość spośród was.
###### **2Kor 2,7**
 Raczej wypada teraz wybaczyć mu i podtrzymać go na duchu, aby nie popadł ów człowiek w rozpaczliwy smutek.
###### **2Kor 2,8**
 Dlatego napominam was, abyście z miłością sprawę jego rozstrzygnęli.
###### **2Kor 2,9**
 W tym też celu napisałem, aby was wypróbować i aby się przekonać, czy we wszystkim jesteście posłuszni.
###### **2Kor 2,10**
 Komu zaś cokolwiek wybaczyliście, ja też [mu wybaczam]. Co bowiem wybaczyłem, jeżeli coś wybaczyłem, uczyniłem to dla was wobec Chrystusa,
###### **2Kor 2,11**
 ażeby nie uwiódł nas szatan, którego knowania dobrze są nam znane.
###### **2Kor 2,12**
 Kiedy przybyłem do Troady, by głosić Ewangelię Chrystusa, a bramy były mi otwarte w Panu,
###### **2Kor 2,13**
 duch mój nie zaznał spokoju, bo nie spotkałem Tytusa, brata mojego. Pożegnałem się przeto i wyruszyłem do Macedonii.
###### **2Kor 2,14**
 Lecz Bogu niech będą dzięki za to, że pozwala nam zawsze zwyciężać w Chrystusie i roznosić po wszystkich miejscach woń Jego poznania.
###### **2Kor 2,15**
 Jesteśmy bowiem miłą Bogu wonnością Chrystusa zarówno dla tych, którzy dostępują zbawienia, jak i dla tych, którzy idą na zatracenie;
###### **2Kor 2,16**
 dla jednych jest to zapach zgubny - na śmierć, dla drugich zapach ożywiający - na życie. A któż potrafi to zrobić?
###### **2Kor 2,17**
 Nie jesteśmy bowiem jak wielu, którzy kupczą słowem Bożym, lecz ze szczerości, jak od Boga mówimy w Chrystusie przed Bogiem.
# 2Kor 2 WUJ
###### **2Kor 2,1**
 A postanowiłem to u siebie, abych powtóre nie z zasmuceniem do was przyszedł.
###### **2Kor 2,2**
 Bo jeśli ja was zasmucam: a któż jest coby mię rozweselił, jedno ten, który jest ze mnie zasmucon?
###### **2Kor 2,3**
 A tożem wam napisał, abych przyszedszy nie miał smutku na smutek. Miałem się był weselić: ufając o was wszystkich, że wesele moje was wszystkich jest.
###### **2Kor 2,4**
 Bom z wielkiego utrapienia i ściśnienia serca napisałem wam, z wielą łez: nie abyście się zasmucili: ale abyście uznali, którą miłość mam obficiej ku wam.
###### **2Kor 2,5**
 A jeśliż kto zasmucił, nie mnieć zasmucił, ale poczęści, abych nie obciążył was wszystkich.
###### **2Kor 2,6**
 Dosyć temu, który takowy jest, na strofowaniu tem, które bywa od wielu:
###### **2Kor 2,7**
 Tak iż przeciwnym obyczajem raczej darować macie i cieszyć, by snać zbytnim smutkiem, który takowy jest, pożart nie był.
###### **2Kor 2,8**
 Przetoż was proszę, abyście miłość przeciwko niemu potwierdzili.
###### **2Kor 2,9**
 Abowiem dla tegom i napisał, abym poznał doświadczenie wasze, jeśliże we wszystkiem jesteście posłuszni.
###### **2Kor 2,10**
 A komuście co darowali, i ja. Bo i ja co, darował, jeślim co darował, dla was, w osobie Chrystusowej.
###### **2Kor 2,11**
 Abyśmy oszukani nie byli od szatana: abowiem nie są nam tajne myśli jego.
###### **2Kor 2,12**
 A gdym przyszedł do Troady dla Ewanieljej Chrystusowej, a drzwi mi były otworzone w Panu:
###### **2Kor 2,13**
 Nie miałem uspokojenia duchowi memu, przetożem nie nalazł Tytusa brata mego, ale pożegnawszy się z nimi, poszedłem do Macedoniej.
###### **2Kor 2,14**
 A dzięka Bogu, który czyni, że tryumfujemy zawsze w Chrystusie Jezusie, i wonność znajomości swej objawia przez nas, na każdem miejscu.
###### **2Kor 2,15**
 Bo jesteśmy dobrą wonnością Chrystusową Bogu w tych, którzy zbawieni bywają, i w tych, którzy giną.
###### **2Kor 2,16**
 Jednym wonią śmierci na śmierć: a drugim wonią żywota ku żywotowi. A do tego kto tak sposobny?
###### **2Kor 2,17**
 Bo nie jesteśmy jako wiele ich, fałszujący słowo Boże: ale z szczerości, ale jako z Boga przed Bogiem, w Chrystusie mówiemy.
# 2Kor 2 STERN
###### **2Kor 2,1**
 Postanowiłem zatem, że nie złożę wam kolejnej bolesnej wizyty.
###### **2Kor 2,2**
 Bo jeśli sprawiam wam ból, to kto mnie uszczęśliwi, jeśli nie ci, którym zadałem ból?
###### **2Kor 2,3**
 Po to właśnie napisałem, jak napisałem - abym gdy przybędę, nie musiał cierpieć bólu przez tych, którzy powinni mnie uszczęśliwić; bo mam do was wszystkich dość zaufania, by wierzyć, że gdybym ja nie mógł być szczęśliwy, to szczęśliwy nie mógłby być też żaden z was.
###### **2Kor 2,4**
 Pisałem do was z sercem wielce niespokojnym i udręczonym i wśród wielu łez, nie aby sprawić wam ból, lecz żeby wam uświadomić, jak bardzo was kocham.
###### **2Kor 2,5**
 A jeśli ktoś spowodował ból, to sprawił on ból nie mnie, lecz w pewnym stopniu -nie chciałbym przesadzić - wam wszystkim.
###### **2Kor 2,6**
 Dla takiego kogoś wystarczająca jest już kara nałożona na niego przez większość,
###### **2Kor 2,7**
 tak że teraz powinniście postąpić na odwrót - przebaczyć mu, pokrzepić go, pocieszyć. W przeciwnym razie człowieka takiego mogłoby ogarnąć bezbrzeżne przygnębienie.
###### **2Kor 2,8**
 Nalegam więc, abyście pokazali, że go naprawdę kochacie.
###### **2Kor 2,9**
 Napisałem do was, żeby sprawdzić, czy przejdziecie tę próbę, i przekonać się, czy mnie do końca posłuchacie.
###### **2Kor 2,10**
 Każdemu, komu wy przebaczacie, i ja przebaczam. Bo w istocie cokolwiek przebaczyłem - jeśli w ogóle było coś do przebaczania - uczyniłem to ze względu na was przed obliczem Mesjasza,
###### **2Kor 2,11**
 aby nas nie podszedł Przeciwnik - bo świetnie sobie zdajemy sprawę z jego knowań!
###### **2Kor 2,12**
 A gdy udałem się do Troady głosić Dobrą Nowinę Mesjasza, skoro Pan otworzył mi drzwi,
###### **2Kor 2,13**
 nie mogłem się uspokoić, bo nie zastałem mego brata Tytusa. Pożegnałem więc tamtejszych łudzi i wyruszyłem dalej, do Macedonii.
###### **2Kor 2,14**
 Lecz dzięki niech będą Bogu, który w Mesjaszu nieustannie wiedzie nas w triumfalnym pochodzie i za naszym pośrednictwem rozprzestrzenia wszędzie woń tego, czym jest poznanie Go!
###### **2Kor 2,15**
 Dla Boga jesteśmy bowiem aromatem Mesjasza, zarówno wśród tych, którzy zostają zbawieni, jak i wśród tych, którzy giną -
###### **2Kor 2,16**
 dla tych ostatnich jesteśmy zapachem śmierci, wiodącym tym bardziej ku śmierci; dla tych pierwszych jesteśmy słodkim zapachem życia, wiodącym tym bardziej ku życiu. Któż podoła takiemu zadaniu?
###### **2Kor 2,17**
 Bo nie jesteśmy jak ci liczni, którzy kramarzą Dobrą Nowiną za pieniądze; przeciwnie, mówimy ze szczerego serca, jak ludzie posłani przez Boga, stojący przed obliczem Bożym, żyjący w jedności z Mesjaszem.
# 2Kor 2 TRO
###### **2Kor 2,1**
 **εκρινα** *ekrina* Osądziłem [[G2919]] WTV-AAI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **εμαυτω** *emautō* mnie samemu [[G1683]] WTF-1DSM **τουτο** *touto* to [[G5124]] WTD-ASN **το** *to* [[G3588]] WTT-ASN **μη** *mē* nie [[G3361]] [[PRT-N]] **παλιν** *palin* znowu [[G3825]] [[ADV]] **ελθειν** *elthein* przyjść [[G2064]] [[V-2AAN]] **εν** *en* w [[G1722]] [[PREP]] **λυπη** *lypē* smutku [[G3077]] [[N-DSF]] **προς** *pros* do [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP
###### **2Kor 2,2**
 **ει** *ei* Jeśli [[G1487]] WTCOND **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εγω** *egō* ja [[G1473]] WTP-1NS **λυπω** *lypō* smucę [[G3076]] WTV-PAI-1S-C **υμας** *hymas* was [[G5209]] WTP-2AP **και** *kai* i [[G2532]] [[CONJ]] **τις** *tis* kto [[G5101]] WTI-NSM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ο** *ho* (tym) [[G3588]] [[T-NSM]] **ευφραινων** *eufrainōn* rozweselającym – cieszącym [[G2165]] [[V-PAP-NSM]] **με** *me* mnie [[G3165]] WTP-1AS **ει** *ei* jeśli [[G1487]] WTCOND **μη** *mē* nie [[G3361]] [[PRT-N]] **ο** *ho* (ten) [[G3588]] [[T-NSM]] **λυπουμενος** *lypoumenos* który jest zasmucany [[G3076]] [[V-PPP-NSM]] **εξ** *eks* przeze [[G1537]] [[PREP]] **εμου** *emou* mnie [[G1700]] WTP-1GS
###### **2Kor 2,3**
 **και** *kai* A [[G2532]] [[CONJ]] **εγραψα** *egrapsa* napisałem [[G1125]] WTV-AAI-1S **υμιν** *hymin* wam [[G5213]] WTP-2DP **τουτο** *touto* to [[G5124]] WTD-ASN **αυτο** *auto* samo [[G846]] WTP-ASN **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **ελθων** *elthōn* przyszedłszy [[G2064]] WTV-2AAP-NSM **λυπην** *lypēn* smutek [[G3077]] WTN-ASF **εχω** *echō* miałbym [[G2192]] WTV-PAS-1S **αφ** *af* od [[G575]] [[PREP]] **ων** *hōn* których [[G3739]] WTR-GPM **εδει** *edei* trzeba było – należało [[G1163]] WTV-IQI-3S **με** *me* mi [[G3165]] WTP-1AS **χαιρειν** *chairein* radować się – cieszyć się [[G5463]] WTV-PAN **πεποιθως** *pepoithōs* będąc przekonany – pokładając ufność [[G3982]] WTV-2RAP-NSM **επι** *epi* do [[G1909]] [[PREP]] **παντας** *pantas* wszystkich [[G3956]] WTA-APM **υμας** *hymas* was [[G5209]] WTP-2AP **οτι** *hoti* że [[G3754]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **εμη** *emē* moja [[G1699]] WTS-1NSF **χαρα** *chara* radość [[G5479]] [[N-NSF]] **παντων** *pantōn* wszystkich [[G3956]] WTA-GPM **υμων** *hymōn* was [[G5216]] WTP-2GP **εστιν** *estin* jest [[G2076]] WTV-PXI-3S
###### **2Kor 2,4**
 **εκ** *ek* Z [[G1537]] [[PREP]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **πολλης** *pollēs* wielkiego [[G4183]] WTA-GSF **θλιψεως** *thlipseōs* ucisku – utrapienia [[G2347]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **συνοχης** *synochēs* ściśnięcia – udręki [[G4928]] [[N-GSF]] **καρδιας** *kardias* serca [[G2588]] [[N-GSF]] **εγραψα** *egrapsa* napisałem [[G1125]] WTV-AAI-1S **υμιν** *hymin* wam [[G5213]] WTP-2DP **δια** *dia* przez [[G1223]] [[PREP]] **πολλων** *pollōn* wielkie [[G4183]] WTA-GPN **δακρυων** *dakryōn* łzy [[G1144]] WTN-GPN **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **ινα** *hina* aby [[G2443]] [[CONJ]] **λυπηθητε** *lypēthēte* zostalibyście zasmuceni [[G3076]] WTV-APS-2P **αλλα** *alla* ale [[G235]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **αγαπην** *agapēn* miłość [[G26]] WTN-ASF **ινα** *hina* aby [[G2443]] [[CONJ]] **γνωτε** *gnōte* poznalibyście [[G1097]] WTV-2AAS-2P **ην** *hēn* którą [[G3739]] WTR-ASF **εχω** *echō* mam [[G2192]] WTV-PAI-1S **περισσοτερως** *perissoterōs* obficiej [[G4056]] [[ADV]] **εις** *eis* ku [[G1519]] [[PREP]] **υμας** *hymas* wam [[G5209]] WTP-2AP
###### **2Kor 2,5**
 **ει** *ei* Jeśli [[G1487]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **τις** *tis* ktoś [[G5100]] WTX-NSM **λελυπηκεν** *lelypēken* zasmuca [[G3076]] WTV-RAI-3S **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εμε** *eme* mnie [[G1691]] WTP-1AS **λελυπηκεν** *lelypēken* zasmuca [[G3076]] WTV-RAI-3S **αλλ** *all* ale [[G235]] [[CONJ]] **απο** *apo* po [[G575]] [[PREP]] **μερους** *merous* części [[G3313]] [[N-GSN]] **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **επιβαρω** *epibarō* obciążałbym [[G1912]] WTV-PAS-1S **παντας** *pantas* wszystkich [[G3956]] WTA-APM **υμας** *hymas* was [[G5209]] WTP-2AP
###### **2Kor 2,6**
 **ικανον** *hikanon* Wystarczające – Dosyć [[G2425]] WTA-NSN **τω** *tō* [[G3588]] WTT-DSM **τοιουτω** *toioutō* dla takiego [[G5108]] WTD-DSM **η** *hē* [[G3588]] [[T-NSF]] **επιτιμια** *epitimia* kara – potępienie [[G2009]] [[N-NSF]] **αυτη** *hautē* ta [[G3778]] WTD-NSF **η** *hē* [[G3588]] [[T-NSF]] **υπο** *hypo* przez [[G5259]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **πλειονων** *pleionōn* większość [[G4119]] WTA-GPM-C
###### **2Kor 2,7**
 **ωστε** *hōste* tak, że [[G5620]] [[CONJ]] **τουναντιον** *tounantion* przeciwnie [[G5121]] [[ADV]]-C **μαλλον** *mallon* raczej [[G3123]] [[ADV]] **υμας** *hymas* wam [[G5209]] WTP-2AP **χαρισασθαι** *charisasthai* okazać łaskę – darować [[G5483]] WTV-ADN **και** *kai* i [[G2532]] [[CONJ]] **παρακαλεσαι** *parakalesai* zachęcić [[G3870]] [[V-AAN]] **μηπως** *mēpōs* aby czasem nie – aby nie jakoś [[G3381]] [[CONJ]] **τη** *tē* [[G3588]] WTT-DSF **περισσοτερα** *perissotera* obfitszym [[G4053]] WTA-DSF-C **λυπη** *lypē* smutkiem [[G3077]] [[N-DSF]] **καταποθη** *katapothē* zostałby pochłonięty [[G2666]] WTV-APS-3S **ο** *ho* [[G3588]] [[T-NSM]] **τοιουτος** *toioutos* taki [[G5108]] WTD-NSM
###### **2Kor 2,8**
 **διο** *dio* Dlatego [[G1352]] [[CONJ]] **παρακαλω** *parakalō* proszę – zachęcam [[G3870]] WTV-PAI-1S **υμας** *hymas* was [[G5209]] WTP-2AP **κυρωσαι** *kyrōsai* postanowić – ustalić [[G2964]] [[V-AAN]] **εις** *eis* ku [[G1519]] [[PREP]] **αυτον** *auton* niemu [[G846]] WTP-ASM **αγαπην** *agapēn* miłość [[G26]] WTN-ASF
###### **2Kor 2,9**
 **εις** *eis* Na [[G1519]] [[PREP]] **τουτο** *touto* to [[G5124]] WTD-ASN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **εγραψα** *egrapsa* napisałem [[G1125]] WTV-AAI-1S **ινα** *hina* aby [[G2443]] [[CONJ]] **γνω** *gnō* poznałbym [[G1097]] WTV-2AAS-1S **την** *tēn* [[G3588]] WTT-ASF **δοκιμην** *dokimēn* wypróbowanie [[G1382]] WTN-ASF **υμων** *hymōn* wasze [[G5216]] WTP-2GP **ει** *ei* jeśli [[G1487]] WTCOND **εις** *eis* ku [[G1519]] [[PREP]] **παντα** *panta* wszystkiemu [[G3956]] WTA-APN **υπηκοοι** *hypēkooi* posłuszni [[G5255]] WTA-NPM **εστε** *este* jesteście [[G2075]] WTV-PXI-2P
###### **2Kor 2,10**
 **ω** *hō* Któremu [[G3739]] WTR-DSM **δε** *de* zaś [[G1161]] [[CONJ]] **τι** *ti* coś [[G5100]] WTX-ASN **χαριζεσθε** *charizesthe* okazujecie łaskę – darowujecie [[G5483]] WTV-PNI-2P **και** *kai* i [[G2532]] [[CONJ]] **εγω** *egō* ja [[G1473]] WTP-1NS **και** *kai* i [[G2532]] [[CONJ]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εγω** *egō* ja [[G1473]] WTP-1NS **ει** *ei* jeśli [[G1487]] WTCOND **τι** *ti* coś [[G5100]] WTX-ASN **κεχαρισμαι** *kecharismai* darowałem – okazałem łaskę [[G5483]] WTV-RNI-1S **ω** *hō* co [[G3739]] WTR-DSM **κεχαρισμαι** *kecharismai* darowałem – okazałem łaskę [[G5483]] WTV-RNI-1S **δι** *di* przez [[G1223]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **εν** *en* w [[G1722]] [[PREP]] **προσωπω** *prosōpō* obliczu – twarzy [[G4383]] WTN-DSN **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **2Kor 2,11**
 **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **πλεονεκτηθωμεν** *pleonektēthōmen* zostalibyśmy wykorzystani – stalibyśmy się łupem zachłanności [[G4122]] WTV-APS-1P **υπο** *hypo* przez [[G5259]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **σατανα** *satana* szatana – [przeciwnik] [[G4567]] [[N-GSM]] **ου** *ou* nie [[G3756]] [[PRT-N]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **τα** *ta* [[G3588]] WTT-APN **νοηματα** *noēmata* myśli – pomyśleń [[G3540]] WTN-APN **αγνοουμεν** *agnooumen* nie rozumiemy – nie jesteśmy świadomi [[G50]] WTV-PAI-1P
###### **2Kor 2,12**
 **ελθων** *elthōn* Przyszedłszy [[G2064]] WTV-2AAP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **εις** *eis* do [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **τρωαδα** *trōada* Troady [[G5174]] WTN-ASF **εις** *eis* względem [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **ευαγγελιον** *euangelion* dobrej nowiny [[G2098]] WTN-ASN **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **θυρας** *thyras* drzwi [[G2374]] [[N-GSF]] **μοι** *moi* mi [[G3427]] WTP-1DS **ανεωγμενης** *aneōgmenēs* które są otworzone [[G455]] WTV-RPP-GSF **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM
###### **2Kor 2,13**
 **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εσχηκα** *eschēka* mam [[G2192]] WTV-RAI-1S **ανεσιν** *anesin* ulgi – wytchnienia [[G425]] WTN-ASF **τω** *tō* (w) [[G3588]] WTT-DSN **πνευματι** *pneumati* duchu [[G4151]] WTN-DSN **μου** *mou* moim [[G3450]] WTP-1GS **τω** *tō* [[G3588]] WTT-DSM **μη** *mē* nie [[G3361]] [[PRT-N]] **ευρειν** *heurein* znaleźć [[G2147]] [[V-2AAN]] **με** *me* ja [[G3165]] WTP-1AS **τιτον** *titon* Tytusa [[G5103]] [[N-ASM]] **τον** *ton* [[G3588]] [[T-ASM]] **αδελφον** *adelfon* brata [[G80]] [[N-ASM]] **μου** *mou* mojego [[G3450]] WTP-1GS **αλλα** *alla* ale [[G235]] [[CONJ]] **αποταξαμενος** *apotaksamenos* rozstawszy się – pożegnawszy się [[G657]] WTV-AMP-NSM **αυτοις** *autois* (z) nimi [[G846]] WTP-DPM **εξηλθον** *eksēlthon* wyszedłem [[G1831]] WTV-2AAI-1S **εις** *eis* do [[G1519]] [[PREP]] **μακεδονιαν** *makedonian* Macedonii [[G3109]] WTN-ASF
###### **2Kor 2,14**
 **τω** *tō* [[G3588]] WTT-DSM **δε** *de* zaś [[G1161]] [[CONJ]] **θεω** *theō* Bogu [[G2316]] WTN-DSM **χαρις** *charis* wdzięczność – łaska [[G5485]] [[N-NSF]] **τω** *tō* [[G3588]] WTT-DSM **παντοτε** *pantote* zawsze – każdej chwili [[G3842]] [[ADV]] **θριαμβευοντι** *thriambeuonti* dającemu zwycięstwo – prowadzącemu w triumfie [[G2358]] WTV-PAP-DSM **ημας** *hēmas* nas [[G2248]] WTP-1AP **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **οσμην** *osmēn* woń [[G3744]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **γνωσεως** *gnōseōs* poznania [[G1108]] [[N-GSF]] **αυτου** *autou* Go [[G846]] [[P-GSM]] **φανερουντι** *fanerounti* objawiającemu – czyniącemu widocznym [[G5319]] WTV-PAP-DSM **δι** *di* przez [[G1223]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP **εν** *en* w [[G1722]] [[PREP]] **παντι** *panti* każdym [[G3956]] WTA-DSM **τοπω** *topō* miejscu [[G5117]] WTN-DSM
###### **2Kor 2,15**
 **οτι** *hoti* że [[G3754]] [[CONJ]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **ευωδια** *euōdia* aromat – słodki zapach [[G2175]] [[N-NSF]] **εσμεν** *esmen* jesteśmy [[G2070]] WTV-PXI-1P **τω** *tō* (dla) [[G3588]] WTT-DSM **θεω** *theō* Boga [[G2316]] WTN-DSM **εν** *en* wśród [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPM **σωζομενοις** *sōzomenois* którzy są zbawiani – którzy są ratowani [[G4982]] WTV-PPP-DPM **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* wśród [[G1722]] [[PREP]] **τοις** *tois* (tych) [[G3588]] WTT-DPM **απολλυμενοις** *apollymenois* którzy giną [[G622]] WTV-PEP-DPM
###### **2Kor 2,16**
 **οις** *hois* tych [[G3739]] WTR-DPM **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **οσμη** *osmē* woń [[G3744]] [[N-NSF]] **θανατου** *thanatou* śmierci [[G2288]] [[N-GSM]] **εις** *eis* ku [[G1519]] [[PREP]] **θανατον** *thanaton* śmierci [[G2288]] [[N-ASM]] **οις** *hois* (dla) tych [[G3739]] WTR-DPM **δε** *de* zaś [[G1161]] [[CONJ]] **οσμη** *osmē* woń [[G3744]] [[N-NSF]] **ζωης** *zōēs* życia [[G2222]] [[N-GSF]] **εις** *eis* ku [[G1519]] [[PREP]] **ζωην** *zōēn* życiu [[G2222]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **προς** *pros* do [[G4314]] [[PREP]] **ταυτα** *tauta* tych [[G5023]] WTD-APN **τις** *tis* kto [[G5101]] WTI-NSM **ικανος** *hikanos* odpowiedni [[G2425]] [[A-NSM]]
###### **2Kor 2,17**
 **ου** *ou* Nie [[G3756]] [[PRT-N]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εσμεν** *esmen* jesteśmy [[G2070]] WTV-PXI-1P **ως** *hōs* jak [[G5613]] [[ADV]] **οι** *hoi* [[G3588]] WTT-NPM **πολλοι** *polloi* wielu [[G4183]] WTA-NPM **καπηλευοντες** *kapēleuontes* kupczących [[G2585]] WTV-PAP-NPM **τον** *ton* [[G3588]] [[T-ASM]] **λογον** *logon* Słowem [[G3056]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **αλλ** *all* ale [[G235]] [[CONJ]] **ως** *hōs* jak [[G5613]] [[ADV]] **εξ** *eks* ze [[G1537]] [[PREP]] **ειλικρινειας** *eilikrineias* szczerości – nieskażoności [[G1505]] [[N-GSF]] **αλλ** *all* ale [[G235]] [[CONJ]] **ως** *hōs* jak [[G5613]] [[ADV]] **εκ** *ek* z [[G1537]] [[PREP]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **κατενωπιον** *katenōpion* w obecności [[G2714]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **λαλουμεν** *laloumen* mówimy [[G2980]] WTV-PAI-1P
