# Hbr 9 BT5
###### **Hbr 9,1**
 Wprawdzie także i pierwsze [przymierze] za-wierało przepisy służby Bożej i posiadało ziemski przybytek.
###### **Hbr 9,2**
 Był to namiot, w którego pierwszej części, zwanej [Miejscem] Świętym, znajdował się świecznik, stół i [na nim] chleby pokładne.
###### **Hbr 9,3**
 Za drugą zaś zasłoną był przybytek, który nosił nazwę "Święte Świętych".
###### **Hbr 9,4**
 Posiadało ono złoty ołtarz kadzenia i Arkę Przymierza, ze wszystkich stron pokrytą złotem. Znajdowały się w niej: naczynie złote z manną, laska Aarona, która [ongiś] zakwitła, i tablice przymierza.
###### **Hbr 9,5**
 Nad arką zaś były cheruby Chwały, które zacieniały przebłagalnię, o czym szczegółowo nie ma potrzeby teraz mówić.
###### **Hbr 9,6**
 Tak zaś te rzeczy zostały urządzone, iż do pierwszej części przybytku zawsze wchodzą kapłani sprawujący służbę świętą,
###### **Hbr 9,7**
 do drugiej natomiast – jedynie arcykapłan, i to tylko raz w roku, i nie bez krwi, którą składa w ofierze za grzechy swoje i swojego ludu.
###### **Hbr 9,8**
 Przez to Duch Święty pokazuje, że jeszcze nie została otwarta droga do Miejsca Świętego, dopóki istnieje pierwszy przybytek.
###### **Hbr 9,9**
 Ten zaś jest obrazem czasu obecnego, a składa się zgodnie z nim dary i ofiary nie mogące udoskonalić w sumieniu tego, który spełnia służbę Bożą.
###### **Hbr 9,10**
 Są to tylko przepisy tyczące się ciała, nałożone do czasu naprawy, jedynie w sprawie pokarmów, napojów i różnych obmyć.
###### **Hbr 9,11**
 Ale Chrystus, zjawiwszy się jako arcykapłan dóbr przyszłych, przez wyższy i doskonalszy, i nie ręką – to jest nie na tym świecie – uczyniony przybytek,
###### **Hbr 9,12**
 ani nie przez krew kozłów i cielców, lecz przez własną krew wszedł raz na zawsze do Miejsca Świętego i osiągnął wieczne odkupienie.
###### **Hbr 9,13**
 Jeśli bowiem krew kozłów i cielców oraz popiół z krowy, którymi skrapia się zanieczyszczonych, sprawiają oczyszczenie ciała,
###### **Hbr 9,14**
 to o ile bardziej krew Chrystusa, który przez Ducha wiecznego złożył Bogu samego siebie jako nieskalaną ofiarę, oczyści wasze sumienia z martwych uczynków, abyście służyć mogli Bogu żywemu.
###### **Hbr 9,15**
 I dlatego jest pośrednikiem Nowego Przymierza, ażeby przez śmierć, poniesioną dla odkupienia przestępstw popełnionych za pierwszego przymierza, ci, którzy są wezwani do wiecznego dziedzictwa, dostąpili spełnienia obietnicy.
###### **Hbr 9,16**
 Gdzie bowiem jest testament, tam musi nastąpić śmierć tego, który sporządza testament.
###### **Hbr 9,17**
 Testament bowiem po śmierci nabiera mocy, nie ma zaś znaczenia, gdy żyje ten, który sporządził testament.
###### **Hbr 9,18**
 Stąd także i pierwsze [przymierze] nie bez krwi zostało wprowadzone.
###### **Hbr 9,19**
 Gdy bowiem Mojżesz ogłosił całemu ludowi wszystkie przepisy Prawa, wziął krew cielców i kozłów z wodą, wełną szkarłatną oraz hizopem i pokropił tak samą księgę, jak i cały lud, mówiąc:
###### **Hbr 9,20**
 To [jest] krew przymierza, które Bóg wam przykazał.
###### **Hbr 9,21**
 Podobnie także skropił krwią przybytek i wszystkie naczynia przeznaczone do służby Bożej.
###### **Hbr 9,22**
 I prawie wszystko oczyszcza się krwią według Prawa, a bez rozlania krwi nie ma odpuszczenia [grzechów].
###### **Hbr 9,23**
 Przeto obrazy rzeczy niebieskich w taki sposób musiały być oczyszczone, same zaś rzeczy niebieskie potrzebowały o wiele doskonalszych ofiar od tamtych.
###### **Hbr 9,24**
 Chrystus bowiem wszedł nie do świątyni zbudowanej rękami ludzkimi, będącej odbiciem prawdziwej [świątyni], ale do samego nieba, aby teraz wstawiać się za nami przed obliczem Boga,
###### **Hbr 9,25**
 ani nie po to, aby się wielekroć sam miał ofiarować, jak arcykapłan, który co roku wchodzi do świątyni z krwią cudzą,
###### **Hbr 9,26**
 gdyż w takim przypadku musiałby cierpieć wiele razy od stworzenia świata. A tymczasem raz jeden ukazał się teraz na końcu wieków, aby zgładzić grzech przez ofiarę z samego siebie.
###### **Hbr 9,27**
 A jak postanowione ludziom raz umrzeć, potem zaś sąd,
###### **Hbr 9,28**
 tak Chrystus raz jeden był ofiarowany dla zgładzenia grzechów wielu, drugi raz ukaże się nie w związku z grzechem, lecz dla zbawienia tych, którzy Go oczekują.
# Hbr 9 PAU
###### **Hbr 9,1**
 Otóż pierwsze przymierze miało przepisy dotyczące kultu oraz ziemską świątynię.
###### **Hbr 9,2**
 Stał tam pierwszy namiot, zwany miejscem świętym. W nim był świecznik i stół chlebów poświęconych.
###### **Hbr 9,3**
 Za drugą zaś zasłoną stał namiot o nazwie miejsce najświętsze.
###### **Hbr 9,4**
 Była w nim złota kadzielnica i Arka Przymierza całkowicie pokryta złotem. Przechowywano w niej złote naczynie z manną, laskę Aarona, która rozkwitła, a także tablice przymierza.
###### **Hbr 9,5**
 Nad arką cheruby chwały kryły w swym cieniu płytę przebłagalną. Nie ma teraz potrzeby mówić o tym w szczegółach.
###### **Hbr 9,6**
 Całość została tak urządzona, żeby kapłani pełniący służbę w każdej chwili mogli wejść do pierwszego namiotu.
###### **Hbr 9,7**
 Do drugiego natomiast - tylko sam najwyższy kapłan raz w roku, i to nie bez krwi składanej w ofierze za winy własne i ludu.
###### **Hbr 9,8**
 Duch Święty chciał w ten sposób pokazać, że dopóki istniał pierwszy namiot, jeszcze nie objawiła się droga do świątyni.
###### **Hbr 9,9**
 Jest to ilustracja stanu dotychczasowego: ani składanie ofiar bezkrwawych, ani nawet krwawych, nie może w sumieniu udoskonalić pełniącego służbę.
###### **Hbr 9,10**
 Są to tylko zewnętrzne przepisy, przyjęte do czasu ich poprawienia, a opierają się one na pokarmach, napojach i na różnych obmyciach.
###### **Hbr 9,11**
 Chrystus zaś, który pojawił się jako najwyższy kapłan dóbr przyszłych, wszedł do namiotu większego i doskonalszego, nie ręką uczynionego, czyli nienależącego do tego stworzenia.
###### **Hbr 9,12**
 Nie z krwią kozłów i cielców, lecz przez własną krew wszedł raz na zawsze do świątyni, znajdując wieczne odkupienie.
###### **Hbr 9,13**
 Jeśli bowiem krew kozłów i wołów oraz popiół z krowy sypany na zanieczyszczonych uświęcają ich przez oczyszczenie ciała,
###### **Hbr 9,14**
 to o ile bardziej krew Chrystusa, który przez Ducha wiecznego sam siebie złożył jako nieskalaną ofiarę Bogu, oczyści nasze sumienie z martwych uczynków, abyśmy mogli służyć Bogu żywemu!
###### **Hbr 9,15**
 Dlatego jest On pośrednikiem nowego Testamentu. Dzięki Jego śmierci, poniesionej dla odkupienia wykroczeń popełnianych za czasu pierwszego Testamentu, powołani otrzymali obietnicę wiecznego dziedzictwa.
###### **Hbr 9,16**
 Otóż dla ważności testamentu wymagana jest śmierć tego, który go sporządził.
###### **Hbr 9,17**
 Testament bowiem nabiera mocy po śmierci, natomiast nie jest prawomocny za życia tego, kto go sporządził.
###### **Hbr 9,18**
 Toteż i pierwszy Testament nie mógł być zapoczątkowany bez przelania krwi.
###### **Hbr 9,19**
 Gdy mianowicie Mojżesz ogłosił całemu ludowi wszystkie przykazania zgodnie z Prawem, wziął krew cielców i kozłów oraz wodę, wełnę szkarłatną i hizop, aby skropić zarówno księgę, jak i cały lud,
###### **Hbr 9,20**
 mówiąc: To jest krew przymierza, które Bóg wam ustanowił!
###### **Hbr 9,21**
 Podobnie skropił krwią namiot i wszystkie sprzęty liturgiczne.
###### **Hbr 9,22**
 Niemal wszystko oczyszcza się we krwi, zgodnie z Prawem, bo bez przelania krwi nie ma odpuszczenia.
###### **Hbr 9,23**
 Skoro więc tak były oczyszczane wyobrażenia tego, co w niebie, to same rzeczywistości niebiańskie wymagały lepszych ofiar niż tamte.
###### **Hbr 9,24**
 Chrystus więc nie wszedł do świątyni uczynionej ludzką ręką, będącej tylko odbiciem prawdziwej, ale do samego nieba. Teraz osobiście oręduje za nami u Boga.
###### **Hbr 9,25**
 Nie musi przy tym wielokrotnie składać siebie w ofierze, w przeciwieństwie do najwyższego kapłana, który co roku wchodził do świątyni z cudzą krwią.
###### **Hbr 9,26**
 Musiałby wówczas wielokrotnie cierpieć od początku świata. On natomiast teraz, u kresu czasów, pojawił się jeden raz, aby zgładzić grzech przez własną ofiarę.
###### **Hbr 9,27**
 Postanowiono, że człowiek umrze jeden raz, a potem będzie sądzony.
###### **Hbr 9,28**
 Tak samo i Chrystus raz złożył siebie w ofierze, żeby ponieść grzechy wielu, a potem objawi się już nie ze względu na grzech, lecz dla zbawienia tych, którzy Go oczekują.
# Hbr 9 BP
###### **Hbr 9,1**
 Przecież i pierwsze Przymierze miało swoje przepisy dotyczące służby Bożej i ziemskie sanktuarium.
###### **Hbr 9,2**
 Sporządzono namiot - pierwszy, w którym znajdował się świecznik i stół oraz chleby poświęcone, nazywał się miejscem świętym,
###### **Hbr 9,3**
 za drugą zaś zasłoną był namiot zwany miejscem najświętszym.
###### **Hbr 9,4**
 Znajdowała się tam złota kadzielnica, a także arka przymierza, która była pokryta cała złotem, a w niej dzban złoty zawierający mannę, laska Aarona, która wypuściła kiedyś pędy, oraz tablice Przymierza.
###### **Hbr 9,5**
 Nad nią znajdowały się cheruby Chwały ocieniające przykrycie arki. O tych rzeczach nie potrzebuję teraz opowiadać szczegółowo.
###### **Hbr 9,6**
 Tak to wszystko było urządzone. Do pierwszego namiotu zawsze wchodzą kapłani, aby spełniać służbę Bożą,
###### **Hbr 9,7**
 natomiast do drugiego - raz w roku sam arcykapłan, i to nie bez krwi, którą ofiaruje za przekroczenia swoje i narodu.
###### **Hbr 9,8**
 Przez to Duch Święty daje do zrozumienia, że dopóki istnieje pierwszy namiot, dopóty nie jest otwarta droga do miejsca poświęconego Bogu.
###### **Hbr 9,9**
 Taki jest obraz czasów składania ofiar bezkrwawych i krwawych, które nie potrafią udoskonalić wewnętrznie tego, kto spełnia służbę Bożą.
###### **Hbr 9,10**
 Są to przecież tylko różne przepisy dotyczące naturalnego porządku: o pokarmach, napojach i obmyciach, nadane do czasu ostatecznego uporządkowania tych spraw.
###### **Hbr 9,11**
 Natomiast Chrystus, arcykapłan dóbr obecnych, wszedł raz na zawsze do miejsca poświęconego Bogu przez lepszy, doskonalszy namiot, nie sporządzony ręką, to znaczy nie należący do świata doczesnych stworzeń.
###### **Hbr 9,12**
 Wszedł z własną krwią, a nie z krwią koźląt i cieląt, i osiągnął wieczne odkupienie.
###### **Hbr 9,13**
 Jeśli już pokropienie krwią koźląt i cieląt, oraz popiołem jałówki uświęca skalanych, dając im oczyszczenie zewnętrzne,
###### **Hbr 9,14**
 to tym bardziej krew Chrystusa, który potęgą ducha wieczystego złożył w ofierze Bogu samego siebie nieskalanego, oczyści nasze sumienie od uczynków martwych, abyśmy oddawali cześć Bogu żyjącemu.
###### **Hbr 9,15**
 Dlatego też jest pośrednikiem nowego "testamentu", aby ci, którzy zostali powołani do dziedzictwa wiecznego, otrzymali obietnicę, poniósł bowiem śmierć dla odkupienia wykroczeń popełnionych za czasów pierwszego "testamentu".
###### **Hbr 9,16**
 Przecież tam, gdzie chodzi o testament, trzeba, żeby ten, który go sporządził, umarł.
###### **Hbr 9,17**
 Testament staje się prawomocny ze śmiercią, nigdy bowiem nie ma mocy, gdy żyje ten, który go sporządził.
###### **Hbr 9,18**
 Stąd też i poprzedni nabrał mocy przez krew.
###### **Hbr 9,19**
 Kiedy Mojżesz odczytał całemu ludowi wszystkie przepisy Prawa, wziąwszy krew cieląt z wodą, wełnę szkarłatną i hizop skropił samą księgę i cały lud,
###### **Hbr 9,20**
 mówiąc: "To jest krew testamentu, który jest dla was Bożym przykazaniem".
###### **Hbr 9,21**
 W ten sposób skropił również namiot i wszystkie sprzęty używane w służbie Bożej.
###### **Hbr 9,22**
 Powiedziałbym, że według Prawa wszystko oczyszcza się krwią, a bez przelania krwi nie ma odpuszczenia.
###### **Hbr 9,23**
 Jeżeli więc trzeba było oczyszczać samo tylko wyobrażenie tego, co jest w niebie, to o ileż większych ofiar wymaga to sanktuarium, co jest w niebie.
###### **Hbr 9,24**
 Chrystus bowiem nie wszedł do świętego namiotu, który sporządziły ludzkie ręce jako namiastkę tego prawdziwego, ale wszedł do samego nieba. Teraz oręduje za nami przed Bogiem.
###### **Hbr 9,25**
 I nie wchodzi co roku do miejsca świętego z cudzą krwią jak arcykapłan po to, aby wielokrotnie ofiarowywać samego siebie.
###### **Hbr 9,26**
 W takim razie musiałby bowiem wielokrotnie cierpieć od założenia świata. Lecz On pojawił się tylko jeden raz, kiedy wypełniły się czasy, aby pozbawić grzech mocy przez swoją ofiarę.
###### **Hbr 9,27**
 Podobnie jak ludzie muszą raz umrzeć, a potem następuje sąd,
###### **Hbr 9,28**
 tak i Chrystus jeden raz ofiarował się, aby wziąć na siebie grzechy wielu. Ukaże się po raz drugi już nie w związku z grzechem, ale dla zbawienia tych, którzy pilnie Go wyczekują.
# Hbr 9 BR
###### **Hbr 9,1**
 Pierwsze przymierze - czemu nie można zaprzeczyć - również zawierało przepisy dotyczące służby Bożej; miało też swój ziemski przybytek.
###### **Hbr 9,2**
 Był nim namiot, w którego pierwszej części, zwanej [Miejscem] Świętym, znajdował się świecznik, stół i chleby pokładne.
###### **Hbr 9,3**
 Dalej, za drugą zasłoną, znajdował się przybytek zwany inaczej [Miejscem] Świętym Świętych.
###### **Hbr 9,4**
 Był tam ołtarz kadzenia, cały ze złota, i Arka Przymierza również cała pokryta złotem. W arce było przechowywane naczynie złote z manną, laska Aarona, która cudownie ongiś zakwitła i tablice Przymierza.
###### **Hbr 9,5**
 Nad arką unosiły się cherubiny chwały, osłaniając przebłagalnię. Ale o tym nie muszę tu szczegółowo rozprawiać.
###### **Hbr 9,6**
 Wszystko zaś jest tak urządzone, że do pierwszej części przybytku wchodzą zawsze kapłani sprawujący świętą służbę.
###### **Hbr 9,7**
 Do drugiej części natomiast może wchodzić tylko arcykapłan, i to tylko raz w roku. Przynosi tam zawsze krew, którą składa w ofierze za grzechy własne i za wykroczenia całego ludu.
###### **Hbr 9,8**
 Duch Święty daje do zrozumienia w ten sposób, że jak długo istnieje pierwszy przybytek, tak długo nie jest jeszcze dostępne dla wszystkich wejście do Świętego Świętych.
###### **Hbr 9,9**
 Miejsce owo jest w rzeczywistości symbolem czasów obecnych, kiedy to składa się dary i ofiary, nie będące jednak w stanie udoskonalić w pełni duszy tego, który sprawuje kult Boży.
###### **Hbr 9,10**
 Chodzi bowiem jedynie o przepisy dotyczące ciała, pokarmów, napojów i różnych obmyć, [przepisy] obowiązujące tak długo, jak długo nie nastąpi doskonalszy porządek.
###### **Hbr 9,11**
 Kiedy zaś pojawił się Chrystus jako arcykapłan dóbr obiecanych, przeszedł przez przybytek większy, doskonalszy i uczyniony nie ręką ludzką - czyli nie przynależący do tego świata.
###### **Hbr 9,12**
 I wszedł raz na zawsze do [Miejsca] Świętego Świętych dokonawszy zbawienia wiecznego nie przez krew kozłów i wołów, lecz przez krew własną.
###### **Hbr 9,13**
 Jeżeli bowiem krew kozłów i wołów oraz popiół ze spalonej jałowicy po rzuceniu ich na nieczystych powodują oczyszczenie ciała,
###### **Hbr 9,14**
 to o ileż bardziej oczyści wasze sumienia z martwych uczynków i przygotuje do służenia Bogu żywemu krew tego Chrystusa, który przez Ducha wiecznego złożył Bogu samego siebie jako nieskalaną ofiarę.
###### **Hbr 9,15**
 Dlatego [Chrystus] jest pośrednikiem Nowego Przymierza: przez śmierć Jego poniesioną dla zgładzenia grzechów, popełnionych [przez ludzi] za czasów pierwszego przymierza, ci, którzy zostali wezwani do odziedziczenia dóbr wiecznych, mogą dostąpić wypełnienia się obietnic.
###### **Hbr 9,16**
 Lecz tam, gdzie wchodzi w grę testament, naprzód musi ponieść śmierć ten, który testament sporządził.
###### **Hbr 9,17**
 Testament bowiem staje się prawomocny dopiero po śmierci tego, kto go sporządził, i przedtem nie posiada żadnego znaczenia.
###### **Hbr 9,18**
 Dlatego też Stary Testament również został ogłoszony przy udziale krwi.
###### **Hbr 9,19**
 Gdy bowiem Mojżesz ogłosił całemu ludowi wszystkie nakazy Prawa, wtedy wziął krew z wołów i kozłów, zmieszał ją z wodą, z wełną szkarłatną oraz z hizopem i pokropił zarówno księgę, jak i lud cały.
###### **Hbr 9,20**
 Wypowiedział przy tym słowa: To jest krew przymierza, które Bóg wam przekazuje [do przestrzegania].
###### **Hbr 9,21**
 Podobnie też pokropił Mojżesz krwią przybytek i wszystkie naczynia przeznaczone do służby Bożej.
###### **Hbr 9,22**
 Według przepisów Prawa prawie wszystko oczyszcza się krwią; odpuszczenie grzechów również nie może się dokonać bez rozlewu krwi.
###### **Hbr 9,23**
 W ten sposób oczyszcza się to wszystko, co jest jedynie obrazem rzeczy niebieskich, natomiast same rzeczy niebieskie domagały się ofiar o wiele bardziej doskonałych.
###### **Hbr 9,24**
 Chrystus wszedł bowiem nie do świątyni zbudowanej rękami ludzkimi, będącej jedynie [słabym] odbiciem świątyni prawdziwej; wszedł do samego nieba, aby teraz wstawiać się za nami u Boga,
###### **Hbr 9,25**
 a nie po to, aby składać ciągle na nowo ofiarę jak arcykapłan ziemski, który co roku wchodzi do świątyni z krwią cudzą.
###### **Hbr 9,26**
 W przeciwnym razie musiałby cierpieć po wielokroć od początku świata. A wiadomo przecież, że pojawił się właśnie teraz u kresu czasów, i to jeden raz tylko, żeby zgładzić grzechy ludzkie przez ofiarę, jaką złożył z samego siebie.
###### **Hbr 9,27**
 I podobnie jak człowiekowi postanowiono raz umrzeć, a potem pójść na sąd,
###### **Hbr 9,28**
 tak też i Chrystus raz jeden został złożony w ofierze dla zgładzenia grzechów wielu ludzi, by następnie ukazać się ponownie, ale już nie dla [sprawy zgładzenia] grzechu, lecz dla zbawienia tych, którzy oczekują na Jego przyjście.
# Hbr 9 WUJ
###### **Hbr 9,1**
 Miałci i pierwszy, usprawiedliwienia służby bożej i świątnicę świecką.
###### **Hbr 9,2**
 Abowiem sprawiony był przybytek pierwszy, w którym były lichtarze, i stół, i położenie chlebów, które zową święte.
###### **Hbr 9,3**
 A za wtóra zasłona, przybytek, który zową święte świętych:
###### **Hbr 9,4**
 Mając złotą kadzidlnicę, i skrzynię testamentu ze wszystkich stron złotem powleczoną: w której wiadro złote mające mannę, i laska Aaronowa, która zakwitnęła, i tablice testamentu,
###### **Hbr 9,5**
 A nad nią były Cherubim chwały zacimiającej ubłagalnicę, o czem teraz nie trzeba z osobna mówić.
###### **Hbr 9,6**
 A gdy to tak było sporządzono, do pierwszego przybytku zawsze wchadzali kapłani, urzędy ofiar odprawujący.
###### **Hbr 9,7**
 Ale do wtórego raz w rok sam nawyższy kapłan, nie bez krwie, którą ofiaruje za swą i ludu niewiadomość.
###### **Hbr 9,8**
 To dając znać Duch święty, iż jeszcze nie była objawiona droga świętych, póki jeszcze stał pierwszy przybytek.
###### **Hbr 9,9**
 Co jest podobieństwem teraźniejszego czasu: wedle którego dary i ofiary ofiarowane bywają, które nie mogą wedle sumnienia doskonałym uczynić służącego Bogu,
###### **Hbr 9,10**
 Gdyż są tylko w pokarmiech i w napojach, i w różnych omywaniach, i sprawiedliwościach ciała aż do czasu naprawienia stanowione.
###### **Hbr 9,11**
 Ale Chrystus stawiwszy się nawyższym kapłanem dóbr przyszłych przez więtszy i doskonalszy przybytek nie ręką uczyniony, to jest, nie tego stworzenia:
###### **Hbr 9,12**
 Ani przez krew kozłów abo cielców, ale przez własną krew wszedł raz do Świątnice, nalazszy wieczne odkupienie.
###### **Hbr 9,13**
 Abowiem jeśli krew kozłów i wołów i popiół jałowice pokropiony, splugawione poświąca ku oczyścieniu ciała:
###### **Hbr 9,14**
 Jako daleko więcej krew Chrystusowa, który przez Ducha świętego samego siebie ofiarował niepokalanym Bogu, oczyści sumnienie nasze od martwych uczynków, ku służeniu Bogu żywiącemu?
###### **Hbr 9,15**
 I dla tego jest nowego testamentu pośrednikiem, żeby za przystąpieniem śmierci, na odkupienie występków tych, które były pod pierwszym testamentem, obietnicę wzięli, którzy wezwani są wiecznego dziedzictwa.
###### **Hbr 9,16**
 Abowiem gdzie testament jest, musi przystąpić śmierć tego, który testament czyni.
###### **Hbr 9,17**
 Bo testament w umarłych potwierdzony jest: inaczej jeszcze nie jest ważny, póki żyw który, testament uczynił.
###### **Hbr 9,18**
 Zkąd ani pierwszy bez krwie nie był poświęcony.
###### **Hbr 9,19**
 Abowiem, gdy Mojżesz wszystko przykazanie zakonne przeczytał wszemu ludowi: wziąwszy krew cielców i kozłów z wodą i wełną szarłatową i Izopem: same też księgi i lud wszystek pokropił,
###### **Hbr 9,20**
 Mówiąc: Ta krew testamentu, który do was Bóg nakazał.
###### **Hbr 9,21**
 Ktemu i przybytek i wszystko naczynie służby krwią takież pokropił.
###### **Hbr 9,22**
 A niemal wszystko we krwi według zakonu bywa oczyściono: a bez rozlania krwie nie bywa odpuszczenie.
###### **Hbr 9,23**
 Potrzeba tedy jest, aby wizerunki rzeczy niebieskich, temi były oczyścione: a same niebieskie, lepszemi ofiarami niźli te.
###### **Hbr 9,24**
 Abowiem Chrystus nie wszedł do świątynie ręką uczynionej, która była wizerunkiem prawdziwej: ale do samego nieba, aby się teraz okazował przed oblicznością Bożą za nami.
###### **Hbr 9,25**
 A nie iżby często ofiarował samego siebie, jako nawyższy kapłan wchodzi do Świątynie co rok ze krwią cudzą:
###### **Hbr 9,26**
 Inaczej trzeba mu było często cierpieć od początku świata: lecz teraz na skończeniu wieków raz się okazał ku zgładzeniu grzechu, przez ofiarę samego siebie.
###### **Hbr 9,27**
 A jako postanowiono ludziom raz umrzeć, a potem sąd.
###### **Hbr 9,28**
 Tak i Chrystus raz jest ofiarowan, aby grzechy wielu wyniszczył: drugi raz bez grzechu okaże się tym, którzy go oczekawają, ku zbawieniu.
# Hbr 9 STERN
###### **Hbr 9,1**
 A pierwsze przymierze miało zarówno przepisy dotyczące kultu, jak i Miejsce Święte tu na ziemi.
###### **Hbr 9,2**
 Postawiono namiot, zewnętrzny, który nazwano Miejscem Świętym. W środku była menora, stół i Chleb Obecności.
###### **Hbr 9,3**
 Za drugą zasłoną - parochetem - był namiot zwany Miejscem Najświętszym,
###### **Hbr 9,4**
 mający złoty ołtarz do palenia kadzidła i Arkę Przymierza całkowicie pokrytą złotem. W Arce był złoty pojemnik z manną, laska Aharona, która zakwitła, i kamienne Tablice Przymierza;
###### **Hbr 9,5**
 nad nią zaś byli k'ruwim reprezentujący Sz'chinę, którzy rzucali cień na wieko Arki - lecz nie czas teraz na szczegółowe omawianie tych rzeczy.
###### **Hbr 9,6**
 Przy takim układzie rzeczy kohanim przez cały czas wchodzą do zewnętrznego namiotu, aby wypełniać swe obowiązki;
###### **Hbr 9,7**
 lecz tylko kohen hagadol wchodzi do wewnętrznego, i to wchodzi tylko raz w roku, i zawsze musi wnosić krew, którą ofiarowuje zarówno za siebie, jak i za grzechy popełnione z niewiedzy przez lud.
###### **Hbr 9,8**
 Przez takie uporządkowanie Ruach Ha-Kodesz pokazywał, że dopóki obowiązywał pierwszy Namiot, droga do Miejsca Najświętszego była wciąż zamknięta.
###### **Hbr 9,9**
 Symbolizuje to wiek obecny i wskazuje, że sumienie osoby pełniącej służbę nie może być doprowadzone do celu poprzez dary i ofiary, jakie składa.
###### **Hbr 9,10**
 Bo opierają się one tylko na pokarmie i napoju oraz na rozmaitych obmyciach rytualnych - na przepisach dotyczących życia zewnętrznego, narzuconych aż do czasu, gdy Bóg nada całej strukturze nowy kształt.
###### **Hbr 9,11**
 Kiedy jednak pojawił się Mesjasz jako kohen gadol dóbr, które już następują, wtedy przez Namiot większy i doskonalszy, nieuczyniony przez człowieka (czyli niepochodzący z tego stworzonego świata),
###### **Hbr 9,12**
 wszedł On raz na zawsze do Miejsca Najświętszego. A wszedł nie przez krew kozłów i cieląt, ale przez swoją własną krew, wyzwalając w ten sposób ludzi na wieki.
###### **Hbr 9,13**
 Bo jeśli skrapianie osób rytualnie nieczystych krwią kozłów i cielców i popiołem z jałówki przywraca im zewnętrzną czystość,
###### **Hbr 9,14**
 to o ileż bardziej krew Mesjasza, który przez Ducha wiecznego ofiarował siebie Bogu jako ofiarę bez skazy, oczyści nasze sumienia od dzieł wiodących do śmierci, abyśmy mogli służyć żywemu Bogu!
###### **Hbr 9,15**
 To na podstawie tej śmierci jest On pośrednikiem nowego przymierza [lub testamentu]. Ponieważ nastąpiła śmierć, która wyzwała ludzi z przewinień popełnionych pod pierwszym przymierzem, ci, którzy zostali powołani, mogą otrzymać obiecane wieczne dziedzictwo.
###### **Hbr 9,16**
 Bo tam, gdzie jest testament, tam musi być koniecznie okazany dowód śmierci jego autora,
###### **Hbr 9,17**
 ponieważ testament nabiera mocy dopiero z chwilą śmierci; nigdy nie obowiązuje, póki jego autor jeszcze żyje.
###### **Hbr 9,18**
 Dlatego pierwsze przymierze również zostało zapoczątkowane krwią.
###### **Hbr 9,19**
 Gdy Mosze ogłosił całemu ludowi wszystkie nakazy Tory, wziął krew cieląt i nieco wody i przy użyciu wełny szkarłatnej i hizopu skropił zarówno sam zwój, jak i cały lud;
###### **Hbr 9,20**
 i rzekł: "Oto krew przymierza, które Bóg dk was ustanowił".
###### **Hbr 9,21**
 Podobnie skropił krwią zarówno Namiot, jak i wszystko, czego się używa podczas obrzędów z nim związanych.
###### **Hbr 9,22**
 W rzeczy samej, według Tory prawie wszystko oczyszcza się krwią, a bez przelania krwi nie ma przebaczenia grzechów.
###### **Hbr 9,23**
 W ten sposób musiały być oczyszczane kopie rzeczy niebieskich, lecz same rzeczy niebieskie wymagają lepszych ofiar niż tamte.
###### **Hbr 9,24**
 Bo Mesjasz wszedł do takiego Miejsca Najświętszego, które nie jest dziełem ludzkim i jedynie kopią tego prawdziwego, lecz do samego nieba, aby teraz stanąć w naszym imieniu przed obliczem samego Boga.
###### **Hbr 9,25**
 Ponadto nie wszedł On do nieba, aby składać siebie na ofiarę raz za razem, jak kohen hagadol rok w rok wchodzący do Miejsca Najświętszego z krwią, która nie jest jego własną krwią;
###### **Hbr 9,26**
 wówczas bowiem musiałby ponosić śmierć wiele razy, poczynając od założenia wszechświata. Lecz w takiej sytuacji objawił się On jeden raz u kresu wieków, aby zgładzić grzech przez ofiarowanie samego siebie.
###### **Hbr 9,27**
 Tak jak ludzie muszą umrzeć jeden raz, a potem przychodzi sąd,
###### **Hbr 9,28**
 tak i Mesjasz, raz będąc złożonym w ofierze, aby ponieść grzechy wielu, pojawi się po raz drugi, już nie żeby zgładzić grzech, ale aby wyzwolić tych, którzy żarliwie Go wyczekują.
# Hbr 9 TRO
###### **Hbr 9,1**
 **ειχεν** *eichen* Miało [[G2192]] WTV-IAI-3S **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **ουν** *oun* więc [[G3767]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **πρωτη** *prōtē* pierwsze [[G4413]] WTA-NSF **δικαιωματα** *dikaiōmata* przepisy – rozporządzenia [[G1345]] WTN-APN **λατρειας** *latreias* służby – aktu kultu [[G2999]] [[N-GSF]] **το** *to* [[G3588]] WTT-NSN **τε** *te* zarówno – także [[G5037]] WTPRT **αγιον** *hagion* święte [[G39]] WTA-NSN **κοσμικον** *kosmikon* światowe – doczesne [[G2886]] WTA-ASN
###### **Hbr 9,2**
 **σκηνη** *skēnē* Namiot – Przybytek [[G4633]] [[N-NSF]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **κατεσκευασθη** *kateskeuasthē* został zbudowany – został przygotowany [[G2680]] [[V-API-3S]] **η** *hē* [[G3588]] [[T-NSF]] **πρωτη** *prōtē* pierwszy [[G4413]] WTA-NSF **εν** *en* w [[G1722]] [[PREP]] **η** *hē* którym [[G3739]] WTR-DSF **η** *hē* [[G3588]] [[T-NSF]] **τε** *te* zarówno – także [[G5037]] WTPRT **λυχνια** *lychnia* świecznik – stojak lampy [[G3087]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **τραπεζα** *trapeza* stół [[G5132]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **προθεσις** *prothesis* przedkładanie [[G4286]] [[N-NSF]] **των** *tōn* [[G3588]] WTT-GPM **αρτων** *artōn* chlebów [[G740]] WTN-GPM **ητις** *hētis* które [[G3748]] WTR-NSF **λεγεται** *legetai* jest nazywany [[G3004]] WTV-PPI-3S **αγια** *hagia* Święte [[G39]] WTA-NSF
###### **Hbr 9,3**
 **μετα** *meta* za [[G3326]] [[PREP]] **δε** *de* zaś [[G1161]] [[CONJ]] **το** *to* [[G3588]] WTT-ASN **δευτερον** *deuteron* drugą [[G1208]] WTA-ASN **καταπετασμα** *katapetasma* zasłoną [[G2665]] WTN-ASN **σκηνη** *skēnē* namiot – przybytek [[G4633]] [[N-NSF]] **η** *hē* [[G3588]] [[T-NSF]] **λεγομενη** *legomenē* który jest nazywany [[G3004]] WTV-PPP-NSF **αγια** *hagia* Święte [[G39]] WTA-NSF **αγιων** *hagiōn* Świętych [[G39]] WTA-GPN
###### **Hbr 9,4**
 **χρυσουν** *chrysoun* złotą [[G5552]] WTA-ASN **εχουσα** *echousa* mająca [[G2192]] [[V-PAP-NSF]] **θυμιατηριον** *thymiatērion* kadzielnicę – ołtarz kadzenia [[G2369]] WTN-ASN **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **κιβωτον** *kibōton* arkę – drewnianą skrzynię [[G2787]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **διαθηκης** *diathēkēs* przymierza [[G1242]] [[N-GSF]] **περικεκαλυμμενην** *perikekalymmenēn* która jest zakrywana – która jest zasłonięta [[G4028]] WTV-RPP-ASF **παντοθεν** *pantothen* zewsząd [[G3840]] [[ADV]] **χρυσιω** *chrysiō* złotem [[G5553]] WTN-DSN **εν** *en* w [[G1722]] [[PREP]] **η** *hē* której [[G3739]] WTR-DSF **σταμνος** *stamnos* dzban – słoik [[G4713]] [[A-NSM]] **χρυση** *chrysē* złoty [[G5552]] WTA-NSF **εχουσα** *echousa* mający [[G2192]] [[V-PAP-NSF]] **το** *to* [[G3588]] WTT-ASN **μαννα** *manna* mannę – [co to jest?] [[G3131]] WTHEB **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **ραβδος** *rabdos* laska [[G4464]] [[N-NSF]] **ααρων** *aarōn* Aarona – [wywyższony] [[G2]] [[N-PRI]] **η** *hē* [[G3588]] [[T-NSF]] **βλαστησασα** *blastēsasa* która zakwitła – która wypuściła pączki [[G985]] WTV-AAP-NSF **και** *kai* i [[G2532]] [[CONJ]] **αι** *hai* [[G3588]] [[T-NPF]] **πλακες** *plakes* tablice – płyty [[G4109]] [[N-NPF]] **της** *tēs* [[G3588]] [[T-GSF]] **διαθηκης** *diathēkēs* przymierza [[G1242]] [[N-GSF]]
###### **Hbr 9,5**
 **υπερανω** *hyperanō* powyżej [[G5231]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **αυτης** *autēs* niej [[G846]] [[P-GSF]] **χερουβιμ** *cheroubim* cherubiny [[G5502]] [[N-PRI]] **δοξης** *doksēs* chwały [[G1391]] [[N-GSF]] **κατασκιαζοντα** *kataskiazonta* zacieniające – osłaniające [[G2683]] WTV-PAP-NPN **το** *to* [[G3588]] WTT-ASN **ιλαστηριον** *hilastērion* ofiarę przebłagalną [[G2435]] WTN-ASN **περι** *peri* o [[G4012]] [[PREP]] **ων** *hōn* których [[G3739]] WTR-GPN **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **νυν** *nyn* teraz [[G3568]] [[ADV]] **λεγειν** *legein* mówić [[G3004]] WTV-PAN **κατα** *kata* po – według [[G2596]] [[PREP]] **μερος** *meros* części [[G3313]] WTN-ASN
###### **Hbr 9,6**
 **τουτων** *toutōn* Te [[G5130]] WTD-GPM **δε** *de* zaś [[G1161]] [[CONJ]] **ουτως** *houtōs* tak [[G3779]] [[ADV]] **κατεσκευασμενων** *kateskeuasmenōn* które są zbudowane – które są przygotowane [[G2680]] WTV-RPP-GPM **εις** *eis* do [[G1519]] [[PREP]] **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **την** *tēn* [[G3588]] WTT-ASF **πρωτην** *prōtēn* pierwszego [[G4413]] WTA-ASF **σκηνην** *skēnēn* namiotu – przybytku [[G4633]] WTN-ASF **διαπαντος** *diapantos* przez każdy – przez cały [[G1275]] [[ADV]] **εισιασιν** *eisiasin* wchodzą [[G1524]] WTV-PXI-3P **οι** *hoi* [[G3588]] WTT-NPM **ιερεις** *hiereis* kapłani [[G2409]] WTN-NPM **τας** *tas* [[G3588]] WTT-APF **λατρειας** *latreias* służby – akty kultu [[G2999]] WTN-APF **επιτελουντες** *epitelountes* wypełniający – spełniający [[G2005]] WTV-PAP-NPM
###### **Hbr 9,7**
 **εις** *eis* do [[G1519]] [[PREP]] **δε** *de* zaś [[G1161]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **δευτεραν** *deuteran* drugiego [[G1208]] WTA-ASF **απαξ** *hapaks* raz [[G530]] [[ADV]] **του** *tou* (w) [[G3588]] WTT-GSM **ενιαυτου** *eniautou* roku [[G1763]] [[N-GSM]] **μονος** *monos* sam – jedyny [[G3441]] [[A-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **αρχιερευς** *archiereus* arcykapłan [[G749]] [[N-NSM]] **ου** *ou* nie [[G3756]] [[PRT-N]] **χωρις** *chōris* bez [[G5565]] [[ADV]] **αιματος** *haimatos* krwi [[G129]] [[N-GSN]] **ο** *ho* którą [[G3739]] WTR-ASN **προσφερει** *prosferei* przynosi – ofiaruje [[G4374]] WTV-PAI-3S **υπερ** *hyper* za [[G5228]] [[PREP]] **εαυτου** *heautou* swoje [[G1438]] WTF-3GSM **και** *kai* i [[G2532]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPN **του** *tou* [[G3588]] WTT-GSM **λαου** *laou* ludu [[G2992]] [[N-GSM]] **αγνοηματων** *agnoēmatōn* grzechy popełnione nieświadomie – błędy niewiedzy [[G51]] WTN-GPN
###### **Hbr 9,8**
 **τουτο** *touto* to [[G5124]] WTD-ASN **δηλουντος** *dēlountos* oznajmiając – ukazując [[G1213]] WTV-PAP-GSN **του** *tou* (przez) [[G3588]] WTT-GSN **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **του** *tou* [[G3588]] WTT-GSN **αγιου** *hagiou* Świętego [[G40]] [[A-GSN]] **μηπω** *mēpō* (że) jeszcze nie [[G3380]] [[ADV]] **πεφανερωσθαι** *pefanerōsthai* być objawiona – być uczyniona widoczą [[G5319]] WTV-RPN **την** *tēn* [[G3588]] WTT-ASF **των** *tōn* [[G3588]] WTT-GPN **αγιων** *hagiōn* świętych [[G39]] WTA-GPN **οδον** *hodon* droga [[G3598]] WTN-ASF **ετι** *eti* jeszcze [[G2089]] [[ADV]] **της** *tēs* [[G3588]] [[T-GSF]] **πρωτης** *prōtēs* pierwszy [[G4413]] WTA-GSF **σκηνης** *skēnēs* namiot – przybytek [[G4633]] [[N-GSF]] **εχουσης** *echousēs* mając [[G2192]] WTV-PAP-GSF **στασιν** *stasin* miejsce postoju [[G4714]] WTN-ASF
###### **Hbr 9,9**
 **ητις** *hētis* który [[G3748]] WTR-NSF **παραβολη** *parabolē* przykład – porównanie [[G3850]] [[N-NSF]] **εις** *eis* do [[G1519]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **καιρον** *kairon* pory [[G2540]] [[N-ASM]] **τον** *ton* [[G3588]] [[T-ASM]] **ενεστηκοτα** *enestēkota* która nastała [[G1764]] WTV-RAP-ASM **καθ** *kath* według [[G2596]] [[PREP]] **ον** *hon* czego [[G3739]] WTR-ASM **δωρα** *dōra* dary – dary ofiarne [[G1435]] WTN-NPN **τε** *te* zarówno – także [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **θυσιαι** *thysiai* ofiary [[G2378]] [[N-NPF]] **προσφερονται** *prosferontai* są przynoszone – są ofiarowane [[G4374]] WTV-PPI-3P **μη** *mē* nie [[G3361]] [[PRT-N]] **δυναμεναι** *dynamenai* mogące [[G1410]] WTV-PNP-NPF **κατα** *kata* według – co do [[G2596]] [[PREP]] **συνειδησιν** *syneidēsin* sumienia [[G4893]] WTN-ASF **τελειωσαι** *teleiōsai* uczynić doskonałymi – zostać doprowadzonymi do doskonałości [[G5048]] [[V-AAN]] **τον** *ton* [[G3588]] [[T-ASM]] **λατρευοντα** *latreuonta* pełniących służbę [[G3000]] WTV-PAP-ASM
###### **Hbr 9,10**
 **μονον** *monon* jedynie – tylko [[G3440]] [[ADV]] **επι** *epi* ku [[G1909]] [[PREP]] **βρωμασιν** *brōmasin* pokarmom [[G1033]] WTN-DPN **και** *kai* i [[G2532]] [[CONJ]] **πομασιν** *pomasin* napojom [[G4188]] WTN-DPN **και** *kai* i [[G2532]] [[CONJ]] **διαφοροις** *diaforois* różnym [[G1313]] WTA-DPM **βαπτισμοις** *baptismois* zanurzeniom – obmywaniom [[G909]] WTN-DPM **και** *kai* i [[G2532]] [[CONJ]] **δικαιωμασιν** *dikaiōmasin* przepisom – rozporządzeniom [[G1345]] WTN-DPN **σαρκος** *sarkos* ciała [[G4561]] [[N-GSF]] **μεχρι** *mechri* aż do [[G3360]] [[ADV]] **καιρου** *kairou* pory [[G2540]] [[N-GSM]] **διορθωσεως** *diorthōseōs* naprawy – poprawy [[G1357]] [[N-GSF]] **επικειμενα** *epikeimena* które są położone [[G1945]] WTV-PNP-NPN
###### **Hbr 9,11**
 **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **παραγενομενος** *paragenomenos* przybywszy [[G3854]] WTV-2ADP-NSM **αρχιερευς** *archiereus* arcykapłan [[G749]] [[N-NSM]] **των** *tōn* [[G3588]] WTT-GPN **μελλοντων** *mellontōn* zmierzający – będący blisko [[G3195]] WTV-PAP-GPN **αγαθων** *agathōn* dóbr [[G18]] WTA-GPN **δια** *dia* przez [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **μειζονος** *meizonos* większy [[G3173]] WTA-GSF-C **και** *kai* i [[G2532]] [[CONJ]] **τελειοτερας** *teleioteras* doskonalszy – dojrzalszy [[G5046]] WTA-GSF-C **σκηνης** *skēnēs* namiot – przybytek [[G4633]] [[N-GSF]] **ου** *ou* nie [[G3756]] [[PRT-N]] **χειροποιητου** *cheiropoiētou* ręką uczyniony [[G5499]] WTA-GSF **τουτ** *tout* to [[G5124]] WTD-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ου** *ou* nie [[G3756]] [[PRT-N]] **ταυτης** *tautēs* tego [[G3778]] WTD-GSF **της** *tēs* [[G3588]] [[T-GSF]] **κτισεως** *ktiseōs* stworzenia [[G2937]] [[N-GSF]]
###### **Hbr 9,12**
 **ουδε** *oude* ani [[G3761]] [[ADV]] **δι** *di* przez [[G1223]] [[PREP]] **αιματος** *haimatos* krew [[G129]] [[N-GSN]] **τραγων** *tragōn* kozłów [[G5131]] WTN-GPM **και** *kai* i [[G2532]] [[CONJ]] **μοσχων** *moschōn* cieląt [[G3448]] WTN-GPM **δια** *dia* przez [[G1223]] [[PREP]] **δε** *de* zaś [[G1161]] [[CONJ]] **του** *tou* [[G3588]] WTT-GSN **ιδιου** *idiou* własną [[G2398]] WTA-GSM **αιματος** *haimatos* krew [[G129]] [[N-GSN]] **εισηλθεν** *eisēlthen* wszedł [[G1525]] WTV-2AAI-3S **εφαπαξ** *efapaks* raz na zawsze [[G2178]] [[ADV]] **εις** *eis* do [[G1519]] [[PREP]] **τα** *ta* [[G3588]] WTT-APN **αγια** *hagia* świętych [[G39]] WTA-APN **αιωνιαν** *aiōnian* wieczne [[G166]] WTA-ASF **λυτρωσιν** *lytrōsin* odkupienie – wybawienie [[G3085]] WTN-ASF **ευραμενος** *heuramenos* znalazłszy [[G2147]] WTV-2AMP-NSM
###### **Hbr 9,13**
 **ει** *ei* Jeśli [[G1487]] WTCOND **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **αιμα** *haima* krew [[G129]] WTN-NSN **ταυρων** *taurōn* byków – wołów [[G5022]] WTN-GMP **και** *kai* i [[G2532]] [[CONJ]] **τραγων** *tragōn* kozłów [[G5131]] WTN-GPM **και** *kai* i [[G2532]] [[CONJ]] **σποδος** *spodos* popiół [[G4700]] [[N-NSF]] **δαμαλεως** *damaleōs* jałówki [[G1151]] [[N-GSF]] **ραντιζουσα** *rantizousa* obsypując – pokrapiając [[G4472]] [[V-PAP-NSF]] **τους** *tous* [[G3588]] WTT-APM **κεκοινωμενους** *kekoinōmenous* które są uczynione pospolitymi – którzy są uczynieni nieczystymi [[G2840]] WTV-RPP-APM **αγιαζει** *hagiazei* uświęca – poświęca [[G37]] WTV-PAI-3S **προς** *pros* ku [[G4314]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **της** *tēs* [[G3588]] [[T-GSF]] **σαρκος** *sarkos* ciała [[G4561]] [[N-GSF]] **καθαροτητα** *katharotēta* czystości [[G2514]] WTN-ASF
###### **Hbr 9,14**
 **ποσω** *posō* jak wielce – o ileż [[G4214]] WTQ-DSN **μαλλον** *mallon* bardziej [[G3123]] [[ADV]] **το** *to* [[G3588]] WTT-NSN **αιμα** *haima* krew [[G129]] WTN-NSN **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **ος** *hos* który [[G3739]] WTR-NSM **δια** *dia* przez [[G1223]] [[PREP]] **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **αιωνιου** *aiōniou* wiecznego [[G166]] [[A-GSN]] **εαυτον** *heauton* siebie samego [[G1438]] WTF-3ASM **προσηνεγκεν** *prosēnegken* przyniósł – ofiarował [[G4374]] [[V-AAI-3S]] **αμωμον** *amōmon* nienagannego – niewinnego [[G299]] WTA-ASM **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **καθαριει** *kathariei* oczyści [[G2511]] WTV-FAI-3S-ATT **την** *tēn* [[G3588]] WTT-ASF **συνειδησιν** *syneidēsin* sumienie [[G4893]] WTN-ASF **υμων** *hymōn* wasze [[G5216]] WTP-2GP **απο** *apo* od [[G575]] [[PREP]] **νεκρων** *nekrōn* martwych [[G3498]] WTA-GPN **εργων** *ergōn* czynów – dzieł [[G2041]] WTN-GPN **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **λατρευειν** *latreuein* służyć [[G3000]] WTV-PAN **θεω** *theō* Bogu [[G2316]] WTN-DSM **ζωντι** *zōnti* żyjącemu [[G2198]] WTV-PAP-DSM
###### **Hbr 9,15**
 **και** *kai* i [[G2532]] [[CONJ]] **δια** *dia* przez [[G1223]] [[PREP]] **τουτο** *touto* to [[G5124]] WTD-ASN **διαθηκης** *diathēkēs* przymierza [[G1242]] [[N-GSF]] **καινης** *kainēs* nowego [[G2537]] WTA-GSF **μεσιτης** *mesitēs* pośrednik [[G3316]] [[N-NSM]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **οπως** *hopōs* żeby [[G3704]] [[ADV]] **θανατου** *thanatou* śmierci [[G2288]] [[N-GSM]] **γενομενου** *genomenou* która stała się [[G1096]] WTV-2ADP-GSM **εις** *eis* ku [[G1519]] [[PREP]] **απολυτρωσιν** *apolytrōsin* odkupieniu [[G629]] WTN-ASF **των** *tōn* (od tych) [[G3588]] WTT-GPF **επι** *epi* w [[G1909]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **πρωτη** *prōtē* pierwszym [[G4413]] WTA-DSF **διαθηκη** *diathēkē* przymierzu [[G1242]] [[N-DSF]] **παραβασεων** *parabaseōn* przestępstw [[G3847]] WTN-GPF **την** *tēn* [[G3588]] WTT-ASF **επαγγελιαν** *epangelian* obietnicę [[G1860]] WTN-ASF **λαβωσιν** *labōsin* wzięliby – otrzymaliby [[G2983]] WTV-2AAS-3P **οι** *hoi* [[G3588]] WTT-NPM **κεκλημενοι** *keklēmenoi* którzy są zaproszeni – którzy są wezwani [[G2564]] WTV-RPP-NPM **της** *tēs* [[G3588]] [[T-GSF]] **αιωνιου** *aiōniou* wiecznego [[G166]] WTA-GSF **κληρονομιας** *klēronomias* dziedziczenia [[G2817]] [[N-GSF]]
###### **Hbr 9,16**
 **οπου** *hopou* Gdzie – Dokąd [[G3699]] [[ADV]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **διαθηκη** *diathēkē* przymierze [[G1242]] [[N-NSF]] **θανατον** *thanaton* śmierci [[G2288]] [[N-ASM]] **αναγκη** *anagkē* konieczność – przymus [[G318]] [[N-NSF]] **φερεσθαι** *feresthai* (by) być przynoszonym – (by) być przyprowadzonym [[G5342]] WTV-PPN **του** *tou* (ten) [[G3588]] WTT-GSM **διαθεμενου** *diathemenou* który zawarł – który ułożył [[G1303]] WTV-2AMP-GSM
###### **Hbr 9,17**
 **διαθηκη** *diathēkē* przymierze [[G1242]] [[N-NSF]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **επι** *epi* przy [[G1909]] [[PREP]] **νεκροις** *nekrois* martwym [[G3498]] WTA-DPM **βεβαια** *bebaia* mocne [[G949]] WTA-NSF **επει** *epei* skoro – jako, że [[G1893]] [[CONJ]] **μηποτε** *mēpote* jeszcze nie – nie wtedy [[G3379]] [[ADV]] **ισχυει** *ischyei* jest silne [[G2480]] WTV-PAI-3S **οτε** *hote* gdy [[G3753]] [[ADV]] **ζη** *zē* żyje [[G2198]] WTV-PAI-3S **ο** *ho* (ten) [[G3588]] [[T-NSM]] **διαθεμενος** *diathemenos* który zawarł – który ułożył [[G1303]] WTV-2AMP-NSM
###### **Hbr 9,18**
 **οθεν** *hothen* Dlatego – Stąd [[G3606]] [[ADV]] **ουδ** *oud* ani [[G3761]] [[ADV]] **η** *hē* [[G3588]] [[T-NSF]] **πρωτη** *prōtē* pierwsze [[G4413]] WTA-NSF **χωρις** *chōris* bez [[G5565]] [[ADV]] **αιματος** *haimatos* krwi [[G129]] [[N-GSN]] **εγκεκαινισται** *egkekainistai* jest poświęcone – jest odnowione [[G1457]] WTV-RPI-3S
###### **Hbr 9,19**
 **λαληθεισης** *lalētheisēs* gdy zostało powiedziane [[G2980]] [[V-APP-GSF]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **πασης** *pasēs* każde [[G3956]] WTA-GSF **εντολης** *entolēs* przykazanie [[G1785]] [[N-GSF]] **κατα** *kata* według [[G2596]] [[PREP]] **νομον** *nomon* Prawa [[G3551]] [[N-ASM]] **υπο** *hypo* przez [[G5259]] [[PREP]] **μωυσεως** *mōuseōs* Mojżesza – [wyciągnąć] [[G3475]] [[N-GSM]] **παντι** *panti* całemu [[G3956]] WTA-DSM **τω** *tō* [[G3588]] WTT-DSM **λαω** *laō* ludowi [[G2992]] WTN-DSM **λαβων** *labōn* wziąwszy [[G2983]] WTV-2AAP-NSM **το** *to* [[G3588]] WTT-ASN **αιμα** *haima* krew [[G129]] WTN-ASN **των** *tōn* [[G3588]] WTT-GPM **μοσχων** *moschōn* cieląt [[G3448]] WTN-GPM **και** *kai* i [[G2532]] [[CONJ]] **τραγων** *tragōn* kozłów [[G5131]] WTN-GPM **μετα** *meta* z [[G3326]] [[PREP]] **υδατος** *hydatos* wodą [[G5204]] [[N-GSN]] **και** *kai* i [[G2532]] [[CONJ]] **εριου** *eriou* wełną [[G2053]] [[N-GSN]] **κοκκινου** *kokkinou* szkarłatną [[G2847]] [[A-GSN]] **και** *kai* i [[G2532]] [[CONJ]] **υσσωπου** *hyssōpou* hizopem [[G5301]] [[N-GSM]] **αυτο** *auto* sam [[G846]] WTP-ASN **τε** *te* zarówno – także [[G5037]] WTPRT **το** *to* [[G3588]] WTT-ASN **βιβλιον** *biblion* zwój [[G975]] WTN-ASN **και** *kai* i [[G2532]] [[CONJ]] **παντα** *panta* cały [[G3956]] WTA-ASM **τον** *ton* [[G3588]] [[T-ASM]] **λαον** *laon* lud [[G2992]] [[N-ASM]] **ερραντισεν** *errantisen* pokropił – skropił [[G4472]] [[V-AAI-3S]]
###### **Hbr 9,20**
 **λεγων** *legōn* mówiąc [[G3004]] [[V-PAP-NSM]] **τουτο** *touto* to [[G5124]] WTD-NSN **το** *to* [[G3588]] WTT-NSN **αιμα** *haima* krew [[G129]] WTN-NSN **της** *tēs* [[G3588]] [[T-GSF]] **διαθηκης** *diathēkēs* przymierza [[G1242]] [[N-GSF]] **ης** *hēs* które [[G3739]] [[R-GSF]] **ενετειλατο** *eneteilato* przykazał [[G1781]] WTV-ADI-3S **προς** *pros* do – względem [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]]
###### **Hbr 9,21**
 **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **σκηνην** *skēnēn* namiot – przybytek [[G4633]] WTN-ASF **δε** *de* zaś [[G1161]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **παντα** *panta* wszystkie [[G3956]] WTA-APN **τα** *ta* [[G3588]] WTT-APN **σκευη** *skeuē* naczynia [[G4632]] WTN-APN **της** *tēs* [[G3588]] [[T-GSF]] **λειτουργιας** *leitourgias* publicznego dzieła – publicznej służby [[G3009]] [[N-GSF]] **τω** *tō* [[G3588]] WTT-DSN **αιματι** *haimati* krwią [[G129]] WTN-DSN **ομοιως** *homoiōs* podobnie [[G3668]] [[ADV]] **ερραντισεν** *errantisen* pokropił – skropił [[G4472]] [[V-AAI-3S]]
###### **Hbr 9,22**
 **και** *kai* i [[G2532]] [[CONJ]] **σχεδον** *schedon* prawie – niemal [[G4975]] [[ADV]] **εν** *en* w [[G1722]] [[PREP]] **αιματι** *haimati* krwi [[G129]] WTN-DSN **παντα** *panta* wszystkie [[G3956]] WTA-NPN **καθαριζεται** *katharizetai* jest oczyszczane [[G2511]] WTV-PPI-3S **κατα** *kata* według [[G2596]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **νομον** *nomon* Prawa [[G3551]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **χωρις** *chōris* bez [[G5565]] [[ADV]] **αιματεκχυσιας** *haimatekchysias* wylania krwi – przelania krwi [[G130]] [[N-GSF]] **ου** *ou* nie [[G3756]] [[PRT-N]] **γινεται** *ginetai* staje się [[G1096]] WTV-PNI-3S **αφεσις** *afesis* uwolnienie – wyzwolenie [[G859]] [[N-NSF]]
###### **Hbr 9,23**
 **αναγκη** *anagkē* Konieczność – Przymus [[G318]] [[N-NSF]] **ουν** *oun* więc [[G3767]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **υποδειγματα** *hypodeigmata* przykłady [[G5262]] WTN-APN **των** *tōn* (tych) [[G3588]] WTT-GPN **εν** *en* w [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPM **ουρανοις** *ouranois* niebiosach [[G3772]] WTN-DPM **τουτοις** *toutois* tymi [[G5125]] WTD-DPN **καθαριζεσθαι** *katharizesthai* być oczyszczane [[G2511]] WTV-PPN **αυτα** *auta* same [[G846]] WTP-APN **δε** *de* zaś [[G1161]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **επουρανια** *epourania* niebiańskie [[G2032]] WTA-APN **κρειττοσιν** *kreittosin* lepszych – znaczniejszych [[G2909]] WTA-DPF **θυσιαις** *thysiais* ofiarami [[G2378]] WTN-DPF **παρα** *para* od [[G3844]] [[PREP]] **ταυτας** *tautas* tych [[G3778]] WTD-APF
###### **Hbr 9,24**
 **ου** *ou* Nie [[G3756]] [[PRT-N]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εις** *eis* do [[G1519]] [[PREP]] **χειροποιητα** *cheiropoiēta* ręką uczynionych [[G5499]] WTA-APN **αγια** *hagia* świętych [[G39]] WTA-APN **εισηλθεν** *eisēlthen* wszedł [[G1525]] WTV-2AAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **αντιτυπα** *antitypa* odpowiedników – odbijających wzór [[G499]] WTA-APN **των** *tōn* [[G3588]] WTT-GPN **αληθινων** *alēthinōn* prawdziwych [[G228]] WTA-GPN **αλλ** *all* ale [[G235]] [[CONJ]] **εις** *eis* do [[G1519]] [[PREP]] **αυτον** *auton* samego [[G846]] WTP-ASM **τον** *ton* [[G3588]] [[T-ASM]] **ουρανον** *ouranon* nieba [[G3772]] [[N-ASM]] **νυν** *nyn* teraz [[G3568]] [[ADV]] **εμφανισθηναι** *emfanisthēnai* zostać objawione – zostać uczynione widoczne [[G1718]] WTV-APN **τω** *tō* [[G3588]] WTT-DSN **προσωπω** *prosōpō* obliczu – twarzy [[G4383]] WTN-DSN **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **υπερ** *hyper* w imieniu [[G5228]] [[PREP]] **ημων** *hēmōn* naszym [[G2257]] WTP-1GP
###### **Hbr 9,25**
 **ουδ** *oud* ani [[G3761]] [[ADV]] **ινα** *hina* aby [[G2443]] [[CONJ]] **πολλακις** *pollakis* wielokrotnie – częstokroć [[G4178]] [[ADV]] **προσφερη** *prosferē* przynosiłby – ofiarowywałby [[G4374]] WTV-PAS-3S **εαυτον** *heauton* siebie samego [[G1438]] WTF-3ASM **ωσπερ** *hōsper* tak, jak [[G5618]] [[ADV]] **ο** *ho* [[G3588]] [[T-NSM]] **αρχιερευς** *archiereus* arcykapłan [[G749]] [[N-NSM]] **εισερχεται** *eiserchetai* wchodzi [[G1525]] WTV-PNI-3S **εις** *eis* do [[G1519]] [[PREP]] **τα** *ta* [[G3588]] WTT-APN **αγια** *hagia* świętych [[G39]] WTA-APN **κατ** *kat* co [[G2596]] [[PREP]] **ενιαυτον** *eniauton* roku [[G1763]] [[N-ASM]] **εν** *en* we [[G1722]] [[PREP]] **αιματι** *haimati* krwi [[G129]] WTN-DSN **αλλοτριω** *allotriō* cudzej – obcej [[G245]] WTA-DSN
###### **Hbr 9,26**
 **επει** *epei* skoro – jako, że [[G1893]] [[CONJ]] **εδει** *edei* trzeba było – należało [[G1163]] WTV-IQI-3S **αυτον** *auton* Mu [[G846]] WTP-ASM **πολλακις** *pollakis* wielokrotnie – częstokroć [[G4178]] [[ADV]] **παθειν** *pathein* wycierpieć [[G3958]] [[V-2AAN]] **απο** *apo* od [[G575]] [[PREP]] **καταβολης** *katabolēs* założenia [[G2602]] [[N-GSF]] **κοσμου** *kosmou* świata [[G2889]] [[N-GSM]] **νυν** *nyn* teraz [[G3568]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **απαξ** *hapaks* raz [[G530]] [[ADV]] **επι** *epi* przy [[G1909]] [[PREP]] **συντελεια** *synteleia* końcu – spełnieniu się [[G4930]] [[N-DSF]] **των** *tōn* [[G3588]] WTT-GPM **αιωνων** *aiōnōn* wieków [[G165]] WTN-GPM **εις** *eis* ku [[G1519]] [[PREP]] **αθετησιν** *athetēsin* unieważnienie – odrzucenie [[G115]] WTN-ASF **αμαρτιας** *hamartias* grzechu [[G266]] [[N-GSF]] **δια** *dia* przez [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **θυσιας** *thysias* ofiarę [[G2378]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **πεφανερωται** *pefanerōtai* jest objawiony – jest uczyniony widocznym [[G5319]] WTV-RPI-3S
###### **Hbr 9,27**
 **και** *kai* I [[G2532]] [[CONJ]] **καθ** *kath* o [[G2596]] [[PREP]] **οσον** *hoson* ile – jak wiele [[G3745]] WTK-ASN **αποκειται** *apokeitai* jest odkładane – jest przechowywane [[G606]] WTV-PNI-3S **τοις** *tois* [[G3588]] WTT-DPM **ανθρωποις** *anthrōpois* ludziom [[G444]] WTN-DPM **απαξ** *hapaks* raz [[G530]] [[ADV]] **αποθανειν** *apothanein* umrzeć [[G599]] [[V-2AAN]] **μετα** *meta* po [[G3326]] [[PREP]] **δε** *de* zaś [[G1161]] [[CONJ]] **τουτο** *touto* tym [[G5124]] WTD-ASN **κρισις** *krisis* sąd [[G2920]] [[N-NSF]]
###### **Hbr 9,28**
 **ουτως** *houtōs* tak [[G3779]] [[ADV]] **ο** *ho* [[G3588]] [[T-NSM]] **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **απαξ** *hapaks* raz [[G530]] [[ADV]] **προσενεχθεις** *prosenechtheis* który został przyniesiony – który został ofiarowany [[G4374]] WTV-APP-NSM **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* (temu) [[G3588]] WTT-ASN **πολλων** *pollōn* wielu [[G4183]] WTA-GPM **ανενεγκειν** *anenegkein* przynieść [[G399]] [[V-2AAN]] **αμαρτιας** *hamartias* grzechy [[G266]] WTN-APF **εκ** *ek* po [[G1537]] [[PREP]] **δευτερου** *deuterou* drugi [[G1208]] [[A-GSN]] **χωρις** *chōris* bez [[G5565]] [[ADV]] **αμαρτιας** *hamartias* grzechu [[G266]] [[N-GSF]] **οφθησεται** *ofthēsetai* zostanie ukazany – będzie uczyniony widocznym [[G3700]] WTV-FPI-3S **τοις** *tois* (tym) [[G3588]] WTT-DPM **αυτον** *auton* Jego [[G846]] WTP-ASM **απεκδεχομενοις** *apekdechomenois* wyczekującym – oczekującym [[G553]] WTV-PNP-DPM **εις** *eis* ku [[G1519]] [[PREP]] **σωτηριαν** *sōtērian* zbawieniu – wyzwoleniu [[G4991]] WTN-ASF
