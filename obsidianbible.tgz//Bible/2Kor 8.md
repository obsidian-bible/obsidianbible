# 2Kor 8 BT5
###### **2Kor 8,1**
 Donosimy wam, bracia, o łasce Bożej, jakiej dostąpiły Kościoły Macedonii,
###### **2Kor 8,2**
 jak to w dotkliwej próbie ucisku uradowały się bardzo i jak skrajne ich ubóstwo zajaśniało bogactwem prostoty.
###### **2Kor 8,3**
 Według możliwości, a nawet – zaświadczam to – ponad swe możliwości okazali oni gotowość,
###### **2Kor 8,4**
 nalegając na nas bardzo i prosząc o łaskę współdziałania w posłudze na rzecz świętych.
###### **2Kor 8,5**
 I nie tylko tak było, jak się spodziewaliśmy, lecz ofiarowali siebie samych naprzód Panu, a potem nam przez wolę Bożą.
###### **2Kor 8,6**
 Poprosiliśmy więc Tytusa, aby, jak to już rozpoczął, tak też i dokonał tego dzieła miłosierdzia pośród was.
###### **2Kor 8,7**
 A podobnie jak obfitujecie we wszystko, w wiarę, w mowę, w wiedzę, we wszelką gorliwość, w miłość naszą do was, tak też obyście i w tę łaskę obfitowali.
###### **2Kor 8,8**
 Nie mówię tego, aby wam wydawać rozkazy, lecz aby wskazując na gorliwość innych, wypróbować waszą miłość.
###### **2Kor 8,9**
 Znacie przecież łaskę Pana naszego, Jezusa Chrystusa, który będąc bogatym, dla was stał się ubogim, aby was ubóstwem swoim ubogacić.
###### **2Kor 8,10**
 Tak więc udzielam wam rady, a to przyniesie pożytek wam, którzy zaczęliście już od ubiegłego roku nie tylko chcieć, lecz i działać.
###### **2Kor 8,11**
 Doprowadźcie teraz to dzieło do końca, aby czynne podzielenie się tym, co macie, potwierdzało waszą chętną gotowość.
###### **2Kor 8,12**
 A gotowość uznaje się nie według tego, czego się nie ma, lecz według tego, co się ma.
###### **2Kor 8,13**
 Nie o to bowiem idzie, żeby innym sprawiać ulgę, a sobie utrapienie, lecz żeby była równość.
###### **2Kor 8,14**
 Teraz więc niech wasz dostatek przyjdzie z pomocą ich potrzebom, aby ich bogactwo było wam pomocą w waszych niedostatkach i aby nastała równość, jak to jest napisane:
###### **2Kor 8,15**
 Nie miał za wiele ten, kto miał dużo. Nie miał za mało ten, kto miał niewiele.
###### **2Kor 8,16**
 A Bogu niech będą dzięki za to, że wszczepił tę troskę o was w serce Tytusa,
###### **2Kor 8,17**
 tak iż przyjął zachętę, a będąc jeszcze bardziej gorliwym, z własnej woli wybrał się do was.
###### **2Kor 8,18**
 Posłaliśmy z nim brata, którego sława w [głoszeniu] Ewangelii rozchodzi się po wszystkich Kościołach.
###### **2Kor 8,19**
 Co więcej, przez same Kościoły został on ustanowiony towarzyszem naszej podróży w tym dziele, około którego się trudzimy ku chwale samego Pana i ku zaspokojeniu naszego pragnienia,
###### **2Kor 8,20**
 wystrzegając się tego, by ktoś na nas nie sarkał z okazji darów, tak obficie przez nas zebranych.
###### **2Kor 8,21**
 Staramy się bowiem o dobro nie tylko wobec Pana, lecz także wobec ludzi.
###### **2Kor 8,22**
 Posłaliśmy z nim również brata naszego, którego gorliwość mieliśmy sposobność wielokrotnie wypróbować, a który teraz, naprawdę ufając wam, okazał się jeszcze bardziej gorliwy.
###### **2Kor 8,23**
 Tytus jest moim towarzyszem i trudzi się ze mną dla was; a bracia nasi – to wysłańcy Kościołów, chwała Chrystusa.
###### **2Kor 8,24**
 Okażcie więc im wobec Kościołów waszą miłość i dajcie dowód naszej z was chluby.
# 2Kor 8 PAU
###### **2Kor 8,1**
 Bracia! Pragniemy, byście wiedzieli o łasce Boga udzielonej Kościołom Macedonii.
###### **2Kor 8,2**
 Chociaż zostali doświadczeni przez wielkie utrapienie, ich ogromna radość i skrajne ubóstwo zaobfitowały bogactwem szczodrości.
###### **2Kor 8,3**
 Na miarę swoich możliwości, a nawet - o czym mogę zaświadczyć - ponad swoje możliwości, sami
###### **2Kor 8,4**
 prosili nas usilnie o łaskę współuczestnictwa w posłudze na rzecz świętych.
###### **2Kor 8,5**
 Uczynili nie tylko to, czego się spodziewaliśmy, ale zgodnie z wolą Bożą samych siebie ofiarowali najpierw Panu, a potem i nam.
###### **2Kor 8,6**
 Poprosiliśmy więc Tytusa, aby on, który rozpoczął wśród was to dzieło łaski, doprowadził je do końca.
###### **2Kor 8,7**
 Jak obfitujecie we wszystko: w wiarę, słowo, poznanie, gorliwość i miłość, której nauczyliście się od nas, obyście także w tę łaskę obfitowali!
###### **2Kor 8,8**
 Mówiąc o tym, nie nakazuję wam niczego, ale wskazuję na gorliwość innych, aby poddać próbie szczerość waszej miłości.
###### **2Kor 8,9**
 Znacie przecież łaskę naszego Pana Jezusa Chrystusa: On, będąc bogaty, dla was stał się ubogi, abyście wy wzbogacili się Jego ubóstwem.
###### **2Kor 8,10**
 W tej sprawie taką mam opinię: Skoro nie tylko zaczęliście działać, ale jako pierwsi podjęliście już przed rokiem postanowienie, to pożyteczne będzie dla was,
###### **2Kor 8,11**
 jeśli doprowadzicie to dzieło do końca. Ochoczo postanowiliście, więc teraz zrealizujcie to według waszych możliwości.
###### **2Kor 8,12**
 Postanowienie jest oceniane nie według tego, czego się nie ma, ale według możliwości realizacji.
###### **2Kor 8,13**
 Nie chodzi przecież o to, aby innym ulżyć, a was obciążyć, ale by było równo.
###### **2Kor 8,14**
 W obecnym czasie wasz nadmiar zaspokoi ich ubóstwo, aby również ich nadmiar zaspokoił wasze ubóstwo i aby nastała równość,
###### **2Kor 8,15**
 jak jest napisane: Kto miał wiele, nie miał za dużo, a temu, kto miał mało, nie zabrakło.
###### **2Kor 8,16**
 Bogu niech będą dzięki, że rozpalił troskę o was w sercu Tytusa,
###### **2Kor 8,17**
 który nie tylko odpowiedział na zachętę, ale w swej wielkiej gorliwości sam pragnął wybrać się do was.
###### **2Kor 8,18**
 Razem z nim posłaliśmy brata, którego za głoszenie Ewangelii chwalą wszystkie Kościoły.
###### **2Kor 8,19**
 Co więcej, przez nałożenie rąk przez Kościoły został on ustanowiony naszym towarzyszem podróży w dziele łaski, któremu ochoczo posługujemy ku chwale samego Pana.
###### **2Kor 8,20**
 Chcemy w ten sposób uchronić się, by ktoś nas nie obmawiał z powodu obfitych darów zebranych dzięki naszemu posługiwaniu.
###### **2Kor 8,21**
 Staramy się bowiem postępować dobrze nie tylko przed Panem, ale także przed ludźmi.
###### **2Kor 8,22**
 Z nimi też posłaliśmy naszego brata, którego gorliwość wielokrotnie mieliśmy możność wypróbować. Teraz jego gorliwość jest jeszcze większa, gdyż ma do was wielkie zaufanie.
###### **2Kor 8,23**
 Jeśli więc chodzi o Tytusa, to jest on moim towarzyszem i współpracuje ze mną ze względu na was. Nasi bracia natomiast to wysłannicy Kościołów i chwała Chrystusa.
###### **2Kor 8,24**
 Dlatego dajcie im poznać waszą miłość i okażcie, że słusznie chlubię się wami wobec Kościołów!
# 2Kor 8 BP
###### **2Kor 8,1**
 Donosimy wam, bracia, o łasce, jaką Bóg obdarzył Kościoły w Macedonii.
###### **2Kor 8,2**
 Z ogromną radością zniosły one ciężką próbę utrapienia, a ich skrajne ubóstwo zdobyło się na nadzwyczajną hojność.
###### **2Kor 8,3**
 Zaświadczam, że według swoich możliwości, a nawet ponad możliwości, dobrowolnie
###### **2Kor 8,4**
 skierowali do nas gorącą prośbę o tę łaskę: o współudział w posłudze na rzecz świętych.
###### **2Kor 8,5**
 Nie tylko tak uczynili, jak tego się spodziewaliśmy, lecz zgodnie z wolą Bożą oddali siebie samych najpierw Panu, a potem nam.
###### **2Kor 8,6**
 Wobec tego poprosiliśmy Tutusa, aby to dzieło, które już u was rozpoczął, doprowadził do końca.
###### **2Kor 8,7**
 Obyście wyróżnili się w tym dziele tak, jak wyróżniacie się wiarą i słowem, gorliwością w każdej dziedzinie i naszą miłością do was.
###### **2Kor 8,8**
 Nie mówię tego w formie rozkazu, lecz aby wskazać wam przykład gorliwości innych i wypróbować, czy wasza miłość jest szczera.
###### **2Kor 8,9**
 Wiecie przecież, na czym polega łaska Pana naszego Jezusa Chrystusa. Oto będąc bogatym stał się dla was ubogim, abyście zostali wzbogaceni Jego ubóstwem.
###### **2Kor 8,10**
 Daję wam tylko radę w tej sprawie, a to przyniesie wam korzyść. W ubiegłym roku wyraziliście chęć i rozpoczęliście realizację tego dzieła.
###### **2Kor 8,11**
 Teraz więc doprowadźcie je do końca. Obyście to dzieło tak ochoczo doprowadzili do końca według waszych możliwości, jak ochoczo zgodziliście się je podjąć.
###### **2Kor 8,12**
 Jeżeli bowiem istnieje ochota, to łączy się ona z przyjemnością tylko wówczas, gdy się daje z tego, co się ma, a nie z tego, czego się nie ma.
###### **2Kor 8,13**
 Nie chodzi bowiem o to, aby innym sprawiać ulgę, a wam utrapienie, lecz aby nastąpiło wyrównanie.
###### **2Kor 8,14**
 W obecnym czasie to, co wam zbywa w zakresie dóbr materialnych, niech zapobiega ich niedostatkowi, aby z kolei to, co im zbywa w zakresie dóbr duchowych, zapobiegło waszemu niedostatkowi w tym względzie. W ten sposób nastąpi wyrównanie,
###### **2Kor 8,15**
 zgodnie z tym, co zostało napisane: "Kto miał dużo, nie miał za wiele, a kto miał niewiele, nie miał za mało".
###### **2Kor 8,16**
 Bogu niech będą dzięki za to, że wszczepił w serce Tytusa tę samą troskliwość o was.
###### **2Kor 8,17**
 Przyjął on moją zachętę, a będąc szczególnie gorliwym, dobrowolnie wyruszył do was.
###### **2Kor 8,18**
 Wraz z nim posłaliśmy brata, któremu głoszenie dobrej nowiny przyniosło chwałę we wszystkich Kościołach.
###### **2Kor 8,19**
 Ponadto Kościoły wyznaczyły go na towarzysza naszej podróży w tym dziele łaski, któremu poświęcamy się ochoczo, ku chwale Pana.
###### **2Kor 8,20**
 Staramy się nie stwarzać okazji, aby na nas narzekano z powodu hojnego daru, którego zebraniem zajęliśmy się.
###### **2Kor 8,21**
 Troszczymy się bowiem nie tylko o to, co jest dobre wobec Pana, lecz także o to, co jest dobre wobec ludzi.
###### **2Kor 8,22**
 Wraz z nimi posłaliśmy naszego brata, którego gorliwość wypróbowaliśmy przy wielu okazjach, a który obecnie wykazuje jeszcze większą gorliwość, wypływającą z zaufania do was.
###### **2Kor 8,23**
 Jeżeli chodzi o Tytusa, to jest on moim towarzyszem i współpracuje ze mną dla waszego dobra. Jeżeli chodzi o naszych braci, to są oni wysłannikami Kościołów i chwałą Chrystusa.
###### **2Kor 8,24**
 Dajcie więc dowód waszej miłości i udowodnjcie im, że słusznie chlubimy się wami wobec wszystkich Kościołów.
# 2Kor 8 BR
###### **2Kor 8,1**
 Donosimy wam, bracia, o łasce Bożej, jakiej dostąpiły Kościoły Macedonii,
###### **2Kor 8,2**
 jak to w dotkliwej próbie ucisku uradowali się bardzo i jak skrajne ich ubóstwo zajaśniało bogactwem prostoty.
###### **2Kor 8,3**
 Według możliwości, a nawet - zaświadczam to - ponad swe możliwości okazali gotowość,
###### **2Kor 8,4**
 nalegając na nas bardzo i prosząc o łaskę współdziałania w posłudze na rzecz świętych.
###### **2Kor 8,5**
 I nie tylko tak było, jakeśmy się spodziewali, lecz ofiarowali siebie samych najpierw Panu, a potem nam przez wolę Bożą.
###### **2Kor 8,6**
 Poprosiliśmy więc Tytusa, aby, jak to już rozpoczął, tak też i dokonał tego dzieła miłosierdzia.
###### **2Kor 8,7**
 A podobnie jak obfitujecie we wszystko, w wiarę, w mowę, w wiedzę, we wszelką gorliwość, w miłość naszą do was, tak też obyście i w tę łaskę obfitowali.
###### **2Kor 8,8**
 Nie mówię tego, aby wam wydawać rozkazy, lecz aby wskazując na gorliwość innych, wypróbować waszą miłość.
###### **2Kor 8,9**
 Znacie przecież łaskę Pana naszego Jezusa Chrystusa, który będąc bogaty, dla was stał się ubogim, aby was ubóstwem swoim ubogacić.
###### **2Kor 8,10**
 Tak więc udzielam wam rady, a to przyniesie pożytek wam, którzy zaczęliście już ubiegłego roku nie tylko chcieć, lecz i działać.
###### **2Kor 8,11**
 Doprowadźcie teraz to dzieło do końca, aby czynne podzielenie się tym, co macie, potwierdzało waszą chętną gotowość.
###### **2Kor 8,12**
 A gotowość uznaje się nie według tego, czego się nie ma, lecz według tego, co się ma.
###### **2Kor 8,13**
 Nie o to bowiem idzie, żeby innym sprawiać ulgę, a sobie utrapienie, lecz żeby była równość.
###### **2Kor 8,14**
 Teraz więc niech wasz dostatek przyjdzie z pomocą ich potrzebom, aby ich bogactwo było wam pomocą w waszych niedostatkach i aby nastała równość według tego, co jest napisane:
###### **2Kor 8,15**
 Nie miał za wiele ten, kto miał dużo. Nie miał za mało ten, kto miał niewiele.
###### **2Kor 8,16**
 A Bogu niech będą dzięki za to, że wszczepił tę troskę o was w serce Tytusa,
###### **2Kor 8,17**
 iż przyjął zachętę, a będąc jeszcze bardziej gorliwym, z własnej woli wybrał się do was.
###### **2Kor 8,18**
 Posłaliśmy z nim brata, którego sława w Ewangelii rozchodzi się po wszystkich Kościołach.
###### **2Kor 8,19**
 Co więcej, przez same Kościoły został on ustanowiony towarzyszem naszej podróży w tym dziele, około którego się trudzimy ku chwale samego Pana i ku zaspokojeniu naszego pragnienia,
###### **2Kor 8,20**
 wystrzegając się tego, by ktoś na nas nie sarkał z okazji darów, tak obficie przez nas zebranych.
###### **2Kor 8,21**
 Staramy się bowiem o dobro nie tylko wobec Pana, lecz także wobec ludzi.
###### **2Kor 8,22**
 Posłaliśmy z nim również brata naszego, którego gorliwość mieliśmy sposobność wielokrotnie wypróbować, a który teraz, naprawdę ufając wam, okazał się jeszcze bardziej gorliwym.
###### **2Kor 8,23**
 Tytus jest moim towarzyszem i trudzi się ze mną dla was; a bracia nasi - to wysłańcy Kościołów, chwała Chrystusa.
###### **2Kor 8,24**
 Okażcie więc im wobec Kościoła waszą miłość i dowody naszej z was chluby.
# 2Kor 8 WUJ
###### **2Kor 8,1**
 A oznajmujemy wam, bracia, łaskę Bożą, która jest dana w kościelech Macedońskich:
###### **2Kor 8,2**
 Iż w wielkiem doświadczeniu utrapienia, obfitość wesela ich była, i ubóstwo ich obfitowało w bogactwo prostoty ich.
###### **2Kor 8,3**
 Iż wedle możności daję im świadectwo i nad możność dobrowolnymi byli.
###### **2Kor 8,4**
 Z wielkiem napominaniem prosząc nas o łaskę, i społeczność posługowania, które dzieje się przeciw świętym.
###### **2Kor 8,5**
 A nie jakośmy się spodziewali, ale sami siebie oddali, naprzód Panu, potem nam przez wolą Bożą:
###### **2Kor 8,6**
 Tak iżeśmy prosili Tytusa, aby jako począł, tak i dokonał u was też łaski tej.
###### **2Kor 8,7**
 Ale jako we wszystkiem obfitujecie w wierze i w mowie, i w umiejętności, i wszelakiej pilności, nadto i w miłości waszej przeciwko nam: abyście i w tej łasce obfitowali.
###### **2Kor 8,8**
 Nie mówię jako rozkazując, ale przez staranie innych, i waszej miłości przyrodzenia dobrego doświadczając.
###### **2Kor 8,9**
 Abowiem znacie łaskę Pana naszego Jezusa Chrystusa, że dla was stał się ubogim, będąc bogatym: abyście ubóstwem jego wy bogatymi byli.
###### **2Kor 8,10**
 A w tem radę dawam: abowiem to wam jest pożyteczno, którzy nie tylko czynić, ale i chciećeście poczęli od roku przeszłego:
###### **2Kor 8,11**
 A teraz i uczynkiem wykonajcie: aby jako jest ochotna chęć woli, tak była i wykonania z tego co macie.
###### **2Kor 8,12**
 Abowiem jeśli jest ochotna wola, wedle tego co ma, jest przyjemna, nie wedle tego czego nie ma.
###### **2Kor 8,13**
 Bo nie iżeby inszym miało być ulżenie, a wam uciśnienie: ale wedle porównania.
###### **2Kor 8,14**
 Na ten czas wasza obfitość, niech dołoży ich niedostatku: aby też ich obfitość była dołożeniem waszego niedostatku, aby było porównanie:
###### **2Kor 8,15**
 Jako jest napisano: Który wiele, nie miał nazbyt: a kto mało, nie miał mniej.
###### **2Kor 8,16**
 A dzięka Bogu, który dał toż staranie o was do serca Tytusowego,
###### **2Kor 8,17**
 Iż napominanie przyjął: ale pilniejszym będąc, z swej chęci udał się do was.
###### **2Kor 8,18**
 Posłaliśmy też z nim brata, którego chwała jest w Ewanieljej po wszystkich kościołach:
###### **2Kor 8,19**
 A nie tylko ale też postanowion jest od kościołów za towarzysza, pielgrzymowania naszego, ku tej łasce, która bywa szafowana od nas ku chwale Pańskiej i chętliwej woli naszej:
###### **2Kor 8,20**
 Strzegąc się tego, aby nas kto nie naganił w tej obfitości, która się przez nas sprawuje.
###### **2Kor 8,21**
 Abowiem przemyślawamy dobra nietylko przed Bogiem ale też przed ludźmi.
###### **2Kor 8,22**
 A posłaliśmy z nimi i brata naszego, któregośmy wielekroć w wielu rzeczach doświadczyli, że jest pilny: a teraz daleko pilniejszy, dla wielkiej ufności przeciwko wam,
###### **2Kor 8,23**
 Chociaż dla Tytusa, który jest moim towarzyszem i pomocnikiem u was, chociaż bracia naszy Apostołowie kościołów, chwała Chrystusowa.
###### **2Kor 8,24**
 Okazanie tedy które jest miłości waszej i przechwalania naszego z was, okażcie przeciw nim przed oblicznością kościołów.
# 2Kor 8 STERN
###### **2Kor 8,1**
 A musimy wam, bracia, powiedzieć o łasce, jaką Bóg dał zgromadzeniom w Macedonii.
###### **2Kor 8,2**
 Pomimo dotkliwych przeciwności i mimo że są rozpaczliwie ubodzy, ich radość obfitowała w bogactwo szczodrobliwości.
###### **2Kor 8,3**
 Powiadam wam, że dawali nie tylko wedle swoich możliwości, ale z własnej nieprzymuszonej woli dawali więcej, niż mogli.
###### **2Kor 8,4**
 Błagali nas i zaklinali o przywilej udziału w tej służbie dla ludu Bożego.
###### **2Kor 8,5**
 A zrobili to nie tak, jakeśmy oczekiwali, tylko najpierw oddali siebie Panu, to znaczy z woli Bożej nam.
###### **2Kor 8,6**
 Wskutek tego wszystkiego poleciliśmy Tytusowi, aby ten sam dar łaski zebrał wśród was, bo też zrobił już tego początek.
###### **2Kor 8,7**
 Jak celujecie we wszystkim - w wierze, w mowie, w poznaniu, w pilności wszelakiej i w swojej miłości ku nam - zadbajcie o to, by celować także w tym darze.
###### **2Kor 8,8**
 Nie wydaję rozkazu, lecz raczej badam szczerość waszej miłości na tle pilności innych.
###### **2Kor 8,9**
 Bo wiecie, jak szczodry był nasz Pan Jeszua Mesjasz - ze względu na was ogołocił się, choć był bogaty, aby przez swe ubóstwo was wzbogacić.
###### **2Kor 8,10**
 Jak mówię, co do tej sprawy wyrażam tylko zdanie. Rok temu nie tylko jako pierwsi podjęliście działanie, ale też jako pierwsi zapragnęliście to zrobić. A korzystne byłoby dla was
###### **2Kor 8,11**
 zakończenie tego, coście zaczęli, aby waszej żarliwej chęci rozpoczęcia tego dzieła dorównała żarliwość w jego dokończeniu, przez udzielenie z tego, co macie.
###### **2Kor 8,12**
 Bo jeśli jest żarliwość, aby dawać, to cenność daru będzie mierzona wedle tego, co macie, a nie tego, czego nie macie.
###### **2Kor 8,13**
 Nie chodzi o to, aby wspomaganie innych miało wam samym przysporzyć kłopotów, ale żeby zapanowała pewna wzajemność:
###### **2Kor 8,14**
 w tej chwili wasza obfitość może wspomóc tamtych w potrzebie, aby kiedy wy będziecie w potrzebie, ich obfitość mogła wspomóc was - i w tym jest wzajemność.
###### **2Kor 8,15**
 Jak mówi Tanach: "Kto zebrał wiele, nie miał nic na zapas, a temu, kto zebrał mało, niczego nie brakło".
###### **2Kor 8,16**
 A dziękuję Bogu, że uczynił Tytusa tak wam oddanym jak my;
###### **2Kor 8,17**
 bo nie tylko uległ on naszym namowom, ale bardzo wam oddany, przybywa do was z własnej inicjatywy.
###### **2Kor 8,18**
 A z nim wysyłamy brata, którego pracę dla Dobrej Nowiny chwalą wszystkie zgromadzenia;
###### **2Kor 8,19**
 i nie tylko to, ale został on wyznaczony przez zgromadzenia, aby z nami podróżować, tak aby nasze zarządzanie tym dziełem miłosierdzia przyniosło cześć Panu i dowiodło naszej gorliwej chęci do pomocy.
###### **2Kor 8,20**
 Mamy tutaj na celu wykazać, że postawa co do zarządzania tymi pokaźnymi sumami jest z naszej strony bez zarzutu;
###### **2Kor 8,21**
 bo trudzimy się wielce, aby robić to, co dobre, nie tylko w oczach Boga, ale i w oczach innych ludzi.
###### **2Kor 8,22**
 Z tymi dwoma posyłamy jeszcze jednego naszego brata, którego gorliwość wypróbowaliśmy wiele razy na wiele sposobów, a który teraz jeszcze jest gorliwszy z powodu wielkiego do was zaufania.
###### **2Kor 8,23**
 Co zaś do Tytusa, to jest on moim towarzyszem i wraz ze mną trudzi się dla was; a pozostali bracia z nim są wysłannikami zgromadzeń i przynoszą chwałę Mesjaszowi.
###### **2Kor 8,24**
 Dlatego miłość, jaką okażecie tym ludziom, będzie dla nich uzasadnieniem naszej dumy z was, a przez nich także dla zgromadzeń, które ich wysłały.
# 2Kor 8 TRO
###### **2Kor 8,1**
 **γνωριζομεν** *gnōrizomen* Oznajmiamy – Dajemy poznać [[G1107]] WTV-PAI-1P **δε** *de* zaś [[G1161]] [[CONJ]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **την** *tēn* [[G3588]] WTT-ASF **χαριν** *charin* łaskę [[G5485]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **την** *tēn* (tę) [[G3588]] WTT-ASF **δεδομενην** *dedomenēn* która jest dana [[G1325]] WTV-RPP-ASF **εν** *en* w [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **εκκλησιαις** *ekklēsiais* zgromadzeniach – (społecznościach) wywołanych [[G1577]] WTN-DPF **της** *tēs* [[G3588]] [[T-GSF]] **μακεδονιας** *makedonias* Macedonii [[G3109]] [[N-GSF]]
###### **2Kor 8,2**
 **οτι** *hoti* że [[G3754]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **πολλη** *pollē* wielkim [[G4183]] WTA-DSF **δοκιμη** *dokimē* wypróbowaniu [[G1382]] [[N-DSF]] **θλιψεως** *thlipseōs* ucisku – utrapienia [[G2347]] [[N-GSF]] **η** *hē* [[G3588]] [[T-NSF]] **περισσεια** *perisseia* obfitość [[G4050]] [[N-NSF]] **της** *tēs* [[G3588]] [[T-GSF]] **χαρας** *charas* radości [[G5479]] [[N-GSF]] **αυτων** *autōn* ich [[G846]] WTP-GPM **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **κατα** *kata* w [[G2596]] [[PREP]] **βαθους** *bathous* głębi [[G899]] [[N-GSN]] **πτωχεια** *ptōcheia* ubóstwo – skrajna nędza [[G4432]] [[N-NSF]] **αυτων** *autōn* ich [[G846]] WTP-GPM **επερισσευσεν** *eperisseusen* zaobfitowało [[G4052]] [[V-AAI-3S]] **εις** *eis* w – ku [[G1519]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **πλουτον** *plouton* bogactwie [[G4149]] [[N-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **απλοτητος** *haplotētos* szczerości – prostoty [[G572]] [[N-GSF]] **αυτων** *autōn* ich [[G846]] WTP-GPM
###### **2Kor 8,3**
 **οτι** *hoti* że [[G3754]] [[CONJ]] **κατα** *kata* według [[G2596]] [[PREP]] **δυναμιν** *dynamin* możności – mocy [[G1411]] WTN-ASF **μαρτυρω** *martyrō* świadczę [[G3140]] WTV-PAI-1S **και** *kai* i [[G2532]] [[CONJ]] **υπερ** *hyper* ponad [[G5228]] [[PREP]] **δυναμιν** *dynamin* możność – moc [[G1411]] WTN-ASF **αυθαιρετοι** *authairetoi* dobrowolnie – z własnych wyborów [[G830]] WTA-NPM
###### **2Kor 8,4**
 **μετα** *meta* z [[G3326]] [[PREP]] **πολλης** *pollēs* wielką [[G4183]] WTA-GSF **παρακλησεως** *paraklēseōs* zachętą – prośbą [[G3874]] [[N-GSF]] **δεομενοι** *deomenoi* prosząc [[G1189]] WTV-PNP-NPM **ημων** *hēmōn* nas [[G2257]] WTP-1GP **την** *tēn* (o) [[G3588]] WTT-ASF **χαριν** *charin* łaskę [[G5485]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **κοινωνιαν** *koinōnian* wspólnotę – udział [[G2842]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **διακονιας** *diakonias* posługi – służby [[G1248]] [[N-GSF]] **της** *tēs* (tej) [[G3588]] [[T-GSF]] **εις** *eis* względem [[G1519]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **αγιους** *hagious* świętych [[G40]] WTA-APM **δεξασθαι** *deksasthai* przyjąć [[G1209]] WTV-ADN **ημας** *hēmas* nas [[G2248]] WTP-1AP
###### **2Kor 8,5**
 **και** *kai* i [[G2532]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **ηλπισαμεν** *ēlpisamen* nabraliśmy nadziei – spodziewaliśmy się [[G1679]] WTV-AAI-1P **αλλ** *all* ale [[G235]] [[CONJ]] **εαυτους** *heautous* siebie samych [[G1438]] WTF-3APM **εδωκαν** *edōkan* dali [[G1325]] WTV-AAI-3P **πρωτον** *prōton* najpierw [[G4412]] [[ADV]] **τω** *tō* [[G3588]] WTT-DSM **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **και** *kai* a [[G2532]] [[CONJ]] **ημιν** *hēmin* nam [[G2254]] WTP-1DP **δια** *dia* przez [[G1223]] [[PREP]] **θεληματος** *thelēmatos* wolę [[G2307]] [[N-GSN]] **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **2Kor 8,6**
 **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **παρακαλεσαι** *parakalesai* zachęcić – poprosić [[G3870]] [[V-AAN]] **ημας** *hēmas* my [[G2248]] WTP-1AP **τιτον** *titon* Tytusa [[G5103]] [[N-ASM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **προενηρξατο** *proenērksato* wcześniej rozpoczął [[G4278]] WTV-ADI-3S **ουτως** *houtōs* tak [[G3779]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **επιτελεση** *epitelesē* dokończyłby – wypełniłby [[G2005]] WTV-AAS-3S **εις** *eis* u [[G1519]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **χαριν** *charin* łaskę [[G5485]] WTN-ASF **ταυτην** *tautēn* tę [[G3778]] WTD-ASF
###### **2Kor 8,7**
 **αλλ** *all* Ale [[G235]] [[CONJ]] **ωσπερ** *hōsper* tak, jak [[G5618]] [[ADV]] **εν** *en* we [[G1722]] [[PREP]] **παντι** *panti* wszystkim [[G3956]] WTA-DSN **περισσευετε** *perisseuete* obfitujecie [[G4052]] WTV-PAI-2P **πιστει** *pistei* wiarą [[G4102]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **λογω** *logō* słowem [[G3056]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **γνωσει** *gnōsei* poznaniem – wiedzy [[G1108]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **παση** *pasē* całą [[G3956]] WTA-DSF **σπουδη** *spoudē* gorliwością – zapałem [[G4710]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **τη** *tē* (tę) [[G3588]] WTT-DSF **εξ** *eks* od [[G1537]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **εν** *en* w [[G1722]] [[PREP]] **ημιν** *hēmin* nas [[G2254]] WTP-1DP **αγαπη** *agapē* miłością [[G26]] [[N-DSF]] **ινα** *hina* aby [[G2443]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **ταυτη** *tautē* tej [[G3778]] WTD-DSF **τη** *tē* [[G3588]] WTT-DSF **χαριτι** *chariti* łasce [[G5485]] [[N-DSF]] **περισσευητε** *perisseuēte* obfitowalibyście [[G4052]] WTV-PAS-2P
###### **2Kor 8,8**
 **ου** *ou* Nie [[G3756]] [[PRT-N]] **κατ** *kat* w [[G2596]] [[PREP]] **επιταγην** *epitagēn* nakazie – rozkazie [[G2003]] WTN-ASF **λεγω** *legō* mówię [[G3004]] WTV-PAI-1S **αλλα** *alla* ale [[G235]] [[CONJ]] **δια** *dia* przez [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **ετερων** *heterōn* innych [[G2087]] WTA-GPM **σπουδης** *spoudēs* gorliwość – zapał [[G4710]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **το** *to* (tej) [[G3588]] WTT-ASN **της** *tēs* [[G3588]] [[T-GSF]] **υμετερας** *hymeteras* waszej [[G5212]] WTS-2GPF **αγαπης** *agapēs* miłości [[G26]] [[N-GSF]] **γνησιον** *gnēsion* szczerej – prawowitej [[G1103]] WTA-ASN **δοκιμαζων** *dokimazōn* próbując [[G1381]] [[V-PAP-NSM]]
###### **2Kor 8,9**
 **γινωσκετε** *ginōskete* znacie [[G1097]] WTV-PAI-2P **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **χαριν** *charin* łaskę [[G5485]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **οτι** *hoti* że [[G3754]] [[CONJ]] **δι** *di* przez [[G1223]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **επτωχευσεν** *eptōcheusen* stał się ubogim [[G4433]] [[V-AAI-3S]] **πλουσιος** *plousios* bogaty [[G4145]] [[A-NSM]] **ων** *ōn* będąc [[G5607]] [[V-PXP-NSM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **τη** *tē* [[G3588]] WTT-DSF **εκεινου** *ekeinou* Jego [[G1565]] WTD-GSM **πτωχεια** *ptōcheia* ubóstwem – skrajną nędzą [[G4432]] [[N-DSF]] **πλουτησητε** *ploutēsēte* wzbogacilibyście się – stalibyście się bogaci [[G4147]] WTV-AAS-2P
###### **2Kor 8,10**
 **και** *kai* A [[G2532]] [[CONJ]] **γνωμην** *gnōmēn* mniemanie – opinię [[G1106]] WTN-ASF **εν** *en* w [[G1722]] [[PREP]] **τουτω** *toutō* tym [[G5129]] WTD-DSN **διδωμι** *didōmi* daję [[G1325]] WTV-PAI-1S **τουτο** *touto* to [[G5124]] WTD-NSN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **υμιν** *hymin* (dla) was [[G5213]] WTP-2DP **συμφερει** *symferei* jest korzystne – jest pożyteczne [[G4851]] WTV-PAI-3S **οιτινες** *hoitines* którzy [[G3748]] WTR-NPM **ου** *ou* nie [[G3756]] [[PRT-N]] **μονον** *monon* jedynie – tylko [[G3440]] [[ADV]] **το** *to* [[G3588]] WTT-ASN **ποιησαι** *poiēsai* uczynić [[G4160]] [[V-AAN]] **αλλα** *alla* ale [[G235]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-ASN **θελειν** *thelein* chcieć [[G2309]] WTV-PAN **προενηρξασθε** *proenērksasthe* wcześniej rozpoczęli [[G4278]] WTV-ADI-2P **απο** *apo* od [[G575]] [[PREP]] **περυσι** *perysi* ubiegłego roku [[G4070]] [[ADV]]
###### **2Kor 8,11**
 **νυνι** *nyni* teraz [[G3570]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-ASN **ποιησαι** *poiēsai* uczynić [[G4160]] [[V-AAN]] **επιτελεσατε** *epitelesate* dokończcie – wypełnijcie [[G2005]] WTV-AAM-2P **οπως** *hopōs* żeby [[G3704]] [[ADV]] **καθαπερ** *kathaper* tak, jak [[G2509]] [[ADV]] **η** *hē* [[G3588]] [[T-NSF]] **προθυμια** *prothymia* gotowość – ochoczość [[G4288]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSM **θελειν** *thelein* chcieć [[G2309]] WTV-PAN **ουτως** *houtōs* tak [[G3779]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **επιτελεσαι** *epitelesai* zakończyć – wypełnić [[G2005]] [[V-AAN]] **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **εχειν** *echein* mieć [[G2192]] WTV-PAN
###### **2Kor 8,12**
 **ει** *ei* Jeśli [[G1487]] WTCOND **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **προθυμια** *prothymia* gotowość – ochoczość [[G4288]] [[N-NSF]] **προκειται** *prokeitai* poprzedza [[G4295]] WTV-PNI-3S **καθο** *katho* według tego, jak [[G2526]] [[ADV]] **εαν** *ean* jeśli [[G1437]] WTCOND **εχη** *echē* miałby [[G2192]] WTV-PAS-3S **τις** *tis* ktoś [[G5100]] WTX-NSM **ευπροσδεκτος** *euprosdektos* bardzo godna przyjęcia [[G2144]] [[A-NSM]] **ου** *ou* nie [[G3756]] [[PRT-N]] **καθο** *katho* według tego, jak [[G2526]] [[ADV]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εχει** *echei* ma [[G2192]] WTV-PAI-3S
###### **2Kor 8,13**
 **ου** *ou* Nie [[G3756]] [[PRT-N]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ινα** *hina* aby [[G2443]] [[CONJ]] **αλλοις** *allois* (dla) innych [[G243]] WTA-DPM **ανεσις** *anesis* ulga – wytchnienie [[G425]] [[N-NSF]] **υμιν** *hymin* (dla) was [[G5213]] WTP-2DP **δε** *de* zaś [[G1161]] [[CONJ]] **θλιψις** *thlipsis* ucisk – utrapienie [[G2347]] [[N-NSF]] **αλλ** *all* ale [[G235]] [[CONJ]] **εξ** *eks* po [[G1537]] [[PREP]] **ισοτητος** *isotētos* równości [[G2471]] [[N-GSF]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* (tej) [[G3588]] WTT-DSM **νυν** *nyn* teraz [[G3568]] [[ADV]] **καιρω** *kairō* porze [[G2540]] WTN-DSM **το** *to* [[G3588]] WTT-NSN **υμων** *hymōn* wasza [[G5216]] WTP-2GP **περισσευμα** *perisseuma* obfitość [[G4051]] WTN-NSN **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **εκεινων** *ekeinōn* ich [[G1565]] WTD-GPM **υστερημα** *hysterēma* niedostatkowi – brakowi [[G5303]] WTN-ASN
###### **2Kor 8,14**
 **ινα** *hina* aby [[G2443]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **το** *to* (ta) [[G3588]] WTT-NSN **εκεινων** *ekeinōn* ich [[G1565]] WTD-GPM **περισσευμα** *perisseuma* obfitość [[G4051]] WTN-NSN **γενηται** *genētai* stałaby się [[G1096]] WTV-2ADS-3S **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **υμων** *hymōn* waszemu [[G5216]] WTP-2GP **υστερημα** *hysterēma* niedostatkowi – brakowi [[G5303]] WTN-ASN **οπως** *hopōs* żeby [[G3704]] [[ADV]] **γενηται** *genētai* stałaby się [[G1096]] WTV-2ADS-3S **ισοτης** *isotēs* równość [[G2471]] [[N-NSF]]
###### **2Kor 8,15**
 **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **γεγραπται** *gegraptai* jest napisane [[G1125]] WTV-RPI-3S **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **το** *to* [[G3588]] WTT-ASN **πολυ** *poly* wiele [[G4183]] WTA-ASN **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **επλεονασεν** *epleonasen* obfitował [[G4121]] [[V-AAI-3S]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* (ten) [[G3588]] [[T-NSM]] **το** *to* [[G3588]] WTT-ASN **ολιγον** *oligon* mało [[G3641]] WTA-ASN **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ηλαττονησεν** *ēlattonēsen* miał za mało [[G1641]] [[V-AAI-3S]]
###### **2Kor 8,16**
 **χαρις** *charis* Wdzięczność – Łaska [[G5485]] [[N-NSF]] **δε** *de* zaś [[G1161]] [[CONJ]] **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **τω** *tō* (Temu) [[G3588]] WTT-DSM **διδοντι** *didonti* dającemu [[G1325]] WTV-PAP-DSM **την** *tēn* [[G3588]] WTT-ASF **αυτην** *autēn* tę [[G846]] [[P-ASF]] **σπουδην** *spoudēn* gorliwość – zapał [[G4710]] WTN-ASF **υπερ** *hyper* o [[G5228]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **καρδια** *kardia* sercu [[G2588]] [[N-DSF]] **τιτου** *titou* Tytusa [[G5103]] [[N-GSM]]
###### **2Kor 8,17**
 **οτι** *hoti* że [[G3754]] [[CONJ]] **την** *tēn* (tę) [[G3588]] WTT-ASF **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **παρακλησιν** *paraklēsin* zachętę [[G3874]] WTN-ASF **εδεξατο** *edeksato* przyjął [[G1209]] WTV-ADI-3S **σπουδαιοτερος** *spoudaioteros* z większym zapałem – coraz gorliwszym [[G4705]] [[A-NSM]]-C **δε** *de* zaś [[G1161]] [[CONJ]] **υπαρχων** *hyparchōn* będąc [[G5225]] [[V-PAP-NSM]] **αυθαιρετος** *authairetos* dobrowolnie – z własnego wyboru [[G830]] [[A-NSM]] **εξηλθεν** *eksēlthen* wyszedł [[G1831]] WTV-2AAI-3S **προς** *pros* do [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP
###### **2Kor 8,18**
 **συνεπεμψαμεν** *synepempsamen* Posłaliśmy razem [[G4842]] WTV-AAI-1P **δε** *de* zaś [[G1161]] [[CONJ]] **μετ** *met* z [[G3326]] [[PREP]] **αυτου** *autou* nim [[G846]] [[P-GSM]] **τον** *ton* [[G3588]] [[T-ASM]] **αδελφον** *adelfon* brata [[G80]] [[N-ASM]] **ου** *hou* którego [[G3739]] WTR-GSM **ο** *ho* [[G3588]] [[T-NSM]] **επαινος** *epainos* pochwała [[G1868]] [[N-NSM]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **ευαγγελιω** *euangeliō* dobrej nowinie [[G2098]] WTN-DSN **δια** *dia* przez [[G1223]] [[PREP]] **πασων** *pasōn* wszystkie [[G3956]] WTA-GPF **των** *tōn* [[G3588]] WTT-GPF **εκκλησιων** *ekklēsiōn* zgromadzenia – (społeczności) wywołanych [[G1577]] WTN-GPF
###### **2Kor 8,19**
 **ου** *ou* nie [[G3756]] [[PRT-N]] **μονον** *monon* jedynie – tylko [[G3440]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **αλλα** *alla* ale [[G235]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **χειροτονηθεις** *cheirotonētheis* który został wybrany przez wyciągnięcie ręki – który został wybrany przez nałożenie rąk [[G5500]] WTV-APP-NSM **υπο** *hypo* przez [[G5259]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPF **εκκλησιων** *ekklēsiōn* zgromadzenia – (społeczności) wywołanych [[G1577]] WTN-GPF **συνεκδημος** *synekdēmos* (na) towarzysza podróży [[G4898]] [[N-NSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **συν** *syn* razem z [[G4862]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **χαριτι** *chariti* łaską [[G5485]] [[N-DSF]] **ταυτη** *tautē* tą [[G3778]] WTD-DSF **τη** *tē* [[G3588]] WTT-DSF **διακονουμενη** *diakonoumenē* która jest obsługiwana [[G1247]] WTV-PPP-DSF **υφ** *hyf* przez [[G5259]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP **προς** *pros* ku [[G4314]] [[PREP]] **την** *tēn* (tej) [[G3588]] WTT-ASF **αυτου** *autou* Jego [[G846]] [[P-GSM]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **δοξαν** *doksan* chwale [[G1391]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **προθυμιαν** *prothymian* gotowości – ochoczości [[G4288]] WTN-ASF **υμων** *hymōn* waszej [[G5216]] WTP-2GP
###### **2Kor 8,20**
 **στελλομενοι** *stellomenoi* unikając [[G4724]] WTV-PMP-NPM **τουτο** *touto* tego [[G5124]] WTD-ASN **μη** *mē* nie [[G3361]] [[PRT-N]] **τις** *tis* ktoś [[G5100]] WTX-NSM **ημας** *hēmas* nas [[G2248]] WTP-1AP **μωμησηται** *mōmēsētai* zhańbiłby – podważyłby [[G3469]] WTV-ADS-3S **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **αδροτητι** *hadrotēti* hojności – obfitości [[G100]] [[N-DSF]] **ταυτη** *tautē* tej [[G3778]] WTD-DSF **τη** *tē* [[G3588]] WTT-DSF **διακονουμενη** *diakonoumenē* która jest obsługiwana [[G1247]] WTV-PPP-DSF **υφ** *hyf* przez [[G5259]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP
###### **2Kor 8,21**
 **προνοουμενοι** *pronooumenoi* Myśląc zawczasu – Troszcząc się [[G4306]] WTV-PMP-NPM **καλα** *kala* dobre – piękne [[G2570]] WTA-APN **ου** *ou* nie [[G3756]] [[PRT-N]] **μονον** *monon* jedynie – tylko [[G3440]] [[ADV]] **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **κυριου** *kyriou* Panem [[G2962]] [[N-GSM]] **αλλα** *alla* ale [[G235]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **ανθρωπων** *anthrōpōn* ludźmi [[G444]] WTN-GPM
###### **2Kor 8,22**
 **συνεπεμψαμεν** *synepempsamen* Posłaliśmy razem z [[G4842]] WTV-AAI-1P **δε** *de* zaś [[G1161]] [[CONJ]] **αυτοις** *autois* nim [[G846]] WTP-DPM **τον** *ton* [[G3588]] [[T-ASM]] **αδελφον** *adelfon* brata [[G80]] [[N-ASM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ον** *hon* którego [[G3739]] WTR-ASM **εδοκιμασαμεν** *edokimasamen* wypróbowaliśmy [[G1381]] WTV-AAI-1P **εν** *en* w [[G1722]] [[PREP]] **πολλοις** *pollois* wielu [[G4183]] WTA-DPN **πολλακις** *pollakis* wielokrotnie – częstokroć [[G4178]] [[ADV]] **σπουδαιον** *spoudaion* (że) z wielkim zapałem – (że) gorliwym [[G4705]] WTA-ASM **οντα** *onta* będąc [[G5607]] WTV-PXP-ASM **νυνι** *nyni* teraz [[G3570]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **πολυ** *poly* wiele [[G4183]] WTA-ASN **σπουδαιοτερον** *spoudaioteron* pilniejszym – gorliwszym [[G4706]] WTA-ASM-C **πεποιθησει** *pepoithēsei* przekonaniu – przeświadczeniu [[G4006]] [[N-DSF]] **πολλη** *pollē* wielkie [[G4183]] WTA-DSF **τη** *tē* (to) [[G3588]] WTT-DSF **εις** *eis* do [[G1519]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP
###### **2Kor 8,23**
 **ειτε** *eite* Czy to [[G1535]] [[CONJ]] **υπερ** *hyper* co do [[G5228]] [[PREP]] **τιτου** *titou* Tytusa [[G5103]] [[N-GSM]] **κοινωνος** *koinōnos* wspólnik [[G2844]] [[N-NSM]] **εμος** *emos* mój [[G1699]] WTS-1NSM **και** *kai* i [[G2532]] [[CONJ]] **εις** *eis* względem [[G1519]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **συνεργος** *synergos* współpracownik [[G4904]] [[A-NSM]] **ειτε** *eite* czy to [[G1535]] [[CONJ]] **αδελφοι** *adelfoi* bracia [[G80]] WTN-NPM **ημων** *hēmōn* nasi [[G2257]] WTP-1GP **αποστολοι** *apostoloi* wysłannicy [[G652]] WTN-NPM **εκκλησιων** *ekklēsiōn* zgromadzeń – (społeczności) wywołanych [[G1577]] WTN-GPF **δοξα** *doksa* chwała [[G1391]] [[N-NSF]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **2Kor 8,24**
 **την** *tēn* [[G3588]] WTT-ASF **ουν** *oun* więc [[G3767]] [[CONJ]] **ενδειξιν** *endeiksin* wykazanie – dowód [[G1732]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **αγαπης** *agapēs* miłości [[G26]] [[N-GSF]] **υμων** *hymōn* waszej [[G5216]] WTP-2GP **και** *kai* i [[G2532]] [[CONJ]] **ημων** *hēmōn* naszej [[G2257]] WTP-1GP **καυχησεως** *kauchēseōs* chluby – chełpienia się [[G2746]] [[N-GSF]] **υπερ** *hyper* co do [[G5228]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **εις** *eis* względem [[G1519]] [[PREP]] **αυτους** *autous* nich [[G846]] [[P-APM]] **ενδειξασθε** *endeiksasthe* okazujcie – wykazujcie [[G1731]] WTV-AMM-2P **και** *kai* i [[G2532]] [[CONJ]] **εις** *eis* przed [[G1519]] [[PREP]] **προσωπον** *prosōpon* obliczem – twarzą [[G4383]] WTN-ASN **των** *tōn* [[G3588]] WTT-GPF **εκκλησιων** *ekklēsiōn* zgromadzeń – (społeczności) wywołanych [[G1577]] WTN-GPF
