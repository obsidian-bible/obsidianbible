# 2Krl 4 BT5
###### **2Krl 4,1**
 Pewna kobieta spośród żon synów prorockich zawołała do Elizeusza tymi słowami: «***Twój sługa, a mój mąż, umarł. A ty wiesz, że twój sługa bał się Pana. Lecz lichwiarz przyszedł, aby zabrać sobie dwoje moich dzieci na niewolników***».
###### **2Krl 4,2**
 Elizeusz zaś rzekł do niej: «***Co mógłbym uczynić dla ciebie? Wskaż mi, co posiadasz w mieszkaniu?***» Odpowiedziała: «***Służebnica twoja nie posiada niczego w mieszkaniu prócz oliwy, którą bym się mogła namaścić***».
###### **2Krl 4,3**
 On zaś rzekł: «***Idź, pożycz sobie z zewnątrz naczynia od wszystkich twoich sąsiadów, naczynia puste, i to niemało.***
###### **2Krl 4,4**
 ***Następnie wrócisz, zamkniesz drzwi za sobą i za synami i będziesz nalewała do tych wszystkich naczyń, a wypełnione odstawisz***».
###### **2Krl 4,5**
 Odeszła więc od niego. Następnie zamknęła drzwi za sobą i za swoimi synami. Ci jej donosili naczynia, a ona nalewała.
###### **2Krl 4,6**
 Kiedy naczynia się napełniły, rzekła do swego syna: «***Przynieś mi jeszcze naczynie!***» Odpowiedział jej: «***Już nie ma naczyń***». Wtedy oliwa przestała płynąć.
###### **2Krl 4,7**
 Poszła więc kobieta oznajmić mężowi Bożemu, który powiedział: «***Idź, sprzedaj oliwę, zwróć twój dług, z reszty zaś żyj ty i twoi synowie!***»
###### **2Krl 4,8**
 Pewnego dnia Elizeusz przechodził przez Szunem. Była tam kobieta bogata, która zawsze nakłaniała go do spożycia posiłku. Ilekroć więc przechodził, udawał się tam, by spożyć posiłek.
###### **2Krl 4,9**
 Powiedziała ona do swego męża: «***Oto jestem przekonana, że świętym mężem Bożym jest ten, który ciągle do nas przychodzi.***
###### **2Krl 4,10**
 ***Przygotujmy mały pokój na górze, obmurowany, i wstawmy tam dla niego lóżko, stół, krzesło i lampę. Kiedy przyjdzie do nas, to tam się uda***».
###### **2Krl 4,11**
 Gdy więc pewnego dnia Elizeusz tam przyszedł, udał się na gorę i tam ułożył się do snu.
###### **2Krl 4,12**
 I powiedział do Gechaziego, swojego sługi: «***Zawołaj tę Szunemitkę!***» Zawołał ją i stanęła przed nim.
###### **2Krl 4,13**
 Rzekł do niego: «***Proszę, powiedz jej: Oto podjęłaś dla nas te wszystkie starania. Co można uczynić dla ciebie? Czy może przemówić słowo za tobą do króla lub do dowódcy wojska?***» Odpowiedziała: «***Ja mieszkam pośród swego ludu***».
###### **2Krl 4,14**
 Mówił dalej: «***Co więc można uczynić dla niej?***» Odpowiedział Gechazi: «***Niestety, ona nie ma syna, a mąż jej jest stary***».
###### **2Krl 4,15**
 Rzekł więc: «***Zawołaj ją!***» Zawołał ją i stanęła przed wejściem.
###### **2Krl 4,16**
 I powiedział: «***O tej porze za rok będziesz pieściła syna***». Odpowiedziała: «***Ach, < mężu Boży >, panie mój! Nie oszukuj służebnicy twojej!***»
###### **2Krl 4,17**
 Potem kobieta poczęła i urodziła syna o tej samej porze, po roku, jak jej zapowiedział Elizeusz.
###### **2Krl 4,18**
 Chłopiec dorastał. Pewnego dnia wyszedł do swego ojca, do żniwiarzy,
###### **2Krl 4,19**
 i odezwał się do ojca: «***Moja głowa! Moja głowa!***» On zaś rozkazał słudze: «***Zabierz go do matki!***»
###### **2Krl 4,20**
 Zabrał go i zaprowadził do jego matki. Pozostał on na jej kolanach aż do południa i umarł.
###### **2Krl 4,21**
 Wtedy weszła ona i położyła go na łóżku męża Bożego, zamknęła za sobą drzwi i wyszła.
###### **2Krl 4,22**
 Zawołała swego męża, mówiąc: «***Przyślij mi, proszę, jednego ze sług z jedną oślicą. Pobiegnę do męża Bożego i wrócę***».
###### **2Krl 4,23**
 Odpowiedział: «***Czemu wyruszasz do niego dzisiaj? Nie ma ani nowiu, ani szabatu***». Odrzekła: «***Bądź spokojny!***»
###### **2Krl 4,24**
 Osiodłała oślicę i rzekła do sługi swego: «***Prowadź, ruszaj! Nie zatrzymuj mnie w drodze, aż ci rozkażę***».
###### **2Krl 4,25**
 Wyruszyła i dotarła do męża Bożego na górze Karmel. Kiedy mąż Boży ujrzał ją z daleka, rzekł do sługi swego, Gechaziego: «***Oto owa Szunemitka.***
###### **2Krl 4,26**
 ***Teraz więc biegnij, proszę, jej na spotkanie i zapytaj ją: Czy dobrze się miewasz? Czy dobrze się miewa twój mąż? Czy dobrze się miewa twoje dziecko?***» Odpowiedziała: «***Dobrze***».
###### **2Krl 4,27**
 Kiedy przyszła do męża Bożego na gorę, ujęła go za nogi. A Gechazi przybliżył się, żeby ją odsunąć. Lecz mąż Boży powiedział: «***Zostaw ją, bo dusza jej w smutku pogrążona, a Pan zakrył to przede mną i nie oznajmił mi***».
###### **2Krl 4,28**
 Ona zaś rzekła: «***Czy ja prosiłam pana mojego o syna? Czyż nie powiedziałam: Nie oszukuj mnie?***»
###### **2Krl 4,29**
 Wtedy [Elizeusz] powiedział Gechaziemu: «***Przepasz biodra, weź laskę moją w dłoń, a idź! Jeżeli spotkasz kogoś, nie pozdrawiaj go; a jeżeli ktoś ciebie pozdrowi, nie odpowiadaj mu. I położysz laskę moją na chłopcu***».
###### **2Krl 4,30**
 Lecz matka chłopca rzekła: «***Na życie Pana i na twoje życie: Nie opuszczę cię!***» Wtedy Elizeusz wstał i poszedł za nią.
###### **2Krl 4,31**
 Gechazi zaś wyprzedził ich i położył laskę na chłopcu, lecz nie było ani głosu, ani znaku życia. Gechazi więc wrócił do niego i oznajmił mu, mówiąc: «***Chłopiec się nie obudził***».
###### **2Krl 4,32**
 Elizeusz wszedł do domu, a oto na jego łóżku chłopiec leżał martwy.
###### **2Krl 4,33**
 Wszedł, zamknął drzwi za sobą i za nim i modlił się do Pana.
###### **2Krl 4,34**
 Następnie wszedł [na łóżko], rozciągnął się na dziecku, przyłożył twarz swoją do jego twarzy, oczy swoje do jego oczu, dłonie swoje do jego dłoni – i pochylony nad nim pozostawał tak, aż się rozgrzało ciało chłopca.
###### **2Krl 4,35**
 Znowu chodził po domu tam i z powrotem. Potem wszedł [na łóżko] i pochylił się nad nim. Wtedy chłopiec kichnął siedem razy i otworzył oczy.
###### **2Krl 4,36**
 On zaś zawołał Gechaziego, mówiąc: «***Zawołaj tę Szunemitkę!***» Kiedy ją zawołał, a przyszła do niego, powiedział: «***Zabierz twojego syna!***»
###### **2Krl 4,37**
 Weszła, upadła do jego stop i oddała mu pokłon aż do ziemi, następnie zabrała swojego syna i odeszła.
###### **2Krl 4,38**
 Elizeusz wrócił do Gilgal. A głód był w kraju. Gdy synowie proroccy siedzieli przed nim, rzekł do sługi swego: «***Nastaw wielki kocioł i ugotuj polewkę dla synów prorockich***».
###### **2Krl 4,39**
 Jeden zaś wyszedł na pole, aby nazbierać jarzyn. Znalazł dziką roślinę i narwał z niej pnączy dzikich kolokwint, napełniając nimi swój płaszcz. Wrócił i nakroił ich do kotła z polewką, bo ich nie znano.
###### **2Krl 4,40**
 Następnie podał ludziom do spożycia. Gdy tylko skosztowali polewki, krzyknęli: «***Śmierć jest w kotle, mężu Boży!***» i nie mogli jeść.
###### **2Krl 4,41**
 On zaś powiedział: «***Przynieście więc mąki!***» I wsypał ją do kotła, mówiąc: «***Nalej ludziom i niech jedzą!***» I już nie było nic szkodliwego w kotle.
###### **2Krl 4,42**
 Pewien człowiek przyszedł z Baal-Szalisza, przynosząc mężowi Bożemu chleb z pierwocin, dwadzieścia chlebów jęczmiennych i świeże zboże w worku. On zaś rozkazał: «***Podaj ludziom i niech jedzą!***»
###### **2Krl 4,43**
 Lecz sługa jego odrzekł: «***Jakże to rozdzielę między stu ludzi?***» A on odpowiedział: «***Podaj ludziom i niech jedzą, bo tak mówi Pan: Nasycą się i pozostawią resztki***».
###### **2Krl 4,44**
 Położył więc to przed nimi, a ci jedli i pozostawili resztki – według słowa Pańskiego.
# 2Krl 4 PAU
###### **2Krl 4,1**
 Pewna kobieta, żona jednego z uczniów proroków, błagała Elizeusza: „Twój sługa, mój mąż umarł! A ty wiesz dobrze, że był on człowiekiem bojącym się PANA. Lecz teraz przyszedł wierzyciel, który chce zabrać moich dwóch małych synów na swoich niewolników”.
###### **2Krl 4,2**
 Odpowiedział jej Elizeusz: „Cóż mogę uczynić dla ciebie? Powiedz mi, co masz w domu?”. Odrzekła: „Nie mam niczego, prócz dzbana oliwy!”.
###### **2Krl 4,3**
 On więc polecił jej: „Idź do sąsiadów i pożycz od nich naczynia; postaraj się o jak najwięcej takich pustych naczyń.
###### **2Krl 4,4**
 A kiedy wrócisz, zamknij drzwi za sobą i za swoimi synami i porozlewaj oliwę do wszystkich tych naczyń, a napełnione odstawiaj na bok”.
###### **2Krl 4,5**
 Wróciła do domu i zamknęła drzwi za sobą i za swoimi synami. Podstawiali jej naczynia, a ona nalewała do nich oliwę.
###### **2Krl 4,6**
 Kiedy naczynia były już pełne, powiedziała do syna: „Przynieś mi następne naczynie”. „Nie ma już naczyń” - odparł jej. W tym momencie oliwa przestała płynąć.
###### **2Krl 4,7**
 Poszła i powiedziała o tym człowiekowi Bożemu, który jej rozkazał: „Idź, sprzedaj oliwę i zapłać swój dług, a z reszty żyj ty i twoi synowie”.
###### **2Krl 4,8**
 Pewnego razu Elizeusz przechodził przez Szunem. Była tam zamożna kobieta, która bardzo nalegała, aby spożył u niej posiłek. Ilekroć więc znajdował się w tamtych okolicach, zatrzymywał się u niej, aby się posilić.
###### **2Krl 4,9**
 Po jakimś czasie powiedziała do swojego męża: „Wiem na pewno, że człowiek Boży, który stale do nas przychodzi, jest święty.
###### **2Krl 4,10**
 Urządźmy więc mały pokój na piętrze i wstawmy do niego łóżko, stół, krzesło i lampę, aby ilekroć przyjdzie do nas, mógł się tam zatrzymać”.
###### **2Krl 4,11**
 Gdy pewnego dnia znów ich odwiedził, udał się do pokoju na piętrze, aby tam odpocząć.
###### **2Krl 4,12**
 Po chwili rzekł do Gechaziego, swojego sługi: „Zawołaj tę Szunemitkę!”. Zawołał ją. A kiedy stanęła przed nim,
###### **2Krl 4,13**
 zwrócił się do swojego sługi: „Powiedz jej: «Cały ten trud podjęłaś dla nas. Co można więc dla ciebie zrobić? Czy wstawić się za tobą do króla albo do dowódcy wojska?»”. Ona jednak odparła: „Mieszkam przecież pośród mego ludu!”.
###### **2Krl 4,14**
 Gdy tak zastanawiał się głośno i pytał: „Cóż więc można dla niej uczynić?”, odezwał się Gechazi: „Ona nie ma syna, a jej mąż jest stary”.
###### **2Krl 4,15**
 Wtedy polecił: „Zawołaj ją z powrotem!”. Zawołał ją. A kiedy stanęła w drzwiach,
###### **2Krl 4,16**
 Elizeusz powiedział: „Za rok o tej porze będziesz pieścić syna!”. Odrzekła na to: „Ależ nie, mój panie, przecież jesteś człowiekiem Bożym, nie oszukuj więc swojej służebnicy!”.
###### **2Krl 4,17**
 Kobieta poczęła i rok później urodziła syna, w tym czasie, który zapowiedział jej Elizeusz.
###### **2Krl 4,18**
 Kiedy chłopiec podrósł, poszedł pewnego dnia do swojego ojca, który był wśród żniwiarzy.
###### **2Krl 4,19**
 Nagle chłopiec krzyknął do ojca: „Ach, moja głowa, moja głowa!”. Ojciec rozkazał swojemu słudze: „Zabierz go do matki!”.
###### **2Krl 4,20**
 Zabrał go i przyprowadził do matki. Chłopiec przesiedział na jej kolanach aż do południa, a potem umarł.
###### **2Krl 4,21**
 Wtedy weszła na piętro i kładąc go na łóżku człowieka Bożego, zamknęła za nim drzwi. Potem wyszła
###### **2Krl 4,22**
 i zawołała do swojego męża: „Przyślij mi któregoś ze sług z oślicą, bo spieszę się do człowieka Bożego i zaraz wrócę”.
###### **2Krl 4,23**
 „A po co idziesz do niego?” - zapytał. „Przecież dzisiaj nie jest ani nów księżyca, ani szabat”. „Nie szkodzi!” - odrzekła.
###### **2Krl 4,24**
 Osiodłała oślicę i zapowiedziała swojemu słudze: „Popędzaj ją i nie zwalniaj w drodze, dopóki ci nie powiem!”.
###### **2Krl 4,25**
 W pośpiechu przybyła do człowieka Bożego na górę Karmel. Kiedy człowiek Boży zobaczył ją z daleka, rzekł do swojego sługi, Gechaziego: „Patrz, to jest Szunemitka!
###### **2Krl 4,26**
 Biegnij na jej spotkanie i zapytaj: «Czy dobrze się czujesz? Czy dobrze się czuje twój mąż? Czy dobrze się czuje twoje dziecko?»”. Odpowiedziała: „Dobrze!”.
###### **2Krl 4,27**
 Kiedy dotarła do człowieka Bożego na górę, uchwyciła się jego nóg. Gechazi podszedł, aby ją odciągnąć, lecz człowiek Boży powstrzymał go: „Zostaw ją! Jest bowiem bardzo nieszczęśliwa, a PAN ukrył to przede mną i nic mi nie powiedział”.
###### **2Krl 4,28**
 Ona zaś zapytała: „Czyż prosiłam pana mego o syna? Czyż nie mówiłam: Nie oszukuj mnie?”.
###### **2Krl 4,29**
 Wtedy polecił Gechaziemu: „Przygotuj się do drogi! Weź do ręki moją laskę i idź! Jeśli spotkasz się z kimś, nie pozdrawiaj go, a jeśli ktoś inny ciebie pozdrowi, nie odpowiadaj mu. Potem połóż laskę na twarzy chłopca”.
###### **2Krl 4,30**
 Lecz matka chłopca zawołała: „Przysięgam na PANA i na twoje życie: Nie odejdę od ciebie!”. Bezzwłocznie więc poszedł z nią.
###### **2Krl 4,31**
 Gechazi natomiast wyprzedził ich i położył laskę na twarzy chłopca, ale nie wydał on żadnego głosu ani nie dał znaku życia. Wrócił zatem do Elizeusza i powiedział mu: „Chłopiec się nie obudził”.
###### **2Krl 4,32**
 Kiedy Elizeusz przybył do domu, zastał chłopca martwego, położonego na jego łóżku.
###### **2Krl 4,33**
 Wszedł, zamknął za sobą i za nim drzwi i zaczął modlić się do PANA.
###### **2Krl 4,34**
 Potem podszedł i położył się na chłopcu, przykładając swoje usta do jego ust, oczy do jego oczu, a dłonie do jego dłoni. Gdy tak leżał nad nim, ciało chłopca zaczęło się rozgrzewać.
###### **2Krl 4,35**
 Przeszedł się po domu tam i z powrotem, znowu podszedł i pochylił się nad nim. Wtedy chłopiec kichnął siedem razy i otworzył oczy.
###### **2Krl 4,36**
 Elizeusz wezwał Gechaziego i polecił mu: „Zawołaj tę Szunemitkę!”. Zawołał ją. Kiedy przyszła, Elizeusz powiedział do niej: „Zabierz swojego syna!”.
###### **2Krl 4,37**
 Ona zaś podeszła, upadła mu do nóg i oddała mu pokłon do ziemi. Potem wzięła swojego syna i wyszła.
###### **2Krl 4,38**
 Elizeusz powrócił do Gilgal. W kraju panował właśnie głód. Kiedy grupa proroków siedziała przed nim, polecił swojemu słudze: „Wstaw wielki kocioł i ugotuj zupę dla tych proroków”.
###### **2Krl 4,39**
 Jeden z nich wyszedł na pole, aby nazbierać trochę ziół. Znalazł dzikie pnącze i nazrywał cały płaszcz jego gorzkich owoców. Kiedy wrócił, wkroił je do kotła z zupą, bo nikt nie wiedział, co to za owoce.
###### **2Krl 4,40**
 Podano ją ludziom do jedzenia. Gdy tylko spróbowali, zaczęli krzyczeć: „Człowieku Boży, śmierć jest w kotle!”. I nie mogli jej jeść.
###### **2Krl 4,41**
 On zaś rzekł: „Przynieście trochę mąki”. Wrzucił ją do kotła i polecił: „Rozlej ludziom i niech jedzą!”. I nie było już nic zatrutego w kotle.
###### **2Krl 4,42**
 Pewien mężczyzna przyszedł z Baal-Szalisza i przyniósł człowiekowi Bożemu pierwsze chleby z nowego ziarna, razem dwadzieścia bochenków chleba jęczmiennego, oraz trochę kłosów świeżego zboża. On zaś nakazał: „Daj je ludziom do jedzenia”.
###### **2Krl 4,43**
 Ten jednak, który mu usługiwał, zawahał się: „Jakże to rozdzielę pomiędzy stu ludzi?”. „Daj je ludziom do jedzenia - powtórzył - gdyż tak mówi PAN: «Najedzą się i pozostawią resztki!»”.
###### **2Krl 4,44**
 Rozdzielił je zatem między nimi, a oni rzeczywiście najedli się i pozostawili resztki, zgodnie ze słowem PANA.
# 2Krl 4 BP
###### **2Krl 4,1**
 Pewna kobieta, żona [jednego] z synów prorockich, skarżyła się Elizeuszowi mówiąc: Sługa twój, mój mąż, umarł; a ty wiesz, że twój sługa bał się Jahwe. Przyszedł wierzyciel zabrać sobie dwoje moich dzieci za niewolników.
###### **2Krl 4,2**
 Elizeusz zapytał ją: Co mógłbym uczynić dla ciebie? Powiedz mi, co masz w domu? Odpowiedziała: Służebnica twoja nie ma nic w domu, prócz odrobiny oliwy.
###### **2Krl 4,3**
 Rzekł: Idź, pożycz sobie skądinąd naczyń, od wszystkich twoich sąsiadów, naczyń pustych, niemało.
###### **2Krl 4,4**
 Wejdź, zamknij drzwi za sobą i za swymi synami, wlej [oliwy] do wszystkich tych naczyń, napełnione zaś odstaw.
###### **2Krl 4,5**
 Odeszła więc od niego, zamknęła drzwi za sobą i za swoimi synami. Podczas gdy oni podstawiali jej [naczynia], ona zaś lała [do nich oliwę].
###### **2Krl 4,6**
 Gdy napełniła naczynia, rzekła do swego syna: Podstaw mi jeszcze naczyń. Odpowiedział jej: Nie ma więcej naczyń. Wtedy oliwa przestała się sączyć.
###### **2Krl 4,7**
 Poszła i oznajmiła [o tym] mężowi Bożemu. On zaś powiedział jej: Idź, sprzedaj oliwę i spłać swój dług. Z reszty utrzymuj siebie i swych synów.
###### **2Krl 4,8**
 Zdarzyło się pewnego dnia, że Elizeusz przechodził przez Szunem. Była tam zacna kobieta i zatrzymała go, aby zjadł [trochę] chleba. I tak się przyjęło, że ile razy przechodził, wstępował tam, aby zjeść chleba.
###### **2Krl 4,9**
 [Kiedyś] powiedziała swemu mężowi: Oto wiem, że ten [człowiek], który zawsze do nas przychodzi, jest świętym mężem Bożym.
###### **2Krl 4,10**
 Zróbmy mały, murowany pokoik na górze i wstawmy mu tam łóżko, stół, krzesło i świecznik. A kiedy się zdarzy, że przyjdzie do nas, będzie się mógł tam zatrzymać.
###### **2Krl 4,11**
 Pewnego dnia, gdy tam przybył, zatrzymał się w pokoiku na górze. Położył się tam
###### **2Krl 4,12**
 i rzekł do Gechaziego, swego sługi: Zawołaj tę Szunamitkę. Zawołał ją i stanęła przed nim.
###### **2Krl 4,13**
 Rzekł do niego: Spytaj jej: Oto troszczysz się o wszystkie te nasze potrzeby, co [chcesz], aby dla ciebie uczynić? Może trzeba przemówić za tobą do króla lub dowódcy wojska? Odpowiedziała: Ja mieszkam wśród swoich ludzi.
###### **2Krl 4,14**
 Spytał: Co więc [można] uczynić dla niej? Gechazi rzekł: Ach, ona nie ma syna, a jej mąż jest starcem.
###### **2Krl 4,15**
 Polecił więc: Zawołaj ją. Zawołał ją i stanęła u wejścia.
###### **2Krl 4,16**
 Powiedział [jej]: Za rok o tym czasie będziesz piastować syna. Odrzekła: Nie! Panie mój, mężu Boży, nie zwódź twojej sługi.
###### **2Krl 4,17**
 Kobieta poczęła i urodziła syna po roku o tym czasie, jak jej powiedział Elizeusz.
###### **2Krl 4,18**
 Chłopiec podrósł. [Jednego] dnia wyszedł do swego ojca do żniwiarzy.
###### **2Krl 4,19**
 [Nagle] zawołał do swego ojca: O moja głowa, moja głowa! [Ojciec] rzekł służącemu: Zanieś go do jego matki.
###### **2Krl 4,20**
 Wziął go więc i zaprowadził do jego matki. Na jej kolanach przebył aż do południa i umarł.
###### **2Krl 4,21**
 Poszła tedy, położyła go na łożu męża Bożego, zamknęła [drzwi] za sobą i wyszła.
###### **2Krl 4,22**
 Zawołała swego męża i poprosiła: Przyślij mi jednego ze sług i jedną z oślic. Pobiegnę do męża Bożego i wrócę.
###### **2Krl 4,23**
 Zapytał: Czemu chcesz iść do niego dzisiaj? Nie jest [to] ani nów, ani szabat. Odrzekła: Pokój [z tobą].
###### **2Krl 4,24**
 Osiodłała oślicę i powiedziała swemu słudze: Prowadź! Idź, nie wstrzymuj mej jazdy, chyba że ci rozkażę.
###### **2Krl 4,25**
 Ruszyła [w drogę] i przybyła do męża Bożego na górę Karmel. Gdy mąż Boży zobaczył ją z naprzeciwka, powiedział do Gechaziego, swojego sługi: Oto owa Szunamitka.
###### **2Krl 4,26**
 Wybiegnij teraz na jej spotkanie i pozdrów ją: Czy masz się dobrze? Czy dobrze się ma twój mąż? Czy dobrze się ma twój chłopczyk? Odpowiedziała: Dobrze.
###### **2Krl 4,27**
 Przyszła do męża Bożego na górę i objęła go za nogi. Gechazi zbliżył się, aby ją odsunąć, ale mąż Boży rzekł: Zostaw ją, bo jej dusza [jest przepojona] goryczą. Jahwe zaś zataił przede mną i nie wyjawił mi [przyczyny].
###### **2Krl 4,28**
 Odezwała się wtedy: Czy prosiłam pana mojego o syna? Czy nie mówiłam: nie zwódź mię?
###### **2Krl 4,29**
 [Elizeusz] polecił Gechaziemu: Przepasz swoje biodra, weź moją laskę w swą rękę i idź. Jeśli kogoś spotkasz, nie pozdrawiaj go, a jeśli cię kto pozdrowi, nie odpowiadaj mu. Połóż moją laskę na twarzy chłopca.
###### **2Krl 4,30**
 Ale matka chłopca zawołała: Na żyjącego Jahwe, na życie twojej duszy: nie opuszczę cię. Wstał więc i poszedł z nią.
###### **2Krl 4,31**
 Gechazi poszedł przed nimi i położył laskę na twarzy chłopca, lecz nie było ani głosu, ani [znaku] uwagi. Wrócił [wtedy] z powrotem naprzeciw [Elizeusza] i oznajmił mu mówiąc: Nie obudził się chłopiec.
###### **2Krl 4,32**
 Elizeusz wszedł do domu. Oto zmarły chłopiec [leżał] złożony na jego łożu.
###### **2Krl 4,33**
 Wszedł więc, zamknął drzwi za nimi obydwoma i modlił się do Jahwe.
###### **2Krl 4,34**
 Poszedł i położył się na chłopcu. Przyłożył swoje usta do jego ust, swoje oczy do jego oczu, swoje dłonie do jego dłoni i rozciągnął się na nim. Ciało chłopca się rozgrzało.
###### **2Krl 4,35**
 Wrócił, [zaczął] chodzić po domu to w tę to w tamtą stronę. [Potem] poszedł i [znów] rozciągnął się na nim. Chłopiec kichnął aż siedem razy i otworzył oczy.
###### **2Krl 4,36**
 [Wówczas] zawołał na Gechaziego i rzekł: Przywołaj ową Szunamitkę. Przywołał ją. A gdy przyszła do niego, rzekł: Zabierz sobie swego syna.
###### **2Krl 4,37**
 [Wtedy] weszła, przypadła do jego nóg, pokłoniła się mu głęboko ku ziemi, zabrała swego syna i wyszła. Odkażenie trującej potrawy
###### **2Krl 4,38**
 Elizeusz wrócił do Gilgal. W kraju był głód. Gdy synowie proroków siedzieli przed nim, rzekł do swego sługi: Nastaw wielki kocioł i ugotuj zupy dla synów prorockich.
###### **2Krl 4,39**
 Jeden wyszedł w pole, aby nazbierać polnej sałaty i znalazł dziki krzew winny. Narwał z niego pełen swój płaszcz polnych, oślich ogórków. Przyszedł i nakrajał do kotła [z] zupą, bo nie wiedziano [że to szkodliwe],
###### **2Krl 4,40**
 i podano mężczyznom do jedzenia. Gdy skosztowali tej zupy, poczęli krzyczeć i wołać: Śmierć w kotle, mężu Boży. I nie mogli jeść.
###### **2Krl 4,41**
 Wtedy [Elizeusz] rzekł: Przynieś mąki. Wsypał [ją] do kotła i rzekł: Podaj ludziom, aby jedli. I nie było [już] nic szkodliwego w kotle.
###### **2Krl 4,42**
 [Pewien] człowiek przyszedł z Baal Szalisza i przyniósł mężowi Bożemu chleb z pierwocin, dwadzieścia chlebów jęczmiennych i zboże w kłosach. [Elizeusz] powiedział: Daj ludziom, aby jedli.
###### **2Krl 4,43**
 [Ale] służący jego rzekł: Jak mogę to położyć przed stu mężczyzn? Odrzekł: Daj ludziom, aby jedli, albowiem tak mówi Jahwe: Będzie się jeść i zostanie.
###### **2Krl 4,44**
 Położył więc przed nimi. Jedli i [jeszcze] zostawili [resztki] - według słowa Jahwe.
# 2Krl 4 BR
###### **2Krl 4,1**
 Pewna kobieta, żona jednego z uczniów prorockich, zaczęła uskarżać się Elizeuszowi, mówiąc: Mój mąż, a twój sługa, nie żyje, a ty wiesz przecież, że był to człowiek bogobojny. A oto przyszedł teraz wierzyciel, żeby [za dług] zabrać mi dwoje moich dzieci do siebie i uczynić je swoimi niewolnikami.
###### **2Krl 4,2**
 Powiedział więc Elizeusz: Co mógłbym uczynić dla ciebie? Powiedz mi, co masz w domu. A ona odpowiedziała: Twoja służebnica nie ma nic w domu poza jedną baryłką oliwy.
###### **2Krl 4,3**
 Wtedy on powiedział: Idź do wszystkich twoich sąsiadów i pożycz od nich wszystkie, jakie tylko mają, puste naczynia. Postaraj się przynieść ich niemało.
###### **2Krl 4,4**
 Kiedy wrócisz do siebie, zamknij się w domu razem z twymi dziećmi i zacznij napełniać oliwą wszystkie [pożyczone] naczynia. Każde naczynie już pełne odstawisz na bok.
###### **2Krl 4,5**
 Odeszła tedy kobieta, zamknęła się ze swymi dziećmi w domu, synowie podawali jej naczynia i zaczęła je napełniać [oliwą].
###### **2Krl 4,6**
 Kiedy wszystkie naczynia już były pełne, powiedziała do swojego syna: Przysuń mi tu jeszcze jakieś naczynie! Ale on odpowiedział: Już nie ma [pustych] naczyń. Wtedy też przestała płynąć oliwa.
###### **2Krl 4,7**
 Kiedy opowiedziała o tym wszystkim mężowi Bożemu, on rzekł na to: Idź, sprzedaj oliwę i zapłać twoje długi. Z tego, co pozostanie będziesz mogła żyć ty i twoi synowie.
###### **2Krl 4,8**
 Pewnego dnia Elizeusz przechodził przez Szunem. Spotkał tam pewną zamożną kobietę, która zawsze bardzo nalegała, żeby coś zjadł u niej. Ilekroć więc przechodził koło jej domu, wstępował [do niej], żeby się posilić.
###### **2Krl 4,9**
 Pewnego dnia powiedziała owa kobieta do swojego męża: Ja wiem, że ten człowiek, który często wstępuje do nas, jest prawdziwie świętym mężem Bożym.
###### **2Krl 4,10**
 Przygotujmy mu na górze malutki, obmurowany pokoik; postawmy tam coś do spania, jakiś stolik, krzesło, świecznik, żeby mógł sobie tam przebywać, kiedy przyjdzie do nas.
###### **2Krl 4,11**
 Gdy więc Elizeusz zjawił się przy najbliższej okazji w Szunem, poszedł już do swojego pokoiku i tam udał się na spoczynek.
###### **2Krl 4,12**
 Do swojego zaś sługi Gechaziego powiedział: Zawołaj tę Szunemitkę. Gechazi ją zawołał, a kiedy już przyszła i stanęła przed Elizeuszem,
###### **2Krl 4,13**
 ten powiedział do Gechaziego: Powiedz jej tak: Okazałaś tyle troski o nas. Co moglibyśmy uczynić ci za to? Czy mamy powiedzieć coś o tobie królowi albo dowódcy wojska? A ona odpowiedziała Gechaziemu: Mieszkam pośród mojego ludu.
###### **2Krl 4,14**
 Zapytał tedy Elizeusz: Co moglibyśmy zrobić dla niej? Gechazi odpowiedział: Ona nie ma syna, a jej mąż jest już w podeszłym wieku.
###### **2Krl 4,15**
 Powiedział tedy Elizeusz: Każ jej wejść do środka! Gechazi ją zawołał. Kiedy stanęła w drzwiach,
###### **2Krl 4,16**
 Elizeusz powiedział do niej: W przyszłym roku o tej porze będziesz pieściła własnego syna! A ona na to: O nie, panie mój, mężu Boży! Racz nie oszukiwać twojej służebnicy.
###### **2Krl 4,17**
 Ale kobieta ta poczęła i w rok później, dokładnie o tej samej porze, porodziła syna, tak jak jej przepowiedział Elizeusz.
###### **2Krl 4,18**
 Dziecko rosło. Pewnego dnia poszło na pole i znalazłszy swojego ojca między żniwiarzami, zaczęło narzekać:
###### **2Krl 4,19**
 Ach, moja głowa! Rzekł tedy ojciec do swojego sługi: Zanieś je do matki.
###### **2Krl 4,20**
 Sługa zaniósł dziecko do matki. Na jej kolanach zostało aż do południa, a potem zmarło.
###### **2Krl 4,21**
 Matka zaniosła je na górę, położyła na łóżku męża Bożego, zamknęła drzwi i wyszła.
###### **2Krl 4,22**
 Potem zawołała swego męża i powiedziała: Przyślij mi, bardzo cię proszę, jednego z twoich sług oraz jedną oślicę, żebym mogła odnaleźć męża Bożego. Wrócę niebawem.
###### **2Krl 4,23**
 Lecz mąż jej odpowiedział: Dlaczego mamy go szukać właśnie dzisiaj? Przecież to ani nów księżyca, ani szabat. Ale kobieta odpowiedziała: Bądź spokojny!
###### **2Krl 4,24**
 I osiodławszy oślicę, rzekła do swego sługi: Prowadź mnie, naprzód! Nie zatrzymuj się nigdzie po drodze, dopóki ci nie powiem, gdzie masz stanąć.
###### **2Krl 4,25**
 I ruszyła w drogę, by odnaleźć męża Bożego na górze Karmel. Mąż Boży, zobaczywszy ją z daleka, powiedział do swego sługi Gechaziego: Oto owa Szunemitka!
###### **2Krl 4,26**
 Wybiegnij jej na spotkanie i zapytaj, jak się czuje ona sama i jak się mają jej mąż i dziecko. A ona odrzekła: Dobrze!
###### **2Krl 4,27**
 Kiedy już znalazła się na górze przed mężem Bożym, upadła mu do nóg. Gechazi podszedł, żeby ją odsunąć, ale mąż Boży powiedział: Zostaw ją, jest bardzo przygnębiona, a Jahwe ukrył to przede mną i jeszcze mi tego nie objawił.
###### **2Krl 4,28**
 Wtedy ona powiedziała: Czy ja sama prosiłam mojego pana o syna? Czyż nie mówiłam, żebyś nie oszukiwał?
###### **2Krl 4,29**
 Powiedział tedy Elizeusz do Gechaziego: Przepasz swoje biodra, weź do ręki [mój] kij i ruszaj w drogę. Nikogo po drodze nie pozdrawiaj, nie odpowiadaj na żadne pytania. [Gdy przyjdziesz na miejsce], dotknij twarzy dziecka moim kijem.
###### **2Krl 4,30**
 A matka chłopca powiedziała: Na życie Jahwe i na twoje życie, ja już stąd nie odejdę. Wtedy Elizeusz wstał i poszedł za nią.
###### **2Krl 4,31**
 Gechazi przybył na miejsce pierwszy i zaraz dotknął laską [Elizeusza] twarzy dziecka. Lecz ani nie dał się słyszeć żaden głos, ani nie było widać żadnego znaku życia. Pobiegł więc z powrotem do Elizeusza i oznajmił mu to, mówiąc: Dziecko się nie obudziło!
###### **2Krl 4,32**
 Kiedy Elizeusz wszedł do swojej izby, zobaczył na swoim łóżku martwego chłopca.
###### **2Krl 4,33**
 Wszedłszy do środka, zamknął za sobą drzwi i zaczął modlić się do Jahwe.
###### **2Krl 4,34**
 Potem poszedł, położył się na chłopcu, przykładając swoje usta do jego ust, swoje oczy do jego oczu, swoje ręce do jego rąk, i tak przez jakiś czas na nim leżał. Kiedy rozgrzało się nieco ciało chłopca,
###### **2Krl 4,35**
 Elizeusz wstał i zaczął się przechadzać tam i z powrotem po izbie. Potem znów podszedł do łóżka i położył się na chłopcu. W końcu chłopiec ziewnął siedem razy i otworzył oczy.
###### **2Krl 4,36**
 Zawołał wtedy Elizeusz Gechaziego i rzekł: Przywołaj tu Szunemitkę. Przywołał ją więc Gechazi, a gdy stanęła przed Elizeuszem, ten powiedział jej: Weź sobie swego syna.
###### **2Krl 4,37**
 A ona upadła mu do nóg i oddała głęboki pokłon. Potem wzięła swego syna i wyszła.
###### **2Krl 4,38**
 Kiedy Elizeusz wrócił do Gilgal, cały kraj ogarniała klęska głodu. Gdy zebrali się wokół niego synowie proroków i zasiedli przed nim, powiedział do swego sługi: Nastaw wielki kocioł i przygotuj jedzenie dla uczniów prorockich.
###### **2Krl 4,39**
 A jeden z nich wyszedł na pole, żeby zbierać zioła. Znalazł przy tym roślinę w rodzaju dzikiego wina i nazbierał z niej tyle owoców, ile mógł pomieścić w swoim płaszczu. Kiedy wrócił do domu, owoce drobno pokrojono i wrzucono do kotła, w którym gotowało się jedzenie. Owoców tych nikt z obecnych nie znał.
###### **2Krl 4,40**
 Potem podano ludziom jedzenie. A oni spróbowawszy potrawy, zaczęli wołać: Mężu Boży, toż w tym kotle czyha na nas śmierć! I przestali jeść.
###### **2Krl 4,41**
 Wtedy powiedział Elizeusz: Przynieście mi tu trochę mąki. Potem, wsypawszy mąkę do kotła, powiedział: teraz dajcie to ludziom, niech jedzą. I nie było już nic szkodliwego w kotle.
###### **2Krl 4,42**
 Pewien człowiek przybył z Baal-Szalisza, przynosząc mężowi Bożemu chleb - dwadzieścia bochenków chleba - ze świeżo zebranego jęczmienia oraz trochę młodego ziarna w worku. Elizeusz powiedział: Daj to ludziom, niech jedzą.
###### **2Krl 4,43**
 Lecz jego sługa rzekł na to: Jakże ja tym obdzielę sto osób? Elizeusz powiedział jednak po raz drugi: Daj ludziom, niech jedzą, gdyż Jahwe powiedział tak: Będą jedli i jeszcze pozostawią resztki.
###### **2Krl 4,44**
 Porozkładał więc przed nimi chleb. Najedli się wszyscy i jeszcze pozostały resztki, zgodnie ze słowami Jahwe.
# 2Krl 4 WUJ
###### **2Krl 4,1**
 A niewiasta jedna z żon prorockich wołała do Elizeusza, mówiąc: Sługa twój mąż mój umarł, a ty wiesz iż sługa twój był bojący się Pana: a oto przyszedł pożyczalnik, aby wziął dwu synów moich, za niewolniki sobie.
###### **2Krl 4,2**
 Której rzekł Elizeusz: Cóż chcesz, żebych ci uczynił? Powiedz mi co masz w domu swoim? A ona odpowiedziała: Nie mam służebnica twoja nic w domu moim, jedno trochę oliwy, którąbym się mazała.
###### **2Krl 4,3**
 Której rzekł: idź napożyczaj u wszech sąsiad twoich naczynia próżnego nie mało.
###### **2Krl 4,4**
 A wnidź, i zamkni drzwi swoje, gdy będziesz wewnątrz ty i synowie twoi: nalejże ztamtąd we wszystkie te naczynia: a gdy pełne będą, weźmiesz.
###### **2Krl 4,5**
 A tak poszła niewiasta, i zamknęła drzwi za sobą, i za syny swemi: oni podawali naczynia, a ona nalewała.
###### **2Krl 4,6**
 A gdy już pełne były naczynia, rzekła do syna swego: Przynieś mi jeszcze naczynie. A on odpowiedział. Nie mam. I stanęła oliwa.
###### **2Krl 4,7**
 I przyszła ona, i powiedziała mężowi Bożemu. A on: Idź, pry, przedaj oliwę, a oddaj pożyczalnikowi twemu: a ty i synowie twoi żywcie się ostatkiem.
###### **2Krl 4,8**
 I przyszedł dzień jeden, i szedł Elizeusz przez Sunam: a była tam niewiasta wielka, która go zatrzymała, aby jadł chleb: a gdy tamtędy często chadzał, wstępował do niej chleba jeść.
###### **2Krl 4,9**
 Która rzekła do męża swego: Widzę, że to jest mąż Boży świety, który tedy często przechodzi.
###### **2Krl 4,10**
 Uczyńmy mu tedy salę małą, a postawmy mu w niej łóżko i stół, i krzesło, i świecznik, że gdy przyjdzie do nas, będzie tam mieszkał.
###### **2Krl 4,11**
 Przyszedł tedy dzień jeden, i przyszedszy wstąpił do onej sale, i odpoczywał tam.
###### **2Krl 4,12**
 I rzekł do Giezy służebnika swego: Zawołaj tej Sunamitki. Gdy jej zawołał, a ona stanęła przed nim,
###### **2Krl 4,13**
 Rzekł do sługi swego: Mów do niej: Otoś nam pilnie we wszystkiem służyła, cóż chcesz, abym ci uczynił? Maszli jaką potrzebę, a chcesz, abych mówił do króla, abo do hetmana wojska. Która odpowiedziała: W pośrodku ludu mego mieszkam.
###### **2Krl 4,14**
 I rzekł: Cóż tedy chce że jej uczynię? I rzekł Giezy: Nie pytaj: syna bowiem nie ma, a mąż jej stary jest.
###### **2Krl 4,15**
 Kazał tedy, aby jej zawołał: która gdy zawołana była i stanęła u drzwi,
###### **2Krl 4,16**
 Rzekł do niej: O tym czasie, i o tejże godzinie, jeśli Bóg da zdrowie będziesz miała w żywocie syna. A ona odpowiedziała: Nie chciej proszę, panie mój, mężu Boży, nie chciej kłamać służebnicy twojej.
###### **2Krl 4,17**
 I poczęła niewiasta i porodziła syna tegoż czasu i godziny, którą powiedział Elizeusz.
###### **2Krl 4,18**
 I urosło dziecię. A gdy był jeden dzień i wyszedszy szło do ojca swego do żeńców,
###### **2Krl 4,19**
 Rzekło ojcu swemu: Głowa mię boli, głowa mię boli. A on rzekł słudze: Weź a dowiedź go do matki jego.
###### **2Krl 4,20**
 Który gdy go wziął, i przywiódł do matki jego położyła go na łonie swem aż do południa, i umarł.
###### **2Krl 4,21**
 I weszła na górę, i położyła go na łóżku człeka Bożego, i zamknęła drzwi: a wyszedszy,
###### **2Krl 4,22**
 Zawołała męża swego, i rzekła: Pośli proszę cię ze mną jednego z sług, i oślicę, że pobieżę aż do człowieka Bożego, i wrócę się.
###### **2Krl 4,23**
 Który jej rzekł: Dla czegóż idziesz do niego? Dziś nie jest nów, ani Sabbath. Ona odpowiedziała: Pójdę
###### **2Krl 4,24**
 I osiodłała oślicę, i przykazała słudze: Poganiaj a spiesz się, żebyś mi nie mieszkał w drodze: a czyń to coć każę.
###### **2Krl 4,25**
 Jachała tedy i przyjachała do męża Bożego na górę Karmeli. I gdy ją ujrzał mąż Boży zprzeciwia, rzekł do Giezego sługi swego: Oto Sunamitka ona:
###### **2Krl 4,26**
 Idź tedy przeciwko niej, a rzecz jej: Dobrzeć li się powodzi, mężowi twemu, i synowi twemu? Która odpowiedziała: Dobrze.
###### **2Krl 4,27**
 A gdy przyszła do męża Bożego na górę, uchwyciła się nóg jego: i przystąpił, Giezy aby ją odwiódł od niego. I rzekł człowiek Boży: Daj jej pokój: bo dusza jej w gorzkości jest, a Pan zataił przedemną, i nie oznajmił mi.
###### **2Krl 4,28**
 Która mu rzekła: Azam prosiła syna u pana mego? azam ci nie mówiła: Nie śmiej się ze mnie?
###### **2Krl 4,29**
 A on rzekł do Giezego: Przepasz biodra twoje, a weźmi moję w rękę twoję, a idź. Jeśli cię człowiek potka, nie pozdrawiaj go: I jeśli cię kto pozdrowi, nie odpowiadaj mu: i położysz laskę moję na oblicze dziecięcia.
###### **2Krl 4,30**
 A matka dziecięcia rzekła: Żywie Pan, i żywie dusza twoja niepuszczę się ciebie. Wstał tedy i poszedł za nią.
###### **2Krl 4,31**
 A Giezy uprzedził je był, i położył był laskę na obliczu dziecięcia, i nie było głosu ani czucia: i wrócił się przeciwko niemu, i powiedział mu, rzekąc: Nie wstałoć dziecię.
###### **2Krl 4,32**
 Wszedł tedy Elizeusz do domu, a ono dziecię umarłe leżało na łóżku jego:
###### **2Krl 4,33**
 A wszedszy zamknął drzwi za sobą i za dziecięciem: i modlił się do Pana.
###### **2Krl 4,34**
 I wstąpił i położył się na dziecięciu: i położył usta swe na usta jego, i oczy swe na oczy jego; i ręce swe na ręce jego: i nachylił się na nie, i zagrzało się ciało dziecięcia.
###### **2Krl 4,35**
 A on wróciwszy aię przechodził się po domu raz i tam i sam: i wstąpił i położył się na nim: i ziewnęło dziecię siedm kroć, i oczy otworzyło,
###### **2Krl 4,36**
 A on zawoławszy Giezego, rzekł mu: Zawołaj tej Sunamitki. Która wezwana, weszła do niego. Który rzekł: Weźmi syna swego.
###### **2Krl 4,37**
 Przyszła ona, i upadła u nóg jego, i pokłoniła się do ziemie: i wzięła syna swego, i wyszła.
###### **2Krl 4,38**
 A Elizeusz wrócił się do Galgal. A głód był w ziemi, i synowie proroccy mieszkali przed nim. I rzekł jednemu z sług swoich: Przystaw garniec wielki, a uwarz potrawę synom prorockim.
###### **2Krl 4,39**
 I wyszedł jeden na pole, aby zbierał zioła polne: i nalazł jakoby macicę winną leśną, i nazbierał z niej coloquintid polnych i napełnił płaszcz swój, i wróciwszy się nakrajał ich w garniec potrawy: bo nie wiedział co było.
###### **2Krl 4,40**
 Nalali tedy towarzyszom, aby jedli: a gdy skosztowali warzej, zawołali mówiąc: Śmierć w garncu, mężu Boży. I nie mogli jeść.
###### **2Krl 4,41**
 A on: Przynieście, pry, mąki. A gdy przynieśli, wsypał w garniec, i rzekł: Nalej gromadzie, aby jedli. I nie było więcej żadnej gorzkości w garncu.
###### **2Krl 4,42**
 A mąż niektóry przyszedł z Baalsalisa, niosąc mężowi Bożemu chleb pierwocin, dwadzieścia chlebów jęczmiennych, i zboże nowe w biesadze swojej. A on rzekł: Daj ludowi, żeby jadł.
###### **2Krl 4,43**
 I odpowiedział mu sługa jego: A wieleż to jest, abych położył przed sto mężów? Znowu on rzekł: Daj ludowi, żeby jadł, bo to mówi Pan: Będą jeść i zbędzie.
###### **2Krl 4,44**
 A tak położył przed nie: który jedli, i zbyło według słowa Pańskiego.
