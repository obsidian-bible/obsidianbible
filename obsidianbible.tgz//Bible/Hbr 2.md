# Hbr 2 BT5
###### **Hbr 2,1**
 Dlatego potrzeba, byśmy z jak największą pilnością zwracali uwagę na to, co usłyszeliśmy, abyśmy przypadkiem nie zeszli na bezdroża.
###### **Hbr 2,2**
 Jeśli bowiem objawiona przez aniołów mowa okazała się mocna, a wszelkie przekroczenie i nieposłuszeństwo otrzymało słuszną zapłatę,
###### **Hbr 2,3**
 jakże my unikniemy [kary], jeśli nie będziemy się troszczyć o tak cenne zbawienie? Było ono głoszone na początku przez Pana, a umocnione w nas przez tych, którzy je słyszeli.
###### **Hbr 2,4**
 Bóg zaś uwierzytelnił je znakami, cudami, różnorakimi przejawami mocy i udzielaniem Ducha Świętego według swej woli.
###### **Hbr 2,5**
 Nie aniołom bowiem poddał przyszły świat, o którym mówimy.
###### **Hbr 2,6**
 Ktoś to gdzieś potwierdził uroczyście, mówiąc:Czym jest człowiek, że pamiętasz o nim, albo syn człowieczy, że się troszczysz o niego;
###### **Hbr 2,7**
 mało co mniejszym uczyniłeś go od aniołów,chwałą i czcią go uwieńczyłeś.
###### **Hbr 2,8**
 Wszystko poddałeś pod jego stopy. Ponieważ zaś poddał Mu wszystko, nic nie zostawił, co by nie było Mu poddane. Teraz wszakże nie widzimy jeszcze, aby wszystko było Mu poddane.
###### **Hbr 2,9**
 Widzimy natomiast Jezusa, który mało co od aniołów był mniejszy, chwałą i czcią uwieńczonego za mękę śmierci, iż z łaski Bożej zaznał śmierci za każdego[człowieka].
###### **Hbr 2,10**
 Przystało bowiem Temu, dla którego wszystko i przez którego wszystko [istnieje], który wielu synów do chwały doprowadza, aby przewodnika ich zbawienia udoskonalił przez cierpienia.
###### **Hbr 2,11**
 Tak bowiem Ten, który uświęca, jak ci, którzy mają być uświęceni, od Jednego wszyscy [pochodzą]. Z tej to przyczyny nie wstydzi się nazywać ich braćmi swymi, mówiąc:
###### **Hbr 2,12**
 Oznajmię imię Twoje braciom moim, pośrodku zgromadzenia będę Cię wychwalał.
###### **Hbr 2,13**
 I znowu:Ufność w Nim pokładać będę. I znowu:Oto Ja i dzieci moje, które Mi dał Bóg.
###### **Hbr 2,14**
 Ponieważ zaś dzieci mają udział we krwi i w ciele, dlatego i On także bez żadnej różnicy otrzymał w nich udział, aby przez śmierć pokonać tego, który dzierżył władzę nad śmiercią, to jest diabła,
###### **Hbr 2,15**
 i aby uwolnić tych wszystkich, którzy całe życie przez bojaźń śmierci podlegli byli niewoli.
###### **Hbr 2,16**
 Zaiste bowiem nie aniołów przygarnia, ale przygarnia potomstwo Abrahamowe.
###### **Hbr 2,17**
 Dlatego musiał się upodobnić pod każdym względem do braci, aby stał się miłosiernym i wiernym arcykapłanem w tym, co się odnosi do Boga – dla przebłagania za grzechy ludu.
###### **Hbr 2,18**
 Przez to bowiem, co sam wycierpiał poddany próbie, może przyjść z pomocą tym, którzy jej podlegają.
# Hbr 2 PAU
###### **Hbr 2,1**
 Musimy więc pilnie rozważać to, co usłyszeliśmy, jeśli nie chcemy minąć się z celem.
###### **Hbr 2,2**
 Skoro bowiem słowo ogłoszone przez aniołów okazało się tak wiążące, a wszelkie przekroczenie i nieposłuszeństwo otrzymało słuszną odpłatę,
###### **Hbr 2,3**
 to jakże my jej unikniemy, jeśli zlekceważymy tak wielkie zbawienie! Zaczął je głosić Pan, a Jego słuchacze je nam potwierdzili.
###### **Hbr 2,4**
 Sam Bóg zaś poświadczył je cudownymi znakami i różnymi przejawami mocy Ducha Świętego, udzielanego zgodnie z Bożą wolą.
###### **Hbr 2,5**
 Przecież nie aniołom poddał On przyszły świat, o którym mówimy.
###### **Hbr 2,6**
 Ktoś przekazał o tym następujące świadectwo: Czym jest człowiek, że o nim pamiętasz, albo syn człowieczy, że troszczysz się o niego?
###### **Hbr 2,7**
 Uczyniłeś go niewiele mniejszym od aniołów, chwałą i czcią go ukoronowałeś...
###### **Hbr 2,8**
 Wszystko poddałeś pod jego stopy! Otóż skoro poddał mu wszystko, to nie zostawił niczego, co nie byłoby mu poddane. Na razie jednak jeszcze nie widzimy, by wszystko było mu poddane.
###### **Hbr 2,9**
 Natomiast w Tym, który został uczyniony niewiele mniejszym od aniołów, dostrzegamy Jezusa, ukoronowanego chwałą i czcią dzięki śmiertelnym cierpieniom! A zatem z łaski Bożej zaznał On śmierci za wszystkich!
###### **Hbr 2,10**
 Otóż wypadało, aby Ten, który jest przyczyną i celem wszystkiego, który wielu synów chce doprowadzić do chwały, udoskonalił przez cierpienie dawcę ich zbawienia.
###### **Hbr 2,11**
 Zarówno bowiem Uświęcający, jak i uświęcani, wszyscy wywodzą się z Jednego. Z tej to przyczyny nie wstydzi się nazwać ich swymi braćmi:
###### **Hbr 2,12**
 Będę głosił Twoje imię moim braciom, będę Cię chwalił pośród zgromadzenia!
###### **Hbr 2,13**
 A także: Będę pokładał w Nim ufność! Oraz: Oto Ja i dzieci, które dał Mi Bóg!
###### **Hbr 2,14**
 Skoro więc dzieci otrzymały udział we krwi i ciele, to również On sam chciał mieć w nich udział, aby przez śmierć mógł pokonać diabła, dzierżącego władzę nad śmiercią,
###### **Hbr 2,15**
 i aby uwolnić tych, którzy bojąc się śmierci, całe życie podlegali niewoli.
###### **Hbr 2,16**
 Przychodzi On bowiem z pomocą nie aniołom, lecz potomstwu Abrahama!
###### **Hbr 2,17**
 Toteż musiał we wszystkim upodobnić się do braci, aby stać się miłosiernym, a zarazem wiarygodnym wobec Boga najwyższym kapłanem, który zgładzi grzechy ludu.
###### **Hbr 2,18**
 Skoro bowiem sam doświadczył pokusy, potrafi przyjść z pomocą kuszonym!
# Hbr 2 BP
###### **Hbr 2,1**
 Musimy zatem bardzo pilnie zważać na to, cośmy usłyszeli, żebyśmy nie minęli się z celem.
###### **Hbr 2,2**
 Jeśli bowiem słowo wypowiedziane przez aniołów okazało się tak prawomocne, że wszelkie wykroczenie i nieposłuszeństwo zostało słusznie ukarane,
###### **Hbr 2,3**
 to jakżeż my ocalejemy, jeśli nie zatroszczymy się o tak cenne zbawienie? Najpierw było ono ogłaszane przez Pana, następnie zostało nam przekazane jako pewne przez tych, którzy je słyszeli.
###### **Hbr 2,4**
 Sam Bóg dołączył swoje świadectwo przez znaki, cuda i różnorodne czyny wykazujące moc oraz przejawy działania Ducha Świętego rozdzielane według Jego upodobania.
###### **Hbr 2,5**
 Przecież nie aniołom poddał ten przyszły świat, o którym mówimy.
###### **Hbr 2,6**
 Ktoś to już przecież gdzieś stwierdził, mówiąc: "Kim jest człowiek, że pamiętasz o nim, czy syn człowieczy, że nim się zajmujesz?
###### **Hbr 2,7**
 Uczyniłeś go niewiele mniejszym od aniołów, chwałą i czcią go uwieńczyłeś.
###### **Hbr 2,8**
 wszystko poddałeś pod jego stopy".
###### **Hbr 2,9**
 Owym zaś "niewiele mniejszym od aniołów" jest, jak widzimy, Jezus przez śmierć męczeńską "chwałą i czcią uwieńczony", skoro z łaski Bożej za wszystkich umarł.
###### **Hbr 2,10**
 Wypadało przecież, żeby Ten, dla którego jest wszystko i przez którego wszystko się stało, gdy miał doprowadzić wielu synów do chwały, uczynił pierwszego sprawcę ich zbawienia doskonałym przez cierpienie.
###### **Hbr 2,11**
 Uświęcający bowiem i uświęceni - wszyscy pochodzą od Jednego, dlatego nie wstydzi się nazwać ich braćmi,
###### **Hbr 2,12**
 mówiąc: "Ogłoszę moim braciom Twoje imię, w zgromadzeniu będę Cię wysławiał",
###### **Hbr 2,13**
 i znowu: "Ja będę w Nim pokładał ufność", i znowu: "Otom ja i dzieci, które mi dał Bóg".
###### **Hbr 2,14**
 Skoro zaś dzieci uczestniczą w naturze ludzkiej, On także otrzymał w niej udział, aby przez śmierć pozbawić mocy tego, który rządził śmiercią, mianowicie diabła,
###### **Hbr 2,15**
 i aby uwolnić wszystkich, którzy w lęku przed śmiercią przez całe życie byli skazani na niewolę.
###### **Hbr 2,16**
 Przecież nie aniołami się zajmuje, ale "troszczy się o potomstwo Abrahama".
###### **Hbr 2,17**
 Zatem musiał pod każdym względem upodobnić się do braci, aby stać się miłosiernym i wiernym arcykapłanem w sprawach Bożych, dla przejednania za winy ludu.
###### **Hbr 2,18**
 Właśnie dlatego, że On sam doznał, czym jest pokusa, może wspomagać kuszonych.
# Hbr 2 BR
###### **Hbr 2,1**
 Dlatego też musimy bardzo zdecydowanie trwać przy tym, cośmy słyszeli, abyśmy przypadkiem nie zeszli na bezdroża.
###### **Hbr 2,2**
 Jeżeli bowiem to, co głosili aniołowie, okazało się tak stanowcze, a wszelkie wykroczenia oraz przejawy nieuległości spotkały się z zasłużoną karą,
###### **Hbr 2,3**
 to czyż my zdołamy uniknąć nieszczęścia, jeśli nie będziemy zabiegać o zbawienie, które - jako coś bardzo cennego - było nam ogłoszone na początku przez samego Pana, a potem zostało potwierdzone w swojej wielkości przez tych, którzy ową naukę słyszeli?
###### **Hbr 2,4**
 Ponadto zaś uwierzytelnił je Bóg cudami, znakami niezwykłymi i przejawami różnych mocy oraz darami Ducha Świętego rozdzielanymi według własnej woli.
###### **Hbr 2,5**
 W rzeczywistości bowiem nie aniołom dał Bóg władzę nad przyszłym światem, o którym mówimy.
###### **Hbr 2,6**
 Przeciwnie, na pewnym miejscu [Pisma Świętego] jest powiedziane: Czymże jest człowiek, że [Ty, Boże] pamiętasz o nim? Czym jest syn zwykłego człowieka, że tak o niego się troszczysz?
###### **Hbr 2,7**
 Uczyniłeś go przecież mało co mniejszym od aniołów, obdarzyłeś go chwałą i czcią [należną królom].
###### **Hbr 2,8**
 Wszystko złożyłeś u stóp jego.Tak więc skoro wszystko złożyłeś u Jego stóp, nie ma już nic takiego, co nie byłoby poddane Jemu, choć jeszcze nie widzimy [co prawda], żeby wszystko było Mu już poddane.
###### **Hbr 2,9**
 Ale już teraz widzimy, że Jezus, który przez krótki czas był niższym od aniołów, został obdarzony chwałą i czcią z powodu wszystkiego, co wycierpiał aż do śmierci, i że - dzięki łaskawości Boga względem nas - zechciał umrzeć dla naszego zbawienia.
###### **Hbr 2,10**
 Bóg, od którego wszystko pochodzi i dzięki któremu istnieje, pragnąc doprowadzić wielu do udziału w swojej chwale, uznał za stosowne udoskonalić przez cierpienie Sprawcę ludzkiego zbawienia.
###### **Hbr 2,11**
 W ten sposób wszyscy pochodzą od jednego [Ojca]: zarówno ten, który uświęca, jak i ci, którzy uświęcenia dostępują. Dlatego Jezus nie wstydzi się nazywać ludzi swymi braćmi, mówiąc:
###### **Hbr 2,12**
 Ogłoszę [o Boże] Twoje imię moim braciom będę Cię wychwalał wobec całego zgromadzenia.
###### **Hbr 2,13**
 Powiedział także: W Nim będę pokładał całą moją ufność oraz: Oto ja sam i moje dzieci, które mi Bóg dał.
###### **Hbr 2,14**
 Ponieważ zaś dzieci powiązane są nawzajem wspólnotą krwi i ciała, dlatego On, bez żadnej różnicy, również wszedł w ową wspólnotę, aby następnie przez śmierć pokonać diabła, który także posiadał władzę nad śmiercią,
###### **Hbr 2,15**
 i aby uwolnić tych wszystkich, którzy pozostawali w jej więzach.
###### **Hbr 2,16**
 Bo rzeczywiście przychodzi On z pomocą nie aniołom, ale - jak mówi Pismo - przygarnia potomków Abrahama.
###### **Hbr 2,17**
 Dlatego właśnie musiał się upodobnić całkowicie do braci; inaczej nie mógłby być miłosiernym i wiernym wobec Boga arcykapłanem, który dokonuje dzieła przebłagania za grzechy całego ludu.
###### **Hbr 2,18**
 W czym bowiem sam cierpiał znosząc różne doświadczenia, w tym może również przyjść z pomocą tym, którzy są poddawani próbom.
# Hbr 2 WUJ
###### **Hbr 2,1**
 Dla tego trzeba nam obficiej przestrzegać tego, cośmy słyszeli: byśmy snadź nie przeciekli.
###### **Hbr 2,2**
 Abowiem jeśli która przez anioły powiedziana jest mowa stała się trwała, a wszelkie przestępstwo i nieposłuszeństwo sprawiedliwą zapłaty nagrodę wzięło:
###### **Hbr 2,3**
 Jakoż my się wybiegamy, jeśli zaniedbamy tak wielkiego zbawienia? które gdy się poczęło przepowiadać przez Pana: od tych, którzy słyszeli, na nas potwierdzone jest:
###### **Hbr 2,4**
 Gdy Bóg społu poświadczał znamiony, i cudami, i rozlicznemi mocami, i rozdawaniem Ducha świętego według wolej swojej.
###### **Hbr 2,5**
 Abowiem nie aniołom poddał Bóg okrąg ziemie przyszły, o którym mówimy.
###### **Hbr 2,6**
 A świadczył ktoś na niektórem miejscu, mówiąc: Cóż jest człowiek, iż nań pamiętasz: abo syn człowieczy iż go nawiedzasz?
###### **Hbr 2,7**
 Umniejszyłeś go mało co mniej od aniołów: chwałą i czcią ukoronowałeś go, i postanowiłeś go nad dziełem rąk twoich.
###### **Hbr 2,8**
 Poddałeś wszystko pod nogi jego. Abowiem w tem, że mu wszystko poddał: niczego nie zostawił jemu nie poddanego. A teraz jeszcze nie widziemy, żeby mu wszystko poddano było.
###### **Hbr 2,9**
 Lecz tego, który mało co niźli aniołowie umniejszony jest, widzimy Jezusa dla męki śmierci, chwałą i czcią ukoronowanego: aby z łaski Bożej, za wszystki śmierci skosztował.
###### **Hbr 2,10**
 Abowiem przystało jemu, dla którego wszystko, i przez którego wszystko, który wiele synów do chwały był przywiódł, sprawcę zbawienia ich przez ucierpienie doskonałym uczynić.
###### **Hbr 2,11**
 Bo który poświęca, i którzy bywają poświęceni: z jednego wszyscy. Dla której przyczyny nie wstyda się bracią ich nazywać,
###### **Hbr 2,12**
 Mówiąc: Opowiem imię twoje braciej mojej, w pośrodku kościoła chwalić cię będę.
###### **Hbr 2,13**
 I zasię: Ja w nim dufać będę. I zasię: Oto ja i dzieci moje, które mi dał Bóg.
###### **Hbr 2,14**
 Ponieważ tedy dzieci spółeczność miały ciała i krwie: i on także tychże uczestnikiem był: aby przez śmierć zepsował tego, który miał władzą śmierci, to jest djabła:
###### **Hbr 2,15**
 A iżby wyzwolił te, którzy dla bojaźni śmierci przez wszystek żywot podlegli byli niewoli.
###### **Hbr 2,16**
 Bo nigdzie aniołów nie przyjmuje: ale nasienie Abrahamowe przyjmuje.
###### **Hbr 2,17**
 Zkąd powinien był we wszystkiem być podobny braciej: aby się stał miłosiernym i wiernym nawyższym kapłanem do Boga, aby ubłagał za grzechy ludu.
###### **Hbr 2,18**
 Abowiem w czem sam ucierpiał i kuszon był, mocen jest i tym, którzy są kuszeni dopomódz.
# Hbr 2 STERN
###### **Hbr 2,1**
 Dlatego musimy zwracać dużo baczniejszą uwagę na rzeczy, które słyszeliśmy, abyśmy się nie oddalili.
###### **Hbr 2,2**
 Bo jeśli obowiązujące stało się słowo, które Bóg wypowiedział przez aniołów, tak że każde pogwałcenie i akt nieposłuszeństwa otrzymywały pełną miarę słusznej odpłaty,
###### **Hbr 2,3**
 to jak ocalejemy, jeśli zlekceważymy tak wielkie wyzwolenie? Wyzwolenie to, na początku oznajmione przez Pana, zostało nam potwierdzone przez tych, którzy Go słyszeli,
###### **Hbr 2,4**
 również i sam Bóg zaświadczył o nim rozmaitymi znakami, dziwami i cudami oraz darami Ruach Ha-Kodesz, które rozdzielił tak, jak zechciał.
###### **Hbr 2,5**
 Bo nie aniołom poddał Bóg 'olam haba, o którym tutaj mówimy.
###### **Hbr 2,6**
 A w jednym miejscu ktoś złożył takie uroczyste świadectwo: "Kimże jest człowiek, żebyś się nim zajmował? albo syn człowieczy, żebyś czuwał nad nim tak troskliwie?
###### **Hbr 2,7**
 Uczyniłeś go trochę niższym od aniołów, ukoronowałeś go chwałą i czcią,
###### **Hbr 2,8**
 wszystko poddałeś pod jego stopy". Poddając mu wszystko, nie pozostawił niczego, co by nie było mu poddane. Obecnie jednak nie widzimy, żeby wszystko było mu poddane, przynajmniej na razie.
###### **Hbr 2,9**
 Widzimy jednak Jeszuę - który rzeczywiście został na trochę uczyniony niższym od aniołów -teraz ukoronowanego chwałą i czcią, bo zaznał śmierci, aby z Bożej łaski zakosztować śmierci za całą ludzkość.
###### **Hbr 2,10**
 Słuszne bowiem było, aby Bóg, który wszystko stworzył i podtrzymuje, wielu synów przywodząc do chwały, Sprawcę ich wyzwolenia doprowadził do celu przez cierpienia.
###### **Hbr 2,11**
 Bo i Jeszua, który czyni ludzi zastrzeżonymi dla Boga, i ci, którzy zostają zastrzeżeni, wspólny mają początek - dlatego nie wstydzi się On nazywać ich braćmi,
###### **Hbr 2,12**
 gdy mówi: "Będę głosił Twoje imię braciom moim, pośród zgromadzenia będę śpiewał Twoją chwałę".
###### **Hbr 2,13**
 Oraz: "W Nim złożę swą ufność...", następnie zaś mówi: "Otom jest, wraz z dziećmi, które dał mi Bóg".
###### **Hbr 2,14**
 Ponieważ zatem dzieci mają udział we wspólnej, fizycznej naturze jako ludzie, stał się On taki jak oni i miał udział w tej samej naturze ludzkiej, aby przez swoją śmierć unieszkodliwić tego, który miał władzę nad śmiercią (czyli Przeciwnika),
###### **Hbr 2,15**
 i w ten sposób wyzwolić tych, którzy z powodu lęku przed śmiercią przez całe życie byli w niewoli.
###### **Hbr 2,16**
 Bo oczywiste jest, że nie przygarnia On aniołów, aby im pomóc, przeciwnie: "Przygarnia potomstwo Awrahama".
###### **Hbr 2,17**
 Dlatego musiał się pod każdym względem upodobnić do swych braci, ażeby się stać miłosiernym i wiernym kohenem gadolem w służbie Bogu, dokonując kappary za grzechy ludu.
###### **Hbr 2,18**
 Skoro bowiem sam cierpiał śmierć, kiedy poddano Go próbie, jest teraz zdolny pomagać tym, którzy przechodzą próby.
# Hbr 2 TRO
###### **Hbr 2,1**
 **δια** *dia* Z powodu [[G1223]] [[PREP]] **τουτο** *touto* tego [[G5124]] WTD-ASN **δει** *dei* trzeba – jest konieczne [[G1163]] WTV-PQI-3S **περισσοτερως** *perissoterōs* obficiej [[G4056]] [[ADV]] **ημας** *hēmas* nam [[G2248]] WTP-1AP **προσεχειν** *prosechein* zważać – zwracać uwagę [[G4337]] WTV-PAN **τοις** *tois* (ku tym) [[G3588]] WTT-DPN **ακουσθεισιν** *akoustheisin* które zostały usłyszane [[G191]] WTV-APP-DPN **μηποτε** *mēpote* by czasem nie [[G3379]] [[ADV]] **παραρρυωμεν** *pararryōmen* przepłynęlibyśmy obok – przecieklibyśmy [[G3901]] WTV-2AAS-1P
###### **Hbr 2,2**
 **ει** *ei* Jeśli [[G1487]] WTCOND **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **δι** *di* przez [[G1223]] [[PREP]] **αγγελων** *angelōn* zwiastunów [[G32]] WTN-GPM **λαληθεις** *lalētheis* które zostało powiedziane [[G2980]] WTV-APP-NSM **λογος** *logos* słowo [[G3056]] [[N-NSM]] **εγενετο** *egeneto* stało się [[G1096]] WTV-2ADI-3S **βεβαιος** *bebaios* mocne [[G949]] [[A-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **πασα** *pasa* każde [[G3956]] WTA-NSF **παραβασις** *parabasis* przestępstwo [[G3847]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **παρακοη** *parakoē* nieposłuszeństwo [[G3876]] [[N-NSF]] **ελαβεν** *elaben* wzięło – odebrało [[G2983]] WTV-2AAI-3S **ενδικον** *endikon* zgodną z prawem – słuszną [[G1738]] WTA-ASF **μισθαποδοσιαν** *misthapodosian* odpłatę – zapłatę [[G3405]] WTN-ASF
###### **Hbr 2,3**
 **πως** *pōs* jak [[G4459]] [[ADV]]-I **ημεις** *hēmeis* my [[G2249]] WTP-1NP **εκφευξομεθα** *ekfeuksometha* wymkniemy się – uciekniemy [[G1628]] WTV-FDI-1P **τηλικαυτης** *tēlikautēs* (o) tak wielkie [[G5082]] WTD-GSF **αμελησαντες** *amelēsantes* zaniedbawszy – zlekceważywszy [[G272]] WTV-AAP-NPM **σωτηριας** *sōtērias* zbawienie – wyzwolenie [[G4991]] [[N-GSF]] **ητις** *hētis* które [[G3748]] WTR-NSF **αρχην** *archēn* początek [[G746]] WTN-ASF **λαβουσα** *labousa* wziąwszy [[G2983]] WTV-2AAP-NSF **λαλεισθαι** *laleisthai* być mówionym [[G2980]] WTV-PPN **δια** *dia* przez [[G1223]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **υπο** *hypo* przez [[G5259]] [[PREP]] **των** *tōn* (tych) [[G3588]] WTT-GPM **ακουσαντων** *akousantōn* którzy usłyszeli [[G191]] WTV-AAP-GPM **εις** *eis* względem [[G1519]] [[PREP]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **εβεβαιωθη** *ebebaiōthē* zostało utwierdzone – zostało umocnione [[G950]] [[V-API-3S]]
###### **Hbr 2,4**
 **συνεπιμαρτυρουντος** *synepimartyrountos* Równocześnie dając świadectwo [[G4901]] WTV-PAP-GSM **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **σημειοις** *sēmeiois* znakom [[G4592]] WTN-DPN **τε** *te* zarówno – także [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **τερασιν** *terasin* cudom [[G5059]] WTN-DPN **και** *kai* i [[G2532]] [[CONJ]] **ποικιλαις** *poikilais* różnym – rozmaitym [[G4164]] WTA-DPF **δυναμεσιν** *dynamesin* mocom [[G1411]] WTN-DPF **και** *kai* i [[G2532]] [[CONJ]] **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **αγιου** *hagiou* Świętego [[G40]] [[A-GSN]] **μερισμοις** *merismois* przydziałom [[G3311]] WTN-DPM **κατα** *kata* według [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **αυτου** *autou* Jego [[G846]] [[P-GSM]] **θελησιν** *thelēsin* woli – zechcenia [[G2308]] WTN-ASF
###### **Hbr 2,5**
 **ου** *ou* Nie [[G3756]] [[PRT-N]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **αγγελοις** *angelois* zwiastunom [[G32]] WTN-DPM **υπεταξεν** *hypetaksen* poddał – podporządkował [[G5293]] [[V-AAI-3S]] **την** *tēn* [[G3588]] WTT-ASF **οικουμενην** *oikoumenēn* świat zamieszkały [[G3625]] WTN-ASF **την** *tēn* (ten) [[G3588]] WTT-ASF **μελλουσαν** *mellousan* mający nastąpić – mający nadejść [[G3195]] WTV-PAP-ASF **περι** *peri* o [[G4012]] [[PREP]] **ης** *hēs* którym [[G3739]] [[R-GSF]] **λαλουμεν** *laloumen* mówimy [[G2980]] WTV-PAI-1P
###### **Hbr 2,6**
 **διεμαρτυρατο** *diemartyrato* Zaświadczył – Oświadczył [[G1263]] WTV-ADI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **που** *pou* gdzieś [[G4225]] WTPRT **τις** *tis* ktoś [[G5100]] WTX-NSM **λεγων** *legōn* mówiąc [[G3004]] [[V-PAP-NSM]] **τι** *ti* czym [[G5101]] WTI-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ανθρωπος** *anthrōpos* człowiek [[G444]] [[N-NSM]] **οτι** *hoti* że [[G3754]] [[CONJ]] **μιμνησκη** *mimnēskē* pamiętasz [[G3403]] WTV-PNI-2S **αυτου** *autou* go [[G846]] [[P-GSM]] **η** *ē* lub [[G2228]] WTPRT **υιος** *hyios* syn [[G5207]] [[N-NSM]] **ανθρωπου** *anthrōpou* człowieka [[G444]] [[N-GSM]] **οτι** *hoti* że [[G3754]] [[CONJ]] **επισκεπτη** *episkeptē* patrzysz – spoglądasz [[G1980]] WTV-PNI-2S **αυτον** *auton* (na) niego [[G846]] WTP-ASM
###### **Hbr 2,7**
 **ηλαττωσας** *ēlattōsas* Uczyniłeś mniejszym [[G1642]] WTV-AAI-2S **αυτον** *auton* go [[G846]] WTP-ASM **βραχυ** *brachy* trochę – mało [[G1024]] WTA-ASN **τι** *ti* coś [[G5100]] WTX-ASN **παρ** *par* od [[G3844]] [[PREP]] **αγγελους** *angelous* zwiastunów [[G32]] [[N-APM]] **δοξη** *doksē* chwałą [[G1391]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **τιμη** *timē* szacunkiem – wartością [[G5092]] [[N-DSF]] **εστεφανωσας** *estefanōsas* uwieńczyłeś – ukoronowałeś [[G4737]] WTV-AAI-2S **αυτον** *auton* go [[G846]] WTP-ASM **και** *kai* i [[G2532]] [[CONJ]] **κατεστησας** *katestēsas* ustanowiłeś [[G2525]] WTV-AAI-2S **αυτον** *auton* go [[G846]] WTP-ASM **επι** *epi* nad [[G1909]] [[PREP]] **τα** *ta* [[G3588]] WTT-APN **εργα** *erga* dziełami – uczynkami [[G2041]] WTN-APN **των** *tōn* [[G3588]] WTT-GPF **χειρων** *cheirōn* rąk [[G5495]] WTN-GPF **σου** *sou* twoich [[G4675]] WTP-2GS
###### **Hbr 2,8**
 **παντα** *panta* wszystkie [[G3956]] WTA-APN **υπεταξας** *hypetaksas* poddaj – podporządkuj [[G5293]] WTV-AAI-2S **υποκατω** *hypokatō* poniżej [[G5270]] [[ADV]] **των** *tōn* [[G3588]] WTT-GPM **ποδων** *podōn* stóp [[G4228]] WTN-GPM **αυτου** *autou* Jego [[G846]] [[P-GSM]] **εν** *en* w [[G1722]] [[PREP]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **τω** *tō* (tym) [[G3588]] WTT-DSM **υποταξαι** *hypotaksai* poddać – podporządkować [[G5293]] [[V-AAN]] **αυτω** *autō* Mu [[G846]] WTP-DSM **τα** *ta* [[G3588]] WTT-APN **παντα** *panta* wszystkie [[G3956]] WTA-APN **ουδεν** *ouden* niczego [[G3762]] WTA-ASN **αφηκεν** *afēken* zostawił [[G863]] [[V-AAI-3S]] **αυτω** *autō* Mu [[G846]] WTP-DSM **ανυποτακτον** *anypotakton* niepodporządkowanego – niekarnego [[G506]] WTA-ASN **νυν** *nyn* teraz [[G3568]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **ουπω** *oupō* jeszcze nie [[G3768]] [[ADV]] **ορωμεν** *horōmen* widzimy [[G3708]] WTV-PAI-1P **αυτω** *autō* (że) Mu [[G846]] WTP-DSM **τα** *ta* [[G3588]] WTT-APN **παντα** *panta* wszystkie [[G3956]] WTA-APN **υποτεταγμενα** *hypotetagmena* które są poddane – które są podporządkowane [[G5293]] WTV-RPP-APN
###### **Hbr 2,9**
 **τον** *ton* (Tego) [[G3588]] [[T-ASM]] **δε** *de* zaś [[G1161]] [[CONJ]] **βραχυ** *brachy* trochę – mało [[G1024]] WTA-ASN **τι** *ti* coś [[G5100]] WTX-ASN **παρ** *par* od [[G3844]] [[PREP]] **αγγελους** *angelous* zwiastunów [[G32]] [[N-APM]] **ηλαττωμενον** *ēlattōmenon* który jest uczyniony mniejszym [[G1642]] WTV-RPP-ASM **βλεπομεν** *blepomen* widzimy [[G991]] WTV-PAI-1P **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]] **δια** *dia* przez [[G1223]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **παθημα** *pathēma* cierpienie [[G3804]] WTN-ASN **του** *tou* [[G3588]] WTT-GSM **θανατου** *thanatou* śmierci [[G2288]] [[N-GSM]] **δοξη** *doksē* chwałą [[G1391]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **τιμη** *timē* szacunkiem – wartością [[G5092]] [[N-DSF]] **εστεφανωμενον** *estefanōmenon* które jest uwieńczone – które jest ukoronowane [[G4737]] WTV-RPP-ASM **οπως** *hopōs* żeby [[G3704]] [[ADV]] **χαριτι** *chariti* łasce [[G5485]] [[N-DSF]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **υπερ** *hyper* za [[G5228]] [[PREP]] **παντος** *pantos* każdego [[G3956]] WTA-GSM **γευσηται** *geusētai* skosztowałby – zasmakowałby [[G1089]] WTV-ADS-3S **θανατου** *thanatou* śmierci [[G2288]] [[N-GSM]]
###### **Hbr 2,10**
 **επρεπεν** *eprepen* Przystało [[G4241]] WTV-IAI-3S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **αυτω** *autō* Temu [[G846]] WTP-DSM **δι** *di* dla [[G1223]] [[PREP]] **ον** *hon* którego [[G3739]] WTR-ASM **τα** *ta* [[G3588]] WTT-NPN **παντα** *panta* wszystkie [[G3956]] WTA-NPN **και** *kai* i [[G2532]] [[CONJ]] **δι** *di* z powodu [[G1223]] [[PREP]] **ου** *hou* którego [[G3739]] WTR-GSM **τα** *ta* [[G3588]] WTT-NPN **παντα** *panta* wszystkie [[G3956]] WTA-NPN **πολλους** *pollous* (by) wielu [[G4183]] WTA-APM **υιους** *hyious* synów [[G5207]] [[N-APM]] **εις** *eis* w [[G1519]] [[PREP]] **δοξαν** *doksan* chwałę [[G1391]] WTN-ASF **αγαγοντα** *agagonta* poprowadziwszy [[G71]] WTV-2AAP-ASM **τον** *ton* [[G3588]] [[T-ASM]] **αρχηγον** *archēgon* początek i wodza – sprawcę [[G747]] [[N-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **σωτηριας** *sōtērias* zbawienia – wyzwolenia [[G4991]] [[N-GSF]] **αυτων** *autōn* ich [[G846]] WTP-GPM **δια** *dia* przez [[G1223]] [[PREP]] **παθηματων** *pathēmatōn* cierpienia [[G3804]] WTN-GPN **τελειωσαι** *teleiōsai* uczynić doskonałym – zostać doprowadzonym do doskonałości [[G5048]] [[V-AAN]]
###### **Hbr 2,11**
 **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **τε** *te* zarówno – także [[G5037]] WTPRT **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **αγιαζων** *hagiazōn* uświęcający – poświęcający [[G37]] [[V-PAP-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* (ci) [[G3588]] WTT-NPM **αγιαζομενοι** *hagiazomenoi* którzy są uświęcani – którzy są poświęcani [[G37]] WTV-PPP-NPM **εξ** *eks* z [[G1537]] [[PREP]] **ενος** *henos* Jednego [[G1520]] WTA-GSM **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **δι** *di* dla- [[G1223]] [[PREP]] **ην** *hēn* tego [[G3739]] WTR-ASF **αιτιαν** *aitian* powodu – przyczyny [[G156]] WTN-ASF **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **επαισχυνεται** *epaischynetai* wstydzi się [[G1870]] WTV-PNI-3S **αδελφους** *adelfous* braćmi [[G80]] [[N-APM]] **αυτους** *autous* ich [[G846]] [[P-APM]] **καλειν** *kalein* nazywać [[G2564]] WTV-PAN
###### **Hbr 2,12**
 **λεγων** *legōn* mówiąc [[G3004]] [[V-PAP-NSM]] **απαγγελω** *apangelō* oznajmię – poinformuję [[G518]] WTV-FAI-1S **το** *to* [[G3588]] WTT-ASN **ονομα** *onoma* imię [[G3686]] WTN-ASN **σου** *sou* Twoje [[G4675]] WTP-2GS **τοις** *tois* [[G3588]] WTT-DPM **αδελφοις** *adelfois* braciom [[G80]] WTN-DPM **μου** *mou* moim [[G3450]] WTP-1GS **εν** *en* w [[G1722]] [[PREP]] **μεσω** *mesō* środku [[G3319]] WTA-DSN **εκκλησιας** *ekklēsias* zgromadzenia – (społeczności) wywołanych [[G1577]] [[N-GSF]] **υμνησω** *hymnēsō* wysławię hymnem – zaśpiewam hymn [[G5214]] WTV-FAI-1S **σε** *se* Cię [[G4571]] WTP-2AS
###### **Hbr 2,13**
 **και** *kai* i [[G2532]] [[CONJ]] **παλιν** *palin* znów [[G3825]] [[ADV]] **εγω** *egō* Ja [[G1473]] WTP-1NS **εσομαι** *esomai* będę [[G2071]] WTV-FXI-1S **πεποιθως** *pepoithōs* pokładający ufność – polegający [[G3982]] WTV-2RAP-NSM **επ** *ep* z powodu [[G1909]] [[PREP]] **αυτω** *autō* Niego [[G846]] WTP-DSM **και** *kai* i [[G2532]] [[CONJ]] **παλιν** *palin* znów [[G3825]] [[ADV]] **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **εγω** *egō* Ja [[G1473]] WTP-1NS **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-NPN **παιδια** *paidia* dzieciątka – małe dzieci [[G3813]] WTN-NPN **α** *ha* które [[G3739]] WTR-APN **μοι** *moi* mi [[G3427]] WTP-1DS **εδωκεν** *edōken* dał [[G1325]] [[V-AAI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]]
###### **Hbr 2,14**
 **επει** *epei* skoro – jako, że [[G1893]] [[CONJ]] **ουν** *oun* więc [[G3767]] [[CONJ]] **τα** *ta* [[G3588]] WTT-NPN **παιδια** *paidia* dzieciątka – małe dzieci [[G3813]] WTN-NPN **κεκοινωνηκεν** *kekoinōnēken* stał się wspólnikiem (stały się wspólnikami) – stał się uczestnikiem (stały się uczestnikami) [[G2841]] WTV-RAI-3S **σαρκος** *sarkos* ciała [[G4561]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **αιματος** *haimatos* krwi [[G129]] [[N-GSN]] **και** *kai* i [[G2532]] [[CONJ]] **αυτος** *autos* On [[G846]] WTP-NSM **παραπλησιως** *paraplēsiōs* podobnie [[G3898]] [[ADV]] **μετεσχεν** *meteschen* uczestniczył [[G3348]] WTV-2AAI-3S **των** *tōn* (z) [[G3588]] WTT-GPN **αυτων** *autōn* nimi [[G846]] WTP-GPN **ινα** *hina* aby [[G2443]] [[CONJ]] **δια** *dia* przez [[G1223]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θανατου** *thanatou* śmierć [[G2288]] [[N-GSM]] **καταργηση** *katargēsē* zostałaby unieważniona – zostałaby uznana za bezużyteczną [[G2673]] WTV-AAS-3S **τον** *ton* (tego) [[G3588]] [[T-ASM]] **το** *to* [[G3588]] WTT-ASN **κρατος** *kratos* moc – siła [[G2904]] WTN-ASN **εχοντα** *echonta* mającego [[G2192]] WTV-PAP-ASM **του** *tou* [[G3588]] WTT-GSM **θανατου** *thanatou* śmierci [[G2288]] [[N-GSM]] **τουτ** *tout* to [[G5124]] WTD-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **τον** *ton* [[G3588]] [[T-ASM]] **διαβολον** *diabolon* oszczercę – diabła [[G1228]] WTA-ASM
###### **Hbr 2,15**
 **και** *kai* i [[G2532]] [[CONJ]] **απαλλαξη** *apallaksē* uwolniłby [[G525]] WTV-AAS-3S **τουτους** *toutous* tych [[G5128]] WTD-APM **οσοι** *hosoi* ilu – jacy [[G3745]] WTK-NPM **φοβω** *fobō* (w) strachu – (w) bojaźni [[G5401]] WTN-DSM **θανατου** *thanatou* (przed) śmiercią [[G2288]] [[N-GSM]] **δια** *dia* przez [[G1223]] [[PREP]] **παντος** *pantos* całe [[G3956]] WTA-GSM **του** *tou* [[G3588]] WTT-GSM **ζην** *zēn* żyć [[G2198]] WTV-PAN **ενοχοι** *enochoi* winni – podlegli [[G1777]] WTA-NPM **ησαν** *ēsan* byli [[G2258]] WTV-IXI-3P **δουλειας** *douleias* niewoli [[G1397]] [[N-GSF]]
###### **Hbr 2,16**
 **ου** *ou* Nie [[G3756]] [[PRT-N]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **δηπου** *dēpou* oczywiście – rzeczywiście [[G1222]] [[ADV]] **αγγελων** *angelōn* zwiastunów [[G32]] WTN-GPM **επιλαμβανεται** *epilambanetai* ujmuje się za – domaga się o [[G1949]] WTV-PNI-3S **αλλα** *alla* ale [[G235]] [[CONJ]] **σπερματος** *spermatos* nasieniem [[G4690]] [[N-GSN]] **αβρααμ** *abraam* Abrahama – [ojciec wielu narodów] [[G11]] [[N-PRI]] **επιλαμβανεται** *epilambanetai* ujmuje się za – domaga się o [[G1949]] WTV-PNI-3S
###### **Hbr 2,17**
 **οθεν** *hothen* Skąd [[G3606]] [[ADV]] **ωφειλεν** *ōfeilen* był winien – był zobowiązany [[G3784]] WTV-IAI-3S **κατα** *kata* we [[G2596]] [[PREP]] **παντα** *panta* wszystkim [[G3956]] WTA-APN **τοις** *tois* [[G3588]] WTT-DPM **αδελφοις** *adelfois* braciom [[G80]] WTN-DPM **ομοιωθηναι** *homoiōthēnai* zostać upodobnionym [[G3666]] WTV-APN **ινα** *hina* aby [[G2443]] [[CONJ]] **ελεημων** *eleēmōn* miłosierny – litościwy [[G1655]] [[A-NSM]] **γενηται** *genētai* stałby się [[G1096]] WTV-2ADS-3S **και** *kai* i [[G2532]] [[CONJ]] **πιστος** *pistos* wierny [[G4103]] [[A-NSM]] **αρχιερευς** *archiereus* arcykapłan [[G749]] [[N-NSM]] **τα** *ta* (co do tych) [[G3588]] WTT-APN **προς** *pros* względem [[G4314]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **θεον** *theon* Boga [[G2316]] [[N-ASM]] **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **ιλασκεσθαι** *hilaskesthai* zostać przebłaganiem [[G2433]] WTV-PPN **τας** *tas* (za) [[G3588]] WTT-APF **αμαρτιας** *hamartias* grzechy [[G266]] WTN-APF **του** *tou* [[G3588]] WTT-GSM **λαου** *laou* ludu [[G2992]] [[N-GSM]]
###### **Hbr 2,18**
 **εν** *en* W [[G1722]] [[PREP]] **ω** *hō* czym [[G3739]] WTR-DSN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **πεπονθεν** *peponthen* doznał cierpienia [[G3958]] WTV-2RAI-3S **αυτος** *autos* On [[G846]] WTP-NSM **πειρασθεις** *peirastheis* zostawszy doświadczonym – zostawszy wypróbowanym [[G3985]] WTV-APP-NSM **δυναται** *dynatai* może [[G1410]] WTV-PNI-3S **τοις** *tois* [[G3588]] WTT-DPM **πειραζομενοις** *peirazomenois* którzy są doświadczani – którzy są poddawani próbie [[G3985]] WTV-PPP-DPM **βοηθησαι** *boēthēsai* pomóc [[G997]] [[V-AAN]]
