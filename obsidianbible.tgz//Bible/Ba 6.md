# Ba 6 BT5
###### **Ba 6,1**
 Z powodu grzechów, jakie popełniliście przeciw Bogu, będziecie uprowadzeni w niewolę do Babilonu przez króla babilońskiego, Nabuchodonozora.
###### **Ba 6,2**
 Gdy już wejdziecie do Babilonu, pozostaniecie tam przez wiele lat, na długi czas, aż do siódmego pokolenia. Potem wyprowadzę was stamtąd w pokoju.
###### **Ba 6,3**
 Oto ujrzycie w Babilonie niesionych na ramionach bogów ze srebra, złota i drewna, którzy bojaźń wzbudzać będą w poganach.
###### **Ba 6,4**
 Uważajcie więc, byście się nie upodobnili do cudzoziemców i by was nie ogarnęła bojaźń przed tymi bogami.
###### **Ba 6,5**
 Kiedy zobaczycie tłum, który idąc przed i za nimi, cześć oddawać im będzie, powiedzcie sobie w myśli: Tobie należy się cześć, o Panie!
###### **Ba 6,6**
 Mój bowiem anioł jest z wami i on sam szuka dusz waszych.
###### **Ba 6,7**
 Rzemieślnik wygładził język tych bogów, sami zaś, pozłoceni i posrebrzeni, są oszustwem i nie mogą mówić.
###### **Ba 6,8**
 Jak pannie, która kocha się w strojach, oni robią wieńce na głowy swoich bogów.
###### **Ba 6,9**
 Zdarza się, że kapłani kradną złoto i srebro swoim bogom i obracają na własne potrzeby, dają je też nierządnicom spod [tego samego] dachu.
###### **Ba 6,10**
 Ubierają w szaty, jak ludzi, bogów srebrnych, złotych i drewnianych, którzy nie mogą się obronić przed rdzą i robakami.
###### **Ba 6,11**
 Gdy odziewają ich w szkarłatne szaty, ścierają z ich twarzy kurz świątyni, który w wielkiej obfitości na nich osiada.
###### **Ba 6,12**
 Ten trzyma berło, jakby jaki rządca kraju, ale nie może zabić, jeśliby ktoś przeciw niemu wykroczył.
###### **Ba 6,13**
 Ów trzyma w prawicy miecz i siekierę, ale nie obroni siebie w czasie wojny ani przed złodziejami.
###### **Ba 6,14**
 Dlatego jasną jest rzeczą, że nie są bogami; więc się ich nie bójcie!
###### **Ba 6,15**
 Jak naczynie stłuczone staje się dla człowieka bezużyteczne, tak się rzecz ma z ich bogami, umieszczonymi w świątyniach.
###### **Ba 6,16**
 Oczy mają pełne kurzu unoszącego się spod nóg przechodniów.
###### **Ba 6,17**
 Jak za tym, co obraził króla, dokoła zamyka się dziedzińce, jako za skazanym na śmierć, tak kapłani obwarowują swe świątynie drzwiami, zamkami i zasuwami, aby nie zostali ograbieni przez złodziei.
###### **Ba 6,18**
 Światła zapalają, i to więcej niż sami potrzebują, a żadnego ci bogowie ujrzeć nie mogą.
###### **Ba 6,19**
 Są oni jak belka w domu: wnętrze ich, jak powiadają, jest stoczone, bo robactwo, wychodzące z ziemi, pożera ich wraz z szatami, a oni tego nie czują.
###### **Ba 6,20**
 Oblicze mają czarne od dymu unoszącego się ze świątyni.
###### **Ba 6,21**
 Na ich ciała i głowy siadają nietoperze, jaskółki i [inne] ptaki; tak samo koty po nich łażą.
###### **Ba 6,22**
 Stąd poznajecie, że nie są bogami, dlatego się ich nie bójcie.
###### **Ba 6,23**
 Złoto, którym dla ozdoby są pokryci, nie będzie błyszczeć, jeśli ktoś śniedzi z niego nie zetrze. Ani nie czuli oni, kiedy ich odlano.
###### **Ba 6,24**
 I chociażby byli kupieni nie wiedzieć za jak wielką cenę, nie ma w nich ducha.
###### **Ba 6,25**
 Ponieważ nie mają nóg, na ramionach muszą być noszeni, pokazując w ten sposób ludziom swą nicość. Muszą się też czuć zawstydzeni ich czciciele tym, że gdy któryś z nich przypadkiem upadnie, to go sami podnoszą.
###### **Ba 6,26**
 Jeżeli zaś ktoś go prosto postawi, nie może poruszyć się sam, a jeżeli będzie nachylony, prosto nie stanie. Dlatego jak przed zmarłymi stawia się im dary.
###### **Ba 6,27**
 Kapłani ofiary bogom składane sprzedają na własne potrzeby, podobnie ich żony peklują dla siebie mięso z ofiar, a nie dają z nich ani biednemu, ani choremu. Kobiety ich w okresie słabości miesięcznej oraz po połogu dotykają ofiar.
###### **Ba 6,28**
 Stąd wiecie, że nie są bogami, i nie bójcie się ich.
###### **Ba 6,29**
 Jakżeż ich nazwać bogami? Przecież kobiety składają ofiary bogom srebrnym, złotym i drewnianym.
###### **Ba 6,30**
 Kapłani siedzą w świątyniach z rozdartymi płaszczami, z ogolonymi brodami i czaszkami, z nienakrytymi głowami.
###### **Ba 6,31**
 Ryczą i krzyczą przed bogami swymi, jak to niektórzy czynią na stypie.
###### **Ba 6,32**
 Kapłani biorą szaty bogów i przyodziewają nimi swoje żony i dzieci.
###### **Ba 6,33**
 A jeśli [tym bogom] ktoś zrobi coś dobrego albo coś złego, nie mają możności za to odpłacić. Nie mogą też króla ustanowić ani złożyć go z tronu.
###### **Ba 6,34**
 Nie mogą też dać ani bogactw, ani miedziaków. Jeśliby ktoś jakiś ślub złożył, a nie dotrzymał go, nie będą tego dochodzić.
###### **Ba 6,35**
 Człowieka nie wyrwą śmierci ani też nie wybawią słabego z ręki mocnego.
###### **Ba 6,36**
 Niewidomemu wzroku nie przywrócą ani nie pomogą uciśnionemu.
###### **Ba 6,37**
 Nad wdową się nie ulitują ani też nie będą dobrodziejami sierot.
###### **Ba 6,38**
 Bogowie drewniani, pozłacani i posrebrzani mogą być przyrównani do kamieni wydobytych z gór, a tych, którzy im cześć oddają, spotka hańba.
###### **Ba 6,39**
 Jakże więc można myśleć o nich, że są bogami, albo ich tak nazywać?
###### **Ba 6,40**
 Nadto, sami Chaldejczycy ich znieważają: gdy zobaczą jakiegoś niemego, który nie może mówić, przynoszą Bela, prosząc, by go obdarzył mową, jakby on mógł ich usłyszeć.
###### **Ba 6,41**
 A nie mogą pojąć, że takich bogów należy porzucić; do tego stopnia rozumu nie mają.
###### **Ba 6,42**
  Kobiety opasane sznurami siedzą przy drogach, palą otręby jak kadzidło.
###### **Ba 6,43**
 Skoro którejś z nich udało się przespać z kimś z przechodzących, to natrząsa się z sąsiadki, że nie była tak zaszczycona jak ona i że jej sznur nie został przerwany.
###### **Ba 6,44**
 Wszystko, co się dla tych bogów czyni, jest oszustwem. Jakże więc można sądzić lub mówić, że to są bogowie?
###### **Ba 6,45**
 Rzemieślnicy i złotnicy zrobili ich – niczym innym nie są, tylko tym, czym oni chcieli, aby byli.
###### **Ba 6,46**
 Sami rzemieślnicy nie dożyli długich lat, jakże więc ich wytwory mają być bogami?
###### **Ba 6,47**
 Pozostawili więc swym potomkom hańbę i oszustwo.
###### **Ba 6,48**
 Kiedy przyjdzie czas wojny i klęski, wówczas kapłani naradzają się, gdzie ukryć się wraz z tymi bogami.
###### **Ba 6,49**
 Jakże więc nie pojąć tego, że nie są bogami ci, którzy nie mogą zachować siebie od wojny i klęsk?
###### **Ba 6,50**
 Dlatego niech będzie wiadomo, że rzeczy drewniane, pozłacane i posrebrzane są oszustwem. Wszystkie narody i wszyscy królowie niech wiedzą, że nie są one bogami, ale dziełem rąk ludzkich i żadnego działania Bożego w nich nie ma.
###### **Ba 6,51**
 Któż więc nie pozna, że nie są bogami?
###### **Ba 6,52**
 Żadnego króla nad krajem nie postawią ani deszczu nie ześlą ludziom.
###### **Ba 6,53**
 Spraw ich nie rozsądzą ani nie uwolnią skrzywdzonego, będąc bezsilni jak wrony między niebem a ziemią.
###### **Ba 6,54**
 Kiedy pożar wybuchnie w świątyni bogów drewnianych, pozłacanych i posrebrzanych, kapłani ich uciekają i ocalają się, a oni sami w środku palą się jak belki.
###### **Ba 6,55**
 Nie mogą się oprzeć ani królowi, ani nieprzyjacielowi.
###### **Ba 6,56**
 Jakże więc może się komuś wydawać albo może ktoś myśleć, że są bogami?
###### **Ba 6,57**
 Bogowie drewniani, posrebrzani i pozłacani ani przed złodziejami, ani przed rozbójnikami nie mogą się obronić, którzy jako silniejsi od nich zabierają im złoto, srebro i ubranie, co jest na nich, i odchodzą, a oni nie mogą obronić siebie.
###### **Ba 6,58**
 Dlatego lepiej jest być królem, który może pokazać swe męstwo, albo pożytecznym w domu naczyniem, którym posługuje się właściciel, niż tymi fałszywymi bogami; albo bramą domu, która ochrania wszystko, co jest w nim, niż tymi fałszywymi bogami; albo kolumną drewnianą w pałacu królewskim niż tymi fałszywymi bogami.
###### **Ba 6,59**
 Słońce, księżyc i gwiazdy, które świecą i otrzymały zadanie, by były pożyteczne, chętnie okazują posłuszeństwo.
###### **Ba 6,60**
 Podobnie i błyskawica, kiedy zabłyśnie, jest piękna dla wzroku. Dlatego też i wiatr wieje w każdym miejscu.
###### **Ba 6,61**
 Podobnie i chmury, kiedy otrzymają od Boga polecenie, by przelatywać nad całą ziemią, wykonują nakaz; także i piorun z wysoka zesłany, aby niszczyć góry i lasy, wykonuje polecenie.
###### **Ba 6,62**
 A ci ani wyglądem, ani siłą nie dadzą się [z nimi] porównać.
###### **Ba 6,63**
 Stąd wcale nie należy mniemać, że są oni bogami, ani ich tak nazywać, nie mogą bowiem ani karać, ani dobrze czynić ludziom.
###### **Ba 6,64**
 Skoro więc wiecie, że nie są bogami, nie bójcie się ich!
###### **Ba 6,65**
 Nie złorzeczą oni ani nie błogosławią królom.
###### **Ba 6,66**
 Poganom znaków na niebie nie ukażą, nie błyszczą jak słońce ani nie świecą jak księżyc.
###### **Ba 6,67**
 Zwierzęta są od nich mocniejsze, mogą bowiem uciec do kryjówki i tak pomóc sobie.
###### **Ba 6,68**
 W żaden sposób nie stwierdziliśmy, że są bogami, dlatego się ich nie bójcie!
###### **Ba 6,69**
 Jak strach na wróble na grządce ogórków, który przed niczym nie strzeże, są ich bogowie drewniani, pozłacani i posrebrzani.
###### **Ba 6,70**
 Podobnie można przyrównać ich bogów drewnianych, pozłacanych i posrebrzanych do krzaka cierniowego w ogrodzie, na którym siada każdy ptak, albo do trupa porzuconego w ciemnościach.
###### **Ba 6,71**
 Z purpury i bisiorów, które na nich butwieją, poznajecie, że nie są bogami. Na koniec oni sami będą stoczeni [przez robactwo] i staną się przedmiotem hańby w kraju.
###### **Ba 6,72**
 Przeto lepszy jest człowiek sprawiedliwy, który nie posiada bożków, będzie bowiem daleko od hańby.
# Ba 6 PAU
# Ba 6 BP
###### **Ba 6,1**
 Z powodu grzechów, któreście popełnili przeciwko Bogu, będziecie uprowadzeni w niewolę do Babilonu przez Nabuchodonozora, króla babilońskiego.
###### **Ba 6,2**
 A kiedy wejdziecie do Babilonu, będziecie tam musieli pozostać przez wiele lat i przez długi czas, aż do siedmiu pokoleń; potem jednak wyprowadzę was stamtąd w pokoju.
###### **Ba 6,3**
 w Babilonie ujrzycie bożków ze srebra, złota i z drzewa, obnoszonych na ramionach i wzbudzających lęk w poganach.
###### **Ba 6,4**
 Strzeżcie się więc, abyście się nie upodobnili do tych cudzoziemców i aby i was nie zdjął lęk przed nimi.
###### **Ba 6,5**
 Kiedy ujrzycie tłum, który idąc przed i za nimi będzie oddawał im cześć, powiedzcie sobie w myśli: "Tobie to, o Panie, należy oddawać cześć".
###### **Ba 6,6**
 Anioł mój bowiem jest z wami i on będzie czuwał nad waszym życiem.
###### **Ba 6,7**
 Język ich został wygładzony przez rzemieślnika, ozłocono ich i posrebrzono, więc są oni oszustwem i nie umieją mówić.
###### **Ba 6,8**
 Jak dla dziewczyny lubującej się w ozdobach, bierze się złoto i wykonuje się korony na głowy tych bożków.
###### **Ba 6,9**
 Zdarza się, że sami kapłani zdzierają ze swoich bożków złoto i srebro i obracają je na własny użytek, a nawet obdarzają nimi zawodowe nierządnice.
###### **Ba 6,10**
 Ozdabiają je szatami jak ludzi - te bożki ze srebra, złota i z drzewa. One jednak nie umieją się uchronić ani przed rdzą, ani przed robactwem.
###### **Ba 6,11**
 A chociaż okryte są szkarłatnymi szatami, trzeba oczyszczać ich oblicze z powodu kurzu świątyni, którego pełno jest na nich.
###### **Ba 6,12**
 Ten oto dzierży berło, niby jaki władca kraju, ale nie jest w stanie zabić tego, kto zawinił przeciwko niemu.
###### **Ba 6,13**
 W prawicy trzyma on miecz lub siekierę, ale nie zdoła się obronić ani w czas wojny, ani też przed złodziejami.
###### **Ba 6,14**
 Po tym można poznać, że nie są bogami, więc się ich nie lękajcie!
###### **Ba 6,15**
 Podobnie jak stłuczone naczynie staje się bezużyteczne dla człowieka, tak też dzieje się z bożkami umieszczonymi w świątyniach.
###### **Ba 6,16**
 Oczy ich napełniają się kurzem, który wnoszą stopy wchodzących [do świątyni].
###### **Ba 6,17**
 Podobnie jak przed człowiekiem, który obraził króla, zamyka się wszystkie bramy dziedzińca, ponieważ ma być prowadzony na śmierć, tak kapłani zabezpieczają świątynie bożków drzwiami, zamkami i zasuwami, aby ich nie ograbili złodzieje.
###### **Ba 6,18**
 Zapałają światło i to liczniejsze nawet niż dla siebie samych, lecz oni nie mogą widzieć żadnego z nich.
###### **Ba 6,19**
 Dzieje się z nimi podobnie jak z belką w świątyni: wnętrze ich - jak powiadają - zżera robactwo, wychodzące z ziemi, a chociaż zżera ono zarówno ich samych, jak i ich szaty, oni tego nie czują.
###### **Ba 6,20**
 Ich oblicze czernieje od dymu w świątyni.
###### **Ba 6,21**
 Nad ich postaciami i głowami latają nietoperze, jaskółki i inne ptaki, wskakują także na nie koty.
###### **Ba 6,22**
 Po tym poznacie, że nie są oni bogami, więc się nie lękajcie ich.
###### **Ba 6,23**
 Jeżeli ze złota, którym [bożki] są pokryte dla ich przyozdobienia, nie usunie się rdzy, nie będą lśnić. Kiedy je odlewano, nie czuli tego.
###### **Ba 6,24**
 Kupiono je za wysoką cenę, a nie ma w nich tchnienia życia.
###### **Ba 6,25**
 ponieważ nie mają nóg, nosi się je na ramionach, ukazując w ten sposób ludziom ich haniebną niemoc. Sami też słudzy muszą się tego wstydzić, że gdy któryś z nich [przypadkiem] upadnie, muszą go sami podnosić.
###### **Ba 6,26**
 Gdy go ktoś prosto ustawi, nie poruszy się sam, a gdy się go pochyli, nie wyprostuje się. Stawiają przed nimi dary jak przed zmarłymi.
###### **Ba 6,27**
 Ofiary im składane zabierają kapłani i sprzedają, a żony ich solą je, nie dając nic ani ubogiemu, ani choremu. Nawet kobiety w stanie słabości miesięcznej i położnice dotykają się ich ofiar.
###### **Ba 6,28**
 poznając po tym wszystkim więc, że nie są bogami, nie lękajcie się ich.
###### **Ba 6,29**
 Jakże można je nazywać bogami? Oto nawet kobiety składają ofiary tym bożkom ze srebra, złota i z drzewa!
###### **Ba 6,30**
 A w ich świątyniach siedzą kapłani, mając rozdarte szaty, ogolone czaszki i brody i odkryte głowy.
###### **Ba 6,31**
 Wykrzykują głośno przed swymi bożkami, jak to niektórzy czynią na stypach pogrzebowych.
###### **Ba 6,32**
 Kapłani zdejmują z nich szaty, aby nimi przyodziać swe żony i dzieci.
###### **Ba 6,33**
 Czy im ktoś wyrządził krzywdę, czy coś dobrego uczynił, nie są zdolne odpłacić im za to. Nie mogą ani ustanowić króla, ani złożyć go z tronu.
###### **Ba 6,34**
 Nie są też w stanie udzielić nikomu bogactwa ani nawet jednego miedziaka. Jeżeli ktoś złożył im ślub, a nie dopełnił go, nie upominają się o to.
###### **Ba 6,35**
 Nie ocalą człowieka od śmierci ani wyrwą słabego spod przemocy możnego.
###### **Ba 6,36**
 Ślepemu nie przywrócą wzroku, uciśnionego nie wyzwolą.
###### **Ba 6,37**
 Wdowie nie okażą litości, sieroty nie wspomogą.
###### **Ba 6,38**
 Te drewniane, pozłacane i posrebrzane bożki podobne są do złomów skalnych, a ci, którzy im służą, okryją się wstydem.
###### **Ba 6,39**
 Jakże więc można wierzyć i mówić, że one są bogami?
###### **Ba 6,40**
 Co więcej, sami Chaldejczycy okazują im zniewagę. Bo gdy ujrzą jakiegoś niemego, który nie może mówić, przyprowadzają go do Bela, prosząc, aby mu przywrócił mowę, jak gdyby mógł [ich] słyszeć.
###### **Ba 6,41**
 Nie są w stanie zrozumieć, że takich bogów należy porzucić, bo nie mają rozumu.
###### **Ba 6,42**
 Niewiasty zaś opasane sznurami siedzą przy drogach i palą otręby.
###### **Ba 6,43**
 A skoro tylko jedna z nich wybrana przez przechodnia odda się mu, urąga swojej sąsiadce, że nie została zaszczycona jak ona i że sznur jej nie został przerwany.
###### **Ba 6,44**
 Wszystko, co się wokół nich dzieje - oszustwem jest. Jakże więc można wierzyć i mówić, że są bogami?
###### **Ba 6,45**
 Wykonali je rzemieślnicy i złotnicy, stąd niczym innym nie są, jak tylko tym, co artyści chcieli uczynić.
###### **Ba 6,46**
 Sami ich wykonawcy nie są długowieczni. Jakże więc twory ich mogłyby stać się bogami?
###### **Ba 6,47**
 Swym potomkom pozostawiają tylko oszustwo i hańbę.
###### **Ba 6,48**
 Bo gdy nadchodzi czas wojny i innych klęsk, kapłani naradzają się między sobą, gdzie by się z nimi ukryć.
###### **Ba 6,49**
 Jakżeż więc nie twierdzić, że nie są one bogami, skoro same nie potrafią się ocalić ani od wojny, ani od innych klęsk?
###### **Ba 6,50**
 A ponieważ są tylko przedmiotami z drewna, pozłacanymi i posrebrzanymi, w końcu będzie wiadome, że są tylko oszustwem; dla wszystkich ludów i królów będzie rzeczą oczywistą, że nie są one bogami, a tylko dziełami rąk ludzkich, i że nie ma w nich żadnego boskiego działania.
###### **Ba 6,51**
 Któż więc nie pojmie jasno, że nie są one bogami?
###### **Ba 6,52**
 Nie zdołają ani króla ustanowić nad krajem, ani ludziom zesłać deszczu.
###### **Ba 6,53**
 Nie rozstrzygną im żadnej sprawy ani też nie wyzwolą uciemiężonego, są bowiem bezsilne jak wrony między niebem a ziemią.
###### **Ba 6,54**
 A gdy w końcu ogień spadnie na świątynię tych drewnianych, pozłacanych i posrebrzanych bożków, ich kapłani ratują się ucieczką, a one spalają się wewnątrz jak belki.
###### **Ba 6,55**
 Nie umieją się przeciwstawić żadnemu królowi ani wrogowi.
###### **Ba 6,56**
 Jakżeż więc można uznać albo też wierzyć, że są bogami?
###### **Ba 6,57**
 Bożki drewniane, posrebrzane i pozłacane, nie mogą się obronić ani przed złodziejami, ani przed rabusiami; ci jako silniejsi od nich odzierają je ze złota i srebra oraz szat, którymi są okryte, i odchodzą, one zaś siebie wspomóc nie mogą.
###### **Ba 6,58**
 Dlatego lepiej być królem, który potrafi okazać swoją moc, lub nawet pożytecznym naczyniem w domu, którego używa właściciel, aniżeli fałszywymi bogami; lepiej także być bramą w domu, która strzeże tego, co w nim jest, aniżeli takimi fałszywymi bogami; lepiej wreszcie być drewnianą kolumną w pałacu królewskim aniżeli takimi fałszywymi bogami.
###### **Ba 6,59**
 Słońce, księżyc i gwiazdy, które świecą: zostały przeznaczone, aby były pożyteczne - są temu posłuszne.
###### **Ba 6,60**
 podobnie i błyskawica, gdy zabłyśnie, wspaniała jest; i wiatr wieje w każdym miejscu [kraju].
###### **Ba 6,61**
 Kiedy Bóg rozkaże chmurom przelatywać nad całą ziemią, wypełniają, co im zlecono.
###### **Ba 6,62**
 Również ogień zesłany z góry, by strawił góry i lasy, wypełnia, co mu rozkazano. Ci zaś bogowie nie są mu podobni ani pod względem piękna, ani mocy.
###### **Ba 6,63**
 Dlatego nie można ani wierzyć, ani mówić, że są bogami, gdyż nie są w stanie ani sprawiedliwie rozsądzać, ani ludziom dobrze czynić.
###### **Ba 6,64**
 Wiedząc zatem, że nie są bogami, nie lękajcie się ich.
###### **Ba 6,65**
 Nie są oni zdolni ani przekląć królów, ani im błogosławić.
###### **Ba 6,66**
 Nie ukazują też ludom żadnych znaków na niebie; nie świecą jak słońce; nie oświetlają jak księżyc.
###### **Ba 6,67**
 Zwierzęta są w lepszym położeniu niż oni, gdyż uciekając mogą znaleźć bezpieczne miejsce i uratować się.
###### **Ba 6,68**
 W żaden sposób nie wynika więc, żeby byli bogami; dlatego nie lękajcie się ich!
###### **Ba 6,69**
 Jak strach na polu ogórkowym niczego nie ustrzeże, podobnie ich bogowie - drewniani, pozłacani i posrebrzani.
###### **Ba 6,70**
 Można też przyrównać tych drewnianych, pozłacanych i posrebrzanych bogów do krzaka cierniowego w ogrodzie, na którym siada wszelki ptak, lub do trupa porzuconego w ciemności.
###### **Ba 6,71**
 Z purpury i bisioru, które na nich butwieją, można poznać, że nie są oni bogami. W końcu sami zostaną zżarci i staną się przedmiotem hańby w kraju.
###### **Ba 6,72**
 Więcej wart jest zatem człowiek sprawiedliwy, który nie ma żadnych bożków, bo uniknie pohańbienia.
# Ba 6 BR
###### **Ba 6,1**
 Z powodu wszystkich grzechów, których dopuściliście się wobec Boga, jako niewolnicy zostaniecie uprowadzeni przez Nabuchodonozora, króla babilońskiego, do Babilonu.
###### **Ba 6,2**
 Znalazłszy się już w Babilonie, będziecie musieli pozostać tam przez wiele lat, aż do siódmego pokolenia. Potem sprowadzę was w spokoju z powrotem do waszego kraju.
###### **Ba 6,3**
 W Babilonie będziecie oglądali wiele podobieństw bogów ze srebra, złota i z drewna. Ludzie będą nosić te podobizny na własnych ramionach, budząc tym lęk dokoła wśród pogan.
###### **Ba 6,4**
 Pamiętajcie, żebyście nie usiłowali upodobnić się do obcych i nie zaczęli obawiać się tych bogów,
###### **Ba 6,5**
 patrząc jak wielu idzie za nimi i cześć im oddaje. Raczej powtarzajcie sobie w duchu: Tylko Tobie należy się cześć, o Panie!
###### **Ba 6,6**
 Anioł mój bowiem jest zawsze z wami i on będzie czuwał nad waszym życiem.
###### **Ba 6,7**
 Rzemieślnik wykonał tym bóstwom gładkie języki, pokrył je złotem i srebrem, ale wszystko to jest zwykłym oszustwem: bogowie ci wcale nie mogą mówić.
###### **Ba 6,8**
 Jak młodej dziewczynie, która lubi się stroić,
###### **Ba 6,9**
 tak również tym bóstwom wkłada się korony złote na głowy. Zdarza się jednak niekiedy, że kapłani zdejmują z owych bóstw złoto i srebro i zatrzymują je dla siebie. Z niego też opłacają nierządnice [przetrzymywane] we własnych izbach.
###### **Ba 6,10**
 Bóstwa wykonane ze srebra, złota lub drzewa ubierają, jak ludzi, w różne szaty. Ale nie są w stanie uchronić ich przed brudem i robakami.
###### **Ba 6,11**
 Przykrywa się je purpurowymi zasłonami, ale mimo to z ich twarzy trzeba ścierać kurz, który unosi się w świątyni i osiada na nich grubą warstwą.
###### **Ba 6,12**
 I chociaż taki bóg trzyma w ręku berło, jak ktoś władający jakimś krajem, nie może on jednak pozbawić życia tego, kto mu odmawia posłuszeństwa.
###### **Ba 6,13**
 W swej prawicy trzyma on, co prawda, miecz albo siekierę, ale nigdy nie jest w stanie uniknąć wojny lub schronić się przed rozbójnikami.
###### **Ba 6,14**
 W ten sposób sami pokazują, że nie ma żadnych bogów. Nie potrzebujecie się więc ich obawiać!
###### **Ba 6,15**
 Jak rozbite naczynie gliniane do niczego się już nie nadaje, tak też jest i z wystawionymi w świątyni posągami bogów:
###### **Ba 6,16**
 pełno w ich oczach kurzu, który wnoszą na stopach przychodzący do świątyni.
###### **Ba 6,17**
 Jak dwory królewskie dokoła są pozamykane przed tym, który obraził króla, i jest on raczej skazany na zagładę, tak też kapłani świątynie swoich bóstw zabezpieczają przed złodziejami za pomocą specjalnych drzwi, zamków i rygli.
###### **Ba 6,18**
 Kapłani zapalają światła - i to nawet więcej, niż ich potrzebują dla siebie - ale ich bożki żadnego z tych świateł nie widzą.
###### **Ba 6,19**
 Dzieje się z nimi tak, jak z belką w świątyni: jest cała zniszczona od wewnątrz; wcale nie widzą robaków, które wychodzą z ziemi i pożerają je razem z ich ubiorem, a one nie są tego świadome.
###### **Ba 6,20**
 Twarze ich są aż czarne od dymu, który się w świątyni unosi.
###### **Ba 6,21**
 Na ich postaciach, na głowach siadają nietoperze, jaskółki oraz inne ptaki, a także wskakują na nie koty.
###### **Ba 6,22**
 Widzicie więc z tego wszystkiego, że to żadni bogowie. Wcale się więc ich nie bójcie!
###### **Ba 6,23**
 Są pokrywani złotem po to, żeby wyglądali ładniej. Ale jeśli się nie zetrze z nich kurzu, nie świecą się wcale. [Bogowie owi] nie czuli też, kiedy ich odlano.
###### **Ba 6,24**
 Płacono za nich każdą cenę, choć nie było w nich tchnienia żadnego życia.
###### **Ba 6,25**
 Ponieważ nie mogli się posługiwać własnymi nogami, trzeba było nosić ich na ramionach, pokazując przez to ludziom, że są nic nie warci. Wstydzą się nawet ci, co ich obsługują, muszą ich bowiem podtrzymywać, bo inaczej przewracają się na ziemię.
###### **Ba 6,26**
 Jeżeli zaś któregoś z tych bogów już postawią, to i tak nie może się sam poruszać; kiedy zaś któryś będzie pochylony, sam nie wyprostuje się. Dlatego kładzie się przed nimi dary jak przed zmarłymi.
###### **Ba 6,27**
 Tym zaś, co składa się im na ofiary, kapłani handlują, ciągnąc z tego zyski. Nie lepiej postępują ich niewiasty: robią dla siebie zapasy z mięsa ofiarnego, nic zaś nie dają ani ubogim, ani chorym. Ofiar dotykają zarówno kobiety nieczyste, jak i matki dopiero po połogu.
###### **Ba 6,28**
 Widzicie więc sami, że to żadni bogowie. Wcale się więc ich nie bójcie!
###### **Ba 6,29**
 I jak tu można ich w ogóle nazywać bogami? Tym bożkom ze srebra, złota i drzewa ofiary składają zwykłe kobiety.
###### **Ba 6,30**
 W ich świątyniach kapłani się rozsiadają, mają porozdzierane szaty, brody i włosy ostrzyżone a głowy wcale nie nakryte.
###### **Ba 6,31**
 Krzyczą i zawodzą przed swymi bogami, jak się to czyni na stypach pogrzebowych.
###### **Ba 6,32**
 Kapłani ściągają z bogów ich ubiory i stroją w nie własne żony i dzieci.
###### **Ba 6,33**
 Gdy ktoś tym bogom uczyni coś złego czy dobrego, nie są w stanie za to zapłacić.
###### **Ba 6,34**
 Nikomu nie mogą też przynieść bogactwa lub jakichkolwiek pieniędzy. A jeśli ktoś złoży im jakieś śluby, ale ich nie wypełnia, to i tak nie uczynią mu nic złego.
###### **Ba 6,35**
 Żadnego człowieka nie mogą uratować od śmierci ani wyrwać słabego spod władzy mocnego.
###### **Ba 6,36**
 Ślepemu nie potrafią przywrócić wzroku, a uwięzionemu - wolności.
###### **Ba 6,37**
 Nie mogą się ulitować nad wdowami, nie są w stanie przyjść z pomocą sierocie.
###### **Ba 6,38**
 Do zwykłych kamieni górskich podobni są owi bogowie z drewna, pozłacani i posrebrzani. Hańbą się okrywa, kto takim cześć składa.
###### **Ba 6,39**
 Jakże więc można w to wszystko wierzyć albo utrzymywać, że są to rzeczywiście bogowie?
###### **Ba 6,40**
 Sami Chaldejczycy znieważają tych bogów. Gdy bowiem mają wśród siebie jakiegoś niemego, który nie może mówić, to przyprowadzają go do Bela prosząc, żeby niememu przywrócił mowę, tak jakby Bel mógł ich w ogóle posłyszeć.
###### **Ba 6,41**
 Oni nie są w stanie zastanowić się i porzucić swoich bogów. Niczego nie rozumieją.
###### **Ba 6,42**
 Kobiety siedzą przy drogach, opasane sznurami, i palą otręby jakby kadzidło.
###### **Ba 6,43**
 Gdy któraś z nich zostanie wzięta spośród reszty przez jakiegoś przechodnia i odda mu się na osobności, to [wróciwszy] naśmiewa się ze swojej sąsiadki, że tamta nie okazała się godna podobnego szczęścia i jej sznur nie został jeszcze zerwany.
###### **Ba 6,44**
 Wszystko, co dzieje się wokół tych bogów, jest kłamstwem. Jakże ktoś może w to wszystko wierzyć, albo utrzymywać, że to rzeczywiście są bogowie?
###### **Ba 6,45**
 Bogów owych robią różni rzemieślnicy i złotnicy. Nie są oni więc niczym innym, jak tylko tym, czym mieli być według zamierzeń ich twórców,
###### **Ba 6,46**
 którzy sami nie żyją zresztą zbyt długo. Jakże więc można uważać za bóstwo to, co oni zrobili? Otóż nie! Żadną miarą!
###### **Ba 6,47**
 Tylko kłamstwo i wstyd zostawiają swemu potomstwu.
###### **Ba 6,48**
 Gdy bóstwom owym zagraża wojna lub inne nieszczęście, kapłani zastanawiają się wspólnie, gdzie można by się skryć z tymi bogami?
###### **Ba 6,49**
 Jak więc można nie zauważyć, że to żadni bogowie, skoro nie są w stanie ani uratować się przed wojną, ani ujść cało przed nieszczęściem?
###### **Ba 6,50**
 Są to zwykłe drewniane przedmioty, pokryte złotem lub srebrem. Widać z tego wyraźnie, że to wszystko jest oszustwem. Z czasem przekonają się wszystkie narody i królowie wszyscy, że to nie żadne bóstwa, a tylko wytwory rąk ludzkich, w których nie ma żadnych boskich mocy.
###### **Ba 6,51**
 Tak więc nikt już chyba nie będzie twierdził, że są to rzeczywiście bogowie.
###### **Ba 6,52**
 Bogowie owi nie mogą ustanawiać w żadnym kraju króla ani zesłać ludziom deszczu.
###### **Ba 6,53**
 Nie są w stanie rozsądzać spraw ludzkich ani wziąć w obronę tego, który doznał krzywdy. Są bowiem zupełnie bezradni, niczym wrony w powietrzu między niebem a ziemią.
###### **Ba 6,54**
 Kiedy pożar ogarnie świątynię bóstw drewnianych, pokrytych złotem i srebrem, wtedy kapłani sami ratują się ucieczką, a bóstwa płoną w ogniu jak drewniane belki.
###### **Ba 6,55**
 Nie są one w stanie przeciwstawić się jakiemukolwiek królowi lub wrogowi.
###### **Ba 6,56**
 Jakże więc ktokolwiek może przypuszczać albo wręcz wierzyć, że są to rzeczywiście bogowie? Ci bogowie z drewna, pokryci srebrem i złotem nie mogą się schronić przed żadnymi rabusiami lub złodziejami.
###### **Ba 6,57**
 Ci ostatni są mocniejsi, ściągają z bogów srebro i złoto razem z ich szatami, które były na nich nałożone. Zabierają wszystko i odchodzą, a bogowie pozostają bezradni, nic nie mogą zrobić.
###### **Ba 6,58**
 Zamiast więc być takim fałszywym bóstwem o wiele lepiej jest być królem, który może okazać swoją siłę, albo jakimś pożytecznym sprzętem domowym, którym jego właściciel dowolnie się posługuje. Lepiej niż owym oszukańczym bóstwem być drzwiami w domu, które chronią tego, co się w domu znajduje, lepiej być kolumną drewnianą w pałacu królewskim niż takim oszukańczym bóstwem.
###### **Ba 6,59**
 Słońce, księżyc i gwiazdy ustanowione po to, żeby dzięki swemu światłu były pożyteczne, chętnie poddają się swemu przeznaczeniu.
###### **Ba 6,60**
 Podobnie i błyskawica, kiedy ukaże się na niebie, przedstawia piękny obraz. Tak też jest i z wiatrem, który wieje na cały kraj.
###### **Ba 6,61**
 Kiedy Bóg rozkaże obłokom, żeby nadciągnęły nad całą ziemię, natychmiast wypełniają to polecenie.
###### **Ba 6,62**
 Albo gdy wreszcie ogień jest zsyłany z wysokości, aby pochłaniać góry i lasy, to dzieje się wszystko dokładnie według otrzymanego polecenia. Temu wszystkiemu bogowie owi nie dorównują ani pięknem, ani siłą.
###### **Ba 6,63**
 Dlatego ani wierzyć, ani utrzymywać nie można, że są to rzeczywiście bogowie. Nie są oni w stanie ani kary ludziom wymierzać, ani im dobrze czynić.
###### **Ba 6,64**
 Skoro więc już teraz wiecie, że nie są bogami, wcale się ich nie obawiajcie!
###### **Ba 6,65**
 Królom owi bogowie ani złorzeczyć, ani błogosławić też nie mogą.
###### **Ba 6,66**
 Narodom nie pokazują żadnych śladów na niebie. Nie mogą promieniować z nieba jak słońce lub księżyc.
###### **Ba 6,67**
 Zamiast takimi bóstwami lepiej być zwierzętami, które mogą uciec i schronić się w jakimś bezpiecznym miejscu.
###### **Ba 6,68**
 Nie ma więc żadnych dowodów, że są to rzeczywiście bóstwa. Dlatego wcale się ich nie bójcie!
###### **Ba 6,69**
 Ci z drewna wykonani, a złotem i srebrem pokryci bogowie są jak straszydła na ogórkowych grządkach, w rzeczywistości nie odstraszające nikogo.
###### **Ba 6,70**
 Albo jak krzak cierniowy w ogrodzie, na którym siadają najrozmaitsze ptaki, albo wreszcie jak trupy, wyrzucone w ciemności; tak bowiem wyrzuca się tych z drewna wykonanych, a złotem i srebrem pokrytych bogów.
###### **Ba 6,71**
 Po purpurze i bisiorze szat, które na nich butwieją, możecie się przekonać, że nie są to żadne bóstwa. Same one wkrótce będą stoczone przez robactwo i staną się pośmiewiskiem dla całego kraju.
###### **Ba 6,72**
 Tak więc lepiej jest być człowiekiem uczciwym, nie posiadającym żadnych posążków bogów, bo wtedy uniknie się pohańbienia.
# Ba 6 WUJ
