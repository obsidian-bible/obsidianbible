# Dn 9 BT5
###### **Dn 9,1**
 W pierwszym roku Dariusza z rodu Medów, syna Artakserksesa, sprawującego władzę nad królestwem chaldejskim,
###### **Dn 9,2**
 w roku pierwszym jego panowania, ja, Daniel, dociekałem w Pismach liczby lat, które objawił Pan prorokowi Jeremiaszowi, że ma się dopełnić siedemdziesiąt lat spustoszenia Jerozolimy.
###### **Dn 9,3**
 Zwróciłem więc swe oblicze do Pana Boga, oddając się modlitwie i błaganiu w postach, pokucie i popiele.
###### **Dn 9,4**
 I modliłem się do Pana, Boga mojego, wyznawałem i mówiłem: O Panie, Boże mój, wielki i straszliwy, który dochowujesz wiernie przymierza tym, co Ciebie kochają i przestrzegają Twoich przykazań.
###### **Dn 9,5**
 Zgrzeszyliśmy, zbłądziliśmy, popełniliśmy nieprawość i zbuntowaliśmy się, odstąpiliśmy od Twoich przykazań.
###### **Dn 9,6**
 Nie byliśmy posłuszni Twoim sługom, prorokom, którzy przemawiali w Twoim imieniu do naszych królów, do naszych przywódców, do naszych przodków i do całej ludności kraju.
###### **Dn 9,7**
 U Ciebie, Panie, sprawiedliwość, a u nas wstyd na twarzach, jak to jest dziś u nas – mieszkańców Judy i Jerozolimy, i całego Izraela, u bliskich i dalekich, we wszystkich krajach, dokąd ich wypędziłeś z powodu niewierności, jaką Ci okazali.
###### **Dn 9,8**
 Panie! Wstyd na naszych twarzach, naszych królów, naszych przywódców i naszych ojców, bo zgrzeszyliśmy przeciw Tobie.
###### **Dn 9,9**
 Ale Pan, Bóg nasz, jest miłosierny i okazuje łaskawość, mimo że zbuntowaliśmy się przeciw Niemu
###### **Dn 9,10**
 i nie słuchaliśmy głosu Pana, Boga naszego, by postępować według wskazań, które nam dał przez swoje sługi, proroków.
###### **Dn 9,11**
 Cały Izrael przekroczył Twoje Prawo i pobłądził, nie słuchając Twego głosu. Spadło na nas przekleństwo [poparte] przysięgą, które zostało zapisane w Prawie Mojżesza, sługi Bożego; zgrzeszyliśmy bowiem przeciw Niemu.
###### **Dn 9,12**
 Spełnił więc słowo, jakie wypowiedział przeciw nam i naszym władcom, którzy panowali nad nami, że sprowadzi na nas wielkie nieszczęście, jakiego nie było pod całym niebem, a jakie spadło na Jerozolimę.
###### **Dn 9,13**
 Tak jak zostało napisane w Prawie Mojżesza, przyszło na nas całe to nieszczęście; nie przebłagaliśmy Pana, Boga naszego, odwracając się od naszych występków i nabywając znajomości Twej prawdy.
###### **Dn 9,14**
 Czuwał więc Pan nad nieszczęściem i sprowadził je na nas, bo Pan, Bóg nasz, jest sprawiedliwy we wszystkich swych poczynaniach, my zaś nie usłuchaliśmy Jego głosu.
###### **Dn 9,15**
 A teraz, Panie, Boże nasz, który wyprowadziłeś swój naród z ziemi egipskiej mocną ręką, zyskując sobie imię, jakie trwa do dziś: zgrzeszyliśmy i popełniliśmy nieprawość.
###### **Dn 9,16**
 Panie, według Twojego miłosierdzia, niech ustanie Twój zapalczywy gniew nad Twoim miastem, Jerozolimą, nad Twoją świętą górą. Bo z powodu naszych grzechów i przewinień naszych przodków stała się Jerozolima i lud Twój przedmiotem szyderstwa u wszystkich wokół nas.
###### **Dn 9,17**
 Teraz zaś, Boże nasz, wysłuchaj modlitwy Twojego sługi i jego błagań i rozjaśnij swe oblicze nad świątynią, która leży zniszczona – ze względu na Ciebie, Panie!
###### **Dn 9,18**
 Nakłoń, mój Boże, swego ucha i wysłuchaj! Otwórz swe oczy i zobacz nasze spustoszenie i miasto, nad którym wzywano Twego imienia. Albowiem zanosimy modlitwy do Ciebie, opierając się nie na naszej sprawiedliwości, ale ufni w Twoje wielkie miłosierdzie.
###### **Dn 9,19**
 Usłysz, Panie! Odpuść, Panie! Panie, zwróć uwagę i działaj niezwłocznie, przez wzgląd na siebie samego, mój Boże! Bo Twojego imienia wzywano nad Twym miastem i nad Twym narodem.
###### **Dn 9,20**
 Gdy jeszcze mówiłem i modliłem się, wyznając grzechy swoje, swojego narodu, Izraela, i składając przed Panem, Bogiem moim, błagania za świętą górę mojego Boga,
###### **Dn 9,21**
 gdy więc jeszcze wymawiałem [słowa] modlitwy, mąż Gabriel, którego spostrzeg-łem przedtem, przybył do mnie, lecąc pośpiesznie, w porze wieczornej ofiary.
###### **Dn 9,22**
 Przybył, rozmawiał ze mną i powiedział: Danielu, wyszedłem teraz, by ci dać całkowite zrozumienie.
###### **Dn 9,23**
 Gdy zacząłeś błagalne modlitwy, wypowiedziano słowo, ja zaś przybyłem, by ci je oznajmić. Ty jesteś bowiem [mężem] umiłowanym. Przeniknij więc słowo i zrozum widzenie:
###### **Dn 9,24**
 Ustalono siedemdziesiąt tygodninad twoim narodem i twoim świętym miastem, by położyć kres nieprawości, grzech obłożyć pieczęciąi odpokutować występek, a wprowadzić wieczną sprawiedliwość, przypieczętować widzenie i prorokai namaścić Święte świętych.
###### **Dn 9,25**
 Ty zaś wiedz i rozumiej:Od chwili, kiedy wypowiedziano słowo, że nastąpi powrót i zostanie odbudowanaJerozolima, do Władcy-Pomazańca –siedem tygodni; i w ciągu sześćdziesięciu dwu tygodnizostaną odbudowane dziedziniec i wał, jednak w czasach pełnych ucisku.
###### **Dn 9,26**
 A po sześćdziesięciu dwóch tygodniachPomazaniec zostanie zgładzonyi nie będzie dla niego...Miasto zaś i świątyniazginą wraz z wodzem, który nadejdzie. Koniec jego nastąpi wśród powodzi, i do końca wojnypotrwają zamierzone spustoszenia.
###### **Dn 9,27**
 Utrwali on przymierze dla wieluw ciągu jednego tygodnia. A około połowy tygodniaustanie ofiara krwawa i ofiara pokarmowa. Na skrzydle zaś świątynibędzie ohyda ziejąca pustkąi przetrwa aż do końca, do czasu ustalonego na spustoszenie***».
# Dn 9 PAU
###### **Dn 9,1**
 Było to w pierwszym roku Dariusza, syna Aswerusa, z plemienia Medów, panującego nad królestwem chaldejskim.
###### **Dn 9,2**
 W pierwszym roku jego panowania ja, Daniel, dociekałem w księgach liczby lat, które objawił PAN prorokowi Jeremiaszowi, a które miały upłynąć od spustoszenia Jerozolimy. Miało to być siedemdziesiąt lat.
###### **Dn 9,3**
 Zwróciłem się ku mojemu PANU Bogu, aby Go błagać. Modliłem się i płakałem przed Nim, poszcząc w pokutnym worze i prochu.
###### **Dn 9,4**
 Modliłem się do PANA, mojego Boga, wyznając: O, PANIE, Boże wielki i budzący grozę, przestrzegający przymierza i wierny wobec tych, którzy Ciebie kochają i wypełniają Twoje nakazy.
###### **Dn 9,5**
 Zgrzeszyliśmy, postępowaliśmy bezbożnie, zawiniliśmy, zbuntowaliśmy się i odstąpiliśmy od Twoich nakazów i Twoich przykazań.
###### **Dn 9,6**
 Nie słuchaliśmy Twoich sług, proroków, którzy w Twoim imieniu mówili do naszych królów, wodzów, do naszych ojców i całego ludu ziemi.
###### **Dn 9,7**
 Tobie, PANIE, przynależy sprawiedliwość, nam zaś - mieszkańcom Jerozolimy i całemu Izraelowi, bliskim i dalekim, we wszystkich krajach, dokąd ich wygnałeś z powodu ich niewierności wobec Ciebie - wstyd, jak to jest dzisiaj.
###### **Dn 9,8**
 PANIE! Hańba naszym królom, naszym wodzom i naszym ojcom, bo zgrzeszyliśmy przeciw Tobie.
###### **Dn 9,9**
 PAN nasz, Bóg, jest miłosierny i przebacza, mimo że zbuntowaliśmy się przeciwko Niemu.
###### **Dn 9,10**
 Nie słuchaliśmy głosu PANA, naszego Boga, aby postępować według Jego Prawa, które nam dał przez swoje sługi, proroków.
###### **Dn 9,11**
 Cały Izrael przekroczył Twoje Prawo, odwrócił się i nie słuchał Twojego głosu. Zgrzeszyliśmy przeciw Tobie, dlatego zesłałeś na nas przekleństwo i skierowałeś przeciw nam przysięgę, która jest zapisana w Prawie Mojżesza, sługi Boga.
###### **Dn 9,12**
 Spełnił swoje słowo, które wypowiedział przeciw nam i przeciw sędziom, którzy nas sądzili, że ześle na nas wielkie nieszczęście, jakiego jeszcze nie było pod niebem, a jakie spadło na Jerozolimę.
###### **Dn 9,13**
 Zgodnie z tym, co jest napisane w Prawie Mojżesza, wszelkie nieszczęście spadło na nas, my jednak nie szukaliśmy ratunku u PANA, naszego Boga, nie poniechaliśmy naszych grzechów i nie chcieliśmy zrozumieć Jego prawdy.
###### **Dn 9,14**
 PAN sam pilnował tych nieszczęść. Pozwolił, aby przyszły na nas, bo sprawiedliwy jest Pan, nasz Bóg, we wszystkim, co czyni. A my nie słuchaliśmy Jego głosu.
###### **Dn 9,15**
 Ty PANIE, Boże nasz, mocną ręką wyprowadziłeś swój naród z kraju Egiptu i tak wsławiłeś swoje imię, jak to jest dzisiaj. My zaś zgrzeszyliśmy i postąpiliśmy źle.
###### **Dn 9,16**
 PANIE, w swej sprawiedliwości powstrzymaj gniew i wzburzenie na Twoje miasto Jerozolimę, na Twoją świętą górę. Z powodu naszych grzechów i grzechów naszych ojców Jerozolima i Twój naród znoszą obelgi tych, którzy nas otaczają.
###### **Dn 9,17**
 Ty, nasz Boże, wysłuchaj modlitwy swojego sługi i jego błagania. Przez wzgląd na siebie rozjaśnij swoje oblicze nad Twoją spustoszoną świątynią.
###### **Dn 9,18**
 Nakłoń, PANIE, swojego ucha i usłysz! Otwórz swoje oczy i spójrz na nasze zniszczenie, na to miasto, nad którym wzywano Twojego imienia! Bo modląc się i zanosząc błagania do Ciebie, pokładamy nadzieję nie we własnej sprawiedliwości, ale w Twoim wielkim miłosierdziu.
###### **Dn 9,19**
 PANIE, usłysz! PANIE, przebacz! PANIE, wspomnij i przybądź co prędzej, przez wzgląd na siebie samego, PANIE, bo Twoje imię było wzywane nad tym miastem i nad tym narodem.
###### **Dn 9,20**
 Tak właśnie mówiłem, modliłem się, wyznawałem moje grzechy i grzechy mojego narodu, Izraela, i zanosiłem błagania do PANA, mojego Boga, za świętą górę Boga.
###### **Dn 9,21**
 Gdy jeszcze się modliłem, w porze wieczornej ofiary pokarmowej szybkim lotem przybył do mnie ten sam Gabriel, którego widziałem w moim widzeniu.
###### **Dn 9,22**
 Wszedł i powiedział do mnie: „Danielu, przybyłem, aby dać ci jasne zrozumienie.
###### **Dn 9,23**
 Gdy zacząłeś się modlić i błagać, Bóg wypowiedział słowo, a ja przyszedłem, aby ci je objawić. Jesteś obdarzony łaską, zważ więc na to, co ci powiem, żebyś zrozumiał widzenie.
###### **Dn 9,24**
 Nad twoim ludem i nad Miastem Świętym ustalono siedemdziesiąt tygodni, by nieprawość doszła do swojego kresu, by grzech opieczętować, by odpokutować występek i zaprowadzić wieczną sprawiedliwość, by opieczętować widzenie i proroka, by namaścić świętego nad świętymi.
###### **Dn 9,25**
 Uznaj to i zrozum: od chwili, kiedy wypowiedziano słowo, że nastąpi powrót i zostanie odbudowana Jerozolima, do nadejścia Przywódcy-Pomazańca - siedem tygodni. Sześćdziesiąt dwa tygodnie - i zostanie odbudowany dziedziniec i fosa, choć będą to jeszcze lata ucisku.
###### **Dn 9,26**
 A po sześćdziesięciu dwóch tygodniach Pomazaniec zostanie zabity - nie za swoje winy. Ludzie księcia, który nadejdzie, zniszczą miasto i świątynię. U jego kresu - wielki zamęt. Aż do końca będzie wojna i jak postanowione - wielkie spustoszenie.
###### **Dn 9,27**
 Przez niego przymierze stanie się dla wielu nie do udźwignięcia, przez jeden tydzień. W połowie tygodnia zostanie zniesiona ofiara krwawa i pokarmowa. Na skrzydle świątyni znajdzie się odrażająca obrzydliwość, aż niszczyciela dosięgnie ustalony koniec”.
# Dn 9 BP
###### **Dn 9,1**
 W pierwszym roku Dariusza, syna Aswerusa z rodu Medów, który został monarchą królestwa Chaldejczyków,
###### **Dn 9,2**
 pierwszego roku jego panowania, ja, Daniel, rozważałem liczbę lat w księgach, [które mówią], że Jahwe przemówił do proroka Jeremiasza, iż siedemdziesiąt lat upłynie nad spustoszoną Jerozolimą.
###### **Dn 9,3**
 Zwróciłem swe oblicze do Pana Boga, aby Go prosić, zanosząc modlitwę i błaganie w poście, worze [pokutnym] i popiele.
###### **Dn 9,4**
 I modliłem się do Jahwe, mojego Boga, czyniłem wyznanie i mówiłem: O Panie, Boże wielki i straszliwy, strzegący Przymierza i miłosierdzia względem tych, co Go kochają i przestrzegają Jego przykazań.
###### **Dn 9,5**
 Zgrzeszyliśmy, popełniliśmy nieprawość, źleśmy postępowali, buntowaliśmy się, odstępując od Twoich przykazań i Twoich praw.
###### **Dn 9,6**
 Nie słuchaliśmy sług Twoich, Proroków, którzy w Imię Twoje przemawiali do naszych królów, naszych książąt, naszych ojców i do całego ludu ziemi.
###### **Dn 9,7**
 Do Ciebie, Panie, [należy] sprawiedliwość, nam zaś wypada się wstydzić - jak w tym właśnie dniu - mężom Judy, mieszkańcom Jeruzalem, całemu Izraelowi, tym którzy są blisko, i tym, którzy są daleko we wszystkich krajach, tam, gdzie ich zesłałeś za ich przeniewierstwa, jakich się wobec Ciebie dopuścili.
###### **Dn 9,8**
 Jahwe, nam się należy zawstydzenie oblicza, naszym królom, naszym książętom i naszym ojcom, bośmy zgrzeszyli przeciw Tobie.
###### **Dn 9,9**
 Ale u Pana, Boga naszego, jest miłosierdzie i przebaczenie, choć zbuntowaliśmy się przeciw Niemu.
###### **Dn 9,10**
 Nie słuchaliśmy głosu Jahwe, Boga naszego aby postępować według Jego praw, które nam dał za pośrednictwem swoich sług. Proroków.
###### **Dn 9,11**
 Cały Izrael przekroczył Twoje prawa i odstąpił, aby nie słuchać Twojego głosu, i dlatego spadło na nas przekleństwo i groźby [wypowiedziane pod przysięgą], które są zapisane w Prawie Mojżesza, sługi Bożego, gdyż zgrzeszyliśmy przeciw Niemu.
###### **Dn 9,12**
 Dotrzymał swojego słowa, które wypowiedział przeciw nam i przeciw naszym sędziom, którzy nas sądzili, że sprowadzi na nas wielkie nieszczęście. [I prawdą jest], że takiego nie było pod całym niebem jak to, które spotkało Jerozolimę.
###### **Dn 9,13**
 Zgodnie z tym, co jest napisane w Prawie Mojżeszowym, całe to nieszczęście przyszło na nas, a myśmy nie przejednali oblicza Jahwe, Boga naszego, odwracając się od naszych grzechów i ucząc się zrozumienia Twojej prawdy.
###### **Dn 9,14**
 Czuwał Jahwe nad nieszczęściem i sprowadził je na nas. Bo Jahwe, nasz Bóg, jest sprawiedliwy we wszystkich swych czynach, których dokonał. [To] my nie słuchaliśmy Jego głosu.
###### **Dn 9,15**
 Teraz, Panie, Boże nasz, który wyprowadziłeś Twój lud z ziemi egipskiej mocną ręką i zdobyłeś sobie Imię, jakie masz po ten dzień: Zgrzeszyliśmy, źle postąpiliśmy.
###### **Dn 9,16**
 Panie, stosownie do wszystkich Twoich [dowodów] dobroci, niech się odwróci - proszę - Twój gniew i Twoja złość od miasta Twojego Jeruzalem, od Twojej świętej góry, albowiem przez nasze grzechy, przez nieprawości naszych ojców Jerozolima i lud Twój stali się przedmiotem szyderstwa wszystkich naszych sąsiadów.
###### **Dn 9,17**
 Teraz więc wysłuchaj, Boże nasz, modlitwy Twojego sługi i jego błagań i spraw, niech rozjaśni się Twoje oblicze nad leżącym w gruzach Twoim sanktuarium z powodu [gniewu] Pana.
###### **Dn 9,18**
 Nakłoń, Boże, swe ucho i wysłuchaj. Otwórz swe oczy i zobacz nasze zniszczenia, miasto, nad którym zostało wezwane Twoje Imię, albowiem zanosimy nasze błagania przed Twoje oblicze nie przez nasze czyny sprawiedliwe, ale ze względu na mnóstwo Twoich [dowodów] miłosierdzia.
###### **Dn 9,19**
 Panie, wysłuchaj, Panie, przebacz, pamiętaj i działaj. Nie ociągaj się ze względu na siebie, Boże mój, gdyż Twoje Imię jest wypowiadane nad miastem Twoim i nad Twoim ludem.
###### **Dn 9,20**
 Jeszcze mówiłem, modliłem się i wyznawałem swój grzech i grzech mojego narodu izraelskiego, i zanosiłem moje błaganie przed oblicze Jahwe, mojego Boga, za górę świętą mojego Boga,
###### **Dn 9,21**
 jeszcze mówiłem [pogrążony] w modlitwie, gdy mąż Gabriel, którego widziałem w widzeniu na początku, przybył do mnie w chyżym locie w czasie wieczornej ofiary [pokarmów].
###### **Dn 9,22**
 przybył, rozmawiał ze mną i rzekł: Danielu, oto teraz wyszedłem, aby cię uczynić zdolnym zrozumieć.
###### **Dn 9,23**
 Na początku twoich błagań padło słowo i ja przybyłem, aby [je tobie] oznajmić, bo ty jesteś umiłowany. Rozważ słowo i zrozum widzenie:
###### **Dn 9,24**
 Siedemdziesiąt tygodni jest postanowione, gdy chodzi o twój naród i twoje miasto święte, aby zakończyć nieprawość, położyć pieczęć na przestępstwie, odpuścić grzech, wprowadzić wieczną sprawiedliwość, opieczętować widzenie i proroka oraz namaścić Święte Świętych.
###### **Dn 9,25**
 Wiedz i zrozum: Od wyjścia nakazu, aby przywrócić i odbudować Jerozolimę, do [ukazania się] pomazańca-księcia, siedem tygodni. Po upływie sześćdziesięciu dwóch tygodni zostaną znów odbudowane plac i rów, ale w czasach ucisku.
###### **Dn 9,26**
 po upływie sześćdziesięciu dwóch tygodni pomazaniec zostanie stracony i nie będzie miał [następcy]. Miasto i sanktuarium zniszczy naród księcia, który przyjdzie, a dokona się to pośród powodzi. Wojna będzie do końca i zniszczenie postanowione.
###### **Dn 9,27**
 Uczyni mocne przymierze z wieloma podczas jednego tygodnia. W połowie tygodnia sprawi, że ustanie ofiara krwawa i ofiara pokarmów. Na skrzydle [ołtarza] będzie ohyda spustoszenia, aż postanowiona kara rozleje się nad niszczycielem.
# Dn 9 BR
###### **Dn 9,1**
 W roku pierwszym panowania Dariusza, który pochodził z rodu Medów i był synem Artakserksesa, a rządził całym królestwem Chaldejczyków,
###### **Dn 9,2**
 w pierwszym roku jego panowania, ja, Daniel, badałem Pisma, licząc lata, które - zgodnie z tym, co Pan objawił prorokowi Jeremiaszowi - miały upłynąć od zburzenia Jerozolimy, a miało być owych lat siedemdziesiąt.
###### **Dn 9,3**
 Zwróciłem moje oblicze w stronę Pana Boga, żeby zanosić do Niego prośby i błagania, poszcząc w worze pokutnym i w popiele.
###### **Dn 9,4**
 I modląc się do mego Boga, wyznawałem i mówiłem: Ach, Panie mój, Boże Wielki i straszny, Ty, który dochowujesz z całą wiernością Twojego Przymierza względem tych, którzy się Ciebie boją i zachowują Twoje przykazania,
###### **Dn 9,5**
 zgrzeszyliśmy, dopuściliśmy się nieprawości; czyniliśmy zło, zdradziliśmy Ciebie i odwróciliśmy się od Twoich przykazań i pouczeń.
###### **Dn 9,6**
 Nie słuchaliśmy Twoich sług, proroków przemawiających w Twoim imieniu do naszych królów i książąt, do naszych ojców i do wszystkich mieszkańców tego kraju.
###### **Dn 9,7**
 U Ciebie, Panie, sprawiedliwość, nasze zaś oblicza okrywa wstyd. Oto, co spotkało nas, synów Judy, mieszkańców Jerozolimy i wszystkich Izraelitów, zarówno tych, co są blisko, jak i tych, co są daleko, w obcych krainach, po których nas rozproszyłeś z powodu występków, jakich dopuszczaliśmy się względem Ciebie.
###### **Dn 9,8**
 Tak, Panie, hańba naszym królom, książętom, naszym ojcom, bo zgrzeszyliśmy przeciwko Tobie.
###### **Dn 9,9**
 O Panie i Boże nasz, okaż nam swoje miłosierdzie i przebacz nam, bośmy Ciebie zdradzili.
###### **Dn 9,10**
 Nie słuchaliśmy głosu Pana i Boga naszego, nie przestrzegaliśmy Jego praw, które nam przekazywał przez swoje sługi i przez swych proroków.
###### **Dn 9,11**
 Cały Izrael łamał Twoje prawa i odchodził [od Ciebie] nie słuchając Twego głosu. Dlatego spadły na nas wszystkie przekleństwa nam poprzysiężone w Prawie Mojżesza, sługi Bożego, ponieważ zgrzeszyliśmy przeciwko Niemu.
###### **Dn 9,12**
 Rozkazał tedy wypełnić słowa, które wypowiedział przeciwko nam oraz przeciwko książętom sprawującym nad nami władzę: sprowadzi na nas nieszczęścia tak wielkie w Jerozolimie, że większych nigdy dotąd nie było pod słońcem.
###### **Dn 9,13**
 I chociaż zgodnie z tym, co jest napisane w Prawie Mojżeszowym, spadły na nas wszystkie te nieszczęścia, nie rozjaśniliśmy oblicza Pana i Boga naszego, nie odwróciliśmy się od naszych nieprawości i nie usiłowaliśmy poznać Twojej prawdy.
###### **Dn 9,14**
 Pan sam pilnował owych nieszczęść i czuwał, żeby spadły na nas. Pan, Bóg nasz, jest bowiem sprawiedliwy we wszystkim, co czyni, a myśmy nie słuchali Jego głosu.
###### **Dn 9,15**
 Teraz zaś, Panie nasz i Boże, który prawicą potężną wyprowadziłeś swój lud z ziemi egipskiej, przez co sława Twoja trwa po dzień dzisiejszy, teraz myśmy zgrzeszyli, popełniliśmy zło.
###### **Dn 9,16**
 Panie [błagam Cię] na wszystkie Twoje sprawiedliwe dzieła, odwróć zapalczywość Twego gniewu od Jerozolimy, od Twojego miasta, od Twojej świętej góry, bo z powodu naszych grzechów oraz grzechów naszych ojców Jerozolimę i cały Twój lud hańba okryła w oczach tych wszystkich, którzy nas otaczają.
###### **Dn 9,17**
 Wysłuchaj więc, o nasz Boże, modlitw i błagań Twojego sługi. Niech Twoje oblicze rozjaśni Twój opuszczony Przybytek, o Panie!
###### **Dn 9,18**
 Nakłoń Twoich uszu i racz nas wysłuchać, o mój Boże! Otwórz swoje oczy i wejrzyj na nasze poniżenie i spustoszenie miasta, nad którym wzywano Twojego Imienia. nasze błagania zanosimy do Ciebie nie ze względu na nasze dobre uczynki, lecz dla wielkiego miłosierdzia Twego.
###### **Dn 9,19**
 O Panie, czuwaj nad nami i zacznij działać! Przez wzgląd na siebie samego, Boże mój, nie zwlekaj! Przecież nad Twoim miastem i nad całym Twoim ludem było kiedyś wzywane Twoje święte Imię!
###### **Dn 9,20**
 Kiedy tak mówiłem, przedkładając moje błagania i wyznając grzechy zarówno moje, jak i całego ludu, kiedy modliłem się do Pana, Boga mojego na górze świętej mojego Boga,
###### **Dn 9,21**
 kiedy tak powtarzałem moje błagania, Gabriel, który objawił mi się już przedtem w wiedzeniu, pojawił się niespodziewanie nade mną w czasie składania ofiary wieczornej
###### **Dn 9,22**
 i powiedział do mnie: Danielu, oto przychodzę, żeby oświecić twój umysł.
###### **Dn 9,23**
 Gdy tylko zacząłeś się modlić, zostało wypowiedziane słowo, które ja teraz ci przekazuję. Jesteś mężem szczególnego upodobania. Staraj się wniknąć w to, co ci powiem, żebyś mógł zrozumieć należycie całe widzenie.
###### **Dn 9,24**
 Siedemdziesiąt tygodni wyznaczono dla ludu twego i dla świętego miasta. I skończy się wszelka nieprawość. Opieczętowane będą wszystkie występki, odpokutowane wszystkie niegodziwości. Wprowadzona zostanie sprawiedliwość na zawsze, zamknie się pieczęciami wizje i proroctwa, a to, co najświętsze, będzie namaszczone.
###### **Dn 9,25**
 Staraj się poznać to i zrozumieć: Od czasu zapowiedzi powrotu i odbudowania Jerozolimy, aż do czasu Księcia Pomazańca upłynie siedem tygodni i sześćdziesiąt dwa tygodnie. Zostaną odbudowane i dziedzińce, i mury, choć czasy będą wciąż pełne ucisku.
###### **Dn 9,26**
 Gdy zaś sześćdziesiąt dwa tygodnie upłyną i Pomazaniec zostanie zgładzony, i nie będzie już nic dla niego zburzone zostaną miasto i przybytek przez księcia, który ma nadejść. Znajdzie swój kres w nieszczęściu, a wojny z nim będą do końca i spustoszenia wcześniej zamierzone.
###### **Dn 9,27**
 Z wieloma zawrze on przymierze, na czas jednego tygodnia; po upływie zaś połowy tygodnia zniesie ofiary z pokarmów i ofiary krwawe. Na jednym zaś skrzydle Świątyni będzie [obraz] ohydnej brzydoty. I tak będzie do końca, do czasu, który jest na spustoszenie.
# Dn 9 WUJ
###### **Dn 9,1**
 Roku pierwszego Daryusza syna Asuerowego z nasienia Medów, który panował nad królestwem Chaldejskiem:
###### **Dn 9,2**
 Roku pierwszego królestwa jego, ja Daniel wyrozumiałem w księgach liczbę lat, o której stała się mowa Pańska do Jeremiasza proroka, aby się wypełniło siedmdziesiąt lat spustoszenia Jeruzalem.
###### **Dn 9,3**
 I obróciłem oblicze moje do Pana Boga mego, abym prosił i modlił się w pościech, w worze, i w popiele. A modliłem się Panu Bogu memu, i wyznawałem, a rzekłem:
###### **Dn 9,4**
 Proszę Panie Boże wielki, i straszny, który strzeżesz przymierza i miłosierdzia miłującym ciebie, i strzegącym przykazania twego.
###### **Dn 9,5**
 Zgrzeszyliśmy, nieprawość czyniliśmy, niezbożnieśmy się sprawowali, odwróciliśmy się, i odstąpiliśmy od przykazań twoich, i sądów.
###### **Dn 9,6**
 Nie byliśmy posłuszni sług twoich proroków, którzy mówili w imię twoje królom naszym, książętom naszym, ojcom naszym, i wszemu ludowi ziemie.
###### **Dn 9,7**
 Tobie Panie sprawiedliwość: a nam zawstydzenie twarzy, jako jest dzisia mężowi Juda, i obywatelom Jeruzalem, i wszemu Izraelowi tym, którzy blizko są, i tym, którzy daleko we wszech ziemiach, do którycheś je wygnał, dla nieprawości ich, któremi grzeszyli przeciw tobie.
###### **Dn 9,8**
 Panie, nam zawstydzenie twarzy, królom naszym, książętom naszym, i ojcom naszym, którzy zgrzeszyli:
###### **Dn 9,9**
 A tobie Panu Bogu naszemu miłosierdzie i zlitowanie: bośmy odstąpili od ciebie:
###### **Dn 9,10**
 I nie słuchaliśmy głosu Pana Boga naszego, żebyśmy chodzili w zakonie jego, który nam dał przez sługi swoje proroki.
###### **Dn 9,11**
 I wszystek Izrael przestąpili zakon twój, i ustąpili, aby nie słuchali głosu twego: i kropiło na nas przeklęctwo, i klątwa, którą napisano w księgach Mojżesza sługi Bożego, bośmy mu zgrzeszyli.
###### **Dn 9,12**
 I utwierdził mowy swoje, które mówił na nas, i na książęta nasze, którzy nas sadzili, że miał przywieść na nas złe wielkie, jakie nigdy nie było pode wszem niebem, wedle tego co się stało w Jeruzalem.
###### **Dn 9,13**
 Jako napisano w zakonie Mojżeszowym, to wszystko złe przyszło na nas, a nie prosiliśmy oblicza twego Panie Boże nasz, abyśmy się nawrócili od nieprawości naszych, a myślili o prawdzie twojej.
###### **Dn 9,14**
 I czuł Pan nad złością, i przywiódł ją na nas: sprawiedliwy Pan Bóg nasz we wszech uczynkach swych, które uczynił: bośmy nie słuchali głosu jego.
###### **Dn 9,15**
 A teraz Panie Boże nasz, któryś wywiódł lud twój z ziemie Egiptskiej ręką mocną, i uczyniłeś sobie imię wedle dnia tego: zgrzeszyliśmy, nieprawośćeśmy czynili,
###### **Dn 9,16**
 Panie, przeciw wszelakiej sprawiedliwości twojej: niech się proszę odwróci gniew twój i zapalczywość twoja od miasta twego Jeruzalem, i od góry świętej twojej. Bo dla grzechów naszych, i dla nieprawości ojców naszych Jeruzalem i lud twój są na pośmiewisko wszystkim około nas.
###### **Dn 9,17**
 Teraz tedy wysłuchaj Boże nasz modlitwę sługi twego, i prośby jego: a okaż oblicze twoje nad świątynią twoją, która spustoszona jest, dla ciebie samego.
###### **Dn 9,18**
 Nakłoń Boże mój ucha twego, a usłysz: otwórz oczy twoje, a obacz spustoszenie nasze: i miasto, nad którem wzywano imienia twego. Bo nie na sprawiedliwościach naszych pokładamy modlitwę przed obliczem twojem: ale na litościach twoich mnogich.
###### **Dn 9,19**
 Wysłuchaj Panie, ubłagaj się Panie, obacz, a uczyń: nie omieszkawaj sam dla siebie Boże mój: bo imienia twego wzywano nad miastem i nad ludem twoim.
###### **Dn 9,20**
 A gdym jeszcze mówił, i modlił się, a wyznawałem grzechy moje, i grzechy ludu mego Izraelskiego, i pokładałem prośby moje przed obliczem Boga mego o górę świętą Boga mego:
###### **Dn 9,21**
 Gdym ja jeszcze mówił w modlitwie, oto mąż Gabryel, któregom widział w widzeniu z początku, prędko lecący dotknął się mnie czasu ofiary wieczornej:
###### **Dn 9,22**
 I nauczył mię a mówił zemną, i rzekł: Danielu terazem wyszedł, abych cię nauczył, a żebyś zrozumiał.
###### **Dn 9,23**
 Od początku modlitw twoich wyszła mowa: a jam przyszedł oznajmić tobie, boś mąż pożądania jest, ty tedy obacz mowę, a zrozumiej widzenie.
###### **Dn 9,24**
 Siedmdziesiąt tygodni ukrócone są na lud twój, i na miasto święte twoje, aby się dokonało przestępstwo, a grzech, aby wziął koniec, ażeby nieprawość była zgładzona, a przywiedziona sprawiedliwość wieczna, i aby się spełniło widzenie i proroctwo, a był pomazany święty świętych.
###### **Dn 9,25**
 A tak wiedz a obacz: od wyszcia mowy, aby zaś było zbudowane Jeruzalem aż do Chrystusa wodza, tygodniów siedm, i tygodniów sześćdziesiąt i dwa będą: a znowu będzie zbudowana ulica, i mury w ciasności czasów.
###### **Dn 9,26**
 A po tygodniów sześćdziesiąt i dwu będzie zabit Chrystus: a nie będzie ludem, jego, który się go zaprzy. A miasto i świątynią skazi lud z wodzem, który przydzie: a koniec jego spustoszenie, a po skończeniu wojny postanowione spustoszenie.
###### **Dn 9,27**
 A zmocni przymierze z mnogimi tydzień jeden, a w pół tygodnia ustanie ofiara i ofiarowanie: i będzie w kościele obrzydłość spustoszenia, i aż do skończenia i końca będzie trwać spustoszenie.
