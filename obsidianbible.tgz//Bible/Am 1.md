# Am 1 BT5
###### **Am 1,1**
 Słowa Amosa, który był jednym spośród pasterzy z Tekoa: co widział w sprawie Izraela, za dni Ozjasza, króla Judy, i za dni Jeroboama, syna Joasza, króla Izraela, na dwa lata przed trzęsieniem ziemi.
###### **Am 1,2**
 Powiedział on:Pan z Syjonu zagrzmi,z Jeruzalem wyda swój głos, a lamentować będą łąki pasterzyi szczyt Karmelu uschnie.
###### **Am 1,3**
 Tak mówi Pan:Z powodu trzech występków Damaszkui z powodu czterechnie odwrócę tego [wyroku],gdyż zmłócili saniami żelaznymi Gilead.
###### **Am 1,4**
 Ześlę więc ogień na dom Chazaela, by strawił pałace Ben-Hadada.
###### **Am 1,5**
 Rozbiję zawory Damaszkui wytępię mieszkańców doliny Aweni dzierżącego berło w Bet-Eden,a naród Aramu uprowadzony zostanie do Kir –mówi Pan.
###### **Am 1,6**
 Tak mówi Pan:Z powodu trzech występków Gazyi z powodu czterechnie odwrócę tego [wyroku],gdyż doszczętnie uprowadzili na wygnanie [ludność], by wydać ją Edomowi.
###### **Am 1,7**
  Ześlę więc ogień na mury Gazy, i strawi on jej pałace.
###### **Am 1,8**
 Wytępię mieszkańców Aszdodui dzierżącego berło w Aszkelonie. Zwrócę rękę przeciw Ekronowii zginie reszta Filistynów –rzekł Pan Bóg.
###### **Am 1,9**
 Tak mówi Pan:Z powodu trzech występków Tyrui z powodu czterechnie odwrócę tego [wyroku],gdyż wydali oni Edomowi uprowadzonych aż do ostatniegoi nie pamiętali o bratnim przymierzu.
###### **Am 1,10**
 Ześlę więc ogień na mury Tyru, i strawi jego pałace.
###### **Am 1,11**
 Tak mówi Pan:Z powodu trzech występków Edomui z powodu czterechnie odwrócę tego [wyroku],gdyż prześladował mieczem brata swego, tłumiąc uczucie miłosierdzia, trwał w swym gniewie nieustanniei gniew swój chował do końca.
###### **Am 1,12**
 Ześlę więc ogień na Teman, i strawi pałace Bosry.
###### **Am 1,13**
 Tak mówi Pan:Z powodu trzech występków synów Ammonai z powodu czterechnie odwrócę tego [wyroku],gdyż rozpruwał łona ciężarnych kobiet Gileadu,by rozszerzyć swoje granice.
###### **Am 1,14**
 Rozpalę więc ogień na murach Rabba,i strawi jego pałacepodczas wrzawy w dzień bitwy, podczas burzy w dzień wichru.
###### **Am 1,15**
 I pójdzie król ich w niewolę, on i książęta jego razem –rzekł Pan.
# Am 1 PAU
###### **Am 1,1**
 Słowa Amosa, który był jednym z pasterzy w Tekoa. W czasach Ozjasza, króla judzkiego, i w czasach Jeroboama, syna Joasza, króla izraelskiego, na dwa lata przed trzęsieniem ziemi, miał on widzenie dotyczące Izraela.
###### **Am 1,2**
 Powiedział on: PAN zagrzmi z Syjonu, wyda swój głos z Jerozolimy, spustoszone będą pastwiska pasterzy i uschnie szczyt Karmelu.
###### **Am 1,3**
 Tak mówi PAN: Z powodu trzech występków Damaszku i z powodu czterech nie odwrócę tego wyroku, gdyż zmłócili żelaznym wałem Gilead.
###### **Am 1,4**
 Ześlę więc ogień na dom Chazaela, by pożarł pałace Ben-Hadada.
###### **Am 1,5**
 Złamię rygle Damaszku i wytnę mieszkańców doliny Awen i trzymającego władzę w Bet-Eden, a naród Aramu będzie uprowadzony do Kir- mówi PAN.
###### **Am 1,6**
 Tak mówi PAN: Z powodu trzech występków Gazy i z powodu czterech nie odwołam tego wyroku, gdyż uprowadzili wszystkich bez reszty, by wydać ich Edomowi.
###### **Am 1,7**
 Ześlę więc ogień na mury Gazy, by pożarł jej pałace.
###### **Am 1,8**
 Wytnę mieszkańców Aszdodu i trzymającego władzę w Aszkelonie. Zwrócę moją rękę przeciwko Ekronowi i zginie reszta Filistynów - powiedział PAN Bóg.
###### **Am 1,9**
 Tak mówi PAN: Z powodu trzech występków Tyru i z powodu czterech nie odwołam tego wyroku, gdyż uprowadzili wszystkich bez reszty, by wydać ich Edomowi, i nie pamiętali o bratnim przymierzu.
###### **Am 1,10**
 Ześlę więc ogień na mury Tyru, by pożarł jego pałace.
###### **Am 1,11**
 Tak mówi PAN: Z powodu trzech występków Edomu i z powodu czterech nie odwołam tego wyroku, gdyż swoich braci prześladował mieczem, tłumiąc w sobie wszelką litość. Gniew jego srożył się nieustannie, a jego złość nie miała końca.
###### **Am 1,12**
 Ześlę więc ogień na Teman, by spalił pałace Bosry.
###### **Am 1,13**
 Tak mówi PAN: Z powodu trzech występków Ammonitów i z powodu czterech nie odwołam tego wyroku, gdyż rozcinali brzuchy ciężarnym kobietom w Gileadzie, aby poszerzyć swoje granice.
###### **Am 1,14**
 Na murach Rabby rozpalę ogień, by spalił jej pałace, podczas zgiełku w dzień bitwy, podczas burzy w dzień wichru.
###### **Am 1,15**
 I pójdzie do niewoli ich król wraz z książętami - powiedział PAN.
# Am 1 BP
###### **Am 1,1**
 Słowa Amosa, jednego z pasterzy z Tekoa: widzenia dotyczące Izraela, które miał za króla judzkiego Ozjasza i za króla izraelskiego Jeroboama, syna Joasa, na dwa lata przed trzęsieniem ziemi.
###### **Am 1,2**
 Z mocą przemówi Jahwe z Syjonu, z Jeruzalem zagrzmi swym głosem; wtedy pastwiska pasterzy okryją się żałobą, a szczyty Karmelu ogarnie susza.
###### **Am 1,3**
 Tak mówi Jahwe: - Dla trzech i dla czterech zbrodni Damaszku nie odmienię postanowienia, bo żelaznymi płozami zmłócili Gilead.
###### **Am 1,4**
 Rzucę ogień do domu Chazaela, by strawił pałace Ben-Hadada;
###### **Am 1,5**
 rozwalę zapory Damaszku, wytracę mieszkańców Bikat-Awen i tego, kto dzierży berło w Bet-Eden, a lud aramejski pójdzie na wygnanie do Kir - mówi Jahwe.
###### **Am 1,6**
 Tak mówi Jahwe: - Dla trzech i dla czterech zbrodni Gazy nie odmienię postanowienia, bo uprowadzali jeńców całymi gromadami, żeby ich wydać w ręce Edomitów.
###### **Am 1,7**
 Rzucę ogień w mury Gazy, by strawił jej pałace;
###### **Am 1,8**
 wytracę mieszkańców Aszdodu i tego, kto dzierży berło w Aszkalonie, zwrócę prawicę moją przeciwko Ekronowi, i Filistyni wyginą do reszty - mówi Jahwe-Pan.
###### **Am 1,9**
 Tak mówi Jahwe: - Dla trzech i dla czterech zbrodni Tyru nie odmienię postanowienia, bo sprzedawali jeńców całymi gromadami Edomitom, nie zważając na związek bratni.
###### **Am 1,10**
 Rzucę ogień na mury Tyru, by strawił jego pałace.
###### **Am 1,11**
 Tak mówi Jahwe: - Dla trzech i dla czterech zbrodni Edomu nie odmienię postanowienia, bo prześladował brata swego mieczem, tłumiąc w sobie wszelkie uczucie litości; niezmiennie żywi [do niego] nienawiść i chowa na zawsze urazę.
###### **Am 1,12**
 Rzucę ogień na Teman, by strawił pałace Bocry.
###### **Am 1,13**
 Tak mówi Jahwe: - Dla trzech i dla czterech zbrodni Ammonitów nie zmienię postanowienia, bo otwierali w Gilead łona niewiast brzemiennych, żeby rozszerzyć swoje posiadłości.
###### **Am 1,14**
 Rozniecę ogień w murach Rabby, by strawił jej pałace, wśród okrzyków wojennych, jak w dzień bitwy, wśród zawieruchy, jak w dzień burzy;
###### **Am 1,15**
 a król ich pójdzie na wygnanie, on i książęta jego razem z nim - mówi Jahwe.
# Am 1 BR
###### **Am 1,1**
 Oto słowa, które Amos, pasterz z Tekoa, usłyszał, gdy miał widzenie w sprawie Izraela, kiedy to Ozjasz był królem Judy, a Jeroboam, syn Joasza, królem Izraela, na dwa lata przed trzęsieniem ziemi.
###### **Am 1,2**
 I powiedział: Pan zagrzmiał z Syjonu, z Jerozolimy głos Jego wychodzi. Smutek ogarnął pastwiska pasterzy, schnie wierzchołek Karmelu.
###### **Am 1,3**
 Pan zaś tak przemawia: Z powodu trzech występków Damaszku i z powodu czterech nie cofnę tego, co już powiedziałem. Ponieważ Gilead zmiażdzyli saniami żelaznymi do młocki,
###### **Am 1,4**
 ześlę przeto ogień na dom Chazaella i strawi wszystkie Ben-Hadada pałace.
###### **Am 1,5**
 Rozkruszę rygle Damaszku, zgubę zgotuję władcy z Bikat- Awen i temu, który dzierży berło w Bet-Eden. Mieszkańcy Aramu muszą isć do Kir na wygnanie - tak bowiem rozkazał Pan.
###### **Am 1,6**
 I oto, co Pan mówi: Z powodu trzech występków Gazy i z powodu czterech nie cofnę tego, co już powiedziałem. Ponieważ wyludnili całe okolice i w ręce Edomu wydali ich mieszkańców,
###### **Am 1,7**
 ześlę tedy ogień na wszystkie mury Gazy, który ich pałace strawi.
###### **Am 1,8**
 Władcy Aszdodu też zgotuję zgubę i temu, co dzierży berło w Aszkelonie. Potem po Ekron wyciągnę me ręce i zginie cała Filistynów reszta tak bowiem Pan rozkazał.
###### **Am 1,9**
 I oto, co jeszcze Pan mówi: Z powodu trzech występków Tyru i z powodu czterech nie cofnę tego, co już powiedziałem, bo wielkie rzesze uprowadzonych wydali w ręce Edomu i nie przestrzegali przymierza zawartego z braćmi.
###### **Am 1,10**
 Ześlę przeto ogień na wszystkie mury Tyru, a on ich pałace strawi.
###### **Am 1,11**
 I oto, co jeszcze Pan mówi: Z powodu trzech występków Edomu i z powodu czterech nie cofnę tego, co już powiedziałem. Ponieważ Edom mieczem wytracił swych braci, nie dopuszczając do miłosierdzia żadnego, ponieważ był nieubłagany w swym gniewie i nigdy nie odstąpił od zapalczywości,
###### **Am 1,12**
 ześlę przeto ogień na Teman, który strawi pałace Bosry.
###### **Am 1,13**
 I oto, co jeszcze Pan mówi: Z powodu trzech występków Ammonitów i z powodu czterech nie cofnę tego, co już powiedziałem. Ponieważ łona niewiast brzemiennych rozpruwali w Gilead, gdy dla siebie chcieli zdobyć więcej ziemi,
###### **Am 1,14**
 ześlę przeto ogień na wszystkie mury Rabba, a on pałace ich strawi pośród okrzyków wojennych w dniu bitwy, wśród ataków wichru i burzy.
###### **Am 1,15**
 Król wasz musi pójść na wygnanie, on i wszyscy książęta jego tak bowiem rozkazał Pan.
# Am 1 WUJ
###### **Am 1,1**
 Słowa Amos, który był między pasterzmi z Thekue: które widział nad Izraelem za dni Ozyasza króla Judzkiego, i za dni Jeroboama syna Joasa króla Izraelskiego, przed dwiema laty trzęsienia ziemie.
###### **Am 1,2**
 I rzekł: Pan z Sion zaryczy, a z Jeruzalem da głos swój: i płakały ozdoby pasterzów, a uszedł wierzch Karmela.
###### **Am 1,3**
 To mówi Pan: Dla trzech występków Damaszku, i dla czterzech nie nawrócę go: iż pomłócili wozmi żelaznemi Galaad.
###### **Am 1,4**
 I poślę ogień do domu Azael, i pożrze domy Benadad.
###### **Am 1,5**
 I skruszę zaworę Damaszku, wytracę obywatela z pola bałwańskiego, i trzymającego berło z domu rozkoszy: i będzie zaprowadzon lud Syryjski do Cyreny, mówi Pan:
###### **Am 1,6**
 To mówi Pan: Dla trzech występków Gazy, i dla czterzech nie nawrócę go: iż przenieśli pojmanie doskonałe, aby je zamknęli w Idumei.
###### **Am 1,7**
 A puszczę ogień na mury Gazy, i pożrze domy jej.
###### **Am 1,8**
 I wytracę obywatela z Azotu, i trzymającego berło z Askalonu, i obrócę rękę moję na Akkaron, i zginą pozostali z Philistynów, mówi Pan Bóg.
###### **Am 1,9**
 To mówi Pan: Dla trzech złości Tyru, i dla czterzech nie nawrócę go, dla tego, że zamknęli pojmanie doskonałe w Idumei, a nie wspomnieli przymierza braterskiego.
###### **Am 1,10**
 I puszczę ogień na mur Tyrski, i pożrze domy jego.
###### **Am 1,11**
 To mówi Pan: Dla trzech złości Edom i dla czterzech nie nawrócę go: przeto iż prześladował mieczem brata swego, i zgwałcił miłosierdzie swoje, i trzymał dłużej zapalczywość swoję, i zagniewanie swe zachował aż do końca.
###### **Am 1,12**
 Puszczę ogień na Theman: i pożrze domy Bosry.
###### **Am 1,13**
 To mówi Pan: Dla trzech złości synów Ammon, i dla czterzech nie nawrócę go: dla tego, bo rozcinał brzemienne Galaad, żeby rozszerzył granice swe.
###### **Am 1,14**
 A rozniecę ogień na murze Rabba, i pożrze domy jej w krzyku w dzień wojny, iż wichrem w dzień ruszenia.
###### **Am 1,15**
 I pójdzie Melchom w niewolą, i on i książęta jego społem, mówi Pan.
