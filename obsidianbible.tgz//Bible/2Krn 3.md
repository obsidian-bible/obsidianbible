# 2Krn 3 BT5
###### **2Krn 3,1**
 Wreszcie Salomon zaczął budować dom Pański w Jerozolimie na górze Moria, która została wskazana jego ojcu, Dawidowi, w miejscu, jakie przygotował Dawid na klepisku Ornana Jebusyty.
###### **2Krn 3,2**
 Zaczął zaś budować drugiego dnia w drugim miesiącu, w czwartym roku swego panowania.
###### **2Krn 3,3**
 Wymiary budowy domu Bożego, dane przez Salomona, były następujące: długość w mierze starożytnej sześćdziesiąt łokci, szerokość – dwadzieścia łokci.
###### **2Krn 3,4**
 Sień, która była przed główną budowlą świątyni, miała szerokości dziesięć, a długości – stosownie do szerokości świątyni – dwadzieścia łokci, wysokości zaś – trzydzieści łokci. Wewnątrz pokryto ją czystym złotem.
###### **2Krn 3,5**
 Wielki dom natomiast wyłożył drewnem cyprysowym, pokrył dobrym złotem, ponadto przyozdobił na wierzchu palmami i łańcuchami.
###### **2Krn 3,6**
 I wyłożył też dla ozdoby ten dom drogocennymi kamieniami, a złoto było złotem z Parwaim.
###### **2Krn 3,7**
 Złotem pokrył belki, progi, ściany i drzwi domu, a na ścianach wyrzeźbił cheruby.
###### **2Krn 3,8**
 Zbudował też Miejsce Najświętsze; długość jego wynosiła dwadzieścia łokci stosownie do szerokości domu, a szerokość jego również dwadzieścia łokci. Pokrył je dobrym złotem, o wadze sześciuset talentów.
###### **2Krn 3,9**
 Ciężar zaś gwoździ – pięćdziesiąt syklów złota. Także i górne pomieszczenia pokrył złotem.
###### **2Krn 3,10**
 W Miejscu Najświętszym uczynił dwa cheruby, dzieło wyrzeźbione artystycznie, i pokrył je złotem.
###### **2Krn 3,11**
 Skrzydła cherubów rozciągały się na dwadzieścia łokci. Jedno skrzydło, sięgające do ściany przybytku, miało pięć łokci; drugie skrzydło, dotykające skrzydła drugiego cheruba, również miało pięć łokci.
###### **2Krn 3,12**
 Podobnie i skrzydło drugiego cheruba sięgało ściany przybytku i miało pięć łokci, a skrzydło drugie także miało pięć łokci i dotykało skrzydła pierwszego cheruba.
###### **2Krn 3,13**
 Skrzydła tych cherubów rozciągały się na dwadzieścia łokci. Stały one na nogach, z twarzami zwróconymi ku przybytkowi.
###### **2Krn 3,14**
 Sporządził także zasłonę z fioletowej purpury, ze szkarłatu, z karmazynu i z bisioru, następnie wyszył na niej cheruby.
###### **2Krn 3,15**
 Postawił potem przed świątynią dwie kolumny o wysokości trzydziestu pięciu łokci, a głowica na szczycie każdej z nich pięciołokciowa.
###### **2Krn 3,16**
 Wyrzeźbił też łańcuchy, jak naszyjnik, i dał je na głowicę kolumny. Wykonał następnie sto jabłek granatu i zawiesił je na tych łańcuchach.
###### **2Krn 3,17**
 Przed Miejscem Świętym wzniósł te kolumny, jedną z prawej strony, drugą z lewej, i nadał prawej imię Jakin, lewej zaś imię Boaz.
# 2Krn 3 PAU
###### **2Krn 3,1**
 Salomon rozpoczął budowę domu PANA w Jerozolimie, na miejscu wskazanym przez Dawida, na górze Moria, na klepisku Ornana, Jebusyty, gdzie Bóg ukazał się jego ojcu Dawidowi.
###### **2Krn 3,2**
 Budowę rozpoczął drugiego dnia w drugim miesiącu czwartego roku swego panowania.
###### **2Krn 3,3**
 Takie były wymiary domu Bożego ustalone przez Salomona w starożytnych łokciach: długość - sześćdziesiąt łokci, szerokość - dwadzieścia łokci.
###### **2Krn 3,4**
 Przedsionek rozciągał się na całą szerokość domu, czyli miał dwadzieścia łokci. Był wysoki na sto dwadzieścia łokci. Od wewnątrz pokryto go szczerym złotem.
###### **2Krn 3,5**
 Główną część wyłożył drewnem cyprysowym i pokrył złotem wysokiej jakości, sufit przyozdobił płaskorzeźbami w kształcie palm i girland.
###### **2Krn 3,6**
 Ozdobił ją szlachetnymi kamieniami i parwajskim złotem.
###### **2Krn 3,7**
 Drewnianą część konstrukcji - progi, ściany i odrzwia domu pokrył złotem, a na ścianach wyrzeźbił cheruby.
###### **2Krn 3,8**
 Zbudował miejsce najświętsze o szerokości równej głównej części domu, czyli dwudziestu łokci, i o długości dwudziestu łokci. Pokrył je złotem wysokiej jakości o wadze sześciuset talentów.
###### **2Krn 3,9**
 Na gwoździe zużył pięćdziesiąt syklów złota. Złotem pokrył również sufit.
###### **2Krn 3,10**
 W miejscu najświętszym postawił dwa rzeźbione cheruby pokryte złotem.
###### **2Krn 3,11**
 Skrzydła cherubów miały łączną długość dwudziestu łokci. Każde skrzydło miało długość pięciu łokci. Jedno skrzydło pierwszego cheruba sięgało ściany domu, drugie zaś dotykało skrzydła drugiego cheruba.
###### **2Krn 3,12**
 Podobnie jedno skrzydło drugiego cheruba sięgało ściany domu, drugie zaś dotykało skrzydła pierwszego cheruba.
###### **2Krn 3,13**
 W sumie rozpiętość ich skrzydeł wynosiła dwadzieścia łokci. Cheruby stały z twarzami zwróconymi do wnętrza domu.
###### **2Krn 3,14**
 Sporządził także zasłonę z purpury, szkarłatu, karmazynu i bisioru i wyszył na niej cheruby.
###### **2Krn 3,15**
 Przed domem wzniósł dwie kolumny wysokie na trzydzieści pięć łokci. Każda z nich miała głowicę na pięć łokci.
###### **2Krn 3,16**
 Na szczytach kolumn zawiesił girlandy, między którymi umieścił sto metalowych owoców granatu.
###### **2Krn 3,17**
 Obie kolumny stały przed wejściem do świątyni, jedna po prawej, a druga po lewej stronie. Kolumnę z prawej strony nazwał Jakin, a tę z lewej Boaz.
# 2Krn 3 BP
###### **2Krn 3,1**
 I tak zaczął Salomon budować Dom Jahwe w Jeruzalem na górze Moria, która została wskazana jego ojcu Dawidowi, na miejscu, które Dawid przygotował na klepisku Ornana Jebuzyty.
###### **2Krn 3,2**
 A zaczął budować w drugim miesiącu, drugiego dnia, w czwartym roku swego panowania.
###### **2Krn 3,3**
 Takie zaś były wymiary budowy Domu Bożego ustalone przez Salomona: długość - w łokciach według miary dawnej - wynosiła sześćdziesiąt łokci, a szerokość - dwadzieścia łokci.
###### **2Krn 3,4**
 Przedsionek natomiast, który się znajdował przed Świątynią i odpowiadał szerokości Domu [Bożego], miał szerokości dwadzieścia łokci, sto dwadzieścia łokci wysokości, a wnętrze jego pokrył [Salomon] czystym złotem.
###### **2Krn 3,5**
 Dom wielki wyłożył drzewem cyprysowym i pokrył szczerym złotem, a na wierzchu przyozdobił palmami i girlandami.
###### **2Krn 3,6**
 Pokrył też Dom ozdobami z drogich kamieni, a złoto [użyte] było złotem z Parwaim.
###### **2Krn 3,7**
 Belki Domu, jego progi, ściany i odrzwia pokrył złotem, a na ścianach wyrzeźbił cheruby.
###### **2Krn 3,8**
 Zbudował również Przybytek Najświętszy, którego długość wynosiła odpowiednio do szerokości Domu dwadzieścia łokci, a szerokość również dwadzieścia łokci, i pokrył go szczerym złotem [wagi] sześciuset talentów.
###### **2Krn 3,9**
 Waga złota [zużytego] na gwoździe wynosiła pięćdziesiąt syklów. Również górne sale pokrył złotem.
###### **2Krn 3,10**
 Uczynił też do Przybytku Najświętszego dwa cheruby rzeźbione i pokryte złotem.
###### **2Krn 3,11**
 Skrzydła cherubów miały dwadzieścia łokci długości. Skrzydło jednego, długości pięciu łokci, sięgało ściany Przybytku, a drugie skrzydło, również długie na pięć łokci, stykało się ze skrzydłem drugiego cheruba.
###### **2Krn 3,12**
 Podobnie skrzydło drugiego cheruba, długie na pięć łokci, sięgało ściany Przybytku, a pozostałe skrzydło, mające również pięć łokci, sięgało skrzydła poprzedniego cheruba.
###### **2Krn 3,13**
 Tak to rozpostarte skrzydła owych cherubów miały dwadzieścia łokci; stały one na swych nogach z twarzami zwróconymi ku Przybytkowi.
###### **2Krn 3,14**
 Wykonał również zasłonę z jasnej i ciemnej purpury, karmazynu i bisioru i wyhaftował na niej cheruby.
###### **2Krn 3,15**
 Wzniósł też przed Świątynią dwie kolumny, których wysokość wynosiła trzydzieści pięć łokci, a głowice na ich szczytach miały po pięć łokci.
###### **2Krn 3,16**
 Wyrzeźbił ponadto girlandy i umieścił je na kolumnach. Wykonał również sto owoców granatu i umieścił je w owych girlandach.
###### **2Krn 3,17**
 Kolumny te ustawił przed Świątynią: jedną z prawej, a drugą z lewej strony; prawą [kolumnę] nazwał Jakin, a lewą Boaz.
# 2Krn 3 BR
###### **2Krn 3,1**
 I zaczął Salomon budowę świątyni Jahwe w Jerozolimie, na górze Moria, wskazanej Dawidowi, jego ojcu, na tym miejscu, które Dawid już pod budowę przygotował, tam gdzie znajdowało się kiedyś klepisko Jebusyty Ornana.
###### **2Krn 3,2**
 Budowę rozpoczęto drugiego dnia drugiego miesiąca w czwartym roku panowania króla Salomona.
###### **2Krn 3,3**
 A oto wymiary fundamentów, które położył Salomon pod budowę świątyni Bożej. Długość - licząc według starych łokci - wynosiła sześćdziesiąt łokci, szerokość zaś dwadzieścia łokci.
###### **2Krn 3,4**
 Przedsionek, znajdujący się przed świątynią na całej jej szerokości, był długi na dwadzieścia łokci, a jego wysokość wynosiła sto dwadzieścia łokci. Od strony wewnętrznej cały przedsionek został przez Salomona wyłożony czystym złotem.
###### **2Krn 3,5**
 Główne pomieszczenie wyłożył on drewnem cyprysowym i szczerym złotem oraz pokrył płaskorzeźbami, przedstawiającymi palmy i łańcuchy.
###### **2Krn 3,6**
 Przyozdobił świątynię drogimi kamieniami, a złoto, którego używał, pochodziło z Parawaim.
###### **2Krn 3,7**
 Wyłożył złotem świątynię, to znaczy belki, progi, ściany i odrzwia, a na ścianach kazał wyrzeźbić cheruby.
###### **2Krn 3,8**
 Zbudowano także Święte Świętych, którego długość, odpowiadająca szerokości świątyni, wynosiła dwadzieścia łokci, a szerokość też dwadzieścia łokci. Pokrył je całe czystym złotem, którego zużyto na ten cel sześćset talentów,
###### **2Krn 3,9**
 na gwoździe zaś wyszło pięćdziesiąt sykli złota. Górne pomieszczenia również wyłożył złotem.
###### **2Krn 3,10**
 W Świętym Świętych ustawiono dwa rzeźbione cheruby, również całe pokryte złotem.
###### **2Krn 3,11**
 Rozpostarte skrzydła cherubów były długie na dwadzieścia łokci. Jedno skrzydło (pierwszego) cheruba, długie na pięć łokci, dotykało ściany świątyni, a drugie, o długości również pięciu łokci, stykało się ze skrzydłem drugiego cheruba.
###### **2Krn 3,12**
 Jedno skrzydło drugiego cheruba, długie na pięć łokci, dotykało ściany świątyni, drugie zaś, długości również pięciu łokci, stykało się ze skrzydłem pierwszego cheruba.
###### **2Krn 3,13**
 Rozpostarte obydwa skrzydła miały dwadzieścia łokci długości. Cheruby były przedstawione w postaci stojącej, twarzami zaś były zwrócone w stronę świątyni.
###### **2Krn 3,14**
 Kazał też Salomon wykonać zasłonę z purpury fioletowej, z purpury szkarłatnej, z karmazynu i z bisioru. Na zasłonie polecił wyszyć cheruby.
###### **2Krn 3,15**
 Przed świątynią ustawił dwie kolumny wysokie na trzydzieści pięć łokci, głowice zaś znajdujące się na szczytach kolumn, miały po pięć łokci wysokości.
###### **2Krn 3,16**
 Wyrzeźbiono również jakby wieńce na kształt łańcuchów, które oplatały głowice kolumn, a w poszczególnych ogniwach łańcuchów umieszczono sto wyrzeźbionych owoców granatu.
###### **2Krn 3,17**
 Kolumny ustawiono przed świątynią, jedną z prawej, a drugą z lewej strony. Ta z lewej otrzymała imię Jakin, ta z prawej - Boaz
# 2Krn 3 WUJ
###### **2Krn 3,1**
 I począł Salomon budować dom Pański w Jeruzalem na górze Moria, która była ukazana Dawidowi ojcu jego, na miejscu, które zgotował Dawid na bojowisku
###### **2Krn 3,2**
 A począł budować miesiąca wtórego, roku czwartego królestwa swego.
###### **2Krn 3,3**
 I te są fundamenty, które założył Salomon, aby zbudował dom Boży, wzdłuż na sześćdziesiąt łokiet miary pierwszej, w szerz dwadzieścia łokiet.
###### **2Krn 3,4**
 A sień na przodku, która się rozciągała w zdłuż według miary szerokości domu, na dwadzieścia łokiet: a wysokość była sto dwadzieścia łokiet: i ozłocił ji we wnątrz szczerem złotem.
###### **2Krn 3,5**
 Dom też więtszy okrył tablicami drzewianemi jodłowemi, i blachy złota szczerego przybił po wszystkiem: a na nim wyrył palmy i jakoby łańcuszki jeden z drugim poplecione.
###### **2Krn 3,6**
 Położył też tło kościelne kosztownym marmurem, ozdobą wielką.
###### **2Krn 3,7**
 A złoto było naprzedniejsze, z którego blachami pobił dom, i bramy jego, i podwoje, i ściany, i drzwi: i wyrył Cherubimy na ścianach.
###### **2Krn 3,8**
 Sprawił też dom świętego świętych: wzdłuż według szerokości domu na dwadzieścia łokiet, i szerz także na dwadzieścia łokiet, i okrył ji blachami złotemi, około sześci set talentów.
###### **2Krn 3,9**
 Ale i gwoździe złote poczynił, tak, że każdy gwóźdź ważył po pięćdziesiąt syklów: Sale też złotem powlekł.
###### **2Krn 3,10**
 Sprawił też w domu świętego świętych dwa Cherubim robotą sznicarską, i okrył je złotem.
###### **2Krn 3,11**
 Skrzydła Cherubim na dwadzieścia łokiet się rozciągały, tak, iż jedno skrzydło miało pięć łokiet, i dosięgało ściany domu: i drugie mając pięć łokiet, dosięgało skrzydła Cherub drugiego.
###### **2Krn 3,12**
 Także skrzydło Cherub drugiego pięć łokiet miało i dosięgało ściany: a skrzydło jego drugie na piąci łokci dosięgało skrzydła Cherub drugiego.
###### **2Krn 3,13**
 I tak skrzydła obu Cherubim rozszerzone były, i rzociągały się na dwadzieścia łokiet: a sami stali prosto na nogach, i twarzy ich ku zewnętrznemu domowi były obrócone.
###### **2Krn 3,14**
 Sprawił też zasłonę z hiacynthu, z szarłatu, karmazynu i bisioru, i wyhaftował na niej Cherubim.
###### **2Krn 3,15**
 Przede drzwiami też kościelnemi dwa słupy, które trzydzieści i pięć łokiet miały w zwyż, a Capitella ich na piąci łokiet.
###### **2Krn 3,16**
 Ktemu i jakoby łańcuszki w wyrocznicy, i włożył je na Capitella słupów: malogranatów też sto: które wprawił między łańcuszki.
###### **2Krn 3,17**
 Same też słupy postawił w sieni kościoła, jeden po prawej, a drugi po lewej stronie: ten, który był po prawej stronie nazwał Jachin, a który po lewej, Booz.
