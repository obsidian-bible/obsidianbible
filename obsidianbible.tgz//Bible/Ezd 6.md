# Ezd 6 BT5
###### **Ezd 6,1**
 Wtedy król Dariusz kazał szukać w babilońskiej bibliotece, w której przechowuje się też skarby.
###### **Ezd 6,2**
 I znaleziono w Ekbatanie, twierdzy w prowincji Medii, pewien zwój, w którym tak było napisane: «***Zapisek historyczny:***
###### **Ezd 6,3**
 ***W roku pierwszym [panowania] króla Cyrusa tenże król wydał taki rozkaz: Sprawa domu Bożego w Jerozolimie: Dom ten ma być odbudowany jako miejsce dla składających Bogu żertwy krwawe i ofiary spalane. Długość jego – sześćdziesiąt łokci, szerokość jego – dwadzieścia łokci, wysokość jego – trzydzieści łokci;***
###### **Ezd 6,4**
 ***układów z kamienia ciosowego – trzy, i z drewna – układ jeden. Koszty będą pokryte ze skarbu królewskiego.***
###### **Ezd 6,5**
 ***Również złote i srebrne sprzęty domu Bożego, które Nabuchodonozor zabrał ze świątyni w Jerozolimie i przeniósł do Babilonu, zwróci się, tak że one powrócą na dawne miejsce do świątyni w Jerozolimie i będą złożone w domu Bożym***».
###### **Ezd 6,6**
 «***Zatem Tattenaju, namiestniku Transeufratei, Sztarboznaju, wraz z waszymi towarzyszami perskimi w Transeufratei – trzymajcie się z dala od tego miejsca!***
###### **Ezd 6,7**
 ***Pozwólcie namiestnikowi Żydów i starszyźnie żydowskiej pracować nad tym domem Bożym. Niech odbudują ten dom Boży na dawnym miejscu.***
###### **Ezd 6,8**
 ***Wydaję rozporządzenie, jak macie się odnosić do owej starszyzny żydowskiej przy budowie tego domu Bożego, mianowicie: z dochodów królewskich, płynących z podatku Transeufratei, dokładnie i bez przerwy mają być owym mężom wypłacane koszty.***
###### **Ezd 6,9**
 ***A jeśli potrzeba też cielców, baranów i jagniąt na całopalenia dla Boga niebios – oprócz pszenicy, soli, wina i oliwy – według żądania kapłanów w Jerozolimie, ma im to być bez uchybień co dzień dostarczane,***
###### **Ezd 6,10**
 ***aby oni składali ofiary miłe Bogu niebios i modlili się za życie króla i jego synów.***
###### **Ezd 6,11**
 ***I wydaję rozporządzenie: Jeśli ktoś przekroczy ten rozkaz, to z domu jego wyrwana będzie belka, a on zawiśnie do niej przybity, dom zaś jego z tego powodu będzie zamieniony w rumowisko.***
###### **Ezd 6,12**
 ***A Bóg, który tam zgotował przybytek dla imienia swego, niech zniszczy każdego króla i naród, który by się ośmielił przeciwdziałać, burząc ten dom Boży w Jerozolimie. Ja, Dariusz, wydałem ten rozkaz: niech będzie on dokładnie wykonany***».
###### **Ezd 6,13**
 Wtedy dokładnie tak, jak zarządził król Dariusz, postąpili Tattenaj, namiestnik Transeufratei, Sztarboznaj i ich towarzysze.
###### **Ezd 6,14**
 A starszyzna żydowska budowała z powodzeniem dzięki proroctwu Aggeusza, proroka, i Zachariasza, syna Iddo, i doprowadzili budowę do skutku, zgodnie z rozkazem Boga Izraela i z rozporządzeniem Cyrusa i Dariusza oraz Artakserksesa, króla perskiego.
###### **Ezd 6,15**
 I dom ten był gotowy na dwudziesty trzeci dzień miesiąca Adar – był to rok szósty panowania króla Dariusza.
###### **Ezd 6,16**
 I Izraelici: kapłani, lewici i reszta wysiedleńców radośnie obchodzili poświęcenie tego domu Bożego.
###### **Ezd 6,17**
 I na poświęcenie tego domu Bożego ofiarowali: sto cielców, dwieście baranów, czterysta jagniąt, a jako ofiarę przebłagalną za całego Izraela – dwanaście kozłów według liczby pokoleń izraelskich.
###### **Ezd 6,18**
 I do służby Bożej w Jerozolimie ustanowili kapłanów według ich oddziałów, a lewitów według ich grup, zgodnie z przepisem księgi Mojżeszowej.
###### **Ezd 6,19**
 Czternastego dnia miesiąca pierwszego wysiedleńcy obchodzili Paschę.
###### **Ezd 6,20**
 Lewici bowiem jak jeden mąż oczyścili się; wszyscy oni byli teraz czyści i zabili [baranki na] Paschę dla wszystkich wysiedleńców, dla braci swoich, kapłanów, i dla siebie.
###### **Ezd 6,21**
 I spożyli paschę Izraelici, którzy wrócili z wygnania, oraz wszyscy, którzy od nieczystości narodów tego kraju odwrócili się ku nim, by szukać Pana, Boga Izraela.
###### **Ezd 6,22**
 I przez siedem dni radośnie obchodzili Święto Przaśników, gdyż Pan rozradował ich, zwracając serce króla Aszszuru ku nim, by ich wspierał przy pracy około domu Boga, Boga Izraela.
# Ezd 6 PAU
###### **Ezd 6,1**
 Wówczas król Dariusz polecił szukać w archiwach Babilonu, gdzie składano również skarby,
###### **Ezd 6,2**
 i znaleziono w Ekbatanie, twierdzy w prowincji Medii, pewien zwój zawierający zapisek historyczny:
###### **Ezd 6,3**
 „W pierwszym roku panowania króla Cyrusa. Polecenie wydane przez króla Cyrusa w sprawie domu Bożego w Jerozolimie: Niech będzie odbudowany dom, w którym będą składane krwawe ofiary. Należy zachować jego poprzednie fundamenty. Rozmiary domu mają być następujące: wysokość - sześćdziesiąt łokci, szerokość - sześćdziesiąt łokci.
###### **Ezd 6,4**
 Mur niech będzie z trzech warstw kamienia ciosanego i jednej warstwy okładziny z drewna. Koszty niech będą pokryte ze skarbca królewskiego.
###### **Ezd 6,5**
 Ponadto złote i srebrne naczynia, które Nabuchodonozor zabrał ze świątyni w Jerozolimie i przyniósł do Babilonu, niech będą zwrócone i niech powrócą do świątyni w Jerozolimie, na swoje dawne miejsce w domu Bożym, gdzie też zostaną złożone”.
###### **Ezd 6,6**
 „Dlatego ty, Tattenaju, namiestniku prowincji Transeufratei, i ty, Szetar-Boznaju, i wy, urzędnicy perscy za Eufratem, nie mieszajcie się do tej sprawy!
###### **Ezd 6,7**
 Pozostawcie w spokoju prace nad tym domem Bożym. Niech namiestnik Żydów i ich starszyzna odbudowują dom Boży na dawnym miejscu.
###### **Ezd 6,8**
 Wydaję następujące rozporządzenie dotyczące waszego postępowania ze starszyzną żydowską w kwestii budowy tego domu Bożego: Będziecie owym ludziom bez zwłoki i dokładnie wypłacać z dochodów królewskich płynących z podatków pobieranych za Eufratem, aby nie mieli trudności z budową.
###### **Ezd 6,9**
 Jeżeli będzie potrzeba cielców, baranów i jagniąt na całopalenia dla Boga niebios - nie licząc pszenicy, soli, wina i oliwy - mają być dostarczone codziennie i bez zwłoki według rozporządzeń kapłanów w Jerozolimie,
###### **Ezd 6,10**
 aby składali ofiary miłe Bogu niebios i modlili się za życie króla i jego synów.
###### **Ezd 6,11**
 Rozkazuję też, aby każdemu, kto złamie to zarządzenie, wyrwano belkę z jego domu i do niej go przybito. A jego dom niech będzie zamieniony w ruinę.
###### **Ezd 6,12**
 Bóg, który uczynił tam mieszkanie dla swego imienia, niech strąci każdego króla i naród, który ośmieliłby się wyciągnąć rękę, aby przekroczyć zarządzenie dotyczące budowy domu Bożego w Jerozolimie. Ja, Dariusz, wydałem to zarządzenie. Należy je dokładnie wykonać!”.
###### **Ezd 6,13**
 Po otrzymaniu pisma wysłanego przez króla Dariusza, Tattenaj, namiestnik prowincji Transeufratei, Szetar-Boznaj i ich urzędnicy postąpili zgodnie z jego treścią i wykonali dokładnie jego zarządzenie.
###### **Ezd 6,14**
 Starszyzna żydowska prowadziła więc prace dalej i budowa posuwała się naprzód, tak jak przepowiadali prorocy Aggeusz i Zachariasz, syn Iddo. Doprowadzono ją do końca zgodnie z poleceniem Boga Izraela i z zarządzeniem Dariusza i Artakerksesa, królów perskich.
###### **Ezd 6,15**
 Zakończono budowę tego domu w trzecim dniu miesiąca Adar, w szóstym roku panowania króla Dariusza.
###### **Ezd 6,16**
 Wówczas wszyscy Izraelici, to znaczy kapłani, lewici i pozostali repatrianci, z radością dokonali poświęcenia domu Bożego.
###### **Ezd 6,17**
 Przy poświęceniu domu Bożego złożyli ofiary ze stu cielców, dwustu baranów i czterystu jagniąt oraz dwunastu kozłów jako ofiarę przebłagalną za dwanaście plemion Izraela.
###### **Ezd 6,18**
 Ustanowili także grupy kapłanów i zastępy lewitów do służby Bożej w Jerozolimie według przepisów księgi Mojżesza.
###### **Ezd 6,19**
 Repatrianci obchodzili Paschę czternastego dnia pierwszego miesiąca,
###### **Ezd 6,20**
 gdyż wszyscy kapłani i lewici się oczyścili. Wszyscy, którzy byli czyści, złożyli ofiarę paschalną za repatriantów, za swych braci kapłanów i za siebie samych.
###### **Ezd 6,21**
 Paschę spożywali zarówno Izraelici, którzy powrócili z niewoli, jak też i inni, którzy odwrócili się od nieczystości pogan tej ziemi i przyłączyli się do nich, aby szukać PANA, Boga Izraela.
###### **Ezd 6,22**
 Przez siedem dni obchodzili radośnie Święto Przaśników, gdyż PAN napełnił ich radością, usposabiając ku nim życzliwie serce króla Assuru, aby wspomógł ich przy budowie domu Bożego dla Boga Izraela.
# Ezd 6 BP
###### **Ezd 6,1**
 Szukano więc na rozkaz króla Dariusza w domu archiwów, gdzie w Babilonie przechowywano też skarby,
###### **Ezd 6,2**
 i znaleziono w twierdzy Ekbatana, w prowincji Medii, zwój, na którym było napisane, co następuje: "Ku pamięci!
###### **Ezd 6,3**
 W pierwszym roku panowania króla Cyrusa wydał on taki rozkaz w sprawie Domu Boga w Jeruzalem. Dom ten należy odbudować, aby był miejscem, na którym się składa ofiary całopalne. Fundamenty jego mają być zachowane. Jego wysokość ma wynosić sześćdziesiąt łokci, a jego szerokość [także] sześćdziesiąt łokci.
###### **Ezd 6,4**
 Trzy warstwy bloków kamiennych i jedna warstwa drzewa [mają być nałożone]. Koszty ma pokryć pałac królewski.
###### **Ezd 6,5**
 Należy ponadto zwrócić złote i srebrne sprzęty z Domu Bożego, które Nebukadnezar zabrał ze Świątyni w Jeruzalem i zawiózł do Babilonu. Mają one być przywiezione z powrotem na dawne miejsce do Świątyni w Jeruzalem. Należy je złożyć w Domu Boga".
###### **Ezd 6,6**
 "Tak więc Tattenaju, zarządco kraju za Eufratem, Szetar-Boznaju i wy, ich towarzysze, niżsi urzędnicy kraju za Eufratem, trzymajcie się z dala od tych spraw czy tego miejsca.
###### **Ezd 6,7**
 Zostawcie wolną rękę namiestnikowi i starszyźnie Judejczyków w robotach przy tej Świątyni Boga. Powinni oni odbudować tę Świątynię Boga na jej [dawnym] miejscu.
###### **Ezd 6,8**
 Oto mój rozkaz dotyczący tego, co macie uczynić dla starszyzny Judejczyków przy budowie Świątyni Boga: Koszty należy dokładnie i bezzwłocznie zwrócić tym mężom, [czerpiąc je] z podatków [wypłacanych] w posiadłościach królewskich z kraju za Eufratem.
###### **Ezd 6,9**
 Także i to, co będzie potrzeba na ofiarę całopalną dla Boga niebios: młode woły, barany i owce, oraz pszenicę, sól, wino i oliwę, należy dawać im natychmiast każdego dnia odpowiednio do życzeń kapłanów w Jeruzalem,
###### **Ezd 6,10**
 aby składali wonne ofiary Bogu niebios i aby się modlili za życie króla i jego synów.
###### **Ezd 6,11**
 Wydaję zatem następujące zarządzenie: każdemu, kto przekroczy ten rozkaz, ma być wyrwana belka z jego domu, on zaś sam przybity do niej i powieszony. Dom zaś jego należy za to [przestępstwo] zamienić w rumowisko.
###### **Ezd 6,12**
 Bóg zaś, który pozwala, by Imię jego tam królowało, niech strąci tego króla i ten naród, który by się odważył przekroczyć ten rozkaz i zburzyć tę Świątynię Boga w Jeruzalem. Ja, Dariusz, wydałem ten rozkaz i ma on być jak najdokładniej wykonany."
###### **Ezd 6,13**
 Tattenaj, władca kraju za Eufratem, Szetar-Boznaj i ich towarzysze postępowali teraz dokładnie według poleceń, jakie im przekazał król Dariusz.
###### **Ezd 6,14**
 Starszyzna Judejczyków podjęła zatem z powodzeniem budowę, [zachęcana] przepowiedniami proroka Aggeusza i Zachariasza, syna Iddy. Doprowadzili budowę do końca zgodnie z rozkazem Boga Izraela i według nakazu Cyrusa i Dariusza (oraz Artakserksesa, króla Persji).
###### **Ezd 6,15**
 W trzecim dniu miesiąca Adar, to jest w szóstym roku panowania króla Dariusza, Świątynia została ukończona.
###### **Ezd 6,16**
 Pełni radości święcili Izraelici, kapłani, lewici i reszta przybyszów z wygnania uroczystość poświęcenia tej Świątyni Boga.
###### **Ezd 6,17**
 Ofiarowali oni na poświęcenie Domu Bożego sto cielców, dwieście baranów, czterysta jagniąt, ponadto jako ofiarę za grzechy całego Izraela dwanaście kozłów odpowiednio do liczby pokoleń izraelskich.
###### **Ezd 6,18**
 Wyznaczyli na służbę Boga w Jeruzalem kapłanów według ich klas i lewitów według ich podziałów, jak to było zapisane w Księdze Mojżesza.
###### **Ezd 6,19**
 Czternastego dnia pierwszego miesiąca święcili przybysze z wygnania Paschę.
###### **Ezd 6,20**
 Wszyscy kapłani bowiem i lewici oczyścili się. Wszyscy byli więc czyści i ofiarowali baranka paschalnego dla wszystkich tych, którzy powrócili z wygnania, a także dla swoich braci, kapłanów, i dla siebie samych.
###### **Ezd 6,21**
 Tak pożywali Paschę ci Izraelici, którzy wrócili z wygnania, a także wszyscy ci, którzy zerwali z nieczystością ludności tego kraju i [przyłączyli się] do nich, aby szukać Jahwe, Boga izraelskiego.
###### **Ezd 6,22**
 Przez siedem dni obchodzili w radości Uroczystość Przaśników. Jahwe bowiem napełnił ich radością, nakłaniając ku nim serce króla asyryjskiego, by ich wspomagał przy pracach wokół Świątyni Boga, Boga Izraela.
# Ezd 6 BR
###### **Ezd 6,1**
 Wydał tedy król Dariusz polecenie, żeby przeszukano pomieszczenia, w których znajdowały się skarbce babilońskie.
###### **Ezd 6,2**
 I znaleziono w Ekbatanie, to jest w twierdzy położonej w prowincji Medii, zwój, na którym były zapisane takie oto słowa: Zapis dla pamięci.
###### **Ezd 6,3**
 W pierwszym roku swego panowania król Cyrus wydał następujące zarządzenie: Świątynia Pańska, [której ślady znajdują się] w Jerozolimie, niech zostanie odbudowana i niech stanie się miejscem, na którym będą składane ofiary krwawe i ofiary całopalne. Niech położą mocne fundamenty, a sama świątynia niech ma sześćdziesiąt łokci wysokości i sześćdziesiąt łokci szerokości.
###### **Ezd 6,4**
 Niech na każde trzy warstwy ciosanego kamienia kładą jedną warstwę drewna. Wszystkie wydatki pokryje pałac królewski.
###### **Ezd 6,5**
 Należy również zwrócić wszystkie przedmioty złote i srebrne, zabrane ze świątyni jerozolimskiej przez Nabuchodonozora. Wszystkie mają być dostarczone z powrotem do Jerozolimy, czyli tam, gdzie się kiedyś znajdowały, i złożone w świątyni pańskiej.
###### **Ezd 6,6**
 Tak więc teraz zarówno ty, Tattenaju, zarządco krainy położonej za Rzeką, jak i ty, Sztarboznaju, razem z twoimi współpracownikami na różnych urzędach w kraju położonym za Rzeką,
###### **Ezd 6,7**
 zostawcie ich w spokoju! Niech bez przeszkód budują dalej świątynie dla swego Boga. Niech namiestnik Żydów i cała starszyzna żydowska odbudowują świątynię Bożą na jej dawnym miejscu.
###### **Ezd 6,8**
 A oto polecenie, jakie wam wydaję, byście skutecznie współdziałali ze starszyzną żydowską przy odbudowie świątyni Pańskiej. Z zasobów królewskich, dokładniej zaś z podatków pobieranych od ludności mieszkającej w kraju za Rzeką, będziecie opłacać wszystkich robotników, tak żeby nie było żadnych przerw w pracy.
###### **Ezd 6,9**
 Wszystko, co będzie potrzebne do składania ofiar całopalenia na cześć Boga Zastępów niebieskich, jak cielce, barany i jagnięta, zboże, sól, wino i oliwa - wszystko to, według zapotrzebowania kapłanów jerozolimskich, niech będzie dostarczane każdego dnia bez żadnych przerw,
###### **Ezd 6,10**
 tak aby mogły być składane ofiary jako woń miła Bogu Zastępów niebieskich i aby się modlono o dobre życie dla króla i jego synów.
###### **Ezd 6,11**
 Ponadto zarządzam: Jeżeli ktoś nie wypełni moich zaleceń, niech go przybiją do belki wyrwanej ze [stropu] jego własnego domu, cały zaś jego dom niech zostanie zamieniony w rumowisko.
###### **Ezd 6,12**
 A Bóg, który zechciał, aby tam zamieszkało Jego imię, zrzuci z tronu każdego władcę i unicestwi każdy lud, który odważyłby się zmienić cokolwiek w tym dekrecie albo ośmieliłby się wyciągnąć rękę, aby zniszczyć tę świątynię Bożą w Jerozolimie. Taki rozkaz wydałem ja, Dariusz, i ma on być jak najściślej wykonany.
###### **Ezd 6,13**
 Tattenaj, zarządca krainy położonej za Rzeką, oraz Sztarboznaj i ich współpracownicy postąpili dokładnie tak, jak im nakazał król Dariusz.
###### **Ezd 6,14**
 Starsi żydowscy zabrali się tedy znów do budowy, czyniąc w swych pracach bardzo wyraźne postępy. Wspomagali ich swoim prorokowaniem prorocy Aggeusz i Zachariasz, syn Iddo. Prowadzili budowę i ukończyli ją zgodnie z wolą Boga Izraela i według rozkazów Cyrusa, Dariusza i Artakserksesa, królów perskich.
###### **Ezd 6,15**
 Zakończyli wszelkie prace przy odbudowie świątyni trzeciego dnia miesiąca Adar, w szóstym roku panowania króla Dariusza.
###### **Ezd 6,16**
 Synowie Izraela, kapłani i lewici oraz wszyscy, którzy jeszcze żyli spośród dawnych wygnańców, z radością obchodzili dzień poświęcenia domu Pańskiego.
###### **Ezd 6,17**
 W dniu poświęcenia świątyni Jahwe złożono na ofiarę sto cielców, dwieście baranów, czterysta jagniąt, a na ofiarę za grzechy całego Izraela - dwanaście kozłów, po jednym na każde z dwunastu pokoleń Izraela.
###### **Ezd 6,18**
 Wyznaczono także kapłanów według odpowiednich podziałów oraz lewitów według ich klas, żeby służyli Bogu, który jest w Jerozolimie, zgodnie z tym, co jest napisane w księdze Mojżesza.
###### **Ezd 6,19**
 Czternastego dnia pierwszego miesiąca ci, którzy wrócili z niewoli, obchodzili święto paschy.
###### **Ezd 6,20**
 Kapłani bowiem i lewici oczyścili się już wszyscy bez wyjątku. Wszyscy byli czyści. Przygotowali oni paschę dla wszystkich, którzy powrócili z wygnania, dla swoich braci kapłanów i dla siebie samych.
###### **Ezd 6,21**
 I tak wszyscy synowie Izraela, którzy powrócili z wygnania, mogli spożyć paschę. Podobnie [spożywali baranka paschalnego] wszyscy, którzy wyrzekli się nieczystości ludów pogańskich mieszkających w tym kraju i przyłączyli się do reszty [synów Izraela], aby wspólnie szukać Jahwe, Boga Izraela.
###### **Ezd 6,22**
 Przez siedem dni obchodzili z radością święto Przaśników. Radością bowiem napełnił wszystkich Jahwe składając ku nim serce króla asyryjskiego, który zechciał im przyjść z pomocą w dziele budowy świątyni Boga, Boga Izraela.
# Ezd 6 WUJ
###### **Ezd 6,1**
 Daryusz tedy król rozkazał i szukali w Bibliotece ksiąg, które były chowane w Babilonie.
###### **Ezd 6,2**
 I naleziono w Ekbatanie, który jest zamek w Medeńskiej krainie księgi jedne, i taka pamięć była w nich napisana.
###### **Ezd 6,3**
 Roku pierwszego Cyrusa króla: Cyrus król dał wyrok, aby dom Boży był zbudowan, który jest w Jeruzalem, na miejscu gdzieby ofiary ofiarowano, ażeby założyli grunty, któreby znosiły wyż sześćdziesiąt łokiet, a szerz, sześćdziesiąt łokiet,
###### **Ezd 6,4**
 Trzy rzędy z kamieni nieciosanych, i takież rzędy z drzewa nowego. A nakłady z domu królewskiego dane będą.
###### **Ezd 6,5**
 Ale i naczynia Kościoła Bożego złote i srebrne, które był Nabuchodonozor wyniósł z Kościoła Jerozolimskiego, a zaniósł je był do Babilonu, niech wrócone będą, i odniesione do Kościoła do Jeruzalem na miejsce swoje, które też położone są w kościele Bożym.
###### **Ezd 6,6**
 Teraz tedy Thathanai książę krainy, które jest za rzeką Stharbuzanai, i rajcę waszy Apharsacheowie, którzyście za rzeką, odstąpcie od nich daleko,
###### **Ezd 6,7**
 A dopuście, żeby był budowan kościół tam ten Boży od Książęcia Żydów i od starszych ich, aby dom Boży tam ten zbudowali na swem miejscu.
###### **Ezd 6,8**
 Alem i ja rozkazał, coby mieli czynić tam ci starszy żydowscy, aby był zbudowan dom Boży to jest, aby z skrzynie królewskiej to jest z poborów, które dawają z krainy za rzeką, pilnie nakłady dawano tym mężom, aby się robocie nie przeszkadzało.
###### **Ezd 6,9**
 A będzieli potrzeba, i cielce i jagnięta i koźlęta na całopalenie Bogu niebieskiemu, zboże, sól, wino, i oliwę, według porządku kapłanów, którzy są w Jeruzalem, niech im dawaj ą na każdy dzień, aby w czem skarga nie była.
###### **Ezd 6,10**
 A niechaj ofiarują ofiary Bogu niebieskiemu, i niech proszą za zdrowie królewskie i synów jego.
###### **Ezd 6,11**
 Odemnie tedy dekret jest uczyniony. Aby każdy człowiek, któryby odmienił to rozkazanie, było wzięto drzewo z domu jego, i było wystawione, i był przybit na nim, a dom jego, aby był pospolity.
###### **Ezd 6,12**
 A Bóg, który chciał, aby tam mieszkało imię swoje, niech rozproszy wszystkie królestwa i lud, któryby ściągnął rękę swoję, aby się sprzeciwił, a rozwalił ten tam dom Boży, który jest w Jeruzalem. Ja Daryusz postanowiłem wyrok, który chcę, aby się z pilnością wypełnił.
###### **Ezd 6,13**
 Thathanaj tedy książę krainy za rzeką, i Stharbuzanaj, i rada jego, wedle tego jako był rozkazał Daryusz król, z pilnością tak wykonali.
###### **Ezd 6,14**
 A starszy żydowscy budowali, i powodziło się im według proroctwa Aggeusza proroka, i Zacharyasza syna Addo: i budowali i wystawili, za rozkazaniem Boga Izraelowego, i za rozkazaniem Cyrusa, i Daryusza, i Artaxerxa królów Perskich.
###### **Ezd 6,15**
 I dokonali tego domu Bożego aż do trzeciego dnia miesiąca Adar, który jest rok szósty królestwa Daryusza króla.
###### **Ezd 6,16**
 I uczynili synowie Izraelowi kapłani i Lewitowie, i inni z synów przeprowadzenia poświęcanie domu Bożego z radością.
###### **Ezd 6,17**
 I ofiarowali na poświęcenie domu Bożego cielców sto, baranów dwieście, baranków czterzysta, kozłów od kóz za grzech wszystkiego Izraela dwanaście, według liczby pokoleni Izraelskich.
###### **Ezd 6,18**
 I postanowili kapłany w rzędziech ich, i Lewity w przemianach swoich nad służbą Bożą w Jeruzalem, jako napisano w księgach Mojżeszowych.
###### **Ezd 6,19**
 I uczynili synowie Izraelscy przeprowadzenia Paschę czternastego dnia księżyca pierwszego.
###### **Ezd 6,20**
 Bo się byli oczyścili kapłani i Lewitowie jako jeden: wszyscy czyści na ofiarowanie Paschy wszystkim synom przeprowadzenia, i braciej swej kapłanom, i sobie.
###### **Ezd 6,21**
 I jedli synowie Izraelscy, którzy się byli wrócili z przeprowadzenia, i wszyscy, którzy się byli odłączyli od plugastwa narodów ziemskich ku nim, żeby szukali Pana Boga Izraelskiego.
###### **Ezd 6,22**
 I uczynili święto przaśników przez siedm dni z weselem, bo je był uweselił Pan, i obrócił był serce króla Assur ku nim, aby pomagał rękom ich w budowaniu domu Pana Boga Izraelowego.
