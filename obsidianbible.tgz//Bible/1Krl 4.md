# 1Krl 4 BT5
###### **1Krl 4,1**
 Król Salomon był królem nad całym Izraelem.
###### **1Krl 4,2**
 A oto jego dostojnicy na najwyższych urzędach: Azariasz, syn Sadoka, kapłan.
###### **1Krl 4,3**
 Elichoref i Achiasz, synowie Sziszy, pisarze; Joszafat, syn Achiluda, pełnomocnik.
###### **1Krl 4,4**
 Benajasz, syn Jojady, wódz wojska; Sadok oraz Abiatar, kapłani.
###### **1Krl 4,5**
 Azariasz, syn Natana, przełożony rządców, i Zabud, syn kapłana Natana, zaufany króla.
###### **1Krl 4,6**
 Achiszar, zarządca pałacu, i Adoniram, syn Abdy, nadzorca robotników pracujących przymusowo.
###### **1Krl 4,7**
 Ponadto Salomon miał nad całym Izraelem dwunastu rządców zaopatrujących w żywność króla i jego dwór. Każdy z nich miał dostarczać żywność przez miesiąc w roku.
###### **1Krl 4,8**
 A oto ich imiona: Ben-Chur na górze Efraima.
###### **1Krl 4,9**
 Ben-Deker w Makas, Szaalbim, Bet-Szemesz, Elon, Bet-Chanan.
###### **1Krl 4,10**
 Ben-Chesed w Arubot, do którego należało Soko i cała ziemia Chefer.
###### **1Krl 4,11**
 Ben-Abinadab miał wszystkie wzgórza koło Dor, a za żonę miał Tafat, córkę Salomona.
###### **1Krl 4,12**
 Baana, syn Achiluda – Tanak, Megiddo aż poza Jokmeam i całe Bet-Szean za Jizreel aż do Abel-Mechola koło Sartany.
###### **1Krl 4,13**
 Ben-Geber w Ramot w Gileadzie miał Osiedla Jaira, syna Manassesa; w Gileadzie miał również obszar Argob w Baszanie, obejmujący sześćdziesiąt dużych miast obmurowanych, o brązowych zaworach u bram.
###### **1Krl 4,14**
 Achinadab, syn Iddo – Machanaim.
###### **1Krl 4,15**
 Achimaas – u Neftalego; on również wziął za żonę córkę Salomona, Basmat.
###### **1Krl 4,16**
 Baana, syn Chuszaja – u Asera, łącznie ze wzgórzami.
###### **1Krl 4,17**
 Joszafat, syn Paruacha, u Issachara.
###### **1Krl 4,18**
 Szimei, syn Eli, u Beniamina.
###### **1Krl 4,19**
 Geber, syn Uriego, w kraju Gilead – ziemię Sichona, króla amoryckiego, i Oga, króla Baszanu. I był jeden rządcą w kraju.
###### **1Krl 4,20**
 Juda oraz Izrael byli liczni jak piasek nadmorski. Jedli, pili i weselili się.
# 1Krl 4 PAU
###### **1Krl 4,1**
 Król Salomon był władcą całego Izraela.
###### **1Krl 4,2**
 Oto jego najwyżsi urzędnicy: Azariasz, syn Sadoka, był kapłanem.
###### **1Krl 4,3**
 Elichoref i Achiasz, synowie Sziszy, byli sekretarzami, a Joszafat, syn Achiluda, był kanclerzem.
###### **1Krl 4,4**
 Benajasz, syn Jojady, był dowódcą armii, natomiast Sadok i Abiatar byli kapłanami.
###### **1Krl 4,5**
 Azariasz, syn Natana, był zwierzchnikiem zarządców prowincji, a Zabud, syn kapłana Natana, był przyjacielem króla.
###### **1Krl 4,6**
 Achiszar kierował administracją pałacu, natomiast Adoniram, syn Abdy, był administratorem robót publicznych.
###### **1Krl 4,7**
 Ponadto Salomon ustanowił dwunastu zarządców prowincji nad całym Izraelem, aby zaopatrywali króla i jego dwór w żywność. Każdy z nich miał dostarczać żywność przez jeden miesiąc w roku.
###### **1Krl 4,8**
 Oto ich imiona: Ben-Chur na górzystym obszarze Efraima.
###### **1Krl 4,9**
 Ben-Deker w Makas, Szaalbim, Bet-Szemesz, Elon, Bet-Chanan.
###### **1Krl 4,10**
 Ben-Chesed w Arubot. Podlegało mu również Soko i cała ziemia Chefer.
###### **1Krl 4,11**
 Ben-Abinadab miał obszar wokół Dor. Jego żoną była Tafat, córka Salomona.
###### **1Krl 4,12**
 Baana, syn Achiluda, zarządzał Tanak i Megiddo oraz całym Bet-Szean poniżej Jezreel i od Bet-Szean do Abel-Mechola aż poza Jokmeam, leżącym koło Sartany.
###### **1Krl 4,13**
 Ben-Geber w Ramot w Gileadzie posiadał osiedla Jaira, syna Manassesa, położone w Gileadzie oraz obszar Argob w Baszanie, obejmujący sześćdziesiąt dużych miast z murami obronnymi, których bramy miały zasuwy z brązu.
###### **1Krl 4,14**
 Achinadab, syn Iddo, w Machanaim.
###### **1Krl 4,15**
 Achimaas na obszarze Neftalego. Wziął on sobie za żonę córkę Salomona, Basmat.
###### **1Krl 4,16**
 Baana, syn Chuszaja, na obszarze Asera i Zabulona.
###### **1Krl 4,17**
 Joszafat, syn Paruacha, na obszarze Issachara.
###### **1Krl 4,18**
 Szimei, syn Eli, na obszarze Beniamina.
###### **1Krl 4,19**
 Geber, syn Uriego, w Gileadzie - ziemi Sichona, króla Amorytów i Oga, króla Baszanu. Natomiast w kraju Judy był jeden zarządca.
###### **1Krl 4,20**
 Ludność Judy i Izraela była tak liczna jak ziarnka piasku na brzegu morza. Wszyscy ucztowali w radości.
# 1Krl 4 BP
###### **1Krl 4,1**
 Król Salomon był władcą całego Izraela.
###### **1Krl 4,2**
 Takich miał dostojników: Azarjahu, syn Cadoka, kapłan;
###### **1Krl 4,3**
 Elichoref i Achijja, synowie Sziszy, sekretarze; Jehoszafat, syn Achiluda, kronikarz;
###### **1Krl 4,4**
 Benajahu, syn Jehojady, dowódca wojska; Cadok i Ebjatar, kapłani;
###### **1Krl 4,5**
 Azarjahu, syn Natana, przełożony prefektów; Zabud, syn Natana, kapłan, przyjaciel króla;
###### **1Krl 4,6**
 Achiszar, marszałek dworu; Adoniram, syn Abdy, kierownik robót przymusowych.
###### **1Krl 4,7**
 Salomon miał dwunastu prefektów nad całym Izraelem. [Oni] troszczyli się o utrzymanie króla i jego dworu. Każdy [z nich] przez [jeden] miesiąc w roku był obowiązany troszczyć się o zaopatrzenie.
###### **1Krl 4,8**
 Takie są ich imiona: syn Chura, w górach Efraim.
###### **1Krl 4,9**
 … Syn Dekera, w Makac, Szaalbim, Bet Szemesz, Ajjalon i Bet Chanan.
###### **1Krl 4,10**
 … Syn Cheseda, w Arubbot. Do niego należało Soko i cała ziemia Chefer.
###### **1Krl 4,11**
 … Syn Abinadaba, na całym wzniesieniu Dor. On miał za żonę córkę Salomona Tafat.
###### **1Krl 4,12**
 Baana, syn Achiluda, w Taanak i Megiddo aż po Jokmeam, w całym Bet-Szean poniżej Jizreel i od Bet-Szean aż do Abel-Mechola, które leży koło Cartan.
###### **1Krl 4,13**
 …Syn Gebera, w Ramot Gilead. Do niego należały skupiska nomadów Jaira, syna Manassego, którzy [znajdowali się] w Gilead. Do niego należał [także] okręg Argob, który jest w Baszanie, sześćdziesiąt wielkich miast [mających] mury i spiżowe zasuwy.
###### **1Krl 4,14**
 Achinadab, syn Iddo, w Machanajim.
###### **1Krl 4,15**
 Achimaac na [terytorium pokolenia] Neftalego. On także pojął za żonę córkę Salomona Basemat.
###### **1Krl 4,16**
 Baana, syn Chuszaja, na [terytorium pokolenia] Aszera i w Bealot.
###### **1Krl 4,17**
 Jehoszafat, syn Paruacha, na [terytorium pokolenia] Issachara.
###### **1Krl 4,18**
 Szimi, syn Eli, na [terytorium pokolenia] Beniamina.
###### **1Krl 4,19**
 Geber, syn Uriego, w krainie Gilead ziemi Sichona, króla Amorytów, i Oga, króla Baszanu. [Nadto] jeden prefekt był w ziemi [judzkiej].
###### **1Krl 4,20**
 [Pokolenia] Judy i Izraela z powodu swej liczebności były tak mnogie jak piasek nadmorski. Jadły i piły, i radowały się.
# 1Krl 4 BR
###### **1Krl 4,1**
 Salomon miał władzę królewską nad całym Izraelem.
###### **1Krl 4,2**
 Oto jego najwyżsi urzędnicy: Azariasz, syn Sadoka, był kapłanem;
###### **1Krl 4,3**
 Elichoref i Achiasz, synowie Sziszy, byli pisarzami; Joszafat, syn Achiluda, był pełnomocnikiem [króla].
###### **1Krl 4,4**
 Benajasz, syn Jojady, dowodził wojskiem, a Sadok i Abiatar byli kapłanami.
###### **1Krl 4,5**
 Azariasz, syn Natana, był przełożonym nadzorców, Zabud zaś, syn kapłana Natana, zaufanym doradcą.
###### **1Krl 4,6**
 Achiszar zarządzał całym pałacem, natomiast Adoniram, syn Abdy, nadzorował wszystkich, którzy byli zatrudnieni przy ciężkich robotach.
###### **1Krl 4,7**
 W całym Izraelu miał Salomon dwunastu nadzorców, którzy zaopatrywali w żywność króla i cały jego dom, każdy z nich przez jeden miesiąc w roku.
###### **1Krl 4,8**
 Oto ich imiona: Ben-Chur na górze Efraima,
###### **1Krl 4,9**
 Ben-Deker w Makas, w Szaalbim, w Bet-Szemesz, w Elon, w Bet-Chanan.
###### **1Krl 4,10**
 Ben-Chesed był w Arubot, do którego należało Soko i cała ziemia Chefer.
###### **1Krl 4,11**
 Ben-Abinadab nadzorował wszystkie wzgórza koło Dor. Jego żona miała na imię Tafat i była córką Salomona.
###### **1Krl 4,12**
 Baana, syn Achiluda, działał w Tanak i w Megiddo, w całym Bet-Szean za Jizreel, powyżej Sartany, aż do Abel-Mechola i do Jokmeam.
###### **1Krl 4,13**
 Ben-Geber przebywał w Ramot, w Gileadzie. Miał pod swoją władzą Osiedla Jaira, syna Manassesa. Jemu podlegała również kraina Argob w Baszanie, obejmująca sześćdziesiąt dużych osiedli, otoczonych murami, zaryglowanymi za pomocą zamków z brązu.
###### **1Krl 4,14**
 Achinadab, syn Iddo, nadzorował Machanaim,
###### **1Krl 4,15**
 Achimaas zaś cały kraj zamieszkany przez pokolenie Neftalego. On to wziął za żonę córkę Salomona, Basmat.
###### **1Krl 4,16**
 Baana, syn Chuszaja, miał władzę nad krainą Asera, łącznie ze wzgórzami.
###### **1Krl 4,17**
 Joszafat zaś, syn Paruacha, czuwał nad posiadłościami pokolenia Issachara.
###### **1Krl 4,18**
 Szimei, syn Eli, sprawował swój urząd na ziemi Beniamina.
###### **1Krl 4,19**
 Wreszcie Geber, syn Uriego, nadzorował położoną w Gileadzie ziemię Sichona, króla amoryckiego, i Oga, króla Baszanu. Do tego dochodzi jeden nadzorca na ziemiach Judy.
###### **1Krl 4,20**
 Mieszkańcy Judy oraz Izraela byli liczni jak piasek nad brzegiem morza. Wszyscy mieli co jeść i pić i byli szczęśliwi.
# 1Krl 4 WUJ
###### **1Krl 4,1**
 A Salomon był królem królując nad wszystkim Izraelem:
###### **1Krl 4,2**
 A te książęta które miał: Azarias syn Sadoka kapłana:
###### **1Krl 4,3**
 Elihoreph i Ahia synowie Sisa pisarze: Jozaphat syn Ahilud Kanclerz:
###### **1Krl 4,4**
 Banajas syn Jojady nad wojskiem: a Sadok i Abiathar kapłani.
###### **1Krl 4,5**
 Azarias syn Nathan nad tym: którzy stali przy królu: Zabud syn Nathan kapłan, przyjaciel królewski:
###### **1Krl 4,6**
 I Abizar przełożony nad domem: a Adoniram syn Abdi nad pobory.
###### **1Krl 4,7**
 Lecz Salomon miał dwanaście przełożonych nad wszystkim Izraelem, którzy dodawali żywności królowi i domowi jego: bo na każdy Miesiąc przez rok jeden z nich potrzeb dodawał.
###### **1Krl 4,8**
 A te są imiona ich: Benhur na górze Ephraim.
###### **1Krl 4,9**
 Bendekar w Makkes i w Salebim i w Bethsames i w Elon i w Bethanan.
###### **1Krl 4,10**
 Benhesed w Aruboth: jego był Socho, i wszystka ziemia Epher.
###### **1Krl 4,11**
 Benabinadab, którego wszystek Nephathdor, Thaphetę córkę Salomonowę miał za żonę.
###### **1Krl 4,12**
 Bana syn Ahilud rządził Thanak i Mageddo i wszystek Bethsan, który jest podle Sarthana pod Jezrahelem od Bethsan aż do Abelmehula przeciw Jekmaan.
###### **1Krl 4,13**
 Bengaber w Ramot Galaad: miał Auothiair syna Manassego w Galaad, on był nad wszystką krainą Argob, która jest w Basan, nad sześciądziesiąt miast wielkich i murowanych, które miały zamykanie miedziane.
###### **1Krl 4,14**
 Ahinadab syn Addo rządził w Manaim.
###### **1Krl 4,15**
 Achimaas w Nephtalim, ale i on miał Bazemathę córkę Salomonowę za żonę.
###### **1Krl 4,16**
 Baana syn Husi w Azer i w Baloth.
###### **1Krl 4,17**
 Jozaphat syn Pharue w Issahar.
###### **1Krl 4,18**
 Semei syn Ela w Benjamin.
###### **1Krl 4,19**
 Gaber syn Uri w ziemi Galaad, w ziemi Sehon króla Amorrhejskiego, i Og króla Bazan, nad wszem co było w onej ziemi.
###### **1Krl 4,20**
 Juda i Izrael niezliczony, jako piasek morski w mnóstwie jedząc i pijąc, a weseląc się.
###### **1Krl 4,21**
 A Salomon mieszkał w państwie swojem, mając wszystkie królestwa, od rzeki ziemie Philistynskiej aż do granice Egiptskiej, którzy mu nosili dary, i służyli mu po wszystkie dni żywota jego.
###### **1Krl 4,22**
 A był obrok Salomonów, na każdy dzień trzydzieści korcy czystej mąki i sześćdziesiąt korcy mąki.
###### **1Krl 4,23**
 Dziesięć wołów tłustych, a dwadzieścia wołów pastewnych, i sto baranów, oprócz łowu, jeleni, sarn i bawołów, i ptastwa karmnego.
###### **1Krl 4,24**
 Bo on dzierżał wszystkę krainę, która była za rzeką, od Taphsa aż da Gazan, i wszystkie króle onych krajów: a miał pokój ze wszech stron w około:
###### **1Krl 4,25**
 I mieszkał Juda i Izrael bez wszelkiej bojaźni, każdy pod winną macicą swoją, i pod figą swoją, od Dan aż do Bersabee po wszystkie dni Salomonowe.
###### **1Krl 4,26**
 I miał Salomon czterdzieści tysięcy żłobów koni do wozów, a dwanaście tysięcy do jazdy.
###### **1Krl 4,27**
 A opatrowali je wyżej pomienieni starostowie królewscy: lecz i potrzeby do stołu króla Salomona z wielką pilnością dodawali czasu swego.
###### **1Krl 4,28**
 Jęczmień też i słomę dla koni, i mułów, wozili na miejsce, gdzie był król, według tego jako iin ustawiono.
###### **1Krl 4,29**
 Dał też Bóg Salomonowi mądrość i roztropność barzo wielką, i przestroność serca jako piasek, który jest na brzegu morskim.
###### **1Krl 4,30**
 I przechodziła mądrość Salomonowa mądrość wszystkich ludzi Wschodnich, i Egiptyanów.
###### **1Krl 4,31**
 I był mędrszy nad wszystkie ludzie: mędrszy niż Ethan Ezrahita, i Hetman, i Chalkol, i Dorda synowie Mahol: i był sławny u wszech narodów okolicznych.
###### **1Krl 4,32**
 Mówił też Salomon trzy tysiące przypowieści: a pieśni jego było tysiąc i pięć.
###### **1Krl 4,33**
 Rozprawiał też o drzewach od Cedru, który jest na Libanie, aż do hyssopu, który wyrasta z ściany: i mówił o zwierzętach, i ptakach, i płazie, i o rybach.
###### **1Krl 4,34**
 I przychodzili ze wszystkich narodów słuchać mądrości Salomonowej, i od wszystkich królów ziemskich, którzy słyszeli mądrość jego.
