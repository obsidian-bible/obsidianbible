# Ap 4 BT5
###### **Ap 4,1**
 Potem ujrzałem:oto drzwi otwarte w niebie, a głos, ów pierwszy, jaki usłyszałem, jak gdyby trąby rozmawiającej ze mną, powiedział:«***Wstąp tutaj, a to ci ukażę, co potem musi się stać***».
###### **Ap 4,2**
 Doznałem natychmiast zachwycenia:A oto w niebie stał troni na tronie [Ktoś] zasiadał.
###### **Ap 4,3**
 A Zasiadający był podobny z wyglądu do jaspisu i do krwawnika, a tęcza dokoła tronu – podobna z wyglądu do szmaragdu.
###### **Ap 4,4**
 Dokoła tronu – dwadzieścia cztery trony, a na tronach dwudziestu czterech siedzących Starców,odzianych w białe szaty, a na ich głowach złote wieńce.
###### **Ap 4,5**
 A z tronu wychodzą błyskawice i głosy, i gromy, i płonie przed tronem siedem lamp ognistych,które są siedmiu Duchami Boga.
###### **Ap 4,6**
 Przed tronem – niby szklane morze podobne do kryształu, a pośrodku tronu i dokoła tronucztery Istoty żyjące, pełne oczu z przodu i z tyłu:
###### **Ap 4,7**
 pierwsza Istota żyjąca podobna do lwa, druga Istota żyjąca podobna do cielca, trzecia Istota żyjąca mająca twarz jak gdyby ludzkąi czwarta Istota żyjąca podobna do orła w locie.
###### **Ap 4,8**
 Cztery Istoty żyjące – a każda z nich ma po sześć skrzydeł – dokoła i wewnątrz są pełne oczu, i bez wytchnienia mówią dniem i nocą:Święty, Święty, Święty, Pan Bóg wszechmogący,Który był i Który jest, i Który przychodzi.
###### **Ap 4,9**
 A ilekroć Istoty żyjące oddadzą chwałę i cześć, i dziękczynienieZasiadającemu na tronie, Żyjącemu na wieki wieków,
###### **Ap 4,10**
 upada dwudziestu czterech Starców przed Zasiadającym na troniei oddają pokłon Żyjącemu na wieki wieków, i rzucają przed tron wieńce swe, mówiąc:
###### **Ap 4,11**
 «***Godzien jesteś, Panie i Boże nasz, odebrać chwałę i cześć, i moc, bo Ty stworzyłeś wszystko, a z woli Twojej istniało [to] i zostało stworzone***».
# Ap 4 PAU
###### **Ap 4,1**
 Potem miałem widzenie: Oto w niebie otworzyła się brama i głos, który słyszałem na początku - podobny do dźwięku trąby - przemówił do mnie: „Wejdź tutaj, a pokażę ci, co potem musi się wydarzyć”.
###### **Ap 4,2**
 Natychmiast ogarnął mnie Duch: Oto w niebie stał tron, a na tronie ktoś siedział.
###### **Ap 4,3**
 Ten, kto siedział, podobny był z wyglądu do kamienia jaspisu i sardu, a tęcza wokół tronu podobna była do szmaragdu.
###### **Ap 4,4**
 Tron otaczały dwadzieścia cztery trony, na których zasiadało dwudziestu czterech starszych. Ubrani byli w białe szaty, a na głowach mieli złote wieńce.
###### **Ap 4,5**
 Z tronu wychodziły błyskawice, głosy i grzmoty, a przed tronem płonęło siedem ognistych lamp, którymi jest siedem Duchów Boga.
###### **Ap 4,6**
 Przed tronem było też jakby morze szklane podobne do kryształu. Na środku tronu i wokół tronu stały cztery istoty żywe, które miały mnóstwo oczu z przodu i z tyłu.
###### **Ap 4,7**
 Pierwsza istota żywa podobna była do lwa, druga istota żywa podobna do byka, trzecia istota żywa miała jakby ludzką twarz, czwarta istota żywa podobna była do lecącego orła.
###### **Ap 4,8**
 Każda z czterech istot żywych miała po sześć skrzydeł i mnóstwo oczu na zewnątrz i wewnątrz. Powtarzały one nieustannie w dzień i w nocy: „Święty, Święty, Święty, Pan, Bóg Wszechmocny, który był, który jest i który przychodzi”.
###### **Ap 4,9**
 A gdy istoty żywe oddawały chwałę, cześć i dziękczynienie Siedzącemu na tronie, Żyjącemu na wieki wieków,
###### **Ap 4,10**
 dwudziestu czterech starszych padało na twarz przed Siedzącym na tronie. Kłaniali się Żyjącemu na wieki wieków i rzucali swoje wieńce przed tronem, mówiąc:
###### **Ap 4,11**
 „Jesteś godny, Panie, nasz Boże, odebrać chwałę, cześć i moc, bo Ty stworzyłeś wszystko, z Twojej woli zaistniało i zostało stworzone”.
# Ap 4 BP
###### **Ap 4,1**
 Potem ujrzałem: Oto drzwi otwarte w niebie, a głos, ów pierwszy, jaki usłyszałem, jak gdyby trąby mówiącej ze mną, powiedział: "Wstąp tutaj, a ukażę ci to, co potem musi się stać".
###### **Ap 4,2**
 Doznałem natychmiast zachwycenia: A oto w niebie stał tron i ktoś zasiadał na tronie.
###### **Ap 4,3**
 A Zasiadający był podobny z wyglądu do jaspisu i do krwawnika, a tęcza dokoła tronu - podobna z wyglądu do szmaragdu.
###### **Ap 4,4**
 Dokoła tronu - dwadzieścia cztery trony, a na tronach siedziało dwudziestu czterech Starców odzianych w białe szaty, a na ich głowach złote wieńce.
###### **Ap 4,5**
 Z tronu wychodzą błyskawice i [słychać] huk gromów, siedem lamp ognistych płonie przed tronem, to jest siedem Duchów Boga.
###### **Ap 4,6**
 Przed tronem niby szklane morze podobne do kryształu, a w środku i dokoła tronu cztery Zwierzęta pełne oczu z przodu i z tyłu.
###### **Ap 4,7**
 Zwierzę pierwsze podobne do lwa, Zwierzę drugie podobne do wołu, Zwierzę trzecie z twarzą jak gdyby ludzką, a Zwierzę czwarte podobne do orła w locie.
###### **Ap 4,8**
 I cztery Zwierzęta - a każde z nich ma po sześć skrzydeł - dokoła i wewnątrz są pełne oczu, i nie mają spoczynku, mówiąc dniem i nocą: "Święty, Święty, Święty, Pan, Bóg, Władca wszechrzeczy, który był, który jest i który przychodzi".
###### **Ap 4,9**
 A ilekroć Zwierzęta oddadzą chwałę i cześć, i dziękczynienie Zasiadającemu na tronie, Żyjącemu na wieki wieków,
###### **Ap 4,10**
 upada dwudziestu czterech Starców przed Zasiadającym na tronie i oddaje pokłon Żyjącemu na wieki wieków, i składa przed tronem swoje wieńce, mówiąc:
###### **Ap 4,11**
 "Godzien jesteś, Panie i Boże nasz, odebrać chwałę i cześć, i moc, boś Ty stworzył wszystko, a dzięki Twojej woli wszystko istniało i zostało stworzone".
# Ap 4 BR
###### **Ap 4,1**
 A potem miałem takie oto widzenie: Ujrzałem bramę otwartą w niebie, a głos owej jakby trąby skierowanej już przedtem w moją stronę mówią do mnie: Wejdź tutaj, a ja ukażę ci to [wszystko], co musi nastąpić.
###### **Ap 4,2**
 I zaraz zostałem uniesiony w zachwycie. Ujrzałem w niebie tron i kogoś, kto siedział na tronie.
###### **Ap 4,3**
 Ów zasiadający na tronie miał twarz przypominającą jaspis lub sardoniks. Dokoła Jego tronu znajdowała się tęcza [grająca kolorami] jak szmaragd.
###### **Ap 4,4**
 Wokół tego tronu stały dwadzieścia cztery inne trony, a na nich siedziało dwudziestu czterech Starców. Wszyscy byli ubrani w białe szaty, a na głowach mieli korony ze złota.
###### **Ap 4,5**
 Od tronu [głównego] rozchodziły się błyskawice, huk i grzmoty. Przed tronem znajdowało się siedem lamp zapalonych. One to oznaczały siedem Duchów Boga.
###### **Ap 4,6**
 Również przed tronem [widziałem] jakby szklane morze, podobne do kryształu, w samym zaś środku tronu i z czterech jego stron znajdowało się czworo Zwierząt, pełnych oczu z przodu i z tyłu.
###### **Ap 4,7**
 Pierwsze Zwierzę było podobne do lwa, drugie do wołu, trzecie miało twarz jakby człowieka, a czwarte przypominało swoim wyglądem lecącego orła.
###### **Ap 4,8**
 Każde z owych czworga Zwierząt miało sześć skrzydeł i było pełne oczu dokoła i wewnątrz. Wszystkie bez ustanku, dniem i nocą wołały: Święty, Święty, Święty Pan, Bóg wszechmocny, Ten, który był, który jest i który przyjdzie.
###### **Ap 4,9**
 Ile razy Zwierzęta składały cześć, chwałę i dziękczynienie Temu, który siedzi na tronie i który żyje na wieki wieków, tyle też razy
###### **Ap 4,10**
 dwudziestu czterech Starców upadało przed Siedzącym na tronie, oddając pokłon Żyjącemu na wieki wieków. Składali też przed tronem swoje korony i wołali:
###### **Ap 4,11**
 Godzien jesteś, Panie i Boże nasz, by składano Ci chwałę i cześć, i [aby Ci przyznawano] moc [najwyższą]. Ty bowiem wszystko stworzyłeś i dzięki Twojej woli [wszystko] zaistniało i zostało stworzone.
# Ap 4 WUJ
###### **Ap 4,1**
 Potemem widział: oto drzwi otworzone w niebie, a głos pierwszy, którym słyszał, jakoby trąby gadającej zemną mówiący: Wstąp sam, a pokażęć co się ma dziać potem.
###### **Ap 4,2**
 Natychmiast byłem w duchu: a oto stolica postawiona była na niebie, a na stolicy siedzący.
###### **Ap 4,3**
 A który siedział, był podobny pojrzeniu kamienia Jaspisa i Sardyna: a tęcza była około stolice, podobna pojrzeniu smaragdowemu.
###### **Ap 4,4**
 A około stolice stolic dwadzieścia i cztery: a na stolicach, dwadzieścia, i czterech starszych siedzących, obleczonych w szaty białe, a na głowiech ich korony złote.
###### **Ap 4,5**
 A z stolice wychodziły łyskawice, i głosy, i gromy: a siedm lamp gorających przed stolicą, który są siedm Duchów Bożych.
###### **Ap 4,6**
 A przed stolicą jako morze szklane podobne kryształowi: w pośrodku stolice i około stolice czworo zwierząt pełne oczu z przodku i z tyłu.
###### **Ap 4,7**
 A zwierzę pierwsze podobne lwowi, a wtóre zwierzę podobne cielcowi, a trzecie zwierzę mające oblicze jako człowieka, a czwarte zwierzę podobne orłowi latającemu.
###### **Ap 4,8**
 A czworo zwierząt, każde z nich miały po sześci skrzydeł a w koło wewnątrz pełne są oczu: odpoczynku nie miały we dnie a w nocy, mówiąc: Święty, Święty, Święty Pan Bóg wszechmogący, który był, i który jest, i który ma przyść.
###### **Ap 4,9**
 A gdy one zwierzęta dawany chwałę, i cześć i dziękowanie siedzącemu na stolicy: żywiącemu na wieki wieków:
###### **Ap 4,10**
 Upadał dwadzieścia i czterze starszych przed siedzącym na stolicy, i kłaniali się żywiącemu na wieki wieków, porzucali korony we przed stolicą, mówiąc:
###### **Ap 4,11**
 Godzieneś jest Panie Boże nasz, wziąć chwałę i cześć i moc: Boś ty stworzył wszystkie rzeczy, i dla woli twojej były i stworzone są.
# Ap 4 STERN
###### **Ap 4,1**
 Po tym wszystkim spojrzałem, a przede mną były otwarte drzwi w niebie, głos zaś niczym trąba, który wcześniej słyszałem, jak mówił ze mną, rzekł: "Wstąp tutaj, a pokażę ci, co się musi stać po tych rzeczach".
###### **Ap 4,2**
 W jednej chwili znalazłem się w Duchu, a przede mną w niebie stał tron, a na tronie ktoś zasiadał.
###### **Ap 4,3**
 Zasiadający tam błyszczał jak diamenty i rubiny, a tęcza jaśniejąca jak szmaragdy otaczała tron.
###### **Ap 4,4**
 Wokół tronu były dwadzieścia cztery inne trony, a na tronach zasiadało dwudziestu czterech starszych, ubranych na biało, ze złotymi koronami na głowach.
###### **Ap 4,5**
 Z tronu wychodziły błyskawice i głosy, i grzmoty, a przed tronem było siedem płonących pochodni, które są siedmiorakim Duchem Bożym.
###### **Ap 4,6**
 Przed tronem było coś jakby szklane morze, przejrzyste jak kryształ. Pośrodku, wokół tronu, były cztery żywe istoty, pokryte oczami z przodu i z tyłu.
###### **Ap 4,7**
 Pierwsza żywa istota była podobna do lwa, druga żywa istota była podobna do wołu, trzecia żywa istota miała twarz wyglądającą jak ludzka, a czwarta z żywych istot była podobna do orła w locie.
###### **Ap 4,8**
 Każda z czerech istot miała sześć skrzydeł i była pokryta oczami w środku i na zewnątrz, a dniem i nocą nigdy nie przestawały mówić: "Święty, święty, święty jest Adonai, Bóg wojsk niebieskich, Ten, który był, który jest i który nadchodzi!".
###### **Ap 4,9**
 A ilekroć żywe istoty oddają chwałę, cześć i dziękczynienie Zasiadającemu na tronie, Temu, który żyje na wieki wieków,
###### **Ap 4,10**
 dwudziestu czterech starszych upada przed Zasiadającym na tronie, który żyje na wieki wieków, i oddają Mu pokłon. Rzucają przed tron swoje korony i mówią:
###### **Ap 4,11**
 "Godzien jesteś, Adonai Eloheinu, odebrać chwałę, cześć i moc, bo Ty wszystko stworzyłeś, tak, z powodu Twojej woli zostało stworzone i powstało!".
# Ap 4 TRO
###### **Ap 4,1**
 **μετα** *meta* Po [[G3326]] [[PREP]] **ταυτα** *tauta* te [[G5023]] WTD-APN **ειδον** *eidon* zobaczyłem [[G1492]] WTV-2AAI-1S **και** *kai* i [[G2532]] [[CONJ]] **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **θυρα** *thyra* drzwi [[G2374]] [[N-NSF]] **ηνεωγμενη** *ēneōgmenē* które jest otworzone (które są otworzone) [[G455]] WTV-RPP-NSF **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **ουρανω** *ouranō* niebie [[G3772]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **φωνη** *fōnē* głos [[G5456]] [[N-NSF]] **η** *hē* [[G3588]] [[T-NSF]] **πρωτη** *prōtē* pierwszy [[G4413]] WTA-NSF **ην** *hēn* który [[G3739]] WTR-ASF **ηκουσα** *ēkousa* usłyszałem [[G191]] WTV-AAI-1S **ως** *hōs* jak [[G5613]] [[ADV]] **σαλπιγγος** *salpingos* trąby [[G4536]] [[N-GSF]] **λαλουσης** *lalousēs* mówiącej [[G2980]] WTV-PAP-GSF **μετ** *met* ze [[G3326]] [[PREP]] **εμου** *emou* mną [[G1700]] WTP-1GS **λεγουσα** *legousa* mówiący [[G3004]] [[V-PAP-NSF]] **αναβα** *anaba* wejdź – wstąp [[G305]] WTV-2AAM-2S-AP **ωδε** *hōde* tu [[G5602]] [[ADV]] **και** *kai* a [[G2532]] [[CONJ]] **δειξω** *deiksō* pokażę [[G1166]] WTV-FAI-1S **σοι** *soi* ci [[G4671]] WTP-2DS **α** *ha* co [[G3739]] WTR-APN **δει** *dei* trzeba – jest konieczne [[G1163]] WTV-PQI-3S **γενεσθαι** *genesthai* stać się [[G1096]] WTV-2ADN **μετα** *meta* po [[G3326]] [[PREP]] **ταυτα** *tauta* tych [[G5023]] WTD-APN
###### **Ap 4,2**
 **και** *kai* I [[G2532]] [[CONJ]] **ευθεως** *eutheōs* zaraz – natychmiast [[G2112]] [[ADV]] **εγενομην** *egenomēn* stałem się [[G1096]] WTV-2ADI-1S **εν** *en* w [[G1722]] [[PREP]] **πνευματι** *pneumati* Duchu [[G4151]] WTN-DSN **και** *kai* i [[G2532]] [[CONJ]] **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **θρονος** *thronos* tron [[G2362]] [[N-NSM]] **εκειτο** *ekeito* był położony – był umieszczony [[G2749]] WTV-INI-3S **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **ουρανω** *ouranō* niebie [[G3772]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **επι** *epi* na [[G1909]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronie [[G2362]] [[N-GSM]] **καθημενος** *kathēmenos* siedzący [[G2521]] WTV-PNP-NSM
###### **Ap 4,3**
 **και** *kai* A [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **καθημενος** *kathēmenos* siedzący [[G2521]] WTV-PNP-NSM **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **ομοιος** *homoios* podobny [[G3664]] [[A-NSM]] **ορασει** *horasei* widzeniem – wizją [[G3706]] [[N-DSF]] **λιθω** *lithō* kamieniowi [[G3037]] WTN-DSM **ιασπιδι** *iaspidi* jaspisowi [[G2393]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **σαρδινω** *sardinō* karneolowi [[G4555]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **ιρις** *iris* tęcza [[G2463]] [[N-NSF]] **κυκλοθεν** *kyklothen* naokoło [[G2943]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronu [[G2362]] [[N-GSM]] **ομοια** *homoia* podobna [[G3664]] WTA-NSF **ορασει** *horasei* widzeniu – wizji [[G3706]] [[N-DSF]] **σμαραγδινω** *smaragdinō* szmaragdu [[G4664]] WTA-DSM
###### **Ap 4,4**
 **και** *kai* I [[G2532]] [[CONJ]] **κυκλοθεν** *kyklothen* naokoło [[G2943]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronu [[G2362]] [[N-GSM]] **θρονοι** *thronoi* tronów [[G2362]] WTN-NPM **εικοσι** *eikosi* dwadzieścia [[G1501]] WTA-NPM **και** *kai* i [[G2532]] [[CONJ]] **τεσσαρες** *tessares* cztery [[G5064]] WTA-NPM **και** *kai* i [[G2532]] [[CONJ]] **επι** *epi* na [[G1909]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **θρονους** *thronous* tronach [[G2362]] [[N-APM]] **ειδον** *eidon* zobaczyłem [[G1492]] WTV-2AAI-1S **τους** *tous* [[G3588]] WTT-APM **εικοσι** *eikosi* dwudziestu [[G1501]] WTA-NPM **και** *kai* i [[G2532]] [[CONJ]] **τεσσαρας** *tessaras* czterech [[G5064]] WTA-APM **πρεσβυτερους** *presbyterous* starszych – starców [[G4245]] WTA-APM **καθημενους** *kathēmenous* siedzących [[G2521]] WTV-PNP-APM **περιβεβλημενους** *peribeblēmenous* którzy są okryci – którzy są odziani [[G4016]] WTV-RPP-APM **εν** *en* w [[G1722]] [[PREP]] **ιματιοις** *himatiois* szatach – płaszczach [[G2440]] WTN-DPN **λευκοις** *leukois* białych [[G3022]] WTA-DPN **και** *kai* i [[G2532]] [[CONJ]] **εσχον** *eschon* mieli [[G2192]] WTV-2AAI-3P **επι** *epi* na [[G1909]] [[PREP]] **τας** *tas* [[G3588]] WTT-APF **κεφαλας** *kefalas* głowach [[G2776]] WTN-APF **αυτων** *autōn* ich [[G846]] WTP-GPM **στεφανους** *stefanous* wieńce – korony [[G4735]] [[N-APM]] **χρυσους** *chrysous* złote [[G5552]] WTA-APM
###### **Ap 4,5**
 **και** *kai* I [[G2532]] [[CONJ]] **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronu [[G2362]] [[N-GSM]] **εκπορευονται** *ekporeuontai* wychodzą [[G1607]] WTV-PNI-3P **αστραπαι** *astrapai* błyskawice [[G796]] [[N-NPF]] **και** *kai* i [[G2532]] [[CONJ]] **βρονται** *brontai* grzmoty [[G1027]] [[N-NPF]] **και** *kai* i [[G2532]] [[CONJ]] **φωναι** *fōnai* głosy [[G5456]] [[N-NPF]] **και** *kai* i [[G2532]] [[CONJ]] **επτα** *hepta* siedem [[G2033]] WTA-NUI **λαμπαδες** *lampades* lamp [[G2985]] [[N-NPF]] **πυρος** *pyros* ognia [[G4442]] [[N-GSN]] **καιομεναι** *kaiomenai* które są zapalone [[G2545]] WTV-PPP-NPF **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronem [[G2362]] [[N-GSM]] **αι** *hai* które [[G3739]] WTR-NPF **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **τα** *ta* [[G3588]] WTT-NPN **επτα** *hepta* siedem [[G2033]] WTA-NUI **πνευματα** *pneumata* duchy [[G4151]] WTN-NPN **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **Ap 4,6**
 **και** *kai* A [[G2532]] [[CONJ]] **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronem [[G2362]] [[N-GSM]] **θαλασσα** *thalassa* morze [[G2281]] [[N-NSF]] **υαλινη** *hyalinē* szkliste [[G5193]] WTA-NSF **ομοια** *homoia* podobne [[G3664]] WTA-NSF **κρυσταλλω** *krystallō* kryształowi [[G2930]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* na [[G1722]] [[PREP]] **μεσω** *mesō* środku [[G3319]] WTA-DSN **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronu [[G2362]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **κυκλω** *kyklō* wokół [[G2945]] WTN-DSM **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronu [[G2362]] [[N-GSM]] **τεσσαρα** *tessara* cztery [[G5064]] WTA-NPN **ζωα** *zōa* istoty żywe [[G2226]] WTN-NPN **γεμοντα** *gemonta* będące pełnymi [[G1073]] WTV-PAP-NPN **οφθαλμων** *ofthalmōn* oczu [[G3788]] WTN-GPM **εμπροσθεν** *emprosthen* z przodu [[G1715]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **οπισθεν** *opisthen* z tyłu [[G3693]] [[ADV]]
###### **Ap 4,7**
 **και** *kai* I [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **ζωον** *zōon* istota żywa [[G2226]] WTN-NSN **το** *to* (ta) [[G3588]] WTT-NSN **πρωτον** *prōton* pierwsza [[G4413]] WTA-NSN **ομοιον** *homoion* podobna [[G3664]] WTA-NSN **λεοντι** *leonti* lwu [[G3023]] WTN-DSM **και** *kai* a [[G2532]] [[CONJ]] **το** *to* (ta) [[G3588]] WTT-NSN **δευτερον** *deuteron* druga [[G1208]] WTA-NSN **ζωον** *zōon* istota żywa [[G2226]] WTN-NSN **ομοιον** *homoion* podobna [[G3664]] WTA-NSN **μοσχω** *moschō* cielęciu [[G3448]] WTN-DSM **και** *kai* a [[G2532]] [[CONJ]] **το** *to* (ta) [[G3588]] WTT-NSN **τριτον** *triton* trzecia [[G5154]] WTA-NSN **ζωον** *zōon* istota żywa [[G2226]] WTN-NSN **εχον** *echon* mająca [[G2192]] WTV-PAP-NSN **το** *to* [[G3588]] WTT-ASN **προσωπον** *prosōpon* oblicze – twarz [[G4383]] WTN-ASN **ως** *hōs* jak [[G5613]] [[ADV]] **ανθρωπος** *anthrōpos* człowiek [[G444]] [[N-NSM]] **και** *kai* a [[G2532]] [[CONJ]] **το** *to* (ta) [[G3588]] WTT-NSN **τεταρτον** *tetarton* czwarta [[G5067]] WTA-NSN **ζωον** *zōon* istota żywa [[G2226]] WTN-NSN **ομοιον** *homoion* podobna [[G3664]] WTA-NSN **αετω** *aetō* orłowi [[G105]] WTN-DSM **πετωμενω** *petōmenō* lecącemu [[G4072]] WTV-PNP-DSM
###### **Ap 4,8**
 **και** *kai* I [[G2532]] [[CONJ]] **τεσσαρα** *tessara* cztery [[G5064]] WTA-NPN **ζωα** *zōa* istoty żywe [[G2226]] WTN-NPN **εν** *hen* jedno [[G1520]] WTA-NSN **καθ** *kath* po [[G2596]] [[PREP]] **εαυτο** *eauto* sobie [[G1438]] WTF-3ASN **ειχον** *eichon* miały [[G2192]] WTV-IAI-3P **ανα** *ana* po [[G303]] [[PREP]] **πτερυγας** *pterygas* skrzydeł [[G4420]] WTN-APF **εξ** *heks* sześć [[G1803]] WTA-NUI **κυκλοθεν** *kyklothen* naokoło [[G2943]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **εσωθεν** *esōthen* z wewnątrz [[G2081]] [[ADV]] **γεμοντα** *gemonta* będące pełnymi [[G1073]] WTV-PAP-NPN **οφθαλμων** *ofthalmōn* oczu [[G3788]] WTN-GPM **και** *kai* i [[G2532]] [[CONJ]] **αναπαυσιν** *anapausin* odpoczynku [[G372]] WTN-ASF **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εχουσιν** *echousin* mają [[G2192]] WTV-PAI-3P **ημερας** *hēmeras* dniem [[G2250]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **νυκτος** *nyktos* nocą [[G3571]] [[N-GSF]] **λεγοντα** *legonta* mówiąc [[G3004]] WTV-PAP-ASM **αγιος** *hagios* Święty [[G40]] [[A-NSM]] **αγιος** *hagios* Święty [[G40]] [[A-NSM]] **αγιος** *hagios* Święty [[G40]] [[A-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **παντοκρατωρ** *pantokratōr* Wszechmogący – Wszechwładca [[G3841]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **ων** *ōn* który jest [[G5607]] [[V-PXP-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **ερχομενος** *erchomenos* przychodzący [[G2064]] WTV-PNP-NSM
###### **Ap 4,9**
 **και** *kai* I [[G2532]] [[CONJ]] **οταν** *hotan* kiedy [[G3752]] [[CONJ]] **δωσουσιν** *dōsousin* dadzą [[G1325]] WTV-FAI-3P **τα** *ta* [[G3588]] WTT-NPN **ζωα** *zōa* istoty żywe [[G2226]] WTN-NPN **δοξαν** *doksan* chwałę [[G1391]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **τιμην** *timēn* szacunek – zaszczyt [[G5092]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **ευχαριστιαν** *eucharistian* dziękczynienie – wdzięczność [[G2169]] WTN-ASF **τω** *tō* [[G3588]] WTT-DSM **καθημενω** *kathēmenō* siedzącemu [[G2521]] WTV-PNP-DSM **επι** *epi* na [[G1909]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronie [[G2362]] [[N-GSM]] **τω** *tō* [[G3588]] WTT-DSM **ζωντι** *zōnti* żyjącemu [[G2198]] WTV-PAP-DSM **εις** *eis* na [[G1519]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **αιωνας** *aiōnas* wieki [[G165]] [[N-APM]] **των** *tōn* [[G3588]] WTT-GPM **αιωνων** *aiōnōn* wieków [[G165]] WTN-GPM
###### **Ap 4,10**
 **πεσουνται** *pesountai* upadną [[G4098]] WTV-FNI-3P **οι** *hoi* [[G3588]] WTT-NPM **εικοσι** *eikosi* dwudziestu [[G1501]] WTA-NPM **και** *kai* i [[G2532]] [[CONJ]] **τεσσαρες** *tessares* czterech [[G5064]] WTA-NPM **πρεσβυτεροι** *presbyteroi* starszych – starców [[G4245]] WTA-NPM **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **καθημενου** *kathēmenou* siedzącym [[G2521]] WTV-PNP-GSM **επι** *epi* na [[G1909]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronie [[G2362]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **προσκυνουσιν** *proskynousin* oddają cześć – kłaniają się [[G4352]] WTV-PAI-3P **τω** *tō* [[G3588]] WTT-DSM **ζωντι** *zōnti* żyjącemu [[G2198]] WTV-PAP-DSM **εις** *eis* na [[G1519]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **αιωνας** *aiōnas* wieki [[G165]] [[N-APM]] **των** *tōn* [[G3588]] WTT-GPM **αιωνων** *aiōnōn* wieków [[G165]] WTN-GPM **και** *kai* i [[G2532]] [[CONJ]] **βαλλουσιν** *ballousin* rzucają [[G906]] WTV-PAI-3P **τους** *tous* [[G3588]] WTT-APM **στεφανους** *stefanous* wieńce – korony [[G4735]] [[N-APM]] **αυτων** *autōn* ich [[G846]] WTP-GPM **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronem [[G2362]] [[N-GSM]] **λεγοντες** *legontes* mówiąc [[G3004]] WTV-PAP-NPM
###### **Ap 4,11**
 **αξιος** *aksios* Godny [[G514]] [[A-NSM]] **ει** *ei* jesteś [[G1488]] WTV-PXI-2S **κυριε** *kyrie* Panie [[G2962]] WTN-VSM **λαβειν** *labein* wziąć [[G2983]] [[V-2AAN]] **την** *tēn* [[G3588]] WTT-ASF **δοξαν** *doksan* chwałę [[G1391]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **τιμην** *timēn* szacunek – zaszczyt [[G5092]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **δυναμιν** *dynamin* moc [[G1411]] WTN-ASF **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **συ** *sy* Ty [[G4771]] WTP-2NS **εκτισας** *ektisas* stworzyłeś [[G2936]] WTV-AAI-2S **τα** *ta* [[G3588]] WTT-APN **παντα** *panta* wszystkie [[G3956]] WTA-APN **και** *kai* i [[G2532]] [[CONJ]] **δια** *dia* przez [[G1223]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **θελημα** *thelēma* wolę [[G2307]] WTN-ASN **σου** *sou* twoją [[G4675]] WTP-2GS **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **και** *kai* i [[G2532]] [[CONJ]] **εκτισθησαν** *ektisthēsan* zostały stworzone [[G2936]] WTV-API-3P
