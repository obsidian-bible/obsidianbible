# Hi 8 BT5
###### **Hi 8,1**
 Wówczas zabrał głos Bildad z Szuach i rzekł:
###### **Hi 8,2**
 «***Jak długo chcesz mówić w ten sposób? Twe słowa gwałtowne jak wicher.***
###### **Hi 8,3**
 ***Czyż Bóg nagina prawo, Wszechmocny zmienia sprawiedliwość?***
###### **Hi 8,4**
 ***A jeśli twe dzieci zgrzeszyły, i wydał On je w moc ich grzechu?***
###### **Hi 8,5**
 ***Jeśli do Boga się zwrócisz, i błagać będziesz Wszechmocnego,***
###### **Hi 8,6**
 ***jeśli jesteś czysty, niewinny, to On zaraz czuwać będzie nad tobą, uczciwy twój dom odbuduje.***
###### **Hi 8,7**
 ***I choć był skromny u ciebie początek, to koniec będzie wspaniały.***
###### **Hi 8,8**
 ***Pytaj dawnych pokoleń, zważ na doświadczenie ich przodków.***
###### **Hi 8,9**
 ***My, wczorajsi, znamy niewiele, bo dni nasze jak cienie na ziemi.***
###### **Hi 8,10**
 ***Czyż oni cię nie pouczą, mówiąc do ciebie, a słowa ich czyż z serc ich nie wypłyną?***
###### **Hi 8,11**
 ***Czyż rośnie papirus bez błota, czy się krzewi sitowie bez wody?***
###### **Hi 8,12**
 ***Jeszcze świeże, niezdatne do ścięcia, wcześniej niż zieleń usycha.***
###### **Hi 8,13**
 ***Takie są drogi niepomnych na Boga, a niegodnego nadzieja przepadnie.***
###### **Hi 8,14**
 ***Ostoja takiego – to babie lato, a jego ufność jak nić pajęczyny.***
###### **Hi 8,15**
 ***Kto się na niej oprze, ten nie ustoi, chwyci się jej, a nie ma oparcia.***
###### **Hi 8,16**
 ***On wprawdzie w słońcu soczysty, jego gałąź wyrasta nad ogród,***
###### **Hi 8,17**
 ***korzenie ma splecione, pośród kamieni on żyje.***
###### **Hi 8,18**
 ***Gdy utniesz go z jego podłoża, ono zaprzeczy: Nie widziałem ciebie.***
###### **Hi 8,19**
 ***Oto jest radość z jego drogi. A z pyłu inni wyrosną.***
###### **Hi 8,20**
  ***Oto Bóg nie odrzuci prawego, ani nie wzmocni ręki złoczyńcy.***
###### **Hi 8,21**
 ***Jeszcze napełni śmiechem twe usta, a twoje wargi okrzykiem wesela.***
###### **Hi 8,22**
 ***Wrogowie okryją się wstydem, przepadną namioty występnych***».
# Hi 8 PAU
###### **Hi 8,1**
 Odezwał się Bildad z Szuach i powiedział:
###### **Hi 8,2**
 „Jak długo jeszcze będziesz tak mówił, a twoje słowa będą jak gwałtowny wicher?
###### **Hi 8,3**
 Czy Bóg nagina prawo, czy Wszechmocny gwałci sprawiedliwość?
###### **Hi 8,4**
 Jeśli twoi synowie wystąpili przeciw Niemu, odda ich w moc ich własnego przewinienia.
###### **Hi 8,5**
 Jeżeli jednak zwrócisz się do Boga i będziesz błagał Wszechmocnego o łaskę,
###### **Hi 8,6**
 jeśli jesteś niewinny i prawy, wtedy On na pewno będzie czuwał nad tobą i odnowi twój dom, bo jesteś sprawiedliwy.
###### **Hi 8,7**
 Choćby twoje poprzednie dobra były niewielkie, późniejsze będą ogromne.
###### **Hi 8,8**
 Zapytaj pokoleń, które były, poznaj doświadczenia ojców!
###### **Hi 8,9**
 Gdyż my jesteśmy zaledwie od wczoraj i nic nie wiemy, a nasze dni na ziemi są jak cienie.
###### **Hi 8,10**
 Oni natomiast na pewno cię pouczą, ich mądrość ci odpowie.
###### **Hi 8,11**
 Czy może papirus rosnąć bez mokradła, a sitowie rozkrzewiać się bez wody?
###### **Hi 8,12**
 Chociaż wypuszcza świeże pędy i nie jest wyrwany, jednak usycha szybciej niż inna trawa.
###### **Hi 8,13**
 Tak dzieje się z każdym, kto zapomina o Bogu, przepadnie nadzieja bezbożnego.
###### **Hi 8,14**
 Krótko trwa to, czemu zawierzył, jego pewność jest jak nić pająka.
###### **Hi 8,15**
 Oparł się o własny dom, lecz upadł, i chociaż się go uchwyci, nie wstanie.
###### **Hi 8,16**
 W świetle słońca bezbożny nabiera tężyzny, jego pędy wychodzą nawet poza ogród.
###### **Hi 8,17**
 Jego korzenie są splątane wśród kamieni, żyje nawet na skalnym podłożu.
###### **Hi 8,18**
 Kiedy jednak zostanie wycięty ze swojego miejsca, ono się go wyprze: «Nigdy cię nie widziałem!».
###### **Hi 8,19**
 Do takiego to szczęśliwego końca wiedzie jego droga, a z tego samego prochu wyrastają następni.
###### **Hi 8,20**
 Naprawdę, Bóg nie odrzuca niewinnego ani nie wspiera złoczyńców.
###### **Hi 8,21**
 Jeszcze twe usta napełni śmiechem, a twoim wargom każe wołać radośnie.
###### **Hi 8,22**
 Twoi wrogowie natomiast okryją się hańbą, rozpadnie się namiot bezbożnych”.
# Hi 8 BP
###### **Hi 8,1**
 Bildad z Szuach zabrał głos i powiedział:
###### **Hi 8,2**
 Dokądże jeszcze będziesz mówił w ten sposób, a słowa ust twoich będą jak gwałtowny wicher?
###### **Hi 8,3**
 Czyżby Bóg miał zmienić prawo a Wszechmogący wypaczać sprawiedliwość?
###### **Hi 8,4**
 Jeśli synowie twoi zgrzeszyli przeciw Niemu, On ich wydał w ręce ich nieprawości.
###### **Hi 8,5**
 Jeśli zaś ty będziesz prosił Boga, jeśli będziesz błagał Wszechmocnego,
###### **Hi 8,6**
 jeśli niewinny jesteś i prawy, wówczas wejrzy On wkrótce na ciebie i odbuduje dom twej sprawiedliwości.
###### **Hi 8,7**
 Dawny twój dobrobyt okaże się nieznaczny wobec wspaniałości tego, który ciebie czeka.
###### **Hi 8,8**
 Zapytaj pokoleń, które przeminęły, i rozważ doświadczenie ojców twoich.
###### **Hi 8,9**
 My bowiem jesteśmy wczorajsi i nie wiemy nic; jak cień są dni nasze na ziemi.
###### **Hi 8,10**
 Oni cię pouczą i powiedzą tobie, z serca ich popłyną słowa:
###### **Hi 8,11**
 Czyż papirus wyrośnie poza mokradłem albo roślina jakaś czy bez wody się rozwinie?
###### **Hi 8,12**
 Jeśli jest w pełni rozwoju, niezdatna do ścięcia, a [jednak] prędzej uschnie niż wszelka inna trawa.
###### **Hi 8,13**
 Taki jest los tych, którzy o Bogu zapominają, tak zginie nadzieja bezbożnego.
###### **Hi 8,14**
 Jego nadzieja trwa krótko, a bezpieczeństwo jak sieć pajęcza.
###### **Hi 8,15**
 Oprze się o dom swój, ale się nie ostoi, uchwyci się go, ale on runie.
###### **Hi 8,16**
 Nasycony wilgocią nim słońce wzejdzie, ponad ogród rozpościera pędy,
###### **Hi 8,17**
 między kamienie zapuszcza swe korzenie i na skałach utrzymuje się przy życiu.
###### **Hi 8,18**
 Ale gdy go wytną z jego miejsca, wyrzeka się go to [miejsce]: "Nigdym ciebie nie widziało".
###### **Hi 8,19**
 Takie oto jest szczęście jego drogi, a z prochu wyrastają inni.
###### **Hi 8,20**
 O nie, Bóg niewinnego nie odrzuca ani na ręce nie trzyma bezbożnego.
###### **Hi 8,21**
 Usta twoje napełni uśmiechem, a wargi - okrzykiem radości.
###### **Hi 8,22**
 Nieprzyjaciele twoi okryją się hańbą, a namiot szyderców przepadnie.
# Hi 8 BR
###### **Hi 8,1**
 Wtedy zabrał głos Bildad z Szuach i tak powiedział:
###### **Hi 8,2**
 Jak długo jeszcze będziesz mówił w ten sposób? Przecież od wichru gwałtowniejsze twe słowa.
###### **Hi 8,3**
 Czy Bóg zmienia swoje prawa, a Wszechmocny łamie sprawiedliwość?
###### **Hi 8,4**
 Skoro synowie twoi zgrzeszyli, to wydał ich na pastwę ich grzechów.
###### **Hi 8,5**
 Jeżeli naprawdę szukasz Boga, to powinieneś z płaczem pójść do Wszechmocnego.
###### **Hi 8,6**
 Jeśliś czysty i prawy, to będzie cię miał w swojej opiece, dom twój jak trzeba naprawi.
###### **Hi 8,7**
 A wtedy, choćby skromny był twój początek, wielki będzie twój koniec.
###### **Hi 8,8**
 Spójrz tylko na drogę minionych pokoleń i korzystaj z doświadczeń twoich ojców!
###### **Hi 8,9**
 Bo my jesteśmy dopiero od wczoraj i wiemy tak mało, a dni nasze to jakby ledwie cień na ziemi.
###### **Hi 8,10**
 Czyż nie są dla ciebie pouczeniem, czy nie przemawiają do ciebie doświadczenia ojców?
###### **Hi 8,11**
 Czy papirus rośnie tam, gdzie nie ma błota? A czy sitowie rozpleni się bez wody?
###### **Hi 8,12**
 Zaledwie zakwitnie, jeszcze nie dojrzeje, a już usycha, wcześniej niż trawa.
###### **Hi 8,13**
 Tak też kończą ci, co nie zważają na Boga, a nadzieje bezbożnych są zawsze daremne.
###### **Hi 8,14**
 Jak nić pajęcza są ich marzenia, a ich pewność nie ma oparcia.
###### **Hi 8,15**
 Nie ostoi się wsparty na własnym domu, nawet uczepiwszy się go, spadnie.
###### **Hi 8,16**
 W słońcu wygląda jakby pełen świeżości, a w ogrodzie wydaje bujne pędy,
###### **Hi 8,17**
 zapuszcza korzenie w bezwodnym piasku i trzyma się mocno nawet wśród kamieni.
###### **Hi 8,18**
 Lecz Bóg odcina go od jego podłoża, a ono powie, że nigdy go nie znało.
###### **Hi 8,19**
 I tyle radości zazna na swojej drodze, a z prochu ziemi już inny wyrasta.
###### **Hi 8,20**
 Bóg nigdy nie odrzuca prawego, ale też nie podtrzymuje ręki niegodziwca.
###### **Hi 8,21**
 Twoją twarz rozpromieni uśmiechem, twoje usta napełni radością.
###### **Hi 8,22**
 Twoich wrogów zaś hańba okryje, a obóz występnych nie ostoi się długo.
# Hi 8 WUJ
###### **Hi 8,1**
 A odpowiadając Baldad Suhites, rzekł:
###### **Hi 8,2**
 I pokądże takowe rzeczy mówić będziesz, a duch rozliczny mowy ust twoich?
###### **Hi 8,3**
 Aza Bóg podchodzi sąd? abo wszechmogący wywraca sprawiedliwość?
###### **Hi 8,4**
 Chociaż synowie twoi zgrzeszyli jemu, i opuścił je w ręce nieprawości ich.
###### **Hi 8,5**
 Wszakże ty, jeśli rano wstaniesz do Boga, a będziesz się modlił wszechmocnemu:
###### **Hi 8,6**
 Jeśli czystym i prostym będziesz chodził, zaraz ocuci ku tobie, i spokojne uczyni mieszkanie sprawiedliwości twojej.
###### **Hi 8,7**
 Tak dalece, iż jeśli początki twoje były małe, i ostatki twoje rozmnożą się wielce.
###### **Hi 8,8**
 Pytaj się bowiem starego wieku, i dowiaduj się pilnie pamięci ojców.
###### **Hi 8,9**
 (Wczorajszy bowiem jesteśmy, i nie wiemy, że dni nasze, na ziemi są jako cień).
###### **Hi 8,10**
 A oni cię nauczą: będąć mówić, i z serca swego wypuszczą wymowy.
###### **Hi 8,11**
 Aza się może zielenić sitowie bez wilgotności? abo rogozie urość bez wody?
###### **Hi 8,12**
 Gdy jeszcze jest w kwieciu, ani go ręką urwą, przed wszystkiem zieleni usycha.
###### **Hi 8,13**
 Tak drogi wszystkich, którzy zapominają Boga, i nadzieja obłudnika zginie:
###### **Hi 8,14**
 Nie upodoba mu się głupstwo jego, a jako pajęcza siatka ufanie jego.
###### **Hi 8,15**
 Będzie się podpierał domu swego a nie ostoi się: będzie ji podpierał, a nie powstanie:
###### **Hi 8,16**
 Zda się wilgotnym niźli wznidzie słońce, a na wschodzie jego wynidzie latorosłka jego.
###### **Hi 8,17**
 Na gromadzie kamienia zagęści się korzenie jego, i między kamieńmi mieszkać będzie.
###### **Hi 8,18**
 Jeśli go pożrze z miejsca swego, zaprze się go, i rzecze: Nie znam cię.
###### **Hi 8,19**
 Abowiem to jest wesele drogi jego, aby zaś z ziemie inni się puścili.
###### **Hi 8,20**
 Bóg nie odrzuci prostego, ani poda ręki złośnikom:
###### **Hi 8,21**
 Aż się napełnią śmiechu usta twoje, a wargi twe wykrzykania.
###### **Hi 8,22**
 Którzy cię mają w nienawiści, obleczeni będą wstydem, przybytek niezbożnych nie będzie.
