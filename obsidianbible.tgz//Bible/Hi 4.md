# Hi 4 BT5
###### **Hi 4,1**
 Wówczas zabrał głos Elifaz z Temanu i rzekł:
###### **Hi 4,2**
 «***Usiłuje się omówić [sprawę]. Przykrość ci to sprawia? Lecz któż się od słów powstrzyma?***
###### **Hi 4,3**
 ***Tyś przecież wielu pouczał, wzmacniałeś omdlałe ręce,***
###### **Hi 4,4**
 ***twe słowa krzepiły słabych, umacniałeś chwiejące się kolana.***
###### **Hi 4,5**
 ***Gdy teraz przyszło na ciebie, tyś słaby, strwożony, gdy ciebie dotknęło.***
###### **Hi 4,6**
 ***Czy bogobojność już nie jest twą ufnością, a nadzieją – doskonałość dróg twoich?***
###### **Hi 4,7**
 ***Przypomnij, czy zginął ktoś prawy? Gdzie sprawiedliwych zgładzono?***
###### **Hi 4,8**
 ***O ile widziałem, złoczyńcy, co sieją udrękę, plon z niej zbierają:***
###### **Hi 4,9**
 ***Od gniewu Boga zginęli, upadli od tchnienia Jego zapalczywości.***
###### **Hi 4,10**
 ***Ryk lwa, wrzask lwicy, łamią się i zęby lwiątek;***
###### **Hi 4,11**
 ***lew ginie z braku łupu, a małe lwicy idą w rozsypkę.***
###### **Hi 4,12**
 ***Doszło mnie tajemne słowo, jego szmer dosłyszało me ucho,***
###### **Hi 4,13**
 ***gdy rozważałem nocne widziadła; gdy sen człowiekiem owładnął.***
###### **Hi 4,14**
 ***Strach mnie ogarnął i drżenie, że wszystkie się kości zatrzęsły,***
###### **Hi 4,15**
 ***tchnienie mi twarz owionęło, włosy się na mnie zjeżyły.***
###### **Hi 4,16**
 ***Stał. Nie poznałem twarzy. Jakaś postać przed mymi oczami. Szelest. I głos dosłyszałem:***
###### **Hi 4,17**
 ***Czyż u Boga człowiek jest niewinny, czy u Stwórcy śmiertelnik jest czysty?***
###### **Hi 4,18**
 ***Wszak On sługom swoim nie ufa: i w aniołach braki dostrzega.***
###### **Hi 4,19**
 ***A cóż mieszkańcy glinianych lepianek, osadzonych na mule? Łatwiej ich zgnieść niż mola.***
###### **Hi 4,20**
 ***Od rana do zmroku wyginą, bez sławy przepadną na wieki.***
###### **Hi 4,21**
 ***Czyż nie zerwą się liny ich [namiotów]? Umrą, lecz nie w mądrości.***
# Hi 4 PAU
###### **Hi 4,1**
 Odezwał się Elifaz z Temanu i powiedział:
###### **Hi 4,2**
 „Słowo pewnie sprawi ci przykrość, ale któż mógłby się od niego powstrzymać?
###### **Hi 4,3**
 Otóż ty kiedyś pomagałeś wielu, dodawałeś otuchy załamanym.
###### **Hi 4,4**
 Gdy ktoś się chwiał, podtrzymywały go twoje słowa, wzmacniałeś uginające się kolana.
###### **Hi 4,5**
 Teraz sam uległeś słabości i gdy cię dotknęła, załamałeś się.
###### **Hi 4,6**
 Czy twoja pobożność nie jest dla ciebie ostoją, a prawość twojego postępowania nadzieją?
###### **Hi 4,7**
 Przypomnij tylko sobie: Czy kiedykolwiek zginął ktoś niewinny? Czy gdziekolwiek giną ludzie prawi?
###### **Hi 4,8**
 Widziałem takich, którzy czynili nieprawość, siali ucisk i go zbierali.
###### **Hi 4,9**
 Zostali powaleni oddechem Boga, zginęli pod naporem Jego gniewu.
###### **Hi 4,10**
 Choć ryczy lew i słychać pomruk lwicy, wypadną zęby drapieżcy.
###### **Hi 4,11**
 Lew ginie z braku łupu i rozproszone jest jego potomstwo.
###### **Hi 4,12**
 Ukradkiem doszło do mnie słowo, moje ucho uchwyciło szmer.
###### **Hi 4,13**
 W czasie sennych marzeń, gdy tłoczą się myśli, kiedy twardy sen ogarnia ludzi,
###### **Hi 4,14**
 strach i lęk mnie opanowały, aż z przerażenia zadrżałem na całym ciele.
###### **Hi 4,15**
 Lekki powiew przeszedł po mojej twarzy, włosy zjeżyły mi się na głowie.
###### **Hi 4,16**
 Ktoś stał, ale jego twarzy nie rozpoznałem, jakaś postać tkwiła przed moimi oczami; wokoło cisza, potem słyszałem głos:
###### **Hi 4,17**
 «Czy człowiek może być uznany przez Boga za doskonale prawego? Czy Stwórca może uznać człowieka za stworzenie bez skazy?».
###### **Hi 4,18**
 Przecież On nie dowierza nawet swoim sługom i swoim posłańcom ukazuje ich braki.
###### **Hi 4,19**
 Cóż więc mówić o mieszkańcach lepianek z gliny, osadzonych na piasku, które można rozgnieść jak mola?
###### **Hi 4,20**
 Między rankiem a wieczorem ulegną zagładzie, przepadną na zawsze i nikt ich nie wspomni.
###### **Hi 4,21**
 Na końcu przerwie się sznur ich namiotu i umrą bez osiągnięcia mądrości.
# Hi 4 BP
###### **Hi 4,1**
 Na to wstał Elifaz z Temanu i powiedział:
###### **Hi 4,2**
 Jeśli przemówimy do Ciebie, nie będzi ci przykro? Lecz któż może powstrzymać słowa?
###### **Hi 4,3**
 Oto pouczałeś wielu, ręce słabe wzmacniałeś,
###### **Hi 4,4**
 mowa twoja pokrzepiała chwiejnych, umacniałeś uginające się kolana.
###### **Hi 4,5**
 A teraz, gdy utrapienie przyszło na ciebie, tracisz cierpliwość, dotknęło ciebie i wpadasz w zwątpienie.
###### **Hi 4,6**
 Czy pobożność twoja nie dodaje ci ufności, a prawość dróg twoich nie napełnia cię otuchą?
###### **Hi 4,7**
 Przypomnij sobie: któryż to z niewinnych zginął i gdzie to sprawiedliwi ulegli zagładzie?
###### **Hi 4,8**
 Widziałem takich, co zło czynili, siali nieprawość i zbierali ją,
###### **Hi 4,9**
 zginęli od tchnienia Bożego i od powiewu gniewu jego zniszczeli.
###### **Hi 4,10**
 Ryk lwa i wycie dzikiego zwierza [ustanie] a zęby młodych lwiątek zostaną starte;
###### **Hi 4,11**
 lew ginie z braku łupu, a małe lwiątka się rozpraszają.
###### **Hi 4,12**
 Oto ukradkiem doleciało do mnie słowo, cichy szmer jego pochwyciło ucho moje.
###### **Hi 4,13**
 Przy rozważaniu nocnych widzeń, gdy ludzi twardy sen ogarnia,
###### **Hi 4,14**
 opanowały mnie lęk i trwoga, tak że od strachu drżały wszystkie kości moje.
###### **Hi 4,15**
 Jakieś tchnienie przeszło po mej twarzy, podnosząc włosy na mym ciele.
###### **Hi 4,16**
 Ktoś stał, nie poznałem jego oblicza, jakaś postać stała mi przed oczyma. Cisza - potem usłyszałem głos:
###### **Hi 4,17**
 Czy człowiek może być sprawiedliwy wobec Boga albo śmiertelnik czysty wobec swego Stwórcy?
###### **Hi 4,18**
 Jeśli On sługom swoim nie ufa i aniołom swoim przypisuje braki,
###### **Hi 4,19**
 to cóż tu mówić o mieszkańcach domów z gliny, których fundamenty są zbudowane na piasku. Łatwiej ich rozgnieść niż mola.
###### **Hi 4,20**
 Od poranka do wieczora zginą, nikt się o nich nie zatroszczy, przepadną na wieki.
###### **Hi 4,21**
 Czyż lina ich namiotu nie jest przecięta? Umrą, nie posiadłszy mądrości.
# Hi 4 BR
###### **Hi 4,1**
 Odezwał się wtedy Elifaz z Temanu i powiedział:
###### **Hi 4,2**
 Czy zniesiesz słowa, które ci powiem? Ale czy można dłużej trwać w milczeniu?
###### **Hi 4,3**
 Ty sam przecież pouczałeś tak wielu i umacniałeś już omdlałe ręce.
###### **Hi 4,4**
 Tych, co się chwiali, krzepiły twe słowa, kolanom, co się gięły, dodawałeś siły.
###### **Hi 4,5**
 Teraz sam się uginasz, gdy na ciebie to spadło, tyś sam przerażony, gdy ciebie dotknęło.
###### **Hi 4,6**
 Przestałeś już polegać na bojaźni Bożej nie pokładasz nadziei we własnej prawości?
###### **Hi 4,7**
 Wiesz przecież, że nie giną niewinni i nikt nie zabija sprawiedliwych.
###### **Hi 4,8**
 Gdzie spojrzę, widzę, że zło zbiera ten, co źle czyni, sieje nienawiść.
###### **Hi 4,9**
 Giną tacy od Bożego tchnienia, unicestwia ich Boże zagniewanie.
###### **Hi 4,10**
 Lwy ryczą groźnie, zawodzą lwice, kruszą się zęby lwiątek.
###### **Hi 4,11**
 Stare lwy giną pozbawione łupu, bezradnie się błąkają rozproszone lwiątka.
###### **Hi 4,12**
 A do mnie gdy doszły słowa objawienia i trafiły do moich uszu,
###### **Hi 4,13**
 gdy rozmyślałem w głębi nocnej ciszy, a ludzie byli we śnie pogrążeni.
###### **Hi 4,14**
 Strach mnie ogarnął i drżenie i trzęsły się wszystkie moje kości.
###### **Hi 4,15**
 Powiało czymś po moim obliczu i zjeżyły się moje włosy.
###### **Hi 4,16**
 Nie mogłem rozpoznać: ktoś stał przede mną. Miałem przed oczyma jakąś postać, która przemówiła:
###### **Hi 4,17**
 Czy jest ktoś sprawiedliwy w oczach Boga? Czy jest niewinny przed Stwórcy obliczem?
###### **Hi 4,18**
 Nie ufa On nawet swoim sługom, nie uważa za świętych nawet aniołów.
###### **Hi 4,19**
 A cóż dopiero mieszkańcy lepianek, zbudowanych na lotnym piasku? Zmiażdżyć ich łatwiej niż mola.
###### **Hi 4,20**
 Od rana do wieczora będą nękani i niepostrzeżenie wyginą bez reszty.
###### **Hi 4,21**
 Będzie zniszczony ich namiot, a oni zginą, bo nie byli mądrzy.
# Hi 4 WUJ
###### **Hi 4,1**
 A odpowiadając Eliphas Themanitczyk rzekł:
###### **Hi 4,2**
 Jeśli poczniemy mówić do ciebie, podobnoć nie miło będzie, ale umyśloną mowę kto zatrzymać może?
###### **Hi 4,3**
 Otoś ich wiele uczył i potwierdzałeś ręce spracowane.
###### **Hi 4,4**
 Chwiejące się umacniały twe mowy, a kolana drżące posilałeś.
###### **Hi 4,5**
 A teraz przyszła na cię plaga, i ustałeś: dotknęła cię i strwożyłeś się.
###### **Hi 4,6**
 Gdzież jest bojaźń twoja, mocność twoja, cierpliwość twoja i doskonałość dróg twoich?
###### **Hi 4,7**
 Wspomni, proszę cię, kto kiedy niewinny zginął, abo kiedy prości zgładzeni są?
###### **Hi 4,8**
 I owszem widziałem te, którzy czynią nieprawość, i sieją boleści, i żną je,
###### **Hi 4,9**
 Że za dmuchnieniem Bożem zginęli, i duchem gniewu jego zniszczeli.
###### **Hi 4,10**
 Ryk lwi, i głos lwice, i zęby lwich szczeniąt skruszone są.
###### **Hi 4,11**
 Tygrys zginął, iż nie miał łupu, i szczenięta lwie rozproszyły się.
###### **Hi 4,12**
 Ale do mnie rzeczone jest słowo skryte, a jakoby ukradkiem przyjęło ucho moje żyły szeptania jego.
###### **Hi 4,13**
 W okropności widzenia nocnego, gdy sen na ludzie zwykł przypadać.
###### **Hi 4,14**
 Zjął mię strach i drżenie, i wszystkie kości moje przestraszone są.
###### **Hi 4,15**
 A gdy duch szedł przy bytności mojej, wstały włosy ciała mego.
###### **Hi 4,16**
 Stanął ktoś, któregom twarzy nie znał, wyobrażenie przed oczyma memi, i słyszałem głos jako wiatru cichego.
###### **Hi 4,17**
 Aza człowiek Bogu przyrównany będzie usprawiedliwion, abo mąż będzie czystszy niż stworzyciel jego?
###### **Hi 4,18**
 Oto ci którzy mu służą, nie są stali, i w Aniołach swoich nalazł nieprawość:
###### **Hi 4,19**
 Jakoż daleko więcej ci którzy mieszkają w domiech glinianych, którzy mają grunt ziemny, będą jako od mola zepsowani.
###### **Hi 4,20**
 Od poranku aż do wieczora będą wycięci, a iż żaden nie rozumie, na wieki zginą.
###### **Hi 4,21**
 A którzy zostaną, odjęci będą z nich: pomrą, a nie w mądrości.
