# Ez 6 BT5
###### **Ez 6,1**
 Pan skierował do mnie to słowo:
###### **Ez 6,2**
 «***Synu człowieczy, zwróć się ku górom izraelskim i prorokuj przeciwko nim.***
###### **Ez 6,3**
 ***Powiedz: Wzgórza izraelskie, słuchajcie słowa Pana Boga. Tak mówi Pan Bóg do wzgórz, do pagórków, do strumieni i do dolin: Oto sprowadzę na was miecz i zniszczę wasze wyżyny.***
###### **Ez 6,4**
 ***Wasze ołtarze opustoszeją, a wasze stele słoneczne zostaną rozbite; waszych poległych rzucę przed bożków.***
###### **Ez 6,5**
 ***< Trupy synów Izraela położę przed waszymi bożkami >, kości ich porozrzucam wokół waszych ołtarzy.***
###### **Ez 6,6**
 ***Gdziekolwiek byście mieszkali, miasta opustoszeją, a wyżyny zniszczeją, tak że wasze ołtarze zostaną opuszczone i zniszczone, bożki wasze zdruzgotane i porozbijane, a wasze stele słoneczne połamane w kawałki i dzieła wasze unicestwione.***
###### **Ez 6,7**
 ***Pośrodku was padną polegli i poznacie, że Ja jestem Pan.***
###### **Ez 6,8**
 ***Ale pozostawię wam przy życiu tych, którzy ujdą miecza pogan, gdy rozproszę was po obcych krajach.***
###### **Ez 6,9**
 ***Ci, którzy pozostaną przy życiu, będą pamiętali o Mnie pośród obcych narodów, dokąd zostaną uprowadzeni. Gdy złamię ich serca wiarołomne, które Mnie opuściły, i oczy ich nierządne, rozglądające się za bożkami, wtedy poczują odrazę do samych siebie z powodu zła, które popełnili wszystkimi swoimi obrzydliwościami.***
###### **Ez 6,10**
 ***I poznają, że Ja jestem Pan i że nie na próżno mówiłem, iż na nich sprowadzę to nieszczęście***».
###### **Ez 6,11**
 Tak mówi Pan: «***Klaskaj w dłonie i tup nogą, i wołaj: Biada z powodu wszystkich obrzydliwości domu Izraela, który padnie od miecza, głodu i zarazy.***
###### **Ez 6,12**
 ***Ten, co jest daleko, umrze od zarazy; ten, co jest blisko, polegnie od miecza, a ten, co pozostanie i będzie oblegany, umrze z głodu. I tak uśmierzę na nich mój gniew.***
###### **Ez 6,13**
 ***Poznacie, że Ja jestem Pan, gdy wasi zabici będą leżeli pokotem u stóp swoich bożków, wokół ich ołtarzy, na każdym pagórku, na wszystkich szczytach gór, pod każdym drzewem zielonym i pod każdym rozłożystym terebintem, gdzie składali ofiarę o miłej woni wszystkim swoim bożkom.***
###### **Ez 6,14**
 ***Wyciągnę rękę przeciwko nim i zamienię kraj ten w ziemię pustą i dziką, począwszy od pustyni aż do Ribla, wszędzie, gdzie mieszkają. I poznają, że Ja jestem Pan***».
# Ez 6 PAU
###### **Ez 6,1**
 PAN znowu przemówił do mnie w następujących słowach:
###### **Ez 6,2**
 „Synu człowieczy, zwróć się w stronę gór Izraela, prorokuj przeciwko nim i
###### **Ez 6,3**
 powiedz: Góry Izraela, słuchajcie słowa PANA BOGA. Tak mówi PAN BÓG do gór i pagórków, do potoków i dolin. Oto Ja sprowadzę na was miecz i zniszczę wasze wzniesienia kultowe.
###### **Ez 6,4**
 Wasze ołtarze będą zburzone, wasze stele połamane, a waszych pomordowanych powalę przed waszymi bożkami.
###### **Ez 6,5**
 Trupy Izraelitów położę przed ich bożkami i rozrzucę wasze kości wokół waszych ołtarzy.
###### **Ez 6,6**
 Gdziekolwiek mieszkacie, miasta zostaną zburzone, wzniesienia kultowe spustoszone. Wasze ołtarze będą zburzone i zniszczone, wasze bożki połamane i usunięte, wasze stele wycięte, a dzieła rąk waszych starte.
###### **Ez 6,7**
 Pomordowani padną pośród was i przekonacie się, że Ja jestem PANEM.
###### **Ez 6,8**
 Ale pozostawię wam ocalałych od miecza wśród narodów, gdy będziecie rozproszeni po obcych krajach.
###### **Ez 6,9**
 Ci, którzy ocaleją pośród narodów, dokąd zostali uprowadzeni, przypomną sobie o Mnie, o mojej udręce z powodu ich cudzołożnego serca, które odstąpiło ode Mnie, oraz z powodu ich cudzołożnych oczu, które oglądały się za bożkami. Będą się brzydzić sobą z powodu zła, które popełnili, i z powodu wszystkich swoich obrzydliwości.
###### **Ez 6,10**
 I przekonają się, że Ja, PAN, nie na darmo mówiłem, że sprowadzę na nich nieszczęście.
###### **Ez 6,11**
 Tak mówi PAN BÓG: Klaśnij w dłonie, tupnij nogą i mów: Biada wszystkim obrzydliwościom ludu izraelskiego, który padnie od miecza, głodu i zarazy.
###### **Ez 6,12**
 Kto będzie daleko, umrze od zarazy. Kto będzie blisko, padnie od miecza, a kto pozostanie i będzie zamknięty, umrze z głodu. Tak wyładuję na nich mój gniew.
###### **Ez 6,13**
 I przekonacie się, że Ja jestem PANEM, gdy ich pomordowani będą między swoimi bożkami, wokół swoich ołtarzy, na każdym wyniosłym wzgórzu, na wszystkich szczytach górskich, pod każdym drzewem zielonym, pod każdym rozłożystym dębem, w miejscu, gdzie składali kojące wonności na cześć swoich bożków.
###### **Ez 6,14**
 Podniosę na nich rękę, ich kraj uczynię ruiną i pustkowiem - od pustyni aż po Riblę - gdziekolwiek mieszkają. I przekonają się, że Ja jestem PANEM”.
# Ez 6 BP
###### **Ez 6,1**
 Jahwe przemówił do mnie w te słowa:
###### **Ez 6,2**
 Synu człowieczy, zwróć swoje oblicze ku górom Izraela, prorokuj im
###### **Ez 6,3**
 i mów: Góry Izraela, słuchajcie słowa Pana, Jahwe. Tak mówi Pan, Jahwe, do gór i pagórków, do potoków i dolin. Oto Ja sprowadzę na was miecz i zniszczę wasze wyżyny.
###### **Ez 6,4**
 Wasze ołtarze będą zburzone, wasze stele zostaną połamane, a [ciała] waszych pomordowanych rozłożę przed waszymi bałwanami.
###### **Ez 6,5**
 Trupy synów Izraela pokładę przed ich bałwanami, a kości wasze rozrzucę wokół waszych ołtarzy.
###### **Ez 6,6**
 Zburzone będą miasta wszędzie, gdzie mieszkacie, wyżyny spustoszone, aby ołtarze wasze były zdruzgotane i żeby zniszczały, by wasze bożki zostały połamane i przestały istnieć, aby wasze stele zostały wycięte, a dzieła [rąk] waszych zniszczone.
###### **Ez 6,7**
 Pomordowani legną pośród was i poznacie, że Ja jestem Jahwe.
###### **Ez 6,8**
 Wszakże pozostawię [Resztę], gdy będziecie mieć niedobitków miecza między narodami, gdy będziecie rozproszeni po różnych krajach.
###### **Ez 6,9**
 Niedobitki wasze pośród narodów, tam, dokąd zostali uprowadzeni, wspomną na mnie, że skruszyłem ich cudzołożne serce, które odstąpiło ode mnie, ich oczy, które sprzeniewierzały się z ich bożkami. Poczują obrzydzenie do siebie samych z powodu zła, które popełniali przez wszystkie swe obrzydliwości.
###### **Ez 6,10**
 I poznają, iż Ja, Jahwe, nie na próżno groziłem, iż spuszczę na nich to nieszczęście.
###### **Ez 6,11**
 Tak mówi Pan, Jahwe: Klaśnij w swe dłonie, tupnij swą nogą i wołaj: Ach! z powodu wszystkich niecnych obrzydliwości Domu Izraela, bo padną od miecza, od głodu i od zarazy.
###### **Ez 6,12**
 Kto będzie daleko, umrze od zarazy; kto będzie blisko, padnie od miecza, a kto się ostoi i będzie oblężony, zginie z głodu. Tak wywrę na nich swą złość.
###### **Ez 6,13**
 I dowiecie się, że Ja jestem Jahwe, gdy ich pomordowani znajdą się między swymi bożkami, wokół swych ołtarzy, na każdym wyniosłym wzgórzu, na wszystkich szczytach górskich, pod każdym drzewem zielonym, pod każdym rozłożystym terebintem, wszędzie gdzie składali wonność [ofiary] błagalnej wszystkim swym bożkom.
###### **Ez 6,14**
 Wyciągnę moją rękę przeciw nim i zamienię kraj w ruinę i pustkowie, od pustyni aż po Ribla, wszędzie gdzie będą ich osiedla. I poznają, że Ja jestem Jahwe.
# Ez 6 BR
###### **Ez 6,1**
 Pan powiedział do mnie:
###### **Ez 6,2**
 Synu człowieczy, zwróć swoje oblicze w stronę gór izraelskich i zacznij do nich przemawiać jako prorok.
###### **Ez 6,3**
 Powiedz im tak: Góry izraelskie, posłuchajcie słowa Pana Boga. Oto, co mówi Bóg i Pan do szczytów górskich i wzniesień, do rozpadlin i polan. Ja sam dobędę przeciwko wam mego miecza i zniszczę wszystkie wasze sanktuaria.
###### **Ez 6,4**
 Zostaną zburzone wasze ołtarze, połamane będą stoły do kadzideł, a waszych poległych Ja sam rzucę przed wasze bożki.
###### **Ez 6,5**
 Ciała Izraelitów ułożę u stóp waszych bożków, a kości zabitych porozrzucam wokół waszych ołtarzy.
###### **Ez 6,6**
 Wszędzie, gdzie teraz mieszkacie, będą spustoszone wasze miasta, zniszczone zostaną miejsca kultu na wyżynach. Muszą bowiem być poniszczone i połamane wasze ołtarze; porozbijane będą porozrzucane wasze bóstwa, nic nie pozostanie ze stołów do kadzideł ani z dzieł rąk waszych.
###### **Ez 6,7**
 Pośrodku was leżeć będą ciała waszych poległych. Wtedy przekonacie się, że Ja jestem Panem.
###### **Ez 6,8**
 A kiedy już zostaniecie rozproszeni po wszystkich krajach, niewielkiej reszcie z was pozwolę przetrwać. Pośród ludów pogańskich niektórym z was uda się uniknąć miecza.
###### **Ez 6,9**
 Otóż ci, co pozostaną przy życiu, będą pamiętać o Mnie wśród narodów, między którymi zostaną rozproszeni. Zetrę bowiem na proch ich serca, tak mi niewierne, zamknę ich oczy, które tak wiarołomnie rozglądały się za cudzymi bogami. Wtedy do samych siebie poczuję odrazę z powodu nieprawości, których się dopuszczali.
###### **Ez 6,10**
 I przekonają się, że Ja jestem Panem i że nie na próżno przestrzegałem ich, że sprowadzę na nich to nieszczęście.
###### **Ez 6,11**
 Tak mówi Pan Bóg: Zacznij klaskać w dłonie, tupać nogami i krzyczeć! Biada całemu Domowi Izraela z powodu wszystkich jego niegodziwości! Wskutek tych występków wszyscy wyginą od miecza, z głodu i zarazy.
###### **Ez 6,12**
 Kto jest daleko, zginie od zarazy, kto blisko - padnie od miecza. Reszta, pozostała przy życiu, wymrze z głodu. Tak oto wyleję na nich moje zagniewanie.
###### **Ez 6,13**
 Gdy wasi zabici będą leżeli między posągami bożków wszędzie - wokół ich ołtarzy, na wszystkich wzgórzach i wyżynach, pod każdym zielonym drzewem, pod każdym rozłożystym dębem oraz tam, gdzie się wznosiła dzięki wam woń miła na część ich bogów - wtedy przekonacie się, że Ja jestem Panem.
###### **Ez 6,14**
 Wyciągam przeciw wam moją rękę i kraj wasz w pustynię zamieniam, poczynając od stepów aż po Riblę, wszystkie zamieszkałe przez was okolice. I wtedy przekonacie się, że Ja jestem Panem.
# Ez 6 WUJ
###### **Ez 6,1**
 I stała się mowa Pańska do mnie, rzekąc:
###### **Ez 6,2**
 Synu człowieczy, obróć oblicze twoje ku górom Izraelskim, a prorokować będziesz na nie,
###### **Ez 6,3**
 I rzeczesz: Góry Izraelskie słuchajcie słowa Pana Boga: To mów Pan Bóg góram i pagórkom, skałam, i dolinam: Oto ja przywiodę na was miecz, i wytracę wyżyny wasze.
###### **Ez 6,4**
 I rozwalę ołtarze wasze, będą połamane bałwany wasze: i porzucę pobite wasze przed bałwany waszemi.
###### **Ez 6,5**
 I dam trupy synów Izraelowych przed bałwany waszemi: a rozrucę kości wasze około ołtarzów waszych,
###### **Ez 6,6**
 We wszech mieszkaniach waszych. Miasta spustoszone będą, a wyżyny zburzone i rozwalone: i zaginą ołtarze wasze, i połamane będą, i ustaną bałwany wasze, i skruszone będą zbory wasze, i wygładzone będą dzieła wasze.
###### **Ez 6,7**
 I padnie zabity w pośrodku was: i dowiecie się, żem ja Pan.
###### **Ez 6,8**
 A pozostawię z was te, którzy ujdą miecza między narody, gdy was rozproszę po ziemiach.
###### **Ez 6,9**
 I wspomnią na mię wyzwoleni waszy, między narodami, do których więźnie są zagnani; żem skruszył serce ich cudzołożące, i odstępujące odemnie: i oczy ich cudzołożące za bałwany swemi: i omierzną sami sobie dla złości, które czynili wszelakiemi brzydkościami swemi.
###### **Ez 6,10**
 I doznają, że ja Pan nie próżnom mówił, żem im to złe miał uczynić.
###### **Ez 6,11**
 To mówi Pan Bóg: Uderz rękę twoję, a przytrąć nogę twoję, i mów: Ach na wszystkie obrzydłości złych domu Izraelowego: bo od miecza, od głodu i od moru polegą.
###### **Ez 6,12**
 Kto daleko jest, morem umrze: a kto blizko, od miecza upadnie: a kto pozostanie i oblężon będzie, głodem umrze: i wykonam rozgniewanie moje na nich.
###### **Ez 6,13**
 A doznacie, żem ja Pan, gdy będą pobici waszy między bałwanami waszemi około ołtarzów waszych, na wszelkim pagórku wysokim, i po wszech wierzchach górnych, i pod każdem drzewem gaistem, i pod wszelkiem dębem gałęzistym, na miejscu, gdzie palili kadzidła wonne wszem bałwanom swym.
###### **Ez 6,14**
 I wyciągnę rękę moję na nie, i uczynię ziemię spustoszoną i opuszczoną od puszczej Deblatha po wszech mieszkaniach ich: a doznają, żem ja Pan.
