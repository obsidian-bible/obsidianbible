# Est 9 BT5
###### **Est 9,1**
 W dwunastym miesiącu, to jest w miesiącu Adar, trzynastego w nim dnia, gdy rozszedł się rozkaz króla i jego dekret do wykonania w dniu, w którym wrogowie Żydów spodziewali się zapanować nad nimi – wszystko się zmieniło i Żydzi zapanowali nad tymi, którzy ich nienawidzili.
###### **Est 9,2**
 I zgromadzili się Żydzi we wszystkich swoich miastach, we wszystkich państwach króla Aswerusa, aby podnieść rękę na tych, którzy pragnęli ich zguby. Nikt nie stawił im czoła, ponieważ strach przed nimi padł na wszystkie narody.
###### **Est 9,3**
 Wszyscy zaś książęta państw, satrapowie i namiestnicy, i zarządcy spraw króla wspomagali Żydów, bo padł na nich strach przed Mardocheuszem.
###### **Est 9,4**
 Mardocheusz bowiem był wielki w domu królewskim i sława jego rosła we wszystkich państwach. Tak ów mąż, Mardocheusz, stawał się coraz to większy.
###### **Est 9,5**
 Tak Żydzi pokonali wszystkich swoich wrogów przez uderzenie mieczem, przez zabójstwa i zagładę, i z nienawidzącymi ich postąpili zgodnie ze swym upodobaniem.
###### **Est 9,6**
 Na zamku w Suzie Żydzi zabili i wytracili pięciuset mężczyzn.
###### **Est 9,7**
 I zabili Parszandatę i Dalfona, i Aspatę,
###### **Est 9,8**
 i Poratę, i Adalię, i Aridatę,
###### **Est 9,9**
 i Parmasztę, i Arisaja, i Aridaja, i Wajezatę –
###### **Est 9,10**
 dziesięciu synów Hamana, syna Hammedaty, ciemięzcy Żydów, ale po ich majątek nie wyciągnęli ręki.
###### **Est 9,11**
 W tym samym dniu król dowiedział się o liczbie zabitych na zamku w Suzie.
###### **Est 9,12**
 Król rzekł do królowej Estery: «***W Suzie na zamku Żydzi zabili i wytracili pięciuset mężów i dziesięciu synów Hamana. A w pozostałych państwach króla co uczynili? Jakie jest jeszcze twoje życzenie, a będzie spełnione?***»
###### **Est 9,13**
 I rzekła Estera: «***Jeśli królowi to się podoba, to niech także jutro pozwolą Żydom, którzy są w Suzie, na działanie według dekretu z dnia dzisiejszego, aby mogli dziesięciu synów Hamana powiesić na drzewie***».
###### **Est 9,14**
 A król orzekł, by tak uczynić. Wydano więc dekret w Suzie, i dziesięciu synów Hamana powieszono.
###### **Est 9,15**
 A Żydzi, którzy byli w Suzie, zgromadzili się także w dniu czternastym miesiąca Adar i zabili w Suzie trzystu mężczyzn, ale po ich majątek nie wyciągnęli ręki.
###### **Est 9,16**
 Reszta Żydów, którzy mieszkali w państwach króla, zgromadziła się i stanęła w obronie swego życia. I uwolnili się od wrogów, i zabili nienawidzących ich siedemdziesiąt pięć tysięcy, ale po ich majątek nie wyciągnęli ręki.
###### **Est 9,17**
 Tak było trzynastego dnia miesiąca Adar. A czternastego odpoczęli i urządzili tegoż dnia ucztę i zabawę.
###### **Est 9,18**
 Żydzi zaś, którzy byli w Suzie, zgromadzili się trzynastego i czternastego dnia, a piętnastego odpoczęli i urządzili tegoż dnia ucztę i zabawę.
###### **Est 9,19**
 Dlatego Żydzi ze wsi, zamieszkujący miasta nie obwarowane, obchodzą dzień czternasty miesiąca Adar jako dzień radości i ucztowania, i dzień zabawy oraz wzajemnego posyłania sobie darów z żywności.
###### **Est 9,20**
 Mardocheusz opisał te wydarzenia i rozesłał listy do wszystkich Żydów, którzy byli we wszystkich państwach króla Aswerusa, blisko i daleko,
###### **Est 9,21**
 aby im wydać polecenie, że mają obchodzić jako święto dzień czternasty w miesiącu Adar i piętnasty w nim – rokrocznie –
###### **Est 9,22**
 jako dni, w których Żydzi uwolnili się od nieprzyjaciół, i miesiąc, w którym smutek obrócił się im w radość, a żałoba w wesele, aby obchodzili je jako dni ucztowania i radości oraz wzajemnego posyłania sobie darów z żywności, przyjaciołom, i darów z żywności – ubogim.
###### **Est 9,23**
 A Żydzi przekazywali to, co rozpoczęli czynić i co napisał im Mardocheusz,
###### **Est 9,24**
 że Haman, syn Hammedaty, Agagita, wróg wszystkich Żydów, powziął plan przeciw Żydom, aby ich wygubić, i rzucił "Pur", to jest los, aby ich zniszczyć i zgładzić.
###### **Est 9,25**
 Gdy zaś doszła wieść o tym do króla, wydał dekret na piśmie: «***Niech zły jego zamysł, jaki powziął przeciwko Żydom, zwróci się na jego głowę!***» I powiesili go i synów jego na drzewie.
###### **Est 9,26**
 Dlatego nazwano dni owe Purim, stosownie do nazwy "Pur". Również na podstawie wszystkich słów tego listu i na podstawie tego, co przeżyli i co ich dotknęło,
###### **Est 9,27**
 Żydzi postanowili i wzięli na siebie i na potomstwo swoje, i na wszystkich przyłączających się do nich, obowiązek nieprzemijający obchodzenia owych dni, stosownie do pisma i stosownie do czasów – rokrocznie.
###### **Est 9,28**
 Owe dni będą wspominane i świętowane we wszystkich pokoleniach, we wszystkich rodzinach, państwach i miastach. I owe dni Purim nie zaginą wśród Żydów, a pamięć ich nie ustanie u potomnych.
###### **Est 9,29**
 Napisali także królowa Estera, córka Abichaila, i Żyd Mardocheusz z wielkim naciskiem, aby ten drugi list [o dniu] Purim obowiązywał jako prawo.
###### **Est 9,30**
 I rozesłano pismo do wszystkich Żydów w stu dwudziestu siedmiu państwach królestwa Aswerusa, słowa pokoju i prawdy,
###### **Est 9,31**
 aby utrwalić owe dni Purim we właściwym czasie, jak je przedtem ustanowili Żyd Mardocheusz i królowa Estera, i jak ustanowili dla siebie i dla potomnych swoich przepisy postu i lamentowania.
###### **Est 9,32**
 Rozporządzenie Estery umocniło przepisy w sprawie owego święta Purim i spisane zostało to w księdze.
# Est 9 PAU
###### **Est 9,1**
 W dwunastym miesiącu, trzynastego dnia tegoż miesiąca, a był to miesiąc Adar, nadszedł dekret sporządzony przez króla.
###### **Est 9,2**
 Tego samego dnia zostali zgładzeni wszyscy przeciwnicy Żydów, a nikt nie stawiał oporu, gdyż się ich obawiano.
###### **Est 9,3**
 Zarządcy prowincji, naczelnicy oraz królewscy pisarze otaczali Żydów czcią, a czynili to z lęku przed Mardocheuszem,
###### **Est 9,4**
 bowiem rozporządzenie króla podano do wiadomości w całym królestwie.
###### **Est 9,5**
 Tak pokonali Żydzi wszystkich swoich wrogów przez uderzenie mieczem, przez zabójstwa i zagładę, i zrobili z nienawidzącymi ich wszystko, co chcieli.
###### **Est 9,6**
 W mieście Suza Żydzi zabili pięciuset mężczyzn,
###### **Est 9,7**
 w tym Farsannestaina, Delfona, Fasgę,
###### **Est 9,8**
 Fardatę, Bareę, Sarbachę,
###### **Est 9,9**
 Marmasimę, Arufajosa, Arsajosa i Zabutajtana,
###### **Est 9,10**
 oraz dziesięciu synów Hamana Pyszałka, syna Hammedaty, który był wrogiem Żydów. I zagrabili ich mienie.
###### **Est 9,11**
 Jeszcze tego samego dnia doszła do króla wieść o liczbie zabitych w Suzie.
###### **Est 9,12**
 Wtedy rzekł do Estery: „W mieście Suza Żydzi zabili pięciuset mężczyzn. A w całym kraju, jak sądzisz, co uczynili? Jeśli jeszcze czegoś pragniesz, otrzymasz!”.
###### **Est 9,13**
 Na to Estera rzekła do króla: „Należy zezwolić Żydom na podobny czyn także jutro, żeby mogli powiesić dziesięciu synów Hamana”.
###### **Est 9,14**
 Król przystał na to, a ciała synów Hamana zostały wydane Żydom w mieście, aby je powiesili.
###### **Est 9,15**
 Tak więc czternastego dnia miesiąca Adar Żydzi, którzy mieszkali w Suzie, zgromadzili się, zabili trzystu mężczyzn, ale niczego nie zrabowali.
###### **Est 9,16**
 Pozostali Żydzi mieszkający w królestwie połączyli się i wspólnymi siłami zdołali uwolnić się od nieprzyjaciół. Trzynastego dnia Adar zgładzili piętnaście tysięcy ludzi, ale niczego nie zrabowali.
###### **Est 9,17**
 Dnia czternastego tego miesiąca odpoczęli, spędzając ten dzień odpoczynku radośnie i wesoło.
###### **Est 9,18**
 Natomiast Żydzi mieszkający w mieście Suza zebrali się czternastego dnia, ale nie odpoczywali. Dopiero dzień piętnasty spędzali radośnie i wesoło.
###### **Est 9,19**
 Dlatego Żydzi rozproszeni w poszczególnych okręgach królestwa obchodzą radośnie czternasty dzień Adar jako dzień świąteczny i każdy przesyła upominek swojemu bliskiemu. Natomiast ci, którzy mieszkają w wielkich miastach obchodzą dzień piętnasty Adar jako radosny dzień święta i posyłają upominki bliskim.
###### **Est 9,20**
 Mardocheusz opisał te wydarzenia w liście wysłanym do Żydów, którzy żyli w królestwie Artakserksesa, zarówno bliskim, jak dalekim,
###### **Est 9,21**
 ustanawiając dni czternasty i piętnasty Adar dniami świątecznymi,
###### **Est 9,22**
 bo w tych dniach Żydzi uwolnili się od swoich wrogów. Natomiast cały miesiąc Adar, w którym smutek zamienił się dla nich w radość, a żałoba w święto, mają obchodzić jako dni wesela, ucztując i radując się, i przesyłając upominki przyjaciołom oraz ubogim.
###### **Est 9,23**
 Żydzi przyjęli życzliwie to wszystko, co pisał do nich Mardocheusz:
###### **Est 9,24**
 jak to Haman, syn Hammedaty, Macedończyk walczył z nimi, jak to postanowił rzucić los, aby ich wytracić,
###### **Est 9,25**
 i jak udał się do króla z prośbą o powieszenie Mardocheusza oraz jak usiłował sprowadzić na Żydów nieszczęście, a także to, że wszystko obróciło się przeciwko niemu i został powieszony on sam i jego dzieci.
###### **Est 9,26**
 Dlatego właśnie dni te zostały nazwane Purim. Nazwa pochodzi od losów, które w ich języku nazywają się purim, a także od treści tego listu oraz wszystkiego, co przeszli i wycierpieli.
###### **Est 9,27**
 Mardocheusz postanowił, a Żydzi przyjęli zobowiązanie na siebie i na swe potomstwo, i na wszystkich przyłączających się do nich, że z pokolenia na pokolenie, w każdym mieście, ojczyźnie, państwie, nigdy nie będą obchodzić tych dni inaczej, jak tylko jako wspomnienie tego, co się stało.
###### **Est 9,28**
 Te dni Purim będą obchodzone po wszystkie czasy, a pamięć o nich nie zaginie u potomnych.
###### **Est 9,29**
 Królowa Estera, córka Aminadaba, i Żyd Mardocheusz opisali swoje czyny i w ten sposób potwierdzili list dotyczący Purim.
###### **Est 9,30**
 [I rozesłano pismo do wszystkich Żydów w stu dwudziestu siedmiu państwach królestwa Aswerusa, pismo pokoju i prawdy,]
###### **Est 9,31**
 Mardocheusz i królowa Estera ustanowili też post dla siebie i dla swoich następców, a potem zachowywali go zgodnie ze swą wolą, nawet ze szkodą dla zdrowia.
###### **Est 9,32**
 Odpowiednim rozporządzeniem Estera ustanowiła to święto na wieki, a potem wszystko opisała na pamiątkę.
# Est 9 BP
###### **Est 9,1**
 A dwunastego miesiąca - czyli miesiąca Adar - dnia trzynastego, kiedy to miano wykonać rozkaz królewski i zarządzenie, a więc tego dnia, kiedy wrogowie Żydów spodziewali się zostać ich panami, nastąpiła odmiana i Żydzi odnieśli triumf nad swymi wrogami.
###### **Est 9,2**
 Żydzi zgromadzili się w swoich miastach i to we wszystkich prowincjach króla Achaszwerosza i podnieśli rękę na tych, którzy dążyli do ich zagłady. A nikt nie mógł im stawić oporu, ponieważ strach przed nimi zaciążył nad wszystkimi narodami.
###### **Est 9,3**
 Wszyscy książęta prowincji, satrapowie, naczelnicy i urzędnicy królewscy opowiedzieli się za Żydami, gdyż padł na nich strach przed Mardocheuszem.
###### **Est 9,4**
 Mardocheusz stał się bowiem wielką osobistością na dworze królewskim, a sława jego obiegła wszystkie prowincje. Wielkość Mardocheusza wciąż rosła.
###### **Est 9,5**
 Tak to Żydzi pobili swoich wrogów, wytracając ich mieczem, mordując i niszcząc. Z tymi, którzy ich nienawidzili, postępowali według swego uznania.
###### **Est 9,6**
 W stolicy Suza stracili Żydzi pięćset mężów.
###### **Est 9,7**
 [Wśród nich] zabili Parszandatę, Dalfona, Aspatę,
###### **Est 9,8**
 Poratę, Adaiję, Aridatę,
###### **Est 9,9**
 Parszmatę, Arisaja, Aridaja, Wajzatę,
###### **Est 9,10**
 dziesięciu synów Hamana, syna Hammedaty, wroga Żydów. Ale po łup ręki nie wyciągnęli.
###### **Est 9,11**
 Tego samego dnia dotarła do króla wiadomość o liczbie pomordowanych w stolicy Suza. Król rzekł do królowej Estery:
###### **Est 9,12**
 W twierdzy Suza Żydzi zabili i wytracili pięciuset mężów i dziesięciu synów Hamana! Czegóż to musieli dokonać w innych prowincjach królewskich?! Jaką jeszcze masz prośbę, a będzie spełniona. Czegóż jeszcze sobie życzysz, a stanie ci się.
###### **Est 9,13**
 Odpowiedziała Estera: Jeśli to się królowi podoba, niech wolno będzie Żydom [zamieszkałym] w Suzie jeszcze jutro uczynić to, na co im dziś zezwolono, i niech powieszą na szubienicy dziesięciu synów Hamana.
###### **Est 9,14**
 I rozkazał król, aby tak uczyniono. Obwieszczono wyrok w Suzie i dziesięciu synów Hamana powieszono.
###### **Est 9,15**
 Także dnia czternastego miesiąca Adar zgromadzili się Żydzi, mieszkający w Suzie, i zabili tam jeszcze trzystu mężów, ale po łupy ręki nie wyciągnęli.
###### **Est 9,16**
 A reszta Żydów, którzy mieszkali w prowincjach królewskich, zgromadziła się, by bronić swego życia, a zabezpieczając się przed swymi wrogami, zabili siedemdziesiąt pięć tysięcy swych prześladowców, ale po łupy ręki nie wyciągnęli.
###### **Est 9,17**
 Stało się to dnia trzynastego miesiąca Adar, czternastego zaś odpoczywali i obchodzili go jako dzień radosnej biesiady.
###### **Est 9,18**
 Natomiast Żydzi mieszkający w Suzie zgromadzili się dnia trzynastego i czternastego, tak że odpoczywali piętnastego i ten obchodzili jako dzień biesiady i wesela. Dlatego to Żydzi, mieszkający w miastach, obchodzą dzień czternasty miesiąca Adar jako dzień biesiady i wesela oraz jako dzień świąteczny, w którym wzajemnie rozdają sobie dary.
###### **Est 9,20**
 Mardocheusz spisał te wypadki i rozesłał pisma do wszystkich Żydów, którzy mieszkali we wszystkich prowincjach króla Achaszwerosza, zarówno tych bliskich, jak i dalekich,
###### **Est 9,21**
 zobowiązując ich, by każdego roku dzień czternasty i dzień piętnasty miesiąca Adar obchodzili uroczyście,
###### **Est 9,22**
 gdyż były to dni, w których Żydzi pozbyli się swoich nieprzyjaciół, i miesiąc, w którym smutek ich zamienił się w radość, a dzień żałoby w święto; dlatego to winny one stać się dla nich dniami uczty i wesela, wzajemnej wymiany darów i jałmużny udzielanej ubogim.
###### **Est 9,23**
 Żydzi przystali na to, co już sami poczęli czynić, a co im był Mardocheusz nakazał pismem.
###### **Est 9,24**
 Haman bowiem, syn Hammedaty, Agagita, prześladowca wszystkich Żydów, zamierzał wytępić Żydów i polecił rzucić pur, to jest los, aby ich zniszczyć i wytracić.
###### **Est 9,25**
 Ale gdy wieść o tym dotarła do króla, wydał on rozkaz na piśmie, aby zbrodniczy plan [Hamana], który on skierował przeciw Żydom, spadł na jego głowę i by jego samego wraz z jego synami powieszono na szubienicy.
###### **Est 9,26**
 Dlatego nazwano te dni Purim od słowa pur. Zgodnie też z treścią tego pisma, jak również zgodnie z tym, co sami przeżyli i co ich spotkało,
###### **Est 9,27**
 Żydzi przyjęli jako prawomocny obowiązek tak dla siebie i swoich potomków, jak również dla tych wszystkich, którzy do nich przystaną, że będą obchodzić te dwa dni stosownie do pisma i w ustalonym czasie po wszystkie lata.
###### **Est 9,28**
 Dni te winny być rozpamiętywane i święcone z pokolenia na pokolenie, w każdej rodzinie, w każdej prowincji i w każdym mieście; te dni Purim nie zanikną nigdy spośród Żydów i pamięć o nich nigdy nie zaginie wśród ich potomków.
###### **Est 9,29**
 Królowa Estera, córka Abichajila, i Żyd Mardocheusz napisali po raz drugi z całą powagą, by to pismo w sprawie Purim miało moc prawną.
###### **Est 9,30**
 Rozesłano więc pismo do wszystkich Żydów w stu dwudziestu siedmiu prowincjach królestwa Achaszwerosza jako słowa pokoju i wierności,
###### **Est 9,31**
 aby dni Purim, przypadające na [oznaczony] czas, wprowadzić jako obowiązujące, jak to Żyd Mardocheusz (i królowa Estera) dla nich ustalili i w sposób, jaki oni przyjęli dla siebie samych i dla swoich potomków wraz z przepisami odnoszącymi się do postu i lamentacji.
###### **Est 9,32**
 Nakaz więc Estery sprawił, że przepisy w sprawie święta Purim zostały ustalone i że wpisano to do księgi.
# Est 9 BR
###### **Est 9,1**
 Trzynastego dnia dwunastego miesiąca, czyli miesiąca Adar, dekret królewski razem z zarządzeniem wykonawczym miał wejść w życie. Był to dzień, w którym przeciwnicy Żydów zamierzali ich zgładzić. Tymczasem stało się odwrotnie: to właśnie Żydzi zgotowali zagładę swym wrogom.
###### **Est 9,2**
 We wszystkich prowincjach podległych władzy Aswerusa gromadzili się Żydzi w jednym mieście i uderzali na tych, którzy przygotowywali im zagładę. Nikt nie był w stanie im się oprzeć, ponieważ strach przed nimi ogarnął wszystkie narody.
###### **Est 9,3**
 Wszyscy książęta prowincji, satrapowie, zarządcy i urzędnicy królewscy przeszli na stronę Żydów, bo bali się Mardocheusza.
###### **Est 9,4**
 Mardocheusz był bowiem w pałacu królewskim bardzo poważany i we wszystkich prowincjach było wiadomo, że zależy od niego coraz więcej.
###### **Est 9,5**
 Tak więc razili Żydzi mieczem swoich wrogów. Krew płynęła obficie. Czynili ze swymi wrogami, co tylko chcieli.
###### **Est 9,6**
 W twierdzy w Suzie zabili Żydzi pięciuset ludzi,
###### **Est 9,7**
 a wśród nich: Parszandatę, Dalfona, Aspatę,
###### **Est 9,8**
 Poratę, Adalię, Aridatę,
###### **Est 9,9**
 Parmasztę, Arisaja, Aridaja i Wajezatę.
###### **Est 9,10**
 Wymordowali w ten sposób dziesięciu synów wroga Żydów Hamana, syna Hammedaty; ich samych pozabijali, ale ich majątku nie tknęli.
###### **Est 9,11**
 Kiedy doniesiono tego dnia królowi, ilu to ludzi poległo w twierdzy w Suzie urządzili Żydzi krwawą łaźnię.
###### **Est 9,12**
 Zabito pięciuset mężczyzn oraz dziesięciu synów Hamana. A co uczyniono w pozostałych prowincjach królewskich? Czy masz jakieś życzenie w tej sprawie? Każda twoja prośba zostanie spełniona. Czy masz jakąś prośbę? Natychmiast uczynię jej zadość.
###### **Est 9,13**
 Odpowiedziała tedy Estera: Jeżeli król uzna to za słuszne, to niech raczy zezwolić, aby Żydzi w Suzie jutro również tak jak dzisiaj mogli działać zgodnie z dekretem królewskim. Poza tym niech im będzie wolno powiesić na szubienicach wszystkich dziesięciu synów Hamana.
###### **Est 9,14**
 I wydał król rozkaz, żeby tak uczyniono. Ponadto wydano w Suzie jeszcze jeden dekret i powieszono dziesięciu synów Hamana.
###### **Est 9,15**
 Tak więc czternastego dnia miesiąca Adar Żydzi zebrali się również razem w Suzie i zabili trzystu ludzi, ale ich mienia nie tknęli.
###### **Est 9,16**
 Pozostali Żydzi mieszkający w innych prowincjach królewskich również gromadzili się razem i występowali w obronie własnego życia. Zapewnili sobie spokój ze strony swoich wrogów, zabijając ich siedemdziesiąt pięć tysięcy. Lecz ich mienia również nie ruszali.
###### **Est 9,17**
 Stało się to wszystko trzynastego dnia miesiąca Adar. Czternastego dnia panował już spokój:[Żydzi w prowincjach] obchodzili uroczyście ten dzień jako święto, jedząc i pijąc.
###### **Est 9,18**
 Żydzi w Suzie zbierali się razem trzynastego i czternastego tego samego miesiąca, a spokój nastąpił u nich dopiero piętnastego i ten dzień obchodzili uroczyście jako święto, jedząc i pijąc.
###### **Est 9,19**
 Dlatego to we wszystkich osiedlach nieumocnionych w całym kraju obchodzą Żydzi czternasty dzień miesiąca Adar jako święto. Jedzą wtedy i piją, i wręczają sobie nawzajem różne podarunki.
###### **Est 9,20**
 Mardocheusz opisał dokładnie to wszystko, co się stało, i przesłał swoje pismo do wszystkich Żydów mieszkających w prowincjach króla Aswerusa, zarówno w tych bliskich, jak i odległych,
###### **Est 9,21**
 nakazując im obchodzić co roku jako uroczyste święto dzień czternasty i piętnasty miesiąca Adar.
###### **Est 9,22**
 Są to bowiem dni, w które Żydzi znów zaznali spokoju od swoich wrogów. Jest to miesiąc, w którym smutek przemienił się w radość, a żałoba - w wesele i szczęście. Te dni świąteczne mieli obchodzić jedząc i pijąc; mieli dawać sobie nawzajem różne upominki i obdzielać jałmużną ubogich.
###### **Est 9,23**
 I tak powtarzali Żydzi co roku, co wtedy uczynili po raz pierwszy i co im nakazał czynić Mardocheusz.
###### **Est 9,24**
 Agagita Haman, syn Hammedaty, zaciekły wróg Żydów, zamierzał bowiem wszystkich Żydów zgładzić. Żeby zaś wyznaczyć dzień ich wyniszczenia i zagłady, kazał rzucić pur czyli los.
###### **Est 9,25**
 Na wieść o tym król przekazał mu specjalnym pismem takie oświadczenie: Twoje złowrogie zamiary skierowane przeciwko Żydom obrócą się przeciwko tobie samemu. I został powieszony razem z swymi synami, na szubienicy.
###### **Est 9,26**
 Dlatego nazwano te dni - od słowa pur - świętem Purim. Stosownie do treści tego pisma oraz ze względu na to, co sami widzieli i przeżyli,
###### **Est 9,27**
 postanowili sobie Żydzi raz na zawsze, w imieniu własnym oraz w imieniu przyszłych pokoleń, a także w imieniu tych, którzy się do nich przyłączą, te dwa dni obchodzić co roku zgodnie z przepisami jak uroczyste święto.
###### **Est 9,28**
 Dni te miały pozostawać na zawsze w ich pamięci przez wszystkie pokolenia, we wszystkich rodzinach, we wszystkich prowincjach i w każdym mieście. Nigdy nie zaniecha się wśród potomków Izraela obchodzenia owych dni świątecznych Purim.
###### **Est 9,29**
 Pragnąc nadać jeszcze większą moc obowiązującą dekretowi święcie Purim, królowa Estera, córka Abichaila wydała jeszcze jedno bardzo stanowne pismo.
###### **Est 9,30**
 Rozesłała je - życząc szczęścia i błogosławieństwa Bożego - do wszystkich Żydów mieszkających w stu dwudziestu siedmiu prowincjach, które pozostawały pod władzą króla Aswerusa.
###### **Est 9,31**
 Pismo to mówiło jeszcze raz o czasie obchodów święta Purim zgodnie z tym, co postanowili: Żyd Mardocheusz i królowa Estera i według tego, do czego zobowiązali samych siebie oraz swoich potomków. Pismo zawierało również wskazania dotyczące postów i obchodów żałobnych.
###### **Est 9,32**
 W ten sposób zaleceniami Estery został potwierdzony nakaz obchodzenia święta Purim. Wszystko to zostało zapisane w księdze.
# Est 9 WUJ
###### **Est 9,1**
 Dwunastego tedy miesiąca, któryśmy wyżej powiedzieli, że Adar zowią, trzynastego dnia, kiedy wszystkim Żydom zatracenie gotowano, a nieprzyjaciele krwie ich pragnęli, za odmianą szczęścia, Żydowie poczęli brać górę, i mścić się nad nieprzyjacioły swemi.
###### **Est 9,2**
 I zebrali się po wszystkich miastach i miasteczkach i miejscach, aby wyciągnęli rękę na nieprzyjacioły i prześladowniki swoje. I żaden się nie śmiał sprzeciwić, dla tego, że strach wielkości ich przeraził był wszystkie narody.
###### **Est 9,3**
 Bo i Sędziowie krain, i książęta, i Oekonomowie, i wszyscy dygnitarze, którzy nad każdem miejscem i sprawą przełożeni byli, wywyższali Żydy, bojąc się Mardocheusza:
###### **Est 9,4**
 O którym dowiedzieli się, że był przedniejszy na pałacu, a iż wiele mógł: sława też imienia jego co dzień rosła, i było jej pełno w uściech wszystkich ludzi.
###### **Est 9,5**
 I tak pobili Żydowie nieprzyjacioły swe porażką wielką, i pozabijali je, oddawając im co im byli gotowi uczynić:
###### **Est 9,6**
 Tak barzo, że też w Susan pięć set mężów zabili, oprócz dziesiąci synów Amana Agagejczyka nieprzyjaciela Żydowskiego, których te są imiona:
###### **Est 9,7**
 Pharsandatha, i Delphon, i Esphatha,
###### **Est 9,8**
 I Phoratha, i Adalia, i Aridatha,
###### **Est 9,9**
 I Phermesta, i Arisaj, i Aridaj, i Jezatha.
###### **Est 9,10**
 Które pobiwszy, łupów z majętności ich tykać się nie chcieli.
###### **Est 9,11**
 I natychmiast liczbę onych, których pobito w Susan, do króla przyniesiono.
###### **Est 9,12**
 Który rzekł królowej: W mieście Susan zabili Żydowie pięć set mężów i innych dziesiąci synów Amanowych: jako wielki mord mniemasz, oni czynią we wszystkich krainach? Czegóż więcej prosisz, a co chcesz, abych kazał uczynić?
###### **Est 9,13**
 Któremu ona odpowiedziała: Jeślić się królowi podoba, niechby dano moc Żydom, aby jako dziś uczynili w Susan, tak i jutro uczynili: a dziesięć synów Amonowych, aby na szubienicach zawieszono.
###### **Est 9,14**
 I rozkazał król, aby się tak stało. I wnet w Susan rozbito wyrok, i dziesiąci synów Amanowych obieszono.
###### **Est 9,15**
 A gdy się zebrali Żydzi czternastego dnia miesiąca Adar, zabito w Susan trzy sta mężów: ani majętność ich nie była od nich rozszarpana.
###### **Est 9,16**
 Ale i po wszystkich ziemiach, które były pod mocą królewską, zastawowali się Żydowie za swe dusze pobiwszy nieprzyjacioły prześladowce swoje: tak barzo, że doszło siedmdziesiąt i pięć tysięcy zabitych, a żaden się niczego nie tknął z ich majętności.
###### **Est 9,17**
 A dzień trzynasty miesiąca Adar był u wszystkich pierwszy zabijania, a czternastego dnia zabijać przestali: który postanowili, aby był uroczysty, aby weń napotem zawżdy biesiady i wesela i uczty sprawowali.
###### **Est 9,18**
 Ale ci, którzy w mieście Susan zabijali, trzynastego i czternastego dnia tegoż miesiąca zabijaniem się zabawiali: a piętnastego dnia zabijać przestali. I przetoż tenże dzień uroczysty postanowili na uczty i na wesele.
###### **Est 9,19**
 Ci lepak Żydowie, którzy w miasteczkach niemurowanych i po wsiach mieszkali, czternasty dzień miesiąca Adar na biesiady i na wesela postanowili, tak, aby się weń radowali, i słali części uczty i potraw jeden drugiemu.
###### **Est 9,20**
 Spisał tedy Mardocheusz to wszystko, i listami zamknąwszy, rozesłał do Żydów, którzy po wszystkich krainach królewskich mieszkali, tak blizko leżących, jako odległych:
###### **Est 9,21**
 Aby czternasty i piętnasty dzień miesiąca Adar za święta przyjęli, a na każdy rok zawsze uroczystą czcią obchodzili:
###### **Est 9,22**
 Iż w te dni pomścili się Żydzi nad nieprzyjacioły swemi, a płacz i smętek obróciły się im w radość i w wesele: ażeby te dni obchodzili ź biesiadami i z weselem, i posyłali jeden drugiemu części potraw, i ubogim dary dawali.
###### **Est 9,23**
 I przyjęli Żydowie w uroczysty obrząd wszystko co na on czas czynić poczęli, i co Mardocheusz przez listy czynić rozkazał.
###### **Est 9,24**
 Abowiem Aman, syn Amadathy z pokolenia Agag, nieprzyjaciel i przeciwnik żydowski, myśli złość przeciwko im, aby je był pobił i zgładził: i miotał Phur, który naszym językiem wykłada się los.
###### **Est 9,25**
 A potem weszła Esther do króla, prosząc aby usiłowanie jego, listy królewskimi wniwecz obrócone było: a złość, którą przeciw Żydom myślił, obróciła się na głowę jego. Nawet i samego, i syny jego, na szubienicy obiesili.
###### **Est 9,26**
 I od onego czasu te dni nazwano Phurim, to jest, losów: przeto iż Phur, to jest, los, w banię był wrzucony. I wszystko co się działo, w liście, to jest, w tych ksiegach zamyka się:
###### **Est 9,27**
 I co ucierpieli, i co napotem odmieniono, przyjęli na się Żydzi i na nasienie swoje, i na wszystkie, którzy na wiarę ich przystać chcieli: aby się żadnemu nie godziło tych, dwu dni bez święcenia strawić, o których pismo świadczy, i pewne czasy wyciągają rok po roku ustawicznie.
###### **Est 9,28**
 Teć są dni, których zapamiętanie żadne nigdy nie zgładzi, i w każdym wieku wszystkie krainy po wszem świecie obchodzić będą: i niemasz żadnego miasta, w któremby dni Phurim, to jest losów, nie były od Żydów święcone, i od ich potomków, którzy są na te ceremonie obowiązani.
###### **Est 9,29**
 I napisali Esther królowa córka Abihail i Mardocheusz Żydowin jeszcze drugi list, aby ze wszelaką pilnością ten dzień ustanowiony był za święty na potomne czasy.
###### **Est 9,30**
 I posłali do wszystkich Żydów, którzy mieszkali we stu i dwudziestu i siedmi krainach Asswerusa króla, aby mieli pokój, i przyjmowali prawdę,
###### **Est 9,31**
 Zachowywając dni losów, a czasu swego z radością obchodząc: jako Mardocheusz z Esther postanowili, a oni chować obiecali, i sami i z potomstwem swoim, posty i wołania, i dni losów,
###### **Est 9,32**
 I wszystko co się w historiej tych ksiąg, które zowią Esther, zamyka.
