# Ha 2 BT5
###### **Ha 2,1**
 Na moich czatach stać będę, udam się na miejsce czuwania, śledząc pilnie, by poznać, co On powie do mnie, jaką odpowiedź da na moją skargę.
###### **Ha 2,2**
 I odpowiedział Pan tymi słowami:«***Zapisz widzenie, na tablicach wyryj, by można było łatwo je odczytać.***
###### **Ha 2,3**
 ***Jest to widzenie na czas oznaczony, lecz wypełnienie jego niechybnie nastąpi; a jeśli się opóźnia, ty go oczekuj, bo w krótkim czasie przyjdzie niezawodnie.***
###### **Ha 2,4**
 ***Oto zginie ten, co jest ducha nieprawego, a sprawiedliwy żyć będzie dzięki swej wierności***».
###### **Ha 2,5**
 Zaiste, wino jest zdrajcą; a człowiek pyszny nie zazna spokoju; traci rozsądek i spokój. Ten, który rozdziawia szeroko swą gardziel jak Szeol i jak śmierć jest nienasycony; choć zebrał ludy wszystkie wokół siebie, wszystkie narody do siebie przyłączył.
###### **Ha 2,6**
 Czyż oni wszyscy nie zanucą przeciw niemu pieśni szyderczej, złośliwej przymówki, zagadek nie ułożą na niego? Powiedzą: Pierwsze Biada temu, kto gromadzi mienie nie swoje! Na jak długo? Obciąża się coraz większymi zastawami!
###### **Ha 2,7**
 Czyż nie powstaną nagle wierzyciele twoii nie obudzą się twoi dręczyciele? Staniesz się dla nich łupem.
###### **Ha 2,8**
 Ponieważ złupiłeś liczne narody, złupią i ciebie pozostałe ludy –z powodu rozlewu krwi ludzkieji gwałtów dokonanych w kraju przeciwko miastu i jego mieszkańcom. Drugie
###### **Ha 2,9**
 Biada ciągnącemu dla domu swego zysk nieprawy, aby zbudować wysoko swe gniazdo i tym sposobem uniknąć nieszczęścia!
###### **Ha 2,10**
 Postanowiłeś na hańbę swojego domu wytracić liczne narody, przeciw życiu własnemu tym grzesząc.
###### **Ha 2,11**
 Kamień ze ściany zawoła, a belka budowy mu zawtóruje: Trzecie
###### **Ha 2,12**
 Biada temu, co miasto na krwi przelanej buduje, a gród umacnia nieprawością!
###### **Ha 2,13**
 Czyż nie jest to wolą Pana Zastępów, że ludy dla ognia pracująi darmo się trudzą narody?
###### **Ha 2,14**
 Albowiem kraj się napełni znajomością chwały Pana, jak wody napełniają morze. Czwarte
###### **Ha 2,15**
 Biada temu, co zmusza bliźniego do picia, pucharem swego jadu go upaja, by się przyglądać jego nagości.
###### **Ha 2,16**
 Nasyciłeś się hańbą, nie chwałą, upij się sam i pokaż swój napletek; bo ciebie dosięgnie kielich z prawicy Pańskiej, a wstyd pokryje całą twoją sławę.
###### **Ha 2,17**
 Spadnie na ciebie krzywda Libanu,rzeź zwierząt napełni cię strachem, z powodu rozlewu krwi ludzkieji gwałtów dokonanych w krajuprzeciwko miastu i jego mieszkańcom. Piąte
###### **Ha 2,18**
 Cóż może posąg, który rzeźbiarz tworzy, obraz z metalu, fałszywa wyrocznia –że w nich to twórca nadzieję pokłada, gdy wykonuje swoje nieme bogi?
###### **Ha 2,19**
 Biada temu, co mówi: «***Obudź się!***» – do drzewa,«***Podnieś się!***» – do niemego głazu. <Czy on pouczy?> Okryte one złotem i srebrem, lecz ducha wcale w nich nie ma.
###### **Ha 2,20**
 A Pan mieszka w swym świętym domu, niechaj zamilknie przed Nim cała ziemia.
# Ha 2 PAU
###### **Ha 2,1**
 Stanę na warcie, pójdę na miejsce czuwania, żeby usłyszeć, gdy przemówi do mnie - na moją skargę odpowie.
###### **Ha 2,2**
 PAN odpowiedział takimi słowami: Zapisz widzenie, wyryj na tablicach, tak aby każdy mógł łatwo je odczytać!
###### **Ha 2,3**
 To widzenie dotyczy przyszłości i wypełni się, bo nie jest złudzeniem. Jeśli się spóźnia, oczekuj go, gdyż niezawodnie nadejdzie i nie będzie zwlekać.
###### **Ha 2,4**
 Patrz, oto dusza pyszałka nie upodoba go sobie, a sprawiedliwy będzie żył dzięki swojej wierności.
###### **Ha 2,5**
 Bogactwo bowiem z pewnością zawiedzie, a człowiek pyszny nie osiągnie celu. Swoją gardziel rozwiera on jak kraina umarłych i jak śmierć nigdy się nie nasyci. Choćby zebrał wokół siebie narody i wszystkie ludy przy sobie zgromadził,
###### **Ha 2,6**
 czyż one nie ułożą o nim pieśni pełnych drwiny, czy nie będą z niego szydzić? Powiedzą: Biada temu, kto przywłaszcza sobie cudze dobra i obciąża się coraz większą winą! Jak długo to jeszcze trwać będzie?
###### **Ha 2,7**
 Czyż nie powstaną nagle twoi wierzyciele, czy udręczeni przez ciebie się nie przebudzą, a ty, czy nie staniesz się ich łupem?
###### **Ha 2,8**
 Ograbiłeś tak wiele narodów, więc inne ludy teraz ciebie ograbią, bo przelałeś krew ludzką i w kraju dokonałeś gwałtów przeciwko miastom oraz ich mieszkańcom.
###### **Ha 2,9**
 Biada temu, kto ciągnie niegodziwe zyski dla swojego domu! Pragnie swoje gniazdo zbudować wysoko i tak uniknąć grożącej katastrofy.
###### **Ha 2,10**
 Na hańbę własnego domu postanowiłeś zgubę wielu ludów i ściągnąłeś na siebie nieszczęście.
###### **Ha 2,11**
 Zawoła kamień ze ściany, a belki budowli odpowiedzą echem.
###### **Ha 2,12**
 Biada temu, kto buduje miasto kosztem krwi przelanej i na nieprawości wznosi swoją twierdzę!
###### **Ha 2,13**
 Bo czyż PAN Zastępów nie sprawia tego, że ogień trawi dzieła ludzkie i narody trudzą się daremnie?
###### **Ha 2,14**
 Cały kraj napełni się poznaniem chwały PANA, podobnie jak morze jest wypełnione wodami.
###### **Ha 2,15**
 Biada temu, kto czarę swojego gniewu każe wypić bliźniemu, aby gdy zupełnie go upoi, potem oglądać jego nagość.
###### **Ha 2,16**
 To ty się nasycisz hańbą zamiast chwały; pij więc sam i pokazuj swoją nagość! Wróci do ciebie puchar z ręki PANA, wstyd i pogarda zniweczą twoją sławę.
###### **Ha 2,17**
 Ty odpowiesz za spustoszenie lasów Libanu, na tobie zaciąży wytępienie zwierząt, przelanie krwi ludzkiej, gwałty popełnione w kraju przeciwko miastom oraz ich mieszkańcom.
###### **Ha 2,18**
 Jaka jest korzyść z rzeźbionego bożka, z odlanego posągu, z fałszywej wyroczni? Jakże twórca może im zaufać - niemym bożkom, które sam wykonał?
###### **Ha 2,19**
 Biada temu, kto mówi do drzewa: Zbudź się! Dźwignij się! - woła do niemego kamienia! Złotem i srebrem są one pokryte, lecz nie ma w nich tchnienia życia.
###### **Ha 2,20**
 PAN natomiast mieszka w swoim świętym mieszkaniu, niech zamilknie przed Nim cała ziemia!
# Ha 2 BP
###### **Ha 2,1**
 Stanę na warcie, udam się na strażnicę i będę się pilnie wpatrywał, żeby zobaczyć, co do mnie będzie mówił [Jahwe] i jaką da odpowiedź na moją skargę.
###### **Ha 2,2**
 I dał mi Jahwe odpowiedź mówiąc: - Zapisz to widzenie, na tabliczkach je wyryj, tak by każdy mógł je łatwo przeczytać.
###### **Ha 2,3**
 Widzenie to bowiem odnosi się do chwili, która dopiero nadejdzie, mówi o końcu i nie zawiedzie; jeżeli zaś nie ziści się rychło, czekaj cierpliwie na jego spełnienie; nastąpi ono niezawodnie i nie opóźni się.
###### **Ha 2,4**
 Oto pyszny nie utrzyma się przy życiu, a sprawiedliwy dzięki swej wierności będzie żył.
###### **Ha 2,5**
 Bogactwo także jest zawodne! Nie ostoi się człowiek zuchwały, który rozwiera paszczę jak otchłań, nienasycony jak śmierć, ściąga ku sobie wszystkie ludy, gromadzi wokół siebie wszystkie narody.
###### **Ha 2,6**
 Wszystkie zaśpiewają o nim pieśń pełną szyderstw i ukrytych przymówek: Biada temu, kto gromadzi nie swoje (na jak długo?) i obarcza się ciężarem zajętego mienia!
###### **Ha 2,7**
 Czyż wierzyciele twoi nie powstaną nagle, czy się nie przebudzą i nie napędzą ci strachu? A wtedy staniesz się ich łupem!
###### **Ha 2,8**
 Ponieważ ty złupiłeś tyle ludów, wszystkie inne narody złupią ciebie za krew ludzką [przelaną] i za gwałt zadany krajowi, miastu i wszystkim jego mieszkańcom.
###### **Ha 2,9**
 Biada temu, kto szuka zysków nieuczciwych - nieszczęście to dla jego domu - by móc założyć sobie gniazdo bardzo wysoko i tak zabezpieczyć się przed nieszczęściem.
###### **Ha 2,10**
 Przez wytępienie tylu narodów zgotowałeś hańbę swemu domowi i ściągnąłeś zgubę na siebie samego.
###### **Ha 2,11**
 Głosi to każdy kamień w ścianie, a wiązanie belek wtóruje mu.
###### **Ha 2,12**
 Biada temu, kto buduje miasto na krwi i zakłada twierdzę na zbrodni!
###### **Ha 2,13**
 Czyż nie od Jahwe Zastępów pochodzą słowa: Narody trudzą się dla płomieni, ludy wysilają się po próżnicy;
###### **Ha 2,14**
 poznanie chwały Jahwe zapełni ziemię, jak woda pokrywa [głębinę] morza.
###### **Ha 2,15**
 Biada temu, kto każe bliźnim pić z czary swego gniewu, aż ich upoi, by potem swe oczy napawać ich nagością!
###### **Ha 2,16**
 Syciłeś się hańbą zamiast chwałą; pij więc i ty i zataczaj się; Do ciebie wróci czara z prawicy Jahwe i wzgarda dla twojej sławy.
###### **Ha 2,17**
 Bo ciążyć będzie na tobie przemoc twa nad Libanem, ogarnie cię przerażenie z powodu wytępionej zwierzyny, [przelanej] krwi ludzkiej i gwałtu, jaki zadałeś krajowi, miastu i wszystkim jego mieszkańcom.
###### **Ha 2,18**
 Jakiż pożytek z rzeźby: że jej twórca nadał jej kształt? Albo z posągu lanego, co daje kłamliwe wyrocznie: że artysta, który go wykonał, pokłada w nim nadzieję i tworzy nieme bóstwa?
###### **Ha 2,19**
 Biada temu, kto mówi do drewna: "Przebudź się!" a do niemego kamienia: "Ocknij się!" (Czy on może dać jakąś wyrocznię?) Pokryty jest wprawdzie złotem i srebrem, ale ducha w nim nie ma żadnego.
###### **Ha 2,20**
 Natomiast Jahwe mieszka w swym świętym Przybytku; niech umilknie wobec Niego ziemia cała.
# Ha 2 BR
###### **Ha 2,1**
 Będę stał tedy na wieży strażniczej, wejdę także wysoko na wały i będę nasłuchiwał uważnie, co też On mi powiedzieć zechce i jak się zachowa wobec mojej skargi.
###### **Ha 2,2**
 A Pan mi tak odpowiedział: Opisz to wszystko, co widzisz, dokładnie wypisz wszystko na tablicach, tak żeby z łatwością mogło być czytane.
###### **Ha 2,3**
 Bo wszystko, co tu teraz widzisz, stanie się w wyznaczonym czasie. Ku końcowi wszystko nieuchronnie zmierza. Jeśli się coś trochę opóźnia, czekaj na to cierpliwie, bo przyjdzie na pewno, zdarzy się niechybnie.
###### **Ha 2,4**
 Wyginie wszystko to, co jest nieprawe, ostanie się zaś tylko sprawiedliwy, on dzięki wierności ocali swe życie.
###### **Ha 2,5**
 Zaprawdę, zgubne są wszelkie bogactwa, nie osiągnie celu wynoszący się duchem. I choć swoje usta jak otchłań otwiera, i jak śmierć jest nienasycony, choćby wszystkie narody dla siebie zagarnął i zgromadził wokół siebie nawet wszystkie ludy.
###### **Ha 2,6**
 Czy nie zaczną o nim wszyscy śpiewać szyderczych pieśni? Ależ tak, wzgardzą nim i tak zaczną wołać: Biada temu, co mienie cudze zabiera, i każe sobie przynosić zbyt wielkie zastawy! (Jak długo jeszcze będzie to czynił?)
###### **Ha 2,7**
 Otóż staną nagle przed tobą wierzyciele twoi pobudzą się ci wszyscy, którzy cię uciskają, i tak staniesz się ich łupem.
###### **Ha 2,8**
 Złupiłeś sam już wiele narodów, a teraz owe narody ograbią ciebie oraz inne ludy, dlatego że tak wiele krwi pośród sprawiedliwych przelałeś, że się dopuszczałeś niejednego gwałtu na krajach całych, na miastach i na ich mieszkańcach.
###### **Ha 2,9**
 Biada tym, co dla swego domu szukaja nieuczciwych zysków, po to aby bardzo wysoko uwić sobie gniazdo i uniknąć tym samym nieszczęścia, które im zagraża!
###### **Ha 2,10**
 Ku pohańbieniu twego domu własnego postanowiłeś wiele ludów zniszczyć. I tak przeciw sobie samemu dopuszczasz się grzechów.
###### **Ha 2,11**
 Głośno wołają kamienie w murach, wtórują im belki strop podtrzymujące.
###### **Ha 2,12**
 Biada temu, co krwią buduje swe miasto, i na niesprwiedliwości zakłada twierdzę.
###### **Ha 2,13**
 Czyż Pan Zastępów nie sprawi, że tylko dla ognia będą się ludy trudzić, a całe narody - pracować na próżno?
###### **Ha 2,14**
 Zaprawdę, kraj cały winien być wypełniony znajomością wielkiej chwały Pana, tak jak wody morze wypełniają.
###### **Ha 2,15**
 Biada temu, kto braciom każe wypijać kielich swojej własnej złości i po to ich upija, by patrzeć na ich nagość.
###### **Ha 2,16**
 Hańbą twą sycić się masz, a nie chwałą. Sam się upij i pokaż twe nieobrzezanie, kielich z rąk Pańskich niech przyjdzie do ciebie, niech wstyd i pohańbienie przysłonią twą chwałę.
###### **Ha 2,17**
 Spadną na ciebie krzywdy, któreś Libanowi czynił, obciąża cię wyniszczenie wszystkich dzikich zwierząt i wszelka krew przelana wśród ludzi niewinnych oraz gwałty, których się dopuszczałeś wobec krajów, miast i wobec ich mieszkańców.
###### **Ha 2,18**
 Cóż może posąg bożka, przez rzeźbiarza zrobiony, jakiś odlew z metalu lub wyrocznia fałszywa? Jak może rzemieślnik liczyć na swe bóstwa, na obrazy nieme, które sam uczynił?
###### **Ha 2,19**
 Biada temu, kto mówi do drzewa, by się przebudziło, i do martwego kamienia, powstał? Czyż może coś odpowiedzieć bóstwo? Srebrem i złotem co prawda, jest ono okryte, lecz nie ma w nim żadnego ducha czy też tchnienia.
###### **Ha 2,20**
 Pan zaś przebywa w swym świętym przybytku, niech tedy świat cały zamilknie przed Jego obliczem.
# Ha 2 WUJ
###### **Ha 2,1**
 Na strażej mojej stać będę, i zastanowię się na zamku: a przypatrzę się, żebym ujrzał co mi rzeką, i co mam odpowiedzieć strofującemu mię.
###### **Ha 2,2**
 I odpowiedział mi Pan, i rzekł: Napisz widzenie, a wyłóż je na tablicach: żeby przebieżał kto je czytać będzie.
###### **Ha 2,3**
 Bo jeszcze widzenie daleko, i ukażę się na końcu, a nie skłama. Jeśliby odwlaczał, oczekawaj go: bo przychodzący przydzie, a nie zamieszka.
###### **Ha 2,4**
 Oto kto niedowiarkiem jest, nie będzie prosta dusza jego w nim samym: a sprawiedliwy wiarą swą żyć będzie.
###### **Ha 2,5**
 A jako wino pijącego zdradza: tak będzie mąż pyszny, a nie będzie ozdobiony: który rozszerzył jako piekło duszę swoję: a sam jest jako śmierć, i nie napełnia się: i zbierze do siebie wszystkie narody, a zgromadzi ku sobie wszystkie ludzie.
###### **Ha 2,6**
 Izali nie ci wszyscy wezmą nań przypowieść, i przysłowie zagadek o nim: i rzeką: Biada temu, kto rozmnaża nie swoje: dokądże? i obciąża przeciw sobie gęste błoto?
###### **Ha 2,7**
 Izali nie nagle powstaną, którzy cię kąsać będą: i wzbudzeni będą szarpiący cię, i będziesz im na łupieztwo?
###### **Ha 2,8**
 Iżeś ty łupił narody mnogie, złupią cię wszyscy, którzy zostaną z narodów, dla krwie człowieczej, i dla krzywdy ziemie, miasta, i wszech mieszkających w niem.
###### **Ha 2,9**
 Biada, który zgromadza łakomstwo złe domowi swemu, aby było na wysokości gniazdo jego, a mniema, że się wybawi z ręki złego.
###### **Ha 2,10**
 Myśliłeś zawstydzenie domowi twemu, posiekłeś narodów wiele, i grzeszyła dusza twoja.
###### **Ha 2,11**
 Bo kamień z ściany wołać będzie: a drzewo, które między spojeniem budowania jest, odpowie.
###### **Ha 2,12**
 Biada, kto buduje miasto krwią, a gotuje miasto nieprawością.
###### **Ha 2,13**
 Izali to nie jest od Pana zastępów? Bo będą pracować ludzie w wielkim ogniu: a narodowie po próżnicy, i ustaną.
###### **Ha 2,14**
 Bo się napełni ziemia, aby poznali chwałę Pańską, jako wody okrywające morze.
###### **Ha 2,15**
 Biada, który dawał napój przyjacielowi swemu, wpuszczając żółć swoję, i upajając, aby oglądał nagość jego.
###### **Ha 2,16**
 Napełniłeś się sromoty miasto sławy: pij też ty, i usni: ogarnie cię kubek prawice Pańskiej, i wracanie sromotne nad chwałą twoją.
###### **Ha 2,17**
 Albowiem nieprawość Libanu okryje cię, i spustoszeniem bydła odstraszy je dla krwie ludzi, i krzywdy ziemie i miasta, i wszech mieszkających w niem.
###### **Ha 2,18**
 Co pomoże rycina, że ji wyrzezał uczyniciel jego, licina, i obraz fałeszny? iż miał nadzieję w uczynku uczyniciel jego, aby uczynił bałwany nieme.
###### **Ha 2,19**
 Biada, który mówi drewnu: Ocuć się: Wstań, kamieniowi milczącemu. Izali ten nauczyć będzie mógł? Oto ten okryty jest złotem i srebrem: a ducha żadnego niemasz we wnętrznościach jego.
###### **Ha 2,20**
 Ale Pan w kościele swym świętym: niech milczy od oblicza jego wszystka ziemia.
