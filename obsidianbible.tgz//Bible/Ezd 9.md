# Ezd 9 BT5
###### **Ezd 9,1**
 Po dokonaniu tego przybliżyli się do mnie książęta z tymi słowami: «***Lud izraelski, kapłani i lewici nie trzymali się z dala od narodów tych krain, jak i od ich okropności, mianowicie – z dala od Kananejczyków, Chittytów, Peryzzytów, Jebusytów, Ammonitów, Moabitów, Egipcjan i Amorytów,***
###### **Ezd 9,2**
 ***lecz spośród córek ich wzięli dla siebie i dla synów swoich żony, tak że rod święty zmieszał się z narodami tych krain; a książęta i zwierzchnicy przodowali w tym wiarołomstwie***».
###### **Ezd 9,3**
 Gdy tę wieść usłyszałem, rozdarłem swoją szatę i płaszcz, wyrywałem sobie włosy z głowy i brody i wstrząśnięty usiadłem.
###### **Ezd 9,4**
 Wtedy zebrali się dokoła mnie wszyscy, którzy z powodu tego wiarołomstwa wygnańców lękali się gróźb Boga Izraela. A ja wstrząśnięty siedziałem aż do ofiary wieczornej.
###### **Ezd 9,5**
 W czasie ofiary wieczornej wstałem z upokorzenia swego, w rozdartej szacie i płaszczu padłem na kolana, wyciągnąłem dłonie do Pana, Boga mojego,
###### **Ezd 9,6**
 i rzekłem: «***Boże mój! Bardzo się wstydzę, Boże mój, podnieść twarz do Ciebie, albowiem przestępstwa nasze urosły powyżej głowy, a wina nasza wzbiła się do nieba.***
###### **Ezd 9,7**
 ***Od dni ojców naszych aż po dziś dzień ciąży na nas wielka wina. My, królowie nasi, kapłani nasi zostaliśmy wydani za nasze przestępstwa pod władzę królów tych krain, pod miecz, w niewolę, na złupienie i na publiczne pośmiewisko, jak to jest dziś.***
###### **Ezd 9,8**
 ***A teraz zaledwie na chwilę przyszło zmiłowanie od Pana, Boga naszego, przez to, że pozostawił nam garstkę ocalonych, że w swoim miejscu świętym dał nam schronienie, że Bóg nasz rozjaśnił oczy nasze i że pozwolił nam w niewoli naszej trochę odetchnąć,***
###### **Ezd 9,9**
 ***bo przecież jesteśmy niewolnikami. Ale w niewoli naszej nie opuścił nas Bóg nasz, lecz dał nam znaleźć względy u królów perskich, pozwalając nam odżyć, byśmy mogli wznieść dom Boga naszego i odbudować jego ruiny – dając nam ostoję w Judzie i Jerozolimie.***
###### **Ezd 9,10**
 ***A teraz, Boże nasz, co powiemy, że po tym znowu przekroczyliśmy Twoje przykazania,***
###### **Ezd 9,11**
 ***które nadałeś przez swoje sługi, proroków, tymi słowami: Ziemia, w której posiadanie wchodzicie, jest ziemią splamioną przez rozpustę tych obcych narodów, przez ich obrzydliwości, którymi ją w nieczystości swej napełnili od końca do końca.***
###### **Ezd 9,12**
 ***Zatem nie wydawajcie córek swoich za ich synów ani nie bierzcie ich córek dla synów swoich. Dalej: nie troszczcie się nigdy o ich pomyślność i szczęście, abyście się wzmocnili i spożywali plon tej ziemi oraz pozostawili ją na zawsze w spadku synom swoim.***
###### **Ezd 9,13**
 ***I po tym wszystkim, co przyszło na nas za nasze złe uczynki i za naszą wielką winę – a przecież Ty, Boże nasz, wymierzyłeś karę poniżej naszej winy i pozostawiłeś nam tylu ocalonych –***
###### **Ezd 9,14**
 ***czy znowu mamy przekraczać Twoje polecenia i spowinowacać się z tymi obrzydliwymi narodami? Czy nie rozgniewasz się na nas aż do wytępienia, tak że nie pozostanie Reszta ocalonych?***
###### **Ezd 9,15**
 ***Panie, Boże Izraela, to łaska Twoja, żeśmy tym razem pozostali ocaleni. Oto jesteśmy przed Tobą obarczeni winą. Zaprawdę, niepodobna wobec tego ostać się przed Tobą***».
# Ezd 9 PAU
###### **Ezd 9,1**
 Gdy zakończono to wszystko, przyszli do mnie przywódcy i powiedzieli: „Niestety, ani lud Izraela, ani kapłani i lewici nie odłączyli się od ludów zamieszkujących tę ziemię, to znaczy od obrzydliwości Kananejczyków, Chetytów, Peryzzytów, Jebusytów, Ammonitów, Moabitów, Egipcjan i Amorytów.
###### **Ezd 9,2**
 Oni bowiem i ich synowie wzięli sobie za żony kobiety z tych narodów i w ten sposób święte potomstwo zmieszało się z obcymi. W tym wiarołomstwie przodowali przywódcy i zwierzchnicy”.
###### **Ezd 9,3**
 Gdy to usłyszałem, rozdarłem swój płaszcz i szaty, zacząłem rwać włosy z głowy i brody i usiadłem wstrząśnięty.
###### **Ezd 9,4**
 Wokół mnie zgromadzili się wszyscy przerażeni słowami groźby Boga Izraela wobec wiarołomstwa repatriantów, a ja siedziałem zdruzgotany aż do wieczornej ofiary pokarmowej.
###### **Ezd 9,5**
 Dopiero wtedy otrząsnąłem się z przygnębienia i mając swój płaszcz i szaty rozdarte, rzuciłem się na kolana z rękami wyciągniętymi ku PANU, mojemu Bogu.
###### **Ezd 9,6**
 I tak się modliłem: „Boże mój, bardzo się wstydzę! I nie śmiem, mój Boże, zwrócić twarzy ku Tobie, gdyż nasze winy wyrastają nam ponad głowę, a nasze przestępstwa sięgają aż do nieba!
###### **Ezd 9,7**
 Od czasu naszych przodków ciąży nad nami wielka wina aż do dzisiaj. Z powodu naszych przestępstw my, nasi królowie i kapłani zostaliśmy wydani władcom obcych narodów na pastwę miecza, w niewolę, na łup i pośmiewisko, czego dziś doświadczamy.
###### **Ezd 9,8**
 Oto jakby na krótką chwilę spotkała nas łaska od PANA, naszego Boga. Ocalił nas garstkę i dał nam oparcie w swoim świętym miejscu. Bóg nasz dał światło naszym oczom i odrobinę wytchnienia w niedoli.
###### **Ezd 9,9**
 Jesteśmy bowiem nadal w niewoli, tyle że w tej niewoli Bóg nas nie opuścił. Okazał nam miłosierdzie wobec królów perskich, tak że wznieśliśmy dom naszego Boga, zdołaliśmy dźwignąć miasto z ruin, uzyskaliśmy odrębność Judy i mur obronny w Jerozolimie.
###### **Ezd 9,10**
 Cóż mamy teraz powiedzieć Tobie, Boże nasz?! Znowu przekroczyliśmy Twoje przykazania,
###### **Ezd 9,11**
 które nadałeś przez sługi swoje, proroków, mówiąc: «Ziemia, do której idziecie, aby ją posiąść, jest ziemią splugawioną obrzydliwościami obcych narodów, które wypełniły ją swoją nieczystością od krańca do krańca.
###### **Ezd 9,12**
 Dlatego nie będziecie wydawać waszych córek za mąż ich synom ani żenić waszych synów z ich córkami. Nie będziecie też nigdy zabiegać o ich dobrobyt ani szukać z nimi pokoju - jeśli chcecie stać się silni, korzystać z dóbr ziemi i pozostawić waszym dzieciom wieczyste dziedzictwo».
###### **Ezd 9,13**
 Po tym wszystkim, co teraz uzyskaliśmy mimo złych czynów i naszej wielkiej winy - bowiem Ty, Boże nasz, wymierzyłeś nam karę łagodniejszą od naszej winy i tak wielu ocaliłeś –
###### **Ezd 9,14**
 czyż mamy na nowo łamać Twoje przykazania i spokrewniać się z narodami, które czynią te obrzydliwości?! Czyż nie zapłonie Twój gniew przeciwko nam aż do całkowitej zagłady, tak że nie pozostanie nawet reszta ocalonych?
###### **Ezd 9,15**
 PANIE, Boże Izraela! Ty jesteś sprawiedliwy i dzięki temu jesteśmy jeszcze tutaj jako reszta ocalałych. Ale stoimy przed Tobą splamieni winą. Z takim jednak grzechem nie sposób ostać się przed Tobą!”.
# Ezd 9 BP
###### **Ezd 9,1**
 Gdy sprawy te zostały ukończone, przystąpili do mnie przełożeni i rzekli: Lud izraelski, kapłani i lewici wcale nie zerwali z ludnością tego kraju. Naśladują obrzydliwości Kananejczyków, Chittytów, Peryzzytów, Jebuzytów, Ammonitów, Moabitów, Egipcjan i Amorytów.
###### **Ezd 9,2**
 Spośród ich córek pobrali żony dla siebie i swoich synów, i tak święte nasienie pomieszało się z ludnością tego kraju, a w niewierności tej pierwszymi byli książęta i przełożeni.
###### **Ezd 9,3**
 Skoro wieść ta doszła do moich uszu, rozerwałem szaty moje i płaszcz mój, rwałem włosy z głowy i brody i siedziałem do głębi wstrząśnięty.
###### **Ezd 9,4**
 Wokół mnie zgromadzili się wszyscy, którzy drżeli z obawy przed groźnymi słowami Boga Izraela z powodu niewierności wygnańców. Ja zaś wstrząśnięty do głębi siedziałem tak aż do ofiary wieczornej.
###### **Ezd 9,5**
 W porze ofiary wieczornej wyszedłem [ze stanu] mego przygnębienia i w szacie, i płaszczu rozdartym upadłem na kolana, a wznosząc ręce do Jahwe, mojego Boga,
###### **Ezd 9,6**
 wołałem: Boże mój, wstyd i poniżenie moje są tak wielkie, że nie śmiem podnieść oblicza mego do Ciebie, Boże mój; bowiem przestępstwa nasze urosły ponad nasze głowy, a wina nasza sięga aż do nieba.
###### **Ezd 9,7**
 Od dni ojców naszych aż do dnia dzisiejszego wielka jest nasza wina, a na skutek naszych grzechów my, królowie nasi i kapłani zostaliśmy wydani w ręce królów tych krajów pod miecz, w niewolę, na spustoszenie i na wstyd, jak to jest i dzisiaj.
###### **Ezd 9,8**
 Oto teraz na czas krótki Jahwe, Bóg nasz, okazał nam miłosierdzie. Pozostawił nam naszą ocalałą Resztę i dał nam schronienie w swoim świętym miejscu. W ten sposób Bóg nasz oświecił nam oczy i udzielił nieco wytchnienia w naszej niewoli.
###### **Ezd 9,9**
 Jesteśmy bowiem niewolnikami, ale w niewoli naszej nie opuścił nas Bóg nasz. Nakłonił ku nam łaskę królów perskich i udzielił nam wytchnienia, byśmy mogli odbudować Świątynię Bożą i dźwignąć ją z gruzów, oraz dał nam ostoję w Judzie i Jeruzalem.
###### **Ezd 9,10**
 Teraz wszakże, o Boże nasz, cóż mamy do powiedzenia po tym wszystkim? Przekroczyliśmy Twoje przykazania,
###### **Ezd 9,11**
 które przekazałeś nam za pośrednictwem Twoich sług, Proroków, w następujących słowach: "Ziemia, na którą wkraczacie, by ją objąć w posiadanie, jest ziemią nieczystości, splamioną nieczystością ludzi tego kraju przez ich obrzydliwości, którymi w swym nieczystym usposobieniu napełnili ją od krańca do krańca.
###### **Ezd 9,12**
 Dlatego nie wydawajcie swych córek za ich synów ani nie bierzcie ich córek dla swoich synów. Nie troszczcie się nigdy ani o ich szczęście, ani powodzenie, byście się wzmocnili pożywając plony tego kraju i mogli przekazać go w dziedzictwie swoim synom na wieki."
###### **Ezd 9,13**
 Po tym wszystkim, co spadło na nas z powodu naszych niegodziwych czynów i wielkiej naszej winy - chociaż Ty, Boże nasz, oszczędzając nas wymierzyłeś nam mniejszą karę, niż byliśmy winni, i pozostawiłeś nam tę ocalałą Resztę -
###### **Ezd 9,14**
 czyż mielibyśmy od nowa gwałcić Twoje przykazania i wstępować w związki małżeńskie z ludami tak obrzydliwymi? Czyż gniew Twój nie posunie się aż do wyniszczenia, nie pozostawiając nam ani Reszty, ani nikogo z ocalałych?
###### **Ezd 9,15**
 Jahwe, Boże Izraela, Ty okazałeś się sprawiedliwym, skoro i dziś jeszcze stanowimy tę Resztę ocalonych! Otośmy przed obliczem Twoim z naszą winą, gdyż z powodu niej nie sposób nam ostać się przed Tobą.
# Ezd 9 BR
###### **Ezd 9,1**
 Kiedy już ukończono przekazywanie darów, starsi ludu podeszli do mnie i powiedzieli: Lud izraelski, kapłani i lewici nie trzymali się z dala od narodów [pogańskich] mieszkających w tym kraju. Naśladowali obrzydliwości Kananejczyków, Chetytów, Peryzzytów, Jebuzytów, Ammonitów, Moabitów, Egipcjan i Amorytów.
###### **Ezd 9,2**
 Ich córki bowiem brali za żony i dla siebie, i dla swoich synów, i tak ów święty naród zmieszał się z narodami zamieszkującymi tę ziemię. A przywódcy ludu jako pierwsi dopuszczali się tego rodzaju występków.
###### **Ezd 9,3**
 Kiedy się o tym dowiedziałem, rozdarłem moją szatę i płaszcz, zacząłem rwać włosy z głowy i brody i usiadłem bardzo zasmucony.
###### **Ezd 9,4**
 Wokół mnie zgromadzili się ci wszyscy, którzy drżeli z powodu słów Boga Izraela, a także z powodu występków tych, którzy wrócili z wygnania. I tak siedziałem pełen zatroskania aż do ofiary wieczornej.
###### **Ezd 9,5**
 Podczas składania ofiary wieczornej podniosłem się, nadal bardzo przygnębiony, w podartych szatach i w poszarpanym płaszczu, i upadłszy na kolana, wzniosłem ręce do Jahwe, mojego Boga,
###### **Ezd 9,6**
 i tak zacząłem się modlić: Boże mój! Tak bardzo mi wstyd [z powodu tego narodu], że nie mam odwagi podnieść ku Tobie moich oczu, o Boże. Nasze występki bowiem sięgają już ponad nasze głowy, a wieść o naszych zbrodniach dociera aż do nieba.
###### **Ezd 9,7**
 Od dni naszych ojców aż do obecnej chwili dźwigamy na sobie ciężkie przewinienia. To właśnie z powodu naszych win zostaliśmy niegdyś wydani, my sami, nasi królowie i kapłani, w ręce obcych królów. Niszczono nas mieczem, skazywano na wygnanie, pozbawiano nas wszystkiego i upokarzano, i tak dzieje się po dzień dzisiejszy.
###### **Ezd 9,8**
 I oto teraz Jahwe, nasz Bóg, okazał nam na chwilę swoje miłosierdzie, zostawiając resztę spośród nas przy życiu i udzielając nam schronienia na swoim świętym miejscu, aby rozjaśnić nasze oczy i darować nam jeszcze nieco wytchnienia w naszej niewoli.
###### **Ezd 9,9**
 Jesteśmy bowiem niewolnikami. Nie opuścił nas jednak Bóg w naszym poniżeniu. Natchnął życzliwością względem nas królów perskich. Oni to darowali nam życie, żebyśmy mogli odbudować świątynię dla naszego Boga i usunąć z niej całe rumowisko, i tak znaleźć miejsce oparcia dla siebie na ziemi judzkiej i w Jerozolimie.
###### **Ezd 9,10**
 I cóż mamy Ci teraz powiedzieć po tym wszystkim, o Boże nasz? Chyba to jedno, że znów złamaliśmy przykazania,
###### **Ezd 9,11**
 które nam ogłosiłeś przez usta sług Twoich. To oni przecież mówili nam: Kraj do którego wchodzicie, aby wziąć go w posiadanie, jest pełen nieczystości; zamieszkujące go narody zbrukały go od krańca do krańca obrzydliwościami, którymi są przepełnione.
###### **Ezd 9,12**
 Strzeżcie się więc, żeby nie dawać waszych córek za żony ich synom ani nie brać ich córek za żony dla waszych synów. Poza tym nie wolno wam troszczyć się o ich dobrobyt ani przysparzać im bogactwa, żebyście sami stawali się coraz silniejsi. To wy macie spożywać najlepsze plony tej ziemi, którą przekażecie kiedyś jako dziedzictwo waszym dzieciom.
###### **Ezd 9,13**
 Po tym wszystkim, co nas spotkało z powodu naszych złych czynów i wielkich nieprawości - choć darowałeś nam życie, o Boże nasz, mimo iż wcale nie zasłużyliśmy na to, i ocaliłeś spośród nas resztę, którą właśnie jesteśmy -
###### **Ezd 9,14**
 czy ośmielilibyśmy się znów łamać Twoje prawa i wiązać się z tymi narodami, tak odrażającymi? Czyż nie zapłonąłbyś wtedy wielkim gniewem? Czy nie zgładziłbyś nas tak, że już nikt by się nie ostał?
###### **Ezd 9,15**
 O Jahwe, Boże Izraela, Ty jesteś samą sprawiedliwością i dlatego ocaliłeś nas jako resztę. Stajemy dziś przed Tobą obciążeni naszymi winami, z powodu których [wiemy to dobrze] nie jesteśmy godni trwać przed Twoim obliczem.
# Ezd 9 WUJ
###### **Ezd 9,1**
 A gdy się to odprawiło, przystąpili do mnie przełożeni, mówiąc: Nie odłączył się lud Izraelski, kapłani i Lewitowie od narodów ziem i od obrzydłości ich, to jest od Chananejczyka i Hethejczyka, i Pherezejczyka, i Jebuzejczyka, i Ammonitów, i Moabitów, i Egiptcyanów, i Amorrejczyków:
###### **Ezd 9,2**
 Bo spojmowali córki ich sobie i synom swym: i pomieszali nasienie święte z ludźmi ziem: ręka też książąt, i urzędu w tem przestępstwie pierwsza była,
###### **Ezd 9,3**
 A gdym usłyszał tę rzecz, rozdarłem płaszcz mój i suknią, i rwałem włosy na głowie mojej i brodzie, i siedziałem smutny.
###### **Ezd 9,4**
 I zeszli się do mnie wszyscy, którzy się bali słowa Boga Izraelowego, dla przestępstwa tych, którzy się byli z niewolej wrócili: a jam siedział smutny aż do ofiary wieczornej:
###### **Ezd 9,5**
 A w ofiarę wieczorną wstałem z utrapienia mego, a rozdarszy płaszcz i suknią, poklęknąłem na kolana moje i rozciągnąłem ręce swe ku Panu Bogu memu.
###### **Ezd 9,6**
 I rzekłem: Boże mój, wstydci mię a sromam się podnieść oblicze moje do ciebie: bo nieprawości nasze rozmnożyły się nad głowę naszę, i grzechy nasze urosły aż do nieba,
###### **Ezd 9,7**
 Ode dni ojców naszych: lecz i my sami zgrzeszyliśmy ciężko aż do dnia tego: a przez nieprawości nasze wydaniśmy sami, i królowie naszy, i kapłani naszy w ręce królów ziemskich, i pod miecz, i w niewolą i na łup, i na zawstydzenie twarzy, jako i dnia tego.
###### **Ezd 9,8**
 A teraz jakoby trochę i na mały czas stała się prośba nasza u Pana Boga naszego, żeby nam zostawiono ostatek, i dany był kołek na miejscu jego świętem i oświecił oczy nasze Bóg nasz, a dał nam trochę żywota w niewolstwie naszem:
###### **Ezd 9,9**
 Bośmy niewolnicy, a w niewolej naszej nie opuścił nas Bóg nasz, ale nakłonił na nas miłosierdzie przed królem Perskim, aby nam dał żywot, i wywyższył dom Boga naszego, i zbudował spustoszenia jego, i dał nam płot w Judzie i w Jeruzalem.
###### **Ezd 9,10**
 A teraz co rzeczemy Boże nasz potem? Bośmy opuścili przykazania twoje.
###### **Ezd 9,11**
 Któreś rozkazał w ręce sług twoich proroków mówiąc: Ziemia, do której wy wchodzicie, abyście ją posiedli, ziemia plugawa jest wedle plugastwa narodów i inszych ziem, i obrzydłości onych, którzy ją napełnili od brzegu aż do brzegu w splugawienia swem.
###### **Ezd 9,12**
 Teraz tedy córek waszych nie dajcie synom ich, i córek ich nie bierzcie synom waszym, i nie szukajcie pokoju ich, i szczęścia ich aż do wieku: abyście byli umocnieni i pożywali dóbr ziemie, żebyście dziedzice mieli syny wasze aż na wieki,
###### **Ezd 9,13**
 A po wszystkiem co przyszło na nas dla uczynków naszych złych, i dla grzechu naszego wielkiego, żeś ty Boże nasz wybawił nas z nieprawości naszej, i dałeś nam zbawienie jako jest dziś,
###### **Ezd 9,14**
 Abyśmy się nie wracali, i nie gwałcili przykazania, twego, i nie wstępowali w małżeństwa, z narody tych obrzydłości. Izaliś się rozgniewał na nas aż do zginienia, żebyś nam nie zostawił ostatków na wybawienie?
###### **Ezd 9,15**
 Panie Boże Izraelów tyś jest sprawiedliwy: żeśmy zostali, którzybyśmy byli wybawieni, jako dnia tego, Otośmy przed tobą w przewinieniu naszem. Bo nie może się ostać przed tobą dla tego.
