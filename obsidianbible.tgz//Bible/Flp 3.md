# Flp 3 BT5
###### **Flp 3,1**
 Na koniec, bracia moi, radujcie się w Panu! Pisanie do was o tym samym nie jest dla mnie uciążliwe, a dla was jest środkiem niezawodnym.
###### **Flp 3,2**
 Strzeżcie się psów, strzeżcie się złych pracowników, strzeżcie się okaleczeńców!
###### **Flp 3,3**
 My bowiem jesteśmy prawdziwie ludem obrzezanym – my, którzy sprawujemy kult w Duchu Bożym i chlubimy się w Chrystusie Jezusie, a nie pokładamy ufności w ciele.
###### **Flp 3,4**
 Chociaż ja także i w ciele mogę pokładać ufność. Jeśli ktoś inny mniema, że może ufność złożyć w ciele, to ja tym bardziej:
###### **Flp 3,5**
 obrzezany ósmego dnia, z rodu Izraela, z pokolenia Beniamina, Hebrajczyk z Hebrajczyków, w stosunku do Prawa – faryzeusz,
###### **Flp 3,6**
 co do gorliwości – prześladowca Kościoła, co do sprawiedliwości legalnej – stałem się bez zarzutu.
###### **Flp 3,7**
 Ale to wszystko, co było dla mnie zyskiem, ze względu na Chrystusa uznałem za stratę.
###### **Flp 3,8**
 I owszem, nawet wszystko uznaję za stratę ze względu na najwyższą wartość poznania Chrystusa Jezusa, mojego Pana. Dla Niego wyzułem się ze wszystkiego i uznaję to za śmieci, bylebym pozyskał Chrystusa
###### **Flp 3,9**
 i znalazł się w Nim – nie mając mojej sprawiedliwości, pochodzącej z Prawa, lecz Bożą sprawiedliwość, otrzymaną dzięki wierze w Chrystusa, sprawiedliwość pochodzącą od Boga, opartą na wierze –
###### **Flp 3,10**
 przez poznanie Go: zarówno mocy Jego zmartwychwstania, jak i udziału w Jego cierpieniach – w nadziei, że upodabniając się do Jego śmierci,
###### **Flp 3,11**
 dojdę jakoś do pełnego powstania z martwych.
###### **Flp 3,12**
 Nie [mówię], że już [to] osiągnąłem i już się stałem doskonały, lecz pędzę, abym też [to] zdobył, bo i sam zostałem zdobyty przez Chrystusa Jezusa.
###### **Flp 3,13**
 Bracia, ja nie sądzę o sobie samym, że już zdobyłem, ale to jedno [czynię]: zapominając o tym, co za mną, a wytężając siły ku temu, co przede mną,
###### **Flp 3,14**
 pędzę ku wyznaczonej mecie, ku nagrodzie, do jakiej Bóg wzywa w górę, w Chrystusie Jezusie.
###### **Flp 3,15**
 Wszyscy więc my, doskonali, tak to rozumiejmy: a jeśli rozumiecie coś inaczej, i to Bóg wam objawi.
###### **Flp 3,16**
 W każdym razie: dokąd doszliśmy, w tę samą stronę zgodnie postępujmy!
###### **Flp 3,17**
 Bądźcie, bracia, wszyscy razem moimi naśladowcami i wpatrujcie się w tych, którzy tak postępują, jak tego wzór macie w nas.
###### **Flp 3,18**
 Wielu bowiem postępuje jak wrogowie krzyża Chrystusowego, o których często wam mówiłem, a teraz mówię z płaczem.
###### **Flp 3,19**
 Ich losem – zagłada, ich bogiem – brzuch, a chwała – w tym, czego winni się wstydzić. To ci, których dążenia są przyziemne.
###### **Flp 3,20**
 Nasza bowiem ojczyzna jest w niebie. Stamtąd też jako Zbawcy wyczekujemy Pana Jezusa Chrystusa,
###### **Flp 3,21**
 który przekształci nasze ciało poniżone w podobne do swego chwalebnego ciała tą mocą, jaką może On także wszystko, co jest, sobie podporządkować.
# Flp 3 PAU
###### **Flp 3,1**
 W końcu, bracia moi, radujcie się w Panu! Nie jest mi ciężko pisać wam o tym, dla was zaś jest to pożyteczne.
###### **Flp 3,2**
 Strzeżcie się psów, strzeżcie się złych pracowników, strzeżcie się okaleczenia.
###### **Flp 3,3**
 To my jesteśmy obrzezaniem, my, którzy sprawujemy kult w Duchu Bożym, chlubimy się Chrystusem Jezusem i w ciele nie pokładamy ufności.
###### **Flp 3,4**
 Chociaż ja mogę pokładać ufność także w ciele. Jeśli ktoś uważa, że może pokładać ufność w ciele, to ja tym bardziej:
###### **Flp 3,5**
 obrzezany ósmego dnia, z narodu izraelskiego, z plemienia Beniamina, Hebrajczyk z Hebrajczyków. W stosunku do Prawa - faryzeusz,
###### **Flp 3,6**
 co do gorliwości - prześladowca Kościoła, a jeśli chodzi o sprawiedliwość opartą na Prawie - nic mi nie można zarzucić.
###### **Flp 3,7**
 Jednak ze względu na Chrystusa uznaję za bezwartościowe wszystko, co przynosiło mi zysk.
###### **Flp 3,8**
 I naprawdę uważam, że to wszystko jest bezwartościowe w porównaniu z bezcennym darem poznania Chrystusa Jezusa, mojego Pana. Dla Niego odrzucam wszystko i uważam za śmieci. Pragnę tylko pozyskać Chrystusa
###### **Flp 3,9**
 i znaleźć się w Nim, nie w oparciu o własną sprawiedliwość, pochodzącą z Prawa, ale dzięki sprawiedliwości, która rodzi się przez wiarę w Chrystusa i której Bóg udziela na podstawie wiary.
###### **Flp 3,10**
 Moim celem jest poznanie Chrystusa, zarówno przez doświadczenie mocy Jego zmartwychwstania, jak i przez udział w Jego cierpieniach. A stając się podobnym do Niego w Jego śmierci,
###### **Flp 3,11**
 dojdę w jakiś sposób do powstania z martwych.
###### **Flp 3,12**
 Nie twierdzę, że to już osiągnąłem lub stałem się doskonały. Usiłuję to dopiero zdobyć, gdyż i ja zostałem zdobyty przez Chrystusa Jezusa.
###### **Flp 3,13**
 Bracia, ja nie wmawiam sobie, że osiągnąłem cel. Ale jedno czynię: zapominając o tym, co jest za mną, a zwracając się ku temu, co przede mną,
###### **Flp 3,14**
 biegnę ku mecie po nagrodę, do której Bóg wzywa w górę w Chrystusie Jezusie.
###### **Flp 3,15**
 Będąc doskonałymi, tak właśnie rozumujmy; a gdybyście nawet inaczej rozumowali, Bóg was oświeci.
###### **Flp 3,16**
 Jeśli zaś jesteśmy na właściwej drodze, podążajmy nią dalej.
###### **Flp 3,17**
 Bracia, naśladujcie mnie i patrzcie na tych, którzy postępują według naszego przykładu.
###### **Flp 3,18**
 Wielu bowiem postępuje jak wrogowie krzyża Chrystusa. O nich często wam mówiłem, a teraz mówię ze łzami.
###### **Flp 3,19**
 Ich losem jest zagłada, ich bogiem - brzuch, a ich chwałą - pohańbienie. Myślą oni w sposób przyziemny.
###### **Flp 3,20**
 Nasza zaś ojczyzna jest w niebie. Stamtąd też oczekujemy Zbawiciela, Pana, Jezusa Chrystusa,
###### **Flp 3,21**
 który przemieni nasze marne ciało i upodobni je do swego chwalebnego ciała. Dokona tego mocą zdolną wszystko sobie podporządkować.
# Flp 3 BP
###### **Flp 3,1**
 Na koniec, bracia moi, radujcie się w Panu. Powtarzanie tego nie jest dla mnie uciążliwe, a was umacnia.
###### **Flp 3,2**
 Strzeżcie się psów, strzeżcie się złych pracowników, strzeżcie się fałszywych obrzezańców.
###### **Flp 3,3**
 Bo prawdziwie obrzezani to my jesteśmy, którzy pod wpływem Ducha czcimy Boga i chlubimy się w Chrystusie Jezusie, a nie pokładamy ufności w ciele.
###### **Flp 3,4**
 Ja wprawdzie mógłbym pokładać ufność w ciele. Jeśli bowiem komuś się wydaje, że może swoją ufność pokładać w ciele, to ja tym bardziej.
###### **Flp 3,5**
 Obrzezany zostałem ósmego dnia, jestem z rodu Izraela, z pokolenia Beniamina, Hebrajczyk z Hebrajczyków, w stosunku do Prawa byłem faryzeuszem,
###### **Flp 3,6**
 a pod względem gorliwości prześladowcą Kościoła, w wypełnianiu legalnej sprawiedliwości - bez zarzutu.
###### **Flp 3,7**
 Ale to wszystko, co miało dla mnie wartość, ze względu na Chrystusa uznaję za bezwartościowe.
###### **Flp 3,8**
 I naprawdę uważam za stratę to wszystko w porównaniu z najwyższą wartością, jaką jest poznanie Chrystusa Jezusa, mojego Pana. Właśnie dla Niego wyzbyłem się tego wszystkiego i uważam to za śmieci,
###### **Flp 3,9**
 bylebym tylko mógł zdobyć Chrystusa i w Nim się znaleźć, nie mając mojej sprawiedliwości [płynącej] z Prawa, ale tę, którą daje wiara w Chrystusa - Bożą, opartą na wierze.
###### **Flp 3,10**
 Dzięki niej poznam zarówno Jego, jak i moc Jego zmartwychwstania, będę miał udział w Jego cierpieniach [w nadziei], że upodabniając się do Niego w śmierci,
###### **Flp 3,11**
 dojdę do chwalebnego powstania z martwych.
###### **Flp 3,12**
 Nie dlatego, żebym już to zdobył i osiągnął doskonałość, lecz staram się ze wszystkich sił pochwycić Chrystusa Jezusa, tak jak ja [przez Niego] zostałem pochwycony.
###### **Flp 3,13**
 Bracia, ja nie myślę, że już to osiągnąłem. Ale jedno czynię: zapominając o tym, co poza mną, usilnie podążam ku temu, co przede mną,
###### **Flp 3,14**
 biegnę naprzód po nagrodę w niebie, dokąd wzywa Bóg w Chrystusie Jezusie.
###### **Flp 3,15**
 Przeto wszyscy doskonali taką przyjmijmy postawę, a jeśli co z tego inaczej pojmujecie, Bóg wam i to odsłoni.
###### **Flp 3,16**
 Trzeba wytrwać przy tym, co już osiągnęliśmy.
###### **Flp 3,17**
 Bracia, bądźcie moimi naśladowcami, uważnie patrzcie na tych, którzy idą za wzorem, jaki w nas macie.
###### **Flp 3,18**
 Bo wielu postępuje tak - o czym wam już nieraz mówiłem, a teraz ze łzami powtarzam jak wrogowie krzyża Chrystusowego.
###### **Flp 3,19**
 Ich końcem zatracenie, bogiem - brzuch, a chwała ich w tym, czego winni się wstydzić.
###### **Flp 3,20**
 Lecz naszą ojczyzną jest niebo, stamtąd też wyglądamy Zbawiciela, Pana Jezusa Chrystusa,
###### **Flp 3,21**
 który przemieni nasze ciało poniżone i uczyni je podobnym do swego ciała uwielbionego swoją mocą, mogącą poddać wszystko pod Jego panowanie.
# Flp 3 BR
###### **Flp 3,1**
 A teraz, bracia moi, radujcie się w Panu. Nie sprawia mi żadnych trudności pisanie wam po raz drugi o tym, co już słyszeliście, a dla was samych to nawet tym większa gwarancja uniknięcia niebezpieczeństwa.
###### **Flp 3,2**
 Otóż upominam was: strzeżcie się [ludzi złych], owych psów, pseudopracowników [Pańskich], unikajcie okaleczeńców [dopuszczających się obrzezania].
###### **Flp 3,3**
 To my właśnie jesteśmy [a nie oni] ludem prawdziwie obrzezanym, my, którzy służymy Bogu przez Jego Ducha i całą naszą ufność pokładamy w Jezusie Chrystusie, a nie w ludzkim ciele.
###### **Flp 3,4**
 Choć z drugiej strony ja osobiście mogę się chlubić także moim ciałem. Jeśli ktokolwiek inny uważa, że ma do tego prawo, to ja posiadam o wiele więcej powodów, by tak o sobie sądzić.
###### **Flp 3,5**
 Zostałem bowiem obrzezany ósmego dnia po urodzeniu, jestem z urodzenia Izraelitą, pochodzę z pokolenia Beniamina, jestem Hebrajczykiem z czystej rasy hebrajskiej. Gdy zaś chodzi o mój stosunek do Prawa, [niech wystarczy to, że] byłem faryzeuszem.
###### **Flp 3,6**
 Powodowany religijnym zapałem stałem się prześladowcą Kościoła, a w przestrzeganiu Prawa nikt nie mógł mi nic zarzucić.
###### **Flp 3,7**
 Lecz wszystko to, tak kiedyś cenne dla mnie, teraz, ze względu na Chrystusa, zapisuję na straty.
###### **Flp 3,8**
 Zresztą wszystko inne również - w porównaniu z wartością, jaką przedstawia dla mnie możność poznania Chrystusa Jezusa, Pana mojego - uważam za stratę. Dla Chrystusa wyzbyłem się [dobrowolnie] wszystkiego i wszystko przedstawia dla mnie wartość nie większą niż zwykłe śmieci. Cenię sobie jedynie to, bym mógł pozyskać Chrystusa
###### **Flp 3,9**
 i zjednoczyć się z Nim całkowicie. I wcale już nie twierdzę, że sam dostąpiłem usprawiedliwienia [wskutek dokonania pewnych uczynków nakazanych] przez Prawo, lecz jestem przekonany, że sprawiedliwość, jaką posiadam, otrzymałem od Boga dzięki wierze w Chrystusa; sprawiedliwości takiej udziela Bóg każdemu, kto wierzy.
###### **Flp 3,10**
 Tak więc pragnę usilnie poznać Chrystusa, [by zrozumieć] moc Jego zmartwychwstania, mieć udział w Jego cierpieniach, stać się podobnym do Niego przez uczestniczenie w Jego śmierci i
###### **Flp 3,11**
 mieć nadzieję powrotu z martwych do życia.
###### **Flp 3,12**
 Wcale nie twierdzę, że już osiągnąłem przedmiot moich pragnień i że już jestem doskonały, lecz nie przestaję zdążać naprzód, bym mógł pochwycić wreszcie to, do czego zmierzam, bo sam już zostałem pochwycony przez Jezusa Chrystusa.
###### **Flp 3,13**
 Nie, bracia, wcale nie myślę, że ja osobiście już osiągnąłem cel [mojego życia]. Staram się bardzo usilnie o jedno: nie myśląc już o tym, co za mną, skupiam całą uwagę na tym, co przede mną, i
###### **Flp 3,14**
 zdążam wytrwale naprzód ku wyznaczonej mecie, po nagrodę, którą według obietnicy Boga mamy otrzymać na wysokościach przez Jezusa Chrystusa.
###### **Flp 3,15**
 Wszyscy my, ludzie duchowo dojrzali, mamy w ten sposób myśleć. A jeśli nawet znajdą się wśród was tacy, którzy będą myśleć inaczej, otrzymacie i pod tym względem odpowiednie światło od Boga.
###### **Flp 3,16**
 Lecz jakkolwiek by było, zdążajmy nadal tą samą drogą, którą kroczyliśmy dotychczas.
###### **Flp 3,17**
 Bracia! Wszyscy bądźcie naśladowcami moimi. Przypatrujcie się tym, którzy postępują zgodnie z przykładem zostawionym przez nas.
###### **Flp 3,18**
 Jest też wielu takich, którzy pokazują swoim życiem, że są wrogami Chrystusowego krzyża. Mówiłem wam o tym już wiele razy, a teraz powtarzam to z płaczem.
###### **Flp 3,19**
 Ludzi tych czeka [w przyszłości] zagłada, obecnie zaś bogiem ich jest brzuch, a chlubą to, czego powinni się wstydzić, przedmiotem zaś ich dążeń - tylko sprawy tego świata.
###### **Flp 3,20**
 Nasza ojczyzna jest w niebie i stamtąd oczekujemy przyjścia Pana naszego, Jezusa Chrystusa.
###### **Flp 3,21**
 On to właśnie przemieni nasze ciało przemijające w ciało chwalebne, podobne do Jego ciała. Dokona zaś tego potęgą, jaką może poddać pod swoją władzę wszystko, co istnieje.
# Flp 3 WUJ
###### **Flp 3,1**
 Naostatek bracia moi, weselcie się w Panu. Toż wam pisać, mnieć nie ciężko, a wam potrzebno.
###### **Flp 3,2**
 Patrzcie na psy, patrzcie na złe robotniki, upatrujcie porzezanie.
###### **Flp 3,3**
 Abowiem my jesteśmy obrzezaniem, którzy duchem służymy Bogu: i chlubimy się w Chrystusie Jezusie, a nie w ciele ufność mamy.
###### **Flp 3,4**
 Aczkolwiek ja mam ufanie i w ciele. Jeśli kto inszy zda się ufać w ciele: więcej ja.
###### **Flp 3,5**
 Obrzezany ósmego dnia, z narodu Izraelskiego, z pokolenia Benjamin, Hebreiczyk z Hebreiczyków, wedle zakonu Faryzeusz,
###### **Flp 3,6**
 Według żarzliwości prześladując kościół Boży: według sprawiedliwości, która jest w zakonie obcując bez przygany.
###### **Flp 3,7**
 Ale co mi było zyskiem, tom poczytał dla Chrystusa być szkodą.
###### **Flp 3,8**
 Owszem poczytam wszystko za szkodę dla wysokiego poznania Jezusa Chrystusa Pana mego: dla któregom wszystkiego postradał, i mam sobie za gnój, abym Chrystusa zyskał:
###### **Flp 3,9**
 I był nalezion w nim nie mając sprawiedliwości mojej, która jest z zakonu: ale tę, która jest z wiary Chrystusa Jezusa, która z Boga jest sprawiedliwość przez wiarę:
###### **Flp 3,10**
 Żebym go poznał, i moc zmartwychwstania jego, i społeczność utrapienia jego: przypodobany śmierci jego,
###### **Flp 3,11**
 Jeślibym jako zabieżał ku powstaniu, które jest z martwych.
###### **Flp 3,12**
 Nie iżbym już wziął, abo już doskonałym był: ale, gonię, jeślibym jako uchwycił, w czemem i uchwycony jest od Chrystusa Jezusa.
###### **Flp 3,13**
 Bracia, jać nie rozumiem, iżbych uchwycił. Lecz jedno tego co nazad jest zapamietywając, a do tego wprzód, wyciągając się.
###### **Flp 3,14**
 Bieżę do kresu ku zakładu wysokiego wezwania Bożego w Chrystusie Jezusie.
###### **Flp 3,15**
 Którzyśmykolwiek tedy doskonali, to rozumiejmy: a jeśli co inaczej rozumiecie, i to wam Bóg objawi.
###### **Flp 3,16**
 Wszakoż do czegośmy przyszli, abyśmy toż rozumieli, i w temże prawidle trwajmy.
###### **Flp 3,17**
 Bądźcie naśladowcami mojemi, bracia: a upatrujcie te, którzy tak chodzą jako macie wzór nasz.
###### **Flp 3,18**
 Boć wiele ich chodzi, którem wam często opowiadał (a teraz i płacząc powiadam) nieprzyjaciele krzyża Chrystusowego.
###### **Flp 3,19**
 Których koniec, zatracenie: których Bóg, jest brzuch: i chwała w sromocie ich, którzy ziemskie rzeczy miłują.
###### **Flp 3,20**
 A nasze obcowanie jest w niebiesiech: zkąd też zbawiciela oczekawamy, Pana naszego Jezusa Chrystusa,
###### **Flp 3,21**
 Który przemieni ciało podłości naszej przypodobane ciału jasności swojej wedle skuteczności , którą też wszystko podbić sobie może.
# Flp 3 STERN
###### **Flp 3,1**
 A zatem, bracia, radujcie się w jedności z Panem. Nie sprawia mi kłopotu powtarzanie tego, co już przedtem wam napisałem, a co dla was będzie zabezpieczeniem:
###### **Flp 3,2**
 strzeżcie się psów, tych złoczyńców, Okaleczeńców!
###### **Flp 3,3**
 Bo to my jesteśmy Obrzezanymi, my, którzy oddajemy cześć w Duchu Bożym i chlubimy się w Mesjaszu Jeszui! Nie pokładamy zaufania w atutach ludzkich,
###### **Flp 3,4**
 mimo że ja z pewnością mam podstawy, aby w takich rzeczach pokładać zaufanie. Jeśli kto inny sądzi, że ma podstawy pokładać zaufanie w ludzkich atutach, to ja mam po temu lepsze podstawy:
###### **Flp 3,5**
 b'rit-mila ósmego dnia, rodowity Izraelita, z plemienia Binjamina, hebrajskojęzyczny i z hebrajskojęzycznymi rodzicami, co do Tory - parusz,
###### **Flp 3,6**
 co do zapału - prześladowca Wspólnoty Mesjanicznej, co do sprawiedliwości wymaganej przez legalizm - bez zarzutu.
###### **Flp 3,7**
 Ale te rzeczy, które zwykłem uznawać za korzyści, z powodu Mesjasza zacząłem uważać za stratę.
###### **Flp 3,8**
 I nie tylko to, ale wszystko uznaję za stratę w porównaniu z najwyższą wartością poznania Mesjasza Jeszui jako mojego Pana. To ze względu na Niego porzuciłem wszystko i uważam to wszystko za śmieci, aby tylko zyskać Mesjasza
###### **Flp 3,9**
 i znaleźć się w jedności z Nim, nie mając żadnej własnej sprawiedliwości, opartej na legalizmie, ale tę sprawiedliwość, która przychodzi przez wierność Mesjasza, sprawiedliwość od Boga, opartą na ufności.
###### **Flp 3,10**
 Owszem, porzuciłem to wszystko, aby Go poznać, czyli aby poznać moc Jego zmartwychwstania i współuczestnictwo w Jego cierpieniach, dostosowując się do Jego śmierci,
###### **Flp 3,11**
 tak abym mógł jakoś dostąpić powstania z martwych.
###### **Flp 3,12**
 Nie chodzi o to, że już tego dostąpiłem czy że już osiągnąłem cel - nie, wciąż do niego dążę, w nadziei pozyskania tego, do czego pozyskał mnie Mesjasz Jeszua.
###### **Flp 3,13**
 Bracia, jeśli o mnie idzie, nie myślę o sobie, jakobym już to pozyskał, ale czynię jedno: zapominając o tym, co za mną, i prąc naprzód, ku temu, co przede mną,
###### **Flp 3,14**
 nie przestaję dążyć do celu, aby zdobyć nagrodę, jaką zapowiada Boże wezwanie w górę w Mesjaszu Jeszui.
###### **Flp 3,15**
 Dlatego wszyscy ci z nas, którzy są dojrzali, niech stale mają to na uwadze, a jeśli myślicie o czymś inaczej, także i to Bóg wam objawi.
###### **Flp 3,16**
 Niech tylko nasze postępowanie pozostaje w zgodzie z poziomem, jaki już osiągnęliśmy.
###### **Flp 3,17**
 Bracia, dołączcie do naśladowania mnie i zwracajcie uwagę na tych, którzy żyją według wzoru, jaki wam ukazaliśmy.
###### **Flp 3,18**
 Bo wielu - jak już przedtem często wam mówiłem, a teraz mówię ze łzami w oczach - żyje niczym wrogowie pala Mesjaszowego.
###### **Flp 3,19**
 Zmierzają do zguby! Ich bóg to ich brzuch, dumni są z tego, czego powinni się wstydzić, bo troszczą się o rzeczy tego świata.
###### **Flp 3,20**
 Ale my jesteśmy obywatelami nieba i to stamtąd oczekujemy Wyzwoliciela, Pana Jeszui Mesjasza.
###### **Flp 3,21**
 On przemieni ciała, jakie mamy w tym nędznym stanie, i uczyni je podobnymi do swojego chwalebnego ciała, tą mocą, która pozwala Mu, by wszystko sobie podporządkował.
# Flp 3 TRO
###### **Flp 3,1**
 **το** *to* [[G3588]] WTT-NSN **λοιπον** *loipon* W końcu [[G3063]] WTA-NSN **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **μου** *mou* moi [[G3450]] WTP-1GS **χαιρετε** *chairete* radujcie się – cieszcie się [[G5463]] WTV-PAM-2P **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **τα** *ta* [[G3588]] WTT-APN **αυτα** *auta* te same [[G846]] WTP-APN **γραφειν** *grafein* pisać [[G1125]] WTV-PAN **υμιν** *hymin* wam [[G5213]] WTP-2DP **εμοι** *emoi* mnie [[G1698]] WTP-1DS **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **οκνηρον** *oknēron* dokuczliwe – nużące [[G3636]] WTA-NSN **υμιν** *hymin* wam [[G5213]] WTP-2DP **δε** *de* zaś [[G1161]] [[CONJ]] **ασφαλες** *asfales* niezawodne – bezpieczne [[G804]] WTA-NSN
###### **Flp 3,2**
 **βλεπετε** *blepete* Uważajcie – Patrzcie [[G991]] WTV-PAM-2P **τους** *tous* (na) [[G3588]] WTT-APM **κυνας** *kynas* psy [[G2965]] [[N-APM]] **βλεπετε** *blepete* uważajcie – patrzcie [[G991]] WTV-PAM-2P **τους** *tous* (na) [[G3588]] WTT-APM **κακους** *kakous* złych [[G2556]] WTA-APM **εργατας** *ergatas* pracowników [[G2040]] [[N-APM]] **βλεπετε** *blepete* uważajcie – patrzcie [[G991]] WTV-PAM-2P **την** *tēn* (na) [[G3588]] WTT-ASF **κατατομην** *katatomēn* fałszywie obrzezanych – którzy są okaleczeni [[G2699]] WTN-ASF
###### **Flp 3,3**
 **ημεις** *hēmeis* My [[G2249]] WTP-1NP **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εσμεν** *esmen* jesteśmy [[G2070]] WTV-PXI-1P **η** *hē* [[G3588]] [[T-NSF]] **περιτομη** *peritomē* obrzezanie [[G4061]] [[N-NSF]] **οι** *hoi* [[G3588]] WTT-NPM **πνευματι** *pneumati* Duchem [[G4151]] WTN-DSN **θεω** *theō* Bogu [[G2316]] WTN-DSM **λατρευοντες** *latreuontes* służąc [[G3000]] WTV-PAP-NPM **και** *kai* i [[G2532]] [[CONJ]] **καυχωμενοι** *kauchōmenoi* chlubiąc się – chełpiąc się [[G2744]] WTV-PNP-NPM **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM **και** *kai* a [[G2532]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εν** *en* w [[G1722]] [[PREP]] **σαρκι** *sarki* ciele [[G4561]] [[N-DSF]] **πεποιθοτες** *pepoithotes* pokładający ufności – polegający [[G3982]] WTV-2RAP-NPM
###### **Flp 3,4**
 **καιπερ** *kaiper* chociaż [[G2539]] [[CONJ]] **εγω** *egō* ja [[G1473]] WTP-1NS **εχων** *echōn* mający [[G2192]] [[V-PAP-NSM]] **πεποιθησιν** *pepoithēsin* przekonanie – przeświadczenie [[G4006]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **σαρκι** *sarki* ciele [[G4561]] [[N-DSF]] **ει** *ei* jeśli [[G1487]] WTCOND **τις** *tis* ktoś [[G5100]] WTX-NSM **δοκει** *dokei* uważa – mniema [[G1380]] WTV-PAI-3S **αλλος** *allos* inny [[G243]] [[A-NSM]] **πεποιθεναι** *pepoithenai* (że) pokładać ufność – (że) polegać [[G3982]] WTV-2RAN **εν** *en* w [[G1722]] [[PREP]] **σαρκι** *sarki* ciele [[G4561]] [[N-DSF]] **εγω** *egō* ja [[G1473]] WTP-1NS **μαλλον** *mallon* bardziej [[G3123]] [[ADV]]
###### **Flp 3,5**
 **περιτομη** *peritomē* obrzezany [[G4061]] [[N-NSF]] **οκταημερος** *oktaēmeros* ósmego dnia [[G3637]] [[A-NSM]] **εκ** *ek* z [[G1537]] [[PREP]] **γενους** *genous* rodu [[G1085]] [[N-GSN]] **ισραηλ** *israēl* Izraela – [ten, który walczył z Bogiem] [[G2474]] [[N-PRI]] **φυλης** *fylēs* plemienia [[G5443]] [[N-GSF]] **βενιαμιν** *beniamin* Beniamina – [syn prawicy] [[G958]] [[N-PRI]] **εβραιος** *hebraios* Hebrajczyk – [poza obszar] [[G1445]] [[A-NSM]] **εξ** *eks* z [[G1537]] [[PREP]] **εβραιων** *hebraiōn* Hebrajczyków – [poza obszar] [[G1445]] WTA-GPM **κατα** *kata* według [[G2596]] [[PREP]] **νομον** *nomon* Prawa [[G3551]] [[N-ASM]] **φαρισαιος** *farisaios* faryzeusz – [oddzielony] [[G5330]] [[N-NSM]]
###### **Flp 3,6**
 **κατα** *kata* według [[G2596]] [[PREP]] **ζηλον** *zēlon* żarliwości – zapału [[G2205]] [[N-ASM]] **διωκων** *diōkōn* prześladujący – nastający na [[G1377]] [[V-PAP-NSM]] **την** *tēn* [[G3588]] WTT-ASF **εκκλησιαν** *ekklēsian* zgromadzenie – (społeczność) wywołanych [[G1577]] WTN-ASF **κατα** *kata* według [[G2596]] [[PREP]] **δικαιοσυνην** *dikaiosynēn* sprawiedliwości [[G1343]] WTN-ASF **την** *tēn* [[G3588]] WTT-ASF **εν** *en* w [[G1722]] [[PREP]] **νομω** *nomō* Prawie [[G3551]] WTN-DSM **γενομενος** *genomenos* stawszy się [[G1096]] WTV-2ADP-NSM **αμεμπτος** *amemptos* nienaganny [[G273]] [[A-NSM]]
###### **Flp 3,7**
 **αλλ** *all* Ale [[G235]] [[CONJ]] **ατινα** *hatina* które [[G3748]] WTR-NPN **ην** *ēn* było [[G2258]] [[V-IXI-3S]] **μοι** *moi* mi [[G3427]] WTP-1DS **κερδη** *kerdē* zyski [[G2771]] WTN-NPN **ταυτα** *tauta* te [[G5023]] WTD-APN **ηγημαι** *hēgēmai* uznałem [[G2233]] WTV-RNI-1S **δια** *dia* ze względu na [[G1223]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **χριστον** *christon* Pomazańca [[G5547]] [[N-ASM]] **ζημιαν** *zēmian* (za) stratę [[G2209]] WTN-ASF
###### **Flp 3,8**
 **αλλα** *alla* Ale [[G235]] [[CONJ]] **μενουνγε** *menounge* wprawdzie raczej – wprawdzie bardziej [[G3304]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **ηγουμαι** *hēgoumai* uznaję [[G2233]] WTV-PNI-1S **παντα** *panta* wszystkie [[G3956]] WTA-APN **ζημιαν** *zēmian* stratą [[G2209]] WTN-ASF **ειναι** *einai* być [[G1511]] WTV-PXN **δια** *dia* z powodu [[G1223]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **υπερεχον** *hyperechon* górującego – przewyższającego [[G5242]] WTV-PAP-ASN **της** *tēs* [[G3588]] [[T-GSF]] **γνωσεως** *gnōseōs* poznania [[G1108]] [[N-GSF]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **μου** *mou* mojego [[G3450]] WTP-1GS **δι** *di* z powodu [[G1223]] [[PREP]] **ον** *hon* którego [[G3739]] WTR-ASM **τα** *ta* [[G3588]] WTT-APN **παντα** *panta* wszystkie [[G3956]] WTA-APN **εζημιωθην** *ezēmiōthēn* zostało mi zabrane [[G2210]] WTV-API-1S **και** *kai* i [[G2532]] [[CONJ]] **ηγουμαι** *hēgoumai* uznaję [[G2233]] WTV-PNI-1S **σκυβαλα** *skybala* (za) gnój – (za) śmieci [[G4657]] WTN-APN **ειναι** *einai* być [[G1511]] WTV-PXN **ινα** *hina* aby [[G2443]] [[CONJ]] **χριστον** *christon* Pomazańca [[G5547]] [[N-ASM]] **κερδησω** *kerdēsō* pozyskałbym [[G2770]] WTV-AAS-1S
###### **Flp 3,9**
 **και** *kai* i [[G2532]] [[CONJ]] **ευρεθω** *heurethō* zostałbym znaleziony [[G2147]] WTV-APS-1S **εν** *en* w [[G1722]] [[PREP]] **αυτω** *autō* Nim [[G846]] WTP-DSM **μη** *mē* nie [[G3361]] [[PRT-N]] **εχων** *echōn* mając [[G2192]] [[V-PAP-NSM]] **εμην** *emēn* mojej [[G1699]] WTS-1ASF **δικαιοσυνην** *dikaiosynēn* sprawiedliwości [[G1343]] WTN-ASF **την** *tēn* [[G3588]] WTT-ASF **εκ** *ek* z [[G1537]] [[PREP]] **νομου** *nomou* Prawa [[G3551]] [[N-GSM]] **αλλα** *alla* ale [[G235]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **δια** *dia* przez [[G1223]] [[PREP]] **πιστεως** *pisteōs* wiarę [[G4102]] [[N-GSF]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **την** *tēn* [[G3588]] WTT-ASF **εκ** *ek* z [[G1537]] [[PREP]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **δικαιοσυνην** *dikaiosynēn* sprawiedliwość [[G1343]] WTN-ASF **επι** *epi* (ze względu) na [[G1909]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **πιστει** *pistei* wiarę [[G4102]] [[N-DSF]]
###### **Flp 3,10**
 **του** *tou* (By) [[G3588]] WTT-GSM **γνωναι** *gnōnai* poznać [[G1097]] [[V-2AAN]] **αυτον** *auton* Go [[G846]] WTP-ASM **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **δυναμιν** *dynamin* moc [[G1411]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **αναστασεως** *anastaseōs* powstania – wzbudzenia [[G386]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **κοινωνιαν** *koinōnian* wspólnotę [[G2842]] WTN-ASF **των** *tōn* [[G3588]] WTT-GPN **παθηματων** *pathēmatōn* cierpień [[G3804]] WTN-GPN **αυτου** *autou* Jego [[G846]] [[P-GSM]] **συμμορφουμενος** *symmorfoumenos* mając nadany ten sam kształt ze – mając nadaną tą samą postać ze [[G4833]] [[V-PPP-NSM]] **τω** *tō* [[G3588]] WTT-DSM **θανατω** *thanatō* śmiercią [[G2288]] WTN-DSM **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Flp 3,11**
 **ει** *ei* Jeśli [[G1487]] WTCOND **πως** *pōs* jak [[G4459]] WTPRT-I **καταντησω** *katantēsō* przeszedłbym [[G2658]] WTV-AAS-1S **εις** *eis* do [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **εξαναστασιν** *eksanastasin* powstania [[G1815]] WTN-ASF **των** *tōn* (z) [[G3588]] WTT-GPM **νεκρων** *nekrōn* martwych [[G3498]] WTA-GPM
###### **Flp 3,12**
 **ουχ** *ouch* Nie [[G3756]] [[PRT-N]] **οτι** *hoti* że [[G3754]] [[CONJ]] **ηδη** *ēdē* już [[G2235]] [[ADV]] **ελαβον** *elabon* wziąłem [[G2983]] WTV-2AAI-1S **η** *ē* lub [[G2228]] WTPRT **ηδη** *ēdē* już [[G2235]] [[ADV]] **τετελειωμαι** *teteleiōmai* jestem uczyniony doskonałym [[G5048]] WTV-RPI-1S **διωκω** *diōkō* ścigam – nastaję [[G1377]] WTV-PAI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **ει** *ei* jeśli [[G1487]] WTCOND **και** *kai* i [[G2532]] [[CONJ]] **καταλαβω** *katalabō* pochwyciłbym – złapałbym [[G2638]] WTV-2AAS-1S **εφ** *ef* za [[G1909]] [[PREP]] **ω** *hō* które [[G3739]] WTR-DSN **και** *kai* i [[G2532]] [[CONJ]] **κατεληφθην** *katelēfthēn* zostałem pochwycony – zostałem złapany [[G2638]] WTV-API-1S **υπο** *hypo* przez [[G5259]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]]
###### **Flp 3,13**
 **αδελφοι** *adelfoi* Bracia [[G80]] WTN-VPM **εγω** *egō* Ja [[G1473]] WTP-1NS **εμαυτον** *emauton* (o) sobie [[G1683]] WTF-1ASM **ου** *ou* nie [[G3756]] [[PRT-N]] **λογιζομαι** *logizomai* liczę – sądzę [[G3049]] WTV-PNI-1S **κατειληφεναι** *kateilēfenai* (że) pochwycić – (że) złapać [[G2638]] WTV-RAN **εν** *hen* jedno [[G1520]] WTA-NSN **δε** *de* zaś [[G1161]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **οπισω** *opisō* za – z tyłu [[G3694]] [[ADV]] **επιλανθανομενος** *epilanthanomenos* zapominając [[G1950]] WTV-PNP-NSM **τοις** *tois* [[G3588]] WTT-DPN **δε** *de* zaś [[G1161]] [[CONJ]] **εμπροσθεν** *emprosthen* przed [[G1715]] [[ADV]] **επεκτεινομενος** *epekteinomenos* wyciągając się [[G1901]] WTV-PNP-NSM
###### **Flp 3,14**
 **κατα** *kata* według [[G2596]] [[PREP]] **σκοπον** *skopon* celu [[G4649]] [[N-ASM]] **διωκω** *diōkō* ścigam – nastaję [[G1377]] WTV-PAI-1S **επι** *epi* ku [[G1909]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **βραβειον** *brabeion* nagrodzie [[G1017]] WTN-ASN **της** *tēs* [[G3588]] [[T-GSF]] **ανω** *anō* w górze – z góry [[G507]] [[ADV]] **κλησεως** *klēseōs* powołania [[G2821]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM
###### **Flp 3,15**
 **οσοι** *hosoi* Ilu [[G3745]] WTK-NPM **ουν** *oun* więc [[G3767]] [[CONJ]] **τελειοι** *teleioi* dojrzali – doskonali [[G5046]] WTA-NPM **τουτο** *touto* to [[G5124]] WTD-ASN **φρονωμεν** *fronōmen* myślelibyśmy – rozumielibyśmy [[G5426]] WTV-PAS-1P **και** *kai* i [[G2532]] [[CONJ]] **ει** *ei* jeśli [[G1487]] WTCOND **τι** *ti* coś [[G5100]] WTX-ASN **ετερως** *heterōs* inaczej [[G2088]] [[ADV]] **φρονειτε** *froneite* myślicie – rozumiecie [[G5426]] WTV-PAI-2P **και** *kai* i [[G2532]] [[CONJ]] **τουτο** *touto* to [[G5124]] WTD-ASN **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **αποκαλυψει** *apokalypsei* objawi [[G601]] WTV-FAI-3S
###### **Flp 3,16**
 **πλην** *plēn* Jednak – Niemniej [[G4133]] [[ADV]] **εις** *eis* ku [[G1519]] [[PREP]] **ο** *ho* czemu [[G3739]] WTR-ASN **εφθασαμεν** *efthasamen* przybyliśmy pierwsi – pospieszyliśmy [[G5348]] WTV-AAI-1P **τω** *tō* [[G3588]] WTT-DSM **αυτω** *autō* tym samym [[G846]] WTP-DSM **στοιχειν** *stoichein* iść w szeregu [[G4748]] WTV-PAN **κανονι** *kanoni* normą – zasadą [[G2583]] WTN-DSM **το** *to* [[G3588]] WTT-ASN **αυτο** *auto* tą samą [[G846]] WTP-ASN **φρονειν** *fronein* myśleć – rozumieć [[G5426]] WTV-PAN
###### **Flp 3,17**
 **συμμιμηται** *symmimētai* Współnaśladowcy [[G4831]] WTN-NPM **μου** *mou* moi [[G3450]] WTP-1GS **γινεσθε** *ginesthe* stawajcie się [[G1096]] WTV-PNM-2P **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **και** *kai* i [[G2532]] [[CONJ]] **σκοπειτε** *skopeite* baczcie – przyglądajcie się [[G4648]] WTV-PAM-2P **τους** *tous* [[G3588]] WTT-APM **ουτως** *houtōs* tak [[G3779]] [[ADV]] **περιπατουντας** *peripatountas* postępującym [[G4043]] WTV-PAP-APM **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **εχετε** *echete* macie [[G2192]] WTV-PAI-2P **τυπον** *typon* (jako) wzór – (jako) typ [[G5179]] [[N-ASM]] **ημας** *hēmas* nas [[G2248]] WTP-1AP
###### **Flp 3,18**
 **πολλοι** *polloi* Wielu [[G4183]] WTA-NPM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **περιπατουσιν** *peripatousin* postępuje – chodzi [[G4043]] WTV-PAI-3P **ους** *hous* (o) których [[G3739]] WTR-APM **πολλακις** *pollakis* wielokrotnie – częstokroć [[G4178]] [[ADV]] **ελεγον** *elegon* mówiłem [[G3004]] WTV-IAI-1S **υμιν** *hymin* wam [[G5213]] WTP-2DP **νυν** *nyn* teraz [[G3568]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **κλαιων** *klaiōn* płacząc [[G2799]] [[V-PAP-NSM]] **λεγω** *legō* mówię [[G3004]] WTV-PAI-1S **τους** *tous* (że to) [[G3588]] WTT-APM **εχθρους** *echthrous* wrogowie – nieprzyjaciele [[G2190]] WTA-APM **του** *tou* [[G3588]] WTT-GSM **σταυρου** *staurou* krzyża [[G4716]] [[N-GSM]] **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **Flp 3,19**
 **ων** *hōn* których [[G3739]] WTR-GPM **το** *to* [[G3588]] WTT-NSN **τελος** *telos* koniec [[G5056]] WTN-NSN **απωλεια** *apōleia* zguba – zatracenie [[G684]] [[N-NSF]] **ων** *hōn* których [[G3739]] WTR-GPM **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **η** *hē* [[G3588]] [[T-NSF]] **κοιλια** *koilia* brzuch [[G2836]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **δοξα** *doksa* chwała [[G1391]] [[N-NSF]] **εν** *en* we [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **αισχυνη** *aischynē* wstydzie – hańbie [[G152]] [[N-DSF]] **αυτων** *autōn* ich [[G846]] WTP-GPM **οι** *hoi* (ci) [[G3588]] WTT-NPM **τα** *ta* (o) [[G3588]] WTT-APN **επιγεια** *epigeia* ziemskich [[G1919]] WTA-APN **φρονουντες** *fronountes* myślący – rozumiejący [[G5426]] WTV-PAP-NPM
###### **Flp 3,20**
 **ημων** *hēmōn* Nasza [[G2257]] WTP-1GP **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **πολιτευμα** *politeuma* ojczyzna – życie jako obywateli [[G4175]] WTN-NSN **εν** *en* w [[G1722]] [[PREP]] **ουρανοις** *ouranois* niebiosach [[G3772]] WTN-DPM **υπαρχει** *hyparchei* jest [[G5225]] WTV-PAI-3S **εξ** *eks* z [[G1537]] [[PREP]] **ου** *hou* których [[G3739]] WTR-GSM **και** *kai* i [[G2532]] [[CONJ]] **σωτηρα** *sōtēra* Zbawiciela – Wybawcę [[G4990]] [[N-ASM]] **απεκδεχομεθα** *apekdechometha* wyczekujemy – oczekujemy [[G553]] WTV-PNI-1P **κυριον** *kyrion* Pana [[G2962]] [[N-ASM]] **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]] **χριστον** *christon* Pomazańca [[G5547]] [[N-ASM]]
###### **Flp 3,21**
 **ος** *hos* który [[G3739]] WTR-NSM **μετασχηματισει** *metaschēmatisei* przekształci się – zmieni postać [[G3345]] WTV-FAI-3S **το** *to* [[G3588]] WTT-ASN **σωμα** *sōma* ciała [[G4983]] WTN-ASN **της** *tēs* [[G3588]] [[T-GSF]] **ταπεινωσεως** *tapeinōseōs* poniżenia – uniżenia [[G5014]] [[N-GSF]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **γενεσθαι** *genesthai* stać się [[G1096]] WTV-2ADN **αυτο** *auto* Jego [[G846]] WTP-ASN **συμμορφον** *symmorfon* podobnego do – mający kształt podobny do [[G4832]] WTA-ASN **τω** *tō* [[G3588]] WTT-DSN **σωματι** *sōmati* ciała [[G4983]] WTN-DSN **της** *tēs* [[G3588]] [[T-GSF]] **δοξης** *doksēs* chwały [[G1391]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **κατα** *kata* według [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **ενεργειαν** *energeian* działania [[G1753]] WTN-ASF **του** *tou* (tego) [[G3588]] WTT-GSM **δυνασθαι** *dynasthai* móc [[G1410]] WTV-PNN **αυτον** *auton* Mu [[G846]] WTP-ASM **και** *kai* i [[G2532]] [[CONJ]] **υποταξαι** *hypotaksai* poddać – podporządkować [[G5293]] [[V-AAN]] **εαυτω** *heautō* sobie [[G1438]] WTF-3DSM **τα** *ta* [[G3588]] WTT-APN **παντα** *panta* wszystkie [[G3956]] WTA-APN
