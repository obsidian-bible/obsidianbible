# 1Krn 4 BT5
###### **1Krn 4,1**
 Synowie Judy: Peres, Chesron, Karmi, Chur i Szobal.
###### **1Krn 4,2**
 Reajasz, syn Szobala, był ojcem Jachata, a Jachat – Achumaja i Lahada. Te są rody Soreatytów.
###### **1Krn 4,3**
 A ci byli z ojca Etama: Jizreel, Jiszma i Jidbasz, a imię ich siostry: Haslelponi.
###### **1Krn 4,4**
 Penuel był ojcem Gedora, a Ezer – ojcem Chuszy. Oto synowie Chura, pierworodnego Efraty, ojca Betlejem.
###### **1Krn 4,5**
 Aszchur, ojciec Tekoa, miał dwie żony: Cheleę i Naarę.
###### **1Krn 4,6**
 Naara urodziła mu Achuzama, Chefera, Temniego i Achasztariego. Ci byli synami Naary.
###### **1Krn 4,7**
 Synowie Chelei: Seret, Sochar i Etnan.
###### **1Krn 4,8**
 Kos był ojcem Anuba, Sobeby i rodów Acharchela, syna Haruma.
###### **1Krn 4,9**
 Jabes był bardziej poważany niż jego bracia. Matka jego dała mu imię Jabes, mówiąc: «***Ponieważ w bólu urodziłam***».
###### **1Krn 4,10**
 A wzywał Jabes Boga Izraela, mówiąc: «***Obyś skutecznie mi błogosławił i rozszerzył granice moje, a ręka Twoja była ze mną, i obyś zachował mnie od złego, a utrapienie moje się skończy!***» I sprawił Bóg to, o co on prosił.
###### **1Krn 4,11**
 Kelub, brat Szuchy, był ojcem Mechira, który był ojcem Esztona.
###### **1Krn 4,12**
 Eszton był ojcem Bet-Rafa, Paseacha i Techinny, ojca Ir-Nachasz. Ci mężowie są z Rekab.
###### **1Krn 4,13**
 Synowie Kenaza: Otniel i Serajasz. Synowie Otniela: Chatat i Meonotaj.
###### **1Krn 4,14**
 Meonotaj był ojcem Ofry. Serajasz był ojcem Joaba, ojca Ge-Haraszim, byli oni bowiem rzemieślnikami.
###### **1Krn 4,15**
 Synowie Kaleba, syna Jefunnego: Ir, Ela i Naam. Syn Eli: Kenaz.
###### **1Krn 4,16**
 Synowie Jehalleleela: Zif, Zifa, Tiria i Asareel.
###### **1Krn 4,17**
 Synowie Ezry: Jeter, Mered, Efer i Jalon. Potem [Bitia] poczęła Miriam, Szammaja i Iszbacha, ojca Esztemoy.
###### **1Krn 4,18**
 A tegoż żona, Judejka, urodziła Jereda, ojca Gedora, Chebera, ojca Soko, i Jekutiela, ojca Zanoacha. Ci są synowie Bitii, córki faraona, którą poślubił Mered.
###### **1Krn 4,19**
 Synowie żony Hodijji, siostry Nachama, ojca Keili, Garmity, i Esztemoy, Maakatyty.
###### **1Krn 4,20**
 Synowie Szymona: Amnon, Rinna, Ben-Chanan i Tilon. Synowie Jisziego: Zochet i Ben-Zochet.
###### **1Krn 4,21**
 Synowie Szeli, syna Judy: Er, ojciec Leki; Laeda, ojciec Mareszy i rodów z wytworni bisioru w Bet-Aszbea;
###### **1Krn 4,22**
 Jokim i mężowie z Kozeby oraz Joasz i Saraf, którzy panowali w Moabie, zanim powrócili do Lechem. Są to wydarzenia bardzo dawne.
###### **1Krn 4,23**
 Byli zaś oni garncarzami. Jako mieszkańcy Netaim i Gedery mieszkali tam przy królu ze względu na prace dla niego wykonywane.
###### **1Krn 4,24**
 Synowie Symeona: Nemuel, Jamin, Jarib, Zerach, Saul;
###### **1Krn 4,25**
 jego synem Szallum, synem Szalluma – Mibsam, jego zaś synem był Miszma.
###### **1Krn 4,26**
 Synowie Miszmy: Chammuel, jego synem był Zakkur, synem Zakkura zaś Szimei.
###### **1Krn 4,27**
 Szimei miał szesnastu synów i sześć córek, lecz jego bracia nie mieli wiele dzieci i wszystkie ich rody nie rozmnożyły się tak, jak potomków Judy.
###### **1Krn 4,28**
 Mieszkali oni w miastach: Beer-Szeba, Molada, Chasar-Szual,
###### **1Krn 4,29**
 Bilha, Esem, Tolad,
###### **1Krn 4,30**
 Betuel, Chorma, Siklag,
###### **1Krn 4,31**
 Bet-Markabot, Chasar-Susim, Bet-Birei, Szaarim. Miasta te należały do nich aż do panowania Dawida.
###### **1Krn 4,32**
 A osiedlami ich były: Etam, Ain, Rimmon, Token i Aszan, pięć miast
###### **1Krn 4,33**
 oraz wszystkie ich wioski, które były naokoło tych miast aż do Baalat. Takie były ich siedziby według ich spisów rodowych.
###### **1Krn 4,34**
 Meszobab, Jamlek, Josza, syn Amazjasza,
###### **1Krn 4,35**
 Joel, Jehu, syn Joszibiasza, syna Serajasza, syna Asjela,
###### **1Krn 4,36**
 Elioenaj, Jaakoba, Jeszochajasz, Asajasz, Adiel, Jesimiel, Benajasz,
###### **1Krn 4,37**
 Ziza, syn Szifiego, syna Allona, syna Jedajasza, syna Szimriego, syna Szemajasza.
###### **1Krn 4,38**
 Ci wymienieni tu imiennie byli naczelnikami swoich rodów. Rodziny ich rozszerzyły się bardzo.
###### **1Krn 4,39**
 Poszli więc aż do wąwozu Gedor, aż do wschodniej strony doliny, szukając pastwiska dla swych trzód.
###### **1Krn 4,40**
 I znaleźli pastwisko obfite i dobre, okolicę rozległą, spokojną i bezpieczną, albowiem już przedtem mieszkali tam Chamici.
###### **1Krn 4,41**
 Ci zapisani tu imiennie przybyli za czasów króla judzkiego, Ezechiasza, zniszczyli ich namioty, a Meunitów, którzy się tam znajdowali, obłożyli klątwą aż do tego dnia, zamieszkawszy na ich miejscu, ponieważ znaleźli tam pastwisko dla swych trzód.
###### **1Krn 4,42**
 Niektórzy z nich, pięciuset mężów spośród synów Symeona, udali się na gorę Seir, a na ich czele byli: Pelatiasz, Neariasz, Refajasz i Uzzjel, synowie Jisziego.
###### **1Krn 4,43**
 Rozbili oni ocalałą resztę Amalekitów i zamieszkali tam aż do dnia dzisiejszego.
# 1Krn 4 PAU
###### **1Krn 4,1**
 Potomkowie Judy: Peres, Chesron, Karmi, Chur i Szobal.
###### **1Krn 4,2**
 Reajasz, syn Szobala, był ojcem Jachata, Jachat ojcem Achumaja i Lahada. Należą oni do rodów Soreatytów.
###### **1Krn 4,3**
 Synami Etama byli: Jezreel, Jeszma i Jedbasz. Ich siostra miała na imię Haslelponi.
###### **1Krn 4,4**
 Penuel był ojcem Gedora, a Ezer ojcem Chuszy. Wszyscy oni są potomkami Chura, pierworodnego Efraty, założyciela Betlejem.
###### **1Krn 4,5**
 Aszchur, założyciel Tekoa, miał dwie żony: Cheleę i Naarę.
###### **1Krn 4,6**
 Naara urodziła mu Achuzama, Chefera, Temniego i Achasztariego - są oni synami Naary.
###### **1Krn 4,7**
 Synami Chelei byli natomiast Seret, Sochar i Etnan.
###### **1Krn 4,8**
 Kos był ojcem Anuba, Sobeby oraz rodów Acharchela, syna Haruma.
###### **1Krn 4,9**
 Jabes był najsławniejszy pośród swych rodaków. Matka nadała mu imię Jabes, mówiąc: „W bólu go urodziłam”.
###### **1Krn 4,10**
 Jabes tak modlił się do Boga Izraela: „Błogosław mi hojnie, powiększając moje posiadłości, wspierając mnie i zachowując od złego, aby skończyło się moje utrapienie”. Bóg wysłuchał jego prośby.
###### **1Krn 4,11**
 Kelub, brat Szuchy, był ojcem Mechira, a Mechir ojcem Esztona.
###### **1Krn 4,12**
 Eszton był ojcem Bet-Rafa, Paseacha i Techinny, założyciela Ir-Nachasz. Pochodzą oni z Reki.
###### **1Krn 4,13**
 Synowie Kenaza: Otniel i Serajasz. Synowie Otniela: Chatat i Meonotaj.
###### **1Krn 4,14**
 Meonotaj był ojcem Ofry, Serajasz był ojcem Joaba, założyciela Ge-Haraszim. Byli oni rzemieślnikami.
###### **1Krn 4,15**
 Synowie Kaleba, syna Jefunnego: Ir, Ela i Naam. Synem Eli był Kenaz.
###### **1Krn 4,16**
 Synowie Jehalleleela: Zif, Zifa, Tiria i Asareel.
###### **1Krn 4,17**
 Synami Ezry byli: Jeter, Mered, Efer i Jalon. Jeter był ojcem Miriam, Szammaja i Iszbacha, ojca Esztemoy.
###### **1Krn 4,18**
 Mered miał dwie żony: Egipcjankę i Judejkę. Judejka urodziła mu Jereda, założyciela Gedoru, Chebera, założyciela Soko, i Jekutiela, założyciela Zanoacha. Synem Bati, córki faraona, którą poślubił Meded, był Noroel.
###### **1Krn 4,19**
 Synami żony Hodijji, siostry Nachama, byli: Garmita - ojciec Keili oraz Esztemoa, Maakatyta.
###### **1Krn 4,20**
 Synowie Szymona: Amnon, Rinna, Ben-Chanan i Tilon. Synowie Jesziego: Zochet i Ben-Zochet.
###### **1Krn 4,21**
 Potomkowie Szeli, syna Judy: Er, ojciec Leki, Laeda, ojciec Mareszy oraz rodów wytwarzających bisior w Bet-Aszbea,
###### **1Krn 4,22**
 Jokim i ludzie z Kozeby oraz Joasz i Saraf, którzy panowali w Moabie, nim wrócili do Lechem. Są to wydarzenia bardzo dawne.
###### **1Krn 4,23**
 Byli oni garncarzami, a mieszkali w Netaim i Gederze. Służyli królowi i mieszkali przy nim.
###### **1Krn 4,24**
 Synami Symeona byli: Nemuel, Jamin, Jarib, Zerach, Saul.
###### **1Krn 4,25**
 Synem Saula był Szallum, a synem Szalluma - Mibsam. Synem Mibsama był Miszma.
###### **1Krn 4,26**
 Synem Miszmy był Chammuel, synem Chammuela był Zakkur, a synem Zakkura - Szimei.
###### **1Krn 4,27**
 Szimei miał szesnastu synów i sześć córek. Jednak jego bracia nie mieli dużo dzieci i dlatego ich rody nie stały się tak liczne jak rody plemienia Judy.
###### **1Krn 4,28**
 Mieszkali oni w miastach: Beer-Szeba, Molada, Chasar-Szual,
###### **1Krn 4,29**
 Bilha, Esem, Tolad,
###### **1Krn 4,30**
 Betuel, Chorma, Siklag,
###### **1Krn 4,31**
 Bet-Markabot, Chasar-Susim, Bet-Birei, Szaarim. Miasta te należały do nich aż do panowania Dawida.
###### **1Krn 4,32**
 Ich siedzibami były też: Etam, Ain, Rimmon, Token i Aszan - razem pięć miast
###### **1Krn 4,33**
 oraz wszystkie okoliczne wioski wokół aż po Baalat. To są miejsca ich zamieszkiwania i ich spisy rodowe.
###### **1Krn 4,34**
 Meszobab, Jamlek, Josza - syn Amazjasza,
###### **1Krn 4,35**
 Joel, Jehu - syn Joszibiasza, syna Serajasza, syna Asjela,
###### **1Krn 4,36**
 Elioenaj, Jaakoba, Jeszochajasz, Asajasz, Adiel, Jesimiel, Benajasz,
###### **1Krn 4,37**
 Ziza, syn Szifiego, syna Allona, syna Jedajasza, syna Szimriego, syna Szemajasza.
###### **1Krn 4,38**
 Ci wyliczeni imiennie byli przywódcami rodów, a ich rodziny stały się bardzo liczne.
###### **1Krn 4,39**
 Dotarli po przełęcz Gedor aż na wschodnią stronę doliny w poszukiwaniu pastwisk dla swych trzód.
###### **1Krn 4,40**
 Natrafili tam na wielkie i bogate pastwiska, a okolica była przestronna, spokojna i bezpieczna. Przed nimi bowiem zamieszkiwali tam Chamici.
###### **1Krn 4,41**
 Zapisani tu imiennie przybyli za czasów Ezechiasza, króla judzkiego. Zniszczyli namioty Chamitów i zajęli miejsce Meunitów, obłożyli je klątwą, która obowiązuje po dziś dzień. Osiedlili się na ich miejscu, ponieważ były tam pastwiska dla ich trzód.
###### **1Krn 4,42**
 Część Symeonitów, pięciuset mężczyzn, udało się na górę Seir. Ich przywódcami byli: Pelatiasz, Neariasz, Refajasz i Uzzjel, potomkowie Jesziego.
###### **1Krn 4,43**
 Rozbili oni resztę ocalałych Amalekitów i zamieszkują tam po dziś dzień.
# 1Krn 4 BP
###### **1Krn 4,1**
 Synami Judy byli: Perec, Checron, Karmi, Chur i Szobal.
###### **1Krn 4,2**
 Reaja, syn Szobala, był ojcem Jachata, a Jachat był ojcem Achumaja i Lahada. To są rody Coreatytów.
###### **1Krn 4,3**
 A ci [pochodzą] od ojca Etama: Jizreel, Jiszma i Jidbasz; siostra ich miała na imię Hacielponi.
###### **1Krn 4,4**
 Penuel był ojcem Gedora, a Ezer był ojcem Chuszy. To są synowie Chura, pierworodnego Efraty, który był ojcem Bet-Lechema.
###### **1Krn 4,5**
 Aszchur, ojciec Tekoi, miał dwie żony: Chelę i Naarę.
###### **1Krn 4,6**
 Naara urodziła mu Achuzzama, Chefera, Temnitów i Achasztarytów. Ci byli synami Naary.
###### **1Krn 4,7**
 Synami Cheli byli: Ceret, Cochar i Etnan.
###### **1Krn 4,8**
 Koc był ojcem Anuba, Hacobeba i rodów Acharchela, syna Haruma.
###### **1Krn 4,9**
 Jabec miał większe poważanie niż jego bracia. Jego matka dała mu na imię Jabec, mówiąc: "W bólu go porodziłam".
###### **1Krn 4,10**
 A Jabec wzywał Boga Izraela, mówiąc: "Obyś mi błogosławił i rozszerzał posiadłości moje. Niech ręka Twoja będzie ze mną, zachowaj mnie od złego, a niech się skończy moje cierpienie". I dał mu Bóg to, o co prosił.
###### **1Krn 4,11**
 Kelub, brat Szuchy, był ojcem Mechira, a ten znów był ojcem Esztona.
###### **1Krn 4,12**
 Eszton był ojcem Bet-Rafy, Paseacha i Techinny, ojca Ir-Nachasza. Ci oto są mężami z Rekab.
###### **1Krn 4,13**
 Synami Kenaza byli: Otniel i Seraj a, a synami Otniela [byli]: Chatat i Meonotaj.
###### **1Krn 4,14**
 Meonotaj był ojcem Ofry. Seraj a był ojcem Joaba, który był ojcem Ge-Charaszim - byli bowiem rzemieślnikami.
###### **1Krn 4,15**
 Synami Kaleba, który był synem Jefunnego, byli: Ir, Ela i Naam, synem Eli był Kenaz.
###### **1Krn 4,16**
 Synami Jehallelela byli: Zif, Zifa, Tirja i Asarel.
###### **1Krn 4,17**
 Synami Ezry byli: Jeter, Mered, Efer i Jalon. Jeter był ojcem Mirjam, Szammaja i Jiszbacha, a ten był ojcem Esztemoi.
###### **1Krn 4,18**
 Żona jego Judejka, urodziła Jereda, ojca Gedora Chebera, ojca Soko, i Jekutiela, ojca Zanoacha. To są synowie Bitji, córki faraona, którą pojął [za żonę] Mered.
###### **1Krn 4,19**
 Synami żony Hodijji, siostry Nachama, byli: ojciec Keili, Garmita i Esztemoa, Maakatyta.
###### **1Krn 4,20**
 Synami zaś Szimona byli: Amnon, Rinna, Ben-Chanan i Tilon. Synami znów Jiszli byli: Zochet i synowie Zocheta.
###### **1Krn 4,21**
 Synami Szeli, syna Judy, byli: Er, ojciec Leki, i Lada, ojciec Mareszy oraz rodów pracujących w wytwórni bisioru w Bet-Aszbea,
###### **1Krn 4,22**
 Jokim, mężowie z Kozeby, Joasz i Saraf, którzy ożenili się w Moabie, ale powrócili do Betlejem. To są dawne wydarzenia.
###### **1Krn 4,23**
 Byli oni garncarzami i mieszkali w Netaim oraz w Gederze. Wykonując prace dla króla, mieszkali przy nim.
###### **1Krn 4,24**
 Synami Symeona byli: Nemuel, Jamin, Jarib, Zerach, Szaul.
###### **1Krn 4,25**
 Jego synem był Szallum, jego synem Mibsam, a jego synem Miszma.
###### **1Krn 4,26**
 Potomkami Miszmy byli: jego syn Chammuel, jego syn Zakkur, jego syn Szimi.
###### **1Krn 4,27**
 Szimi miał szesnastu synów i sześć córek, lecz bracia jego nie mieli licznego potomstwa. Wszystkie ich rody nie były tak liczne jak potomkowie Judy.
###### **1Krn 4,28**
 Mieszkali oni w Beerszeba, Molada i Chacar-Szual,
###### **1Krn 4,29**
 w Bilha, Ecem, Tolad,
###### **1Krn 4,30**
 Betuel, Chorma, Ciklag,
###### **1Krn 4,31**
 Bet-Markabot, Hacar-Susim, Bet-Birei i w Szaaraim. Te miasta należały do nich aż do panowania Dawida
###### **1Krn 4,32**
 a także osiedla: Etam, Ain, Rimmon, Token i Aszan, czyli pięć miasteczek
###### **1Krn 4,33**
 i wszystkie ich wioski, otaczające owe miasteczka aż po Baal. Oto ich siedziby i spisy ich rodów:
###### **1Krn 4,34**
 Meszobab, Jamlek i Josza, syn Amacji,
###### **1Krn 4,35**
 Joel, Jehu, syn Joszibji, który był synem Seraji, a ten znów synem Asiela,
###### **1Krn 4,36**
 Eljoenaj, Jaakoba, Jeszochaja, Asaja, Adiel, Jesimiel, Benaja,
###### **1Krn 4,37**
 Ziza, syn Szifiego, który był synem Allona, a ten synem Jedaji, syna Szimriego, a ten znów był synem Szemaji.
###### **1Krn 4,38**
 Wyliczeni tu imiennie byli książętami swoich rodów, a domy ich ojców rozrosły się niezmiernie.
###### **1Krn 4,39**
 Dotarli aż do wejścia do Gedor, do wschodniej części doliny, w poszukiwaniu pastwisk dla swych trzód.
###### **1Krn 4,40**
 Znaleźli pastwiska bujne i dobre, ziemię rozległą, spokojną i bezpieczną, ponieważ poprzedni mieszkańcy byli potomkami Chama.
###### **1Krn 4,41**
 Wymienieni tu [mężowie] przybyli w czasach króla judzkiego Ezechiasza, zniszczyli ich namioty, a Meunitów, których tam zastali obłożyli klątwą aż po dzień dzisiejszy. Następnie sami osiedlili się na ich miejscu, albowiem były tam pastwiska dla trzód.
###### **1Krn 4,42**
 Pewna ich część, pięciuset mężów spośród potomków Symeona, wyruszyła w góry Seiru, a na ich czele [poszli] synowie Jisziego: Pelatja, Nearja, Refaja i Uzziel.
###### **1Krn 4,43**
 Pobili oni resztę ocalałych Amalekitów i zamieszkali tam aż po dzień dzisiejszy.
# 1Krn 4 BR
###### **1Krn 4,1**
 Oto synowie Judy: Peres, Chesron, Karmi, Chur i Szobal.
###### **1Krn 4,2**
 Reajasz, syn Szobala, był ojcem Jachata, Jachat - ojcem Achumaja i Lahada. Są to rody Soreatytów.
###### **1Krn 4,3**
 Synami Etama byli: Jizreel, Jiszma oraz Jidbasz. Ich siostra nazywała się Haslelponi.
###### **1Krn 4,4**
 Penuel był ojcem Gedora, Ezer zaś ojcem Chuszy. Byli to potomkowie Chura, pierworodnego Efraty, ojca Betlejem.
###### **1Krn 4,5**
 Aszchur, ojciec Tekoa, miał dwie żony: Cheleę i Naarę.
###### **1Krn 4,6**
 Synami Naary byli: Achuzam, Chefer, Temni oraz Achasztari. Naara była ich matką.
###### **1Krn 4,7**
 Natomiast synami Chelei byli: Seret, Sochar i Etnan.
###### **1Krn 4,8**
 Potomkami Kosa byli: Anub, Sobeba oraz wszystkie rody Acharchela, syna Haruma.
###### **1Krn 4,9**
 Jabes cieszył się większym poważaniem niż jego bracia. Kiedy przychodził na świat, jego matka nadała mu imię Jabes, mówiła bowiem: Rodziłam go w wielkim bólu.
###### **1Krn 4,10**
 A Jabes modlił się do Boga Izraela, mówiąc: Racz mnie obdarzyć swoim błogosławieństwem i rozszerzyć moje granice! Niech Twoja prawica będzie ze mną, niech mnie strzeże od wszelkiego nieszczęścia i nie sprowadza na mnie żadnego ucisku! I dał mu Bóg wszystko, o co tylko prosił.
###### **1Krn 4,11**
 Kelub, brat Szuchy, był ojcem Mechira, a Mechir był ojcem Esztona.
###### **1Krn 4,12**
 Potomkami Esztona byli: Bet-Rafa, Paseach oraz Techinna, ojciec Ir-Nachasza. Ci wywodzili się z Rekab.
###### **1Krn 4,13**
 Synami Kenaza byli Otniel i Serajasz, a synami Otniela - Chatat i Meonotaj.
###### **1Krn 4,14**
 Meonotaj był ojcem Ofry, a Serajasz - ojcem Joaba, ojca Ge-Haraszim, to znaczy ludzi z Doliny Rzemieślników, gdyż byli oni rzemieślnikami.
###### **1Krn 4,15**
 Synami Kaleba, syna Jefunnego, byli: Ir, Ela i Naam, a synem Eli był Kenaz.
###### **1Krn 4,16**
 A oto synowie Jehalleleela: Zif, Zifa, Tiria, Asareel,
###### **1Krn 4,17**
 synami Ezry zaś byli: Jeter, Mered, Efer i Jalon. Potem [Bitia, Egipcjanka, żona Mereda] urodziła Miriam, Szammaja oraz Iszbacha, ojca Esztemoi.
###### **1Krn 4,18**
 Jego żona, Judejka, była matką Jereda, ojca Gedora, Chebera, ojca Soko, oraz Jekutiela, ojca Zanoacha. Byli to synowie Bitii, córki faraona, którą Mered wziął sobie za żonę,
###### **1Krn 4,19**
 i synowie jego judzkiej żony Hodijji, siostry Nachama, ojca Keili, Garmity, oraz Esztemoi, Maakatyty.
###### **1Krn 4,20**
 A oto synowie Szymona: Amnon, Rinna, Ben-Chanan i Tilon. Synowie zaś Jisziego: Zochet i Ben-Zochet.
###### **1Krn 4,21**
 Szela, syn Judy, był ojcem Era, ojca Leki, i Laedy, ojca Mareszy. Od niego też wywodziły się rody wytwarzające bisior w Bet-Aszbea,
###### **1Krn 4,22**
 a także Jokim i mężowie z Kozeby oraz Joasz i Saraf, którzy panowali w Moabie, zanim powrócili do Betlejem. Są to już bardzo dawne dzieje.
###### **1Krn 4,23**
 Byli oni garncarzami, a mieszkali w Netaim i w Gederze, pozostając zawsze w pobliżu króla, ponieważ wykonywali dla niego różne prace.
###### **1Krn 4,24**
 A oto synowie Symeona: Nemuel, Jamin, Jarib, Zerach, Saul.
###### **1Krn 4,25**
 Saul był ojcem Szalluma, Szallum ojcem Mibsama, Mibsam ojcem Miszmy,
###### **1Krn 4,26**
 Miszma ojcem Chammuela, Chammuel ojcem Zakkura, Zakkur ojcem Szimeiego.
###### **1Krn 4,27**
 Szimei miał szesnastu synów i sześć córek, ale jego bracia nie mieli zbyt licznego potomstwa i dlatego wszystkie ich rody nie były tak wielkie jak potomków Judy.
###### **1Krn 4,28**
 Mieszkali oni w miastach: Beer-Szeba, Molada, Chasar-Szual,
###### **1Krn 4,29**
 Bilha, Esem, Tolad,
###### **1Krn 4,30**
 Betuel, Chorma, Siklag,
###### **1Krn 4,31**
 Bet-Markabot, Chasar-Susim, Bet-Birei, Szaarim. Miasta te były w ich posiadaniu aż do czasu panowania Dawida.
###### **1Krn 4,32**
 Poza tym należały do nich miasta: Etam, Ain, Rimmon, Token i Aszan - w sumie pięć miast -
###### **1Krn 4,33**
 oraz wszystkie okoliczne osiedla aż po miasto Baalat. To były ich siedziby według spisów rodowych.
###### **1Krn 4,34**
 Meszobab, Jamlek, Josza, syn Amazjasza,
###### **1Krn 4,35**
 Joel, Jehu, syn Joszibiasza, syna Serajasza, syna Asjela,
###### **1Krn 4,36**
 Elioenaj, Jaakoba, Jeszochajasz, Asajasz, Adiel, Jesimiel, Benajasz,
###### **1Krn 4,37**
 Ziza, syn Szifiego, syna Allona, syna Jedajasza, syna Szimriego, syna Szemajasza -
###### **1Krn 4,38**
 to wymienieni imiennie naczelnicy rodów, które z czasem bardzo się rozrosły
###### **1Krn 4,39**
 i zawędrowały aż na wschodnią stronę doliny, w okolice wąwozu Gedor, szukając pastwisk dla swoich trzód.
###### **1Krn 4,40**
 I znaleźli pastwiska obfite w trawę, i dobre tereny rozległe, spokojne, wolne od wszelkich niebezpieczeństw. Należały one kiedyś do rodu Chamitów.
###### **1Krn 4,41**
 Otóż ludzie wyliczeni przed chwilą po imieniu przybyli tu za czasów króla judzkiego Ezechiasza. Zniszczyli namioty tubylców, a Meunitów, którzy się tam również znajdowali, obłożyli klątwą na zawsze i sami osiedlili się na ich miejscu, ponieważ znaleźli tam pastwiska dla swoich trzód.
###### **1Krn 4,42**
 Niektórzy spośród potomków Symeona udali się w góry Seir. Było ich razem około pięciuset, a na ich czele stali: Pelatiasz, Neariasz, Refajasz i Uzzjel, synowie Jisziego.
###### **1Krn 4,43**
 Rozbili oni resztki ocalałych Amalekitów i osiedlili się na miejscu, które zajmują po dzień dzisiejszy.
# 1Krn 4 WUJ
###### **1Krn 4,1**
 Synowie Judowi: Phares, Hesron, i Charmi, i Hur, i Sobal.
###### **1Krn 4,2**
 A Raja syn Sobalów zrodził Jobatha, z którego poszli Ahumai i Laad. Te rodzaje Sarathi.
###### **1Krn 4,3**
 To też pokolenie Etam: Jezrahel i Jesema i Jedebos. A imię siostry ich Asalelphuni.
###### **1Krn 4,4**
 A Phanuel ociec Gedor, a Ezer ociec Hosa, ci są synowie Hur pierworodnego Ephrata ojca Bethlehem,
###### **1Krn 4,5**
 Assur lepak ociec Thekujej miał dwie żenie, Halaa i Naara,
###### **1Krn 4,6**
 I urodziła mu Naara, Oozama, i Hephera, i Hetmani, i Ahastari, ci są synowie Nagra.
###### **1Krn 4,7**
 A synowie Halajej: Sereth, Isaar, i Ethnan.
###### **1Krn 4,8**
 Kos lepak zrodził Anoba, i Soboba, i naród Aharehela syna Arum.
###### **1Krn 4,9**
 Lecz Jabes był zacniejszy nad bracią swą, a matka jego dała mu imię Jabes, mówiąc: lżem go w boleści porodziła.
###### **1Krn 4,10**
 I wzywał Jabes Boga Izraelskiego, mówiąc: Jeśli błogosławiąc błogosławić mi będziesz, i rozszerzysz granice moje, a ręka twoja będzie ze mną, a uczynisz, że mię złość nie potłumi. I dał Bóg o co prosił.
###### **1Krn 4,11**
 A Kaleb brat Sue zrodził Machira, który był ojcem Esthon.
###### **1Krn 4,12**
 Esthon lepak zrodził Betrapha, i Phesse i Tehmna ojca miasta Naas: ci są mężowie Recha.
###### **1Krn 4,13**
 A synowie Cenez: Othoniel i Saraja: synowie Othomelowi: Hathath i Maonathi.
###### **1Krn 4,14**
 Maonathi zrodził Ophra. Asaraja zrodził Joaba ojca Doliny rzemieślników: bo tam rzemieślnicy byli.
###### **1Krn 4,15**
 A synowie Kaleba syna Jephone: Hir i Ela i Naham. Synowie też Ele: Cenez.
###### **1Krn 4,16**
 A synowie Jaleleel: Ziph, i Zipha, Thiria, i Asrael.
###### **1Krn 4,17**
 A synowie Ezra: Jether, i Mered i Epher, i Jalon: I urodziła Maryą, i Sammaja, i Jesba ojca Esthamo.
###### **1Krn 4,18**
 Żona też jego Judaja, urodziła Jared ojca Gedo, i Hebera ojca Socho, i Ikuthiela ojca Zanoe, A to synowie Bethiej córki Pharaonowej, którą był pojął Mered.
###### **1Krn 4,19**
 A synowie żony Odaje siostry Nahama ojca Ceila: Garmi, i Estham, który był z Machaty.
###### **1Krn 4,20**
 Synowie też Symonowi: Amnon, i Rinna syn Hanan, i Thilon. A synowie Jesi: Zoheth i Benzoheth.
###### **1Krn 4,21**
 Synowie Sele, syna Juda, Her, ociec Lechy, i Laada ociec Maresy, i rodzaje domu robiących około bisiora w domu przysięgi.
###### **1Krn 4,22**
 I który zastanowił słońce, i mężowie kłamstwa, i bezpieczny, i rozpalający, którzy byli książęty w Moab i którzy się wrócili do Lahem, a to słowa stare.
###### **1Krn 4,23**
 Ci są garncarze, mieszkający w sadziech, i między płoty, przy królu, około robót jego, i mieszkali tam.
###### **1Krn 4,24**
 Synowie Symeonowi: Namuel, i Jamin, Jarib, Zara, Saul.
###### **1Krn 4,25**
 Sellum syn jego: Mabsan syn jego, Masma syn jego.
###### **1Krn 4,26**
 Synowie Masma: Hamuel syn jego: Zachur syn jego, Semei syn jego.
###### **1Krn 4,27**
 Synów Semei szesnaście, a córek sześć: ale bracia jego nie mieli synów wiele, a wszystek rodzaj nie mógł zrównać z liczbą synów Juda.
###### **1Krn 4,28**
 A mieszkali w Bersabee, i Molada, i Hasarsual.
###### **1Krn 4,29**
 I w Bala, i w Asom, i w Tholad.
###### **1Krn 4,30**
 I w Rathuel, i w Horma, i w Siceleg.
###### **1Krn 4,31**
 I w Bethmarchaboth, i w Hasarsusim, i w Bethberai, i w Saarim. Te miasta ich aż do króla Dawida.
###### **1Krn 4,32**
 Wsi też ich: Etam, i Aen, Remmon, i Thochen, i Asan miast pięć.
###### **1Krn 4,33**
 I wszystkie wioski ich około tych miast, aż do Baal. To jest mieszkanie ich, i rozdział osiadłości.
###### **1Krn 4,34**
 Mosobab też, i Jemlech, i Josa syn Amasiaszów.
###### **1Krn 4,35**
 I Joel, i Jehu syn Josabiei, syna Saraje, syna Asiel.
###### **1Krn 4,36**
 I Elioenai, i Jakóba, i Isuhaja, i Asaja, i Adiel, i Ismiel, i Banaja.
###### **1Krn 4,37**
 Ziza też syn Sepheja, syna Allon, syna Idaja, syna Semry, syna Samaja.
###### **1Krn 4,38**
 Teć są mianowane książęta w rodziech ich, i w domu powinowactw swoich wielce się rozmnożyli.
###### **1Krn 4,39**
 I ruszyli, się aby weszli do Gador aż na wschód słośca doliny, i żeby szukali paszej trzodam swoim.
###### **1Krn 4,40**
 I naleźli pasze obfite i barzo dobre, i ziemię szeroką, i spokojną, i rodzajną, w której pierwej mieszkali z rodu Cham.
###### **1Krn 4,41**
 Ci tedy przyszli, któreśmy mianowicie wyżej opisali, za czasu Ezechiasza króla Judzkiego: i porazili namioty ich, i obywatele, które tam naleźli, i wygładzili je aż do dnia dzisiejszego: i mieszkali miasto nich, iż tamże barzo obfite pasze naleźli.
###### **1Krn 4,42**
 Z synów też Simeon szli na górę Seir mężów pięćset, mając książęta Phaltiasza, i Naariasza, i Raphajasza, i Oziel syny Jesi:
###### **1Krn 4,43**
 I wybili ostatki, które były mogły ujść, z Amalekitów, i mieszkali tam miasto nich, aż po dziś dzień.
