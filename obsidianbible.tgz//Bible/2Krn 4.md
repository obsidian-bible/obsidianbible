# 2Krn 4 BT5
###### **2Krn 4,1**
 Uczynił też ołtarz z brązu, długi na dwadzieścia łokci, szeroki na dwadzieścia łokci, a na dziesięć łokci wysoki.
###### **2Krn 4,2**
  Następnie sporządził odlew okrągłego "morza" o średnicy dziesięciu łokci, wysokości pięciu łokci i o obwodzie trzydziestu łokci.
###### **2Krn 4,3**
 Pod nim były dokoła odlewy rozchylonych kielichów kwiatowych, dziesięć na jeden łokieć, opasujących to "morze" w krąg; w jego odlewie były razem odlane dwa rzędy rozchylonych kielichów kwiatowych.
###### **2Krn 4,4**
 Stało ono na dwunastu wołach. Trzy zwracały się ku północy, trzy ku zachodowi, trzy ku południowi, trzy na wschód. Morze to znajdowało się nad nimi u góry, a wszystkie ich zady [zwracały się] do wewnątrz.
###### **2Krn 4,5**
 Grubość jego była na szerokość dłoni, a brzeg jego był wykonany jak brzeg kielicha kwiatu lilii. Jego pojemność wynosiła tysiąc bat.
###### **2Krn 4,6**
 Sporządził też dziesięć kadzi i postawił ich pięć po prawej stronie, a pięć po lewej, aby obmywać w nich to, co przygotowano na całopalenie. "Morze" natomiast służyło kapłanom do mycia się w nim.
###### **2Krn 4,7**
 Sporządził także dziesięć złotych świeczników, zgodnie z przepisami o nich, i umieścił je w Miejscu Świętym, pięć po prawej stronie, pięć po lewej.
###### **2Krn 4,8**
 Sporządził ponadto dziesięć stołów i kazał je umieścić w Miejscu Świętym, pięć z prawej strony, pięć z lewej, a ponadto sto złotych kropielnic.
###### **2Krn 4,9**
 Wybudował nadto dziedziniec kapłański i wielki dziedziniec oraz bramy do niego wiodące, które pokrył brązem.
###### **2Krn 4,10**
 "Morze" zaś umieścił z prawej strony, w kierunku południowego wschodu.
###### **2Krn 4,11**
 Sporządził też Huram kotły, łopatki i kropielnice. Tak ukończył pracę, którą miał wykonać w świątyni Boga dla króla Salomona, a mianowicie:
###### **2Krn 4,12**
 dwie kolumny z owalnymi głowicami na szczycie tych kolumn, następnie dwie siatki do pokrycia dwóch owalnych głowic na szczycie tych kolumn,
###### **2Krn 4,13**
 dalej czterysta jabłek granatu na obydwu siatkach, po dwa rzędy jabłek granatu na każdej siatce < do pokrycia dwóch owalnych głowic, które były na tych kolumnach >,
###### **2Krn 4,14**
 i dziesięć kadzi na podstawach;
###### **2Krn 4,15**
 również jedno "morze" i dwanaście wołów pod nim,
###### **2Krn 4,16**
 kotły, łopatki, widełki do mięsa i wszystkie naczynia dla króla Salomona i dla domu Pańskiego sporządził Huram-Abi z polerowanego brązu.
###### **2Krn 4,17**
 Król polecił je odlać nad Jordanem, w dolinie między Sukkot i Seredata.
###### **2Krn 4,18**
 Sprawił zaś Salomon wszystkich tych naczyń takie mnóstwo, iż nie można było obliczyć wagi brązu, z którego je wykonano.
###### **2Krn 4,19**
 Sprawił też Salomon wszystkie naczynia, które są w domu Bożym, i złoty ołtarz, stoły na chleby pokładne,
###### **2Krn 4,20**
 świeczniki i ich lampy z czystego złota, by je zgodnie z przepisem zapalano przed sanktuarium.
###### **2Krn 4,21**
 Ponadto kwiaty, lampy i szczypce ze złota, i to z najlepszego złota.
###### **2Krn 4,22**
 A te nożyce do knotów, kropielnice, czasze i popielnice były z czystego złota. U wejścia do świątyni [zawiasy] bram wewnętrznych do Miejsca Najświętszego oraz bramy świątyni do głównej budowli były także złote.
# 2Krn 4 PAU
###### **2Krn 4,1**
 Sporządził również ołtarz z brązu o długości i szerokości dwudziestu łokci i wysokości dziesięciu łokci.
###### **2Krn 4,2**
 Potem wykonał „morze” - okrągły zbiornik o średnicy dziesięciu łokci, licząc od krawędzi do krawędzi, wysoki na pięć łokci i mający obwód trzydziestu łokci.
###### **2Krn 4,3**
 Poniżej jego krawędzi wykonano ornamenty przypominające woły. Podwójny rząd takich ozdób opasywał brzeg całego „morza”, po dziesięć na łokieć.
###### **2Krn 4,4**
 Było ono ustawione na dwunastu posągach wołów, z których trzy przodem były zwrócone na północ, trzy na zachód, trzy na południe i trzy na wschód, tyłem zaś do środka. Na nich wspierało się „morze”.
###### **2Krn 4,5**
 Jego ściany miały grubość jednej dłoni. Brzeg „morza” miał kształt kielicha kwiatu lilii. Jego pojemność wynosiła trzy tysiące bat.
###### **2Krn 4,6**
 Sporządził dziesięć mis przeznaczonych na obmycia. Pięć z nich ustawił po prawej, a pięć po lewej stronie, aby obmywać w nich przed spaleniem dary ofiarne. Samym kapłanom natomiast do obmyć służyło „morze”.
###### **2Krn 4,7**
 Wykonał też dziesięć złotych świeczników, zgodnie z przepisami, i ustawił pięć z nich po prawej, a pięć po lewej stronie w środkowej części świątyni.
###### **2Krn 4,8**
 Zrobił dziesięć stołów, które ustawił w środkowej części świątyni, pięć po prawej, a pięć po lewej stronie, ponadto sporządził sto złotych kropielnic.
###### **2Krn 4,9**
 Wybudował dziedziniec kapłański oraz wielki dziedziniec z bramami, które pokrył brązem.
###### **2Krn 4,10**
 „Morze” ustawił po prawej stronie świątyni, od południowego wschodu.
###### **2Krn 4,11**
 Hiram wykonał ponadto misy, łopatki i kropielnice. W ten sposób zakończył realizację następujących zamówień króla Salomona dla domu Bożego:
###### **2Krn 4,12**
 dwie kolumny, dwie podobne do pucharów głowice na szczytach dwóch kolumn, dwie sieci dla pokrycia dwóch owalnych głowic wieńczących kolumny,
###### **2Krn 4,13**
 czterysta owoców granatu dla dwóch wzorów sieci, po dwa rzędy owoców granatu w każdym, jako ozdoba owalnych głowic zwieńczających kolumny,
###### **2Krn 4,14**
 dziesięć podstaw i dziesięć mis na podstawach
###### **2Krn 4,15**
 oraz „morze” z dwunastoma posągami wołów pod nim,
###### **2Krn 4,16**
 a także naczynia, łopatki i widełki. Wszystkie te przedmioty, które wykonał Hiram-Abi do domu PANA na zlecenie króla Salomona, były z polerowanego brązu.
###### **2Krn 4,17**
 Do wykonania odlewów, zamówionych przez króla, posłużył się glinianymi formami. Król polecił je odlać w dolinie Jordanu, w gęstej ziemi, pomiędzy Sukkot a Seredą.
###### **2Krn 4,18**
 Salomon sporządził tak wiele przedmiotów, że ilość brązu użytego do ich wykonania była wprost nie do określenia.
###### **2Krn 4,19**
 Salomon wyposażył również dom Boży w inne przedmioty: złoty ołtarz i stoły na chleby poświęcone,
###### **2Krn 4,20**
 świeczniki oraz szczerozłote lampy zapalane zgodnie z przepisami przed najbardziej wewnętrznym miejscem świątyni.
###### **2Krn 4,21**
 Polecił wykonać z najlepszego złota także kwiaty, lampy i szczypce;
###### **2Krn 4,22**
 ponadto noże, kropielnice, puchary i kadzielnice. Ze złota były również bramy świątynne, drzwi prowadzące do miejsca najświętszego oraz drzwi do środkowej części domu.
# 2Krn 4 BP
###### **2Krn 4,1**
 Wykonał również ołtarz spiżowy długi na dwadzieścia łokci, szeroki również na dwadzieścia, a na dziesięć łokci wysoki.
###### **2Krn 4,2**
 Następnie wykonał odlew okrągłego "morza", którego średnica wynosiła dziesięć łokci, wysokość pięć łokci, a obwód trzydzieści.
###### **2Krn 4,3**
 Pod nim wyobrażenia kwiatów otaczały je dookoła wieńcem na trzydzieści łokci; okalały one morze dookoła dwoma rzędami i zostały odlane razem z morzem.
###### **2Krn 4,4**
 A stało ono na dwunastu wołach, z których trzy były zwrócone na północ, trzy na zachód, trzy na południe, a trzy na wschód. Morze znajdowało się nad nimi, a wszystkie ich zady były zwrócone do jego środka.
###### **2Krn 4,5**
 Grubość jego [ścian] była na szerokość dłoni, a jego krawędź miała kształt kielicha kwiatu lilii. Mogło pomieścić 3000 bat.
###### **2Krn 4,6**
 Wykonał też dziesięć zbiorników, z których pięć ustawił po prawej, a pięć po lewej strome; miano w nich obmywać wszystko, co było przygotowane na całopalenie. Morze natomiast było przeznaczone do obmywania się w nim kapłanów.
###### **2Krn 4,7**
 Następnie zrobił dziesięć świeczników złotych, zgodnie z ustalonymi o nich przepisami, i ustawił je w Świątyni, pięć po prawej, a pięć po lewej strome.
###### **2Krn 4,8**
 Wykonał również dziesięć stołów, które ustawił w Świątyni: pięć po prawej, a pięć po lewej strome. Sprawił nadto sto złotych czasz.
###### **2Krn 4,9**
 Wybudował dziedziniec kapłanów i wielki dziedziniec oraz bramy do nich, które pokrył spiżem.
###### **2Krn 4,10**
 Morze zaś umieścił po prawej strome w kierunku południowo-wschodnim.
###### **2Krn 4,11**
 Zrobił też Chiram kociołki, widełki i kropielnice. Tak to ukończył pracę, którą zobowiązał się wykonać dla króla Salomona w Domu Bożym.
###### **2Krn 4,12**
 Wykonał mianowicie dwie kolumny z owalnymi głowicami, które wieńczyły ich szczyty, oraz dwie siatki, które okrywały dwie owalne głowice na szczycie tych kolumn;
###### **2Krn 4,13**
 oprócz tego czterysta jabłek granatu do obydwu siatek, po dwa rzędy jabłek granatu do każdej siatki, w celu pokrycia owalnych głowic, wieńczących szczyty kolumn;
###### **2Krn 4,14**
 dziesięć podstaw i dziesięć zbiorników na podstawach;
###### **2Krn 4,15**
 jedno morze i dwanaście wołów pod nim.
###### **2Krn 4,16**
 Ponadto kociołki, łopatki i widełki. Wszystkie te przedmioty wykonał Chiram-Abi dla króla Salomona do Domu Jahwe z czystego spiżu.
###### **2Krn 4,17**
 Odlewał je król w okręgu Jordanu, w gliniastej ziemi, pomiędzy Sukkot i Ceredata.
###### **2Krn 4,18**
 A sporządził Salomon owych naczyń tak wiele, że nie badano wagi spiżu.
###### **2Krn 4,19**
 Sprawił też Salomon wszystkie sprzęty do Domu Bożego: ołtarz złoty i stoły na chleby składane Bogu,
###### **2Krn 4,20**
 świeczniki oraz szczerozłote lampy do nich, aby je zapalono przed Świątynią zgodnie z przepisem;
###### **2Krn 4,21**
 ponadto kwiaty, lampy i szczypce złote, wykonane z wyborowego złota;
###### **2Krn 4,22**
 wreszcie noże, czasze, kropielnice i kadzielnice - wszystko ze szczerego złota; podobnie też podwoje [wiodące do] Świątyni, bramy wewnętrzne do miejsca Najświętszego i bramy do miejsca Świętego - wszystko ze złota.
# 2Krn 4 BR
###### **2Krn 4,1**
 Zrobił Salomon ołtarz z brązu, długi na dwadzieścia łokci, szeroki też na dziesięć łokci.
###### **2Krn 4,2**
 Z brązu również odlał tak zwane morze o średnicy dziesięciu łokci, dokładnie okrągłe. Jego wysokość wynosiła pięć łokci, a obwód trzydzieści łokci.
###### **2Krn 4,3**
 Rzeźby w kształcie wołów znajdowały się pod spodem morza, dokoła niego, po dziesięć na każdym łokciu, w dwóch szeregach. Woły tworzyły razem z morzem jeden odlew.
###### **2Krn 4,4**
 Całe morze spoczywało na dwunastu wołach, z których trzy skierowane były na północ, trzy na zachód, trzy na południe i trzy na wschód. Morze umieszczone było nad nimi tak, że ich grzbiety były pod nim ukryte.
###### **2Krn 4,5**
 Ściany morza były grube na szerokość dłoni, a obrzeże przypominało wyglądem kielich kwiatu lilii. Morze mogło pomieścić trzy tysiące batów.
###### **2Krn 4,6**
 Poza tym kazał Salomon wykonać dziesięć kadzi, z których pięć ustawiono po prawej i pięć po lewej stronie (morza), a wszystkie miały służyć do obmyć. Tam oczyszczano to wszystko, co było przeznaczone na ofiary całopalenia, Kapłani zaś dokonywali swoich obmyć w morzu miedzianym.
###### **2Krn 4,7**
 Wykonano także, według otrzymanych wskazań, dziesięć świeczników ze złota. Świeczniki umieszczono przed wejściem do Świętego Świętych, pięć po prawej i pięć po lewej stronie.
###### **2Krn 4,8**
 Ponadto zrobiono dziesięć stołów i postawiono w świątyni pięć z nich po prawej i pięć po lewej stronie. Wykonano też sto czar ze złota.
###### **2Krn 4,9**
 Urządzono dziedziniec dla kapłanów oraz wielki dziedziniec i wiodące do niego bramy, których podwoje pokryto brązem.
###### **2Krn 4,10**
 Morze było ustawione z prawej strony, w kierunku zachodnio-południowym.
###### **2Krn 4,11**
 W końcu zrobił Huram kotły, łopatki i kropielnice. I tak doprowadził Huram do końca prace, które wykonywał dla Salomona wewnątrz świątyni Bożej.
###### **2Krn 4,12**
 Oto, co zrobił: dwie kolumny z owalnymi głowicami na szczytach; dwie jakby siatki pokrywające głowice, znajdujące się na szczytach kolumn;
###### **2Krn 4,13**
 czterysta owoców granatu do obydwu siatek, po dwa rzędy granatów na każdej siatce, okrywającej głowice, które znajdowały się na szczytach kolumn;
###### **2Krn 4,14**
 dziesięć kadzi na podstawach,
###### **2Krn 4,15**
 tak zwane morze wsparte na dwunastu rzeźbionych wołach;
###### **2Krn 4,16**
 kotły, łopatki i widełki do mięsa i wszystkie pozostałe sprzęty. Wszystko to wykonał mistrz Huram-Abi na polecenie króla Salomona dla świątyni Jahwe. Przedmioty były wykonane z polerowanego brązu.
###### **2Krn 4,17**
 Król polecił je odlewać na równinie nadjordańskiej, między Sukkot i Seredata.
###### **2Krn 4,18**
 Przedmiotów tych kazał Salomon uczynić tak dużo, że brązu na nie zużytego nikt nie był w stanie zważyć.
###### **2Krn 4,19**
 Salomon kazał również wykonać wszystkie inne przedmioty dla świątyni Jahwe, a więc ołtarz ze złota, stoły, na których miały się znajdować chleby podkładne;
###### **2Krn 4,20**
 świeczniki, razem z lampami, ze szczerego złota, do zapalania według przepisów prawa przed Świętym Świętych;
###### **2Krn 4,21**
 kwiaty, lampy, szczypce ze złota, z najcenniejszego złota;
###### **2Krn 4,22**
 nożyce do obcinania knotów, kropielnice, czary i popielnice - też ze szczerego złota. Nadto wszystkie zawiasy u bram wewnętrznych do Świętego Świętych oraz u bramy prowadzącej do samej świątyni były wykonane ze złota.
# 2Krn 4 WUJ
###### **2Krn 4,1**
 Uczynił też ołtarz miedziany dwadzieścia łokiet w zdłuż, i dwadzieścia łokiet w szerz, i dziesięć łokiet w zwyż.
###### **2Krn 4,2**
 Morze też lane na dziesiąci łokiet od brzegu aż do brzegu, okrągłe w koło: pięć łokiet miało w zwyż, a sznur na trzydzieści łokiet obtaczał okrąg jego.
###### **2Krn 4,3**
 Podobieństwo też wołów było pod niem, a na dziesięć łokiet ze wnątrz niejakie rzezania, jakoby dwiema rzędy środek morza obtaczały. Woły też były lite:
###### **2Krn 4,4**
 A samo morze na dwanaście wołów postawione było, z których trzej patrzali ku północy, a drudzy trzej ku zachodowi, a trzej inni ku południu, a trzej ostatni ku wschodowi, mając na sobie morze: a pośladki wołów były wewnątrz pod morzem.
###### **2Krn 4,5**
 A miąszość jego była na dłoń, a brzeg jego, był jako brzeg kubka, abo rozwitej liliiej, a brało w się trzy tysiące wiader.
###### **2Krn 4,6**
 Sprawił też dziesięć wanien, i postawił pięć po prawej, a pięć po lewej stronie iżby w nich omywali wszystko, co na całopalenie ofiarować mieli: a w morzu kapłani się omywali.
###### **2Krn 4,7**
 Sprawił też i dziesięć lichtarzów złotych nakształt jako je było rozkazano uczynić, i postawił je w kościele, pięć po prawej, a pięć po lewej stronie.
###### **2Krn 4,8**
 Nadto i stołów dziesięć: i postawił je w kościele, pięć po prawej, a pięć po lewej stronie: sto też czasz złotych.
###### **2Krn 4,9**
 Zbudował też sień kapłańską, i pałac wielki: i drzwi u pałacu, które oprawił miedzią.
###### **2Krn 4,10**
 A morze postawił po prawej stronie ku wschodu słońca na południe.
###### **2Krn 4,11**
 Poczynił też Hiram kotły, i widełki i czasze: i dokończył wszystkiej roboty domu Bożego.
###### **2Krn 4,12**
 To jest, dwa słupy i Capitella, i wierzchy, i jakoby niejakie siatki, któreby okrywały wierzchy nad Capitellami.
###### **2Krn 4,13**
 Malogranatów też cztery sta, i siatki dwie, tak, iż dwa rzędy malogranatów, z każdą się siatką złączały, które okrywały Capitella i wierzchy słupów.
###### **2Krn 4,14**
 Posprawował też podstawki i wanny, które włożył na podstawkach:
###### **2Krn 4,15**
 Morze jedno, wołów też dwanaście.
###### **2Krn 4,16**
 Pod morzem: i kotły, i widełki i czasze. Wszystkie naczynia porobił Salomonowi Hiram ociec jego w domu Pańskim z miedzi co naczystszej.
###### **2Krn 4,17**
 W krainie Jordanu odlewał je król w ziemi iłowatej między Sochot i Saredatha.
###### **2Krn 4,18**
 A było mnóstwo naczynia niezliczone, tak, iż wagi miedzi nie wiedziano.
###### **2Krn 4,19**
 I sprawił Salomon wszystko naczynie domu Bożego, i ołtarz złoty, i stoły, a na nich pokładne chleby:
###### **2Krn 4,20**
 Lichtarze też z lampami ich, aby świeciły przed wyrocznicą, według obyczaju, z szczerego złota.
###### **2Krn 4,21**
 I kwiaty niejakie, i lampy, i nożyczki złote: wszystko ze złota szczerego są sprawione.
###### **2Krn 4,22**
 Puszki też do kadzidła, i kadzielnice, i czasze, i moździerzyki z szczerego złota. I drzwi wyrył kościoła wnętrznego, to jest do świętego świętych, i drzwi kościelne zewnątrz złote. I tym sposobem dokończyła się wszystka robota, którą sprawił Salomon w domu Pańskim,
