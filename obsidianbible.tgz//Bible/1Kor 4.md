# 1Kor 4 BT5
###### **1Kor 4,1**
 Niech więc uważają nas ludzie za sługi Chrystusa i za szafarzy tajemnic Bożych.
###### **1Kor 4,2**
 A od szafarzy już tutaj się żąda, aby każdy z nich był wierny.
###### **1Kor 4,3**
 Mnie zaś najmniej zależy na tym, czy będę osądzony przez was, czy przez jakikolwiek trybunał ludzki. Co więcej, nawet sam siebie nie sądzę.
###### **1Kor 4,4**
 Sumienie nie wyrzuca mi wprawdzie niczego, ale to mnie jeszcze nie usprawiedliwia. Pan jest moim sędzią.
###### **1Kor 4,5**
 Przeto nie sądźcie przedwcześnie, dopóki nie przyjdzie Pan, który rozjaśni to, co w ciemnościach ukryte, i ujawni zamysły serc. Wtedy każdy otrzyma od Boga pochwałę.
###### **1Kor 4,6**
 Mówiąc to, miałem na myśli, bracia, mnie samego i Apollosa, ze względu na was, abyście mogli zrozumieć, że nie wolno wykraczać ponad to, co zostało napisane, i niech nikt w swej pysze nie wynosi się nad drugiego.
###### **1Kor 4,7**
 Któż będzie cię wyróżniał? Cóż masz, czego byś nie otrzymał? A jeśli otrzymałeś, to czemu się chełpisz, tak jakbyś nie otrzymał?
###### **1Kor 4,8**
 Tak więc już jesteście nasyceni, już opływacie w bogactwa. Zaczęliście królować bez nas! Otóż tak! Nawet trzeba, żebyście królowali, byśmy mogli współkrólować z wami.
###### **1Kor 4,9**
 Wydaje mi się bowiem, że Bóg nas, apostołów, wyznaczył jako ostatnich, jakby na śmierć skazanych. Staliśmy się bowiem widowiskiem dla świata, aniołów i ludzi;
###### **1Kor 4,10**
 my głupi dla Chrystusa, wy mądrzy w Chrystusie, my niemocni, wy mocni; wy doznajecie szacunku, a my wzgardy.
###### **1Kor 4,11**
 Aż do tej chwili łakniemy i cierpimy pragnienie, brak nam odzieży, jesteśmy policzkowani i skazani na tułaczkę,
###### **1Kor 4,12**
 i utrudzeni pracą rąk własnych. Błogosławimy, gdy nam złorzeczą, znosimy, gdy nas prześladują;
###### **1Kor 4,13**
 dobrym słowem odpowiadamy, gdy nas spotwarzają. Staliśmy się jakby śmieciem tego świata i wzbudzamy odrazę we wszystkich aż do tej chwili.
###### **1Kor 4,14**
 Nie piszę tego, żeby was zawstydzić, lecz aby was napomnieć – jako moje najdroższe dzieci.
###### **1Kor 4,15**
 Choćbyście mieli bowiem dziesiątki tysięcy wychowawców w Chrystusie, nie macie wielu ojców; ja to właśnie przez Ewangelię zrodziłem was w Chrystusie Jezusie.
###### **1Kor 4,16**
 Proszę was przeto, bądźcie naśladowcami moimi!
###### **1Kor 4,17**
 Dlatego to posłałem do was Tymoteusza, który jest moim synem umiłowanym i wiernym w Panu, aby wam przypomniał drogi moje w Chrystusie i to, czego nauczam wszędzie, w każdym Kościele.
###### **1Kor 4,18**
 Przechwalali się niektórzy, dumni z tego, że nie przybywam do was.
###### **1Kor 4,19**
 Otóż właśnie przybędę wkrótce, jeśli taka będzie wola Pana, i będę zważał nie na słowa tych, co się unoszą pychą, ale [zobaczę], co mogą uczynić.
###### **1Kor 4,20**
 Albowiem nie w słowie, lecz w mocy przejawia się królestwo Boże.
###### **1Kor 4,21**
 Cóż chcecie? Z rózgą mam do was przybyć czy z miłością i w duchu łagodności?
# 1Kor 4 PAU
###### **1Kor 4,1**
 Każdy niech uważa nas za sługi Chrystusa i zarządców tajemnic Boga.
###### **1Kor 4,2**
 Od zarządców zaś oczekuje się, by każdy z nich był wierny.
###### **1Kor 4,3**
 Dla mnie jednak jest najmniej ważne, czy będę osądzony przez was, czy przez jakikolwiek trybunał ludzki. Sam siebie też nie osądzam:
###### **1Kor 4,4**
 niczego wprawdzie w sobie nie dostrzegam, ale to mnie nie usprawiedliwia. Pan jest moim sędzią.
###### **1Kor 4,5**
 Nie rozstrzygajcie niczego aż do przyjścia Pana, który rozjaśni to, co ukryte w ciemności, i ujawni zamysły serc, a wtedy każdy otrzyma pochwałę od Boga.
###### **1Kor 4,6**
 Bracia! Ze względu na was odniosłem to do siebie samego i Apollosa, abyście na naszym przykładzie nauczyli się, że nie wolno wykraczać poza to, co napisano, i wynosić się jeden nad drugiego.
###### **1Kor 4,7**
 Kto cię wyróżnia? Co masz, czegoś nie otrzymał? Jeśli więc otrzymałeś, to dlaczego przechwalasz się, jakbyś nie otrzymał?
###### **1Kor 4,8**
 Jesteście już syci, już wzbogaciliście się, bez nas zaczęliście królować! Obyście naprawdę królowali, abyśmy i my królowali z wami.
###### **1Kor 4,9**
 Wydaje mi się bowiem, że Bóg wyznaczył nas, apostołów, jako ostatnich, jakby na śmierć skazanych, gdyż staliśmy się widowiskiem dla świata, aniołów i ludzi.
###### **1Kor 4,10**
 My, głupi z powodu Chrystusa, wy zaś rozsądni dzięki Chrystusowi; my - słabi, wy - mocni, my - pozbawieni czci, wy - szanowani.
###### **1Kor 4,11**
 Aż do tej pory cierpimy głód i pragnienie, brak nam ubrania, policzkują nas i tułamy się,
###### **1Kor 4,12**
 jesteśmy utrudzeni pracą własnych rąk. Gdy nas znieważają - błogosławimy, gdy prześladują - znosimy to,
###### **1Kor 4,13**
 gdy nas obrzucają obelgami - modlimy się. Aż dotąd jesteśmy jakby śmieciami świata, odrazą dla wszystkich.
###### **1Kor 4,14**
 Nie piszę o tym, aby was zawstydzić, lecz abyście to, jako moje ukochane dzieci, zrozumieli.
###### **1Kor 4,15**
 Choćbyście mieli dziesiątki tysięcy wychowawców w Chrystusie, ojców macie niewielu, a właśnie ja w Chrystusie Jezusie zrodziłem was przez Ewangelię.
###### **1Kor 4,16**
 Dlatego zachęcam was: bądźcie moimi naśladowcami!
###### **1Kor 4,17**
 W tym celu posłałem do was Tymoteusza, który jest moim ukochanym i wiernym Panu dzieckiem, aby wam przypomniał moje drogi w Chrystusie Jezusie, jak nauczam w każdym Kościele.
###### **1Kor 4,18**
 Dlatego że do was nie przychodzę, niektórzy wpadli w pychę.
###### **1Kor 4,19**
 Przyjdę jednak niebawem, jeśli Pan zechce, i poznam nie słowa owych pyszałków, ale ich moc,
###### **1Kor 4,20**
 bo królestwo Boże nie polega na słowie, ale na mocy.
###### **1Kor 4,21**
 Co wolicie? Czy mam do was przybyć z rózgą, czy w duchu miłości i delikatności?
# 1Kor 4 BP
###### **1Kor 4,1**
 Niechaj każdy człowiek uważa nas zatem za poddanych Chrystusa i szafarzy tajemnic Bożych.
###### **1Kor 4,2**
 W tej dziedzinie wymaga się od szafarza szczególnie wierności.
###### **1Kor 4,3**
 Mnie zaś nie zależy na tym, czy będę osądzony przez was czy przez inny ludzki trybunał, zresztą nawet sam siebie nie osądzam.
###### **1Kor 4,4**
 Sumienie wprawdzie niczego mi nie wyrzuca, ale to nie wystarcza, abym czuł się niewinny. Moim sędzią jest Pan.
###### **1Kor 4,5**
 Powstrzymajcie się zatem od wydawania sądów aż do czasu, gdy przyjdzie Pan. On oświetli rzeczy ukryte w ciemnościach i wyjawi zamiary serc, wtedy każdy otrzyma pochwałę od Boga.
###### **1Kor 4,6**
 To wszystko zastosowałem do siebie i do Apollosa ze względu na was, abyście na naszym przykładzie nauczyli się następującej zasady: "Nic ponad to, co zostało napisane" oraz abyście nie szczycili się jednymi, a drugimi pogardzali.
###### **1Kor 4,7**
 Kto ciebie wyróżnia? Co posiadasz, czego byś nie otrzymał? Jeśli zaś otrzymałeś, to dlaczego chlubisz się tym tak, jakbyś nie otrzymał?
###### **1Kor 4,8**
 Już jesteście nasyceni i wzbogaceni wewnętrznie? Bez nas macie udział w królestwie? Obyście nadal posiadali królestwo, a my abyśmy wraz z wami mieli w nim udział.
###### **1Kor 4,9**
 Wydaje mi się, że Bóg wyznaczył nam, apostołom, ostatnie miejsce, jak ludziom skazanym na śmierć. Staliśmy się bowiem widowiskiem dla świata, aniołów i ludzi.
###### **1Kor 4,10**
 My jesteśmy głupi z powodu Chrystusa, wy mądrzy w Chrystusie, my słabi, wy silni, wy cieszycie się uznaniem, my jesteśmy pozbawieni czci.
###### **1Kor 4,11**
 Aż do tego czasu ciągle jeszcze odczuwamy głód i pragnienie, jesteśmy nadzy i policzkowani, tułamy się
###### **1Kor 4,12**
 i trudzimy pracą rąk własnych. Rzucają na nas obelgi, a my błogosławimy, prześladują nas, a my to cierpliwie znosimy.
###### **1Kor 4,13**
 Zniesławiają nas, a my odwzajemniamy się uprzejmością. Staliśmy się jakby odpadami świata oraz brudem z wszystkiego zeskrobanym i jesteśmy nim aż dotąd.
###### **1Kor 4,14**
 Nie piszę tego, aby was zawstydzić, lecz żeby was upomnieć jak moje dzieci ukochane.
###### **1Kor 4,15**
 Chociaż mielibyście dziesięć tysięcy wychowawców w Chrystusie, to jednak niewielu macie ojców. Ja natomiast stałem się waszym ojcem w Chrystusie Jezusie, ponieważ oznajmiłem wam dobrą nowinę.
###### **1Kor 4,16**
 Błagam więc was: naśladujcie mnie!
###### **1Kor 4,17**
 Dlatego posłałem do was Tymoteusza, moje ukochane i wierne w Panu dziecko. On przypomni wam moje nauki o postępowaniu w Chrystusie Jezusie; to, czego nauczam wszędzie i w każdym kościele.
###### **1Kor 4,18**
 Niektórzy unieśli się pychą, ponieważ nie przybywam do was.
###### **1Kor 4,19**
 Wkrótce jednak przybędę, o ile Pan zechce, a wówczas nie będę brał pod uwagę słów tych, których pycha uniosła, lecz ich czyny.
###### **1Kor 4,20**
 Bo królestwo Boże nie polega na słowie, lecz czynie.
###### **1Kor 4,21**
 Co wolicie? Czy mam przybyć do was z rózgą, czy też z miłością i dobrocią.
# 1Kor 4 BR
###### **1Kor 4,1**
 Niech więc uważają nas ludzie za sługi Chrystusa i za szafarzy tajemnic Bożych.
###### **1Kor 4,2**
 A od szafarzy już tutaj się żąda, aby każdy z nich był wierny.
###### **1Kor 4,3**
 Mnie zaś najmniej zależy na tym, czy będę osądzony przez was, czy przez jakikolwiek trybunał ludzki. Co więcej, nawet sam siebie nie sądzę.
###### **1Kor 4,4**
 Sumienie nie wyrzuca mi wprawdzie niczego, ale to mnie jeszcze nie usprawiedliwia. Pan jest moim sędzią.
###### **1Kor 4,5**
 Przeto nie sądźcie przedwcześnie, dopóki nie przyjdzie Pan, który rozjaśni to, co w ciemnościach ukryte, i ujawni zamiary serc. Wtedy każdy otrzyma od Boga pochwałę.
###### **1Kor 4,6**
 Mówiąc to, miałem na myśli, bracia, mnie samego i Apollosa ze względu na was, abyście mogli zrozumieć, że nie wolno wykraczać ponad to, co zostało napisane, i niech nikt w swej pysze nie wynosi się nad drugiego.
###### **1Kor 4,7**
 Któż będzie cię wyróżniał? Cóż masz, czego byś nie otrzymał? A jeśliś otrzymał, to czemu się chełpisz, tak jakbyś nie otrzymał?
###### **1Kor 4,8**
 Tak więc już jesteście nasyceni, już opływacie w bogactwa. Zaczęliście królować bez nas? Otóż tak! Nawet trzeba, żebyście królowali, byśmy mogli współkrólować z wami.
###### **1Kor 4,9**
 Wydaje mi się bowiem, że Bóg nas, apostołów, wyznaczył jako ostatnich, jakby na śmierć skazanych. Staliśmy się bowiem widowiskiem światu, aniołom i ludziom;
###### **1Kor 4,10**
 my głupi dla Chrystusa, wy mądrzy w Chrystusie; my niemocni, wy mocni; wy doznajecie szacunku, a my wzgardy.
###### **1Kor 4,11**
 Aż do tej chwili łakniemy i cierpimy pragnienie, brak nam odzieży, jesteśmy policzkowani i skazani na tułaczkę,
###### **1Kor 4,12**
 i utrudzeni pracą rąk własnych. Błogosławimy, gdy nam złorzeczą, znosimy, gdy nas prześladują;
###### **1Kor 4,13**
 dobrym słowem odpowiadamy, gdy nas spotwarzają. Staliśmy się jakby śmieciem tego świata i odrazą dla wszystkich aż do tej chwili.
###### **1Kor 4,14**
 Nie piszę tego, żeby was zawstydzić, lecz aby was napomnieć jako moje najdroższe dzieci.
###### **1Kor 4,15**
 Choćbyście mieli bowiem dziesiątki tysięcy wychowawców w Chrystusie, nie macie wielu ojców; ja to właśnie przez Ewangelię zrodziłem was w Chrystusie Jezusie.
###### **1Kor 4,16**
 Proszę was przeto, bądźcie naśladowcami moimi.
###### **1Kor 4,17**
 Dlatego to posłałem do was Tymoteusza, który jest moim synem umiłowanym i wiernym w Panu, aby wam przypominał drogi moje w Chrystusie i to, czego nauczam wszędzie, w każdym Kościele.
###### **1Kor 4,18**
 Przechwalali się niektórzy, dumni z tego, że nie przybywam do was.
###### **1Kor 4,19**
 Otóż właśnie przybędę wkrótce jeśli taka będzie wola Pana, i nie będę zważał na słowa tych, co się unoszą pychą, ale [zobaczę], co mogę uczynić.
###### **1Kor 4,20**
 Albowiem nie w słowie, lecz w mocy przejawia się królestwo Boże.
###### **1Kor 4,21**
 Cóż chcecie? Z rózgą mam do was przybyć czy z miłością i z łagodnością?
# 1Kor 4 WUJ
###### **1Kor 4,1**
 Tak niechaj człowiek o nas rozumie Jako o sługach Chrystusowych, i szafarzach tajemnic Bożych.
###### **1Kor 4,2**
 Tu już szukają między szafarzmi, aby który nalezion był wiernym.
###### **1Kor 4,3**
 Ale u mnie to jest namniejsza, żebych był od was sądzony, abo od dnia ludzkiego; lecz ani sam siebie sądzę.
###### **1Kor 4,4**
 Abowiem się w niwczem nie czuję: ale nie w tem jestem usprawiedliwion: a który mię sądzi Pan jest.
###### **1Kor 4,5**
 A tak nie sądźcie przed czasem, ażby Pan przyszedł, który też oświeci zakrycia ciemności, i objawi rady serc: a tedy chwała będzie każdemu od Boga.
###### **1Kor 4,6**
 A tomci bracia obrócił na się i na Apolla, dla was: abyście się nauczyli z nas, żeby się nadto co jest napisano, jeden za drugim nie nadymał przeciwko drugiemu.
###### **1Kor 4,7**
 Abowiem któż się rozsądza? A co masz czegoś nie wziął? A jeśliżeś wziął, przeczże się chlubisz jakobyś nie wziął?
###### **1Kor 4,8**
 Jużeście nasyceni, jużeście się bogatemi stali: oprócz nas królujecie: a bodajeście królowali, żebyśmy i my z wami królowali.
###### **1Kor 4,9**
 Bo mniemam, iż Bóg nas Apostoły ostatnie pokazał jakoby na śmierć naznaczone. Abowiem staliśmy się dziwowiskiem światu, i aniołom, i ludziom.
###### **1Kor 4,10**
 My głupi dla Chrystusa a wy roztropni w Chrystusie, myśmi słabi, a wy mocni: wy zacni, a my beze czci.
###### **1Kor 4,11**
 A do tej godziny i łakniemy, i pragniemy, i nadzy jesteśmy, i bywamy policzkowani, i tułamy się,
###### **1Kor 4,12**
 I pracujemy, robiąc swemi rękoma. Złorzeczą nam, a błogosławiemy: prześladowanie cierpiemy, a znosimy:
###### **1Kor 4,13**
 Bluźnią nas, a modlimy się. Staliśmy się jako plugastwa tego świata, śmieci wszystkich aż dotąd.
###### **1Kor 4,14**
 Nie żebym was zawstydził to piszę, ale jako syny moje najmilsze napominam.
###### **1Kor 4,15**
 Abowiem choćbyście mieli dziesięć tysięcy Pedagogów w Chrystusie, ale nie wiele ojców, bo w Chrystusie Jezusie przez Ewanielią jam was urodził.
###### **1Kor 4,16**
 Proszę was tedy, bądźcie naśladowcami mojemi jakom i ja Chrystusów.
###### **1Kor 4,17**
 Dla tegom posłał do was Tymoteusza, który jest syn mój namilszy i wierny w Panu który wam przypomni drogi moje, które są w Chrystusie Jezusie, jako wszędy w każdym kościele uczę
###### **1Kor 4,18**
 Jakobych nie miał przyść do was, tak się niektórzy nadęli.
###### **1Kor 4,19**
 Ale rychło przydę do was, jeśli Pan będzie chciał: i doznam nie mowy tych, którzy się nadęli, ale mocy.
###### **1Kor 4,20**
 Abowiem nie w mowie jest królestwo Boże, ale w mocy.
###### **1Kor 4,21**
 Co chcecie? z rózgąli mam przyść do was, czyli z miłością, i z duchem cichości?
# 1Kor 4 STERN
###### **1Kor 4,1**
 Powinniście więc uważać nas za sługi Mesjasza, za powierników ukrytych prawd Bożych.
###### **1Kor 4,2**
 A od powiernika wymaga się tego, aby się okazał godny zaufania.
###### **1Kor 4,3**
 mnie zaś zbytnio nie obchodzi, jak osądzicie mnie wy czy jakiś sąd ludzki; bo w istocie nawet sam siebie nie osądzam.
###### **1Kor 4,4**
 Nie jestem świadomy niczego, co by świadczyło przeciw mnie, ale to nie czyni mnie niewinnym. Tym, który mnie osądza, jest Pan.
###### **1Kor 4,5**
 Nie ferujcie więc wyroków przedwcześnie, zanim przyjdzie Pan; bo On wywiedzie na światło to, co teraz ukryte w ciemności; obnaży pobudki ludzkich serc; a wtedy każdy otrzyma od Boga taką pochwałę, na jaką zasłużył.
###### **1Kor 4,6**
 A w tym, bracia, co teraz mówiłem, posłużyłem się przykładem siebie i Apollosa, chcąc was nauczyć, abyście nie wykraczali ponad to, co mówi Tanach, i nie opowiadali się butnie za jednym przywódcą przeciwko drugiemu.
###### **1Kor 4,7**
 Bo ostatecznie cóż czyni cię tak szczególnym? Cóż masz, czego byś nie otrzymał w darze? A jeśli był to rzeczywiście dar, to czemu chełpisz się, tak jakby nie był?
###### **1Kor 4,8**
 Już się nasyciliście? Już jesteście bogaci? Zostaliście królami, choć my nimi nie jesteśmy? No to życzyłbym wam, żebyście naprawdę byli królami, ażebyśmy i my mogli uczestniczyć w waszym królowaniu!
###### **1Kor 4,9**
 Bo sądzę, że Bóg umieścił nas, wysłanników, na szarym końcu, jak ludzi skazanych na śmierć na arenie: staliśmy się widowiskiem dla całego wszechświata, tak aniołów, jak i ludzi.
###### **1Kor 4,10**
 Ze względu na Mesjasza my jesteśmy głupcami, ale w jedności z Mesjaszem wy jesteście mądrzy! My jesteśmy słabi, ale wy jesteście silni; jesteście poważani, a my poniżani.
###### **1Kor 4,11**
 Aż dotąd chodzimy głodni i spragnieni, odziani w łachmany, poniewierani, tułamy się z miejsca do miejsca,
###### **1Kor 4,12**
 w znoju zarabiamy na życie własnymi rękami. Gdy nas przeklinają, zawsze błogosławimy; gdy nas prześladują, dalej to znosimy;
###### **1Kor 4,13**
 gdy nas oczerniają, nie zaprzestajemy naszych apeli. Jesteśmy odpadkami tego świata, śmieciem ziemi - tak jest, aż dotąd!
###### **1Kor 4,14**
 Nie piszę tego po to, aby was zawstydzić, ale żeby rzucić wam, drogie dzieci, wyzwanie i skłonić was do zmiany.
###### **1Kor 4,15**
 Bo nawet gdybyście mieli dziesięć tysięcy nauczycieli, to co się tyczy Mesjasza, nie macie wielu ojców; bo co się tyczy Mesjasza Jeszui, to ja stałem się waszym ojcem przez Dobrą Nowinę.
###### **1Kor 4,16**
 Dlatego nalegam, abyście mnie naśladowali.
###### **1Kor 4,17**
 Z tego powodu posłałem do was Tymoteusza, moje ukochane i wierne dziecię w Panu. On wam przypomni, w jaki sposób żyję w jedności z Mesjaszem Jeszuą i jak nauczam wszędzie, w każdym zgromadzeniu.
###### **1Kor 4,18**
 Gdy nie przybyłem do was w odwiedziny, niektórzy z was zrobili się butni.
###### **1Kor 4,19**
 Ale wkrótce do was przybędę, jeśli Pan zechce; i przyjrzę się nie gadaniu tych butnych, ale ich mocy.
###### **1Kor 4,20**
 Bo Królestwo Boże to nie kwestia słów, ale mocy.
###### **1Kor 4,21**
 Co wolicie - żebym przybył do was z kijem? Czy z miłością, w duchu łagodności?
# 1Kor 4 TRO
###### **1Kor 4,1**
 **ουτως** *houtōs* Tak [[G3779]] [[ADV]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **λογιζεσθω** *logizesthō* niech zalicza – niech liczy [[G3049]] WTV-PNM-3S **ανθρωπος** *anthrōpos* człowiek [[G444]] [[N-NSM]] **ως** *hōs* jak [[G5613]] [[ADV]] **υπηρετας** *hypēretas* podwładnych – pomocnikòw [[G5257]] [[N-APM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **οικονομους** *oikonomous* zarządców [[G3623]] [[N-APM]] **μυστηριων** *mystēriōn* tajemnic [[G3466]] WTN-GPN **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **1Kor 4,2**
 **ο** *ho* Co [[G3739]] WTR-ASN **δε** *de* zaś [[G1161]] [[CONJ]] **λοιπον** *loipon* w końcu [[G3063]] WTA-ASN **ζητειται** *zēteitai* jest szukane [[G2212]] WTV-PPI-3S **εν** *en* w [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPM **οικονομοις** *oikonomois* zarządcach [[G3623]] WTN-DPM **ινα** *hina* aby [[G2443]] [[CONJ]] **πιστος** *pistos* wiernym [[G4103]] [[A-NSM]] **τις** *tis* każdy [[G5100]] WTX-NSM **ευρεθη** *heurethē* zostałby znaleziony [[G2147]] WTV-APS-3S
###### **1Kor 4,3**
 **εμοι** *emoi* Mnie [[G1698]] WTP-1DS **δε** *de* zaś [[G1161]] [[CONJ]] **εις** *eis* za [[G1519]] [[PREP]] **ελαχιστον** *elachiston* najmniejsze [[G1646]] WTA-ASN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ινα** *hina* aby [[G2443]] [[CONJ]] **υφ** *hyf* przy [[G5259]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **ανακριθω** *anakrithō* zostałbym osądzony [[G350]] WTV-APS-1S **η** *ē* lub [[G2228]] WTPRT **υπο** *hypo* przez [[G5259]] [[PREP]] **ανθρωπινης** *anthrōpinēs* ludzki [[G442]] WTA-GSF **ημερας** *hēmeras* dzień [[G2250]] [[N-GSF]] **αλλ** *all* ale [[G235]] [[CONJ]] **ουδε** *oude* ani [[G3761]] [[ADV]] **εμαυτον** *emauton* siebie [[G1683]] WTF-1ASM **ανακρινω** *anakrinō* osądzam [[G350]] WTV-PAI-1S
###### **1Kor 4,4**
 **ουδεν** *ouden* niczego [[G3762]] WTA-ASN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εμαυτω** *emautō* (o) sobie [[G1683]] WTF-1DSM **συνοιδα** *synoida* uważam – dostrzegam [[G4894]] WTV-RAI-1S **αλλ** *all* ale [[G235]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εν** *en* w [[G1722]] [[PREP]] **τουτω** *toutō* tym [[G5129]] WTD-DSN **δεδικαιωμαι** *dedikaiōmai* jestem uznany za sprawiedliwego – jestem usprawiedliwiony [[G1344]] WTV-RPI-1S **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **ανακρινων** *anakrinōn* osądzający [[G350]] [[V-PAP-NSM]] **με** *me* mnie [[G3165]] WTP-1AS **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S
###### **1Kor 4,5**
 **ωστε** *hōste* że [[G5620]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **προ** *pro* przed [[G4253]] [[PREP]] **καιρου** *kairou* porą [[G2540]] [[N-GSM]] **τι** *ti* coś [[G5100]] WTX-ASN **κρινετε** *krinete* sądźcie [[G2919]] WTV-PAM-2P **εως** *heōs* aż [[G2193]] [[CONJ]] **αν** *an* (kiedy)kolwiek [[G302]] WTPRT **ελθη** *elthē* przyszedłby [[G2064]] WTV-2AAS-3S **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **ος** *hos* który [[G3739]] WTR-NSM **και** *kai* i [[G2532]] [[CONJ]] **φωτισει** *fōtisei* wydobędzie na światło – oświetli [[G5461]] WTV-FAI-3S **τα** *ta* [[G3588]] WTT-APN **κρυπτα** *krypta* ukryte [[G2927]] WTA-APN **του** *tou* [[G3588]] WTT-GSN **σκοτους** *skotous* ciemności [[G4655]] [[N-GSN]] **και** *kai* i [[G2532]] [[CONJ]] **φανερωσει** *fanerōsei* ukaże – uczyni widocznym [[G5319]] WTV-FAI-3S **τας** *tas* [[G3588]] WTT-APF **βουλας** *boulas* postanowienia – rady [[G1012]] WTN-APF **των** *tōn* [[G3588]] WTT-GPF **καρδιων** *kardiōn* serc [[G2588]] WTN-GPF **και** *kai* i [[G2532]] [[CONJ]] **τοτε** *tote* wtedy [[G5119]] [[ADV]] **ο** *ho* [[G3588]] [[T-NSM]] **επαινος** *epainos* pochwała [[G1868]] [[N-NSM]] **γενησεται** *genēsetai* stanie się [[G1096]] WTV-FDI-3S **εκαστω** *hekastō* każdemu [[G1538]] WTA-DSM **απο** *apo* od [[G575]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **1Kor 4,6**
 **ταυτα** *tauta* Te [[G5023]] WTD-APN **δε** *de* zaś [[G1161]] [[CONJ]] **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **μετεσχηματισα** *meteschēmatisa* odnosiłem – zmieniłem postać [[G3345]] WTV-AAI-1S **εις** *eis* do [[G1519]] [[PREP]] **εμαυτον** *emauton* siebie [[G1683]] WTF-1ASM **και** *kai* i [[G2532]] [[CONJ]] **απολλω** *apollō* Apollosa [[G625]] [[N-ASM]] **δι** *di* przez [[G1223]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **ινα** *hina* aby [[G2443]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **ημιν** *hēmin* nas [[G2254]] WTP-1DP **μαθητε** *mathēte* nauczylibyście się [[G3129]] WTV-2AAS-2P **το** *to* [[G3588]] WTT-ASN **μη** *mē* nie [[G3361]] [[PRT-N]] **υπερ** *hyper* ponad [[G5228]] [[PREP]] **ο** *ho* co [[G3739]] WTR-ASN **γεγραπται** *gegraptai* jest napisane [[G1125]] WTV-RPI-3S **φρονειν** *fronein* myśleć – rozumieć [[G5426]] WTV-PAN **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **εις** *heis* jeden [[G1520]] [[A-NSM]] **υπερ** *hyper* ponad [[G5228]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **ενος** *henos* jednego [[G1520]] WTA-GSM **φυσιουσθε** *fysiousthe* bylibyście nadęci [[G5448]] WTV-PPS-2P **κατα** *kata* przeciw [[G2596]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **ετερου** *heterou* innemu [[G2087]] WTA-GSM
###### **1Kor 4,7**
 **τις** *tis* Kto [[G5101]] WTI-NSM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **σε** *se* cię [[G4571]] WTP-2AS **διακρινει** *diakrinei* wyróżnia – rozsądza [[G1252]] WTV-PAI-3S **τι** *ti* co [[G5101]] WTI-ASN **δε** *de* zaś [[G1161]] [[CONJ]] **εχεις** *echeis* masz [[G2192]] WTV-PAI-2S **ο** *ho* co [[G3739]] WTR-ASN **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ελαβες** *elabes* otrzymałeś – wziąłeś [[G2983]] WTV-2AAI-2S **ει** *ei* jeśli [[G1487]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **ελαβες** *elabes* otrzymałeś – wziąłeś [[G2983]] WTV-2AAI-2S **τι** *ti* dlaczego [[G5101]] WTI-ASN **καυχασαι** *kauchasai* chlubisz się – chełpisz się [[G2744]] WTV-PNI-2S **ως** *hōs* jak [[G5613]] [[ADV]] **μη** *mē* nie [[G3361]] [[PRT-N]] **λαβων** *labōn* otrzymawszy – wziąwszy [[G2983]] WTV-2AAP-NSM
###### **1Kor 4,8**
 **ηδη** *ēdē* Już [[G2235]] [[ADV]] **κεκορεσμενοι** *kekoresmenoi* którzy są zaspokojeni – którzy są nasyceni [[G2880]] WTV-RPP-NPM **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **ηδη** *ēdē* już [[G2235]] [[ADV]] **επλουτησατε** *eploutēsate* wzbogaciliście się [[G4147]] WTV-AAI-2P **χωρις** *chōris* niezależnie od – bez [[G5565]] [[ADV]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP **εβασιλευσατε** *ebasileusate* królowaliście – panowaliście [[G936]] WTV-AAI-2P **και** *kai* i [[G2532]] [[CONJ]] **οφελον** *ofelon* oby [[G3785]] WTINJ **γε** *ge* rzeczywiście – prawdziwie [[G1065]] WTPRT **εβασιλευσατε** *ebasileusate* królowaliście – panowaliście [[G936]] WTV-AAI-2P **ινα** *hina* aby [[G2443]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **ημεις** *hēmeis* my [[G2249]] WTP-1NP **υμιν** *hymin* (z) wami [[G5213]] WTP-2DP **συμβασιλευσωμεν** *symbasileusōmen* razem królowalibyśmy – razem panowalibyśmy [[G4821]] WTV-AAS-1P
###### **1Kor 4,9**
 **δοκω** *dokō* Uważam [[G1380]] WTV-PAI-1S-C **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **οτι** *hoti* że [[G3754]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **τους** *tous* [[G3588]] WTT-APM **αποστολους** *apostolous* wysłanników [[G652]] [[N-APM]] **εσχατους** *eschatous* ostatnimi [[G2078]] WTA-APM **απεδειξεν** *apedeiksen* pokazał [[G584]] [[V-AAI-3S]] **ως** *hōs* jak [[G5613]] [[ADV]] **επιθανατιους** *epithanatious* skazanych na śmierć [[G1935]] WTA-APM **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **θεατρον** *theatron* teatr – widowisko [[G2302]] WTN-NSN **εγενηθημεν** *egenēthēmen* staliśmy się [[G1096]] WTV-AOI-1P **τω** *tō* [[G3588]] WTT-DSM **κοσμω** *kosmō* światu [[G2889]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **αγγελοις** *angelois* zwiastunom [[G32]] WTN-DPM **και** *kai* i [[G2532]] [[CONJ]] **ανθρωποις** *anthrōpois* ludziom [[G444]] WTN-DPM
###### **1Kor 4,10**
 **ημεις** *hēmeis* My [[G2249]] WTP-1NP **μωροι** *mōroi* głupcy [[G3474]] WTA-NPM **δια** *dia* przez [[G1223]] [[PREP]] **χριστον** *christon* Pomazańca [[G5547]] [[N-ASM]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **δε** *de* zaś [[G1161]] [[CONJ]] **φρονιμοι** *fronimoi* rozumni – rozsądni [[G5429]] WTA-NPM **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ημεις** *hēmeis* my [[G2249]] WTP-1NP **ασθενεις** *astheneis* słabi – bezsilni [[G772]] WTA-NPM **υμεις** *hymeis* wy [[G5210]] WTP-2NP **δε** *de* zaś [[G1161]] [[CONJ]] **ισχυροι** *ischyroi* mocni – silni [[G2478]] WTA-NPM **υμεις** *hymeis* wy [[G5210]] WTP-2NP **ενδοξοι** *endoksoi* wspaniali – dostojni [[G1741]] WTA-NPM **ημεις** *hēmeis* my [[G2249]] WTP-1NP **δε** *de* zaś [[G1161]] [[CONJ]] **ατιμοι** *atimoi* lekceważeni – bez szacunku [[G820]] WTA-NPM
###### **1Kor 4,11**
 **αχρι** *achri* Aż do [[G891]] [[PREP]] **της** *tēs* (tej) [[G3588]] [[T-GSF]] **αρτι** *arti* teraz [[G737]] [[ADV]] **ωρας** *hōras* godziny – pory [[G5610]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **πεινωμεν** *peinōmen* jesteśmy głodni – łakniemy [[G3983]] WTV-PAI-1P **και** *kai* i [[G2532]] [[CONJ]] **διψωμεν** *dipsōmen* pragnęlibyśmy [[G1372]] WTV-PAS-1P **και** *kai* i [[G2532]] [[CONJ]] **γυμνητευομεν** *gymnēteuomen* jesteśmy nadzy [[G1130]] WTV-PAI-1P **και** *kai* i [[G2532]] [[CONJ]] **κολαφιζομεθα** *kolafizometha* jesteśmy bici pięściami – jesteśmy policzkowani [[G2852]] WTV-PPI-1P **και** *kai* i [[G2532]] [[CONJ]] **αστατουμεν** *astatoumen* jesteśmy na tułaczce – jesteśmy bez stałego miejsca [[G790]] WTV-PAI-1P
###### **1Kor 4,12**
 **και** *kai* i [[G2532]] [[CONJ]] **κοπιωμεν** *kopiōmen* trudzimy się [[G2872]] WTV-PAI-1P **εργαζομενοι** *ergazomenoi* pracując [[G2038]] WTV-PNP-NPM **ταις** *tais* [[G3588]] WTT-DPF **ιδιαις** *idiais* własnymi [[G2398]] WTA-DPF **χερσιν** *chersin* rękami [[G5495]] WTN-DPF **λοιδορουμενοι** *loidoroumenoi* będąc znieważanymi – którym się zmyśla [[G3058]] WTV-PPP-NPM **ευλογουμεν** *eulogoumen* błogosławimy – wysławiamy [[G2127]] WTV-PAI-1P **διωκομενοι** *diōkomenoi* będąc prześladowanymi – będąc ściganymi [[G1377]] WTV-PPP-NPM **ανεχομεθα** *anechometha* znosimy – podnosimy się [[G430]] WTV-PNI-1P
###### **1Kor 4,13**
 **βλασφημουμενοι** *blasfēmoumenoi* bluźniąc nam – złorzecząc nam [[G987]] WTV-PPP-NPM **παρακαλουμεν** *parakaloumen* zachęcamy [[G3870]] WTV-PAI-1P **ως** *hōs* jak [[G5613]] [[ADV]] **περικαθαρματα** *perikatharmata* śmieci – nieczystości [[G4027]] WTN-NPN **του** *tou* [[G3588]] WTT-GSM **κοσμου** *kosmou* świata [[G2889]] [[N-GSM]] **εγενηθημεν** *egenēthēmen* staliśmy się [[G1096]] WTV-AOI-1P **παντων** *pantōn* wszystkich [[G3956]] WTA-GPN **περιψημα** *peripsēma* odpad [[G4067]] WTN-NSN **εως** *heōs* aż do [[G2193]] [[CONJ]] **αρτι** *arti* teraz [[G737]] [[ADV]]
###### **1Kor 4,14**
 **ουκ** *ouk* Nie [[G3756]] [[PRT-N]] **εντρεπων** *entrepōn* zawstydzając [[G1788]] [[V-PAP-NSM]] **υμας** *hymas* was [[G5209]] WTP-2AP **γραφω** *grafō* piszę [[G1125]] WTV-PAI-1S **ταυτα** *tauta* te [[G5023]] WTD-APN **αλλ** *all* ale [[G235]] [[CONJ]] **ως** *hōs* jak [[G5613]] [[ADV]] **τεκνα** *tekna* dzieci [[G5043]] WTN-NPN **μου** *mou* moje [[G3450]] WTP-1GS **αγαπητα** *agapēta* umiłowane [[G27]] WTA-NPN **νουθετω** *nouthetō* napominam – kładę do rozumu [[G3560]] WTV-PAI-1S
###### **1Kor 4,15**
 **εαν** *ean* Jeśli [[G1437]] WTCOND **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **μυριους** *myrious* dziesiątki tysięcy – miriady [[G3463]] WTA-APM **παιδαγωγους** *paidagōgous* pedagogów – wychowawców [[G3807]] [[N-APM]] **εχητε** *echēte* mielibyście [[G2192]] WTV-PAS-2P **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **αλλ** *all* ale [[G235]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **πολλους** *pollous* wielu [[G4183]] WTA-APM **πατερας** *pateras* ojców [[G3962]] [[N-APM]] **εν** *en* w [[G1722]] [[PREP]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM **δια** *dia* przez [[G1223]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **ευαγγελιου** *euangeliou* dobrą nowinę [[G2098]] [[N-GSN]] **εγω** *egō* ja [[G1473]] WTP-1NS **υμας** *hymas* was [[G5209]] WTP-2AP **εγεννησα** *egennēsa* zrodziłem [[G1080]] WTV-AAI-1S
###### **1Kor 4,16**
 **παρακαλω** *parakalō* Zachęcam [[G3870]] WTV-PAI-1S **ουν** *oun* więc [[G3767]] [[CONJ]] **υμας** *hymas* was [[G5209]] WTP-2AP **μιμηται** *mimētai* naśladowcy [[G3402]] WTN-NPM **μου** *mou* moi [[G3450]] WTP-1GS **γινεσθε** *ginesthe* stawajcie się [[G1096]] WTV-PNM-2P
###### **1Kor 4,17**
 **δια** *dia* Przez [[G1223]] [[PREP]] **τουτο** *touto* to [[G5124]] WTD-ASN **επεμψα** *epempsa* posłałem [[G3992]] WTV-AAI-1S **υμιν** *hymin* wam [[G5213]] WTP-2DP **τιμοθεον** *timotheon* Tymoteusza – [czczący Boga] [[G5095]] [[N-ASM]] **ος** *hos* który [[G3739]] WTR-NSM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **τεκνον** *teknon* dziecko [[G5043]] WTN-NSN **μου** *mou* moje [[G3450]] WTP-1GS **αγαπητον** *agapēton* umiłowane [[G27]] WTA-ASN **και** *kai* i [[G2532]] [[CONJ]] **πιστον** *piston* wierne [[G4103]] WTA-ASN **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **ος** *hos* który [[G3739]] WTR-NSM **υμας** *hymas* wam [[G5209]] WTP-2AP **αναμνησει** *anamnēsei* przypomni [[G363]] WTV-FAI-3S **τας** *tas* [[G3588]] WTT-APF **οδους** *hodous* drogi [[G3598]] WTN-APF **μου** *mou* moje [[G3450]] WTP-1GS **τας** *tas* [[G3588]] WTT-APF **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **πανταχου** *pantachou* wszędzie [[G3837]] [[ADV]] **εν** *en* w [[G1722]] [[PREP]] **παση** *pasē* każdym [[G3956]] WTA-DSF **εκκλησια** *ekklēsia* zgromadzeniu – (społeczności) wywołanych [[G1577]] [[N-DSF]] **διδασκω** *didaskō* nauczam [[G1321]] WTV-PAI-1S
###### **1Kor 4,18**
 **ως** *hōs* Jak – Ponieważ [[G5613]] [[ADV]] **μη** *mē* nie [[G3361]] [[PRT-N]] **ερχομενου** *erchomenou* przychodząc [[G2064]] WTV-PNP-GSM **δε** *de* zaś [[G1161]] [[CONJ]] **μου** *mou* ja [[G3450]] WTP-1GS **προς** *pros* do [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **εφυσιωθησαν** *efysiōthēsan* popadli w zarozumiałość – zostali nadęci [[G5448]] WTV-API-3P **τινες** *tines* niektórzy [[G5100]] WTX-NPM
###### **1Kor 4,19**
 **ελευσομαι** *eleusomai* Przyjdę [[G2064]] WTV-FDI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **ταχεως** *tacheōs* szybko [[G5030]] [[ADV]] **προς** *pros* do [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **εαν** *ean* jeśli [[G1437]] WTCOND **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **θεληση** *thelēsē* chciałby [[G2309]] WTV-AAS-3S **και** *kai* i [[G2532]] [[CONJ]] **γνωσομαι** *gnōsomai* poznam [[G1097]] WTV-FDI-1S **ου** *ou* nie [[G3756]] [[PRT-N]] **τον** *ton* [[G3588]] [[T-ASM]] **λογον** *logon* słowo [[G3056]] [[N-ASM]] **των** *tōn* (tych) [[G3588]] WTT-GPM **πεφυσιωμενων** *pefysiōmenōn* którzy są zarozumiali – którzy są nadęci [[G5448]] WTV-RPP-GPM **αλλα** *alla* ale [[G235]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **δυναμιν** *dynamin* moc [[G1411]] WTN-ASF
###### **1Kor 4,20**
 **ου** *ou* nie [[G3756]] [[PRT-N]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **λογω** *logō* słowie [[G3056]] WTN-DSM **η** *hē* [[G3588]] [[T-NSF]] **βασιλεια** *basileia* Królestwo [[G932]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **αλλ** *all* ale [[G235]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **δυναμει** *dynamei* mocy [[G1411]] [[N-DSF]]
###### **1Kor 4,21**
 **τι** *ti* Co [[G5101]] WTI-ASN **θελετε** *thelete* chcecie [[G2309]] WTV-PAI-2P **εν** *en* w [[G1722]] [[PREP]] **ραβδω** *rabdō* lasce – rózdze [[G4464]] [[N-DSF]] **ελθω** *elthō* przyszedłbym [[G2064]] WTV-2AAS-1S **προς** *pros* do [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **η** *ē* czy [[G2228]] WTPRT **εν** *en* w [[G1722]] [[PREP]] **αγαπη** *agapē* miłości [[G26]] [[N-DSF]] **πνευματι** *pneumati* duchu [[G4151]] WTN-DSN **τε** *te* i także [[G5037]] WTPRT **πραοτητος** *praotētos* łagodności – uprzejmości [[G4236]] [[N-GSF]]
