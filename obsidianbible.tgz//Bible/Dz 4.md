# Dz 4 BT5
###### **Dz 4,1**
 Kiedy przemawiali do ludu, podeszli do nich kapłani i dowódca straży świątynnej oraz saduceusze
###### **Dz 4,2**
 oburzeni, że nauczają lud i głoszą zmartwychwstanie umarłych w Jezusie.
###### **Dz 4,3**
 Zatrzymali ich i oddali pod straż aż do następnego dnia, bo już był wieczór.
###### **Dz 4,4**
 A wielu z tych, którzy słyszeli naukę, uwierzyło. Liczba mężczyzn sięgała pięciu tysięcy.
###### **Dz 4,5**
 Następnego dnia zebrali się ich przełożeni i starsi, i uczeni w Jeruzalem:
###### **Dz 4,6**
 arcykapłan Annasz, Kajfasz, Jan, Aleksander i ilu ich było z rodu arcykapłańskiego.
###### **Dz 4,7**
 Postawiwszy ich pośrodku, pytali: «***Czyją mocą albo w czyim imieniu uczyniliście to?***»
###### **Dz 4,8**
 Wtedy Piotr napełniony Duchem Świętym powiedział do nich: «***Przełożeni ludu i starsi!***
###### **Dz 4,9**
 ***Jeżeli przesłuchujecie nas dzisiaj w sprawie dobrodziejstwa, dzięki któremu chory człowiek odzyskał zdrowie,***
###### **Dz 4,10**
 ***to niech będzie wiadomo wam wszystkim i całemu ludowi Izraela, że w imię Jezusa Chrystusa Nazarejczyka – którego wy ukrzyżowaliście, a którego Bóg wskrzesił z martwych – że dzięki Niemu ten człowiek stanął przed wami zdrowy.***
###### **Dz 4,11**
 ***On jest kamieniem odrzuconym przez was budujących, tym, który stał się głowicą węgła.***
###### **Dz 4,12**
 ***I nie ma w żadnym innym zbawienia, gdyż nie dano ludziom pod niebem żadnego innego imienia, przez które moglibyśmy być zbawieni***».
###### **Dz 4,13**
 Widząc odwagę Piotra i Jana, a dowiedziawszy się, że są oni ludźmi nieuczonymi i prostymi, dziwili się. Rozpoznawali w nich też towarzyszy Jezusa.
###### **Dz 4,14**
 A widząc nadto, że stoi z nimi uzdrowiony człowiek, nie znajdowali odpowiedzi.
###### **Dz 4,15**
 Kazali więc im wyjść z sali Sanhedrynu i naradzali się między sobą:
###### **Dz 4,16**
 «***Co mamy zrobić z tymi ludźmi? Bo dokonali jawnego znaku, oczywistego dla wszystkich mieszkańców Jeruzalem. Przecież temu nie możemy zaprzeczyć.***
###### **Dz 4,17**
 ***Aby jednak nie szerzyło się to wśród ludu, surowo zabrońmy im przemawiać do kogokolwiek w to imię!***»
###### **Dz 4,18**
 Przywołali ich potem i zakazali im w ogóle przemawiać i nauczać w imię Jezusa.
###### **Dz 4,19**
 Lecz Piotr i Jan odpowiedzieli: «***Rozsądźcie, czy słuszne jest w oczach Bożych bardziej słuchać was niż Boga?***
###### **Dz 4,20**
 ***Bo my nie możemy nie mówić tego, cośmy widzieli i słyszeli***».
###### **Dz 4,21**
 Oni zaś ponowili groźby, a nie znajdując żadnej podstawy do wymierzenia im kary, wypuścili ich ze względu na lud, bo wszyscy wielbili Boga z powodu tego, co się stało.
###### **Dz 4,22**
 A człowiek, który doznał tego cudownego uzdrowienia, miał ponad czterdzieści lat.
###### **Dz 4,23**
 Uwolnieni przybyli do swoich i opowiedzieli, co do nich mówili arcykapłani i starsi.
###### **Dz 4,24**
 A ci, wysłuchawszy tego, wznieśli jednomyślnie głos do Boga i mówili: «***Wszechwładny Stwórco nieba i ziemi, i morza, i wszystkiego, co w nich istnieje,***
###### **Dz 4,25**
 ***Ty przez Ducha Świętego powiedziałeś ustami sługi Twego, Dawida: Dlaczego burzą się narody i ludy knują daremne spiski?***
###### **Dz 4,26**
 ***Powstali królowie ziemii książęta zeszli się razem przeciw Panu i przeciw Jego Pomazańcowi.***
###### **Dz 4,27**
 ***Zeszli się bowiem rzeczywiście w tym mieście przeciw świętemu Słudze Twemu, Jezusowi, którego namaściłeś, Herod i Poncjusz Piłat z poganami i pokoleniami Izraela,***
###### **Dz 4,28**
 ***aby uczynić to, co ręka Twoja i myśl zamierzyły.***
###### **Dz 4,29**
 ***A teraz spójrz, Panie, na ich groźby i daj sługom Twoim głosić słowo Twoje z całą odwagą,***
###### **Dz 4,30**
 ***gdy Ty wyciągać będziesz swą rękę, aby uzdrawiać i dokonywać znaków i cudów przez imię świętego Sługi Twego, Jezusa***».
###### **Dz 4,31**
 Po tej ich modlitwie zadrżało miejsce, na którym byli zebrani; a wszyscy zostali napełnieni Duchem Świętym i głosili odważnie słowo Boże.
###### **Dz 4,32**
 Jeden duch i jedno serce ożywiały wszystkich, którzy uwierzyli. Żaden nie nazywał swoim tego, co posiadał, ale wszystko mieli wspólne.
###### **Dz 4,33**
 Apostołowie z wielką mocą świadczyli o zmartwychwstaniu Pana Jezusa, a wielka łaska spoczywała na wszystkich.
###### **Dz 4,34**
 Nikt z nich nie cierpiał niedostatku, bo właściciele pól albo domów sprzedawali je
###### **Dz 4,35**
 i przynosili pieniądze [uzyskane] ze sprzedaży, i składali je u stóp Apostołów. Każdemu też rozdzielano według potrzeby.
###### **Dz 4,36**
 A Józef, nazwany przez Apostołów Barnaba, to znaczy "Syn Pocieszenia", lewita rodem z Cypru,
###### **Dz 4,37**
 sprzedał ziemię, którą posiadał, a pieniądze przyniósł i złożył u stóp Apostołów.
# Dz 4 PAU
###### **Dz 4,1**
 Kiedy jeszcze przemawiali do ludu, podeszli do nich kapłani z dowódcą straży świątynnej oraz saduceusze. Byli oburzeni, że nauczają ludzi i głoszą zmartwychwstanie umarłych w Jezusie.
###### **Dz 4,2**
 
###### **Dz 4,3**
 Zatrzymali ich i zamknęli na noc w więzieniu. Był już bowiem wieczór.
###### **Dz 4,4**
 Tymczasem wielu, którzy słuchali nauki, uwierzyło. A było ich około pięciu tysięcy mężczyzn.
###### **Dz 4,5**
 Nazajutrz zebrali się w Jeruzalem ich zwierzchnicy i starsi oraz nauczyciele Pisma.
###### **Dz 4,6**
 Przyszli tam wyżsi kapłani: Annasz, Kajfasz, Jan, Aleksander i inni z rodu najwyższych kapłanów.
###### **Dz 4,7**
 Postawili ich w środku i zapytali: „Jaką mocą i w czyim imieniu to uczyniliście?”.
###### **Dz 4,8**
 A Piotr, napełniony Duchem Świętym, odpowiedział: „Zwierzchnicy ludu oraz starsi!
###### **Dz 4,9**
 Jeżeli przesłuchujecie nas dzisiaj z powodu dobrodziejstwa, jakiego doznał chory człowiek, gdy został uzdrowiony,
###### **Dz 4,10**
 to wiedzcie, wy i wszyscy Izraelici, że stało się to w imię Jezusa Chrystusa, Nazarejczyka, którego ukrzyżowaliście. Bóg wskrzesił Go z martwych. To dzięki Niemu ten człowiek stoi przed wami zdrowy.
###### **Dz 4,11**
 On jest kamieniem odrzuconym przez was, budowniczych. Ale właśnie On stał się kamieniem węgielnym.
###### **Dz 4,12**
 Tylko dzięki Niemu można być zbawionym. Bo nie dano ludziom żadnego innego imienia pod niebem, w którym możemy być zbawieni”.
###### **Dz 4,13**
 Stanowczość Piotra i Jana zdumiała pytających. Wiedzieli przecież, że są ludźmi prostymi i niewykształconymi. Rozpoznali w nich też uczniów Jezusa.
###### **Dz 4,14**
 Patrzyli również na stojącego z nimi człowieka, który został uzdrowiony, i nie wiedzieli, co odpowiedzieć.
###### **Dz 4,15**
 Kazali im wyjść z sali posiedzeń i naradzali się.
###### **Dz 4,16**
 Mówili: „Co zrobić z tymi ludźmi? Wszyscy mieszkańcy Jeruzalem wiedzą o cudzie, jakiego dokonali. Nie możemy temu zaprzeczyć.
###### **Dz 4,17**
 Żeby jednak ta sprawa nie nabierała większego rozgłosu, zabrońmy im surowo przemawiać do kogokolwiek w to imię”.
###### **Dz 4,18**
 Wezwali ich więc i stanowczo im zabronili przemawiać i nauczać w imię Jezusa.
###### **Dz 4,19**
 A Piotr i Jan odpowiedzieli: „Rozsądźcie sami, co jest słuszne przed Bogiem: was słuchać czy Boga?
###### **Dz 4,20**
 Bo nie możemy milczeć o tym, cośmy widzieli i słyszeli”.
###### **Dz 4,21**
 A oni, nie znajdując nic, co zasługiwałoby na karę, ponownie im zagrozili i wypuścili ich ze względu na lud. Wszyscy zaś wielbili Boga z powodu tego, co się stało.
###### **Dz 4,22**
 A człowiek, który został cudownie uzdrowiony, miał ponad czterdzieści lat.
###### **Dz 4,23**
 Uwolnieni poszli do swoich i opowiedzieli o tym, co usłyszeli od wyższych kapłanów i starszych.
###### **Dz 4,24**
 Po wysłuchaniu ich, jednogłośnie modlili się do Boga: „Panie! Stwórco nieba, ziemi, morza i wszystkiego, co w nich istnieje.
###### **Dz 4,25**
 Ty przez Ducha Świętego powiedziałeś ustami Twego sługi a naszego ojca Dawida: Dlaczego wzburzyli się poganie, a ludy sprzysięgły się bez przyczyny?
###### **Dz 4,26**
 Sprzymierzyli się królowie ziemscy, a władcy zmówili się razem przeciwko Panu i przeciwko Jego Pomazańcowi.
###### **Dz 4,27**
 Rzeczywiście bowiem Herod, Poncjusz Piłat, poganie i lud izraelski wystąpili razem w tym mieście przeciwko Twemu świętemu Słudze, Jezusowi, którego namaściłeś.
###### **Dz 4,28**
 Tak dokonało się to, co od dawna postanowiła Twoja moc i wola.
###### **Dz 4,29**
 A teraz popatrz, Panie, jak nam grożą! Pozwól nam, Twym sługom, odważnie głosić Twoje słowo.
###### **Dz 4,30**
 Wyciągnij swoją rękę, aby w imię Twojego świętego Sługi, Jezusa, dokonywały się uzdrowienia, znaki i cuda”.
###### **Dz 4,31**
 Po tej modlitwie zadrżało miejsce, na którym przebywali. Napełnił ich Duch Święty, a oni odważnie głosili słowo Boże.
###### **Dz 4,32**
 Wszyscy wierzący mieli jedno serce i jedną duszę. Nikt z nich nie uważał za swoje tego, co posiadał, ale wszystko było wspólne.
###### **Dz 4,33**
 Apostołowie z wielką mocą świadczyli o Zmartwychwstaniu Pana Jezusa i wszyscy byli obdarzeni bogactwem łaski.
###### **Dz 4,34**
 Nikt z nich nie cierpiał niedostatku, gdyż właściciele ziemi i domów sprzedawali je, a uzyskane pieniądze przynosili
###### **Dz 4,35**
 i składali przed apostołami. I rozdzielano je każdemu według potrzeb.
###### **Dz 4,36**
 Także Józef, lewita pochodzący z Cypru, zwany przez apostołów Barnabą, to jest człowiekiem pocieszenia,
###### **Dz 4,37**
 sprzedał swoją posiadłość. Otrzymane pieniądze przyniósł i położył przed apostołami.
# Dz 4 BP
###### **Dz 4,1**
 Kiedy przemawiali do ludu, zbliżyli się do nich kapłani, dowódca straży świątynnej i saduceusze
###### **Dz 4,2**
 oburzeni, że nauczają lud, głosząc zmartwychwstanie umarłych w Jezusie.
###### **Dz 4,3**
 Schwycili ich i wtrącili do więzienia, zatrzymując do następnego dnia, bo był już wieczór.
###### **Dz 4,4**
 Wielu z tych, którzy słuchali nauki, uwierzyło, a liczba mężczyzn sięgała pięciu tysięcy.
###### **Dz 4,5**
 Następnego dnia zebrali się w Jerozolimie przełożeni, kapłani, nauczyciele Pisma
###### **Dz 4,6**
 (arcykapłan Annasz, Kajfasz, Jan, Aleksander i wszyscy z rodu arcykapłańskiego),
###### **Dz 4,7**
 którzy wezwali uwięzionych do siebie i pytali: "Jaką mocą lub w czyim imieniu to uczyniliście?"
###### **Dz 4,8**
 Wtedy Piotr pełen Ducha Świętego powiedział do nich: "Przełożeni ludu i kapłani!
###### **Dz 4,9**
 Skoro oskarżacie nas o to, że uzdrowiliśmy chorego człowieka,
###### **Dz 4,10**
 to wiedzcie zarówno wy, jak i cały lud izraelski, że on stoi przed nami zdrowy dzięki imieniu Jezusa Chrystusa, którego wyście ukrzyżowali, a Bóg wskrzesił z martwych.
###### **Dz 4,11**
 To On właśnie "stał się kamieniem węgielnym odrzuconym przez budowniczych".
###### **Dz 4,12**
 Nie ma bowiem poza Nim zbawienia, gdyż na świecie nie ma innego imienia danego ludziom, dzięki któremu moglibyśmy być zbawieni".
###### **Dz 4,13**
 Widząc odwagę Piotra i Jana, ludzi prostych i niewykształconych, podziwiali ich i rozpoznali w nich tych, którzy przybywali z Jezusem.
###### **Dz 4,14**
 A patrząc na uzdrowionego człowieka stojącego z nimi, nie wiedzieli, co odpowiedzieć.
###### **Dz 4,15**
 Nakazawszy im więc opuścić sanhedryn, mówili między sobą:
###### **Dz 4,16**
 "Co zrobić z tymi ludźmi? Nie możemy przecież zaprzeczyć, że dali oczywisty znak, o którym wiedzą wszyscy mieszkańcy Jerozolimy.
###### **Dz 4,17**
 By jednak ta sprawa nie nabierała większego rozgłosu wśród ludu, zabrońmy im nauczać kogokolwiek w to imię".
###### **Dz 4,18**
 Wezwali ich i zakazali w ogóle przemawiać i nauczać w imię Jezusa.
###### **Dz 4,19**
 Na to Piotr i Jan tak im odpowiedzieli: "Rozsądźcie, co jest słuszniejsze wobec Boga: was słuchać czy Boga?
###### **Dz 4,20**
 Nie możemy nie mówić tego, cośmy widzieli i słyszeli".
###### **Dz 4,21**
 Nie znajdując powodu do ukarania grozili dalej, ale wypuścili ich ze względu na lud, ponieważ wszyscy z powodu tego wydarzenia wielbili Boga;
###### **Dz 4,22**
 a człowiek, który został cudownie uzdrowiony, miał lat ponad czterdzieści.
###### **Dz 4,23**
 Po wypuszczeniu przybyli do swoich i opowiedzieli, co im mówili arcykapłani i starsi.
###### **Dz 4,24**
 Gdy tego wysłuchali, modlili się wspólnie słowami: "Panie, "Stwórco nieba i ziemi, i morza, i wszystkiego, co się w nich znajduje",
###### **Dz 4,25**
 który powiedziałeś przez Ojca naszego, pod wpływem Ducha Świętego, ustami sługi Twojego Dawida: "Dlaczego zbuntowały się narody i ludy knuły rzeczy próżne.
###### **Dz 4,26**
 Powstali królowie ziemi i władcy zmówili się wspólnie przeciwko Panu i przeciwko Jego Pomazańcowi".
###### **Dz 4,27**
 Rzeczywiście, przeciwko świętemu Słudze Twemu, Jezusowi, którego namaściłeś, zmówili się w tym mieście Herod i Poncjusz Piłat z narodami pogańskimi i pokoleniami Izraela,
###### **Dz 4,28**
 aby dokonało się to, co Twoja wola zamierzyła uczynić.
###### **Dz 4,29**
 A teraz, Panie wejrzyj na ich groźby i daj Twoim sługom, by z pełną odwagą głosili Twoje słowo,
###### **Dz 4,30**
 gdyż ręka Twoja dokona uzdrowienia, a zdumiewające znaki dziać się będą w imię świętego Sługi Twojego, Jezusa".
###### **Dz 4,31**
 A gdy się modlili, zadrżała ziemia w miejscu, gdzie się zebrali, i napełnieni zostali wszyscy Duchem Świętym, głosząc z odwagą słowo Boże.
###### **Dz 4,32**
 Wszyscy wierzący stanowili jedną duszę i jedno serce, i nikt nie mówił, że cokolwiek jest jego własnością, wszystko bowiem mieli wspólne.
###### **Dz 4,33**
 Apostołowie z wielką mocą świadczyli o zmartwychwstaniu Pana Jezusa, życzliwość zaś ogromna towarzyszyła im wszystkim.
###### **Dz 4,34**
 Nie było też wśród nich cierpiących niedostatku, gdyż właściciele sprzedawali swoje pola i domy, a pieniądze przynosili
###### **Dz 4,35**
 i kładli u stóp apostołów; rozdzielano zaś każdemu według jego potrzeb.
###### **Dz 4,36**
 Również Józef zwany przez apostołów Barnabą, to znaczy Synem Pocieszenia, Lewita, rodem z Cypru,
###### **Dz 4,37**
 sprzedał swoją ziemię, a pieniądze przyniósł i złożył u stóp apostołów.
# Dz 4 BR
###### **Dz 4,1**
 Kiedy jeszcze przemawiali do ludu, nadeszli kapłani z dowódcą straży świątynnej i saduceusze.
###### **Dz 4,2**
 Byli oburzeni, że ci dwaj nauczają lud, głosząc przyszłe zmartwychwstanie wszystkich w Jezusie.
###### **Dz 4,3**
 Pojmali ich i wtrącili do więzienia, każąc zatrzymać aż do dnia następnego, bo było już późno.
###### **Dz 4,4**
 Tymczasem wielu z tych, którzy usłyszeli ich naukę, uwierzyło. I tak liczba nowo nawróconych mężczyzn sięgała pięciu tysięcy.
###### **Dz 4,5**
 Nazajutrz zebrali się razem w Jerozolimie przełożeni żydowscy, starsi i uczeni [w Piśmie].
###### **Dz 4,6**
 Przybyli także arcykapłani Annasz i Kajfasz, Jan, Aleksander i wszyscy pozostali z rodu arcykapłańskiego.
###### **Dz 4,7**
 Kazano sprowadzić apostołów, postawiono ich pośrodku i zapytano: Jakąż to mocą albo w czyim imieniu dokonaliście tego?
###### **Dz 4,8**
 Wtedy Piotr, napełniony Duchem Świętym, powiedział do nich: Przełożeni i starsi ludu!
###### **Dz 4,9**
 Skoro już chcecie dowiedzieć się czegoś na temat dobrodziejstwa, dzięki któremu ten człowiek odzyskał zdrowie,
###### **Dz 4,10**
 to zechciejcie przyjąć do wiadomości wy wszyscy i cały naród izraelski, że to w imię Jezusa Chrystusa Nazareńskiego, przez was przybitego do krzyża, lecz zmartwychwskrzeszonego przez Boga - przez Niego właśnie człowiek ten stoi przed wami zdrowy.
###### **Dz 4,11**
 To On jest owym kamieniem, który wyście jako budowniczowie odrzucili, a On stał się kamieniem podtrzymującym cały fundament.
###### **Dz 4,12**
 I nikt nie może dostąpić zbawienia inaczej niż tylko w Nim, bo nikomu na świecie nie dał Bóg imienia, w którym moglibyśmy osiągnąć zbawienie.
###### **Dz 4,13**
 Odwaga Piotra i Jana zadziwiła pytających tym bardziej, że jak się przekonali, byli to ludzie niewykształceni i prości. Z łatwością rozpoznano w nich również dawnych towarzyszy Jezusa.
###### **Dz 4,14**
 Lecz widziano także stojącego obok nich człowieka uzdrowionego. Nie wiedzieli więc, co o tym wszystkim sądzić.
###### **Dz 4,15**
 Kazali im tedy opuścić salę zebrań i poczęli się naradzać.
###### **Dz 4,16**
 Pytali przy tym jedni drugich: Co tu zrobić z tymi ludźmi? Nie ulega wątpliwości, że jawnie dokonali cudu, znanego teraz już wszystkim mieszkańcom Jerozolimy. Nikt przecież nie może temu zaprzeczyć.
###### **Dz 4,17**
 Żeby jednak wieść o tym nie rozchodziła się jeszcze bardziej wśród ludzi, zabronimy im stanowczo wygłaszać jakichkolwiek dalszych przemówień z powoływaniem się na to imię.
###### **Dz 4,18**
 Wezwano ich przeto i zakazano im przemawiać i nauczać w imię Jezusa.
###### **Dz 4,19**
 Lecz Jan i Piotr odpowiedzieli na to: Zastanówcie się sami, tak wobec Boga: Czy należy słuchać was, czy raczej Boga?
###### **Dz 4,20**
 Nie możemy bowiem przemilczeć tego, cośmy widzieli i słyszeli.
###### **Dz 4,21**
 Lecz oni ponowili swoje groźby. Ponieważ jednak nie znaleźli żadnej podstawy [prawnej] do wymierzenia im kary, wypuścili ich, obawiając się ludu, który wielbił Boga z powodu tego, co się stało.
###### **Dz 4,22**
 Człowiek zaś cudownie uleczony miał trochę ponad czterdzieści lat.
###### **Dz 4,23**
 W ten sposób wypuszczeni na wolność [apostołowie] przybyli do swoich i opowiedzieli o tym, co usłyszeli od arcykapłanów i starszych.
###### **Dz 4,24**
 A ci, wysłuchawszy wszystkiego, jednogłośnie tak oto poczęli modlić się do Boga: Wszechpotężny Stwórco nieba i ziemi, i morza, i wszystkiego, co w nich istnieje!
###### **Dz 4,25**
 Przez Ducha Świętego powiedziałeś ustami sługi Twego Dawida: Dlaczegóż buntują się narody, dlaczego ludy spiskują na próżno?
###### **Dz 4,26**
 Podnieśli głowy królowie ziemscy i książęta zeszli się razem przeciw Panu i przeciw Jego Pomazańcowi.
###### **Dz 4,27**
 Rzeczywiście bowiem Herod i Poncjusz Piłat, i poganie, i ludzie pokoleń Izraela zeszli się razem w tym mieście przeciw Świętemu Słudze Twemu, Jezusowi, którego namaściłeś,
###### **Dz 4,28**
 aby dopełnić tego, co Twoja ręka i wola zamierzyły od dawna.
###### **Dz 4,29**
 A teraz posłuchaj, Panie, jak grożą! Spraw, by Twoi słudzy mogli z całą odwagą głosić Twoje słowo!
###### **Dz 4,30**
 Wyciągnij swoją prawicę, aby uzdrawiać i dokonywać znaków i cudów w imię Świętego Sługi Twego, Jezusa.
###### **Dz 4,31**
 Kiedy już skończyli się modlić, zadrżało miejsce, na którym byli wszyscy zebrani: zostali napełnieni Duchem Świętym i z całą odwagą poczęli głosić słowo Boże.
###### **Dz 4,32**
 A wszystkich wierzących ożywiał jeden duch i te same uczucia. Nikt nie uważał za swoje tego, co posiadał; wszystko było wspólne.
###### **Dz 4,33**
 Apostołowie zaś z wielką mocą świadczyli o zmartwychwstaniu Pana Jezusa, a wszyscy cieszyli się licznymi łaskami.
###### **Dz 4,34**
 Nikt też nie cierpiał żadnego niedostatku, bo ci, którzy posiadali własne pola albo domy, sprzedawali wszystko,
###### **Dz 4,35**
 a pieniądze przynosili i składali u stóp apostołów. Rozdzielano je potem każdemu według potrzeby.
###### **Dz 4,36**
 Tak właśnie uczynił [między innymi] Józef, lewita z Cypru, któremu apostołowie nadali przydomek Barnabas, tj. Syn Pocieszenia.
###### **Dz 4,37**
 Sprzedał on własną ziemię, a pieniądze przyniósł i złożył u stóp apostołów.
# Dz 4 WUJ
###### **Dz 4,1**
 A gdy oni mówili do ludu, nadeszli kapłani i urząd kościelny i Saduceuszowie:
###### **Dz 4,2**
 Frasując się, iż uczyli lud, a opowiadali w Jezusie powstanie od umarłych:
###### **Dz 4,3**
 I pojmali je, i wsadzili je do więzienia do jutra: bo już był wieczór.
###### **Dz 4,4**
 A wiele tych, którzy byli słowo uslyszeli, uwierzyło: i była liczba mężów pięć tysięcy.
###### **Dz 4,5**
 I stało się nazajutrz, że się zebrali przełożeni ich, i starszy i Doktorowie w Jeruzalem.
###### **Dz 4,6**
 I Annasz nawyższy kapłan, i Kaiphasz, i Jan, i Aleksander, i ile ich jedno było z rodu kapłańskiego.
###### **Dz 4,7**
 A stawiwszy je w pośrodku, pytali: którą mocą abo którem imieniem wyście to uczynili?
###### **Dz 4,8**
 Tedy Piotr napełniony Ducha świętego, rzekł do nich: Książęta ludu i starszy słuchajcie:
###### **Dz 4,9**
 Jeśli my dziś sądzeni jesteśmy o dobrodziejstwo przeciw człowiekowi niemocnemu, przez coby ten był uzdrowiony.
###### **Dz 4,10**
 Niechże wam wszem jawno będzie, i wszystkiemu ludowi Izraelskiemu: że przez imię Pana naszego Jezusa Chrystusa Nazareńskiego, któregoście wy ukrzyżowali, którego był wzbudził od umarłych, przez tegoć ten stoi zdrowy przed wami.
###### **Dz 4,11**
 Ten jest kamień, który jest odrzucony od was budujących, który się stał na głowę węgła.
###### **Dz 4,12**
 I niemasz w żadnym innym zbawienia. Abowiem nie jest pod niebem inne imię dane ludziom, w którembyśmy mieli być zbawieni.
###### **Dz 4,13**
 A widząc bezpieczność Piotrowę i Janowę, i porozumiawszy, iż byli ludzie bez nauki i prostacy, dziwowali się, i poznali je, iż byli z Jezusem:
###### **Dz 4,14**
 Widząc też człowieka z niemi stojącego, który był uzdrowion nie mogli nic przeciwko mówić.
###### **Dz 4,15**
 A kazali im precz ustąpić z Rady, i namawiali się wespół,
###### **Dz 4,16**
 Mówiąc: Co uczynimy tym ludziom? gdyż jednak znak uczyniony jest przez nie, wiadomy wszystkim mieszkającym w Jeruzalem, rzecz jasna jest, a zaprzeć nie możemy.
###### **Dz 4,17**
 Ale izby się więcej nie rozsławiało między ludzie zagroźmy im, aby więcej w imię to żadnemu człowiekowi nie mówili.
###### **Dz 4,18**
 A wezwawszy ich, zakazali, aby koniecznie nie mówili, ani uczyli w imię Jezusowe.
###### **Dz 4,19**
 Lecz Piotr i Jan odpowiedziawszy, rzekli do nich: Jeśliż jest sprawiedliwa przed oczyma Boskiemi, was raczej niźli Boga słuchać, rozsądźcie.
###### **Dz 4,20**
 Bo nie możemy cośmy widzieli i słyszeli nie mówić.
###### **Dz 4,21**
 A oni zagroziwszy, wypuścili je, nie najdując jakoby je skarać, dla ludu: ponieważ wszyscy wysławiali to co się było stało, w tem co się przydało.
###### **Dz 4,22**
 Bo było więcej niż czterdzieści lat człowiekowi, na którym się stało to cudo ozdrowienia.
###### **Dz 4,23**
 Lecz gdy ich wypuszczono, przyszli do swych: i oznajmili im cokolwiek do nich nawyższy kapłani i starszy mówili.
###### **Dz 4,24**
 Którzy usłyszawszy, zgodnie podnieśli głos swój ku Bogu, i mówili: Panie, tyś jest, któryś stworzył niebo i ziemię, morze i wszystko co w nich jest:
###### **Dz 4,25**
 Któryś Duchem świętym przez usta ojca naszego Dawida sługi twego powiedział: Czemu się narody wzburzyły, a ludzie próżne rzeczy rozmyślali?
###### **Dz 4,26**
 Stanęli królowie ziemscy, i książęta zeszli się w gromadę przeciw Panu i przeciw Chrystusowi jego?
###### **Dz 4,27**
 Abowiem się zgromadzili prawdziwie w mieście tem przeciw świętemu Synowi twemu Jezusowi, któregoś pomazał, Herod, i Ponthis Piłat, z pogany i z ludźmi Izraelskiemi.
###### **Dz 4,28**
 Aby uczynili co ręka twa i rada twa postanowiły, aby się stało.
###### **Dz 4,29**
 A teraz Panie wejrzy na pogróżki ich: a daj sługom twym ze wszystką bezpiecznością opowiadać słowo twoje:
###### **Dz 4,30**
 W tem, abyś ściągał rękę twoję na uzdrawiania, a żeby się znaki i cuda działy przez imię świętego Syna twego Jezusa.
###### **Dz 4,31**
 A gdy się modlili, zatrząsnęło się miejsce, na ktorem byli zgromadzeni: i napełnieni są Ducha ś. i mówili śmiele słowo Boże.
###### **Dz 4,32**
 A mnóstwa wierzących było serce jedno i dusza jedna: ani żaden z nich to co miał swem nazywał: ale było im wszystko spółne.
###### **Dz 4,33**
 A wielką mocą Apostołowie dawali świadectwo zmartwychwstania Jezusa Chrystusa Pana naszego: i była wielka łaska nad niemi wszystkiemi.
###### **Dz 4,34**
 Bo żadnego między niemi nie było niedostatecznego. Gdyż którzykolwiek mieli role abo domy, przedawszy przynosili zapłatę za ono co przedawali.
###### **Dz 4,35**
 I kładli przed nogi Apostolskie. I rozdawano każdemu ile komu było potrzeba.
###### **Dz 4,36**
 A Józef, który nazwany był Barnabaszem od Apostołów (co wyłożywszy jest, Syn pocieszenia) Lewit, rodem z Cypru,
###### **Dz 4,37**
 Mając rolą, przedał ją i przyniósł pieniądze, i położył u nóg Apostolskich.
# Dz 4 STERN
###### **Dz 4,1**
 Kefa i Jochanan mówili jeszcze do ludu, gdy natarli na nich kohanim, dowódca straży świątynnej i c'dukim,
###### **Dz 4,2**
 bardzo rozsierdzeni, że głoszą ludowi naukę o zmartwychwstaniu, a jako dowód podają Jeszuę.
###### **Dz 4,3**
 Straż świątynna pojmała ich, a że był już wieczór, zamknęli ich na noc w areszcie.
###### **Dz 4,4**
 Wielu jednak z tych, którzy usłyszeli orędzie, zaufało; liczba samych tylko mężczyzn dochodziła do pięciu tysięcy.
###### **Dz 4,5**
 Nazajutrz przełożeni ludu, starsi i nauczyciele Tory zebrali się w Jeruszalaim,
###### **Dz 4,6**
 wraz z 'Ananem, kohenem hagadolem, Kajafą, Jochananem, Aleksandrem i innymi ludźmi z rodziny kohena hagadola.
###### **Dz 4,7**
 Postawili wysłanników przed sobą i pytali: "Jaką mocą albo w czyim imieniu to zrobiliście?".
###### **Dz 4,8**
 Wtedy Kefa, pełen Ruach Ha-Kodesz, rzekł im: "Przełożeni i starsi ludu!
###### **Dz 4,9**
 Jeśli bada się nas dziś w sprawie dobrego uczynku wyświadczonego ułomnemu, jeśli chcecie wiedzieć, jak zostało mu wrócone zdrowie,
###### **Dz 4,10**
 to niech będzie wiadomo wam i całemu ludowi Israela, że to w imię Mesjasza, Jeszui z Naceret, któregoście stracili na palu jak zbrodniarza, lecz którego Bóg wskrzesił z martwych, człowiek ten stoi przed wami całkowicie uzdrowiony.
###### **Dz 4,11**
 Ten Jeszua jest kamieniem odrzuconym przez was, budowniczych, który stał się kamieniem węgielnym. W nikim innym nie ma zbawienia!
###### **Dz 4,12**
 Bo nie ma pod niebem żadnego innego imienia danego ludziom, przez które mamy być zbawieni!".
###### **Dz 4,13**
 Widząc, jak śmiało występują Kefa i Jochanan, mimo że to nieuczeni am-ha'arec, zdumieli się; rozpoznali ich też, że byli z Jeszuą.
###### **Dz 4,14**
 A ponieważ widzieli, że człowiek, który został uzdrowiony, stoi tuż koło nich, nie mogli powiedzieć nic, żeby podważyć uzdrowienie.
###### **Dz 4,15**
 Nakazali im więc oddalić się od Sanhedrinu i omawiali sprawę na osobności.
###### **Dz 4,16**
 "Co możemy począć z tymi ludźmi? - zapytywali się nawzajem. - Bo przecież każdy w Jeruszalaim widzi, jaki niezwykły cud nastąpił za ich sprawą, temu zaprzeczyć nie możemy.
###### **Dz 4,17**
 Ale żeby się to dalej wśród ludu nie szerzyło, dajmy im ostrzeżenie, żeby więcej w tym imieniu nie przemawiali".
###### **Dz 4,18**
 Wezwali ich z powrotem i nakazali, aby pod żadnym pozorem nie przemawiali i nie nauczali w imieniu Jeszui.
###### **Dz 4,19**
 Ale Kefa i Jochanan odrzekli: "Musicie osądzić, czy słuszne jest w oczach Boga słuchać raczej was niż Boga.
###### **Dz 4,20**
 Co do nas zaś, nie możemy nie mówić o tym, co naprawdę widzieliśmy i słyszeliśmy".
###### **Dz 4,21**
 Grozili im jeszcze, ale w końcu ich wypuścili - nie mogli ich ukarać ze względu na lud, bo wszyscy chwalili Boga za to, co się stało,
###### **Dz 4,22**
 bowiem ów cudownie uzdrowiony człowiek miał ponad czterdzieści lat.
###### **Dz 4,23**
 Po uwolnieniu wrócili do przyjaciół i zdali sprawę z tego, co im powiedzieli główni kohanim i starsi.
###### **Dz 4,24**
 Kiedy oni to usłyszeli, zgodnie wznieśli głosy do Boga. "Władco! -modlili się - Tyś uczynił niebo, ziemię, morze i wszystko, co w nich jest.
###### **Dz 4,25**
 - - -
###### **Dz 4,26**
 Przez Ruach Ha-Kodesz, ustami naszego ojca Dawida, sługi swego, powiedziałeś: "Czemu rozwścieczyły się narody, a ludy uknuły próżne plany? Królowie ziemi powstali, a władcy zebrali się razem przeciwko Adonai i przeciwko Jego Mesjaszowi".
###### **Dz 4,27**
 Tak stało się w tym mieście, bo Herod i Poncjusz Piłat, wraz z goim i ludami Israela, zebrali się wszyscy przeciw świętemu słudze Twemu Jeszui, któregoś uczynił Mesjaszem,
###### **Dz 4,28**
 aby dokonać tego, o czym moc Twoja i plan już z góry postanowiły, że nastąpi.
###### **Dz 4,29**
 Teraz więc, Panie, zwróć uwagę na ich groźby i uzdolnij swe sługi, aby śmiało głosili Twą naukę!
###### **Dz 4,30**
 Wyciągnij swą rękę, by uzdrawiać i czynić znaki i cuda przez imię świętego Twego sługi Jeszui!".
###### **Dz 4,31**
 Kiedy się jeszcze modlili, zatrzęsło się miejsce, gdzie byli zebrani. Wszyscy zostali napełnieni Ruach Ha-Kodesz i śmiało głosili Boże orędzie.
###### **Dz 4,32**
 Wszyscy ci liczni wierzący byli jednego serca i duszy, a nikt nie rościł sobie prawa do własnego majątku, lecz każdy dzielił się wszystkim, co miał.
###### **Dz 4,33**
 Wysłannicy z wielką mocą dalej zaświadczali o zmartwychwstaniu Pana Jeszui, a wszyscy oni byli w wielkim poważaniu.
###### **Dz 4,34**
 Nie było wśród nich nikogo biednego, bo ci, którzy posiadali ziemię czy domy, sprzedawali je, a dochód oddawali
###### **Dz 4,35**
 wysłannikom, aby każdemu udzielali wedle potrzeb.
###### **Dz 4,36**
 Na przykład Josef, którego wysłannicy zwali Bar-Nabbą (co oznacza "Napominający"), l'wi pochodzący z Cypru,
###### **Dz 4,37**
 sprzedał pole, które do niego należało, a pieniądze przyniósł wysłannikom.
# Dz 4 TRO
###### **Dz 4,1**
 **λαλουντων** *lalountōn* Gdy mówią [[G2980]] WTV-PAP-GPM **δε** *de* zaś [[G1161]] [[CONJ]] **αυτων** *autōn* oni [[G846]] WTP-GPM **προς** *pros* do [[G4314]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **λαον** *laon* ludu [[G2992]] [[N-ASM]] **επεστησαν** *epestēsan* stanęli obok [[G2186]] WTV-2AAI-3P **αυτοις** *autois* nich [[G846]] WTP-DPM **οι** *hoi* [[G3588]] WTT-NPM **ιερεις** *hiereis* kapłani [[G2409]] WTN-NPM **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **στρατηγος** *stratēgos* dowódca straży – komendant [[G4755]] [[N-NSM]] **του** *tou* [[G3588]] WTT-GSN **ιερου** *hierou* świątyni [[G2411]] [[N-GSN]] **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **σαδδουκαιοι** *saddoukaioi* saduceusze – [sprawiedliwy] [[G4523]] WTN-NPM
###### **Dz 4,2**
 **διαπονουμενοι** *diaponoumenoi* Będąc oburzonymi – Będąc rozdrażnionymi [[G1278]] WTV-PNP-NPM **δια** *dia* przez [[G1223]] [[PREP]] **το** *to* (to, co) [[G3588]] WTT-ASN **διδασκειν** *didaskein* nauczać [[G1321]] WTV-PAN **αυτους** *autous* oni [[G846]] [[P-APM]] **τον** *ton* [[G3588]] [[T-ASM]] **λαον** *laon* lud [[G2992]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **καταγγελλειν** *katangellein* zwiastować – głosić [[G2605]] WTV-PAN **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM **την** *tēn* [[G3588]] WTT-ASF **αναστασιν** *anastasin* powstanie – wzbudzenie [[G386]] WTN-ASF **την** *tēn* [[G3588]] WTT-ASF **εκ** *ek* z [[G1537]] [[PREP]] **νεκρων** *nekrōn* martwych [[G3498]] WTA-GPM
###### **Dz 4,3**
 **και** *kai* i [[G2532]] [[CONJ]] **επεβαλον** *epebalon* położyli – narzucili [[G1911]] WTV-2AAI-3P **αυτοις** *autois* im [[G846]] WTP-DPM **τας** *tas* [[G3588]] WTT-APF **χειρας** *cheiras* ręce [[G5495]] WTN-APF **και** *kai* i [[G2532]] [[CONJ]] **εθεντο** *ethento* umieścili [[G5087]] WTV-2AMI-3P **εις** *eis* do [[G1519]] [[PREP]] **τηρησιν** *tērēsin* strzeżenia [[G5084]] WTN-ASF **εις** *eis* do [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **αυριον** *aurion* jutra [[G839]] [[ADV]] **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εσπερα** *hespera* wieczór [[G2073]] [[N-NSF]] **ηδη** *ēdē* już [[G2235]] [[ADV]]
###### **Dz 4,4**
 **πολλοι** *polloi* Liczni – Wielu [[G4183]] WTA-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPM **ακουσαντων** *akousantōn* którzy usłyszeli [[G191]] WTV-AAP-GPM **τον** *ton* [[G3588]] [[T-ASM]] **λογον** *logon* słowo [[G3056]] [[N-ASM]] **επιστευσαν** *episteusan* uwierzyli [[G4100]] WTV-AAI-3P **και** *kai* i [[G2532]] [[CONJ]] **εγενηθη** *egenēthē* stała się [[G1096]] [[V-AOI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **αριθμος** *arithmos* liczba [[G706]] [[N-NSM]] **των** *tōn* (tych) [[G3588]] WTT-GPM **ανδρων** *andrōn* mężów [[G435]] WTN-GPM **ωσει** *hōsei* jakby [[G5616]] [[ADV]] **χιλιαδες** *chiliades* tysięcy [[G5505]] [[A-NPF]] **πεντε** *pente* pięć [[G4002]] WTA-NUI
###### **Dz 4,5**
 **εγενετο** *egeneto* Stało się [[G1096]] WTV-2ADI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **επι** *epi* na [[G1909]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **αυριον** *aurion* jutro [[G839]] [[ADV]] **συναχθηναι** *synachthēnai* zostać zebranymi – zostać zgromadzonymi [[G4863]] WTV-APN **αυτων** *autōn* ich [[G846]] WTP-GPM **τους** *tous* [[G3588]] WTT-APM **αρχοντας** *archontas* przywódcy – przełożeni [[G758]] [[N-APM]] **και** *kai* i [[G2532]] [[CONJ]] **πρεσβυτερους** *presbyterous* starsi [[G4245]] WTA-APM **και** *kai* i [[G2532]] [[CONJ]] **γραμματεις** *grammateis* znawcy Pisma – uczeni w Piśmie [[G1122]] [[N-APM]] **εις** *eis* w [[G1519]] [[PREP]] **ιερουσαλημ** *ierousalēm* Jeruzalem – [dziedzictwo pokoju] [[G2419]] [[N-PRI]]
###### **Dz 4,6**
 **και** *kai* i [[G2532]] [[CONJ]] **ανναν** *hannan* Annasza – [JH jest łaskawy] [[G452]] [[N-ASM]] **τον** *ton* [[G3588]] [[T-ASM]] **αρχιερεα** *archierea* arcykapłana [[G749]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **καιαφαν** *kaiafan* Kajfasza [[G2533]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **ιωαννην** *iōannēn* Jana – [JHWH jest łaskawy] [[G2491]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **αλεξανδρον** *aleksandron* Aleksandra – [obrońca mężów] [[G223]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **οσοι** *hosoi* ilu – jacy [[G3745]] WTK-NPM **ησαν** *ēsan* byli [[G2258]] WTV-IXI-3P **εκ** *ek* z [[G1537]] [[PREP]] **γενους** *genous* rodu [[G1085]] [[N-GSN]] **αρχιερατικου** *archieratikou* arcykapłańskiego [[G748]] [[A-GSN]]
###### **Dz 4,7**
 **και** *kai* i [[G2532]] [[CONJ]] **στησαντες** *stēsantes* postawiwszy [[G2476]] WTV-AAP-NPM **αυτους** *autous* ich [[G846]] [[P-APM]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **μεσω** *mesō* środku [[G3319]] WTA-DSN **επυνθανοντο** *epynthanonto* wypytywali się – dowiadywali się [[G4441]] WTV-INI-3P **εν** *en* w [[G1722]] [[PREP]] **ποια** *poia* jakiej [[G4169]] WTI-DSF **δυναμει** *dynamei* mocy [[G1411]] [[N-DSF]] **η** *ē* lub [[G2228]] WTPRT **εν** *en* w [[G1722]] [[PREP]] **ποιω** *poiō* jakim [[G4169]] WTI-DSN **ονοματι** *onomati* imieniu [[G3686]] WTN-DSN **εποιησατε** *epoiēsate* uczyniliście [[G4160]] WTV-AAI-2P **τουτο** *touto* to [[G5124]] WTD-ASN **υμεις** *hymeis* wy [[G5210]] WTP-2NP
###### **Dz 4,8**
 **τοτε** *tote* Wtedy [[G5119]] [[ADV]] **πετρος** *petros* Piotr – [kamyk] [[G4074]] [[N-NSM]] **πλησθεις** *plēstheis* zostawszy napełnionym [[G4130]] WTV-APP-NSM **πνευματος** *pneumatos* Duchem [[G4151]] [[N-GSN]] **αγιου** *hagiou* Świętym [[G40]] [[A-GSN]] **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **προς** *pros* do [[G4314]] [[PREP]] **αυτους** *autous* nich [[G846]] [[P-APM]] **αρχοντες** *archontes* przywódcy – przełożeni [[G758]] WTN-VPM **του** *tou* [[G3588]] WTT-GSM **λαου** *laou* ludu [[G2992]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **πρεσβυτεροι** *presbyteroi* starsi [[G4245]] WTA-VPM **του** *tou* [[G3588]] WTT-GSM **ισραηλ** *israēl* Izraela – [ten, który walczył z Bogiem] [[G2474]] [[N-PRI]]
###### **Dz 4,9**
 **ει** *ei* Jeśli [[G1487]] WTCOND **ημεις** *hēmeis* my [[G2249]] WTP-1NP **σημερον** *sēmeron* dzisiaj [[G4594]] [[ADV]] **ανακρινομεθα** *anakrinometha* jesteśmy sądzeni [[G350]] WTV-PPI-1P **επι** *epi* z powodu [[G1909]] [[PREP]] **ευεργεσια** *euergesia* dobrodziejstwa – dobrej pracy [[G2108]] [[N-DSF]] **ανθρωπου** *anthrōpou* (dla) człowieka [[G444]] [[N-GSM]] **ασθενους** *asthenous* słabego – bezsilnego [[G772]] WTA-GSM **εν** *en* w [[G1722]] [[PREP]] **τινι** *tini* czym [[G5101]] WTI-DSM **ουτος** *houtos* ten [[G3778]] WTD-NSM **σεσωσται** *sesōstai* jest uratowany – jest zbawiony [[G4982]] WTV-RPI-3S
###### **Dz 4,10**
 **γνωστον** *gnōston* znajome [[G1110]] WTA-NSN **εστω** *estō* niech jest [[G2077]] WTV-PXM-3S **πασιν** *pasin* wszystkim [[G3956]] WTA-DPM **υμιν** *hymin* wam [[G5213]] WTP-2DP **και** *kai* i [[G2532]] [[CONJ]] **παντι** *panti* całemu [[G3956]] WTA-DSM **τω** *tō* [[G3588]] WTT-DSM **λαω** *laō* ludowi [[G2992]] WTN-DSM **ισραηλ** *israēl* Izraela – [ten, który walczył z Bogiem] [[G2474]] [[N-PRI]] **οτι** *hoti* że [[G3754]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **ονοματι** *onomati* imieniu [[G3686]] WTN-DSN **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **του** *tou* [[G3588]] WTT-GSM **ναζωραιου** *nazōraiou* Nazarejczyka [[G3480]] [[N-GSM]] **ον** *hon* którego [[G3739]] WTR-ASM **υμεις** *hymeis* wy [[G5210]] WTP-2NP **εσταυρωσατε** *estaurōsate* ukrzyżowaliście [[G4717]] WTV-AAI-2P **ον** *hon* którego [[G3739]] WTR-ASM **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ηγειρεν** *ēgeiren* wzbudził – podniósł [[G1453]] [[V-AAI-3S]] **εκ** *ek* z [[G1537]] [[PREP]] **νεκρων** *nekrōn* martwych [[G3498]] WTA-GPM **εν** *en* w [[G1722]] [[PREP]] **τουτω** *toutō* Tym [[G5129]] WTD-DSN **ουτος** *houtos* ten [[G3778]] WTD-NSM **παρεστηκεν** *parestēken* stoi [[G3936]] WTV-RAI-3S **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **υμων** *hymōn* wami [[G5216]] WTP-2GP **υγιης** *hygiēs* zdrowy [[G5199]] [[A-NSM]]
###### **Dz 4,11**
 **ουτος** *houtos* Ten [[G3778]] WTD-NSM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ο** *ho* [[G3588]] [[T-NSM]] **λιθος** *lithos* kamień [[G3037]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **εξουθενηθεις** *eksouthenētheis* który został wzgardzony – który został wzięty za nic [[G1848]] WTV-APP-NSM **υφ** *hyf* przez [[G5259]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **των** *tōn* [[G3588]] WTT-GPM **οικοδομουντων** *oikodomountōn* budujących [[G3618]] WTV-PAP-GPM **ο** *ho* [[G3588]] [[T-NSM]] **γενομενος** *genomenos* który stał się [[G1096]] WTV-2ADP-NSM **εις** *eis* ku [[G1519]] [[PREP]] **κεφαλην** *kefalēn* głowie [[G2776]] WTN-ASF **γωνιας** *gōnias* narożnika – kąta [[G1137]] [[N-GSF]]
###### **Dz 4,12**
 **και** *kai* i [[G2532]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **εν** *en* w [[G1722]] [[PREP]] **αλλω** *allō* innym [[G243]] WTA-DSM **ουδενι** *oudeni* nikim [[G3762]] WTA-DSM **η** *hē* [[G3588]] [[T-NSF]] **σωτηρια** *sōtēria* zbawienie – wyzwolenie [[G4991]] [[N-NSF]] **ουτε** *oute* nie [[G3777]] [[CONJ]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ονομα** *onoma* imię [[G3686]] WTN-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ετερον** *heteron* inne [[G2087]] WTA-NSN **υπο** *hypo* pod [[G5259]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **ουρανον** *ouranon* niebem [[G3772]] [[N-ASM]] **το** *to* [[G3588]] WTT-NSN **δεδομενον** *dedomenon* które jest dane [[G1325]] WTV-RPP-NSN **εν** *en* w [[G1722]] [[PREP]] **ανθρωποις** *anthrōpois* ludziach [[G444]] WTN-DPM **εν** *en* w [[G1722]] [[PREP]] **ω** *hō* którym [[G3739]] WTR-DSN **δει** *dei* trzeba – jest konieczne [[G1163]] WTV-PQI-3S **σωθηναι** *sōthēnai* zostać zbawionym – zostać uratowanym [[G4982]] WTV-APN **ημας** *hēmas* nam [[G2248]] WTP-1AP
###### **Dz 4,13**
 **θεωρουντες** *theōrountes* Oglądając [[G2334]] WTV-PAP-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **του** *tou* [[G3588]] WTT-GSM **πετρου** *petrou* Piotra – [kamyk] [[G4074]] [[N-GSM]] **παρρησιαν** *parrēsian* śmiałość [[G3954]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **ιωαννου** *iōannou* Jana – [JHWH jest łaskawy] [[G2491]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **καταλαβομενοι** *katalabomenoi* chwyciwszy – przyłapawszy [[G2638]] WTV-2AMP-NPM **οτι** *hoti* że [[G3754]] [[CONJ]] **ανθρωποι** *anthrōpoi* ludzie [[G444]] WTN-NPM **αγραμματοι** *agrammatoi* niewykształceni – niepiśmienni [[G62]] WTA-NPM **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **και** *kai* i [[G2532]] [[CONJ]] **ιδιωται** *idiōtai* niezaznajomieni – prostacy [[G2399]] WTN-NPM **εθαυμαζον** *ethaumazon* dziwili się [[G2296]] WTV-IAI-3P **επεγινωσκον** *epeginōskon* poznawali – uznawali [[G1921]] WTV-IAI-3P **τε** *te* zarówno – także [[G5037]] WTPRT **αυτους** *autous* ich [[G846]] [[P-APM]] **οτι** *hoti* że [[G3754]] [[CONJ]] **συν** *syn* z [[G4862]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **ιησου** *iēsou* Jezusem – [JHWH jest zbawieniem] [[G2424]] WTN-DSM **ησαν** *ēsan* byli [[G2258]] WTV-IXI-3P
###### **Dz 4,14**
 **τον** *ton* [[G3588]] [[T-ASM]] **δε** *de* zaś [[G1161]] [[CONJ]] **ανθρωπον** *anthrōpon* (na) człowieka [[G444]] [[N-ASM]] **βλεποντες** *blepontes* patrząc [[G991]] WTV-PAP-NPM **συν** *syn* razem z [[G4862]] [[PREP]] **αυτοις** *autois* nimi [[G846]] WTP-DPM **εστωτα** *hestōta* stojącego [[G2476]] WTV-RAP-ASM **τον** *ton* (tego) [[G3588]] [[T-ASM]] **τεθεραπευμενον** *tetherapeumenon* który jest uleczony [[G2323]] WTV-RPP-ASM **ουδεν** *ouden* nic [[G3762]] WTA-ASN **ειχον** *eichon* mieli [[G2192]] WTV-IAI-3P **αντειπειν** *anteipein* odpowiedzieć – mówić przeciwko [[G471]] [[V-2AAN]]
###### **Dz 4,15**
 **κελευσαντες** *keleusantes* Rozkazawszy [[G2753]] WTV-AAP-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **αυτους** *autous* im [[G846]] [[P-APM]] **εξω** *eksō* na zewnątrz – poza [[G1854]] [[ADV]] **του** *tou* [[G3588]] WTT-GSN **συνεδριου** *synedriou* sanhedrynu – rady [[G4892]] [[N-GSN]] **απελθειν** *apelthein* odejść [[G565]] [[V-2AAN]] **συνεβαλον** *synebalon* razem zderzyli się [[G4820]] WTV-2AAI-3P **προς** *pros* przeciw [[G4314]] [[PREP]] **αλληλους** *allēlous* sobie [[G240]] WTC-APM
###### **Dz 4,16**
 **λεγοντες** *legontes* mówiąc [[G3004]] WTV-PAP-NPM **τι** *ti* co [[G5101]] WTI-ASN **ποιησομεν** *poiēsomen* uczynimy [[G4160]] WTV-FAI-1P **τοις** *tois* [[G3588]] WTT-DPM **ανθρωποις** *anthrōpois* ludziom [[G444]] WTN-DPM **τουτοις** *toutois* tym [[G5125]] WTD-DPM **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **γνωστον** *gnōston* znajomy [[G1110]] WTA-NSN **σημειον** *sēmeion* znak [[G4592]] WTN-NSN **γεγονεν** *gegonen* stał się [[G1096]] WTV-2RAI-3S **δι** *di* przez [[G1223]] [[PREP]] **αυτων** *autōn* nich [[G846]] WTP-GPM **πασιν** *pasin* wszystkim [[G3956]] WTA-DPM **τοις** *tois* [[G3588]] WTT-DPM **κατοικουσιν** *katoikousin* zamieszkującym [[G2730]] WTV-PAP-DPM **ιερουσαλημ** *ierousalēm* Jeruzalem – [dziedzictwo pokoju] [[G2419]] [[N-PRI]] **φανερον** *faneron* widoczne – jawne [[G5318]] WTA-NSN **και** *kai* i [[G2532]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **δυναμεθα** *dynametha* możemy [[G1410]] WTV-PNI-1P **αρνησασθαι** *arnēsasthai* wyprzeć się – odrzucić [[G720]] WTV-ADN
###### **Dz 4,17**
 **αλλ** *all* Ale [[G235]] [[CONJ]] **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **επι** *epi* w [[G1909]] [[PREP]] **πλειον** *pleion* większym [[G4119]] WTA-ASN-C **διανεμηθη** *dianemēthē* zostałoby rozpowszechnione [[G1268]] WTV-APS-3S **εις** *eis* w [[G1519]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **λαον** *laon* ludzie [[G2992]] [[N-ASM]] **απειλη** *apeilē* groźbą [[G547]] [[N-DSF]] **απειλησωμεθα** *apeilēsōmetha* zagrozilibyśmy [[G546]] WTV-AMS-1P **αυτοις** *autois* im [[G846]] WTP-DPM **μηκετι** *mēketi* już więcej nie [[G3371]] [[ADV]] **λαλειν** *lalein* mówić [[G2980]] WTV-PAN **επι** *epi* w [[G1909]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **ονοματι** *onomati* imieniu [[G3686]] WTN-DSN **τουτω** *toutō* tym [[G5129]] WTD-DSN **μηδενι** *mēdeni* żadnemu [[G3367]] WTA-DSM **ανθρωπων** *anthrōpōn* (z) ludzi [[G444]] WTN-GPM
###### **Dz 4,18**
 **και** *kai* I [[G2532]] [[CONJ]] **καλεσαντες** *kalesantes* wezwawszy [[G2564]] WTV-AAP-NPM **αυτους** *autous* ich [[G846]] [[P-APM]] **παρηγγειλαν** *parēngeilan* nakazali [[G3853]] WTV-AAI-3P **αυτοις** *autois* im [[G846]] WTP-DPM **το** *to* [[G3588]] WTT-ASN **καθολου** *katholou* w ogóle [[G2527]] [[ADV]] **μη** *mē* nie [[G3361]] [[PRT-N]] **φθεγγεσθαι** *fthengesthai* przemawiać [[G5350]] WTV-PNN **μηδε** *mēde* ani [[G3366]] [[CONJ]] **διδασκειν** *didaskein* nauczać [[G1321]] WTV-PAN **επι** *epi* w [[G1909]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **ονοματι** *onomati* imieniu [[G3686]] WTN-DSN **του** *tou* [[G3588]] WTT-GSM **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]]
###### **Dz 4,19**
 **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **πετρος** *petros* Piotr – [kamyk] [[G4074]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ιωαννης** *iōannēs* Jan – [JHWH jest łaskawy] [[G2491]] [[N-NSM]] **αποκριθεντες** *apokrithentes* odpowiedziawszy [[G611]] WTV-AOP-NPM **προς** *pros* do [[G4314]] [[PREP]] **αυτους** *autous* nich [[G846]] [[P-APM]] **ειπον** *eipon* powiedzieli [[G2036]] WTV-2AAI-3P **ει** *ei* czy [[G1487]] WTCOND **δικαιον** *dikaion* sprawiedliwe [[G1342]] WTA-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Bogiem [[G2316]] [[N-GSM]] **υμων** *hymōn* was [[G5216]] WTP-2GP **ακουειν** *akouein* słuchać [[G191]] WTV-PAN **μαλλον** *mallon* bardziej [[G3123]] [[ADV]] **η** *ē* niż [[G2228]] WTPRT **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **κρινατε** *krinate* osądźcie [[G2919]] WTV-AAM-2P
###### **Dz 4,20**
 **ου** *ou* Nie [[G3756]] [[PRT-N]] **δυναμεθα** *dynametha* możemy [[G1410]] WTV-PNI-1P **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ημεις** *hēmeis* my [[G2249]] WTP-1NP **α** *ha* co [[G3739]] WTR-APN **ειδομεν** *eidomen* zobaczyliśmy [[G1492]] WTV-2AAI-1P **και** *kai* i [[G2532]] [[CONJ]] **ηκουσαμεν** *ēkousamen* usłyszeliśmy [[G191]] WTV-AAI-1P **μη** *mē* nie [[G3361]] [[PRT-N]] **λαλειν** *lalein* mówić [[G2980]] WTV-PAN
###### **Dz 4,21**
 **οι** *hoi* (Ci) [[G3588]] WTT-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **προσαπειλησαμενοι** *prosapeilēsamenoi* dodatkowo zagroziwszy – jeszcze zagroziwszy [[G4324]] WTV-AMP-NPM **απελυσαν** *apelysan* uwolnili – wypuścili [[G630]] WTV-AAI-3P **αυτους** *autous* ich [[G846]] [[P-APM]] **μηδεν** *mēden* nic [[G3367]] WTA-ASN **ευρισκοντες** *heuriskontes* znajdując [[G2147]] WTV-PAP-NPM **το** *to* (tego) [[G3588]] WTT-ASN **πως** *pōs* jak [[G4459]] [[ADV]]-I **κολασωνται** *kolasōntai* mogliby ukarać [[G2849]] WTV-AMS-3P **αυτους** *autous* ich [[G846]] [[P-APM]] **δια** *dia* z powodu [[G1223]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **λαον** *laon* ludu [[G2992]] [[N-ASM]] **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **εδοξαζον** *edoksazon* chwalili [[G1392]] WTV-IAI-3P **τον** *ton* [[G3588]] [[T-ASM]] **θεον** *theon* Boga [[G2316]] [[N-ASM]] **επι** *epi* z powodu [[G1909]] [[PREP]] **τω** *tō* (tego) [[G3588]] WTT-DSN **γεγονοτι** *gegonoti* co stało się [[G1096]] WTV-2RAP-DSN
###### **Dz 4,22**
 **ετων** *etōn* Lat [[G2094]] WTN-GPN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **πλειονων** *pleionōn* liczniejszych [[G4119]] WTA-GPN-C **τεσσαρακοντα** *tessarakonta* (niż) czterdzieści [[G5062]] WTA-NUI **ο** *ho* [[G3588]] [[T-NSM]] **ανθρωπος** *anthrōpos* człowiek [[G444]] [[N-NSM]] **εφ** *ef* na [[G1909]] [[PREP]] **ον** *hon* którym [[G3739]] WTR-ASM **εγεγονει** *egegonei* stał się [[G1096]] WTV-LAI-3S **το** *to* [[G3588]] WTT-NSN **σημειον** *sēmeion* znak [[G4592]] WTN-NSN **τουτο** *touto* ten [[G5124]] WTD-NSN **της** *tēs* [[G3588]] [[T-GSF]] **ιασεως** *iaseōs* uzdrowienia – uleczenia [[G2392]] [[N-GSF]]
###### **Dz 4,23**
 **απολυθεντες** *apolythentes* Zostawszy zwolnionymi – Zostawszy wypuszczonymi [[G630]] WTV-APP-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **ηλθον** *ēlthon* przyszli [[G2064]] WTV-2AAI-3P **προς** *pros* do [[G4314]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **ιδιους** *idious* swoich [[G2398]] WTA-APM **και** *kai* i [[G2532]] [[CONJ]] **απηγγειλαν** *apēngeilan* oznajmili – poinformowali [[G518]] WTV-AAI-3P **οσα** *hosa* ile – jak [[G3745]] WTK-APN **προς** *pros* do [[G4314]] [[PREP]] **αυτους** *autous* nich [[G846]] [[P-APM]] **οι** *hoi* [[G3588]] WTT-NPM **αρχιερεις** *archiereis* arcykapłani [[G749]] WTN-NPM **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **πρεσβυτεροι** *presbyteroi* starsi [[G4245]] WTA-NPM **ειπον** *eipon* powiedzieli [[G2036]] WTV-2AAI-3P
###### **Dz 4,24**
 **οι** *hoi* (Ci) [[G3588]] WTT-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **ακουσαντες** *akousantes* usłyszawszy [[G191]] WTV-AAP-NPM **ομοθυμαδον** *homothymadon* jednomyślnie – jednogłośnie [[G3661]] [[ADV]] **ηραν** *ēran* podnieśli [[G142]] WTV-AAI-3P **φωνην** *fōnēn* głos [[G5456]] WTN-ASF **προς** *pros* do [[G4314]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **θεον** *theon* Boga [[G2316]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **ειπον** *eipon* powiedzieli [[G2036]] WTV-2AAI-3P **δεσποτα** *despota* Władco [[G1203]] WTN-VSM **συ** *sy* Ty [[G4771]] WTP-2NS **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Boże [[G2316]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **ποιησας** *poiēsas* który uczyniłeś [[G4160]] WTV-AAP-NSM **τον** *ton* [[G3588]] [[T-ASM]] **ουρανον** *ouranon* niebo [[G3772]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **γην** *gēn* ziemię [[G1093]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **θαλασσαν** *thalassan* morze [[G2281]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **παντα** *panta* wszystkie [[G3956]] WTA-APN **τα** *ta* [[G3588]] WTT-APN **εν** *en* w [[G1722]] [[PREP]] **αυτοις** *autois* nich [[G846]] WTP-DPN
###### **Dz 4,25**
 **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **δια** *dia* przez [[G1223]] [[PREP]] **στοματος** *stomatos* usta [[G4750]] [[N-GSN]] **δαβιδ** *dabid* Dawida – [umiłowany] [[G1138]] [[N-PRI]] **του** *tou* [[G3588]] WTT-GSM **παιδος** *paidos* chłopca [[G3816]] [[N-GSM]] **σου** *sou* Twojego [[G4675]] WTP-2GS **ειπων** *eipōn* (przez) którego powiedziałeś [[G2036]] WTV-2AAP-NSM **ινα** *hina* po [[G2443]] [[CONJ]] **τι** *ti* co [[G5101]] WTI-ASN **εφρυαξαν** *efryaksan* parsknęli – wzburzyli się [[G5433]] WTV-AAI-3P **εθνη** *ethnē* poganie – narody [[G1484]] WTN-NPN **και** *kai* i [[G2532]] [[CONJ]] **λαοι** *laoi* ludy [[G2992]] WTN-NPM **εμελετησαν** *emeletēsan* rozważały – troszczyły [[G3191]] WTV-AAI-3P **κενα** *kena* puste – próżne [[G2756]] WTA-APN
###### **Dz 4,26**
 **παρεστησαν** *parestēsan* Stanęli obok [[G3936]] WTV-AAI-3P **οι** *hoi* [[G3588]] WTT-NPM **βασιλεις** *basileis* królowie [[G935]] WTN-NPM **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **αρχοντες** *archontes* przywódcy – przełożeni [[G758]] WTN-NPM **συνηχθησαν** *synēchthēsan* zostali zebrani – zostali zgromadzeni [[G4863]] WTV-API-3P **επι** *epi* na [[G1909]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **αυτο** *auto* to samo [[G846]] WTP-ASN **κατα** *kata* przeciw [[G2596]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Panu [[G2962]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **κατα** *kata* przeciw [[G2596]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańcowi [[G5547]] [[N-GSM]] **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Dz 4,27**
 **συνηχθησαν** *synēchthēsan* Zostali zebrani – Zostali zgromadzeni [[G4863]] WTV-API-3P **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **επ** *ep* na- [[G1909]] [[PREP]] **αληθειας** *alētheias* prawdę [[G225]] [[N-GSF]] **επι** *epi* przeciwko [[G1909]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **αγιον** *hagion* Świętemu [[G40]] WTA-ASM **παιδα** *paida* chłopcu [[G3816]] [[N-ASM]] **σου** *sou* Twojemu [[G4675]] WTP-2GS **ιησουν** *iēsoun* Jezusowi – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]] **ον** *hon* którego [[G3739]] WTR-ASM **εχρισας** *echrisas* namaściłeś – pomazałeś [[G5548]] WTV-AAI-2S **ηρωδης** *hērōdēs* Herod – [syn bohatera] [[G2264]] [[N-NSM]] **τε** *te* zarówno – także [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **ποντιος** *pontios* Poncjusz – [mostek] [[G4194]] [[N-NSM]] **πιλατος** *pilatos* Piłat [[G4091]] [[N-NSM]] **συν** *syn* razem z [[G4862]] [[PREP]] **εθνεσιν** *ethnesin* poganami – narodami [[G1484]] WTN-DPN **και** *kai* i [[G2532]] [[CONJ]] **λαοις** *laois* ludami [[G2992]] WTN-DPM **ισραηλ** *israēl* Izraela – [ten, który walczył z Bogiem] [[G2474]] [[N-PRI]]
###### **Dz 4,28**
 **ποιησαι** *poiēsai* (aby) uczynić [[G4160]] [[V-AAN]] **οσα** *hosa* ile – jakie [[G3745]] WTK-APN **η** *hē* [[G3588]] [[T-NSF]] **χειρ** *cheir* ręka [[G5495]] [[N-NSF]] **σου** *sou* Twoja [[G4675]] WTP-2GS **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **βουλη** *boulē* postanowienie – rada [[G1012]] [[N-NSF]] **σου** *sou* Twoje [[G4675]] WTP-2GS **προωρισεν** *proōrisen* przeznaczyła [[G4309]] [[V-AAI-3S]] **γενεσθαι** *genesthai* (aby) stać się [[G1096]] WTV-2ADN
###### **Dz 4,29**
 **και** *kai* I [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **νυν** *nyn* teraz [[G3568]] [[ADV]] **κυριε** *kyrie* Panie [[G2962]] WTN-VSM **επιδε** *epide* spojrzyj – wejrzyj [[G1896]] WTV-2AAM-2S **επι** *epi* na [[G1909]] [[PREP]] **τας** *tas* [[G3588]] WTT-APF **απειλας** *apeilas* groźby [[G547]] WTN-APF **αυτων** *autōn* ich [[G846]] WTP-GPM **και** *kai* i [[G2532]] [[CONJ]] **δος** *dos* daj [[G1325]] WTV-2AAM-2S **τοις** *tois* [[G3588]] WTT-DPM **δουλοις** *doulois* niewolnikom – sługom [[G1401]] WTN-DPM **σου** *sou* Twoim [[G4675]] WTP-2GS **μετα** *meta* ze [[G3326]] [[PREP]] **παρρησιας** *parrēsias* śmiałością [[G3954]] [[N-GSF]] **πασης** *pasēs* całą [[G3956]] WTA-GSF **λαλειν** *lalein* mówić [[G2980]] WTV-PAN **τον** *ton* [[G3588]] [[T-ASM]] **λογον** *logon* Słowo [[G3056]] [[N-ASM]] **σου** *sou* Twoje [[G4675]] WTP-2GS
###### **Dz 4,30**
 **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **την** *tēn* [[G3588]] WTT-ASF **χειρα** *cheira* rękę [[G5495]] WTN-ASF **σου** *sou* Twoją [[G4675]] WTP-2GS **εκτεινειν** *ekteinein* wyciągnąć [[G1614]] WTV-PAN **σε** *se* Ty [[G4571]] WTP-2AS **εις** *eis* ku [[G1519]] [[PREP]] **ιασιν** *iasin* uzdrowieniu – uleczeniu [[G2392]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **σημεια** *sēmeia* znaki [[G4592]] WTN-NPN **και** *kai* i [[G2532]] [[CONJ]] **τερατα** *terata* cuda [[G5059]] WTN-NPN **γινεσθαι** *ginesthai* stawać się [[G1096]] WTV-PNN **δια** *dia* przez [[G1223]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **ονοματος** *onomatos* imię [[G3686]] [[N-GSN]] **του** *tou* [[G3588]] WTT-GSM **αγιου** *hagiou* Świętego [[G40]] WTA-GSM **παιδος** *paidos* chłopca [[G3816]] [[N-GSM]] **σου** *sou* Twojego [[G4675]] WTP-2GS **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]]
###### **Dz 4,31**
 **και** *kai* I [[G2532]] [[CONJ]] **δεηθεντων** *deēthentōn* gdy poprosili [[G1189]] WTV-AOP-GPM **αυτων** *autōn* oni [[G846]] WTP-GPM **εσαλευθη** *esaleuthē* zostało wstrząśnięte – zostało zachwiane [[G4531]] [[V-API-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **τοπος** *topos* miejsce [[G5117]] [[N-NSM]] **εν** *en* w [[G1722]] [[PREP]] **ω** *hō* którym [[G3739]] WTR-DSM **ησαν** *ēsan* byli [[G2258]] WTV-IXI-3P **συνηγμενοι** *synēgmenoi* którzy są zebrani – którzy są zgromadzeni [[G4863]] WTV-RPP-NPM **και** *kai* i [[G2532]] [[CONJ]] **επλησθησαν** *eplēsthēsan* zostali napełnieni [[G4130]] WTV-API-3P **απαντες** *hapantes* wszyscy [[G537]] WTA-NPM **πνευματος** *pneumatos* Duchem [[G4151]] [[N-GSN]] **αγιου** *hagiou* Świętym [[G40]] [[A-GSN]] **και** *kai* i [[G2532]] [[CONJ]] **ελαλουν** *elaloun* mówili [[G2980]] WTV-IAI-3P **τον** *ton* [[G3588]] [[T-ASM]] **λογον** *logon* Słowo [[G3056]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **μετα** *meta* ze [[G3326]] [[PREP]] **παρρησιας** *parrēsias* śmiałością [[G3954]] [[N-GSF]]
###### **Dz 4,32**
 **του** *tou* [[G3588]] WTT-GSN **δε** *de* zaś [[G1161]] [[CONJ]] **πληθους** *plēthous* mnóstwo – mnogość [[G4128]] [[N-GSN]] **των** *tōn* (tych) [[G3588]] WTT-GPM **πιστευσαντων** *pisteusantōn* którzy uwierzyli [[G4100]] WTV-AAP-GPM **ην** *ēn* było [[G2258]] [[V-IXI-3S]] **η** *hē* [[G3588]] [[T-NSF]] **καρδια** *kardia* serce [[G2588]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **ψυχη** *psychē* dusza [[G5590]] [[N-NSF]] **μια** *mia* jedna [[G1520]] WTA-NSF **και** *kai* i [[G2532]] [[CONJ]] **ουδ** *oud* ani [[G3761]] [[ADV]] **εις** *heis* jeden [[G1520]] [[A-NSM]] **τι** *ti* coś [[G5100]] WTX-ASN **των** *tōn* [[G3588]] WTT-GPN **υπαρχοντων** *hyparchontōn* będące dobytkiem – będące mieniem [[G5224]] WTV-PAP-GPN **αυτω** *autō* jego [[G846]] WTP-DSM **ελεγεν** *elegen* mówił [[G3004]] WTV-IAI-3S **ιδιον** *idion* własne [[G2398]] WTA-ASM **ειναι** *einai* być [[G1511]] WTV-PXN **αλλ** *all* ale [[G235]] [[CONJ]] **ην** *ēn* było [[G2258]] [[V-IXI-3S]] **αυτοις** *autois* im [[G846]] WTP-DPM **απαντα** *hapanta* wszystkie [[G537]] WTA-NPN **κοινα** *koina* wspólne [[G2839]] WTA-NPN
###### **Dz 4,33**
 **και** *kai* I [[G2532]] [[CONJ]] **μεγαλη** *megalē* wielką [[G3173]] WTA-DSF **δυναμει** *dynamei* mocą [[G1411]] [[N-DSF]] **απεδιδουν** *apedidoun* oddawali [[G591]] WTV-IAI-3P **το** *to* [[G3588]] WTT-ASN **μαρτυριον** *martyrion* świadectwo [[G3142]] WTN-ASN **οι** *hoi* [[G3588]] WTT-NPM **αποστολοι** *apostoloi* wysłannicy [[G652]] WTN-NPM **της** *tēs* (o) [[G3588]] [[T-GSF]] **αναστασεως** *anastaseōs* powstaniu – wzbudzeniu [[G386]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χαρις** *charis* łaska [[G5485]] [[N-NSF]] **τε** *te* zarówno – także [[G5037]] WTPRT **μεγαλη** *megalē* wielka [[G3173]] WTA-NSF **ην** *ēn* była [[G2258]] [[V-IXI-3S]] **επι** *epi* nad [[G1909]] [[PREP]] **παντας** *pantas* wszystkimi [[G3956]] WTA-APM **αυτους** *autous* nimi [[G846]] [[P-APM]]
###### **Dz 4,34**
 **ουδε** *oude* Ani [[G3761]] [[ADV]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ενδεης** *endeēs* cierpiący niedostatek – cierpiący brak [[G1729]] [[A-NSM]] **τις** *tis* ktoś [[G5100]] WTX-NSM **υπηρχεν** *hypērchen* był [[G5225]] WTV-IAI-3S **εν** *en* wśród [[G1722]] [[PREP]] **αυτοις** *autois* nich [[G846]] WTP-DPM **οσοι** *hosoi* ilu – jacy [[G3745]] WTK-NPM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **κτητορες** *ktētores* właścicielami – posiadaczami [[G2935]] WTN-NPM **χωριων** *chōriōn* terenów – pól [[G5564]] WTN-GPN **η** *ē* lub [[G2228]] WTPRT **οικιων** *oikiōn* domów [[G3614]] WTN-GPF **υπηρχον** *hypērchon* byli [[G5225]] WTV-IAI-3P **πωλουντες** *pōlountes* sprzedając [[G4453]] WTV-PAP-NPM **εφερον** *eferon* nieśli [[G5342]] WTV-IAI-3P **τας** *tas* [[G3588]] WTT-APF **τιμας** *timas* szacunki – wartości [[G5092]] WTN-APF **των** *tōn* [[G3588]] WTT-GPM **πιπρασκομενων** *pipraskomenōn* które są sprzedawane [[G4097]] WTV-PPP-GPM
###### **Dz 4,35**
 **και** *kai* i [[G2532]] [[CONJ]] **ετιθουν** *etithoun* kładli [[G5087]] WTV-IAI-3P **παρα** *para* przy [[G3844]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **ποδας** *podas* stopach [[G4228]] [[N-APM]] **των** *tōn* [[G3588]] WTT-GPM **αποστολων** *apostolōn* wysłanników [[G652]] WTN-GPM **διεδιδοτο** *diedidoto* zostało rozdane – zostało rozdzielone [[G1239]] WTV-IPI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **εκαστω** *hekastō* każdemu [[G1538]] WTA-DSM **καθοτι** *kathoti* według tego, jak- [[G2530]] [[ADV]] **αν** *an* kolwiek [[G302]] WTPRT **τις** *tis* ktoś [[G5100]] WTX-NSM **χρειαν** *chreian* potrzebę [[G5532]] WTN-ASF **ειχεν** *eichen* miał [[G2192]] WTV-IAI-3S
###### **Dz 4,36**
 **ιωσης** *iōsēs* Józef – [On powiększył] [[G2500]] [[N-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **επικληθεις** *epiklētheis* który był przezywany [[G1941]] WTV-APP-NSM **βαρναβας** *barnabas* Barnaba – [syn pocieszenia] [[G921]] [[N-NSM]] **υπο** *hypo* przez [[G5259]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **αποστολων** *apostolōn* wysłanników [[G652]] WTN-GPM **ο** *ho* co [[G3739]] WTR-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **μεθερμηνευομενον** *methermēneuomenon* które jest tłumaczone [[G3177]] WTV-PPP-NSN **υιος** *hyios* syn [[G5207]] [[N-NSM]] **παρακλησεως** *paraklēseōs* zachęty – pociechy [[G3874]] [[N-GSF]] **λευιτης** *leuitēs* lewita – [przyłączyć] [[G3019]] [[N-NSM]] **κυπριος** *kyprios* Cypryjczyk [[G2953]] [[N-NSM]] **τω** *tō* [[G3588]] WTT-DSN **γενει** *genei* rodem [[G1085]] WTN-DSN
###### **Dz 4,37**
 **υπαρχοντος** *hyparchontos* które jest [[G5225]] WTV-PAP-GSM **αυτω** *autō* jego [[G846]] WTP-DSM **αγρου** *agrou* pole [[G68]] [[N-GSM]] **πωλησας** *pōlēsas* sprzedawszy [[G4453]] WTV-AAP-NSM **ηνεγκεν** *ēnegken* przyniósł [[G5342]] [[V-AAI-3S]] **το** *to* [[G3588]] WTT-ASN **χρημα** *chrēma* pieniądze – bogactwo [[G5536]] WTN-ASN **και** *kai* i [[G2532]] [[CONJ]] **εθηκεν** *ethēken* położył [[G5087]] [[V-AAI-3S]] **παρα** *para* do [[G3844]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **ποδας** *podas* stóp [[G4228]] [[N-APM]] **των** *tōn* [[G3588]] WTT-GPM **αποστολων** *apostolōn* wysłanników [[G652]] WTN-GPM
