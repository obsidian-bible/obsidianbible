# Dz 1 BT5
###### **Dz 1,1**
 Pierwszą Księgę napisałem, Teofilu, o wszystkim, co Jezus czynił i czego nauczał od początku
###### **Dz 1,2**
 aż do dnia, w którym dał polecenia Apostołom, których sobie wybrał przez Ducha Świętego, a potem został wzięty do nieba.
###### **Dz 1,3**
 Im też po swojej męce dał wiele dowodów, że żyje: ukazywał się im przez czterdzieści dni i mówił o królestwie Bożym.
###### **Dz 1,4**
 A podczas wspólnego posiłku przykazał im nie odchodzić z Jerozolimy, ale oczekiwać obietnicy Ojca: «***Słyszeliście o niej ode Mnie – [mówił] –***
###### **Dz 1,5**
 ***Jan chrzcił wodą, ale wy wkrótce zostaniecie ochrzczeni Duchem Świętym***».
###### **Dz 1,6**
 Zapytywali Go zebrani: «***Panie, czy w tym czasie przywrócisz królestwo Izraela?***»
###### **Dz 1,7**
 Odpowiedział im: «***Nie wasza to rzecz znać czasy i chwile, które Ojciec ustalił swoją władzą,***
###### **Dz 1,8**
***ale gdy Duch Święty zstąpi na was, otrzymacie Jego moc i będziecie moimi świadkami w Jeruzalem i w całej Judei, i w Samarii, i aż po krańce ziemi***».
###### **Dz 1,9**
 Po tych słowach uniósł się w ich obecności w górę i obłok zabrał Go im sprzed oczu.
###### **Dz 1,10**
 Kiedy jeszcze wpatrywali się w Niego, jak wstępował do nieba, przystąpili do nich dwaj mężowie w białych szatach.
###### **Dz 1,11**
 i rzekli: «***Mężowie z Galilei, dlaczego stoicie i wpatrujecie się w niebo? Ten Jezus, wzięty od was do nieba, przyjdzie tak samo, jak widzieliście Go wstępującego do nieba***».
###### **Dz 1,12**
 Wtedy wrócili do Jeruzalem z góry zwanej Oliwną, która jest blisko Jeruzalem, w odległości drogi szabatowej.
###### **Dz 1,13**
 Przybywszy tam, weszli do sali na górze i przebywali w niej: Piotr i Jan, i Jakub, i Andrzej, Filip i Tomasz, Bartłomiej i Mateusz, Jakub, syn Alfeusza, i Szymon Gorliwy, i Juda, [brat] Jakuba.
###### **Dz 1,14**
 Wszyscy oni trwali jednomyślnie na modlitwie razem z niewiastami, z Maryją, Matką Jezusa, i z braćmi Jego.
###### **Dz 1,15**
 Wtedy Piotr w obecności braci, a zebrało się razem około stu dwudziestu osób, tak przemówił:
###### **Dz 1,16**
 «***Bracia, musiało wypełnić się słowo Pisma, które Duch Święty zapowiedział przez usta Dawida o Judaszu. On to wskazał drogę tym, którzy pojmali Jezusa,***
###### **Dz 1,17**
 ***bo on zaliczał się do nas i miał udział w naszym posługiwaniu.***
###### **Dz 1,18**
  ***Za pieniądze, niegodziwie zdobyte, nabył ziemię i spadłszy głową na dół, pękł na pół, i wypłynęły wszystkie jego wnętrzności.***
###### **Dz 1,19**
 ***Rozniosło się to wśród wszystkich mieszkańców Jeruzalem, tak że nazwano ową rolę w ich języku Hakeldamach, to znaczy: Pole Krwi.***
###### **Dz 1,20**
 ***Napisano bowiem w Księdze Psalmów: Niech opustoszeje dom jego i niech nikt w nim nie mieszka! A urząd jego niech inny obejmie!***
###### **Dz 1,21**
 ***Trzeba więc, aby jeden z tych, którzy towarzyszyli nam przez cały czas, kiedy Pan Jezus przebywał z nami,***
###### **Dz 1,22**
 ***począwszy od chrztu Janowego aż do dnia, w którym został wzięty od nas do nieba, stał się razem z nami świadkiem Jego zmartwychwstania***».
###### **Dz 1,23**
 Postawiono dwóch: Józefa, zwanego Barsabą, z przydomkiem Justus, i Macieja.
###### **Dz 1,24**
 I taką odmówili modlitwę: «***Ty, Panie, znasz serca wszystkich, wskaż z tych dwóch jednego, którego sobie wybrałeś,***
###### **Dz 1,25**
 ***by zajął miejsce w tym posługiwaniu i w apostolstwie, któremu sprzeniewierzył się Judasz, aby pójść swoją drogą***».
###### **Dz 1,26**
 I dali im losy, a los padł na Macieja. I został dołączony do jedenastu Apostołów.
# Dz 1 PAU
###### **Dz 1,1**
 Teofilu, w pierwszej księdze napisałem o wszystkim, co Jezus czynił i czego nauczał od początku
###### **Dz 1,2**
 aż do dnia, w którym pod wpływem Ducha Świętego udzielił pouczeń wybranym przez siebie apostołom i został wzięty do nieba.
###### **Dz 1,3**
 Po swojej męce wiele razy okazywał im, że żyje. Przez czterdzieści dni zjawiał się im bowiem i mówił o królestwie Bożym.
###### **Dz 1,4**
 Gdy zasiedli do wspólnego posiłku, nakazał im: „Nie opuszczajcie Jerozolimy, ale oczekujcie spełnienia się obietnicy Ojca, o której wam mówiłem:
###### **Dz 1,5**
 Jan chrzcił wodą, wy zaś wkrótce zostaniecie ochrzczeni Duchem Świętym”.
###### **Dz 1,6**
 A zebrani pytali Go: „Panie, czy teraz na nowo przywrócisz królestwo Izraela?”.
###### **Dz 1,7**
 Odpowiedział im: „Nie możecie znać czasu ani chwili, które zastrzegł sobie Ojciec.
###### **Dz 1,8**
 Otrzymacie jednak moc Ducha Świętego, który zstąpi na was, i staniecie się moimi świadkami w Jeruzalem, w całej Judei, w Samarii i aż po krańce ziemi”.
###### **Dz 1,9**
 A kiedy to powiedział, zobaczyli, jak uniósł się w górę, a obłok zabrał Go im sprzed oczu.
###### **Dz 1,10**
 Uporczywie wpatrywali się w niebo, gdy On odchodził. Wtedy stanęli przy nich dwaj mężczyźni ubrani na biało
###### **Dz 1,11**
 i powiedzieli: „Galilejczycy, dlaczego stoicie i wpatrujecie się w niebo? Jezus został wzięty spomiędzy was do nieba, ale przyjdzie tak samo, jak Go widzieliście idącego do nieba”.
###### **Dz 1,12**
 Potem wrócili do Jeruzalem z góry zwanej Oliwną, która znajduje się blisko Jeruzalem, w odległości drogi szabatowej.
###### **Dz 1,13**
 A gdy tam przybyli, weszli do sali na piętrze, gdzie się zwykle zbierali. Byli tam: Piotr, Jan, Jakub, Andrzej, Filip, Tomasz, Bartłomiej, Mateusz, Jakub, syn Alfeusza, Szymon Gorliwy i Juda, syn Jakuba.
###### **Dz 1,14**
 Wszyscy oni modlili się wytrwale i jednomyślnie. Razem z nimi były także kobiety, Maryja, Matka Jezusa, i Jego bracia.
###### **Dz 1,15**
 Wtedy Piotr stanął wśród braci, a zebrało się tam około stu dwudziestu osób, i powiedział:
###### **Dz 1,16**
 „Bracia! Musiało się wypełnić to, co Duch Święty zapowiedział w Piśmie przez Dawida o Judaszu. Przewodził on tym, którzy uwięzili Jezusa,
###### **Dz 1,17**
 chociaż należał do nas i miał udział w tym samym posługiwaniu.
###### **Dz 1,18**
 On to kupił kawałek ziemi za pieniądze nieuczciwie zdobyte. Spadł jednak głową na dół, rozpękł się i wypłynęły wszystkie jego wnętrzności.
###### **Dz 1,19**
 Dowiedzieli się o tym wszyscy mieszkańcy Jeruzalem i dlatego tę ziemię nazwano w ich języku Hakeldamach, to znaczy: Ziemia Krwi.
###### **Dz 1,20**
 W Księdze Psalmów czytamy bowiem: Niech opustoszeje dom jego i niech nikt w nim nie zamieszkuje, a urząd jego niech przejmie kto inny.
###### **Dz 1,21**
 Są wśród nas tacy, którzy nam towarzyszyli przez cały czas, gdy Pan Jezus przebywał z nami,
###### **Dz 1,22**
 począwszy od chrztu Janowego aż do dnia, gdy został zabrany spośród nas do nieba. Trzeba więc, aby jeden z nich stał się razem z nami świadkiem Jego Zmartwychwstania”.
###### **Dz 1,23**
 Przedstawili dwóch: Józefa, zwanego Barsabą, z przydomkiem Justus, i Macieja.
###### **Dz 1,24**
 I tak się modlili: „Panie, Ty znasz serca wszystkich. Wskaż, którego z tych dwóch wybrałeś.
###### **Dz 1,25**
 Niech zajmie miejsce Judasza, który porzucił apostolską służbę i odszedł na właściwe sobie miejsce”.
###### **Dz 1,26**
 Rozdali im więc losy. A los padł na Macieja. I dołączono go do grona jedenastu apostołów.
# Dz 1 BP
###### **Dz 1,1**
 Teofilu, pierwszą księgę napisałem o całej działalności i nauce Jezusa,
###### **Dz 1,2**
 doprowadzając opis do czasu Jego wniebowstąpienia, przed którym przez Ducha Świętego dał misję wybranym przez siebie apostołom.
###### **Dz 1,3**
 On to po męce przez wiele znaków dał niezbite dowody, że żyje, ukazując się im przez czterdzieści dni i nauczając o królestwie Bożym.
###### **Dz 1,4**
 W czasie wspólnego posiłku nakazał im: "Nie opuszczajcie Jerozolimy, ale czekajcie na obietnicę Ojca, o której ode mnie słyszeliście.
###### **Dz 1,5**
 Jan bowiem chrzcił wodą, wy zaś niedługo otrzymacie chrzest Ducha Świętego".
###### **Dz 1,6**
 Zgromadzeni ludzie pytali Go więc: "Panie, czy w tym czasie przywrócisz królestwo Izraelowi?"
###### **Dz 1,7**
 Odpowiedział im: "Nie potrzebujecie znać czasu, a zwłaszcza tej chwili, którą Ojciec zastrzegł dla siebie.
###### **Dz 1,8**
 Otrzymacie moc Ducha Świętego, który na was zstąpi, i będziecie moimi świadkami w Jerozolimie, w całej Judei, w Samarii i na całym świecie".
###### **Dz 1,9**
 Po tych słowach na ich oczach uniósł się do góry i widzieli Go, dopóki obłok im Go nie zakrył.
###### **Dz 1,10**
 A gdy za odchodzącym uporczywie patrzyli w niebo, wtedy stanęło przy nich dwóch ludzi na biało ubranych,
###### **Dz 1,11**
 którzy powiedzieli: "Galilejczycy, czemu stoicie patrząc w niebo? Ten Jezus wzięty spośród was do nieba przyjdzie w taki sam sposób, jak Go widzieliście odchodzącego".
###### **Dz 1,12**
 Wtedy wrócili do Jerozolimy z góry, zwanej Oliwną, znajdującej się w pobliżu, bo w odległości drogi szabatu.
###### **Dz 1,13**
 I kiedy przyszli do domu, weszli na górę, tam gdzie zwykle się zatrzymywali. Byli to: Piotr, Jan, Jakub, Andrzej, Filip i Tomasz, Bartłomiej i Mateusz, Jakub syn Alfeusza, Szymon zwany Gorliwym i Judasz, syn Jakuba.
###### **Dz 1,14**
 Wszyscy oni trwali na wspólnej modlitwie, a razem z nimi były też kobiety, Maryja, matka Jezusa i Jego bracia.
###### **Dz 1,15**
 Wtedy to spośród nich wystąpił Piotr z przemówieniem (zebrało się tam wtedy około 120 osób):
###### **Dz 1,16**
 "Bracia! Musiały się wypełnić słowa zapowiedziane przez Ducha Świętego ustami Dawida o Judaszu, który stanął na czele tych, którzy pojmali Jezusa,
###### **Dz 1,17**
 choć był przecież jednym z nas, to znaczy miał udział w tym samym posługiwaniu.
###### **Dz 1,18**
 Otrzymawszy za tę niegodziwość zapłatę, kupił rolę. Powiesił się, pękł na pół i wypłynęły z niego wszystkie wnętrzności.
###### **Dz 1,19**
 Wiadome to było wszystkim mieszkańcom Jerozolimy, tak że rola ta została nazwana Hakeldamach, to znaczy pole krwi.
###### **Dz 1,20**
 Napisano bowiem w Księdze Psalmów: "Niech dom jego stanie się pusty i niech nikt w nim nie zamieszkuje", a "obowiązki jego niech przejmie inny".
###### **Dz 1,21**
 Dlatego trzeba, aby to był jeden spośród tych,
###### **Dz 1,22**
 którzy z nami chodzili przez cały czas przebywania Pana Jezusa, od chrztu Jana aż do dnia wniebowstąpienia, i wraz z nami świadczył o Jego zmartwychwstaniu".
###### **Dz 1,23**
 Wysunęli dwóch: Józefa Barsabę, z przydomkiem Justus, i Macieja.
###### **Dz 1,24**
 I modlili się: "Panie, Ty znasz serca wszystkich, wskaż więc, którego z tych dwóch
###### **Dz 1,25**
 wybrałeś na miejsce Judasza do służby i posłannictwa, któremu ten się sprzeniewierzył, odchodząc na właściwe sobie miejsce".
###### **Dz 1,26**
 Rozdali im losy, los padł na Macieja i dołączono go do Jedenastu.
# Dz 1 BR
###### **Dz 1,1**
 W mojej pierwszej księdze opisałem, Teofilu, to wszystko, co Jezus czynił i czego nauczał od samego początku
###### **Dz 1,2**
 aż do dnia, w którym został wzięty do nieba, udzieliwszy przedtem przez Ducha Świętego różnych pouczeń ludziom wybranym przez siebie na apostołów.
###### **Dz 1,3**
 To im właśnie po swojej męce zostawił wiele dowodów, że nadal żyje; ukazywał się im bowiem przez czterdzieści dni i mówił o królestwie Bożym.
###### **Dz 1,4**
 Pewnego zaś dnia, kiedy był razem z nimi, wydał im takie oto polecenie: Nie opuszczajcie Jerozolimy, lecz oczekujcie tu na spełnienie się tego, co wam przyobiecał Ojciec i o czym ja również wam mówiłem.
###### **Dz 1,5**
 Jan chrzcił wodą, a wy zostaniecie wkrótce ochrzczeni Duchem Świętym.
###### **Dz 1,6**
 Zapytali Go zebrani: Panie, czy to właśnie w tym czasie przywrócisz na nowo wielkość królestwa izraelskiego?
###### **Dz 1,7**
 Lecz Jezus odpowiedział im: Nie do was należy znać dzień i godzinę, którą Ojciec ustanowił całą powagą swojej władzy.
###### **Dz 1,8**
 Gdy jednak zstąpi na was Duch Święty otrzymacie Jego moc i będziecie świadczyć o Mnie w Jerozolimie i w całej Judei, i w Samarii, aż po krańce ziemi.
###### **Dz 1,9**
 Powiedziawszy to uniósł się na ich oczach w górę i zniknął w obłoku.
###### **Dz 1,10**
 A gdy oni patrzyli z uwagą za wstępującym w niebo, przystąpili do nich dwaj mężowie odziani w białe szaty
###### **Dz 1,11**
 i powiedzieli: O Galilejczycy, czemuż tak stoicie i patrzycie w niebo? Jezus, który dopiero co został wzięty od was do nieba, przyjdzie tak samo, jak widzieliście Go, gdy wstępował do nieba.
###### **Dz 1,12**
 Z Góry Oliwnej, znajdującej się niedaleko Jerozolimy w odległości drogi jednego szabatu, wrócili do Jerozolimy i
###### **Dz 1,13**
 weszli do [pewnego] pomieszczenia w górnej części domu. Byli tam apostołowie: Piotr i Jan, Jakub i Andrzej, Filip i Tomasz, Bartłomiej i Mateusz, Jakub, syn Alfeusza, i Szymon Gorliwy, i Juda, brat Jakuba.
###### **Dz 1,14**
 Wszyscy razem trwali na modlitwie z niewiastami, Maryją, Matką Jezusa, i Jego braćmi.
###### **Dz 1,15**
 Wtedy to Piotr wobec wszystkich braci, których zebrało się razem około stu dwudziestu, tak przemówił:
###### **Dz 1,16**
 Bracia, musiało się spełnić to, co Duch Święty przepowiedział w Piśmie przez usta Dawida o Judaszu, który wskazał drogę do pojmania Jezusa.
###### **Dz 1,17**
 Przedtem należał do nas i uczestniczył w naszym posługiwaniu.
###### **Dz 1,18**
 Za pieniądze zdobyte w niegodziwy sposób nabył sobie ziemię; potem, spadłszy głową na dół, pękł na pół i wypłynęły wszystkie jego wnętrzności.
###### **Dz 1,19**
 Wieść o tym rozeszła się wśród wszystkich mieszkańców Jerozolimy i tak oto nazwano ową rolę w ich języku Hakeldamach, to jest Pole Krwi.
###### **Dz 1,20**
 W Księdze Psalmów jest bowiem napisane: Niech stanie się pustym dom jego i niech nikt w nim nie mieszka. Jego urząd zaś niech obejmie ktoś inny.
###### **Dz 1,21**
 Tak więc wypada, aby jeden z tych, którzy byli z nami przez cały czas, kiedy Pan Jezus znajdował się wśród nas,
###### **Dz 1,22**
 od chrztu Janowego aż do chwili swego wniebowstąpienia, został razem z nami świadkiem Jego zmartwychwstania.
###### **Dz 1,23**
 Przedstawiono więc dwóch: Józefa Barsabę, z przydomkiem Justus, i Macieja.
###### **Dz 1,24**
 I odmówili taką oto modlitwę: Panie, Ty znasz serca wszystkich; wskaż nam, którego z tych dwu wybrałeś,
###### **Dz 1,25**
 aby mógł objąć urząd posługiwania i apostolatu po Judaszu, ponieważ ten się sprzeniewierzył i poszedł swoją drogą.
###### **Dz 1,26**
 Potem rzucili losy i padł los na Macieja, który też zaraz został dołączony do jedenastu apostołów.
# Dz 1 WUJ
###### **Dz 1,1**
 Pierwsząm mowę uczynił, o Theophile, o wszystkiem co począł Jezus czynić i uczyć:
###### **Dz 1,2**
 Aż do dnia, którego rozkazawszy Apostołom przez Ducha świętego, które obrał, wzięt jest:
###### **Dz 1,3**
 Którym też siebie samego po swej męce stawił żywym w rozmaitych dowodziech, przez czterdzieści dni się im ukazując, i mówiąc o królestwie Bożem.
###### **Dz 1,4**
 A z nimi jedząc rozkazał im, aby nie odchodzili z Jeruzalem, ale czekali obietnice Ojcowskiej: którąście (prawi) słyszeli przez usta moje.
###### **Dz 1,5**
 Abowiemci Jan chrzcił wodą, a wy będziecie chrzczeni Duchem świętym po nie wielu tych dni.
###### **Dz 1,6**
 A tak, którzy się byli zeszli, pytali go, mówiąc: Panie, zali w tym czasie przywrócisz królestwo Izraelowi?
###### **Dz 1,7**
 I rzekł do nich: Nie wasza rzecz jest znać czasy i chwile, które Ociec w swej władzy położył:.
###### **Dz 1,8**
 Ale weźmiecie moc Ducha świętego, który przydzie na was: i będziecie mi świadkami w Jeruzalem, i we wszystkiej Żydowskiej ziemi, i w Samarjej, i aż na kraj ziemie.
###### **Dz 1,9**
 A to rzekłszy, gdy oni patrzali podniesion jest, a obłok wziął go od oczu ich.
###### **Dz 1,10**
 A gdy pilnie patrzali za nim do nieba idącym: oto dwa mężowie stanęli przy nich w białem odzieniu:
###### **Dz 1,11**
 Którzy też rzekli: Mężowie Galilejscy, czemu stoicie, patrząc w niebo? ten Jezus, który wzięt jest od was do nieba, tak przydzie jakoście go widzieli idącego do nieba.
###### **Dz 1,12**
 Tedy się wrócili do Jeruzalem od góry, którą zowią Oliwną: która jest blizko Jeruzalem, mając drogę szabbatu.
###### **Dz 1,13**
 A gdy wyszli wstąpili do wieczernika, gdzie mieszkali Piotr i Jan, Jakób i Andrzej, Filip i Tomasz, Bartłomiej i Mateusz, Jakób Alpheuszów, i Symon Zelotes? i Judas Jakobów.
###### **Dz 1,14**
 Ci wszysci trwali jednomyślnie na modlitwie z niewiastami i z Maryą matką Jezusową, i z bracią jego.
###### **Dz 1,15**
 W one dni powstawszy Piotr w pośród braciej rzekł: (a był poczet osób wespołek jakoby sto dwadzieścia).
###### **Dz 1,16**
 Mężowie bracia, musiałoć się wypełnić pismo, które opowiedział Duch święty przez usta Dawidowe, o Judaszu (który był wodzem tych co pojmali Jezusa):
###### **Dz 1,17**
 Który był policzony z nami, i dostała mu się cząstka tego usługowania.
###### **Dz 1,18**
 A onci otrzymał rolą z zapłaty niesprawiedliwości: a obiesiwszy się rozpuki się na poły, i wypłynęły wszystkie wnętrzności jego.
###### **Dz 1,19**
 I stało się jawno wszystkim mieszkającym w Jeruzalem: tak iż nazwano onę rolą ich językiem Haceldama, to jest, rola krwie.
###### **Dz 1,20**
 Abowiem napisano w księgach Psalmów: Niechaj będzie ich mieszkanie puste, a niech nie będzie ktoby w nim mieszkał. A biskupstwo jego niech weźmie drugi.
###### **Dz 1,21**
 Potrzeba tedy z tych mężów, którzy się z nami schodzili przez wszystek czas, którego Pan Jezus wchodził i wychodził między nami:
###### **Dz 1,22**
 Począwszy ode chrztu Janowego aż do tego dnia, w który jest od nas, aby jeden z nich był z nami świadkiem zmartwychwstania jego.
###### **Dz 1,23**
 I postanowili dwu, Józefa, którego zwano Barsabas, którego nazywano Justem, i Macieja.
###### **Dz 1,24**
 A modląc się mówili: Ty Panie, który znasz serca wszystkich, okaż któregoś obrał z tych dwu jednego.
###### **Dz 1,25**
 Aby wziął miejsce usługowania tego i Apostolstwa, z którego wypadł Judasz, aby odszedł na miejsce swe.
###### **Dz 1,26**
 I dali im losy, i padł los na Macieja, i policzon jest z jedenaścią Apostołów.
# Dz 1 STERN
###### **Dz 1,1**
 Drogi Teofilu, w pierwszej księdze napisałem o wszystkim, co Jeszua od początku czynił i czego nauczał
###### **Dz 1,2**
 aż do dnia, gdy udzieliwszy przez Ruach Ha-Kodesz pouczeń wysłannikom, których wybrał, został zabrany w górę do nieba.
###### **Dz 1,3**
 Po Jego śmierci ukazywał im się i dawał wiele przekonujących dowodów, że żyje. Oglądali Go przez okres czterdziestu dni, a On mówił z nimi o Królestwie Bożym.
###### **Dz 1,4**
 Podczas jednego z takich spotkań polecił, aby nie opuszczali Jeruszalaim, ale czekali na to, "co obiecał Ojciec, a o czym ode mnie słyszeliście.
###### **Dz 1,5**
 Bo Jochanan zanurzał ludzi w wodzie; ale za kilka dni wy będziecie zanurzeni w Ruach Ha-Kodesz!".
###### **Dz 1,6**
 Kiedy byli razem, zapytali Go: "Panie, czy teraz przywrócisz niezawisłość Israelowi?"
###### **Dz 1,7**
 Odparł: "Nie musicie znać dat ani godzin; to Ojciec ma je pod swoją władzą.
###### **Dz 1,8**
 Ale otrzymacie moc, kiedy zstąpi na was Ruach Ha-Kodesz; będziecie moimi świadkami i w Jeruszalaim, i w całej J'hudzie i Szomron, aż po krańce ziemi!".
###### **Dz 1,9**
 Powiedziawszy to, został zabrany im sprzed oczu; i obłok skrył Go przed ich wzrokiem.
###### **Dz 1,10**
 A gdy wpatrywali się za Nim w niebo, ujrzeli nagle dwóch mężów odzianych w biel, stojących tuż koło nich.
###### **Dz 1,11**
 Mężowie ci rzekli: "Galilejczycy! Czemu stoicie, wpatrując się w przestrzeń? Ten Jeszua, który został od was zabrany do nieba, powróci do was tak samo, jak Go widzieliście idącego do nieba".
###### **Dz 1,12**
 Wtedy wrócili, pokonując odległość drogi szabbatowej, z Góry Oliwnej do Jeruszalaim.
###### **Dz 1,13**
 Wszedłszy do miasta, poszli do pokoju na górze, gdzie przebywali. A takie były imiona wysłanników: Kefa, Ja'akow, Jochanan, Andrzej, Filip, T'oma, Bar-Talmaj, Mattitjahu, Ja'akow Ben-Chalfaj, Szim'on "Zelota" i J'huda Ben-Ja'akow.
###### **Dz 1,14**
 Wszyscy oni oddawali się jednomyślnie modlitwie, wraz z kilkoma kobietami, w tym Miriam (matką Jeszui), i Jego braćmi.
###### **Dz 1,15**
 W tym czasie, gdy grupa wierzących liczyła około stu dwudziestu osób, Kefa powstał i zwrócił się do współwierzących:
###### **Dz 1,16**
 "Bracia, Ruach Ha-Kodesz przez Dawida powiedział zawczasu o J'hudzie, i musiały się te słowa Tanach wypełnić. On przewodził tym, którzy pojmali Jeszuę -
###### **Dz 1,17**
 był jednym z nas i miał wyznaczony udział w naszej pracy".
###### **Dz 1,18**
 (Za pieniądze otrzymane za swój czyn niegodziwy kupił J'huda pole; i tam upadł, i umarł. Jego ciało nabrzmiało i pękło, a wszystkie jego wnętrzności się wylały.
###### **Dz 1,19**
 Stało się to wiadome każdemu w Jeruszalaim, tak że nazwano to pole Chakal-D'ma, co w ich języku oznacza "Pole Krwi").
###### **Dz 1,20**
 "Napisano zaś - rzekł Kefa - w księdze Psalmów: "Niech spustoszone będą dobra jego, niech nie będzie nikogo, kto by w nich mieszkał"; i "Niech kto inny urząd jego przejmie".
###### **Dz 1,21**
 Dlatego jeden z ludzi, którzy zawsze byli z nami w czasie, gdy Pan Jeszua chodził pośród nas,
###### **Dz 1,22**
 odkąd Jochanan zanurzał ludzi aż do dnia, gdy Jeszua został od nas zabrany w górę, jeden z nich musi stać się wraz z nami świadkiem Jego zmartwychwstania".
###### **Dz 1,23**
 Przedstawiono dwóch - Josefa Bar-Sabbę o przydomku Justus oraz Mattitjahu.
###### **Dz 1,24**
 I modlili się: "Panie, Ty znasz wszystkie serca. Pokaż nam, którego z tych dwóch wybrałeś,
###### **Dz 1,25**
 aby przejął dzieło i urząd wysłannika, który J'huda porzucił, by odejść na swoje miejsce".
###### **Dz 1,26**
 I ciągnęli losy, aby wybrać między tymi dwoma, i los padł na Mattitjahu. Dołączył on więc do jedenastu wysłanników.
# Dz 1 TRO
###### **Dz 1,1**
 **τον** *ton* [[G3588]] [[T-ASM]] **μεν** *men* Wprawdzie – Prawdziwie [[G3303]] WTPRT **πρωτον** *prōton* pierwsze [[G4413]] WTA-ASM **λογον** *logon* słowo [[G3056]] [[N-ASM]] **εποιησαμην** *epoiēsamēn* uczyniłem [[G4160]] WTV-AMI-1S **περι** *peri* o [[G4012]] [[PREP]] **παντων** *pantōn* wszystkich [[G3956]] WTA-GPN **ω** *ō* o [[G5599]] WTINJ **θεοφιλε** *theofile* Teofilu – [przyjaciel Boga] [[G2321]] WTN-VSM **ων** *hōn* które [[G3739]] WTR-GPN **ηρξατο** *ērksato* zaczął [[G756]] WTV-ADI-3S **ο** *ho* [[G3588]] [[T-NSM]] **ιησους** *iēsous* Jezus – [JHWH jest zbawieniem] [[G2424]] [[N-NSM]] **ποιειν** *poiein* czynić [[G4160]] WTV-PAN **τε** *te* zarówno – także [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **διδασκειν** *didaskein* nauczać [[G1321]] WTV-PAN
###### **Dz 1,2**
 **αχρι** *achri* Aż do [[G891]] [[PREP]] **ης** *hēs* którego [[G3739]] [[R-GSF]] **ημερας** *hēmeras* dnia [[G2250]] [[N-GSF]] **εντειλαμενος** *enteilamenos* przykazawszy [[G1781]] WTV-ANP-NSM **τοις** *tois* [[G3588]] WTT-DPM **αποστολοις** *apostolois* wysłannikom [[G652]] WTN-DPM **δια** *dia* przez [[G1223]] [[PREP]] **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **αγιου** *hagiou* Świętego [[G40]] [[A-GSN]] **ους** *hous* których [[G3739]] WTR-APM **εξελεξατο** *ekseleksato* wybrał [[G1586]] WTV-AMI-3S **ανεληφθη** *anelēfthē* został uniesiony – został wzięty do góry [[G353]] [[V-API-3S]]
###### **Dz 1,3**
 **οις** *hois* których [[G3739]] WTR-DPM **και** *kai* i [[G2532]] [[CONJ]] **παρεστησεν** *parestēsen* postawił obok [[G3936]] [[V-AAI-3S]] **εαυτον** *heauton* siebie [[G1438]] WTF-3ASM **ζωντα** *zōnta* (jako) żyjącego [[G2198]] WTV-PAP-ASM **μετα** *meta* po [[G3326]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **παθειν** *pathein* wycierpieć [[G3958]] [[V-2AAN]] **αυτον** *auton* Mu [[G846]] WTP-ASM **εν** *en* w [[G1722]] [[PREP]] **πολλοις** *pollois* wielu [[G4183]] WTA-DPN **τεκμηριοις** *tekmēriois* pewnych dowodach – niewątpliwych dowodach [[G5039]] WTN-DPN **δι** *di* przez [[G1223]] [[PREP]] **ημερων** *hēmerōn* dni [[G2250]] WTN-GPF **τεσσαρακοντα** *tessarakonta* czterdzieści [[G5062]] WTA-NUI **οπτανομενος** *optanomenos* dając siebie widzieć [[G3700]] WTV-PNP-NSM **αυτοις** *autois* im [[G846]] WTP-DPM **και** *kai* i [[G2532]] [[CONJ]] **λεγων** *legōn* mówiąc [[G3004]] [[V-PAP-NSM]] **τα** *ta* (te) [[G3588]] WTT-APN **περι** *peri* o [[G4012]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **βασιλειας** *basileias* Królestwie [[G932]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **Dz 1,4**
 **και** *kai* i [[G2532]] [[CONJ]] **συναλιζομενος** *synalizomenos* jedząc wspólnie – będąc zebranym na jednym miejscu [[G4871]] WTV-PNP-NSM **μετ** *met* z [[G3326]] [[PREP]] **αυτων** *autōn* nimi [[G846]] WTP-GPM **παρηγγειλεν** *parēngeilen* nakazał [[G3853]] [[V-AAI-3S]] **αυτοις** *autois* im [[G846]] WTP-DPM **απο** *apo* od [[G575]] [[PREP]] **ιεροσολυμων** *ierosolymōn* Jerozolimy – [dziedzictwo pokoju] [[G2414]] WTN-GPN **μη** *mē* nie [[G3361]] [[PRT-N]] **χωριζεσθαι** *chōrizesthai* być oddalonymi [[G5563]] WTV-PPN **αλλα** *alla* ale [[G235]] [[CONJ]] **περιμενειν** *perimenein* oczekiwać [[G4037]] WTV-PAN **την** *tēn* [[G3588]] WTT-ASF **επαγγελιαν** *epangelian* obietnicy [[G1860]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **πατρος** *patros* Ojca [[G3962]] [[N-GSM]] **ην** *hēn* którą [[G3739]] WTR-ASF **ηκουσατε** *ēkousate* słyszeliście [[G191]] WTV-AAI-2P **μου** *mou* (ode) Mnie [[G3450]] WTP-1GS
###### **Dz 1,5**
 **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **ιωαννης** *iōannēs* Jan – [JHWH jest łaskawy] [[G2491]] [[N-NSM]] **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **εβαπτισεν** *ebaptisen* zanurzył [[G907]] [[V-AAI-3S]] **υδατι** *hydati* (w) wodzie [[G5204]] WTN-DSN **υμεις** *hymeis* wy [[G5210]] WTP-2NP **δε** *de* zaś [[G1161]] [[CONJ]] **βαπτισθησεσθε** *baptisthēsesthe* zostaniecie zanurzeni [[G907]] WTV-FPI-2P **εν** *en* w [[G1722]] [[PREP]] **πνευματι** *pneumati* Duchu [[G4151]] WTN-DSN **αγιω** *hagiō* Świętym [[G40]] WTA-DSN **ου** *ou* nie [[G3756]] [[PRT-N]] **μετα** *meta* po [[G3326]] [[PREP]] **πολλας** *pollas* wielu [[G4183]] WTA-APF **ταυτας** *tautas* tych [[G3778]] WTD-APF **ημερας** *hēmeras* dniach [[G2250]] WTN-APF
###### **Dz 1,6**
 **οι** *hoi* [[G3588]] WTT-NPM **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **ουν** *oun* więc [[G3767]] [[CONJ]] **συνελθοντες** *synelthontes* zszedłszy się [[G4905]] WTV-2AAP-NPM **επηρωτων** *epērōtōn* pytali [[G1905]] WTV-IAI-3P **αυτον** *auton* Go [[G846]] WTP-ASM **λεγοντες** *legontes* mówiąc [[G3004]] WTV-PAP-NPM **κυριε** *kyrie* Panie [[G2962]] WTN-VSM **ει** *ei* czy [[G1487]] WTCOND **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **χρονω** *chronō* czasie [[G5550]] WTN-DSM **τουτω** *toutō* tym [[G5129]] WTD-DSM **αποκαθιστανεις** *apokathistaneis* przywracasz [[G600]] WTV-PAI-2S **την** *tēn* [[G3588]] WTT-ASF **βασιλειαν** *basileian* królestwo [[G932]] WTN-ASF **τω** *tō* [[G3588]] WTT-DSM **ισραηλ** *israēl* Izraelowi – [ten, który walczył z Bogiem] [[G2474]] [[N-PRI]]
###### **Dz 1,7**
 **ειπεν** *eipen* Powiedział [[G2036]] WTV-2AAI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **προς** *pros* do [[G4314]] [[PREP]] **αυτους** *autous* nich [[G846]] [[P-APM]] **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **υμων** *hymōn* wasze [[G5216]] WTP-2GP **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **γνωναι** *gnōnai* poznać [[G1097]] [[V-2AAN]] **χρονους** *chronous* czasy [[G5550]] [[N-APM]] **η** *ē* lub [[G2228]] WTPRT **καιρους** *kairous* pory [[G2540]] [[N-APM]] **ους** *hous* które [[G3739]] WTR-APM **ο** *ho* [[G3588]] [[T-NSM]] **πατηρ** *patēr* Ojciec [[G3962]] [[N-NSM]] **εθετο** *etheto* umieścił [[G5087]] WTV-2AMI-3S **εν** *en* we [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **ιδια** *idia* własnej [[G2398]] WTA-DSF **εξουσια** *eksousia* władzy [[G1849]] [[N-DSF]]
###### **Dz 1,8**
 **αλλα** *alla* ale [[G235]] [[CONJ]] **ληψεσθε** *lēpsesthe* weźmiecie [[G2983]] WTV-FDI-2P **δυναμιν** *dynamin* moc [[G1411]] WTN-ASF **επελθοντος** *epelthontos* który przyszedł [[G1904]] WTV-2AAP-GSN **του** *tou* [[G3588]] WTT-GSN **αγιου** *hagiou* Świętego [[G40]] [[A-GSN]] **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **εφ** *ef* do [[G1909]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **και** *kai* i [[G2532]] [[CONJ]] **εσεσθε** *esesthe* będziecie [[G2071]] WTV-FXI-2P **μοι** *moi* Mi [[G3427]] WTP-1DS **μαρτυρες** *martyres* świadkowie [[G3144]] WTN-NPM **εν** *en* w [[G1722]] [[PREP]] **τε** *te* zarówno – także [[G5037]] WTPRT **ιερουσαλημ** *ierousalēm* Jeruzalem – [dziedzictwo pokoju] [[G2419]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **παση** *pasē* całej [[G3956]] WTA-DSF **τη** *tē* [[G3588]] WTT-DSF **ιουδαια** *ioudaia* Judei – [[wielbić] ziemię] [[G2449]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **σαμαρεια** *samareia* Samarii – [zachować] [[G4540]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **εως** *heōs* aż do [[G2193]] [[CONJ]] **εσχατου** *eschatou* krańca – ostatka [[G2078]] WTA-GSM **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]]
###### **Dz 1,9**
 **και** *kai* I [[G2532]] [[CONJ]] **ταυτα** *tauta* te [[G5023]] WTD-APN **ειπων** *eipōn* powiedziawszy [[G2036]] WTV-2AAP-NSM **βλεποντων** *blepontōn* patrząc [[G991]] WTV-PAP-GPM **αυτων** *autōn* oni [[G846]] WTP-GPM **επηρθη** *epērthē* został podniesiony [[G1869]] [[V-API-3S]] **και** *kai* i [[G2532]] [[CONJ]] **νεφελη** *nefelē* chmura – obłok [[G3507]] [[N-NSF]] **υπελαβεν** *hypelaben* podjęła – zabrała [[G5274]] WTV-2AAI-3S **αυτον** *auton* Go [[G846]] WTP-ASM **απο** *apo* z [[G575]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **οφθαλμων** *ofthalmōn* oczu [[G3788]] WTN-GPM **αυτων** *autōn* ich [[G846]] WTP-GPM
###### **Dz 1,10**
 **και** *kai* I [[G2532]] [[CONJ]] **ως** *hōs* jak [[G5613]] [[ADV]] **ατενιζοντες** *atenizontes* patrzącymi wprost – którzy skierowali wprost wzrok [[G816]] WTV-PAP-NPM **ησαν** *ēsan* byli [[G2258]] WTV-IXI-3P **εις** *eis* w [[G1519]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **ουρανον** *ouranon* niebo [[G3772]] [[N-ASM]] **πορευομενου** *poreuomenou* idącego [[G4198]] WTV-PNP-GSM **αυτου** *autou* Go [[G846]] [[P-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **ανδρες** *andres* mężowie [[G435]] WTN-NPM **δυο** *dyo* dwaj [[G1417]] WTA-NUI **παρειστηκεισαν** *pareistēkeisan* stanęli przy [[G3936]] WTV-LAI-3P **αυτοις** *autois* nich [[G846]] WTP-DPM **εν** *en* w [[G1722]] [[PREP]] **εσθητι** *esthēti* szacie – odzieniu [[G2066]] [[N-DSF]] **λευκη** *leukē* białej [[G3022]] WTA-DSF
###### **Dz 1,11**
 **οι** *hoi* którzy [[G3739]] WTR-NPM **και** *kai* i [[G2532]] [[CONJ]] **ειπον** *eipon* powiedzieli [[G2036]] WTV-2AAI-3P **ανδρες** *andres* mężowie [[G435]] WTN-VPM **γαλιλαιοι** *galilaioi* Galilejczycy – [przesunąć] [[G1057]] WTN-VPM **τι** *ti* dlaczego [[G5101]] WTI-ASN **εστηκατε** *hestēkate* stoicie [[G2476]] WTV-RAI-2P **εμβλεποντες** *emblepontes* przypatrując się [[G1689]] WTV-PAP-NPM **εις** *eis* w [[G1519]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **ουρανον** *ouranon* niebo [[G3772]] [[N-ASM]] **ουτος** *houtos* Ten [[G3778]] WTD-NSM **ο** *ho* [[G3588]] [[T-NSM]] **ιησους** *iēsous* Jezus – [JHWH jest zbawieniem] [[G2424]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **αναληφθεις** *analēftheis* który został uniesiony – który został wzięty do góry [[G353]] WTV-APP-NSM **αφ** *af* od [[G575]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **εις** *eis* do [[G1519]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **ουρανον** *ouranon* nieba [[G3772]] [[N-ASM]] **ουτως** *houtōs* tak [[G3779]] [[ADV]] **ελευσεται** *eleusetai* przyjdzie [[G2064]] WTV-FDI-3S **ον** *hon* (w) jaki [[G3739]] WTR-ASM **τροπον** *tropon* sposób [[G5158]] [[N-ASM]] **εθεασασθε** *etheasasthe* oglądaliście [[G2300]] WTV-ADI-2P **αυτον** *auton* Go [[G846]] WTP-ASM **πορευομενον** *poreuomenon* idącego – zmierzającego [[G4198]] WTV-PNP-ASM **εις** *eis* do [[G1519]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **ουρανον** *ouranon* nieba [[G3772]] [[N-ASM]]
###### **Dz 1,12**
 **τοτε** *tote* Wtedy [[G5119]] [[ADV]] **υπεστρεψαν** *hypestrepsan* wrócili [[G5290]] WTV-AAI-3P **εις** *eis* do [[G1519]] [[PREP]] **ιερουσαλημ** *ierousalēm* Jeruzalem – [dziedzictwo pokoju] [[G2419]] [[N-PRI]] **απο** *apo* od [[G575]] [[PREP]] **ορους** *orous* góry [[G3735]] [[N-GSN]] **του** *tou* [[G3588]] WTT-GSN **καλουμενου** *kaloumenou* która jest nazywana – która jest zwana [[G2564]] WTV-PPP-GSN **ελαιωνος** *elaiōnos* Oliwną [[G1638]] [[N-GSM]] **ο** *ho* która [[G3739]] WTR-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **εγγυς** *engys* blisko [[G1451]] [[ADV]] **ιερουσαλημ** *ierousalēm* Jeruzalem – [dziedzictwo pokoju] [[G2419]] [[N-PRI]] **σαββατου** *sabbatou* szabatu – [odpoczynek] [[G4521]] [[N-GSN]] **εχον** *echon* mająca [[G2192]] WTV-PAP-ASN **οδον** *hodon* drogę [[G3598]] WTN-ASF
###### **Dz 1,13**
 **και** *kai* I [[G2532]] [[CONJ]] **οτε** *hote* gdy [[G3753]] [[ADV]] **εισηλθον** *eisēlthon* weszli [[G1525]] WTV-2AAI-3P **ανεβησαν** *anebēsan* wstąpili [[G305]] WTV-2AAI-3P **εις** *eis* do [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **υπερωον** *hyperōon* sali na piętrze – górnej izby [[G5253]] WTN-ASN **ου** *hou* gdzie [[G3757]] [[ADV]] **ησαν** *ēsan* byli [[G2258]] WTV-IXI-3P **καταμενοντες** *katamenontes* pozostając – zatrzymując się [[G2650]] WTV-PAP-NPM **ο** *ho* [[G3588]] [[T-NSM]] **τε** *te* zarówno – także [[G5037]] WTPRT **πετρος** *petros* Piotr – [kamyk] [[G4074]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ιακωβος** *iakōbos* Jakub – [pięta] [[G2385]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ιωαννης** *iōannēs* Jan – [JHWH jest łaskawy] [[G2491]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ανδρεας** *andreas* Andrzej – [męski] [[G406]] [[N-NSM]] **φιλιππος** *filippos* Filip – [miłujący konie] [[G5376]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **θωμας** *thōmas* Tomasz – [bliźniak] [[G2381]] [[N-NSM]] **βαρθολομαιος** *bartholomaios* Bartłomiej – [syn Tolmai] [[G918]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ματθαιος** *matthaios* Mateusz – [dar od Boga] [[G3156]] [[N-NSM]] **ιακωβος** *iakōbos* Jakub – [pięta] [[G2385]] [[N-NSM]] **αλφαιου** *halfaiou* (syn) Alfeusza – [zmiana] [[G256]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **σιμων** *simōn* Szymon – [słyszeć] [[G4613]] [[N-NSM]] **ο** *ho* (ten) [[G3588]] [[T-NSM]] **ζηλωτης** *zēlōtēs* zapaleniec – gorliwiec [[G2207]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ιουδας** *ioudas* Judasz – [wielbić] [[G2455]] [[N-NSM]] **ιακωβου** *iakōbou* (syn) Jakuba – [pięta] [[G2385]] [[N-GSM]]
###### **Dz 1,14**
 **ουτοι** *houtoi* Ci [[G3778]] WTD-NPM **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **ησαν** *ēsan* byli [[G2258]] WTV-IXI-3P **προσκαρτερουντες** *proskarterountes* trwającymi niezłomnie [[G4342]] WTV-PAP-NPM **ομοθυμαδον** *homothymadon* jednomyślnie – jednogłośnie [[G3661]] [[ADV]] **τη** *tē* (w) [[G3588]] WTT-DSF **προσευχη** *proseuchē* modlitwie [[G4335]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **τη** *tē* [[G3588]] WTT-DSF **δεησει** *deēsei* prośbie [[G1162]] [[N-DSF]] **συν** *syn* razem z [[G4862]] [[PREP]] **γυναιξιν** *gynaiksin* kobietami [[G1135]] WTN-DPF **και** *kai* i [[G2532]] [[CONJ]] **μαρια** *maria* Marią – [prawd. buntować się] [[G3137]] [[N-DSF]] **τη** *tē* [[G3588]] WTT-DSF **μητρι** *mētri* matką [[G3384]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSM **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **συν** *syn* z [[G4862]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPM **αδελφοις** *adelfois* braćmi [[G80]] WTN-DPM **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Dz 1,15**
 **και** *kai* I [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **ημεραις** *hēmerais* dniach [[G2250]] WTN-DPF **ταυταις** *tautais* tych [[G3778]] WTD-DPF **αναστας** *anastas* wstawszy – podniósłszy się [[G450]] WTV-2AAP-NSM **πετρος** *petros* Piotr – [kamyk] [[G4074]] [[N-NSM]] **εν** *en* w [[G1722]] [[PREP]] **μεσω** *mesō* środku [[G3319]] WTA-DSN **των** *tōn* [[G3588]] WTT-GPM **μαθητων** *mathētōn* uczniów [[G3101]] WTN-GPM **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **τε** *te* zarówno – także [[G5037]] WTPRT **οχλος** *ochlos* tłum [[G3793]] [[N-NSM]] **ονοματων** *onomatōn* imion [[G3686]] WTN-GPN **επι** *epi* na [[G1909]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **αυτο** *auto* tym samym [[G846]] WTP-ASN **ως** *hōs* jak [[G5613]] [[ADV]] **εκατον** *hekaton* sto [[G1540]] WTA-NUI **εικοσιν** *eikosin* dwadzieścia [[G1501]] WTA-NPM
###### **Dz 1,16**
 **ανδρες** *andres* Mężowie [[G435]] WTN-VPM **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **εδει** *edei* trzeba było – należało [[G1163]] WTV-IQI-3S **πληρωθηναι** *plērōthēnai* zostać wypełnionym [[G4137]] WTV-APN **την** *tēn* [[G3588]] WTT-ASF **γραφην** *grafēn* Pismo [[G1124]] WTN-ASF **ταυτην** *tautēn* to [[G3778]] WTD-ASF **ην** *hēn* które [[G3739]] WTR-ASF **προειπεν** *proeipen* wcześniej powiedział [[G4277]] WTV-2AAI-3S **το** *to* [[G3588]] WTT-NSN **πνευμα** *pneuma* Duch [[G4151]] WTN-NSN **το** *to* [[G3588]] WTT-NSN **αγιον** *hagion* Święty [[G40]] WTA-NSN **δια** *dia* przez [[G1223]] [[PREP]] **στοματος** *stomatos* usta [[G4750]] [[N-GSN]] **δαβιδ** *dabid* Dawida – [umiłowany] [[G1138]] [[N-PRI]] **περι** *peri* o [[G4012]] [[PREP]] **ιουδα** *iouda* Judaszu – [wielbić] [[G2455]] [[N-GSM]] **του** *tou* [[G3588]] WTT-GSM **γενομενου** *genomenou* który stał się [[G1096]] WTV-2ADP-GSM **οδηγου** *hodēgou* przewodnikiem [[G3595]] [[N-GSM]] **τοις** *tois* (tych) [[G3588]] WTT-DPM **συλλαβουσιν** *syllabousin* którzy schwytali – którzy ujęli [[G4815]] WTV-2AAP-DPM **τον** *ton* [[G3588]] [[T-ASM]] **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]]
###### **Dz 1,17**
 **οτι** *hoti* że [[G3754]] [[CONJ]] **κατηριθμημενος** *katērithmēmenos* który jest zaliczony [[G2674]] WTV-RPP-NSM **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **συν** *syn* z [[G4862]] [[PREP]] **ημιν** *hēmin* nami [[G2254]] WTP-1DP **και** *kai* i [[G2532]] [[CONJ]] **ελαχεν** *elachen* dostał w udziale – dostał w drodze losowania [[G2975]] WTV-2AAI-3S **τον** *ton* [[G3588]] [[T-ASM]] **κληρον** *klēron* dziedzictwo – los [[G2819]] [[N-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **διακονιας** *diakonias* posługi – służby [[G1248]] [[N-GSF]] **ταυτης** *tautēs* tej [[G3778]] WTD-GSF
###### **Dz 1,18**
 **ουτος** *houtos* Ten [[G3778]] WTD-NSM **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **ουν** *oun* więc [[G3767]] [[CONJ]] **εκτησατο** *ektēsato* nabył [[G2932]] WTV-ADI-3S **χωριον** *chōrion* miejsce – pole [[G5564]] WTN-ASN **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **μισθου** *misthou* zapłaty [[G3408]] [[N-GSM]] **της** *tēs* [[G3588]] [[T-GSF]] **αδικιας** *adikias* niesprawiedliwości – bezprawia [[G93]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **πρηνης** *prēnēs* padł na twarz [[G4248]] [[A-NSM]] **γενομενος** *genomenos* który stał się [[G1096]] WTV-2ADP-NSM **ελακησεν** *elakēsen* pękł – rozerwał się z głośnym hałasem [[G2997]] [[V-AAI-3S]] **μεσος** *mesos* wpół [[G3319]] [[A-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **εξεχυθη** *eksechythē* został wylany (zostały wylane) – został rozsypany (zostały rozsypane) [[G1632]] [[V-API-3S]] **παντα** *panta* wszystkie [[G3956]] WTA-NPN **τα** *ta* [[G3588]] WTT-NPN **σπλαγχνα** *splagchna* wnętrzności [[G4698]] WTN-NPN **αυτου** *autou* jego [[G846]] [[P-GSM]]
###### **Dz 1,19**
 **και** *kai* I [[G2532]] [[CONJ]] **γνωστον** *gnōston* znajome [[G1110]] WTA-NSN **εγενετο** *egeneto* stało się [[G1096]] WTV-2ADI-3S **πασιν** *pasin* wszystkim [[G3956]] WTA-DPM **τοις** *tois* [[G3588]] WTT-DPM **κατοικουσιν** *katoikousin* zamieszkującym [[G2730]] WTV-PAP-DPM **ιερουσαλημ** *ierousalēm* Jeruzalem – [dziedzictwo pokoju] [[G2419]] [[N-PRI]] **ωστε** *hōste* tak, że [[G5620]] [[CONJ]] **κληθηναι** *klēthēnai* zostać nazwanym [[G2564]] WTV-APN **το** *to* [[G3588]] WTT-ASN **χωριον** *chōrion* miejsce – pole [[G5564]] WTN-ASN **εκεινο** *ekeino* to [[G1565]] WTD-ASN **τη** *tē* [[G3588]] WTT-DSF **ιδια** *idia* własną [[G2398]] WTA-DSF **διαλεκτω** *dialektō* mową [[G1258]] [[N-DSF]] **αυτων** *autōn* ich [[G846]] WTP-GPM **ακελδαμα** *akeldama* Akeldama – [pole krwi] [[G184]] [[N-PRI]] **τουτ** *tout* tego [[G5124]] WTD-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **χωριον** *chōrion* miejsce – pole [[G5564]] WTN-ASN **αιματος** *haimatos* krwi [[G129]] [[N-GSN]]
###### **Dz 1,20**
 **γεγραπται** *gegraptai* Jest napisane [[G1125]] WTV-RPI-3S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **βιβλω** *biblō* zwoju – księdze [[G976]] [[N-DSF]] **ψαλμων** *psalmōn* psalmów – pieśni [[G5568]] WTN-GPM **γενηθητω** *genēthētō* niech stanie się [[G1096]] WTV-AOM-3S **η** *hē* [[G3588]] [[T-NSF]] **επαυλις** *epaulis* mieszkanie – siedziba [[G1886]] [[N-NSF]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **ερημος** *erēmos* puste [[G2048]] WTA-NSF **και** *kai* i [[G2532]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **εστω** *estō* niech jest [[G2077]] WTV-PXM-3S **ο** *ho* [[G3588]] [[T-NSM]] **κατοικων** *katoikōn* zamieszkujący [[G2730]] [[V-PAP-NSM]] **εν** *en* w [[G1722]] [[PREP]] **αυτη** *autē* niej [[G846]] WTP-DSF **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **επισκοπην** *episkopēn* doglądanie – dozorowanie [[G1984]] WTN-ASF **αυτου** *autou* jego [[G846]] [[P-GSM]] **λαβοι** *laboi* oby wziął – oby otrzymał [[G2983]] WTV-2AAO-3S **ετερος** *heteros* inny [[G2087]] [[A-NSM]]
###### **Dz 1,21**
 **δει** *dei* Trzeba – Jest konieczne [[G1163]] WTV-PQI-3S **ουν** *oun* więc [[G3767]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPM **συνελθοντων** *synelthontōn* którzy zeszli się [[G4905]] WTV-2AAP-GPM **ημιν** *hēmin* (do) nas [[G2254]] WTP-1DP **ανδρων** *andrōn* mężów [[G435]] WTN-GPM **εν** *en* w [[G1722]] [[PREP]] **παντι** *panti* całym [[G3956]] WTA-DSM **χρονω** *chronō* czasie [[G5550]] WTN-DSM **εν** *en* w [[G1722]] [[PREP]] **ω** *hō* którym [[G3739]] WTR-DSM **εισηλθεν** *eisēlthen* wszedł [[G1525]] WTV-2AAI-3S **και** *kai* i [[G2532]] [[CONJ]] **εξηλθεν** *eksēlthen* wyszedł [[G1831]] WTV-2AAI-3S **εφ** *ef* przed [[G1909]] [[PREP]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **ιησους** *iēsous* Jezus – [JHWH jest zbawieniem] [[G2424]] [[N-NSM]]
###### **Dz 1,22**
 **αρξαμενος** *arksamenos* zacząwszy [[G756]] WTV-AMP-NSM **απο** *apo* od [[G575]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **βαπτισματος** *baptismatos* zanurzenia [[G908]] [[N-GSN]] **ιωαννου** *iōannou* Jana – [JHWH jest łaskawy] [[G2491]] [[N-GSM]] **εως** *heōs* aż do [[G2193]] [[CONJ]] **της** *tēs* [[G3588]] [[T-GSF]] **ημερας** *hēmeras* dnia [[G2250]] [[N-GSF]] **ης** *hēs* którego [[G3739]] [[R-GSF]] **ανεληφθη** *anelēfthē* został uniesiony – został wzięty do góry [[G353]] [[V-API-3S]] **αφ** *af* od [[G575]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP **μαρτυρα** *martyra* świadkiem [[G3144]] [[N-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **αναστασεως** *anastaseōs* powstania – wzbudzenia [[G386]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **γενεσθαι** *genesthai* stać się [[G1096]] WTV-2ADN **συν** *syn* razem z [[G4862]] [[PREP]] **ημιν** *hēmin* nami [[G2254]] WTP-1DP **ενα** *hena* jeden [[G1520]] WTA-ASM **τουτων** *toutōn* (z) tych [[G5130]] WTD-GPM
###### **Dz 1,23**
 **και** *kai* I [[G2532]] [[CONJ]] **εστησαν** *hestēsan* postawili [[G2476]] WTV-2AAI-3P **δυο** *dyo* dwaj [[G1417]] WTA-NUI **ιωσηφ** *iōsēf* Józefa – [On powiększył] [[G2501]] [[N-PRI]] **τον** *ton* [[G3588]] [[T-ASM]] **καλουμενον** *kaloumenon* który jest nazywany – który jest zwany [[G2564]] WTV-PPP-ASM **βαρσαβαν** *barsaban* Barsabą – [syn pragnienia] [[G923]] [[N-ASM]] **ος** *hos* który [[G3739]] WTR-NSM **επεκληθη** *epeklēthē* został przezywany [[G1941]] [[V-API-3S]] **ιουστος** *ioustos* Justus – [tylko] [[G2459]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ματθιαν** *matthian* Mattiasza – [dar YH] [[G3159]] [[N-ASM]]
###### **Dz 1,24**
 **και** *kai* I [[G2532]] [[CONJ]] **προσευξαμενοι** *proseuksamenoi* pomodliwszy się [[G4336]] WTV-ADP-NPM **ειπον** *eipon* powiedzieli [[G2036]] WTV-2AAI-3P **συ** *sy* Ty [[G4771]] WTP-2NS **κυριε** *kyrie* Panie [[G2962]] WTN-VSM **καρδιογνωστα** *kardiognōsta* znawco serca – znawco życia wewnętrznego [[G2589]] WTN-VSM **παντων** *pantōn* wszystkich [[G3956]] WTA-GPM **αναδειξον** *anadeikson* wskaż – ukaż [[G322]] WTV-AAM-2S **εκ** *ek* z [[G1537]] [[PREP]] **τουτων** *toutōn* tych [[G5130]] WTD-GPM **των** *tōn* [[G3588]] WTT-GPM **δυο** *dyo* dwóch [[G1417]] WTA-NUI **ον** *hon* którego [[G3739]] WTR-ASM **ενα** *hena* jednego [[G1520]] WTA-ASM **εξελεξω** *ekseleksō* wybrałeś sobie [[G1586]] WTV-AMI-2S
###### **Dz 1,25**
 **λαβειν** *labein* (By) wziąć [[G2983]] [[V-2AAN]] **τον** *ton* [[G3588]] [[T-ASM]] **κληρον** *klēron* dziedzictwo – los [[G2819]] [[N-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **διακονιας** *diakonias* posługi – służby [[G1248]] [[N-GSF]] **ταυτης** *tautēs* tej [[G3778]] WTD-GSF **και** *kai* i [[G2532]] [[CONJ]] **αποστολης** *apostolēs* wysłannictwa [[G651]] [[N-GSF]] **εξ** *eks* od [[G1537]] [[PREP]] **ης** *hēs* którego [[G3739]] [[R-GSF]] **παρεβη** *parebē* przekroczył – odszedł na bok [[G3845]] WTV-2AAI-3S **ιουδας** *ioudas* Judasz – [wielbić] [[G2455]] [[N-NSM]] **πορευθηναι** *poreuthēnai* (żeby) pójść [[G4198]] WTV-AON **εις** *eis* ku [[G1519]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **τοπον** *topon* miejscu [[G5117]] [[N-ASM]] **τον** *ton* [[G3588]] [[T-ASM]] **ιδιον** *idion* własnemu [[G2398]] WTA-ASM
###### **Dz 1,26**
 **και** *kai* I [[G2532]] [[CONJ]] **εδωκαν** *edōkan* dali [[G1325]] WTV-AAI-3P **κληρους** *klērous* losy [[G2819]] [[N-APM]] **αυτων** *autōn* ich [[G846]] WTP-GPM **και** *kai* i [[G2532]] [[CONJ]] **επεσεν** *epesen* padł [[G4098]] WTV-2AAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **κληρος** *klēros* los [[G2819]] [[N-NSM]] **επι** *epi* na [[G1909]] [[PREP]] **ματθιαν** *matthian* Mattiasza – [dar YH] [[G3159]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **συγκατεψηφισθη** *sygkatepsēfisthē* został dołączony – został wspólnie uznany [[G4785]] [[V-API-3S]] **μετα** *meta* z [[G3326]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **ενδεκα** *hendeka* jedenastoma [[G1733]] WTA-NUI **αποστολων** *apostolōn* wysłannikami [[G652]] WTN-GPM
