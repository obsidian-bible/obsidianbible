# Iz 2 BT5
###### **Iz 2,1**
 Widzenie Izajasza, syna Amosa, dotyczące Judy i Jerozolimy.
###### **Iz 2,2**
 Stanie się na końcu czasów, że góra świątyni Pańskiejstać będzie mocno na szczycie góri wystrzeli ponad pagórki.Wszystkie narody do niej popłyną,
###### **Iz 2,3**
 mnogie ludy pójdą i rzekną:«***Chodźcie, wstąpmy na górę Pańską, do świątyni Boga Jakuba!Niech nas nauczy dróg swoich, byśmy kroczyli Jego ścieżkami. Bo Prawo pochodzi z Syjonui słowo Pańskie – z Jeruzalem***».
###### **Iz 2,4**
 On będzie rozjemcą pomiędzy ludamii sędzią dla licznych narodów. Wtedy swe miecze przekują na lemiesze, a swoje włócznie na sierpy. Naród przeciw narodowi nie podniesie miecza, nie będą się więcej zaprawiać do wojny.
###### **Iz 2,5**
 Chodźcie, domu Jakuba, postępujmy w światłości Pańskiej!
###### **Iz 2,6**
 Zaiste, odrzuciłeś Twój lud, dom Jakuba, bo pełen jest wróżbitówi wieszczków, jak Filistyni; na zgodę uderza w ręce cudzoziemców.
###### **Iz 2,7**
 Kraj jego pełen jest srebra i złota, a skarby jego są niezliczone. Kraj jego pełen jest koni, a wozy jego nieprzeliczone.
###### **Iz 2,8**
 Kraj jego pełen jest bożków.[Oni] wielbią rąk swoich dzieło, które wykonały ich palce.
###### **Iz 2,9**
 Poniżył się człowiek, upodlił śmiertelny; nie przebaczaj im!
###### **Iz 2,10**
  Wejdź między skały, ukryj się w prochuze strachu przed Panem, przed blaskiem Jego majestatu.
###### **Iz 2,11**
 Wyniosłe oczy człowieka się ukorząi duma ludzka będzie poniżona. Sam tylko Pan się wywyższydnia owego.
###### **Iz 2,12**
 Albowiem dzień Pana Zastępów nadejdzieprzeciw wszystkim pysznym i nadętymi przeciw wszystkim hardym, by się ukorzyli,
###### **Iz 2,13**
 przeciw wszystkim cedrom Libanu, wysoko się wzbijającym, i przeciw wszystkim dębom Baszanu,
###### **Iz 2,14**
 przeciw wszystkim górom niebotycznymi przeciw wszystkim pagórkom wyniosłym,
###### **Iz 2,15**
 przeciw każdej wieży strzelisteji przeciw wszystkim murom obronnym,
###### **Iz 2,16**
 przeciw wszystkim okrętom Tarsziszi przeciw wszystkim statkom zbytkownym.
###### **Iz 2,17**
 Wtedy pycha człowieka będzie poniżonai upokorzona ludzka wyniosłość. Sam tylko Pan się wywyższydnia owego,
###### **Iz 2,18**
 posągi zaś bożków całkowicie znikną.
###### **Iz 2,19**
 Wtedy wejdą do jaskiń skalnychi do jam podziemnychze strachu przed Panem, przed blaskiem Jego majestatu, kiedy powstanie, by przerazić ziemię.
###### **Iz 2,20**
 Owego dnia człowiek wyrzuci kretom i nietoperzombożki swe srebrne i bałwany złote, zrobione po to, by im cześć oddawał,
###### **Iz 2,21**
 gdy wejdzie między rozpadliny skalnei w szczeliny opokize strachu przed Panemi przed blaskiem Jego majestatu, kiedy powstanie, by przerazić ziemię.
###### **Iz 2,22**
 Zaniechajcie człowieka, który ledwie dech ma w nozdrzach. Bo ile on wart?
# Iz 2 PAU
###### **Iz 2,1**
 Widzenie Izajasza, syna Amosa, o Judzie i Jeruzalem.
###### **Iz 2,2**
 Tak będzie przy końcu czasów: Góra świątyni PANA będzie utwierdzona jako pierwsza między górami i wyniesiona ponad wzgórza. Popłyną do niej wszystkie narody,
###### **Iz 2,3**
 wiele ludów przyjdzie i powie: „Chodźcie, wejdźmy na górę PANA, do świątyni Boga Jakuba! On nas nauczy dróg swoich, abyśmy chodzili Jego ścieżkami!”. Bo z Syjonu wyjdzie nauka i słowo PANA z Jeruzalem.
###### **Iz 2,4**
 On będzie sędzią narodów i rozjemcą wielu ludów. Wtedy przekują swoje miecze na lemiesze, a swoje włócznie na sierpy. Naród przeciw narodowi nie podniesie miecza i nie będą się już uczyć sztuki wojennej.
###### **Iz 2,5**
 Domu Jakuba! Chodźcie! Postępujmy w światłości PANA!
###### **Iz 2,6**
 Lecz odrzuciłeś swój lud, dom Jakuba, gdyż pełno jest w nim wróżbitów i wieszczków - jak u Filistynów, i wchodzi w układy z obcymi.
###### **Iz 2,7**
 Jego kraj jest pełen srebra i złota, nieprzebrane są jego skarby, szczyci się liczną konnicą i niezliczoną ilością rydwanów.
###### **Iz 2,8**
 W kraju tym pełno bożków, kłaniają się dziełom rąk własnych, temu, co wykonały ich palce.
###### **Iz 2,9**
 Człowiek tak się poniżył, śmiertelnik upadł tak nisko, że im nie wybaczysz.
###### **Iz 2,10**
 Wejdź między skały, ukrywaj się w prochu z lęku przed PANEM i przed blaskiem Jego majestatu, gdy powstanie, aby przerazić ziemię.
###### **Iz 2,11**
 On upokorzy oczy pyszałków, poniży pychę człowieka. W tym dniu tylko PAN się wywyższy!
###### **Iz 2,12**
 Bo jest to Dzień PANA Zastępów przeciw wszystkiemu, co pyszne, wyniosłe, przeciwko wszystkiemu, co harde - aby zostało ugięte;
###### **Iz 2,13**
 i przeciw wszystkim cedrom Libanu wybujałym i wyniosłym, przeciwko wszystkim dębom Baszanu;
###### **Iz 2,14**
 i przeciw wszystkim górom wysokim i wszystkim wzgórzom wyniosłym;
###### **Iz 2,15**
 przeciwko każdej wysokiej wieży i wszystkim murom warownym;
###### **Iz 2,16**
 i przeciw wszystkim okrętom z Tarszisz i wszelkim statkom pełnym przepychu!
###### **Iz 2,17**
 Pycha człowieka zostanie złamana, a duma ludzka - poniżona. W tym dniu tylko PAN się wywyższy.
###### **Iz 2,18**
 Bożki zaś znikną zupełnie.
###### **Iz 2,19**
 Wejdą do jaskiń skalnych i do jam podziemnych z lęku przed PANEM i przed blaskiem Jego majestatu, gdy powstanie, aby przerazić ziemię.
###### **Iz 2,20**
 W tym dniu człowiek wyrzuci dla kretów i nietoperzy swoje bożki ze srebra i złota, które uczynił, aby im się kłaniać.
###### **Iz 2,21**
 Wtedy wejdzie w szczeliny skalne z lęku przed PANEM i blaskiem Jego majestatu, gdy powstanie, aby przerazić ziemię.
###### **Iz 2,22**
 „Przestańcie polegać na ludziach! Nie mają nic oprócz tchnienia w nozdrzach - jakże więc można na nich liczyć?”.
# Iz 2 BP
###### **Iz 2,1**
 Los [przyszły] Judy i Jeruzalem, który oglądał Izajasz, syn Amoca:
###### **Iz 2,2**
 Stanie się w czasach późniejszych, że góra Domu Jahwe stać będzie utwierdzona na szczycie najwyższym i wyniesiona nad wzgórza. Popłyną do niej wszystkie narody,
###### **Iz 2,3**
 wiele ludów zdążać będzie i mówić: - Pójdźmy i wstąpmy na górę Jahwe, do Domu Boga Jakuba, by On nas dróg swoich nauczył, byśmy Jego ścieżkami chodzili! Z Syjonu bowiem wyjdzie Nauka i Słowo Jahwe - z Jeruzalem.
###### **Iz 2,4**
 On będzie sądził narody, Prawo wielu ludom ogłosi. Przekują swe miecze na pługi, a włócznie swoje na sierpy. Nie wzniesie naród miecza przeciw narodowi, już się nie będą zbroić do wojen.
###### **Iz 2,5**
 Naprzód więc, Domu Jakuba! Postępujmy w światłości Jahwe;
###### **Iz 2,6**
 Lecz odtrąciłeś swój lud, Dom Jakuba. Pełen jest bowiem [obyczajów] Wschodu, wróżbiarzy - na wzór Filistynów, i wchodzi w związki z obcymi.
###### **Iz 2,7**
 Kraj jego pełen jest srebra i złota, a jego skarby są nieprzebrane. Kraina pełna rumaków [bojowych] i niezliczonych wozów wojennych.
###### **Iz 2,8**
 Pełno jest w jego kraju bożyszczy, biją pokłony przed tworem rąk własnych, dziełem własnych palców.
###### **Iz 2,9**
 [Dlatego] ugnie się człowiek, mąż zostanie poniżony, (a Ty im nie darujesz).
###### **Iz 2,10**
 Wchodź między skały i w prochu się ukryj z trwogi przed Jahwe, przed blaskiem jego potęgi, gdy On powstanie, by ziemię porazić
###### **Iz 2,11**
 Oczy pyszałków ukorzone będą i pycha ludzka zostanie złamana, a sam tylko Jahwe dnia tego ujawni swój majestat.
###### **Iz 2,12**
 Bo [przyjdzie] dzień Jahwe Zastępów, [dzień sądu] nad wszystkim, co pyszne i dumne, nad tym, co harde - bo będzie ugięte,
###### **Iz 2,13**
 i nad wszystkimi cedrami Libanu wybujałymi i wyniosłymi, i nad wszystkimi dębami Baszanu,
###### **Iz 2,14**
 górami, co się piętrzą wysoko, nad wszelkimi wyniosłymi wzgórzami,
###### **Iz 2,15**
 nad wszelką wieżycą wysoką i każdym murem warownym,
###### **Iz 2,16**
 nad wszystkimi okrętami Tarszisz i wszelkim zbytkownym przedmiotem.
###### **Iz 2,17**
 Pycha człowieka zostanie ugięta, ludzka wyniosłość będzie poniżona, a sam tylko Jahwe dnia tego ujawni swój majestat.
###### **Iz 2,18**
 Wtedy zupełnie znikną bożyszcza.
###### **Iz 2,19**
 Do jaskiń skalnych powchodzą, do dołów [wykopanych w] ziemi z trwogi przed Jahwe, przed blaskiem Jego potęgi, gdy On powstanie, by porazić ziemię.
###### **Iz 2,20**
 Dnia tego człowiek wyrzuci kretom i nietoperzom swych bożków ze srebra i złota, których sporządził, by bić im pokłony.
###### **Iz 2,21**
 [Sam zaś] wejdzie w rozpadliny skalne i do szczelin wśród głazów z trwogi przed Jahwe, przed blaskiem Jego potęgi, gdy On powstanie, by porazić ziemię.
###### **Iz 2,22**
 Przestańcie polegać na człowieku, który nie ma nic prócz tchu w nozdrzach. Bo cóż może mieć za znaczenie?
# Iz 2 BR
###### **Iz 2,1**
 Izajasz, syn Amosa takie miał widzenie dotyczące Judy i Jeruzalem.
###### **Iz 2,2**
 Dojdzie kiedyś do tego, że wzgórze Świątyni Pana znów widnieć będzie dumnie ponad gór łańcuchem, przewyższając wszystkie pozostałe szczyty.
###### **Iz 2,3**
 I będą tam przybywać wszystkie narody, ludy rozliczne przybędą wołając: Chodźmy, udajmy się na Górę Pańską! Wejdźmy do świątyni Boga Jakuba, aby nas nauczył dróg swoich i abyśmy mogli chodzić Jego ścieżkami. Z Syjonu bowiem przyjdzie Prawo, z Jeruzalem - wyrocznia Pana.
###### **Iz 2,4**
 Będzie sprawował swą władzę nad ludami i rozsądzał sprawy bardzo wielu narodów, które swoje miecze na lemiesze przekują a włócznie na sierpy zamienią. I nie będą już narody na się mieczy podnosić, ani też zaprawiać się więcej do wojny.
###### **Iz 2,5**
 Przyjdźcie więc, domu Jakuba, zacznijmy chodzić w światłości Pana.
###### **Iz 2,6**
 To prawda, że odrzuciłeś swój lud, cały dom Jakuba. Kraj pełen jest wróżbitów i czarowników jak Filistyni, a pokój zależy od cudzoziemców.
###### **Iz 2,7**
 Kraj jego jest pełen srebra i złota tudzież przeogromnych skarbów. W kraju jest też mnóstwo koni i niezliczone ilości rydwanów.
###### **Iz 2,8**
 Ale pełno w tym kraju także bożków cudzych. Ludzie cześć oddają dziełom ich rąk własnych kłaniają się temu, co zrobiły ich palce.
###### **Iz 2,9**
 Śmiertelnik sam się upokorzy, poniży się człowiek; obyś im więcej nie wybaczał tego.
###### **Iz 2,10**
 Uchodź więc między skały, ukryj się w prochu ziemi przed obliczem strasznego Pana, przed blaskiem Jego majestatu, kiedyś się podniesie, aby drżeniem napełnić całą ziemię.
###### **Iz 2,11**
 I spuści pyszałek swe wyniosłe oczy i będzie upokorzona pycha człowiecza. Jeden Bóg będzie wywyższony w dniu owym.
###### **Iz 2,12**
 A będzie to dzień Pana Zastępów wyznaczony na strącenie wszelkiej wielkości.
###### **Iz 2,13**
 I na połamania wszystkich cedrów Libanu oraz rozłożystych dębów Baszanu.
###### **Iz 2,14**
 Na wyrównanie wszystkich górskich szczytów i wszystkich znaczniejszych wzniesień.
###### **Iz 2,15**
 Na zburzenie wszystkich wież wysokich i murów warownych na skarpach.
###### **Iz 2,16**
 Na zniszczenie wszystkich okrętów Tarszisz i wszystkich cennych przedmiotów.
###### **Iz 2,17**
 I będzie upokorzona wyniosłość człowiecza i poniżona zarozumiałość ludzka i tylko jeden Bóg będzie wywyższony w dniu owym,
###### **Iz 2,18**
 znikną zaś posągi wszystkich obcych bożków.
###### **Iz 2,19**
 Udajcie się wtedy do rozpadlin skalnych szukajcie schronienia w podziemnych jaskiniach przed obliczem Strasznego Pana przed blaskiem Jego Majestatu kiedy się podniesie, aby drżeniem napełnić całą ziemię.
###### **Iz 2,20**
 Za dni owych wyrzuci człowiek kretom i nietoperzom posążki bogów ze srebra, oraz idole ze złota, które zrobił sobie kiedyś po to, żeby im chwałę oddawać.
###### **Iz 2,21**
 I schroni się w rozpadlinach skalnych oraz w podziemnych jaskiniach, schowa się przed obliczem Strasznego Pana, przed blaskiem Jego Majestatu, kiedy się podniesie, aby drżeniem napełnić ziemię.
###### **Iz 2,22**
 Przestańcie więc całą ufność pokładać w człowieku, który ma zaledwie dech w swoich nozdrzach. Jakże więc można liczyć na niego?
# Iz 2 WUJ
###### **Iz 2,1**
 Słowo, które widział Izajasz syn Amos, nad Judą i Jeruzalem.
###### **Iz 2,2**
 I będzie w ostateczne dni przygotowana góra domu Pańskiego na wierzchu gór, i wywyższy się nad pagórki, a popłyną do niej wszyscy narodowie.
###### **Iz 2,3**
 Pójdą też wiele ludzi, i rzekną: Chodźcie a wstąpmy na górę Pańską, i do domu Boga Jakóbowego, a nauczy nas dróg swoich, i będziemy chodzić ścieżkami jego, bo z Sionu wynidzie zakon, a słowo Pańskie z Jeruzalem.
###### **Iz 2,4**
 I będzie sądził narody, i będzie strofował ludzi wiele: i przekują miecze swe na lemiesze, a włócznie swe na sierpy: nie podniesie miecza naród przeciw narodowi: ani się będą więcej ćwiczyć ku bitwie.
###### **Iz 2,5**
 Domie Jakobów pódźcie, a chodźmy w światłości Pańskiej.
###### **Iz 2,6**
 Abowiem porzuciłeś twój lud, dom Jakobów, iż pełni są jako przedtem, i mieli wieszczki jako Filistynowie, a dzieci się cudzych jęli.
###### **Iz 2,7**
 Napełniona jest ziemia srebra i złota: i niemasz końca skarbom jego: i napełniła się ziemia jego koni, i niemasz liczby poczwórnych jego.
###### **Iz 2,8**
 I napełniła się ziemia jego bałwanów: kłaniali się dziełu rąk swoich, które uczyniły palce ich.
###### **Iz 2,9**
 I kłaniał się człowiek, i uniżał się mąż: przetoż nie odpuszczaj im.
###### **Iz 2,10**
 Wnidź do skały, a skryj się w wykopanej ziemi przed obliczem strachu Pańskiego i przed jasnością majestatu jego.
###### **Iz 2,11**
 Oczy wyniosłe człowiecze zniżone są, i nachylona będzie wysokość mężów: a sam Pan wywyższy się w on dzień.
###### **Iz 2,12**
 Bo dzień Pana zastępów na każdego pysznego i wysokiego, i na każdego hardego: i zniżon będzie:
###### **Iz 2,13**
 I na wszystkie cedry Libanu wysokie i wyniosłe, i na wszystkie dęby Basan:
###### **Iz 2,14**
 I na wszystkie góry wysokie, i na wszystkie pagórki wyniosłe:
###### **Iz 2,15**
 I na każdą wieżę wysoką, i na każdy mur obronny:
###### **Iz 2,16**
 I na wszystkie okręty Tharsis, i na wszystko co jest piękne ku widzeniu.
###### **Iz 2,17**
 I będzie nachylona wyniosłość ludzi, i uniżona będzie wysokość mężów, a sam Pan wywyższy się w on dzień:
###### **Iz 2,18**
 A bałwany do szczątka będą pokruszone:
###### **Iz 2,19**
 I wnidą do jaskiń skalnych, i do przepaści ziemie przed obliczem strachu Pańskiego, i przed chwałą majestatu jego, gdy powstanie, aby karał ziemię.
###### **Iz 2,20**
 W on dzień porzuci człowiek bałwany srebra swego, i wyobrażenia złota swego, który był sobie sprawił, aby się im kłaniał, krety i nietoperze.
###### **Iz 2,21**
 I wnidzie w rozpadliny skalne, i w maclochy kamienne przed obliczem strachu Pana, i przed chwałą majestatu jego, gdy powstanie, aby karał ziemię.
###### **Iz 2,22**
 A tak miejcie pokój z człowiekiem, którego dech jest w nozdrzach jego, bo poczytan jest on za wysokiego.
