# Ga 3 BT5
###### **Ga 3,1**
 O, nierozumni Galaci! Któż was urzekł, was, przed których oczami nakreślono obraz Jezusa Chrystusa ukrzyżowanego?
###### **Ga 3,2**
 Tego jednego chciałbym się od was dowiedzieć, czy Ducha otrzymaliście dzięki uczynkom wymaganym przez Prawo, czy z powodu posłuszeństwa wierze?
###### **Ga 3,3**
 Czyż jesteście aż tak nierozumni, że zacząwszy duchem, chcecie teraz kończyć ciałem?
###### **Ga 3,4**
 Czyż tak wielkich rzeczy doznaliście na próżno? A byłoby to rzeczywiście na próżno.
###### **Ga 3,5**
 Czy Ten, który udziela wam Ducha i działa cuda wśród was, [czyni to] dzięki uczynkom wymaganym przez Prawo, czy też z powodu posłuszeństwa wierze?
###### **Ga 3,6**
 W taki sam sposób Abraham uwierzył Bogu, i to mu policzono za sprawiedliwość.
###### **Ga 3,7**
 Zrozumiejcie zatem, że ci, którzy polegają na wierze, ci są synami Abrahama.
###### **Ga 3,8**
 I stąd Pismo, widząc, że w przyszłości Bóg dzięki wierze będzie dawał poganom usprawiedliwienie, już Abrahamowi oznajmiło tę radosną nowinę: W tobie będą błogosławione wszystkie narody.
###### **Ga 3,9**
 I dlatego ci, którzy żyją dzięki wierze, mają uczestnictwo w błogosławieństwie wraz z Abrahamem, który dał posłuch wierze.
###### **Ga 3,10**
 Natomiast na tych wszystkich, którzy polegają na uczynkach wymaganych przez Prawo, ciąży przekleństwo. Napisane jest bowiem: Przeklęty każdy, kto nie wypełnia wytrwale wszystkiego, co nakazuje wykonać Księga Prawa.
###### **Ga 3,11**
 A że w Prawie nikt nie osiąga usprawiedliwienia przed Bogiem, wynika stąd, że sprawiedliwy żyć będzie dzięki wierze.
###### **Ga 3,12**
 Prawo zaś nie uwzględnia wiary, lecz [mówi]: Kto wypełnia przepisy, dzięki nim żyć będzie.
###### **Ga 3,13**
 Z tego przekleństwa Prawa Chrystus nas wykupił – stawszy się za nas przekleństwem, bo napisane jest: Przeklęty każdy, którego powieszono na drzewie –
###### **Ga 3,14**
 aby błogosławieństwo Abrahama stało się w Chrystusie Jezusie udziałem pogan i abyśmy przez wiarę otrzymali obiecanego Ducha.
###### **Ga 3,15**
  Bracia, użyję przykładu ze stosunków między ludźmi. Nikt nie obala ani nie zmienia testamentu prawnie sporządzonego, choć jest on jedynie dziełem ludzkim.
###### **Ga 3,16**
 Otóż to właśnie Abrahamowi i jego potomstwu dano obietnice. I nie mówi [Pismo]: "i potomkom", co wskazywałoby na wielu, ale [wskazano] na jednego: i potomkowi twojemu, którym jest Chrystus.
###### **Ga 3,17**
 A chcę przez to powiedzieć: testamentu, uprzednio przez Boga prawnie ustanowionego, Prawo, które powstało czterysta trzydzieści lat później, nie może obalić, tak by unieważnić obietnicę.
###### **Ga 3,18**
 Bo gdyby dziedzictwo pochodziło z Prawa, tym samym nie mogłoby pochodzić z obietnicy. A tymczasem przez obietnicę Bóg okazał łaskę Abrahamowi.
###### **Ga 3,19**
 Na cóż więc Prawo? Zostało ono dodane ze względu na przestępstwa aż do przyjścia Potomka, któremu udzielono obietnicy; przekazane zostało przez aniołów; podane przez pośrednika.
###### **Ga 3,20**
 Pośrednika jednak nie potrzeba, gdy chodzi o jedną osobę, a Bóg właśnie jest sam jeden.
###### **Ga 3,21**
 A czy może Prawo to sprzeciwia się obietnicom Bożym? Żadną miarą! Gdyby mianowicie dane było Prawo, mające moc udzielania życia, wówczas rzeczywiście usprawiedliwienie płynęłoby z Prawa.
###### **Ga 3,22**
 Lecz Pismo poddało wszystko pod [władzę] grzechu, aby obietnica dostała się dzięki wierze w Jezusa Chrystusa tym, którzy wierzą.
###### **Ga 3,23**
 Do czasu przyjścia wiary byliśmy poddani pod straż Prawa i trzymani w zamknięciu aż do przyszłego objawienia się wiary.
###### **Ga 3,24**
 Tym sposobem Prawo stało się dla nas wychowawcą, [który miał prowadzić] ku Chrystusowi, abyśmy dzięki wierze uzyskali usprawiedliwienie.
###### **Ga 3,25**
 Gdy jednak wiara nadeszła, już nie jesteśmy poddani wychowawcy.
###### **Ga 3,26**
 Wszyscy bowiem przez wiarę jesteście synami Bożymi – w Chrystusie Jezusie.
###### **Ga 3,27**
 Bo wy wszyscy, którzy zostaliście ochrzczeni w Chrystusie, przyoblekliście się w Chrystusa.
###### **Ga 3,28**
 Nie ma już Żyda ani poganina, nie ma już niewolnika ani człowieka wolnego, nie ma już mężczyzny ani kobiety, wszyscy bowiem jesteście kimś jednym w Chrystusie Jezusie.
###### **Ga 3,29**
 Jeżeli zaś należycie do Chrystusa, to jesteście też potomstwem Abrahama, dziedzicami zgodnie z obietnicą.
# Ga 3 PAU
###### **Ga 3,1**
 O nierozumni Galaci! Kto was zaślepił? Czy wasze oczy nie patrzyły na Jezusa Chrystusa ukrzyżowanego?
###### **Ga 3,2**
 Wytłumaczcie mi jedno: Czy otrzymaliście Ducha dzięki przestrzeganiu Prawa, czy też dlatego, że posłuchaliście orędzia wiary?
###### **Ga 3,3**
 Czy tak nierozumni jesteście, że zaczęliście od Ducha, a kończycie teraz ciałem?
###### **Ga 3,4**
 Czy tak wielkich rzeczy doświadczyliście na próżno? Bo jeśli tak, to rzeczywiście na próżno!
###### **Ga 3,5**
 Czy Ten, który udziela wam Ducha i dokonuje w was wielkich znaków, czyni tak dlatego, że wypełniacie Prawo, czy też dlatego, że przyjęliście głoszoną wiarę?
###### **Ga 3,6**
 Abraham uwierzył Bogu, który właśnie za to uznał go za sprawiedliwego.
###### **Ga 3,7**
 Wiedzcie więc, że tylko ci, którzy wierzą, są synami Abrahama.
###### **Ga 3,8**
 Właśnie Pismo, które przewidziało, że Bóg usprawiedliwi pogan dzięki wierze, ogłosiło Abrahamowi radosną nowinę: Przez ciebie otrzymają błogosławieństwo wszystkie ludy ziemi.
###### **Ga 3,9**
 Tak więc ci, którzy wierzą, są błogosławieni na równi z Abrahamem, który uwierzył.
###### **Ga 3,10**
 Ci natomiast, którzy powołują się na przestrzeganie Prawa, podlegają przekleństwu. Napisane jest bowiem: Przeklęty każdy, kto nie wypełnia wszystkich przepisów księgi Prawa.
###### **Ga 3,11**
 Jest oczywiste, że nikt nie zostanie usprawiedliwiony przed Bogiem dzięki Prawu, ponieważ: Sprawiedliwy będzie żyć z wiary.
###### **Ga 3,12**
 Prawo zaś nie opiera się na wierze, ale mówi: Kto wypełnia przepisy Prawa, dzięki nim żyć będzie.
###### **Ga 3,13**
 Chrystus wyzwolił nas od przekleństwa Prawa - gdy stał się dla nas przekleństwem, bo jest napisane: Przeklęty każdy, kto zawisł na drzewie -
###### **Ga 3,14**
 aby błogosławieństwo Abrahama stało się w Chrystusie Jezusie udziałem narodów i abyśmy dzięki wierze otrzymali obiecanego Ducha.
###### **Ga 3,15**
 Bracia, odwołam się do zwyczajów ludzi. Nawet ludzkiego testamentu ważnie sporządzonego nikt nie może unieważnić ani zmienić.
###### **Ga 3,16**
 Otóż obietnice zostały przekazane Abrahamowi i jego potomstwu. Nie powiedziano: „i potomkom”, jak gdyby miały dotyczyć wielu, ale jednego: i potomkowi twemu. Jest nim Chrystus.
###### **Ga 3,17**
 Powiadam więc: Testamentu uwiarygodnionego przez Boga nie może unieważnić Prawo ustanowione czterysta trzydzieści lat później i w ten sposób zniweczyć obietnicę.
###### **Ga 3,18**
 Bo gdyby dziedzictwo otrzymywało się dzięki Prawu, to wtedy nie na podstawie obietnicy. A właśnie przez obietnicę Bóg okazał łaskę Abrahamowi.
###### **Ga 3,19**
 Po co więc Prawo? Zostało dodane ze względu na wykroczenia, do czasu przyjścia potomka, dla którego przeznaczona była obietnica. Zostało podane przez aniołów na ręce pośrednika.
###### **Ga 3,20**
 Nie ma jednak pośrednika, gdy jest tylko jedna osoba. A Bóg jest jeden.
###### **Ga 3,21**
 Czy więc Prawo przeciwstawia się Bożym obietnicom? Ależ nie! Gdyby bowiem zostało dane Prawo, które miałoby moc udzielania życia, wtedy usprawiedliwienie pochodziłoby z Prawa.
###### **Ga 3,22**
 Ale Pismo zamknęło wszystko pod władzą grzechu, aby dzięki wierze w Jezusa Chrystusa obietnica urzeczywistniła się w tych, którzy wierzą.
###### **Ga 3,23**
 Zanim nadszedł czas wiary, żyliśmy pod władzą Prawa zamknięci w oczekiwaniu objawienia się wiary.
###### **Ga 3,24**
 W ten sposób Prawo stało się naszym opiekunem aż do czasu przyjścia Chrystusa, abyśmy mogli otrzymać usprawiedliwienie dzięki wierze.
###### **Ga 3,25**
 Kiedy zaś nadszedł czas wiary, nie jesteśmy już poddani opiekunowi.
###### **Ga 3,26**
 Wszyscy przecież dzięki wierze w Jezusa Chrystusa jesteście synami Bożymi.
###### **Ga 3,27**
 Wy zatem, którzy w Chrystusie zostaliście ochrzczeni, przyodzialiście się w Chrystusa.
###### **Ga 3,28**
 Nie ma już Żyda ani Greka, nie ma niewolnika ani wolnego, nie ma mężczyzny ani kobiety, ponieważ wszyscy jesteście jedno w Chrystusie Jezusie.
###### **Ga 3,29**
 A jeśli należycie do Chrystusa, to jesteście potomstwem Abrahama oraz, zgodnie z obietnicą, dziedzicami.
# Ga 3 BP
###### **Ga 3,1**
 O, niemądrzy Galatowie! Któż was zwiódł? A przecież przed oczami mieliście obraz Jezusa Chrystusa ukrzyżowanego.
###### **Ga 3,2**
 Jednego tylko chcę się od was dowiedzieć: otrzymaliście Ducha dzięki uczynkom nakazanym przez Prawo czy też dzięki posłuszeństwu wobec wiary?
###### **Ga 3,3**
 Czy jesteście aż tak niemądrzy? Rozpocząć od ducha, a teraz skończyć w ciele!
###### **Ga 3,4**
 Czyż na próżno tak dużo doświadczyliście? Czyżby rzeczywiście na próżno?
###### **Ga 3,5**
 Czyż Ten, który udziela wam Ducha i działa pośród was cuda, czyni to dla uczynków nakazanych przez Prawo, czy też dla posłuszeństwa wobec wiary?
###### **Ga 3,6**
 Podobnie było z Abrahamem: "uwierzył Bogu i to poczytano mu za usprawiedliwienie".
###### **Ga 3,7**
 Zrozumiejcie więc, że synami Abrahama są ci właśnie, którzy wierzą.
###### **Ga 3,8**
 Pismo zaś przewidując, że Bóg usprawiedliwi pogan dzięki wierze, dało Abrahamowi tę radosną nowinę: "Ty będziesz błogosławieństwem dla wszystkich narodów".
###### **Ga 3,9**
 Tak więc ci, którzy wierzą, mają błogosławieństwo razem z wierzącym Abrahamem.
###### **Ga 3,10**
 Ci natomiast, którzy powołują się na uczynki nakazane przez Prawo, ściągają na siebie przekleństwo. Napisano bowiem: "Przeklęty niech będzie każdy, kto nie zachowuje wiernie wszystkich przepisów zawartych w Księdze Prawa".
###### **Ga 3,11**
 Jest rzeczą zrozumiałą, że nikt nie doznaje usprawiedliwienia u Boga przez Prawo, ponieważ napisano: "Sprawiedliwy żyć będzie dzięki wierze".
###### **Ga 3,12**
 Prawo nie uwzględnia wiary, lecz powiada: "Kto wypełnia przepisy Prawa, żyć będzie dzięki nim".
###### **Ga 3,13**
 Chrystus uwolnił nas od przekleństwa Prawa, stając się ze względu na nas przekleństwem. Napisano bowiem: "Przeklęty każdy, kto wisi na drzewie".
###### **Ga 3,14**
 Stało się tak dlatego, aby zstąpiło błogosławieństwo na pogan w Jezusie Chrystusie, udzielone Abrahamowi, i byśmy dzięki wierze otrzymali obiecanego Ducha.
###### **Ga 3,15**
 Bracia! Posłużę się przykładem: Nikt nie unieważnia i nie zmienia prawnie sporządzonego testamentu, choć jest on tylko dziełem człowieka.
###### **Ga 3,16**
 Otóż Abrahamowi właśnie i jego potomstwu dano obietnice. Nie powiedziano: potomstwu, jakby chodziło o wielu, lecz mówiono o jednym: "I potomkowi twemu", to jest Chrystusowi.
###### **Ga 3,17**
 Chcę przez to powiedzieć: Testamentu, sporządzonego prawnie przez Boga, nie może znieść Prawo, które powstało po czterystu trzydziestu latach, bo inaczej obietnica byłaby bez znaczenia.
###### **Ga 3,18**
 Gdyby bowiem dziedzictwo wywodziło się z Prawa, nie wywodziłoby się z obietnicy - tymczasem Bóg przez obietnicę okazał Abrahamowi swoją łaskę.
###### **Ga 3,19**
 Czymże więc jest Prawo? Dodano je dla ujawnienia wykroczeń - do czasu przyjścia potomstwa, dla którego była przeznaczona obietnica. Prawo to przekazali aniołowie przez pośrednika.
###### **Ga 3,20**
 Tam, gdzie jest jeden, nie potrzeba pośrednika, a właśnie Bóg jest jeden.
###### **Ga 3,21**
 Czyż więc Prawo sprzeciwia się obietnicom Boga? Na pewno nie! Gdyby bowiem nadane Prawo mogło obdarzać życiem, to rzeczywiście źródłem usprawiedliwienia byłoby Prawo.
###### **Ga 3,22**
 Pismo jednak obwarowało wszystko grzechem, by obietnica spełniała się wobec wierzących dzięki wierze w Jezusa Chrystusa.
###### **Ga 3,23**
 Zanim zaś nastały czasy wiary, strzegło nas Prawo. Byliśmy zamknięci aż do momentu objawienia się wiary.
###### **Ga 3,24**
 Tak więc Prawo stało się opiekunem czuwającym nad nami aż do czasu przyjścia Chrystusa, byśmy dzięki wierze doznali usprawiedliwienia.
###### **Ga 3,25**
 Gdy zaś nastały czasy wiary, już nie jesteśmy poddani opiekunowi.
###### **Ga 3,26**
 Wszyscy bowiem dzięki wierze jesteście synami Boga - w Chrystusie Jezusie.
###### **Ga 3,27**
 Wy bowiem, którzyście przez chrzest zanurzyli się w Chrystusie, przyoblekliście się w Chrystusa.
###### **Ga 3,28**
 Nie istnieje odtąd Żyd ani Grek, nie istnieje niewolnik ani wolny, nie istnieje mężczyzna i kobieta - wy wszyscy bowiem stanowicie jedność w Chrystusie Jezusie.
###### **Ga 3,29**
 A jeżeli należycie do Chrystusa, to jesteście potomstwem Abrahama i - zgodnie z daną obietnicą - spadkobiercami.
# Ga 3 BR
###### **Ga 3,1**
 O nierozumni Galaci! A któż was tak omamił, was, przed których oczyma ukazano przecież obraz Jezusa Chrystusa ukrzyżowanego?
###### **Ga 3,2**
 Chciałbym, żebyście mi odpowiedzieli tylko na jedno: W jaki to sposób otrzymaliście Ducha [Bożego]: przez wypełnianie nakazów Prawa czy przez to, że daliście posłuch wierze?
###### **Ga 3,3**
 Czy jesteście aż tak nierozumni, że rozpocząwszy już [nowe życie] przez Ducha Bożego, chcecie teraz kończyć [je] poleganiem na własnym ciele?
###### **Ga 3,4**
 Czy wszystko to zostało wam dane na próżno? A byłoby rzeczywiście na próżno [gdybyście znów do ciała wrócili].
###### **Ga 3,5**
 Kiedy Bóg zsyła na was swego Ducha i dokonuje na waszych oczach cudów, czy sprawia to dlatego, że wypełniacie nakazy Prawa, czy też dlatego, że idziecie za głosem Ewangelii?
###### **Ga 3,6**
 Tak też i Abraham uwierzył Bogu i dlatego został uznany za sprawiedliwego.
###### **Ga 3,7**
 Musicie więc wiedzieć, że potomkami Abrahama są ci, którzy mają wiarę.
###### **Ga 3,8**
 I dlatego Pismo widząc naprzód, że Bóg będzie czynił pogan sprawiedliwymi na mocy ich wiary, mówi o Abrahamie: W tobie będą błogosławione wszystkie narody.
###### **Ga 3,9**
 I dlatego wszyscy, którzy trwają w wierze, uczestniczą w błogosławieństwie danym Abrahamowi za to, że uwierzył.
###### **Ga 3,10**
 Natomiast przekleństwo ciąży na tych wszystkich, którzy pokładają nadzieję w uczynkach dokonanych według nakazów Prawa. Jest bowiem napisane: Przeklęty każdy, kto nie wypełnia wszystkiego, co nakazuje Księga Prawa.
###### **Ga 3,11**
 To zaś, że nikt nie może uchodzić w oczach Boga za sprawiedliwego na mocy Prawa, wynika [z Pisma, które mówi], że sprawiedliwy będzie żyć dzięki wierze.
###### **Ga 3,12**
 Tymczasem Prawo nie opiera się na wierze, skoro [jest w nim powiedziane, że] kto wypełnia przepisy, dzięki nim żyć będzie.
###### **Ga 3,13**
 Lecz Chrystus wyzwolił nas z tego przekleństwa Prawa, sam stając się dla naszego dobra przekleństwem, zgodnie z tym, co napisane: Przeklęty każdy, kto zawisł na drzewie.
###### **Ga 3,14**
 W ten sposób błogosławieństwo przyrzeczone przez Boga Abrahamowi za pośrednictwem Jezusa Chrystusa zstąpiło na pogan, a my wszyscy dzięki wierze otrzymaliśmy obietnicę Ducha [Świętego].
###### **Ga 3,15**
 Bracia, posłużę się przykładem zaczerpniętym z życia ludzkiego. Jeżeli jakiś człowiek pozostawia testament sporządzony zgodnie z przepisami, to nikt nie może [owego testamentu] ani obalić, ani zmienić.
###### **Ga 3,16**
 Otóż Bóg dał pewne obietnice Abrahamowi i jego potomstwu. Pismo nie mówi 'o potomkach' [Abrahama] - tak jakby chodziło o wiele osób - lecz o jednym potomku, wskazując przez to wyraźnie na jedną osobę, to jest na Chrystusa.
###### **Ga 3,17**
 Otóż pragnę wam przypomnieć, że testamentu, ustanowionego przez Boga, Prawo ogłoszone czterysta trzydzieści lat później nie mogło obalić; nie mogło też unieważnić obietnic związanych z owym testamentem.
###### **Ga 3,18**
 Jeżeli bowiem ktoś staje się dziedzicem na mocy Prawa, to tym samym nie jest nim z racji obietnic. Otóż Abrahamowi okazał Bóg swoją łaskawość poprzez obietnice.
###### **Ga 3,19**
 Wobec tego po co w ogóle Prawo? Otóż zostało ono dane po to, by człowiek poznał, co jest wykroczeniem. Miało ono trwać do czasu przyjścia Potomka [Abrahama], to jest do chwili spełnienia się obietnic. Zostało ogłoszone przy współudziale aniołów i poprzez człowieka który służył za pośrednika.
###### **Ga 3,20**
 W przypadku jednak, gdy chodzi o jedną osobę, pośrednik nie jest potrzebny. Otóż Bóg jest właśnie jeden.
###### **Ga 3,21**
 Czyż wobec tego Prawo sprzeciwia się obietnicom? Ależ nie! Gdyby zostało dane Prawo, które byłoby w stanie dać życie [wieczne], to człowiek rzeczywiście dostępowałby usprawiedliwienia przez Prawo.
###### **Ga 3,22**
 Lecz Pismo wyraźnie mówi, że cała ludzkość znajduje się pod władzą grzechu, aby obietnica objęła swym zasięgiem, dzięki wierze w Jezusa Chrystusa, wszystkich, którzy mają wiarę.
###### **Ga 3,23**
 Do czasu przyjścia wiary byliśmy trzymani w więzach pod strażą Prawa, oczekując na objawienie się owej wiary.
###### **Ga 3,24**
 Tak więc Prawo było naszym wychowawcą aż do przyjścia Chrystusa, abyśmy dostąpili usprawiedliwienia przez wiarę.
###### **Ga 3,25**
 Teraz jednak, gdy nadszedł czas wiary, nie pozostajemy już pod władzą wychowawcy.
###### **Ga 3,26**
 Wszyscy zaś jesteście przez wiarę synami Bożymi dzięki waszemu zjednoczeniu z Jezusem Chrystusem.
###### **Ga 3,27**
 Wszyscy bowiem zostaliście ochrzczeni, aby wejść w jedność z Chrystusem i przyoblec się niejako w Chrystusa.
###### **Ga 3,28**
 Nie ma już podziału ludzi na Żydów i nie-Żydów, na niewolników i wolnych, na mężczyzn i kobiety; wszyscy jesteście jedno w zjednoczeniu z Jezusem Chrystusem.
###### **Ga 3,29**
 A jeśli przynależycie do Chrystusa, to jesteście potomkami Abrahama i właśnie wy dostaniecie w dziedzictwie to, co [Bóg] przyobiecał [Abrahamowi].
# Ga 3 WUJ
###### **Ga 3,1**
 O głupi Galatowie, któż was omamił, abyście prawdzie nie byli posłuszni, przed których oczyma Jezus Chrystus przedtem opisany jest, między wami ukrzyżowany?
###### **Ga 3,2**
 Tego się tylko od was chcę nauczyć: Z uczynków zakonnych wzięliście Ducha, czyli z słuchania wiary?
###### **Ga 3,3**
 Takeście głupi, że począwszy duchem, teraz ciałem bywacie wykonani?
###### **Ga 3,4**
 Takżeście wiele cierpieli darmo? jeśli jednak darmo.
###### **Ga 3,5**
 Który tedy wam dodawa Ducha, i sprawuje mocy w was, z uczynków zakonu, czyli z słuchania wiary?
###### **Ga 3,6**
 Jako napisano jest: Uwierzył Abraham Bogu, i poczytano mu ku sprawiedliwości.
###### **Ga 3,7**
 Poznajcież tedy, iż którzy z wiary są, ci są synmi Abrahamowemi.
###### **Ga 3,8**
 A upatrując pismo, iż z wiary Bóg usprawiedliwia Pogany, przedtem opowiadało Abrahamowi. Iż będą błogosławione w tobie wszystkie narody.
###### **Ga 3,9**
 A tak którzy są z wiary, będą błogosławieni z wiernym Abrahamem.
###### **Ga 3,10**
 Abowiem którzykolwiek są z uczynków zakonu, pod przeklęctwem są. Bo napisano jest: Przeklęty każdy, któryby nie trwał we wszystkiem co napisano w księgach zakonu, aby ono czynił.
###### **Ga 3,11**
 A iż przez zakon żaden nie bywa usprawiedliwion u Boga, jawno jest: iż sprawiedliwy z wiary żywie.
###### **Ga 3,12**
 A zakon nie jest z wiary: ale któryby je czynił, w nich żyć będzie.
###### **Ga 3,13**
 Chrystus nas wykupił od przeklęctwa zakonu stawszy się za nas przeklęctwem, (abowiem napisano jest: Przeklęty każdy, który wisi na drzewie).
###### **Ga 3,14**
 Aby w Poganach stało się błogosławieństwo Abrahamowe w Chrystusie Jezusie: abyśmy obietnicę Ducha wzięli przez wiarę.
###### **Ga 3,15**
 Bracia (wedle człowieka mówię) wszak człowieczego testamentu utwierdzonego nikt nie odrzuca, abo więcej stanawia.
###### **Ga 3,16**
 Abrahamowi opowiedziane są obietnice, i nasieniu jego: Nie mówi, I nasieniom, jakoby w wielu: ale jako w jednem, I nasieniu twojemu, który jest Chrystus.
###### **Ga 3,17**
 A to powiadam, testamentu przedtem od Boga utwierdzonego, zakon, który po czterech set i trzydzieści lat dan jest, nie wątli ku zepsowaniu obietnice.
###### **Ga 3,18**
 Abowiem jeśliż z zakonu dziedzictwo, już nie z obietnice. Lecz Abrahamowi przez obietnicę Bóg darował.
###### **Ga 3,19**
 Cóż tedy zakon? Postanowiony jest dla występków, ażby przyszło nasienie, któremu obiecał rozrządzony przez anioły w ręce pośrednika.
###### **Ga 3,20**
 A pośrednik nie jestci jednego: lecz Bóg jeden jest.
###### **Ga 3,21**
 Zakon tedy przeciwko obietnicom Bożym? Nie daj Boże. Abowiem gdyby był dan zakon, któryby mógł obżywiać: prawdziwieby z zakonu była sprawiedliwość.
###### **Ga 3,22**
 Ale pismo zamknęło wszystko pod grzechem, aby obietnica z wiary Jezusa Chrystusa była dana wierzącym.
###### **Ga 3,23**
 A przedtem niż przyszła wiara, byliśmy pod zakonem strzeżeni, będąc zamknieni ku tej wierze, która miała być objawiona.
###### **Ga 3,24**
 A przetoż zakon, Pedagogiem naszym był w Chrystusie: abychmy z wiary byli usprawiedliwieni.
###### **Ga 3,25**
 Lecz gdy przyszła wiara: już nie jesteśmy pod Pedagogiem.
###### **Ga 3,26**
 Abowiem wszyscy synami Bożemi jesteście przez wiarę, która jest w Chrystusie Jezusie.
###### **Ga 3,27**
 Bo którzykolwiek jesteście ochrzczeni w Chrystusie: oblekliście się w Chrystusa.
###### **Ga 3,28**
 Nie jest Żyd ani Greczyn: nie jest niewolnik, ani wolny: nie jest mężczyzna, ani niewiasta. Abowiem wszyscy wy jedno jesteście w Chrystusie Jezusie.
###### **Ga 3,29**
 A jeśliście wy Chrystusowi: tedyście nasieniem Abrahamowem, dziedzicami wedle obietnice.
# Ga 3 STERN
###### **Ga 3,1**
 Głupi Galacjanie! Czy was kto zauroczył? Na waszych oczach odmalowano wyraźnie Jeszuę Mesjasza jako tego, który został stracony jak zbrodniarz!
###### **Ga 3,2**
 Tego jednego chcę się od was dowiedzieć: czy Ducha otrzymaliście poprzez legalistyczne przestrzeganie nakazów Tory, czy poprzez zaufanie i wierność temu, co usłyszeliście?
###### **Ga 3,3**
 Aż tak jesteście głupi? Rozpocząwszy od mocy Ducha, sądzicie, że możecie osiągnąć cel swą własną mocą?
###### **Ga 3,4**
 Na darmo tyle wycierpieliście? Jeśli w ten sposób rozumujecie, to faktycznie wasze cierpienie było daremne!
###### **Ga 3,5**
 A Bóg, który daje wam Ducha i czyni cuda wśród was - czy robi to z powodu waszego legalistycznego przestrzegania nakazów Tory, czy też dlatego, że ufacie temu, co usłyszeliście, i jesteście temu wierni?
###### **Ga 3,6**
 Tak samo było z Awrahamem: "Złożył ufność w Bogu i był Mu wierny, i to zostało mu policzone jako sprawiedliwość".
###### **Ga 3,7**
 Bądźcie zatem pewni, że to ci, którzy żyją ufnością i wiernością, są naprawdę dziećmi Awrahama.
###### **Ga 3,8**
 Również Tanach, przewidując, że Bóg uzna nie-Żydów za sprawiedliwych, jeśli będą żyć w ufności i wierności, zawczasu oznajmił Awrahamowi Dobrą Nowinę, mówiąc: "Za twoją sprawą będą błogosławieni wszyscy goim".
###### **Ga 3,9**
 Ci zatem, którzy polegają na ufności i wierności, są błogosławieni razem z Awrahamem, który ufał i był wierny.
###### **Ga 3,10**
 Bo nad każdym, kto polega na legalistycznym przestrzeganiu nakazów Tory, ciąży przekleństwo, napisano bowiem: "Przeklęty każdy, kto nie wykonuje wytrwale wszystkiego, co zapisano w Zwoju Tory".
###### **Ga 3,11**
 A oczywiste jest, że przez legalizm nikt nie dostępuje uznania przez Boga za sprawiedliwego, bo "człowiek sprawiedliwy żył będzie przez ufanie i wierność".
###### **Ga 3,12**
 Ponadto legalizm nie opiera się na ufności i wierności, ale na wypaczeniu tekstu, który mówi: "Ktokolwiek czyni te rzeczy, dzięki nim dostąpi życia".
###### **Ga 3,13**
 Mesjasz wykupił nas od przekleństwa orzeczonego w Torze, stawszy się przeklętym za nas; Tanach bowiem mówi: "Każdy, kto wisi na palu, podlega przekleństwu".
###### **Ga 3,14**
 Jeszua Mesjasz uczynił to, aby w jedności z Nim nie-Żydzi mogli otrzymać błogosławieństwo zapowiedziane Awrahamowi, ażebyśmy przez ufność i wierność otrzymali to, co obiecane, mianowicie Ducha.
###### **Ga 3,15**
 Bracia, pozwolę sobie na porównanie do codziennego życia: kiedy ktoś składa jakiś ślub, nikt inny nie może go unieważnić ani czegoś do tego dodać.
###### **Ga 3,16**
 A przecież obietnice zostały złożone Awrahamowi i jego potomstwu. Nie jest powiedziane: "i potomkom", czyli wielu, przeciwnie, mowa o jednym - "i potomstwu twojemu" - a tym "jednym" jest Mesjasz.
###### **Ga 3,17**
 Chcę powiedzieć, co następuje: prawna część Tory, która powstała czterysta trzydzieści lat później, nie unieważnia ślubu złożonego przez Boga i nie może znieść tej obietnicy.
###### **Ga 3,18**
 Bo jeśli dziedzictwo wynika z prawnej części Tory, to nie wynika już z obietnicy. Ale Bóg dał je Awrahamowi przez obietnicę.
###### **Ga 3,19**
 Czemu więc ma służyć prawna część Tory? Została dodana, aby stworzyć przestępstwa, aż do czasu nadejścia potomstwa, o którym została dana obietnica. Ponadto została przekazana przez aniołów i pośrednika.
###### **Ga 3,20**
 A obecność pośrednika wskazuje, że jest ich więcej niż jeden, tymczasem Bóg jest jeden.
###### **Ga 3,21**
 Czy znaczy to, że prawna część Tory sprzeciwia się obietnicom Bożym? Nigdy w życiu! Bo gdyby prawna część Tory, którą dał Bóg, miała sama w sobie moc udzielać życia, to sprawiedliwość faktycznie pochodziłaby z legalistycznego przestrzegania takiej Tory.
###### **Ga 3,22**
 Tymczasem Tanach zamyka wszystko pod władzą grzechu, tak aby na podstawie ufnej wierności Jeszui Mesjasza zostało dane to, co zostało obiecane, tym, którzy pozostają ufnie wierni.
###### **Ga 3,23**
 A zanim nadszedł czas na tę ufną wierność, byliśmy uwięzieni w poddaństwie wobec systemu, który rodzi się z wypaczenia Tory w legalizm, trzymani pod strażą aż do czasu objawienia się tej przyszłej ufnej wierności.
###### **Ga 3,24**
 Tora zatem pełniła funkcję surowego opiekuna aż do przyjścia Mesjasza, abyśmy mogli zostać uznani za sprawiedliwych na podstawie ufności i wierności.
###### **Ga 3,25**
 Lecz teraz, gdy nadszedł czas tej ufnej wierności, nie jesteśmy już poddani opiekunowi.
###### **Ga 3,26**
 Bo w jedności z Mesjaszem wy wszyscy jesteście dziećmi Bożymi przez tę ufną wierność.
###### **Ga 3,27**
 Bo wszyscy ci z was, którzy zostali zanurzeni w Mesjasza, przyoblekli się w Mesjasza, w którym
###### **Ga 3,28**
 nie ma ani Żyda, ani nie-Żyda, ani niewolnika, ani wolnego, ani mężczyzny, ani kobiety. Bo w jedności z Mesjaszem Jeszuą wszyscy jedno jesteście.
###### **Ga 3,29**
 A jeżeli należycie do Mesjasza, to jesteście potomstwem Awrahama i dziedzicami według obietnicy.
# Ga 3 TRO
###### **Ga 3,1**
 **ω** *ō* O [[G5599]] WTINJ **ανοητοι** *anoētoi* nierozumni – bezmyślni [[G453]] WTA-VPM **γαλαται** *galatai* Galacjanie [[G1052]] WTN-VPM **τις** *tis* kto [[G5101]] WTI-NSM **υμας** *hymas* was [[G5209]] WTP-2AP **εβασκανεν** *ebaskanen* otumanił – zauroczył [[G940]] [[V-AAI-3S]] **τη** *tē* [[G3588]] WTT-DSF **αληθεια** *alētheia* prawdą [[G225]] [[N-DSF]] **μη** *mē* nie [[G3361]] [[PRT-N]] **πειθεσθαι** *peithesthai* być przekonanymi – być posłusznymi [[G3982]] WTV-PPN **οις** *hois* którym [[G3739]] WTR-DPM **κατ** *kat* na [[G2596]] [[PREP]] **οφθαλμους** *ofthalmous* oczach [[G3788]] [[N-APM]] **ιησους** *iēsous* Jezus – [JHWH jest zbawieniem] [[G2424]] [[N-NSM]] **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **προεγραφη** *proegrafē* został wcześniej zapisany [[G4270]] WTV-2API-3S **εν** *en* w [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **εσταυρωμενος** *estaurōmenos* który jest ukrzyżowany [[G4717]] WTV-RPP-NSM
###### **Ga 3,2**
 **τουτο** *touto* To [[G5124]] WTD-ASN **μονον** *monon* jedynie – tylko [[G3440]] [[ADV]] **θελω** *thelō* chcę [[G2309]] WTV-PAI-1S **μαθειν** *mathein* dowiedzieć się – nauczyć się [[G3129]] [[V-2AAN]] **αφ** *af* od [[G575]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **εξ** *eks* z – przez [[G1537]] [[PREP]] **εργων** *ergōn* czynów – uczynków [[G2041]] WTN-GPN **νομου** *nomou* Prawa [[G3551]] [[N-GSM]] **το** *to* [[G3588]] WTT-ASN **πνευμα** *pneuma* Ducha [[G4151]] WTN-ASN **ελαβετε** *elabete* otrzymaliście [[G2983]] WTV-2AAI-2P **η** *ē* czy [[G2228]] WTPRT **εξ** *eks* ze – przez [[G1537]] [[PREP]] **ακοης** *akoēs* słuchania [[G189]] [[N-GSF]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]]
###### **Ga 3,3**
 **ουτως** *houtōs* Tak [[G3779]] [[ADV]] **ανοητοι** *anoētoi* nierozumni – bezmyślni [[G453]] WTA-NPM **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **εναρξαμενοι** *enarksamenoi* rozpocząwszy [[G1728]] WTV-ADP-NPM **πνευματι** *pneumati* Duchem [[G4151]] WTN-DSN **νυν** *nyn* teraz [[G3568]] [[ADV]] **σαρκι** *sarki* ciałem [[G4561]] [[N-DSF]] **επιτελεισθε** *epiteleisthe* kończycie [[G2005]] WTV-PEI-2P
###### **Ga 3,4**
 **τοσαυτα** *tosauta* Tak wiele [[G5118]] WTD-APN **επαθετε** *epathete* wycierpieliście [[G3958]] WTV-2AAI-2P **εικη** *eikē* bez powodu – na próżno [[G1500]] [[ADV]] **ειγε** *eige* jeśli rzeczywiście – jeśli oczywiście [[G1489]] WTCOND **και** *kai* i [[G2532]] [[CONJ]] **εικη** *eikē* bez powodu – na próżno [[G1500]] [[ADV]]
###### **Ga 3,5**
 **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **ουν** *oun* więc [[G3767]] [[CONJ]] **επιχορηγων** *epichorēgōn* dostarczający – zaopatrujący [[G2023]] [[V-PAP-NSM]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **το** *to* [[G3588]] WTT-ASN **πνευμα** *pneuma* Ducha [[G4151]] WTN-ASN **και** *kai* i [[G2532]] [[CONJ]] **ενεργων** *energōn* działający [[G1754]] [[V-PAP-NSM]] **δυναμεις** *dynameis* moce [[G1411]] WTN-APF **εν** *en* w [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **εξ** *eks* z [[G1537]] [[PREP]] **εργων** *ergōn* uczynków – czynów [[G2041]] WTN-GPN **νομου** *nomou* Prawa [[G3551]] [[N-GSM]] **η** *ē* lub [[G2228]] WTPRT **εξ** *eks* ze [[G1537]] [[PREP]] **ακοης** *akoēs* słuchania [[G189]] [[N-GSF]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]]
###### **Ga 3,6**
 **καθως** *kathōs* Tak, jak [[G2531]] [[ADV]] **αβρααμ** *abraam* Abraham – [ojciec wielu narodów] [[G11]] [[N-PRI]] **επιστευσεν** *episteusen* uwierzył [[G4100]] [[V-AAI-3S]] **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **ελογισθη** *elogisthē* zostało poczytane – zostało policzone [[G3049]] [[V-API-3S]] **αυτω** *autō* mu [[G846]] WTP-DSM **εις** *eis* do – ku [[G1519]] [[PREP]] **δικαιοσυνην** *dikaiosynēn* uznania za sprawiedliwego – usprawiedliwienia [[G1343]] WTN-ASF
###### **Ga 3,7**
 **γινωσκετε** *ginōskete* Wiecie [[G1097]] WTV-PAI-2P **αρα** *ara* zatem [[G686]] WTPRT **οτι** *hoti* że [[G3754]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **εκ** *ek* z [[G1537]] [[PREP]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **ουτοι** *houtoi* ci [[G3778]] WTD-NPM **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **υιοι** *hyioi* synowie [[G5207]] WTN-NPM **αβρααμ** *abraam* Abrahama – [ojciec wielu narodów] [[G11]] [[N-PRI]]
###### **Ga 3,8**
 **προιδουσα** *proidousa* Zobaczywszy wcześniej – Przewidziawszy [[G4275]] WTV-2AAP-NSF **δε** *de* zaś [[G1161]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **γραφη** *grafē* Pismo [[G1124]] [[N-NSF]] **οτι** *hoti* że [[G3754]] [[CONJ]] **εκ** *ek* z [[G1537]] [[PREP]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **δικαιοι** *dikaioi* usprawiedliwia – uznaje za sprawiedliwych [[G1344]] WTV-PAI-3S **τα** *ta* [[G3588]] WTT-APN **εθνη** *ethnē* pogan – narody [[G1484]] WTN-APN **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **προευηγγελισατο** *proeuēngelisato* wcześniej ogłosiło nowinę [[G4283]] WTV-ADI-3S **τω** *tō* [[G3588]] WTT-DSM **αβρααμ** *abraam* Abrahamowi – [ojciec wielu narodów] [[G11]] [[N-PRI]] **οτι** *hoti* że [[G3754]] [[CONJ]] **ευλογηθησονται** *eulogēthēsontai* zostaną błogosławione – zostaną wysławione [[G2127]] WTV-FPI-3P **εν** *en* w [[G1722]] [[PREP]] **σοι** *soi* tobie [[G4671]] WTP-2DS **παντα** *panta* wszyscy [[G3956]] WTA-NPN **τα** *ta* [[G3588]] WTT-NPN **εθνη** *ethnē* poganie – narody [[G1484]] WTN-NPN
###### **Ga 3,9**
 **ωστε** *hōste* Tak, że [[G5620]] [[CONJ]] **οι** *hoi* (ci) [[G3588]] WTT-NPM **εκ** *ek* z [[G1537]] [[PREP]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **ευλογουνται** *eulogountai* są błogosławieni – są wysławiani [[G2127]] WTV-PPI-3P **συν** *syn* z [[G4862]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **πιστω** *pistō* wiernym [[G4103]] WTA-DSM **αβρααμ** *abraam* Abrahamem – [ojciec wielu narodów] [[G11]] [[N-PRI]]
###### **Ga 3,10**
 **οσοι** *hosoi* Ilu [[G3745]] WTK-NPM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εξ** *eks* z [[G1537]] [[PREP]] **εργων** *ergōn* czynów – uczynków [[G2041]] WTN-GPN **νομου** *nomou* Prawa [[G3551]] [[N-GSM]] **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **υπο** *hypo* pod [[G5259]] [[PREP]] **καταραν** *kataran* przekleństwem [[G2671]] WTN-ASF **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **γεγραπται** *gegraptai* jest napisane [[G1125]] WTV-RPI-3S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **επικαταρατος** *epikataratos* przeklęty [[G1944]] [[A-NSM]] **πας** *pas* każdy [[G3956]] [[A-NSM]] **ος** *hos* który [[G3739]] WTR-NSM **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εμμενει** *emmenei* trwa [[G1696]] WTV-PAI-3S **εν** *en* we [[G1722]] [[PREP]] **πασιν** *pasin* wszystkich [[G3956]] WTA-DPN **τοις** *tois* [[G3588]] WTT-DPN **γεγραμμενοις** *gegrammenois* które są zapisane [[G1125]] WTV-RPP-DPN **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **βιβλιω** *bibliō* zwoju [[G975]] WTN-DSN **του** *tou* [[G3588]] WTT-GSM **νομου** *nomou* Prawa [[G3551]] [[N-GSM]] **του** *tou* (by) [[G3588]] WTT-GSM **ποιησαι** *poiēsai* uczynić [[G4160]] [[V-AAN]] **αυτα** *auta* je [[G846]] WTP-APN
###### **Ga 3,11**
 **οτι** *hoti* że [[G3754]] [[CONJ]] **δε** *de* zaś [[G1161]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **νομω** *nomō* Prawie [[G3551]] WTN-DSM **ουδεις** *oudeis* nikt [[G3762]] [[A-NSM]] **δικαιουται** *dikaioutai* jest uznawany za sprawiedliwego – jest usprawiedliwiany [[G1344]] WTV-PPI-3S **παρα** *para* przed [[G3844]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogiem [[G2316]] WTN-DSM **δηλον** *dēlon* jawne – oczywiste [[G1212]] WTA-NSN **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **δικαιος** *dikaios* sprawiedliwy [[G1342]] [[A-NSM]] **εκ** *ek* z [[G1537]] [[PREP]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **ζησεται** *zēsetai* będzie żyć [[G2198]] WTV-FDI-3S
###### **Ga 3,12**
 **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **νομος** *nomos* Prawo [[G3551]] [[N-NSM]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **εκ** *ek* z [[G1537]] [[PREP]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **αλλ** *all* ale [[G235]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **ποιησας** *poiēsas* który uczynił [[G4160]] WTV-AAP-NSM **αυτα** *auta* je [[G846]] WTP-APN **ανθρωπος** *anthrōpos* człowiek [[G444]] [[N-NSM]] **ζησεται** *zēsetai* będzie żyć [[G2198]] WTV-FDI-3S **εν** *en* w [[G1722]] [[PREP]] **αυτοις** *autois* nich [[G846]] WTP-DPN
###### **Ga 3,13**
 **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **εξηγορασεν** *eksēgorasen* wykupił – odkupił [[G1805]] [[V-AAI-3S]] **εκ** *ek* od – z [[G1537]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **καταρας** *kataras* przekleństwa [[G2671]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **νομου** *nomou* Prawa [[G3551]] [[N-GSM]] **γενομενος** *genomenos* stawszy się [[G1096]] WTV-2ADP-NSM **υπερ** *hyper* za [[G5228]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP **καταρα** *katara* przekleństwo [[G2671]] [[N-NSF]] **γεγραπται** *gegraptai* jest napisane [[G1125]] WTV-RPI-3S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **επικαταρατος** *epikataratos* przeklęty [[G1944]] [[A-NSM]] **πας** *pas* każdy [[G3956]] [[A-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **κρεμαμενος** *kremamenos* który jest wiszący [[G2910]] WTV-PMP-NSM **επι** *epi* na [[G1909]] [[PREP]] **ξυλου** *ksylou* drzewie [[G3586]] [[N-GSN]]
###### **Ga 3,14**
 **ινα** *hina* aby [[G2443]] [[CONJ]] **εις** *eis* do [[G1519]] [[PREP]] **τα** *ta* [[G3588]] WTT-APN **εθνη** *ethnē* pogan – narodów [[G1484]] WTN-APN **η** *hē* [[G3588]] [[T-NSF]] **ευλογια** *eulogia* błogosławieństwo – wysławienie [[G2129]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSM **αβρααμ** *abraam* Abrahama – [ojciec wielu narodów] [[G11]] [[N-PRI]] **γενηται** *genētai* stałoby się [[G1096]] WTV-2ADS-3S **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM **ινα** *hina* aby [[G2443]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **επαγγελιαν** *epangelian* obietnicę [[G1860]] WTN-ASF **του** *tou* [[G3588]] WTT-GSN **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **λαβωμεν** *labōmen* otrzymalibyśmy [[G2983]] WTV-2AAS-1P **δια** *dia* przez [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **πιστεως** *pisteōs* wiarę [[G4102]] [[N-GSF]]
###### **Ga 3,15**
 **αδελφοι** *adelfoi* Bracia [[G80]] WTN-VPM **κατα** *kata* na wzór – po [[G2596]] [[PREP]] **ανθρωπον** *anthrōpon* człowieka [[G444]] [[N-ASM]] **λεγω** *legō* mówię [[G3004]] WTV-PAI-1S **ομως** *homōs* przecież – jeszcze [[G3676]] [[CONJ]] **ανθρωπου** *anthrōpou* ludzkiego – człowieka [[G444]] [[N-GSM]] **κεκυρωμενην** *kekyrōmenēn* które jest uprawomocnione – które jest ustalone [[G2964]] WTV-RPP-ASF **διαθηκην** *diathēkēn* przymierze [[G1242]] WTN-ASF **ουδεις** *oudeis* nikt [[G3762]] [[A-NSM]] **αθετει** *athetei* odrzuca [[G114]] WTV-PAI-3S **η** *ē* lub [[G2228]] WTPRT **επιδιατασσεται** *epidiatassetai* dodaje – dodatkowo rozporządza [[G1928]] WTV-PNI-3S
###### **Ga 3,16**
 **τω** *tō* [[G3588]] WTT-DSM **δε** *de* zaś [[G1161]] [[CONJ]] **αβρααμ** *abraam* Abrahamowi – [ojciec wielu narodów] [[G11]] [[N-PRI]] **ερρηθησαν** *errēthēsan* zostały wypowiedziane [[G4483]] WTV-API-3P **αι** *hai* [[G3588]] [[T-NPF]] **επαγγελιαι** *epangeliai* obietnice [[G1860]] [[N-NPF]] **και** *kai* i [[G2532]] [[CONJ]] **τω** *tō* [[G3588]] WTT-DSN **σπερματι** *spermati* potomkowi – nasieniu [[G4690]] WTN-DSN **αυτου** *autou* jego [[G846]] [[P-GSM]] **ου** *ou* nie [[G3756]] [[PRT-N]] **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **και** *kai* i [[G2532]] [[CONJ]] **τοις** *tois* [[G3588]] WTT-DPN **σπερμασιν** *spermasin* potomkom – nasieniu [[G4690]] WTN-DPN **ως** *hōs* jak [[G5613]] [[ADV]] **επι** *epi* o [[G1909]] [[PREP]] **πολλων** *pollōn* wielu [[G4183]] WTA-GPN **αλλ** *all* ale [[G235]] [[CONJ]] **ως** *hōs* jak [[G5613]] [[ADV]] **εφ** *ef* o [[G1909]] [[PREP]] **ενος** *henos* jednym [[G1520]] [[A-GSN]] **και** *kai* i [[G2532]] [[CONJ]] **τω** *tō* (dla) [[G3588]] WTT-DSN **σπερματι** *spermati* potomka – nasienia [[G4690]] WTN-DSN **σου** *sou* twojego [[G4675]] WTP-2GS **ος** *hos* którym [[G3739]] WTR-NSM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]]
###### **Ga 3,17**
 **τουτο** *touto* To [[G5124]] WTD-ASN **δε** *de* zaś [[G1161]] [[CONJ]] **λεγω** *legō* mówię [[G3004]] WTV-PAI-1S **διαθηκην** *diathēkēn* przymierza [[G1242]] WTN-ASF **προκεκυρωμενην** *prokekyrōmenēn* które jest wcześniej uprawomocnione – które jest wcześniej ustalone [[G4300]] WTV-RPP-ASF **υπο** *hypo* przez [[G5259]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εις** *eis* w [[G1519]] [[PREP]] **χριστον** *christon* Pomazańcu [[G5547]] [[N-ASM]] **ο** *ho* [[G3588]] [[T-NSM]] **μετα** *meta* po [[G3326]] [[PREP]] **ετη** *etē* latach [[G2094]] WTN-APN **τετρακοσια** *tetrakosia* czterystu [[G5071]] WTA-APN **και** *kai* i [[G2532]] [[CONJ]] **τριακοντα** *triakonta* trzydziestu [[G5144]] WTA-NUI **γεγονως** *gegonōs* które stało się [[G1096]] WTV-2RAP-NSM **νομος** *nomos* Prawo [[G3551]] [[N-NSM]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ακυροι** *akyroi* unieważnia [[G208]] WTV-PAI-3S **εις** *eis* do [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **καταργησαι** *katargēsai* uznać za bezużyteczną – utracić na znaczeniu [[G2673]] [[V-AAN]] **την** *tēn* [[G3588]] WTT-ASF **επαγγελιαν** *epangelian* obietnicę [[G1860]] WTN-ASF
###### **Ga 3,18**
 **ει** *ei* Jeśli [[G1487]] WTCOND **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εκ** *ek* z [[G1537]] [[PREP]] **νομου** *nomou* Prawa [[G3551]] [[N-GSM]] **η** *hē* [[G3588]] [[T-NSF]] **κληρονομια** *klēronomia* dziedziczenie [[G2817]] [[N-NSF]] **ουκετι** *ouketi* już nie [[G3765]] [[ADV]] **εξ** *eks* z [[G1537]] [[PREP]] **επαγγελιας** *epangelias* obietnicy [[G1860]] [[N-GSF]] **τω** *tō* [[G3588]] WTT-DSM **δε** *de* zaś [[G1161]] [[CONJ]] **αβρααμ** *abraam* Abrahamowi – [ojciec wielu narodów] [[G11]] [[N-PRI]] **δι** *di* przez [[G1223]] [[PREP]] **επαγγελιας** *epangelias* obietnicę [[G1860]] [[N-GSF]] **κεχαρισται** *kecharistai* darował [[G5483]] WTV-RNI-3S **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]]
###### **Ga 3,19**
 **τι** *ti* Czym [[G5101]] WTI-NSN **ουν** *oun* więc [[G3767]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **νομος** *nomos* Prawo [[G3551]] [[N-NSM]] **των** *tōn* [[G3588]] WTT-GPF **παραβασεων** *parabaseōn* przestępstw [[G3847]] WTN-GPF **χαριν** *charin* z powodu [[G5484]] [[ADV]] **προσετεθη** *prosetethē* zostało przyłączone – zostało dodane [[G4369]] [[V-API-3S]] **αχρις** *achris* aż do [[G891]] [[PREP]] **ου** *hou* kiedy [[G3739]] WTR-GSM **ελθη** *elthē* przyszedłby [[G2064]] WTV-2AAS-3S **το** *to* [[G3588]] WTT-NSN **σπερμα** *sperma* potomek – nasienie [[G4690]] WTN-NSN **ω** *hō* któremu [[G3739]] WTR-DSM **επηγγελται** *epēngeltai* jest obiecane [[G1861]] WTV-RNI-3S **διαταγεις** *diatageis* które zostało zarządzone – które zostało rozporządzone [[G1299]] WTV-2APP-NSM **δι** *di* przez [[G1223]] [[PREP]] **αγγελων** *angelōn* zwiastunów [[G32]] WTN-GPM **εν** *en* w [[G1722]] [[PREP]] **χειρι** *cheiri* ręku [[G5495]] [[N-DSF]] **μεσιτου** *mesitou* pośrednika [[G3316]] [[N-GSM]]
###### **Ga 3,20**
 **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **μεσιτης** *mesitēs* pośrednik [[G3316]] [[N-NSM]] **ενος** *henos* jednego [[G1520]] WTA-GSM **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **εις** *heis* jeden [[G1520]] [[A-NSM]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S
###### **Ga 3,21**
 **ο** *ho* [[G3588]] [[T-NSM]] **ουν** *oun* więc [[G3767]] [[CONJ]] **νομος** *nomos* Prawo [[G3551]] [[N-NSM]] **κατα** *kata* przeciw [[G2596]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPF **επαγγελιων** *epangeliōn* obietnicom [[G1860]] WTN-GPF **του** *tou* (z) [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **μη** *mē* nie [[G3361]] [[PRT-N]] **γενοιτο** *genoito* oby stało się [[G1096]] WTV-2ADO-3S **ει** *ei* jeśli [[G1487]] WTCOND **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εδοθη** *edothē* zostało dane [[G1325]] [[V-API-3S]] **νομος** *nomos* Prawo [[G3551]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **δυναμενος** *dynamenos* mogące [[G1410]] WTV-PNP-NSM **ζωοποιησαι** *zōopoiēsai* ożywić [[G2227]] [[V-AAN]] **οντως** *ontōs* istotnie – naprawdę [[G3689]] [[ADV]] **αν** *an* (kiedy)kolwiek [[G302]] WTPRT **εκ** *ek* z [[G1537]] [[PREP]] **νομου** *nomou* Prawa [[G3551]] [[N-GSM]] **ην** *ēn* było [[G2258]] [[V-IXI-3S]] **η** *hē* [[G3588]] [[T-NSF]] **δικαιοσυνη** *dikaiosynē* uznanie za sprawiedliwego – usprawiedliwienie [[G1343]] [[N-NSF]]
###### **Ga 3,22**
 **αλλα** *alla* Ale [[G235]] [[CONJ]] **συνεκλεισεν** *synekleisen* razem zamknęło – współzakluczyło [[G4788]] [[V-AAI-3S]] **η** *hē* [[G3588]] [[T-NSF]] **γραφη** *grafē* Pismo [[G1124]] [[N-NSF]] **τα** *ta* [[G3588]] WTT-APN **παντα** *panta* wszystkie [[G3956]] WTA-APN **υπο** *hypo* pod [[G5259]] [[PREP]] **αμαρτιαν** *hamartian* grzechem [[G266]] WTN-ASF **ινα** *hina* aby [[G2443]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **επαγγελια** *epangelia* obietnica [[G1860]] [[N-NSF]] **εκ** *ek* z [[G1537]] [[PREP]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **δοθη** *dothē* zostałaby dana [[G1325]] WTV-APS-3S **τοις** *tois* [[G3588]] WTT-DPM **πιστευουσιν** *pisteuousin* którzy są wierzącymi [[G4100]] WTV-PAP-DPM
###### **Ga 3,23**
 **προ** *pro* Przed [[G4253]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **δε** *de* zaś [[G1161]] [[CONJ]] **ελθειν** *elthein* przyjść [[G2064]] [[V-2AAN]] **την** *tēn* [[G3588]] WTT-ASF **πιστιν** *pistin* wiara [[G4102]] WTN-ASF **υπο** *hypo* pod [[G5259]] [[PREP]] **νομον** *nomon* Prawem [[G3551]] [[N-ASM]] **εφρουρουμεθα** *efrouroumetha* byliśmy pilnowani [[G5432]] WTV-IPI-1P **συγκεκλεισμενοι** *sygkekleismenoi* którzy są razem zamkniętymi – będący współzakluczonymi [[G4788]] WTV-RPP-NPM **εις** *eis* do [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **μελλουσαν** *mellousan* mającej nastąpić – mającej nadejść [[G3195]] WTV-PAP-ASF **πιστιν** *pistin* wiary [[G4102]] WTN-ASF **αποκαλυφθηναι** *apokalyfthēnai* zostać objawiona [[G601]] WTV-APN
###### **Ga 3,24**
 **ωστε** *hōste* Tak, że [[G5620]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **νομος** *nomos* Prawo [[G3551]] [[N-NSM]] **παιδαγωγος** *paidagōgos* pedagog – wychowawca [[G3807]] [[N-NSM]] **ημων** *hēmōn* nasz [[G2257]] WTP-1GP **γεγονεν** *gegonen* stało się [[G1096]] WTV-2RAI-3S **εις** *eis* do [[G1519]] [[PREP]] **χριστον** *christon* Pomazańca [[G5547]] [[N-ASM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **εκ** *ek* z [[G1537]] [[PREP]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **δικαιωθωμεν** *dikaiōthōmen* zostalibyśmy uznani za sprawiedliwych – zostalibyśmy usprawiedliwieni [[G1344]] WTV-APS-1P
###### **Ga 3,25**
 **ελθουσης** *elthousēs* Gdy przyszła [[G2064]] WTV-2AAP-GSF **δε** *de* zaś [[G1161]] [[CONJ]] **της** *tēs* [[G3588]] [[T-GSF]] **πιστεως** *pisteōs* wiara [[G4102]] [[N-GSF]] **ουκετι** *ouketi* już nie [[G3765]] [[ADV]] **υπο** *hypo* pod [[G5259]] [[PREP]] **παιδαγωγον** *paidagōgon* pedagogiem – wychowawcą [[G3807]] [[N-ASM]] **εσμεν** *esmen* jesteśmy [[G2070]] WTV-PXI-1P
###### **Ga 3,26**
 **παντες** *pantes* Wszyscy [[G3956]] WTA-NPM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **υιοι** *hyioi* synowie [[G5207]] WTN-NPM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **δια** *dia* przez [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **πιστεως** *pisteōs* wiarę [[G4102]] [[N-GSF]] **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańca [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] WTN-DSM
###### **Ga 3,27**
 **οσοι** *hosoi* Ilu [[G3745]] WTK-NPM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εις** *eis* w [[G1519]] [[PREP]] **χριστον** *christon* Pomazańca [[G5547]] [[N-ASM]] **εβαπτισθητε** *ebaptisthēte* zostaliście zanurzeni [[G907]] WTV-API-2P **χριστον** *christon* (w) Pomazańca [[G5547]] [[N-ASM]] **ενεδυσασθε** *enedysasthe* przyoblekliście się – wdzialiście na siebie [[G1746]] WTV-AMI-2P
###### **Ga 3,28**
 **ουκ** *ouk* Nie [[G3756]] [[PRT-N]] **ενι** *eni* jest [[G1762]] WTV-PXI-3S **ιουδαιος** *ioudaios* Judejczyk – [wielbić] [[G2453]] [[A-NSM]] **ουδε** *oude* ani [[G3761]] [[ADV]] **ελλην** *hellēn* Grek [[G1672]] [[N-NSM]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ενι** *eni* jest [[G1762]] WTV-PXI-3S **δουλος** *doulos* niewolnik – sługa [[G1401]] [[N-NSM]] **ουδε** *oude* ani [[G3761]] [[ADV]] **ελευθερος** *eleutheros* wolny [[G1658]] [[A-NSM]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ενι** *eni* jest [[G1762]] WTV-PXI-3S **αρσεν** *arsen* męskie [[G730]] WTN-NSN **και** *kai* i [[G2532]] [[CONJ]] **θηλυ** *thēly* żeńskie [[G2338]] WTA-NSN **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **εις** *heis* jednym [[G1520]] [[A-NSM]] **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM
###### **Ga 3,29**
 **ει** *ei* Jeśli [[G1487]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **αρα** *ara* zatem [[G686]] WTPRT **του** *tou* [[G3588]] WTT-GSM **αβρααμ** *abraam* Abrahama – [ojciec wielu narodów] [[G11]] [[N-PRI]] **σπερμα** *sperma* potomek – nasienie [[G4690]] WTN-NSN **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **και** *kai* i [[G2532]] [[CONJ]] **κατ** *kat* według [[G2596]] [[PREP]] **επαγγελιαν** *epangelian* obietnicy [[G1860]] WTN-ASF **κληρονομοι** *klēronomoi* dziedzice [[G2818]] WTN-NPM
