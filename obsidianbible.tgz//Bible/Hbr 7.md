# Hbr 7 BT5
###### **Hbr 7,1**
 Ten to Melchizedek, król Szalemu, kapłan Boga Najwyższego, wyszedł na spotkanie Abrahama, wracającego po rozgromieniu królów, i udzielił mu błogosławieństwa.
###### **Hbr 7,2**
 Jemu Abraham także wydzielił dziesięcinę z całego [łupu]. Imię jego najpierw oznacza króla sprawiedliwości, a następnie także króla Szalemu, to jest króla pokoju.
###### **Hbr 7,3**
 Bez ojca, bez matki, bez rodowodu, nie ma ani początku [swych] dni, ani też końca życia, upodobniony zaś do Syna Bożego, pozostaje kapłanem na zawsze.
###### **Hbr 7,4**
 Rozważcie, jak wielki jest ten, któremu sam patriarcha Abraham dał dziesięcinę z najlepszego łupu.
###### **Hbr 7,5**
 Wprawdzie i ci z synów Lewiego, którzy otrzymują kapłaństwo, mają zgodnie z Prawem polecenie pobierania dziesięciny od ludu, to jest od braci swoich, chociaż i oni wywodzą się z rodu Abrahama.
###### **Hbr 7,6**
 Tamten jednak, który nie wywodził się z ich rodu, otrzymał dziesięcinę od Abrahama i pobłogosławił tego, który miał obietnice.
###### **Hbr 7,7**
 Nie ma zaś żadnej wątpliwości, iż to, co mniejsze, otrzymuje błogosławieństwo od tego, co wyższe.
###### **Hbr 7,8**
 Ponadto, tu biorą dziesięciny ludzie, którzy umierają, tam zaś ten, o którym wydane jest świadectwo, że żyje.
###### **Hbr 7,9**
 I jeśli się można tak wyrazić, także Lewi, który pobiera dziesięciny, złożył dziesięcinę poprzez Abrahama.
###### **Hbr 7,10**
 Był bowiem jeszcze w lędźwiach praojca swego, gdy Melchizedek wyszedł mu na spotkanie.
###### **Hbr 7,11**
 Gdyby więc doskonałość została osiągnięta przez kapłaństwo lewickie, lud bowiem otrzymał Prawo z nim związane, to jakaż była potrzeba ustanawiania jeszcze innego kapłana na wzór Melchizedeka, a nie na wzór Aarona?
###### **Hbr 7,12**
 Ze zmianą bowiem kapłaństwa musi też nastąpić zmiana Prawa.
###### **Hbr 7,13**
 Ten zaś, o którym się to mówi, należał do innego pokolenia, z którego nikt nie służył ołtarzowi.
###### **Hbr 7,14**
 Wiadomo przecież, że nasz Pan wyszedł z pokolenia Judy, a Mojżesz nic nie wspomniał o kapłanach z tego pokolenia.
###### **Hbr 7,15**
 Jest to jeszcze bardziej oczywiste, skoro na podobieństwo Melchizedeka jest ustanowiony inny kapłan,
###### **Hbr 7,16**
 który stał się takim nie według cielesnego przepisu Prawa, ale według mocy niezniszczalnego życia.
###### **Hbr 7,17**
 Dane Mu jest bowiem takie świadectwo: Ty jesteś kapłanem na wieki na wzór Melchizedeka.
###### **Hbr 7,18**
 Zostaje przeto usunięte poprzednie Prawo z powodu swej słabości i nieużyteczności.
###### **Hbr 7,19**
 Prawo nie doprowadziło niczego do pełnej doskonałości, a było wprowadzeniem lepszej nadziei, przez którą zbliżamy się do Boga.
###### **Hbr 7,20**
 Tym więcej, iż stało się to nie bez złożenia przysięgi. Gdy bowiem tamci bez przysięgi stawali się kapłanami,
###### **Hbr 7,21**
 Ten właśnie przez przysięgę Tego, który do Niego powiedział: Poprzysiągł Pan, a nie będzie żałował: Ty jesteś kapłanem na wieki.
###### **Hbr 7,22**
 O tyle też Jezus stał się poręczycielem lepszego przymierza.
###### **Hbr 7,23**
 I gdy tamtych wielu było kapłanami, gdyż śmierć nie zezwalała im trwać przy życiu,
###### **Hbr 7,24**
 Ten właśnie, ponieważ trwa na wieki, ma kapłaństwo nieprzemijające.
###### **Hbr 7,25**
 Przeto i zbawiać na wieki może całkowicie tych, którzy przez Niego przystępują do Boga, bo wciąż żyje, aby się wstawiać za nimi.
###### **Hbr 7,26**
 Takiego bowiem potrzeba nam było arcykapłana: świętego, niewinnego, nieskalanego, oddzielonego od grzeszników, wywyższonego ponad niebiosa,
###### **Hbr 7,27**
 takiego, który nie jest zobowiązany, jak inni arcykapłani, do składania codziennej ofiary najpierw za swoje grzechy, a potem za grzechy ludu. To bowiem uczynił raz na zawsze, ofiarując samego siebie.
###### **Hbr 7,28**
 Prawo bowiem ustanawiało arcykapłanami ludzi obciążonych słabością, słowo zaś przysięgi, złożonej po nadaniu Prawa, [ustanawia arcykapłanem] Syna doskonałego na wieki.
# Hbr 7 PAU
###### **Hbr 7,1**
 Otóż ten Melchizedek, król Szalemu, kapłan Boga Najwyższego, wyszedł na spotkanie z Abrahamem, wracającym po pobiciu królów, i pobłogosławił go.
###### **Hbr 7,2**
 Jemu to Abraham wydzielił dziesięcinę ze wszystkiego. Jego imię oznacza najpierw „króla sprawiedliwości”, ale również króla Szalemu, czyli „króla pokoju”.
###### **Hbr 7,3**
 Bez ojca, bez matki, bez rodowodu, nie ma początku dni ani też końca życia, podobnie do Syna Bożego pozostaje kapłanem na zawsze.
###### **Hbr 7,4**
 Rozważcie, jak wielki musiał być ten, któremu sam patriarcha Abraham dał dziesięcinę z najlepszego łupu.
###### **Hbr 7,5**
 Wprawdzie i potomkowie Lewiego, otrzymując kapłaństwo, mają zgodnie z Prawem przywilej pobierania dziesięcin od ludu, czyli od własnych braci, chociaż i oni wywodzą się od Abrahama.
###### **Hbr 7,6**
 Ten zaś, nie pochodząc z ich rodu, otrzymał dziesięcinę od Abrahama i pobłogosławił dziedzica obietnic.
###### **Hbr 7,7**
 A nie da się zaprzeczyć, że to, co niższe, otrzymuje błogosławieństwo od wyższego.
###### **Hbr 7,8**
 Tu ponadto przyjmują dziesięciny ludzie śmiertelni, tam zaś ktoś, o kim zaświadczono, że żyje!
###### **Hbr 7,9**
 Dodajmy wreszcie, że w osobie Abrahama oddaje dziesięcinę nawet Lewi, któremu należą się dziesięciny.
###### **Hbr 7,10**
 Był on bowiem jeszcze w lędźwiach swego ojca, gdy ten spotkał się z Melchizedekiem.
###### **Hbr 7,11**
 Gdyby doskonałość dało się osiągnąć dzięki kapłaństwu lewickiemu - jako że było ono podstawą prawa ustanowionego dla ludu - to po cóż byłoby ustanawiać jeszcze innego kapłana na wzór Melchizedeka, a nie na wzór Aarona?
###### **Hbr 7,12**
 Otóż zmiana kapłaństwa z konieczności powoduje też zmianę prawa.
###### **Hbr 7,13**
 A Ten, którego dotyczy ta wypowiedź, należał do innego plemienia, z którego nikt nie pełnił służby ołtarza.
###### **Hbr 7,14**
 Wiadomo przecież, że nasz Pan pochodził z Judy, a Mojżesz nie wspomina o kapłanach z tego plemienia.
###### **Hbr 7,15**
 Jest to tym bardziej oczywiste, że na podobieństwo Melchizedeka pojawia się inny kapłan,
###### **Hbr 7,16**
 stając się nim nie z zewnętrznego przepisu, lecz z mocy niezniszczalnego życia.
###### **Hbr 7,17**
 Bóg zaświadczył bowiem: Ty jesteś kapłanem na wieki na wzór Melchizedeka.
###### **Hbr 7,18**
 Zniósł więc dawny przepis, który okazał się za słaby i bezużyteczny.
###### **Hbr 7,19**
 Prawo bowiem nie uczyniło niczego doskonalszym, toteż jego miejsce zajęła lepsza nadzieja, przez którą możemy zbliżyć się do Boga.
###### **Hbr 7,20**
 A dokonało się to nie bez przysięgi. Tamci bowiem zostawali kapłanami bez składania przysięgi,
###### **Hbr 7,21**
 Ten zaś dzięki przysiędze Boga, który powiedział do Niego: Pan przysiągł i nie będzie żałował: Ty jesteś kapłanem na wieki!
###### **Hbr 7,22**
 Tak więc Jezus jest gwarantem znacznie lepszego przymierza.
###### **Hbr 7,23**
 Ponadto tamci kapłani musieli być liczni, bo śmierć nie pozwalała im trwać.
###### **Hbr 7,24**
 Ten zaś, przez to, że trwa na wieki, ma kapłaństwo nieprzemijające.
###### **Hbr 7,25**
 Toteż na zawsze może zbawić tych, którzy zbliżają się do Boga. Żyje przecież wiecznie, aby się wstawiać za nimi.
###### **Hbr 7,26**
 Takiego właśnie potrzeba nam było najwyższego kapłana: świętego, niewinnego, nieskalanego, odłączonego od grzeszników, a sięgającego ponad niebo.
###### **Hbr 7,27**
 Nie musi On codziennie, jak dawni najwyżsi kapłani, składać ofiary najpierw za własne grzechy, a potem za grzechy ludu. Uczynił to bowiem raz na zawsze, samego siebie składając w ofierze.
###### **Hbr 7,28**
 Prawo ustanawia najwyższymi kapłanami słabych ludzi, słowo zaś przysięgi, zastępującej Prawo, ustanawia Syna doskonałego na wieki.
# Hbr 7 BP
###### **Hbr 7,1**
 Ów bowiem Melchizedech, król Salemu, kapłan Boga Najwyższego, wyszedłszy na spotkanie Abrahama pobłogosławił mu, gdy wracał on po rozgromieniu królów.
###### **Hbr 7,2**
 Jemu to wręczył "Abraham dziesiątą część ze wszystkiego". Pierwotnie bowiem imię jego znaczy "król sprawiedliwości", następnie też "król Salemu", czyli król pokoju.
###### **Hbr 7,3**
 Bez wzmianki o ojcu czy matce, bez rodowodu, bez wskazania początku dni i końca życia - upodobniony zatem do Syna Bożego - pozostaje kapłanem na wieki.
###### **Hbr 7,4**
 Widzicie więc, jak wielki był ten, któremu Abraham jako głowa narodu dał dziesiątą część z najlepszych zdobyczy.
###### **Hbr 7,5**
 Wprawdzie i tym synom Lewiego, którym powierzono funkcje kapłańskie, Prawo nakazuje pobierać dziesięciny od ludu, czyli od ich braci, chociaż i oni wywodzą się z potomstwa Abrahama.
###### **Hbr 7,6**
 Ale ów przyjął dziesięcinę od Abrahama, nie należąc do ich rodu, i pobłogosławił tego, który otrzymał obietnicę.
###### **Hbr 7,7**
 Bezsprzecznie, niższy bywa błogosławiony przez wyższego.
###### **Hbr 7,8**
 Tutaj biorą dziesięciny ludzie śmiertelni, tam zaś ktoś, o kim się świadczy, że żyje.
###### **Hbr 7,9**
 I można powiedzieć, że przez Abrahama zapłacił dziesięcinę także Lewi, który bierze dziesięciny,
###### **Hbr 7,10**
 bo Lewi jeszcze w ogóle nie istniał, kiedy jego ojcu "wyszedł naprzeciw Melchizedech".
###### **Hbr 7,11**
 Jeśli więc doskonałość była osiągalna przez kapłaństwo lewickie, bo przecież naród w związku z nim otrzymał Prawo, to po co było ustanawiać kogoś innego "na wzór Melchizedecha" i mówić, że nie jest "na wzór Aarona"?
###### **Hbr 7,12**
 Przecież ze zmianą kapłaństwa zachodzi konieczność zmienienia także i Prawa.
###### **Hbr 7,13**
 Ten, o którym mowa, jest członkiem innego pokolenia, z którego nikt nie poświęcał się służbie ołtarza.
###### **Hbr 7,14**
 Powszechnie wiadomo, że Pan nasz urodził się w pokoleniu Judy, a Mojżesz nic nie mówił o kapłanach z tego pokolenia.
###### **Hbr 7,15**
 Jest to tym bardziej widoczne, jeśli "na podobieństwo Melchizedecha" ustanawia się innego kapłana,
###### **Hbr 7,16**
 który zostaje nim nie na mocy przepisu Prawa o naturalnym pochodzeniu, ale mocą niezniszczalnego życia.
###### **Hbr 7,17**
 Stwierdza się bowiem: "Ty jesteś kapłanem na wieki na podobieństwo Melchizedecha".
###### **Hbr 7,18**
 Dochodzi zatem do uchylenia poprzedniego Prawa z powodu jego niestałości i nieużyteczności.
###### **Hbr 7,19**
 Prawo bowiem nie doprowadziło do doskonałości, przeto daje się [w jego miejsce] doskonalszą nadzieję, przez którą zbliżamy się do Boga.
###### **Hbr 7,20**
 I to nie bez stwierdzenia pod przysięgą. Gdy owi zostawali kapłanami bez przysięgi,
###### **Hbr 7,21**
 On - przez przysięgę Tego, który Mu powiedział: "Przysiągł Pan i nie odwoła tego: Ty jesteś kapłanem na wieki".
###### **Hbr 7,22**
 Dlatego Jezus jest poręczycielem lepszego przymierza.
###### **Hbr 7,23**
 Tamtych kapłanów było wielu, bo śmierć przeszkadzała im w spełnianiu funkcji.
###### **Hbr 7,24**
 On natomiast, ponieważ trwa na wieki, posiada kapłaństwo nieprzemijające.
###### **Hbr 7,25**
 Przeto i zbawiać może w sposób doskonały tych, którzy przez Niego przychodzą do Boga, bo zawsze żyje, aby wstawiać się za nimi.
###### **Hbr 7,26**
 Wypadało, żebyśmy mieli takiego arcykapłana - świętego, dobrego, czystego, odłączonego od grzeszników i wywyższonego ponad niebiosa.
###### **Hbr 7,27**
 Nie potrzebuje On codziennie, jak arcykapłani, składać ofiar najpierw za własne grzechy, a potem za grzechy narodu; uczynił to bowiem raz na zawsze, złożywszy siebie samego w ofierze.
###### **Hbr 7,28**
 Tak więc Prawo ustanawia arcykapłanami ludzi podległych słabości, a słowa przysięgi poza Prawem [ustanawiają arcykapłanem] - Syna doskonałego na wieki.
# Hbr 7 BR
###### **Hbr 7,1**
 Właśnie Melchizedek, król Szalemu, kapłan Boga Najwyższego, wyszedł na spotkanie Abrahama, gdy ten wracał po rozgromieniu królów. On to udzielił Abrahamowi błogosławieństwa,
###### **Hbr 7,2**
 Abraham zaś wręczył mu dziesięcinę z całego łupu. Imię Melchizedeka oznacza najpierw 'król sprawiedliwości', a następnie 'król Szalemu', to jest 'król pokoju'.
###### **Hbr 7,3**
 Nikt nie zna jego ojca ani matki, ani żadnego spośród jego przodków; nigdzie nie mówi się ani o jego narodzinach, ani śmierci. Jest pod tym względem podobny do Syna Człowieczego. Pozostaje na wieki kapłanem.
###### **Hbr 7,4**
 Zastanówcie się więc sami, jak wielkim jest ten, któremu sam Abraham patriarcha złożył dziesięcinę ze swego najcenniejszego łupu.
###### **Hbr 7,5**
 To prawda, że potomkowie Lewiego, piastujący godność kapłańską, otrzymali polecenie, zgodnie z Prawem, pobierania dziesięciny od ludu, to jest od braci swoich, chociaż wszyscy wywodzą się od wspólnego ojca Abrahama.
###### **Hbr 7,6**
 Tymczasem Melchizedek nie wywodził się z tego rodu, a jednak otrzymał dziesięcinę od Abrahama z wszystkiego, co ten posiadał, i sam udzielił błogosławieństwa temu, który miał obietnice od Boga.
###### **Hbr 7,7**
 Otóż nie ulega wątpliwości, że ten, który błogosławieństwa udziela, jest zazwyczaj wyższy od tego, który je otrzymuje.
###### **Hbr 7,8**
 Ponadto w przypadku potomków z rodu Lewiego dziesięcinę otrzymują zwykli ludzie - śmiertelnicy, natomiast gdy chodzi o Melchizedeka, to dziesięcinę otrzymał ktoś, kto - jak zapewnia Pismo - nie umiera.
###### **Hbr 7,9**
 Wreszcie można w pewnym sensie twierdzić, że w osobie Abrahama składającego dziesięcinę spłacił ją także Lewi, którego potomkowie właśnie mają prawo odbierania tej daniny.
###### **Hbr 7,10**
 Wtedy bowiem, kiedy Melichzedek wyszedł na spotkanie Abrahama, w ciele Patriarchy już przecież przebywał Lewi.
###### **Hbr 7,11**
 Jeśli więc doskonałość już została osiągnięta przez kapłaństwo wywodzące się od Lewiego - lud bowiem otrzymał Prawo oparte na tym kapłaństwie - to po cóż było ustanawiać jeszcze inne kapłaństwo, to na wzór Melchizedeka, zamiast pozostawać przy kapłaństwie według Aarona?
###### **Hbr 7,12**
 Otóż ze zmianą kapłaństwa wiąże się też potrzeba zmiany Prawa.
###### **Hbr 7,13**
 Ten zaś, do którego odnoszą się powyższe słowa [Jezus], należał przecież do pokolenia, z którego nikt nie służył ołtarzowi.
###### **Hbr 7,14**
 Wiadomo zaś, że Pan nasz należał przez swe narodzenie do pokolenia Judy, tymczasem Mojżesz wcale nie wspomina o kapłanach, którzy by pochodzili z tego pokolenia.
###### **Hbr 7,15**
 Wszystko staje się jeszcze bardziej jasne wobec faktu, że oto pojawia się inny kapłan na wzór Melchizedeka
###### **Hbr 7,16**
 i jest kapłanem nie na mocy przepisów ludzkiego prawa, lecz z powodu nieprzemijającego życia.
###### **Hbr 7,17**
 W rzeczywistości bowiem tak mówi o Nim Pismo: Jesteś kapłanem na wieki na wzór Melchizedeka.
###### **Hbr 7,18**
 Tak więc zostało zniesione uprzednio istniejące Prawo, gdyż okazało się słabe i nieużyteczne.
###### **Hbr 7,19**
 Niczemu bowiem nie dało pełnej doskonałości. Miejsce Prawa zajęła nadzieja lepszej przyszłości i poprzez tę nadzieję zbliżamy się do Boga.
###### **Hbr 7,20**
 Co więcej: towarzyszyła temu przysięga Boża, podczas gdy inni zostawali kapłanami bez jakiejkolwiek przysięgi.
###### **Hbr 7,21**
 Tymczasem On został kapłanem na mocy specjalnej przysięgi Tego, który doń powiedział: Pan złożył przysięgę i nie będzie żałował: Ty jesteś kapłanem na wieki.
###### **Hbr 7,22**
 Wskutek tego Jezus zapewnił nam także wyższość Nowego Przymierza.
###### **Hbr 7,23**
 Poza tym, podczas gdy tam wielu [kolejno] zostawało kapłanami, gdyż śmierć trwać im nie pozwalała [na wieki],
###### **Hbr 7,24**
 to Ten, ponieważ trwa na wieki, posiada kapłaństwo wiekuiste.
###### **Hbr 7,25**
 Dlatego też może zbawiać wszystkich, którzy kiedykolwiek żyć będą, byleby tylko zechcieli zbliżyć się do Boga przez Niego. On bowiem żyje po to, aby wstawiać się za nami.
###### **Hbr 7,26**
 Takiego to właśnie potrzeba nam było arcykapłana: świętego, niewinnego, nieskalanego, oddzielonego od grzeszników, wywyższonego ponad niebiosa;
###### **Hbr 7,27**
 takiego, który nie musi, jak inni arcykapłani, składać codziennie ofiary naprzód za swoje grzechy, a potem za grzechy całego ludu. Uczynił to jeden raz na zawsze, kiedy siebie samego złożył w ofierze.
###### **Hbr 7,28**
 Prawo ustanowiło kapłanami ludzi niedoskonałych, słowo zaś przysięgi złożonej po ogłoszeniu Prawa [ustanowiło kapłanem] Syna, który jest na wieki niezmienną doskonałością.
# Hbr 7 WUJ
###### **Hbr 7,1**
 Abowiem ten Melchisedech, król Salem, kapłan Boga nawyższego, który wyszedł przeciw Abrahamowi wracającemu się z porażki królów, i błogosławił mu:
###### **Hbr 7,2**
 Któremu i dziesięciny wszystkiego wydzielił Abraham: naprzód który wykłada się król sprawiedliwości: potem też i król Salem, co jest, król pokoju.
###### **Hbr 7,3**
 Bez ojca, bez matki, bez wyliczenia rodu, nie mając ani początku dniów ani końca żywota: a przypodobany Synowi Bożemu, trwa kapłanem na wieki.
###### **Hbr 7,4**
 A przypatrzcie się jako to wielki, któremu też dziesięcinę z rzeczy przedniejszych dał Abraham Patriarcha.
###### **Hbr 7,5**
 A iście z synów Lewi, urząd kapłański przyjmujący, rozkazanie mają, aby brali dziesięcinę od ludu wedle zakonu, to jest, od braciej swojej: chociaż i oni wyszli z biodra Abrahamowych.
###### **Hbr 7,6**
 Lecz którego naród nie jest poczytan między nimi, dziesięcinę brał od Abrahama, i tego, który miał obietnice błogosławił.
###### **Hbr 7,7**
 A bez wszelakiego sporu, co mniejszem jest, od lepszego bywa błogosławione.
###### **Hbr 7,8**
 A tu jednak, ludzie, którzy umierają dziesięciny biorą: lecz tam świadectwo ma, iż żywie.
###### **Hbr 7,9**
 A (iżby się tak rzekło ) przez Abrahama, i Lewi, który brał dziesięciny, oddał dziesięcinę.
###### **Hbr 7,10**
 Abowiem jeszcze był w biodrach ojcowych, gdy wyszedł przeciw niemu Melchisedech.
###### **Hbr 7,11**
 Jeśliż tedy doskonałość była przez kapłaństwo Lewitskie (bo pod niem lud wziął zakon) cóż jeszcze było potrzeba, aby nastał inszy kapłan wedle porządku Melchisedechowego, a nie był rzeczon wedle porządku Aaronowego.
###### **Hbr 7,12**
 Bo za przeniesieniem kapłaństwa, trzeba, żeby się i zakonu przeniesienie stało.
###### **Hbr 7,13**
 Bo o którym się to mówi, z inszego jest pokolenia, z którego żaden nie pilnował ołtarza.
###### **Hbr 7,14**
 Abowiem jawna jest, iż z Juda poszedł Pan nasz: w którem pokoleniu nic o kapłaniech nie mówił Mojżesz.
###### **Hbr 7,15**
 A jeszcze daleko więcej jawna rzecz jest: jeśliże na podobieństwo Melchisedecha powstaje inszy kapłan,
###### **Hbr 7,16**
 Który nie wedle zakonu rozkazania cielesnego stał się, ale wedle mocy żywota nieskazitelnego.
###### **Hbr 7,17**
 Abowiem świadczy: Iż ty jesteś kapłanem na wieki, wedle porządku Melchisedechowego.
###### **Hbr 7,18**
 Odrzucenie iście staje się przeszłego przykazania: dla słabości jego i niepożyteczności.
###### **Hbr 7,19**
 Bo zakon niczego nie przywiódł ku doskonałości, ale wprowadzenie lepszej nadzieje, przez którą przybliżamy się ku Bogu.
###### **Hbr 7,20**
 A ponieważ, jest nie bez przysięgi (Bo inni bez przysięgi kapłany zostali:
###### **Hbr 7,21**
 A ten z przysięgą przez tego, który rzekł do niego: Przysiągł Pan, a nie będzie mu żal: tyś jest kapłanem na wieki).
###### **Hbr 7,22**
 Tym lepszego testamentu stał się Jezus rękojmią.
###### **Hbr 7,23**
 A innychci wiele się kapłany stawało, dla tego, iż im śmierć trwać nie dopuszczała:
###### **Hbr 7,24**
 Ale ten iż na wieki trwa, wiekuiste ma kapłaństwo.
###### **Hbr 7,25**
 Przetoż i zbawić na wieki może, przystępujące przez niegoż do Boga: zawsze żywiąc, aby się wstawiał za nami.
###### **Hbr 7,26**
 Abowiem przystało, abyśmy takiego mieli, nawyższego kapłana świętego, niewinnego, niepokalanego, odłączonego od grzeszników, i który się stał wyższy nad niebiosa.
###### **Hbr 7,27**
 Który nie ma potrzeby na każdy dzień, jako kapłani pierwej za występki swoje ofiarować, potem za ludzkie: bo to uczynił raz, siebie ofiarowawszy.
###### **Hbr 7,28**
 Abowiem zakon ludzie postanawiał kapłany krewkości podległe, lecz mowa przysięgi, która jest po zakonie, Syna na wieki doskonałego.
# Hbr 7 STERN
###### **Hbr 7,1**
 Ten to Malki-Cedek, król Szalemu, kohen Boga Ha'Eliona, wyszedł na spotkanie Awrahamowi powracającemu po rozgromieniu królów i pobłogosławił go;
###### **Hbr 7,2**
 Awraham zaś dał mu dziesiątą część ze wszystkiego. Otóż przede wszystkim jest on - według przekładu swego imienia - "królem sprawiedliwości", jest również królem Szalemu, co oznacza "król pokoju".
###### **Hbr 7,3**
 Nie ma zapisów o jego ojcu, matce, pochodzeniu, urodzeniu czy śmierci, lecz podobnie jak Syn Boży trwa on jako kohen na wieki.
###### **Hbr 7,4**
 Pomyślcie, jak był wielki! Nawet Patriarcha Awraham dał mu dziesiątą część z najlepszych łupów.
###### **Hbr 7,5**
 A potomkowie Lwiego, którzy stali się kohanim, mają w Torze przykazanie, aby pobierać dziesiątą część dochodów od ludu, a zatem od własnych braci, mimo że i oni są potomkami Awrahama.
###### **Hbr 7,6**
 Tymczasem Malki-Cedek, mimo że nie pochodził od L'wiego, wziął dziesięcinę od Awrahama. I pobłogosławił Awrahama, człowieka, który otrzymał Boże obietnice;
###### **Hbr 7,7**
 a jest poza wszelką dyskusją, że ten, kto błogosławi, wyżej stoi od tego, kto błogosławieństwo otrzymuje.
###### **Hbr 7,8**
 Ponadto w przypadku kohanim dziesięcinę przyjmują ludzie, którzy umierają, tymczasem w przypadku Malki-Cedeka przyjmuje ją ktoś, o kim zaświadczono, że wciąż żyje.
###### **Hbr 7,9**
 Można by pójść jeszcze dalej i powiedzieć, że L'wi, który sam otrzymuje dziesięciny, zapłacił dziesięcinę za pośrednictwem Awrahama;
###### **Hbr 7,10**
 gdyż był jeszcze w ciele swego przodka Awrahama, gdy spotkał Malki-Cedeka.
###### **Hbr 7,11**
 Gdyby zatem możliwe było osiągnięcie celu za pomocą systemu kohanim wywodzących się od Lwiego (gdyż to w związku z tym systemem lud otrzymał Torę), po cóż byłby potrzebny kohen innego, odmiennego rodzaju, taki, o którym mówi się, że miał być przyrównany do Malki-Cedeka, a nie do Aharona?
###### **Hbr 7,12**
 Bo jeśli przeobrażeniu ulega system kohanim, to musi z konieczności dojść do przeobrażenia Tory.
###### **Hbr 7,13**
 Ten, o którym mówi się te rzeczy, należy do innego plemienia, z którego nikt nigdy nie służył przy ołtarzu;
###### **Hbr 7,14**
 bo każdy wie, że nasz Pan wywodził się z J'hudy i że Mosze nie wspomniał nic o tym plemieniu, gdy mówił o kohanim.
###### **Hbr 7,15**
 Staje się to jeszcze oczywistsze, gdy pojawia się "kohen innego rodzaju", taki jak Malki-Cedek,
###### **Hbr 7,16**
 który został kohenem nie na podstawie wyrażonej w Torze zasady związanej z fizycznym pochodzeniem, ale na podstawie mocy niezniszczalnego życia.
###### **Hbr 7,17**
 Stwierdza się bowiem: "Jesteś kohenem NA WIEKI, aby Cię przyrównywano do Malki-Cedeka".
###### **Hbr 7,18**
 A zatem z jednej strony zostaje uchylona wcześniejsza zasada z powodu swej słabości i nieskuteczności
###### **Hbr 7,19**
 (bo Tora nie doprowadziła niczego do celu); z drugiej zaś strony zostaje wprowadzona nadzieja na coś lepszego, przez co przybliżamy się do Boga.
###### **Hbr 7,20**
 Co więcej, Bóg złożył przysięgę. Bo w związku z tymi, którzy teraz stają się kohanim, nie składa się żadnej przysięgi;
###### **Hbr 7,21**
 lecz Jeszua stał się kohenem na podstawie przysięgi, którą złożył Bóg, gdy powiedział Mu: "Przysiągł Adonai i zdania nie zmieni: "Jesteś kohenem na wieki... "".
###### **Hbr 7,22**
 Także i to pokazuje, o ileż lepsze jest przymierze, którego Jeszua stał się poręczycielem.
###### **Hbr 7,23**
 Ponadto dzisiejszych kohanim jest wielu, bo śmierć nie pozwala im piastować dalej urzędu.
###### **Hbr 7,24**
 Lecz ponieważ On żyje na wieki, Jego funkcja jako kohena nie przechodzi na innego;
###### **Hbr 7,25**
 a wobec tego jest On w pełni zdolny wyzwalać tych, którzy przez Niego przychodzą do Boga; ponieważ żyje na wieki i dzięki temu na wieki może wstawiać się za nimi.
###### **Hbr 7,26**
 Taki właśnie kohen gadol odpowiada naszej potrzebie - święty, bez śladu zła, bez zmazy, oddzielony od grzeszników i wyniesiony ponad niebiosa;
###### **Hbr 7,27**
 taki, który w odróżnieniu od innych kohanim g'dolim nie musi codziennie składać ofiary najpierw za własne grzechy, a dopiero potem za grzechy ludu; bo złożył On jedną ofiarę, raz na zawsze, ofiarowując samego siebie.
###### **Hbr 7,28**
 Tora bowiem ustanawia jako kohanim g'dolim ludzi, którzy mają słabości; lecz tekst mówiący o przysiędze, napisany później niż Tora, ustanawia Syna, który został doprowadzony do celu na wieki.
# Hbr 7 TRO
###### **Hbr 7,1**
 **ουτος** *houtos* Ten [[G3778]] WTD-NSM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **μελχισεδεκ** *melchisedek* Melchisedek – [król sprawiedliwości] [[G3198]] [[N-PRI]] **βασιλευς** *basileus* król [[G935]] [[N-NSM]] **σαλημ** *salēm* Salemu – [pokój] [[G4532]] [[N-PRI]] **ιερευς** *hiereus* kapłan [[G2409]] [[N-NSM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **του** *tou* [[G3588]] WTT-GSM **υψιστου** *hypsistou* Najwyższego [[G5310]] WTA-GSM **ο** *ho* [[G3588]] [[T-NSM]] **συναντησας** *synantēsas* wyszedłszy na spotkanie z [[G4876]] WTV-AAP-NSM **αβρααμ** *abraam* Abrahamem – [ojciec wielu narodów] [[G11]] [[N-PRI]] **υποστρεφοντι** *hypostrefonti* wracającym [[G5290]] WTV-PAP-DSM **απο** *apo* po [[G575]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **κοπης** *kopēs* rozbiciu – uderzeniu [[G2871]] [[N-GSF]] **των** *tōn* [[G3588]] WTT-GPM **βασιλεων** *basileōn* królów [[G935]] WTN-GPM **και** *kai* i [[G2532]] [[CONJ]] **ευλογησας** *eulogēsas* pobłogosławiwszy – wysławiwszy [[G2127]] WTV-AAP-NSM **αυτον** *auton* go [[G846]] WTP-ASM
###### **Hbr 7,2**
 **ω** *hō* któremu [[G3739]] WTR-DSM **και** *kai* i [[G2532]] [[CONJ]] **δεκατην** *dekatēn* dziesięcinę [[G1181]] WTA-ASF **απο** *apo* z [[G575]] [[PREP]] **παντων** *pantōn* wszystkich [[G3956]] WTA-GPN **εμερισεν** *emerisen* przydzielił [[G3307]] [[V-AAI-3S]] **αβρααμ** *abraam* Abraham – [ojciec wielu narodów] [[G11]] [[N-PRI]] **πρωτον** *prōton* najpierw [[G4412]] [[ADV]] **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **ερμηνευομενος** *hermēneuomenos* który jest tłumaczony – który jest wykładany [[G2059]] [[V-PPP-NSM]] **βασιλευς** *basileus* król [[G935]] [[N-NSM]] **δικαιοσυνης** *dikaiosynēs* sprawiedliwości [[G1343]] [[N-GSF]] **επειτα** *epeita* następnie [[G1899]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **βασιλευς** *basileus* król [[G935]] [[N-NSM]] **σαλημ** *salēm* Salemu – [pokój] [[G4532]] [[N-PRI]] **ο** *ho* co [[G3739]] WTR-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **βασιλευς** *basileus* król [[G935]] [[N-NSM]] **ειρηνης** *eirēnēs* pokoju [[G1515]] [[N-GSF]]
###### **Hbr 7,3**
 **απατωρ** *apatōr* będący bez ojca [[G540]] [[A-NSM]] **αμητωρ** *amētōr* będący bez matki [[G282]] [[A-NSM]] **αγενεαλογητος** *agenealogētos* będący bez rodowodu – będący bez genealogii [[G35]] [[A-NSM]] **μητε** *mēte* ani [[G3383]] [[CONJ]] **αρχην** *archēn* początek [[G746]] WTN-ASF **ημερων** *hēmerōn* dni [[G2250]] WTN-GPF **μητε** *mēte* ani [[G3383]] [[CONJ]] **ζωης** *zōēs* życia [[G2222]] [[N-GSF]] **τελος** *telos* koniec [[G5056]] WTN-ASN **εχων** *echōn* mający [[G2192]] [[V-PAP-NSM]] **αφωμοιωμενος** *afōmoiōmenos* który jest podobny – który jest upodobniony [[G871]] WTV-RPP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **τω** *tō* [[G3588]] WTT-DSM **υιω** *hyiō* Synowi [[G5207]] WTN-DSM **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **μενει** *menei* pozostaje – trwa [[G3306]] WTV-PAI-3S **ιερευς** *hiereus* (jako) kapłan [[G2409]] [[N-NSM]] **εις** *eis* na [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **διηνεκες** *diēnekes* ciągłe – nieprzerwane [[G1336]] WTA-ASN
###### **Hbr 7,4**
 **θεωρειτε** *theōreite* Oglądacie – Widzicie [[G2334]] WTV-PAI-2P **δε** *de* zaś [[G1161]] [[CONJ]] **πηλικος** *pēlikos* jak wielki [[G4080]] [[A-NSM]] **ουτος** *houtos* ten [[G3778]] WTD-NSM **ω** *hō* któremu [[G3739]] WTR-DSM **και** *kai* i [[G2532]] [[CONJ]] **δεκατην** *dekatēn* dziesięcinę [[G1181]] WTA-ASF **αβρααμ** *abraam* Abraham – [ojciec wielu narodów] [[G11]] [[N-PRI]] **εδωκεν** *edōken* dał [[G1325]] [[V-AAI-3S]] **εκ** *ek* z [[G1537]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **ακροθινιων** *akrothiniōn* najlepszych łupów – pierwocin [[G205]] WTN-GPN **ο** *ho* [[G3588]] [[T-NSM]] **πατριαρχης** *patriarchēs* patriarcha [[G3966]] [[N-NSM]]
###### **Hbr 7,5**
 **και** *kai* I [[G2532]] [[CONJ]] **οι** *hoi* (ci) [[G3588]] WTT-NPM **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **εκ** *ek* z [[G1537]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **υιων** *hyiōn* synów [[G5207]] WTN-GPM **λευι** *leui* Lewiego – [przyłączyć] [[G3017]] [[N-PRI]] **την** *tēn* [[G3588]] WTT-ASF **ιερατειαν** *hierateian* kapłaństwo [[G2405]] WTN-ASF **λαμβανοντες** *lambanontes* biorąc – otrzymując [[G2983]] WTV-PAP-NPM **εντολην** *entolēn* przykazanie [[G1785]] WTN-ASF **εχουσιν** *echousin* mają [[G2192]] WTV-PAI-3P **αποδεκατουν** *apodekatoun* (by) pobierać dziesięcinę [[G586]] WTV-PAN **τον** *ton* (od) [[G3588]] [[T-ASM]] **λαον** *laon* ludu [[G2992]] [[N-ASM]] **κατα** *kata* według [[G2596]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **νομον** *nomon* Prawa [[G3551]] [[N-ASM]] **τουτ** *tout* to [[G5124]] WTD-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **τους** *tous* (od) [[G3588]] WTT-APM **αδελφους** *adelfous* braci [[G80]] [[N-APM]] **αυτων** *autōn* ich [[G846]] WTP-GPM **καιπερ** *kaiper* chociaż [[G2539]] [[CONJ]] **εξεληλυθοτας** *ekselēlythotas* wychodzących [[G1831]] WTV-RAP-APM **εκ** *ek* z [[G1537]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **οσφυος** *osfyos* lędźwi – biodra [[G3751]] [[N-GSF]] **αβρααμ** *abraam* Abrahama – [ojciec wielu narodów] [[G11]] [[N-PRI]]
###### **Hbr 7,6**
 **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **γενεαλογουμενος** *genealogoumenos* mając ustalonego rodowodu – będąc umieszczony w genealogii [[G1075]] [[V-PPP-NSM]] **εξ** *eks* z [[G1537]] [[PREP]] **αυτων** *autōn* nich [[G846]] WTP-GPM **δεδεκατωκεν** *dedekatōken* przyjął dziesięcinę – zebrał dziesięcinę [[G1183]] WTV-RAI-3S **τον** *ton* (od) [[G3588]] [[T-ASM]] **αβρααμ** *abraam* Abrahama – [ojciec wielu narodów] [[G11]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **τον** *ton* [[G3588]] [[T-ASM]] **εχοντα** *echonta* mającego [[G2192]] WTV-PAP-ASM **τας** *tas* [[G3588]] WTT-APF **επαγγελιας** *epangelias* obietnice [[G1860]] WTN-APF **ευλογηκεν** *eulogēken* pobłogosławił – wysławił [[G2127]] WTV-RAI-3S
###### **Hbr 7,7**
 **χωρις** *chōris* Bez [[G5565]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **πασης** *pasēs* całego – wszystkiego [[G3956]] WTA-GSF **αντιλογιας** *antilogias* sporu – buntu [[G485]] [[N-GSF]] **το** *to* [[G3588]] WTT-NSN **ελαττον** *elatton* gorsze – mniejsze [[G1640]] WTA-NSN **υπο** *hypo* przez [[G5259]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **κρειττονος** *kreittonos* lepsze – znaczniejsze [[G2909]] WTA-GSM **ευλογειται** *eulogeitai* jest błogosławione – jest wysławiane [[G2127]] WTV-PPI-3S
###### **Hbr 7,8**
 **και** *kai* I [[G2532]] [[CONJ]] **ωδε** *hōde* tutaj [[G5602]] [[ADV]] **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **δεκατας** *dekatas* dziesięciny [[G1181]] WTA-APF **αποθνησκοντες** *apothnēskontes* umierający [[G599]] WTV-PAP-NPM **ανθρωποι** *anthrōpoi* ludzie [[G444]] WTN-NPM **λαμβανουσιν** *lambanousin* przyjmują – biorą [[G2983]] WTV-PAI-3P **εκει** *ekei* tam [[G1563]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **μαρτυρουμενος** *martyroumenos* który jest poświadczany [[G3140]] [[V-PPP-NSM]] **οτι** *hoti* że [[G3754]] [[CONJ]] **ζη** *zē* żyje [[G2198]] WTV-PAI-3S
###### **Hbr 7,9**
 **και** *kai* I [[G2532]] [[CONJ]] **ως** *hōs* jak [[G5613]] [[ADV]] **επος** *epos* wypowiedź – słowo [[G2031]] WTN-ASN **ειπειν** *eipein* powiedzieć [[G2036]] [[V-2AAN]] **δια** *dia* przez [[G1223]] [[PREP]] **αβρααμ** *abraam* Abrahama – [ojciec wielu narodów] [[G11]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **λευι** *leui* Lewi – [przyłączyć] [[G3017]] [[N-PRI]] **ο** *ho* [[G3588]] [[T-NSM]] **δεκατας** *dekatas* dziesięciny [[G1181]] WTA-APF **λαμβανων** *lambanōn* przyjmujący – biorący [[G2983]] [[V-PAP-NSM]] **δεδεκατωται** *dedekatōtai* jest obłożony dziesięciną [[G1183]] WTV-RPI-3S
###### **Hbr 7,10**
 **ετι** *eti* jeszcze [[G2089]] [[ADV]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **οσφυι** *osfyi* lędźwi – biodrze [[G3751]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSM **πατρος** *patros* ojca [[G3962]] [[N-GSM]] **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **οτε** *hote* gdy [[G3753]] [[ADV]] **συνηντησεν** *synēntēsen* wyszedł na spotkanie – przyszedł naprzeciwko [[G4876]] [[V-AAI-3S]] **αυτω** *autō* mu [[G846]] WTP-DSM **ο** *ho* [[G3588]] [[T-NSM]] **μελχισεδεκ** *melchisedek* Melchisedek – [król sprawiedliwości] [[G3198]] [[N-PRI]]
###### **Hbr 7,11**
 **ει** *ei* Jeśli [[G1487]] WTCOND **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **ουν** *oun* więc [[G3767]] [[CONJ]] **τελειωσις** *teleiōsis* doskonałość – dojrzałość [[G5050]] [[N-NSF]] **δια** *dia* przez [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **λευιτικης** *leuitikēs* lewickie – [przyłączyć] [[G3020]] WTA-GSF **ιερωσυνης** *hierōsynēs* kapłaństwo [[G2420]] [[N-GSF]] **ην** *ēn* było [[G2258]] [[V-IXI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **λαος** *laos* lud [[G2992]] [[N-NSM]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **επ** *ep* z powodu [[G1909]] [[PREP]] **αυτη** *autē* niego [[G846]] WTP-DSF **νενομοθετητο** *nenomothetēto* otrzymał prawo – otrzymał ustanowienie [[G3549]] WTV-LPI-3S **τις** *tis* jaka [[G5101]] WTI-NSF **ετι** *eti* jeszcze [[G2089]] [[ADV]] **χρεια** *chreia* potrzeba [[G5532]] [[N-NSF]] **κατα** *kata* (by) według [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **ταξιν** *taksin* porządku [[G5010]] WTN-ASF **μελχισεδεκ** *melchisedek* Melchisedeka – [król sprawiedliwości] [[G3198]] [[N-PRI]] **ετερον** *heteron* innego [[G2087]] WTA-ASM **ανιστασθαι** *anistasthai* powstawać – wzbudzać [[G450]] WTV-PMN **ιερεα** *hierea* kapłana [[G2409]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **κατα** *kata* według [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **ταξιν** *taksin* porządku [[G5010]] WTN-ASF **ααρων** *aarōn* Aarona – [wywyższony] [[G2]] [[N-PRI]] **λεγεσθαι** *legesthai* być nazywanym [[G3004]] WTV-PPN
###### **Hbr 7,12**
 **μετατιθεμενης** *metatithemenēs* Gdy jest zamieniane – Gdy jest przenoszone [[G3346]] WTV-PPP-GSF **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **της** *tēs* [[G3588]] [[T-GSF]] **ιερωσυνης** *hierōsynēs* kapłaństwo [[G2420]] [[N-GSF]] **εξ** *eks* z [[G1537]] [[PREP]] **αναγκης** *anagkēs* konieczności – przymusu [[G318]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **νομου** *nomou* Prawa [[G3551]] [[N-GSM]] **μεταθεσις** *metathesis* zamienienie – przemieszczenie [[G3331]] [[N-NSF]] **γινεται** *ginetai* staje się [[G1096]] WTV-PNI-3S
###### **Hbr 7,13**
 **εφ** *ef* O [[G1909]] [[PREP]] **ον** *hon* którym [[G3739]] WTR-ASM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **λεγεται** *legetai* jest mówione [[G3004]] WTV-PPI-3S **ταυτα** *tauta* te [[G5023]] WTD-NPN **φυλης** *fylēs* plemię [[G5443]] [[N-GSF]] **ετερας** *heteras* inne [[G2087]] WTA-GSF **μετεσχηκεν** *meteschēken* uczestniczyło [[G3348]] WTV-RAI-3S **αφ** *af* z [[G575]] [[PREP]] **ης** *hēs* którego [[G3739]] [[R-GSF]] **ουδεις** *oudeis* nikt [[G3762]] [[A-NSM]] **προσεσχηκεν** *proseschēken* miał zwróconą uwagę – zważał [[G4337]] WTV-RAI-3S **τω** *tō* (ku) [[G3588]] WTT-DSN **θυσιαστηριω** *thysiastēriō* ołtarzowi [[G2379]] WTN-DSN
###### **Hbr 7,14**
 **προδηλον** *prodēlon* wcześniej jawne [[G4271]] WTA-NSN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **οτι** *hoti* że [[G3754]] [[CONJ]] **εξ** *eks* z [[G1537]] [[PREP]] **ιουδα** *iouda* Judy – [wielbić] [[G2448]] [[N-GSM]] **ανατεταλκεν** *anatetalken* wzrósł – wstał [[G393]] WTV-RAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **ημων** *hēmōn* nasz [[G2257]] WTP-1GP **εις** *eis* w [[G1519]] [[PREP]] **ην** *hēn* którym [[G3739]] WTR-ASF **φυλην** *fylēn* plemieniu [[G5443]] WTN-ASF **ουδεν** *ouden* nic [[G3762]] WTA-ASN **περι** *peri* o [[G4012]] [[PREP]] **ιερωσυνης** *hierōsynēs* kapłaństwie [[G2420]] [[N-GSF]] **μωσης** *mōsēs* Mojżesz – [wyciągnąć] [[G3475]] [[N-NSM]] **ελαλησεν** *elalēsen* powiedział [[G2980]] [[V-AAI-3S]]
###### **Hbr 7,15**
 **και** *kai* I [[G2532]] [[CONJ]] **περισσοτερον** *perissoteron* obficiej [[G4054]] WTA-NSN-C **ετι** *eti* jeszcze [[G2089]] [[ADV]] **καταδηλον** *katadēlon* oczywiste – jawne [[G2612]] WTA-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ει** *ei* jeśli [[G1487]] WTCOND **κατα** *kata* według [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **ομοιοτητα** *homoiotēta* podobieństwa [[G3665]] WTN-ASF **μελχισεδεκ** *melchisedek* Melchisedeka – [król sprawiedliwości] [[G3198]] [[N-PRI]] **ανισταται** *anistatai* wstaje – podnosi się [[G450]] WTV-PMI-3S **ιερευς** *hiereus* kapłan [[G2409]] [[N-NSM]] **ετερος** *heteros* inny [[G2087]] [[A-NSM]]
###### **Hbr 7,16**
 **ος** *hos* który [[G3739]] WTR-NSM **ου** *ou* nie [[G3756]] [[PRT-N]] **κατα** *kata* według [[G2596]] [[PREP]] **νομον** *nomon* Prawa [[G3551]] [[N-ASM]] **εντολης** *entolēs* przykazania [[G1785]] [[N-GSF]] **σαρκικης** *sarkikēs* cielesnego [[G4559]] WTA-GSF **γεγονεν** *gegonen* stał się [[G1096]] WTV-2RAI-3S **αλλα** *alla* ale [[G235]] [[CONJ]] **κατα** *kata* według [[G2596]] [[PREP]] **δυναμιν** *dynamin* mocy [[G1411]] WTN-ASF **ζωης** *zōēs* życia [[G2222]] [[N-GSF]] **ακαταλυτου** *akatalytou* niezniszczalnego [[G179]] WTA-GSF
###### **Hbr 7,17**
 **μαρτυρει** *martyrei* świadczy [[G3140]] WTV-PAI-3S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **οτι** *hoti* że [[G3754]] [[CONJ]] **συ** *sy* Ty [[G4771]] WTP-2NS **ιερευς** *hiereus* kapłan [[G2409]] [[N-NSM]] **εις** *eis* na [[G1519]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **αιωνα** *aiōna* wiek [[G165]] [[N-ASM]] **κατα** *kata* według [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **ταξιν** *taksin* porządku [[G5010]] WTN-ASF **μελχισεδεκ** *melchisedek* Melchisedeka – [król sprawiedliwości] [[G3198]] [[N-PRI]]
###### **Hbr 7,18**
 **αθετησις** *athetēsis* Unieważnienie – Odrzucenie [[G115]] [[N-NSF]] **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **γινεται** *ginetai* staje się [[G1096]] WTV-PNI-3S **προαγουσης** *proagousēs* które jest poprzednie – które jest wcześniejsze [[G4254]] WTV-PAP-GSF **εντολης** *entolēs* przykazanie [[G1785]] [[N-GSF]] **δια** *dia* z powodu [[G1223]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **αυτης** *autēs* jego [[G846]] [[P-GSF]] **ασθενες** *asthenes* słabości – bezsilności [[G772]] WTA-ASN **και** *kai* i [[G2532]] [[CONJ]] **ανωφελες** *anōfeles* bezużyteczności – niekorzystności [[G512]] WTA-ASN
###### **Hbr 7,19**
 **ουδεν** *ouden* nic [[G3762]] WTA-ASN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ετελειωσεν** *eteleiōsen* uczyniło doskonałym – zostało doprowadzone do doskonałości [[G5048]] [[V-AAI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **νομος** *nomos* Prawo [[G3551]] [[N-NSM]] **επεισαγωγη** *epeisagōgē* późniejsze wprowadzenie [[G1898]] [[N-NSF]] **δε** *de* zaś [[G1161]] [[CONJ]] **κρειττονος** *kreittonos* lepszej – znaczniejszej [[G2909]] WTA-GSF **ελπιδος** *elpidos* nadziei [[G1680]] [[N-GSF]] **δι** *di* przez [[G1223]] [[PREP]] **ης** *hēs* którą [[G3739]] [[R-GSF]] **εγγιζομεν** *engizomen* zbliżamy się do – jesteśmy bliscy [[G1448]] WTV-PAI-1P **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM
###### **Hbr 7,20**
 **και** *kai* I [[G2532]] [[CONJ]] **καθ** *kath* o [[G2596]] [[PREP]] **οσον** *hoson* ile – jak wiele [[G3745]] WTK-ASN **ου** *ou* nie [[G3756]] [[PRT-N]] **χωρις** *chōris* bez [[G5565]] [[ADV]] **ορκωμοσιας** *horkōmosias* przysięgi [[G3728]] [[N-GSF]] **οι** *hoi* [[G3588]] WTT-NPM **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **χωρις** *chōris* bez [[G5565]] [[ADV]] **ορκωμοσιας** *horkōmosias* przysięgi [[G3728]] [[N-GSF]] **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **ιερεις** *hiereis* kapłani [[G2409]] WTN-NPM **γεγονοτες** *gegonotes* którzy stali się [[G1096]] WTV-2RAP-NPM
###### **Hbr 7,21**
 **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **μετα** *meta* z [[G3326]] [[PREP]] **ορκωμοσιας** *horkōmosias* przysięgą [[G3728]] [[N-GSF]] **δια** *dia* przez [[G1223]] [[PREP]] **του** *tou* (Tego) [[G3588]] WTT-GSM **λεγοντος** *legontos* który mówi [[G3004]] WTV-PAP-GSM **προς** *pros* do [[G4314]] [[PREP]] **αυτον** *auton* Niego [[G846]] WTP-ASM **ωμοσεν** *ōmosen* przysiągł [[G3660]] [[V-AAI-3S]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **μεταμεληθησεται** *metamelēthēsetai* będzie żałował – zmieni zdania [[G3338]] WTV-FOI-3S **συ** *sy* Ty [[G4771]] WTP-2NS **ιερευς** *hiereus* kapłan [[G2409]] [[N-NSM]] **εις** *eis* na [[G1519]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **αιωνα** *aiōna* wiek [[G165]] [[N-ASM]] **κατα** *kata* według [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **ταξιν** *taksin* porządku [[G5010]] WTN-ASF **μελχισεδεκ** *melchisedek* Melchisedeka – [król sprawiedliwości] [[G3198]] [[N-PRI]]
###### **Hbr 7,22**
 **κατα** *kata* o [[G2596]] [[PREP]] **τοσουτον** *tosouton* tak wiele – tyle [[G5118]] WTD-ASN **κρειττονος** *kreittonos* lepszego – znaczniejszego [[G2909]] WTA-GSF **διαθηκης** *diathēkēs* przymierza [[G1242]] [[N-GSF]] **γεγονεν** *gegonen* stał się [[G1096]] WTV-2RAI-3S **εγγυος** *engyos* gwarant – poręczyciel [[G1450]] [[A-NSM]] **ιησους** *iēsous* Jezus – [JHWH jest zbawieniem] [[G2424]] [[N-NSM]]
###### **Hbr 7,23**
 **και** *kai* I [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **πλειονες** *pleiones* liczniejszymi [[G4119]] WTA-NPM-C **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **γεγονοτες** *gegonotes* którzy stali się [[G1096]] WTV-2RAP-NPM **ιερεις** *hiereis* kapłani [[G2409]] WTN-NPM **δια** *dia* przez [[G1223]] [[PREP]] **το** *to* (to, że) [[G3588]] WTT-ASN **θανατω** *thanatō* śmierci [[G2288]] WTN-DSM **κωλυεσθαι** *kōlyesthai* być powstrzymanym – być utrudnionym [[G2967]] WTV-PPN **παραμενειν** *paramenein* (by) pozostać – (by) trwać [[G3887]] WTV-PAN
###### **Hbr 7,24**
 **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **δια** *dia* przez [[G1223]] [[PREP]] **το** *to* (to, że) [[G3588]] WTT-ASN **μενειν** *menein* pozostawać [[G3306]] WTV-PAN **αυτον** *auton* Mu [[G846]] WTP-ASM **εις** *eis* na [[G1519]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **αιωνα** *aiōna* wiek [[G165]] [[N-ASM]] **απαραβατον** *aparabaton* niemożliwe do przejścia – niezmienne [[G531]] WTA-ASF **εχει** *echei* ma [[G2192]] WTV-PAI-3S **την** *tēn* [[G3588]] WTT-ASF **ιερωσυνην** *hierōsynēn* kapłaństwo [[G2420]] WTN-ASF
###### **Hbr 7,25**
 **οθεν** *hothen* Dlatego – Stąd [[G3606]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **σωζειν** *sōzein* ratować – zbawiać [[G4982]] WTV-PAN **εις** *eis* na [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **παντελες** *panteles* zawsze – całkowite [[G3838]] WTA-ASN **δυναται** *dynatai* może [[G1410]] WTV-PNI-3S **τους** *tous* [[G3588]] WTT-APM **προσερχομενους** *proserchomenous* podchodzących – zbliżających się [[G4334]] WTV-PNP-APM **δι** *di* przez [[G1223]] [[PREP]] **αυτου** *autou* Niego [[G846]] [[P-GSM]] **τω** *tō* (ku) [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **παντοτε** *pantote* zawsze – w każdej chwili [[G3842]] [[ADV]] **ζων** *zōn* żyjąc [[G2198]] [[V-PAP-NSM]] **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **εντυγχανειν** *entygchanein* wstawiać się [[G1793]] WTV-PAN **υπερ** *hyper* za [[G5228]] [[PREP]] **αυτων** *autōn* nich [[G846]] WTP-GPM
###### **Hbr 7,26**
 **τοιουτος** *toioutos* Taki [[G5108]] WTD-NSM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ημιν** *hēmin* nam [[G2254]] WTP-1DP **επρεπεν** *eprepen* przystało – dopasowało się [[G4241]] WTV-IAI-3S **αρχιερευς** *archiereus* arcykapłan [[G749]] [[N-NSM]] **οσιος** *hosios* świętobliwy – święty [[G3741]] [[A-NSM]] **ακακος** *akakos* niewinny – prostoduszny [[G172]] [[A-NSM]] **αμιαντος** *amiantos* nieskazitelny – nieskalany [[G283]] [[A-NSM]] **κεχωρισμενος** *kechōrismenos* który jest odłączony – który jest oddzielony [[G5563]] WTV-RPP-NSM **απο** *apo* od [[G575]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **αμαρτωλων** *hamartōlōn* grzeszników [[G268]] WTA-GPM **και** *kai* i [[G2532]] [[CONJ]] **υψηλοτερος** *hypsēloteros* wyższy [[G5308]] [[A-NSM]]-C **των** *tōn* (od) [[G3588]] WTT-GPM **ουρανων** *ouranōn* niebios [[G3772]] WTN-GPM **γενομενος** *genomenos* który stał się [[G1096]] WTV-2ADP-NSM
###### **Hbr 7,27**
 **ος** *hos* Ten [[G3739]] WTR-NSM **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εχει** *echei* ma [[G2192]] WTV-PAI-3S **καθ** *kath* co [[G2596]] [[PREP]] **ημεραν** *hēmeran* dzień [[G2250]] WTN-ASF **αναγκην** *anagkēn* konieczności – przymus [[G318]] WTN-ASF **ωσπερ** *hōsper* tak, jak [[G5618]] [[ADV]] **οι** *hoi* [[G3588]] WTT-NPM **αρχιερεις** *archiereis* arcykapłani [[G749]] WTN-NPM **προτερον** *proteron* wcześniej [[G4386]] [[ADV]] **υπερ** *hyper* za [[G5228]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPF **ιδιων** *idiōn* własne [[G2398]] WTA-GPM **αμαρτιων** *hamartiōn* grzechy [[G266]] WTN-GPF **θυσιας** *thysias* ofiary [[G2378]] WTN-APF **αναφερειν** *anaferein* prowadzić – nosić [[G399]] WTV-PAN **επειτα** *epeita* następnie [[G1899]] [[ADV]] **των** *tōn* (za te) [[G3588]] WTT-GPF **του** *tou* [[G3588]] WTT-GSM **λαου** *laou* ludu [[G2992]] [[N-GSM]] **τουτο** *touto* to [[G5124]] WTD-ASN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εποιησεν** *epoiēsen* uczynił [[G4160]] [[V-AAI-3S]] **εφαπαξ** *efapaks* raz na zawsze [[G2178]] [[ADV]] **εαυτον** *heauton* siebie samego [[G1438]] WTF-3ASM **ανενεγκας** *anenegkas* wzniósłszy [[G399]] WTV-AAP-NSM
###### **Hbr 7,28**
 **ο** *ho* [[G3588]] [[T-NSM]] **νομος** *nomos* Prawo [[G3551]] [[N-NSM]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ανθρωπους** *anthrōpous* ludzi [[G444]] [[N-APM]] **καθιστησιν** *kathistēsin* ustanawia [[G2525]] WTV-PAI-3S **αρχιερεις** *archiereis* arcykapłanami [[G749]] [[N-APM]] **εχοντας** *echontas* mających [[G2192]] WTV-PAP-APM **ασθενειαν** *astheneian* słabość – bezsiłę [[G769]] WTN-ASF **ο** *ho* [[G3588]] [[T-NSM]] **λογος** *logos* słowo [[G3056]] [[N-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **της** *tēs* [[G3588]] [[T-GSF]] **ορκωμοσιας** *horkōmosias* przysięgi [[G3728]] [[N-GSF]] **της** *tēs* [[G3588]] [[T-GSF]] **μετα** *meta* po [[G3326]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **νομον** *nomon* Prawie [[G3551]] [[N-ASM]] **υιον** *hyion* Syna [[G5207]] [[N-ASM]] **εις** *eis* na [[G1519]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **αιωνα** *aiōna* wiek [[G165]] [[N-ASM]] **τετελειωμενον** *teteleiōmenon* który jest uczyniony doskonałym – który jest doprowadzony do doskonałości [[G5048]] WTV-RPP-ASM
