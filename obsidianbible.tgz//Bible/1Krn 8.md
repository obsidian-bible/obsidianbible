# 1Krn 8 BT5
###### **1Krn 8,1**
 Beniamin był ojcem swego pierworodnego – Beli; drugiego – Aszbela, trzeciego – Achracha,
###### **1Krn 8,2**
 czwartego – Nochy, piątego – Rafy.
###### **1Krn 8,3**
 Synami Beli byli: Addar, Gera, ojciec Ehuda,
###### **1Krn 8,4**
 Abiszua, Naaman i Achoach,
###### **1Krn 8,5**
 Gera, Szefufan i Churam.
###### **1Krn 8,6**
 Oto synowie Ehuda; ci byli naczelnikami rodów mieszkających w Geba i przesiedlono ich do Manachat:
###### **1Krn 8,7**
 Naaman, Achiasz i Gera; on to ich przesiedlił i był ojcem Uzzy i Achichuda,
###### **1Krn 8,8**
 a Szacharaima – w kraju Moabu. Potem gdy odprawił swe żony: Chuszim i Baarę,
###### **1Krn 8,9**
 miał ze swej nowej żony: Jobaba, Sibię, Meszę, Malkoma,
###### **1Krn 8,10**
 Jeusa, Sakiasza i Mirmę; ci byli jego synami, naczelnikami rodów.
###### **1Krn 8,11**
 Z Chuszim miał: Abituba i Elpaala.
###### **1Krn 8,12**
 Synowie Elpaala: Eber, Miszam i Szemed, on to zbudował Ono, Lod i miejscowości przynależne.
###### **1Krn 8,13**
 Beria i Szema byli naczelnikami rodów mieszkających w Ajjalonie; oni to wypędzili mieszkańców Gat.
###### **1Krn 8,14**
 Achio, Szaszak, Jeremot,
###### **1Krn 8,15**
 Zebadiasz, Arad, Eder,
###### **1Krn 8,16**
 Mikael, Jiszpa i Jocha byli synami Berii,
###### **1Krn 8,17**
 Zebadiasz, Meszullam, Chizki, Cheber,
###### **1Krn 8,18**
 Jiszmeraj, Jizlia i Jobab byli synami Elpaala.
###### **1Krn 8,19**
 Jakim, Zikri, Zabdi,
###### **1Krn 8,20**
 Elienaj, Silletaj, Eliel,
###### **1Krn 8,21**
 Adajasz, Berajasz, Szimrat byli synami Szimejego.
###### **1Krn 8,22**
 Jiszpan, Eber, Eliel,
###### **1Krn 8,23**
 Abdon, Zikri, Chanan,
###### **1Krn 8,24**
 Chananiasz, Elam, Antotiasz,
###### **1Krn 8,25**
 Jifdejasz iniel byli synami Szaszaka.
###### **1Krn 8,26**
 Szamszeraj, Szechariasz, Ataliasz,
###### **1Krn 8,27**
 Jaareszjasz, Eliasz, Zikri byli synami Jerochama.
###### **1Krn 8,28**
 Ci byli naczelnikami rodów według ich spisów; zamieszkali oni w Jerozolimie.
###### **1Krn 8,29**
 W Gibeonie zamieszkał ojciec Gibeonu; jego żona miała na imię Maaka.
###### **1Krn 8,30**
 Jego synem pierworodnym był Abdon, potem Sur, Kisz, Baal, Ner, Nadab,
###### **1Krn 8,31**
 Gedor, Achio i Zeker.
###### **1Krn 8,32**
 Miklot był ojcem Szimejego. Oni również mieszkali w pobliżu swych krewnych ze swoimi braćmi w Jerozolimie.
###### **1Krn 8,33**
 Ner był ojcem Kisza, Kisz – Saula. Saul był ojcem Jonatana, Malkiszuy, Abinadaba i Eszbaala.
###### **1Krn 8,34**
 Synem Jonatana był Meribbaal; Meribbaal był ojcem Miki.
###### **1Krn 8,35**
 Synowie Miki: Piton, Melek, Tarea i Achaz.
###### **1Krn 8,36**
 Achaz był ojcem Joaddy; Joadda – Alemeta, Azmaweta i Zimriego; Zimri był ojcem Mosy.
###### **1Krn 8,37**
 Mosa był ojcem Binei; jego synem był Rafa, synem jego Eleasa, synem jego Asel.
###### **1Krn 8,38**
 Asel miał sześciu synów, a oto ich imiona: Azrikam, Bokru, Izmael, Szeariasz, Obadiasz i Chanan. Wszyscy oni byli synami Asela.
###### **1Krn 8,39**
 Synowie jego brata Eszeka: Ulam, jego pierworodny, drugi Jeusz, trzeci Elifelet.
###### **1Krn 8,40**
 Synowie Ulama byli dzielnymi wojownikami strzelającymi z łuku. Mieli oni wielu synów i wnuków – stu pięćdziesięciu. Ci wszyscy byli potomkami Beniamina.
# 1Krn 8 PAU
###### **1Krn 8,1**
 Pierworodnym synem Beniamina był Bela, drugim - Aszbel, trzecim - Achrach,
###### **1Krn 8,2**
 czwartym - Nocha, a piątym - Rafa.
###### **1Krn 8,3**
 Potomkami Beli byli: Addar, Gera, ojciec Ehuda,
###### **1Krn 8,4**
 Abiszua, Naaman i Achoach,
###### **1Krn 8,5**
 Gera, Szefufan i Churam.
###### **1Krn 8,6**
 Oto potomkowie Ehuda, którzy przewodzili rodom mieszkających w Geba, przesiedlonym następnie do Manachat:
###### **1Krn 8,7**
 Naaman, Achiasz i Gera, który ich przesiedlił, ojciec Uzzy i Achichuda.
###### **1Krn 8,8**
 Kiedy Szacharaim odprawił żony Chuszim i Baarę, nowa żona urodziła mu w Moabie tych synów:
###### **1Krn 8,9**
 Jobaba, Sibię, Meszę, Malkoma,
###### **1Krn 8,10**
 Jeusa, Sakiasza i Mirmę. Byli oni przywódcami rodów.
###### **1Krn 8,11**
 Chuszim urodziła mu Abituba i Elpaala.
###### **1Krn 8,12**
 Synami Elpaala byli: Eber, Miszam i Szemed. To on zbudował Ono, Lod z przysiółkami.
###### **1Krn 8,13**
 Beria i Szema byli przywódcami rodów mieszkających w Ajjalonie. To oni wypędzili mieszkańców Gat.
###### **1Krn 8,14**
 Achio, Szaszak, Jeremot,
###### **1Krn 8,15**
 Zebadiasz, Arad, Eder,
###### **1Krn 8,16**
 Mikael, Jeszpa i Jocha byli potomkami Berii.
###### **1Krn 8,17**
 Zebadiasz, Meszullam, Chizki, Cheber,
###### **1Krn 8,18**
 Jeszmeraj, Jezlia i Jobab byli potomkami Elpaala.
###### **1Krn 8,19**
 Jakim, Zikri, Zabdi,
###### **1Krn 8,20**
 Elienaj, Silletaj, Eliel,
###### **1Krn 8,21**
 Adajasz, Berajasz, Szimrat byli potomkami Szimeiego.
###### **1Krn 8,22**
 Jeszpan, Eber, Eliel,
###### **1Krn 8,23**
 Abdon, Zikri, Chanan,
###### **1Krn 8,24**
 Chananiasz, Elam, Antotiasz,
###### **1Krn 8,25**
 Jefdejasz i Peniel byli potomkami Szaszaka.
###### **1Krn 8,26**
 Szamszeraj, Szechariasz, Ataliasz,
###### **1Krn 8,27**
 Jaareszjasz, Eliasz i Zikri byli potomkami Jerochama.
###### **1Krn 8,28**
 Oni byli przywódcami rodów zgodnie ze spisami. Zamieszkali w Jerozolimie.
###### **1Krn 8,29**
 W Gabaonie mieszkał ojciec Gabaona, założyciel miasta, wraz ze swą żoną o imieniu Maaka.
###### **1Krn 8,30**
 Jego pierworodnym synem był Abdon, a następni to: Sur, Kisz, Baal, Ner, Nadab,
###### **1Krn 8,31**
 Gedor, Achio, Zeker i Miklot.
###### **1Krn 8,32**
 Miklotowi urodził się Szima. Oni również mieszkali w Jerozolimie ze swymi braćmi.
###### **1Krn 8,33**
 Ner był ojcem Kisza, a Kisz - Saula. Saul był ojcem Jonatana, Malkiszuy, Abinadaba i Eszbaala.
###### **1Krn 8,34**
 Synem Jonatana był Meribbaal, a synem Meribbaala - Mika.
###### **1Krn 8,35**
 Synami Miki byli: Piton, Melek, Tarea i Achaz.
###### **1Krn 8,36**
 Achaz był ojcem Joaddy, a Joadda - Alemeta, Azmaweta i Zimriego. Zimri zaś był ojcem Mosy.
###### **1Krn 8,37**
 Mosa był ojcem Binei. Binea - ojcem Rafajasza. Rafajasz - ojcem Eleasy. Eleasa zaś - ojcem Asela.
###### **1Krn 8,38**
 Asel miał sześciu synów, oto ich imiona: Azrikam, Bokru, Izmael, Szeariasz, Obadiasz i Chanan. Wszyscy oni byli synami Asela.
###### **1Krn 8,39**
 Synami jego brata Eszeka byli: pierworodny Ulam, a po nim Jeusz i Elifelet jako trzeci.
###### **1Krn 8,40**
 Synowie Ulama byli doskonałymi wojownikami i świetnymi łucznikami. Mieli wielu synów i wnuków - w sumie stu pięćdziesięciu. Wszyscy oni byli Beniaminitami.
# 1Krn 8 BP
###### **1Krn 8,1**
 Pierworodnym synem Beniamina był Bela, drugim Aszbel, trzecim Achrach,
###### **1Krn 8,2**
 czwartym Noach, piątym Rafa.
###### **1Krn 8,3**
 Synami Beli byli: Addar, Gera, Abihud,
###### **1Krn 8,4**
 Abiszua, Naaman, Achoach,
###### **1Krn 8,5**
 Gera, Szefufan i Churam.
###### **1Krn 8,6**
 A ci oto są synami Ehuda; byli oni naczelnikami rodów mieszkających w Geba i zostali uprowadzeni do Manachat.
###### **1Krn 8,7**
 Naaman, Achijja i Gera. Ten ich przesiedlił, a był on ojcem Uzzy i Achichuda.
###### **1Krn 8,8**
 Szacharajim miał synów w krainie Moab, po odesłaniu swoich żon: Chuszimy i Baary.
###### **1Krn 8,9**
 Jego żona Chodesz urodziła mu: Jobaba, Cibję, Meszę, Malkama,
###### **1Krn 8,10**
 Jeuca, Sakję i Mirmę. Ci jego synowie byli naczelnikami rodów.
###### **1Krn 8,11**
 A z Chuszimy miał Abituba i Elpaala.
###### **1Krn 8,12**
 Synami Elpaala byli: Eber, Miszam i Szemed, który zbudował Ono i Lod wraz z zależnymi od nich osiedlami.
###### **1Krn 8,13**
 Beria i Szema byli naczelnikami rodów mieszkających w Ajjalonie. Wypędzili oni mieszkańców Get.
###### **1Krn 8,14**
 Jego braćmi byli: Szaszak, Jeremot.
###### **1Krn 8,15**
 Zebadja zaś, Arad, Ader,
###### **1Krn 8,16**
 Mikael, Jiszpa i Jocha byli synami Berii.
###### **1Krn 8,17**
 Zebadja, Meszullam, Chizki, Cheber,
###### **1Krn 8,18**
 Jiszmeraj, Jiziia i Jobab byli [synami] Elpaala.
###### **1Krn 8,19**
 Jakim, Zikri, Zabdi,
###### **1Krn 8,20**
 Elienaj, Ciiietaj, Eliel,
###### **1Krn 8,21**
 Adaja, Beraja i Szimrat byli synami Szimiego.
###### **1Krn 8,22**
 Jiszpan, Eber, Eliel,
###### **1Krn 8,23**
 Abdon, Zikri, Chanan,
###### **1Krn 8,24**
 Chananja, Elam, Antotijja,
###### **1Krn 8,25**
 Jifdeja i Feniel byli synami Szaszaka.
###### **1Krn 8,26**
 Szamszeraj, Szecharja, Ataija,
###### **1Krn 8,27**
 Jaareszja, Elijja i Zikri byli synami Jerochama.
###### **1Krn 8,28**
 Oni to byli naczelnikami rodów z nimi spokrewnionych, a mieszkali w Jeruzalem.
###### **1Krn 8,29**
 W Gibeonie mieszkał ojciec Gibeonu Jeiel, a żona jego miała na imię Maaka.
###### **1Krn 8,30**
 Jego pierworodnym synem był Abdon, [a następnymi] Cur, Kisz, Baal, Nadab,
###### **1Krn 8,31**
 Gedor, Achjoi Zaker.
###### **1Krn 8,32**
 Miklot był ojcem Szimiego. Ci również wraz ze swymi braćmi mieszkali w Jeruzalem naprzeciw swych braci.
###### **1Krn 8,33**
 Ner był ojcem Kisza. Kisz był ojcem Saula, a Saul był ojcem Jonatana, Malkiszui, Abinadaba i Eszbaala.
###### **1Krn 8,34**
 Synem Jonatana był Meribbaal. Meribbaal był ojcem Miki.
###### **1Krn 8,35**
 Synami Miki byli: Piton, Melek, Tarea i Achaz.
###### **1Krn 8,36**
 Achaz był ojcem Jehoaddy, a Jehoadda był ojcem Alemeta, Azmaweta i Zimnego. Zimri był ojcem Mocy.
###### **1Krn 8,37**
 Moca był ojcem Biny, którego synem był Rafa, jego synem był Elasa, a jego synem Acel.
###### **1Krn 8,38**
 Acel miał sześciu synów o takich imionach: Azrikam, Bokru, Jiszmael, Szearja, Abadja i Chanan. Ci wszyscy byli synami Acela.
###### **1Krn 8,39**
 Synami jego brata Eszeka byli: pierworodny Ulam, drugi Jeusz, trzeci Elifelet.
###### **1Krn 8,40**
 Ulam miał synów, którzy byli dzielnymi wojownikami, sprawnymi łucznikami. Mieli oni wielu synów i wnuków [razem] 150. Wszyscy byli oni Beniaminitami.9
# 1Krn 8 BR
###### **1Krn 8,1**
 Beniamin miał pięciu synów. Pierwszy z nich, pierworodny, nazywał się Bela, drugi Aszbel, trzeci Achrach,
###### **1Krn 8,2**
 cztwarty Nocha, piąty Rafa.
###### **1Krn 8,3**
 Synami Beli byli: Addar, Gera, Abihud,
###### **1Krn 8,4**
 Abiszua, Naaman, Achoach,
###### **1Krn 8,5**
 Gera, Szefufan i Churam.
###### **1Krn 8,6**
 A oto synowie Ehuda, naczelnicy rodów, mieszkających początkowo w Geba, a potem w Manachat:
###### **1Krn 8,7**
 Naaman, Achiasz i Gera. To za sprawą Gery dokonało się ich przesiedlenie. Synami Gery byli Uzza, Achichud i
###### **1Krn 8,8**
 Szachraim - w kraju Moabu. Gdy zaś [Gera] oddalił od siebie swe żony Chuszimę i Baarę,
###### **1Krn 8,9**
 jego [nowa] żona urodziła mu synów: Jobaba, Sibię, Meszę, Malkoma,
###### **1Krn 8,10**
 Jeusa, Sakiasza i Mirmę. Tak nazywali się ci synowie; wszyscy byli naczelnikami rodów.
###### **1Krn 8,11**
 Chuszim natomiast była matką Abituba i Elpaala.
###### **1Krn 8,12**
 Synami zaś Elpaala byli: Eber, Miszam i Szemed. To Szemed zbudował Ono, Lod i okoliczne miasta.
###### **1Krn 8,13**
 Beria i Szema byli naczelnikami rodów mieszkających w Ajjalonie. Oni to wypędzili mieszkańców Gat z ich własnego miasta.
###### **1Krn 8,14**
 Synami Berii byli: Achio, Szaszak, Jeremot,
###### **1Krn 8,15**
 Zebadiasz, Arad, Eder,
###### **1Krn 8,16**
 Mikael, Jiszpa i Jocha.
###### **1Krn 8,17**
 Synami Elpaala byli: Zebadiasz, Meszullam, Chizki, Cheber,
###### **1Krn 8,18**
 Jiszmeraj, Jizlia i Jobab.
###### **1Krn 8,19**
 Synami Szimeiego byli: Jakim, Zikri, Zabdi,
###### **1Krn 8,20**
 Elienaj, Silletaj, Eliel,
###### **1Krn 8,21**
 Adajasz, Berajasz i Szimrat.
###### **1Krn 8,22**
 Synami Szaszaka byli: Jiszpan, Eber, Eliel,
###### **1Krn 8,23**
 Abdon, Zikri, Chanan,
###### **1Krn 8,24**
 Chananiasz, Elam, Antotiasz,
###### **1Krn 8,25**
 Jifdejasz i Paniel.
###### **1Krn 8,26**
 Synami Jerochama byli: Szamszeraj, Szechariasz, Ataliasz,
###### **1Krn 8,27**
 Jaareszjasz, Eliasz, Zikri.
###### **1Krn 8,28**
 Wszyscy oni byli naczelnikami rodów, według ich wykazów rodowych i mieszkali w Jerozolimie.
###### **1Krn 8,29**
 W Gibeonie żył Abi-Gibeon, którego żona miała na imię Maaka.
###### **1Krn 8,30**
 Synami jego byli: Abdon jako pierworodny, potem Sur, Kisz, Baal, Ner, Nadab,
###### **1Krn 8,31**
 Gedor, Achio i Zeker.
###### **1Krn 8,32**
 Miklot był ojcem Szimeiego. Wszyscy oni mieszkali w pobliżu swoich krewnych, razem z braćmi w Jerozolimie.
###### **1Krn 8,33**
 Ner był ojcem Kisza, Kisz ojcem Saula, Saul ojcem Jonatana, Malkiszuy, Abinadaba i Eszbaala.
###### **1Krn 8,34**
 Jonatan był ojcem Meribbaala, Meribbaal ojcem Miki,
###### **1Krn 8,35**
 synami zaś Miki byli: Piton, Melek, Tarea i Achaz.
###### **1Krn 8,36**
 Achaz był ojcem Joaddy, Joadda ojcem Alemeta, Azmaweta i Zimriego, Zimri zaś był ojcem Mosy.
###### **1Krn 8,37**
 Mosa był ojcem Binei, Binea ojcem Rafy, Rafa ojcem Eleasy, Eleasa ojcem Aserla.
###### **1Krn 8,38**
 A oto sześciu synów Asela: Azrikam, Bokru, Izmael, Szeariasz, Obadiasz i Chanan. Tak nazywali się synowie Asela.
###### **1Krn 8,39**
 jego brat Eszek miał trzech synów: pierworodny był Ulam, drugi Jeusz i trzeci Eliefelet.
###### **1Krn 8,40**
 Synowie Ulama byli dzielnymi wojownikami, szczególnie sprawnie potrafili posługiwać się łukiem. Mieli oni wielu - bo w sumie stu pięćdziesięciu - synów i wnuków. Wszyscy wywodzili się od Beniamina.
# 1Krn 8 WUJ
###### **1Krn 8,1**
 A Benjamin zrodził Bale pierworodnego swego, Asbela wtórego, Ahare trzeciego,
###### **1Krn 8,2**
 Nohaa czwartego, i Rapha piątego.
###### **1Krn 8,3**
 A byli synowie Bale, Addar, i Gera, i Abiud,
###### **1Krn 8,4**
 Abisue też, i Naaman i Ahoe,
###### **1Krn 8,5**
 I Gera, i Sephuphan, i Huram.
###### **1Krn 8,6**
 Ci są synowie Achod, książęta rodów mieszkających w Gabaa, którzy przeniesieni są do Mamabath.
###### **1Krn 8,7**
 A Naaman, i Achia, i Gera ten je przeprowadził, i zrodził Oza, i Ahiud.
###### **1Krn 8,8**
 Lecz Saharaim zrpdził w krainie Moabskiej, odprawiwszy Husim, i Barę żony swe.
###### **1Krn 8,9**
 A zrodził z Hodes żony swej Jobaba, i Sebia, i Mosa, i Molchoma,
###### **1Krn 8,10**
 Jehusa, i Sechia, i Marma, ci są synowie jego książęta w domiech ich.
###### **1Krn 8,11**
 A Mehusim zrodził Abitob i Elphaal.
###### **1Krn 8,12**
 A synowie Elphaal: Heber i Misaam, i Samad: ten zbudował Ono, i Lod, i córki jego.
###### **1Krn 8,13**
 Baria lepak i Sama książęta rodów mieszkających w Ajalon: ci wygnali obywatele Geth.
###### **1Krn 8,14**
 I Ahio, i Sesak, i Jerymoth,
###### **1Krn 8,15**
 I Zabadia, i Arod, i Heder,
###### **1Krn 8,16**
 Michael też, i Jespha, i Josa synowie Baria.
###### **1Krn 8,17**
 I Zabadia, i Mosollam, i Hezeci, i Heber,
###### **1Krn 8,18**
 I Jesamari, i Jezlia, i Jobab synowie Elphaal,
###### **1Krn 8,19**
 I Jacim, i Zechri, i Zabdi,
###### **1Krn 8,20**
 I Elioenai, i Selethai, i Eliel,
###### **1Krn 8,21**
 I Adaja, i Baraja, i Samarath synowie Semei.
###### **1Krn 8,22**
 I Jespham, i Heber, i Eliel,
###### **1Krn 8,23**
 I Abdon, i Zechri, i Hanan,
###### **1Krn 8,24**
 I Hanania, i Elam, i Anathotia,
###### **1Krn 8,25**
 I Jephdaja, i Phanuel synowie Sesak,
###### **1Krn 8,26**
 I Samsari, i Sohoria, i Otholia,
###### **1Krn 8,27**
 I Jersia, i Elia, i Zechri, synowie Jeroham.
###### **1Krn 8,28**
 Ci Patryarchowie i książęta rodów, którzy mieszkali w Jeruzalem.
###### **1Krn 8,29**
 A w Gabaon mieszkali Abigabaon, a imię żony jego Maacha:
###### **1Krn 8,30**
 A syn jego pierworodny Abdon, i Sur, i Cis, i Baal, i Nadab.
###### **1Krn 8,31**
 Gedor też i Ahio, i Zacher, i Macelloth:
###### **1Krn 8,32**
 A Macelloth zrodził Samaa: i mieszkali przeciwko braciej swojej w Jeruzalem z bracią swą.
###### **1Krn 8,33**
 Ner lepak zrodził Cis, a Cis zrodził Saula. Saul zaś zrodził Jonathana, i Melchisua, i Abinadaba, i Esbaala.
###### **1Krn 8,34**
 A syn Jonathanów Meribbaal: a Meribbaal spłodził Micha.
###### **1Krn 8,35**
 Synowie Micha: Phiton, i Melech, i Tharaa, i Ahaz.
###### **1Krn 8,36**
 A Ahaz zrodził Joada, a Joada zrodził Alamath, i Azmioth, i Zamri: Zamri lepak zrodził Mosa,
###### **1Krn 8,37**
 A Mosa zrodził Banaa, którego syn był Rapha, z którego poszedł Elasa, który zrodził Asel,
###### **1Krn 8,38**
 A Asel miał sześci synów, tych imion, Ezrikam, Bokru, Ismabel, Saria, Obdia, i Hanan: ci wszyscy synowie Asel.
###### **1Krn 8,39**
 A synowie Esek brata jego: Ulam pierworodny, a Jehus wtóry, a Eliphaleth trzeci.
###### **1Krn 8,40**
 A byli synowie Ulam mężowie barzo duży i wielką mocą łuk ciągnący: i mający wiele synów i wnuków, aż do stu i piącidbiesiąt. Ci wszyscy synowie Benjamin.
