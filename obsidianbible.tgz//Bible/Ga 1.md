# Ga 1 BT5
###### **Ga 1,1**
 Paweł, apostoł nie z ludzkiego ustanowienia czy zlecenia, lecz z ustanowienia Jezusa Chrystusa i Boga Ojca, który Go wskrzesił z martwych,
###### **Ga 1,2**
 oraz wszyscy bracia, którzy są ze mną – do Kościołów Galacji:
###### **Ga 1,3**
 Łaska wam i pokój od Boga, Ojca naszego, i Pana Jezusa Chrystusa,
###### **Ga 1,4**
 który wydał samego siebie za nasze grzechy, aby wyrwać nas z obecnego złego świata, zgodnie z wolą Boga i Ojca naszego.
###### **Ga 1,5**
 Jemu to chwała na wieki wieków! Amen.
###### **Ga 1,6**
 Nadziwić się nie mogę, że od Tego, który was łaską Chrystusa powołał, tak szybko chcecie przejść do innej Ewangelii.
###### **Ga 1,7**
 Innej jednak Ewangelii nie ma: są tylko jacyś ludzie, którzy sieją wśród was zamęt i którzy chcieliby przekręcić Ewangelię Chrystusową.
###### **Ga 1,8**
 Ale gdybyśmy nawet my lub anioł z nieba głosił wam Ewangelię różną od tej, którą wam głosiliśmy – niech będzie przeklęty!
###### **Ga 1,9**
 Już to przedtem powiedzieliśmy, a teraz jeszcze mówię: Gdyby wam ktoś głosił Ewangelię różną od tej, którą [od nas] otrzymaliście – niech będzie przeklęty!
###### **Ga 1,10**
 A zatem teraz: czy zabiegam o względy ludzi, czy raczej Boga? Czy ludziom staram się przypodobać? Gdybym jeszcze ludziom chciał się przypodobać, nie byłbym sługą Chrystusa.
###### **Ga 1,11**
 Oświadczam więc wam, bracia, że głoszona przeze mnie Ewangelia nie jest wymysłem ludzkim.
###### **Ga 1,12**
 Nie otrzymałem jej bowiem ani nie nauczyłem się od jakiegoś człowieka, lecz objawił mi ją Jezus Chrystus.
###### **Ga 1,13**
 Słyszeliście przecież o moim postępowaniu ongiś, gdy jeszcze wyznawałem judaizm, jak z niezwykłą gorliwością zwalczałem Kościół Boży i usiłowałem go zniszczyć,
###### **Ga 1,14**
 jak w żarliwości dla judaizmu przewyższałem wielu moich rówieśników z mego narodu, jak byłem szczególnie wielkim zapaleńcem w zachowywaniu tradycji moich przodków.
###### **Ga 1,15**
 Gdy jednak spodobało się Temu, który wybrał mnie jeszcze w łonie matki mojej i powołał łaską swoją,
###### **Ga 1,16**
 aby objawić Syna swego we mnie, bym Ewangelię o Nim głosił poganom, natychmiast, nie radząc się ciała i krwi
###### **Ga 1,17**
 ani nie udając się do Jerozolimy, do tych, którzy apostołami stali się pierwej niż ja, skierowałem się do Arabii, a później znowu wróciłem do Damaszku.
###### **Ga 1,18**
 Następnie, trzy lata później, udałem się do Jerozolimy, aby poznać się z Kefasem, i zatrzymałem się u niego [tylko] piętnaście dni.
###### **Ga 1,19**
 Spośród zaś innych, którzy należą do grona Apostołów, widziałem jedynie Jakuba, brata Pańskiego.
###### **Ga 1,20**
 A Bóg jest mi świadkiem, że w tym, co tu do was piszę, nie kłamię.
###### **Ga 1,21**
 Potem udałem się do krain Syrii i Cylicji.
###### **Ga 1,22**
 Kościołom zaś chrześcijańskim w Judei pozostawałem osobiście nie znany.
###### **Ga 1,23**
 Docierała do nich jedynie wieść: ten, co dawniej nas prześladował, teraz jako Dobrą Nowinę głosi wiarę, którą ongiś usiłował wytępić.
###### **Ga 1,24**
 I wielbili Boga z mego powodu.
# Ga 1 PAU
###### **Ga 1,1**
 Paweł, powołany na apostoła nie przez ludzi, ani za pośrednictwem człowieka, ale przez Jezusa Chrystusa i Boga Ojca, który wskrzesił Go z martwych,
###### **Ga 1,2**
 oraz wszyscy bracia, którzy są ze mną - do Kościołów Galacji.
###### **Ga 1,3**
 Niech będzie z wami łaska i pokój Boga naszego Ojca i Pana Jezusa Chrystusa.
###### **Ga 1,4**
 On wydał samego siebie za nasze grzechy, aby nas wyrwać z obecnego złego świata zgodnie z wolą Boga, naszego Ojca.
###### **Ga 1,5**
 Jemu chwała na wieki wieków. Amen.
###### **Ga 1,6**
 Dziwię się, że od Tego, który was powołał łaską Chrystusa, tak szybko odchodzicie do innej ewangelii.
###### **Ga 1,7**
 Nie ma innej ewangelii! Są tylko jacyś ludzie, którzy wśród was sieją zamęt i chcą zmienić Ewangelię Chrystusa.
###### **Ga 1,8**
 Lecz gdybyśmy nawet my sami, albo gdyby anioł z nieba głosił wam ewangelię inną od tej, którą wam głosiliśmy, niech będzie wyłączony ze wspólnoty.
###### **Ga 1,9**
 Powtarzam jeszcze raz, to co powiedziałem: Jeśli ktoś głosi wam inną ewangelię od tej, którą przyjęliście, niech będzie wyłączony ze wspólnoty.
###### **Ga 1,10**
 A zatem, czy zabiegam o względy ludzi, czy Boga? Czy ludziom staram się przypodobać? Gdybym chciał się przypodobać ludziom, nie byłbym sługą Chrystusa.
###### **Ga 1,11**
 Oświadczam wam, bracia, że głoszona przeze mnie Ewangelia nie pochodzi od ludzi.
###### **Ga 1,12**
 Nie przyjąłem jej, ani nie nauczyłem się od człowieka, ale objawił mi ją Jezus Chrystus.
###### **Ga 1,13**
 Słyszeliście przecież o moim dawniejszym postępowaniu w judaizmie; o tym, jak bardzo prześladowałem Kościół Boży i chciałem go zniszczyć.
###### **Ga 1,14**
 Wiernością judaizmowi przewyższałem wielu rówieśników w moim narodzie, gorliwie przestrzegając tradycji przodków.
###### **Ga 1,15**
 Kiedy jednak Bogu - który wybrał mnie w łonie mojej matki i wezwał swą łaską - spodobało się
###### **Ga 1,16**
 objawić swego Syna we mnie dla głoszenia Ewangelii o Nim pośród narodów, wtedy nie szukałem już rady u ludzi.
###### **Ga 1,17**
 Nie pospieszyłem też do Jerozolimy, do tych, którzy apostołami stali się przede mną, ale natychmiast skierowałem się do Arabii, a potem znowu powróciłem do Damaszku.
###### **Ga 1,18**
 Następnie, trzy lata później poszedłem do Jerozolimy, aby poznać Kefasa i zostałem u niego piętnaście dni.
###### **Ga 1,19**
 Spośród apostołów nie widziałem natomiast nikogo, z wyjątkiem Jakuba, brata Pańskiego.
###### **Ga 1,20**
 Zaświadczam przed Bogiem, że w tym, co do was piszę, nie kłamię.
###### **Ga 1,21**
 Następnie udałem się w okolice Syrii i Cylicji.
###### **Ga 1,22**
 Kościołom Chrystusa w Judei pozostawałem osobiście nieznany.
###### **Ga 1,23**
 Słyszeli tylko: nasz dawny prześladowca głosi teraz wiarę, którą przedtem starał się zniszczyć.
###### **Ga 1,24**
 I chwalili Boga z mego powodu.
# Ga 1 BP
###### **Ga 1,1**
 Paweł - powołany na apostoła nie przez ludzi ani jakiegokolwiek człowieka, lecz przez Jezusa Chrystusa i przez Boga Ojca, który wskrzesił Go z martwych -
###### **Ga 1,2**
 oraz wszyscy bracia, którzy przebywają ze mną, przekazują pozdrowienia Kościołom w Galacji.
###### **Ga 1,3**
 Łaska niech będzie z wami i pokój Boga, naszego Ojca i Pana Jezusa Chrystusa.
###### **Ga 1,4**
 On to ofiarował siebie samego za nasze grzechy, aby nas uwolnić od zła, które towarzyszy temu życiu. Taka była wola Boga, naszego Ojca.
###### **Ga 1,5**
 Jemu chwała na całą wieczność. Amen.
###### **Ga 1,6**
 Dziwię się, że tak szybko odstępujecie od Tego, który was powołał do uczestnictwa w łasce Chrystusowej, i zwracacie się ku innej ewangelii.
###### **Ga 1,7**
 Nie ma innej! Są jedynie tacy, którzy sieją zamęt wśród was i chcą sfałszować ewangelię Chrystusa.
###### **Ga 1,8**
 Ale choćbyśmy sami czy nawet anioł z nieba głosił wam coś innego, niż myśmy wam głosili, niech będzie wyklęty!
###### **Ga 1,9**
 Jak poprzednio stwierdziliśmy, tak i teraz powtarzam: Gdyby wam ktoś głosił ewangelię inną od tej, którą otrzymaliście, niech będzie wyklęty!
###### **Ga 1,10**
 Czyż bowiem teraz ludziom chcę się przypodobać, czy Bogu? Czy szukam uznania wśród ludzi? Gdybym jeszcze teraz szukał uznania wśród ludzi, nie byłbym sługą Chrystusa.
###### **Ga 1,11**
 Oświadczam wam, bracia, że ewangelia, którą głosiłem, nie pochodzi od człowieka.
###### **Ga 1,12**
 Bo ja sam nie otrzymałem jej od człowieka ani jej się nauczyłem, lecz mam ją dzięki objawieniu Jezusa Chrystusa.
###### **Ga 1,13**
 Słyszeliście bowiem o moim dawnym postępowaniu - kiedy byłem wyznawcą judaizmu - że zaciekle prześladowałem Kościół Boży i usiłowałem go zniszczyć,
###### **Ga 1,14**
 że jako wyznawca judaizmu wszystkich moich rówieśników z mego narodu prześcignąłem nadzwyczajną gorliwością wobec ojczystych tradycji.
###### **Ga 1,15**
 A kiedy Ten, który wybrał mnie w łonie matki i powołał dzięki swojej łasce, raczył
###### **Ga 1,16**
 mi objawić swego Syna, abym głosił Jego ewangelię poganom, wtedy nie kierowałem się już względami czysto ludzkimi
###### **Ga 1,17**
 ani nie wstępowałem do Jerozolimy, by tam spotkać tych, którzy już przede mną byli, apostołów, lecz udałem się do Arabii, a potem wróciłem znów do Damaszku.
###### **Ga 1,18**
 A po trzech latach udałem się do Jerozolimy, by poznać Kefasa. Pozostałem u niego przez piętnaście dni.
###### **Ga 1,19**
 Nikogo z apostołów poza Jakubem, bratem Pana, nie widziałem.
###### **Ga 1,20**
 To, co wam piszę - Bóg mi jest świadkiem - nie jest kłamstwem.
###### **Ga 1,21**
 Potem udałem się do Syrii i Cylicji.
###### **Ga 1,22**
 A Kościoły Chrystusowe w Judei nie znały mnie osobiście.
###### **Ga 1,23**
 Słyszały one tylko tyle: Dawny nasz prześladowca głosi teraz tę wiarę, którą niegdyś usiłował wytępić.
###### **Ga 1,24**
 I wielbili Boga z mego powodu.
# Ga 1 BR
###### **Ga 1,1**
 Paweł - ustanowiony apostołem nie przez ludzi ani nie za pośrednictwem ludzi, lecz przez Jezusa Chrystusa i przez Boga Ojca, który zmartwychwskrzesił Jezusa -
###### **Ga 1,2**
 oraz wszyscy będący ze mną bracia [zwracają się] do Kościołów Galacji.
###### **Ga 1,3**
 Niech was obdarzy łaską i pokojem Bóg, Ojciec nasz, i Pan Jezus Chrystus,
###### **Ga 1,4**
 który wydał siebie samego za nasze grzechy, aby nas wyrwać z tego świata złego, zgodnie z wolą Boga, Ojca naszego.
###### **Ga 1,5**
 Jemu to chwała na wieki wieków! Amen.
###### **Ga 1,6**
 Dziwię się, że od tego, który, powołał was za łaską Chrystusa odchodzicie tak szybko ku innej ewangelii.
###### **Ga 1,7**
 Tymczasem nie ma innej ewangelii; są tylko ludzie, którzy siejąc wśród was zamęt, chcieliby odmienić Ewangelię Chrystusa.
###### **Ga 1,8**
 I jeśli znalazłby się ktoś - mniejsza o to, kto by to był: my sami czy jakiś anioł z nieba - kto głosiłby inną Ewangelię niż ta, którą myśmy wam głosili - niech będzie przeklęty.
###### **Ga 1,9**
 Już powiedzieliśmy to, a teraz jeszcze raz powtarzamy: niech będzie przeklęty każdy, kto by wam głosił ewangelię inną niż ta, którą otrzymaliście.
###### **Ga 1,10**
 Czy oznacza to, że szukam uznania u ludzi? Nie, ja pragnę uznania tylko u Boga. Czy zależy mi na tym, by się przypodobać ludziom? Gdybym pragnął przypodobać się ludziom, z pewnością nie byłbym sługą Chrystusa.
###### **Ga 1,11**
 Zapewniam was, bracia, że Ewangelia, którą głoszę, nie jest pochodzenia ludzkiego.
###### **Ga 1,12**
 Nie otrzymałem jej od nikogo z ludzi i nie przejąłem jej od nikogo spośród ludzi. Objawił mi ją sam Jezus Chrystus.
###### **Ga 1,13**
 Słyszeliście o moim postępowaniu, kiedy jeszcze byłem związany z judaizmem; o tym, z jaką gwałtownością prześladowałem Kościół Boży, starając się zniszczyć go;
###### **Ga 1,14**
 o tym, jak w przestrzeganiu religijnych zwyczajów żydowskich prześcigałem wielu moich rówieśników, będąc zagorzałym obrońcą tradycji ojców.
###### **Ga 1,15**
 Lecz Bóg, powodowany swą dobrocią, znalazł we mnie upodobanie, nim się jeszcze narodziłem, i wezwał mnie, [bym Mu służył].
###### **Ga 1,16**
 Kiedy zaś objawił mi Syna swego po to, bym opowiadał o Nim poganom, to nie szukałem u nikogo żadnej rady
###### **Ga 1,17**
 i nie skierowałem swoich kroków do Jerozolimy, by przedstawić się tym, którzy byli już przede mną apostołami, lecz natychmiast udałem się do Arabii, po czym znów wróciłem do Damaszku.
###### **Ga 1,18**
 Dopiero w trzy lata później znalazłem się w Jerozolimie, ażeby zobaczyć osobiście Kefasa, z którym pozostawałem zresztą [tylko] piętnaście dni.
###### **Ga 1,19**
 Z innych apostołów, nie widziałem nikogo prócz Jakuba, brata Pana.
###### **Ga 1,20**
 Napisałem wam całą i samą prawdę. Bóg mi świadkiem, że nie kłamię.
###### **Ga 1,21**
 Potem udałem się do Syrii i Cylicji.
###### **Ga 1,22**
 W tym czasie ciągle jeszcze byłem nie znany osobiście wiernym Kościołów Judei.
###### **Ga 1,23**
 Słyszeli tylko, jak mówiono o mnie: ten, który nas kiedyś prześladował, obecnie głosi nam jako Dobrą Nowinę tę wiarę, którą do niedawna zwalczał.
###### **Ga 1,24**
 I tak oto z mego powodu wielbili Boga.
# Ga 1 WUJ
###### **Ga 1,1**
 Paweł Apostoł nie od ludzi, ani przez człowieka, ale przez Jezusa Chrystusa, i Boga Ojca, który go wzbudził z martwych,
###### **Ga 1,2**
 I wszyscy bracia, którzy są zemną kościołom Galatjej.
###### **Ga 1,3**
 Łaska wam i pokój od Boga Ojca i Pana naszego Jezusa Chrystusa,
###### **Ga 1,4**
 Który samego siebie dał za grzechy nasze, aby nas wyrwał z teraźniejszego wieku złego, wedle wolej Boga i Ojca naszego:
###### **Ga 1,5**
 Któremu jest chwała na wieki wieków, Amen.
###### **Ga 1,6**
 Dziwuję się, iż tak prędko przenosicie się od tego, który was wezwał do łaski Chrystusowej, do inszej Ewanieljej:
###### **Ga 1,7**
 Która nie jest insza, jedno są niektórzy co wami trwożą, i chcą wywrócić Ewanielią Chrystusową,
###### **Ga 1,8**
 Ale choćby my, abo anioł z nieba przepowiadał wam mimo to cośmy wam przepowiadali, niech będzie przeklęctwem.
###### **Ga 1,9**
 Jakośmy przedtem powiadali, i teraz zasię mówię: Jeśliby kto wam opowiadał mimo to coście wzięli, niech będzie przeklęctwem.
###### **Ga 1,10**
 Bo teraz przed ludźmi li sprawę mam, czyli przed Bogiem? Czyli szukam, abym się ludziom podobał? Jeślibych się jeszcze ludziom podobał, nie byłbych sługą Chrystusowym.
###### **Ga 1,11**
 Abowiem oznajmuję wam bracia, iż Ewangelia, która jest przepowiadana odemnie, nie jest wedle człowieka.
###### **Ga 1,12**
 Bom jej ja nie od człowieka wziął, anim się nauczył: ale przez objawienie Jezusa Chrystusa.
###### **Ga 1,13**
 Boście słyszeli o mojem obcowaniu nie kiedy w Żydowstwie: iżem nad miarę prześladował kościół Boży, i burzyłem ji,
###### **Ga 1,14**
 I postępowałem w Żydowstwie nad wiele rówienników moich w narodzie moim, będąc więtszym miłośnikiem ustaw moich ojczystych.
###### **Ga 1,15**
 Lecz gdy się podobało temu, który mię odłączył z żywota matki mojej, i wezwał przez łaskę swoję:
###### **Ga 1,16**
 Aby objawił Syna swego we mnie, abych go przepowiadał między Pogany: natychmiast nie przestawałem z ciałem i ze krwią:
###### **Ga 1,17**
 Anim poszedł do Jeruzalem do tych, którzy przedemną byli Apostołów: Alem szedł do Arabjej, i wróciłem się zasię do Damaszku.
###### **Ga 1,18**
 Zatem po trzech leciech poszedłem do Jeruzalem, abym oglądał Piotra: i zmieszkałem u niego piętnaście dni.
###### **Ga 1,19**
 A inszego z Apostołów żadnegom nie widział: jedno Jakóba brata Pańskiego.
###### **Ga 1,20**
 A co wam piszę, oto przed Bogiem, żeć nie kłamam.
###### **Ga 1,21**
 Potem przyszedłem do krajów Syrjej i Cylicjej.
###### **Ga 1,22**
 A byłem nieznajomym z twarzy kościołom Żydowstwa, które były w Chrystusie:
###### **Ga 1,23**
 Ale tylko usłyszeli byli, Iż który prześladował nas niekiedy, teraz opowiada wiarę, którą przedtem burzył:
###### **Ga 1,24**
 I sławili Boga ze mnie.
# Ga 1 STERN
###### **Ga 1,1**
 Sza'ul, wysłannik - posłannictwo swoje otrzymałem nie od ludzi ani przez pośrednictwo ludzi, ale za sprawą Jeszui Mesjasza i Boga Ojca, który wskrzesił Go z martwych - a także wszyscy bracia, którzy są ze mną,
###### **Ga 1,2**
 do Wspólnot Mesjanicznych w Galacji:
###### **Ga 1,3**
 łaska wam i szalom od Boga, Ojca naszego, i od Pana Jeszui Mesjasza,
###### **Ga 1,4**
 który oddał siebie za nasze grzechy, aby nas wyzwolić z obecnego nikczemnego porządku tego świata, w posłuszeństwie woli Boga, naszego Ojca.
###### **Ga 1,5**
 Jemu niech będzie chwała na wieki wieków! Amen.
###### **Ga 1,6**
 Zdumiony jestem, że tak się wam śpieszy, aby się odsunąć ode mnie, od tego, który z łaski Mesjasza wezwał was, i aby zwrócić się ku jakiejś innej rzekomej "Dobrej Nowinie",
###### **Ga 1,7**
 która nie jest wcale żadną dobrą nowiną! Chodzi po prostu o to, że pewni ludzie nie dają wam spokoju i usiłują wypaczyć prawdziwą Dobrą Nowinę Mesjasza.
###### **Ga 1,8**
 Gdybyśmy jednak nawet my - albo też nawet i anioł z nieba! - mieli wam oznajmić jakąś tak zwaną Dobrą Nowinę przeciwną tej Dobrej Nowinie, którą wam faktycznie oznajmiliśmy - niech taki ktoś będzie przeklęty na wieki!
###### **Ga 1,9**
 Już powiedzieliśmy i mówię to jeszcze raz: jeśli ktoś głosi "Dobrą Nowinę" przeciwną temu, co otrzymaliście, niech będzie przeklęty na wieki!
###### **Ga 1,10**
 Czy wygląda to tak, jakbym próbował zaskarbić sobie ludzkie uznanie? Nie! Chcę uznania Bożego! A może usiłuję schlebiać ludziom? Gdybym nadal to robił, nie byłbym sługą Mesjasza.
###### **Ga 1,11**
 Ponadto chcę, bracia, aby było jasne, że Dobra Nowina, tak jak ją głoszę, nie jest wytworem ludzkim,
###### **Ga 1,12**
 bo ani nie otrzymałem jej od kogoś innego, ani mnie jej nie nauczano - przyszła ona jako bezpośrednie objawienie dane przez Jeszuę Mesjasza.
###### **Ga 1,13**
 Bo słyszeliście, jak przedtem żyłem w tradycyjnym judaizmie, jak czyniłem, co w mojej mocy, aby prześladować Bożą Wspólnotę Mesjaniczną i zniszczyć ją,
###### **Ga 1,14**
 i o tym, jak - ponieważ pałałem większą żarliwością względem tradycji przekazanych przez mych praojców niż większość moich rówieśników Żydów - w tradycyjnym judaizmie czyniłem znacznie szybsze postępy niż oni.
###### **Ga 1,15**
 Kiedy jednak Bóg, który mnie wybrał, nim jeszcze przyszedłem na świat, i wezwał mnie w swej łasce, postanowił
###### **Ga 1,16**
 objawić mi swego Syna, abym Go mógł rozgłaszać nie-Żydom, nie radziłem się nikogo
###### **Ga 1,17**
 i nie udałem się w górę do Jeruszalaim, aby zobaczyć się z tymi, którzy wysłannikami byli przede mną. Za to od razu wyruszyłem do Arabii, a potem wróciłem do Dammeseku.
###### **Ga 1,18**
 Dopiero trzy lata później wybrałem się w górę do Jeruszalaim, aby poznać Kefę, i zostałem z nim dwa tygodnie,
###### **Ga 1,19**
 poza nim jednak nie spotkałem innych wysłanników, wyjąwszy Ja'akowa, brata Pańskiego.
###### **Ga 1,20**
 (Co do tych spraw, o których wam teraz piszę, zaklinam się przed Bogiem, że nie kłamię!).
###### **Ga 1,21**
 Potem udałem się do Syrii i Cylicji,
###### **Ga 1,22**
 ale w J'hudzie zgromadzenia mesjaniczne nie wiedziały nawet, jak wyglądam -
###### **Ga 1,23**
 bo słyszeli tylko wieści: "Ten, który niegdyś nas prześladował, teraz głosi Dobrą Nowinę o wierze, którą ongi usiłował zniszczyć!".
###### **Ga 1,24**
 I chwalili Boga z mojego powodu.
# Ga 1 TRO
###### **Ga 1,1**
 **παυλος** *paulos* Paweł – [mały] [[G3972]] [[N-NSM]] **αποστολος** *apostolos* wysłannik [[G652]] [[N-NSM]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **απ** *ap* od [[G575]] [[PREP]] **ανθρωπων** *anthrōpōn* ludzi [[G444]] WTN-GPM **ουδε** *oude* ani [[G3761]] [[ADV]] **δι** *di* przez [[G1223]] [[PREP]] **ανθρωπου** *anthrōpou* człowieka [[G444]] [[N-GSM]] **αλλα** *alla* ale [[G235]] [[CONJ]] **δια** *dia* przez [[G1223]] [[PREP]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **πατρος** *patros* Ojca [[G3962]] [[N-GSM]] **του** *tou* [[G3588]] WTT-GSM **εγειραντος** *egeirantos* który wzbudził – który podniósł [[G1453]] WTV-AAP-GSM **αυτον** *auton* Go [[G846]] WTP-ASM **εκ** *ek* z [[G1537]] [[PREP]] **νεκρων** *nekrōn* martwych [[G3498]] WTA-GPM
###### **Ga 1,2**
 **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* (ci) [[G3588]] WTT-NPM **συν** *syn* ze [[G4862]] [[PREP]] **εμοι** *emoi* mną [[G1698]] WTP-1DS **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **αδελφοι** *adelfoi* bracia [[G80]] WTN-NPM **ταις** *tais* [[G3588]] WTT-DPF **εκκλησιαις** *ekklēsiais* zgromadzeniom – (społecznościom) wywołanych [[G1577]] WTN-DPF **της** *tēs* [[G3588]] [[T-GSF]] **γαλατιας** *galatias* Galacji [[G1053]] [[N-GSF]]
###### **Ga 1,3**
 **χαρις** *charis* łaska [[G5485]] [[N-NSF]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **και** *kai* i [[G2532]] [[CONJ]] **ειρηνη** *eirēnē* pokój [[G1515]] [[N-NSF]] **απο** *apo* od [[G575]] [[PREP]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **πατρος** *patros* Ojca [[G3962]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **Ga 1,4**
 **του** *tou* [[G3588]] WTT-GSM **δοντος** *dontos* który dał [[G1325]] WTV-2AAP-GSM **εαυτον** *heauton* siebie samego [[G1438]] WTF-3ASM **υπερ** *hyper* za [[G5228]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPF **αμαρτιων** *hamartiōn* grzechy [[G266]] WTN-GPF **ημων** *hēmōn* nasze [[G2257]] WTP-1GP **οπως** *hopōs* żeby [[G3704]] [[ADV]] **εξεληται** *ekselētai* wyrwałby [[G1807]] WTV-2AMS-3S **ημας** *hēmas* nas [[G2248]] WTP-1AP **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **ενεστωτος** *enestōtos* nastającego [[G1764]] WTV-RAP-GSM **αιωνος** *aiōnos* wieku [[G165]] [[N-GSM]] **πονηρου** *ponērou* niegodziwego – złego [[G4190]] WTA-GSM **κατα** *kata* według [[G2596]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **θελημα** *thelēma* woli [[G2307]] WTN-ASN **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **πατρος** *patros* Ojca [[G3962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP
###### **Ga 1,5**
 **ω** *hō* któremu [[G3739]] WTR-DSM **η** *hē* [[G3588]] [[T-NSF]] **δοξα** *doksa* chwała [[G1391]] [[N-NSF]] **εις** *eis* na [[G1519]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **αιωνας** *aiōnas* wieki [[G165]] [[N-APM]] **των** *tōn* [[G3588]] WTT-GPM **αιωνων** *aiōnōn* wieków [[G165]] WTN-GPM **αμην** *amēn* amen – [zaprawdę] [[G281]] WTHEB
###### **Ga 1,6**
 **θαυμαζω** *thaumazō* Dziwię się [[G2296]] WTV-PAI-1S **οτι** *hoti* że [[G3754]] [[CONJ]] **ουτως** *houtōs* tak [[G3779]] [[ADV]] **ταχεως** *tacheōs* szybko [[G5030]] [[ADV]] **μετατιθεσθε** *metatithesthe* odwracacie się – przenosicie się [[G3346]] WTV-PEI-2P **απο** *apo* od [[G575]] [[PREP]] **του** *tou* (Tego) [[G3588]] WTT-GSM **καλεσαντος** *kalesantos* który wezwał – który powołał [[G2564]] WTV-AAP-GSM **υμας** *hymas* was [[G5209]] WTP-2AP **εν** *en* w [[G1722]] [[PREP]] **χαριτι** *chariti* łasce [[G5485]] [[N-DSF]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **εις** *eis* do [[G1519]] [[PREP]] **ετερον** *heteron* innej [[G2087]] WTA-ASN **ευαγγελιον** *euangelion* dobrej nowiny [[G2098]] WTN-ASN
###### **Ga 1,7**
 **ο** *ho* która [[G3739]] WTR-NSN **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **αλλο** *allo* inna [[G243]] WTA-NSN **ει** *ei* jeśli [[G1487]] WTCOND **μη** *mē* nie [[G3361]] [[PRT-N]] **τινες** *tines* jacyś – niektórzy [[G5100]] WTX-NPM **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **οι** *hoi* [[G3588]] WTT-NPM **ταρασσοντες** *tarassontes* poruszający – trwożący [[G5015]] WTV-PAP-NPM **υμας** *hymas* was [[G5209]] WTP-2AP **και** *kai* i [[G2532]] [[CONJ]] **θελοντες** *thelontes* chcący [[G2309]] WTV-PAP-NPM **μεταστρεψαι** *metastrepsai* odwrócić – zmienić [[G3344]] [[V-AAN]] **το** *to* [[G3588]] WTT-ASN **ευαγγελιον** *euangelion* dobrą nowinę [[G2098]] WTN-ASN **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **Ga 1,8**
 **αλλα** *alla* ale [[G235]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **εαν** *ean* jeśli [[G1437]] WTCOND **ημεις** *hēmeis* my [[G2249]] WTP-1NP **η** *ē* lub [[G2228]] WTPRT **αγγελος** *angelos* zwiastun [[G32]] [[N-NSM]] **εξ** *eks* z [[G1537]] [[PREP]] **ουρανου** *ouranou* nieba [[G3772]] [[N-GSM]] **ευαγγελιζηται** *euangelizētai* głosiłby dobrą nowinę [[G2097]] WTV-PMS-3S **υμιν** *hymin* wam [[G5213]] WTP-2DP **παρ** *par* wbrew [[G3844]] [[PREP]] **ο** *ho* której [[G3739]] WTR-ASN **ευηγγελισαμεθα** *euēngelisametha* ogłosiliśmy dobrą nowinę [[G2097]] WTV-AMI-1P **υμιν** *hymin* wam [[G5213]] WTP-2DP **αναθεμα** *anathema* przekleństwo – zaklęcie [[G331]] WTN-NSN **εστω** *estō* niech jest [[G2077]] WTV-PXM-3S
###### **Ga 1,9**
 **ως** *hōs* jak [[G5613]] [[ADV]] **προειρηκαμεν** *proeirēkamen* wcześniej powiedzieliśmy [[G4280]] WTV-RAI-1P **και** *kai* i [[G2532]] [[CONJ]] **αρτι** *arti* teraz [[G737]] [[ADV]] **παλιν** *palin* znowu [[G3825]] [[ADV]] **λεγω** *legō* mówię [[G3004]] WTV-PAI-1S **ει** *ei* jeśli [[G1487]] WTCOND **τις** *tis* ktoś [[G5100]] WTX-NSM **υμας** *hymas* wam [[G5209]] WTP-2AP **ευαγγελιζεται** *euangelizetai* głosi dobrą nowinę [[G2097]] WTV-PMI-3S **παρ** *par* wbrew [[G3844]] [[PREP]] **ο** *ho* której [[G3739]] WTR-ASN **παρελαβετε** *parelabete* przyjęliście [[G3880]] WTV-2AAI-2P **αναθεμα** *anathema* przekleństwo – zaklęcie [[G331]] WTN-NSN **εστω** *estō* niech jest [[G2077]] WTV-PXM-3S
###### **Ga 1,10**
 **αρτι** *arti* Teraz [[G737]] [[ADV]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ανθρωπους** *anthrōpous* ludzi [[G444]] [[N-APM]] **πειθω** *peithō* przekonuję [[G3982]] WTV-PAI-1S **η** *ē* czy [[G2228]] WTPRT **τον** *ton* [[G3588]] [[T-ASM]] **θεον** *theon* Boga [[G2316]] [[N-ASM]] **η** *ē* czy [[G2228]] WTPRT **ζητω** *zētō* szukam [[G2212]] WTV-PAI-1S **ανθρωποις** *anthrōpois* ludziom [[G444]] WTN-DPM **αρεσκειν** *areskein* przypodobać się [[G700]] WTV-PAN **ει** *ei* jeśli [[G1487]] WTCOND **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ετι** *eti* jeszcze [[G2089]] [[ADV]] **ανθρωποις** *anthrōpois* ludziom [[G444]] WTN-DPM **ηρεσκον** *ēreskon* przypodobałem się [[G700]] WTV-IAI-1S **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **δουλος** *doulos* niewolnik – sługa [[G1401]] [[N-NSM]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **αν** *an* (kiedy)kolwiek [[G302]] WTPRT **ημην** *ēmēn* byłem [[G2252]] WTV-IXI-1S
###### **Ga 1,11**
 **γνωριζω** *gnōrizō* Oznajmiam – Daję poznać [[G1107]] WTV-PAI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **το** *to* [[G3588]] WTT-ASN **ευαγγελιον** *euangelion* dobrą nowinę [[G2098]] WTN-ASN **το** *to* [[G3588]] WTT-ASN **ευαγγελισθεν** *euangelisthen* która została ogłoszona jako dobra nowina [[G2097]] WTV-APP-ASN **υπ** *hyp* przeze [[G5259]] [[PREP]] **εμου** *emou* mnie [[G1700]] WTP-1GS **οτι** *hoti* że [[G3754]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **κατα** *kata* według [[G2596]] [[PREP]] **ανθρωπον** *anthrōpon* człowieka [[G444]] [[N-ASM]]
###### **Ga 1,12**
 **ουδε** *oude* ani [[G3761]] [[ADV]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εγω** *egō* ja [[G1473]] WTP-1NS **παρα** *para* od [[G3844]] [[PREP]] **ανθρωπου** *anthrōpou* człowieka [[G444]] [[N-GSM]] **παρελαβον** *parelabon* przyjąłem [[G3880]] WTV-2AAI-1S **αυτο** *auto* ją [[G846]] WTP-ASN **ουτε** *oute* ani [[G3777]] [[CONJ]] **εδιδαχθην** *edidachthēn* zostałem nauczony [[G1321]] WTV-API-1S **αλλα** *alla* ale [[G235]] [[CONJ]] **δι** *di* przez [[G1223]] [[PREP]] **αποκαλυψεως** *apokalypseōs* objawienie [[G602]] [[N-GSF]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **Ga 1,13**
 **ηκουσατε** *ēkousate* Usłyszeliście [[G191]] WTV-AAI-2P **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **την** *tēn* (o) [[G3588]] WTT-ASF **εμην** *emēn* moim [[G1699]] WTS-1ASF **αναστροφην** *anastrofēn* postępowaniu – obracaniu się [[G391]] WTN-ASF **ποτε** *pote* poprzednim – niegdyś [[G4218]] WTPRT **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **ιουδαισμω** *ioudaismō* judaizmie – [żyć jak [wielbić]] [[G2454]] WTN-DSM **οτι** *hoti* że [[G3754]] [[CONJ]] **καθ** *kath* w [[G2596]] [[PREP]] **υπερβολην** *hyperbolēn* nadmiarze [[G5236]] WTN-ASF **εδιωκον** *ediōkon* prześladowałem – nastawałem na [[G1377]] WTV-IAI-1S **την** *tēn* [[G3588]] WTT-ASF **εκκλησιαν** *ekklēsian* zgromadzenie – (społeczność) wywołanych [[G1577]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **επορθουν** *eporthoun* niszczyłem [[G4199]] WTV-IAI-1S **αυτην** *autēn* je [[G846]] [[P-ASF]]
###### **Ga 1,14**
 **και** *kai* i [[G2532]] [[CONJ]] **προεκοπτον** *proekopton* robiłem postępy – przesunąć się naprzód [[G4298]] WTV-IAI-1S **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **ιουδαισμω** *ioudaismō* judaizmie – [żyć jak [wielbić]] [[G2454]] WTN-DSM **υπερ** *hyper* ponad [[G5228]] [[PREP]] **πολλους** *pollous* wielu [[G4183]] WTA-APM **συνηλικιωτας** *synēlikiōtas* współrówieśników [[G4915]] [[N-APM]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **γενει** *genei* rodzie [[G1085]] WTN-DSN **μου** *mou* moim [[G3450]] WTP-1GS **περισσοτερως** *perissoterōs* w większym stopniu – obficiej [[G4056]] [[ADV]] **ζηλωτης** *zēlōtēs* zapaleniec – gorliwiec [[G2207]] [[N-NSM]] **υπαρχων** *hyparchōn* będąc [[G5225]] [[V-PAP-NSM]] **των** *tōn* [[G3588]] WTT-GPM **πατρικων** *patrikōn* ojczystych [[G3967]] WTA-GPM **μου** *mou* mych [[G3450]] WTP-1GS **παραδοσεων** *paradoseōn* przekazów – tradycji [[G3862]] WTN-GPF
###### **Ga 1,15**
 **οτε** *hote* Gdy [[G3753]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **ευδοκησεν** *eudokēsen* miał upodobanie [[G2106]] [[V-AAI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **αφορισας** *aforisas* który odłączył – który oddzielił [[G873]] WTV-AAP-NSM **με** *me* mnie [[G3165]] WTP-1AS **εκ** *ek* od [[G1537]] [[PREP]] **κοιλιας** *koilias* łona – wnętrza [[G2836]] [[N-GSF]] **μητρος** *mētros* matki [[G3384]] [[N-GSF]] **μου** *mou* mojej [[G3450]] WTP-1GS **και** *kai* i [[G2532]] [[CONJ]] **καλεσας** *kalesas* który wezwał – który powołał [[G2564]] WTV-AAP-NSM **δια** *dia* przez [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **χαριτος** *charitos* łaskę [[G5485]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Ga 1,16**
 **αποκαλυψαι** *apokalypsai* (by) objawić [[G601]] [[V-AAN]] **τον** *ton* [[G3588]] [[T-ASM]] **υιον** *hyion* Syna [[G5207]] [[N-ASM]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **εν** *en* we [[G1722]] [[PREP]] **εμοι** *emoi* mnie [[G1698]] WTP-1DS **ινα** *hina* aby [[G2443]] [[CONJ]] **ευαγγελιζωμαι** *euangelizōmai* głosiłbym dobrą nowinę [[G2097]] WTV-PMS-1S **αυτον** *auton* (o) Nim [[G846]] WTP-ASM **εν** *en* wśród [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPN **εθνεσιν** *ethnesin* narodów – pogan [[G1484]] WTN-DPN **ευθεως** *eutheōs* zaraz – natychmiast [[G2112]] [[ADV]] **ου** *ou* nie [[G3756]] [[PRT-N]] **προσανεθεμην** *prosanethemēn* radziłem się – dodatkowo nałożyłem [[G4323]] WTV-2AMI-1S **σαρκι** *sarki* ciała [[G4561]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **αιματι** *haimati* krwi [[G129]] WTN-DSN
###### **Ga 1,17**
 **ουδε** *oude* ani [[G3761]] [[ADV]] **ανηλθον** *anēlthon* wszedłem – wstąpiłem [[G424]] WTV-2AAI-1S **εις** *eis* do [[G1519]] [[PREP]] **ιεροσολυμα** *ierosolyma* Jerozolimy – [dziedzictwo pokoju] [[G2414]] WTN-ASF **προς** *pros* do [[G4314]] [[PREP]] **τους** *tous* (tych) [[G3588]] WTT-APM **προ** *pro* przede [[G4253]] [[PREP]] **εμου** *emou* mną [[G1700]] WTP-1GS **αποστολους** *apostolous* wysłanników [[G652]] [[N-APM]] **αλλ** *all* ale [[G235]] [[CONJ]] **απηλθον** *apēlthon* odszedłem [[G565]] WTV-2AAI-1S **εις** *eis* do [[G1519]] [[PREP]] **αραβιαν** *arabian* Arabii – [płaskowyż pustynny] [[G688]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **παλιν** *palin* znów [[G3825]] [[ADV]] **υπεστρεψα** *hypestrepsa* wróciłem [[G5290]] WTV-AAI-1S **εις** *eis* do [[G1519]] [[PREP]] **δαμασκον** *damaskon* Damaszku [[G1154]] WTN-ASF
###### **Ga 1,18**
 **επειτα** *epeita* Następnie [[G1899]] [[ADV]] **μετα** *meta* po [[G3326]] [[PREP]] **ετη** *etē* latach [[G2094]] WTN-APN **τρια** *tria* trzech [[G5140]] WTA-APN **ανηλθον** *anēlthon* wszedłem – wstąpiłem [[G424]] WTV-2AAI-1S **εις** *eis* do [[G1519]] [[PREP]] **ιεροσολυμα** *ierosolyma* Jerozolimy – [dziedzictwo pokoju] [[G2414]] WTN-ASF **ιστορησαι** *historēsai* (by) poznać [[G2477]] [[V-AAN]] **πετρον** *petron* Piotra – [kamyk] [[G4074]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **επεμεινα** *epemeina* pozostałem – zatrzymałem się [[G1961]] WTV-AAI-1S **προς** *pros* przy [[G4314]] [[PREP]] **αυτον** *auton* nim [[G846]] WTP-ASM **ημερας** *hēmeras* dni [[G2250]] WTN-APF **δεκαπεντε** *dekapente* piętnaście [[G1178]] WTA-NUI
###### **Ga 1,19**
 **ετερον** *heteron* innego [[G2087]] WTA-ASM **δε** *de* zaś [[G1161]] [[CONJ]] **των** *tōn* (z) [[G3588]] WTT-GPM **αποστολων** *apostolōn* wysłanników [[G652]] WTN-GPM **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ειδον** *eidon* zobaczyłem [[G1492]] WTV-2AAI-1S **ει** *ei* jeśli [[G1487]] WTCOND **μη** *mē* nie [[G3361]] [[PRT-N]] **ιακωβον** *iakōbon* Jakuba – [pięta] [[G2385]] [[N-ASM]] **τον** *ton* [[G3588]] [[T-ASM]] **αδελφον** *adelfon* brata [[G80]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]]
###### **Ga 1,20**
 **α** *ha* Co [[G3739]] WTR-APN **δε** *de* zaś [[G1161]] [[CONJ]] **γραφω** *grafō* piszę [[G1125]] WTV-PAI-1S **υμιν** *hymin* wam [[G5213]] WTP-2DP **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Bogiem [[G2316]] [[N-GSM]] **οτι** *hoti* że [[G3754]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **ψευδομαι** *pseudomai* kłamię [[G5574]] WTV-PNI-1S
###### **Ga 1,21**
 **επειτα** *epeita* Następnie [[G1899]] [[ADV]] **ηλθον** *ēlthon* przyszedłem [[G2064]] WTV-2AAI-1S **εις** *eis* do [[G1519]] [[PREP]] **τα** *ta* [[G3588]] WTT-APN **κλιματα** *klimata* okolic – obszarów [[G2824]] WTN-APN **της** *tēs* [[G3588]] [[T-GSF]] **συριας** *syrias* Syrii [[G4947]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **της** *tēs* [[G3588]] [[T-GSF]] **κιλικιας** *kilikias* Cylicji [[G2791]] [[N-GSF]]
###### **Ga 1,22**
 **ημην** *ēmēn* Byłem [[G2252]] WTV-IXI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **αγνοουμενος** *agnooumenos* który jest nieznany – który jest niepoznawany [[G50]] [[V-PPP-NSM]] **τω** *tō* [[G3588]] WTT-DSN **προσωπω** *prosōpō* obliczem – twarzą [[G4383]] WTN-DSN **ταις** *tais* [[G3588]] WTT-DPF **εκκλησιαις** *ekklēsiais* zgromadzeniom – (społecznościom) wywołanych [[G1577]] WTN-DPF **της** *tēs* [[G3588]] [[T-GSF]] **ιουδαιας** *ioudaias* Judei – [[wielbić] ziemię] [[G2449]] [[N-GSF]] **ταις** *tais* [[G3588]] WTT-DPF **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM
###### **Ga 1,23**
 **μονον** *monon* jedynie – tylko [[G3440]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **ακουοντες** *akouontes* słyszącymi [[G191]] WTV-PAP-NPM **ησαν** *ēsan* byli [[G2258]] WTV-IXI-3P **οτι** *hoti* że [[G3754]] [[CONJ]] **ο** *ho* (ten) [[G3588]] [[T-NSM]] **διωκων** *diōkōn* który prześladuje – który nastaje na [[G1377]] [[V-PAP-NSM]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **ποτε** *pote* wcześniej – niegdyś [[G4218]] WTPRT **νυν** *nyn* teraz [[G3568]] [[ADV]] **ευαγγελιζεται** *euangelizetai* głosi dobrą nowinę [[G2097]] WTV-PMI-3S **την** *tēn* [[G3588]] WTT-ASF **πιστιν** *pistin* wiary [[G4102]] WTN-ASF **ην** *hēn* którą [[G3739]] WTR-ASF **ποτε** *pote* wcześniej – niegdyś [[G4218]] WTPRT **επορθει** *eporthei* niszczył [[G4199]] WTV-IAI-3S
###### **Ga 1,24**
 **και** *kai* i [[G2532]] [[CONJ]] **εδοξαζον** *edoksazon* chwalili [[G1392]] WTV-IAI-3P **εν** *en* przeze [[G1722]] [[PREP]] **εμοι** *emoi* mnie [[G1698]] WTP-1DS **τον** *ton* [[G3588]] [[T-ASM]] **θεον** *theon* Boga [[G2316]] [[N-ASM]]
