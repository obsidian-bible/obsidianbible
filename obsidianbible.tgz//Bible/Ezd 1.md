# Ezd 1 BT5
###### **Ezd 1,1**
 Aby się spełniło słowo Pańskie z ust Jeremiasza, pobudził Pan ducha Cyrusa, króla perskiego, w pierwszym roku [jego panowania], tak iż obwieścił on, również na piśmie, w całym państwie swoim, co następuje:
###### **Ezd 1,2**
 «***Tak mówi Cyrus, król perski: Wszystkie państwa ziemi dał mi Pan, Bóg niebios. I On mi rozkazał zbudować Mu dom w Jerozolimie, w Judzie.***
###### **Ezd 1,3**
 ***Jeśli jest między wami jeszcze ktoś z całego ludu Jego, to niech Bóg jego będzie z nim; a niech idzie do Jerozolimy w Judzie i niech zbuduje dom Pana, Boga Izraela – tego Boga, który jest w Jerozolimie.***
###### **Ezd 1,4**
 ***A co do każdego z pozostających jeszcze przy życiu – to współmieszkańcy wszystkich miejscowości, gdzie taki przebywa, mają go wesprzeć srebrem, złotem, sprzętem i bydłem – oprócz darów dobrowolnych dla domu Bożego w Jerozolimie***».
###### **Ezd 1,5**
 Zatem głowy rodów Judy i Beniamina, kapłani i lewici, słowem każdy, którego ducha Bóg pobudził, wybrali się w drogę, aby zbudować dom Pański w Jerozolimie.
###### **Ezd 1,6**
 A wszyscy ich sąsiedzi poparli ich wszystkim: srebrem, złotem, sprzętem, bydłem i kosztownościami – oprócz wszelkich darów dobrowolnych.
###### **Ezd 1,7**
 A król Cyrus wydał sprzęty domu Pańskiego, które Nabuchodonozor zabrał z Jerozolimy i złożył w domu swego boga.
###### **Ezd 1,8**
 I wydał je Cyrus, król perski, skarbnikowi Mitredatowi, który przekazał je Szeszbassarowi, księciu judzkiemu.
###### **Ezd 1,9**
 A oto liczba tych sprzętów: czasz złotych – trzydzieści, czasz srebrnych – noży tysiąc dwadzieścia dziewięć,
###### **Ezd 1,10**
 pucharów złotych – trzydzieści, pucharów srebrnych – około czterystu dziesięciu, innych sprzętów – tysiąc;
###### **Ezd 1,11**
 wszystkich sprzętów złotych i srebrnych – pięć tysięcy czterysta. To wszystko przyniósł Szeszbassar, gdy przyprowadził wygnańców z Babilonii do Jerozolimy.
# Ezd 1 PAU
###### **Ezd 1,1**
 W pierwszym roku panowania Cyrusa, króla Persji - aby wypełniło się słowo PANA zapowiedziane przez Jeremiasza - pobudził PAN ducha Cyrusa, króla Persji, żeby w całym królestwie ogłosił i rozesłał na piśmie następujące rozporządzenie:
###### **Ezd 1,2**
 „Tak mówi Cyrus, król Persji: «PAN, Bóg niebios, dał mi wszystkie królestwa świata. On też zlecił mi, aby wybudować Mu dom w Jerozolimie, w Judei.
###### **Ezd 1,3**
 Kto z was należy do Jego ludu - niech jego Bóg będzie z nim - niechaj wraca do Jerozolimy w Judei i niech odbudowuje dom PANA, Boga Izraela. On bowiem jest Bogiem mieszkającym w Jerozolimie.
###### **Ezd 1,4**
 Każdego więc, kto pozostał przy życiu, mieszkańcy tej miejscowości, w której mieszkał, niech zaopatrzą w srebro i złoto, w sprzęt domowy i bydło, i niech dodadzą dobrowolne ofiary na dom Boga, który jest w Jerozolimie»".
###### **Ezd 1,5**
 Przywódcy rodów Judy i Beniamina, jak też kapłani i lewici, słowem każdy, którego ducha Bóg pobudził, wyruszyli, aby budować dom PANA w Jerozolimie.
###### **Ezd 1,6**
 Wszyscy ich sąsiedzi wspomogli ich hojnie: srebrem, złotem, sprzętami domowymi, bydłem i kosztownościami, nie licząc wszystkich ofiar dobrowolnych.
###### **Ezd 1,7**
 Król Cyrus rozkazał wziąć wszystkie przedmioty należące niegdyś do domu PANA, które Nabuchodonozor wywiózł z Jerozolimy, aby ofiarować je w świątyni swojego boga.
###### **Ezd 1,8**
 Cyrus, król Persji, polecił skarbnikowi Mitredatowi przejąć je i przekazać Szeszbassarowi, namiestnikowi judzkiemu.
###### **Ezd 1,9**
 A oto ich lista: trzydzieści złotych mis, tysiąc srebrnych mis, dwadzieścia dziewięć noży,
###### **Ezd 1,10**
 trzydzieści pucharów ze złota, czterysta dziesięć pucharów zastępczych ze srebra, tysiąc innych naczyń.
###### **Ezd 1,11**
 Wszystkich przedmiotów złotych i srebrnych było pięć tysięcy czterysta. To wszystko zabrał Szeszbassar, wracając razem z innymi wygnańcami z Babilonii do Jerozolimy.
# Ezd 1 BP
###### **Ezd 1,1**
 W pierwszym roku panowania Cyrusa, króla Persji, Jahwe, aby się wypełniło Jego słowo przepowiedziane przez Jeremiasza, pobudził ducha Cyrusa, króla Persji, żeby ogłosił [te słowa] w całym swoim królestwie [i wyraził je] także na piśmie: "
###### **Ezd 1,2**
 Tak mówi Cyrus, król Persji: Wszystkie królestwa świata dał mi Jahwe, Bóg niebios. On też nakazał mi, abym Mu wybudował Świątynię w Jeruzalem w Judzie.
###### **Ezd 1,3**
 Ktokolwiek spośród was należy do społeczności Jego ludu, niech Bóg jego będzie z nim! Niech uda się do Jeruzalem w Judzie i niech buduje Świątynię Jahwe, Bogu Izraela, temu Bogu, który jest w Jeruzalem.
###### **Ezd 1,4**
 I każdego z ocalałej reszty [Judejczyków] winni mieszkańcy wszelkiej miejscowości, gdziekolwiek by on przebywał, wspomagać srebrem i złotem, dobytkiem, bydłem, a także dobrowolnymi darami dla Świątyni Jahwe, która jest w Jeruzalem".
###### **Ezd 1,5**
 Powstali więc przywódcy rodów Judy i Beniamina, kapłani i lewici, wszyscy, w których Bóg wzbudził natchnienie, aby wyruszyli i budowali Świątynię Jahwe w Jeruzalem.
###### **Ezd 1,6**
 Wszyscy sąsiedzi wspomogli ich [dając] srebrne naczynia, złoto, majętność oraz bydło i kosztowności, nie licząc wszystkich dobrowolnych ofiar.
###### **Ezd 1,7**
 Król Cyrus polecił wydać naczynia ze Świątyni Jahwe, które Nebukadnezar kazał zabrać z Jeruzalem i ofiarował do świątyni swego boga.
###### **Ezd 1,8**
 Cyrus, król Persji, przekazał je skarbnikowi Mitredatowi, on zaś wręczył je Szeszbaccarowi, księciu judzkiemu.
###### **Ezd 1,9**
 A oto ich wykaz: trzydzieści czasz złotych, tysiąc czasz srebrnych, dwadzieścia dziewięć kadzielnic,
###### **Ezd 1,10**
 trzydzieści kielichów złotych, czterysta dziesięć kielichów ze srebra mniejszej wartości i tysiąc innych sprzętów.
###### **Ezd 1,11**
 Wszystkich naczyń ze złota i srebra było razem pięć tysięcy czterysta. Wszystko to zabrał z sobą Szeszbaccar, gdy wygnańcy powracali z Babilonii do Jeruzalem.
# Ezd 1 BR
###### **Ezd 1,1**
 W pierwszym roku panowania Cyrusa, króla Persji - aby się wypełniły słowa Jahwe wypowiedziane przez usta Jeremiasza - natchnął Jahwe swoim duchem Cyrusa, króla perskiego, który ustnie i na piśmie, rozesłanym po całym jego królestwie, wydał takie zarządzenie:
###### **Ezd 1,2**
 Oto, co mówi Cyrus, król perski: Jahwe, Bóg Zastępów niebieskich, przekazał mi wszystkie królestwa ziemi i polecił, abym Mu zbudował dom w Jerozolimie na ziemi judzkiej.
###### **Ezd 1,3**
 Kto z was należy do tego ludu, niech będzie z nim jego Bóg, Jahwe, i niech się udaje do Jerozolimy na ziemi judzkiej, aby wziąć udział w budowaniu domu dla Jahwe, Boga Izraela! Bo prawdziwie Bogiem jest Ten, który przebywa w Jeruzalem.
###### **Ezd 1,4**
 Tym zaś, którzy ocaleli na ziemi judzkiej albo na jakimkolwiek innym miejscu, niech wszyscy inni pospieszą z pomocą w postaci obdarowujących ich srebrem, złotem, wszelkim sprzętem i bydłem. Poza tym dobrowolnymi ofiarami niech wspierają świątynię Pańską, znajdującą się w Jerozolimie.
###### **Ezd 1,5**
 Przywódcy rodów Judy i Beniamina, kapłani oraz lewici i wszyscy, którzy poddali się Bożemu natchnieniu, wyruszyli tedy, aby zbudować świątynię Jahwe w Jerozolimie.
###### **Ezd 1,6**
 Wszyscy najbliżsi sąsiedzi pośpieszyli im z pomocą, obdarowując ich srebrem, złotem, różnorakim sprzętem, bydłem i cennymi przedmiotami, nie licząc wszelkiej innej dobrowolnej pomocy.
###### **Ezd 1,7**
 Król Cyrus zwrócił wszystkie naczynia świątynne, wywiezione kiedyś przez Nabuchodonozora z Jerozolimy i złożone w świątyni jego boga.
###### **Ezd 1,8**
 Cyrus, król perski, przekazał te kosztowności na ręce Mitredata, skarbnika, od którego po przeliczeniu przejął wszystko Szeszbassar, książę judzki.
###### **Ezd 1,9**
 A oto wykaz odzyskanych rzeczy: trzydzieści czasz złotych, tysiąc czasz srebrnych, dwadzieścia dziewięć kadzielnic,
###### **Ezd 1,10**
 trzydzieści złotych pucharów, czterysta dziesięć srebrnych pucharów oraz tysiąc innych przedmiotów.
###### **Ezd 1,11**
 Wszystkich razem przedmiotów ze złota i srebra było pięć tysięcy czterysta. Wszystko to zabrał ze sobą Szeszbassar, gdy wygnańcy wracali z Babilonu do Jerozolimy.
# Ezd 1 WUJ
###### **Ezd 1,1**
 Roku pierwszego Cyrusa króla Perskiego, aby się wypełniło słowo Pańskie z ust Jeremiaszowych, wzbudził Pan ducha Cyrusa króla Perskiego: i puścił głos po wszystkiem królestwie swem, i na piśmie, rzekąc:
###### **Ezd 1,2**
 To mówi Cyrus król Perski: wszystkie królestwa ziemskie dał mi Pan Bóg niebieski, i ten mi rozkazał, abych mu zbudował dom w Jeruzalem, które jest w Żydostwie.
###### **Ezd 1,3**
 Kto jest między wami ze wszystkiego ludu jego? Niechaj będzie z nimi Pan Bóg jego. Niech idzie do Jeruzalem, które jest w Żydostwie, a niech buduje dom Pana Boga Izraelskiego (on ci jest Bóg), który jest w Jeruzalem.
###### **Ezd 1,4**
 A wszyscy inni po wszystkich miejscach, gdziekolwiek mieszkają, niech go podpomagają mężowie z miejsca swego, srebrem i złotem, i majętnością, i bydłem, oprócz co dobrowolnie ofiarują kościołowi Bożemu, który jest w Jeruzalem.
###### **Ezd 1,5**
 I powstali przedniejszy z ojców, z Judy, i z Benjamin, i kapłani i Lewitowie, i wszelki, którego Bóg ducha wzbudził, aby szli budować kościół Pański, który był w Jeruzalem.
###### **Ezd 1,6**
 I wszyscy, którzy byli w okolicy, wspomogli ręce ich naczyniem srebrnem i złotem, majętnością i bydłem, sprzętem, oprócz tego co z dobrej wolej ofiarowali byli,
###### **Ezd 1,7**
 Król też Cyrus wyniósł naczynia kościoła Pańskiego, które był pobrał Nabuchodonozor z Jeruzalem, i położył je był we zborze Boga swego.
###### **Ezd 1,8**
 A Cyrus król Perski wyniósł je przez ręce Mithridata syna Gazabar, i odliczył je Sassabasar książęciu Judzkiemu.
###### **Ezd 1,9**
 I ta jest liczba ich: Czasz złotych trzydzieści, czasz srebrnych tysiąc, nożów dwadzieścia i dziewięć:
###### **Ezd 1,10**
 Kubków złotych trzydzieści, kubków srebrnych drugich cztery sta i dziesięć: inszego naczynia tysiąc.
###### **Ezd 1,11**
 Wszystkiego naczynia złotego i srebrnego pięć tysięcy i cztery sta: wszystko wziął Sassabasar z temi, którzy wyszli z przeprowadzenia Babilońskiego do Jeruzalem.
