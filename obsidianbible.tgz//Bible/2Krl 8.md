# 2Krl 8 BT5
###### **2Krl 8,1**
 Elizeusz powiedział do kobiety, której syna wskrzesił: «***Wstań, idź razem z twoją rodziną, zamieszkaj na obczyźnie – tam, gdzie będziesz mogła – ponieważ Pan sprowadził głód. Idzie on już na kraj na okres siedmiu lat***».
###### **2Krl 8,2**
 Kobieta wstała i spełniła to, co powiedział mąż Boży. Poszła ona razem ze swoją rodziną i żyła na obczyźnie w kraju Filistynów przez siedem lat.
###### **2Krl 8,3**
 Po upływie siedmiu lat kobieta wróciła z kraju Filistynów i udała się do króla, błagając o zwrot jej domu i jej pola.
###### **2Krl 8,4**
 Król zaś – w czasie rozmowy z Gechazim, sługą męża Bożego – powiedział: «***Opowiedz mi wszystkie wielkie dzieła, których dokonał Elizeusz***».
###### **2Krl 8,5**
 Podczas gdy Gechazi opowiadał królowi, jak [prorok] wskrzesił zmarłego, właśnie nadeszła kobieta, której syna wskrzesił, i odwołała się do króla w sprawie domu i pola. Wtedy Gechazi powiedział: «***Panie mój, królu, oto kobieta i oto jej syn, którego wskrzesił Elizeusz***».
###### **2Krl 8,6**
 Król wypytał kobietę, a ona mu opowiedziała. Wtedy król przydzielił jej jednego dworzanina, nakazując: «***Przywróć jej całą posiadłość oraz wszystkie dochody z pola od dnia, odkąd opuściła kraj, aż do dzisiaj***».
###### **2Krl 8,7**
 Elizeusz przyszedł do Damaszku. Kiedy Ben-Hadad, król Aramu, chorował, oznajmiono mu: «***Mąż Boży przyszedł aż tutaj***».
###### **2Krl 8,8**
 Wtedy król powiedział do Chazaela: «***Weź dar ze sobą, idź na spotkanie męża Bożego i przez niego wypytaj się Pana, czy wyzdrowieję z tej choroby***».
###### **2Krl 8,9**
 Wyszedł więc Chazael mu na spotkanie, wziął ze sobą dary i wszelkie kosztowności z Damaszku, obładowując czterdzieści wielbłądów. Przyszedł i stanął przed nim, mówiąc: «***Twój syn, Ben-Hadad, król Aramu, posłał mnie do ciebie z pytaniem: Czy wyzdrowieję z tej choroby?***»
###### **2Krl 8,10**
 Odpowiedział mu Elizeusz: «***Idź i powiedz mu: "Będziesz żył na pewno". Lecz Pan objawił mi, że na pewno on umrze***».
###### **2Krl 8,11**
 Następnie stężała mu twarz, zmieszał się mocno i zapłakał mąż Boży.
###### **2Krl 8,12**
 A Chazael zapytał: «***Dlaczego pan mój płacze?***» Odpowiedział: «***Ponieważ wiem, co złego uczynisz synom Izraela: ich warownie zniszczysz ogniem, kwiat ich wojowników pozabijasz, ich drobne dzieci roztrzaskasz, a ich brzemiennym kobietom będziesz rozpruwał łona***».
###### **2Krl 8,13**
 Wtedy Chazael zawołał: «***Czymże jest twój sługa, ten pies, żeby miał wykonać tę wielką zapowiedź?***» Elizeusz odpowiedział: «***Pan objawił mi, że będziesz królem Aramu***».
###### **2Krl 8,14**
 Oddalił się więc Chazael od Elizeusza i poszedł do swego pana, który go zapytał: «***Co ci zapowiedział Elizeusz?***» A on odrzekł: «***Zapowiedział mi, że na pewno będziesz żył***».
###### **2Krl 8,15**
 Następnego dnia Chazael wziął nakrycie, zamoczył w wodzie i rozciągnął na jego twarzy, tak iż on umarł. Chazael zaś w jego miejsce został królem.
###### **2Krl 8,16**
 W piątym roku [panowania] Jorama, syna Achaba, króla izraelskiego, < a Jozafat był królem Judy >, Joram, syn Jozafata, został królem judzkim.
###### **2Krl 8,17**
 W chwili objęcia rządów miał trzydzieści dwa lata i królował osiem lat w Jerozolimie.
###### **2Krl 8,18**
 Kroczył on drogą królów izraelskich, podobnie jak czynił rod Achaba, ponieważ córka Achaba była jego żoną. Czynił on to, co jest złe w oczach Pana.
###### **2Krl 8,19**
 Jednakże Pan nie chciał zniszczyć Judy ze względu na swego sługę, Dawida, tak jak mu obiecał, iż da mu przed sobą płomyk na zawsze.
###### **2Krl 8,20**
 Za jego czasów Edom wyrwał się spod władzy Judy i wybrał sobie króla.
###### **2Krl 8,21**
 Wtedy Joram ze wszystkimi rydwanami przeszedł do Sair. Kiedy powstał w nocy [do natarcia], przebił się przez Edomitów, którzy okrążyli jego oraz dowódców rydwanów. Lud zaś uciekł do swoich namiotów.
###### **2Krl 8,22**
 Edom zatem wyrwał się spod władzy Judy aż do dnia dzisiejszego. W tym samym czasie wyrwała się także Libna.
###### **2Krl 8,23**
 A czyż pozostałe dzieje Jorama i wszystkie jego czyny nie są opisane w Księdze Kronik Królów Judy?
###### **2Krl 8,24**
 I spoczął Joram ze swymi przodkami, i pochowano go obok przodków w Mieście Dawidowym, syn zaś jego, Ochozjasz, został w jego miejsce królem.
###### **2Krl 8,25**
 W dwunastym roku [panowania] Jorama, syna Achaba, króla Izraela – Ochozjasz, syn Jorama, został królem Judy.
###### **2Krl 8,26**
 W chwili objęcia władzy Ochozjasz miał dwadzieścia dwa lata i królował jeden rok w Jerozolimie. Jego matka miała na imię Atalia i była córką Omriego, króla izraelskiego.
###### **2Krl 8,27**
 Kroczył on drogą rodu Achaba i czynił to, co jest złe w oczach Pańskich, tak jak ród Achaba, ponieważ był spowinowacony z rodem Achaba.
###### **2Krl 8,28**
 Ochozjasz wyruszył z Joramem, synem Achaba, na wojnę przeciw Chazaelowi, królowi Aramu, w Ramot w Gileadzie. Lecz Aramejczycy zranili Jorama.
###### **2Krl 8,29**
 Zatem król Joram wycofał się do Jizreel, aby leczyć się z ran, które mu zadali Aramejczycy w Ramot, kiedy walczył przeciw Chazaelowi, królowi Aramu. Wtedy Ochozjasz, syn Jorama, król judzki, przyszedł odwiedzić Jorama, syna Achaba, w Jizreel, ponieważ był on chory.
# 2Krl 8 PAU
###### **2Krl 8,1**
 Elizeusz zwrócił się pewnego razu do kobiety, której syna wskrzesił: „Uciekaj ze swoją rodziną i zatrzymaj się tam, gdzie będziesz mogła, gdyż PAN na siedem lat zarządził głód, który właśnie nadszedł na ziemię”.
###### **2Krl 8,2**
 Kobieta postąpiła według słowa człowieka Bożego: wyruszyła ze swoją rodziną i zatrzymała się przez okres siedmiu lat w kraju Filistynów.
###### **2Krl 8,3**
 Kiedy siedem lat dobiegało końca, powróciła i poszła do króla z prośbą o zwrot jej domu i pola.
###### **2Krl 8,4**
 Król zaś rozmawiał właśnie z Gechazim, sługą Bożego człowieka: „Opowiedz mi o wszystkich wielkich dziełach, których dokonał Elizeusz”.
###### **2Krl 8,5**
 Gdy więc opowiadał królowi o tym, jak wskrzesił zmarłego, właśnie zjawiła się ta kobieta, której syna wskrzesił, prosząc króla o zwrot domu i pola. Odezwał się wówczas Gechazi: „Panie mój, królu! To jest ta kobieta, której syna wskrzesił Elizeusz”.
###### **2Krl 8,6**
 Król zaraz zaczął ją wypytywać, a ona mu o tym opowiedziała. Potem król przydzielił jej jednego z urzędników, polecając mu: „Przywróć jej wszystko, co do niej należy, łącznie z dochodami z pola, poczynając od dnia, w którym opuściła kraj, aż do dzisiaj”.
###### **2Krl 8,7**
 Pewnego razu Elizeusz przyszedł do Damaszku, a w tym czasie Ben-Hadad, król Aramu, był chory. Oznajmiono mu: „Człowiek Boży przyszedł aż tutaj”.
###### **2Krl 8,8**
 Wtedy król zwrócił się do Chazaela: „Weź ze sobą dar i udaj się na spotkanie człowieka Bożego. Poradź się PANA przez niego i zapytaj: «Czy wyzdrowieję z tej choroby?»”.
###### **2Krl 8,9**
 Chazael wyszedł więc na spotkanie z Elizeuszem, zabierając ze sobą dary z najlepszych rzeczy Damaszku, załadowane na czterdziestu wielbłądach. Kiedy przybył i stanął przed nim, powiedział: „Twój syn, Ben-Hadad, król Aramu, przysyła mnie do ciebie z pytaniem: «Czy wyzdrowieję z tej choroby?»”.
###### **2Krl 8,10**
 Elizeusz mu odpowiedział: „Idź i powiedz mu: «Na pewno będziesz żył». PAN jednak objawił mi, że on na pewno umrze”.
###### **2Krl 8,11**
 Wtedy z twarzą zastygłą, utkwił w nim wzrok, aż tamten się zawstydził. Po chwili zaś człowiek Boży zapłakał.
###### **2Krl 8,12**
 Wówczas Chazael się odezwał: „Dlaczego mój pan płacze?”. Odpowiedział: „Wiem bowiem, jak wiele zła wyrządzisz Izraelitom: ich twierdze spalisz ogniem, młodych mężczyzn pozabijasz mieczem, główki niemowląt roztrzaskasz i rozprujesz brzuchy kobietom brzemiennym”.
###### **2Krl 8,13**
 Chazael odrzekł na to: „Czymże jest twój sługa - czyż nie jest zwykłym psem? Jakże mógłbym dokonać tak strasznej rzeczy?”. Lecz Elizeusz odparł: „PAN mi objawił, że to ty będziesz królem Aramu”.
###### **2Krl 8,14**
 Chazael odszedł więc od Elizeusza i wrócił do swojego pana, który zapytał go: „I co ci powiedział Elizeusz?”. Odparł: „Powiedział mi, że na pewno będziesz żył”.
###### **2Krl 8,15**
 Ale następnego dnia wziął kawałek grubego materiału, zamoczył w wodzie i przykrył jego twarz. W ten sposób Ben-Hadad umarł, a Chazael został po nim królem.
###### **2Krl 8,16**
 W piątym roku rządów Jorama, syna Achaba, króla Izraela, Joram, syn Jozafata, został królem Judy.
###### **2Krl 8,17**
 Miał trzydzieści dwa lata, gdy wstąpił na tron, i przez osiem lat panował w Jerozolimie.
###### **2Krl 8,18**
 Postępował on jednak wzorem królów izraelskich, naśladując we wszystkim ród Achaba, gdyż córka Achaba była jego żoną. Czynił więc to, co nie podobało się Panu.
###### **2Krl 8,19**
 Pan jednak nie chciał zniszczyć Judy ze względu na Dawida, swojego sługę, zgodnie z daną mu obietnicą, że na zawsze zachowa lampę świecącą dla niego i jego następców.
###### **2Krl 8,20**
 Za rządów Jorama Edomici wyrwali się spod panowania Judy i ustanowili sobie króla.
###### **2Krl 8,21**
 Wówczas Joram wyruszył w kierunku Sair ze wszystkimi swoimi rydwanami. Wstał w nocy i uderzył na Edomitów, którzy otoczyli go wraz z jego dowódcami rydwanów, podczas gdy jego wojsko uciekło do swoich domów.
###### **2Krl 8,22**
 Edom pozostaje więc niezależny od Judy aż do dnia dzisiejszego. W tym samym czasie odpadła również Libna.
###### **2Krl 8,23**
 Pozostałe wydarzenia związane z panowaniem Jorama obejmujące wszystko, czego dokonał, są opisane w kronikach królów Judy.
###### **2Krl 8,24**
 Joram spoczął przy swoich przodkach, a pochowano go w Mieście Dawida. Jego syn, Ochozjasz, został po nim królem.
###### **2Krl 8,25**
 W dwunastym roku rządów Jorama, syna Achaba, króla Izraela, Ochozjasz, syn Jorama, został królem Judy.
###### **2Krl 8,26**
 Ochozjasz miał dwadzieścia dwa lata, gdy wstąpił na tron i przez jeden rok panował w Jerozolimie. Jego matka miała na imię Atalia i była wnuczką Omriego, króla izraelskiego.
###### **2Krl 8,27**
 Postępował on jak dom Achaba. Czynił to, co nie podobało się PANU, naśladując ród Achaba, gdyż był z nim spokrewniony.
###### **2Krl 8,28**
 Wyruszył z Joramem, synem Achaba, na wojnę przeciwko Chazaelowi, królowi Aramu, pod Ramot w Gileadzie. Lecz Aramejczycy zranili Jorama.
###### **2Krl 8,29**
 Król Joram wycofał się więc do Jezreel, żeby tam wyleczyć się z ran, które mu zadali Aramejczycy w Ramot podczas bitwy z Chazaelem, królem Aramu. Ochozjasz, syn Jorama, króla Judy, udał się więc do Jezreel, aby odwiedzić chorego Jorama, syna Achaba.
# 2Krl 8 BP
###### **2Krl 8,1**
 Elizeusz powiedział do kobiety, której syna wskrzesił, te słowa: Wstań, idź - ty i twój dom - i przenieś się tam, gdzie będziesz się mogła osiedlić, bo Jahwe wezwał głód i już przychodzi do kraju na siedem lat.
###### **2Krl 8,2**
 Wstała więc kobieta i uczyniła według słowa męża Bożego - ona i jej dom - i mieszkała w ziemi filistyńskiej siedem lat.
###### **2Krl 8,3**
 Potem gdy upłynęło siedem lat, wróciła [owa] kobieta z ziemi filistyńskiej i poszła, aby upomnieć się u króla o swój dom i o swoje pole.
###### **2Krl 8,4**
 Król rozmawiał [właśnie] z Gechazim, sługą męża Bożego, mówiąc: Opowiedz mi - proszę - o wszystkich wielkich [dziełach], jakich dokonał Elizeusz.
###### **2Krl 8,5**
 Gdy on opowiadał królowi, jak [Elizeusz] wskrzesił umarłego, oto kobieta, której [on] syna wskrzesił, upominała się u króla o swój dom i o swoje pole. [Wówczas] Gechazi rzekł: Panie mój, królu. [To jest] ta kobieta i [to jest] ten jej syn, którego wskrzesił Elizeusz.
###### **2Krl 8,6**
 Król poprosił kobietę i opowiedziała mu. Król dał jej [potem] pewnego dostojnika polecając: Przywróć [jej] wszystko, co do niej należy, i wszystkie dochody z pola od dnia, w którym opuściła kraj, aż do teraz.
###### **2Krl 8,7**
 Elizeusz przybył do Damaszku. BenHadad, król Aramu, chorował. Oznajmiono mu mówiąc: Mąż Boży przyszedł aż tutaj.
###### **2Krl 8,8**
 Król rzekł do Chazaela: Weź z sobą podarek, wyjdź naprzeciw męża Bożego i zasięgnij rady Jahwe przez niego pytając, czy wyzdrowieję z tej mojej choroby.
###### **2Krl 8,9**
 Chazael wyszedł naprzeciw niego. Wziął z sobą podarek - wszystko, co było najlepszego w Damaszku: obciążenie czterdziestu wielbłądów - przyszedł, zatrzymał się przed nim i rzekł: Syn twój, Ben-Hadad, król Aramu, posłał mię do ciebie pytając: Czy wyzdrowieję z tej mojej choroby.
###### **2Krl 8,10**
 Elizeusz odpowiedział mu: Idź, powiedz mu: Na pewno wyzdrowiejesz. Ale Jahwe objawił mi, że na pewno umrze.
###### **2Krl 8,11**
 [Po czym] jego twarz zmartwiała. Mąż Boży wzruszył się i rozpłakał.
###### **2Krl 8,12**
 Chazael zapytał: Dlaczego pan mój płacze? Odpowiedział: Bo wiem, ile zła wyrządzisz synom Izraela. Ich twierdze spalisz, młodzieńców pomordujesz mieczem, dzieci roztrzaskasz [o mury], zaś ich brzemiennym wyprujesz [wnętrzności].
###### **2Krl 8,13**
 Chazael odparł: Czy twój sługa jest psem, żeby czynił tę okropną rzecz? Elizeusz rzekł: Jahwe mi objawił, że ty zostaniesz królem nad Aramem.
###### **2Krl 8,14**
 Odszedł od Elizeusza i przyszedł do swego pana. [Ten] zapytał go: Co ci powiedział Elizeusz? Odpowiedział: Rzekł mi: Na pewno wyzdrowiejesz.
###### **2Krl 8,15**
 Następnego dnia wziął przykrycie, umoczył w wodzie i rozciągnął nad jego twarzą. [Król] umarł. Chazael został po nim królem.
###### **2Krl 8,16**
 W piątym roku [panowania] Jorama, syna Achaba, króla izraelskiego [...] władcą został Joram, syn Jozafata, króla Judy.
###### **2Krl 8,17**
 Miał trzydzieści dwa lata, gdy zaczął panować, a osiem lat królował w Jerozolimie.
###### **2Krl 8,18**
 Szedł drogą królów izraelskich, jak to czynił dom Achaba, bo miał za żonę córkę Achaba. Czynił to, co było złe w oczach Jahwe.
###### **2Krl 8,19**
 Jahwe nie chciał wygubić Judy przez wzgląd na Dawida, swego sługę, ponieważ obiecał mu zostawić iskierkę po wszystkie dni przed swoim obliczem.
###### **2Krl 8,20**
 Za jego dni wyzwolił się Edom spod ręki Judy i ustanowił nad sobą króla.
###### **2Krl 8,21**
 Joram wyprawił się do Sairu, biorąc wszystkie rydwany z sobą. Wstał on w nocy i pobił Edomitów, którzy go otoczyli [wraz] z dowódcami rydwanów. Lud uciekł do swoich namiotów.
###### **2Krl 8,22**
 Wyzwolił się więc Edom spod ręki Judy aż do tego dnia. W tym samym czasie zbuntowała się również Libna.
###### **2Krl 8,23**
 Reszta dziejów Jorama i wszystko, co zdziałał, czyż te [sprawy] nie są opisane w Księdze Kronik Królów Judy?
###### **2Krl 8,24**
 Joram spoczął ze swoimi przodkami i został pogrzebany wraz ze swoimi ojcami w Mieście Dawidowym. Po nim królował jego syn Ochozjasz.
###### **2Krl 8,25**
 Ochozjasz, syn Jorama, króla Judy, został władcą w dwunastym roku [panowania] Jorama, syna Achaba, króla izraelskiego.
###### **2Krl 8,26**
 Ochozjasz miał dwadzieścia dwa lata, gdy zaczął panować, i jeden rok królował w Jerozolimie. Jego matka nazywała się Atalia i była córką Omriego, króla Izraela.
###### **2Krl 8,27**
 Szedł drogą domu Achaba i czynił to, co było złe w oczach Jahwe, jak dom Achaba, gdyż był on zięciem domu Achaba.
###### **2Krl 8,28**
 Wyruszył z Joramem, synem Achaba, na wojnę z Chazaelem, królem Aramu, o Ramot Gilead. Aramejczycy zranili Jorama.
###### **2Krl 8,29**
 Król Joram powrócił do Jizreel, aby się leczyć z rany, którą mu zadali Aramejczycy w Ramot, gdy walczył z Chazaelem, królem Aramu. Ochozjasz, syn Jorama, króla Judy, zstąpił, aby zobaczyć Jorama, syna Achaba, w Jizreel, ponieważ był chory.
# 2Krl 8 BR
###### **2Krl 8,1**
 Elizeusz powiedział do kobiety, której dziecko kiedyś przywrócił do życia: Wstań, uchodź stąd z całą twoją rodziną i zamieszkaj w innej okolicy, gdzie będziesz mogła, gdyż Jahwe zsyła na cały ten kraj klęskę głodu, która będzie trwała siedem lat.
###### **2Krl 8,2**
 Wstawszy tedy kobieta uczyniła tak, jak jej nakazał mąż Boży: poszła z całą swoją rodziną i pozostawała przez siedem lat w kraju Filistynów.
###### **2Krl 8,3**
 Po siedmiu latach wróciwszy z kraju Filistynów, udała się do króla w sprawie swojego domu i pola.
###### **2Krl 8,4**
 Król zaś akurat rozmawiał z Gechazim, sługą męża Bożego, domagając się, żeby mu ów sługa wyliczył wszystkie niezwykłe dzieła, których dokonał Elizeusz.
###### **2Krl 8,5**
 Sługa opowiadał właśnie o tym, jak jego pan przywrócił do życia pewnego zmarłego, kiedy weszła kobieta, której syna z martwych wskrzesił Elizeusz, i zaczęła przedstawiać królowi sprawę swojego domu i pola. Powiedział wtedy Gechazi: Królu mój i panie, oto kobieta i jej syn, którego Elizeusz przywrócił do życia.
###### **2Krl 8,6**
 Zapytana o to przez króla, kobieta opowiedziała mu o wszystkim. Król przywołał jednego ze swych urzędników i wydał mu taki rozkaz: Dopilnuj, żeby zwrócono jej wszystko, co do niej należało ze wszystkimi [corocznymi] zbiorami z pól, od czasu wyjścia jej z tego kraju aż do dnia dzisiejszego.
###### **2Krl 8,7**
 Elizeusz udał się do Damaszku. Gdy królowi Aramu, Ben-Hadadowi, który był wtedy chory, doniesiono, że przybył tam mąż Boży,
###### **2Krl 8,8**
 król tak powiedział do Chazaela: Weź ze sobą jakiś podarek, udaj się do męża Bożego i za jego pośrednictwem zapytaj Jahwe, czy wyjdę z tej choroby.
###### **2Krl 8,9**
 Udał się tedy Chazael do Elizeusza, przynosząc ze sobą dary z tego wszystkiego, co było najcenniejsze w Damaszku. Dary dźwigało czterdzieści wielbłądów. Kiedy przybył na miejsce, stanął przed Elizeuszem i powiedział: syn twój, Ben-Hadad, król Aramu, przysłał mnie, żebym cię zapytał, czy wyjdzie on z tej choroby.
###### **2Krl 8,10**
 Rzekł na to Elizeusz: wracaj i powiedz, że napewno wyjdzie z tej choroby, ale że Jahwe objawił mi również, iż wkrótce potem umrze.
###### **2Krl 8,11**
 [Powiedziawszy to] mąż Boży zatrzymał swój wzrok na Chazaelu i tak mu się przypatrywał, że tamten aż poczerwieniał.
###### **2Krl 8,12**
 I zapłakał mąż Boży. Chazael zapytał wtedy: Dlaczego mój pan płacze? A Elizeusz odpowiedział: Bo wiem, ile zła ty właśnie wyrządzisz synom Izraela. To ty puścisz z dymem ich miasta warowne, ty wytracisz mieczem ich młodych wojowników, pozbawisz życia ich niemowlęta i będziesz rozpruwał łona ich brzemiennych kobiet.
###### **2Krl 8,13**
 Rzekł na to Chazael: A czyż twój sługa jest podłym psem, żeby miał dopuszczać się takich zbrodni? Odpowiedział Elizeusz: Jahwe mi już objawił, że ty będziesz królem Aramejczyków.
###### **2Krl 8,14**
 Opuściwszy Elizeusza, Chazael powrócił do swojego pana, który go zaraz zapytał: Co powiedział ci Elizeusz? On zaś odrzekł: Zapewnia cię, że wyjdziesz z tej choroby.
###### **2Krl 8,15**
 Nazajutrz Chazael wziął prześcieradło, zmoczył je w wodzie i owinął nim głowę króla, wskutek czego król zmarł. Władzę po zmarłym królu objął Chazael.
###### **2Krl 8,16**
 W piątym roku panowania Jorama, syna Achaba, króla izraelskiego, kiedy królem judzkim był jeszcze Jozafat, królem w Judzie został Joram, syn Jozafata.
###### **2Krl 8,17**
 Gdy wstąpił na tron, miał trzydzieści dwa lata, a sprawował władzę przez lat osiem, przebywając w Jerozolimie.
###### **2Krl 8,18**
 Naśladował swoim życiem królów izraelskich, a zwłaszcza tych z domu Achaba, gdyż miał za żonę jedną z córek Achaba. Czynił wszystko, co jest złe w oczach Jahwe.
###### **2Krl 8,19**
 Jahwe nie chciał zniszczyć Judy ze względu na Dawida, swego sługę, zgodnie z obietnicą, którą mu uczynił, że mianowicie światłość będzie zawsze nad jego potomkami.
###### **2Krl 8,20**
 Wtedy to Edom uwolnił się od władzy Judy i ustanowił sobie własnego króla.
###### **2Krl 8,21**
 Zebrał tedy Joram wszystkie swoje rydwany i wyruszył na Sair. Kiedy powstawszy nocą zaatakował Edomitów, ci okrążyli ze wszystkich stron jego samego oraz rydwany, natomiast reszta jego wojowników schroniła się w namiotach.
###### **2Krl 8,22**
 I tak Edom wyzwolił się spod władzy judzkiej [i jest wolny] aż po dzień dzisiejszy. W tym samym czasie usamodzielniła się także Libna.
###### **2Krl 8,23**
 Pozostałe dzieje Jorama, wszystkie jego dokonania są opisane w Księdze kronik królów judzkich.
###### **2Krl 8,24**
 Kiedy Joram odszedł do swoich przodków i został pochowany obok praojców w Mieście Dawidowym, władzę po nim objął jego syn Ochozjasz.
###### **2Krl 8,25**
 W dwunastym roku panowania Jorama, syna Achaba, króla izraelskiego, królem Judy został Ochozjasz, syn Jorama.
###### **2Krl 8,26**
 Kiedy wstępował na tron, miał dwadzieścia dwa lata, rządził zaś tylko jeden rok, przebywając w Jerozolimie. Jego matka nazywała się Atalia i była krewną Ormiego, króla izraelskiego.
###### **2Krl 8,27**
 W swoim postępowaniu naśladował on Achaba, gdyż był spowinowacony z jego rodem, i czynił to, co jest złe w oczach Jahwe.
###### **2Krl 8,28**
 Razem z Joramem, synem Achaba, stanął on w Ramot w Gileadzie do walki z Chzaelem, królem Aramu. Aramejczycy zranili Jorama,
###### **2Krl 8,29**
 wobec czego wrócił on do Jizreel, żeby się wyleczyć z ran zadanych mu przez Aramejczyków pod Ramot, gdzie walczył przeciwko Chazaelowi, królowi Aramu. Wtedy to Ochozjasz, syn Jorama, króla judzkiego, przyszedł do Jizreel, żeby odwiedzić chorego Jorama.
# 2Krl 8 WUJ
###### **2Krl 8,1**
 A Elizeusz rzekł do onej niewiasty, której był syna ożywił, mówiąc: Wstań, a idź ty i dom twój, a bądź gościem gdziekolwiek najdziesz: bo Pan zawołał głodu, i przyjdzie na ziemię przez siedm lat.
###### **2Krl 8,2**
 Która wstała i uczyniła według słowa człowieka Bożego, a poszedszy z domem swym była gościem w ziemi Philistyńskiej przez wiele dni?
###### **2Krl 8,3**
 A gdy wyszło siedm lat, wróciła się niewiasta z ziemi Philistyńskiej: i wyszła, aby prosiła króla o dom swój i o role swoje.
###### **2Krl 8,4**
 A król rozmawiał z Giezym sługą męża Bożego, mówiąc: Powiadaj mi wszystkie zacne rzeczy, które czynił Elizeusz,
###### **2Krl 8,5**
 A gdy on powiedał królowi jako wskrzesił umarłego, ukazała się niewiasta, której był syna ożywił, wołając do króla o dom swój i o role swoje. I rzekł Giezy: Panie mój królu, tać to jest niewiasta, i to jest syn jej, którego wskrzesił Elizeusz.
###### **2Krl 8,6**
 I pytał król niewiasty: która mu powiedziała. I dał jej król rzezańca jednego, mówiąc: Przywróć jej wszystko co jej jest, i wszystkie dochody z ról, odednia którego opuściła ziemię aż dotąd.
###### **2Krl 8,7**
 Przyszedł też Elizeusz do Damaszku, a Benadad król Syryjski chorował: i powiedziano mu, mówiąc: Przyszedł tu mąż Boży.
###### **2Krl 8,8**
 I rzekł król do Hazaela: Weźmi z sobą dary, a idź przeciwko mężowi Bożemu, a poradź się Pana przezeń, mówiąc: Będę li mógł wybiegać się z tej niemocy mojej?
###### **2Krl 8,9**
 A tak poszedł Hazael przeciwko niemu, mając z sobą dary i wszelkie dobra Damaszku brzemiona czterdziestu wielbłądów. I stanąwszy przed nim, rzekł: Syn twój Benadad król Syryjski posłał mię do ciebie, mówiąc: Będę li mógł ozdrowieć z tej niemocy mojej.
###### **2Krl 8,10**
 I rzekł mu Elizeusz: Idź, rzecz mu: Będziesz zdrów: lecz mi Pan pokazał, że śmiercią umrzesz.
###### **2Krl 8,11**
 I stał z nim, i stworzył się, aż do zapłonienia twarzy: i płakał mąż Boży.
###### **2Krl 8,12**
 Któremu rzekł Hazael: Czemu Pan mój płacze? A on rzekł: Iż wiem co za złości poczynisz synom Izraelowym. Miasta ich obronne ogniem spalisz, i młodzieńce ich mieczem pomordujesz, i dzieci ich poroztrącasz, a brzemienne porozcinasz.
###### **2Krl 8,13**
 I rzekł Hazael: A cóżem ja sługa twój, pies, żebych miał uczynić rzecz tak wielką? I rzekł Elizeusz: Okazał mi Pan, że ty będziesz królem Syryjskim.
###### **2Krl 8,14**
 Który odszedszy od Elizeusza przyszedł do pana swego. Który rzekł do niego: Cóżci powiedział Elizeusz: A on odpowiedział: Powiedział mi, przyjdziesz do zdrowia.
###### **2Krl 8,15**
 A gdy przyszedł dzień drugi, wziął kołdrę, i nalał wody i rozciągnął na obliczu jego: który gdy umarł, królował Hazael miasto niego.
###### **2Krl 8,16**
 Roku piątego Jorama syna Achaba króla Izraelskiego, i Jozaphata króla Judzkiego królował Joram syn Jozaphata króla Judzkiego.
###### **2Krl 8,17**
 Trzydzieści mu lat i dwie było, gdy począł królować, a ośm lat królował w Jeruzalem.
###### **2Krl 8,18**
 I chodził drogami królów Izraelskich, jako chodził dom Achabów: córka bowiem Achabowa była żona jego: i czynił złość przed oczyma Pańskimi.
###### **2Krl 8,19**
 A Pan niechciał wytracić Judy dla Dawida sługi swego, jako mu był przyrzekł, aby mu dał świecę i synom jego po wszystkie dni.
###### **2Krl 8,20**
 Za czasów jego odstąpił Edom, aby nie był pod Juda, i postanowił sobie króla.
###### **2Krl 8,21**
 I przyciągnął Joram do Seira i wszystkie wozy z nim: i wstał w nocy i poraził Edomczyki, którzy go byli obtoczyli, i hetmany wozów, a lud uciekł do przybytków swoich.
###### **2Krl 8,22**
 Odstąpił tedy Edom, żeby nie był pod Juda aż do dnia dzisiejszego. Obstąpiła tedy i Lobna onego czasu.
###### **2Krl 8,23**
 A ostatek mów Joram i wszystko co czynił, izali to nie napisano jest w księgach słów dni królów Judzkich.
###### **2Krl 8,24**
 I zasnął Joram z ojcy swemi: i pogrzebion jest z nimi w mieście Dawidowem, i królował Ochoziasz syn jego miasto niego.
###### **2Krl 8,25**
 Roku dwunastego Jorama syna Achabowego króla Izraelskiego królował Ochoziasz syn Jorama króla Judzkiego.
###### **2Krl 8,26**
 Dwadzieścia lat i dwie było Ochozyaszowi, gdy począł królować, a rok jeden królował w Jeruzalem: imię matki jego Athalia córka Amry króla Izraelskiego.
###### **2Krl 8,27**
 I chodził drogami domu Achabowego, i czynił złość przed Panem, jako dom Achabów: bo był zięciem domowi Achabowemu.
###### **2Krl 8,28**
 Wyciągnął też z Joramem synem Acliabowyni na wojnę przeciw Hazaelowi królowi Syryjskiemu do Ramoth Galaad, i zranili Syryjczykowie Jorama.
###### **2Krl 8,29**
 Który się wrócił, żeby go leczono do Jezrahel, bo go zranili byli Syryjczykowie w Ramoth walczącego przeciw Hazaelowi królowi Syryjskiemu. A Ochoziasz syn Joramów król Judzki, stąpił nawiedzać syna Achabowego w Jezrahelu, bo tam chorował.
