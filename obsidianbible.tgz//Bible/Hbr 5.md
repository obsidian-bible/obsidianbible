# Hbr 5 BT5
###### **Hbr 5,1**
 Każdy bowiem arcykapłan spomiędzy ludzi brany, dla ludzi jest ustanawiany w sprawach odnoszących się do Boga, aby składał dary i ofiary za grzechy.
###### **Hbr 5,2**
 Może on współczuć tym, którzy nie wiedzą i błądzą, ponieważ sam podlega słabości.
###### **Hbr 5,3**
 I ze względu na nią powinien tak za lud, jak i za samego siebie składać ofiary za grzechy.
###### **Hbr 5,4**
 A nikt sam sobie nie bierze tej godności, lecz tylko ten, kto jest powołany przez Boga jak Aaron.
###### **Hbr 5,5**
 Podobnie i Chrystus nie sam siebie okrył sławą przez to, iż stał się arcykapłanem, ale [uczynił to] Ten, który powiedział do Niego:Ty jesteś moim Synem, Ja Cię dziś zrodziłem,
###### **Hbr 5,6**
 jak i w innym [miejscu]:Ty jesteś kapłanem na wiekina wzór Melchizedeka.
###### **Hbr 5,7**
 Z głośnym wołaniem i płaczem za swych dni doczesnych zanosił On gorące prośby i błagania do Tego, który mógł Go wybawić od śmierci, i został wysłuchany dzięki swej uległości.
###### **Hbr 5,8**
 I chociaż był Synem, nauczył się posłuszeństwa przez to, co wycierpiał.
###### **Hbr 5,9**
 A gdy wszystko wykonał, stał się sprawcą zbawienia wiecznego dla wszystkich, którzy Go słuchają,
###### **Hbr 5,10**
 nazwany przez Boga arcykapłanem na wzór Melchizedeka.
###### **Hbr 5,11**
 Wiele mamy o Nim do powiedzenia, a trudno to wyjaśnić, ponieważ ociężali jesteście w słuchaniu.
###### **Hbr 5,12**
 Gdy bowiem ze względu na czas powinniście być nauczycielami, sami potrzebujecie kogoś, kto by was pouczył o podstawowych zasadach słów Bożych, i mleka wam potrzeba, a nie stałego pokarmu.
###### **Hbr 5,13**
 Każdy, kto pije [tylko] mleko, nieświadom jest nauki o sprawiedliwości, ponieważ jest niemowlęciem.
###### **Hbr 5,14**
 Przeciwnie, stały pokarm jest właściwy dla dorosłych, którzy przez ćwiczenie mają władze umysłu zaprawione do rozróżniania dobra i zła.
# Hbr 5 PAU
###### **Hbr 5,1**
 Każdy bowiem najwyższy kapłan, brany spośród ludzi, dla ludzi też jest ustanawiany w sprawach Bożych, aby składał dary i ofiary za grzechy.
###### **Hbr 5,2**
 Potrafi on współczuć tym, którzy błądzą nieświadomie, gdyż i sam podlega słabości.
###### **Hbr 5,3**
 Z tego też powodu musi składać ofiary za grzechy zarówno w imieniu ludu, jak i własnym.
###### **Hbr 5,4**
 A nikt nie może przyjąć tej godności, jeśli nie jest powołany przez Boga jak Aaron.
###### **Hbr 5,5**
 Toteż i Chrystus nie sam siebie okrył chwałą najwyższego kapłana. Uczynił to Ten, który powiedział do Niego: Ty jesteś moim Synem, Ja Ciebie dziś zrodziłem.
###### **Hbr 5,6**
 Podobnie mówi w innym miejscu: Ty jesteś kapłanem na wieki na wzór Melchizedeka.
###### **Hbr 5,7**
 On to podczas swego ziemskiego życia, z wielkim wołaniem i łzami zanosił błagania i prośby do Tego, który mógł Go ocalić od śmierci. I został wysłuchany dzięki swej uległości!
###### **Hbr 5,8**
 Chociaż był Synem, przez cierpienia nauczył się posłuszeństwa.
###### **Hbr 5,9**
 Tak udoskonalony, stał się przyczyną wiecznego zbawienia dla wszystkich, którzy są Mu posłuszni.
###### **Hbr 5,10**
 A Bóg ogłosił Go najwyższym kapłanem na wzór Melchizedeka.
###### **Hbr 5,11**
 Mamy o tym wiele do powiedzenia, lecz trudno wam to przekazać, skoro w słuchaniu staliście się ociężali.
###### **Hbr 5,12**
 Chociaż bowiem ze względu na czas winniście już być nauczycielami, sami ponownie potrzebujecie pouczenia o podstawowych zasadach nauki Bożej. Zamiast stałego pokarmu, znowu potrzebujecie mleka!
###### **Hbr 5,13**
 Każdy bowiem niewprawny w nauce sprawiedliwości jest jak niemowlę ssące mleko.
###### **Hbr 5,14**
 Dojrzali zaś przyjmują pokarm stały, gdyż przez praktykę mają zmysły wyćwiczone do rozróżniania między tym co dobre i złe.
# Hbr 5 BP
###### **Hbr 5,1**
 Każdy przecież arcykapłan brany jest spośród ludzi i ustanawiany nad ludźmi w sprawach Bożych, żeby składał dary i ofiary za grzechy.
###### **Hbr 5,2**
 Może on okazywać łagodność wobec niewiedzących i błądzących, ponieważ i sam doznaje słabości,
###### **Hbr 5,3**
 wszak musi tak za lud, jak i za siebie składać ofiarę za grzechy.
###### **Hbr 5,4**
 A nikt nie bierze sobie tego zaszczytu, jeśli nie jest powołany przez Boga tak jak Aaron.
###### **Hbr 5,5**
 Również i Chrystus nie sam siebie obdarzył godnością arcykapłańską, ale Ten, kto powiedział do Niego: "Synem moim jesteś, jam ciebie dziś zrodził",
###### **Hbr 5,6**
 jak i na innym miejscu mówi: "Tak jesteś kapłanem na wieki na podobieństwo Melchizedecha".
###### **Hbr 5,7**
 On to za swego życia na ziemi z głośnym wołaniem i łzami zanosił modły i błagania do Tego, który mógł Go ocalić od śmierci. I został wysłuchany, bo okazał uległość.
###### **Hbr 5,8**
 Chociaż był Synem, z tego, co wycierpiał, doznał, czym jest posłuszeństwo.
###### **Hbr 5,9**
 A poznawszy je tak doskonale, stał się sprawcą zbawienia wiecznego dla wszystkich, którzy są Mu posłuszni.
###### **Hbr 5,10**
 Nazwany został przez Boga arcykapłanem "na podobieństwo Melchizedecha".
###### **Hbr 5,11**
 Na ten temat trzeba będzie wam dużo powiedzieć i włożyć wiele trudu w wyjaśnienie, bo niechętni z was słuchacze.
###### **Hbr 5,12**
 A chociaż byłby już czas na to, żebyście [innych] nauczali, trzeba was na nowo pouczać o najprostszych zasadach nauki Bożej, czyli dawać mleko zamiast stałego pokarmu.
###### **Hbr 5,13**
 A przecież każdy, kto żywi się mlekiem, nieświadom jest nauki o sprawiedliwości, bo jest dzieckiem.
###### **Hbr 5,14**
 Dorośli natomiast, ci mianowicie, którzy przez ćwiczenie wyrobili w sobie łatwość rozróżniania dobra od zła, potrzebują stałego pokarmu.
# Hbr 5 BR
###### **Hbr 5,1**
 Każdy bowiem arcykapłan wzięty spomiędzy ludzi ustanowiony jest po to, aby w ich imieniu pełnił służbę Bożą; aby składał dary i ofiary za grzechy.
###### **Hbr 5,2**
 Powinien współczuć tym, którzy trwają w niewiedzy i w błędzie, bo przecież sam również podlega słabościom.
###### **Hbr 5,3**
 Powinien też nie tylko za lud, lecz także i za siebie składać ofiary za grzechy.
###### **Hbr 5,4**
 I nikt nie może sam sobie przywłaszczać tej godności, lecz tak jak Aaron powinien być powołany przez Boga.
###### **Hbr 5,5**
 Chrystus również nie sam według własnego uznania zdobył sobie sławę przez to, że stał się arcykapłanem. Uczynił to Ten, który powiedział do Niego: Jesteś moim Synem. Ja dziś Ciebie zrodziłem.
###### **Hbr 5,6**
 Na innym zaś miejscu oświadczył: Ty jesteś kapłanem na wieki na wzór Melchizedeka.
###### **Hbr 5,7**
 Za dni swego ziemskiego życia, wołając donośnie i płacząc, zanosił modły i błagania gorące do Tego, który mógł Go wybawić [od śmierci]. Ze względu na swą uległość został wysłuchany.
###### **Hbr 5,8**
 I chociaż był Synem [Bożym], nauczył się przez swe cierpienie [prawdziwego] posłuszeństwa.
###### **Hbr 5,9**
 A kiedy już dokonał całego dzieła, dla wszystkich, którzy Go słuchają, stał się sprawcą wiecznego zbawienia.
###### **Hbr 5,10**
 On, którego Bóg nazwał kapłanem na wzór Melchizedeka.
###### **Hbr 5,11**
 Mielibyśmy jeszcze wiele do powiedzenia o Nim, ale trudno przedłożyć wam całą naukę, gdyż jesteście bardzo nieskorzy do słuchania.
###### **Hbr 5,12**
 Upłynęło wiele czasu i powinniście sami stać się nauczycielami innych, tymczasem was właśnie trzeba jeszcze nauczać i przekazywać wam rzeczy najbardziej elementarne z nauki Bożej. Zamiast odżywiać się już solidnym pokarmem, wy jeszcze ciągle potrzebujecie mleka [niczym niemowlęta].
###### **Hbr 5,13**
 Otóż każdy, kto odżywia się tylko mlekiem, nie wie, co to sprawiedliwość, bo jest jeszcze niemowlęciem.
###### **Hbr 5,14**
 Natomiast stałym pokarmem żywią się ludzie dorośli, którzy wskutek posiadanego doświadczenia mają umysł dostatecznie wyszkolony i potrafią odróżnić dobro od zła.
# Hbr 5 WUJ
###### **Hbr 5,1**
 Abowiem każdy Nawyższy kapłan z ludzi wzięty, dla ludzi bywa postanowion w tem co do Boga należy, aby ofiarował dary i ofiary za grzechy.
###### **Hbr 5,2**
 Któryby się mógł użalić tych co nie umieją i błądzą: gdyż i on obłożon jest krewkością:
###### **Hbr 5,3**
 A dla tego powinien jest, jako za lud, także i sam za się ofiarować za grzechy.
###### **Hbr 5,4**
 A żaden sobie czci nie bierze: jedno który bywa wezwan od Boga, jako Aaron.
###### **Hbr 5,5**
 Tak i Chrystus nie sam siebie wsławił, że się stał Nawyższym kapłanem: ale który do niego mówił, Syn mój jesteś ty, jam ciebie dziś urodził.
###### **Hbr 5,6**
 Jako i na inszem miejscu mówi: Tyż jest kapłanem na wieki, wedle porządku Melchisedechowego.
###### **Hbr 5,7**
 Który za dni ciała swego, modlitwy i pokorne prośby temu, który go mógł wybawić od śmierci, z wołaniem potężnem, i łzami ofiarowawszy, był wysłuchan dla swej uczciwości.
###### **Hbr 5,8**
 A chociaż był synem Bożym, nauczył się z tego co cierpiał posłuszeństwa:
###### **Hbr 5,9**
 A doskonałym zostawszy, stał się wszystkim, którzy mu posłuszni są przyczyną zbawienia wiecznego.
###### **Hbr 5,10**
 Nazwany od Boga Nawyższym kapłanem, wedle porządku Melchisedecha.
###### **Hbr 5,11**
 O którym nam wielka rzecz i nie wyprawna ku mówieniu: boście się stali słabymi ku słuchaniu.
###### **Hbr 5,12**
 Abowiem, gdyście mieli dla czasu być nauczycielami: zasię potrzebujecie, aby was uczono, które są początki zaczęcia mów Bożych: i staliście się, którymby mleka trzeba, a nie twardego pokarmu.
###### **Hbr 5,13**
 Bo każdy, który jest mleka uczestnikiem, nie świadom jest mowy sprawiedliwości: abowiem dzieciątkiem jest.
###### **Hbr 5,14**
 A doskonałych jest twardy pokarm: tych którzy przez zwyczajenie zmysły mają wyćwiczone ku rozeznaniu dobrego i złego.
# Hbr 5 STERN
###### **Hbr 5,1**
 Bo każdy kohen gadol wzięty spośród ludzi jest mianowany, aby występować w imieniu ludu w sprawach związanych z Bogiem, aby składać dary i ofiary za grzechy.
###### **Hbr 5,2**
 Może on odnosić się łagodnie do nieuczonych i tych, którzy błądzą, bo i on jest poddany słabości.
###### **Hbr 5,3**
 Z powodu tej słabości musi on składać ofiary również za własne grzechy, tak samo jak za grzechy ludu.
###### **Hbr 5,4**
 A nikt sam sobie tego zaszczytu nie powierza, lecz zostaje powołany przez Boga, tak jak Aharon.
###### **Hbr 5,5**
 A zatem i Mesjasz nie otoczył chwałą sam siebie, aby się stać kohenem gadolem, lecz zrobił to Ten, który rzekł do Niego: "Jesteś moim Synem, dziś stałem się Twym Ojcem".
###### **Hbr 5,6**
 A w innym jeszcze miejscu mówi: "Jesteś kohenem na wieki, aby Cię przyrównywano do Malki-Cedeka".
###### **Hbr 5,7**
 Podczas swego życia na ziemi zanosił Jeszua modlitwy i prośby, wołając głośno i wylewając łzy, do Tego, który miał moc wyzwolić Go od śmierci. I został wysłuchany ze względu na swą pobożność.
###### **Hbr 5,8**
 Mimo że był Synem, przez swe cierpienia nauczył się posłuszeństwa.
###### **Hbr 5,9**
 A gdy został doprowadzony do celu, stał się źródłem wiecznego wyzwolenia dla wszystkich, którzy są Mu posłuszni,
###### **Hbr 5,10**
 ponieważ został przez Boga ogłoszony kohenem gadolem, aby Go przyrównywano do Malki-Cedeka.
###### **Hbr 5,11**
 Wiele mamy do powiedzenia na ten temat, ale trudno to wyłuszczać, bo otępieliście w rozumieniu.
###### **Hbr 5,12**
 Choć bowiem w tym czasie powinniście już być nauczycielami, potrzebujecie, żeby was ktoś znowu nauczał o najbardziej podstawowych zasadach ze Słowa Bożego! Potrzebne wam mleko, a nie pokarm stały!
###### **Hbr 5,13**
 Każdy, kto musi nadal pić mleko, jest wciąż niemowlęciem, bez doświadczenia w stosowaniu Słowa o sprawiedliwości.
###### **Hbr 5,14**
 Lecz pokarm stały jest dla dojrzałych, dla tych, których narządy dzięki nieustannej praktyce zostały wyszkolone w odróżnianiu dobra od zła.
# Hbr 5 TRO
###### **Hbr 5,6**
 **καθως** *kathōs* Tak, jak [[G2531]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **ετερω** *heterō* innym [[G2087]] WTA-DSM **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **συ** *sy* Ty [[G4771]] WTP-2NS **ιερευς** *hiereus* kapłan [[G2409]] [[N-NSM]] **εις** *eis* na [[G1519]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **αιωνα** *aiōna* wiek [[G165]] [[N-ASM]] **κατα** *kata* według [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **ταξιν** *taksin* porządku [[G5010]] WTN-ASF **μελχισεδεκ** *melchisedek* Melchisedeka – [król sprawiedliwości] [[G3198]] [[N-PRI]]
###### **Hbr 5,1**
 **πας** *pas* Każdy [[G3956]] [[A-NSM]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **αρχιερευς** *archiereus* arcykapłan [[G749]] [[N-NSM]] **εξ** *eks* z [[G1537]] [[PREP]] **ανθρωπων** *anthrōpōn* ludzi [[G444]] WTN-GPM **λαμβανομενος** *lambanomenos* który jest brany [[G2983]] [[V-PPP-NSM]] **υπερ** *hyper* za [[G5228]] [[PREP]] **ανθρωπων** *anthrōpōn* ludzi [[G444]] WTN-GPM **καθισταται** *kathistatai* jest ustanawiany [[G2525]] WTV-PPI-3S **τα** *ta* [[G3588]] WTT-APN **προς** *pros* względem [[G4314]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **θεον** *theon* Boga [[G2316]] [[N-ASM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **προσφερη** *prosferē* przynosiłby – ofiarowywałby [[G4374]] WTV-PAS-3S **δωρα** *dōra* dary – dary ofiarne [[G1435]] WTN-APN **τε** *te* zarówno – także [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **θυσιας** *thysias* ofiary [[G2378]] WTN-APF **υπερ** *hyper* za [[G5228]] [[PREP]] **αμαρτιων** *hamartiōn* grzechy [[G266]] WTN-GPF
###### **Hbr 5,2**
 **μετριοπαθειν** *metriopathein* zdolny współczuć – w odpowiedniej mierze współczuć [[G3356]] WTV-PAN **δυναμενος** *dynamenos* mogący [[G1410]] WTV-PNP-NSM **τοις** *tois* [[G3588]] WTT-DPM **αγνοουσιν** *agnoousin* nie rozumiejącym – nie rozeznającym się [[G50]] WTV-PAP-DPM **και** *kai* i [[G2532]] [[CONJ]] **πλανωμενοις** *planōmenois* dającym się zwieść – dającym się wprowadzić w błąd [[G4105]] WTV-PPP-DPM **επει** *epei* skoro – jako, że [[G1893]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **αυτος** *autos* on [[G846]] WTP-NSM **περικειται** *perikeitai* jest otoczony – jest objęty [[G4029]] WTV-PNI-3S **ασθενειαν** *astheneian* słabością – bezsiłą [[G769]] WTN-ASF
###### **Hbr 5,3**
 **και** *kai* i [[G2532]] [[CONJ]] **δια** *dia* z powodu [[G1223]] [[PREP]] **ταυτην** *tautēn* tego [[G3778]] WTD-ASF **οφειλει** *ofeilei* powinien [[G3784]] WTV-PAI-3S **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **περι** *peri* za [[G4012]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **λαου** *laou* lud [[G2992]] [[N-GSM]] **ουτως** *houtōs* tak [[G3779]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **περι** *peri* za [[G4012]] [[PREP]] **εαυτου** *heautou* siebie [[G1438]] WTF-3GSM **προσφερειν** *prosferein* przynosić – składać ofiarę [[G4374]] WTV-PAN **υπερ** *hyper* za [[G5228]] [[PREP]] **αμαρτιων** *hamartiōn* grzechy [[G266]] WTN-GPF
###### **Hbr 5,4**
 **και** *kai* i [[G2532]] [[CONJ]] **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **εαυτω** *heautō* (dla) siebie samego [[G1438]] WTF-3DSM **τις** *tis* ktoś [[G5100]] WTX-NSM **λαμβανει** *lambanei* bierze – przyjmuje [[G2983]] WTV-PAI-3S **την** *tēn* [[G3588]] WTT-ASF **τιμην** *timēn* szacunek – zaszczyt [[G5092]] WTN-ASF **αλλα** *alla* ale [[G235]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **καλουμενος** *kaloumenos* który jest wzywany [[G2564]] [[V-PPP-NSM]] **υπο** *hypo* przez [[G5259]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **καθαπερ** *kathaper* tak, jak [[G2509]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **ααρων** *aarōn* Aaron – [wywyższony] [[G2]] [[N-PRI]]
###### **Hbr 5,5**
 **ουτως** *houtōs* Tak [[G3779]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **εαυτον** *heauton* sobie samemu [[G1438]] WTF-3ASM **εδοξασεν** *edoksasen* oddał chwałę [[G1392]] [[V-AAI-3S]] **γενηθηναι** *genēthēnai* (by) stać się [[G1096]] WTV-AON **αρχιερεα** *archierea* arcykapłanem [[G749]] [[N-ASM]] **αλλ** *all* ale [[G235]] [[CONJ]] **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **λαλησας** *lalēsas* który powiedział [[G2980]] WTV-AAP-NSM **προς** *pros* do [[G4314]] [[PREP]] **αυτον** *auton* Niego [[G846]] WTP-ASM **υιος** *hyios* Syn [[G5207]] [[N-NSM]] **μου** *mou* mój [[G3450]] WTP-1GS **ει** *ei* jesteś [[G1488]] WTV-PXI-2S **συ** *sy* Ty [[G4771]] WTP-2NS **εγω** *egō* Ja [[G1473]] WTP-1NS **σημερον** *sēmeron* dzisiaj [[G4594]] [[ADV]] **γεγεννηκα** *gegennēka* zrodziłem [[G1080]] WTV-RAI-1S **σε** *se* Cię [[G4571]] WTP-2AS
###### **Hbr 5,7**
 **ος** *hos* Ten [[G3739]] WTR-NSM **εν** *en* w [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **ημεραις** *hēmerais* dniach [[G2250]] WTN-DPF **της** *tēs* [[G3588]] [[T-GSF]] **σαρκος** *sarkos* ciała [[G4561]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **δεησεις** *deēseis* błagania – prośby [[G1162]] WTN-APF **τε** *te* zarówno – także [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **ικετηριας** *hiketērias* usilne prośby [[G2428]] WTN-APF **προς** *pros* do [[G4314]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **δυναμενον** *dynamenon* mogącego [[G1410]] WTV-PNP-ASM **σωζειν** *sōzein* ratować – zbawiać [[G4982]] WTV-PAN **αυτον** *auton* Go [[G846]] WTP-ASM **εκ** *ek* od [[G1537]] [[PREP]] **θανατου** *thanatou* śmierci [[G2288]] [[N-GSM]] **μετα** *meta* z [[G3326]] [[PREP]] **κραυγης** *kraugēs* krzyku – wrzasku [[G2906]] [[N-GSF]] **ισχυρας** *ischyras* mocnego – silnego [[G2478]] WTA-GSF **και** *kai* i [[G2532]] [[CONJ]] **δακρυων** *dakryōn* łzy [[G1144]] WTN-GPN **προσενεγκας** *prosenegkas* przyniósłszy [[G4374]] WTV-AAP-NSM **και** *kai* i [[G2532]] [[CONJ]] **εισακουσθεις** *eisakoustheis* zostawszy wysłuchanym [[G1522]] WTV-APP-NSM **απο** *apo* za [[G575]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **ευλαβειας** *eulabeias* pobożność – oddawaną cześć [[G2124]] [[N-GSF]]
###### **Hbr 5,8**
 **καιπερ** *kaiper* chociaż [[G2539]] [[CONJ]] **ων** *ōn* będąc [[G5607]] [[V-PXP-NSM]] **υιος** *hyios* Syn [[G5207]] [[N-NSM]] **εμαθεν** *emathen* nauczył się [[G3129]] WTV-2AAI-3S **αφ** *af* przez [[G575]] [[PREP]] **ων** *hōn* (te) które [[G3739]] WTR-GPN **επαθεν** *epathen* wycierpiał [[G3958]] WTV-2AAI-3S **την** *tēn* [[G3588]] WTT-ASF **υπακοην** *hypakoēn* posłuszeństwo [[G5218]] WTN-ASF
###### **Hbr 5,9**
 **και** *kai* i [[G2532]] [[CONJ]] **τελειωθεις** *teleiōtheis* który został uczyniony doskonałym – który został uczyniony dojrzałym [[G5048]] WTV-APP-NSM **εγενετο** *egeneto* stał się [[G1096]] WTV-2ADI-3S **τοις** *tois* [[G3588]] WTT-DPM **υπακουουσιν** *hypakouousin* którzy są posłuszni [[G5219]] WTV-PAP-DPM **αυτω** *autō* Mu [[G846]] WTP-DSM **πασιν** *pasin* (dla) wszystkich [[G3956]] WTA-DPM **αιτιος** *aitios* przyczyna – sprawca [[G159]] [[A-NSM]] **σωτηριας** *sōtērias* zbawienia – wyzwolenia [[G4991]] [[N-GSF]] **αιωνιου** *aiōniou* wiecznego [[G166]] WTA-GSF
###### **Hbr 5,10**
 **προσαγορευθεις** *prosagoreutheis* który został nazwany [[G4316]] WTV-APP-NSM **υπο** *hypo* przez [[G5259]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **αρχιερευς** *archiereus* arcykapłan [[G749]] [[N-NSM]] **κατα** *kata* według [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **ταξιν** *taksin* porządku [[G5010]] WTN-ASF **μελχισεδεκ** *melchisedek* Melchisedeka – [król sprawiedliwości] [[G3198]] [[N-PRI]]
###### **Hbr 5,11**
 **περι** *peri* O [[G4012]] [[PREP]] **ου** *hou* czym [[G3739]] WTR-GSM **πολυς** *polys* liczne – wiele [[G4183]] [[A-NSM]] **ημιν** *hēmin* nam [[G2254]] WTP-1DP **ο** *ho* [[G3588]] [[T-NSM]] **λογος** *logos* słowo [[G3056]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **δυσερμηνευτος** *dysermēneutos* trudne do wyjaśnienia – trudne do zrozumienia [[G1421]] [[A-NSM]] **λεγειν** *legein* (by) mówić [[G3004]] WTV-PAN **επει** *epei* skoro – jako, że [[G1893]] [[CONJ]] **νωθροι** *nōthroi* ociężali – tępi [[G3576]] WTA-NPM **γεγονατε** *gegonate* staliście się [[G1096]] WTV-2RAI-2P **ταις** *tais* (w) [[G3588]] WTT-DPF **ακοαις** *akoais* słuchaniu [[G189]] WTN-DPF
###### **Hbr 5,12**
 **και** *kai* i [[G2532]] [[CONJ]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **οφειλοντες** *ofeilontes* którzy są zobowiązani – którzy są winnymi [[G3784]] WTV-PAP-NPM **ειναι** *einai* (by) być [[G1511]] WTV-PXN **διδασκαλοι** *didaskaloi* nauczyciele [[G1320]] WTN-NPM **δια** *dia* przez [[G1223]] [[PREP]] **τον** *ton* (ten) [[G3588]] [[T-ASM]] **χρονον** *chronon* czas [[G5550]] [[N-ASM]] **παλιν** *palin* znów [[G3825]] [[ADV]] **χρειαν** *chreian* potrzebę [[G5532]] WTN-ASF **εχετε** *echete* macie [[G2192]] WTV-PAI-2P **του** *tou* (by) [[G3588]] WTT-GSM **διδασκειν** *didaskein* nauczać [[G1321]] WTV-PAN **υμας** *hymas* was [[G5209]] WTP-2AP **τινα** *tina* ktoś [[G5101]] WTI-NPN **τα** *ta* [[G3588]] WTT-NPN **στοιχεια** *stoicheia* elementy [[G4747]] WTN-NPN **της** *tēs* [[G3588]] [[T-GSF]] **αρχης** *archēs* początku [[G746]] [[N-GSF]] **των** *tōn* [[G3588]] WTT-GPN **λογιων** *logiōn* słów – wypowiedzi [[G3051]] WTN-GPN **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **γεγονατε** *gegonate* staliście się [[G1096]] WTV-2RAI-2P **χρειαν** *chreian* potrzebę [[G5532]] WTN-ASF **εχοντες** *echontes* mający [[G2192]] WTV-PAP-NPM **γαλακτος** *galaktos* mleka [[G1051]] [[N-GSN]] **και** *kai* a [[G2532]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **στερεας** *stereas* stałego – solidnego [[G4731]] WTA-GSF **τροφης** *trofēs* pożywienia – pokarmu [[G5160]] [[N-GSF]]
###### **Hbr 5,13**
 **πας** *pas* Każdy [[G3956]] [[A-NSM]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **μετεχων** *metechōn* uczestniczący [[G3348]] [[V-PAP-NSM]] **γαλακτος** *galaktos* (w) mleku [[G1051]] [[N-GSN]] **απειρος** *apeiros* niedoświadczony – nieumiejętny [[G552]] [[A-NSM]] **λογου** *logou* (w) słowie [[G3056]] [[N-GSM]] **δικαιοσυνης** *dikaiosynēs* sprawiedliwości [[G1343]] [[N-GSF]] **νηπιος** *nēpios* niemowlę [[G3516]] [[A-NSM]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S
###### **Hbr 5,14**
 **τελειων** *teleiōn* dojrzali – doskonali [[G5046]] WTA-GPM **δε** *de* zaś [[G1161]] [[CONJ]] **εστιν** *estin* jest (są) [[G2076]] WTV-PXI-3S **η** *hē* [[G3588]] [[T-NSF]] **στερεα** *sterea* stałe – solidne [[G4731]] WTA-NSF **τροφη** *trofē* pożywienie – pokarm [[G5160]] [[N-NSF]] **των** *tōn* [[G3588]] WTT-GPM **δια** *dia* przez [[G1223]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **εξιν** *heksin* praktykę – nawyk [[G1838]] WTN-ASF **τα** *ta* [[G3588]] WTT-APN **αισθητηρια** *aisthētēria* zmysły – władze poznawcze [[G145]] WTN-APN **γεγυμνασμενα** *gegymnasmena* które są wyćwiczone [[G1128]] WTV-RPP-APN **εχοντων** *echontōn* mający [[G2192]] WTV-PAP-GPM **προς** *pros* do [[G4314]] [[PREP]] **διακρισιν** *diakrisin* rozróżnienia – rozsądzenia [[G1253]] WTN-ASF **καλου** *kalou* dobre – piękne [[G2570]] [[A-GSN]] **τε** *te* zarówno – także [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **κακου** *kakou* złe [[G2556]] [[A-GSN]]
