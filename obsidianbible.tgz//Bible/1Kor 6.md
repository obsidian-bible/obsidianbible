# 1Kor 6 BT5
###### **1Kor 6,1**
 Czy odważy się ktoś z was, gdy zdarzy się nieporozumienie z drugim, szukać sprawiedliwości u niesprawiedliwych zamiast u świętych?
###### **1Kor 6,2**
 Czyż nie wiecie, że święci będą sędziami tego świata? A jeśli świat będzie przez was sądzony, to czy nie jesteście godni wyrokować w tak błahych sprawach?
###### **1Kor 6,3**
 Czyż nie wiecie, że będziemy sądzili także aniołów? O ileż przeto więcej sprawy doczesne!
###### **1Kor 6,4**
 Wy zaś, gdy macie sprawy doczesne do rozstrzygnięcia, zwracacie się do ludzi za nic uważanych w Kościele!
###### **1Kor 6,5**
 Mówię to, aby was zawstydzić. Bo czyż nie znajdzie się wśród was ktoś na tyle mądry, by mógł rozstrzygać spory między swymi braćmi?
###### **1Kor 6,6**
 A tymczasem brat oskarża brata, i to przed niewierzącymi.
###### **1Kor 6,7**
 Już samo to jest godne potępienia, że w ogóle zdarzają się wśród was sądowe sprawy. Czemuż nie znosicie raczej niesprawiedliwości? Czemuż nie ponosicie raczej szkody?
###### **1Kor 6,8**
 Tymczasem wy dopuszczacie się niesprawiedliwości i wyrządzacie szkody, i to właśnie braciom.
###### **1Kor 6,9**
  Czyż nie wiecie, że niesprawiedliwi nie posiądą królestwa Bożego? Nie łudźcie się! Ani rozpustnicy, ani bałwochwalcy, ani cudzołożnicy, ani rozwiąźli, ani mężczyźni współżyjący ze sobą,
###### **1Kor 6,10**
 ani złodzieje, ani chciwi, ani pijacy, ani oszczercy, ani zdziercy nie odziedziczą królestwa Bożego.
###### **1Kor 6,11**
 A takimi byli niektórzy z was. Lecz zostaliście obmyci, uświęceni i usprawiedliwieni w imię Pana naszego, Jezusa Chrystusa i przez Ducha Boga naszego.
###### **1Kor 6,12**
 Wszystko mi wolno, ale nie wszystko przynosi korzyść. Wszystko mi wolno, ale ja niczemu nie oddam się w niewolę.
###### **1Kor 6,13**
 Pokarm [jest] dla żołądka, a żołądek dla pokarmu. Bóg zaś unicestwi jedno i drugie. Ale ciało nie jest dla rozpusty, lecz dla Pana, a Pan dla ciała.
###### **1Kor 6,14**
 Bóg zaś i Pana wskrzesił, i nas również swą mocą wskrzesi.
###### **1Kor 6,15**
 Czyż nie wiecie, że ciała wasze są członkami Chrystusa? Czyż wziąwszy członki Chrystusa, będę je czynił członkami nierządnicy? Przenigdy!
###### **1Kor 6,16**
 Albo czyż nie wiecie, że ten, kto łączy się z nierządnicą, stanowi z nią jedno ciało? Będą bowiem – jak jest powiedziane – dwoje jednym ciałem.
###### **1Kor 6,17**
 Ten zaś, kto się łączy z Panem, jest z Nim jednym duchem.
###### **1Kor 6,18**
 Strzeżcie się rozpusty! Bo czyż jakikolwiek grzech popełniony przez człowieka jest poza ciałem? Lecz [ja wam mówię,] kto grzeszy rozpustą, przeciwko własnemu ciału grzeszy.
###### **1Kor 6,19**
 Czyż nie wiecie, że ciało wasze jest przybytkiem Ducha Świętego, który w was jest, a którego macie od Boga, i że już nie należycie do samych siebie?
###### **1Kor 6,20**
 Za [wielką] bowiem cenę zostaliście nabyci. Chwalcie więc Boga w waszym ciele!
# 1Kor 6 PAU
###### **1Kor 6,1**
 Czy ktoś z was, kiedy ma sprawę sądową z drugim, odważy się procesować przed niesprawiedliwymi zamiast przed świętymi?
###### **1Kor 6,2**
 Czy nie wiecie, że święci będą sądzić świat? Jeśli więc wy osądzacie świat, to czyż nie możecie wyrokować w bardziej błahych sprawach?
###### **1Kor 6,3**
 Nie wiecie, że będziemy sądzić aniołów? A cóż dopiero zwykłe sprawy codziennego życia!
###### **1Kor 6,4**
 Sprawy z codziennego życia, o ile takie macie, oddawajcie pod sąd pokornych w Kościele.
###### **1Kor 6,5**
 Mówię to, abyście się zawstydzili. Czyż nie ma wśród was nikogo roztropnego, kto mógłby rozsądzić sprawę między braćmi?
###### **1Kor 6,6**
 Tymczasem brat procesuje się z bratem, i to przed niewierzącymi!
###### **1Kor 6,7**
 Już samo to, że procesujecie się między sobą, jest poniżające! Dlaczego raczej nie znosicie niesprawiedliwości? Dlaczego raczej nie jesteście gotowi doznawać krzywdy?
###### **1Kor 6,8**
 To wy właśnie dopuszczacie się niesprawiedliwości i wyrządzacie krzywdę, i to braciom!
###### **1Kor 6,9**
 Czy nie wiecie, że niesprawiedliwi nie otrzymają królestwa Bożego? Nie łudźcie się! Ani rozpustnicy, ani bałwochwalcy, ani cudzołożnicy, ani rozwiąźli, ani mężczyźni współżyjący ze sobą,
###### **1Kor 6,10**
 ani złodzieje, ani zachłanni, ani pijacy, ani oszczercy, ani zdziercy nie otrzymają królestwa Bożego.
###### **1Kor 6,11**
 Takimi byli niektórzy spośród was, ale zostaliście obmyci, uświęceni, uznani za sprawiedliwych w imię Pana Jezusa Chrystusa i przez Ducha naszego Boga.
###### **1Kor 6,12**
 Wszystko mi wolno, ale nie wszystko jest pożyteczne. Wszystko mi wolno, ale ja niczemu nie poddam się w niewolę.
###### **1Kor 6,13**
 Pokarm jest dla żołądka, a żołądek dla pokarmu. Bóg natomiast unicestwi i jedno, i drugie. Ciało nie jest dla rozpusty, ale dla Pana, a Pan dla ciała.
###### **1Kor 6,14**
 Bóg, który wskrzesił Pana, i nas wskrzesi swoją mocą.
###### **1Kor 6,15**
 Czyż nie wiecie, że wasze ciała są częścią Ciała Chrystusa? Czy wezmę część Ciała Chrystusa i zrobię ją częścią ciała nierządnicy? Przenigdy!
###### **1Kor 6,16**
 Czy nie wiecie, że ten, który łączy się z nierządnicą, jest z nią jednym ciałem? Będą bowiem - jak jest powiedziane - dwoje jednym ciałem.
###### **1Kor 6,17**
 Ten, kto łączy się z Panem, jest z Nim jednym duchem.
###### **1Kor 6,18**
 Uciekajcie przed rozpustą! Każdy inny grzech, który popełnia człowiek, jest poza ciałem, ale kto oddaje się rozpuście, grzeszy przeciw własnemu ciału.
###### **1Kor 6,19**
 Czy nie wiecie, że wasze ciało jest świątynią Ducha Świętego, który jest w was? Macie Go od Boga i nie należycie już do siebie.
###### **1Kor 6,20**
 Bóg przecież wykupił was za wielką cenę. Oddajcie więc Bogu chwałę w waszym ciele!
# 1Kor 6 BP
###### **1Kor 6,1**
 Czy naprawdę odważyłby się ktoś z was zwrócić w sprawie spornej po rozstrzygnięcie do niesprawiedliwych zamiast do świętych?
###### **1Kor 6,2**
 Czy nie wiecie, że święci będą sądzić świat? Jeżeli zaś wy będziecie sądzić świat, to czy nie zasługujecie na to, aby wyrokować w tak błahych sprawach?
###### **1Kor 6,3**
 Czy nie wiecie, że będziemy sądzić nawet aniołów? Tym bardziej więc możemy rozstrzygać o sprawach życia codziennego.
###### **1Kor 6,4**
 Dlaczego więc do wydawania wyroków o tych sprawach wybieracie na sędziów tych, którzy w Kościele nic nie znaczą?
###### **1Kor 6,5**
 Mówię to, aby was zawstydzić. Czy nie ma wśród was ani jednego mądrego, który mógłby rozstrzygać spory wśród braci?
###### **1Kor 6,6**
 Jak to wygląda, że brat z bratem się procesuje i to jeszcze przed niewierzącymi?
###### **1Kor 6,7**
 Już sam fakt, że wnosicie przeciwko sobie skargi do sądu, świadczy o was niekorzytnie. Dlaczego raczej nie znosicie cierpliwie krzywd? Dlaczego raczej nie zapominacie o wyrządzonych wam szkodach?
###### **1Kor 6,8**
 Lecz wy sami wyrządzacie krzywdy oraz dopuszczacie się grabieży i to jeszcze na braciach.
###### **1Kor 6,9**
 Czy nie wiecie, że niesprawiedliwi nie osiągną królestwa Bożego? Nie łudźcie się! Królestwa Bożego nie osiągną rozpustnicy, bałwochwalcy i cudzołożnicy, ludzie nie umiejący się oprzeć rozkoszom i mężczyźni współżyjący ze sobą,
###### **1Kor 6,10**
 złodzieje, chciwcy oraz pijacy, oszczercy i rabusie.
###### **1Kor 6,11**
 Niektórzy z was takimi wprawdzie byli, lecz już zostaliście obmyci, uświęceni i usprawiedliwieni w imię Pana Jezusa Chrystusa i Ducha Boga naszego.
###### **1Kor 6,12**
 Wszystko mi wolno, ale nie wszystko przynosi korzyść. Wszystko mi wolno, ale ja niczemu nie ulegnę.
###### **1Kor 6,13**
 Pokarm przeznaczony jest dla żołądka, a żołądek dla pokarmu. Bóg zaś unicestwi zarówno jedno, jak i drugie. Natomiast ciało nie jest dla rozpusty, ale dla Pana, a Pan dla ciała.
###### **1Kor 6,14**
 Bóg zaś swoją mocą wskrzesił nasze ciała do życia, tak jak wskrzesił Pana.
###### **1Kor 6,15**
 Czy nie wiecie, że wasze ciała są członkami Chrystusa? Czy wezmę członki Chrystusa i uczynię je członkami nierządnicy? Przenigdy!
###### **1Kor 6,16**
 Albo czy nie wiecie, że ten, kto łączy się z nierządnicą, tworzy z nią jedno ciało? Pismo Święte powiada bowiem: "Będą dwoje w jednym ciele".
###### **1Kor 6,17**
 Kto natomiast łączy się z Panem, staje się z Nim jednym duchem.
###### **1Kor 6,18**
 Unikajcie rozpusty! Każdy inny grzech, jakiego dopuszcza się człowiek, nie dotyczy ciała, ale w wypadku rozpusty człowiek grzeszy przeciw własnemu ciału.
###### **1Kor 6,19**
 Czyż nie wiecie, że ciała wasze są świątynią Świętego Ducha, który w was przebywa? Otrzymaliście Go od Boga i nie należycie do siebie.
###### **1Kor 6,20**
 Bóg nabył was na własność za wielką cenę. Niech więc ciała wasze chwalą Boga.
# 1Kor 6 BR
###### **1Kor 6,1**
 Czy odważy się ktoś z was, gdy zdarzy się nieporozumienie z drugim, szukać sprawiedliwości u niesprawiedliwych, zamiast u świętych?
###### **1Kor 6,2**
 Czyż nie wiecie, że święci będą sędziami tego świata? A jeśli świat będzie przez was sądzony, to czyż nie jesteście godni wyrokować w tak błahych sprawach?
###### **1Kor 6,3**
 Czyż nie wiecie, że będziemy sądzili także aniołów? O ileż przeto więcej sprawy doczesne!
###### **1Kor 6,4**
 Wy zaś, gdy macie sprawy doczesne do rozstrzygnięcia, zwracacie się do ludzi za nic uważanych w Kościele!
###### **1Kor 6,5**
 Mówię to, aby was zawstydzić. Bo czyż nie znajdzie się wśród was ktoś na tyle mądry, by mógł rozstrzygnąć spory między swymi braćmi?
###### **1Kor 6,6**
 A tymczasem brat oskarża brata, i to przed niewierzącymi.
###### **1Kor 6,7**
 Już samo to jest godne potępienia, że w ogóle zdarzają się wśród was sprawy sądowe. Czemuż nie znosicie raczej niesprawiedliwości? Czemuż nie ponosicie raczej szkody?
###### **1Kor 6,8**
 Tymczasem wy dopuszczacie się niesprawiedliwości i szkody wyrządzacie, i to właśnie braciom.
###### **1Kor 6,9**
 Czyż nie wiecie, że niesprawiedliwi nie posiądą królestwa Bożego? Nie łudźcie się! Ani rozpustnicy, ani bałwochwalcy, ani cudzołożnicy, ani rozwięźli, ani mężczyźni współżyjący ze sobą,
###### **1Kor 6,10**
 ani złodzieje ani chciwi, ani pijacy, ani oszczercy, ani zdziercy nie odziedziczą królestwa Bożego.
###### **1Kor 6,11**
 A takimi byli niektórzy z was. Lecz zostaliście obmyci, uświęceni i usprawiedliwieni w imię Pana [naszego] Jezusa Chrystusa i przez Ducha Boga naszego.
###### **1Kor 6,12**
 Wszystko mi wolno, ale nie wszystko przynosi korzyść. Wszystko mi wolno, ale ja niczemu nie oddam się w niewolę.
###### **1Kor 6,13**
 Pokarm dla żołądka, a żołądek dla pokarmu. Bóg zaś unicestwi jedno i drugie. Ciało nie jest dla rozpusty, ale dla Pana, a Pan dla ciała.
###### **1Kor 6,14**
 Bóg zaś i Pana wskrzesił, i nas również swą mocą przywroci do życia.
###### **1Kor 6,15**
 Czyż nie wiecie, że ciała wasze są członkami Chrystusa? Czyż wziąwszy członki Chrystusa będę je czynił członkami nierządnicy? Przenigdy!
###### **1Kor 6,16**
 Albo czyż nie wiecie, że ten, kto łączy się z nierządnicą, stanowi z nią jedno ciało? Będą bowiem - jak jest powiedziane - dwoje jednym ciałem.
###### **1Kor 6,17**
 Ten zaś, kto się łączy z Panem, jest z Nim jednym duchem.
###### **1Kor 6,18**
 Strzeżcie się rozpusty! Bo czyż jakikolwiek grzech popełniony przez człowieka jest poza ciałem? Lecz [ja wam mówię, że] kto grzeszy rozpustą, przeciwko własnemu ciału grzeszy.
###### **1Kor 6,19**
 Czyż nie wiecie, że ciało wasze jest przybytkiem Ducha Świętego, który w was jest, a którego macie od Boga, i że już nie należycie do samych siebie?
###### **1Kor 6,20**
 Za [wielką] bowiem cenę zostaliście nabyci. Chwalcie więc Boga w waszym ciele!
# 1Kor 6 WUJ
###### **1Kor 6,1**
 Śmie który z was mając sprawę przeciw drugiemu sądzić się przed niesprawiedliwemi, a nie przed świętemi?
###### **1Kor 6,2**
 Azaś nie wiecie, iż święci będą ten świat sądzić? A jeśli od was świat sądzon będzie: nie godniżeście sądzić rzeczy namniejszych?
###### **1Kor 6,3**
 Nie wiecie, iż anioły sądzić będziemy? jako daleko więcej rzeczy świeckie?
###### **1Kor 6,4**
 Jeśli tedy będziecie mieć sądy świeckie, którzy są wzgardzeni w kościele, tych wysadźcie na sądzenie.
###### **1Kor 6,5**
 Mówię ku wstydowi waszemu. Także niemasz między wami mądrego żadnego, który by mógł rozsądzić między bratem swoim?
###### **1Kor 6,6**
 Ale się brat z bratem prawuje: i to przed niewiernemi?
###### **1Kor 6,7**
 Jużci koniecznie jest w was występek, że sądy między sobą miewacie. Czemu raczej krzywdy nie podejmujecie? czemu raczej szkody nie cierpicie?
###### **1Kor 6,8**
 Ale wy krzywdę czynicie i szkodzicie, a jeszcze bracią.
###### **1Kor 6,9**
 Aza nie wiecie, iż niesprawiedliwi nie osięgą królestwa Bożego? Nie mylcie się, ani porubnicy, ani bałwanom służący, ani cudzołożnicy, ani psotliwi, ani Sodomczycy,
###### **1Kor 6,10**
 Ani złodzieje, ani łakomi, ani pijanice, ani złorzeczący, ani drapieżce nie posięgą królestwa Bożego.
###### **1Kor 6,11**
 I tymeście niektórzy byli: aleścię omyci, aleście poświęceni, aleście usprawiedliwieni w imię Pana naszego Jezu Chrysta, i w Duchu Boga naszego.
###### **1Kor 6,12**
 Wszystko mi się godzi, ale nie wszystko pożyteczno. Wszystko mi się godzi, ale się ja w moc niczemu nie poddam.
###### **1Kor 6,13**
 Pokarm brzuchowi, a brzuch pokarmowi: lecz Bóg i ten i te zepsuje: A ciało nie porubstwu, ale Panu, a Pan ciału.
###### **1Kor 6,14**
 A Bóg i Pana wzbudził, i nas wzbudzi przez moc swoję.
###### **1Kor 6,15**
 Nie wiecie, iż ciała wasze są członkami Chrystusowemi? wziąwszy tedy członki Chrystusowe, uczynię je członkami nierządnice? Nie daj tego Boże.
###### **1Kor 6,16**
 Abo nie wiecie, iż ten co się złącza z nierządnicą, staje się jednem ciałem? Abowiem (mówi) będą dwa w jednem ciele.
###### **1Kor 6,17**
 A kto się złącza z Panem, jednym duchem jest.
###### **1Kor 6,18**
 Uciekajcie przed porubstwem. Wszelki grzech, któryby człowiek czynił, nie jest na ciele: ale kto porubstwo płodzi, przeciwko ciału swemu grzeszy.
###### **1Kor 6,19**
 Aza nie wiecie, iż członki wasze są kościołem Ducha świętego który w was jest, którego macie od Boga, a nie jesteście swoi?
###### **1Kor 6,20**
 Abowiemeście kupieni zapłatą wielką. Chwąlcież i noście Boga w ciele waszem.
# 1Kor 6 STERN
###### **1Kor 6,1**
 Jeśli ktoś z was ma skargę na drugiego, jak możecie iść przed pogańskich sędziów, a nie przed lud Boży?
###### **1Kor 6,2**
 Nie wiecie, że lud Boży będzie sądził wszechświat? Skoro macie sądzić wszechświat, to tak błahych spraw nie potraficie osądzić?
###### **1Kor 6,3**
 Czyż nie wiecie, że będziemy sądzić aniołów - że nie wspomnę już o sprawach codziennego życia?
###### **1Kor 6,4**
 Jeśli zatem trzeba rozsądzić sprawy codziennego życia, czemu powierzacie to ludziom, którzy nie mają we Wspólnocie Mesjanicznej żadnego znaczenia?
###### **1Kor 6,5**
 Wstydźcie się, powiadam! Czy to możliwe, żeby nie było wśród was żadnego na tyle mądrego, aby umiał rozstrzygnąć spór między braćmi?
###### **1Kor 6,6**
 A tu brat wnosi sprawę przeciw bratu, i to przed niewierzącymi!
###### **1Kor 6,7**
 W istocie już to, że wnosicie sprawy przeciwko sobie, to wasza porażka. Czemu raczej nie doznać krzywdy? Czemu raczej nie zostać oszukanym?
###### **1Kor 6,8**
 Tymczasem wy sami krzywdzicie i oszukujecie, i to własnych braci!
###### **1Kor 6,9**
 To nie wiecie, że niesprawiedliwi nie będą mieć udziału w Królestwie Bożym? Nie łudźcie się - ludzie, którzy współżyją przed małżeństwem, którzy czczą bałwany, którzy już po ślubie współżyją z kimś, kogo nie poślubili, którzy czynnie lub biernie uprawiają homoseksualizm,
###### **1Kor 6,10**
 którzy kradną, są chciwi, upijają się, lżą, rabują - nikt z nich nie będzie miał udziału w Królestwie Bożym.
###### **1Kor 6,11**
 Tak niektórzy z was postępowali. Ale oczyściliście się, zostaliście zastrzeżeni dla Boga, uznano was za sprawiedliwych poprzez moc Pana Jeszui Mesjasza i Ducha naszego Boga.
###### **1Kor 6,12**
 Mówisz: "Wszystko mi wolno"? Być może, ale nie wszystko jest korzystne. "Wszystko mi wolno"? Być może, ale co do mnie, nie pozwolę, aby cokolwiek mną zawładnęło.
###### **1Kor 6,13**
 "Pokarm jest dla żołądka, a żołądek dla pokarmu"? Być może, ale Bóg położy kres im obu. Jednakże ciało nie jest dla rozwiązłości, tylko dla Pana, Pan zaś dla ciała.
###### **1Kor 6,14**
 Bóg wskrzesił Pana i wskrzesi też nas swą mocą.
###### **1Kor 6,15**
 To nie wiecie, że wasze ciała są członkami Mesjasza? Czy zatem mam wziąć członki Mesjasza i uczynić je członkami prostytutki? Nigdy w życiu!
###### **1Kor 6,16**
 Czyż nie wiecie, że człowiek, który łączy się z prostytutką, fizycznie staje się jedno z nią? Bo Tanach mówi: "Tych dwoje będzie jednym ciałem";
###### **1Kor 6,17**
 ale człowiek, który łączy się z Panem, jest jednym duchem.
###### **1Kor 6,18**
 Strzeżcie się rozwiązłości! Każdy inny grzech, jaki człowiek popełnia, jest na zewnątrz ciała, ale wszetecznik grzeszy przeciwko własnemu ciału.
###### **1Kor 6,19**
 Czy nie wiecie, że wasze ciało jest świątynią dla Ruach Ha-Kodesz, który w was mieszka, któregoście otrzymali od Boga? Faktem jest, że nie należycie do siebie;
###### **1Kor 6,20**
 bo zostaliście kupieni za pewną cenę. Więc używajcie swych ciał, aby uwielbić Boga.
# 1Kor 6 TRO
###### **1Kor 6,1**
 **τολμα** *tolma* Śmie – Odważa się [[G5111]] WTV-PAI-3S **τις** *tis* ktoś [[G5100]] WTX-NSM **υμων** *hymōn* (z) was [[G5216]] WTP-2GP **πραγμα** *pragma* sprawę [[G4229]] WTN-ASN **εχων** *echōn* mając [[G2192]] [[V-PAP-NSM]] **προς** *pros* do [[G4314]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **ετερον** *heteron* innego [[G2087]] WTA-ASM **κρινεσθαι** *krinesthai* być sądzonym [[G2919]] WTV-PPN **επι** *epi* przed [[G1909]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **αδικων** *adikōn* niesprawiedliwymi [[G94]] WTA-GPM **και** *kai* a [[G2532]] [[CONJ]] **ουχι** *ouchi* nie [[G3780]] WTPRT-I **επι** *epi* przed [[G1909]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **αγιων** *hagiōn* świętymi [[G40]] WTA-GPM
###### **1Kor 6,2**
 **ουκ** *ouk* Nie [[G3756]] [[PRT-N]] **οιδατε** *oidate* wiecie [[G1492]] WTV-RAI-2P **οτι** *hoti* że [[G3754]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **αγιοι** *hagioi* święci [[G40]] WTA-NPM **τον** *ton* [[G3588]] [[T-ASM]] **κοσμον** *kosmon* świat [[G2889]] [[N-ASM]] **κρινουσιν** *krinousin* będą sądzić [[G2919]] WTV-FAI-3P **και** *kai* i [[G2532]] [[CONJ]] **ει** *ei* jeśli [[G1487]] WTCOND **εν** *en* w [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **κρινεται** *krinetai* jest sądzony [[G2919]] WTV-PPI-3S **ο** *ho* [[G3588]] [[T-NSM]] **κοσμος** *kosmos* świat [[G2889]] [[N-NSM]] **αναξιοι** *anaksioi* niegodni [[G370]] WTA-NPM **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **κριτηριων** *kritēriōn* sądzeń [[G2922]] WTN-GPN **ελαχιστων** *elachistōn* najmniejszych [[G1646]] WTA-GPN
###### **1Kor 6,3**
 **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **οιδατε** *oidate* wiecie [[G1492]] WTV-RAI-2P **οτι** *hoti* że [[G3754]] [[CONJ]] **αγγελους** *angelous* zwiastunów [[G32]] [[N-APM]] **κρινουμεν** *krinoumen* będziemy sądzić [[G2919]] WTV-FAI-1P **μητι** *mēti* czyż nie [[G3385]] WTPRT-I **γε** *ge* rzeczywiście – prawdziwie [[G1065]] WTPRT **βιωτικα** *biōtika* życiowe [[G982]] WTA-APN
###### **1Kor 6,4**
 **βιωτικα** *biōtika* Życiowe [[G982]] WTA-APN **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **ουν** *oun* więc [[G3767]] [[CONJ]] **κριτηρια** *kritēria* sądzenia [[G2922]] WTN-APN **εαν** *ean* jeśli [[G1437]] WTCOND **εχητε** *echēte* mielibyście [[G2192]] WTV-PAS-2P **τους** *tous* [[G3588]] WTT-APM **εξουθενημενους** *eksouthenēmenous* którzy są bez znaczenia – którzy są miani za nic [[G1848]] WTV-RPP-APM **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **εκκλησια** *ekklēsia* zgromadzeniu – (społeczności) wywołanych [[G1577]] [[N-DSF]] **τουτους** *toutous* tych [[G5128]] WTD-APM **καθιζετε** *kathizete* sądzacie [[G2523]] WTV-PAI-2P
###### **1Kor 6,5**
 **προς** *pros* Do [[G4314]] [[PREP]] **εντροπην** *entropēn* zawstydzenia [[G1791]] WTN-ASF **υμιν** *hymin* wam [[G5213]] WTP-2DP **λεγω** *legō* mówię [[G3004]] WTV-PAI-1S **ουτως** *houtōs* tak [[G3779]] [[ADV]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **εν** *en* wśród [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **σοφος** *sofos* mądry [[G4680]] [[A-NSM]] **ουδε** *oude* ani [[G3761]] [[ADV]] **εις** *eis* jeden [[G1520]] [[A-NSM]] **ος** *hos* który [[G3739]] WTR-NSM **δυνησεται** *dynēsetai* będzie mógł [[G1410]] WTV-FDI-3S **διακριναι** *diakrinai* rozsądzić [[G1252]] [[V-AAN]] **ανα** *ana* każdy [[G303]] [[PREP]] **μεσον** *meson* pośród [[G3319]] WTA-ASN **του** *tou* [[G3588]] WTT-GSM **αδελφου** *adelfou* brata [[G80]] [[N-GSM]] **αυτου** *autou* jego [[G846]] [[P-GSM]]
###### **1Kor 6,6**
 **αλλα** *alla* Ale [[G235]] [[CONJ]] **αδελφος** *adelfos* brat [[G80]] [[N-NSM]] **μετα** *meta* z [[G3326]] [[PREP]] **αδελφου** *adelfou* bratem [[G80]] [[N-GSM]] **κρινεται** *krinetai* jest sądzony [[G2919]] WTV-PPI-3S **και** *kai* i [[G2532]] [[CONJ]] **τουτο** *touto* to [[G5124]] WTD-NSN **επι** *epi* przed [[G1909]] [[PREP]] **απιστων** *apistōn* niewierzącymi [[G571]] WTA-GPM
###### **1Kor 6,7**
 **ηδη** *ēdē* Już [[G2235]] [[ADV]] **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **ουν** *oun* więc [[G3767]] [[CONJ]] **ολως** *holōs* całkowicie [[G3654]] [[ADV]] **ηττημα** *hēttēma* porażka – poniżenie [[G2275]] WTN-NSN **εν** *en* pośród [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **οτι** *hoti* że [[G3754]] [[CONJ]] **κριματα** *krimata* sądy – wyroki [[G2917]] WTN-APN **εχετε** *echete* macie [[G2192]] WTV-PAI-2P **μεθ** *meth* z [[G3326]] [[PREP]] **εαυτων** *heautōn* sobą [[G1438]] WTF-3GPM **δια** *dia* przez [[G1223]] [[PREP]] **τι** *ti* co [[G5101]] WTI-ASN **ουχι** *ouchi* nie [[G3780]] WTPRT-I **μαλλον** *mallon* raczej [[G3123]] [[ADV]] **αδικεισθε** *adikeisthe* znosicie niesprawiedliwość – jesteście krzywdzeni [[G91]] WTV-PPI-2P **δια** *dia* przez [[G1223]] [[PREP]] **τι** *ti* co [[G5101]] WTI-ASN **ουχι** *ouchi* nie [[G3780]] WTPRT-I **μαλλον** *mallon* raczej [[G3123]] [[ADV]] **αποστερεισθε** *apostereisthe* dajecie się pozbawić [[G650]] WTV-PPI-2P
###### **1Kor 6,8**
 **αλλα** *alla* Ale [[G235]] [[CONJ]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **αδικειτε** *adikeite* czynicie niesprawiedliwość – krzywdzicie [[G91]] WTV-PAI-2P **και** *kai* i [[G2532]] [[CONJ]] **αποστερειτε** *apostereite* pozbawiacie – oszukujecie [[G650]] WTV-PAI-2P **και** *kai* i [[G2532]] [[CONJ]] **ταυτα** *tauta* te [[G5023]] WTD-NPN **αδελφους** *adelfous* braci [[G80]] [[N-APM]]
###### **1Kor 6,9**
 **η** *ē* Czy [[G2228]] WTPRT **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **οιδατε** *oidate* wiecie [[G1492]] WTV-RAI-2P **οτι** *hoti* że [[G3754]] [[CONJ]] **αδικοι** *adikoi* niesprawiedliwi [[G94]] WTA-NPM **βασιλειαν** *basileian* Królestwa [[G932]] WTN-ASF **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ου** *ou* nie [[G3756]] [[PRT-N]] **κληρονομησουσιν** *klēronomēsousin* odziedziczą – dostaną w udziale [[G2816]] WTV-FAI-3P **μη** *mē* nie [[G3361]] [[PRT-N]] **πλανασθε** *planasthe* dajcie się zwieść – dajcie się wprowadzić w błąd [[G4105]] WTV-PPM-2P **ουτε** *oute* ani [[G3777]] [[CONJ]] **πορνοι** *pornoi* nierządnicy – wszetecznicy [[G4205]] WTN-NPM **ουτε** *oute* ani [[G3777]] [[CONJ]] **ειδωλολατραι** *eidōlolatrai* bałwochwalcy [[G1496]] WTN-NPM **ουτε** *oute* ani [[G3777]] [[CONJ]] **μοιχοι** *moichoi* cudzołożnicy [[G3432]] WTN-NPM **ουτε** *oute* ani [[G3777]] [[CONJ]] **μαλακοι** *malakoi* zniewieściali – miękcy [[G3120]] WTA-NPM **ουτε** *oute* ani [[G3777]] [[CONJ]] **αρσενοκοιται** *arsenokoitai* homoseksualiści – pokładający się z mężczyznami [[G733]] WTN-NPM
###### **1Kor 6,10**
 **ουτε** *oute* Ani [[G3777]] [[CONJ]] **κλεπται** *kleptai* złodzieje – kradnący [[G2812]] WTN-NPM **ουτε** *oute* ani [[G3777]] [[CONJ]] **πλεονεκται** *pleonektai* chciwcy – zachłanni [[G4123]] WTN-NPM **ουτε** *oute* ani [[G3777]] [[CONJ]] **μεθυσοι** *methysoi* pijacy [[G3183]] WTN-NPM **ου** *ou* nie [[G3756]] [[PRT-N]] **λοιδοροι** *loidoroi* oszczercy – znieważający [[G3060]] WTA-NPM **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **αρπαγες** *harpages* zdziercy – drapieżcy [[G727]] WTA-NPM **βασιλειαν** *basileian* Królestwa [[G932]] WTN-ASF **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ου** *hou* nie [[G3756]] [[PRT-N]] **κληρονομησουσιν** *klēronomēsousin* odziedziczą – dostaną w udziale [[G2816]] WTV-FAI-3P
###### **1Kor 6,11**
 **και** *kai* i [[G2532]] [[CONJ]] **ταυτα** *tauta* tacy [[G5023]] WTD-NPN **τινες** *tines* jacyś [[G5100]] WTX-NPM **ητε** *ēte* byliście [[G2258]] WTV-IXI-2P **αλλα** *alla* ale [[G235]] [[CONJ]] **απελουσασθε** *apelousasthe* obmyliście się [[G628]] WTV-AMI-2P **αλλα** *alla* ale [[G235]] [[CONJ]] **ηγιασθητε** *hēgiasthēte* zostaliście poświęceni – zostaliście uświęceni [[G37]] WTV-API-2P **αλλ** *all* ale [[G235]] [[CONJ]] **εδικαιωθητε** *edikaiōthēte* zostaliście uznani za sprawiedliwych – zostaliście usprawiedliwieni [[G1344]] WTV-API-2P **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **ονοματι** *onomati* imieniu [[G3686]] WTN-DSN **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **πνευματι** *pneumati* Duchu [[G4151]] WTN-DSN **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP
###### **1Kor 6,12**
 **παντα** *panta* Wszystkie [[G3956]] WTA-NPN **μοι** *moi* mi [[G3427]] WTP-1DS **εξεστιν** *eksestin* wolno – jest dozwolone [[G1832]] WTV-PQI-3S **αλλ** *all* ale [[G235]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **παντα** *panta* wszystkie [[G3956]] WTA-NPN **συμφερει** *symferei* jest korzystne – jest pożyteczne [[G4851]] WTV-PAI-3S **παντα** *panta* wszystkie [[G3956]] WTA-NPN **μοι** *moi* mi [[G3427]] WTP-1DS **εξεστιν** *eksestin* wolno – jest dozwolone [[G1832]] WTV-PQI-3S **αλλ** *all* ale [[G235]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εγω** *egō* ja [[G1473]] WTP-1NS **εξουσιασθησομαι** *eksousiasthēsomai* będę owładnięty – będę pod władzą [[G1850]] WTV-FPI-1S **υπο** *hypo* przez [[G5259]] [[PREP]] **τινος** *tinos* coś [[G5100]] WTX-GSN
###### **1Kor 6,13**
 **τα** *ta* [[G3588]] WTT-NPN **βρωματα** *brōmata* Pokarmy [[G1033]] WTN-NPN **τη** *tē* (dla) [[G3588]] WTT-DSF **κοιλια** *koilia* brzucha [[G2836]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **κοιλια** *koilia* brzuch [[G2836]] [[N-NSF]] **τοις** *tois* (dla) [[G3588]] WTT-DPN **βρωμασιν** *brōmasin* pokarmów [[G1033]] WTN-DPN **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ταυτην** *tautēn* ten [[G3778]] WTD-ASF **και** *kai* i [[G2532]] [[CONJ]] **ταυτα** *tauta* te [[G5023]] WTD-APN **καταργησει** *katargēsei* udaremni – uzna za bezużyteczne [[G2673]] WTV-FAI-3S **το** *to* [[G3588]] WTT-NSN **δε** *de* zaś [[G1161]] [[CONJ]] **σωμα** *sōma* ciało [[G4983]] WTN-NSN **ου** *ou* nie [[G3756]] [[PRT-N]] **τη** *tē* (dla) [[G3588]] WTT-DSF **πορνεια** *porneia* nierządu – wszeteczeństwa [[G4202]] [[N-DSF]] **αλλα** *alla* ale [[G235]] [[CONJ]] **τω** *tō* (dla) [[G3588]] WTT-DSM **κυριω** *kyriō* Pana [[G2962]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **τω** *tō* (dla) [[G3588]] WTT-DSN **σωματι** *sōmati* ciała [[G4983]] WTN-DSN
###### **1Kor 6,14**
 **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **τον** *ton* [[G3588]] [[T-ASM]] **κυριον** *kyrion* Pana [[G2962]] [[N-ASM]] **ηγειρεν** *ēgeiren* wzbudził – podniósł [[G1453]] [[V-AAI-3S]] **και** *kai* i [[G2532]] [[CONJ]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **εξεγερει** *eksegerei* wzbudzi – podniesie [[G1825]] WTV-FAI-3S **δια** *dia* przez [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **δυναμεως** *dynameōs* moc [[G1411]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **1Kor 6,15**
 **ουκ** *ouk* Nie [[G3756]] [[PRT-N]] **οιδατε** *oidate* wiecie [[G1492]] WTV-RAI-2P **οτι** *hoti* że [[G3754]] [[CONJ]] **τα** *ta* [[G3588]] WTT-NPN **σωματα** *sōmata* ciała [[G4983]] WTN-NPN **υμων** *hymōn* wasze [[G5216]] WTP-2GP **μελη** *melē* członki [[G3196]] WTN-NPN **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **εστιν** *estin* jest (są) [[G2076]] WTV-PXI-3S **αρας** *aras* wziąwszy – zabrawszy [[G142]] WTV-AAP-NSM **ουν** *oun* więc [[G3767]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **μελη** *melē* członki [[G3196]] WTN-APN **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **ποιησω** *poiēsō* uczyniłbym [[G4160]] WTV-AAS-1S **πορνης** *pornēs* nierządnicy – wszetecznicy [[G4204]] [[N-GSF]] **μελη** *melē* członkami [[G3196]] WTN-APN **μη** *mē* nie [[G3361]] [[PRT-N]] **γενοιτο** *genoito* oby stał się [[G1096]] WTV-2ADO-3S
###### **1Kor 6,16**
 **η** *ē* Lub [[G2228]] WTPRT **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **οιδατε** *oidate* wiecie [[G1492]] WTV-RAI-2P **οτι** *hoti* że [[G3754]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **κολλωμενος** *kollōmenos* który jest łączony [[G2853]] [[V-PPP-NSM]] **τη** *tē* (z) [[G3588]] WTT-DSF **πορνη** *pornē* nierządnicą – wszetecznicą [[G4204]] [[N-DSF]] **εν** *hen* jedno [[G1520]] WTA-NSN **σωμα** *sōma* ciało [[G4983]] WTN-NSN **εστιν** *estin* jest (są) [[G2076]] WTV-PXI-3S **εσονται** *esontai* będą [[G2071]] WTV-FXI-3P **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **φησιν** *fēsin* mówi [[G5346]] WTV-PXI-3S **οι** *hoi* [[G3588]] WTT-NPM **δυο** *dyo* dwoje [[G1417]] WTA-NUI **εις** *eis* ku [[G1519]] [[PREP]] **σαρκα** *sarka* ciału [[G4561]] WTN-ASF **μιαν** *mian* jednemu [[G1520]] WTA-ASF
###### **1Kor 6,17**
 **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **κολλωμενος** *kollōmenos* który jest łączony [[G2853]] [[V-PPP-NSM]] **τω** *tō* (z) [[G3588]] WTT-DSM **κυριω** *kyriō* Panem [[G2962]] WTN-DSM **εν** *hen* jeden [[G1520]] WTA-NSN **πνευμα** *pneuma* duch [[G4151]] WTN-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S
###### **1Kor 6,18**
 **φευγετε** *feugete* Uciekajcie [[G5343]] WTV-PAM-2P **την** *tēn* (przed) [[G3588]] WTT-ASF **πορνειαν** *porneian* nierządem – wszeteczeństwem [[G4202]] WTN-ASF **παν** *pan* każdy [[G3956]] WTA-NSN **αμαρτημα** *hamartēma* grzech – wina [[G265]] WTN-NSN **ο** *ho* które [[G3739]] WTR-ASN **εαν** *ean* jeśli [[G1437]] WTCOND **ποιηση** *poiēsē* uczyniłby [[G4160]] WTV-AAS-3S **ανθρωπος** *anthrōpos* człowiek [[G444]] [[N-NSM]] **εκτος** *ektos* na zewnątrz [[G1622]] [[ADV]] **του** *tou* [[G3588]] WTT-GSN **σωματος** *sōmatos* ciała [[G4983]] [[N-GSN]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **πορνευων** *porneuōn* oddający się nierządowi – popełniający wszeteczeństwo [[G4203]] [[V-PAP-NSM]] **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **ιδιον** *idion* własnemu [[G2398]] WTA-ASN **σωμα** *sōma* ciału [[G4983]] WTN-ASN **αμαρτανει** *hamartanei* grzeszy [[G264]] WTV-PAI-3S
###### **1Kor 6,19**
 **η** *ē* Czy [[G2228]] WTPRT **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **οιδατε** *oidate* wiecie [[G1492]] WTV-RAI-2P **οτι** *hoti* że [[G3754]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **σωμα** *sōma* ciało [[G4983]] WTN-NSN **υμων** *hymōn* wasze [[G5216]] WTP-2GP **ναος** *naos* świątynia – przybytek [[G3485]] [[N-NSM]] **του** *tou* [[G3588]] WTT-GSN **εν** *en* w [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **αγιου** *hagiou* Świętego [[G40]] [[A-GSN]] **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ου** *hou* którego [[G3739]] WTR-GSN **εχετε** *echete* macie [[G2192]] WTV-PAI-2P **απο** *apo* od [[G575]] [[PREP]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **εαυτων** *heautōn* was samych [[G1438]] WTF-3GPM
###### **1Kor 6,20**
 **ηγορασθητε** *ēgorasthēte* Zostaliście wykupieni [[G59]] WTV-API-2P **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **τιμης** *timēs* drogo – (za cenę) szacunku [[G5092]] [[N-GSF]] **δοξασατε** *doksasate* oddajcie chwałę [[G1392]] WTV-AAM-2P **δη** *dē* właśnie – zatem [[G1211]] WTPRT **τον** *ton* [[G3588]] [[T-ASM]] **θεον** *theon* Bogu [[G2316]] [[N-ASM]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **σωματι** *sōmati* ciele [[G4983]] WTN-DSN **υμων** *hymōn* waszym [[G5216]] WTP-2GP **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **πνευματι** *pneumati* duchu [[G4151]] WTN-DSN **υμων** *hymōn* waszym [[G5216]] WTP-2GP **ατινα** *hatina* które [[G3748]] WTR-NPN **εστιν** *estin* jest (są) [[G2076]] WTV-PXI-3S **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
