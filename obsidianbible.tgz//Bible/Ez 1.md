# Ez 1 BT5
###### **Ez 1,1**
 Działo się to roku trzydziestego, dnia piątego, czwartego miesiąca, gdy się znajdowałem wśród zesłańców nad rzeką Kebar. Otworzyły się niebiosa i doświadczyłem widzenia Bożego.
###### **Ez 1,2**
 Piątego dnia miesiąca – rok to był piąty od uprowadzenia do niewoli króla Jojakina
###### **Ez 1,3**
 Pan skierował słowo do kapłana Ezechiela, syna Buziego, w ziemi Chaldejczyków nad rzeką Kebar; była tam nad nim ręka Pańska.
###### **Ez 1,4**
 Patrzyłem, a oto wiatr gwałtowny nadszedł od północy, wielki obłok i ogień płonący <oraz blask dokoła niego>, a z jego środka [promieniowało coś] jakby połysk stopu złota ze srebrem, <ze środka ognia>.
###### **Ez 1,5**
 Pośrodku było coś podobnego do czterech Istot żyjących. Oto ich wygląd: miały one postać człowieka.
###### **Ez 1,6**
 Każda z nich miała po cztery twarze i po cztery skrzydła.
###### **Ez 1,7**
 Nogi ich były proste, stopy ich zaś były podobne do stóp cielca; lśniły jak brąz wygładzony.
###### **Ez 1,8**
 Miały one pod skrzydłami ręce ludzkie po swych czterech bokach. Oblicza <i skrzydła < owych czterech istot –
###### **Ez 1,9**
 skrzydła ich mianowicie przylegały wzajemnie do siebie – nie odwracały się, gdy one szły; każda szła prosto przed siebie.
###### **Ez 1,10**
 Oblicza ich miały taki wygląd: każda z czterech istot miała z prawej strony oblicze człowieka i oblicze lwa, z lewej zaś strony każda z czterech miała oblicze cielca i oblicze orła,
###### **Ez 1,11**
 <oblicza ich < i skrzydła ich były rozwinięte ku górze; dwa przylegały wzajemnie do siebie, a dwa okrywały ich tułowie.
###### **Ez 1,12**
 Każda posuwała się prosto przed siebie; szły tam, dokąd duch je prowadził; idąc, nie odwracały się.
###### **Ez 1,13**
 W środku między tymi Istotami żyjącymi pojawiły się jakby żarzące się w ogniu węgle, podobne do pochodni, poruszające się między owymi Istotami żyjącymi. Ogień rzucał jasny blask, a z ognia wychodziły błyskawice.
###### **Ez 1,14**
 Istoty żyjące biegały tam i z powrotem niczym błyskawice.
###### **Ez 1,15**
 Przypatrzyłem się tym Istotom żyjącym, a oto przy każdej z tych czterech Istot żyjących znajdowało się na ziemi jedno koło.
###### **Ez 1,16**
 Wygląd tych kół <i ich wykonanie < odznaczały się połyskiem topazu, a wszystkie cztery miały ten sam wygląd i wydawało się, jakby były wykonane tak, że jedno koło było w drugim.
###### **Ez 1,17**
 Mogły chodzić w czterech kierunkach; gdy zaś szły, nie odwracały się, idąc.
###### **Ez 1,18**
 Obręcz ich była ogromna; przypatrywałem się im i oto: obręcz u tych wszystkich czterech była pełna oczu wokoło.
###### **Ez 1,19**
 A gdy te Istoty żyjące się posuwały, także koła posuwały się razem z nimi, gdy zaś te Istoty żyjące podnosiły się z ziemi, podnosiły się również koła.
###### **Ez 1,20**
 Dokądkolwiek poruszał je duch, tam szły także koła; równocześnie podnosiły się z nimi, ponieważ duch życia znajdował się w kołach.
###### **Ez 1,21**
 Gdy szły [te istoty], szły i one, a gdy przystawały, również i koła się zatrzymywały; gdy one od ziemi się podrywały, podrywały się z nimi także koła, ponieważ duch życia znajdował się w kołach.
###### **Ez 1,22**
 Nad głowami tych Istot żyjących było coś jakby sklepienie niebieskie, jakby kryształ lśniący, rozpostarty ponad ich głowami, w górze.
###### **Ez 1,23**
 Pod sklepieniem jednak skrzydła ich były wzniesione, jedne przy drugich; u każdej z nich dwoje pokrywało ich tułowie.
###### **Ez 1,24**
 Gdy szły, słyszałem poszum ich skrzydeł jak szum wielkich wód, jak głos Wszechmogącego, odgłos ogłuszający jak zgiełk obozu żołnierskiego; natomiast gdy stały, skrzydła miały opuszczone.
###### **Ez 1,25**
 Nad sklepieniem, które było nad ich głowami, rozlegał się głos; <gdy stały, skrzydła miały opuszczone>.
###### **Ez 1,26**
 Ponad sklepieniem, które znajdowało się nad ich głowami, było coś, co wyglądało jak szafir, a miało kształt tronu, a na nim jakby zarys postaci człowie-ka.
###### **Ez 1,27**
 Następnie widziałem coś jakby połysk stopu złota ze srebrem, <który wyglądał jak ogień wokół niego>. Ku górze od tego, co wyglądało jak biodra, i w dół od tego, co wyglądało jak biodra, widziałem coś, co wyglądem przypominało ogień, a wokół niego roztaczał się blask.
###### **Ez 1,28**
 Jak pojawienie się tęczy na obłokach w dzień deszczowy, tak przedstawiał się ów blask dokoła. Taki był widok tego, co było podobne do chwały Pańskiej. Oglądałem ją. Następnie padłem na twarz i usłyszałem głos Mówiącego.
# Ez 1 PAU
###### **Ez 1,1**
 Stało się to trzydziestego roku, w piątym dniu, czwartego miesiąca, gdy byłem wśród uprowadzonych nad rzeką Kebar. Otworzyło się niebo i miałem widzenia od Boga.
###### **Ez 1,2**
 W piątym dniu miesiąca - był to piąty rok od uprowadzenia króla Jechoniasza -
###### **Ez 1,3**
 PAN przemówił do kapłana Ezechiela, syna Buziego, w ziemi Chaldejczyków nad rzeką Kebar. Tam ręka PANA spoczęła na nim.
###### **Ez 1,4**
 W gwałtownym wichrze nadchodzącym z północy ujrzałem wtedy wielką chmurę i błyskający ogień. Wokół tej chmury była światłość, a w jej środku jakby blask pozłacanego srebra w ogniu.
###### **Ez 1,5**
 W środku znajdowała się podobizna czterech żywych istot. Z wyglądu przypominały one człowieka.
###### **Ez 1,6**
 Każda miała cztery twarze i cztery skrzydła.
###### **Ez 1,7**
 Ich nogi były proste, a stopy podobne do kopyt cielca. Lśniły jak dobrze wypolerowany brąz.
###### **Ez 1,8**
 Na ich czterech bokach pod skrzydłami były ręce. Wszystkie cztery istoty miały twarze i skrzydła.
###### **Ez 1,9**
 A skrzydła przylegały jedno do drugiego. Idąc, istoty nie odwracały się. Każda szła prosto przed siebie.
###### **Ez 1,10**
 U wszystkich czterech twarze miały z przodu wygląd człowieka, z prawej strony lwa, z lewej wołu, a z tyłu orła.
###### **Ez 1,11**
 Takie były ich twarze. Ich skrzydła były rozpostarte ku górze. U każdej dwa przylegały jedno do drugiego, a dwa okrywały ciało.
###### **Ez 1,12**
 Każda szła prosto przed siebie. Szły tam, dokąd je duch prowadził. Idąc, nie odwracały się.
###### **Ez 1,13**
 Między istotami żywymi było coś przypominającego żarzące się węgle, podobne do płonących pochodni. Krążyło to między istotami żywymi. Ogień dawał blask, a z ognia wychodziły błyskawice.
###### **Ez 1,14**
 Żywe istoty biegały tam i z powrotem jak błyskawice.
###### **Ez 1,15**
 Spojrzałem na żywe istoty. A oto na ziemi obok każdej z czterech żywych istot było koło.
###### **Ez 1,16**
 Wygląd kół oraz ich wykonanie odznaczały się blaskiem chryzolitu. Wszystkie cztery były do siebie podobne. Miały ten sam wygląd i wydawało się, jakby zostały wykonane tak, że jedno koło było wewnątrz drugiego koła.
###### **Ez 1,17**
 Gdy się poruszały, szły w czterech kierunkach. Nie odwracały się, gdy szły.
###### **Ez 1,18**
 Ich obręcze były wysokie i przerażające, pełne oczu dokoła.
###### **Ez 1,19**
 Gdy istoty żywe szły naprzód, koła posuwały się. Gdy zaś istoty żywe wznosiły się nad ziemię, wznosiły się również koła.
###### **Ez 1,20**
 Kierował nimi duch i one szły tam, dokąd je duch kierował; koła wznosiły się wraz z nimi, gdyż duch istot żywych był w kołach.
###### **Ez 1,21**
 Gdy istoty żywe poruszały się, szły także koła, a gdy stawały, to również koła się zatrzymywały. Gdy wznosiły się nad ziemię, wtedy wraz z nimi wznosiły się i koła, gdyż duch istot żywych był w kołach.
###### **Ez 1,22**
 Nad głowami istot żywych było coś w kształcie sklepienia, błyszczącego jak olśniewający kryształ. Było to rozpostarte w górze nad ich głowami.
###### **Ez 1,23**
 Pod sklepieniem były natomiast rozpostarte ich skrzydła zwrócone ku sobie. Każda istota żywa miała dwa, które okrywały jej ciało.
###### **Ez 1,24**
 Usłyszałem szum skrzydeł. Był on jak szum wielkich wód, jak głos Wszechmogącego. Gdy się poruszały, ów dźwięk przypominał wrzawę tłumu lub zgiełk obozowiska. Gdy się zatrzymywały, opuszczały swe skrzydła.
###### **Ez 1,25**
 I rozległ się głos znad sklepienia, które było nad ich głowami.
###### **Ez 1,26**
 A ponad sklepieniem, które było nad ich głowami, ukazało się coś, co miało wygląd kamienia szafiru i było podobne do tronu. Nad nim zaś, w górze, było coś z wyglądu przypominające człowieka.
###### **Ez 1,27**
 I widziałem jakby blask pozłacanego srebra, jakby ogień wokół niego. W górę od tego, co było podobne do bioder, i w dół od tego, co przypominało biodra, widziałem coś, co wyglądało jak ogień. A wokół niego światłość.
###### **Ez 1,28**
 Jak tęcza pojawiająca się na obłokach w dzień deszczowy, taka była światłość dokoła. Było to widzenie chwały PANA. Gdy ją ujrzałem, upadłem na twarz. I usłyszałem głos, który mówił.
# Ez 1 BP
###### **Ez 1,1**
 Stało się trzydziestego roku, w czwartym [miesiącu], piątego [dnia] miesiąca, gdy [przebywałem] pośród wygnańców nad rzeką Kebar, że rozwarły się niebiosa i miałem widzenie Boże.
###### **Ez 1,2**
 W piątym [dniu] miesiąca - był to piąty rok zesłania króla Jojakina -
###### **Ez 1,3**
 Jahwe przemówił do kapłana Ezechiela, syna Buzi, w ziemi Chaldejczyków nad rzeką Kebar, i spoczęła tam na nim ręka Jahwe.
###### **Ez 1,4**
 Spojrzałem: oto gwałtowny wiatr nadciągnął z północy. [Pojawiła się] wielka chmura i błyskawice. Światłość [otaczała] ją wkoło, a w jej środku [jaśniał] jakby blask pozłacanego srebra pośród ognia.
###### **Ez 1,5**
 W jego wnętrzu było podobieństwo czterech istot żywych; a wyglądały tak: miały one postać ludzką.
###### **Ez 1,6**
 Każda [z nich] miała cztery oblicza i cztery skrzydła.
###### **Ez 1,7**
 Ich nogi były proste, a stopy ich nóg [wyglądały] jak stopy nóg cielca. Lśniły połyskiem wypolerowanego brązu.
###### **Ez 1,8**
 Pod swymi skrzydłami u czterch boków miały ręce ludzkie. Wszystkie cztery miały oblicza i skrzydła.
###### **Ez 1,9**
 Ich skrzydła były złączone z sobą. Idąc nie odwracały się, ale każda posuwała się prosto przed siebie.
###### **Ez 1,10**
 Wygląd ich oblicza: z prawej strony wszystkie cztery miały oblicze człowieka i oblicze lwa, zaś z lewej strony wszystkie cztery miały oblicze wołu i oblicze orła.
###### **Ez 1,11**
 [...] Skrzydła ich były rozwinięte ku górze. Każda miała dwa [skrzydła], które łączyły się z sobą, i dwa, którymi okrywały swe ciała.
###### **Ez 1,12**
 Każda posuwała się prosto przed siebie. Szły tam, dokąd duch zmierzał, a idąc nie odwracały się.
###### **Ez 1,13**
 Między istotami żywymi było coś, co wyglądało jak węgle ogniem rozżarzone, na podobieństwo pochodni. Krążyło ono między istotami żywymi. Ogień świecił, a z ognia wychodziły błyski.
###### **Ez 1,14**
 Istoty żywe biegały tam i z powrotem na podobieństwo błyskawicy.
###### **Ez 1,15**
 Spojrzałem na istoty żywe: a oto na ziemi obok każdej z czterech istot żywych znajdowało się jedno koło.
###### **Ez 1,16**
 Koła wyglądały jak blask chryzolitu. Wszystkie cztery miały ten sam kształt, a tak wyglądały i tak były wykonane, jak gdyby [jedno] koło znajdowało się wewnątrz drugiego.
###### **Ez 1,17**
 Poruszając się szły w swoich czterech kierunkach. Idąc nie odwracały się.
###### **Ez 1,18**
 Ich obręcze były wysokie. Przyjrzałem się im, a wszystkie cztery obręcze miały pełno oczu wokoło.
###### **Ez 1,19**
 Gdy istoty żywe poruszały się, koła posuwały się obok nich. Gdy istoty żywe się wznosiły ponad ziemię, koła [również] się unosiły.
###### **Ez 1,20**
 Tam, dokąd duch zmierzał, tam szły [istoty żywe]. Równocześnie z nimi unosiły się koła, bo duch istot żywych był w kołach.
###### **Ez 1,21**
 Gdy się one poruszały, posuwały się [koła]. Gdy one stawały, [koła] się zatrzymywały. Gdy one się wznosiły ponad ziemię, równocześnie z nimi unosiły się koła, bo duch istot żywych był w kołach.
###### **Ez 1,22**
 Nad głowami istot żywych [było coś] na kształt sklepienia, jak blask straszliwego kryształu, rozpostartego w górze nad ich głowami.
###### **Ez 1,23**
 pod sklepieniem [rozpościerały] się ich skrzydła proste, [które łączyły się] z sobą. Każda [istota żywa] miała też dwa [skrzydła], które okrywały ich ciała.
###### **Ez 1,24**
 Słyszałem szum ich skrzydeł; był jak szum wielkich wód, jak głos Wszechmogącego. Był jak głos wrzawy, jak rozgwar obozowiska, gdy się poruszały. Gdy się zatrzymywały, opuszczały swe skrzydła.
###### **Ez 1,25**
 I dał się słyszeć głos znad sklepienia, które było nad ich głowami.
###### **Ez 1,26**
 Ponad sklepieniem, które było nad ich głowami, ukazało się coś, co wyglądało jak kamień szafiru, a podobne było do tronu. W górze zaś nad tym, co było podobne do tronu, znajdowało się coś, [co miało] wygląd człowieka.
###### **Ez 1,27**
 I widziałem jak gdyby blask pozłacanego srebra, jak widok ognia wewnątrz niego wokoło. Od podobieństwa jego bioder wzwyż i od podobieństwa jego bioder w dół ujrzałem coś, co wyglądało jak ogień. Światłość [otaczała] go wkoło.
###### **Ez 1,28**
 Jak widok tęczy, która pojawia się na chmurze w dzień deszczowy, tak wyglądała światłość wokoło. Takie było widzenie podobieństwa Chwały Jahwe. Gdy ją ujrzałem, padłem na twarz. Wówczas usłyszałem głos, który mówił.
# Ez 1 BR
###### **Ez 1,1**
 Dnia piątego, czwartego miesiąca, roku trzydziestego, gdy znajdowałem się wśród wygnańców nad rzeką Kebar, otworzyły się niebiosa. I miałem widzenie Boga.
###### **Ez 1,2**
 Dnia piątego tego miesiąca - a upłynęło już wtedy pięć lat od uprowadzenia do niewoli króla Jojakina -
###### **Ez 1,3**
 skierował Pan swoje słowo do Ezechiela, syna Buziego, kapłana, który przebywał w krainie chaldejskiej, nad rzeką Kebar. Tam to Pan wyciągnął nad nim rękę.
###### **Ez 1,4**
 I oto widziałem, jak wicher gwałtowny nadchodził od północy. Niósł ze sobą wielki ognisty obłok, rozświetlający wszystko dokoła. W samym środku ognia błyszczało coś jak najszlachetniejsze złoto.
###### **Ez 1,5**
 Wśród płomieni ognistych widać było jakby cztery istoty żywe, podobne z wyglądu do ludzi.
###### **Ez 1,6**
 Każda z tych istot miała cztery twarze i cztery skrzydła.
###### **Ez 1,7**
 Nogi miały wyprostowane, zaś ich stopy przypominały stopy ogromnego cielca, a lśniły tak jak brąz starannie wygładzony.
###### **Ez 1,8**
 Spod skrzydeł, ze wszystkich czterech stron, wystawały ludzkie ręce. [Miały oblicze i skrzydła owe cztery istoty].
###### **Ez 1,9**
 Ich skrzydła dotykały siebie nawzajem. Kiedy się poruszały te istoty, nie odwracały się w żadną stronę: każda zmierzała w tym kierunku, jaki jej wyznaczało własne oblicze.
###### **Ez 1,10**
 Oblicza te zaś wyglądały tak: z przodu każda z czterech istot miała twarz ludzką, z prawej strony u każdej z nich był widoczny lew, po lewej stronie każdej z czterech istot wystawał łeb wołu, a z tyłu każdej z nich widać było głowę orła.
###### **Ez 1,11**
 Skrzydła ich były uniesione ku górze w ten sposób, że dwa stykały się ze sobą, a dwa okrywały całe ciało.
###### **Ez 1,12**
 Każda z tych istot posuwała się w kierunku wskazanym przez jej oblicze. Szły zaś tam, dokąd je duch prowadził, nie zbaczały nigdzie ze swej drogi.
###### **Ez 1,13**
 W samym środku, między tymi istotami widać było jakby rozżarzone węgle albo pochodnie, które się poruszały na wszystkie strony. Ogień rozświetlał wszystko dokoła, z ognia też wychodziły błyskawice.
###### **Ez 1,14**
 Owe żywe istoty biegały tam i z powrotem jakby błyskawice.
###### **Ez 1,15**
 Przypatrzyłem się dokładnie owym istotom żywym i zobaczyłem, że obok każdej z nich znajdowało się na ziemi jedno koło.
###### **Ez 1,16**
 Koła wyglądały tak, jakby były zrobione z chryzolitu. Wszystkie cztery były dokładnie do siebie podobne, a były tak zrobione, jakby jedno obracało się wewnątrz drugiego.
###### **Ez 1,17**
 Mogły się one poruszać we wszystkie cztery strony, nie zbaczając przy tym nigdzie z obranej drogi.
###### **Ez 1,18**
 Rozmiary tych kół były tak ogromne, że aż mnie przerażały. Wszystkie cztery koła na swych obręczach miały pełno oczu.
###### **Ez 1,19**
 Gdy istoty żywe zaczynały się poruszać, wówczas posuwały się do przodu także i koła.
###### **Ez 1,20**
 Posuwały się zaś tam, dokąd istoty były prowadzone przez ducha. Koła podnosiły się z miejsca razem [z owymi istotami], bo duch tych istot był również w kołach.
###### **Ez 1,21**
 Gdy istoty żywe posuwały się do przodu, szły z nimi także koła, kiedy zaś się zatrzymywały, koła również stawały. Gdy któraś z istot podnosiła się z ziemi, podnosiły się także koła, bo duch istot żywych był również w kołach.
###### **Ez 1,22**
 Ponad głowami wszystkich istot żywych znajdowało się coś na kształt sklepienia, strasznego z wyglądu, jakby jeden ogromny kryształ unoszący się w górze nad ich głowami.
###### **Ez 1,23**
 Pod sklepieniem były rozpostarte ich skrzydła tak, że jedno dotykało drugiego. Dwa skrzydła zaś okrywały ciała każdej z żywych istot.
###### **Ez 1,24**
 Słyszałem także szum ich skrzydeł. Był to jakby szum wód potężnych albo jak głos Wszechmocnego. Kiedy ruszały z miejsca, słychać było odgłosy pochodzące z jakiegoś wojskowego obozu. Kiedy zaś przystawały, skrzydła ich opadały ku ziemi.
###### **Ez 1,25**
 Szum dochodził także sponad sklepienia znajdującego się nad ich głowami. Kiedy przystawały, skrzydła ich opadały ku ziemi.
###### **Ez 1,26**
 Ponad sklepieniem, nad ich głowami, znajdowało się coś na kształt szafirowego tronu. Na owym wzniesieniu podobnym do tronu zasiadała postać, przypominająca wyglądem postać ludzką.
###### **Ez 1,27**
 Wokół jakby bioder zobaczyłem jasność z samego środka błyszczącego złota, niczym wieńca z płomieni. Spod tego zaś, co kształtem przypomina biodra, wydostawał się ogień, rzucający swój blask dokoła.
###### **Ez 1,28**
 Jak pojawienie się tęczy na obłokach w dzień deszczowy, podobny blask i tu rozchodził się dokoła. Wyglądało to tak jakby Chwała Boża. Zobaczywszy to, upadłem na twarz. I wtedy usłyszałem, jak ktoś do mnie mówił.
# Ez 1 WUJ
###### **Ez 1,1**
 I stało się trzydziestego roku, w czwartym, piątego dnia miesiąca, gdym był w pośrodku pojmanych nad rzeką Chobar otworzyły się niebiosa, i widziałem widzenia Boże.
###### **Ez 1,2**
 Piątego dnia miesiąca, ten jest rok piąty przeprowadzenia, króla Joachina,
###### **Ez 1,3**
 Stało się słowo Pańskie do Ezechiela syna Buzy kapłana w ziemi Chaldejskiej, nad rzeką Chobar, i stała się tam nad nim ręka Pańska.
###### **Ez 1,4**
 I widziałem, a to wiatr wichru przychodził od północy: i obłok wielki, i ogień mieszający, a jasność około niego: aż pośrodku jego jako kształt mosiądzu, to jest z pośrodku ognia:
###### **Ez 1,5**
 A w pośrodku jego podobieństwo czterzech zwierząt: a ta osoba ich: podobieństwo człowieka w nich.
###### **Ez 1,6**
 Czworo oblicze u jednego, a czterzy skrzydła u jednego.
###### **Ez 1,7**
 Nogi ich nogi proste a stopa nogi ich jako stopa nogi cielęcej, a iskierki jako pozór miedzi rozpalonej:
###### **Ez 1,8**
 I ręce człowiecze pod skrzydły ich, po czterzech stronach: a oblicza i skrzydła po czterzech stronach miały.
###### **Ez 1,9**
 A skrzydła ich złączone były jednego z drugim. Nie wracały się gdy chodziły, ale każde przed obliczem swojem chodziło.
###### **Ez 1,10**
 A podobieństwo twarzy ich: twarz człowiecza, i twarz lwia po prawicy tego czworga: a twarz wołowa po lewicy tego czworga: a twarz orłowa na wierzchu tego czworga.
###### **Ez 1,11**
 Twarzy ich, skrzydła ich rozciągnione z wierzchu: dwie skrzydle każdego złączały się, a dwie zakrywały ciała ich:
###### **Ez 1,12**
 A każde z nich przed obliczem swem chodziło: dokąd duch pędził: tam chodziły i nie wracały się kiedy chodziły.
###### **Ez 1,13**
 A podobieństwo zwierząt, osoba ich jako węgla ognistego gorającego, i jako kształt pochodni. Toć było widzenie przebiegające między zwierzęty jasność ogniowa, a z ognia wychodząca błyskawica.
###### **Ez 1,14**
 A zwierzęta biegały, i wracały się na kształt błyskawice błyskającej.
###### **Ez 1,15**
 A gdym patrzał na zwierzęta, ukazało się koło jedno na ziemi wedle zwierząt, mając cztery twarzy.
###### **Ez 1,16**
 A pozór kół i robota ich jako widzenie morza: a podobieństwo jedno u wszystkich czterzech: a pozór ich i robota jakoby było koło w pośrodku koła.
###### **Ez 1,17**
 Na cztery strony ich chodząc chodziły, a nie wracały się gdy chodziły.
###### **Ez 1,18**
 Miały też koła stan i wysokość, i wejrzenie, straszne: a wszystko ciało pełne oczu w około onych czterech.
###### **Ez 1,19**
 A gdy chodziły zwierzęta, chodziły społem i koła wedle nich: i gdy się podnosiły zwierzęta od ziemie, podnosiły się też i koła.
###### **Ez 1,20**
 Gdziekolwiek szedł duch, tam gdy szedł duch, i koła się społem podnosiły idąc za nim. Bo duch żywota był w kołach.
###### **Ez 1,21**
 Z idącemi chodziły, a z stojącemi stały: a z podniesionemi od ziemie wespół się i koła podnosiły, idąc za nimi: bo duch żywota był w kołach.
###### **Ez 1,22**
 I podobieństwo utwierdzenia nad głowami zwierząt, jako pozór kryształu strasznego i rozciągnionego nad głowami ich z wierzchu.
###### **Ez 1,23**
 A pod utwierdzeniem skrzydła ich proste jednego ku drugiemu: każde dwiema skrzydłami zakrywało ciało swe, a drugie także się zakrywało.
###### **Ez 1,24**
 I słyszałem szum skrzydeł ich, jako głos wód wielkich, jako głos wysokiego Boga: gdy chodziły, był jako głos mnóstwa jako głos obozu: a gdy stały, spuszczały się skrzydła ich.
###### **Ez 1,25**
 Bo gdy był głos na utwierdzeniu, które było nad głową ich, stały i opuszczały skrzydła swe.
###### **Ez 1,26**
 A nad utwierdzeniem, które wisiało nad ich głowami, jako pozór kamienia szafiru, podobieństwo stolice, a na podobieństwie stolice, podobieństwo jako osoba człowiecza na niej.
###### **Ez 1,27**
 I widziałem jako kształt mosiądzu, jako widzenie ognia wewnątrz jego w około: od biodr jego i wyżej, a od biodr jego aż na dół widziałem jako kształt ognia błyszczącego w około.
###### **Ez 1,28**
 Jako widzenie tęcze, gdy bywa na obłoku w dzień dżdżu, takie było widzenie blasku w około. (2,1a) To widzenie podobieństwa chwały Pańskiej, i widziałem i upadłem na oblicze swe, i usłyszałem głos mówiącego,
