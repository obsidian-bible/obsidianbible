# 1Kor 9 BT5
###### **1Kor 9,1**
 Czyż nie jestem wolny? Czy nie jestem apostołem? Czyż nie widziałem Jezusa, Pana naszego? Czyż nie jesteście moim dziełem w Panu?
###### **1Kor 9,2**
 Jeżeli nawet nie jestem apostołem dla innych, dla was na pewno nim jestem. Albowiem wy jesteście pieczęcią mego apostołowania w Panu.
###### **1Kor 9,3**
 Oto moja obrona wobec tych, którzy mnie potępiają.
###### **1Kor 9,4**
 Czyż nie mamy prawa skorzystać z jedzenia i picia?
###### **1Kor 9,5**
 Czyż nie wolno nam brać ze sobą niewiasty - siostry, podobnie jak to czynią pozostali apostołowie oraz bracia Pańscy i Kefas?
###### **1Kor 9,6**
 Czy tylko mnie samemu i Barnabie nie wolno nie zarobkować?
###### **1Kor 9,7**
 Czy ktoś pełni kiedykolwiek służbę żołnierską, pozostając na własnym żołdzie? Albo czy ktoś uprawia winnicę i nie spożywa z jej owoców? Lub czy pasie ktoś trzodę, a nie posila się jej mlekiem?
###### **1Kor 9,8**
 Czyż mówię to tylko na zwykły ludzki sposób? Czy nie wspomina o tym także Prawo?
###### **1Kor 9,9**
 Napisane jest właśnie w Prawie Mojżesza: Nie zawiążesz pyska wołowi młócącemu. Czyż o woły troszczy się Bóg,
###### **1Kor 9,10**
 czy też powiedział to przede wszystkim ze względu na nas? Bo przecież ze względu na nas zostało napisane, iż oracz ma orać w nadziei, a młocarz – [młócić] w nadziei, że będzie miał coś z tego.
###### **1Kor 9,11**
 Jeżeli więc my zasialiśmy wam dobra duchowe, to cóż wielkiego, że uczestniczymy w żniwie waszych dóbr doczesnych?
###### **1Kor 9,12**
 Jeżeli inni mają udział w waszej majętności, to czemuż raczej nie my? Nie korzystaliśmy jednak z tej możliwości, lecz znosimy wszystko, byle nie stawiać żadnych przeszkód Ewangelii Chrystusowej.
###### **1Kor 9,13**
 Czyż nie wiecie, że ci, którzy trudzą się około ofiar, żywią się ze świątyni, a ci, którzy posługują przy ołtarzu, mają udział w [ofiarach] ołtarza?
###### **1Kor 9,14**
 Tak też i Pan postanowił, ażeby z Ewangelii żyli ci, którzy głoszą Ewangelię.
###### **1Kor 9,15**
 Lecz ja z żadnego z tych praw nie skorzystałem. Piszę zaś to, nie żeby coś osiągnąć w ten sposób. Wolałbym raczej umrzeć niż... Nikt mnie nie pozbawi mojej chluby.
###### **1Kor 9,16**
 Nie jest dla mnie powodem do chluby to, że głoszę Ewangelię. Świadom jestem ciążącego na mnie obowiązku. Biada mi bowiem, gdybym nie głosił Ewangelii!
###### **1Kor 9,17**
 Gdybym to czynił z własnej woli, miałbym zapłatę, lecz jeśli działam nie z własnej woli, to tylko spełniam obowiązki szafarza.
###### **1Kor 9,18**
 Jakąż przeto mam zapłatę? Otóż tę właśnie, że głosząc Ewangelię bez żadnej zapłaty, nie korzystam z praw, jakie mi daje Ewangelia.
###### **1Kor 9,19**
 Tak więc nie zależąc od nikogo, stałem się niewolnikiem wszystkich, aby tym liczniejsi byli ci, których pozyskam.
###### **1Kor 9,20**
 Stałem się jak Żyd – dla Żydów, aby pozyskać Żydów. Dla tych, co podlegają Prawu, byłem jak ten, który jest pod Prawem – choć w rzeczywistości nie byłem pod Prawem – by pozyskać tych, co pozostawali pod Prawem.
###### **1Kor 9,21**
 Dla zwolnionych od Prawa byłem jako nie podlegający Prawu – nie będąc zresztą wolnym od prawa Bożego, lecz podlegając prawu Chrystusowemu – by pozyskać tych, którzy nie są pod Prawem.
###### **1Kor 9,22**
 Dla słabych stałem się jak słaby, by pozyskać słabych. Stałem się wszystkim dla wszystkich, żeby uratować choć niektórych.
###### **1Kor 9,23**
 Wszystko zaś czynię dla Ewangelii, by mieć w niej swój udział.
###### **1Kor 9,24**
 Czyż nie wiecie, że gdy zawodnicy biegną na stadionie, wszyscy wprawdzie biegną, lecz jeden tylko otrzymuje nagrodę? Przeto tak biegnijcie, abyście ją otrzymali.
###### **1Kor 9,25**
 Każdy, kto staje do zapasów, wszystkiego sobie odmawia; oni, aby zdobyć przemijającą nagrodę, my zaś – nieprzemijającą.
###### **1Kor 9,26**
 Ja przeto biegnę nie jakby na oślep; walczę nie tak, jakby zadając ciosy w próżnię –
###### **1Kor 9,27**
 lecz poskramiam moje ciało i biorę je w niewolę, abym innym głosząc naukę, sam przypadkiem nie został uznany za niezdatnego.
# 1Kor 9 PAU
###### **1Kor 9,1**
 Czy nie jestem wolny? Czy nie jestem apostołem? Czy nie widziałem Jezusa, naszego Pana? A wy, czyż nie jesteście moim dziełem dla Pana?
###### **1Kor 9,2**
 Nawet jeśli dla innych nie jestem apostołem, to dla was nim jestem, bo wy jesteście pieczęcią mojego apostołowania w Panu.
###### **1Kor 9,3**
 Taka jest moja obrona przed tymi, którzy mnie oceniają:
###### **1Kor 9,4**
 Czy naprawdę nie mamy prawa do jedzenia i picia?
###### **1Kor 9,5**
 Czy naprawdę nie mamy prawa podróżować z siostrą, jak to czynią inni apostołowie, bracia Pana i Kefas?
###### **1Kor 9,6**
 Czy tylko ja i Barnaba mamy obowiązek pracować na swoje utrzymanie?
###### **1Kor 9,7**
 Czy ktoś kiedykolwiek służył w wojsku na własny koszt? Kto sadzi winnicę i nie zjada z niej owoców? Albo kto pasie owce, a nie żywi się ich mlekiem?
###### **1Kor 9,8**
 Ja mówię o tym tylko po ludzku, ale czy i Prawo o tym nie mówi?
###### **1Kor 9,9**
 W Prawie Mojżesza napisano: Nie zawiążesz pyska wołowi młócącemu. Czy o woły troszczy się Bóg?
###### **1Kor 9,10**
 Czy nie mówi tego ze względu na nas? To właśnie ze względu na nas napisano, że ten, co orze i młóci, pracuje w nadziei, że będzie miał w tym swój udział.
###### **1Kor 9,11**
 Jeżeli posialiśmy wam dobra duchowe, to cóż wielkiego, że zbieramy z waszych dóbr materialnych?
###### **1Kor 9,12**
 Skoro inni mają do was takie prawo, czy my nie mamy do tego większego prawa? Nie skorzystaliśmy jednak z tego prawa, lecz wszystko znosimy, aby nie stawiać przeszkód Ewangelii Chrystusa.
###### **1Kor 9,13**
 Czy nie wiecie, że ci, którzy sprawują kult, jedzą ze złożonych ofiar, i ci, co są przy ołtarzu, mają z nich swoją część?
###### **1Kor 9,14**
 Tak również Pan postanowił, że ci, którzy głoszą Ewangelię, z Ewangelii żyją.
###### **1Kor 9,15**
 Ja jednak nie korzystałem z tych przywilejów. I nie piszę o tym, aby coś na tym zyskać! Wolałbym raczej umrzeć niż…. Nikt mnie nie pozbawi mojej chluby.
###### **1Kor 9,16**
 Głoszę bowiem Ewangelię nie dla własnej chluby, ale z nałożonego na mnie obowiązku. Biada mi, gdybym nie głosił Ewangelii!
###### **1Kor 9,17**
 Gdybym głosił ją z własnej woli, miałbym prawo do zapłaty. Jeżeli jednak nie głoszę jej z własnej woli, to wypełniam tylko obowiązek.
###### **1Kor 9,18**
 Jaka jest więc moja zapłata? Taka, że głosząc Ewangelię bez zapłaty, nie korzystam z prawa, jakie mi daje jej głoszenie.
###### **1Kor 9,19**
 Będąc wolny od wszystkich, stałem się niewolnikiem wszystkich, aby pozyskać jak najliczniejszych.
###### **1Kor 9,20**
 Dla Żydów stałem się Żydem, aby ich pozyskać. Chociaż nie podlegam Prawu, to dla tych, którzy podlegają Prawu, stałem się jak ten, który podlega Prawu, aby i tych pozyskać, którzy podlegają Prawu.
###### **1Kor 9,21**
 Dla tych, którzy nie podlegają Prawu, jestem jak ten, który nie podlega Prawu. Ja przestrzegam Prawo Boże, lecz już jako ten, który żyje Prawem Chrystusa, aby pozyskać tych, którzy nie podlegają Prawu.
###### **1Kor 9,22**
 Dla słabych stałem się słaby, aby słabych pozyskać. Dla wszystkich stałem się wszystkim, aby wszelkim sposobem przynajmniej niektórym zapewnić zbawienie.
###### **1Kor 9,23**
 Wszystko przecież czynię dla Ewangelii, abym miał w niej swój udział.
###### **1Kor 9,24**
 Czy nie wiecie, że na stadionie biegną wszyscy zawodnicy, ale tylko jeden z nich otrzymuje nagrodę? Tak biegnijcie, abyście ją zdobyli.
###### **1Kor 9,25**
 Każdy zawodnik podejmuje wiele wyrzeczeń. Tamci, by zdobyć wieniec zniszczalny, my - niezniszczalny.
###### **1Kor 9,26**
 I ja biegnę, ale nie tak, jakbym nie znał mety, i nie wymachuję bezładnie pięściami,
###### **1Kor 9,27**
 ale biorę w karby i opanowuję swoje ciało, abym głosząc innym naukę, sam nie został odrzucony.
# 1Kor 9 BP
###### **1Kor 9,1**
 Czy nie jestem wolny? Czy nie jestem apostołem? Czy nie widziałem Jezusa, Pana naszego? Czy wy nie jesteście moim dziełem w Panu?
###### **1Kor 9,2**
 Jeśli nawet dla innych nie jestem apostołem, to dla was na pewno nim jestem. Wy jesteście pieczęcią mego urzędu apostolskiego w Panu.
###### **1Kor 9,3**
 Oto moja obrona wobec tych, którzy wysuwają przeciwko mnie zarzuty.
###### **1Kor 9,4**
 Czy nie mamy prawa do utrzymania przez was?
###### **1Kor 9,5**
 Czy nie wolno nam zabrać ze sobą siostry, kobiety, podobnie jak czynią to pozostali apostołowie oraz bracia Pana i Kefas?
###### **1Kor 9,6**
 Czy tylko mnie i Barnabie nie wolno zwalniać się od pracy ręcznej?
###### **1Kor 9,7**
 Któż pełni kiedykolwiek służbę żołnierską na własny koszt? Kto uprawia winnicę, a nie kosztuje jej owocu? Albo kto pasie trzodę i nie kosztuje mleka, które trzoda daje?
###### **1Kor 9,8**
 Czy mówię tylko o tym według ludzkiego sposobu myślenia? Czy nie wspomina o tym również Prawo?
###### **1Kor 9,9**
 Otóż w Prawie Mojżesza jest napisane: "Nie zawiążesz pyska młócącemu wołowi". Czy Bóg, który to powiedział, troszczy się o woły?
###### **1Kor 9,10**
 Czy też wypowiedział to ze względu na nas? Przecież nas ma na uwadze [Pismo Święte], kiedy pisze, że z nadzieją zysku ma rolnik orać, a młócący młócić.
###### **1Kor 9,11**
 Jeżeli zasialiśmy wśród was dobra duchowe, to cóż w tym wielkiego, że mamy udział w plonach waszych dóbr materialnych?
###### **1Kor 9,12**
 Jeżeli innym wolno domagać się, abyście ich utrzymywali, to tym bardziej to nam przysługuje. Nie skorzystaliśmy jednak z tej możliwości, lecz sami ponosimy cały ciężar utrzymywania, aby nie stwarzać żadnej przeszkody dobrej nowinie Chrystusa.
###### **1Kor 9,13**
 Czy nie wiecie, że ci, którzy sprawują święte obrzędy, żywią się na koszt świątyni, a ci, którzy służą ołtarzowi, mają udział w ofiarach składanych na ołtarzu?
###### **1Kor 9,14**
 Tak samo i Pan postanowił, aby ci, którzy głoszą dobrą nowinę, żyli z głoszenia dobrej nowiny.
###### **1Kor 9,15**
 Ja nie skorzystałem jednak z żadnego z tych praw. Nie piszę również o tych sprawach dlatego, aby coś tą drogą osiągnąć. Wolałbym raczej umrzeć, niż... Nikt nie pozbawi mnie mojej chluby.
###### **1Kor 9,16**
 Fakt, że głoszę ewangelię, nie jest dla mnie powodem do chluby. Jest to obowiązek, który został na mnie nałożony. Biada mi, gdybym nie głosił ewangelii.
###### **1Kor 9,17**
 Gdybym czynił to z własnej woli, otrzymałbym zapłatę. Jeśli jednak nie czynię tego z własnej woli, to znaczy, że spełniam tylko powierzone mi czynności szafarza.
###### **1Kor 9,18**
 Za co wobec tego przysługuje mi zapłata? Otóż za to, że głosząc ewangelię bez wynagrodzenia, nie korzystam z przysługujących mi stąd praw.
###### **1Kor 9,19**
 Chociaż jestem od nikogo niezależny, to jednak stałem się niewolnikiem wszystkich, abym ich jak najwięcej pozyskał.
###### **1Kor 9,20**
 Dla Żydów stałem się Żydem, aby ich pozyskać. Dla tych, którzy zachowują Prawo [starotestamentalne], i ja wypełniam to Prawo - chociaż mu nie podlegam - aby ich pozyskać.
###### **1Kor 9,21**
 Dla tych, którzy nie kierują się tym Prawem, i ja się do niego nie stosuję - chociaż nie jestem wolny od Prawa Bożego, bo podlegam Prawu Chrystusa - aby ich pozyskać.
###### **1Kor 9,22**
 Dla słabych stałem się słaby, aby ich pozyskać. Dla wszystkich stałem się wszystkim, aby chociaż niektórych zbawić.
###### **1Kor 9,23**
 Wszystko to zaś czynię dla ewangelii, aby mieć w niej swój udział.
###### **1Kor 9,24**
 Czy nie wiecie, że chociaż na stadionie biegną wszyscy zawodnicy, to jednak tylko jeden otrzymuje nagrodę. Dlatego tak biegnijcie, abyście ją osiągnęli!
###### **1Kor 9,25**
 Każdy, kto bierze udział w zawodach sportowych, odmawia sobie wszystkiego. Oni walczą, aby otrzymać w nagrodę wieniec, który przemija, a my walczymy o nagrodę nie przemijającą.
###### **1Kor 9,26**
 Ja więc nie biegnę na oślep, a kiedy uderzam, nie trafiam w próżnię,
###### **1Kor 9,27**
 lecz poskramiam i ujarzmiam moje ciało, abym nauczając innych sam nie odpadł [w zawodach].
# 1Kor 9 BR
###### **1Kor 9,1**
 Czyż nie jestem wolny? Czyż nie jestem apostołem? Czyż nie widziałem Jezusa, Pana mojego? Czyż nie jesteście moim dziełem w Panu?
###### **1Kor 9,2**
 Jeżeli nawet nie jestem apostołem dla innych, dla was na pewno nim jestem. Albowiem wy jesteście pieczęcią mego apostołowania w Panu.
###### **1Kor 9,3**
 Oto moja obrona wobec tych, którzy mnie potępiają.
###### **1Kor 9,4**
 Czyż nie mamy prawa skorzystać z jedzenia i picia?
###### **1Kor 9,5**
 Czyż nie wolno nam brać ze sobą niewiasty-siostry, podobnie jak to czynią pozostali apostołowie oraz bracia Pańscy i Kefas?
###### **1Kor 9,6**
 Czy tylko mnie samemu i Barnabie nie wolno nie zarobkować?
###### **1Kor 9,7**
 Czy ktoś pełni kiedykolwiek służbę żołnierską pozostając na własnym żołdzie? Albo czy ktoś uprawia winnicę i nie spożywa z jej owoców? Lub czy pasie ktoś trzodę, a nie posila się jej mlekiem?
###### **1Kor 9,8**
 Czyż mówię to tylko na zwykły ludzki sposób? Czy nie wspomina o tym także Prawo?
###### **1Kor 9,9**
 Napisane jest właśnie w Prawie Mojżesza: Nie zawiążesz pyska wołowi młócącemu. Czyż o woły troszczy się Bóg,
###### **1Kor 9,10**
 czy też powiedział to przede wszystkim ze względu na nas? Bo przecież ze względu na nas zostało napisane, iż oracz ma orać w nadziei, a młocarz - [młócić] ufając, że będzie miał coś z tego.
###### **1Kor 9,11**
 Jeżeli więc my zasialiśmy wam dobra duchowe, to cóż wielkiego, że uczestniczymy w żniwie waszych dóbr doczesnych?
###### **1Kor 9,12**
 Jeżeli inni mają udział w waszej majętności, to czemuż raczej nie my? Nie korzystaliśmy jednak z tej możności, lecz znosimy wszystko, byle nie stwarzać żadnych przeszkód Ewangelii Chrystusowej.
###### **1Kor 9,13**
 Czyż nie wiecie, że ci, którzy trudzą się około ofiar, żywią się ze świątyni, a ci, którzy posługują przy ołtarzu, mają udział w [ofiarach] ołtarza?
###### **1Kor 9,14**
 Tak też i Pan postanowił, ażeby z Ewangelii żyli ci, którzy głoszą Ewangelię.
###### **1Kor 9,15**
 Lecz ja z żadnego z tych praw nie skorzystałem. Piszę zaś to, nie żeby coś osiągnąć w ten sposób. Wolałbym raczej umrzeć, niż... Nikt mnie nie pozbawi mojej chluby.
###### **1Kor 9,16**
 Nie jest dla mnie powodem do chluby to, że głoszę Ewangelię. Świadom jestem ciążącego na mnie obowiązku. Biada mi, gdybym nie głosił Ewangelii!
###### **1Kor 9,17**
 Gdybym to czynił z własnej woli, miałbym zapłatę, lecz jeśli działam nie z własnej woli, to tylko spełniam obowiązki szafarza.
###### **1Kor 9,18**
 Jakąż przeto mam zapłatę? Otóż tę właśnie, że głosząc Ewangelię bez żadnej zapłaty, nie korzystam z praw, jakie mi daje Ewangelia.
###### **1Kor 9,19**
 Tak więc nie zależąc od nikogo, stałem się niewolnikiem wszystkich, aby tym liczniejsi byli ci, których pozyskam.
###### **1Kor 9,20**
 Stałem się jak Żyd - dla Żydów, aby pozyskać Żydów. Dla tych, co są pod Prawem, byłem jak ten, który jest pod Prawem - choć w rzeczywistości nie byłem pod Prawem - by pozyskać tych, co pozostawali pod Prawem.
###### **1Kor 9,21**
 Dla zwolnionych od Prawa byłem jako nie podlegający Prawu - nie będąc zresztą wolnym od prawa Bożego, lecz podlegając prawu Chrystusowemu - by pozyskać tych, którzy nie są pod Prawem.
###### **1Kor 9,22**
 Dla słabych stałem się jak słaby, by pozyskać słabych. Stałem się wszystkim dla wszystkich, aby uratować za wszelką cenę choć niektórych.
###### **1Kor 9,23**
 Wszystko zaś czynię dla Ewangelii, by mieć w niej swój udział.
###### **1Kor 9,24**
 Czyż nie wiecie, że gdy zawodnicy biegną na stadionie, wszyscy wprawdzie biegną, lecz jeden tylko otrzymuje nagrodę? Przeto tak biegnijcie, abyście ją otrzymali.
###### **1Kor 9,25**
 Każdy, który staje do zapasów, wszystkiego sobie odmawia; oni, aby zdobyć przemijającą nagrodę, my zaś - nieprzemijającą.
###### **1Kor 9,26**
 Ja przeto biegnę nie jakby na oślep; walczę nie tak, jakby zadając ciosy w próżnię,
###### **1Kor 9,27**
 lecz poskramiam moje ciało i biorę je w niewolę, abym innym głosząc naukę, sam przypadkiem nie został uznany za niezdatnego.
# 1Kor 9 WUJ
###### **1Kor 9,1**
 Nie jestem wolnym, nie jestem Apostołem: Izalim Chrystusa Jezusa Pana naszego nie widział? Izali wy nie jesteście robota moja w Panu.
###### **1Kor 9,2**
 A jeśli innym nie jestem Apostołem: a wszakże wam jestem. Abowiem pieczęć Apostolstwa mego wy jesteście w Panu.
###### **1Kor 9,3**
 Obrona moja u tych, którzy mię pytają ta jest:
###### **1Kor 9,4**
 Izali nie mamy wolności jeść i pić?
###### **1Kor 9,5**
 Izali nie mamy wolności wodzić się z siostrą niewiastą, jako i drudzy Apostołowie, i bracia Pańscy i Cephas?
###### **1Kor 9,6**
 Czyli ja sam i Barnabasz nie mamy wolności tego czynić?
###### **1Kor 9,7**
 Kto kiedy żołnierską swym kosztem służy?" kto sadzi winnicę: a z owocu jej nie pożywa?
###### **1Kor 9,8**
 Kto trzodę pasie: a mleka trzody nie pożywa?
###### **1Kor 9,9**
 Izali według człowieka to mówię? Izali też zakan tego nie mówi? Abowiem w zakonie Mojżeszowym napisano jest: Nie zawiążesz gęby wołowi młócącemu. IzaliBóg o wolech pieczą ma?
###### **1Kor 9,10**
 Czyli koniecznie dla nas mówi? Abowiem dla nas jest napisano: iż w nadziei ma orać co orze: a który młóci w nadzieję wzięcia pożytku.
###### **1Kor 9,11**
 Jeśli my wam duchowneśmy rzeczy siali, wielka rzecz jest, jeślibyśmy wasze cielesne żęli?
###### **1Kor 9,12**
 Jeśli inszy mocy nad wami są uczestnikami, czemu nie raczej my? Lecześmy tej mocy nie używali: ale wszystko znaszamy, abyśmy jakiej przeszkody Ewanieljej Chrystusowej nie dali.
###### **1Kor 9,13**
 Nie wiecie, iż którzy w śwtątnicy robią, co jest z swiątnice jedzą: a którzy ołtarzowi usługują, uczestnikami są ołtarza?
###### **1Kor 9,14**
 Tak też Pan postanowił tym, którzy Ewanielią opowiadają, aby z Ewanieljej żyli.
###### **1Kor 9,15**
 A jam żadnej z tych rzeczy nie używał. I nie pisałem tego, aby się tak zemną stało: bo mnie lepiej umrzeć, niżby kto pochwałę maję miał wyniszczyć.
###### **1Kor 9,16**
 Bo jeśli Ewanielią będę opowiadał, nie mam chluby: bo mię potrzeba przyciska: abowiem biada mnie, jeśli bym Ewanieljej nie przepowiadał.
###### **1Kor 9,17**
 Bo jeśli to dobrowolnie czynię, mam zapłatę. Lecz jeśli poniewolnie, szafarstwa mi zwierzono.
###### **1Kor 9,18**
 Któraż tedy moja jest zapłata? Abych opowiadając Ewanielią, bez nakładu wystawił Ęwanielią, żebych wolności mojej źle nie używał w Ewanieljej.
###### **1Kor 9,19**
 Abowiem będąc wolnym od wszystkich, uczyniłem się niewolnikiem wszystkich, abych ich więcej pozyskał.
###### **1Kor 9,20**
 I stałem się Żydom jako Żyd, abych Żydy pozyskał.
###### **1Kor 9,21**
 Tym co pod zakonem są, jakobych był pod zakonem (chociam sam nie był pod zakonem), abym te co pod zakonem byli pozyskał. Tym, którzy byli bez zakonu, jakobym był bez zakonu (chociam nie był bez zakonu Bożego, alem był w zakonie Chrystusowym), abym pozyskał tych, którzy byli bez zakonu.
###### **1Kor 9,22**
 Stałem się mdły: abych mdłych pozyskał. Wszystkim stałem się wszystko: abym wszystkie zbawił.
###### **1Kor 9,23**
 A wszystko czynię dla Ewanieljej: abym się stał jej uczestnikiem.
###### **1Kor 9,24**
 Nie wiecie, iż ci, którzy w zawód biegają, acz wszyscy bieżą, ale jeden zakład bierze? Tak bieżcie, abyście otrzymali.
###### **1Kor 9,25**
 A każdy, który się potyka na placu od wszystkiego się powściąga. A onić, aby wzięli wieniec skazitelny: a my nieskazitelny.
###### **1Kor 9,26**
 A. ja tedy tak bieżę, nie jako na niepewną: tak szermuję, nie jako wiatr. bijąc:
###### **1Kor 9,27**
 Ale karzę ciało moje, i w niewolą podbijam, bym snadź inszym przepowiadając, sam się nie stał odrzuconym.
# 1Kor 9 STERN
###### **1Kor 9,1**
 Czyż nie jestem wolnym człowiekiem? Czy nie jestem wysłannikiem Mesjasza? Czym nie widział Jeszui, naszego Pana? I czy wy sami nie jesteście skutkiem mojej pracy dla Pana?
###### **1Kor 9,2**
 Nawet jeśli dla innych nie jestem wysłannikiem, to w każdym razie jestem nim dla was; bo stanowicie żywy dowód, że jestem wysłannikiem Pana.
###### **1Kor 9,3**
 Oto moja obrona, gdy mnie ludzie badają.
###### **1Kor 9,4**
 Czy nie mamy prawa korzystać z jedzenia i picia?
###### **1Kor 9,5**
 Czy nie mamy prawa zabierać z sobą wierzącej żony, jak to robią pozostali wysłannicy, w tym bracia Pana i Kefa?
###### **1Kor 9,6**
 A może Bar-Nabba i ja jako jedyni mamy obowiązek zarabiać na swoje utrzymanie?
###### **1Kor 9,7**
 Słyszeliście kiedy o żołnierzu, który sam sobie płaci żołd? Albo o rolniku, który zasadza winnicę i nie spożywa z jej owocu? Kto pasie stada, nie pijąc z ich mleka?
###### **1Kor 9,8**
 To, co mówię, opiera się nie tylko na autorytecie ludzkim, bo i Tora powiada to samo -
###### **1Kor 9,9**
 w Torze Moszego napisano bowiem: "Nie zawiążesz pyska wołu, kiedy młóci zboże". Jeśli Bóg troszczy się o bydło,
###### **1Kor 9,10**
 tym bardziej powie to samo o was. Tak jest, zostało to napisane dla nas i oznacza, że ten, kto orze, i ten, kto młóci, powinni pracować, licząc na udział w plonach.
###### **1Kor 9,11**
 Jeśli posialiśmy wśród was duchowe ziarno, czy będzie to zbyt wiele, jeśli zbierzemy od was plon materialny?
###### **1Kor 9,12**
 Jeśli inni mają udział w tym prawie do waszego wsparcia, czyż my nie mamy do niego większego prawa? Ale z prawa tego nie korzystamy. Znosimy raczej najrozmaitsze rzeczy, aby tylko w żaden sposób nie przeszkadzać Dobrej Nowinie o Mesjaszu.
###### **1Kor 9,13**
 Czy nie wiecie, że ci, którzy pracują w Świątyni, otrzymują żywność ze Świątyni, a ci, którzy służą przy ołtarzu, otrzymują udział w składanych tam ofiarach?
###### **1Kor 9,14**
 Tak samo Pan polecił, aby ci, którzy głoszą Dobrą Nowinę, z Dobrej Nowiny się utrzymywali.
###### **1Kor 9,15**
 Ja jednak nie skorzystałem z żadnego z tych praw. Nie piszę też teraz po to, aby je sobie zabezpieczyć, bo wolałbym raczej umrzeć, niż zostać pozbawionym podstawy do chlubienia się!
###### **1Kor 9,16**
 Bo nie mogę się chlubić tym jedynie, że głoszę Dobrą Nowinę - robię to z wewnętrznego przymusu: biada mi, gdybym nie głosił Dobrej Nowiny!
###### **1Kor 9,17**
 Bo jeśli robię to chętnie, to mam nagrodę; lecz jeśli robię to niechętnie, to i tak to robię, powierzono mi bowiem zadanie.
###### **1Kor 9,18**
 Co jest zatem moją nagrodą? To oto, że głosząc Dobrą Nowinę, mogę ją udostępniać za darmo, nie korzystając z praw, które mi ona przyznaje.
###### **1Kor 9,19**
 Bo choć jestem wolnym człowiekiem, niezwiązanym niczyimi rozkazami, to uczyniłem siebie niewolnikiem wszystkich, ażeby pozyskać tylu, ilu tylko można.
###### **1Kor 9,20**
 Czyli dla Żydów postawiłem się w położeniu Żyda, aby pozyskać Żydów. Dla ludzi poddanych legalistycznemu wypaczeniu Tory postawiłem się w położeniu osoby poddanej takiemu legalizmowi, aby pozyskać poddanych temu legalizmowi, mimo że sam nie jestem poddany legalistycznemu wypaczeniu Tory.
###### **1Kor 9,21**
 Dla tych, którzy żyją poza porządkiem Tory, postawiłem się w położeniu człowieka poza porządkiem Tory, aby pozyskać tych poza porządkiem Tory - sam nie będąc jednak poza porządkiem Bożej Tory, lecz w ramach porządku Tory, której moc nadaje Mesjasz.
###### **1Kor 9,22**
 Dla "słabych" stałem się "słaby", aby pozyskać "słabych". Stałem się dla wszelakiego rodzaju ludzi wszelakimi rzeczami, ażebym we wszelakich okolicznościach mógł zbawić przynajmniej niektórych.
###### **1Kor 9,23**
 A robię to wszystko przez wzgląd na nagrody obiecane przez Dobrą Nowinę, abym miał w nich udział wraz z pozostałymi, którzy zaufają.
###### **1Kor 9,24**
 Czy nie wiecie, że w wyścigu współzawodniczą wszyscy biegacze, ale tylko jeden zdobywa nagrodę? Biegnijcie więc tak, by wygrać!
###### **1Kor 9,25**
 Otóż każdy atleta, trenując, poddaje się surowym rygorom, a czyni to, aby zdobyć wieniec laurowy, który rychło zwiędnie. My jednak robimy to, aby zdobyć koronę, która trwa na wieki.
###### **1Kor 9,26**
 Dlatego nie biegnę bez celu, ale prosto ku mecie; nie zadaję ciosów w próżnię, ale staram się trafiać za każdym razem.
###### **1Kor 9,27**
 Traktuję swe ciało surowo i czynię je swym niewolnikiem, abym ogłosiwszy Dobrą Nowinę innym, sam nie został zdyskwalifikowany.
# 1Kor 9 TRO
###### **1Kor 9,1**
 **ουκ** *ouk* Nie [[G3756]] [[PRT-N]] **ειμι** *eimi* jestem [[G1510]] WTV-PXI-1S **αποστολος** *apostolos* wysłannik [[G652]] [[N-NSM]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ειμι** *eimi* jestem [[G1510]] WTV-PXI-1S **ελευθερος** *eleutheros* wolny [[G1658]] [[A-NSM]] **ουχι** *ouchi* czyż nie [[G3780]] WTPRT-I **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]] **χριστον** *christon* Pomazańca [[G5547]] [[N-ASM]] **τον** *ton* [[G3588]] [[T-ASM]] **κυριον** *kyrion* Pana [[G2962]] [[N-ASM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **εωρακα** *heōraka* widziałem [[G3708]] WTV-RAI-1S-ATT **ου** *ou* nie [[G3756]] [[PRT-N]] **το** *to* [[G3588]] WTT-NSN **εργον** *ergon* dzieło [[G2041]] WTN-NSN **μου** *mou* moje [[G3450]] WTP-1GS **υμεις** *hymeis* wy [[G5210]] WTP-2NP **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM
###### **1Kor 9,2**
 **ει** *ei* Jeśli [[G1487]] WTCOND **αλλοις** *allois* (dla) innych [[G243]] WTA-DPM **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ειμι** *eimi* jestem [[G1510]] WTV-PXI-1S **αποστολος** *apostolos* wysłannik [[G652]] [[N-NSM]] **αλλα** *alla* ale [[G235]] [[CONJ]] **γε** *ge* rzeczywiście – prawdziwie [[G1065]] WTPRT **υμιν** *hymin* wam [[G5213]] WTP-2DP **ειμι** *eimi* jestem [[G1510]] WTV-PXI-1S **η** *hē* [[G3588]] [[T-NSF]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **σφραγις** *sfragis* pieczęć [[G4973]] [[N-NSF]] **της** *tēs* [[G3588]] [[T-GSF]] **εμης** *emēs* mojego [[G1699]] WTS-1GSF **αποστολης** *apostolēs* wysłannictwa [[G651]] [[N-GSF]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM
###### **1Kor 9,3**
 **η** *hē* [[G3588]] [[T-NSF]] **εμη** *emē* Moja [[G1699]] WTS-1NSF **απολογια** *apologia* obrona [[G627]] [[N-NSF]] **τοις** *tois* (przed) [[G3588]] WTT-DPM **εμε** *eme* mnie [[G1691]] WTP-1AS **ανακρινουσιν** *anakrinousin* osądzającymi [[G350]] WTV-PAP-DPM **αυτη** *autē* ta [[G3778]] WTD-NSF **εστιν** *estin* jest [[G2076]] WTV-PXI-3S
###### **1Kor 9,4**
 **μη** *mē* Nie [[G3361]] [[PRT-N]] **ουκ** *ouk* [[G3756]] [[PRT-N]] **εχομεν** *echomen* mamy [[G2192]] WTV-PAI-1P **εξουσιαν** *eksousian* prawa – władzy [[G1849]] WTN-ASF **φαγειν** *fagein* zjeść [[G5315]] [[V-2AAN]] **και** *kai* i [[G2532]] [[CONJ]] **πιειν** *piein* wypić [[G4095]] [[V-2AAN]]
###### **1Kor 9,5**
 **μη** *mē* Nie [[G3361]] [[PRT-N]] **ουκ** *ouk* [[G3756]] [[PRT-N]] **εχομεν** *echomen* mamy [[G2192]] WTV-PAI-1P **εξουσιαν** *eksousian* prawa – władzy [[G1849]] WTN-ASF **αδελφην** *adelfēn* siostry [[G79]] WTN-ASF **γυναικα** *gynaika* żony – kobiety [[G1135]] WTN-ASF **περιαγειν** *periagein* brać ze sobą [[G4013]] WTV-PAN **ως** *hōs* jak [[G5613]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **λοιποι** *loipoi* pozostali [[G3062]] WTA-NPM **αποστολοι** *apostoloi* wysłannicy [[G652]] WTN-NPM **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **αδελφοι** *adelfoi* bracia [[G80]] WTN-NPM **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **κηφας** *kēfas* Kefas – [skała] [[G2786]] [[N-NSM]]
###### **1Kor 9,6**
 **η** *ē* Czy [[G2228]] WTPRT **μονος** *monos* sam [[G3441]] [[A-NSM]] **εγω** *egō* ja [[G1473]] WTP-1NS **και** *kai* i [[G2532]] [[CONJ]] **βαρναβας** *barnabas* Barnaba – [syn pocieszenia] [[G921]] [[N-NSM]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εχομεν** *echomen* mamy [[G2192]] WTV-PAI-1P **εξουσιαν** *eksousian* prawa – władzy [[G1849]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **μη** *mē* nie [[G3361]] [[PRT-N]] **εργαζεσθαι** *ergazesthai* pracować [[G2038]] WTV-PNN
###### **1Kor 9,7**
 **τις** *tis* Kto [[G5101]] WTI-NSM **στρατευεται** *strateuetai* bierze udział w wojnie – pełni służbę żołnierską [[G4754]] WTV-PMI-3S **ιδιοις** *idiois* (na) własne [[G2398]] WTA-DPM **οψωνιοις** *opsōniois* koszty – żołdy [[G3800]] WTN-DPN **ποτε** *pote* przedtem – kiedykolwiek [[G4218]] WTPRT **τις** *tis* kto [[G5101]] WTI-NSM **φυτευει** *fyteuei* sadzi [[G5452]] WTV-PAI-3S **αμπελωνα** *ampelōna* winnicę [[G290]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **καρπου** *karpou* owocu [[G2590]] [[N-GSM]] **αυτου** *autou* jej [[G846]] [[P-GSM]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εσθιει** *esthiei* je [[G2068]] WTV-PAI-3S **η** *ē* lub [[G2228]] WTPRT **τις** *tis* kto [[G5101]] WTI-NSM **ποιμαινει** *poimainei* pasie [[G4165]] WTV-PAI-3S **ποιμνην** *poimnēn* stado – trzodę [[G4167]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **γαλακτος** *galaktos* mleka [[G1051]] [[N-GSN]] **της** *tēs* [[G3588]] [[T-GSF]] **ποιμνης** *poimnēs* stada – trzody [[G4167]] [[N-GSF]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εσθιει** *esthiei* je [[G2068]] WTV-PAI-3S
###### **1Kor 9,8**
 **μη** *mē* Czy [[G3361]] [[PRT-N]] **κατα** *kata* według [[G2596]] [[PREP]] **ανθρωπον** *anthrōpon* człowieka [[G444]] [[N-ASM]] **ταυτα** *tauta* te [[G5023]] WTD-APN **λαλω** *lalō* mówię [[G2980]] WTV-PAI-1S **η** *ē* lub [[G2228]] WTPRT **ουχι** *ouchi* czyż nie [[G3780]] WTPRT-I **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **νομος** *nomos* Prawo [[G3551]] [[N-NSM]] **ταυτα** *tauta* te [[G5023]] WTD-APN **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S
###### **1Kor 9,9**
 **εν** *en* W [[G1722]] [[PREP]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **τω** *tō* [[G3588]] WTT-DSM **μωσεως** *mōseōs* Mojżesza – [wyciągnąć] [[G3475]] [[N-GSM]] **νομω** *nomō* Prawie [[G3551]] WTN-DSM **γεγραπται** *gegraptai* jest napisane [[G1125]] WTV-RPI-3S **ου** *ou* nie [[G3756]] [[PRT-N]] **φιμωσεις** *fimōseis* zawiążesz pyska – nałożysz kagańca [[G5392]] WTV-FAI-2S **βουν** *boun* wołowi [[G1016]] [[N-ASM]] **αλοωντα** *aloōnta* młócącemu [[G248]] WTV-PAP-ASM **μη** *mē* czy [[G3361]] [[PRT-N]] **των** *tōn* (o) [[G3588]] WTT-GPM **βοων** *boōn* woły [[G1016]] WTN-GPM **μελει** *melei* troszczy się – martwi się [[G3199]] WTV-PQI-3S **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bóg [[G2316]] WTN-DSM
###### **1Kor 9,10**
 **η** *ē* Czy [[G2228]] WTPRT **δι** *di* z powodu [[G1223]] [[PREP]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **παντως** *pantōs* całkowicie [[G3843]] [[ADV]] **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **δι** *di* z powodu [[G1223]] [[PREP]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εγραφη** *egrafē* zostało napisane [[G1125]] WTV-2API-3S **οτι** *hoti* że [[G3754]] [[CONJ]] **επ** *ep* w [[G1909]] [[PREP]] **ελπιδι** *elpidi* nadziei [[G1680]] [[N-DSF]] **οφειλει** *ofeilei* powinien [[G3784]] WTV-PAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **αροτριων** *arotriōn* orzący [[G722]] [[V-PAP-NSM]] **αροτριαν** *arotrian* orać [[G722]] WTV-PAN **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **αλοων** *aloōn* młócący [[G248]] [[V-PAP-NSM]] **της** *tēs* (w) [[G3588]] [[T-GSF]] **ελπιδος** *elpidos* nadziei [[G1680]] [[N-GSF]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **μετεχειν** *metechein* uczestniczyć [[G3348]] WTV-PAN **επ** *ep* w [[G1909]] [[PREP]] **ελπιδι** *elpidi* nadziei [[G1680]] [[N-DSF]]
###### **1Kor 9,11**
 **ει** *ei* Jeśli [[G1487]] WTCOND **ημεις** *hēmeis* my [[G2249]] WTP-1NP **υμιν** *hymin* wam [[G5213]] WTP-2DP **τα** *ta* [[G3588]] WTT-APN **πνευματικα** *pneumatika* duchowe [[G4152]] WTA-APN **εσπειραμεν** *espeiramen* zasialiśmy [[G4687]] WTV-AAI-1P **μεγα** *mega* wielkie [[G3173]] WTA-NSN **ει** *ei* jeśli [[G1487]] WTCOND **ημεις** *hēmeis* my [[G2249]] WTP-1NP **υμων** *hymōn* wasze [[G5216]] WTP-2GP **τα** *ta* [[G3588]] WTT-APN **σαρκικα** *sarkika* cielesne [[G4559]] WTA-APN **θερισομεν** *therisomen* będziemy żąć [[G2325]] WTV-FAI-1P
###### **1Kor 9,12**
 **ει** *ei* Jeśli [[G1487]] WTCOND **αλλοι** *alloi* inni [[G243]] WTA-NPM **της** *tēs* (w) [[G3588]] [[T-GSF]] **εξουσιας** *eksousias* prawie – władzy [[G1849]] [[N-GSF]] **υμων** *hymōn* waszym [[G5216]] WTP-2GP **μετεχουσιν** *metechousin* uczestniczą [[G3348]] WTV-PAI-3P **ου** *ou* nie [[G3756]] [[PRT-N]] **μαλλον** *mallon* raczej [[G3123]] [[ADV]] **ημεις** *hēmeis* my [[G2249]] WTP-1NP **αλλ** *all* ale [[G235]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εχρησαμεθα** *echrēsametha* posłużyliśmy się – skorzystaliśmy [[G5530]] WTV-ADI-1P **τη** *tē* [[G3588]] WTT-DSF **εξουσια** *eksousia* prawem – władzą [[G1849]] [[N-DSF]] **ταυτη** *tautē* tym [[G3778]] WTD-DSF **αλλα** *alla* ale [[G235]] [[CONJ]] **παντα** *panta* wszystkie [[G3956]] WTA-APN **στεγομεν** *stegomen* wytrzymujemy – znosimy [[G4722]] WTV-PAI-1P **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **εγκοπην** *egkopēn* przeszkody [[G1464]] WTN-ASF **τινα** *tina* jakieś [[G5100]] WTX-ASF **δωμεν** *dōmen* dalibyśmy [[G1325]] WTV-2AAS-1P **τω** *tō* [[G3588]] WTT-DSN **ευαγγελιω** *euangeliō* dobrej nowinie [[G2098]] WTN-DSN **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **1Kor 9,13**
 **ουκ** *ouk* Nie [[G3756]] [[PRT-N]] **οιδατε** *oidate* wiecie [[G1492]] WTV-RAI-2P **οτι** *hoti* że [[G3754]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **τα** *ta* (przy) [[G3588]] WTT-APN **ιερα** *hiera* świętych – poświęconych [[G2413]] WTA-APN **εργαζομενοι** *ergazomenoi* pracujący [[G2038]] WTV-PNP-NPM **εκ** *ek* ze [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **ιερου** *hierou* świątyni [[G2411]] [[N-GSN]] **εσθιουσιν** *esthiousin* jedzą [[G2068]] WTV-PAI-3P **οι** *hoi* (ci) [[G3588]] WTT-NPM **τω** *tō* [[G3588]] WTT-DSN **θυσιαστηριω** *thysiastēriō* ołtarzu [[G2379]] WTN-DSN **προσεδρευοντες** *prosedreuontes* przy będący [[G4332]] WTV-PAP-NPM **τω** *tō* (z) [[G3588]] WTT-DSN **θυσιαστηριω** *thysiastēriō* ołtarza [[G2379]] WTN-DSN **συμμεριζονται** *symmerizontai* mają udział [[G4829]] WTV-PNI-3P
###### **1Kor 9,14**
 **ουτως** *houtōs* Tak [[G3779]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **διεταξεν** *dietaksen* zarządził – rozporządził [[G1299]] [[V-AAI-3S]] **τοις** *tois* (tym) [[G3588]] WTT-DPM **το** *to* [[G3588]] WTT-ASN **ευαγγελιον** *euangelion* dobrą nowinę [[G2098]] WTN-ASN **καταγγελλουσιν** *katangellousin* zwiastującym – głoszącym [[G2605]] WTV-PAP-DPM **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **ευαγγελιου** *euangeliou* dobrej nowiny [[G2098]] [[N-GSN]] **ζην** *zēn* żyć [[G2198]] WTV-PAN
###### **1Kor 9,15**
 **εγω** *egō* Ja [[G1473]] WTP-1NS **δε** *de* zaś [[G1161]] [[CONJ]] **ουδενι** *oudeni* nic [[G3762]] WTA-DSN **εχρησαμην** *echrēsamēn* posłużyłem się – skorzystałem [[G5530]] WTV-ADI-1S **τουτων** *toutōn* (z) tych [[G5130]] WTD-GPN **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εγραψα** *egrapsa* napisałem [[G1125]] WTV-AAI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **ταυτα** *tauta* (o) tych [[G5023]] WTD-APN **ινα** *hina* aby [[G2443]] [[CONJ]] **ουτως** *houtōs* tak [[G3779]] [[ADV]] **γενηται** *genētai* stałoby się [[G1096]] WTV-2ADS-3S **εν** *en* we [[G1722]] [[PREP]] **εμοι** *emoi* mnie [[G1698]] WTP-1DS **καλον** *kalon* dobre – piękne [[G2570]] WTA-NSN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **μοι** *moi* mi [[G3427]] WTP-1DS **μαλλον** *mallon* raczej [[G3123]] [[ADV]] **αποθανειν** *apothanein* umrzeć [[G599]] [[V-2AAN]] **η** *ē* niż [[G2228]] WTPRT **το** *to* (tą) [[G3588]] WTT-ASN **καυχημα** *kauchēma* chlubę [[G2745]] WTN-ASN **μου** *mou* moją [[G3450]] WTP-1GS **ινα** *hina* aby [[G2443]] [[CONJ]] **τις** *tis* kto [[G5100]] WTX-NSM **κενωση** *kenōsē* uczyniłby pustą – pozbawiłby znaczenia [[G2758]] WTV-AAS-3S
###### **1Kor 9,16**
 **εαν** *ean* Jeśli [[G1437]] WTCOND **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ευαγγελιζωμαι** *euangelizōmai* głosiłbym dobrą nowinę [[G2097]] WTV-PMS-1S **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **μοι** *moi* mi [[G3427]] WTP-1DS **καυχημα** *kauchēma* chluba [[G2745]] WTN-NSN **αναγκη** *anagkē* (jako) konieczność – (jako) przymus [[G318]] [[N-NSF]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **μοι** *moi* (na) mnie [[G3427]] WTP-1DS **επικειται** *epikeitai* leży [[G1945]] WTV-PNI-3S **ουαι** *ouai* biada [[G3759]] WTINJ **δε** *de* zaś [[G1161]] [[CONJ]] **μοι** *moi* mi [[G3427]] WTP-1DS **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **εαν** *ean* jeśli [[G1437]] WTCOND **μη** *mē* nie [[G3361]] [[PRT-N]] **ευαγγελιζωμαι** *euangelizōmai* głosiłbym dobrej nowiny [[G2097]] WTV-PMS-1S
###### **1Kor 9,17**
 **ει** *ei* jeśli [[G1487]] WTCOND **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εκων** *hekōn* z własnej woli – ochoczo [[G1635]] [[A-NSM]] **τουτο** *touto* to [[G5124]] WTD-ASN **πρασσω** *prassō* robię – czynię [[G4238]] WTV-PAI-1S **μισθον** *misthon* zapłatę [[G3408]] [[N-ASM]] **εχω** *echō* mam [[G2192]] WTV-PAI-1S **ει** *ei* jeśli [[G1487]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **ακων** *akōn* nieochoczo [[G210]] [[A-NSM]] **οικονομιαν** *oikonomian* zarządzanie sprawami domowymi [[G3622]] WTN-ASF **πεπιστευμαι** *pepisteumai* jest mi powierzone – jestem obdarzony zaufaniem [[G4100]] WTV-RPI-1S
###### **1Kor 9,18**
 **τις** *tis* Jaka [[G5101]] WTI-NSM **ουν** *oun* więc [[G3767]] [[CONJ]] **μοι** *moi* moja [[G3427]] WTP-1DS **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ο** *ho* [[G3588]] [[T-NSM]] **μισθος** *misthos* zapłata [[G3408]] [[N-NSM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **ευαγγελιζομενος** *euangelizomenos* głosząc dobrą nowinę [[G2097]] WTV-PMP-NSM **αδαπανον** *adapanon* darmową – nie obciążoną kosztami [[G77]] WTA-ASN **θησω** *thēsō* położyłbym [[G5087]] WTV-AAS-1S **το** *to* (tę) [[G3588]] WTT-ASN **ευαγγελιον** *euangelion* dobrą nowinę [[G2098]] WTN-ASN **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **μη** *mē* nie [[G3361]] [[PRT-N]] **καταχρησασθαι** *katachrēsasthai* korzystać – użyć [[G2710]] WTV-ADN **τη** *tē* (z) [[G3588]] WTT-DSF **εξουσια** *eksousia* prawa – władzy [[G1849]] [[N-DSF]] **μου** *mou* mojego [[G3450]] WTP-1GS **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **ευαγγελιω** *euangeliō* dobrej nowinie [[G2098]] WTN-DSN
###### **1Kor 9,19**
 **ελευθερος** *eleutheros* Wolny [[G1658]] [[A-NSM]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ων** *ōn* będąc [[G5607]] [[V-PXP-NSM]] **εκ** *ek* od [[G1537]] [[PREP]] **παντων** *pantōn* wszystkich [[G3956]] WTA-GPM **πασιν** *pasin* (dla) wszystkich [[G3956]] WTA-DPM **εμαυτον** *emauton* siebie samego [[G1683]] WTF-1ASM **εδουλωσα** *edoulōsa* uczyniłem niewolnikiem – zniewoliłem [[G1402]] WTV-AAI-1S **ινα** *hina* aby [[G2443]] [[CONJ]] **τους** *tous* [[G3588]] WTT-APM **πλειονας** *pleionas* więcej – liczniejsze (grono) [[G4119]] WTA-APM-C **κερδησω** *kerdēsō* pozyskałbym [[G2770]] WTV-AAS-1S
###### **1Kor 9,20**
 **και** *kai* i [[G2532]] [[CONJ]] **εγενομην** *egenomēn* stałem się [[G1096]] WTV-2ADI-1S **τοις** *tois* (dla) [[G3588]] WTT-DPM **ιουδαιοις** *ioudaiois* Judejczyków – [wielbić] [[G2453]] WTA-DPM **ως** *hōs* jak [[G5613]] [[ADV]] **ιουδαιος** *ioudaios* Judejczyk – [wielbić] [[G2453]] [[A-NSM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **ιουδαιους** *ioudaious* Judejczyków – [wielbić] [[G2453]] WTA-APM **κερδησω** *kerdēsō* pozyskałbym [[G2770]] WTV-AAS-1S **τοις** *tois* (dla tych) [[G3588]] WTT-DPM **υπο** *hypo* pod [[G5259]] [[PREP]] **νομον** *nomon* Prawem [[G3551]] [[N-ASM]] **ως** *hōs* jak [[G5613]] [[ADV]] **υπο** *hypo* pod [[G5259]] [[PREP]] **νομον** *nomon* Prawem [[G3551]] [[N-ASM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **τους** *tous* (tych) [[G3588]] WTT-APM **υπο** *hypo* pod [[G5259]] [[PREP]] **νομον** *nomon* Prawem [[G3551]] [[N-ASM]] **κερδησω** *kerdēsō* pozyskałbym [[G2770]] WTV-AAS-1S
###### **1Kor 9,21**
 **τοις** *tois* (dla) [[G3588]] WTT-DPM **ανομοις** *anomois* niemających Prawa – bezprawnych [[G459]] WTA-DPM **ως** *hōs* jak [[G5613]] [[ADV]] **ανομος** *anomos* niemający Prawa – bezprawny [[G459]] [[A-NSM]] **μη** *mē* nie [[G3361]] [[PRT-N]] **ων** *ōn* będąc [[G5607]] [[V-PXP-NSM]] **ανομος** *anomos* niemającym Prawa – bezprawnym [[G459]] [[A-NSM]] **θεω** *theō* Boga [[G2316]] WTN-DSM **αλλ** *all* ale [[G235]] [[CONJ]] **εννομος** *ennomos* zgodne z Prawem [[G1772]] [[A-NSM]] **χριστω** *christō* Pomazańca [[G5547]] WTN-DSM **ινα** *hina* aby [[G2443]] [[CONJ]] **κερδησω** *kerdēsō* pozyskałbym [[G2770]] WTV-AAS-1S **ανομους** *anomous* niemających Prawa – bezprawnych [[G459]] WTA-APM
###### **1Kor 9,22**
 **εγενομην** *egenomēn* stałem się [[G1096]] WTV-2ADI-1S **τοις** *tois* (dla) [[G3588]] WTT-DPM **ασθενεσιν** *asthenesin* słabych – bezsilnych [[G772]] WTA-DPM **ως** *hōs* jak [[G5613]] [[ADV]] **ασθενης** *asthenēs* słaby – bezsilny [[G772]] [[A-NSM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **τους** *tous* [[G3588]] WTT-APM **ασθενεις** *astheneis* słabych – bezsilnych [[G772]] WTA-APM **κερδησω** *kerdēsō* pozyskałbym [[G2770]] WTV-AAS-1S **τοις** *tois* (dla) [[G3588]] WTT-DPM **πασιν** *pasin* wszystkich [[G3956]] WTA-DPM **γεγονα** *gegona* stałem się [[G1096]] WTV-2RAI-1S **τα** *ta* [[G3588]] WTT-NPN **παντα** *panta* wszystkim [[G3956]] WTA-NPN **ινα** *hina* aby [[G2443]] [[CONJ]] **παντως** *pantōs* przynajmniej – w ogóle [[G3843]] [[ADV]] **τινας** *tinas* niektórych – jakichś [[G5100]] WTX-APM **σωσω** *sōsō* zbawiłbym – uratowałbym [[G4982]] WTV-AAS-1S
###### **1Kor 9,23**
 **τουτο** *touto* To [[G5124]] WTD-ASN **δε** *de* zaś [[G1161]] [[CONJ]] **ποιω** *poiō* czynię [[G4160]] WTV-PAI-1S **δια** *dia* dla – ze względu na [[G1223]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **ευαγγελιον** *euangelion* dobrej nowiny [[G2098]] WTN-ASN **ινα** *hina* aby [[G2443]] [[CONJ]] **συγκοινωνος** *sygkoinōnos* współuczestnik [[G4791]] [[A-NSM]] **αυτου** *autou* jej [[G846]] WTP-GSN **γενωμαι** *genōmai* stałbym się [[G1096]] WTV-2ADS-1S
###### **1Kor 9,24**
 **ουκ** *ouk* Nie [[G3756]] [[PRT-N]] **οιδατε** *oidate* wiecie [[G1492]] WTV-RAI-2P **οτι** *hoti* że [[G3754]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **εν** *en* na [[G1722]] [[PREP]] **σταδιω** *stadiō* stadionie [[G4712]] WTN-DSN **τρεχοντες** *trechontes* biegnący [[G5143]] WTV-PAP-NPM **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **τρεχουσιν** *trechousin* biegną [[G5143]] WTV-PAI-3P **εις** *heis* jeden [[G1520]] [[A-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **λαμβανει** *lambanei* otrzymuje [[G2983]] WTV-PAI-3S **το** *to* [[G3588]] WTT-ASN **βραβειον** *brabeion* nagrodę [[G1017]] WTN-ASN **ουτως** *houtōs* tak [[G3779]] [[ADV]] **τρεχετε** *trechete* biegnijcie [[G5143]] WTV-PAM-2P **ινα** *hina* aby [[G2443]] [[CONJ]] **καταλαβητε** *katalabēte* chwycilibyście – złapalibyście [[G2638]] WTV-2AAS-2P
###### **1Kor 9,25**
 **πας** *pas* Każdy [[G3956]] [[A-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **αγωνιζομενος** *agōnizomenos* walczący [[G75]] WTV-PNP-NSM **παντα** *panta* (od) wszystkiego [[G3956]] WTA-APN **εγκρατευεται** *egkrateuetai* powściąga się – wstrzymuje się [[G1467]] WTV-PNI-3S **εκεινοι** *ekeinoi* tamci [[G1565]] WTD-NPM **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **ουν** *oun* więc [[G3767]] [[CONJ]] **ινα** *hina* aby [[G2443]] [[CONJ]] **φθαρτον** *ftharton* zniszczalny [[G5349]] WTA-ASM **στεφανον** *stefanon* wieniec – koronę [[G4735]] [[N-ASM]] **λαβωσιν** *labōsin* otrzymaliby – wzięliby [[G2983]] WTV-2AAS-3P **ημεις** *hēmeis* my [[G2249]] WTP-1NP **δε** *de* zaś [[G1161]] [[CONJ]] **αφθαρτον** *aftharton* niezniszczalny [[G862]] WTA-ASM
###### **1Kor 9,26**
 **εγω** *egō* Ja [[G1473]] WTP-1NS **τοινυν** *toinyn* zatem [[G5106]] WTPRT **ουτως** *houtōs* tak [[G3779]] [[ADV]] **τρεχω** *trechō* biegnę [[G5143]] WTV-PAI-1S **ως** *hōs* jak [[G5613]] [[ADV]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **αδηλως** *adēlōs* (na) oślep – niepewnie [[G84]] [[ADV]] **ουτως** *houtōs* tak [[G3779]] [[ADV]] **πυκτευω** *pykteuō* boksuję – uderzam pięściami [[G4438]] WTV-PAI-1S **ως** *hōs* jak [[G5613]] [[ADV]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **αερα** *aera* powietrze [[G109]] [[N-ASM]] **δερων** *derōn* uderzający – bijący [[G1194]] [[V-PAP-NSM]]
###### **1Kor 9,27**
 **αλλ** *all* ale [[G235]] [[CONJ]] **υπωπιαζω** *hypōpiazō* biję pod oko – tłukę [[G5299]] WTV-PAI-1S **μου** *mou* moje [[G3450]] WTP-1GS **το** *to* [[G3588]] WTT-ASN **σωμα** *sōma* ciało [[G4983]] WTN-ASN **και** *kai* i [[G2532]] [[CONJ]] **δουλαγωγω** *doulagōgō* biorę w niewolę [[G1396]] WTV-PAI-1S-C **μηπως** *mēpōs* żeby w jakiś sposób – aby nie jakoś [[G3381]] [[CONJ]] **αλλοις** *allois* innym [[G243]] WTA-DPM **κηρυξας** *kēryksas* ogłosiwszy [[G2784]] WTV-AAP-NSM **αυτος** *autos* sam [[G846]] WTP-NSM **αδοκιμος** *adokimos* niewypróbowany – zdyskwalifikowany [[G96]] [[A-NSM]] **γενωμαι** *genōmai* stałbym się [[G1096]] WTV-2ADS-1S
