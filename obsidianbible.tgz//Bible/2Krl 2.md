# 2Krl 2 BT5
###### **2Krl 2,1**
 Kiedy Pan miał wśród wichru unieść Eliasza do nieba, Eliasz szedł z Elizeuszem z Gilgal.
###### **2Krl 2,2**
 Wtedy Eliasz rzekł do Elizeusza: «***Zostań, proszę, tutaj, bo Pan posłał mnie aż do Betel***». Elizeusz zaś odpowiedział: «***Na życie Pana i na twoje życie: nie opuszczę cię!***» Przyszli zatem do Betel.
###### **2Krl 2,3**
 Wtedy synowie proroccy, którzy byli w Betel, wyszli do Elizeusza i powiedzieli do niego: «***Czy wiesz, że Pan dzisiaj uniesie twego pana w gorę, ponad twą głowę?***» On zaś odrzekł: «***Również i ja to wiem. Zamilczcie!***»
###### **2Krl 2,4**
 Wtedy powiedział do niego Eliasz: «***Elizeuszu! Zostań, proszę, tutaj, bo Pan posłał mnie aż do Jerycha***». On zaś odrzekł: «***Na życie Pana i na twoje życie: nie opuszczę cię!***» Weszli więc do Jerycha.
###### **2Krl 2,5**
 Wtedy synowie proroccy, którzy byli w Jerychu, przybliżyli się do Elizeusza i powiedzieli do niego: «***Czy wiesz, że Pan dzisiaj uniesie twego pana w gorę, ponad twą głowę?***» On zaś odpowiedział: «***Również i ja to wiem. Zamilczcie!***»
###### **2Krl 2,6**
 Wtedy rzekł Eliasz do niego: «***Zostań, proszę, tutaj, bo Pan posłał mnie aż do Jordanu***». Elizeusz zaś odpowiedział: «***Na życie Pana i na twoje życie: nie opuszczę cię!***» I szli dalej razem.
###### **2Krl 2,7**
 A pięćdziesięciu spośród synów prorockich poszło i stanęło z przeciwka, w oddali, podczas gdy oni obydwaj przystanęli nad Jordanem.
###### **2Krl 2,8**
 Wtedy Eliasz zdjął swój płaszcz, zwinął go i uderzył w wody, tak iż się rozdzieliły w obydwie strony. A oni we dwóch przeszli po suchym łożysku.
###### **2Krl 2,9**
 Kiedy zaś przeszli, Eliasz rzekł do Elizeusza: «***Żądaj, co mam ci uczynić, zanim wzięty będę od ciebie***». Elizeusz zaś powiedział: «***Niechby – proszę – dwie części twego ducha przeszły na mnie!***»
###### **2Krl 2,10**
 On zaś odrzekł: «***Trudnej rzeczy zażądałeś. Jeżeli mnie ujrzysz, jak wzięty będę od ciebie, spełni się twoje życzenie; jeśli zaś nie [ujrzysz], nie spełni się***».
###### **2Krl 2,11**
 Podczas gdy oni szli i rozmawiali, oto [zjawił się] wóz ognisty wraz z rumakami ognistymi i rozdzielił obydwóch; a Eliasz wśród wichru wstąpił do niebios.
###### **2Krl 2,12**
 Elizeusz zaś patrzał i wołał: «***Ojcze mój! Ojcze mój! Rydwanie Izraela i jego jeźdźcze***». I już go więcej nie ujrzał. Ująwszy następnie swoje szaty, Elizeusz rozdarł je na dwie części
###### **2Krl 2,13**
 i podniósł płaszcz Eliasza, który spadł od niego z góry. Wrócił i stanął nad brzegiem Jordanu.
###### **2Krl 2,14**
 I wziął płaszcz Eliasza, który spadł od niego z góry, i uderzył w wody. Wtedy rzekł: «***Gdzie jest Pan, Bóg Eliasza?***» I uderzył w wody, a one rozdzieliły się na obydwie strony. Elizeusz zaś przeszedł [środkiem].
###### **2Krl 2,15**
 Synowie proroccy, którzy byli w Jerychu, ujrzeli go z przeciwka i oświadczyli: «***Duch Eliasza spoczął na Elizeuszu***». Wyszli zatem naprzeciw niego, oddali mu pokłon do ziemi
###### **2Krl 2,16**
 i powiedzieli do niego: «***Oto wśród twoich sług jest pięćdziesięciu dzielnych ludzi. Niechaj pójdą i poszukają pana twojego, czy go nie uniósł Duch Pański i nie spuścił na jakąś gorę lub na jakąś dolinę***». Lecz on odpowiedział: «***Nie posyłajcie!***»
###### **2Krl 2,17**
 A gdy nalegali na niego zbyt mocno, powiedział: «***Poślijcie!***» Posłali więc pięćdziesięciu mężów, którzy szukali Eliasza trzy dni i nie znaleźli go.
###### **2Krl 2,18**
 Skoro wrócili do niego, gdy przebywał w Jerychu, rzekł do nich: «***Czyż wam nie powiedziałem: Nie chodźcie?***»
###### **2Krl 2,19**
 Mieszkańcy miasta mówili do Elizeusza: «***Popatrz! Położenie miasta jest miłe, jak sam, panie mój, widzisz, lecz woda jest niezdrowa, a ziemia nie daje plonów***».
###### **2Krl 2,20**
 On zaś rzekł: «***Przynieście mi nową misę i włóżcie w nią soli!***» I przynieśli mu.
###### **2Krl 2,21**
 Wtedy podszedł do źródła wody, wrzucił w nie sol i powiedział: «***Tak mówi Pan: Uzdrawiam te wody, już odtąd nie wyjdą stąd ani śmierć, ani niepłodność***».
###### **2Krl 2,22**
 Wody więc zostały uzdrowione aż po dzień dzisiejszy – według słowa, które wypowiedział Elizeusz.
###### **2Krl 2,23**
 Stamtąd poszedł do Betel. Kiedy zaś postępował drogą, mali chłopcy wybiegli z miasta i naśmiewali się z niego szyderczo, mówiąc do niego: «***Chodź no, łysku! Chodź no, łysku!***»
###### **2Krl 2,24**
 On zaś odwrócił się, spojrzał na nich i przeklął ich w imię Pańskie. Wówczas wypadły z lasu dwa niedźwiedzie i rozszarpały spośród nich czterdzieści dwoje dzieci.
###### **2Krl 2,25**
 Stamtąd Elizeusz poszedł na gorę Karmel, skąd udał się do Samarii.
# 2Krl 2 PAU
###### **2Krl 2,1**
 Kiedy PAN miał zabrać Eliasza wśród wichru do nieba, Eliasz i Elizeusz szli właśnie z Gilgal.
###### **2Krl 2,2**
 W pewnej chwili Eliasz powiedział do Elizeusza: „Zostań tutaj, gdyż PAN posłał mnie aż do Betel”. „Przysięgam na PANA i na twoje życie - odparł Elizeusz - że cię nie opuszczę!”. Poszli więc do Betel.
###### **2Krl 2,3**
 Wtedy przyszła do Elizeusza grupa proroków z Betel, pytając go: „Czy wiesz, że PAN ma dzisiaj zabrać twojego mistrza od ciebie?”. „Tak, też to wiem - odpowiedział - ale nic o tym nie mówcie”.
###### **2Krl 2,4**
 Zwrócił się do niego Eliasz: „Zostań tutaj, gdyż PAN posłał mnie do Jerycha”. On zaś mu odpowiedział: „Przysięgam na PANA i na twoje życie, że cię nie opuszczę!”. Przybyli zatem do Jerycha.
###### **2Krl 2,5**
 Tam podeszła do Elizeusza grupa proroków z Jerycha, pytając go: „Czy wiesz, że PAN ma dzisiaj zabrać twojego mistrza od ciebie?”. „Wiem - odpowiedział - ale nic o tym nie mówcie”.
###### **2Krl 2,6**
 Zwrócił się do niego Eliasz: „Zostań tutaj, gdyż PAN posłał mnie nad Jordan”. On zaś mu odpowiedział: „Przysięgam na PANA i na twoje życie, że cię nie opuszczę!”. Szli więc dalej razem.
###### **2Krl 2,7**
 Pięćdziesięciu mężczyzn z grupy proroków wyruszyło za nimi i przystanęło z daleka naprzeciwko, podczas gdy oni dwaj stanęli nad Jordanem.
###### **2Krl 2,8**
 Wtedy Eliasz zdjął swój płaszcz, zwinął go i uderzył nim wody, a one rozdzieliły się na jedną i drugą stronę. Wówczas przeszli obydwaj po suchej ziemi.
###### **2Krl 2,9**
 Gdy przechodzili, Eliasz rzekł do Elizeusza: „Powiedz, co mam dla ciebie zrobić, zanim będę zabrany od ciebie?”. „Oby podwójna część twojego ducha stała się moim udziałem” - odparł Elizeusz.
###### **2Krl 2,10**
 „Trudnej rzeczy zażądałeś - powiedział - jeśli jednak ujrzysz mnie, jak będę zabierany od ciebie, spełni się twoje życzenie, a jeśli mnie nie zobaczysz, nie spełni się ono”.
###### **2Krl 2,11**
 Kiedy więc tak szli i rozmawiali, nagle zjawił się rydwan z ognia i konie ogniste, które ich rozdzieliły. Wtedy Eliasz wstąpił wśród wichru do nieba.
###### **2Krl 2,12**
 Elizeusz zaś patrzył na to i wołał: „Ojcze mój, ojcze mój! Ty jesteś rydwanem Izraela i jego jeźdźcem!”. I nie zobaczył go już więcej. Elizeusz chwycił wówczas swoje szaty i rozerwał je na dwie części.
###### **2Krl 2,13**
 Potem podniósł płaszcz Eliasza, który spadł od niego, i udał się w drogę powrotną. A kiedy stanął nad brzegiem Jordanu,
###### **2Krl 2,14**
 wziął płaszcz Eliasza, który spadł od niego, i uderzył nim wody. Zawołał: „Gdzież jest Pan, Bóg Eliasza?”. Kiedy ponownie uderzył wody, rozdzieliły się na jedną i drugą stronę i Elizeusz przeszedł.
###### **2Krl 2,15**
 W grupie proroków, która obserwowała go z przeciwka, zaczęto mówić: „Duch Eliasza spoczął na Elizeuszu”. Wyszli mu na spotkanie i oddali mu pokłon aż do ziemi.
###### **2Krl 2,16**
 Potem powiedzieli do niego: „Jest wśród nas, twoich sług, pięćdziesięciu dzielnych ludzi. Niech wyruszą na poszukiwanie twojego mistrza. Może bowiem duch PANA uniósł go i spuścił na jakąś górę lub w dolinę”. Ale on odpowiedział: „Nie posyłajcie!”.
###### **2Krl 2,17**
 Oni jednak tak nalegali na niego, że nie potrafił im odmówić. Powiedział więc: „Poślijcie”. Wysłali pięćdziesięciu ludzi, którzy szukali go przez trzy dni, lecz go nie znaleźli.
###### **2Krl 2,18**
 Kiedy wrócili do Jerycha, gdzie przebywał, powiedział im: „A nie mówiłem wam: Nie chodźcie?”.
###### **2Krl 2,19**
 Mieszkańcy miasta żalili się Elizeuszowi: „Jak sam widzisz, panie nasz, położenie miasta jest dobre, ale wody są niezdrowe, dlatego ziemia nie daje plonów”.
###### **2Krl 2,20**
 Polecił zatem: „Przynieście mi nową miskę i włóżcie do niej soli”. Kiedy mu ją przynieśli,
###### **2Krl 2,21**
 udał się do źródła wody i wrzucając do niego sól, powiedział: „Tak mówi PAN: «Uzdrawiam te wody. Nigdy więcej nie spowodują one śmierci ani braku plonów»”.
###### **2Krl 2,22**
 Wody więc stały się zdrowe aż po dzień dzisiejszy, zgodnie ze słowem, które Elizeusz wypowiedział.
###### **2Krl 2,23**
 Stamtąd Elizeusz wyruszył do Betel. Kiedy był w drodze, wyszło z miasta kilku wyrostków, którzy zaczęli wyśmiewać się z niego, wołając: „Wynoś się, łysa pało! Wynoś się, łysa pało!”.
###### **2Krl 2,24**
 Wtedy odwrócił się i patrząc na nich, przeklął ich w imię PANA, a natychmiast wypadły z lasu dwie niedźwiedzice, które rozszarpały czterdziestu dwóch chłopców.
###### **2Krl 2,25**
 Odszedł więc stamtąd, udając się na górę Karmel, a później wrócił do Samarii.
# 2Krl 2 BP
###### **2Krl 2,1**
 Gdy Jahwe miał zabrać Eliasza w wichrze do nieba, Eliasz i Elizeusz szli z Gilgal.
###### **2Krl 2,2**
 Eliasz rzekł do Elizeusza: Zostań - proszę - tutaj, gdyż Jahwe posyła mię aż do Betel. Elizeusz odpowiedział: Na żyjącego Jahwe, na życie twojej duszy: nie opuszczę cię. I zeszli do Betel.
###### **2Krl 2,3**
 Synowie proroków, którzy byli w Betel, wyszli do Elizeusza i powiedzieli mu: Czy wiesz, że Jahwe zabiera dzisiaj twojego pana [w górę] ponad twoją głowę? Odrzekł: Ja też wiem. Zachowajcie milczenie!
###### **2Krl 2,4**
 Eliasz zaś rzekł do niego: Elizeuszu, zostań - proszę - tutaj, gdyż Jahwe posyła mię do Jerycha. Odpowiedział: Na żyjącego Jahwe, na życie twojej duszy: nie opuszczę cię. I przyszli do Jerycha.
###### **2Krl 2,5**
 Synowie proroków, którzy byli w Jerychu, przystąpili do Elizeusza i powiedzieli mu: Czy wiesz, że Jahwe zabiera dzisiaj twojego pana [w górę] ponad twoją głowę? Odrzekł: Ja też wiem. Zachowajcie milczenie!
###### **2Krl 2,6**
 Eliasz prosił go: Zostań - proszę - tutaj, gdyż Jahwe posyła mię nad Jordan. Odpowiedział: Na żyjącego Jahwe, na życie twojej duszy: nie opuszczę cię. I poszli obydwaj.
###### **2Krl 2,7**
 Pięćdziesięciu mężów ze synów prorockich poszło [za nimi] i stanęli naprzeciw, z daleka. Oni zaś obydwaj zatrzymali się nad Jordanem.
###### **2Krl 2,8**
 Eliasz wziął swój płaszcz, zwinął go i uderzył wodę. Rozstąpiła się na tę i na tamtą stronę, a oni obaj przeszli po suchym [dnie].
###### **2Krl 2,9**
 Gdy przeszli, Eliasz rzekł do Elizeusza: Proś! Co mam ci uczynić, zanim będę wzięty od ciebie? Elizeusz poprosił: Niech mam podwójną część twojego ducha.
###### **2Krl 2,10**
 [Eliasz] odrzekł: O trudną rzecz prosisz. Jeśli mnie zobaczysz [w chwili], gdy będę wzięty od ciebie, stanie się zadość twojej [prośbie]. Jeśli zaś nie, nie stanie się.
###### **2Krl 2,11**
 I stało się, że w czasie ich marszu, gdy szli i rozmawiali, oto ognisty rydwan oraz ogniste konie rozdzieliły ich obydwóch i Eliasz wstąpił do nieba w wichrze.
###### **2Krl 2,12**
 Elizeusz widząc [to] krzyknął: Mój ojcze, mój ojcze, rydwanie Izraela i jego rycerzu! I nie ujrzał go więcej. Chwycił swe szaty i rozdarł je na dwie części.
###### **2Krl 2,13**
 [Potem] podniósł płaszcz Eliasza, który zsunął się z niego, wrócił się i stanął nad brzegiem Jordanu.
###### **2Krl 2,14**
 Elizeusz wziął płaszcz Eliasza, który zsunął się z niego, uderzył wodę i rzekł: Gdzie jest Jahwe, Bóg Eliasza. Także on uderzył wodę i rozstąpiła się na tę i na tamtą stronę i Elizeusz przeszedł.
###### **2Krl 2,15**
 Synowie proroków, którzy byli w Jerychu, ujrzeli go z naprzeciwka i rzekli: Duch Eliasza spoczął na Elizeuszu. Wyszli naprzeciw niego, pokłonili się mu głęboko ku ziemi
###### **2Krl 2,16**
 i powiedzieli mu: Oto [pośród] sług twoich jest pięćdziesięciu dzielnych mężów. Pozwól, że pójdą i będą szukać twojego pana, może [przypadkiem] duch Jahwe uniósł go i zostawił na jednej z gór lub w jakiejś dolinie. Odpowiedział: Nie posyłajcie.
###### **2Krl 2,17**
 Nalegali [jednak] na niego, aż do uprzykrzenia. Wtedy rzekł: Poślijcie. Posłali więc pięćdziesięciu mężów. Szukali trzy dni i nie znaleźli go.
###### **2Krl 2,18**
 Wrócili zatem do niego - a przebywał on w Jerychu - i powiedział im: Czy nie mówiłem wam: Nie chodźcie?
###### **2Krl 2,19**
 Mężowie miasta powiedzieli Elizeuszowi: Oto położenie miasta jest dobre, jak pan mój widzi, ale woda jest niedobra i ziemia nieurodzajna.
###### **2Krl 2,20**
 Odrzekł: Przynieście mi nową misę i wsypcie do niej soli. Przynieśli mu.
###### **2Krl 2,21**
 Poszedł do źródła wody, wsypał tam sól i rzekł: Tak mówi Jahwe: uzdrawiam tę wodę. Nie wyjdą stąd więcej śmierć i nieurodzaj.
###### **2Krl 2,22**
 I uzdrowiona została woda aż do dnia dzisiejszego, według słowa Elizeusza, które wyrzekł.
###### **2Krl 2,23**
 Stamtąd udał się do Betel. Kiedy szedł drogą, mali chłopcy wybiegli z miasta, wyśmiewali się z niego i mówili mu: Wstąp łysy. Wstąp łysy.
###### **2Krl 2,24**
 Obejrzał się za siebie, spojrzał na nich i złorzeczył im w Imię Jahwe. [Wówczas] dwa niedźwiedzie wypadły z lasu i rozszarpały spośród nich czterdzieści dwoje dzieci.
###### **2Krl 2,25**
 Stamtąd poszedł na górę Karmel, skąd powrócił [później] do Samarii.
# 2Krl 2 BR
###### **2Krl 2,1**
 Kiedy Jahwe miał w gwałtownej wichurze zabrać Eliasza do nieba, Eliasz wraz z Elizeuszem wychodził właśnie z Gilgal.
###### **2Krl 2,2**
 W pewnej chwili Eliasz powiedział do Elizeusza: Zostań, proszę cię, tutaj, bo Jahwe wysyła mnie aż do Betel. Rzekł na to Elizeusz: Na życie Jahwe i na twoje życie, nie opuszczę cię nigdy!
###### **2Krl 2,3**
 I poszli obaj do Betel. A uczniowie proroków, którzy byli w Betel, wyszli Elizeuszowi na spotkanie i powiedzieli mu: Czy ty wiesz, że Jahwe uniesie dziś twego pana w górę, ponad twoją głowę? A on odpowiedział: Tak, ja również to wiem, ale zachowajcie spokój!
###### **2Krl 2,4**
 Eliasz zaś powiedział do Elizeusza: Elizeuszu, proszę cię, pozostań tutaj, bo Jahwe wysyła mnie do Jerycha. Odpowiedział Elizeusz: Na życie Jahwe i na twoje życie, nie opuszczę cię nigdy! I przybyli do Jerycha.
###### **2Krl 2,5**
 Synowie proroków przebywających w Jerychu przyszli do Elizeusza i powiedzieli mu: Czy ty wiesz, że Jahwe uniesie dziś twego pana w górę, ponad twoją głową? A on odpowiedział: Tak, ja również to wiem, ale zachowajcie spokój!
###### **2Krl 2,6**
 Potem Eliasz powiedział: Zostań tutaj, proszę cię, gdyż Jahwe wysyła mnie nad Jordan. Odpowiedział Elizeusz: Na życie Jahwe i na twoje życie, nie opuszczę cię nigdy! I poszli obaj razem.
###### **2Krl 2,7**
 Pięćdziesięciu spośród synów prorockich szło za nimi. Zatrzymali się w pewnej odległości naprzeciwko ich, a oni stanęli nad brzegiem Jordanu.
###### **2Krl 2,8**
 Wtedy Eliasz wziął swój płaszcz, zwinął go i uderzył nim o wodę, tak że wody się rozdzieliły, a oni obaj przeszli suchą nogą na drugą stronę.
###### **2Krl 2,9**
 Kiedy już przeszli na drugą stronę, Eliasz powiedział: Powiedz, co chcesz, żebym ci uczynił, zanim zostanę zabrany od ciebie. Elizeusz odpowiedział: Niech twój duch zstąpi na mnie w podwójnej mierze!
###### **2Krl 2,10**
 Eliasz powiedział: Żądasz ode mnie rzeczy bardzo trudnej. Ale stanie ci się to, jeśli będziesz mnie widział w chwili, gdy będę się z tobą rozstawał; natomiast nie spełni się twoje życzenie, jeśli nie będziesz mnie wtedy widział.
###### **2Krl 2,11**
 Kiedy ruszyli w dalszą drogę, rozmawiając ze sobą, nagle rydwan ognisty, zaprzężony w dwa ogniste rumaki, rozdzielił ich i Eliasz, spowity trąbą powietrza, został zabrany do nieba.
###### **2Krl 2,12**
 Widząc to Elizeusz zaczął wołać: Ojcze mój, ojcze mój! Rydwanie Izraela i woźnico jego! I po chwili już go nie widział. Wziął wtedy swój płaszcz i rozdarł go na dwie części,
###### **2Krl 2,13**
 płaszcz Eliasza zaś, który spadł z góry, Elizeusz podniósł i zabrał ze sobą. Potem udał się Elizeusz w stronę Jordanu i stanął nad jego brzegiem.
###### **2Krl 2,14**
 Wziął następnie płaszcz Eliasza, i uderzył nim o wodę [Jordanu], mówiąc: Gdzie jest Jahwe, Bóg Eliasza? Gdzie on jest? Gdy uderzył płaszczem o wodę, woda rozdzieliła się na dwie strony, a Elizeusz przeszedł suchą nogą.
###### **2Krl 2,15**
 Uczniowie proroccy z Jerycha, którzy stali po drugiej stronie Jordanu, widząc to, mówili: Duch Eliasza zstąpił teraz na Elizeusza. I wyszli Elizeuszowi na spotkanie. Upadli przed nim na twarz i powiedzieli mu:
###### **2Krl 2,16**
 Wśród twoich sług jest pięćdziesięciu odważnych wojowników. Niech pójdą i poszukają twojego pana. Może duch Jahwe uniósł go i pozostawił gdzieś na jakimś szczycie górskim albo w dolinie? Lecz on odpowiedział: Nie wysyłajcie nigdzie nikogo!
###### **2Krl 2,17**
 Ale gdy oni nadal usilnie nalegali, powiedział: Dobrze, poślijcie ich! Wysłano więc owych pięćdziesięciu ludzi, którzy przez trzy dni szukali Eliasza, ale go nie znaleźli.
###### **2Krl 2,18**
 Kiedy wrócili do Elizeusza, który pozostał w Jerychu, ten im powiedział: Czyż ja wam nie mówiłem, żebyście nigdzie nie chodzili?
###### **2Krl 2,19**
 Mieszkańcy zaś powiedzieli do Elizeusza: Pobyt w tym mieście - jak sam pan nasz widzi - byłby całkiem miły, gdyby nie to, że woda jest tu niedobra i ziemia nieurodzajna.
###### **2Krl 2,20**
 Elizeusz powiedział: Przynieście mi tu jakieś nowe naczynie napełnione solą. I przyniesiono mu naczynie z solą.
###### **2Krl 2,21**
 A on poszedł do źródła wody i wrzuciwszy sól do wody, powiedział: Oto, co mówi Jahwe: Uzdrawiam teraz te wody. Nie będą one już więcej przyczyną ani śmierci, ani bezpłodności.
###### **2Krl 2,22**
 I stały się zdrowe owe wody, i takie są po dzień dzisiejszy - zgodnie ze słowami wypowiedzianymi przez Elizeusza.
###### **2Krl 2,23**
 Stamtąd udał się Elizeusz do Betel. Kiedy szedł drogą przez osiedla, biegli za nim mali chłopcy i wyśmiewali się z niego, wołając: Chodź tu, łysku! Łysku, chodź tu!
###### **2Krl 2,24**
 On zaś obejrzał się w ich stronę i przeklął ich w imię Jahwe. W pewnej chwili wyszły z lasu dwa niedźwiedzie i rozszarpały czterdziestu dwóch chłopców.
###### **2Krl 2,25**
 Potem udał się na górę Karmel, skąd powrócił do Samarii.
# 2Krl 2 WUJ
###### **2Krl 2,1**
 I stało się, gdy Pan chciał podnieść Eliasza z wichrem do nieba: szli Eliasz i Elizeusz z Galgal.
###### **2Krl 2,2**
 I rzekł Eliasz do Elizeusza: Siedź tu, bo mnie Pan posłał aż do Bethel. Któremu rzekł Elizeusz: Żywie Pan i żywie dusza twoja, że się ciebie nie puszczę. A gdy przyszli do Bethel,
###### **2Krl 2,3**
 Wyszli synowie proroccy, którzy byli w Bethel do Elizeusza, i rzekli mu: A wieszże, że dziś Pan weźmie pana twego od ciebie? Który odpowiedział: I jać wiem: Milczcie.
###### **2Krl 2,4**
 I rzekł Eliasz do Elizeusza: Siedź tu, bo mię Pan posłał do Jerycha: A on rzekł: Żywie Pan i żywie dusza twoja, że się ciebie nie puszczę. A gdy przyszli do Jerycha,
###### **2Krl 2,5**
 Przystąpili synowie proroccy, którzy byli w Jerychu do Elizeusza, i rzekli mu: A wiesz, iż Pan dzisia weźmie pana twego od ciebie? rzekł im: I jać wiem: Milczcie.
###### **2Krl 2,6**
 I rzekł mu Eliasz: Siedź tu, bo mię Pan posłał aż do Jordana. A on rzekł: Żywie Pan i żywie dusza twoja, że się ciebie nie puszczę. A tak szli pospołu obadwa.
###### **2Krl 2,7**
 A pięćdziesiąt mężów z synów prorockich szli za nimi, którzy i stanęli przeciwko daleko: a oni oba stali nad Jordanem.
###### **2Krl 2,8**
 I wziął Eliasz płaszcz swój, i zwinął ji, i uderzył wody, które się rozstąpiły na obie stronie, i przeszli oba po suszy.
###### **2Krl 2,9**
 A gdy przeszli, Eliasz rzekł do Elizeusza: Żądaj czego chcesz, abych ci uczynił, pierwej niż będę wzięt od ciebie. I rzekł Elizeusz: Proszę, aby się stał we mnie dwojaki duch twój.
###### **2Krl 2,10**
 Który odpowiedział: Trudnejeś rzeczy prosił: wszakże, jeśli mię ujrzysz, gdy będę wzięt od ciebie, stanieć się o coś żądał: ale jeśli nie ujrzysz, nie stanie.
###### **2Krl 2,11**
 A gdy szli, a idąc rozmawiali: alić wóz ognisty, i konie ogniste rozłączyły obudwu: i wstąpił Eliasz przez wicher do nieba,
###### **2Krl 2,12**
 A Elizeusz widział i wołał: Ojcze mój, ojcze mój, wozie Izraelów i woźnica jego. I nie widział go więcej: a ująwszy szaty swe rozdarł je na dwie części.
###### **2Krl 2,13**
 I podniósł płaszcz Eliaszów, który mu był upadł, a wróciwszy się stanął na brzegu Jordanu.
###### **2Krl 2,14**
 A płaszczem Eliaszowym, który mu był upadł, uderzył wody, a nie rozstąpiły się: I rzekł: Gdzież jest Bóg Eliaszów i teraz? I uderzył wody, i rozstąpiły się i tam i sam, i przeszedł Elizeusz.
###### **2Krl 2,15**
 A widząc synowie proroków, którzy byli w Jerychu na przeciw, rzekli: Odpoczynął duch Eliaszów na Elizeuszu. A wyszedszy przeciwko niemu, pokłonili się mu twarzą do ziemie.
###### **2Krl 2,16**
 I rzekli mu: Oto przy sługach twoich jest pięćdziesiąt mężów mocnych, którzy mogą iść i szukać pana twego, by go snać Duch Pański nie pochwycił i nie porzucił na której górze, abo na której dolinie. A on rzekł: Nie posyłajcie.
###### **2Krl 2,17**
 I przymusili go, aż zezwolił, i rzekł: Poślijcież. I posłali piącidziesiąt mężów: którzy, gdy szukali przez trzy dni, nie naleźli.
###### **2Krl 2,18**
 I wrócili się do niego, a on mieszkał w Jerychu, i rzekł im: Azam wam nie mówił: Nie posyłajcie.
###### **2Krl 2,19**
 Rzekli też mężowie miasta do Elizeusza: Oto mieszkanie miasta tego jest barzo dobre, jako ty sam panie widzisz: ale wody są barzo złe, i ziemia niepłodna.
###### **2Krl 2,20**
 A on rzekł: Przynieście mi naczynie nowe, a włóżcie w nie soli. Które gdy przynieśli,
###### **2Krl 2,21**
 Wyszedszy do źródła wód wpuścił w nie soli, i rzekł: To mówi Pan: Uzdrowiłem te wody, i nie będzie więcej w nich śmierci ani niepłodności.
###### **2Krl 2,22**
 A tak uzdrowione są wody aż do dnia tego, według słowa Elizeuszowego, które mówił.
###### **2Krl 2,23**
 I szedł z onąd do Bethel: a gdy szedł drogą, dzieci małe wyszły z miasta, i naśmiewały się z niego, mówiąc: Wstępuj łysku, wstępuj łysku.
###### **2Krl 2,24**
 Który gdy się obejrzał, ujrzał je, i złorzeczył im w imię Pańskie: i wyszli dwa niedźwiedzie z lasa, i rozdrapali z nich czterdzieści i dwoje dzieci.
###### **2Krl 2,25**
 I poszedł z onąd na górę Karmeli, a ztamtąd wrócił się do Samariiej.
