# Ha 1 BT5
###### **Ha 1,1**
 Wyrok, który usłyszał w widzeniu prorok Habakuk. Habakuka Pierwsza lamentacja
###### **Ha 1,2**
 Jak długo, Panie, mam wzywać pomocy –a Ty nie wysłuchujesz?Wołam do Ciebie: Na pomoc! –a Ty nie wysłuchujesz.
###### **Ha 1,3**
 Dlaczego ukazujesz mi niegodziwośći przyglądasz się nieszczęściu?Oto ucisk i przemoc przede mną, powstają spory, wybuchają waśnie.
###### **Ha 1,4**
 Tak więc straciło Prawo moc swoją, sprawiedliwego sądu już nie ma; bezbożny bowiem gnębi uczciwego, dlatego wyrok sądowy ulega wypaczeniu. Habakuka Pierwsza odpowiedź Pana
###### **Ha 1,5**
 Spójrzcie na ludy dokoła, a patrzciepełni zdumienia i trwogi:gdyż Ja dokonuję za dni waszych dzieła –nie dacie wiary, gdy [wam o tym] będzie się opowiadać.
###### **Ha 1,6**
 Oto powołam Chaldejczyków,lud dziki a gwałtowny, który przemierza ziemie rozległe, aby zagarnąć siedziby nie swoje.
###### **Ha 1,7**
 Trwogę budzi ten naród, on sam ustala prawo i panowanie.
###### **Ha 1,8**
 Jego konie są bardziej rącze niż pantery, bardziej drapieżne niż wilki wieczorem; jeźdźcy ich w pędzie gonią za łupem, zbliżają się szybko z daleka, spadając na żer niby orzeł.
###### **Ha 1,9**
 Wszyscy oni idą pełni żądzy mordu, a ich spojrzenia są jak wiatr palący;gromadzą jeńców niby ziarna piasku.
###### **Ha 1,10**
 Królowie są dla nich przedmiotem szyderstwa, a pośmiewiskiem stają się władcy; twierdze zaś wszystkie to dla nich igraszka, sypią szańce i biorą je szturmem.
###### **Ha 1,11**
 Potem nabiera tchu i oddala się;przestępcą jest ten, kto ubóstwia swą siłę. Habakuka Druga lamentacja
###### **Ha 1,12**
 Czyż to nie Ty, Boże mój, Świętości moja, jesteś od samych początków Panem? Nie pomrzemy!Na sąd go przeznaczyłeś, o Panie, Opoko moja, zachowałeś go, aby mu wymierzyć karę.
###### **Ha 1,13**
 Zbyt czyste oczy Twoje, by na zło patrzyły, a nieprawości pochwalać nie możesz. Czemu jednak spoglądasz na ludzi zdradliwychi milczysz, gdy bezbożny pożera uczciwszego od siebie?
###### **Ha 1,14**
 Obchodzi się on z ludźmi jak z rybami morskimi, jak z pełzającymi zwierzętami, którymi nikt nie rządzi.
###### **Ha 1,15**
 Wszystkich łowi na wędkę, zagarnia swoim niewodemalbo w sieci gromadzi –krzycząc przy tym z radości.
###### **Ha 1,16**
 Przeto ofiarę składa swojej sieci, pali kadzidło niewodowi swemu, bo przez nie zdobył sobie łup bogaty, a pożywienie jego stało się obfite.
###### **Ha 1,17**
 Czyż zatem nie zarzuca na nowo swych sieci,aby mordować ludy bez litości?Habakuka Druga odpowiedź Pana
# Ha 1 PAU
###### **Ha 1,1**
 Wypowiedź prorocka, która została przekazana prorokowi Habakukowi w widzeniu.
###### **Ha 1,2**
 Jak długo, PANIE, będę Ciebie błagał, a Ty nie wysłuchujesz? Będę głośno wołał: krzywda mi się dzieje! -a Ty nie ratujesz?
###### **Ha 1,3**
 Dlaczego mam patrzeć na krzywdę, dlaczego muszę doznawać ucisku? Gdziekolwiek spojrzę - widzę gwałt i przemoc, muszę doświadczać zawiści i sporów.
###### **Ha 1,4**
 Także prawo stało się bezsilne, nikt się nie liczy ze sprawiedliwością. Uczciwego osacza bezbożny, wyroki sądu są niesprawiedliwe.
###### **Ha 1,5**
 Spójrzcie na narody i zobaczcie, osłupiejecie z ogromu zdumienia! Teraz dokonam tak wielkiego dzieła, że trudno wam będzie uwierzyć.
###### **Ha 1,6**
 Oto wezwę Chaldejczyków: naród okrutny i nieposkromiony, który wyruszy w odległe krainy, by cudze ziemie zdobywać.
###### **Ha 1,7**
 Naród to straszny i budzący grozę, sam stanowi o swoich prawach i wielkości.
###### **Ha 1,8**
 Jego konie są szybsze od panter i groźniejsze od wilków stepowych; jego jeźdźcy pędzą z daleka, lecą jak orły spadające na żer.
###### **Ha 1,9**
 Nadchodzą gotowi do wszelkiej przemocy, nie oglądając się za siebie, zgarniają jeńców jak piasek.
###### **Ha 1,10**
 Mają za nic królów i kpią sobie z książąt; szydzą ze wszystkich warowni, zdobywają je, sypiąc ziemne wały.
###### **Ha 1,11**
 A potem ruszają dalej niczym poszum burzowego wichru. Lecz kara dosięgnie tego, kto własną siłę ubóstwia.
###### **Ha 1,12**
 Czy nie istniejesz odwiecznie, PANIE, Boże mój, Święty? My nie chcemy ginąć! Wezwałeś go, PANIE, by dokonał sądu, powołałeś, by wymierzył karę.
###### **Ha 1,13**
 Oczy Twoje zbyt czyste, by zła nie dostrzegły! Ty nie możesz bezczynnie patrzeć na udrękę! Czemu więc milczysz, widząc nieuczciwość, kiedy bezbożny pożera sprawiedliwego?
###### **Ha 1,14**
 Czyżbyś uczynił ludzi podobnymi do morskich ryb albo do płazów niemających władcy?
###### **Ha 1,15**
 Bo on wszystkich łowi na wędkę, zagarnia swoją siecią albo zbiera niewodem - radując się przy tym bardzo.
###### **Ha 1,16**
 Dlatego składa ofiarę swojej sieci, pali kadzidło swojemu niewodowi - bo dzięki nim ma zysk przeobfity i ucztę bardzo wystawną.
###### **Ha 1,17**
 Dlatego miecz jego zawsze gotowy, by bez litości wyniszczać narody.
# Ha 1 BP
###### **Ha 1,1**
 Proroctwo, które otrzymał w widzeniu prorok Habakuk.
###### **Ha 1,2**
 Jak długo jeszcze, o Jahwe, mam wołać o pomoc, choć Ty nie wysłuchujesz! Wołam do Ciebie: "Ucisk!" a Ty nie śpieszysz na ratunek.
###### **Ha 1,3**
 Dlaczego każesz mi patrzeć na nieprawość, dlaczego muszę przyglądać się uciskowi? Przemoc i gwałt dzieją się na mych oczach, szerzą się kłótnie i spory.
###### **Ha 1,4**
 Dlatego prawo traci swą moc, a sprawiedliwość nigdy nie dochodzi do głosu; a że bezbożny ma w swojej mocy sprawiedliwego, wyroki są zawsze stronnicze.
###### **Ha 1,5**
 Spójrzcie na narody i dziwujcie się, niech was ogarnie największe zdumienie! Bo dokonuje się za waszych dni takie dzieło, że nie uwierzylibyście, gdyby wam o nim opowiadano.
###### **Ha 1,6**
 Oto wzbudzę Chaldejczyków, ów naród srogi i nieposkromiony, który przemierza dalekie krainy, by brać w posiadanie cudze siedziby.
###### **Ha 1,7**
 Straszny jest i groźny, wymierza kary i sieje spustoszenie.
###### **Ha 1,8**
 Konie jego są szybsze niż pantery, groźniejsze niż wilki o wieczornej porze. Rumaki jego pędzą, jeźdźcy jego przylatują z daleka jak orzeł, który się rzuca na żer.
###### **Ha 1,9**
 Każdy z nich przychodzi, by grabić. Ich pierwsze natarcie, niby wichura, zgarnia jeńców jak piasek.
###### **Ha 1,10**
 Z królów szydzi, a z książąt drwi; śmieje się z każdej twierdzy, usypuje wał i zajmuje ją.
###### **Ha 1,11**
 Potem zawraca jak wicher i ciągnie dalej. Ale ściąga na siebie winę, kto we własnej potędze widzi swego boga.
###### **Ha 1,12**
 Czy nie od wieków istniejesz, o Jahwe, Boże mój, Święty, Nieśmiertelny? Powołałeś go, o Jahwe, by dokonał sądu, Opoko moja, wyznaczyłeś go do wymierzenia kary.
###### **Ha 1,13**
 Tak czyste są Twoje oczy, że nie możesz patrzeć na zło, nie możesz znieść widoku udręki. Dlaczegóż więc przyglądasz się niewiernym i milczysz, gdy bezbożny gubi sprawiedliwego?
###### **Ha 1,14**
 Sprawiłeś, że [może postępować] z ludźmi jak z rybami morskimi, jak z robactwem bezpańskim.
###### **Ha 1,15**
 Łowi wszystkich na wędkę, zagarnia w swoją sieć i gromadzi w swym więcierzu. Stąd czerpie radość i uciechę.
###### **Ha 1,16**
 Dlatego składa ofiary swej sieci i pali kadzidło przed swym więcierzem. Im przecież zawdzięcza bogate łupy i obfite uczty.
###### **Ha 1,17**
 Toteż bezustannie dobywa miecza, by bezlitośnie mordować narody.
# Ha 1 BR
###### **Ha 1,1**
 Słowa, które prorok Habakuk usłyszał podczas pewnego widzenia.
###### **Ha 1,2**
 Jak długo jeszcze mam cię wzywać, Panie, a Ty wcale nie raczysz mnie słuchać? Wołam do Ciebie: Pomóż mi, bom w ucisku! A Ty mi nie chcesz dopomóc.
###### **Ha 1,3**
 Czemu zezwalasz, bym tyle zła cierpiał, i patrzysz bezczynnie na mą krzywdę? Gdzie tylko spojrzę, widzę gwałt i ucisk, wszędzie tylko waśnie i kłótnie.
###### **Ha 1,4**
 Dlatego żadnej mocy nie ma Prawo, nie wydaje się już sprawiedliwych wyroków. Bezbożni uciskają prawych, a samo Prawo znaczy coś innego.
###### **Ha 1,5**
 Popatrzcie wszystkie ludy dokoła, niech ogarnie was i zduminie, i trwoga, gdyż za dni waszych dokonam dzieła, o którym będą wam opowiadać ale wy nie zechcecie uwierzyć.
###### **Ha 1,6**
 Otóż sprowadzę na was Chaldejczyków, naród okrutny , gwałtowny. Przemierzą oni rozległe krainy, by zagarnąć dla siebie domostwa, które wcale do nich nie należą.
###### **Ha 1,7**
 Naród ten budzi wszędzie strach i trwogę i sam sobie wyznacza swe prawo i wielkość.
###### **Ha 1,8**
 Ich konie są szybsze niżeli pantery i bardziej dzikie niż stepowe wilki. Pędzą na rumakach ich jeźdźcy, wszyscy przybywają z daleka, nadlatują stadami jak orły z góry, co gwałtownie na żer się rzucają.
###### **Ha 1,9**
 Zbliżają się gotowi dokonać najstraszniejszych gwałtów, twarze wszystkich rozpalone niczym wiatr ze wschodu, jeńców u nich tyle ile piasku.
###### **Ha 1,10**
 Drwią sobie nawet z samych królów i wyśmiewają się z potężnych książąt. Nie przerażają ich wcale największe warownie; wały przed nimi usypują z ziemi i wszystkie twierdzę łatwo zdobywają.
###### **Ha 1,11**
 Potem prą dalej niczym gwałtowny. Lecz kiedyś będą żałować tego, że swoją siłę uczynili bóstwem.
###### **Ha 1,12**
 Panie, czyż nie jesteś od wieków moim swiętym Bogiem? (Panie), my umierać nie chcemy. Panie, Ty ich po to tylko powołałeś, aby nad nami sąd przeprowadzili. Ty, naszą opoko, na to ich przeznaczyłeś, żeby nas pokarać.
###### **Ha 1,13**
 Zbyt czyste są Twe oczy, by na zło patrzyły. Ty nie możesz pochwalać żadnego ucisku. Czemuż więc widząc bezbożnika milczysz, czemuż niegodziwiec pożera prawego?
###### **Ha 1,14**
 Czemu traktujesz ludzi tak jak ryby w morzu jak pełzające robactwo, którym nikt nie rządzi?
###### **Ha 1,15**
 Chwyta je wszystkie na wędkę i zgarnia do sieci, i gromadzi je we własnym zbiorniku, ciesząc się bardzo przy tym i radując.
###### **Ha 1,16**
 Dlatego ofiary składa na cześć swojej sieci i całopalenia przed zbiornikiem na ryby, bo przez nie zdobył dobra niemałe i wspomiałe zapasy jedzenia.
###### **Ha 1,17**
 Dobywa tedy wciąż na nowo swego miecza, ażeby bez litości mordować narody.
# Ha 1 WUJ
###### **Ha 1,1**
 Brzemię które widział Habakuk prorok.
###### **Ha 1,2**
 Dokądże Panie wołać będę, a nie wysłuchasz? krzyczeć będę ku tobie gwałt cierpiąc, a nie wybawisz?
###### **Ha 1,3**
 Przeczżeś mi ukazał nieprawość i pracą, patrzyć na łup, i niesprawiedliwość przedemną, i stał się sąd, i sprzeciwieństwo potężniejsze.
###### **Ha 1,4**
 Dla tego podrapan jest zakon, i nie przyszedł aż do końca sąd, iż niezbożny przemaga przeciw sprawiedliwemu, dla tego wychodzi sąd przewrotny.
###### **Ha 1,5**
 Pojrzycie między narody, a przypatrzcie się, dziwujcie się, a zdumiejcie się: bo się stał uczynek za dni waszych, któremu żaden wierzyć nie będzie, gdy ji będą powiadać.
###### **Ha 1,6**
 Bo oto ja wzbudzę Chaldejczyki, naród gorzki a prędki, idący po szerokości ziemie, aby posiadł mieszkania nie swoje.
###### **Ha 1,7**
 Straszny i ogromny jest: od niego samego sąd, I brzemię jego wynidzie.
###### **Ha 1,8**
 Lżejsze niż Pardowie konie jego, a prędszy niż wilcy z wieczora: rozbieżą się jezdni jego: bo jezdni jego z daleka przydą, latać będą jako orzeł bawiący się ku jedzeniu.
###### **Ha 1,9**
 Wszyscy na łupieztwo przydą, twarzy ich wiatr palący: i zgromadzi jako piasek pojmanie.
###### **Ha 1,10**
 A ten z królów tryumphy czynić będzie, a tyranowie błaznami u niego będą. Ten się będzie śmiał z każdego zamku, i usypie wał i weźmie ji.
###### **Ha 1,11**
 Tedy się odmieni duch, i przeminie, i upadnie. Tać jest moc jego Boga jego.
###### **Ha 1,12**
 Izaliś nie ty od początku Panie Boże mój, święty mój, a nie umrzemy? Panie na sąd postawiłeś go: i mocnego, abyś skarał, ugruntowałeś go.
###### **Ha 1,13**
 Czyste są oczy twoje, abyś nie patrzał na złe, a patrzyć na nieprawość nie będziesz mógł. Przeczże patrzysz na nieprawość czyniące, a milczysz, gdy niezbożny pożera sprawiedliwszego niż sam?
###### **Ha 1,14**
 I uczynisz ludzie jako ryby morskie, i jako płaz nie mający wodza.
###### **Ha 1,15**
 Wszystko wędą podniósł, wyciągnął je niewodem swoim, i zgromadził w sieć swoję, (16) Dla tego się weselić i radować będzie.
###### **Ha 1,16**
 Dla tego będzie ofiarował niewodowi swemu, i uczyni ofiarę sieci swej: bo przez te utył dział jego, i pokarm jego wyborny.
###### **Ha 1,17**
 Dla tego tedy rozszerzył niewód swój, a zawżdy zabijać narodów nie przepuści.
