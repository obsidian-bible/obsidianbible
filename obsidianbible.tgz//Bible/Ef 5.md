# Ef 5 BT5
###### **Ef 5,1**
 Bądźcie więc naśladowcami Boga, jako dzieci umiłowane,
###### **Ef 5,2**
 i postępujcie drogą miłości, bo i Chrystus was umiłował i samego siebie wydał za nas w ofierze i dani na woń miłą Bogu.
###### **Ef 5,3**
 O nierządzie zaś i wszelkiej nieczystości albo chciwości niechaj nawet mowy nie będzie wśród was, jak przystoi świętym,
###### **Ef 5,4**
 ani o tym, co haniebne, ani niedorzecznego gadania lub nieprzyzwoitych żartów, bo to wszystko jest niestosowne. Raczej winno być wdzięczne usposobienie.
###### **Ef 5,5**
 O tym bowiem bądźcie przekonani, że żaden rozpustnik ani nieczysty, ani chciwiec – to jest bałwochwalca – nie ma dziedzictwa w królestwie Chrystusa i Boga.
###### **Ef 5,6**
 Niechaj was nikt nie zwodzi próżnymi słowami, bo przez te [grzechy] nadchodzi gniew Boży na synów buntu.
###### **Ef 5,7**
 Nie miejcie więc z nimi nic wspólnego!
###### **Ef 5,8**
 Niegdyś bowiem byliście ciemnością, lecz teraz jesteście światłością w Panu: postępujcie jak dzieci światłości.
###### **Ef 5,9**
 Owocem bowiem światłości jest wszelka prawość i sprawiedliwość, i prawda.
###### **Ef 5,10**
 Badajcie, co jest miłe Panu.
###### **Ef 5,11**
 I nie miejcie udziału w bezowocnych uczynkach ciemności, a raczej piętnując [je], nawracajcie [tamtych].
###### **Ef 5,12**
 O tym bowiem, co się u nich dzieje po kryjomu, wstyd nawet mówić.
###### **Ef 5,13**
 Natomiast wszystkie te rzeczy, gdy są piętnowane, stają się jawne dzięki światłu, bo wszystko, co staje się jawne, jest światłem.
###### **Ef 5,14**
 Dlatego się mówi: Zbudź się, o śpiący, i powstań z martwych, a zajaśnieje ci Chrystus.
###### **Ef 5,15**
 Baczcie więc pilnie, jak postępujecie: nie jak niemądrzy, ale jak mądrzy.
###### **Ef 5,16**
 Wyzyskujcie chwilę sposobną, bo dni są złe.
###### **Ef 5,17**
 Nie bądźcie przeto nierozsądni, lecz usiłujcie zrozumieć, co jest wolą Pana.
###### **Ef 5,18**
 I nie upijajcie się winem, bo to jest [przyczyną] rozwiązłości, ale napełniajcie się Duchem,
###### **Ef 5,19**
 przemawiając do siebie wzajemnie psalmami i hymnami, i pieśniami pełnymi ducha, śpiewając i wysławiając Pana w waszych sercach.
###### **Ef 5,20**
 Dziękujcie zawsze za wszystko Bogu Ojcu w imię Pana naszego, Jezusa Chrystusa.
###### **Ef 5,21**
 Bądźcie sobie wzajemnie poddani w bojaźni Chrystusowej.
###### **Ef 5,22**
 Żony niechaj będą poddane swym mężom, jak Panu,
###### **Ef 5,23**
 bo mąż jest głową żony, jak i Chrystus – Głową Kościoła: On – Zbawca Ciała.
###### **Ef 5,24**
 Lecz jak Kościół poddany jest Chrystusowi, tak i żony mężom – we wszystkim.
###### **Ef 5,25**
 Mężowie, miłujcie żony, bo i Chrystus umiłował Kościół i wydał za niego samego siebie,
###### **Ef 5,26**
 aby go uświęcić, oczyściwszy obmyciem wodą, któremu towarzyszy słowo,
###### **Ef 5,27**
 aby samemu sobie przedstawić Kościół jako chwalebny, nie mający skazy czy zmarszczki, czy czegoś podobnego, lecz aby był święty i nieskalany.
###### **Ef 5,28**
 Mężowie powinni miłować swoje żony, tak jak własne ciało. Kto miłuje swoją żonę, siebie samego miłuje.
###### **Ef 5,29**
 Przecież nigdy nikt nie odnosił się z nienawiścią do własnego ciała, lecz [każdy] je żywi i pielęgnuje, jak i Chrystus – Kościół,
###### **Ef 5,30**
 bo jesteśmy członkami Jego Ciała.
###### **Ef 5,31**
 Dlatego opuści człowiek ojca i matkę, a połączy się z żoną swoją, i będą dwoje jednym ciałem.
###### **Ef 5,32**
 Tajemnica to wielka, a ja mówię: w odniesieniu do Chrystusa i do Kościoła.
###### **Ef 5,33**
 W końcu więc niechaj również każdy z was tak miłuje swą żonę jak siebie samego. A żona niechaj ze czcią się odnosi do swojego męża.
# Ef 5 PAU
###### **Ef 5,1**
 Bądźcie więc naśladowcami Boga jak umiłowane dzieci
###### **Ef 5,2**
 i żyjcie w miłości na wzór Chrystusa, który nas umiłował i samego siebie wydał za nas jako dar i ofiarę dla Boga, jako miłą woń.
###### **Ef 5,3**
 Jak przystoi świętym, niech nie będzie u was mowy o nierządzie i nieczystości albo o chciwości.
###### **Ef 5,4**
 Nie pozwalajcie sobie na bezwstydne postępowanie, niedorzeczne gadanie czy niestosowne żarty, lecz postępujcie w życzliwości.
###### **Ef 5,5**
 To bowiem powinniście wiedzieć, że nikt rozpustny, bezwstydny lub skąpy, czyli bałwochwalca, nie ma dziedzictwa w królestwie Chrystusa i Boga.
###### **Ef 5,6**
 Niech was nikt nie zwodzi pustym gadaniem, bo przez nie nadchodzi gniew Boży na synów buntu.
###### **Ef 5,7**
 Nie miejcie z nimi nic wspólnego.
###### **Ef 5,8**
 Niegdyś byliście ciemnością, teraz zaś jesteście światłością w Panu. Postępujecie więc jak dzieci światłości!
###### **Ef 5,9**
 A owocem światłości jest wszelka dobroć, sprawiedliwość i prawda.
###### **Ef 5,10**
 Starajcie się rozeznać, co podoba się Panu
###### **Ef 5,11**
 i nie miejcie udziału w bezowocnych czynach ciemności. Co więcej, ukazujcie je,
###### **Ef 5,12**
 bo aż wstyd mówić o tym, co u nich dzieje się po kryjomu.
###### **Ef 5,13**
 Wszystko natomiast, co jest ukazane, wychodzi na jaw dzięki światłu.
###### **Ef 5,14**
 Wszystko bowiem, co zostaje ujawnione, jest światłem. Dlatego powiedziano: Zbudź się, o śpiący, i powstań z martwych, a oświeci cię Chrystus.
###### **Ef 5,15**
 Uważajcie więc, jak postępujecie: nie jak niemądrzy, ale jako mądrzy.
###### **Ef 5,16**
 Wykorzystujcie okazję, bo dni są złe.
###### **Ef 5,17**
 Dlatego nie bądźcie nierozumni, ale starajcie się pojąć, jaka jest wola Pana.
###### **Ef 5,18**
 Nie upijajcie się winem, przez co dochodzi do rozwiązłości, lecz napełniajcie się Duchem.
###### **Ef 5,19**
 Odmawiajcie wspólnie psalmy, hymny i natchnione pieśni, śpiewając Panu i uwielbiając Go całym sercem.
###### **Ef 5,20**
 Zawsze bądźcie za wszystko wdzięczni Bogu i Ojcu w imię naszego Pana, Jezusa Chrystusa.
###### **Ef 5,21**
 Bądźcie sobie wzajemnie poddani w bojaźni Chrystusowej.
###### **Ef 5,22**
 Żony niech będą poddane mężom jak Panu,
###### **Ef 5,23**
 ponieważ mąż jest głową żony, jak Chrystus jest Głową Kościoła - On, Zbawca Ciała.
###### **Ef 5,24**
 I jak Kościół jest poddany Chrystusowi we wszystkim, tak żony niech będą poddane mężom.
###### **Ef 5,25**
 Mężowie miłujcie swoje żony, tak jak Chrystus umiłował swój Kościół i wydał za niego samego siebie,
###### **Ef 5,26**
 aby go uświęcić przez oczyszczenie kąpielą wody i słowem,
###### **Ef 5,27**
 aby postawić go przy sobie jako Kościół chwalebny, bez skazy i zmarszczki, czy czegoś podobnego, aby był święty i nieskalany.
###### **Ef 5,28**
 Mężowie tak powinni miłować swoje żony jak własne ciało. Kto miłuje swoją żonę, siebie samego miłuje.
###### **Ef 5,29**
 Nikt nigdy nie znienawidził własnego ciała, lecz każdy je karmi i pielęgnuje, tak jak Chrystus Kościół.
###### **Ef 5,30**
 Otóż my tworzymy z Nim jedno Ciało.
###### **Ef 5,31**
 I tak mężczyzna opuści ojca i matkę, a złączy się ze swoją żoną i dwoje będą jednym ciałem.
###### **Ef 5,32**
 Jest to wielka tajemnica, a ja mówię w odniesieniu do Chrystusa i do Kościoła.
###### **Ef 5,33**
 Niech więc każdy z was tak miłuje swoją żonę jak siebie samego. Żona natomiast niech odnosi się do swego męża z szacunkiem.
# Ef 5 BP
###### **Ef 5,1**
 Naśladujcie Boga jako [Jego] dzieci umiłowane.
###### **Ef 5,2**
 Żyjcie w miłości, jak i Chrystus umiłował nas i wydał siebie samego za nas jako dar i ofiarę na wdzięczną wonność Bogu.
###### **Ef 5,3**
 A nierząd, wszelka nieczystość czy chciwość niechaj nie będą nawet wspominane wśród was, bo tak przystoi świętym.
###### **Ef 5,4**
 Podobnie bezwstyd, niedorzeczne gadanie i nieprzyzwoite żarty nie przystoją wam. Oddajcie się raczej modlitwie dziękczynnej.
###### **Ef 5,5**
 Trzeba [wam] o tym wiedzieć, że żaden rozpustnik lub bezwstydnik, żaden chciwiec, który jest bałwochwalcą, nie ma dziedzictwa w królestwie Chrystusa i Boga.
###### **Ef 5,6**
 Nie dajcie się omamić próżnymi słowami, bo to wszystko sprowadza gniew Boży na buntowników.
###### **Ef 5,7**
 Nie stawajcie się ich wspólnikami.
###### **Ef 5,8**
 Wprawdzie niegdyś byliście ciemnością, lecz teraz jesteście światłością w Panu. Postępujcie więc jak dzieci światłości.
###### **Ef 5,9**
 A owocem światłości jest wszelka dobroć, sprawiedliwość i prawda.
###### **Ef 5,10**
 Baczcie na to, co jest miłe Panu.
###### **Ef 5,11**
 I nie miejcie nic wspólnego z bezowocnymi czynami ciemności, co więcej, piętnujcie je.
###### **Ef 5,12**
 Bo nawet wstyd mówić o tym, czego oni w skrytości się dopuszczają.
###### **Ef 5,13**
 Wszystko zaś, co jest napiętnowane, staje się jawne dzięki światłu.
###### **Ef 5,14**
 Wszystko też, co zostaje ujawnione, staje się światłem. Dlatego [hymn] mówi: Zbudź się z uśpienia i powstań z martwych, a Chrystus cię oświeci.
###### **Ef 5,15**
 Baczcie zatem uważnie, jak postępujecie. Nie postępujcie nierozsądnie, lecz mądrze.
###### **Ef 5,16**
 Wykorzystujcie każdą sposobną chwilę, bo nadeszły złe dni.
###### **Ef 5,17**
 Dlatego też nie bądźcie bezmyślni, lecz starajcie się zrozumieć, jaka jest wola Pana.
###### **Ef 5,18**
 Nie upijajcie się winem, bo to prowadzi do rozwiązłości, lecz napełnieni Duchem [Świętym]
###### **Ef 5,19**
 odmawiajcie wspólnie psalmy, hymny i pieśni duchowe. Śpiewajcie Panu z całego serca pieśń pochwalną.
###### **Ef 5,20**
 Zawsze za wszystko dziękujcie Bogu i Ojcu w imię naszego Pana, Jezusa Chrystusa.
###### **Ef 5,21**
 Bądźcie podlegli sobie nawzajem w bojaźni Chrystusowej.
###### **Ef 5,22**
 Żony swoim mężom jak Panu,
###### **Ef 5,23**
 gdyż mąż jest dla żony głową, jak Chrystus jest Głową dla Kościoła, On, Zbawiciel Ciała.
###### **Ef 5,24**
 Jak Kościół podległy Chrystusowi, tak niech żony będą podległe we wszystkim mężom.
###### **Ef 5,25**
 Mężowie, miłujcie [wasze] żony, jak Chrystus umiłował Kościół i wydał zań samego siebie,
###### **Ef 5,26**
 aby go uświęcić, oczyściwszy przez obmycie wodą, połączone ze słowem,
###### **Ef 5,27**
 aby przygotować sobie Kościół chwalebny, bez skazy, bez jakichkolwiek uchybień, lecz święty i nieskalany.
###### **Ef 5,28**
 Mężowie powinni miłować swoje żony jak własne ciało. Kto miłuje swoją żonę, sam siebie miłuje.
###### **Ef 5,29**
 Bo nikt nigdy nie miał w nienawiści swojego ciała, ale żywi je i troszczy się o nie jak Chrystus o Kościół.
###### **Ef 5,30**
 My zaś jesteśmy członkami Jego Ciała.
###### **Ef 5,31**
 Dlatego też "mężczyzna opuści ojca i matkę, przyłączy się do swojej żony i tak tych dwoje staną się jednym ciałem".
###### **Ef 5,32**
 Wielka to tajemnica! Ja to mówię w odniesieniu do Chrystusa i do Kościoła.
###### **Ef 5,33**
 A zatem każdy z was niech miłuje swoją żonę, jak siebie samego, a żona niech odnosi się ze czcią do swojego męża.
# Ef 5 BR
###### **Ef 5,1**
 Naśladujcie tedy Boga, gdyż jesteście Jego umiłowanymi dziećmi.
###### **Ef 5,2**
 W waszym postępowaniu kierujcie się miłością, bo Chrystus umiłował was i samego siebie wydał za nas jako ofiarę i dar o woni miłej dla Boga.
###### **Ef 5,3**
 O nierządzie zaś i wszelkiej nieczystości lub chciwości nie może być nawet mowy wśród was, którzy stanowicie lud święty.
###### **Ef 5,4**
 Nie wypada też, byście się posługiwali jakimiś grubiaństwami, by miała miejsce wśród was bezsensowna gadanina lub nieprzyzwoite żarty. Powinniście być raczej pełni wdzięczności jedni względem drugich.
###### **Ef 5,5**
 Musicie bowiem pamiętać, że ci, którzy się oddają rozpuście, nieczystości lub grzeszą chciwością - być chciwym to znaczy służyć idolom - nigdy nie będą mieli udziału w królestwie Chrystusa i Boga.
###### **Ef 5,6**
 Niech was nikt nie zwodzi pięknymi słówkami: żebyście wiedzieli, że to właśnie z powodu takich występków gniew Boży spadnie na tych, którzy nie słuchają Boga.
###### **Ef 5,7**
 Nie miejcie więc nic wspólnego z tego rodzaju ludźmi.
###### **Ef 5,8**
 Kiedyś trwaliście w ciemności, lecz teraz, dzięki waszemu zjednoczeniu z Panem, znajdujecie się w światłości i dlatego musicie postępować jak synowie światłości.
###### **Ef 5,9**
 Owocem światłości jest bowiem wszelka prawość, sprawiedliwość i prawda.
###### **Ef 5,10**
 Starajcie się też zawsze o to, co miłe Panu,
###### **Ef 5,11**
 i nie miejcie nic wspólnego z tymi, którzy dopuszczają się uczynków ciemności. Starajcie się raczej odwieść ich od złego.
###### **Ef 5,12**
 Wstyd nawet mówić o tym, czego ci ludzie dokonują w skrytości.
###### **Ef 5,13**
 Kiedy zaś wszystkie te uczynki wyjdą na jaw, wtedy dopiero okaże się, czym naprawdę są.
###### **Ef 5,14**
 Wszystko bowiem, co zostaje dokładnie ujawnione, staje się światłością. Dlatego też jest powiedziane: Przebudź się, ty, który śpisz, i powstań spomiędzy umar-łych, a Chrystus olśni cię swoim światłem.
###### **Ef 5,15**
 Badajcie więc sami wasze postępowanie, żyjcie jak ludzie rozsądni, a nie jak głupi.
###### **Ef 5,16**
 Wykorzystujcie każdą sposobność [by dobrze czynić], bo dni są złe.
###### **Ef 5,17**
 Nie bądźcie więc nierozsądni, lecz starajcie się zrozumieć, jaka jest [względem was] wola Pana.
###### **Ef 5,18**
 Nie upijajcie się też winem, bo to was doprowadzi do rozwiązłości, lecz bądźcie pełni Ducha [Świętego].
###### **Ef 5,19**
 Przemawiając jedni do drugich, posługujcie się psalmami, hymnami i pieśniami, pełnymi ducha [gorliwości] śpiewajcie Panu i wysławiajcie Go w waszych sercach.
###### **Ef 5,20**
 I nie przestawajcie też dziękować za wszystko Bogu Ojcu w imię Pana naszego Jezusa Chrystusa.
###### **Ef 5,21**
 Bądźcie także poddani sobie, kierując się nawzajem bojaźnią Chrystusa.
###### **Ef 5,22**
 Żony niech będą poddane swym mężom, tak jakby ulegały samemu Panu.
###### **Ef 5,23**
 Mąż jest bowiem głową żony, podobnie jak Chrystus jest Głową Kościoła. Jest On również Zbawcą swego Ciała [Kościoła].
###### **Ef 5,24**
 I jak Kościół jest poddany Chrystusowi, tak też żony powinny ulegać we wszystkim swoim mężom.
###### **Ef 5,25**
 Mężowie niech miłują swoje żony, bo Chrystus również umiłował Kościół i wydał zań samego siebie.
###### **Ef 5,26**
 Chciał przez to uświęcić Kościół i obmyć go wodą przy użyciu słowa;
###### **Ef 5,27**
 pragnął stawić przed sobą ów Kościół w całym jego pięknie, bez żadnej skazy lub rysy albo jakiegoś braku, ale w świętości i nieskazitelności.
###### **Ef 5,28**
 Mężowie powinni miłować żony tak jak własne ciała. Kto miłuje swoją żonę, siebie samego miłuje.
###### **Ef 5,29**
 Wiadomo przecież, że nikt nigdy nie ma w nienawiści własnego ciała; przeciwnie, karmi je i otacza troską, jak Chrystus Kościół.
###### **Ef 5,30**
 Wszyscy bowiem jesteśmy członkami Jego Ciała.
###### **Ef 5,31**
 Dlatego [mówi Pismo]: Opuści człowiek ojca i matkę i przejdzie do swojej żony, i odtąd będą stanowić jedno ciało.
###### **Ef 5,32**
 Chodzi w tych słowach o wielką tajemnicę, a ja wam mówię, że to tajemnica Chrystusa i Kościoła.
###### **Ef 5,33**
 [Lecz odnosi się również do każdego z was]. Niech więc każdy miłuje swoją żonę, tak jak siebie samego, a każda żona niech okazuje szacunek mężowi.
# Ef 5 WUJ
###### **Ef 5,1**
 Bądźcież tedy naśladowcami Bożymi: jako synowie namilsi:
###### **Ef 5,2**
 A chodźcie w miłości, jako i Chrystus umiłował nas, i wydał samego siebie za nas obiatą i ofiarą Bogu na wonność wdzięczności.
###### **Ef 5,3**
 A porubstwo i wszelka nieczystość, abo łakomstwo, niechaj nie będzie ani pomieniono między wami, jako świętym przystoi:
###### **Ef 5,4**
 Abo sprosność, abo głupia mowa, abo żartowanie, które do rzeczy nie należy: ale raczej dziękowanie.
###### **Ef 5,5**
 Bo to wiedzcie, rozumiejąc, iż wszelki porubca, abo nieczysty, abo łakomiec (co jest bałwochwalstwo) nie ma dziedzictwa w królestwie Chrystusowem i Bożem.
###### **Ef 5,6**
 Niechaj was nikt nie zwodzi próżnemi słowy. Abowiem dla tegoć przychodzi gniew Boży na syny niewierności.
###### **Ef 5,7**
 Nie bądźcież tedy uczestnikami ich.
###### **Ef 5,8**
 Abowiemeście byli niekiedy ciemnością: lecz teraz światłością w Panu. Jako synowie światłości chodźcie:
###### **Ef 5,9**
 Bo owoc światłości, jest we wszelakiej dobrotliwości, i sprawiedliwości, i prawdzie.
###### **Ef 5,10**
 Doświadczając co jest wdzięcznego Bogu:
###### **Ef 5,11**
 A nie spółkujcie z uczynkami niepożytecznemi ciemności, ale raczej strofujcie.
###### **Ef 5,12**
 Abowiem co się od nich potajemnie dzieje, sromota i powiadać.
###### **Ef 5,13**
 A wszystko co bywa strofowano, od światłości bywa objawiono. Bo wszystko co objawiono bywa, jest światło.
###### **Ef 5,14**
 Dla tego mówi: Wstań który spisz, i powstań z martwych, a oświeci cię Chrystus.
###### **Ef 5,15**
 Patrzcież tedy bracia, jakobyście ostrożnie chodzili: nie jako nie mądrzy, ale jako mądrzy:
###### **Ef 5,16**
 Czas odkupując, iż dni złe są.
###### **Ef 5,17**
 A przetoż nie bądźcie nieroztropnemi: ale rozumiejącemi, która jest wola Boga.
###### **Ef 5,18**
 A nie upijajcie się winem, w którem jest nieczystota, ale bądźcie napełnieni Duchem świętym:
###### **Ef 5,19**
 Rozmawiając sobie w Psalmiech, i w pieśniach, i w śpiewaniach duchownych, śpiewając i grając w sercach waszych Panu:
###### **Ef 5,20**
 Dziękując zawsze za wszystko, w imię Pana naszego Jezusa Chrystusa Bogu i Ojcu.
###### **Ef 5,21**
 Będąc poddanemi jedni drugim, w bojaźni Chrystusowej.
###### **Ef 5,22**
 Żony niechaj będą poddane mężom swym, jako Panu:
###### **Ef 5,23**
 Abowiem mąż jest głową żony, jako Chrystus jest głową kościoła: On zbawicielem ciała jego,
###### **Ef 5,24**
 Ale jako kościół poddany jest Chrystusowi, tak też żony swoim mężom we wszystkiem.
###### **Ef 5,25**
 Mężowie, miłujcie żony wasze, jako i Chrystus umiłował kościół, i samego siebie wydał zań:
###### **Ef 5,26**
 Aby ji poświęcił, oczyściwszy ji omyciem wody w słowie żywota:
###### **Ef 5,27**
 Aby sam sobie wystawił kościół chwalebny, niemający zmazy, abo zmarsku, abo czego takowego: ale iżby był święty i niepokalany.
###### **Ef 5,28**
 Tak i mężowie mają miłować żony swoje, jako swoje ciała. Kto miłuje żonę swoję: samego siebie miłuje.
###### **Ef 5,29**
 Abowiem nigdy żaden ciała swego nie miał w nienawiści: ale je wychowywa i ogrzewa, jako i Chrystus kościół.
###### **Ef 5,30**
 Bo jesteśmy członkami ciała jego, z ciała jego i z kości jego.
###### **Ef 5,31**
 Dla tego opuści człowiek ojca i matkę swoję: i złączy się z żoną swoją: i będą dwoje w jednem ciele.
###### **Ef 5,32**
 Sakrament to wielki jest: a ja mówię w Chrystusie i w kościele.
###### **Ef 5,33**
 Wszakże i każdy z was z osobna, niechaj miłuje żonę swoję, jako siebie samego: a żona niech się boi męża swego.
# Ef 5 STERN
###### **Ef 5,1**
 Naśladujcie więc Boga jako Jego ukochane dzieci
###### **Ef 5,2**
 i wiedźcie życie w miłości, tak jak Mesjasz nas zaiste umiłował i złożył siebie za nas na ofiarę, jako ofiara zabita dla Boga, miła woń.
###### **Ef 5,3**
 Nie powinno się wśród was nawet wspominać o rozwiązłości czy jakiejkolwiek nieczystości, czy chciwości - te zupełnie nie przystają świętemu ludowi Bożemu.
###### **Ef 5,4**
 Nie na miejscu jest też wulgarność i głupie paplanie czy grubiańskie słowa, powinniście natomiast składać dzięki.
###### **Ef 5,5**
 Bo tego możecie być pewni: żaden człowiek rozwiązły, nieczysty lub chciwy - czyli żaden bałwochwalca - nie ma udziału w Królestwie Mesjasza i Boga.
###### **Ef 5,6**
 Niech nikt was nie zwodzi próżną gadaniną, bo to z powodu tych rzeczy sąd Boga nadchodzi na tych, którzy są Mu nieposłuszni.
###### **Ef 5,7**
 Nie dołączajcie więc do nich!
###### **Ef 5,8**
 Bo byliście niegdyś w ciemności, ale teraz, zjednoczeni z Panem, jesteście światłością. Żyjcie jak dzieci światłości,
###### **Ef 5,9**
 bo owoc światłości jest we wszelkiego rodzaju dobroci, prawości i prawdzie -
###### **Ef 5,10**
 starajcie się dociec, co się spodoba Panu.
###### **Ef 5,11**
 Nie miejcie nic wspólnego z czynami zrodzonymi przez ciemność, ale je obnażajcie,
###### **Ef 5,12**
 bo wstyd nawet mówić o tym, co ci ludzie potajemnie robią.
###### **Ef 5,13**
 Lecz prawdziwa natura wszystkiego, co wystawia się na światło, zostaje objawiona,
###### **Ef 5,14**
 ponieważ wszystko, co objawione, jest jakimś światłem. Dlatego powiedziano: "Wstań, o śpiący! Powstań z martwych, a Mesjasz zajaśnieje nad tobą!"
###### **Ef 5,15**
 Dlatego uważajcie pilnie, w jaki sposób żyjecie - żyjcie mądrze, a nie niemądrze.
###### **Ef 5,16**
 Dobrze wykorzystujcie czas, bo dni są złe.
###### **Ef 5,17**
 Nie bądźcie więc głupi, ale starajcie się zrozumieć, jaka jest wola Pana.
###### **Ef 5,18**
 Nie upijajcie się winem, bo przez to tracicie panowanie nad sobą. Za to ciągle bądźcie napełnieni Duchem -
###### **Ef 5,19**
 śpiewajcie sobie wzajemnie psalmy, hymny i pieśni duchowe, śpiewajcie Panu i grajcie Mu w swoich sercach.
###### **Ef 5,20**
 Zawsze za wszystko składajcie dzięki Bogu Ojcu w imieniu Pana Jeszui Mesjasza.
###### **Ef 5,21**
 Podporządkowujcie się jedni drugim w bojaźni Mesjasza.
###### **Ef 5,22**
 Żony powinny podporządkować się mężom, tak jak podporządkowują się Panu,
###### **Ef 5,23**
 bo mąż jest głową żony, podobnie jak Mesjasz jako głowa Wspólnoty Mesjanicznej jest Tym, który zapewnia ciału bezpieczeństwo.
###### **Ef 5,24**
 Jak Wspólnota Mesjaniczna podporządkowuje się Mesjaszowi, tak i żony powinny podporządkowywać się swym mężom we wszystkim.
###### **Ef 5,25**
 Mężowie zaś, kochajcie swoje żony, tak jak Mesjasz ukochał Wspólnotę Mesjaniczną i samego siebie oddał za nią,
###### **Ef 5,26**
 aby ją zastrzec dla Boga, oczyściwszy ją - jeśli można tak rzec - przez zanurzenie w mikwe,
###### **Ef 5,27**
 aby przyszykować sobie Wspólnotę Mesjaniczną jako oblubienicę, którą można się chlubić, bez zmazy, zmarszczki czy innej podobnej rzeczy, lecz świętą i bez skazy.
###### **Ef 5,28**
 Tak mężowie powinni kochać swoje żony - jak własne ciało. Bo mężczyzna, który kocha żonę, sam siebie kocha.
###### **Ef 5,29**
 Bo przecież nikt nigdy nie nienawidził własnego ciała! Przeciwnie, karmi je dobrze i troszczy się o nie, tak jak to czyni Mesjasz ze Wspólnotą Mesjaniczną,
###### **Ef 5,30**
 bo jesteśmy członkami Jego Ciała.
###### **Ef 5,31**
 "Dlatego mężczyzna opuści swego ojca i matkę i pozostanie ze swą żoną, i tych dwoje będzie jednym".
###### **Ef 5,32**
 Jest w tym ukryta głęboka prawda, która - jak twierdzę - dotyczy Mesjasza i Wspólnoty Mesjanicznej.
###### **Ef 5,33**
 Tekst ten jednak odnosi się również do każdego z was z osobna; niech każdy mężczyzna kocha żonę jak samego siebie i niech żona szanuje swego męża.
# Ef 5 TRO
###### **Ef 5,1**
 **γινεσθε** *ginesthe* Stawajcie się [[G1096]] WTV-PNM-2P **ουν** *oun* więc [[G3767]] [[CONJ]] **μιμηται** *mimētai* naśladowcy [[G3402]] WTN-NPM **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ως** *hōs* jak [[G5613]] [[ADV]] **τεκνα** *tekna* dzieci [[G5043]] WTN-NPN **αγαπητα** *agapēta* umiłowane [[G27]] WTA-NPN
###### **Ef 5,2**
 **και** *kai* i [[G2532]] [[CONJ]] **περιπατειτε** *peripateite* postępujcie – chodźcie [[G4043]] WTV-PAM-2P **εν** *en* w [[G1722]] [[PREP]] **αγαπη** *agapē* miłości [[G26]] [[N-DSF]] **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **ηγαπησεν** *ēgapēsen* umiłował [[G25]] [[V-AAI-3S]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **και** *kai* i [[G2532]] [[CONJ]] **παρεδωκεν** *paredōken* wydał [[G3860]] [[V-AAI-3S]] **εαυτον** *heauton* siebie samego [[G1438]] WTF-3ASM **υπερ** *hyper* za [[G5228]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP **προσφοραν** *prosforan* dar [[G4376]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **θυσιαν** *thysian* ofiarę [[G2378]] WTN-ASF **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **εις** *eis* na [[G1519]] [[PREP]] **οσμην** *osmēn* woń [[G3744]] WTN-ASF **ευωδιας** *euōdias* aromatu – słodkiego zapachu [[G2175]] [[N-GSF]]
###### **Ef 5,3**
 **πορνεια** *porneia* Nierząd – Wszeteczeństwo [[G4202]] [[N-NSF]] **δε** *de* zaś [[G1161]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **πασα** *pasa* każda [[G3956]] WTA-NSF **ακαθαρσια** *akatharsia* nieczystość [[G167]] [[N-NSF]] **η** *ē* lub [[G2228]] WTPRT **πλεονεξια** *pleoneksia* chciwość – zachłanność [[G4124]] [[N-NSF]] **μηδε** *mēde* ani nie [[G3366]] [[CONJ]] **ονομαζεσθω** *onomazesthō* niech będzie wymieniana – niech będzie nazywany [[G3687]] WTV-PPM-3S **εν** *en* wśród [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **πρεπει** *prepei* przystoi [[G4241]] WTV-PQI-3S **αγιοις** *hagiois* świętym [[G40]] WTA-DPM
###### **Ef 5,4**
 **και** *kai* i [[G2532]] [[CONJ]] **αισχροτης** *aischrotēs* haniebność – nieprzyzwoitość [[G151]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **μωρολογια** *mōrologia* głupie mówienie [[G3473]] [[N-NSF]] **η** *ē* lub [[G2228]] WTPRT **ευτραπελια** *eutrapelia* błazeństwo [[G2160]] [[N-NSF]] **τα** *ta* [[G3588]] WTT-NPN **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ανηκοντα** *anēkonta* które przystoją – będące stosownymi [[G433]] WTV-PAP-NPN **αλλα** *alla* ale [[G235]] [[CONJ]] **μαλλον** *mallon* bardziej [[G3123]] [[ADV]] **ευχαριστια** *eucharistia* dziękczynienie – wdzięczność [[G2169]] [[N-NSF]]
###### **Ef 5,5**
 **τουτο** *touto* To [[G5124]] WTD-NSN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **γινωσκοντες** *ginōskontes* wiedząc [[G1097]] WTV-PAP-NPM **οτι** *hoti* że [[G3754]] [[CONJ]] **πας** *pas* każdy [[G3956]] [[A-NSM]] **πορνος** *pornos* rozpustnik – wszetecznik [[G4205]] [[N-NSM]] **η** *ē* lub [[G2228]] WTPRT **ακαθαρτος** *akathartos* nieczysty [[G169]] [[A-NSM]] **η** *ē* lub [[G2228]] WTPRT **πλεονεκτης** *pleonektēs* chciwiec – zachłanny [[G4123]] [[N-NSM]] **ος** *hos* co [[G3739]] WTR-NSM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ειδωλολατρης** *eidōlolatrēs* bałwochwalca [[G1496]] [[N-NSM]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εχει** *echei* ma [[G2192]] WTV-PAI-3S **κληρονομιαν** *klēronomian* dziedziczenia [[G2817]] WTN-ASF **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **βασιλεια** *basileia* Królestwie [[G932]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **Ef 5,6**
 **μηδεις** *mēdeis* Nikt [[G3367]] [[A-NSM]] **υμας** *hymas* was [[G5209]] WTP-2AP **απατατω** *apatatō* niech zwodzi [[G538]] WTV-PAM-3S **κενοις** *kenois* pustymi – próżnymi [[G2756]] WTA-DPM **λογοις** *logois* słowami [[G3056]] WTN-DPM **δια** *dia* z powodu [[G1223]] [[PREP]] **ταυτα** *tauta* tych [[G5023]] WTD-APN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ερχεται** *erchetai* przychodzi [[G2064]] WTV-PNI-3S **η** *hē* [[G3588]] [[T-NSF]] **οργη** *orgē* gniew [[G3709]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **επι** *epi* na [[G1909]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **υιους** *hyious* synów [[G5207]] [[N-APM]] **της** *tēs* [[G3588]] [[T-GSF]] **απειθειας** *apeitheias* nieposłuszeństwa – nieuległości [[G543]] [[N-GSF]]
###### **Ef 5,7**
 **μη** *mē* Nie [[G3361]] [[PRT-N]] **ουν** *oun* więc [[G3767]] [[CONJ]] **γινεσθε** *ginesthe* stawajcie się [[G1096]] WTV-PNM-2P **συμμετοχοι** *symmetochoi* wspólnikami – współuczestniczącymi [[G4830]] WTA-NPM **αυτων** *autōn* ich [[G846]] WTP-GPM
###### **Ef 5,8**
 **ητε** *ēte* byliście [[G2258]] WTV-IXI-2P **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ποτε** *pote* niegdyś [[G4218]] WTPRT **σκοτος** *skotos* ciemnością [[G4655]] WTN-NSN **νυν** *nyn* teraz [[G3568]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **φως** *fōs* światło [[G5457]] WTN-NSN **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **ως** *hōs* jak [[G5613]] [[ADV]] **τεκνα** *tekna* dzieci [[G5043]] WTN-NPN **φωτος** *fōtos* światła [[G5457]] [[N-GSN]] **περιπατειτε** *peripateite* postępujcie – chodźcie [[G4043]] WTV-PAM-2P
###### **Ef 5,9**
 **ο** *ho* [[G3588]] [[T-NSM]] **γαρ** *gar* bo [[G1063]] [[CONJ]] **καρπος** *karpos* owoc [[G2590]] [[N-NSM]] **του** *tou* [[G3588]] WTT-GSN **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **εν** *en* we [[G1722]] [[PREP]] **παση** *pasē* wszelkiej – każdej [[G3956]] WTA-DSF **αγαθωσυνη** *agathōsynē* dobroci [[G19]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **δικαιοσυνη** *dikaiosynē* sprawiedliwości [[G1343]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **αληθεια** *alētheia* prawdzie [[G225]] [[N-DSF]]
###### **Ef 5,10**
 **δοκιμαζοντες** *dokimazontes* badając [[G1381]] WTV-PAP-NPM **τι** *ti* co [[G5101]] WTI-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ευαρεστον** *euareston* bardzo podobające się [[G2101]] WTA-NSN **τω** *tō* [[G3588]] WTT-DSM **κυριω** *kyriō* Panu [[G2962]] WTN-DSM
###### **Ef 5,11**
 **και** *kai* i [[G2532]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **συγκοινωνειτε** *sygkoinōneite* bądźcie współuczestnikami [[G4790]] WTV-PAM-2P **τοις** *tois* [[G3588]] WTT-DPN **εργοις** *ergois* uczynkom – dziełom [[G2041]] WTN-DPN **τοις** *tois* [[G3588]] WTT-DPN **ακαρποις** *akarpois* bezowocnym – jałowym [[G175]] WTA-DPN **του** *tou* [[G3588]] WTT-GSN **σκοτους** *skotous* ciemności [[G4655]] [[N-GSN]] **μαλλον** *mallon* bardziej [[G3123]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **ελεγχετε** *elegchete* karćcie – zawstydzajcie [[G1651]] WTV-PAM-2P
###### **Ef 5,12**
 **τα** *ta* [[G3588]] WTT-NPN **γαρ** *gar* bo [[G1063]] [[CONJ]] **κρυφη** *kryfē* skrycie [[G2931]] [[ADV]] **γινομενα** *ginomena* stające się [[G1096]] WTV-PNP-APN **υπ** *hyp* przed [[G5259]] [[PREP]] **αυτων** *autōn* nich [[G846]] WTP-GPM **αισχρον** *aischron* haniebne – wstydliwe [[G150]] WTA-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **και** *kai* i [[G2532]] [[CONJ]] **λεγειν** *legein* nazywać [[G3004]] WTV-PAN
###### **Ef 5,13**
 **τα** *ta* [[G3588]] WTT-APN **δε** *de* zaś [[G1161]] [[CONJ]] **παντα** *panta* wszystkie [[G3956]] WTA-APN **ελεγχομενα** *elegchomena* które są zawstydzane – które są obnażone [[G1651]] WTV-PPP-NPN **υπο** *hypo* przez [[G5259]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **φωτος** *fōtos* światło [[G5457]] [[N-GSN]] **φανερουται** *faneroutai* są uczynione widocznymi [[G5319]] WTV-PPI-3S **παν** *pan* wszystko [[G3956]] WTA-NSN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **φανερουμενον** *faneroumenon* które jest czynione widocznym [[G5319]] WTV-PPP-NSN **φως** *fōs* światło [[G5457]] WTN-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S
###### **Ef 5,14**
 **διο** *dio* Dlatego [[G1352]] [[CONJ]] **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **εγειραι** *egeirai* obudź się [[G1453]] WTV-AMM-2S **ο** *ho* [[G3588]] [[T-NSM]] **καθευδων** *katheudōn* śpiący [[G2518]] [[V-PAP-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **αναστα** *anasta* powstań [[G450]] WTV-2AAM-2S-AP **εκ** *ek* z [[G1537]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **νεκρων** *nekrōn* martwych [[G3498]] WTA-GPM **και** *kai* a [[G2532]] [[CONJ]] **επιφαυσει** *epifausei* zajaśnieje – zabłyśnie [[G2017]] WTV-FAI-3S **σοι** *soi* ci [[G4671]] WTP-2DS **ο** *ho* [[G3588]] [[T-NSM]] **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]]
###### **Ef 5,15**
 **βλεπετε** *blepete* Uważajcie – Patrzcie [[G991]] WTV-PAM-2P **ουν** *oun* więc [[G3767]] [[CONJ]] **πως** *pōs* jak [[G4459]] [[ADV]] **ακριβως** *akribōs* uważnie – dokładnie [[G199]] [[ADV]] **περιπατειτε** *peripateite* postępujecie – chodzicie [[G4043]] WTV-PAI-2P **μη** *mē* nie [[G3361]] [[PRT-N]] **ως** *hōs* jak [[G5613]] [[ADV]] **ασοφοι** *asofoi* niemądrzy [[G781]] WTA-NPM **αλλ** *all* ale [[G235]] [[CONJ]] **ως** *hōs* jak [[G5613]] [[ADV]] **σοφοι** *sofoi* mądrzy [[G4680]] WTA-NPM
###### **Ef 5,16**
 **εξαγοραζομενοι** *eksagorazomenoi* wykupując – odkupując [[G1805]] WTV-PMP-NPM **τον** *ton* [[G3588]] [[T-ASM]] **καιρον** *kairon* czas [[G2540]] [[N-ASM]] **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **αι** *hai* [[G3588]] [[T-NPF]] **ημεραι** *hēmerai* dni [[G2250]] [[N-NPF]] **πονηραι** *ponērai* niegodziwe – złe [[G4190]] [[A-NPF]] **εισιν** *eisin* są [[G1526]] WTV-PXI-3P
###### **Ef 5,17**
 **δια** *dia* Przez [[G1223]] [[PREP]] **τουτο** *touto* to [[G5124]] WTD-ASN **μη** *mē* nie [[G3361]] [[PRT-N]] **γινεσθε** *ginesthe* stawajcie się [[G1096]] WTV-PNM-2P **αφρονες** *afrones* nierozsądni – głupi [[G878]] WTA-NPM **αλλα** *alla* ale [[G235]] [[CONJ]] **συνιεντες** *synientes* rozumiejąc – pojmując [[G4920]] WTV-PAP-NPM **τι** *ti* co [[G5101]] WTI-NSN **το** *to* [[G3588]] WTT-NSN **θελημα** *thelēma* wola [[G2307]] WTN-NSN **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]]
###### **Ef 5,18**
 **και** *kai* I [[G2532]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **μεθυσκεσθε** *methyskesthe* być pijanymi [[G3182]] WTV-PPN-2P **οινω** *oinō* winem [[G3631]] WTN-DSM **εν** *en* w [[G1722]] [[PREP]] **ω** *hō* którym [[G3739]] WTR-DSM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ασωτια** *asōtia* rozwiązłość [[G810]] [[N-NSF]] **αλλα** *alla* ale [[G235]] [[CONJ]] **πληρουσθε** *plērousthe* bądźcie napełniani [[G4137]] WTV-PPM-2P **εν** *en* w [[G1722]] [[PREP]] **πνευματι** *pneumati* Duchu [[G4151]] WTN-DSN
###### **Ef 5,19**
 **λαλουντες** *lalountes* mówiąc [[G2980]] WTV-PAP-NPM **εαυτοις** *heautois* sobie samym [[G1438]] WTF-3DPM **ψαλμοις** *psalmois* (przez) psalmy – (przez) pieśni [[G5568]] WTN-DPM **και** *kai* i [[G2532]] [[CONJ]] **υμνοις** *hymnois* hymny [[G5215]] WTN-DPM **και** *kai* i [[G2532]] [[CONJ]] **ωδαις** *ōdais* pieśni [[G5603]] WTN-DPF **πνευματικαις** *pneumatikais* duchowe [[G4152]] WTA-DPF **αδοντες** *adontes* śpiewając [[G103]] WTV-PAP-NPM **και** *kai* i [[G2532]] [[CONJ]] **ψαλλοντες** *psallontes* śpiewając – śpiewając psalmy [[G5567]] WTV-PAP-NPM **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **καρδια** *kardia* sercu [[G2588]] [[N-DSF]] **υμων** *hymōn* waszym [[G5216]] WTP-2GP **τω** *tō* [[G3588]] WTT-DSM **κυριω** *kyriō* Panu [[G2962]] WTN-DSM
###### **Ef 5,20**
 **ευχαριστουντες** *eucharistountes* dziękując [[G2168]] WTV-PAP-NPM **παντοτε** *pantote* zawsze – każdej chwili [[G3842]] [[ADV]] **υπερ** *hyper* za [[G5228]] [[PREP]] **παντων** *pantōn* wszystkie [[G3956]] WTA-GPN **εν** *en* w [[G1722]] [[PREP]] **ονοματι** *onomati* imieniu [[G3686]] WTN-DSN **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **πατρι** *patri* Ojcu [[G3962]] WTN-DSM
###### **Ef 5,21**
 **υποτασσομενοι** *hypotassomenoi* będąc poddanymi – będąc podporządkowani [[G5293]] WTV-PPP-NPM **αλληλοις** *allēlois* jedni drugim [[G240]] WTC-DPM **εν** *en* w [[G1722]] [[PREP]] **φοβω** *fobō* strachu – bojaźni [[G5401]] WTN-DSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **Ef 5,22**
 **αι** *hai* [[G3588]] [[T-NPF]] **γυναικες** *gynaikes* Żony – Kobiety [[G1135]] [[N-NPF]] **τοις** *tois* [[G3588]] WTT-DPM **ιδιοις** *idiois* własnym [[G2398]] WTA-DPM **ανδρασιν** *andrasin* mężom [[G435]] WTN-DPM **υποτασσεσθε** *hypotassesthe* bądźcie poddane – bądźcie podporządkowane [[G5293]] WTV-PMM-2P **ως** *hōs* jak [[G5613]] [[ADV]] **τω** *tō* [[G3588]] WTT-DSM **κυριω** *kyriō* Panu [[G2962]] WTN-DSM
###### **Ef 5,23**
 **οτι** *hoti* bo [[G3754]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **ανηρ** *anēr* mąż [[G435]] [[N-NSM]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **κεφαλη** *kefalē* głowa [[G2776]] [[N-NSF]] **της** *tēs* [[G3588]] [[T-GSF]] **γυναικος** *gynaikos* żony – kobiety [[G1135]] [[N-GSF]] **ως** *hōs* jak [[G5613]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **κεφαλη** *kefalē* głowa [[G2776]] [[N-NSF]] **της** *tēs* [[G3588]] [[T-GSF]] **εκκλησιας** *ekklēsias* zgromadzenia – (społeczności) wywołanych [[G1577]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **αυτος** *autos* On [[G846]] WTP-NSM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **σωτηρ** *sōtēr* Zbawiciel – Wybawca [[G4990]] [[N-NSM]] **του** *tou* [[G3588]] WTT-GSN **σωματος** *sōmatos* ciała [[G4983]] [[N-GSN]]
###### **Ef 5,24**
 **αλλ** *all* Ale [[G235]] [[CONJ]] **ωσπερ** *hōsper* tak, jak [[G5618]] [[ADV]] **η** *hē* [[G3588]] [[T-NSF]] **εκκλησια** *ekklēsia* zgromadzenie – (społeczność) wywołanych [[G1577]] [[N-NSF]] **υποτασσεται** *hypotassetai* jest poddane – jest podporządkowane [[G5293]] WTV-PPI-3S **τω** *tō* [[G3588]] WTT-DSM **χριστω** *christō* Pomazańcowi [[G5547]] WTN-DSM **ουτως** *houtōs* tak [[G3779]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **αι** *hai* [[G3588]] [[T-NPF]] **γυναικες** *gynaikes* żony – kobiety [[G1135]] [[N-NPF]] **τοις** *tois* [[G3588]] WTT-DPM **ιδιοις** *idiois* własnym [[G2398]] WTA-DPM **ανδρασιν** *andrasin* mężom [[G435]] WTN-DPM **εν** *en* we [[G1722]] [[PREP]] **παντι** *panti* wszystkim [[G3956]] WTA-DSN
###### **Ef 5,25**
 **οι** *hoi* [[G3588]] WTT-NPM **ανδρες** *andres* Mężowie [[G435]] WTN-NPM **αγαπατε** *agapate* miłujcie [[G25]] WTV-PAM-2P **τας** *tas* [[G3588]] WTT-APF **γυναικας** *gynaikas* żony – kobiety [[G1135]] WTN-APF **εαυτων** *heautōn* swoje [[G1438]] WTF-3GPM **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **ηγαπησεν** *ēgapēsen* umiłował [[G25]] [[V-AAI-3S]] **την** *tēn* [[G3588]] WTT-ASF **εκκλησιαν** *ekklēsian* zgromadzenie – (społeczność) wywołanych [[G1577]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **εαυτον** *heauton* siebie samego [[G1438]] WTF-3ASM **παρεδωκεν** *paredōken* wydał [[G3860]] [[V-AAI-3S]] **υπερ** *hyper* za [[G5228]] [[PREP]] **αυτης** *autēs* nie [[G846]] [[P-GSF]]
###### **Ef 5,26**
 **ινα** *hina* aby [[G2443]] [[CONJ]] **αυτην** *autēn* go [[G846]] [[P-ASF]] **αγιαση** *hagiasē* uświęciłby [[G37]] WTV-AAS-3S **καθαρισας** *katharisas* oczyściwszy [[G2511]] WTV-AAP-NSM **τω** *tō* [[G3588]] WTT-DSN **λουτρω** *loutrō* kąpielą [[G3067]] WTN-DSN **του** *tou* [[G3588]] WTT-GSN **υδατος** *hydatos* wody [[G5204]] [[N-GSN]] **εν** *en* w [[G1722]] [[PREP]] **ρηματι** *rēmati* przesłaniu – wypowiedzi [[G4487]] WTN-DSN
###### **Ef 5,27**
 **ινα** *hina* aby [[G2443]] [[CONJ]] **παραστηση** *parastēsē* postawiłby przy [[G3936]] WTV-AAS-3S **αυτην** *autēn* nim [[G846]] [[P-ASF]] **εαυτω** *heautō* siebie [[G1438]] WTF-3DSM **ενδοξον** *endokson* (jako) wspaniałe – (jako) dostojne [[G1741]] WTA-ASF **την** *tēn* [[G3588]] WTT-ASF **εκκλησιαν** *ekklēsian* zgromadzenie – (społeczność) wywołanych [[G1577]] WTN-ASF **μη** *mē* nie [[G3361]] [[PRT-N]] **εχουσαν** *echousan* mające [[G2192]] WTV-PAP-ASF **σπιλον** *spilon* plamę [[G4696]] [[N-ASM]] **η** *ē* lub [[G2228]] WTPRT **ρυτιδα** *rytida* zmarszczkę [[G4512]] WTN-ASF **η** *ē* lub [[G2228]] WTPRT **τι** *ti* coś [[G5100]] WTX-ASN **των** *tōn* (z) [[G3588]] WTT-GPN **τοιουτων** *toioutōn* takich [[G5108]] WTD-GPN **αλλ** *all* ale [[G235]] [[CONJ]] **ινα** *hina* aby [[G2443]] [[CONJ]] **η** *ē* byłoby [[G5600]] WTV-PXS-3S **αγια** *hagia* święte [[G40]] WTA-NSF **και** *kai* i [[G2532]] [[CONJ]] **αμωμος** *amōmos* nienaganne – niewinne [[G299]] WTA-NSF
###### **Ef 5,28**
 **ουτως** *houtōs* Tak [[G3779]] [[ADV]] **οφειλουσιν** *ofeilousin* powinni [[G3784]] WTV-PAI-3P **οι** *hoi* [[G3588]] WTT-NPM **ανδρες** *andres* mężowie [[G435]] WTN-NPM **αγαπαν** *agapan* miłować [[G25]] WTV-PAN **τας** *tas* [[G3588]] WTT-APF **εαυτων** *heautōn* swoje [[G1438]] WTF-3GPM **γυναικας** *gynaikas* żony – kobiety [[G1135]] WTN-APF **ως** *hōs* jak [[G5613]] [[ADV]] **τα** *ta* [[G3588]] WTT-APN **εαυτων** *heautōn* swoje [[G1438]] WTF-3GPM **σωματα** *sōmata* ciała [[G4983]] WTN-APN **ο** *ho* [[G3588]] [[T-NSM]] **αγαπων** *agapōn* miłujący [[G25]] [[V-PAP-NSM]] **την** *tēn* [[G3588]] WTT-ASF **εαυτου** *heautou* swoją [[G1438]] WTF-3GSM **γυναικα** *gynaika* żonę – kobietę [[G1135]] WTN-ASF **εαυτον** *heauton* siebie samego [[G1438]] WTF-3ASM **αγαπα** *agapa* miłuje [[G25]] WTV-PAI-3S
###### **Ef 5,29**
 **ουδεις** *oudeis* nikt [[G3762]] [[A-NSM]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ποτε** *pote* dawniej [[G4218]] WTPRT **την** *tēn* [[G3588]] WTT-ASF **εαυτου** *heautou* swoje [[G1438]] WTF-3GSM **σαρκα** *sarka* ciało [[G4561]] WTN-ASF **εμισησεν** *emisēsen* znienawidził [[G3404]] [[V-AAI-3S]] **αλλ** *all* ale [[G235]] [[CONJ]] **εκτρεφει** *ektrefei* pielęgnuje – żywi [[G1625]] WTV-PAI-3S **και** *kai* i [[G2532]] [[CONJ]] **θαλπει** *thalpei* otacza troską – pielęgnuje [[G2282]] WTV-PAI-3S **αυτην** *autēn* je [[G846]] [[P-ASF]] **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **την** *tēn* [[G3588]] WTT-ASF **εκκλησιαν** *ekklēsian* zgromadzenie – (społeczność) wywołanych [[G1577]] WTN-ASF
###### **Ef 5,30**
 **οτι** *hoti* bo [[G3754]] [[CONJ]] **μελη** *melē* członki [[G3196]] WTN-NPN **εσμεν** *esmen* jesteśmy [[G2070]] WTV-PXI-1P **του** *tou* [[G3588]] WTT-GSN **σωματος** *sōmatos* ciała [[G4983]] [[N-GSN]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **εκ** *ek* z [[G1537]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **σαρκος** *sarkos* ciała [[G4561]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **εκ** *ek* z [[G1537]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **οστεων** *osteōn* kości [[G3747]] WTN-GPN **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Ef 5,31**
 **αντι** *anti* Za [[G473]] [[PREP]] **τουτου** *toutou* to [[G5127]] WTD-GSN **καταλειψει** *kataleipsei* pozostawi – opuści [[G2641]] WTV-FAI-3S **ανθρωπος** *anthrōpos* człowiek [[G444]] [[N-NSM]] **τον** *ton* [[G3588]] [[T-ASM]] **πατερα** *patera* ojca [[G3962]] [[N-ASM]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **μητερα** *mētera* matkę [[G3384]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **προσκολληθησεται** *proskollēthēsetai* zostanie złączony [[G4347]] WTV-FPI-3S **προς** *pros* z [[G4314]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **γυναικα** *gynaika* żoną – kobietą [[G1135]] WTN-ASF **αυτου** *autou* jego [[G846]] [[P-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **εσονται** *esontai* będą [[G2071]] WTV-FXI-3P **οι** *hoi* [[G3588]] WTT-NPM **δυο** *dyo* dwoje [[G1417]] WTA-NUI **εις** *eis* w [[G1519]] [[PREP]] **σαρκα** *sarka* ciele [[G4561]] WTN-ASF **μιαν** *mian* jednym [[G1520]] WTA-ASF
###### **Ef 5,32**
 **το** *to* [[G3588]] WTT-NSN **μυστηριον** *mystērion* Tajemnica [[G3466]] WTN-NSN **τουτο** *touto* to [[G5124]] WTD-NSN **μεγα** *mega* wielka [[G3173]] WTA-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **εγω** *egō* ja [[G1473]] WTP-1NS **δε** *de* zaś [[G1161]] [[CONJ]] **λεγω** *legō* mówię [[G3004]] WTV-PAI-1S **εις** *eis* względem [[G1519]] [[PREP]] **χριστον** *christon* Pomazańca [[G5547]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **εις** *eis* względem [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **εκκλησιαν** *ekklēsian* zgromadzenia – (społeczności) wywołanych [[G1577]] WTN-ASF
###### **Ef 5,33**
 **πλην** *plēn* Jednakże [[G4133]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **οι** *hoi* (ci) [[G3588]] WTT-NPM **καθ** *kath* po- [[G2596]] [[PREP]] **ενα** *hena* jedynczo [[G1520]] WTA-ASM **εκαστος** *hekastos* każdy [[G1538]] [[A-NSM]] **την** *tēn* [[G3588]] WTT-ASF **εαυτου** *heautou* swoją [[G1438]] WTF-3GSM **γυναικα** *gynaika* żonę – kobietę [[G1135]] WTN-ASF **ουτως** *houtōs* tak [[G3779]] [[ADV]] **αγαπατω** *agapatō* niech miłuje [[G25]] WTV-PAM-3S **ως** *hōs* jak [[G5613]] [[ADV]] **εαυτον** *heauton* siebie samego [[G1438]] WTF-3ASM **η** *hē* [[G3588]] [[T-NSF]] **δε** *de* zaś [[G1161]] [[CONJ]] **γυνη** *gynē* żona – kobieta [[G1135]] [[N-NSF]] **ινα** *hina* aby [[G2443]] [[CONJ]] **φοβηται** *fobētai* bałaby się – lękałaby się [[G5399]] WTV-PNS-3S **τον** *ton* [[G3588]] [[T-ASM]] **ανδρα** *andra* męża [[G435]] [[N-ASM]]
