# Flm 1 BT5
###### **Flm 1,1**
 Paweł, więzień Chrystusa Jezusa, i Tymoteusz, brat, do Filemona, umiłowanego naszego współpracownika,
###### **Flm 1,2**
 do Apfii, siostry, do naszego towarzysza broni, Archipa, i do Kościoła [gromadzącego] się w twym domu.
###### **Flm 1,3**
 Łaska wam i pokój od Boga, Ojca naszego, i Pana Jezusa Chrystusa.
###### **Flm 1,4**
 Dziękuję Bogu mojemu zawsze, ilekroć wspominam cię w moich modlitwach,
###### **Flm 1,5**
 słysząc o twojej miłości i wierze, jaką żywisz względem Pana Jezusa i dla wszystkich świętych.
###### **Flm 1,6**
 Oby twój udział w wierze okazał się twórczy w głębszym poznaniu wszelkiego dobrego czynu, [jaki jest do spełnienia] wśród was dla Chrystusa.
###### **Flm 1,7**
 Bracie, doznałem wielkiej radości i pociechy z powodu twojej miłości, jako że serca świętych otrzymały od ciebie pokrzepienie.
###### **Flm 1,8**
 Przeto, choć z całą swobodą mogę w Chrystusie nakładać na ciebie obowiązek,
###### **Flm 1,9**
 to jednak raczej proszę w imię miłości, bo taki już jestem. Ja, stary Paweł, a teraz jeszcze więzień Chrystusa Jezusa –
###### **Flm 1,10**
 proszę cię za moim dzieckiem, za tym, którego zrodziłem w kajdanach, za Onezymem.
###### **Flm 1,11**
 Niegdyś dla ciebie nieużyteczny, teraz właśnie i dla ciebie, i dla mnie stał się on bardzo użyteczny.
###### **Flm 1,12**
 Jego ci odsyłam; ty zaś jego, to jest serce moje, przyjmij do domu.
###### **Flm 1,13**
 Zamierzałem go trzymać przy sobie, aby zamiast ciebie oddawał mi usługi w kajdanach, [które noszę dla] Ewangelii.
###### **Flm 1,14**
 Jednakże postanowiłem nie czynić niczego bez twojej zgody, aby dobry twój czyn był nie jakby z musu, ale z dobrej woli.
###### **Flm 1,15**
 Może bowiem po to oddalił się od ciebie na krótki czas, abyś go odebrał na zawsze,
###### **Flm 1,16**
 już nie jako niewolnika, lecz więcej niż niewolnika, jako brata umiłowanego. [Takim jest on] zwłaszcza dla mnie, ileż więcej dla ciebie zarówno w doczesności, jak i w Panu.
###### **Flm 1,17**
 Jeśli więc się poczuwasz do łączności ze mną, przyjmij go jak mnie.
###### **Flm 1,18**
 Jeśli zaś wyrządził ci jakąś szkodę lub winien jest cokolwiek, policz to na mój rachunek.
###### **Flm 1,19**
 Ja, Paweł, piszę to własnoręcznie, ja uiszczę odszkodowanie – nie mówiąc już o tym, że ty w większym stopniu winien mi jesteś samego siebie.
###### **Flm 1,20**
 Tak, bracie, niech ja przez ciebie zaznam radości w Panu: pokrzep moje serce w Chrystusie!
###### **Flm 1,21**
 Piszę do ciebie ufny w twoje posłuszeństwo, świadom, że nawet więcej zrobisz, niż mówię.
###### **Flm 1,22**
 A zarazem przygotuj mi gościnę, ufam bowiem, że będę wam zwrócony dzięki waszym modlitwom.
###### **Flm 1,23**
 Pozdrawia cię Epafras, mój współwięzień w Chrystusie,
###### **Flm 1,24**
 [oraz] Marek, Arystarch, Demas, Łukasz – moi współpracownicy.
###### **Flm 1,25**
 Łaska Pana naszego, Jezusa Chrystusa, [niech będzie] z duchem waszym! Amen.
# Flm 1 PAU
###### **Flm 1,1**
 Paweł, więzień Chrystusa Jezusa, i brat Tymoteusz do umiłowanego Filemona, naszego współpracownika,
###### **Flm 1,2**
 do naszej siostry Apfii, do Archipa, naszego towarzysza, i do Kościoła w twoim domu:
###### **Flm 1,3**
 łaska wam i pokój od Boga, naszego Ojca, i od Pana Jezusa Chrystusa.
###### **Flm 1,4**
 Dziękuję Bogu zawsze, gdy wspominam cię w moich modlitwach,
###### **Flm 1,5**
 bo słyszę o twojej wierze i miłości, jaką żywisz ku Panu Jezusowi i wszystkim świętym.
###### **Flm 1,6**
 Niech wspólna wiara doprowadzi cię do poznania wszelkiego dobra, które jest w nas dzięki Chrystusowi.
###### **Flm 1,7**
 Uradowała mnie bardzo i umocniła twoja miłość. Przez ciebie, bracie, serca świętych doznały pokrzepienia.
###### **Flm 1,8**
 Chociaż mam pełną swobodę nakazywać ci to, co stosowne,
###### **Flm 1,9**
 wolę jednak prosić cię w imię miłości, bo taki już jestem ja, Paweł, starzec, a teraz i więzień Chrystusa Jezusa.
###### **Flm 1,10**
 Wstawiam się za moim dzieckiem, które zrodziłem w więzieniu, za Onezymem.
###### **Flm 1,11**
 Przedtem był on dla ciebie nieużyteczny, teraz jest pomocą zarówno dla ciebie, jak i dla mnie.
###### **Flm 1,12**
 Jego, to jest moje serce, odsyłam do ciebie.
###### **Flm 1,13**
 Miałem zamiar zatrzymać go przy sobie, aby usługiwał mi zamiast ciebie, gdy noszę więzy dla Ewangelii.
###### **Flm 1,14**
 Nie chciałem jednak postanawiać czegokolwiek bez twojej zgody, aby twój dobry czyn nie brał się z przymusu, lecz z własnej woli.
###### **Flm 1,15**
 Może po to oddalił się od ciebie na pewien czas, żebyś go z powrotem odzyskał na zawsze.
###### **Flm 1,16**
 Ale już nie jako niewolnika, lecz więcej niż niewolnika - jako umiłowanego brata: mojego w sposób szczególny, lecz tym bardziej twojego zarówno w tym życiu, jak i w Panu.
###### **Flm 1,17**
 Jeśli więc poczuwasz się do łączności ze mną, przyjmij go, jak mnie.
###### **Flm 1,18**
 A jeśli w czymkolwiek cię obraził lub jest ci coś winien, policz to na mój rachunek.
###### **Flm 1,19**
 Ja, Paweł - piszę to własnoręcznie - ja zapłacę. Nie wspominam ci już, że to ty jesteś mi winien i to samego siebie.
###### **Flm 1,20**
 Tak, bracie! Oddaj mi tę przysługę w Panu. Pokrzep moje serce w Chrystusie.
###### **Flm 1,21**
 Pewny twojego posłuszeństwa piszę do ciebie, wiedząc, że zrobisz jeszcze więcej, niż mówię.
###### **Flm 1,22**
 Proszę cię też, abyś przygotował mi mieszkanie, gdyż mam nadzieję, że dzięki waszym modlitwom Bóg odda mnie wam.
###### **Flm 1,23**
 Pozdrawia cię Epafras, który w Chrystusie Jezusie razem ze mną przebywa w więzieniu,
###### **Flm 1,24**
 oraz moi współpracownicy: Marek, Arystarch, Demas, Łukasz.
###### **Flm 1,25**
 Łaska Pana Jezusa Chrystusa niech będzie z waszym duchem.
# Flm 1 BP
###### **Flm 1,1**
 Paweł, więzień Chrystusa Jezusa, i brat Tymoteusz do naszego przyjaciela i współpracownika Filemona,
###### **Flm 1,2**
 do siostry Apfii, do Archipa, który trudzi się z nami [dla ewangelii] i do Kościoła [gromadzącego się] w twoim domu.
###### **Flm 1,3**
 Łaska wam i pokój od Boga Ojca naszego i od Pana Jezusa Chrystusa.
###### **Flm 1,4**
 Dziękuję Bogu mojemu za każdym razem, ilekroć cię wspominam w moich modlitwach.
###### **Flm 1,5**
 Dowiaduję się bowiem o twojej miłości i zaufaniu, jakie żywisz do Pana Jezusa i do wszystkich świętych.
###### **Flm 1,6**
 Oby twój udział w wierze doprowadził cię do głębszego poznania wszelkiego dobra, które jest wśród nas, ku chwale Chrystusa.
###### **Flm 1,7**
 Ucieszyłeś mnie już, bracie, i podniosłeś na duchu swoją miłością, która sprawia świętym radość.
###### **Flm 1,8**
 Dlatego też, mimo że mam od Chrystusa pełną władzę wymagać od ciebie tego, do czego jesteś zobowiązany,
###### **Flm 1,9**
 ja Paweł, [twój] przełożony, chociaż teraz dźwigam kajdany dla Chrystusa Jezusa, wolę raczej poprosić ciebie w imię miłości.
###### **Flm 1,10**
 Proszę cię zatem w sprawie mojego syna Onezyma, dla którego w więzieniu stałem się ojcem.
###### **Flm 1,11**
 Dawniej nic on dla ciebie nie znaczył, a teraz znaczy wiele i dla ciebie, i dla mnie.
###### **Flm 1,12**
 Odsyłam go, to jest serce moje, do ciebie.
###### **Flm 1,13**
 Chętnie zatrzymałbym go przy sobie, aby w twoim imieniu usługiwał mi w więzieniu [w którym przebywam dla] ewangelii.
###### **Flm 1,14**
 Nie chciałem jednak tego uczynić bez twojej zgody, aby twój wspaniałomyślny gest był dobrowolny, a nie wymuszony.
###### **Flm 1,15**
 Może właśnie dlatego na krótko oddalił się od ciebie, abyś odzyskał go na zawsze,
###### **Flm 1,16**
 już nie jak niewolnika, ale o wiele więcej nad niewolnika, jak umiłowanego brata, najbardziej mi bliskiego. O ile bardziej [bliski on] tobie i jako człowiek, i jako [współwyznawca] w Panu.
###### **Flm 1,17**
 Jeżeli zatem uważasz się za mojego przyjaciela, przyjmij go tak, jakbyś mnie przyjął.
###### **Flm 1,18**
 A jeśli wyrządził ci jakąś szkodę albo jest ci coś winien, zapisz to na mój rachunek.
###### **Flm 1,19**
 Ja, Paweł, zobowiązałem się na piśmie [wszystko] ci spłacić, nie wymawiając, że [właściwie] ty sam do mnie należysz.
###### **Flm 1,20**
 Tak, bracie, liczę więc na twoją przysługę dla Pana. Spraw mi tę radość w Chrystusie.
###### **Flm 1,21**
 Piszę te słowa w nadziei, że spełnisz moją prośbę, a nawet jestem przekonany, że uczynisz więcej niż to, o co proszę.
###### **Flm 1,22**
 Przygotuj mi też gościnę, spodziewam się bowiem, że powrócę do was dzięki waszym modlitwom.
###### **Flm 1,23**
 Pozdrawia cię Epafras, który jest razem ze mną w więzieniu w Chrystusie Jezusie,
###### **Flm 1,24**
 i współpracownicy: Marek, Arystarch, Demas i Łukasz.
###### **Flm 1,25**
 Łaska Pana Jezusa Chrystusa niech będzie z wami.
# Flm 1 BR
###### **Flm 1,1**
 Paweł, więzień dla sprawy Jezusa Chrystusa, i Tymoteusz, brat, do Filemona, umiłowanego towarzysza trudów,
###### **Flm 1,2**
 do Apfii, siostry, do naszego towarzysza [apostolskich] zmagań Archipa i do całego Kościoła zbierającego się w tym domu.
###### **Flm 1,3**
 Bóg, Ojciec nasz, i Pan Jezus Chrystus niech was obdarzą łaską i pokojem.
###### **Flm 1,4**
 Ilekroć modlę się i myślę o tobie, zawsze dziękuję Bogu za ciebie,
###### **Flm 1,5**
 słysząc o twojej miłości względem całej społeczności wiernych oraz o twojej wierze w Pana Jezusa.
###### **Flm 1,6**
 Proszę też Boga, aby wspólnota wiary, wiążącej was wzajemnie, doprowadziła do głębszego poznania tych wszystkich dóbr, które posiadacie, zmierzając do coraz ściślejszego zjednoczenia z Chrystusem.
###### **Flm 1,7**
 Twoja miłość, bracie [mój], sprawiła mi wiele radości i bardzo podniosła mnie na duchu, właśnie dlatego, że stała się pokrzepieniem dla wiernych całej społeczności.
###### **Flm 1,8**
 Toteż, choć posiadam - i to od samego Chrystusa - prawo nakładania na ciebie pewnych obowiązków,
###### **Flm 1,9**
 to jednak [nie nakazuję ci, lecz] proszę w imię naszej miłości wzajemnej. Tak więc ja, Paweł, będąc takim, jakim mnie znasz, teraz już starzec, a nadto i więzień dla sprawy Jezusa Chrystusa,
###### **Flm 1,10**
 zwracam się do ciebie z prośbą w sprawie mojego syna, Onezyma, którego zrodziłem [duchowo] będąc już w więzieniu.
###### **Flm 1,11**
 Człowiek ten niegdyś 'nieużyteczny', teraz i dla mnie, i dla ciebie okazał się bardzo pożyteczny.
###### **Flm 1,12**
 Odsyłam ci go i chciałbym, byś go przyjął jak moje własne serce.
###### **Flm 1,13**
 Zamierzałem początkowo zatrzymać go przy sobie, by - ponieważ ciebie zabrakło - on właśnie oddawał konieczne przysługi mnie, przebywającemu w więzieniu dla Ewangelii.
###### **Flm 1,14**
 Ostatecznie jednak postanowiłem nie czynić niczego bez twojej wyraźnej zgody. Nie chcę cię bowiem zmuszać do żadnego dobrodziejstwa, chcę, żebyś działał w pełni dobrowolnie.
###### **Flm 1,15**
 Może bowiem dlatego Onezym uciekł od ciebie na pewien czas, byś go potem odzyskał na zawsze,
###### **Flm 1,16**
 i to już nie jako zwykłego niewolnika, lecz jako brata umiłowanego? [Jeżeli takim on jest], zwłaszcza dla mnie, to o ileż bardziej dla ciebie - nie tylko ze względu na sprawy doczesne, lecz także ze względu na Pana.
###### **Flm 1,17**
 Tak więc, jeżeli łączy cię cokolwiek ze mną, przyjmij go jak mnie samego.
###### **Flm 1,18**
 A jeżeli wyrządził ci jakąś szkodę lub może jest ci coś winien, zapisz to do wykazu moich długów.
###### **Flm 1,19**
 Piszę ci własnoręcznie to zobowiązanie: Ja, Paweł, uiszczę należność. Nie chcę w tym miejscu przypominać, że ty jesteś u mnie jeszcze większym dłużnikiem. Jesteś mi winien po prostu samego siebie.
###### **Flm 1,20**
 Tak więc, bracie, proszę cię, pozwól mi doznać trochę radości w Panu: pokrzep moje serce w Chrystusie!
###### **Flm 1,21**
 Pisząc to jestem przekonany, że mnie wysłuchasz i uczynisz więcej niż to, o co cię proszę.
###### **Flm 1,22**
 Przy okazji proszę cię, przygotuj mi jakieś schronienie. Mam bowiem nadzieję, że dzięki waszym modlitwom będę wam zwrócony.
###### **Flm 1,23**
 Pozdrawia cię Epafras, mój współwięzień dla sprawy Jezusa Chrystusa,
###### **Flm 1,24**
 oraz Marek, Arystarch, Demas i Łukasz - towarzysze moi.
###### **Flm 1,25**
 Łaska Pana naszego Jezusa Chrystusa niech będzie z wami. Amen.
# Flm 1 WUJ
###### **Flm 1,1**
 Paweł więzień Chrystusa Jezusa, i Tymoteusz brat: Philemonowi miłemu a pomocnikowi naszemu,
###### **Flm 1,2**
 I Appiej siestrze namilszej, i Archippowi towarzyszowi naszemu i zgromadzeniu, które jest w domu twoim.
###### **Flm 1,3**
 Łaska wam i pokój od Boga Ojca naszego, i Pana Jezusa Chrystusa.
###### **Flm 1,4**
 Dziękuję Bogu memu, zawsze pamiętając na cię w modlitwach moich,
###### **Flm 1,5**
 Słysząc o twojej miłości i wierze, którą masz ku Panu Jezusowi, i ku wszem świętym:
###### **Flm 1,6**
 Aby społeczność wiary twej stała się jawna w poznaniu wszego dobrego uczynku, które jest w was w Chrystusie Jezusie.
###### **Flm 1,7**
 Abowiem wesele wielkie miałem i pociechę w miłości twej, iż wnętrzności świętych są przez cię ochłodzone bracie.
###### **Flm 1,8**
 Przetoż mając wielką bezpieczność w Chrystusie Jezusie rozkazać ci co do rzeczy należy:
###### **Flm 1,9**
 Dla miłości raczej proszę, gdyżeś takim jest, jako Paweł stary, a teraz i więzień Jezusa Chrystusa.
###### **Flm 1,10**
 Proszę cię za synem moim, któregom zrodził w więzieniu mojem Onezymem,
###### **Flm 1,11**
 Który tobie niekiedy był niepożytecznym, a teraz i mnie i tobie użytecznym,
###### **Flm 1,12**
 Któregom ci odesłał. A ty przyjmi go jako wnętrzności moje.
###### **Flm 1,13**
 Któregom ja chciał przy sobie zatrzymać, aby mi za cię służył w więzieniu Ewanieljej:
###### **Flm 1,14**
 Wszakże bez twej rady nie chciałem nic czynić, aby dobrodziejstwo twoje nie było jako z przymuszenia, ale z dobrej wolej.
###### **Flm 1,15**
 Abowiem snać dla tego ustąpił na chwilę od ciebie, abyś go przyjął wiecznym:
###### **Flm 1,16**
 Już nie jako sługę, ale miasto sługi brata namiszego, zwłaszcza mnie: jakoż daleko więcej tobie i w ciele i w Panu?
###### **Flm 1,17**
 Jeśli mię tedy masz towarzyszem: przyjmi go jako mnie.
###### **Flm 1,18**
 A jeślić co uszkodził abo winien: to mnie przyczytaj.
###### **Flm 1,19**
 Jam Paweł napisał ręką moją: ja nagrodzę: żebymci nie rzekł, iżeś mi i samego siebie winien.
###### **Flm 1,20**
 Tak bracie. Ja ciebie niech zażyję w Panu. Ochłódź wnętrzności moje w Panu.
###### **Flm 1,21**
 Pisałem ci dufając posłuszeństwu twemu: wiedząc, iż też nad to co mówię, uczynisz.
###### **Flm 1,22**
 A zaraz też zgotuj mi gospodę: abowiem spodziewam się, iż przez modlitwy wasze będę wam darowan.
###### **Flm 1,23**
 Pozdrawia cię Epaphras spół więzień mój w Chrystusie Jezusie,
###### **Flm 1,24**
 Marek, Arystarchus, Demas i Łukasz pomocnicy moi.
###### **Flm 1,25**
 Łaska Pana naszego Jezusa Chrystusa z duchem waszym. Amen.1
# Flm 1 STERN
###### **Flm 1,1**
 Sza'ul, więzień ze względu na Mesjasza Jeszuę, i brat Tymoteusz do naszego drogiego współpracownika Filemona,
###### **Flm 1,2**
 wraz z siostrą Apfią, naszym współbojownikiem Archipem i zgromadzeniem, które zbiera się w twoim domu:
###### **Flm 1,3**
 łaska wam i szalom od Boga, naszego Ojca, i Pana Jeszui Mesjasza.
###### **Flm 1,4**
 Dziękuję mojemu Bogu za każdym razem, gdy wspominam cię w modlitwach, Filemonie,
###### **Flm 1,5**
 bo słyszę o twojej miłości i oddaniu dla Pana Jeszui i dla całego ludu Bożego.
###### **Flm 1,6**
 Modlę się, aby wspólnota oparta na twoim oddaniu zrodziła pełne zrozumienie każdej dobrej rzeczy, jaka należy do nas w jedności z Mesjaszem.
###### **Flm 1,7**
 Bo twoja miłość przydała mi wiele radości i otuchy. Bracie, pokrzepiłeś serca ludu Bożego.
###### **Flm 1,8**
 Dlatego nie będę się wahał, aby w jedności z Mesjaszem zalecić ci, byś uczynił to, co powinieneś.
###### **Flm 1,9**
 Ponieważ jednak ja, Sza'ul, jestem tym, kim jestem, człowiekiem starym, a teraz jeszcze ze względu na Mesjasza Jeszuę więźniem, wolę zwrócić się do ciebie na fundamencie miłości.
###### **Flm 1,10**
 Prośba, jaką mam do ciebie, dotyczy mojego syna, któremu stałem się ojcem tu w więzieniu, Onezyma.
###### **Flm 1,11**
 Jego imię znaczy "użyteczny" i choć był on kiedyś bezużyteczny dla ciebie, teraz stał się nader użyteczny, nie tylko dla ciebie, ale i dla mnie,
###### **Flm 1,12**
 tak że zwracając go tobie, posyłam część mojego własnego serca.
###### **Flm 1,13**
 Gorąco bym pragnął go przy sobie zatrzymać, aby mógł mi usługiwać zamiast ciebie tu w więzieniu, gdzie jestem ze względu na Dobrą Nowinę.
###### **Flm 1,14**
 Ale nie chciałem robić niczego bez twojej zgody, aby dobro, które mi czynisz, było dobrowolne, a nie wymuszone.
###### **Flm 1,15**
 Być może został od ciebie na krótki czas oddzielony, abyś mógł go odzyskać na wieki,
###### **Flm 1,16**
 już nie jako niewolnika, ale więcej niż niewolnika - jako drogiego brata. A jest nim, szczególnie dla mnie. Lecz o ileż droższy musi być tobie, zarówno z ludzkiego punktu widzenia, jak i w jedności z Panem!
###### **Flm 1,17**
 Jeśli zatem jesteś we wspólnocie ze mną, przyjmij go tak, jak byś mnie przyjął.
###### **Flm 1,18**
 A jeśli wyrządził ci jaką szkodę albo jest ci co winien, obciąż tym mnie.
###### **Flm 1,19**
 Ja, Sza'ul, piszę własnoręcznie. Zapłacę za to. (A nie wspomnę tu oczywiście, że jesteś mi winien swoje życie).
###### **Flm 1,20**
 Tak, bracie, uczyń mi, proszę, tę łaskę w Panu, pokrzep moje serce w Mesjaszu.
###### **Flm 1,21**
 Ufny, że odpowiesz pozytywnie, piszę to, wiedząc, że uczynisz więcej niż to, o co proszę.
###### **Flm 1,22**
 Jeszcze jedno: przygotuj dla mnie pomieszczenie. Bo mam nadzieję, że dzięki modlitwom was wszystkich Bóg da mi sposobność odwiedzenia was.
###### **Flm 1,23**
 Epafras, mój współwięzień ze względu na Mesjasza Jeszuę, przesyła ci pozdrowienia,
###### **Flm 1,24**
 podobnie Marek, Arystarch, Demas i Łukasz, moi współpracownicy.
###### **Flm 1,25**
 Łaska Pana Jeszui Mesjasza niech będzie z twoim duchem.1
# Flm 1 TRO
###### **Flm 1,1**
 **παυλος** *paulos* Paweł – [mały] [[G3972]] [[N-NSM]] **δεσμιος** *desmios* więzień [[G1198]] [[N-NSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **τιμοθεος** *timotheos* Tymoteusz – [czczący Boga] [[G5095]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **αδελφος** *adelfos* brat [[G80]] [[N-NSM]] **φιλημονι** *filēmoni* Filemonowi – [przyjazny] [[G5371]] WTN-DSM **τω** *tō* [[G3588]] WTT-DSM **αγαπητω** *agapētō* umiłowanemu [[G27]] WTA-DSM **και** *kai* i [[G2532]] [[CONJ]] **συνεργω** *synergō* współpracownikowi [[G4904]] WTA-DSM **ημων** *hēmōn* naszemu [[G2257]] WTP-1GP
###### **Flm 1,2**
 **και** *kai* i [[G2532]] [[CONJ]] **απφια** *apfia* Apfii [[G682]] [[N-DSF]] **τη** *tē* [[G3588]] WTT-DSF **αγαπητη** *agapētē* umiłowanej [[G27]] WTA-DSF **και** *kai* i [[G2532]] [[CONJ]] **αρχιππω** *archippō* Archipowi – [władca koń] [[G751]] WTN-DSM **τω** *tō* [[G3588]] WTT-DSM **συστρατιωτη** *systratiōtē* współbojownikowi – współżołnierzowi [[G4961]] WTN-DSM **ημων** *hēmōn* naszemu [[G2257]] WTP-1GP **και** *kai* i [[G2532]] [[CONJ]] **τη** *tē* [[G3588]] WTT-DSF **κατ** *kat* w [[G2596]] [[PREP]] **οικον** *oikon* domu [[G3624]] [[N-ASM]] **σου** *sou* twoim [[G4675]] WTP-2GS **εκκλησια** *ekklēsia* zgromadzeniu – (społeczności) wywołanych [[G1577]] [[N-DSF]]
###### **Flm 1,3**
 **χαρις** *charis* łaska [[G5485]] [[N-NSF]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **και** *kai* i [[G2532]] [[CONJ]] **ειρηνη** *eirēnē* pokój [[G1515]] [[N-NSF]] **απο** *apo* od [[G575]] [[PREP]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **πατρος** *patros* Ojca [[G3962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **και** *kai* i [[G2532]] [[CONJ]] **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **Flm 1,4**
 **ευχαριστω** *eucharistō* Dziękuję [[G2168]] WTV-PAI-1S **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **μου** *mou* mojemu [[G3450]] WTP-1GS **παντοτε** *pantote* zawsze – w każdej chwili [[G3842]] [[ADV]] **μνειαν** *mneian* wspomnienie [[G3417]] WTN-ASF **σου** *sou* (o) tobie [[G4675]] WTP-2GS **ποιουμενος** *poioumenos* czyniąc [[G4160]] WTV-PMP-NSM **επι** *epi* w [[G1909]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPF **προσευχων** *proseuchōn* modlitwach [[G4335]] WTN-GPF **μου** *mou* moich [[G3450]] WTP-1GS
###### **Flm 1,5**
 **ακουων** *akouōn* słuchając [[G191]] [[V-PAP-NSM]] **σου** *sou* (o) twojej [[G4675]] WTP-2GS **την** *tēn* [[G3588]] WTT-ASF **αγαπην** *agapēn* miłości [[G26]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **πιστιν** *pistin* wierze [[G4102]] WTN-ASF **ην** *hēn* którą [[G3739]] WTR-ASF **εχεις** *echeis* masz [[G2192]] WTV-PAI-2S **προς** *pros* do [[G4314]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **κυριον** *kyrion* Pana [[G2962]] [[N-ASM]] **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **εις** *eis* względem [[G1519]] [[PREP]] **παντας** *pantas* wszystkich [[G3956]] WTA-APM **τους** *tous* [[G3588]] WTT-APM **αγιους** *hagious* świętych [[G40]] WTA-APM
###### **Flm 1,6**
 **οπως** *hopōs* żeby [[G3704]] [[ADV]] **η** *hē* [[G3588]] [[T-NSF]] **κοινωνια** *koinōnia* wspólnota [[G2842]] [[N-NSF]] **της** *tēs* [[G3588]] [[T-GSF]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **σου** *sou* twojej [[G4675]] WTP-2GS **ενεργης** *energēs* skuteczna – sprawna [[G1756]] WTA-NSF **γενηται** *genētai* stałaby się [[G1096]] WTV-2ADS-3S **εν** *en* w [[G1722]] [[PREP]] **επιγνωσει** *epignōsei* poznaniu [[G1922]] [[N-DSF]] **παντος** *pantos* każdego [[G3956]] [[A-GSN]] **αγαθου** *agathou* dobra [[G18]] [[A-GSN]] **του** *tou* [[G3588]] WTT-GSN **εν** *en* w [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **εις** *eis* względem [[G1519]] [[PREP]] **χριστον** *christon* Pomazańca [[G5547]] [[N-ASM]] **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]]
###### **Flm 1,7**
 **χαραν** *charan* radość [[G5479]] WTN-ASF **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εχομεν** *echomen* mamy [[G2192]] WTV-PAI-1P **πολλην** *pollēn* wielką [[G4183]] WTA-ASF **και** *kai* i [[G2532]] [[CONJ]] **παρακλησιν** *paraklēsin* zachętę [[G3874]] WTN-ASF **επι** *epi* z powodu [[G1909]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **αγαπη** *agapē* miłości [[G26]] [[N-DSF]] **σου** *sou* twojej [[G4675]] WTP-2GS **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **τα** *ta* [[G3588]] WTT-NPN **σπλαγχνα** *splagchna* głębokie uczucia – wnętrzności [[G4698]] WTN-NPN **των** *tōn* [[G3588]] WTT-GPM **αγιων** *hagiōn* świętych [[G40]] WTA-GPM **αναπεπαυται** *anapepautai* doznał odświeżenia (doznały odświeżenia) – doznał pokrzepienia (doznały pokrzepienia) [[G373]] WTV-RPI-3S **δια** *dia* przez [[G1223]] [[PREP]] **σου** *sou* ciebie [[G4675]] WTP-2GS **αδελφε** *adelfe* bracie [[G80]] WTN-VSM
###### **Flm 1,8**
 **διο** *dio* Dlatego [[G1352]] [[CONJ]] **πολλην** *pollēn* wielką [[G4183]] WTA-ASF **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **παρρησιαν** *parrēsian* śmiałość [[G3954]] WTN-ASF **εχων** *echōn* mając [[G2192]] [[V-PAP-NSM]] **επιτασσειν** *epitassein* nakazać – rozkazać [[G2004]] WTV-PAN **σοι** *soi* ci [[G4671]] WTP-2DS **το** *to* [[G3588]] WTT-ASN **ανηκον** *anēkon* co przystoi – będące stosownym [[G433]] WTV-PAP-ASN
###### **Flm 1,9**
 **δια** *dia* przez [[G1223]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **αγαπην** *agapēn* miłość [[G26]] WTN-ASF **μαλλον** *mallon* raczej [[G3123]] [[ADV]] **παρακαλω** *parakalō* proszę – zachęcam [[G3870]] WTV-PAI-1S **τοιουτος** *toioutos* taki [[G5108]] WTD-NSM **ων** *ōn* będąc [[G5607]] [[V-PXP-NSM]] **ως** *hōs* jak [[G5613]] [[ADV]] **παυλος** *paulos* Paweł – [mały] [[G3972]] [[N-NSM]] **πρεσβυτης** *presbytēs* starzec [[G4246]] [[N-NSM]] **νυνι** *nyni* teraz [[G3570]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **δεσμιος** *desmios* więzień [[G1198]] [[N-NSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **Flm 1,10**
 **παρακαλω** *parakalō* proszę – zachęcam [[G3870]] WTV-PAI-1S **σε** *se* cię [[G4571]] WTP-2AS **περι** *peri* o [[G4012]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **εμου** *emou* moje [[G1700]] WTP-1GS **τεκνου** *teknou* dziecko [[G5043]] [[N-GSN]] **ον** *hon* którego [[G3739]] WTR-ASM **εγεννησα** *egennēsa* zrodziłem [[G1080]] WTV-AAI-1S **εν** *en* w [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPM **δεσμοις** *desmois* więzach [[G1199]] WTN-DPM **μου** *mou* moich [[G3450]] WTP-1GS **ονησιμον** *onēsimon* Onezyma – [użyteczny] [[G3682]] [[N-ASM]]
###### **Flm 1,11**
 **τον** *ton* (tego) [[G3588]] [[T-ASM]] **ποτε** *pote* niegdyś – dawniej [[G4218]] WTPRT **σοι** *soi* ci [[G4671]] WTP-2DS **αχρηστον** *achrēston* nieprzydatnego – bezużytecznego [[G890]] WTA-ASM **νυνι** *nyni* teraz [[G3570]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **σοι** *soi* ci [[G4671]] WTP-2DS **και** *kai* i [[G2532]] [[CONJ]] **εμοι** *emoi* mnie [[G1698]] WTP-1DS **ευχρηστον** *euchrēston* pożytecznego – przydatnego [[G2173]] WTA-ASM
###### **Flm 1,12**
 **ον** *hon* którego [[G3739]] WTR-ASM **ανεπεμψα** *anepempsa* odesłałem [[G375]] WTV-AAI-1S **συ** *sy* ci [[G4771]] WTP-2NS **δε** *de* zaś [[G1161]] [[CONJ]] **αυτον** *auton* jego [[G846]] WTP-ASM **τουτ** *tout* to [[G5124]] WTD-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **τα** *ta* [[G3588]] WTT-NPN **εμα** *ema* moje [[G1699]] WTS-1NPN **σπλαγχνα** *splagchna* głębokie uczucia – wnętrzności [[G4698]] WTN-NPN **προσλαβου** *proslabou* przygarnij [[G4355]] WTV-2AMM-2S
###### **Flm 1,13**
 **ον** *hon* którego [[G3739]] WTR-ASM **εγω** *egō* ja [[G1473]] WTP-1NS **εβουλομην** *eboulomēn* chciałem [[G1014]] WTV-INI-1S **προς** *pros* przy [[G4314]] [[PREP]] **εμαυτον** *emauton* sobie samym [[G1683]] WTF-1ASM **κατεχειν** *katechein* zatrzymać [[G2722]] WTV-PAN **ινα** *hina* aby [[G2443]] [[CONJ]] **υπερ** *hyper* za [[G5228]] [[PREP]] **σου** *sou* ciebie [[G4675]] WTP-2GS **διακονη** *diakonē* służyłby [[G1247]] WTV-PAS-3S **μοι** *moi* mi [[G3427]] WTP-1DS **εν** *en* w [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPM **δεσμοις** *desmois* więzach [[G1199]] WTN-DPM **του** *tou* [[G3588]] WTT-GSN **ευαγγελιου** *euangeliou* dobrej nowiny [[G2098]] [[N-GSN]]
###### **Flm 1,14**
 **χωρις** *chōris* bez [[G5565]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **της** *tēs* [[G3588]] [[T-GSF]] **σης** *sēs* twojego [[G4674]] WTS-2GSF **γνωμης** *gnōmēs* mniemania – opinii [[G1106]] [[N-GSF]] **ουδεν** *ouden* niczego [[G3762]] WTA-ASN **ηθελησα** *ēthelēsa* chciałem [[G2309]] WTV-AAI-1S **ποιησαι** *poiēsai* uczynić [[G4160]] [[V-AAN]] **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **ως** *hōs* jak [[G5613]] [[ADV]] **κατα** *kata* według [[G2596]] [[PREP]] **αναγκην** *anagkēn* konieczności – przymusu [[G318]] WTN-ASF **το** *to* [[G3588]] WTT-NSN **αγαθον** *agathon* dobro [[G18]] WTA-NSN **σου** *sou* twoje [[G4675]] WTP-2GS **η** *ē* byłoby [[G5600]] WTV-PXS-3S **αλλα** *alla* ale [[G235]] [[CONJ]] **κατα** *kata* według [[G2596]] [[PREP]] **εκουσιον** *hekousion* dobrowolnego – chętnego [[G1595]] WTA-ASN
###### **Flm 1,15**
 **ταχα** *tacha* Może [[G5029]] [[ADV]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **δια** *dia* z powodu [[G1223]] [[PREP]] **τουτο** *touto* tego [[G5124]] WTD-ASN **εχωρισθη** *echōristhē* został oddzielony – został oddalony [[G5563]] [[V-API-3S]] **προς** *pros* na [[G4314]] [[PREP]] **ωραν** *hōran* godzinę [[G5610]] WTN-ASF **ινα** *hina* aby [[G2443]] [[CONJ]] **αιωνιον** *aiōnion* wiecznego [[G166]] WTA-ASM **αυτον** *auton* go [[G846]] WTP-ASM **απεχης** *apechēs* otrzymałbyś [[G568]] WTV-PAS-2S
###### **Flm 1,16**
 **ουκετι** *ouketi* już nie [[G3765]] [[ADV]] **ως** *hōs* jak [[G5613]] [[ADV]] **δουλον** *doulon* niewolnika – sługę [[G1401]] [[N-ASM]] **αλλ** *all* ale [[G235]] [[CONJ]] **υπερ** *hyper* za [[G5228]] [[PREP]] **δουλον** *doulon* niewolnika – sługę [[G1401]] [[N-ASM]] **αδελφον** *adelfon* brata [[G80]] [[N-ASM]] **αγαπητον** *agapēton* umiłowanego [[G27]] WTA-ASM **μαλιστα** *malista* najbardziej [[G3122]] [[ADV]] **εμοι** *emoi* mnie [[G1698]] WTP-1DS **ποσω** *posō* ile więcej – jak wielce [[G4214]] WTQ-DSN **δε** *de* zaś [[G1161]] [[CONJ]] **μαλλον** *mallon* bardziej [[G3123]] [[ADV]] **σοι** *soi* tobie [[G4671]] WTP-2DS **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **σαρκι** *sarki* ciele [[G4561]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM
###### **Flm 1,17**
 **ει** *ei* Jeśli [[G1487]] WTCOND **ουν** *oun* więc [[G3767]] [[CONJ]] **εμε** *eme* mnie [[G1691]] WTP-1AS **εχεις** *echeis* masz [[G2192]] WTV-PAI-2S **κοινωνον** *koinōnon* (za) wspólnika [[G2844]] WTA-ASM **προσλαβου** *proslabou* przygarnij [[G4355]] WTV-2AMM-2S **αυτον** *auton* go [[G846]] WTP-ASM **ως** *hōs* jak [[G5613]] [[ADV]] **εμε** *eme* mnie [[G1691]] WTP-1AS
###### **Flm 1,18**
 **ει** *ei* Jeśli [[G1487]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **τι** *ti* jakąś [[G5100]] WTX-ASN **ηδικησεν** *ēdikēsen* uczynił niesprawiedliwość – skrzywdził [[G91]] [[V-AAI-3S]] **σε** *se* tobie [[G4571]] WTP-2AS **η** *ē* lub [[G2228]] WTPRT **οφειλει** *ofeilei* jest winien [[G3784]] WTV-PAI-3S **τουτο** *touto* to [[G5124]] WTD-ASN **εμοι** *emoi* mnie [[G1698]] WTP-1DS **ελλογει** *ellogei* zaliczaj [[G1677]] WTV-PAM-2S
###### **Flm 1,19**
 **εγω** *egō* Ja [[G1473]] WTP-1NS **παυλος** *paulos* Paweł – [mały] [[G3972]] [[N-NSM]] **εγραψα** *egrapsa* napisałem [[G1125]] WTV-AAI-1S **τη** *tē* [[G3588]] WTT-DSF **εμη** *emē* moją [[G1699]] WTS-1DSF **χειρι** *cheiri* ręką [[G5495]] [[N-DSF]] **εγω** *egō* ja [[G1473]] WTP-1NS **αποτισω** *apotisō* oddam – spłacę [[G661]] WTV-FAI-1S **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **λεγω** *legō* mówiłbym [[G3004]] WTV-PAS-1S **σοι** *soi* ci [[G4671]] WTP-2DS **οτι** *hoti* że [[G3754]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **σεαυτον** *seauton* siebie samego [[G4572]] WTF-2ASM **μοι** *moi* mi [[G3427]] WTP-1DS **προσοφειλεις** *prosofeileis* jesteś winien w zamian [[G4359]] WTV-PAI-2S
###### **Flm 1,20**
 **ναι** *nai* Tak [[G3483]] WTPRT **αδελφε** *adelfe* bracie [[G80]] WTN-VSM **εγω** *egō* ja [[G1473]] WTP-1NS **σου** *sou* (z) ciebie [[G4675]] WTP-2GS **οναιμην** *onaimēn* obym miał korzyść [[G3685]] WTV-2ADO-1S **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **αναπαυσον** *anapauson* pokrzep – odśwież [[G373]] WTV-AAM-2S **μου** *mou* moje [[G3450]] WTP-1GS **τα** *ta* [[G3588]] WTT-APN **σπλαγχνα** *splagchna* głębokie uczucia – wnętrzności [[G4698]] WTN-APN **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM
###### **Flm 1,21**
 **πεποιθως** *pepoithōs* Będąc przekonany – Pokładając ufność [[G3982]] WTV-2RAP-NSM **τη** *tē* (o) [[G3588]] WTT-DSF **υπακοη** *hypakoē* posłuszeństwie [[G5218]] [[N-DSF]] **σου** *sou* twoim [[G4675]] WTP-2GS **εγραψα** *egrapsa* napisałem [[G1125]] WTV-AAI-1S **σοι** *soi* ci [[G4671]] WTP-2DS **ειδως** *eidōs* wiedząc [[G1492]] WTV-RAP-NSM **οτι** *hoti* że [[G3754]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **υπερ** *hyper* ponad [[G5228]] [[PREP]] **ο** *ho* co [[G3739]] WTR-ASN **λεγω** *legō* mówię [[G3004]] WTV-PAI-1S **ποιησεις** *poiēseis* uczynisz [[G4160]] WTV-FAI-2S
###### **Flm 1,22**
 **αμα** *hama* Równocześnie [[G260]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **ετοιμαζε** *hetoimaze* przygotuj [[G2090]] WTV-PAM-2S **μοι** *moi* mi [[G3427]] WTP-1DS **ξενιαν** *ksenian* gościnę [[G3578]] WTN-ASF **ελπιζω** *elpizō* mam nadzieję [[G1679]] WTV-PAI-1S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **οτι** *hoti* że [[G3754]] [[CONJ]] **δια** *dia* przez [[G1223]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPF **προσευχων** *proseuchōn* modlitwy [[G4335]] WTN-GPF **υμων** *hymōn* wasze [[G5216]] WTP-2GP **χαρισθησομαι** *charisthēsomai* zostanę darowany [[G5483]] WTV-FPI-1S **υμιν** *hymin* wam [[G5213]] WTP-2DP
###### **Flm 1,23**
 **ασπαζονται** *aspazontai* Pozdrawiają [[G782]] WTV-PNI-3P **σε** *se* cię [[G4571]] WTP-2AS **επαφρας** *epafras* Epafras – [uroczy] [[G1889]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **συναιχμαλωτος** *synaichmalōtos* współwięzień – współjeniec [[G4869]] [[A-NSM]] **μου** *mou* mój [[G3450]] WTP-1GS **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM
###### **Flm 1,24**
 **μαρκος** *markos* Marek [[G3138]] [[N-NSM]] **αρισταρχος** *aristarchos* Arystarch – [najlepszy przywódca] [[G708]] [[N-NSM]] **δημας** *dēmas* Demas [[G1214]] [[N-NSM]] **λουκας** *loukas* Łukasz – [urodzony o świcie] [[G3065]] [[N-NSM]] **οι** *hoi* [[G3588]] WTT-NPM **συνεργοι** *synergoi* współpracownicy [[G4904]] WTA-NPM **μου** *mou* moi [[G3450]] WTP-1GS
###### **Flm 1,25**
 **η** *hē* [[G3588]] [[T-NSF]] **χαρις** *charis* Łaska [[G5485]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **μετα** *meta* z [[G3326]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **πνευματος** *pneumatos* duchem [[G4151]] [[N-GSN]] **υμων** *hymōn* waszym [[G5216]] WTP-2GP **αμην** *amēn* amen – [zaprawdę] [[G281]] WTHEB **προς** *pros* do [[G4314]] [[PREP]] **φιλημονα** *filēmona* Filemona – [przyjazny] [[G5371]] [[N-ASM]] **εγραφη** *egrafē* zostało napisane [[G1125]] WTV-2API-3S **απο** *apo* z [[G575]] [[PREP]] **ρωμης** *rōmēs* Rzymu [[G4516]] [[N-GSF]] **δια** *dia* przez [[G1223]] [[PREP]] **ονησιμου** *onēsimou* Onezyma – [użyteczny] [[G3682]] [[N-GSM]] **οικετου** *oiketou* domownika – pracownika domowego [[G3610]] [[N-GSM]]
