# 1Mch 9 BT5
###### **1Mch 9,1**
 Demetriusz dowiedział się, że Nikanor poległ i jego wojsko w bitwie [poniosło klęskę]. Posłał więc drugi raz Bakchidesa i Alkimosa do ziemi judzkiej, a razem z nimi prawe skrzydło wojska.
###### **1Mch 9,2**
 Ci wyruszyli drogą w stronę Galilei, rozłożyli się obozem koło Masalot w Arbeli, zdobyli je i zabili wielu ludzi.
###### **1Mch 9,3**
 Następnie zaś w pierwszym miesiącu sto pięćdziesiątego drugiego roku rozłożyli się obozem koło Jeruzalem.
###### **1Mch 9,4**
 Potem jednak odstąpili i w dwadzieścia tysięcy piechoty i dwa tysiące konnicy poszli do Berei.
###### **1Mch 9,5**
 Juda razem z trzema tysiącami wyborowych żołnierzy miał obóz rozbity w Elasa.
###### **1Mch 9,6**
 Gdy zobaczyli oni ogromną ilość wojska, zlękli się bardzo i wielu uciekło z obozu. Pozostało z nich nie więcej niż ośmiuset żołnierzy.
###### **1Mch 9,7**
 Juda widział, że jego wojsko się rozbiegło, a bitwa była dla niego nieunikniona. Głęboka więc troska opanowała jego serce, bo nie miał czasu ich zebrać.
###### **1Mch 9,8**
 Pełen boleści powiedział do tych, którzy pozostali: «***Wstańmy i uderzmy na naszych nieprzyjaciół, a może uda się nam ich pobić***».
###### **1Mch 9,9**
 Ale oni odradzali mu słowami: «***To się nam nie uda. W tej chwili raczej ratujmy swoje własne życie! Później powrócimy razem z naszymi braćmi i przeciwko nim będziemy walczyli. Jest nas zbyt mało***».
###### **1Mch 9,10**
 Juda jednak odpowiedział: «***Przenigdy tego nie zrobię, abym miał przed nimi uciekać. Jeżeli na nas już czas, mężnie za naszych braci oddamy życie. Nie pozwólmy niczego ująć z naszej chwały!***»
###### **1Mch 9,11**
 Wojsko wyruszyło z obozu i ustawiło się naprzeciwko nich. Konnica podzieliła się na dwie części, procarze i łucznicy szli przed wojskiem, a w pierwszym szeregu byli sami najbardziej waleczni. Bakchides zaś był na prawym skrzydle.
###### **1Mch 9,12**
 Zbliżały się jego falangi złożone z dwóch części i grano na trąbach. Ci, którzy byli po stronie Judy, także zagrali na trąbach.
###### **1Mch 9,13**
 Ziemia zadrżała od krzyku, jaki wydały wojska, bitwa trwała od rana aż do wieczora.
###### **1Mch 9,14**
 Wtedy Juda zauważył, że Bakchides i główna część wojska są po prawej stronie. Wszyscy odważni zebrali się koło niego
###### **1Mch 9,15**
 i prawe skrzydło zostało przez nich rozbite. Ścigano ich aż do góry Azara.
###### **1Mch 9,16**
 Gdy ci, którzy byli na lewym skrzydle, zobaczyli, że prawe skrzydło zostało rozbite, odwrócili się i szli z tyłu, w ślad za Judą i jego żołnierzami.
###### **1Mch 9,17**
 Bitwa stała się jeszcze cięższa, a wielu zabitych padło po jednej i po drugiej stronie.
###### **1Mch 9,18**
 Także Juda padł zabity, a inni pouciekali.
###### **1Mch 9,19**
 Jonatan zaś i Szymon zabrali Judę, swego brata, i pochowali go w grobach jego przodków.
###### **1Mch 9,20**
 Opłakiwano go, a cały Izrael bardzo go żałował. Przez długi czas trwała po nim żałoba. Mówiono:
###### **1Mch 9,21**
 «***Jak mógł paść bohater, który wybawiał Izraela?***»
###### **1Mch 9,22**
 Reszta tego, czego dokonywał Juda, jego walk, mężnych jego czynów i jego wielkości, nie została spisana. Było tego bowiem zbyt wiele.
###### **1Mch 9,23**
 Po śmierci Judy podnieśli się na wszystkich obszarach izraelskich bezbożnicy i powstali wszyscy złoczyńcy.
###### **1Mch 9,24**
 W tym też czasie nastał bardzo wielki głód i cała kraina przeszła na ich stronę.
###### **1Mch 9,25**
 Bakchides wybrał bezbożnych ludzi i ustanowił ich panami krainy,
###### **1Mch 9,26**
 a oni wyszukiwali i śledzili przyjaciół Judy, potem zaś prowadzili ich do Bakchidesa, a on mścił się i wyśmiewał się z nich.
###### **1Mch 9,27**
 W ten sposób zaczęło się wielkie prześladowanie Izraela, takie, jakiego nie było od czasu, gdy nie widziano [już] proroka.
###### **1Mch 9,28**
 Wtedy przyjaciele Judy zebrali się i powiedzieli do Jonatana:
###### **1Mch 9,29**
 «***Umarł twój brat, Juda. Od tego czasu nie ma nikogo, kto by był do niego podobny, kto by wyruszył przeciwko wrogom, przeciwko Bakchidesowi i przeciwko tym, którzy są nieprzyjaciółmi naszego narodu.***
###### **1Mch 9,30**
 ***Wobec tego dzisiaj na jego miejsce wybraliśmy ciebie, abyś był naszym zwierzchnikiem i wodzem oraz abyś prowadził wojnę w naszej sprawie***».
###### **1Mch 9,31**
 W tym więc czasie Jonatan objął dowództwo i stanął w miejsce swego brata, Judy.
###### **1Mch 9,32**
 Gdy Bakchides dowiedział się o tym, poszukiwał go, aby zamordować.
###### **1Mch 9,33**
 Ale Jonatan, jego brat, Szymon, i wszyscy jego zwolennicy, spostrzegłszy to, uciekli na pustynię Tekoa i rozbili obóz przy wodzie cysterny Asfar.
###### **1Mch 9,34**
 Bakchides wiadomość o tym otrzymał w szabat. Osobiście więc wyruszył z całym swoim wojskiem na drugą stronę Jordanu.
###### **1Mch 9,35**
 Wtedy [Jonatan] posłał swego brata, który był przełożonym nad ludem, i prosił przyjaciół swych, Nabatejczyków, aby u nich mogli przetrzymać swe tabory, których mieli wiele.
###### **1Mch 9,36**
 Ale synowie Jambriego wyszli z Medeby, pochwycili Jana ze wszystkim, co posiadał, i zatrzymując go, odeszli.
###### **1Mch 9,37**
 Po tych wydarzeniach Jonatanowi i jego bratu, Szymonowi, doniesiono, że synowie Jambriego urządzają wielkie wesele, a pannę młodą, córkę jednego z wielkich dostojników kananejskich, z wielkim orszakiem prowadzą z Nadabat.
###### **1Mch 9,38**
 Przypomnieli więc sobie krew swego brata, Jana, poszli i skryli się w skalnej grocie.
###### **1Mch 9,39**
 Kiedy podnieśli oczy, oto [ujrzeli] hałaśliwy orszak i dużą ilość podarunków. Wyszedł im naprzeciw pan młody, jego przyjaciele i bracia, z bębnami, muzyką i wielką ilością broni.
###### **1Mch 9,40**
 Wtedy tamci wyskoczyli z zasadzki i pobili ich; padło wielu rannych, a pozostali uciekli na górę. [Zwycięzcy] zabrali wszystkie zdobyte na nich łupy,
###### **1Mch 9,41**
 wesele zaś przemieniło się w płacz, a głos muzyki w żałobny lament.
###### **1Mch 9,42**
 W ten sposób pomścili krew swego brata i powrócili na mokradła Jordanu.
###### **1Mch 9,43**
 Na wiadomość o tym przyszedł Bakchides z licznym wojskiem w szabat aż do brzegów Jordanu.
###### **1Mch 9,44**
 Jonatan zaś powiedział do tych, którzy byli przy nim: «***Powstańmy i walczmy o swoje życie! Dziś bowiem jest inaczej, aniżeli było wczoraj czy przedwczoraj.***
###### **1Mch 9,45**
 ***Oto bowiem z przodu i z tyłu bitwa nam zagraża, wody Jordanu są z jednej i z drugiej strony, a ponadto mokradła i zarośla. Nie ma miejsca, którędy można by ustąpić.***
###### **1Mch 9,46**
 ***Wołajcie więc teraz do Nieba, abyście mogli być wybawieni z rąk naszych nieprzyjaciół***».
###### **1Mch 9,47**
 Bitwa się rozpoczęła. Jonatan wyciągnął rękę, aby uderzyć Bakchidesa, ale on się cofnął.
###### **1Mch 9,48**
 Wtedy Jonatan razem ze swymi żołnierzami wskoczył do Jordanu i przepłynęli na drugą stronę rzeki, ale [żołnierze Bakchidesa] nie przeprawili się za nimi przez Jordan.
###### **1Mch 9,49**
 Tego dnia ze strony Bakchidesa padło blisko tysiąc żołnierzy.
###### **1Mch 9,50**
 Potem powrócił [Bakchides] do Jerozolimy i w Judei odbudowywał obronne miasta: warownię w Jerychu, w Emaus, w Bet-Choron, w Betel, w Tamnata, [w] Faraton i w Tefon; w każdej – wysokie mury, bramy i zasuwy,
###### **1Mch 9,51**
 i pozostawił w nich załogę, która by po nieprzyjacielsku obchodziła się z Izraelem.
###### **1Mch 9,52**
 Ponadto umocnił jeszcze miasto Bet-Sur, Gezer i zamek, umieścił w nich wojsko i zapasy żywności,
###### **1Mch 9,53**
 a synów ludzi najznamienitszych w kraju wziął jako zakładników i umieścił ich pod strażą na zamku w Jerozolimie.
###### **1Mch 9,54**
 W drugim miesiącu sto pięćdziesiątego trzeciego roku Alkimos wydał rozkaz zburzenia muru wewnętrznego dziedzińca świątyni. W ten sposób niszczył on to, co prorocy budowali. Rozpoczęto już burzenie.
###### **1Mch 9,55**
 W tym jednak czasie Alkimos został porażony, a jego przedsięwzięcie unicestwione. Jego usta się zamknęły dotknięte paraliżem. Nie mógł już nic powiedzieć ani nawet wydać ostatnich rozporządzeń co do swego domu.
###### **1Mch 9,56**
 Wtedy też Alkimos w wielkich boleściach zakończył życie.
###### **1Mch 9,57**
 Gdy Bakchides dowiedział się o śmierci Alkimosa, powrócił do króla. Na ziemi judzkiej zaś przez dwa lata trwał pokój.
###### **1Mch 9,58**
 Wszyscy jednak bezbożnicy naradzali się, mówiąc: «***Oto Jonatan i jego stronnicy mieszkają spokojnie i bez troski. Przywołamy więc teraz Bakchidesa, a on ich wszystkich pochwyci w ciągu jednej nocy***».
###### **1Mch 9,59**
 Poszli więc i doradzili mu to,
###### **1Mch 9,60**
 a on wyruszył w drogę z licznym wojskiem. Potajemnie wysłał też listy do swoich zwolenników, którzy mieszkali w Judei, ażeby pochwycili Jonatana i tych, którzy z nim trzymają. Nie udało im się to jednak, gdyż zamiary ich zostały odkryte.
###### **1Mch 9,61**
 Natomiast [tamci] pochwycili w kraju blisko pięćdziesięciu ludzi spomiędzy tych, którzy byli przyczyną zła, i zabili ich.
###### **1Mch 9,62**
 Jonatan zaś razem z Szymonem i tymi, którzy z nimi trzymali, usunął się na pustynię do Bet-Basi, odbudował to, co było w nim w ruinie, i obwarował je.
###### **1Mch 9,63**
 Gdy Bakchides dowiedział się o tym, zgromadził całe wojsko i przywołał nawet tych, którzy byli w Judei,
###### **1Mch 9,64**
 potem zaś przybył, koło Bet-Basi rozłożył się obozem i przez długi czas zdobywał je, budując machiny oblężnicze.
###### **1Mch 9,65**
 Ale Jonatan zostawił w mieście swego brata, Szymona, a sam wyruszył w okolice. Poszedł z małą liczbą [żołnierzy]
###### **1Mch 9,66**
 i pobił Odomera i jego braci, a tak samo synów Fazirona, którzy mieszkali w swych namiotach. Gdy zaczęli zwyciężać, wzrośli w siły.
###### **1Mch 9,67**
 Szymon zaś i jego żołnierze wypadli z miasta i spalili machiny oblężnicze,
###### **1Mch 9,68**
 a potem walczyli przeciwko Bakchidesowi, i został przez nich pobity. Bardzo go zmartwili, gdyż nie udał się jego zamiar i posunięcie.
###### **1Mch 9,69**
 Gniew swój więc wyładował na tych bezbożnych ludziach, którzy doradzali mu, by wyruszył do tej krainy. Wielu z nich zamordował, a potem miał zamiar powrócić do swej ojczyzny.
###### **1Mch 9,70**
 Jonatan jednak dowiedział się o tym i wysłał do niego poselstwo, aby zawrzeć z nim pokój i uzyskać zwrot jeńców.
###### **1Mch 9,71**
 Zgodził się on i uczynił według jego życzenia. Pod przysięgą też zapewnił, że przez całe życie nie będzie knuł nic złego przeciw niemu.
###### **1Mch 9,72**
 Zwrócił także jeńców, których jeszcze przedtem z ziemi judzkiej wziął do niewoli. Potem wycofał się, odszedł do swojej ojczyzny i więcej już nie wkraczał na ich ziemie.
###### **1Mch 9,73**
 Tak ustąpił miecz spośród Izraela. Jonatan zamieszkał w Mikmas. Potem zaś Jonatan zaczął sądzić lud, a bezbożnych usunął z Izraela.
# 1Mch 9 PAU
###### **1Mch 9,1**
 Kiedy Demetriusz usłyszał o śmierci Nikanora i klęsce jego wojska, ponownie wysłał do ziemi Judy Bakchidesa i Alkimosa, przydzielając im prawe skrzydło wojsk.
###### **1Mch 9,2**
 Wyruszyli drogą do Galilei i rozbili obóz przy Mesalot w Arbeli. Zajęli je i zabili wielu ludzi.
###### **1Mch 9,3**
 Pierwszego miesiąca, sto pięćdziesiątego drugiego roku rozbili obóz pod Jeruzalem.
###### **1Mch 9,4**
 Potem jednak wycofali się i z dwudziestoma tysiącami piechoty oraz dwoma tysiącami jeźdźców udali się do Berei.
###### **1Mch 9,5**
 Tymczasem Juda z trzema tysiącami wyborowych żołnierzy obozował w Elasie.
###### **1Mch 9,6**
 Gdy ludzie Judy zobaczyli tak liczną armię, bardzo się przestraszyli i wielu uciekło z obozu. Pozostało ich nie więcej niż ośmiuset.
###### **1Mch 9,7**
 Gdy Juda zobaczył, że jego wojsko się rozproszyło, a bitwa jest nieuchronna, bardzo się zmartwił, ponieważ nie miał czasu, aby je zgromadzić.
###### **1Mch 9,8**
 Opadł z sił i powiedział do pozostałych: „Stańmy do walki przeciw naszym wrogom, być może zdołamy ich odeprzeć”.
###### **1Mch 9,9**
 Oni jednak odradzali mu: „Nie damy rady. Lepiej ratujmy własne życie! Powrócimy z naszymi braćmi i wtedy będziemy walczyć przeciwko nim. Teraz jest nas niewielu”.
###### **1Mch 9,10**
 Juda odpowiedział: „W żadnym wypadku nie mógłbym tak postąpić! Nie będę przed nimi uciekał! Jeśli nadchodzi nasz czas, idźmy odważnie na śmierć za naszych braci, aby nie zostawić skazy na naszym dobrym imieniu”.
###### **1Mch 9,11**
 Nieprzyjacielskie wojsko wyruszyło z obozu i stanęło w szyku bojowym. Jazdę podzielono na dwie części. Procarze i łucznicy szli na przedzie wojska, a wraz z nimi wszyscy najdzielniejsi. Bakchides był na prawym skrzydle.
###### **1Mch 9,12**
 Piechota przy dźwiękach trąb zbliżała się z dwóch stron. Również ludzie Judy zadęli w trąby.
###### **1Mch 9,13**
 Ziemia zadrżała od zgiełku wojsk. Rozpoczęła się bitwa, która trwała od rana aż do wieczora.
###### **1Mch 9,14**
 Juda spostrzegł, że Bakchides i główna część wojska byli po jego prawej stronie. Wszyscy odważnego serca dołączyli do niego
###### **1Mch 9,15**
 i prawe skrzydło wroga zostało przez nich rozbite. Ścigali ich aż do gór Azotu.
###### **1Mch 9,16**
 Gdy żołnierze z lewego skrzydła ujrzeli, że prawe skrzydło zostało rozbite, zawrócili w ślad za Judą i jego ludźmi, zachodząc ich od tyłu.
###### **1Mch 9,17**
 Bitwa stała się jeszcze cięższa. Po obu stronach padło wielu zabitych.
###### **1Mch 9,18**
 Zginął także Juda, a pozostali uciekli.
###### **1Mch 9,19**
 Jonatan i Szymon zabrali swego brata Judę i pochowali go w grobie jego przodków w Modin.
###### **1Mch 9,20**
 Cały Izrael opłakiwał go i rozpaczał w wielkim żalu. Żałoba trwała wiele dni. Mówili:
###### **1Mch 9,21**
 „Jak to możliwe, że zginął bohater, wybawca Izraela?”.
###### **1Mch 9,22**
 Pozostałe dokonania Judy, jego bitwy, bohaterskie czyny i jego wielkość nie zostały opisane, ponieważ było ich zbyt wiele.
###### **1Mch 9,23**
 Po śmierci Judy na obszarze całego Izraela pojawili się ludzie nieprawi i rozpanoszyli się krzewiciele niesprawiedliwości.
###### **1Mch 9,24**
 W tym czasie zapanował bardzo wielki głód i cały kraj przeszedł na ich stronę.
###### **1Mch 9,25**
 Bakchides wybrał bezbożnych ludzi i ustanowił ich zarządcami kraju.
###### **1Mch 9,26**
 Tropili oni przyjaciół Judy i znalezionych prowadzili do Bakchidesa. A on ich karał i wystawiał na pośmiewisko.
###### **1Mch 9,27**
 Nastał w Izraelu wielki ucisk, jakiego nie było od końca czasów prorockich.
###### **1Mch 9,28**
 Wszyscy przyjaciele Judy zebrali się razem i powiedzieli do Jonatana:
###### **1Mch 9,29**
 „Odkąd umarł twój brat Juda, nie ma nikogo, kto jak on przeciwstawiłby się wrogom: Bakchidesowi i tym, którzy nienawidzą naszego narodu.
###### **1Mch 9,30**
 Dlatego dzisiaj wybraliśmy ciebie, abyś w jego miejsce był naszym wodzem i tym, który przewodzi nam w walce”.
###### **1Mch 9,31**
 Jonatan przejął wtedy dowództwo i zastąpił swego brata Judę.
###### **1Mch 9,32**
 Bakchides dowiedział się o tym i starał się go zabić.
###### **1Mch 9,33**
 Gdy Jonatan i jego brat Szymon oraz ich towarzysze usłyszeli o tym, uciekli na pustynię Tekoa i rozbili obóz przy wodnym zbiorniku Asfar.
###### **1Mch 9,34**
 Wieść o tym dotarła do Bakchidesa w dzień szabatu. Wyruszył więc z całym swym wojskiem na drugi brzeg Jordanu.
###### **1Mch 9,35**
 Jonatan wysłał swego brata Jana, który dowodził wojskiem, aby poprosił swoich przyjaciół, Nabatejczyków, o przechowanie ich licznych taborów.
###### **1Mch 9,36**
 Tymczasem z Medeby wyszli synowie Jambriego, przechwycili Jana oraz wszystko, co wiózł, i odeszli z łupami.
###### **1Mch 9,37**
 Po tych wydarzeniach oznajmiono Jonatanowi i jego bratu, Szymonowi, że synowie Jambriego wyprawiają huczne wesele i z Nadabat prowadzą w wielkim orszaku pannę młodą, córkę jednego ze znaczniejszych dygnitarzy Kanaanu.
###### **1Mch 9,38**
 Wtedy przypomnieli sobie o krwawej śmierci swego brata Jana, wyruszyli i zaczaili się w górskiej kryjówce.
###### **1Mch 9,39**
 Wypatrując, ujrzeli wreszcie hałaśliwy i wielki tabor pana młodego. Z bębnami, muzykantami i mnóstwem sprzętu szedł on w towarzystwie swych przyjaciół i braci na spotkanie tamtych.
###### **1Mch 9,40**
 Wtedy ludzie Jonatana wypadli na nich z kryjówki i pobili. Padło wielu zabitych, a pozostali uciekli w góry. Całe ich mienie stało się łupem.
###### **1Mch 9,41**
 Wesele zamieniło się w żałobę, a śpiew ich muzykantów w lamentacje.
###### **1Mch 9,42**
 Tak dokonali pomsty za krew ich brata, a potem powrócili na mokradła obok Jordanu.
###### **1Mch 9,43**
 Kiedy Bakchides usłyszał o tym, przybył z liczną armią w dzień szabatu aż nad brzegi Jordanu.
###### **1Mch 9,44**
 Jonatan powiedział do swoich towarzyszy: „Stańmy do walki o nasze życie, bo jeszcze nigdy nie znajdowaliśmy się w takim położeniu.
###### **1Mch 9,45**
 Oto osaczył nas nieprzyjaciel. Z dwóch stron - wody Jordanu, tam - grzęzawisko i gęstwina. Nie mamy możliwości ucieczki.
###### **1Mch 9,46**
 Teraz więc wołajcie do Nieba o ocalenie z ręki waszych nieprzyjaciół”.
###### **1Mch 9,47**
 Rozpoczęła się bitwa. Jonatan podniósł swoją rękę, aby ugodzić Bakchidesa, ale on wycofał się przed nim.
###### **1Mch 9,48**
 Wtedy Jonatan i jego ludzie skoczyli do Jordanu i przepłynęli na drugi brzeg. Tamci jednak nie przeprawili się za nimi przez Jordan.
###### **1Mch 9,49**
 I padło w tym dniu około tysiąc ludzi Bakchidesa.
###### **1Mch 9,50**
 Bakchides powrócił do Jeruzalem. Wybudował w Judei umocnienia: twierdzę w Jerychu oraz wysokie mury i bramy z ryglami w Emaus, Bet-Choron, Betel i Tamnata, Faraton i Tefon.
###### **1Mch 9,51**
 W każdym z nich umieścił nieprzyjazny Izraelowi oddział żołnierzy.
###### **1Mch 9,52**
 Obwarował także miasta Bet-Sur i Gezer oraz twierdzę i umieścił w nich wojska, a także zapasy żywności.
###### **1Mch 9,53**
 Jako zakładników wziął synów przywódców kraju i uwięził ich w twierdzy w Jeruzalem.
###### **1Mch 9,54**
 W drugim miesiącu sto pięćdziesiątego trzeciego roku Alkimos rozkazał zburzyć mur wewnętrznego dziedzińca świątyni, niszcząc w ten sposób dzieło proroków. Właśnie wtedy, gdy rozpoczęto niszczenie,
###### **1Mch 9,55**
 dokładnie w tym samym czasie Alkimos został porażony. Wstrzymano więc prace, które rozpoczął. Zaniemówił on i został sparaliżowany. Nie mógł nic powiedzieć i nie potrafił wydać rozporządzeń dotyczących swego majątku.
###### **1Mch 9,56**
 Wkrótce Alkimos umarł w wielkich cierpieniach.
###### **1Mch 9,57**
 Gdy Bakchides dowiedział się o tym, że Alkimos umarł, powrócił do króla. Przez dwa lata w ziemi Judy panował pokój.
###### **1Mch 9,58**
 Wtedy wszyscy nieprawi naradzali się i mówili: „Jonatan i jego ludzie mieszkają w spokoju i czują się bezpieczni. Sprowadźmy więc Bakchidesa, a on schwyta ich wszystkich w ciągu jednej nocy”.
###### **1Mch 9,59**
 Potem poszli i naradzali się z nim.
###### **1Mch 9,60**
 Bakchides ruszył w drogę z licznym wojskiem, a do wszystkich swoich sprzymierzeńców w Judei potajemnie napisał, aby schwytali Jonatana i jego towarzyszy. Nie udało się im to jednak, ponieważ ich zamiar wyszedł na jaw.
###### **1Mch 9,61**
 Tymczasem ludzie Jonatana pochwycili w kraju około pięćdziesięciu mężczyzn, od których to zło wzięło początek, i zabili ich.
###### **1Mch 9,62**
 Jonatan wycofał się wraz z Szymonem i swoimi ludźmi do Bet-Basi, które znajduje się na pustyni, odbudował je z ruin i obwarował.
###### **1Mch 9,63**
 Gdy Bakchides dowiedział się o tym, zgromadził całe swe wojsko, a swoim ludziom w Judei posłał rozkazy.
###### **1Mch 9,64**
 Przybył i rozbił obóz pod Bet-Basi. Atakował je wiele dni i zbudował machiny oblężnicze.
###### **1Mch 9,65**
 Jonatan zostawił w mieście swojego brata Szymona, a sam z niewielką liczbą ludzi wypuścił się w głąb kraju.
###### **1Mch 9,66**
 Pokonał Odomera i jego braci, a także synów Fazirona, mieszkających w namiotach. Zaczął atakować i wzrastał w siłę.
###### **1Mch 9,67**
 Szymon i jego ludzie wyszli z miasta i podpalili machiny oblężnicze.
###### **1Mch 9,68**
 Walczyli z Bakchidesem i pokonali go. Został przez nich bardzo upokorzony, bo tak jego plany, jak i wyprawa okazały się daremne.
###### **1Mch 9,69**
 Dał upust swej złości, zabijając ludzi nieprawych, którzy radzili mu przybyć do tego kraju. I postanowił odejść do swojej ziemi.
###### **1Mch 9,70**
 Jonatan dowiedział się o tym i wysłał do niego posłów, aby zawrzeć z nim porozumienie i uzyskać zwolnienie jeńców.
###### **1Mch 9,71**
 A on przyjął tę propozycję i spełnił jego prośbę. Przysiągł również, że do końca swojego życia nie będzie działał na jego szkodę.
###### **1Mch 9,72**
 Zwolnił jeńców, których wcześniej uwięził w ziemi Judy, zawrócił i odszedł do swojego kraju. Nigdy już nie próbował wkraczać w ich granice.
###### **1Mch 9,73**
 W Izraelu odłożono miecze. Jonatan zamieszkał w Mikmas i zaczął jako sędzia rządzić ludem. Jonatan usunął bezbożnych ludzi z Izraela.
# 1Mch 9 BP
###### **1Mch 9,1**
 Demetriusz, dowiedziawszy się o śmierci Nikanora i klęsce jego wojska poniesionej w bitwie, postanowił wysłać po raz drugi do ziemi judzkiej Bakchidesa i Alkimosa z prawym skrzydłem [wojska].
###### **1Mch 9,2**
 Wyruszyli oni drogą wiodącą do Galilei i rozbili obóz pod Masalot w Arbeli. Zdobyli to miasto i wymordowali mnóstwo ludzi.
###### **1Mch 9,3**
 Następnie w miesiącu pierwszym roku sto pięćdziesiątego drugiego stanęli obozem pod Jerozolimą.
###### **1Mch 9,4**
 Odstąpili jednak i w sile dwudziestu tysięcy piechoty oraz dwóch tysięcy jazdy pociągnęli do Berei.
###### **1Mch 9,5**
 Juda z trzema tysiącami doborowych żołnierzy obozował w Elasa.
###### **1Mch 9,6**
 Widząc tak ogromną ilość wojska [Żydzi] przerazili się i wielu potajemnie opuszczało obóz, tak że pozostało ich nie więcej jak ośmiuset żołnierzy.
###### **1Mch 9,7**
 Juda widząc, że wojsko jego zaczęło się rozbiegać z obozu a bitwa jest nieunikniona, przeraził się bardzo, gdyż nie miał czasu, aby ich zebrać.
###### **1Mch 9,8**
 Pełen rozpaczy powiedział do tych, którzy go nie opuścili: Ruszajmy i uderzmy na naszych wrogów, może uda się nam stawić im czoła.
###### **1Mch 9,9**
 Oni jednak chcieli go od tego odwieść, mówiąc: Nie podołamy! Ratujmy teraz nasze życie. Jest nas zbyt mało. Wrócimy później z naszymi braćmi, aby walczyć z wrogiem.
###### **1Mch 9,10**
 Juda odparł: Nie uczynię tego nigdy, abym miał przed nimi uciekać. Jeżeli nadeszła nasza godzina, mężnie złóżmy swoje życie w ofierze za naszych braci, nie pozostawiając żadnej skazy na naszej sławie.
###### **1Mch 9,11**
 Wojsko wyszło z obozu i ustawiło się naprzeciwko nich. Jazda rozdzieliła się na dwa oddziały, procarze i łucznicy wraz z silnymi, doborowymi żołnierzami szli na przedzie przed wojskiem, a najmężniejsi w pierwszym szeregu. Sam Bakchides znajdował się na prawym skrzydle.
###### **1Mch 9,12**
 Na obu flankach ukazała się falanga przy dźwiękach trąb. Wojownicy Judy również zadęli w trąby.
###### **1Mch 9,13**
 Ziemia zadrżała od wrzasku obu wojsk, zawrzała bitwa i trwała od rana do wieczora.
###### **1Mch 9,14**
 Skoro Juda spostrzegł, że Bakchides wraz z głównymi siłami znajduje się na prawym skrzydle, a wokół niego zebrali się wszyscy najdzielniejsi,
###### **1Mch 9,15**
 rozbił prawe skrzydło i ścigał ich aż do góry Azot.
###### **1Mch 9,16**
 Żołnierze z lewego skrzydła widząc, że prawe jest w rozsypce, zawrócili [uderzając] od tyłu na Judę i jego ludzi.
###### **1Mch 9,17**
 Walczono z większą jeszcze zaciętością; poległo wielu ludzi po jednej i drugiej strome.
###### **1Mch 9,18**
 Padł również Juda, a reszta uciekła.
###### **1Mch 9,19**
 Jonatan i Szymon zabrali swego brata Judę i pochowali go w grobie ojców w Modin.
###### **1Mch 9,20**
 Opłakiwali go, a wraz z nimi lamentował nad nim cały lud izraelski i przez wiele dni obchodził żałobę wołając:
###### **1Mch 9,21**
 Jakże mógł paść bohater, który miał ocalić Izraela?
###### **1Mch 9,22**
 Wielu bohaterskich czynów, jakich dokonał Juda w stoczonych walkach, jak również wielkich zalet nie spisano, gdyż zbyt wiele tego było.
###### **1Mch 9,23**
 Po śmierci Judy w całym kraju Izraela podnieśli głowę wszyscy ci, którzy odstąpili od Prawa, i rozpanoszyli się złoczyńcy.
###### **1Mch 9,24**
 Nastał w owych dniach wielki głód i cały kraj podporządkował się im.
###### **1Mch 9,25**
 Bakchides wybrał bezbożnych mężów, aby rządzili krajem.
###### **1Mch 9,26**
 Wyszukiwali oni i szpiegowali przyjaciół Judy, po czym prowadzili ich do Bakchidesa, który karał ich i lżył.
###### **1Mch 9,27**
 Rozpoczęło się wówczas tak wielkie prześladowanie Izraela, jakiego nie pamiętano od czasów pojawienia się ostatniego Proroka.
###### **1Mch 9,28**
 Wówczas zebrali się wszyscy przyjaciele Judy i rzekli do Jonatana:
###### **1Mch 9,29**
 "Od czasu śmierci twego brata Judy nie znalazł się mąż jemu podobny, który by wystąpił przeciwko naszym wrogom, Bakchidesowi i tym wszystkim, którzy są nieprzyjaciółmi naszego narodu.
###### **1Mch 9,30**
 Dlatego ciebie wybieramy dzisiaj na jego miejsce, abyś był naszym wodzem i byś poprowadził nas do walki".
###### **1Mch 9,31**
 Od tej chwili przejął Jonatan dowództwo i zastąpił swego brata Judę.
###### **1Mch 9,32**
 Bakchides, dowiedziawszy się o tym, usiłował go zabić.
###### **1Mch 9,33**
 Powiadomiono o tym Jonatana, brata jego Szymona i wszystkich towarzyszy. Uszli więc na pustynię Tekoe i rozbili obóz nad wodą jeziora Asfar.
###### **1Mch 9,34**
 Wiadomość o tym dotarła do Bakchidesa w dzień szabatu. Wyruszył więc osobiście z całym swym wojskiem na drugą stronę Jordanu.
###### **1Mch 9,35**
 Wówczas wysłał Jonatan brata swego, który dowodził służbą obozową, i prosił przyjaciół swych Nabatejczyków, aby przechowali ich liczne tabory.
###### **1Mch 9,36**
 Lecz z Madaby wypadli synowie Jambriego i pochwyciwszy Jana wraz z całym jego dobytkiem, oddalili się ze zdobyczą.
###### **1Mch 9,37**
 Po tych wydarzeniach doniesiono Jonatanowi i jego bratu Szymonowi, że synowie Jambriego wyprawiają wielkie wesele i pannę młodą - córkę jednego z najznaczniejszych dostojników kananejskich - prowadzą we wspaniałym orszaku z Nadabat.
###### **1Mch 9,38**
 Wspomniawszy więc na przelaną krew swego brata Jana, poszli w góry i ukryli się w grocie.
###### **1Mch 9,39**
 Podniósłszy oczy spojrzeli: oto [usłyszeli wrzawę] wielkiego hałaśliwego pochodu: pan młody w otoczeniu przyjaciół i braci wychodzi naprzeciw z bębnami, muzyką i mnóstwem broni.
###### **1Mch 9,40**
 Wtedy wypadli z zasadzki, rzucili się na nich, zabijając i raniąc wielu, pozostali przy życiu uciekli w góry. Wszystko, [co mieli], stało się łupem [Żydów].
###### **1Mch 9,41**
 Weselna radość zamieniła się w smutek, dźwięki muzyki w żałobny lament.
###### **1Mch 9,42**
 Pomściwszy w ten sposób śmierć swego brata powrócili nad bagniste brzegi Jordanu.
###### **1Mch 9,43**
 Gdy o tym doniesiono Bakchidesowi, przybył w dzień sobotni z wielkim wojskiem aż do brzegów Jordanu.
###### **1Mch 9,44**
 I przemówił Jonatan do tych, którzy z nim byli: "Ruszajmy do walki w obronie naszego życia. Dzisiejsze położenie jest bowiem inne niż było wczoraj czy przedwczoraj:
###### **1Mch 9,45**
 oto nieprzyjaciel przed nami i za nami, a po obu stronach wody Jordanu, błota i zarośla. Nie ma drogi odwrotu.
###### **1Mch 9,46**
 Błagajcie więc teraz niebo, by ocaliło was z rąk waszych nieprzyjaciół".
###### **1Mch 9,47**
 Zawrzała walka. Jonatan wyciągnął rękę, aby ugodzić Bakchidesa, on jednak cofnął się i umknął ciosu.
###### **1Mch 9,48**
 Wówczas Jonatan i jego żołnierze wskoczyli do Jordanu i przepłynęli na drugi brzeg, [wróg] jednak nie przeszedł za nimi rzeki.
###### **1Mch 9,49**
 Bakchides stracił tego dnia blisko tysiąc żołnierzy.
###### **1Mch 9,50**
 Powróciwszy do Jerozolimy odbudował warowne miasta Judei: twierdzę w Jerychu, w Emmaus, w Betoron, w Betel, w Tamnata, w Faraton i w Tefon. Wszystkie [zabezpieczył] wysokimi murami, bramami i zasuwami.
###### **1Mch 9,51**
 Osadził w nich załogi, aby gnębiły Izraela.
###### **1Mch 9,52**
 Umocnił ponadto miasto Betsur, Gezer i twierdzę [jerozolimską], gdzie umieścił wojsko i zapasy żywności.
###### **1Mch 9,53**
 Synów najznaczniejszych ludzi w kraju wziął jako zakładników i zamknął ich pod strażą na zamku w Jerozolimie.
###### **1Mch 9,54**
 W drugim miesiącu roku sto pięćdziesiątego trzeciego nakazał Alkimos zburzyć mur wewnętrznego dziedzińca Świątyni. Zniszczył więc dzieło proroków i przystąpił do burzenia.
###### **1Mch 9,55**
 W tym właśnie czasie został tknięty paraliżem, co przeszkodziło w wykonaniu prac. Zamknęło mu usta i był tak porażony, że nie mógł wyrzec słowa, ani wydać rozporządzeń w sprawach swego domu.
###### **1Mch 9,56**
 Wówczas to zmarł Alkimos w wielkich męczarniach.
###### **1Mch 9,57**
 Dowiedziawszy się o śmierci Alkimosa, powrócił Bakchides do króla. W ziemi judzkiej przez dwa lata panował pokój.
###### **1Mch 9,58**
 Tymczasem wszyscy bezbożnicy naradzali się mówiąc: "Oto Jonatan i jego zwolennicy żyją spokojnie i bezpiecznie. Sprowadźmy więc teraz Bakchidesa, niech ujmie ich wszystkich jednej nocy".
###### **1Mch 9,59**
 Udali się do niego i odbyli wspólne narady.
###### **1Mch 9,60**
 Wyruszył w drogę z dużymi siłami, wysyłając potajemnie listy do swych sprzymierzeńców w Judei, aby schwytali Jonatana i jego ludzi. Nie mogli jednak tego zrobić, ponieważ zamierzenie ich zostało ujawnione.
###### **1Mch 9,61**
 [Stronnicy Jonatana] ujęli blisko pięćdziesięciu ludzi, którzy byli przywódcami spisku, i zabili ich.
###### **1Mch 9,62**
 Jonatan i Szymon wraz ze swymi towarzyszami uszli na pustynię do Baitbasi. Odbudowali jej ruiny i poczynili umocnienia.
###### **1Mch 9,63**
 Na wieść o tym zebrał Bakchides całe wojsko, ściągając nawet siły z Judei.
###### **1Mch 9,64**
 Przybył i rozbił obóz pod Baitbasi, po czym rozpoczął długotrwałe oblężenie przy pomocy machin wojennych.
###### **1Mch 9,65**
 Jonatan pozostawił w mieście swego brata Szymona, sam zaś wyruszył w [głąb] kraju z garstką wojska.
###### **1Mch 9,66**
 Pokonał Odomera i jego braci oraz synów Fazirona, którzy obozowali w namiotach. W miarę zwycięstw rosło jego wojsko.
###### **1Mch 9,67**
 W tym samym czasie Szymon ze swymi ludźmi czyniąc wypady z miasta spalił machiny oblężnicze.
###### **1Mch 9,68**
 W dalszych walkach odnieśli nad Bakchidesem wielkie zwycięstwo i bardzo go nękali, tak że cały plan jego wyprawy spełzł na niczym.
###### **1Mch 9,69**
 Gniew swój skierował przeciwko bezbożnym mężom, którzy mu doradzali, aby się udał do ich kraju, wielu z nich pozabijał i postanowił powrócić do swej ojczyzny.
###### **1Mch 9,70**
 Skoro Jonatan dowiedział się o tym, wysłał do niego posłów, aby zawrzeć pokój i starać się o wydanie jeńców.
###### **1Mch 9,71**
 [Bakchides] zgodził się i spełnił jego prośbę. Zobowiązał się również przysięgą, że już nigdy nie wyrządzi mu krzywdy.
###### **1Mch 9,72**
 Zwrócił mu jeńców, których dawniej uprowadził z Judei, i zawróciwszy odszedł do swego kraju i postanowił już nigdy więcej na te ziemie nie wracać.
###### **1Mch 9,73**
 Miecz nieprzyjacielski przestał zagrażać Izraelowi. Jonatan zamieszkał w Machmas. Zaczął sądzić lud i oczyścił Izraela od bezbożnych.
# 1Mch 9 BR
###### **1Mch 9,1**
 Kiedy Demetriusz się dowiedział, że Nikanor poniósł klęskę razem ze swoim wojskiem, ponownie wysłał do Judei Bakchidesa i Alkimosa, przydzielając im oddziały wojskowe, które stacjonowały na południu.
###### **1Mch 9,2**
 Drogą na Gilgal przybyli do Masalot koło Arabeli i tam rozbili namioty. Wkrótce zdobyli miasto i wymordowali mnóstwo ludzi.
###### **1Mch 9,3**
 W pierwszym miesiącu roku sto pięćdziesiątego drugiego założyli obóz pod Jerozolimą,
###### **1Mch 9,4**
 skąd wyruszyli niebawem - z wojskiem liczącym dwadzieścia tysięcy pieszych wojowników i dwa tysiące jeźdźców - do Berei.
###### **1Mch 9,5**
 Tymczasem Juda z trzema tysiącami doborowych wojowników stał obozem pod Elsa.
###### **1Mch 9,6**
 Kiedy żydzi zobaczyli, jak wielką przewagę mają nad nimi oddziały nieprzyjaciela, bardzo się zlękli. Wielu zaraz uciekło z obozu, tak że w końcu zostało tylko ośmiuset ludzi.
###### **1Mch 9,7**
 Juda, widząc, że tuż przed bitwą rozpada się całe jego wojsko, bardzo się zaniepokoił, gdyż nie było już czasu, żeby ludzi ponownie zgromadzić.
###### **1Mch 9,8**
 Jednakże mimo obaw zawołał do tych, którzy byli przy nim: Chodźmy, ruszajmy na naszych wrogów! Może jednak uda nam się ich pokonać.
###### **1Mch 9,9**
 Lecz ludzie sprzeciwiali się, mówiąc, że jest to całkowicie niemożliwe, że teraz należy raczej ocalić życie, by potem wrócić z braćmi i dopiero wtedy przystąpić do walki, że zbyt mało pozostało wojowników gotowych walczyć.
###### **1Mch 9,10**
 Ale Juda odpowiedział: W żadnym wypadku nie będę stąd uciekał. Jeżeli nadszedł już czas, to idźmy odważnie na śmierć, za naszych braci, a wtedy żaden cień nie padnie na nasze dobre imię.
###### **1Mch 9,11**
 Wojska nieprzyjacielskie wyszły z obozu i stanęły gotowe do walki. Konnica podzieliła się na dwa oddziały, procarze i łucznicy szli przed całym wojskiem, a na samym przedzie szereg najdzielniejszych wojowników.
###### **1Mch 9,12**
 Bakchides znajdował się na lewym skrzydle. Obydwa skrzydła zaczęły zbliżać się do siebie, było już słychać głos trąb wojennych. Wówczas wojownicy Judy również zadęli w trąby.
###### **1Mch 9,13**
 Ziemia zadrżała od wrzawy, jaką uczyniły obydwa wojska a walka trwała od rana aż do wieczora.
###### **1Mch 9,14**
 W pewnej chwili Juda zauważył, że Bakchides z grupą najdzielniejszych wojowników znajduje się po prawej stronie. Natychmiast zebrał wokół siebie co odważniejszych wojowników
###### **1Mch 9,15**
 i rozgromił doszczętnie całe prawe skrzydło wroga. Resztki ocalałych ścigano aż do gór Azotu.
###### **1Mch 9,16**
 A kiedy wojska znajdujące się na lewym skrzydle zobaczyły, że prawe skrzydło zostało rozbite, zawróciły i uderzyły na tyły wojska Judy.
###### **1Mch 9,17**
 I rozgorzała zaciekła walka, podczas której obydwie strony poniosły ogromne straty.
###### **1Mch 9,18**
 Poległ także Juda, pozostali zaś ratowali się ucieczką.
###### **1Mch 9,19**
 Jonatan i Szymon zabrali swego brata i pochowali go w grobach ich ojców w Modin.
###### **1Mch 9,20**
 Opłakiwał go cały Izrael; odprawiano długie modły żałobne. Żałoba trwała przez wiele dni, przy czym wołano ciągle:
###### **1Mch 9,21**
 Poległ oto bohater, który wybawił Izraela.
###### **1Mch 9,22**
 Pozostałe dzieje Judy, jego wyprawy wojenne, różne wielkie poczynania i niezwykłe czyny zostały już tu wspomniane. Byłoby tego zbyt wiele.
###### **1Mch 9,23**
 Po śmierci Judy znowu podnieśli głowy bezbożnicy we wszystkich częściach Izraela, a na światło dzienne wyszli z ukrycia rozmaici złoczyńcy.
###### **1Mch 9,24**
 Równocześnie nastała klęska bardzo dotkliwego głodu. Z czasem, podobnie jak owi przeniewiercy, cały kraj odstąpił od wierności Bogu.
###### **1Mch 9,25**
 Wybrał tedy Bakchides kilku niegodziwców i uczynił ich panami całego kraju.
###### **1Mch 9,26**
 Ci zaczęli wyszukiwać dawnych zwolenników Judy, przesłuchiwali ich i oddawali w ręce Bakchidesa. A on mścił się na nich poddając ich różnym torturom.
###### **1Mch 9,27**
 Ucisk zapanował w całym Izraelu tak wielki, jakiego nie było od czasu proroka.
###### **1Mch 9,28**
 Wtedy zebrali się wszyscy zwolennicy Judy i powiedzieli do Jonatana:
###### **1Mch 9,29**
 Od czasu śmierci twojego brata Judy nie ma już nikogo, kto by nas poprowadził - jak to kiedyś on czynił - na wojnę przeciwko naszym wrogom, takim jak Bakchides, czy wszystkim innym nieprzyjaciołom naszego narodu.
###### **1Mch 9,30**
 Ciebie zatem wybraliśmy dziś na naszego przywódcę. Tak jak on kiedyś, ty będziesz teraz nami dowodził i prowadził nas na wojnę.
###### **1Mch 9,31**
 Objął tedy Jonatan nad nimi władzę, stając się w ten sposób następcą swego brata Judy.
###### **1Mch 9,32**
 Bakchides, dowiedziawszy się o tym, postanowił go zgładzić.
###### **1Mch 9,33**
 Kiedy wieść o tym dotarła do Jonatana i jego brata Szymona oraz do wszystkich z ich otoczenia, zbiegli na pustynię Tekoa i pozostawali tam w pobliżu Asfar, koło cysterny napełnionej wodą.
###### **1Mch 9,34**
 [Bakchides dowiedział się o tym akurat w szabat i natychmiast przeprawił się ze wszystkimi swoimi ludźmi na drugą stronę Jordanu].
###### **1Mch 9,35**
 Wówczas Jonatan wysłał Jana, swego brata, który przewodził ludowi, do zaprzyjaźnionych z nim Nabatejczyków, żeby mogli zostawić u nich na przechowanie swoje dość liczne tabory.
###### **1Mch 9,36**
 Lecz synowie Jambriego wyszli z Medeby, napadli na Jana i uprowadzili go ze wszystkim, co posiadał.
###### **1Mch 9,37**
 Po jakimś czasie powiadomiono i jego brata Szymona, że synowie Jambriego urządzają wielkie gody weselne, na które oblubienica, córka jednego ze znakomitszych możnowładców kananejskich, w otoczeniu wspaniałego orszaku, nadciąga z Nadabat.
###### **1Mch 9,38**
 Przypomnieli sobie wtedy, jak to synowie Jambriego przelali krew ich brata Jana. Wyruszyli więc szybko w drogę i ukryli się w górach.
###### **1Mch 9,39**
 Wkrótce zobaczyli rozbawiony orszak niosący bardzo liczne dary. Naprzeciw temu orszakowi wyszedł oblubieniec, jego przyjaciele i bracia z bębnami, przy dźwięku pieśni, ale też dobrze uzbrojeni.
###### **1Mch 9,40**
 [Ukryci w górach] rzucili się tedy na nich od tyłu i sprawili im prawdziwie krwawą łaźnię. Wielu z uczestników wesela poległo, reszta ukryła się w górach, całe zaś ich mienie zabrali [zwycięzcy] jako łup.
###### **1Mch 9,41**
 I tak oto gody weselne zamieniły się w żałobę, a pieśni weselne - w opłakiwanie zmarłych.
###### **1Mch 9,42**
 W ten sposób pomścili śmierć swego brata. Potem wrócili znów na mokradła przy samym Jordanie.
###### **1Mch 9,43**
 A kiedy Bakchides dowiedział się o tym, przybył - a był to szabat - z wielkim oddziałem wojowników nad brzeg Jordanu.
###### **1Mch 9,44**
 Wtedy Jonatan powiedział do swoich ludzi: Przygotujcie się, musimy walczyć o nasze życie. Jeszcze nigdy nie znajdowaliśmy się w takim wielkim niebezpieczeństwie.
###### **1Mch 9,45**
 Nieprzyjaciele otoczyli nas ze wszystkich stron. Zarówno przed nami, jak i za nami są wody Jordanu, jego zarośla i mokradła. Nie ma którędy się wycofać.
###### **1Mch 9,46**
 Dlatego wzywajcie głośno na pomoc niebiosa, żebyście się mogli wydostać z rąk waszych wrogów.
###### **1Mch 9,47**
 Potem doszło do walki wręcz. Jonatan już się zamierzył, żeby ugodzić Bakchidesa, ale ten uchylił się od ciosu.
###### **1Mch 9,48**
 W końcu Jonatan i jego ludzie wskoczyli do Jordanu i przepłynęli na drugą stronę. Wrogowie zaś nie zdołali już przeprawić się za nimi przez Jordan.
###### **1Mch 9,49**
 Z wojowników Bakchidesa poległo tego dnia około tysiąca ludzi.
###### **1Mch 9,50**
 Wróciwszy do Jerozolimy Bakchides zabrał się do budowy umocnień w następujących miastach Judei: Jerycho, Emmaus, Bet-Choron, Betel, Tamnata, Faraton i Tefon. W każdym z tych miast zbudował wysokie mury i bramy ryglowane specjalnymi belkami.
###### **1Mch 9,51**
 Obsadził je własnymi załogami, które miały osłaniać te miasta przed Izraelitami.
###### **1Mch 9,52**
 W miastach Bet-Sur i Gezer, a także w twierdzy [jerozolimskiej] kazał przeprowadzić umocnienia, osadził w nich wojsko i zgromadził zapasy żywności.
###### **1Mch 9,53**
 Synów zaś tych, którzy cieszyli się szczególnym uznaniem w całym kraju, wziął jako zakładników i przetrzymywał ich w twierdzy w Jerozolimie.
###### **1Mch 9,54**
 W drugim miesiącu roku sto pięćdziesiątego trzeciego rozkazał Alkimos zburzyć mury wewnętrznego dziedzińca świątyni. Polecił rozpocząć od zniszczenia tego, co już odbudowali prorocy.
###### **1Mch 9,55**
 Lecz wtedy właśnie został rażony paraliżem i nie wykonano jego zamierzeń. Nie mógł już nawet otworzyć ust. Był sparaliżowany, nie mógł wypowiedzieć ani jednego słowa. Nawet tym, co posiadał już nie był w stanie rozporządzić.
###### **1Mch 9,56**
 Wkrótce zmarł w wielkich cierpieniach.
###### **1Mch 9,57**
 Po śmierci Alkimosa Bakchides znów wrócił do króla, a w Judei zapanował na dwa lata spokój.
###### **1Mch 9,58**
 Potem wszyscy poplecznicy zebrali się na naradę i powiedzieli: Jonatan i poplecznicy żyją sobie spokojnie we własnych domach i czują się bezpiecznie. Jeżeli sprowadzimy tu teraz Bakchidesa, będzie mógł pochwycić ich wszystkich w ciągu jednej nocy.
###### **1Mch 9,59**
 Poszli więc do niego i omówili z nim całą sprawę.
###### **1Mch 9,60**
 Bakchides ruszył natychmiast w drogę, zabierając ze sobą duży oddział wojska. Potajemnie wysłał list do wszystkich swoich sprzymierzeńców w Judei, żądając, żeby pochwycili Jonatana i jego zwolenników. Nie udało się to jednak, gdyż ich zamiary zostały w porę wykryte.
###### **1Mch 9,61**
 Co więcej, Jonatan wydał rozkaz, żeby pięćdziesięciu spośród mieszkających w kraju, którzy byli odpowiedzialni za ten zbrodniczy plan, pochwycić i zgładzić.
###### **1Mch 9,62**
 Wtedy Jonatan i Szymon oraz ich zwolennicy wycofali się na pustynię, do twierdzy Bet-Basi, gdzie Jonatan kazał odbudować wszystko, co leżało w gruzach, i umocnić całą twierdzę.
###### **1Mch 9,63**
 Gdy Bakchides dowiedział się o tym, zebrał wszystkie swoje oddziały, a swoim ludziom w Judei wydał odpowiednie polecenia.
###### **1Mch 9,64**
 Następnie przybył sam w okolice Bet-Basi i tam rozbił namioty. Kazał poustawiać machiny oblężnicze i przez wiele dni oblegał miasto.
###### **1Mch 9,65**
 Wtedy Jonatan zostawił swojego brata Szymona w mieście, a sam z garstką wojowników udał się do okolicznych osiedli.
###### **1Mch 9,66**
 Po drodze pokonał Odomera i jego braci, a także powywracał namioty, w których mieszkali potomkowie Fazirona. Odnosił coraz liczniejsze zwycięstwa i znów wzrastał w siły.
###### **1Mch 9,67**
 Tymczasem Szymon i jego ludzie zrobili wypad z miasta i spalili machiny oblężnicze.
###### **1Mch 9,68**
 Zaatakowali również oddziały Bakchidesa i zadali im dotkliwe straty. Nękali go ze wszystkich stron i doprowadzili do tego, że nie udało mu się osiągnąć jego zamiarów.
###### **1Mch 9,69**
 Bakchides rozgniewał się bardzo na tych bezbożników, którzy mu doradzili, żeby udał się na tę wyprawę. Kazał wielu z nich wymordować, po czym postanowił wrócić do swojego kraju.
###### **1Mch 9,70**
 Gdy tylko dowiedział się o tym Jonatan, wysłał do niego swoich ludzi, proponując zawarcie pokoju i uwolnienie jeńców.
###### **1Mch 9,71**
 Bakchides zgodził się na to i przysiągł Jonatanowi, że nigdy w życiu nie wystąpi już przeciwko niemu.
###### **1Mch 9,72**
 Zwolnił także jeńców, których wziął do niewoli jeszcze przedtem w Judei. Potem ruszył w drogę i wrócił do swego domu. W Judei nie pojawił się już nigdy więcej.
###### **1Mch 9,73**
 A w Izraelu nie chwytano już potem za broń. Jonatan osiadł w Mikmas, skąd jako sędzia rządził całym Izraelem. Wytępił przy tym wszystkich bezbożników, jacy byli w Izraelu.
# 1Mch 9 WUJ
