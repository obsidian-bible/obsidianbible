# 2Krn 7 BT5
###### **2Krn 7,1**
  Skoro Salomon zakończył modlitwę, spadł ogień z nieba i strawił całopalenie oraz żertwy, a chwała Pańska wypełniła dom.
###### **2Krn 7,2**
 Kapłani nie mogli wejść do domu Pańskiego, ponieważ chwała Pańska napełniła dom Pański.
###### **2Krn 7,3**
 Wszyscy zaś Izraelici, widząc zstępujący ogień i chwałę Pańską spoczywającą nad świątynią, padli twarzą do ziemi, na posadzkę, i oddali pokłon, a potem wysławiali Pana, że jest dobry i że na wieki Jego łaska.
###### **2Krn 7,4**
  Król zaś i cały lud składali ofiary przed obliczem Pana.
###### **2Krn 7,5**
 Król Salomon złożył w ofierze dwadzieścia dwa tysiące sztuk większego i sto dwadzieścia tysięcy drobnego bydła. I tak poświęcili dom Boży – król i cały naród.
###### **2Krn 7,6**
 Kapłani trwali przy swoich powinnościach, lewici zaś – z instrumentami muzycznymi, które sprawił król Dawid, by wtórowały pieśniom na cześć Pana: bo na wieki Jego łaska, gdy Dawid wychwalał Go za ich pośrednictwem. Naprzeciw nich trąbili kapłani, a cały Izrael stał.
###### **2Krn 7,7**
 Potem poświęcił Salomon środkową część dziedzińca przed domem Pańskim, bo dokonał tam ofiary całopalnej i z tłuszczu ofiar biesiadnych, gdyż brązowy ołtarz, który sprawił Salomon, nie mógł pomieścić całopalenia, ofiary pokarmowej oraz tłuszczów.
###### **2Krn 7,8**
 Wtedy Salomon, a z nim wielkie zgromadzenie całego Izraela, od Wejścia do Chamat aż do Potoku Egipskiego, obchodzili uroczyste święto przez siedem dni.
###### **2Krn 7,9**
 W ósmym dniu odbyło się uroczyste zebranie, bo siedem dni trwało poświęcenie ołtarza i siedem dni uroczystość.
###### **2Krn 7,10**
 A w dwudziestym trzecim dniu siódmego miesiąca odesłał lud do ich namiotów – radosny, z sercem wdzięcznym za wszystkie dobrodziejstwa, które Pan wyświadczył Dawidowi, Salomonowi i swemu ludowi izraelskiemu.
###### **2Krn 7,11**
 Salomon ukończył świątynię Pańską i pałac królewski oraz szczęśliwie wykonał wszystko to, co pragnął sprawić w świątyni Pańskiej i w swoim pałacu.
###### **2Krn 7,12**
 Wówczas Salomonowi w nocy ukazał się Pan i rzekł mu: «***Wysłuchałem twojej modlitwy i wybrałem sobie to miejsce na dom składania ofiary.***
###### **2Krn 7,13**
 ***Gdy zamknę niebiosa i nie będzie deszczu i gdy nakażę szarańczy, by zniszczyła pola, lub gdy ześlę na mój lud zarazę,***
###### **2Krn 7,14**
 ***to jeśli upokorzy się mój lud, nad którym zostało wezwane moje imię, i będą błagać, i będą szukać mego oblicza, a zawrócą ze swoich złych dróg, Ja z nieba wysłucham [ich] i przebaczę im grzechy, a kraj ich ocalę.***
###### **2Krn 7,15**
 ***Odtąd moje oczy będą otwarte, a uszy moje uważne na modlitwę w tym miejscu.***
###### **2Krn 7,16**
 ***Teraz wybrałem i uświęciłem ten dom, aby tam było imię moje na wieki, a oczy moje i moje serce tam będą skierowane przez wszystkie dni.***
###### **2Krn 7,17**
 ***Ty zaś, jeśli będziesz tak postępował wobec Mnie, jak postępował Twój ojciec, Dawid, dbając o to, aby wypełniać wszystko, do czego cię zobowiązałem, jeśli będziesz przestrzegał moich praw i nakazów,***
###### **2Krn 7,18**
 ***utrwalę tron twego królestwa, jak przyrzekłem niegdyś twemu ojcu, Dawidowi, mówiąc: Nie będzie ci odjęty potomek od rządów nad Izraelem.***
###### **2Krn 7,19**
 ***Ale jeżeli odwrócicie się ode Mnie i porzucicie moje prawa i nakazy, które wam dałem, oraz zechcecie pójść i służyć cudzym bogom i oddawać im pokłon,***
###### **2Krn 7,20**
 ***to wyrwę was z korzeniami z mojej ziemi, którą wam dałem, a dom, który poświęciłem memu imieniu, odtrącę od mego oblicza i uczynię z niego przedmiot przypowieści i pośmiewiska u wszystkich narodów.***
###### **2Krn 7,21**
 ***Świątynia, która była tak wspaniała, wywoływać będzie zdumienie u każdego przechodnia, tak iż zapyta: Dlaczego Pan tak uczynił temu krajowi i tej świątyni?***
###### **2Krn 7,22**
 ***A odpowiedzą: Dlatego, że opuścili Pana, Boga ich ojców, który wyprowadził ich z ziemi egipskiej, a upodobali sobie innych bogów oraz oddawali im pokłon i służyli: dlatego sprowadził na nich całe to nieszczęście***».
# 2Krn 7 PAU
###### **2Krn 7,1**
 Kiedy Salomon skończył modlitwę, z nieba spadł ogień i pochłonął ofiary całopalne i pozostałe ofiary, a chwała PANA wypełniła dom.
###### **2Krn 7,2**
 Kapłani nie mogli wejść do domu PANA, gdyż chwała PANA wypełniła dom PANA.
###### **2Krn 7,3**
 Gdy wszyscy Izraelici zobaczyli zstępujący ogień i chwałę PANA nad domem, upadli na ziemię, twarzą do posadzki, oddali pokłon i chwalili PANA, bo jest dobry, bo Jego miłosierdzie trwa na wieki.
###### **2Krn 7,4**
 Następnie król wraz z całym ludem złożył PANU ofiarę.
###### **2Krn 7,5**
 Król Salomon ofiarował dwadzieścia dwa tysiące wołów i sto dwadzieścia tysięcy owiec. W ten sposób król i cały lud dokonali poświęcenia domu Bożego.
###### **2Krn 7,6**
 Kapłani wypełniali swoją posługę, a lewici przygrywali do pieśni na cześć PANA. Używali instrumentów, które kazał wykonać Dawid, aby chwalić PANA, bo Jego miłosierdzie trwa na wieki. Gdy śpiewano pieśń Dawida, kapłani grali na rogach, a cały Izrael stał przed nimi.
###### **2Krn 7,7**
 Salomon poświęcił środek dziedzińca znajdującego się przed domem PANA, bo na nim złożył ofiary całopalne i tłuszcz ofiar wspólnotowych. Ołtarz z brązu, który Salomon kazał odlać, nie mógł pomieścić całopaleń, ofiar pokarmowych i tłuszczu.
###### **2Krn 7,8**
 Salomon wraz z wielkim zgromadzeniem wszystkich Izraelitów od Lebo-Chamat aż po Potok Egipski obchodził święto przez siedem dni.
###### **2Krn 7,9**
 Uroczyste zgromadzenie odbyło się ósmego dnia, gdyż poświęcenie ołtarza trwało siedem dni i przez siedem dni świętowano.
###### **2Krn 7,10**
 Dwudziestego trzeciego dnia siódmego miesiąca Salomon rozesłał lud, który wracał do domów napełniony radością, z wdzięcznym sercem za dobroć, jaką PAN okazał Dawidowi, Salomonowi i swojemu ludowi izraelskiemu.
###### **2Krn 7,11**
 Kiedy Salomon ukończył budowę domu PANA i pałacu królewskiego oraz szczęśliwie doprowadził do końca wszystko, co zamierzył zrobić w domu PANA i w pałacu,
###### **2Krn 7,12**
 PAN ukazał mu się w nocy i powiedział: „Usłyszałem twoją modlitwę i wybrałem sobie to miejsce na dom ofiar.
###### **2Krn 7,13**
 Jeśli zamknę niebiosa i nie będzie deszczu, jeśli ześlę szarańczę, która zniszczy pola, albo jeśli ześlę zarazę na mój lud,
###### **2Krn 7,14**
 a mój lud, nad którym wezwano mojego imienia, upokorzy się, będzie błagał, będzie szukał mojego oblicza i zmieni swoje złe postępowanie, to Ja z nieba wysłucham ich i przebaczę im grzechy, a ich kraj ocalę.
###### **2Krn 7,15**
 Moje oczy będą otwarte, a uszy zasłuchane w modlitwę, która wznosi się z tego miejsca.
###### **2Krn 7,16**
 Wybrałem bowiem i uświęciłem ten dom, aby odtąd moje imię zawsze w nim przebywało. Moje oczy i serce ciągle będą w nim obecne.
###### **2Krn 7,17**
 Jeśli więc ty będziesz służył Mi jak twój ojciec Dawid i wypełnisz wszystko, do czego cię zobowiązałem, jeśli będziesz przestrzegał moich praw i nakazów,
###### **2Krn 7,18**
 wówczas Ja utrwalę twoją władzę królewską zgodnie z obietnicą daną twojemu ojcu, Dawidowi: «Nie zabraknie ci następcy panującego nad Izraelem».
###### **2Krn 7,19**
 Jeśli jednak odwrócicie się ode Mnie i porzucicie moje prawa i przykazania, do których was zobowiązałem, a pójdziecie służyć i oddawać cześć innym bogom,
###### **2Krn 7,20**
 wtedy usunę was z ziemi, którą wam dałem, a dom, który uświęciłem moim imieniem, opuszczę. Stanie się on przestrogą, a nawet pośmiewiskiem dla wszystkich ludów.
###### **2Krn 7,21**
 Każdy, kto będzie przechodził obok tego wspaniałego domu, wpadnie w osłupienie i zapyta: «Dlaczego PAN tak postąpił z tym krajem i z tym domem?».
###### **2Krn 7,22**
 Odpowiedzą mu: «Ponieważ opuścili PANA, Boga ich przodków, który wyprowadził ich z ziemi egipskiej, i związali się z innymi bogami, służąc im i oddając cześć. Dlatego sprowadził na nich całe to nieszczęście»”.
# 2Krn 7 BP
###### **2Krn 7,1**
 Kiedy Salomon zakończył modlitwę, spadł ogień z nieba, pochłonął całopalenie i [inne] ofiary, a Chwała Jahwe wypełniła Dom.
###### **2Krn 7,2**
 I nie mogli już kapłani wejść do Domu Jahwe, albowiem Chwała Jahwe wypełniła Jego Dom.
###### **2Krn 7,3**
 Wszyscy zaś synowie Izraela, widząc zstępujący na Dom ogień i Chwałę Jahwe, upadli twarzą do ziemi na [kamienne] płyty, oddali pokłon i wielbili Jahwe, "bo dobry jest, bo na wieki [trwa] miłosierdzie jego".
###### **2Krn 7,4**
 Król i wszystek lud złożyli ofiary przed Jahwe.
###### **2Krn 7,5**
 Król Salomon złożył jako ofiarę 22 000 wołów i 120 000 owiec. W ten sposób król wraz z całym ludem dokonali poświęcenia Domu Bożego.
###### **2Krn 7,6**
 Kapłani trwali na stanowiskach, podobnie jak i lewici z instrumentami muzycznymi Jahwe, które wprowadził król Dawid, by składali na nich dziękczynienia dla Jahwe, "bo na wieki miłosierdzie Jego". Naprzeciw nich kapłani grali na trąbach, a wszystek lud stał.
###### **2Krn 7,7**
 Poświęcił też Salomon środkową część dziedzińca, który się znajdował przed Domem Jahwe; tam bowiem złożył ofiary całopalne i tłuszcz z ofiar dziękczynnych, gdyż na ołtarzu spiżowym zbudowanym przez Salomona nie mogły się pomieścić ofiary całopalne oraz ofiary z pokarmów i tłuszczów.
###### **2Krn 7,8**
 Salomon i cały Izrael wraz z nim - wielkie zgromadzenie [ludu przybyłego] od Wejścia do Chamat aż do Potoku Egipskiego - obchodzili w owym czasie wielkie święto przez dni siedem.
###### **2Krn 7,9**
 W ósmym dniu odbyło się uroczyste zgromadzenie, gdyż poświęcenie ołtarza trwało dni siedem i przez siedem dni obchodzili święto uroczyste.
###### **2Krn 7,10**
 Dwudziestego trzeciego dnia siódmego miesiąca [Salomon] odesłał lud do ich namiotów; [ludzi] rozradowanych, z sercem przepełnionym wdzięcznością za dobrodziejstwa, które Jahwe wyświadczył Dawidowi, Salomonowi i swemu ludowi izraelskiemu.
###### **2Krn 7,11**
 Tak więc ukończył Salomon budowę Domu Jahwe i pałacu królewskiego; wszystko, cokolwiek zamierzał Salomon uczynić w Domu Jahwe lub w swoim pałacu, doprowadził szczęśliwie do końca.
###### **2Krn 7,12**
 Potem Jahwe ukazał się Salomonowi w nocy i rzekł do niego: Wysłuchałem twojej modlitwy i wybrałem sobie to miejsce jako Dom ofiary.
###### **2Krn 7,13**
 Gdy zamknę niebiosa i deszcz przestanie padać, gdy dam rozkaz szarańczy, by ogołociła ziemię, gdy ześlę na lud mój zarazę,
###### **2Krn 7,14**
 a upokorzy się lud mój, nad którym wzywano mego Imienia, pocznie się modlić i szukać mego oblicza, a nawróci się ze zgubnych dróg swoich, wówczas Ja wysłucham z nieba, odpuszczę im grzechy i ocalę ich ziemię.
###### **2Krn 7,15**
 Oczy moje będą otwarte, a uszy moje czułe na modlitwę zanoszoną w tym miejscu.
###### **2Krn 7,16**
 Wybrałem bowiem i poświęciłem ten Dom, aby tu przebywało me Imię na wieki, i tu będą oczy moje i serce moje przez wszystkie dni.
###### **2Krn 7,17**
 Ty zaś, gdy będziesz postępował wobec mnie tak, jak postępował twój ojciec Dawid, i będziesz pełnił wszystko, co ci nakazałem, strzegąc praw moich i nakazów,
###### **2Krn 7,18**
 wówczas utrwalę stolicę królestwa twego, jak to już przyrzekłem twemu ojcu Dawidowi, mówiąc: Nie zabraknie ci potomka sprawującego rządy nad Izraelem.
###### **2Krn 7,19**
 Jeśli jednak odwrócicie się [ode mnie], jeśli odrzucicie prawa i przykazania moje, które wam dałem, a odszedłszy obcym bogom służyć będziecie i padać przed nimi na twarz,
###### **2Krn 7,20**
 wówczas wykorzenię was z mojej ziemi, którą wam dałem, a Dom, który poświęciłem Imieniu memu, odrzucę od swego oblicza i podam na przedmiot przypowieści i pośmiewisko u wszystkich ludów.
###### **2Krn 7,21**
 A Dom ten, który był tak sławny, napełni przerażeniem każdego, kto obok niego przejdzie. I powie on: "Czemuż to Jahwe postąpił tak z tym krajem i z tą Świątynią?"
###### **2Krn 7,22**
 I odpowiedzą: "Dlatego, że opuścili Jahwe, Boga ich ojców, który ich wyprowadził z ziemi egipskiej, a przylgnęli do innych bogów, padali przed nimi na twarz i służyli im. Oto dlaczego zesłał na nich te wszystkie nieszczęścia."
# 2Krn 7 BR
###### **2Krn 7,1**
 Gdy Salomon skończył się modlić, zstąpił z nieba ogień i pochłonął ofiarę całopalenia oraz inne żertwy, a chwała Jahwe napełniła całą świątynię.
###### **2Krn 7,2**
 Nawet kapłani nie mogli wejść do świątyni, gdyż chwała Jahwe napełniała ją całą.
###### **2Krn 7,3**
 Wszyscy synowie Izraela widząc, jak ogień i chwała Boża zstępują na świątynię, skłonili się twarzą aż do ziemi i zaczęli wielbić Jahwe, mówiąc: Dobry jest, a miłosierdzie Jego trwa na wieki.
###### **2Krn 7,4**
 Potem król i cały lud złożyli ofiary na cześć Jahwe.
###### **2Krn 7,5**
 Złożył wtedy król Salomon na ofiarę dwadzieścia dwa tysiące wołów i sto dwadzieścia tysięcy owiec. W ten sposób król i cały lud dokonali poświęcenia domu Bożego.
###### **2Krn 7,6**
 Kapłani zajęli swoje miejsca, byli obecni także lewici z instrumentami do wykonywania muzyki na cześć Jahwe. Instrumenty te kazał dla nich kiedyś sporządzić Dawid, żeby przy ich wtórze - gdy będą pełnić swoją służbę dla chwały Bożej - wysławiali Jahwe, bo miłosierdzie Jego trwa na wieki. To oni śpiewali pieśni ułożone przez Dawida. Po obydwu ich stronach kapłani grali na trąbach, a wszyscy Izraelici stali.
###### **2Krn 7,7**
 Potem poświęcił Salomon środek dziedzińca znajdującego się przed świątynią. Tam bowiem spalono ofiary całopalne oraz wszystek tłuszcz z ofiar pojednania, gdyż zbudowany przez niego ołtarz brązowy był za mały na składanie całopaleń, a także ofiar z pokarmów i tłuszczów.
###### **2Krn 7,8**
 Świętował Salomon wtedy razem z całym Izraelem przez siedem dni. Na uroczystości przybyło bardzo wielu mieszkańców Izraela, od Wejścia do Chamat aż do Potoku Egipskiego.
###### **2Krn 7,9**
 Ósmego dnia zwołano zgromadzenie, aby zakończyć uroczystości. Poświęcano ołtarz świątynny przez siedem dni i wszystkie uroczystości trwały siedem dni.
###### **2Krn 7,10**
 Dwudziestego trzeciego dnia siódmego miesiąca Salomon rozesłał do namiotów ludzi rozradowanych i uszczęśliwionych dobrem, które Jahwe wyświadczył Dawidowi, Salomonowi oraz swojemu ludowi izraelskiemu.
###### **2Krn 7,11**
 I tak ukończył Salomon budowę świątyni Jahwe i pałacu królewskiego oraz wyposażył świątynię Jahwe i pałac królewski w to wszystko, co uważał za potrzebne.
###### **2Krn 7,12**
 Wtedy objawił mu się nocą Jahwe i powiedział: Wysłuchałem twojej prośby i upatrzyłem sobie to miejsce na przybytek, w którym będą składane ofiary.
###### **2Krn 7,13**
 A kiedy zamknę niebiosa i nie będzie deszczu, kiedy sprowadzę na kraj żarłoczną szarańczę albo ześlę na mój lud zarazę,
###### **2Krn 7,14**
 wtedy jeśli mój lud, nad którym jest wzywanie moje imię, ukorzy się, zacznie się modlić i szukać mojego oblicza, jeśli zejdzie ze swojej złej drogi - wysłucham go z niebios, przebaczę mu jego grzechy i uratuję ( od zagłady) jego kraj.
###### **2Krn 7,15**
 Teraz moje oczy są otwarte i uszy nadstawione na modły zanoszone z tego miejsca.
###### **2Krn 7,16**
 Upodobałem sobie ten dom i poświęciłem go, aby moje imię mogło w nim zamieszkać na wieki. Na niego będą zawsze skierowane moje oczy i ku niemu będzie się zwracało moje serce.
###### **2Krn 7,17**
 Jeśli zaś ty, jak twój ojciec, Dawid, będziesz chodził zawsze w mojej obecności, wprowadzając w życie wszystko, co tylko ci nakażę, jeśli będziesz przestrzegał wszystkich moich praw i pouczeń,
###### **2Krn 7,18**
 to Ja będę umacniał twoją królewską władzę zgodnie z przymierzem, jakie zawarłem z twoim ojcem, Dawidem, któremu przyrzekłem, że nie zabraknie mu nigdy potomka panującego nad całym Izraelem.
###### **2Krn 7,19**
 Lecz jeśli się odwrócisz ode Mnie, jeśli zlekceważysz sobie moje prawa i przykazania, które wam dałem, jeśli pójdziesz służyć innym bogom, oddając im pokłony,
###### **2Krn 7,20**
 to usunę was z ziemi, którą wam dałem, i odwrócę swoje oblicze od domu, który poświęciłem dla swego imienia, i uczynię to miejsce powodem wzgardy i pośmiewiska dla wszystkich narodów.
###### **2Krn 7,21**
 Ta zaś świątynia, budząca teraz taki podziw, będzie wprawiać w osłupienie wszystkich obok niej przechodzących, którzy też zaczną pytać: Dlaczego Jahwe postąpił tak z tym krajem i z tą świątynią?
###### **2Krn 7,22**
 I znajdą na to tylko jedną odpowiedź: Dlatego że odeszli od Jahwe, Boga ich ojców, których On wyprowadził z Egiptu; dlatego że poszli za innymi bogami, służąc im i bijąc przed nimi pokłony. Oto, dlaczego zesłał na nich te wszystkie nieszczęścia.
# 2Krn 7 WUJ
###### **2Krn 7,1**
 A gdy dokończył Salomon modlitwy, ogień zstąpił z nieba, i pożarł całopalenia i ofiary: a chwała Pańska napełniła dom.
###### **2Krn 7,2**
 I nie mogli kapłani wniść do kościoła Pańskiego, przeto iż była chwała Pańska napełniła Kościół Pański.
###### **2Krn 7,3**
 Ale i wszyscy synowie Izraelscy widzieli zstępujący ogień, i chwałę Pańską na dom: i upadszy twarzą swą na ziemię na tło kamieniem położone, pokłonili się i chwalili Pana: Iż dobry, iż na wieki miłosierdzie jego.
###### **2Krn 7,4**
 A król i wszystek lud ofiarowali ofiary przed Panem.
###### **2Krn 7,5**
 Król tedy Salomon zabił na ofiarę, wołów dwadzieścia i dwa tysiąca, baranów sto i dwadzieścia tysięcy: i poświęcił dom Boży, król i wszystek lud.
###### **2Krn 7,6**
 A kapłani stali w urzędziech swoich: Lewitowie na instrumentach pieśni Pańskich, które sprawił Dawid król, ku chwaleniu Pana: Iż na wieki miłosierdzie jego, Psalmy Dawidowe grając rękami swemi: a kapłani trąbili przed nim: a wszystek lud Izraelski stał.
###### **2Krn 7,7**
 Poświęcił też Salomon pośrodek sieni przed kościołem Pańskim: bo tam był ofiarował całopalenia, i tłustości zapokojnych ofiar: abowiem ołtarz miedziany, który był sprawił, nie mógł zdzierzeć całopalenia, i ofiar, i tłustości.
###### **2Krn 7,8**
 Uczynił tedy Salomon onego czasu uroczyste święto przez siedm dni, i wszystek Izrael z nim, zgromadzenie barzo wielkie, od weścia Emath, aż do potoka Egiptskiego.
###### **2Krn 7,9**
 I uczynił dnia ósmego święto zgromadzenia, dla tego że poświęcał ołtarz przez siedm dni, i święto obchodził przez siedm dni.
###### **2Krn 7,10**
 Dnia tedy dwudziestego i trzeciego miesiąca siódmego rozpuścił lud do przybytków swoich, weselący się i radujący z dobra, które Pan uczynił Dawidowi, i Salomonowi, i ludowi swemu Izraelskiemu.
###### **2Krn 7,11**
 I dokonał Salomon domu Pańskiego, i domu królewskiego, i wszystkiego co był umyślił w sercu swojem, aby uczynił w domu Pańskim, i w domu swym, i poszczęściło mu się.
###### **2Krn 7,12**
 I ukazał mu się Pan w nocy, i rzekł: Wysłuchałem modlitwę twoję, i obrałem to miejsce sobie za dom ofiary.
###### **2Krn 7,13**
 Jeśli zamknę niebo i deszcz by nie szedł, i kazałbym i przykazał szarańczy, aby pożarła ziemię, i przepuściłbym powietrze na lud mój:
###### **2Krn 7,14**
 A nawróciwszy się lud mój, nad którym wzywano jest imię moje, prosiłby mię i szukał oblicza mego, i pokutowałby za drogi swe złośliwe: i ja wysłucham z nieba, i będę miłości w grzechom ich, i uzdrowię ziemię ich.
###### **2Krn 7,15**
 Oczy też moje będą otworzone, i uszy moje gotowe ku modlitwie tego, który się będzie na tem miejscu modlił.
###### **2Krn 7,16**
 Bom obrał i poświęcił to miejsce, aby tam imię moje było na wieki, ażeby tam trwały oczy moje, i serce moje po wszystkie dni.
###### **2Krn 7,17**
 Ty też jeśli będziesz chodził przedemną, jako chodził Dawid ociec twój, a będziesz czynił wedle wszystkiego com ci przykazał, i będziesz strzegł sprawiedliwości i sądów moich:
###### **2Krn 7,18**
 Wzbudzę stolicę królestwa twego, jakom obiecał Dawidowi ojcu twemu, mówiąc: Nie będzie odjęty z pokolenia twego mąż, któryby był książęciem nad Izraelem.
###### **2Krn 7,19**
 Ale jeśli się odwrócicie, a opuścicie sprawiedliwości moje, i przykazania moje, którem wam podał, a odszedszy będziecie służyć bogom cudzym, i kłaniać się im:
###### **2Krn 7,20**
 Wykorzenię was z ziemie mojej, którąm wam dał: a ten dom, którym poświęcił imieniowi memu, odrzucę od oblicza mego, i podam ji w przypowieść, i na przykład wszystkim narodom.
###### **2Krn 7,21**
 A dom ten będzie za przypowieść wszystkim przechodzącym, i zdumiawszy się będą mówić: Przecz tak uczynił Pan tej ziemi, i domowi temu?
###### **2Krn 7,22**
 I odpowiedzą: Iż opuścili Pana Boga ojców swoich, który je wywiódł z ziemie Egiptskiej: a chwycili się bogów cudzych, i kłaniali się im i chwalili: przeto przyszło na nie to wszystko złe.
