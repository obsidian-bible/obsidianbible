# Ez 2 BT5
###### **Ez 2,1**
 Rzekł On do mnie: «***Synu człowieczy, stań na nogi. Będę do ciebie mówił***».
###### **Ez 2,2**
 I wstąpił we mnie duch, <gdy do mnie mówił>, i postawił mnie na nogi; potem słuchałem Tego, który do mnie mówił.
###### **Ez 2,3**
 Powiedział mi: «***Synu człowieczy, posyłam cię do synów Izraela, do ludu buntowników, którzy Mi się sprzeciwili. Oni i przodkowie ich występowali przeciwko Mnie aż do dnia dzisiejszego.
###### **Ez 2,4**
 To ludzie o bezczelnych twarzach i zatwardziałych sercach; posyłam cię do nich, abyś im powiedział: Tak mówi Pan Bóg.
###### **Ez 2,5**
 A oni, czy będą słuchać, czy też zaprzestaną – są bowiem ludem opornym – przecież będą wiedzieli, że prorok jest wśród nich.
###### **Ez 2,6**
 A ty, synu człowieczy, nie bój się ich ani się nie lękaj ich słów, nawet gdyby wokół ciebie były osty i ciernie i gdybyś się znalazł wśród skorpionów. Nie obawiaj się ich słów ani się nie lękaj ich twarzy, bo to lud oporny.
###### **Ez 2,7**
 Przekażesz im moje słowa, czy będą słuchać, czy też zaprzestaną, bo przecież są buntownikami.
###### **Ez 2,8**
 Ty więc, synu człowieczy, słuchaj tego, co ci powiem. Nie opieraj się, jak ten lud zbuntowany. Otwórz usta swoje i zjedz, co ci podam***».
###### **Ez 2,9**
 Popatrzyłem, a oto wyciągnięta była w moim kierunku ręka, w której był zwój księgi.
###### **Ez 2,10**
 Rozwinęła go przede mną; był zapisany z jednej i drugiej strony, a opisane w nim były narzekania, wzdychania i biadania.
# Ez 2 PAU
###### **Ez 2,1**
 Rzekł do mnie: „Synu człowieczy, wstań. Będę do ciebie mówił”.
###### **Ez 2,2**
 Gdy to powiedział, wstąpił we mnie duch, postawił mnie na nogi i słyszałem Tego, który mówił do mnie.
###### **Ez 2,3**
 Powiedział mi: „Synu człowieczy, posyłam cię do Izraelitów, do ludu buntowników, którzy wystąpili przeciwko Mnie. Oni i ich ojcowie sprzeniewierzali się Mi aż po dzień dzisiejszy.
###### **Ez 2,4**
 Są oni synami o zuchwałym obliczu i zatwardziałym sercu. Posyłam cię do nich, abyś im powiedział: Tak mówi PAN BÓG.
###### **Ez 2,5**
 Oni zaś, czy usłuchają, czy nie - są bowiem narodem buntowniczym - będą wiedzieli, że jest wśród nich prorok.
###### **Ez 2,6**
 Ty zaś, synu człowieczy, nie bój się ich i nie lękaj się ich słów, chociażby cię otaczali szydercy i pyszałkowie i chociażbyś siedział na skorpionach. Nie bój się ich i niech cię nie zrażają ich słowa, bo są oni narodem buntowniczym.
###### **Ez 2,7**
 Będziesz im mówił moje słowa, czy usłuchają, czy nie, są bowiem zbuntowani.
###### **Ez 2,8**
 Ty zaś, synu człowieczy, słuchaj tego, co Ja mówię do ciebie, i nie bądź buntownikiem jak ten naród buntowników. Otwórz swoje usta i zjedz, co ci podam”.
###### **Ez 2,9**
 Spojrzałem i zobaczyłem wyciągniętą ku mnie rękę, a w niej zwój księgi.
###### **Ez 2,10**
 A gdy go rozwinął przede mną, widziałem, że był on zapisany z obu stron. Były na nim wypisane skargi, wzdychania i biadania.
# Ez 2 BP
###### **Ez 2,1**
 I rzekł do mnie: Synu człowieczy, stań na swoich nogach, chcę mówić z tobą.
###### **Ez 2,2**
 Gdy przemówił do mnie, wstąpił we mnie duch. Postawił mię na nogi i słuchałem tego, który mówił do mnie.
###### **Ez 2,3**
 Powiedział mi: Synu człowieczy, ja posyłam cię do synów Izraela, do ludu buntowniczego, który powstał przeciwko mnie. Oni i ich ojcowie sprzeniewierzyli się mi aż po dzień dzisiejszy.
###### **Ez 2,4**
 Są to synowie o zawziętej twarzy i zatwardziałym sercu. Do nich cię posyłam, abyś im powiedział: Tak mówi Pan, Jahwe.
###### **Ez 2,5**
 Oni zaś, czy będą słuchać, czy [tego] nie uczynią - oni bowiem są Domem buntowniczym - powinni wiedzieć, że Prorok jest wśród nich.
###### **Ez 2,6**
 A ty, synu człowieczy, nie bój się ich, słów ich się nie lękaj, bo ciernie cię otaczają i na skorpionach siedzisz. Nie lękaj się ich słów, niech cię nie przeraża ich oblicze, gdyż są oni Domem buntowniczym.
###### **Ez 2,7**
 Powiedz im moje słowa, czy będą słuchać, czy [tego] nie uczynią, bo oni są buntownicy.
###### **Ez 2,8**
 Ty tedy, synu człowieczy, słuchaj, co Ja mówię do ciebie, i nie bądź tak przekorny, jak Dom buntowniczy. Otwórz swe usta i zjedz to, co ci daję.
###### **Ez 2,9**
 Spojrzałem: oto [ukazała się] ręka wyciągnięta ku mnie, a w niej był zwój księgi.
###### **Ez 2,10**
 Rozwinął go przede mną. Był on zapisany z obu stron, a spisane były na nim żale, skargi i lamenty.
# Ez 2 BR
###### **Ez 2,1**
 A takie były, skierowane do mnie słowa: Wstań, synu człowieczy, bo chcę ci coś powiedzieć.
###### **Ez 2,2**
 Gdy słuchałem tych słów, wszedł we mnie duch i postawił mnie na nogi. I wtedy posłyszałem Tego, który do mnie przemawiał.
###### **Ez 2,3**
 On zaś tak mówił: Synu człowieczy! Posyłam cię do zbuntowanych synów izraelskich, do tych, którzy się przeciwko Mnie buntują. Oni sami oraz synowie ich ciągle odchodzili ode Mnie i tak jest aż do dnia dzisiejszego.
###### **Ez 2,4**
 Są to ludzie o zuchwałych twarzach i zatwardziałych sercach. To właśnie do nich dziś posyłam ciebie. I powiesz im, że tak mówił Pan Bóg.
###### **Ez 2,5**
 I czy cię będą wtedy słuchać, czy nawet nie - bo to naród bardzo oporny - będą musieli uznać, że oto pojawił się pośród nich prorok.
###### **Ez 2,6**
 A ty, synu człowieczy, nie bój się ich i niech cię nie przerażają ich słowa! Nawet gdybyś widział wokół siebie same ciernie i gdybyś miał siadać na skorpionach, nie bój się tego, co ci będą mówić, nie lękaj się też wcale ich wzroku! Jest to naród bardzo oporny.
###### **Ez 2,7**
 Masz im przekazywać moje słowa, czy będą cię słuchać, czy nie, ponieważ są narodem bardzo opornym.
###### **Ez 2,8**
 A ty, synu człowieczy, posłuchaj, co ci powiem. Nie opieraj Mi się, tak jak ten lud tak bardzo oporny. Otwórz twoje usta i spożyj to, co ci podam.
###### **Ez 2,9**
 I zobaczyłem, jak wyciąga do mnie rękę, w której trzyma zwój księgi.
###### **Ez 2,10**
 A kiedy rozwinął przede mną zwój, zobaczyłem, że jest zapisany po obydwu stronach. Były tam spisane różne skargi, narzekania i biadania.
# Ez 2 WUJ
###### **Ez 2,1**
 i rzekł do mnie: Synu człowieczy stań na nogi twe, a będę mówił z tobą.
###### **Ez 2,2**
 I wszedł w mię duch potem jako wyrzekł do mnie i postawił mię na nogi moje: i słyszałem mówiącego do mnie.
###### **Ez 2,3**
 I rzekącego: Synu człowieczy, posyłam ja ciebie do synów Izraelowych, do narodów odstępnych, które odstąpiły odemnie; sami i ojcowie ich przestąpili przymierze moje aż do dnia tego.
###### **Ez 2,4**
 I synowie twardej twarzy, i nieukróconego serca są, do których ja ciebie posyłam: a rzeczesz do nich: To mówi Pan Bóg:
###### **Ez 2,5**
 Jeśli snać, abo ci usłuchają, i jeśli snać zaniechają, bo domem drażniącym jest: i będą wiedzieć że prorok był w pośrodku ich.
###### **Ez 2,6**
 A tak ty synu człowieczy nie bój się ich, ani się mów ich lękaj: bo niewiernicy i przewrotnicy są z tobą, a z niedźwiadkami mieszkasz. Słów ich nie bój się, a oblicza ich nie strachaj się, bo dom drażniący jest.
###### **Ez 2,7**
 Ą tak będziesz mówił słowa moje do nich, jeśli snać usłyszą, a przestaną, bo drażniący są.
###### **Ez 2,8**
 A ty synu człowieczy słuchaj co ja mówię do ciebie: nie bądź drażniącym, jako dom drażniący jest, otwórz usta twoje, a jedz co ja daję tobie.
###### **Ez 2,9**
 I ujrzałem ano ręka ściągniona ku mnie, w której były zwinione księgi:
###### **Ez 2,10**
 (9b) i rozwinęła je przedemną, które były popisane wewnątrz i zwierzchu: a napisano na nich narzekanie pieśń i biadę.
