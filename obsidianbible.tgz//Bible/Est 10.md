# Est 10 BT5
###### **Est 10,1**
 Król Aswerus nałożył podatek na kraj i na wyspy morza.
###### **Est 10,2**
 A wszystkie dzieła jego potęgi i jego mocy, i opis wielkości Mardocheusza, którego król uczynił wielkim, czyż te sprawy nie są zapisane w Księdze kronik królów Medów i Persów?
###### **Est 10,3**
[^2]
Albowiem Żyd Mardocheusz był drugim po królu Aswerusie i wielkim w oczach Żydów, i umiłowanym przez mnóstwo braci swoich. Troszczył się o dobro swego ludu i zabiegał o szczęście całego swojego narodu.
###### **Est 10,3a**
 I mówił Mardocheusz: «***Przez Boga to się stało.***
##### **Est 10,3b**
 ***Wspomniałem sobie bowiem sen, który miałem o tych sprawach: nic w nim nie zostało pominięte;***
##### **Est 10,3c**
 ***małe źródło, które stało się rzeką, potem było światło i słońce, i wielka woda. Rzeką tą jest Estera, którą poślubił król i uczynił królową.***
##### **Est 10,3d**
 ***A dwa smoki to jestem ja i Haman,***
###### **Est 10,3e**
 ***narody zaś zgromadziły się, aby zgładzić imię Żydów.***
###### **Est 10,3f**
 ***Naród mój to Izrael: ci, którzy wołali do Boga i zostali ocaleni. Pan ocalił swój naród i uwolnił nas Pan ze wszystkich nieszczęść, i uczynił Bóg znaki i cuda, jakie nie działy się wśród pogan.***
###### **Est 10,3g**
 ***W tym celu przygotował dwa losy: jeden dla ludu Bożego, a drugi dla narodów pogańskich.***
###### **Est 10,3h**
 ***Oba te losy przyszły na godzinę i czas, i na dzień sądu wszystkich narodów przed oblicze Boga.***
###### **Est 10,3i**
 ***Bóg zaś wspomniał na lud swój i oddał sprawiedliwość dziedzictwu swemu.***
###### **Est 10,3k**
 ***I będą dla nich owe dni w miesiącu Adar, czternastego i piętnastego tegoż miesiąca, dniami zgromadzenia i radości, i wesołości przed obliczem Boga z pokolenia na pokolenie, na wieki w Jego ludzie izraelskim***».***
###### **Est 10,3l**
 W czwartym roku panowania Ptolemeusza i Kleopatry Dozyteusz, który uważał się za kapłana i lewitę, i Ptolemeusz, syn jego, przynieśli powyższy list dotyczący Frurai, który – jak powiadają – jest wiarogodny. Przetłumaczył go Lizymach, syn Ptolemeusza z Jerozolimy.
# Est 10 PAU
###### **Est 10,1**
 Król nałożył podatki na ziemię królestwa i wyspy na morzu.
###### **Est 10,2**
 W księdze królów perskich i medyjskich opisał też na pamiątkę swoją potęgę i waleczność, a także bogactwo i świetność swego królestwa.
###### **Est 10,3**
 Mardocheusz był drugi po królu Artakserksesie. Był wielki w królestwie, a czczony i miłowany przez Żydów, opowiadał całemu narodowi, co się wydarzyło. (a) Mardocheusz mówił: „Wszystko stało się za przyczyną Boga. (b) Przypomniałem sobie bowiem sen, jaki miałem w związku z tymi wydarzeniami i każde z nich się wypełniło. (c) Małe źródło stało się rzeką, pojawiło się światło i słońce, i mnóstwo wody. Rzeką jest Estera, którą król poślubił i uczynił królową. (d) Dwa smoki - to ja i Haman. (e) Narodami są ci, którzy się zeszli, aby wymazać imię Żydów. (f) Moim narodem jest Izrael, który wołał do Boga i został ocalony. PAN ocalił swój lud i PAN wybawił nas ze wszystkich tych nieszczęść. Bóg uczynił wielkie znaki i cuda, jakie nie zdarzyły się wśród pogan, (g) dlatego wyznaczył dwa losy: jeden dla ludu Bożego, a drugi dla wszystkich narodów. (h) Te dwa losy spełniły się o godzinie i czasie, w dniu sądu przed Bogiem i wobec wszystkich narodów pogańskich. (i) Wtedy to Bóg wspomniał swój lud i oddał sprawiedliwość swojemu dziedzictwu. (k) Te więc dni miesiąca Adar, czternasty i piętnasty dzień tego miesiąca, będą dla Jego ludu Izraela dniami spotkań, radości i wesela przed Bogiem przez pokolenia na wieki”. (l) Dozyteusz, który mówił, że jest kapłanem i lewitą, oraz Ptolemeusz, jego syn, przywieźli powyższy list dotyczący Purim w czwartym roku panowania Ptolemeusza i Kleopatry. Mówili, że jest wiarygodny i że został przetłumaczony w Jeruzalem przez Lizymacha, syna Ptolemeusza.
# Est 10 BP
###### **Est 10,1**
 Król Achaszwerosz nałożył podatek na ziemie i wyspy morza.
###### **Est 10,2**
 A czyż nie zapisano w księdze kronik królów Medii i Persji wszystkich dowodów jego władzy i potęgi, a także dokładnego sprawozdania o wielkości Mardocheusza, do której król go wyniósł? Żyd Mardocheusz był bowiem drugim po królu Achaszweroszu, cieszył się uznaniem u Żydów i doznawał miłości ze strony własnych współziomków. Dbał on gorliwie o dobro swego ludu i ujmował się za losem całego swego plemienia.
###### **Est 10,3**
 Według LXX: F 10.3a-31 3a Rzekł Mardocheusz: - To wszystko stało się za przyczyną Boga. 3b Przypominam sobie bowiem sen, który miałem o tych wszystkich wydarzeniach. Nie było w nim niczego, co by się nie ziściło: 3c małe źródło zamienione w rzekę, światło, które zajaśniało, i słońce, i obfitość wody. Rzeką jest Estera, którą król poślubił i ustanowił królową. 3d Dwa smoki zaś - to ja i Aman. 3e Narody - to ci, którzy wspólnie postanowili wytracić imię Żydów. 3f Lud mój - to Izrael, który wołał do Boga i został ocalony. To Pan ocalił swój lud, Pan wyzwolił nas od tych wszystkich cierpień. Bóg uczynił znaki i cuda wielkie, jakie wśród pogan się nie zdarzają. 3g Dlatego Bóg wyznaczył dwa losy: jeden dla ludu Bożego, drugi dla wszystkich pozostałych narodów. 3h Obydwa te losy wypełniły się w godzinie, w czasie i w dniu sądu wyznaczonym dla wszystkich narodów przed Bogiem. 3i Bóg wspomniał wówczas na swój naród i oddał sprawiedliwość swojemu dziedzictwu. 3k Te dni w miesiącu Adar, czternastego i piętnastego dnia tego miesiąca, mają być dla nich dniami zgromadzenia, radości i wesołości przed obliczem Boga dla wszystkich pokoleń na wieki w Jego narodzie izraelskim. 3l Roku czternastego panowania Ptolomeusza i Kleopatry, Dozyteusz, który - jak mówił - był kapłanem i lewitą, oraz syn jego Ptolomeusz, przynieśli ten list odnoszący się do święta Frurai, według ich zapewnień prawdziwy, a przełożył go zaś Lyzymach, syn Ptolomeusza, jeden z mieszkańców Jerozolimy.
# Est 10 BR
###### **Est 10,1**
 Król Aswerus zobowiązał cały kraj i wszystkie wyspy do płacenia podatku.
###### **Est 10,2**
 Wszystkie zaś znaczne dzieła dokonane przez króla oraz wielkie poważanie, jakim cieszył się u króla Mardocheusz, wszystko to jest opisane w księdze kronik Medów i Persów.
###### **Est 10,3**
 Żyd Mardocheusz był bowiem drugą osobowością po królu Aswerusie. Cieszył się on także wielkim szacunkiem u wszystkich swoich rodaków i był przez nich kochany. Troszczył się zawsze o dobro swojego narodu i zabiegał o szczęście dla przyszłych pokoleń. (a) Mówił Mardocheusz: Wszystko to zawdzięczamy Bogu. (b) Przypominam sobie, jak mi się to wszystko kiedyś śniło. Wszystko się sprawdziło. (c) Widziałem wtedy małe źródełko, które przemieniło się z czasem w potężny potok obfitujący w wodę; zobaczyłem znów wiele światła i wschodzące na nowo słońce i wielką wodę. Otóż tym potokiem obfitującym w wodę była Estera, którą król poślubił i uczynił królową. (d) Dwa smoki, które wtedy widziałem - to ja i Haman, (e) a narody tamte - to ci wszyscy, którzy zamierzali zgładzić Żydów; (f) mój zaś lud - to Izraelici, którzy wołali o pomoc Boga i zostali ocaleni. Pan uratował swój lud, Pan wybawił nas od wszystkich owych ucisków, Bóg uczynił znaki i cuda tak wielkie, jakich przedtem nigdy jeszcze nie dokonał wśród innych narodów. (g) Dlatego spotkały ludzkość jakby dwa przeznaczenia: jedno dla ludu Bożego, drugie dla pozostałych narodów. (h) Wypełnić się miały te obydwa przeznaczenia w określonej godzinie i w wyznaczonym czasie, czyli w dniu sądu, jaki miał się dokonać przed obliczem Boga nad wszystkimi narodami. (i) Bóg wspomniał na lud, który jest Jego dziedzictwem; wejrzał na ten lud i przyznał mu jego prawa. (k) Dni te w miesiącu Adar, to znaczy czternasty i piętnasty tego miesiąca, mają być obchodzone uroczyście przez Jego naród izraelski po wszystkie czasy i pokolenia na oczach Boga, razem przez cały lud, ze szczególną radością. (l) W czwartym roku panowania Ptolomeusza i Kleopatry pismo to, dotyczące święta Purim przynieśli: Dosyteusz, który uważał się za kapłana i lewitę, oraz syn jego Ptolomeusz. Ten według powszechnego mniemania wiarygodny list został przetłumaczony przez Lizymacha z Jerozolimy, syna Ptolomeusza.
# Est 10 WUJ
###### **Est 10,1**
 A król Asswerus uczynił hołdowne, wszystkę ziemię, i wszystkie wyspy morskie.
###### **Est 10,2**
 Którego moc i panowanie i zacność, i wywyższenie, którem wywyższył Mardocheusza, napisane są w księgach Medskich i Perskich:
###### **Est 10,3**
 I jako Mardocheusz z narodu żydowskiego, był wtórym po królu Asswerusie: i wielki u żydów, a wdzięcznym ludowi braciej swej, starając się o dobre ludu swego, i mówiąc to co należało ku pokojowi narodu swego.
