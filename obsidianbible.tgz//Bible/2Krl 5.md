# 2Krl 5 BT5
###### **2Krl 5,1**
 Naaman, wódz wojska króla Aramu, miał wielkie znaczenie u swego pana i doznawał względów, ponieważ przez niego Pan spowodował ocalenie Aramejczyków. Lecz ten człowiek – < dzielny wojownik > – był trędowaty.
###### **2Krl 5,2**
 Aramejczycy podczas napadu łupieskiego uprowadzili z ziemi Izraela młodą dziewczynę, którą przeznaczono do usług żonie Naamana.
###### **2Krl 5,3**
 Ona rzekła do swojej pani: «***O, gdyby pan mój udał się do proroka, który jest w Samarii! Ten by go Wówczas uwolnił od trądu***».
###### **2Krl 5,4**
 Naaman więc poszedł oznajmić to swojemu panu, powtarzając słowa dziewczyny, która pochodziła z kraju Izraela.
###### **2Krl 5,5**
 A król Aramu odpowiedział: «***Ruszaj w drogę! A ja poślę list do króla izraelskiego***». Wyruszył więc, zabierając ze sobą dziesięć talentów srebra, sześć tysięcy syklów złota i dziesięć ubrań na zmianę.
###### **2Krl 5,6**
 I przedłożył królowi izraelskiemu list następującej treści: «***Z chwilą gdy dojdzie do ciebie ten list, [wiedz], iż posyłam do ciebie Naamana, sługę mego, abyś go uwolnił od trądu***».
###### **2Krl 5,7**
 Kiedy przeczytano list królowi izraelskiemu, rozdarł swoje szaty i powiedział: «***Czy ja jestem Bogiem, żebym mógł uśmiercać i ożywiać? Bo ten poleca mi uwolnić człowieka od trądu! Tylko dobrze zastanówcie się i rozważcie, czy on nie szuka zaczepki ze mną?***»
###### **2Krl 5,8**
 Lecz kiedy Elizeusz, mąż Boży, dowiedział się, iż król izraelski rozdarł swoje szaty, polecił powiedzieć królowi: «***Czemu rozdarłeś szaty? Niech on przyjdzie do mnie, a dowie się, że jest prorok w Izraelu***».
###### **2Krl 5,9**
 Więc Naaman przyjechał swymi końmi i swoim powozem i stanął przed drzwiami domu Elizeusza.
###### **2Krl 5,10**
 Elizeusz zaś kazał mu przez posłańca powiedzieć: «***Idź, obmyj się siedem razy w Jordanie, a ciało twoje będzie takie jak poprzednio i staniesz się czysty!***»
###### **2Krl 5,11**
 Rozgniewał się Naaman i odszedł ze słowami: «***Przecież myślałem sobie: Na pewno wyjdzie, stanie, następnie wezwie imienia Pana, Boga swego, poruszy ręką nad miejscem [chorym] i odejmie trąd.***
###### **2Krl 5,12**
 ***Czyż Abana i Parpar, rzeki Damaszku, nie są lepsze od wszystkich wód Izraela? Czyż nie mogłem się w nich wykąpać i być oczyszczonym?***» Pełen gniewu zawrócił, by odejść.
###### **2Krl 5,13**
 Lecz słudzy jego przybliżyli się i przemówili do niego tymi słowami: «***Mój ojcze, gdyby prorok kazał ci spełnić coś trudnego, czy byś nie wykonał? O ileż więc bardziej, jeśli ci powiedział: Obmyj się, a będziesz czysty***».
###### **2Krl 5,14**
 Odszedł więc Naaman i zanurzył się siedem razy w Jordanie, według słowa męża Bożego, a ciało jego na powrót stało się jak ciało małego chłopca i został oczyszczony.
###### **2Krl 5,15**
 Wtedy wrócił do męża Bożego z całym orszakiem, wszedł i stanął przed nim, mówiąc: «***Oto przekonałem się, że na całej ziemi nie ma Boga poza Izraelem! A teraz zechciej przyjąć dar od twego sługi!***»
###### **2Krl 5,16**
 On zaś odpowiedział: «***Na życie Pana, przed którego obliczem stoję – nie wezmę!***» Tamten nalegał na niego, aby przyjął, lecz on odmówił.
###### **2Krl 5,17**
 Wtedy Naaman rzekł: «***Jeśli już nie [chcesz], to niech dadzą twemu słudze tyle ziemi, ile para mułów unieść może, ponieważ odtąd twój sługa nie będzie składał ofiary całopalnej ani ofiary krwawej innym bogom, jak tylko Panu.***
###### **2Krl 5,18**
 ***To jedynie niech Pan Bóg tylko przebaczy twemu słudze: kiedy pan mój wchodzi do świątyni Rimmona, aby tam oddać pokłon, opiera się na moim ramieniu – wtedy i ja muszę oddać pokłon w świątyni Rimmona. < Gdy więc będę oddawał pokłon w świątyni Rimmona >, tę tylko czynność niech Pan Bóg przebaczy twemu słudze!***»
###### **2Krl 5,19**
 Elizeusz odpowiedział mu: «***Idź w pokoju!***» Kiedy odszedł od niego szmat drogi,
###### **2Krl 5,20**
 Gechazi, sługa Elizeusza, męża Bożego, powiedział sobie: «***Oto mój pan oszczędził tego Aramejczyka, Naamana, nie przyjmując od niego rzeczy, które przyniósł. Na życie Pana – pobiegnę za nim i wezmę od niego cokolwiek***».
###### **2Krl 5,21**
 I pobiegł Gechazi za Naamanem. Kiedy Naaman ujrzał, że biegnie za nim, zeskoczył z wozu na jego spotkanie i powiedział: «***Czy [wszystko] idzie dobrze?***»
###### **2Krl 5,22**
 Odpowiedział: «***Dobrze. Pan mój polecił mi powiedzieć: Teraz oto przyszli do mnie dwaj młodzieńcy z góry Efraima, synowie proroccy. Daj mi, proszę, jeden talent srebra i dwa ubrania na zmianę***».
###### **2Krl 5,23**
 Odpowiedział Naaman: «***Racz przyjąć dwa talenty***». Nalegał na niego, zawiązał dwa talenty srebra w dwóch workach, do tego dwa ubrania na zmianę, i wręczył dwom swoim sługom, którzy to nieśli przed nim.
###### **2Krl 5,24**
 Kiedy przyszedł do Ofelu, Gechazi odebrał te rzeczy z ich rąk i złożył w domu. Następnie odprawił mężów, którzy odeszli.
###### **2Krl 5,25**
 Sam zaś poszedł i stawił się przed swoim panem, a Elizeusz zapytał go: «***Skąd ty idziesz, Gechazi?***» Odparł: «***Sługa twój nigdzie nie chodził***».
###### **2Krl 5,26**
 Lecz on powiedział do niego: «***Nie, serce moje ci towarzyszyło, kiedy ktoś odwrócił się na wozie swoim na twoje spotkanie. Czy teraz jest czas brać srebro, aby nabywać ubrania, drzewa oliwne, winnice, drobne i większe bydło, niewolników i niewolnice?***
###### **2Krl 5,27**
 ***A trąd Naamana przylgnie do ciebie i do twojego potomstwa na zawsze***». Gechazi więc oddalił się od niego biały jak śnieg od trądu.
# 2Krl 5 PAU
###### **2Krl 5,1**
 Naaman był dowódcą wojska króla Aramu. Był on człowiekiem bardzo poważanym i wysoko cenionym przez swojego pana, gdyż przez niego PAN dał zwycięstwo Aramowi. Niestety, ten dzielny wojownik był trędowaty.
###### **2Krl 5,2**
 Podczas jakiegoś napadu na Izraela Aramejczycy wzięli do niewoli młodą dziewczynę, którą oddano na służbę żonie Naamana.
###### **2Krl 5,3**
 Pewnego razu powiedziała ona do swojej pani: „O, gdyby tylko mój pan mógł stanąć przed prorokiem, który jest w Samarii. On uwolniłby go od trądu”.
###### **2Krl 5,4**
 Naaman poszedł więc do swojego pana i oznajmił mu to, co powiedziała dziewczyna z ziemi Izraela.
###### **2Krl 5,5**
 „Wyruszaj natychmiast - odrzekł król Aramu - a ja poślę list do króla izraelskiego”. Wyruszył zatem, zabierając ze sobą dziesięć talentów srebra, sześć tysięcy syklów złota oraz dziesięć kompletów ubrań.
###### **2Krl 5,6**
 List, który przekazał królowi izraelskiemu, był następującej treści: „Wraz z tym listem posyłam do ciebie Naamana, mojego sługę, abyś uwolnił go od trądu”.
###### **2Krl 5,7**
 Kiedy król Izraela przeczytał list, rozdarł swoje szaty i wykrzyknął: „Czy ja jestem Bogiem, abym miał uśmiercać lub ożywiać? Ten bowiem przysyła do mnie człowieka, abym go uwolnił od trądu! Widzicie jasno, że szuka on zaczepki ze mną!”.
###### **2Krl 5,8**
 Kiedy Elizeusz, człowiek Boży, usłyszał, że król Izraela rozdarł swoje szaty, polecił mu oznajmić: „Dlaczego rozdarłeś swoje szaty? Niech przyjdzie do mnie i przekona się, że jest prorok w Izraelu!”.
###### **2Krl 5,9**
 Przybył więc Naaman z całym swym orszakiem i stanął przed drzwiami domu Elizeusza.
###### **2Krl 5,10**
 Elizeusz natomiast wysłał do niego posłańca z poleceniem: „Idź i obmyj się siedem razy w Jordanie, a twoje ciało stanie się zdrowe i będziesz oczyszczony”.
###### **2Krl 5,11**
 Naaman rozgniewał się na to i odchodząc, mówił: „Myślałem sobie: Na pewno wyjdzie, stanie i wezwie imienia PANA, Boga swojego, a potem uniesie rękę nad chorym miejscem i uwolni mnie od trądu.
###### **2Krl 5,12**
 Czyż Abana i Parpar, rzeki Damaszku, nie są lepsze od wszystkich wód Izraela? Czyż nie mogłem się w nich obmyć i być oczyszczonym?”. Odwrócił się i odszedł w gniewie.
###### **2Krl 5,13**
 Lecz jego słudzy podeszli do niego i zaczęli go przekonywać: „Panie, gdyby prorok polecił ci zrobić coś trudnego, czyż byś tego nie wykonał? O ileż bardziej, jeśli ci powiedział: «Obmyj się, a będziesz czysty»”.
###### **2Krl 5,14**
 Wszedł więc do Jordanu i zanurzył się w nim siedem razy, zgodnie ze słowem człowieka Bożego, a jego ciało stało się na powrót zdrowe jak ciało małego dziecka. I stał się czysty.
###### **2Krl 5,15**
 Natychmiast z całym orszakiem wrócił do człowieka Bożego. Kiedy stanął przed nim, powiedział: „Teraz już naprawdę wiem, że na całej ziemi nie ma Boga poza Izraelem! Przyjmij więc dar ode mnie, twojego sługi”.
###### **2Krl 5,16**
 On jednak odpowiedział: „Przysięgam na PANA, któremu służę: Nie przyjmę niczego!”. I pomimo usilnego nalegania z jego strony, odmówił.
###### **2Krl 5,17**
 Rzekł wtedy Naaman: „Jeśli nie, to mam prośbę: niech twojemu słudze będzie wolno zabrać tyle ziemi, ile udźwignie para mułów, gdyż odtąd nie będę już składał całopaleń ani ofiar innym bogom, jak tylko PANU.
###### **2Krl 5,18**
 Tylko to jedno niech PAN wybaczy twojemu słudze: kiedy pan mój wchodzi do świątyni Rimmona, aby oddać tam pokłon, opiera się na moim ramieniu, wtedy i ja oddaję pokłon w świątyni Rimmona. To jedno, że będę oddawał pokłon w świątyni Rimmona, niech PAN wybaczy twojemu słudze”.
###### **2Krl 5,19**
 Elizeusz rzekł mu: „Idź w pokoju!”. Naaman nie uszedł jeszcze zbyt daleko,
###### **2Krl 5,20**
 kiedy Gechazi, sługa Elizeusza, człowieka Bożego, pomyślał sobie: „Cóż to, mój pan oszczędził tego Aramejczyka, Naamana, nie przyjmując od niego tego, co przyniósł. Przysięgam na PANA: pobiegnę zaraz za nim i wezmę coś od niego”.
###### **2Krl 5,21**
 Gechazi pospieszył za Naamanem. Gdy tylko Naaman zobaczył go biegnącego, zszedł z rydwanu, wyszedł mu na spotkanie i zapytał: „Czy wszystko w porządku?”.
###### **2Krl 5,22**
 Odrzekł: „Wszystko dobrze, tylko mój pan przysłał mnie z prośbą: «Właśnie teraz przyszli do mnie dwaj młodzieńcy z góry Efraima, należący do uczniów proroków. Proszę cię dla nich o talent srebra i dwa komplety ubrań»”.
###### **2Krl 5,23**
 „Ależ weź dwa talenty” - odpowiedział Naaman. I przymusił go wręcz, pakując dwa talenty srebra do dwóch worków, które wraz z dwoma kompletami ubrań wzięli dwaj jego słudzy i nieśli przed nim.
###### **2Krl 5,24**
 Gdy przybyli do twierdzy, odebrał je od sług i złożył w domu. Potem odesłał tych ludzi. Kiedy oni już odeszli,
###### **2Krl 5,25**
 on sam przyszedł do swojego pana. Zapytał go Elizeusz: „Gdzie byłeś Gechazi?”. On zaś odparł: „Twój sługa nigdzie nie wychodził”.
###### **2Krl 5,26**
 Elizeusz jednak powiedział do niego: „Czyż moje myśli nie towarzyszyły ci, gdy pewien człowiek zszedł ze swojego rydwanu i wyszedł na spotkanie z tobą? Czy teraz jest czas przyjmowania srebra i nabywania ubrań, ogrodów oliwnych, winnic, owiec bydła, niewolników i niewolnic?
###### **2Krl 5,27**
 Dlatego też trąd Naamana przylgnie do ciebie i do twojego potomstwa na zawsze!”. Kiedy Gechazi wychodził od niego, był biały od trądu jak śnieg.
# 2Krl 5 BP
###### **2Krl 5,1**
 Naaman, wódz wojska króla Aramu był mężem bardzo poważanym i wysoko cenionym przez swego pana, ponieważ przez niego Jahwe dał zwycięstwo Aramejczykom. Mąż [ten], bohater wojska, był trędowaty.
###### **2Krl 5,2**
 [Swego czasu] bandy Aramejczyków urządziły [napad] i uprowadziły z ziemi izraelskiej małą dziewczynkę, [która] została [później] służącą żony Naamana.
###### **2Krl 5,3**
 [Ona to] powiedziała [raz] do swojej pani: Ach, gdyby pan mój [stanął] przed Prorokiem, który jest w Samarii, wówczas [on] uleczyłby go z trądu.
###### **2Krl 5,4**
 [Naaman] przybył i oznajmił swojemu panu mówiąc: Tak a tak powiedziała dziewczynka, która [pochodzi] z ziemi izraelskiej.
###### **2Krl 5,5**
 Król Aramu rzekł: Idź! Wstąp, a poślę list do króla izraelskiego. Wyruszył więc i wziął z sobą dziesięć talentów srebra, sześć tysięcy [syklów] złota oraz dziesięć szat na zmianę.
###### **2Krl 5,6**
 Królowi izraelskiemu wręczył list tej treści: Oto wraz z tym listem, który otrzymujesz, posyłam ci Naamana, mojego dworzanina, abyś go uleczył z trądu.
###### **2Krl 5,7**
 Gdy król izraelski przeczytał list, rozdarł swoje szaty i zawołał: Czy ja jestem Bogiem, mogącym zadawać śmierć i przywracać życie, że ten posyła do mnie, abym uleczył człowieka z trądu? Bez wątpienia - wiedzcie i zauważcie, że szuka on okazji [do wojny] ze mną.
###### **2Krl 5,8**
 Gdy Elizeusz, mąż Boży, dowiedział się, że król Izraela rozdarł szaty swoje, posłał do króla, aby [mu] powiedzieć: Czemu rozdarłeś swe szaty? Niech przyjdzie do mnie, a dowie się, że jest Prorok w Izraelu.
###### **2Krl 5,9**
 I przybył Naaman, swoimi końmi, na swoim wozie, i zatrzymał się przed wejściem do domu Elizeusza.
###### **2Krl 5,10**
 Elizeusz posłał do niego posłańca mówiąc: Idź, obmyj się siedem razy w Jordanie, a ciało twoje stanie się znowu [zdrowe] i będziesz oczyszczony.
###### **2Krl 5,11**
 Rozgniewał się Naaman, odszedł i rzekł: Oto sądziłem, że na pewno wyjdzie, stanie, wezwie Imienia Jahwe, swojego Boga, dotknie swoją ręką [chorego] miejsca i uzdrowi trąd.
###### **2Krl 5,12**
 Czyż Abana i Parpar, rzeki Damaszku, nie są lepsze od wszystkich wód Izraela? Czy nie mogłem się w nich obmyć i być oczyszczonym? Odwrócił się i odszedł zły.
###### **2Krl 5,13**
 Ale jego słudzy podeszli, przemówili do niego i rzekli: Mój ojcze! Gdyby Prorok polecił ci [wykonać] wielką rzecz, czy byś nie wykonał? Tym bardziej [powinieneś go usłuchać], skoro ci powiedział: Obmyj się, a będziesz oczyszczony.
###### **2Krl 5,14**
 Zszedł więc i zanurzył się siedem razy w Jordanie, według słowa męża Bożego. Ciało jego stało się znowu [zdrowe], jak ciało małego chłopca, i został oczyszczony.
###### **2Krl 5,15**
 [Wtedy] wrócił on z całym orszakiem do męża Bożego, wszedł, stanął przed nim i rzekł: Oto wiem, że na całej ziemi nie ma [takiego] Boga jak w Izraelu. A teraz przyjmij podarek od twojego sługi.
###### **2Krl 5,16**
 Odpowiedział: Na żyjącego Jahwe, któremu służę, nie wezmę. Nalegał na niego, aby wziął, ale odmówił.
###### **2Krl 5,17**
 Wtedy Naaman rzekł: Skoro nie, pozwól, aby twojemu słudze dano [tyle] ziemi, [ile wynosi] obciążenie pary mułów, bo sługa twój nie będzie więcej składał całopalenia i krwawej ofiary innym bóstwom, jak tylko Jahwe.
###### **2Krl 5,18**
 [Ale] tę rzecz niech wybaczy Jahwe twojemu słudze: Kiedy mój pan przychodzi do świątyni Rimmona, aby tam bić pokłony, i wspiera się na mojej ręce, [wówczas] skłaniam się głęboko w świątyni Rimmona, podczas jego składania pokłonów [...]. Tę rzecz niech daruje Jahwe twojemu słudze.
###### **2Krl 5,19**
 Odpowiedział mu: Idź w pokoju. [Naaman] oddalił się od niego na znaczną odległość,
###### **2Krl 5,20**
 [gdy] Gechazi, sługa Elizeusza, męża Bożego, powiedział [sobie]: Oto mój pan oszczędził Naamana, tego Aramejczyka, odmawiając przyjęcia tego, co przyniósł. Na żyjącego Jahwe, pobiegnę za nim i wezmę coś od niego.
###### **2Krl 5,21**
 I pobiegł Gechazi za Naamanem. Gdy Naaman ujrzał, że biegnie za nim, zeskoczył z wozu na jego spotkanie i spytał: Czy pokój [zwiastujesz]?
###### **2Krl 5,22**
 Odrzekł: Pokój. Mój pan posłał mię, aby [ci] powiedzieć: Oto teraz właśnie przyszli do mnie dwaj chłopcy z gór Efraim od synów prorockich, zechciej im dać talent srebra i dwie szaty na zmianę.
###### **2Krl 5,23**
 Naaman poprosił: Racz wziąć dwa talenty. Nalegał na niego i zawiązał do dwóch worków dwa talenty srebra oraz dwie szaty na zmianę. Dał dwom swoim sługom i dźwigali przed nim.
###### **2Krl 5,24**
 A gdy przybył do Ofel, wziął [je] od nich i złożył w domu. Mężczyzn odprawił i poszli.
###### **2Krl 5,25**
 Sam zaś przyszedł i posługiwał swojemu panu. Elizeusz zapytał go: Gechazi, skąd [przychodzisz]? Odpowiedział: Sługa twój nigdzie nie chodził.
###### **2Krl 5,26**
 Rzekł mu: Nie? Serce moje śledziło, jak [pewien] mąż zszedł z wozu na twoje spotkanie. Czy pora brać srebro i nabywać szaty, oliwki i winnice, trzodę i bydło, sługi i służące?
###### **2Krl 5,27**
 Trąd Naamana przylgnie do ciebie i do twoich potomków na zawsze. I wyszedł od niego [biały] od trądu jak śnieg.
# 2Krl 5 BR
###### **2Krl 5,1**
 Naaman, dowódca wojsk króla Aramu, cieszył się wielkim szacunkiem u swego pana i miał niemałą władzę. To właśnie dzięki niemu Jahwe uratował Aramejczyków. Lecz mąż ten, bardzo odważny i dzielny, był trędowaty.
###### **2Krl 5,2**
 Tymczasem Aramejczycy, utworzywszy groźne oddziały zbrojne, porwali dziewczynę izraelską, którą przeznaczono na służącą dla żony Naamana.
###### **2Krl 5,3**
 Pewnego razu powiedziała ona do swojej pani: Gdyby mój pan zechciał nawiedzić proroka, który jest w Samarii, na pewno zostałby uwolniony od trądu.
###### **2Krl 5,4**
 Naaman powtórzył to swojemu panu, mówiąc: Młoda dziewczyna, Izraelitka, doradzała mi tak i tak.
###### **2Krl 5,5**
 A król Aramejczyków powiedział: Idź tam, ja sam wyślę list do króla izraelskiego. Wyruszył tedy [Naaman] w drogę, zabierając ze sobą dziesięć talentów srebra, sześć tysięcy sykli złota i dziesięć szat na zmianę.
###### **2Krl 5,6**
 Miał też ze sobą list od króla izraelskiego, a w liście tym było napisane: Kiedy otrzymasz ten list, wiedz, że masz przed sobą sługę mojego, Naamana, którego posyłam do ciebie, abyś go uleczył z trądu.
###### **2Krl 5,7**
 Przeczytawszy list, król izraelski rozdarł swoje szaty i powiedział: Czyż ja jestem Bogiem, który może pozbawiać ludzi życia i ożywiać ich na nowo, że on przysyła do mnie tego człowieka, bym go uwolnił od trądu? Sami widzicie, że on wyraźnie szuka jakiejś zaczepki.
###### **2Krl 5,8**
 Gdy mąż Boży, Elizeusz, dowiedział się, że król izraelski rozdarł swoje szaty, posłał kogoś do króla z zapytaniem: Dlaczego ty rozdzierasz swoje szaty? Niech przyjdzie do mnie, to przekona się, że jest w Izraelu prorok.
###### **2Krl 5,9**
 Przybył więc Naaman ze swymi końmi i ze swym rydwanem i zatrzymał się przed domem Elizeusza.
###### **2Krl 5,10**
 Elizeusz zaś wydał mu przez kogoś takie polecenie: Idź i obmyj się siedem razy w Jordanie; twoje ciało przybierze dawny wygląd i będziesz zdrów.
###### **2Krl 5,11**
 Naaman jednak rozgniewał się i odszedł, mówiąc: Myślałem, że on wyjdzie do mnie, że się przedstawi osobiście, że będzie wzywał imienia Jahwe, swojego Boga, że dotknie własnymi rękami moich ran i uwolni mnie od trądu.
###### **2Krl 5,12**
 Czyż rzeki Damaszku, Abana i Parpar, nie są potężniejsze niż wszystkie wody Izraela? Czyż ja nie mogłem obmyć się w nich i stać się czystym? Potem odwróciwszy się, odszedł bardzo zagniewany.
###### **2Krl 5,13**
 Lecz wtedy zbliżyli się do niego jego słudzy i zaczęli mówić: nasz ojcze! Czyż nie posłuchałbyś proroka, gdyby kazał ci uczynić coś trudnego? O ileż chętniej powinieneś go posłuchać, kiedy ci mówi: Obmyj się, a będziesz czysty?
###### **2Krl 5,14**
 Dopiero wtedy poszedł i zanurzył się siedem razy w Jordanie, zgodnie z poleceniem męża Bożego. Jego ciało przybrało wygląd ciała małego dziecka i zostało oczyszczone.
###### **2Krl 5,15**
 Wrócił zatem Naaman z całym swoim orszakiem do męża Bożego. Przybywszy na miejsce, wszedł [do jego domu], stanął przed nim i powiedział: Teraz wiem, że nie ma na całej ziemi innego Boga oprócz Boga Izraela. Racz tedy przyjąć od sługi swego ten oto podarek.
###### **2Krl 5,16**
 Elizeusz na to rzekł: Na życie Jahwe, któremu służę, nie mogę przyjąć tego daru. Naaman nalegał dalej, żeby Elizeusz przyjął od niego dar, ale ten odmówił.
###### **2Krl 5,17**
 Powiedział tedy Naaman: Jeżeli nie, to zechciej dać twojemu słudze tutejszej ziemi tyle, ile zdołają unieść dwa muły. Sługa twój bowiem nie chce już odtąd składać całopaleń ani ofiar krwawych na cześć innych bogów, jak tylko na cześć Jahwe.
###### **2Krl 5,18**
 Niech Jahwe jednak wybaczy to twojemu słudze: Kiedy mój pan wchodzi do świątyni Rimmona, aby się modlić, i opiera się na moim ramieniu, wtedy i ja jestem zmuszony oddać pokłon; niech więc Jahwe wybaczy twemu słudze, że składa pokłony w świątyni Rimmona!
###### **2Krl 5,19**
 Rzekł na to Elizeusz: Idź w pokoju! Tak więc odszedł Naaman.
###### **2Krl 5,20**
 Nie znajdował się jeszcze zbyt daleko, kiedy Gechazi, sługa Elizeusza, męża Bożego, powiedział sam do siebie: Pan mój oszczędził tego Aramejczyka, nie przyjmując od niego żadnego daru. Na życie Jahwe, pobiegnę za nim i może jeszcze coś dostanę.
###### **2Krl 5,21**
 I ruszył Gechazi w drogę za Naamanem. Kiedy Naaman zauważył, że za nim biegnie, zszedł ze swego wozu, podszedł do niego i zapytał: Czy wszystko w porządku?
###### **2Krl 5,22**
 A Gechazi odpowiedział: Tak, wszystko w porządku. Tylko mój pan przysłał mnie, żeby ci powiedzieć, że oto przyszli do niego z gór efraimskich dwaj młodzi ludzie spośród uczniów prorockich. [Mój pan prosi], żebyś dał im jeden talent srebra i dwa ubrania na zmianę.
###### **2Krl 5,23**
 Naaman odrzekł: Chętnie dam ci dwa talenty [srebra]. I bardzo nalegał, żeby przyjęto to, co dawał. Włożywszy dwa talenty srebra do dwóch worków, dodał do nich dwa ubrania na zmianę i wysłał dwóch swoich służących, żeby zanieśli Gechaziemu [wszystko na miejsce].
###### **2Krl 5,24**
 Kiedy dotarli na wzgórze [Ofel], Gechazi wziął od nich dary i złożył w domu, a potem odesłał z powrotem tych ludzi.
###### **2Krl 5,25**
 Sam zaś poszedł pokazać się swemu panu. Elizeusz zapytał go: Skąd przychodzisz, Gechazi? A on powiedział: Twój sługa nie wychodził nigdzie.
###### **2Krl 5,26**
 Lecz Elizeusz rzekł do niego: Czyż mój duch nie był z tobą, kiedy ów człowiek zszedł z wozu, aby ci wyjść na spotkanie? Czyż jest to odpowiednia chwila, żeby przyjmować od niego srebro, kupować ubrania, drzewa oliwne i winnice, owce i woły, sługi i służebnice?
###### **2Krl 5,27**
 Trąd z Naamana przejdzie na ciebie i na twoje potomstwo po wszystkie czasy. I trąd jak biały śnieg okrywał ciało Gechaziego, kiedy odchodził od Elizeusza.
# 2Krl 5 WUJ
###### **2Krl 5,1**
 Naaman Hetman króla Syryjskiego, był mąż wielki u pana swego i w uczciwości: przezeń bowiem dał Pan wybawienie Syriej: a był mąż mężny i bogaty, ale trędowaty.
###### **2Krl 5,2**
 A z Syriej wyszli byli łotrzykowie i pojmali byli z ziemie Izraelskiej dzieweczkę maluczką, która była na posłudze żony Naamanowej.
###### **2Krl 5,3**
 Która rzekła do paniej swojej: Oby to pan mój był u proroka, który jest w Samariiej: pewnieby go uzdrowił od trędu, który ma.
###### **2Krl 5,4**
 Wszedł tedy Naaman do pana swego, i powiedział mu, rzekąc: Tak a tak mówiła dzieweczka z ziemie Izraelskiej.
###### **2Krl 5,5**
 I rzekł mu król Syryjski: Jedźże a poślę list do króla Izraelskiego. Który gdy jachał i wziął z sobą dziesięć talentów srebra, i sześć tysięcy złotych, i dziesięcioro szat odmiennych,
###### **2Krl 5,6**
 Przyniósł list do króla Izraelskiego, w te słowa: Gdy weźmiesz ten list, wiedz, iżem postał do dębie Naamana sługę mego, abyś go uzdrowił, od trądu jego.
###### **2Krl 5,7**
 A gdy król Izraelski list przeczytał: rozdarł szaty swe, i rzekł: Azam ja jest Bóg, żebych mógł zabić i ożywić, iż ten posłał do mnie, abych uzdrowił człowieka od trądu jego? Przypatrzcie się, a obaczcie, żeć na mię przyczyn szuka.
###### **2Krl 5,8**
 Co gdy usłyszał Elizeusz mąż Boży, to jest, że król Izraelski rozdarł szaty swoję, posłał do niego, mówiąc: Przecześ rozdarł szaty swe? nieck przyjdzie do mnie, a niech wie, że jest prorok w Izraelu.
###### **2Krl 5,9**
 Przyjechał tedy Naaman z końmi i z wozmi i stanął u drzwi domu Elizeuszowego:
###### **2Krl 5,10**
 I wysłał do niego Elizeusz posłańca, mówiąc: Idź, a omyj się siedm kroć w Jordanie, i wróci się zdrowie ciału twemu, i będziesz oczyścion.
###### **2Krl 5,11**
 Rozgniewawszy się Naaman odchodził, mówiąc: Mniemałem że miał wyniść do mnie, a stojąc wzywać interna Pana Boga swego, i dotknąć ręką swą miejsca trędu, a uzdrowić mię.
###### **2Krl 5,12**
 Aza nie lepsze są Atena i Pharphar rzeki Damaszku, niźli wszystkie wody Izraelskie, żebych się w nich omył, a był oczyścion? Gdy tedy się obrócił, i odjeżdżał, gniewając się,
###### **2Krl 5,13**
 Przystąpili do niego słudzy jego, i rzekli mu: Ojcze, chociaćby był wielką rzecz prorok powiedział, saiste miałbyś był uczynić, jako daleko więcej, żeć teraz rzekł: Omyj się, a będziesz oczyścion?
###### **2Krl 5,14**
 Szedł, i omył się w Jordanie siedm kroć, według mowy męża Bożego, i naprawiło się ciało jego, jako ciało dziecięcia maluczkiego, i był oczyściony.
###### **2Krl 5,15**
 A wróciwszy się do męża Bożego ze wszystkim swym pocztem, przyszedł, i stanął przed nim, i rzekł: Prawdziwiem doznał, że niemasz innego Boga na wszystkiej ziemi, jedno tylko w Izraelu. Proszę tedy, abyś wziął błogosławieństwo od sługi twego.
###### **2Krl 5,16**
 Lecz on odpowiedział: Żywie Pan, przed którym stoję, że nie wezmę, A gdy gwałt czynił, zgoła nie zezwolił,
###### **2Krl 5,17**
 I rzekł Naaman: Jako chcesz, ale proszę dozwól mi słudze twemu: że z ziemie wezmę brzemię na dwu mułów: bo sługa twój nie będzie więcej czynił całopalenia ani ofiary cudzym bogom, jedno Panu.
###### **2Krl 5,18**
 A to tylko jest o co masz prosić Pana za sługą twoim, gdy wnidzie pan mój do zboru Remmon, aby się kłaniał, a gdy się on będzie wspierał na ręce mojej: jeśli się pokłonię we zborze Remmon, gdy się on pokłoni na onemże miejscu, aby to Pan ninie słudze twemu odpuścił.
###### **2Krl 5,19**
 Który mu rzekł: Idź w pokoju, A tak odjachał cd niego, obrawszy czas ziemie.
###### **2Krl 5,20**
 I rzekł Giezy sługa męża Bożego: Zfolgował pan mój Naatnanowi temu Syryjczykowi że nie wziął od niego co przyniósł: żywie Pan, że pobieżę za nim i wezmę co od niego,
###### **2Krl 5,21**
 I szedł Giezy za Naamanem, którego gdy on obaczył bieżącego do siebie, skoczył z woza przeciwko niemu, i rzekł: Dobrzeli się wszystko wiedzie?
###### **2Krl 5,22**
 A on rzekł: Dobrze. Pan mój posłał mię do ciebie, rzekąc: Teraz przyszli do mnie dwa młodzieńcy z góry Ephraim z synów prorockich: daj im talent srebra, i szaty odmienne dwojakie.
###### **2Krl 5,23**
 I rzekł Naaman: Lepiej, że weźmiesz dwa talenty. I przymusił go, i zawiązał dwa talenty srebra we dwa wory, i dwojakie szaty, i włożył na dwa pachołki swoje, którzy też nieśli przed nim.
###### **2Krl 5,24**
 A gdy przyszedł już w wieczór, wziął z ręki ich, i schował w domu, a męże odprawił, i poszli.
###### **2Krl 5,25**
 A sam wszedszy stanął przed panem swym, I rzekł Elizeusz: Zkąd idziesz Giezy? A on odpowiedział: Nie chodził nigdzie sługa twój.
###### **2Krl 5,26**
 A on rzekł: Aza serce moje nie było przytomne, kiedy się wrócił człowiek z wożą swego przeciwko tobie? Teraz tedy wziąłeś srebro i wziąłeś szaty, abyś kupił oliwnice i winnice, i owce i woły, i sługi, i służebnice.
###### **2Krl 5,27**
 Ale i trąd Naamanów przylgnie do ciebie i do nasienia twego aż na wieki. I wyszedł od niego trędowaty jako śnieg.
