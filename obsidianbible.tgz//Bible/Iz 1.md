# Iz 1 BT5
###### **Iz 1,1**
 Widzenie Izajasza, syna Amosa, które miał w sprawie Judy i Jerozolimy w czasach królów judzkich: Ozjasza, Jotama, Achaza i Ezechiasza.
###### **Iz 1,2**
 Niebiosa, słuchajcie, ziemio, nadstaw uszu, bo Pan przemawia:«***Wykarmiłem i wychowałem synów, lecz oni wystąpili przeciw Mnie.***
###### **Iz 1,3**
 ***Wół rozpoznaje swego panai osioł żłób swego właściciela; Izrael na niczym się nie zna, lud mój niczego nie rozumie***».
###### **Iz 1,4**
 Biada ci, narodzie grzeszny, ludu obciążony nie-prawością, plemię zbójeckie, dzieci wyrodne!Opuścili Pana, wzgardzili Świętym Izraela, wstecz się odwrócili.
###### **Iz 1,5**
 Gdzie was jeszcze uderzyć, skoro mnożycie przestępstwa?Cała głowa chora, całe serce osłabłe;
###### **Iz 1,6**
 od stopy nogi do szczytu głowy nie ma w nim części nietkniętej:rany i sińce, i opuchnięte pręgi, nie opatrzone ani przewiązane, ni złagodzone oliwą.
###### **Iz 1,7**
 Kraj wasz spustoszony, wasze miasta ogniem spalone, cudzoziemcy tratują wam niwy na waszych oczach; spustoszenie jak po zagładzie Sodomy.
###### **Iz 1,8**
 Córa Syjonu ostała sięjak chatka w winnicy, jak szałas w ogrodzie warzywnym, jak miasto oblężone.
###### **Iz 1,9**
 Gdyby nam Pan Zastępów nie zostawił Reszty,stalibyśmy się jak Sodoma, podobni bylibyśmy Gomorze.
###### **Iz 1,10**
 Słuchajcie słowa Pańskiego, wodzowie sodomscy, daj posłuch prawu naszego Boga, ludu Gomory!
###### **Iz 1,11**
  «***Co Mi po mnóstwie waszych ofiar? –mówi Pan. Syt jestem całopalenia kozłówi łoju tłustych cielców. Krew wołów i baranów, i kozłów Mi obrzydła.***
###### **Iz 1,12**
 ***Gdy przychodzicie, by stanąć przede Mną, kto tego żądał od was, żebyście wydeptywali me dziedzińce?***
###### **Iz 1,13**
 ***Zaprzestańcie składania czczych ofiar! Obrzydłe Mi jest wznoszenie dymu; święta nowiu, szabaty, zwoływanie świętych zebrań. Nie mogę ścierpieć świąt i uroczystości.***
###### **Iz 1,14**
 ***Nienawidzę całą dusząwaszych świąt nowiu i obchodów; stały Mi się ciężarem, sprzykrzyło Mi się je znosić!***
###### **Iz 1,15**
 ***dy wyciągniecie ręce, odwrócę od was me oczy. Choćbyście nawet mnożyli modlitwy, Ja nie wysłucham. Ręce wasze pełne są krwi.***
###### **Iz 1,16**
 ***Obmyjcie się i oczyśćcie!Usuńcie zło uczynków waszychsprzed moich oczu!Przestańcie czynić zło!***
###### **Iz 1,17**
 ***Zaprawiajcie się w dobru! Troszczcie się o sprawiedliwość,wspomagajcie uciśnionego, oddajcie słuszność sierocie, w obronie wdowy stawajcie!***
###### **Iz 1,18**
 ***Chodźcie i spór ze Mną wiedźcie! – mówi Pan. Choćby wasze grzechy były jak szkarłat, jak śnieg wybieleją; choćby były czerwone jak purpura, staną się [białe] jak wełna.***
###### **Iz 1,19**
 ***Jeżeli będziecie ulegli i posłuszni, dóbr ziemskich będziecie zażywać.***
###### **Iz 1,20**
 ***Ale jeśli się zatniecie w oporze, miecz was wytępi***».Albowiem usta Pańskie [to] wyrzekły.
###### **Iz 1,21**
 Jakżeż to miasto wiernestało się nierządnicą?Syjon był pełen rozsądku, sprawiedliwość w nim mieszkała, a teraz – zabójcy!
###### **Iz 1,22**
 Twe srebro żużlem się stało, wino twoje z wodą zmieszane.
###### **Iz 1,23**
 Twoi książęta zbuntowani, wspólnicy złodziei; wszyscy lubią podarki, gonią za wynagrodzeniem. Nie oddają sprawiedliwości sierocie, sprawa wdowy nie dociera do nich.
###### **Iz 1,24**
 Przeto [taka jest] wyrocznia Pana, Boga Zastępów, Wszechmocnego u Izraela:«***Ach! uraduję się kosztem moich wrogów, pomszczę się na mych nieprzyjaciołach.***
###### **Iz 1,25**
 ***Zwrócę rękę moją na ciebie, wypalę do czysta twą rudęi usunę cały twój ołów.***
###### **Iz 1,26**
 ***Przywrócę twoich sędziów jak dawniej, i twoich radnych jak na początku. Wówczas cię nazwą Miastem Sprawiedliwości,Grodem Wiernym***».
###### **Iz 1,27**
 Syjon okupi się poszanowaniem prawa, a jego nawróceni – sprawiedliwością.
###### **Iz 1,28**
 Buntownicy zaś i grzesznicy razem w proch starci, a odstępujący od Pana wyginą.
###### **Iz 1,29**
 Zaiste, wstyd wam będzie z powodu terebintów, które umiłowaliście, zarumienicie się wobec gajów, które obraliście sobie.
###### **Iz 1,30**
 Bo będziecie jak terebintze zwiędłym listowiemi jak ogród, w którym nie ma wody.
###### **Iz 1,31**
 I stanie się mocarz podpałką, a dzieło jego iskrą. Zapłoną razem oboje, a nie będzie komu gasić.
# Iz 1 PAU
###### **Iz 1,1**
 Widzenie Izajasza, syna Amosa, które miał za dni królów judzkich: Ozjasza, Jotama, Achaza i Ezechiasza, o Judzie i Jerozolimie.
###### **Iz 1,2**
 Posłuchaj, niebo! Nakłoń uszu, ziemio, bo PAN przemawia! „Wychowałem synów i wyniosłem wysoko, a oni Mnie zdradzili!
###### **Iz 1,3**
 Wół zna swego gospodarza i osioł - żłób swego pana, a Izrael Mnie nie poznaje, mój lud niczego nie rozumie”.
###### **Iz 1,4**
 Biada narodowi grzesznemu, ludowi obciążonemu winą, potomstwu złoczyńców i synom wyrodnym! Opuścili PANA, wzgardzili Świętym Izraela, odwrócili się od Niego.
###### **Iz 1,5**
 Gdzie was jeszcze chłostać? Mnożycie przestępstwa! Cała głowa już chora, całe serce osłabłe!
###### **Iz 1,6**
 Od stóp do głowy nie ma zdrowego miejsca. Same blizny i sińce, a świeże rany - nieprzewiązane, nieopatrzone i niezwilżone oliwą.
###### **Iz 1,7**
 Wasza ziemia jest pustynią, wasze miasta - spalone w ogniu! Plony pól waszych zjadają obcy na waszych oczach. Spustoszenie jak po zniszczeniu Sodomy.
###### **Iz 1,8**
 Opuszczona więc córka Syjonu jak szałas w winnicy, jak altanka w ogrodzie warzywnym, jak oblężone miasto!
###### **Iz 1,9**
 Gdyby PAN Zastępów nie pozostawił nam reszty, stalibyśmy się jak Sodoma, bylibyśmy podobni do Gomory.
###### **Iz 1,10**
 Słuchajcie słów PANA, przywódcy Sodomy! Otwórz się na naukę naszego Boga, o, ludu Gomory!
###### **Iz 1,11**
 „Po cóż Mi wasze niezliczone ofiary? - mówi PAN. Dość mam całopaleń z baranów i tłuszczu tuczonych cielców! Nie mam już upodobania we krwi wołów, jagniąt i kozłów.
###### **Iz 1,12**
 Gdy przychodzicie przed moje oblicze, czy ktoś od was wymaga, żebyście wydeptywali moje dziedzińce?
###### **Iz 1,13**
 Nie przynoście Mi więcej ofiar nieszczerych. Wstręt budzi we Mnie wasze kadzidło, nie znoszę świąt nowiu, szabatu, zwoływania zgromadzeń, uroczystych obrzędów naznaczonych grzechem.
###### **Iz 1,14**
 Dni nowiu i świąt waszych na wskroś już nie cierpię, stały Mi się ciężarem, już nie mogę ich znieść.
###### **Iz 1,15**
 Gdy wyciągniecie do Mnie swe ręce, zasłonię przed wami moje oczy, choćbyście mnożyli modły, Ja ich nie wysłucham. Ręce wasze są pełne krwi!
###### **Iz 1,16**
 Obmyjcie się! Oczyśćcie! Usuńcie sprzed mojego oblicza zło waszych niecnych czynów. Przestańcie czynić źle!
###### **Iz 1,17**
 Uczcie się czynić dobrze! Szukajcie tego, co prawe! Poskramiajcie ciemięzcę, brońcie prawa sieroty, stawajcie w obronie wdowy!
###### **Iz 1,18**
 Chodźcie, rozsądźmy - mówi PAN. Choćby wasze grzechy były jak szkarłat - nad śnieg wybieleją. Choćby były czerwone jak purpura - staną się białe jak wełna.
###### **Iz 1,19**
 Jeżeli naprawdę posłuchacie, będziecie zażywali dóbr ziemi.
###### **Iz 1,20**
 Lecz jeśli będziecie trwać w uporze - miecz was wytępi”. Tak orzekły usta PANA!
###### **Iz 1,21**
 Ach, jakąż nierządnicą stał się Gród Wierności! Syjon był pełen prawości, siedzibą sprawiedliwości, a teraz są w nim mordercy.
###### **Iz 1,22**
 Twoje srebro zamieniło się w żużel, twoje wino zmieszane z wodą.
###### **Iz 1,23**
 Przywódcy twoi to buntownicy i wspólnicy złodziei! Każdemu miłe przekupstwo i pogoń za podarkami. Nie bronią prawa sieroty, głusi są na skargi wdowy.
###### **Iz 1,24**
 Dlatego tak mówi PAN, BÓG Zastępów, Mocarz Izraela: „Biada moim wrogom! Dokonam na nich pomsty, odpłacę moim nieprzyjaciołom.
###### **Iz 1,25**
 I zwrócę moją rękę przeciwko tobie, wytopię w tyglu twój żużel i usunę wszelki ołów!
###### **Iz 1,26**
 Przywrócę twoich sędziów jak dawniej, i twoich doradców - jak na początku. Znowu cię nazwą Miastem Sprawiedliwości, Grodem Wierności”.
###### **Iz 1,27**
 Syjon będzie odkupiony dzięki prawości, a ci, którzy się w nim nawrócą - przez sprawiedliwość!
###### **Iz 1,28**
 Odstępcy zostaną zgładzeni wraz z grzesznymi, zginą ci, którzy opuszczają PANA.
###### **Iz 1,29**
 Będziecie się wstydzili terebintów, którymi się rozkoszujecie. Zarumienicie się z powodu gajów, które sobie upodobaliście.
###### **Iz 1,30**
 Bo sami staniecie się jak terebint, którego liście więdną, i jak gaj bez wody.
###### **Iz 1,31**
 Siłacz stanie się jak paździerz, a jego dzieło jak iskra. Spłoną razem i nikt nie zdoła ich zagasić.
# Iz 1 BP
###### **Iz 1,1**
 Widzenie Izajasza, syna Amoca, dotyczące Judy i Jeruzalem, które miał za dni królów judzkich: Ozjasza, Jotama, Achaza i Ezechiasza.
###### **Iz 1,2**
 Słuchajcie, niebiosa, nakłoń uszu, ziemio, bo Jahwe przemawia! - Jam synów wychował i wyniósł wysoko, lecz ci mnie zdradzili.
###### **Iz 1,3**
 Zna wół gospodarza swojego a osioł żłób swego pana, lecz Izrael znać [mnie] nie chce, mój lud nie nabiera rozumu.
###### **Iz 1,4**
 Biada narodowi grzesznemu, ludowi obciążonemu winą, potomstwu złoczyńców i synom wyrodnym! Opuścili Jahwe, wzgardzili Świętym [Bogiem] Izraela, wstecz się odwrócili.
###### **Iz 1,5**
 Gdzie mam was jeszcze chłostać, [skoro] wciąż trwacie w odstępstwie? Cała głowa jest chora, całe serce niemocą objęte.
###### **Iz 1,6**
 Nie ma w nim od stóp do głowy miejsca zupełnie zdrowego - same rany i sińce! A blizny jeszcze świeże nie są opatrzone ani przewiązane, ani zmiękczone oliwą.
###### **Iz 1,7**
 Ziemia wasza - pustynią, miasta ogniem spalone, a włości na oczach waszych objadają wrogowie (spustoszenie - jak przy zniszczeniu Sodomy).
###### **Iz 1,8**
 Opuszczona jest Córa Syjonu jak szałas w winnicy, jak altana na polu warzywnym, jak miasto wokół oblężone.
###### **Iz 1,9**
 I gdyby nam Jahwe Zastępów nie ocalił Reszty, losem Sodomy stałby się nasz los, do Gomory bylibyśmy podobni.
###### **Iz 1,10**
 Słuchajcie słów Jahwe, książęta Sodomy! Nakłoń uszu, ludu Gomory, by słuchać praw Boga naszego! -
###### **Iz 1,11**
 Cóż mi po mnóstwie waszych ofiar krwawych? - mówi Jahwe. Syt jestem całopaleń z baranów i tłuszczu cielców tuczonych. Nie mam [już] upodobania we krwi wołów, jagniąt i kozłów.
###### **Iz 1,12**
 Gdy się przede mną zjawiacie - któż tego od was wymaga, byście deptali po moich dziedzińcach? -
###### **Iz 1,13**
 nie przynoście mi już obiat kłamliwych. Dym kadzielny wzbudza we mnie odrazę. Nowiów, szabatów, zwoływania zebrań, obłudy, zgromadzeń świątecznych nie mogę znieść [dłużej].
###### **Iz 1,14**
 Dni nowiu, świąt waszych [obchody] znienawidziłem zupełnie; stały się dla mnie ciężarem, znużyło mnie ich znoszenie.
###### **Iz 1,15**
 Gdy dłonie swe do mnie wyciągać będziecie, zasłonię oczy przed wami, a chociaż mnożyć będziecie modły, Ja wcale słuchać nie będę. Krwią ociekają wasze ręce!
###### **Iz 1,16**
 Obmyjcie się i oczyśćcie! Usuńcie sprzed oczu moich zło waszych bezecnych postępków! Przestańcie czynić nieprawość!
###### **Iz 1,17**
 Uczcie się pełnić dobre uczynki, szukajcie tego, co sprawiedliwe! Poskromcie ciemięzcę; Prawo przyznajcie sierotom i wdowy bierzcie w obronę! -
###### **Iz 1,18**
 Chodźcie, rozsądźmy - mówi Jahwe. Choć grzechy wasze są niby szkarłat, jednak jak śnieg wybieleją; choć są jak purpura czerwone, jak wełna staną się [białe].
###### **Iz 1,19**
 Jeśli zechcecie dać posłuch, dóbr ziemi zażywać będziecie.
###### **Iz 1,20**
 Lecz jeśli będziecie oporni i krnąbrni, zginiecie niechybnie od miecza. - Zaiste, [to] usta Jahwe wyrzekły.
###### **Iz 1,21**
 Jakże to wierna [niegdyś] stolica stała się nierządnicą! Syjon był pełen prawości, sprawiedliwość w nim przebywała, a teraz - mordercy.
###### **Iz 1,22**
 Twe srebro zmieniło się w żużel, twe wino - z wodą zmieszane.
###### **Iz 1,23**
 Twoi książęta - to buntownicy i sprzymierzeńcy złodziei. Każdy lubuje się w darach [przekupnych] i goni za podarkami. Sierocie praw nie przyznają, a skarga wdowy nie dociera do nich.
###### **Iz 1,24**
 Przeto [tak] mówi Pan, Jahwe Zastępów, Mocarny [Bóg] Izraela: - Biada! Dokonam pomsty nad mymi wrogami, nieprzyjaciołom moim odpłacę!
###### **Iz 1,25**
 Dłoń swą przeciw tobie obrócę, twój żużel w tyglu wypalę i wszelki twój ołów usunę.
###### **Iz 1,26**
 Przywrócę twych sędziów, jak było pierwotnie, i twych doradców, jak było w zaraniu. Potem nazwą cię znowu "Grodem Sprawiedliwym", "Miastem Wierności".
###### **Iz 1,27**
 Syjon przez prawość będzie odkupiony, a nawróceni jego - poprzez sprawiedliwość.
###### **Iz 1,28**
 Zmiażdżeni będą razem odstępcy i grzesznicy, zginą ci, którzy opuścili Jahwe.
###### **Iz 1,29**
 Oto powstydzicie się terebintów, przedmiotu swoich pożądań; rumienić się będziecie na myśl o ogrodach, któreście tak bardzo cenili.
###### **Iz 1,30**
 Staniecie się bowiem [sami] jako terebinty, których liście więdną, i jako ogród pozbawiony wody.
###### **Iz 1,31**
 Mąż potężny stanie się jakby [zeschła] trawa, a jego dzieło jak iskra, i spłoną oboje pospołu, a nie będzie nikogo, kto by ugasił.
# Iz 1 BR
###### **Iz 1,1**
 Izajasz, syn Amosa miał widzenie dotyczące Judy i Jerozolimy za czasów panowania królów judzkich Ozjasza, Jotama, Achaza i Ezechiasza.
###### **Iz 1,2**
 Posłuchajcie niebiosa, ziemio nadstaw uszu, bo oto przemawia Pan: Wykarmiłem twoich synów i pozwoliłem im wzrastać, a oni przeciwko Mnie wystąpili.
###### **Iz 1,3**
 Wół rozpoznaje własnego pana i osioł żłób swego właściciela. Tylko Izrael nie uznaje nikogo, niczego mój lud nie rozumie.
###### **Iz 1,4**
 Ach ty narodzie grzeszny, ludu obciążony winami, plemię pełne złości, przewrotne potomstwo! Wszyscy oni odeszli od Pana, wzgardzili Świętym Izraela i odwrócili się od Niego.
###### **Iz 1,5**
 Gdzież muszę wam zadać cios kolejny, bo nadal mnożycie wasze zdrady? Chora jest cała wasza głowa, wyczerpane zupełnie wasze serce.
###### **Iz 1,6**
 Caliście zepsuci, od stóp aż do głowy pokrywają was opuchnięcia, sińce i otwarte rany; nic nie opatrzone, nie obwiązane niczym, nie zwilżone oliwą.
###### **Iz 1,7**
 Spustoszony cały wasz kraj, wszystkie miasta spalone ziemię waszą na oczach waszych łupią wrogowie. Wszystko wygląda tak, jak kiedyś, po swym nieszczęściu, Sodoma
###### **Iz 1,8**
 Tylko córka Syjonu została jak skromna chatka w winnicy, jak szałas w ogrodzie warzywnym, albo jak oblężone miasto.
###### **Iz 1,9**
 Gdyby Pan Zastępów nie ocalił kilku, bylibyśmy wszyscy jak Sodoma stalibyśmy się do Gomory podobni.
###### **Iz 1,10**
 Posłuchajcie tego, co mówi Pan, o wy przywódcy Sodomy! Weź sobie do serca prawo naszego Boga o ty ludu Gomory!
###### **Iz 1,11**
 Po cóż mi wasze niezliczone ofiary: mówi Pan. Przesyt czuję od całopaleń kozłów i od obfitości tłuszczu upasionych wołów. Odrazą Mnie napełnia krew cielców i baranów.
###### **Iz 1,12**
 Kiedy przyjdziecie, żeby Mnie się pokazać to czy zażąda ktoś od was, by wydeptywać me progi?
###### **Iz 1,13**
 Przestańcie mi już przynosić te niepotrzebne dary, gdyż ich dym napełnia Mnie odrazą. Święto nowiu księżyca, szabaty, zgromadzenia: nie znoszę już więcej tych świąt i uroczystości.
###### **Iz 1,14**
 Wasze nowie miesiąca i pielgrzymowania, znienawidziłem całą moją duszą. Są mi prawdziwym ciężarem i już nie mam siły ich znosić.
###### **Iz 1,15**
 Gdy wyciągacie do Mnie swe ręce, Ja odwracam od was me oczy. Mnożyliście coraz bardziej swe modły, lecz Ja was nie słuchałem, bo wasze ręce całe krwią zbrukane.
###### **Iz 1,16**
 Obmyjcie się więc, oczyśćcie się! Usuńcie waszą złość sprzed mego oblicza, przestańcie nareszcie grzeszyć!
###### **Iz 1,17**
 Starajcie się dobro czynić, szukajcie tego, co prawe! Spieszcie z pomocą uciśnionym bądźcie sprawiedliwi dla sierot, bierzcie w obronę wdowy!
###### **Iz 1,18**
 Przyjdźcie więc, by pospierać się ze Mną - mówi Pan. Jeśli grzechy wasze będą jak szkarłat, ponad śnieg wybieleją; jeśli będą jak purpura czerwone, staną się bielsze od wełny.
###### **Iz 1,19**
 Jeżeli gotowi jesteście słuchać, będziecie się żywić owocami ziemi.
###### **Iz 1,20**
 Lecz jeśli z uporem będziecie się buntować, miecz pożre was wszystkich.
###### **Iz 1,21**
 A czemuż stało się nierządnicą to miasto ongiś tak wierne? Góra Syjon tak kiedyś rozsądna, kiedyś miejscem sprawiedliwości, Jest teraz zamieszkała przez samych morderców.
###### **Iz 1,22**
 Twoje srebra na złom zamieniono a wino pomieszano z wodą.
###### **Iz 1,23**
 Zbuntowali się twoi książęta i stali się wspólnikami złodziei. Wszystkich ogarnęła żądza posiadania każdy pragnie jakiegoś podarku. Nie uznają prawa sieroty, głuchymi się stali na wołanie wdowy.
###### **Iz 1,24**
 Taki więc wydał wyrok Pan Zastępów i Bóg Izraela potężny: Biada moim wrogom, bo teraz się zemszczę, użyję sobie na nieprzyjaciołach moich.
###### **Iz 1,25**
 I skieruję przeciw tobie mą rękę, i roztopię cię jak złom w płomieniach i oddzielę od ciebie ołów.
###### **Iz 1,26**
 I ześlę ci znowu sędziów jak kiedyś, i dam ci jak ongiś doradców. I znowu będą cię nazywać Miastem - Sprawiedliwością i Twierdzą wierności.
###### **Iz 1,27**
 I uratuje się Syjon swoim szacunkiem dla prawa, jego nawróceni - dzięki sprawiedliwości.
###### **Iz 1,28**
 Zbuntowani i grzesznicy zostaną skruszeni i zginą ci wszyscy, co odeszli od Pana.
###### **Iz 1,29**
 I wstyd was ogarnie z powodu terebintów, którymi się rozkoszujecie; czerwienić się będziecie z powodu ogrodów, które was tak oczarowują.
###### **Iz 1,30**
 Sami bowiem będziecie niczym terebinty, o liściach bardzo już uwiędłych albo jak ogród pozbawiony wody.
###### **Iz 1,31**
 Wielcy tego świata staną się podpałką a ich dzieła - zaledwie iskierką. Spłoną razem z dziełami swoimi i nie zdoła ich nikt uratować od ognia.
# Iz 1 WUJ
###### **Iz 1,1**
 Widzenie Izajasza syna Amos, które widział nad Judą, i Jeruzalem za dni Oziasza, Joathana, Achasa, i Ezechiasza królów Judzkich.
###### **Iz 1,2**
 Słuchajcie niebiosa, a weźmi w uszy ziemio, abowiem Pan mówił. Wychowałem syny i wywyższyłem: a oni mię wzgardzili.
###### **Iz 1,3**
 Poznał wół Pana swego, i osieł żłób Pana swego: a Izrael mię nie poznał, a lud mój nie zrozumiał.
###### **Iz 1,4**
 Biada narodowi grzesznemu, ludowi nieprawością obciążonemu, nasieniu złemu, synom złośliwym: opuścili Pana, bluźnili świętego Izraelowego, odwrócili się wstecz.
###### **Iz 1,5**
 Na czemże was mam więcej karać, którzy przyczyniacie przestępstwa? każda głowa chora, a każde serce żałosne.
###### **Iz 1,6**
 Od stopy nogi aż do wierzchu głowy nie masz w nim zdrowia: rana i siność i spuchły raz, nie jest zawiązany, ani lekarstwem opatrzony, ani oliwą zmiękczony.
###### **Iz 1,7**
 Ziemia wasza spustoszona, miasta wasze ogniem popalone: krainę waszę przed wami cudzoziemcy pożerają, i spustoszeje jako w zburzeniu nieprzyjacielskiem.
###### **Iz 1,8**
 I zostanie się córka Siońska jako chłodnik w winnicy, a jako budka w ogrodzie ogórkowym, i jako miasta, które burzą.
###### **Iz 1,9**
 By nam był Pan zastępów nie zostawił nasienia: bylibychmy jako Sodoma stalibyśmy się Gomorze podobni.
###### **Iz 1,10**
 Słuchajcie słowa Pańskiego książęta Sodomskie, weźcie w uszy zakon Boga naszego ludu Gomorski.
###### **Iz 1,11**
 Cóż mi po mnóstwie ofiar waszych, mówi Pan? Pełenem całopalenia baranów, i łoju tłustego bydła, i krwie cielców, i jagniąt, i kozłów nie chciałem.
###### **Iz 1,12**
 Gdyście przychodzili przed oczy moje, kto tego szukał z rąk waszych, abyście chodzili po sieniach moich?
###### **Iz 1,13**
 Nie ofiarujcież więcej ofiary próżno: kadzenie jest mi obrzydłością. Nowiu miesiąca, i Szabbathu, i innych świąt, nie ścierpię, nieprawe są zbory wasze:
###### **Iz 1,14**
 Nowi waszych, i uroczystych świąt waszych nienawidzi dusza moja, stały mi się przykre, zmordowałem się znosząc.
###### **Iz 1,15**
 A gdy wyciągniecie ręce wasze, odwrócę oczy moje od was: a gdy rozmnożycie modlitwę, nie wysłucham: bo ręce wasze pełne są krwie.
###### **Iz 1,16**
 Omyjcie się, czystymi bądźcie, odejmcie złość myśli waszych od oczu moich: przestańcie źle czynić:
###### **Iz 1,17**
 Uczcie się dobrze czynić: szukajcie sądu, wspomagajcie uciśnionego, czyńcie sprawiedliwość sierocie, brońcie wdowy.
###### **Iz 1,18**
 A przyjdźcie, a strofujcie mię, mówi Pan: Choćby były grzechy wasze jako szarłat, jako śnieg wybieleją: i choćby były czerwone jako karmazyn, będą białe jako wełna.
###### **Iz 1,19**
 Jeśli zechcecie, a posłuchacie mię, dóbr ziemie pożywać będziecie.
###### **Iz 1,20**
 Ale jeśli nie zechcecie, a mnie ku gniewowi przywiedziecie: miecz was pożrze, bo usta Pańskie mówiły.
###### **Iz 1,21**
 Jako się stało nierządnicą miasto wierne, pełne sądu? sprawiedliwość mieszkała w niem, a teraz mężobójce.
###### **Iz 1,22**
 Srebro twoje obróciło się w zużelicę: wino twoje zmieszało się z wodą.
###### **Iz 1,23**
 Książęta twoje niewierne, towarzysze złodziejscy: wszyscy miłują dary, a idą za nagrodą. Sierocie nie czynią sprawiedliwości: a sprawa wdowia nie przychodzi przed nie.
###### **Iz 1,24**
 Przeto mówi Pan Bóg zastępów mocny Izraelski: Ach pocieszę się nad nieprzyjaciółmi swemi, a pomszczę się nad przeciwniki memi.
###### **Iz 1,25**
 I obrócę rękę swoję na cię, i wypalę do czysta zużelicę twoję, i odpędzę wszystkę cenę twoję.
###### **Iz 1,26**
 I przywrócę sędzię twoje jako przedtem byli, a rajcę twoje jako z starodawna: potem będziesz nazwano miastem sprawiedliwego, miastem wiernem.
###### **Iz 1,27**
 Sion w sądzie odkupione będzie, i przywiodą je zaś w sprawiedliwości.
###### **Iz 1,28**
 A zetrze złośniki i grzeszniki społem: a którzy Pana opuścili, będą wyniszczeni.
###### **Iz 1,29**
 Bo będą pohańbieni od bałwanów, którym ofiarowali: i będziecie się wstydzić za ogrody, któreście byli obrali:
###### **Iz 1,30**
 Gdy będziecie jako dąb, którego liście opadło, i jako ogród bez wody.
###### **Iz 1,31**
 I będzie moc wasza, jako perz z zgrzebi, a dzieło wasze, jako iskra: i zapali się oboje pospołu, a nie będzie ktoby zagasił.
