# Hi 6 BT5
###### **Hi 6,1**
 Wówczas zabrał głos Hiob i rzekł:
###### **Hi 6,2**
 «***Gdyby zważono dokładnie mój ból, a moje biedy razem byłyby na szali!***
###### **Hi 6,3**
 ***Cięższe są one teraz niż piasek morski, stąd nierozważne me słowa.***
###### **Hi 6,4**
 ***Bo tkwią we mnie strzały Wszechmogącego, których jady wchłania moja dusza, strach przed Bogiem na mnie naciera.***
###### **Hi 6,5**
 ***Czy onager ryczy na murawie lub mruczy wół, gdy ma paszę?***
###### **Hi 6,6**
 ***Czy miła potrawa bez soli, a sok malwy czy w smaku przyjemny?***
###### **Hi 6,7**
 ***Moja dusza nie ważyła się tego dotknąć, a to się stało wstrętnym mym pokarmem.***
###### **Hi 6,8**
 ***Któż da mi to, o co proszę? Niech Bóg mi da to, czego się spodziewam!***
###### **Hi 6,9**
 ***Oby Bóg zechciał mnie zmiażdżyć, wyciągnąć rękę i przeciąć pasmo mych dni.***
###### **Hi 6,10**
 ***Przez to już doznałbym ulgi i rozradował w bezlitosnej udręce, że nie wzgardziłem słowami Świętego.***
###### **Hi 6,11**
 ***Co siłą jest dla mnie, by przetrwać? Jakiż mój kres, bym wytrwał cierpliwie?***
###### **Hi 6,12**
 ***Czy moja siła z kamienia? Czy ja mam ciało ze spiżu?***
###### **Hi 6,13**
 ***Zaiste nie ma dla mnie pomocy, zabrano ode mnie zaradność, daleki ode mnie ratunek.***
###### **Hi 6,14**
 ***Zrozpaczonemu potrzeba pomocy od bliźnich, bo porzuci on cześć Wszechmocnego.***
###### **Hi 6,15**
 ***Bracia moi zawiedli jak wody potoku, jak łożyska potoków znikają;***
###### **Hi 6,16**
 ***od lodu są one zmącone, śnieg się nad nimi rozpuścił.***
###### **Hi 6,17**
 ***W czasie letniego upału wysychają, od gorąca znikają ze swych łożysk.***
###### **Hi 6,18**
 ***Ze swych dróg karawany zbaczają, w pustyni zagłębią się, zginą:***
###### **Hi 6,19**
 ***podróżni z Temy wzrok natężają, mają w nich nadzieję wędrowcy sabejscy.***
###### **Hi 6,20**
 ***Wstyd im, że mieli już pewność, doszli do nich i są zmieszani.***
###### **Hi 6,21**
 ***Tym wy jesteście dla mnie, przeraża was moje nieszczęście.***
###### **Hi 6,22**
 ***Czyż mówiłem: Dajcie mi coś, wykupcie mnie swoim bogactwem?***
###### **Hi 6,23**
 ***Uwolnijcie z ręki ciemięzcy, wykupcie mnie od okrutników?***
###### **Hi 6,24**
 ***Wskazania dajcie – zamilknę, a w czym zbłądziłem, pouczcie.***
###### **Hi 6,25**
 ***Ile mocy w słowach szczerych! A cóż poprawią wasze sądy?***
###### **Hi 6,26**
 ***Czyż chcecie ganić same słowa – mowy zrozpaczonego na wiatr [rzucane]?***
###### **Hi 6,27**
 ***A wy sierotę gubicie, [los] byście rzucali i swoim kupczyli przyjacielem!***
###### **Hi 6,28**
 ***A teraz popatrzcie na mnie: a wobec was nie skłamię.***
###### **Hi 6,29**
 ***Nawróćcie się, niech zło zaniknie, nawróćcie się: jeszcze [trwa] moja prawość.***
###### **Hi 6,30**
 ***Czyż język mój jest występny? Czy podniebienie grzechu nie rozezna?***
# Hi 6 PAU
###### **Hi 6,1**
 Hiob odpowiedział tymi słowami:
###### **Hi 6,2**
 „Gdyby moją tragedię można było zważyć i położyć na szali razem z mym nieszczęściem,
###### **Hi 6,3**
 byłyby na pewno cięższe od piasku morskiego. Dlatego moje słowa nie znają umiaru.
###### **Hi 6,4**
 Bo utkwiły we mnie strzały Wszechmocnego, mój duch pije ich truciznę, przygniata mnie lęk zesłany przez Boga.
###### **Hi 6,5**
 Czy dziki osioł ryczy na pastwisku, a wół pomrukuje, kiedy ma paszę?
###### **Hi 6,6**
 Czyż można jeść pokarm bez soli albo czy smakuje samo białko jajka?
###### **Hi 6,7**
 Brzydzę się nawet tego dotknąć, a stało się to dla mnie pokarmem.
###### **Hi 6,8**
 Oby została spełniona moja prośba i Bóg dał mi to, czego pragnę!
###### **Hi 6,9**
 Niech mnie zniszczy, niech podniesie rękę i mnie zgładzi!
###### **Hi 6,10**
 Tylko ta pozostanie mi pociecha i ucieszę się w okrutnym bólu, że nie zaparłem się słów Świętego.
###### **Hi 6,11**
 Skąd mam brać siłę, żeby przetrwać? Jak długo jeszcze będzie się ciągnąć moje życie?
###### **Hi 6,12**
 Czyż jestem twardy jak kamień albo czy moje ciało jest z brązu?
###### **Hi 6,13**
 Czyż nie ma już dla mnie ratunku i zostałem pozbawiony pomocy?
###### **Hi 6,14**
 Kto bliźniemu odmawia współczucia, ten wyzbywa się bojaźni Wszechmocnego.
###### **Hi 6,15**
 Bracia moi zwodzą mnie jak potok, jak wody przepływające w korytach rzek;
###### **Hi 6,16**
 mętne od stłoczonego w nich lodu, zmącone topniejącym w nich śniegiem.
###### **Hi 6,17**
 Latem zanikają i zostawiają puste koryta.
###### **Hi 6,18**
 Karawany schodzą do nich ze swych szlaków, idą na bezdroża i tam przepadają.
###### **Hi 6,19**
 Karawany z Temy wypatrują strumieni, zdążają do nich wędrowcy z Saby.
###### **Hi 6,20**
 Lecz ich nadzieje zawodzą: docierają wreszcie do celu i stają przerażeni.
###### **Hi 6,21**
 Tak samo wy zachowujecie się wobec mnie. Zobaczyliście spustoszenie i lęk was ogarnął.
###### **Hi 6,22**
 Czy mówiłem: «Pomóżcie mi, użyczcie mi siły,
###### **Hi 6,23**
 uwolnijcie z ręki wroga, wyzwólcie mnie od ciemięzcy?».
###### **Hi 6,24**
 Pouczcie mnie, a zamilknę. Powiedzcie, w czym pobłądziłem!
###### **Hi 6,25**
 Czy szczere słowa mają być w pogardzie i czy to ma na celu wasze upomnienie?
###### **Hi 6,26**
 Czyż macie zamiar potępić moją mowę? Czy słowa zrozpaczonego są wiatrem?
###### **Hi 6,27**
 Wy nawet o sierotę los rzucacie i targujecie się o przyjaciela.
###### **Hi 6,28**
 Teraz jednak spójrzcie na mnie, na pewno wobec was nie skłamię.
###### **Hi 6,29**
 Zwróćcie się, proszę, nie stanie się nic złego, zwróćcie się do mnie, słuszność nadal jest po mojej stronie.
###### **Hi 6,30**
 Czy mam na swym języku nieprawość? Czyż moje podniebienie zła nie wyczuwa?
# Hi 6 BP
###### **Hi 6,1**
 Job zabrał głos i tak odpowiedział:
###### **Hi 6,2**
 O gdyby można zważyć moją zgryzotę i razem z nią położyć na szali moje cierpienie,
###### **Hi 6,3**
 byłyby one cięższe od piasku morskiego. Oto dlaczego plącze się moja mowa.
###### **Hi 6,4**
 Strzały Najwyższego przeszywają mnie, dusza moja wchłania ich truciznę, upiory Boże uderzyły we mnie.
###### **Hi 6,5**
 Czy dziki osioł ryczy na trawie zielonej albo czy porykuje wół nad paszą swoją?
###### **Hi 6,6**
 Czy można jeść mdły pokarm bez soli albo czy ma jakiś smak białko jajka?
###### **Hi 6,7**
 Dusza moja wzdryga się przed dotknięciem tego, wszystko to jest dla mnie jak spleśniały chleb.
###### **Hi 6,8**
 Ach, kiedyż się spełni to, o co proszę, kiedy Bóg da mi to, czego się spodziewam?
###### **Hi 6,9**
 Oby Bóg zechciał mnie uśmiercić, oby wyciągnął swą rękę i przeciął me życie!
###### **Hi 6,10**
 Będę miał przynajmniej tę pociechę i cieszyć się będę, choć jęczę z bólu, że nie łamałem przykazań Świętego.
###### **Hi 6,11**
 Ileż mam jeszcze siły, aby wytrwać, i jakiż kres mnie czeka, jeśli to przeżyję?
###### **Hi 6,12**
 Czy siła moja jest z kamienia albo ciało moje ze spiżu?
###### **Hi 6,13**
 Moją ostatnią pociechą jest nicość, a wybawienie moje dalekie ode mnie.
###### **Hi 6,14**
 Kto przyjacielowi współczucia odmawia, ten odrzuca od siebie bojaźń Bożą.
###### **Hi 6,15**
 Bracia moi oszukali mnie jak potok, jak koryto rzek, które przepływają:
###### **Hi 6,16**
 mętne od płynącego w nich lodu, wezbrane od topniejącego śniegu.
###### **Hi 6,17**
 W czasie posuchy zanikają, a podczas upałów koryto ich wysycha.
###### **Hi 6,18**
 Ku nim karawany zbaczają z dróg swoich, wstępują na pustynię i tam giną.
###### **Hi 6,19**
 Wypatrują ich karawany z Tema, podróżni z Saby w nich nadzieję pokładają.
###### **Hi 6,20**
 Zawiedli się w swoim oczekiwaniu, przybyli nad ich brzegi i stanęli w osłupieniu.
###### **Hi 6,21**
 Takimi wy staliście się teraz dla mnie, ujrzeliście moje nieszczęście i przeraziliście się.
###### **Hi 6,22**
 Czyż wam powiedziałem: "Dajcie mi, podarujcie wasze majętności"?
###### **Hi 6,23**
 Albo: "Uwolnijcie z ręki wroga, wybawcie mnie z ręki ciemięzcy"?
###### **Hi 6,24**
 Pouczcie mnie, a zamilknę, albo wskażcie mi, w czym pobłądziłem.
###### **Hi 6,25**
 Jakąż moc mają słowa prawdziwe, a wasze strofowanie cóż ma na celu?
###### **Hi 6,26**
 Czy zamierzacie ganić moją mowę, uznawać za wiatr słowa zrozpaczonego?
###### **Hi 6,27**
 O tak, wy chcecie potępić sierotę, zaprzedać swego przyjaciela.
###### **Hi 6,28**
 A teraz zechciejcie spojrzeć na mnie, czy kłamałbym wam w oczy?
###### **Hi 6,29**
 Wróćcie się, proszę was, niech nie będzie już nieprawości. Przyjdź także ty, który nosisz w sobie mą niewinność.
###### **Hi 6,30**
 Czy jest fałsz na języku moim? Czy podniebienie moje nie rozeznaje nieprawości?
# Hi 6 BR
###### **Hi 6,1**
 A Hiob tak odpowiedział:
###### **Hi 6,2**
 Ach, gdyby ktoś mógł zważyć ciężar mego bólu i zmieścić na wadze wielkość moich cierpień!
###### **Hi 6,3**
 Byłyby one cięższe od morskiego piasku. I stąd się biorą słowa mego narzekania.
###### **Hi 6,4**
 Godzą we mnie strzały Najwyższego, a ich jad przenika moją duszę i groźby Boga wprawiają mnie w trwogę.
###### **Hi 6,5**
 Czy dziki osioł ryczy, gdy ma trawę, albo wół, kiedy ma żłób pełny?
###### **Hi 6,6**
 Czyż zwykło się spożywać nieosolone potrawy? Albo czy ma jakiś smak białko bez soli?
###### **Hi 6,7**
 Rzeczy takich nawet dotknąć nie chcę, bo są dla mnie jak chleb nieczysty.
###### **Hi 6,8**
 Ale czy stanie się to, czego pragnę? Czy Bóg raczy spełnić me nadzieje?
###### **Hi 6,9**
 Niech więc Bóg zechce mnie zmiażdżyć, wyciągnąć swoje ręce i przeciąć me życie.
###### **Hi 6,10**
 Sprawiłby mi ulgę, pocieszyłby w udrękach, których mi nie szczędzi, ja bym zaś wiedział, że nie wzgardziłem słowami Świętego.
###### **Hi 6,11**
 Bo czy wystarczy mi sił, żeby wszystko wytrzymać? Czy zachowam cierpliwość do samego końca?
###### **Hi 6,12**
 Czy jestem twardy jak skała? Czy moje ciało ze spiżu?
###### **Hi 6,13**
 Czy nikt mi już nie pomoże? Czy nie ma dla mnie żadnego ratunku?
###### **Hi 6,14**
 Ci, co zwątpili, idą do przyjaciół, nawet kiedy przestaną bać się Wszechmocnego.
###### **Hi 6,15**
 Moi bracia są jak znikający potok: odchodzą ode mnie jak płynące wody,
###### **Hi 6,16**
 w które lód się przemienia, gdy warstwą śniegu zostanie pokryty.
###### **Hi 6,17**
 Gdy nadejdzie susza, zanika zupełnie, wysycha w swym łożysku za dni upalnych.
###### **Hi 6,18**
 Poszukując go, z drogi zbaczają wędrowcy, zapuszczają się na pustynię i giną.
###### **Hi 6,19**
 Wypatrują go podróżni z Temy, liczą na niego kupcy z Saby.
###### **Hi 6,20**
 Oszukani w swoich rachubach, docierają na miejsce i są zawiedzeni.
###### **Hi 6,21**
 I wy jesteście dla mnie takimi, na widok mój napełniacie się odrazą.
###### **Hi 6,22**
 A czyż prosiłem, byście mi coś dali lub okup za mnie złożyli ze swych bogactw?
###### **Hi 6,23**
 Żebyście mnie bronili przed atakami ciemięzcy, wykupili z rąk tyranów?
###### **Hi 6,24**
 Pouczcie mnie - to zamilknę, i powiedzcie mi, w czym błądzę.
###### **Hi 6,25**
 Wiele można zdziałać przez mądre słowa, a wasze łajanie na nic się nie przyda.
###### **Hi 6,26**
 Chcecie mnie potępiać za same słowa? Za mowę, która jakby na wiatr rzuca ten, co stracił nadzieję?
###### **Hi 6,27**
 Na pastwę losu sierotę rzucacie, przyjacielem kupczycie za lichą zapłatę.
###### **Hi 6,28**
 Popatrzcie na mnie przychylniejszym okiem. Ja przecież nie kłamię wam w żywe oczy.
###### **Hi 6,29**
 Przestańcie już, zła zaniechajcie, uwierzcie, że moje ścieżki są proste.
###### **Hi 6,30**
 Czy słowem dopuszczam się nieprawości? Czyż moje podniebienie nie odróżnia złego?
# Hi 6 WUJ
###### **Hi 6,1**
 A Job odpowiadając rzekł:
###### **Hi 6,2**
 Daj Boże, aby grzechy moje, którymich gniew zasłużył, i nędza, którą cierpię, były włożone na wagę.
###### **Hi 6,3**
 Jako piasek morski ta by się cięższa ukazała: ztądże i słowa moje pełne są boleści.
###### **Hi 6,4**
 Abowiem strzały Pańskie we mnie są, których gniew wypił ducha mego, a strachy pańskie walczą przeciwko mnie.
###### **Hi 6,5**
 Izali będzie ryczał leśny osieł, gdy ma trawę? abo wół będzie ryczał, gdy stanie u pełnego żłobu?
###### **Hi 6,6**
 Abo możeli być jedziona rzecz niesmaczna, która nie jest osolona? abo może kto skosztować co skosztowane śmierć przynosi?
###### **Hi 6,7**
 Czego się przedtem dotknąć nie chciała dusza moja, teraz dla ucisku jest pokarmem moim?
###### **Hi 6,8**
 Ktoby dał, aby się stała prośba moja, a iżby mi Bóg dał czego oczekawam.
###### **Hi 6,9**
 A który począł, tenby mię zstarł? rozpuścił rękę swoję i wyciąłby mię?
###### **Hi 6,10**
 A żeby mi to było za pociechę iż trapiąc mię boleścią nie folgował, anim się sprzeciwiał mowam świętego.
###### **Hi 6,11**
 Co bowiem za moc moja, żebych wytrwał? abo co za koniec mój, abym cierpliwie się sprawował?
###### **Hi 6,12**
 Ani moc kamienna moc moja, ni ciało moje jest miedziane.
###### **Hi 6,13**
 Oto niemasz mnie pomocy we mnie, i powinowaci też moi odstąpili odemnie.
###### **Hi 6,14**
 Który odejmuje od przyjaciela swego miłosierdzie, bojaźń Pańską opuszcza.
###### **Hi 6,15**
 Bracia moi minęli mię, jako potok, który prędki bieży po nizinach.
###### **Hi 6,16**
 Którzy się boją szronu, przypadnie śnieg na nie.
###### **Hi 6,17**
 Czasu którego rozproszeni będą, zaginą: a skoro się zagrzeje, rozpłyną się z miejsca swego.
###### **Hi 6,18**
 Powikłały się ścieżki kroków ich: będą próżno chodzić, i zaginą.
###### **Hi 6,19**
 Obaczcie ścieżki Thema, drogi Saba, a poczekajcie trochę.
###### **Hi 6,20**
 Zawstydzili się, iżem miał nadzieję: przyszli też aż do mnie, a wstydem okryli się.
###### **Hi 6,21**
 Terazeście przyszli: a teraz widząc skaranie moje boicie się.
###### **Hi 6,22**
 Azam mówił: Przynieście mi i z majętności waszej podarujcie mię?
###### **Hi 6,23**
 Abo, wybawcie mię z ręki nieprzyjacielskiej, i z ręki mocarzów wyrwicie mię?
###### **Hi 6,24**
 Nauczcie mię, a ja będę milczał: a jeślim podobno czego nie umiał nauczcie mię.
###### **Hi 6,25**
 Czemuście uwłóczyli mowam prawdy, gdyż niemasz żadnego z was, któryby mię mógł strofować?
###### **Hi 6,26**
 Na łajanie tylko mowę stroicie, a na wiatr słowa wypuszczacie.
###### **Hi 6,27**
 Na sierotę się targacie, i staracie się wywrócić przyjaciela waszego.
###### **Hi 6,28**
 Wszakoż jednak coście zaczęli konajcie: nadstawcie ucha, a obaczcie jeśli kłamam.
###### **Hi 6,29**
 Odpowiedzcie, proszę, bez swaru: a mówiąc to co jest sprawiedliwo, osądźcie.
###### **Hi 6,30**
 I nie najdziecie w języku moim nieprawości, ani w ustach moich głupstwo będzie brzmiało.
