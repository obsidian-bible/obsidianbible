# Am 4 BT5
###### **Am 4,1**
 Słuchajcie słowa tego, krowy Baszanu, które mieszkacie na górach Samarii:uciskacie biednych, gnębicie ubogich, mówicie do mężów swoich: «***Przynieś, a będziemy pili!***»
###### **Am 4,2**
 Poprzysiągł Pan Bóg na świętość swoją:Oto dni na was nadchodzą, że pochwycą was, a tych, co pozostaną, [złowią] jak ryby na kółka, wędkami,
###### **Am 4,3**
 i przez wyłomy w murze wyjdzie każda przed siebie, i powloką was do Hermonu– wyrocznia Pana.
###### **Am 4,4**
 Idźcie do Betel i grzeszcie, do Gilgal i grzeszcie więcej; przynoście co ranka ofiary wasze i co trzeci dzień dziesięciny!
###### **Am 4,5**
 Nawet chleb kwaszony spalajcie na ofiarę pochwalną i nawołujcie głośno do ofiar dobrowolnych, bo to lubicie, synowie Izraela– wyrocznia Pana Boga.
###### **Am 4,6**
 To Ja sprowadziłem na was klęskę głodu we wszystkich waszych miastach i brak chleba we wszystkich waszych wioskach, ale do Mnie nie powróciliście– wyrocznia Pana.
###### **Am 4,7**
 To Ja wstrzymałem dla was deszcz na trzy miesiące przed żniwami; spuściłem deszcz na jedno miasto, a w drugim mieście nie padało; jedno pole zostało zroszone, a drugie pole, na które nie padał deszcz, stało się suche.
###### **Am 4,8**
 I wlekli się mieszkańcy dwóch, trzech miast do jednego miasta, by napić się wody, lecz nie zaspokoili pragnienia; ale do Mnie nie powróciliście– wyrocznia Pana.
###### **Am 4,9**
 Karałem was zwarzeniem i śniecią zbóż; liczne ogrody wasze i winnice, figowce i oliwki zjadła szarańcza; ale do Mnie nie powróciliście– wyrocznia Pana.
###### **Am 4,10**
 Zesłałem na was zarazę jak na Egipt; wybiłem mieczem waszych młodzieńców, a konie wasze uprowadzono; i sprawiłem, że zaduch waszych obozów podrażnił wam nozdrza; ale do Mnie nie powróciliście – wyrocznia Pana.
###### **Am 4,11**
 Spustoszyłem was, jak podczas Bożego spustoszenia Sodomy i Gomory; staliście się jak głownia wyciągnięta z ognia; ale do Mnie nie powróciliście – wyrocznia Pana.
###### **Am 4,12**
 Dlatego tak uczynię tobie, Izraelu, a ponieważ tak ci uczynię, przygotuj się, by stawić się przed Bogiem twym, Izraelu!
###### **Am 4,13**
 On to jest, który tworzy góry i stwarza wichry, objawia człowiekowi swoje zamiary, wywołuje jutrzenkę i ciemność, stąpa po wyżynach ziemi. Pan, Bóg Zastępów, jest imię Jego.
# Am 4 PAU
###### **Am 4,1**
 Słuchajcie tego słowa, krowy Baszanu, które mieszkacie na górach Samarii, uciskacie biednych, gnębicie ubogich i mówicie waszym mężom: „Przynieś no coś do picia!”.
###### **Am 4,2**
 PAN BÓG przysiągł na swoją świętość: Oto nadchodzą dni, kiedy wywloką was hakami, a pozostałe - rybackimi wędkami.
###### **Am 4,3**
 Wyjdziecie przez wyłomy w murze, jedna po drugiej, i zostaniecie wypędzone za Hermon- wyrocznia PANA.
###### **Am 4,4**
 Idźcie do Betel i grzeszcie, idźcie do Gigal i grzeszcie jeszcze więcej! Każdego ranka przynoście wasze ofiary i co trzeci dzień dziesięciny!
###### **Am 4,5**
 Składajcie także chleb kwaszony na ofiarę dziękczynną i głośno ogłaszajcie, że składacie dobrowolne ofiary! Bo przecież lubicie te rzeczy, Izraelici- wyrocznia PANA BOGA.
###### **Am 4,6**
 To Ja sprowadziłem na was klęskę głodu we wszystkich waszych miastach i brak chleba we wszystkich waszych wioskach. Lecz wy nie powróciliście do Mnie - wyrocznia PANA.
###### **Am 4,7**
 To Ja wam deszcz wstrzymałem na trzy miesiące przed żniwami: zesłałem deszcz na jedno miasto, a w drugim mieście nie padało; jedno pole zostało zroszone, a drugie, na które deszcz nie padał, pozostało suche.
###### **Am 4,8**
 I mieszkańcy dwu, trzech miast przyszli do jednego, aby się napić, ale nie zaspokoili pragnienia. Lecz wy nie powróciliście do Mnie - wyrocznia PANA.
###### **Am 4,9**
 Dotknąłem wasze zboża rdzą i śniecią, sprawiłem, że uschły wasze ogrody i winnice, a drzewa figowe i oliwne obgryzła szarańcza. Lecz wy nie powróciliście do Mnie - wyrocznia PANA.
###### **Am 4,10**
 Zesłałem na was zarazę jak niegdyś na Egipt, wybiłem mieczem waszych młodzieńców, pozwoliłem uprowadzić wasze konie; swąd spalonych obozów dotarł do waszych nozdrzy. Lecz wy nie powróciliście do Mnie - wyrocznia PANA.
###### **Am 4,11**
 Dokonałem wśród was wielkiego spustoszenia, jak niegdyś w Sodomie i Gomorze, staliście się jak głownia wyciągnięta z ognia. Lecz wy nie powróciliście do Mnie - wyrocznia PANA.
###### **Am 4,12**
 Dlatego tak postąpię z tobą, Izraelu! A ponieważ tak chcę z tobą postąpić, przygotuj się, Izraelu, na spotkanie z twoim Bogiem!
###### **Am 4,13**
 Bo to On kształtuje góry i rządzi wichrami, On objawia człowiekowi swoje myśli, stwarza jutrzenkę i ciemność i kroczy po wyżynach ziemi. PAN, BÓG Zastępów, to Jego imię.
# Am 4 BP
###### **Am 4,1**
 Słuchajcie słowa tego, krowy Baszamu, wy, na górze Samarii, co uciskacie ubogich i znęcacie się nad biednymi, wy, co mówicie do swych mężów: "Przynieś coś, byśmy się mogli napić".
###### **Am 4,2**
 Poprzysiągł Jahwe-Pan na swoją świętość: Oto przyjdą na was dni, kiedy [zarzucą] haki, by was uprowadzić, a na ostatnie z was - kolce;
###### **Am 4,3**
 wychodzić będziecie przez ruiny, jedna za drugą, i pędzić was będą w stronę Chermonu - mówi Jahwe.
###### **Am 4,4**
 Przychodźcie do Betel i grzeszcie, i do Gilgal, by grzeszyć jeszcze bardziej! Przynoście co rano swoje ofiary, co trzeci dzień swe dziesięciny!
###### **Am 4,5**
 Spalajcie, co kwaszone, na ofiarę dziękczynną i nawołujcie głośno do ofiar dobrowolnych! Wszak lubicie to, synowie Izraela - mówi Jahwe-Pan.
###### **Am 4,6**
 A przecież Ja sprawiłem we wszystkich waszych miastach, że zęby wasze nie miały co gryźć i że we wszystkich waszych osadach był niedostatek chleba; a jednak nie nawróciliście się do mnie - mówi Jahwe.
###### **Am 4,7**
 Ja też pozbawiłem was deszczu, gdy jeszcze trzy miesiące zostawało do żniw; zesłałem deszcz na jedno miasto, a nie zesłałem go na drugie; jedno pole zrosił deszcz, a pole, na które nie zesłałem deszczu, wyschło;
###### **Am 4,8**
 udawali się tedy z dwóch, trzech miast - do jednego, aby się napić wody, ale nie ugasili pragnienia; a jednak nie nawróciliście się do mnie - mówi Jahwe.
###### **Am 4,9**
 Dotknąłem wasze zboże rdzą i śniecią, pozwoliłem uschnąć waszym ogrodom i waszym winnicom, wasze drzewa figowe i oliwne zniszczyła szarańcza; a jednak nie nawróciliście się do mnie - mówi Jahwe.
###### **Am 4,10**
 Zesłałem na was zarazę, jak niegdyś na Egipt, pozabijałem mieczem waszych młodzieńców, a konie wasze pozwoliłem uprowadzić; sprawiłem, że zaduch waszego obozu wciskał się w wasze nozdrza; a jednak nie nawróciliście się do mnie - mówi Jahwe.
###### **Am 4,11**
 Dokonałem wśród was spustoszenia, jakiego Bóg dokonał na Sodomie i Gomorze, i byliście podobni do polana ocalonego z pożaru; a jednak nie nawróciliście się do mnie - mówi Jahwe.
###### **Am 4,12**
 Dlatego tak oto postąpię z tobą, Izraelu! A ponieważ tak zamierzam z tobą postąpić, gotuj się, Izraelu, na spotkanie z Bogiem twoim!
###### **Am 4,13**
 Bo On to jest, który ukształtował góry i stworzył wiatr, który odsłania człowiekowi jego własne myśli; On, który stwarza zorzę poranną i ciemność i kroczy po wyniosłościach ziemi. Jahwe, Bóg Zastępów, jest Imię Jego.
# Am 4 BR
###### **Am 4,1**
 Posłuchajcie, krowy baszańskie na wzgórzach Samarii, wy, co słabych uciskacie i ciemiężycie ubogich, a do mężów waszych mówicie: Przyniesiono wino, to się napijemy.
###### **Am 4,2**
 Dlatego na swoją świętość Pan złożył przysięgę: Oto przychodzą na was dni, że chwytać was będą na łowieckie haki, a tych, co jeszcze zostaną, ułowią na wędkę.
###### **Am 4,3**
 I jedna za drugą będziecie się przedostawać poprzez wyłomy w murze i ścigać was będą aż do góry Hermon - taka jest Pana wyrocznia.
###### **Am 4,4**
 Idźcie do Betel i tam grzeszcie, do Gilgal idźcie i jeszcze więcej grzeszcie! Składajcie tam rano wasze krwawe ofiary, a dnia trzeciego dziesięciny przynoście!
###### **Am 4,5**
 Spalajcie nawet chleb kwaśny na dziękczynną ofiarę, do ofiar dobrowolnych zachęcajcie się nawzajem, głośno to obwieszczajcie tak aby was słyszano. Bo się w tym lubujecie, Izraela synowie - taka jest Pana wyrocznia.
###### **Am 4,6**
 To Ja sprowadziłem głód na wszystkie wasze miasta i sprawiłem, że w wioskach waszych zabrakło chleba, a mimo to nie nawróciliście się do Mnie - oto wyrocznia Boga i Pana.
###### **Am 4,7**
 Deszcz wam przestałem zsyłać, gdy brakło już tylko trzech miesięcy do żniwa, a potem na jedno miasto deszcz zsyłałem, na drugie zaś nie zsyłałem; jedno pole miało pod dostatkiem deszczu, drugiemu brakło wody, tak że całkiem wyschło.
###### **Am 4,8**
 Dwa lub trzy miasta śpieszyły do jednego, bo chciały znaleźć wodę, wciąż jednak dokuczało im uciążliwe pragnienie. A mimo to nie wróciliście do Mnie - oto wyrocznia Pana!
###### **Am 4,9**
 Zniszczyłem wszystkie wasze zboża zarazą rdzy i śnieci, spustoszyłem ogrody i winnice wasze. Drzewa figowe i oliwki całkowicie pochłonęła szarańcza. A mimo to nie wróciliście do Mnie - oto wyrocznia Pana!
###### **Am 4,10**
 Zarazę na was zesłałem jak kiedyś na Egipcjan, wszystkich waszych młodzieńców wytraciłem mieczem, a konie wasze wrogom na łup dałem. Odór trupów z waszego obozu aż do nozdrzy wam sięgał. A mimo to nie wróciliście do Mnie - oto wyrocznia Pana!
###### **Am 4,11**
 Sprowadzę wiec na was gromy potężne, jak kiedyś Bóg na Sodomę i Gomorę; byliście jak drzewo opalone, które się wydobywa z ognia. A mimo to nie wróciliście do Mnie - oto wyrocznia Pana!
###### **Am 4,12**
 Dlatego wszystko to uczynię tobie, Izraelu, ponieważ zaś wszystko to ci uczynię, przygotuj się, by stanąć przed twoim Bogiem!
###### **Am 4,13**
 Zastanów się, przecież to On stwarza góry i kieruje wichrami, On też objawia ludziom wszystkie ich zamiary, On sprawia, że jest jutrzenka poranna i (wieczorna) ciemność. On stąpa również po wyżynach ziemi, imię zaś Jego jest Pan i Bóg Zastępów.
# Am 4 WUJ
###### **Am 4,1**
 Słuchajcie słowa tego krowy tłuste, które jesteście na górze Samaryjskiej, które po twarz czynicie nędznikom, a niszczycie ubogie: które mówicie panom swym: Przynieście, a będziem pić.
###### **Am 4,2**
 Przysiągł Pan Bóg na świętobliwość swoję: że oto dni przyda na was, a wyniosą was na drzewcach, a ostatki wasze w garncach warzących.
###### **Am 4,3**
 I dziurami wynidziecie, jedna przeciw drugiej, a będziecie zarzucone do Armon, mówi Pan.
###### **Am 4,4**
 Chodźcież do Bethel, a niezbożnie czyńcie: do Galgal, a rozmnażajcie przestępstwo: a przynoście poranu ofiary wasze, przez trzy dni dziesięciny wasze.
###### **Am 4,5**
 I ofiarujcie z kwaszonego chwałę: a nazywajcie dobrowolne ofiary: a opowiadajcie: boście tak chcieli synowie Izraelscy, mówi Pan Bóg.
###### **Am 4,6**
 Ztądże i ja dałem wam strętwienie zębów we wszech mieściech waszych, i niedostatek chleba po wszech miejscach waszych, a nie nawróciliście się do mnie, mówi Pan.
###### **Am 4,7**
 Jam też zahamował od was deszcz, gdy jeszcze były trzy miesiące do żniwa: a spuszczałem deszcz na jedno miasto, a na drugie miasto nie spuszczałem: część jedna dżdżem polana była, a część, na którą nie spuszczałem dżdżu wyschła.
###### **Am 4,8**
 I przyszły dwie i trzy miasta do jednego miasta, aby wodę piły, i nie napiły się: a nie nawróciliście się do mnie, mówi Pan.
###### **Am 4,9**
 Karałem was wiatrem palącym, i suszą, mnóstwo ogrodów waszych, i winnic waszych: oliwnice wasze i figownice wasze pożerała gąsiennica: a nie wróciliście się do mnie, mówi Pan.
###### **Am 4,10**
 Puściłem na was śmierć na drodze Egiptskiej, pozabijałem mieczem młodzieńce wasze aż do pojmania koni waszych: i uczyniłem, że przyszła zgniłość obozów waszych w nozdrze wasze: a nie wróciliście się do mnie, mówi Pan.
###### **Am 4,11**
 Wywróciłem was jako wywrócił Bóg Sodomę i Gomorrę, i staliście się jako głownia porwana z ognia: a nie wróciliście się do mnie, mówi Pan.
###### **Am 4,12**
 Przetoż to uczynię tobie Izraelu: a gdyć to uczynię, przygotuj się na zabieżenie Panu Bogu twemu Izraelu.
###### **Am 4,13**
 Bo oto tworzący góry i stwarzający wiatr, i oznajmujący człowiekowi mowę swoję, czyniący mgłę poranną, a chodzący po wysokościach ziemie: Pan Bóg zastępów imię jego.
