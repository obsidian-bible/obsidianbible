# Hbr 11 BT5
###### **Hbr 11,1**
 Wiara zaś jest poręką tych dóbr, których się spodziewamy, dowodem tych rzeczywistości, których nie widzimy.
###### **Hbr 11,2**
 To dzięki niej przodkowie otrzymali świadectwo.
###### **Hbr 11,3**
 Przez wiarę poznajemy, że słowem Boga wszechświat został tak stworzony, iż to, co widzimy, powstało nie z rzeczy widzial-nych.
###### **Hbr 11,4**
 Dzięki wierze Abel złożył Bogu cenniejszą niż Kain ofiarę, za co otrzymał świadectwo, iż jest sprawiedliwy. Bóg bowiem zaświadczył o jego darach, toteż choć umarł, przez nią jeszcze przemawia.
###### **Hbr 11,5**
 Przez wiarę Henoch został uniesiony, aby nie oglądał śmierci. I nie znaleziono go, ponieważ Bóg go zabrał. Przed zabraniem bowiem otrzymał świadectwo, iż podobał się Bogu.
###### **Hbr 11,6**
 Bez wiary zaś nie można podobać się Bogu. Przystępujący bowiem do Boga musi uwierzyć, że [Bóg] jest i że wynagradza tych, którzy Go szukają.
###### **Hbr 11,7**
 Przez wiarę Noe został pouczony cudownie o tym, czego jeszcze nie można było ujrzeć, i pełen bojaźni zbudował arkę, aby ocalić swą rodzinę. Przez wiarę też potępił świat i stał się dziedzicem sprawiedliwości, którą otrzymuje się dzięki wierze.
###### **Hbr 11,8**
  Dzięki wierze ten, którego nazwano Abrahamem, usłuchał wezwania, by wyruszyć do ziemi, którą miał objąć w posiadanie. Wyszedł, nie wiedząc, dokąd idzie.
###### **Hbr 11,9**
 Dzięki wierze przywędrował do Ziemi Obiecanej, jako ziemi obcej, pod namiotami mieszkając z Izaakiem i Jakubem, współdziedzicami tej samej obietnicy.
###### **Hbr 11,10**
 Oczekiwał bowiem miasta zbudowanego na silnych fundamentach, którego architektem i budowniczym jest sam Bóg.
###### **Hbr 11,11**
 Dzięki wierze także i sama Sara, mimo podeszłego wieku, otrzymała moc poczęcia. Uznała bowiem za godnego wiary Tego, który udzielił obietnicy.
###### **Hbr 11,12**
 Przeto z człowieka jednego, i to już niemal obumarłego, powstało potomstwo tak liczne jak gwiazdy na niebie, jak niezliczone ziarnka piasku na wybrzeżu morza.
###### **Hbr 11,13**
 W wierze pomarli oni wszyscy, nie osiągnąwszy tego, co im przyrzeczono, lecz patrzyli na to z daleka i witali, uznawszy siebie za obcych i gości na tej ziemi.
###### **Hbr 11,14**
 Ci bowiem, co tak mówią, wykazują, że szukają ojczyzny.
###### **Hbr 11,15**
 Gdyby zaś tę wspominali, z której wyszli, znaleźliby sposobność powrotu do niej.
###### **Hbr 11,16**
 Teraz zaś do lepszej dążą, to jest do niebieskiej. Dlatego Bóg nie wstydzi się być nazywanym ich Bogiem, gdyż przysposobił im miasto.
###### **Hbr 11,17**
 Dzięki wierze Abraham, wystawiony na próbę, ofiarował Izaaka, i to jedynego syna składał na ofiarę, on, który otrzymał obietnicę,
###### **Hbr 11,18**
 któremu powiedziane było: Z Izaaka będzie dla ciebie potomstwo.
###### **Hbr 11,19**
 Pomyślał bowiem, iż Bóg mocen jest wskrzesić także umarłych, i dlatego odzyskał go, na podobieństwo [śmierci i zmartwychwstania Chrystusa].
###### **Hbr 11,20**
 Dzięki wierze w przyszłość Izaak pobłogosławił Jakuba i Ezawa.
###### **Hbr 11,21**
 Dzięki wierze Jakub, umierając, pobłogosławił każdego z synów Józefa i pochylił się głęboko przed wierzchołkiem jego laski.
###### **Hbr 11,22**
 Dzięki wierze Józef, konając, wspomniał o wyjściu synów Izraela i dał polecenie w sprawie swoich kości.
###### **Hbr 11,23**
 Dzięki wierze Mojżesz był ukrywany przez swoich rodziców w ciągu trzech miesięcy po swoim narodzeniu, ponieważ widzieli, że ładne jest dzieciątko, a nie ulękli się nakazu króla.
###### **Hbr 11,24**
 Dzięki wierze Mojżesz, gdy dorósł, odmówił nazywania się synem córki faraona,
###### **Hbr 11,25**
 wolał raczej cierpieć z ludem Bożym, niż zażywać przemijających rozkoszy grzechu.
###### **Hbr 11,26**
 Uważał bowiem za większe bogactwo znoszenie zniewag dla Chrystusa niż wszystkie skarby Egiptu, gdyż patrzył na zapłatę.
###### **Hbr 11,27**
 Dzięki wierze opuścił Egipt, nie uląkłszy się gniewu królewskiego; wytrwał, jakby widział Niewidzialnego.
###### **Hbr 11,28**
 Dzięki wierze zgotował Paschę i pokropienie krwią, aby nie do-tknął się ich Ten, który zabijał to, co pierworodne.
###### **Hbr 11,29**
 Dzięki wierze przeszli Morze Czerwone jak po suchej ziemi, a gdy Egipcjanie spróbowali to uczynić, potonęli.
###### **Hbr 11,30**
 Dzięki wierze runęły mury Jerycha, gdy je obchodzili dokoła w ciągu siedmiu dni.
###### **Hbr 11,31**
 Dzięki wierze nierządnica Rachab nie zginęła razem z niewierzącymi, bo gościnnie przyjęła wysłanych na zwiady.
###### **Hbr 11,32**
 I cóż jeszcze mam powiedzieć? Nie starczyłoby mi bowiem czasu na opowiadanie o Gedeonie, Baraku, Samsonie, Jeftem, Dawidzie, Samuelu i o prorokach,
###### **Hbr 11,33**
 którzy dzięki wierze zdobyli królestwa, dokonali czynów sprawiedliwych, otrzymali obietnice, zamknęli paszcze lwom,
###### **Hbr 11,34**
 przygasili żar ognia, uniknęli ostrzy miecza i wyleczyli się z niemocy, stali się bohaterami w walce i do ucieczki zmusili nieprzyjacielskie szyki.
###### **Hbr 11,35**
 Dzięki dokonanym przez nich wskrzeszeniom niewiasty otrzymały swoich zmarłych. Jedni ponieśli katusze, nie przyjąwszy uwolnienia, aby otrzymać lepsze zmartwychwstanie.
###### **Hbr 11,36**
 Inni zaś doznali zelżywości i biczowania, a nadto kajdan i więzienia.
###### **Hbr 11,37**
 Kamienowano ich, przerzynano piłą, < kuszono >, przebijano mieczem; tułali się w skórach owczych, kozich, w nędzy, w utrapieniu, w ucisku –
###### **Hbr 11,38**
 świat nie był ich wart – i błąkali się po pustyniach i górach, po jaskiniach i rozpadlinach ziemi.
###### **Hbr 11,39**
 A ci wszyscy, choć ze względu na swą wiarę stali się godni pochwały, nie otrzymali przyrzeczonej obietnicy,
###### **Hbr 11,40**
 gdyż Bóg, który nam lepszy los zgotował, nie chciał, aby oni osiągnęli doskonałość bez nas.
# Hbr 11 PAU
###### **Hbr 11,1**
 Wiara jest gwarancją tego, czego się spodziewamy, i dowodem rzeczywistości niewidzialnej.
###### **Hbr 11,2**
 Dzięki niej nasi przodkowie otrzymali świadectwo.
###### **Hbr 11,3**
 Przez wiarę poznajemy, że światy zostały stworzone słowem Bożym, czyli to, co widzimy, nie powstało z rzeczy widzialnych.
###### **Hbr 11,4**
 Przez wiarę Abel złożył Bogu ofiarę lepszą niż Kain, dzięki czemu został uznany za sprawiedliwego przez samego Boga, który zaświadczył o jego darach. Choć więc umarł, przez nią nadal przemawia.
###### **Hbr 11,5**
 Przez wiarę Henoch został zabrany, aby uniknąć śmierci, i nie znaleziono go, bo Bóg go zabrał. Już bowiem przed swym zabraniem otrzymał świadectwo, że spodobał się Bogu.
###### **Hbr 11,6**
 Bez wiary zaś nie można podobać się Bogu. Ten, kto zbliża się do Boga, musi wierzyć, że On jest i że nagradza tych, którzy Go szukają.
###### **Hbr 11,7**
 Przez wiarę Noe otrzymał pouczenie o sprawach jeszcze niewidocznych, przyjął je poważnie i zbudował arkę, aby ocalić swoją rodzinę. Przez wiarę potępił ten świat i stał się dziedzicem sprawiedliwości, którą otrzymuje się przez wiarę.
###### **Hbr 11,8**
 Przez wiarę Abraham okazał posłuszeństwo wezwaniu, aby wyruszyć na miejsce, które miał otrzymać w dziedzictwie. Wyruszył, nie wiedząc, dokąd zmierza.
###### **Hbr 11,9**
 Przez wiarę przebywał w Ziemi Obiecanej jak w obcej, pod namiotami mieszkając z Izaakiem i Jakubem, dziedzicami tej samej obietnicy.
###### **Hbr 11,10**
 Oczekiwał bowiem miasta opartego na trwałych fundamentach, którego architektem i budowniczym będzie sam Bóg.
###### **Hbr 11,11**
 Przez wiarę również Sara, choć bezpłodna, w podeszłym wieku otrzymała moc wydania potomstwa, gdyż za wiarygodnego uznała dawcę obietnicy.
###### **Hbr 11,12**
 Toteż z jednego człowieka, naznaczonego już śmiercią, zrodziło się niezliczone mnóstwo, jak gwiazdy na niebie i jak piasek na brzegu morza.
###### **Hbr 11,13**
 Wszyscy oni pomarli w wierze i nie doczekali spełnienia obietnic. Ale z daleka je oglądali i witali, wyznając, że są na ziemi obcymi i wędrowcami.
###### **Hbr 11,14**
 Ci bowiem, którzy tak mówią, dowodzą, że dopiero szukają ojczyzny.
###### **Hbr 11,15**
 Gdyby bowiem mieli na myśli tę, z której wyszli, to znaleźliby sposobność powrotu do niej.
###### **Hbr 11,16**
 Teraz jednak dążą do lepszej ojczyzny, która jest w niebie. Dlatego Bóg nie wstydzi się, gdy nazywają Go swoim Bogiem, bo przygotował im miasto.
###### **Hbr 11,17**
 Przez wiarę Abraham, wystawiony na próbę, zdecydował się złożyć w ofierze Izaaka. On, który otrzymał obietnice, poświęcił na ofiarę jedynego syna.
###### **Hbr 11,18**
 A przecież Bóg mu powiedział: za twoje potomstwo zostanie uznane potomstwo Izaaka.
###### **Hbr 11,19**
 Był jednak przekonany, że Bóg może nawet wskrzesić umarłego, i dlatego odzyskał go jakby na pouczenie.
###### **Hbr 11,20**
 Przez wiarę w rzeczy przyszłe Izaak pobłogosławił Jakuba i Ezawa.
###### **Hbr 11,21**
 Przez wiarę Jakub, umierając, pobłogosławił obu synów Józefa, a sam pokłonił się przed wierzchołkiem jego laski.
###### **Hbr 11,22**
 Przez wiarę Józef, zanim umarł, wspomniał o wyjściu Izraelitów i wydał polecenie co do swego pogrzebu.
###### **Hbr 11,23**
 Przez wiarę rodzice Mojżesza ukrywali go po urodzeniu przez trzy miesiące, ponieważ widzieli w dziecku piękno i nie ulękli się dekretu władcy.
###### **Hbr 11,24**
 Przez wiarę Mojżesz, gdy stał się dojrzały, nie chciał uchodzić za syna córki faraona.
###### **Hbr 11,25**
 Wolał raczej cierpieć razem z ludem Bożym, niż korzystać z przemijającej rozkoszy grzechu.
###### **Hbr 11,26**
 Uznał zniewagi znoszone dla Chrystusa za bogactwo większe niż skarby Egiptu, ponieważ spodziewał się odpłaty.
###### **Hbr 11,27**
 Przez wiarę opuścił Egipt, nie lękając się gniewu władcy. Stał się wytrwały, jak gdyby widział Niewidzialnego.
###### **Hbr 11,28**
 Przez wiarę obchodził Paschę i dokonał pokropienia krwią, aby Niszczyciel nie poraził pierworodnych Izraela.
###### **Hbr 11,29**
 Przez wiarę przeszli oni Morze Czerwone jak suchą ziemię, a Egipcjanie utonęli, próbując uczynić to samo.
###### **Hbr 11,30**
 Przez wiarę upadły mury Jerycha, gdy wokół nich chodzili przez siedem dni.
###### **Hbr 11,31**
 Przez wiarę nierządnica Rachab nie zginęła razem z tymi, którzy okazali się nieposłuszni, gdyż gościnnie przyjęła zwiadowców.
###### **Hbr 11,32**
 Cóż jeszcze mogę dodać? Zabrakłoby mi czasu, gdybym chciał opowiadać o Gedeonie, Baraku, Samsonie, Jeftem, Dawidzie, Samuelu i prorokach.
###### **Hbr 11,33**
 Przez wiarę pokonali oni królestwa, dokonali dzieł sprawiedliwości, doczekali się spełnienia obietnic, zamknęli lwom paszcze,
###### **Hbr 11,34**
 stłumili żar ognia, uniknęli ostrza miecza, okazali moc nad słabością i waleczność na wojnie, odparli wojska cudzoziemskie.
###### **Hbr 11,35**
 Kobiety odzyskały swych zmarłych przez zmartwychwstanie. Inni woleli tortury zamiast możliwości wykupienia, aby otrzymać lepsze zmartwychwstanie.
###### **Hbr 11,36**
 Jeszcze inni doświadczyli szyderstw, chłosty, kajdan i więzienia.
###### **Hbr 11,37**
 Kamienowano ich, przerzynano piłą, ścinano mieczem. Tułali się w skórach owczych i kozich, cierpieli niedostatek, ucisk i poniewierkę.
###### **Hbr 11,38**
 Świat nie był ich godny. Błądzili po miejscach pustynnych, po górach, jaskiniach i rozpadlinach ziemi.
###### **Hbr 11,39**
 A jednak ci wszyscy, choć przez wiarę otrzymali świadectwo, nie doczekali spełnienia obietnicy.
###### **Hbr 11,40**
 Bóg bowiem ze względu na nas przygotował coś wspanialszego, ażeby bez nas nie osiągnęli oni celu!
# Hbr 11 BP
###### **Hbr 11,1**
 Wiara jest mocnym przekonaniem, że istnieje to, czego się spodziewamy, jest świadectwem o wydarzeniach, których nie widzimy.
###### **Hbr 11,2**
 Ona wystawia świadectwo naszym przodkom.
###### **Hbr 11,3**
 Przez wiarę poznajemy, że światy zostały stworzone słowem Boga, że to, co jest dostrzegalne, powstało z niewidzialnego.
###### **Hbr 11,4**
 Dzięki wierze Abel złożył Bogu lepszą ofiarę niż Kain, która mu wystawia świadectwo, że jest doskonały, Bóg bowiem zaświadczył o jego darach; dzięki niej też, chociaż umarł, jeszcze przemawia.
###### **Hbr 11,5**
 Dzięki wierze Henoch był przeniesiony [z tego świata], aby nie umarł, a "nie został znaleziony; ponieważ przeniósł go Bóg". Oto przed przeniesieniem otrzymał świadectwo, że "bardzo podobał się Bogu".
###### **Hbr 11,6**
 Bez wiary więc nie można podobać się Bogu, bowiem kto zbliża się do Boga, musi wierzyć, że On istnieje i że wynagradza tych, którzy Go szukają.
###### **Hbr 11,7**
 Dzięki wierze Noe ostrzeżony przed tym, czego jeszcze nie było widać, pełen czci, przygotował arkę dla ratowania swej rodziny. Dzięki wierze wydał wyrok na świat i dostąpił sprawiedliwości opartej na wierze.
###### **Hbr 11,8**
 Dzięki wierze Abraham, gdy został wezwany, posłusznie poszedł na miejsce, które miał otrzymać jako dziedzictwo, a wyszedł nie wiedząc nawet, dokąd ma iść.
###### **Hbr 11,9**
 Dzięki wierze zawędrował do Ziemi Obiecanej jako obcej, zamieszkując w namiotach wraz z Izaakiem i Jakubem, współdziedzicami tej samej obietnicy.
###### **Hbr 11,10**
 Oczekiwał bowiem miasta o stałych fundamentach, które Bóg miał zaplanować i zbudować.
###### **Hbr 11,11**
 Dzięki wierze nawet i [bezpłodna] Sara mimo podeszłego wieku mogła począć syna, ponieważ zaufała Temu, który dał obietnicę.
###### **Hbr 11,12**
 Dlatego z jednego i to niemal obumarłego człowieka powstało liczne potomstwo: "Jak gwiazdy na niebie i jak nie przeliczony piasek na brzegu morskim".
###### **Hbr 11,13**
 Zachowując wiarę poumierali oni wszyscy, nie osiągnąwszy obiecanych dóbr, lecz z daleka je oglądali i pozdrawiali, a przyznawali, że są na tej ziemi cudzoziemcami i wędrowcami.
###### **Hbr 11,14**
 Tak mówiąc okazywali, że szukają ojczyzny.
###### **Hbr 11,15**
 A jeśliby myśleli o tej, z której wyszli, mieli przecież czas powrócić.
###### **Hbr 11,16**
 Zdążają zatem do lepszej, mianowicie do niebieskiej. Dlatego Bóg pozwala się nazywać ich Bogiem, bo przecież przygotował im miasto.
###### **Hbr 11,17**
 Dzięki wierze Abraham poddany próbie złożył w ofierze Izaaka; ten, który z wiarą przyjął obietnicę, składał w ofierze jedynego syna.
###### **Hbr 11,18**
 Ten, któremu powiedziano: "W Izaaku będziesz miał potomstwo",
###### **Hbr 11,19**
 był przekonany, że Bóg potrafi wskrzesić nawet umarłego, dlatego otrzymał Izaaka także po to, aby stał się on wyobrażeniem Chrystusa.
###### **Hbr 11,20**
 Dzięki wierze w to, co miało się stać, Izaak dał błogosławieństwo Jakubowi i Ezawowi.
###### **Hbr 11,21**
 Dzięki wierze umierający Jakub pobłogosławił obydwóch synów Józefa i "schylił się nad wierzchołkiem swej laski".
###### **Hbr 11,22**
 Dzięki wierze Józef u kresu życia przypomniał sobie o wyjściu Izraelitów i wydał polecenie co do [przeniesienia] swych kości.
###### **Hbr 11,23**
 Dzięki wierze rodzice ukrywali Mojżesza przez trzy miesiące po jego urodzeniu, ponieważ widzieli, że chłopiec był urodziwy, a nie ulękli się rozporządzenia królewskiego.
###### **Hbr 11,24**
 Dzięki wierze Mojżesz, gdy dorósł, nie chciał uchodzić za syna córki faraona.
###### **Hbr 11,25**
 Wolał raczej cierpieć z ludem Bożym, aniżeli korzystać z przemijających owoców grzechu.
###### **Hbr 11,26**
 Znoszenie zelżywości dla Pomazańca [Izraela] uważał za większe bogactwo niż wszystkie skarby Egiptu, bo myślał o czekającej go nagrodzie.
###### **Hbr 11,27**
 Dzięki wierze opuścił Egipt, nie bojąc się gniewu królewskiego; okazał taką wytrwałość, jakby widział Niewidzialnego.
###### **Hbr 11,28**
 Dzięki wierze urządził paschę i pomazanie krwią, aby niszczyciel nie tknął ich pierworodnych.
###### **Hbr 11,29**
 Dzięki wierze przeszli Morze Czerwone jak po suchej ziemi, próbujących tego samego Egipcjan pochłonęły fale.
###### **Hbr 11,30**
 Dzięki wierze [oblegających] upadły mury Jerycha, okrążane siedem dni.
###### **Hbr 11,31**
 Dzięki wierze nierządna Rahab nie zginęła razem ze stawiającymi opór, bo życzliwie przyjęła wywiadowców.
###### **Hbr 11,32**
 Cóż bym jeszcze powiedział? Zabrakłoby mi czasu, gdybym miał opowiadać o Gedeonie, Baraku, Samsonie, Jeftem czy Dawidzie i Samuelu oraz prorokach.
###### **Hbr 11,33**
 Oni dzięki swej wierze zwalczyli królestwa, szerzyli sprawiedliwość, dostąpili skutków obietnic, zamknęli paszcze lwów,
###### **Hbr 11,34**
 zwyciężyli siłę ognia, uniknęli ostrza miecza, podnieśli się z choroby, okazali waleczność w boju, rozbili szyki wrogów,
###### **Hbr 11,35**
 kobiety otrzymały swoich zmarłych przywróconych życiu. Inni natomiast, nie przyjąwszy ofiarowanej im wolności, byli łamani kołem, aby osiągnąć większe dobro - zmartwychwstanie.
###### **Hbr 11,36**
 Jeszcze inni zaznali szyderstw i chłosty a także kajdan i więzienia,
###### **Hbr 11,37**
 byli kamienowani, przecinani piłą, ginęli od miecza, okryci skórami owiec i kozłów tułali się, cierpieli niedostatek, udrękę i poniewierkę.
###### **Hbr 11,38**
 Świat nie był ich wart! Błąkali się po pustkowiach, po górach, jaskiniach i rozpadlinach ziemi.
###### **Hbr 11,39**
 I to ci wszyscy, chociaż godni uznania dla swej wiary, nie doczekali się spełnienia obietnicy.
###### **Hbr 11,40**
 Bóg zatroszczył się dla nas o coś lepszego, nie chciał, by oni bez nas osiągnęli doskonałość.
# Hbr 11 BR
###### **Hbr 11,1**
 Wierzyć zaś - to znaczy być pewnym, że się otrzyma to, czego się oczekuje; to znaczy być przekonanym o rzeczywistym istnieniu tego, czego się nie widzi.
###### **Hbr 11,2**
 Chlubne świadectwo takiej wiary zostawiali nasi ojcowie.
###### **Hbr 11,3**
 To właśnie na drodze wiary możemy stwierdzić, iż wszechrzeczy stworzone słowem Bożym, to wszystko, co oczyma widzimy, powstało kiedyś nie z rzeczy widzialnych.
###### **Hbr 11,4**
 Wiarą powodowany Abel złożył Bogu ofiarę cenniejszą od ofiary Kaina i uzyskał wskutek tego świadectwo męża sprawiedliwego. Świadectwo takie wydał sam Bóg ze względu na dary [Abla]. Dlatego przez wiarę swoją przemawia Abel nawet spoza grobu.
###### **Hbr 11,5**
 Dzięki wierze Henoch został zabrany z tego świata, by nie zaznał śmierci. Nikt go już więcej nie oglądał, ponieważ Bóg zabrał go do siebie. Już przedtem jednak - jak mówi Pismo znalazł Bóg w nim upodobanie.
###### **Hbr 11,6**
 A bez wiary nie można podobać się Bogu. Kto bowiem pragnie dojść do Boga, musi najpierw uwierzyć, że Bóg istnieje i że nagradza tych, którzy Go szukają.
###### **Hbr 11,7**
 Noe, choć o tym otrzymał pouczenia, czego jeszcze nie można było ujrzeć oczyma, to jednak już powodowany światłem wiary i napełniony bojaźnią przystąpił do budowy arki, mając w ten sposób ocalić cały ludzki ród. Idąc również za głosem wiary wzgardził światem i osiągnął to, że został uznany za sprawiedliwego w oczach Bożych.
###### **Hbr 11,8**
 Wiarą powodowany Abraham usłuchał wezwania Bożego i wyruszył do ziemi, którą [według obietnicy Boga] miął wziąć jako dziedzictwo. Wyruszył w drogę, choć nie wiedział, dokąd idzie.
###### **Hbr 11,9**
 Słuchając głosu wiary przybył do ziemi obiecanej jako cudzoziemiec i mieszkał pod namiotami, podobnie jak Izaak i Jakub, którzy otrzymali taką samą obietnicę [od Boga].
###### **Hbr 11,10**
 Oczekiwał bowiem na osiedlenie się w mieście o niewzruszonych fundamentach, w mieście, którego budowniczym i twórcą jest sam Bóg.
###### **Hbr 11,11**
 Dzięki wierze również Sara mimo podeszłego wieku otrzymała moc zrodzenia potomstwa. Była bowiem przekonana, że można uwierzyć Temu, który jej dal obietnicę.
###### **Hbr 11,12**
 I tak właśnie z jednego męża - i to już prawie obumarłego - zrodziło się potomstwo liczne jak gwiazdy na niebie, jak piasek niezliczony nad brzegiem morza.
###### **Hbr 11,13**
 Wszyscy pomarli w wierze. Nie było im dane doczekać się dóbr przyobiecanych przez Boga. Widzieli je i radośnie witali z daleka. Siebie samych zaś uważali za gości i pielgrzymów na tej ziemi,
###### **Hbr 11,14**
 co oznacza, że ciągle poszukiwali swójej ojczyzny.
###### **Hbr 11,15**
 Nie można przypuszczać, że myśleli o tej ojczyźnie, z której wyszli, bo przecież znaleźliby niejedną sposobność, by do niej wrócić.
###### **Hbr 11,16**
 Tymczasem oni zdążają do lepszej, to jest do niebieskiej ojczyzny. Dlatego Bóg pozwala nazywać się ich Bogiem, bo rzeczywiście przygotował im ojczyznę.
###### **Hbr 11,17**
 Przez wiarę Abraham, gdy był poddawany Bożej próbie, nie zawahał się złożyć w ofierze swego jedynego syna Izaaka,
###### **Hbr 11,18**
 tego, z którym wiązała się obietnica: Przez Izaaka otrzymasz potomstwo.
###### **Hbr 11,19**
 [Abraham] był przekonany, że Bóg jest w stanie wskrzeszać także umarłych; dlatego odzyskał Izaaka, aby był symbolem [zmartwychwstania Jezusa].
###### **Hbr 11,20**
 Powodowany wiarą w to wszystko, co miało się zdarzyć w przyszłości, Izaak udzielił błogosławieństwa Jakubowi i Ezawowi.
###### **Hbr 11,21**
 Z wiary także płynęło błogosławieństwo, którym umierający już Jakub obdarzył obydwu synów Józefa, pochylając się głęboko nad jego łaską.
###### **Hbr 11,22**
 Pod wpływem wiary konający Józef mówił o wyjściu synów Izraela [z Egiptu] i wydał zlecenie co do sposobu pogrzebania swoich własnych kości.
###### **Hbr 11,23**
 Wiarą powodowani rodzice Mojżesza nie przelękli się wcale rozkazu królewskiego i po urodzeniu dziecka ukrywali je przez trzy miesiące, gdyż widzieli, jak bardzo było piękne.
###### **Hbr 11,24**
 Dzięki wierze Mojżesz, gdy dorósł, nie chciał, by uważano go za syna córki faraona.
###### **Hbr 11,25**
 Wolał znosić uciski razem z całym ludem Bożym, zamiast poddawać się - przemijającym zresztą - rozkoszom grzechu.
###### **Hbr 11,26**
 Mając przed oczyma ciągle przyszłą zapłatę, ponad wszystkie skarby Egiptu przedkładał możność znoszenia ucisków dla Mesjasza.
###### **Hbr 11,27**
 Wiarą powodowany opuścił Egipt, nie lękając się wcale gniewu króla; był w swych postanowieniach nieugięty, tak jakby patrzył ustawicznie na Niewidzialnego.
###### **Hbr 11,28**
 Wiarą kierował się również, gdy nakazywał urządzić obchody Paschy i pokropić krwią [odrzwia domów], aby nie dotykał ich ten, który miał wyniszczyć wszystkie pierworodne.
###### **Hbr 11,29**
 Dzięki wierze [Izraelici] suchą stopą przeszli przez Morze Czerwone, tymczasem Egipcjanie, gdy spróbowali pójść w ich ślady, wszyscy potonęli.
###### **Hbr 11,30**
 Wskutek wiary [atakujących] runęły mury Jerycha po siedmiodniowym ich oblężeniu.
###### **Hbr 11,31**
 Dzięki wierze nierządnica Rahab przyjęła gościnnie wysłanych na zwiady [Izraelitów] i nie zginęła wespół z bezbożnymi.
###### **Hbr 11,32**
 Cóż jeszcze mam powiedzieć? Nie wystarczyłoby mi czasu na opowiedzenie wszystkiego o Gedeonie, Baraku, Samsonie, Jeftem, Dawidzie, Samuelu i o prorokach.
###### **Hbr 11,33**
 Przez swóją wiarę [mężowie ci] doprowadzili do podboju królestw, rządzili sprawiedliwie, doczekali się spełnienia obietnic, zamknęli paszcze lwów
###### **Hbr 11,34**
 i ugasili najgroźniejszy żar ognia; zdołali uniknąć śmierci od miecza, wyszli cało z największych niemocy, czasu wojny okazali się prawdziwymi bohaterami, zmuszając do ucieczki całe zastępy nieprzyjaciół.
###### **Hbr 11,35**
 Dzięki zmartwychwskrzeszeniom [które się dokonały za ich sprawą] niewiasty mogły cieszyć się powrotem do życia swoich mężów. Jedni spośród nich dobrowolnie szli na męki i by osiągnąć wyższe dobro w postaci chwalebnego zmartwychwstania, gardzili przedkładaną im wolnością.
###### **Hbr 11,36**
 Inni byli znieważani, biczowani, zakuwani w kajdany i wtrącani do więzienia.
###### **Hbr 11,37**
 Jeszcze innych kamienowano, [żywcem] przecinano piłami, poddawano różnym próbom, przebijano mieczem. Przyodziani w owcze lub kozie skóry, tułali się w nędzy, zewsząd narażeni na prześladowania i uciski.
###### **Hbr 11,38**
 Świat nie był ich godzien. Błądzili tedy po pustyniach i górach, [ukrywali się] po jaskiniach i rozpadlinach ziemi.
###### **Hbr 11,39**
 I choć wszyscy zasłużyli na najwyższe uznanie ze strony Boga, to jednak żaden z nich nie dożył wypełnienia się obietnic,
###### **Hbr 11,40**
 gdyż Bóg, który zgotował nam los lepszy, nie chciał, aby oni doszli bez nas do doskonałości.
# Hbr 11 WUJ
###### **Hbr 11,1**
 A wiara jest gruntem rzeczy tych, których się spodziewamy, wywodem rzeczy nie widzianych.
###### **Hbr 11,2**
 Abowiem w tej świadectwo otrzymali starzy.
###### **Hbr 11,3**
 Wiarą dochodzimy iż są sprawione wieki słowem Bożem: aby z niewidzialnych stały się widzialne.
###### **Hbr 11,4**
 Wiarą Abel obfitszą ofiarę ofiarował Bogu niźli Kain: przez którą świadectwo otrzymał iż był sprawiedliwy: gdyż Bóg świadectwo dał o darzech jego, i umarwszy przez nie jeszcze mówi.
###### **Hbr 11,5**
 Wiarą Henoch był przeniesion, aby śmierci nie oglądał, i nienajdował się, bo go przeniósł Bóg: abowiem przed przeniesieniem miał świadectwo iż się Bogu podobał.
###### **Hbr 11,6**
 A bez wiary niepodobna jest spodobać się Bogu. Abowiem przystępującemu do Boga, potrzeba wierzyć, iż jest: a iż jest oddawcą tym, którzy go szukają.
###### **Hbr 11,7**
 Wiarą Noe odpowiedź wziąwszy o tem czego jeszcze nie było widać, bojąc się, zgotował korab ku zachowaniu domu swego, przez który potępił świat: sprawiedliwości, która jest przez wiarę, dziedzicem jest uczyniony.
###### **Hbr 11,8**
 Wiarą, który, nazwany jest Abraham, usłuchał, aby wyszedł na miejsce, które w dziedzictwo wziąć miał: i wyszedł, niewiedząc dokąd szedł.
###### **Hbr 11,9**
 Wiarą mieszkał w ziemi obiecanej, jako w cudzej, mieszkając w namieciech z Izaakiem i Jakóbem spólnemi dziedzicmi tejże obietnice.
###### **Hbr 11,10**
 Abowiem oczekawał miasta fundamenty mającego: którego rzemieślnik i budownik Bóg.
###### **Hbr 11,11**
 Wiarą, i sama Sara niepłodna wzięła moc ku przyjęciu nasienia, i mimo czas wieku: iż wiernym być rozumiała tego co obiecał.
###### **Hbr 11,12**
 Przetoż i z jednego narodziło się a (to z obumarłego), w liczbie jako gwiazd niebieskich, i jako piasku niezliczonego, który jest na brzegu morskim.
###### **Hbr 11,13**
 Wedle wiary umarli ci wszyscy, niedostawszy obietnic, ale zdaleka je upatrując, i pozdrawiając, i wyznawając iż są gośćmi i przychodniami na ziemi.
###### **Hbr 11,14**
 Bo którzyć to mówią: okazują, iż ojczyzny szukają.
###### **Hbr 11,15**
 A jeśliby na one pamiętali, z której wyszli, mielić wżdy czas wrócić się.
###### **Hbr 11,16**
 Lecz teraz lepszej żądają, to jest, niebieskiej. Przetoż nie wstyda się Bóg nazywać się Bogiem ich, gdyż im miasto zgotował.
###### **Hbr 11,17**
 Wiarą, Abraham ofiarował Izaaka, gdy był kuszon: a ofiarował jednorodnego, który był wziął obietnicę:
###### **Hbr 11,18**
 (Do którego rzeczono, Iż w Izaaku tobie będzie nazwano nasienie).
###### **Hbr 11,19**
 Mając za to, iż Bóg może i z umarłych wzbudzić. Zkąd go też w podobieństwo wziął.
###### **Hbr 11,20**
 Wiarą, i w przyszłych rzeczach błogosławił Izaak Jakóba i Ezau.
###### **Hbr 11,21**
 Wiarą, Jakób umierając, każdemu z synów Józefowych błogosławił: i pokłonił się wierzchowi laski jego
###### **Hbr 11,22**
 Wiarą, Józef umierając, o wyszciu synów Izraelskich wspomionął, i około kości swoich rozkazał.
###### **Hbr 11,23**
 Wiarą, Mojżesza narodzonego kryli trzy miesiące rodzicy jego: przeto iż go widzieli pięknym dzieciątkiem, i nie bali się wyroku królewskiego.
###### **Hbr 11,24**
 Wiarą, Mojżesz stawszy się wielkim, nie znał się być synem córki Faraonowej:
###### **Hbr 11,25**
 Więcej obierając być utrapionym wespół z ludem Bożym, niźli mieć doczesnego grzechu rozkosz,
###### **Hbr 11,26**
 Za więtsze bogactwo poczytając urąganie Chrystusowe, niż skarby Egiptskie: bo się oglądał na odpłatę
###### **Hbr 11,27**
 Wiarą, opuścił Egipt: nie bojąc się gniewu królewskiego: abowiem niewidzialnego jakoby widząc oczekawał.
###### **Hbr 11,28**
 Wiarą, sprawił Paschę, i wylanie krwie: aby ten który pierworodne tracił, ich się nie dotknął.
###### **Hbr 11,29**
 Wiarą, przeszli morze Czerwone jako po suchej ziemi: czego doznawszy Egiptyanie, pożarci są.
###### **Hbr 11,30**
 Wiarą, mury Jerycha upadły, obeszciem siedmiu dni.
###### **Hbr 11,31**
 Wiarą, Rahab nierządnica nie zginęła z niewiernymi: przyjąwszy z pokojem szpiegi.
###### **Hbr 11,32**
 A cóż jeszcze mam mówić? Boć mi czasu nie stanie, gdybym rozpowiadał o Gedeonie, Baruchu, Samsonie, Jephte, Dawidzie, Samuelu, i prorocech:
###### **Hbr 11,33**
 Którzy przez wiarę zwalczyli królestwa, czynili sprawiedliwość, dostąpili obietnic, zawarli lwie paszczeki,
###### **Hbr 11,34**
 Zagasili gwałt ognia, uszli ostrza miecza, wzmogli z niemocy, mężnymi się stali na wojnie, obozy obcych odwracali:
###### **Hbr 11,35**
 Niewiasty wzięły swoje umarłe z zmartwychwstania. A drudzy byli ciągnieni, nie przyjąwszy odkupienia, aby lepsze zmartwychwstanie naleźli.
###### **Hbr 11,36**
 A drudzy doznali pośmiewisk i bicia, nadto i więzienia i ciemnic:
###### **Hbr 11,37**
 Byli kamienowani, przecinani, doświadczani, w zabiciu miecza pomarli, błąkali się w owczych, w kozich skórach, niedostateczni, uciśnieni, utrapieni:
###### **Hbr 11,38**
 Których nie był godzien świat, tułając się po puszczach po górach i jamach, i w jaskiniach ziemie.
###### **Hbr 11,39**
 A ci wszyscy świadectwem wiary doświadczeni, obietnice nie odnieśli.
###### **Hbr 11,40**
 Iż Bóg o nas coś lepszego przejrzał, aby nie bez nas byli doskonałymi uczynieni.
# Hbr 11 STERN
###### **Hbr 11,1**
 Ufanie to przeświadczenie o tym, na co mamy nadzieję, przekonanie o rzeczach, których nie widzimy.
###### **Hbr 11,2**
 To z tego względu Pismo zaświadczyło o zasłudze ludzi z dawnych czasów.
###### **Hbr 11,3**
 Przez ufanie rozumiemy, że wszechświat został stworzony przez wypowiedziane słowo Boga, tak że to, co widzimy, nie powstało ze zjawisk istniejących.
###### **Hbr 11,4**
 Przez ufanie Hewel złożył ofiarę lepszą niż Kain; z tego powodu został uznany za sprawiedliwego, o czym zaświadczył mu Bóg na podstawie jego darów. Przez to, że zaufał, on nadal przemawia, mimo że nie żyje.
###### **Hbr 11,5**
 Przez ufanie Chanoch został zabrany z tego życia, nie ujrzawszy śmierci - "nie można go było znaleźć, gdyż zabrał go Bóg" - bo zaświadczono o nim, że zanim go zabrano, podobał się Bogu.
###### **Hbr 11,6**
 A bez ufania niemożliwe jest podobać się Bogu, bo ktokolwiek do Niego przychodzi, musi ufać, że On istnieje i że dla tych, którzy Go odszukają, staje się On Tym, który nagradza.
###### **Hbr 11,7**
 Przez ufanie Noach, otrzymawszy Boskie ostrzeżenie o tym, czego nie było jeszcze widać, przepełniony świętą bojaźnią zbudował arkę, aby ocalić swój dom. Przez to ufanie wydał wyrok na świat i otrzymał sprawiedliwość, która pochodzi z ufania.
###### **Hbr 11,8**
 Przez ufanie okazał posłuszeństwo Awraham, wezwany, aby wyruszyć do miejsca, które Bóg miał mu dać w posiadanie. I istotnie, wyruszył, nie wiedząc, dokąd zmierza.
###### **Hbr 11,9**
 Przez ufanie żył jak przybysz w Ziemi obietnicy, jak gdyby nie należała ona do niego, mieszkając w namiotach z Jic'chakiem i Ja'akowem, którzy wraz z nim mieli otrzymać to, co obiecane.
###### **Hbr 11,10**
 Wypatrywał on bowiem miasta o trwałych fundamentach, którego architektem i budowniczym jest Bóg.
###### **Hbr 11,11**
 Przez ufanie otrzymał moc, aby spłodzić dziecko, mimo że upłynął już stosowny do tego wiek, podobnie jak u Sary; gdyż uważał za godnego wiary Tego, który dał obietnicę.
###### **Hbr 11,12**
 Dlatego ten jeden człowiek, nieomal martwy, spłodził potomków tak licznych jak gwiazdy na niebie i tak niezliczonych jak ziarnka piasku na brzegu morza.
###### **Hbr 11,13**
 Wszyscy ci ludzie nie przestawali ufać aż do śmierci, nie otrzymawszy tego, co było obiecane. Jedynie widzieli to i powitali z daleka, uznając się za przybyszów i pielgrzymów na ziemi.
###### **Hbr 11,14**
 Bo ludzie, którzy mówią w ten sposób, dają do zrozumienia, że szukają ojczyzny.
###### **Hbr 11,15**
 A gdyby wciąż wspominali tę, którą opuścili, mieliby okazję, aby tam powrócić;
###### **Hbr 11,16**
 w takiej jednak sytuacji dążą do lepszej ojczyzny, niebieskiej. Dlatego Bóg nie wstydzi się nazywać ich Bogiem, bo przygotował dla nich miasto.
###### **Hbr 11,17**
 Przez ufanie Awraham, gdy wystawiono go na próbę, złożył na ofiarę Jic'chaka. Tak jest, ofiarował jedynego syna, on, który otrzymał obietnice,
###### **Hbr 11,18**
 któremu powiedziano: "To, co zwie się twym "potomstwem", będzie w Jic'chaku".
###### **Hbr 11,19**
 Bo doszedł do wniosku, że Bóg może nawet wskrzeszać ludzi z martwych! I - mówiąc przenośnie - w taki sposób go otrzymał.
###### **Hbr 11,20**
 Przez ufanie Jic'chak w błogosławieństwach wypowiedzianych nad Ja'akowem i Esawem wspomniał o wydarzeniach, które miały dopiero nastąpić.
###### **Hbr 11,21**
 Przez ufanie Ja'akow, umierając, pobłogosławił każdego z synów Josefa, oparłszy się na swej lasce, gdy pochylił się w modlitwie.
###### **Hbr 11,22**
 Przez ufanie Josef u schyłku życia wspomniał o Wyjściu ludu Isra'ela i wydał polecenia, co uczynić z jego kośćmi.
###### **Hbr 11,23**
 Przez ufanie rodzice Moszego ukrywali go przez trzy miesiące po urodzeniu, bo widzieli, że jest pięknym dzieckiem, i nie lękali się dekretu króla.
###### **Hbr 11,24**
 Przez ufanie Mosze, gdy dorósł, nie zgodził się, aby go zwano synem córki faraona.
###### **Hbr 11,25**
 Wybrał poniewierkę wraz z ludem Bożym zamiast korzystania z przemijających rozkoszy grzechu.
###### **Hbr 11,26**
 Zniewagi, jakie cierpiał ze względu na Mesjasza, zaczął uważać za bogactwo większe niż skarby Egiptu, bo wzrok swój utkwił w nagrodzie.
###### **Hbr 11,27**
 Przez ufanie opuścił Egipt, nie lękając się gniewu króla; wytrwał jako ten, który widzi to, co niewidzialne.
###### **Hbr 11,28**
 Przez ufanie dochował posłuszeństwa nakazom Pesach, takim jak pomazanie krwią, aby Niszczyciel pierworodnych nie tknął pierworodnych Isra'ela.
###### **Hbr 11,29**
 Przez ufanie przeszli przez Morze Czerwone jak po suchym lądzie; gdy próbowali tego dokonać Egipcjanie, pochłonęło ich morze.
###### **Hbr 11,30**
 Przez ufanie padły mury Jericha, gdy lud przemaszerował wokół nich przez siedem dni.
###### **Hbr 11,31**
 Przez ufanie nierządnica Rachaw przyjęła szpiegów i dlatego nie zginęła wraz z tymi, którzy byli nieposłuszni.
###### **Hbr 11,32**
 Cóż mam rzec więcej? Nie ma już czasu, by mówić o Gid'onie, Baraku, Szimszonie, Jiftachu, Dawidzie, Sz'mu'elu i prorokach,
###### **Hbr 11,33**
 którzy przez ufanie zdobywali królestwa, czynili sprawiedliwość, otrzymywali, co obiecane, zamykali paszcze lwom,
###### **Hbr 11,34**
 gasili siłę ognia, umykali przed ostrzem miecza, słabości swe zmieniali w siłę, stawali się potężni w boju i rozgramiali obce wojska.
###### **Hbr 11,35**
 Kobiety swych zmarłych otrzymywały z powrotem, zmartwychwstałych; inni, poddawani męczarniom i bici na śmierć, nie przyjęli wybawienia, aby móc zyskać lepsze zmartwychwstanie.
###### **Hbr 11,36**
 Inni doświadczali szyderstw i biczowania, potem kajdan i więzienia.
###### **Hbr 11,37**
 Kamienowano ich, przerzynano piłą, zabijano mieczem. Chodzili odziani w owcze i kozie skóry, bez środków do życia, prześladowani, gnębieni,
###### **Hbr 11,38**
 błąkając się po pustyniach i górach, żyjąc w jaskiniach i jamach w ziemi! Świat nie był ich wart!
###### **Hbr 11,39**
 Wszystkim im zaświadczono o ich zasługach ze względu na ich ufanie. Mimo to nie otrzymali tego, co obiecane,
###### **Hbr 11,40**
 bo Bóg zaplanował coś lepszego, co obejmie i nas, tak że tylko wraz z nami będą oni doprowadzeni do celu.
# Hbr 11 TRO
###### **Hbr 11,1**
 **εστιν** *estin* Jest [[G2076]] WTV-PXI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **πιστις** *pistis* wiara [[G4102]] [[N-NSF]] **ελπιζομενων** *elpizomenōn* które są obiecanymi przez nadzieję [[G1679]] WTV-PPP-GPM **υποστασις** *hypostasis* zrozumienie – pewność [[G5287]] [[N-NSF]] **πραγματων** *pragmatōn* spraw [[G4229]] WTN-GPN **ελεγχος** *elegchos* wykazanie – przekonanie [[G1650]] [[N-NSM]] **ου** *ou* nie [[G3756]] [[PRT-N]] **βλεπομενων** *blepomenōn* które są widziane – które są obserwowane [[G991]] WTV-PPP-GPN
###### **Hbr 11,2**
 **εν** *en* przez [[G1722]] [[PREP]] **ταυτη** *tautē* tę [[G3778]] WTD-DSF **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εμαρτυρηθησαν** *emartyrēthēsan* otrzymali świadectwo [[G3140]] WTV-API-3P **οι** *hoi* [[G3588]] WTT-NPM **πρεσβυτεροι** *presbyteroi* starsi [[G4245]] WTA-NPM
###### **Hbr 11,3**
 **πιστει** *pistei* Wiarą [[G4102]] [[N-DSF]] **νοουμεν** *nooumen* rozumiemy – zauważamy [[G3539]] WTV-PAI-1P **κατηρτισθαι** *katērtisthai* (że) być wydoskonalone – (że) być umocnione [[G2675]] WTV-RPN **τους** *tous* [[G3588]] WTT-APM **αιωνας** *aiōnas* wieki [[G165]] [[N-APM]] **ρηματι** *rēmati* wypowiedzią [[G4487]] WTN-DSN **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* (temu, że) [[G3588]] WTT-ASN **μη** *mē* nie [[G3361]] [[PRT-N]] **εκ** *ek* z [[G1537]] [[PREP]] **φαινομενων** *fainomenōn* które są ukazane [[G5316]] WTV-PEP-GPN **τα** *ta* [[G3588]] WTT-NPN **βλεπομενα** *blepomena* które są widziane – które są obserwowane [[G991]] WTV-PPP-NPN **γεγονεναι** *gegonenai* stać się [[G1096]] WTV-2RAN
###### **Hbr 11,4**
 **πιστει** *pistei* Wiarą [[G4102]] [[N-DSF]] **πλειονα** *pleiona* więcej [[G4119]] WTA-ASF-C **θυσιαν** *thysian* ofiarę [[G2378]] WTN-ASF **αβελ** *abel* Abel – [tchnienie] [[G6]] [[N-PRI]] **παρα** *para* obok [[G3844]] [[PREP]] **καιν** *kain* Kaina – [prawd. włócznia] [[G2535]] [[N-PRI]] **προσηνεγκεν** *prosēnegken* przyniósł – ofiarował [[G4374]] [[V-AAI-3S]] **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **δι** *di* przez [[G1223]] [[PREP]] **ης** *hēs* którą [[G3739]] [[R-GSF]] **εμαρτυρηθη** *emartyrēthē* otrzymał świadectwo [[G3140]] [[V-API-3S]] **ειναι** *einai* (że) być [[G1511]] WTV-PXN **δικαιος** *dikaios* sprawiedliwy [[G1342]] [[A-NSM]] **μαρτυρουντος** *martyrountos* świadczący [[G3140]] WTV-PAP-GSM **επι** *epi* nad [[G1909]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPN **δωροις** *dōrois* darami – darami ofiarnymi [[G1435]] WTN-DPN **αυτου** *autou* jego [[G846]] [[P-GSM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Bogu [[G2316]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **δι** *di* przez [[G1223]] [[PREP]] **αυτης** *autēs* nią [[G846]] [[P-GSF]] **αποθανων** *apothanōn* umarłszy [[G599]] WTV-2AAP-NSM **ετι** *eti* jeszcze [[G2089]] [[ADV]] **λαλει** *lalei* mówi [[G2980]] WTV-PAI-3S
###### **Hbr 11,5**
 **πιστει** *pistei* Wiarą [[G4102]] [[N-DSF]] **ενωχ** *henōch* Henoch – [rozpoczynający] [[G1802]] [[N-PRI]] **μετετεθη** *metetethē* został przeniesiony – został przemieszczony [[G3346]] [[V-API-3S]] **του** *tou* [[G3588]] WTT-GSM **μη** *mē* nie [[G3361]] [[PRT-N]] **ιδειν** *idein* zobaczyć [[G1492]] [[V-2AAN]] **θανατον** *thanaton* śmierci [[G2288]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **ευρισκετο** *eurisketo* był znaleziony [[G2147]] WTV-IPI-3S **διοτι** *dioti* dlatego, że [[G1360]] [[CONJ]] **μετεθηκεν** *metethēken* przeniósł – przemieścił [[G3346]] [[V-AAI-3S]] **αυτον** *auton* go [[G846]] WTP-ASM **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **προ** *pro* przed [[G4253]] [[PREP]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **της** *tēs* [[G3588]] [[T-GSF]] **μεταθεσεως** *metatheseōs* przeniesieniem – przemieszczeniem [[G3331]] [[N-GSF]] **αυτου** *autou* go [[G846]] [[P-GSM]] **μεμαρτυρηται** *memartyrētai* otrzymał świadectwo [[G3140]] WTV-RPI-3S **ευηρεστηκεναι** *euērestēkenai* bardzo spodobać się [[G2100]] WTV-RAN **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM
###### **Hbr 11,6**
 **χωρις** *chōris* bez [[G5565]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **αδυνατον** *adynaton* niemożliwe [[G102]] WTA-NSN **ευαρεστησαι** *euarestēsai* bardzo spodobać się [[G2100]] [[V-AAN]] **πιστευσαι** *pisteusai* uwierzyć [[G4100]] [[V-AAN]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **δει** *dei* trzeba – jest konieczne [[G1163]] WTV-PQI-3S **τον** *ton* [[G3588]] [[T-ASM]] **προσερχομενον** *proserchomenon* podchodzący – zbliżający się [[G4334]] WTV-PNP-ASM **τω** *tō* (ku) [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **οτι** *hoti* że [[G3754]] [[CONJ]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **και** *kai* i [[G2532]] [[CONJ]] **τοις** *tois* (dla) [[G3588]] WTT-DPM **εκζητουσιν** *ekzētousin* szukających [[G1567]] WTV-PAP-DPM **αυτον** *auton* Go [[G846]] WTP-ASM **μισθαποδοτης** *misthapodotēs* nagradzający – odpłacający [[G3406]] [[N-NSM]] **γινεται** *ginetai* staje się [[G1096]] WTV-PNI-3S
###### **Hbr 11,7**
 **πιστει** *pistei* Wiarą [[G4102]] [[N-DSF]] **χρηματισθεις** *chrēmatistheis* zostawszy ostrzeżonym – otrzymawszy wyrocznię [[G5537]] WTV-APP-NSM **νωε** *nōe* Noe – [odpocząć] [[G3575]] [[N-PRI]] **περι** *peri* odnośnie [[G4012]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **μηδεπω** *mēdepō* jeszcze nie [[G3369]] [[ADV]] **βλεπομενων** *blepomenōn* które są widzialne – które są obserwowane [[G991]] WTV-PPP-GPN **ευλαβηθεις** *eulabētheis* przyjąwszy ze czcią – przyjąwszy pobożnie [[G2125]] WTV-APP-NSM **κατεσκευασεν** *kateskeuasen* zbudował [[G2680]] [[V-AAI-3S]] **κιβωτον** *kibōton* arkę – drewnianą skrzynię [[G2787]] WTN-ASF **εις** *eis* ku [[G1519]] [[PREP]] **σωτηριαν** *sōtērian* zbawieniu – wyzwoleniu [[G4991]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **οικου** *oikou* domu [[G3624]] [[N-GSM]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **δι** *di* przez [[G1223]] [[PREP]] **ης** *hēs* którą [[G3739]] [[R-GSF]] **κατεκρινεν** *katekrinen* potępił – zasądził [[G2632]] [[V-AAI-3S]] **τον** *ton* [[G3588]] [[T-ASM]] **κοσμον** *kosmon* świat [[G2889]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **της** *tēs* [[G3588]] [[T-GSF]] **κατα** *kata* według [[G2596]] [[PREP]] **πιστιν** *pistin* wiary [[G4102]] WTN-ASF **δικαιοσυνης** *dikaiosynēs* sprawiedliwości [[G1343]] [[N-GSF]] **εγενετο** *egeneto* stał się [[G1096]] WTV-2ADI-3S **κληρονομος** *klēronomos* dziedzic [[G2818]] [[N-NSM]]
###### **Hbr 11,8**
 **πιστει** *pistei* Wiarą [[G4102]] [[N-DSF]] **καλουμενος** *kaloumenos* który jest wzywany [[G2564]] [[V-PPP-NSM]] **αβρααμ** *abraam* Abraham – [ojciec wielu narodów] [[G11]] [[N-PRI]] **υπηκουσεν** *hypēkousen* okazał posłuszeństwo [[G5219]] [[V-AAI-3S]] **εξελθειν** *ekselthein* (by) wyjść [[G1831]] [[V-2AAN]] **εις** *eis* do [[G1519]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **τοπον** *topon* miejsca [[G5117]] [[N-ASM]] **ον** *hon* które [[G3739]] WTR-ASM **ημελλεν** *ēmellen* miał [[G3195]] WTV-IAI-3S-ATT **λαμβανειν** *lambanein* brać – wziąć [[G2983]] WTV-PAN **εις** *eis* do [[G1519]] [[PREP]] **κληρονομιαν** *klēronomian* dziedziczenia [[G2817]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **εξηλθεν** *eksēlthen* wyszedł [[G1831]] WTV-2AAI-3S **μη** *mē* nie [[G3361]] [[PRT-N]] **επισταμενος** *epistamenos* wiedząc [[G1987]] WTV-PNP-NSM **που** *pou* gdzie [[G4226]] WTPRT-I **ερχεται** *erchetai* przychodzi [[G2064]] WTV-PNI-3S
###### **Hbr 11,9**
 **πιστει** *pistei* Wiarą [[G4102]] [[N-DSF]] **παρωκησεν** *parōkēsen* zamieszkał – zamieszkał jako cudzoziemiec [[G3939]] [[V-AAI-3S]] **εις** *eis* względem [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **γην** *gēn* ziemi [[G1093]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **επαγγελιας** *epangelias* obietnicy [[G1860]] [[N-GSF]] **ως** *hōs* jak [[G5613]] [[ADV]] **αλλοτριαν** *allotrian* obcej – cudzej [[G245]] WTA-ASF **εν** *en* w [[G1722]] [[PREP]] **σκηναις** *skēnais* namiotach – przybytkach [[G4633]] WTN-DPF **κατοικησας** *katoikēsas* zamieszkawszy [[G2730]] WTV-AAP-NSM **μετα** *meta* z [[G3326]] [[PREP]] **ισαακ** *isaak* Izaakiem – [śmiać się] [[G2464]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **ιακωβ** *iakōb* Jakubem – [pięta] [[G2384]] [[N-PRI]] **των** *tōn* [[G3588]] WTT-GPM **συγκληρονομων** *sygklēronomōn* współdziedzicami [[G4789]] WTA-GPM **της** *tēs* [[G3588]] [[T-GSF]] **επαγγελιας** *epangelias* obietnicy [[G1860]] [[N-GSF]] **της** *tēs* [[G3588]] [[T-GSF]] **αυτης** *autēs* tej samej [[G846]] [[P-GSF]]
###### **Hbr 11,10**
 **εξεδεχετο** *eksedecheto* czekał [[G1551]] WTV-INI-3S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **την** *tēn* (na to) [[G3588]] WTT-ASF **τους** *tous* [[G3588]] WTT-APM **θεμελιους** *themelious* fundamenty [[G2310]] [[N-APM]] **εχουσαν** *echousan* mające [[G2192]] WTV-PAP-ASF **πολιν** *polin* miasto [[G4172]] WTN-ASF **ης** *hēs* którego [[G3739]] [[R-GSF]] **τεχνιτης** *technitēs* architekt – rzemieślnik [[G5079]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **δημιουργος** *dēmiourgos* budowniczy – twórca [[G1217]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]]
###### **Hbr 11,11**
 **πιστει** *pistei* Wiarą [[G4102]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **αυτη** *autē* ta [[G846]] WTP-NSF **σαρρα** *sarra* Sara – [księżniczka] [[G4564]] [[N-NSF]] **δυναμιν** *dynamin* moc [[G1411]] WTN-ASF **εις** *eis* ku [[G1519]] [[PREP]] **καταβολην** *katabolēn* zasiewu [[G2602]] WTN-ASF **σπερματος** *spermatos* nasienia [[G4690]] [[N-GSN]] **ελαβεν** *elaben* wzięła – otrzymała [[G2983]] WTV-2AAI-3S **και** *kai* i [[G2532]] [[CONJ]] **παρα** *para* wbrew [[G3844]] [[PREP]] **καιρον** *kairon* stosownej porze [[G2540]] [[N-ASM]] **ηλικιας** *hēlikias* dojrzałości – wiekowi [[G2244]] [[N-GSF]] **ετεκεν** *eteken* urodziła [[G5088]] WTV-2AAI-3S **επει** *epei* skoro – jako, że [[G1893]] [[CONJ]] **πιστον** *piston* wiernym – godnym wiary [[G4103]] WTA-ASM **ηγησατο** *hēgēsato* uznała [[G2233]] WTV-ADI-3S **τον** *ton* (Tego) [[G3588]] [[T-ASM]] **επαγγειλαμενον** *epangeilamenon* który obiecał [[G1861]] WTV-ADP-ASM
###### **Hbr 11,12**
 **διο** *dio* Dlatego [[G1352]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **αφ** *af* z [[G575]] [[PREP]] **ενος** *henos* jednego [[G1520]] WTA-GSM **εγεννηθησαν** *egennēthēsan* zostali zrodzeni [[G1080]] WTV-API-3P **και** *kai* i [[G2532]] [[CONJ]] **ταυτα** *tauta* te [[G5023]] WTD-NPN **νενεκρωμενου** *nenekrōmenou* który jest uczyniony martwym [[G3499]] WTV-RPP-GSM **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **τα** *ta* [[G3588]] WTT-NPN **αστρα** *astra* gwiazdy [[G798]] WTN-NPN **του** *tou* [[G3588]] WTT-GSM **ουρανου** *ouranou* nieba [[G3772]] [[N-GSM]] **τω** *tō* (co do) [[G3588]] WTT-DSN **πληθει** *plēthei* mnóstwa – mnogości [[G4128]] WTN-DSN **και** *kai* i [[G2532]] [[CONJ]] **ωσει** *hōsei* jakby [[G5616]] [[ADV]] **αμμος** *ammos* piasek [[G285]] [[N-NSF]] **η** *hē* (ten) [[G3588]] [[T-NSF]] **παρα** *para* na [[G3844]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **χειλος** *cheilos* wardze [[G5491]] WTN-ASN **της** *tēs* [[G3588]] [[T-GSF]] **θαλασσης** *thalassēs* morza [[G2281]] [[N-GSF]] **η** *hē* (ten) [[G3588]] [[T-NSF]] **αναριθμητος** *anarithmētos* niezliczony [[G382]] WTA-NSF
###### **Hbr 11,13**
 **κατα** *kata* Według [[G2596]] [[PREP]] **πιστιν** *pistin* wiary [[G4102]] WTN-ASF **απεθανον** *apethanon* umarli [[G599]] WTV-2AAI-3P **ουτοι** *houtoi* ci [[G3778]] WTD-NPM **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **μη** *mē* nie [[G3361]] [[PRT-N]] **λαβοντες** *labontes* wziąwszy [[G2983]] WTV-2AAP-NPM **τας** *tas* [[G3588]] WTT-APF **επαγγελιας** *epangelias* obietnic [[G1860]] WTN-APF **αλλα** *alla* ale [[G235]] [[CONJ]] **πορρωθεν** *porrōthen* z daleka [[G4207]] [[ADV]] **αυτας** *autas* je [[G846]] WTP-APF **ιδοντες** *idontes* zobaczywszy [[G1492]] WTV-2AAP-NPM **και** *kai* i [[G2532]] [[CONJ]] **πεισθεντες** *peisthentes* zostawszy przekonanymi [[G3982]] WTV-APP-NPM **και** *kai* i [[G2532]] [[CONJ]] **ασπασαμενοι** *aspasamenoi* pozdrowiwszy [[G782]] WTV-ADP-NPM **και** *kai* i [[G2532]] [[CONJ]] **ομολογησαντες** *homologēsantes* wyznawszy [[G3670]] WTV-AAP-NPM **οτι** *hoti* że [[G3754]] [[CONJ]] **ξενοι** *ksenoi* obcy – cudzoziemcy [[G3581]] WTA-NPM **και** *kai* i [[G2532]] [[CONJ]] **παρεπιδημοι** *parepidēmoi* obcokrajowcy [[G3927]] WTA-NPM **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **επι** *epi* na [[G1909]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]]
###### **Hbr 11,14**
 **οι** *hoi* [[G3588]] WTT-NPM **γαρ** *gar* Bowiem [[G1063]] [[CONJ]] **τοιαυτα** *toiauta* w taki sposób [[G5108]] WTD-APN **λεγοντες** *legontes* mówiąc [[G3004]] WTV-PAP-NPM **εμφανιζουσιν** *emfanizousin* objawia się – czyni się widocznym [[G1718]] WTV-PAI-3P **οτι** *hoti* że [[G3754]] [[CONJ]] **πατριδα** *patrida* ojczyzny [[G3968]] WTN-ASF **επιζητουσιν** *epizētousin* poszukują [[G1934]] WTV-PAI-3P
###### **Hbr 11,15**
 **και** *kai* I [[G2532]] [[CONJ]] **ει** *ei* jeśli [[G1487]] WTCOND **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **εκεινης** *ekeinēs* tej [[G1565]] WTD-GSF **εμνημονευον** *emnēmoneuon* pamiętali – przypomnieli sobie [[G3421]] WTV-IAI-3P **αφ** *af* z [[G575]] [[PREP]] **ης** *hēs* której [[G3739]] [[R-GSF]] **εξηλθον** *eksēlthon* wyszli [[G1831]] WTV-2AAI-3P **ειχον** *eichon* mieli [[G2192]] WTV-IAI-3P **αν** *an* (kiedy)kolwiek [[G302]] WTPRT **καιρον** *kairon* porę [[G2540]] [[N-ASM]] **ανακαμψαι** *anakampsai* zawrócić [[G344]] [[V-AAN]]
###### **Hbr 11,16**
 **νυνι** *nyni* teraz [[G3570]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **κρειττονος** *kreittonos* lepszej – znaczniejszej [[G2909]] WTA-GSF **ορεγονται** *oregontai* pragną – sięgają [[G3713]] WTV-PMI-3P **τουτ** *tout* to [[G5124]] WTD-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **επουρανιου** *epouraniou* niebiańskiego [[G2032]] WTA-GSF **διο** *dio* dlatego [[G1352]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **επαισχυνεται** *epaischynetai* wstydzi się [[G1870]] WTV-PNI-3S **αυτους** *autous* ich [[G846]] [[P-APM]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **θεος** *theos* (jako) Bóg [[G2316]] [[N-NSM]] **επικαλεισθαι** *epikaleisthai* być przywoływany [[G1941]] WTV-PPN **αυτων** *autōn* ich [[G846]] WTP-GPM **ητοιμασεν** *hētoimasen* przygotował [[G2090]] [[V-AAI-3S]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **αυτοις** *autois* im [[G846]] WTP-DPM **πολιν** *polin* miasto [[G4172]] WTN-ASF
###### **Hbr 11,17**
 **πιστει** *pistei* Wiarą [[G4102]] [[N-DSF]] **προσενηνοχεν** *prosenēnochen* przyniósł – ofiarował [[G4374]] WTV-2RAI-3S-ATT **αβρααμ** *abraam* Abraham – [ojciec wielu narodów] [[G11]] [[N-PRI]] **τον** *ton* [[G3588]] [[T-ASM]] **ισαακ** *isaak* Izaaka – [śmiać się] [[G2464]] [[N-PRI]] **πειραζομενος** *peirazomenos* który jest doświadczany – który jest poddawany próbie [[G3985]] [[V-PPP-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **τον** *ton* [[G3588]] [[T-ASM]] **μονογενη** *monogenē* jednorodzonego – jedynaka [[G3439]] WTA-ASM **προσεφερεν** *proseferen* przynosił – ofiarowywał [[G4374]] WTV-IAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **τας** *tas* [[G3588]] WTT-APF **επαγγελιας** *epangelias* obietnice [[G1860]] WTN-APF **αναδεξαμενος** *anadeksamenos* przyjąwszy – otrzymawszy [[G324]] WTV-ADP-NSM
###### **Hbr 11,18**
 **προς** *pros* do [[G4314]] [[PREP]] **ον** *hon* którego [[G3739]] WTR-ASM **ελαληθη** *elalēthē* zostało powiedziane [[G2980]] [[V-API-3S]] **οτι** *hoti* że [[G3754]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **ισαακ** *isaak* Izaaku – [śmiać się] [[G2464]] [[N-PRI]] **κληθησεται** *klēthēsetai* zostanie nazwane – zostanie zwane [[G2564]] WTV-FPI-3S **σοι** *soi* tobie [[G4671]] WTP-2DS **σπερμα** *sperma* nasienie [[G4690]] WTN-NSN
###### **Hbr 11,19**
 **λογισαμενος** *logisamenos* poczytawszy – policzywszy [[G3049]] WTV-ADP-NSM **οτι** *hoti* że [[G3754]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **εκ** *ek* z [[G1537]] [[PREP]] **νεκρων** *nekrōn* martwych [[G3498]] WTA-GPM **εγειρειν** *egeirein* wzbudzać – podnosić [[G1453]] WTV-PAN **δυνατος** *dynatos* mocny [[G1415]] [[A-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **οθεν** *hothen* dlatego – stąd [[G3606]] [[ADV]] **αυτον** *auton* go [[G846]] WTP-ASM **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* ku [[G1722]] [[PREP]] **παραβολη** *parabolē* przykładowi – porównaniu [[G3850]] [[N-DSF]] **εκομισατο** *ekomisato* dostał – odebrał [[G2865]] WTV-AMI-3S
###### **Hbr 11,20**
 **πιστει** *pistei* Wiarą [[G4102]] [[N-DSF]] **περι** *peri* około [[G4012]] [[PREP]] **μελλοντων** *mellontōn* mających nastąpić [[G3195]] WTV-PAP-GPN **ευλογησεν** *eulogēsen* pobłogosławił – wysławił [[G2127]] [[V-AAI-3S]] **ισαακ** *isaak* Izaak – [śmiać się] [[G2464]] [[N-PRI]] **τον** *ton* [[G3588]] [[T-ASM]] **ιακωβ** *iakōb* Jakuba – [pięta] [[G2384]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **τον** *ton* [[G3588]] [[T-ASM]] **ησαυ** *ēsau* Ezawa – [owłosiony] [[G2269]] [[N-PRI]]
###### **Hbr 11,21**
 **πιστει** *pistei* Wiarą [[G4102]] [[N-DSF]] **ιακωβ** *iakōb* Jakub – [pięta] [[G2384]] [[N-PRI]] **αποθνησκων** *apothnēskōn* umierając [[G599]] [[V-PAP-NSM]] **εκαστον** *hekaston* każdego [[G1538]] WTA-ASM **των** *tōn* (z) [[G3588]] WTT-GPM **υιων** *hyiōn* synów [[G5207]] WTN-GPM **ιωσηφ** *iōsēf* Józefa – [On powiększył] [[G2501]] [[N-PRI]] **ευλογησεν** *eulogēsen* pobłogosławił – wysławił [[G2127]] [[V-AAI-3S]] **και** *kai* i [[G2532]] [[CONJ]] **προσεκυνησεν** *prosekynēsen* oddał cześć – pokłonił się [[G4352]] [[V-AAI-3S]] **επι** *epi* przed [[G1909]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **ακρον** *akron* skrajem [[G206]] WTN-ASN **της** *tēs* [[G3588]] [[T-GSF]] **ραβδου** *rabdou* laski [[G4464]] [[N-GSF]] **αυτου** *autou* jego [[G846]] [[P-GSM]]
###### **Hbr 11,22**
 **πιστει** *pistei* Wiarą [[G4102]] [[N-DSF]] **ιωσηφ** *iōsēf* Józef – [On powiększył] [[G2501]] [[N-PRI]] **τελευτων** *teleutōn* umierając [[G5053]] [[V-PAP-NSM]] **περι** *peri* o [[G4012]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **εξοδου** *eksodou* odejściu – wyjściu [[G1841]] [[N-GSF]] **των** *tōn* [[G3588]] WTT-GPM **υιων** *hyiōn* synów [[G5207]] WTN-GPM **ισραηλ** *israēl* Izraela – [ten, który walczył z Bogiem] [[G2474]] [[N-PRI]] **εμνημονευσεν** *emnēmoneusen* pamiętał – przypomniał sobie [[G3421]] [[V-AAI-3S]] **και** *kai* i [[G2532]] [[CONJ]] **περι** *peri* o [[G4012]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **οστεων** *osteōn* kościach [[G3747]] WTN-GPN **αυτου** *autou* jego [[G846]] [[P-GSM]] **ενετειλατο** *eneteilato* przykazał [[G1781]] WTV-ADI-3S
###### **Hbr 11,23**
 **πιστει** *pistei* Wiarą [[G4102]] [[N-DSF]] **μωσης** *mōsēs* Mojżesz – [wyciągnąć] [[G3475]] [[N-NSM]] **γεννηθεις** *gennētheis* który został zrodzony [[G1080]] WTV-APP-NSM **εκρυβη** *ekrybē* został ukryty [[G2928]] WTV-2API-3S **τριμηνον** *trimēnon* (przez) trzy miesiące [[G5150]] WTA-ASN **υπο** *hypo* przez [[G5259]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **πατερων** *paterōn* ojców [[G3962]] WTN-GPM **αυτου** *autou* jego [[G846]] [[P-GSM]] **διοτι** *dioti* dlatego, że [[G1360]] [[CONJ]] **ειδον** *eidon* zobaczyli [[G1492]] WTV-2AAI-3P **αστειον** *asteion* miłe – piękne [[G791]] WTA-ASN **το** *to* (to) [[G3588]] WTT-ASN **παιδιον** *paidion* dzieciątko – małe dziecko [[G3813]] WTN-ASN **και** *kai* i [[G2532]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εφοβηθησαν** *efobēthēsan* przestraszyli się – bali się [[G5399]] WTV-AOI-3P **το** *to* [[G3588]] WTT-ASN **διαταγμα** *diatagma* rozkazu – rozporządzenia [[G1297]] WTN-ASN **του** *tou* [[G3588]] WTT-GSM **βασιλεως** *basileōs* króla [[G935]] [[N-GSM]]
###### **Hbr 11,24**
 **πιστει** *pistei* Wiarą [[G4102]] [[N-DSF]] **μωσης** *mōsēs* Mojżesz – [wyciągnąć] [[G3475]] [[N-NSM]] **μεγας** *megas* wielki [[G3173]] [[A-NSM]] **γενομενος** *genomenos* który stał się [[G1096]] WTV-2ADP-NSM **ηρνησατο** *ērnēsato* nie zgodził się – odrzucił [[G720]] WTV-ADI-3S **λεγεσθαι** *legesthai* być nazywanym [[G3004]] WTV-PPN **υιος** *hyios* syn [[G5207]] [[N-NSM]] **θυγατρος** *thygatros* córki [[G2364]] [[N-GSF]] **φαραω** *faraō* faraona [[G5328]] [[N-PRI]]
###### **Hbr 11,25**
 **μαλλον** *mallon* bardziej [[G3123]] [[ADV]] **ελομενος** *helomenos* wybrawszy sobie [[G138]] WTV-2AMP-NSM **συγκακουχεισθαι** *sygkakoucheisthai* doznawać krzywd razem z [[G4778]] WTV-PNN **τω** *tō* [[G3588]] WTT-DSM **λαω** *laō* ludem [[G2992]] WTN-DSM **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **η** *ē* niż [[G2228]] WTPRT **προσκαιρον** *proskairon* chwilowe [[G4340]] WTA-ASF **εχειν** *echein* mieć [[G2192]] WTV-PAN **αμαρτιας** *hamartias* grzechu [[G266]] [[N-GSF]] **απολαυσιν** *apolausin* wykorzystanie [[G619]] WTN-ASF
###### **Hbr 11,26**
 **μειζονα** *meizona* (za) większe [[G3173]] WTA-ASM-C **πλουτον** *plouton* bogactwo [[G4149]] [[N-ASM]] **ηγησαμενος** *hēgēsamenos* uznawszy [[G2233]] WTV-ADP-NSM **των** *tōn* [[G3588]] WTT-GPM **εν** *en* od [[G1722]] [[PREP]] **αιγυπτω** *aigyptō* Egiptu – [lud Nilu] [[G125]] [[N-DSF]] **θησαυρων** *thēsaurōn* skarbów [[G2344]] WTN-GPM **τον** *ton* [[G3588]] [[T-ASM]] **ονειδισμον** *oneidismon* zniewagę – obelgę [[G3680]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **απεβλεπεν** *apeblepen* spoglądał – kierował wzrok [[G578]] WTV-IAI-3S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εις** *eis* na [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **μισθαποδοσιαν** *misthapodosian* odpłatę – zapłatę [[G3405]] WTN-ASF
###### **Hbr 11,27**
 **πιστει** *pistei* Wiarą [[G4102]] [[N-DSF]] **κατελιπεν** *katelipen* pozostawił – opuścił [[G2641]] WTV-2AAI-3S **αιγυπτον** *aigypton* Egipt – [lud Nilu] [[G125]] WTN-ASF **μη** *mē* nie [[G3361]] [[PRT-N]] **φοβηθεις** *fobētheis* przestraszywszy się – zląkłszy się [[G5399]] WTV-AOP-NSM **τον** *ton* [[G3588]] [[T-ASM]] **θυμον** *thymon* wzburzenia – szału [[G2372]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **βασιλεως** *basileōs* króla [[G935]] [[N-GSM]] **τον** *ton* [[G3588]] [[T-ASM]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **αορατον** *aoraton* niewidzialne [[G517]] WTA-ASM **ως** *hōs* jak [[G5613]] [[ADV]] **ορων** *horōn* widząc [[G3708]] [[V-PAP-NSM]] **εκαρτερησεν** *ekarterēsen* stał się wytrwałym [[G2594]] [[V-AAI-3S]]
###### **Hbr 11,28**
 **πιστει** *pistei* Wiarą [[G4102]] [[N-DSF]] **πεποιηκεν** *pepoiēken* czynił [[G4160]] WTV-RAI-3S **το** *to* [[G3588]] WTT-ASN **πασχα** *pascha* Paschę – [przejście] [[G3957]] WTARAM **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **προσχυσιν** *proschysin* polanie – wylanie [[G4378]] WTN-ASF **του** *tou* [[G3588]] WTT-GSN **αιματος** *haimatos* krwią [[G129]] [[N-GSN]] **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **ο** *ho* [[G3588]] [[T-NSM]] **ολοθρευων** *olothreuōn* niszczący – gubiący [[G3645]] [[V-PAP-NSM]] **τα** *ta* [[G3588]] WTT-APN **πρωτοτοκα** *prōtotoka* pierworodne [[G4416]] WTA-APN **θιγη** *thigē* dotknąłby [[G2345]] WTV-2AAS-3S **αυτων** *autōn* ich [[G846]] WTP-GPM
###### **Hbr 11,29**
 **πιστει** *pistei* Wiarą [[G4102]] [[N-DSF]] **διεβησαν** *diebēsan* przeszli [[G1224]] WTV-2AAI-3P **την** *tēn* [[G3588]] WTT-ASF **ερυθραν** *erythran* Czerwone [[G2063]] WTA-ASF **θαλασσαν** *thalassan* Morze [[G2281]] WTN-ASF **ως** *hōs* jak [[G5613]] [[ADV]] **δια** *dia* przez [[G1223]] [[PREP]] **ξηρας** *ksēras* suchą [[G3584]] [[N-GSF]] **ης** *hēs* którego [[G3739]] [[R-GSF]] **πειραν** *peiran* próbę – doświadczenie [[G3984]] WTN-ASF **λαβοντες** *labontes* wziąwszy [[G2983]] WTV-2AAP-NPM **οι** *hoi* [[G3588]] WTT-NPM **αιγυπτιοι** *aigyptioi* Egipcjanie [[G124]] WTA-NPM **κατεποθησαν** *katepothēsan* zostali pochłonięci [[G2666]] WTV-API-3P
###### **Hbr 11,30**
 **πιστει** *pistei* Wiarą [[G4102]] [[N-DSF]] **τα** *ta* [[G3588]] WTT-NPN **τειχη** *teichē* mury [[G5038]] WTN-NPN **ιεριχω** *ierichō* Jerycha [[G2410]] [[N-PRI]] **επεσεν** *epesen* upadły [[G4098]] WTV-2AAI-3S **κυκλωθεντα** *kyklōthenta* które zostały okrążone – które zostały otoczone [[G2944]] WTV-APP-NPN **επι** *epi* przez [[G1909]] [[PREP]] **επτα** *hepta* siedem [[G2033]] WTA-NUI **ημερας** *hēmeras* dni [[G2250]] WTN-APF
###### **Hbr 11,31**
 **πιστει** *pistei* Wiarą [[G4102]] [[N-DSF]] **ρααβ** *raab* Rachab – [duma] [[G4460]] [[N-PRI]] **η** *hē* [[G3588]] [[T-NSF]] **πορνη** *pornē* nierządnica – wszetecznica [[G4204]] [[N-NSF]] **ου** *ou* nie [[G3756]] [[PRT-N]] **συναπωλετο** *synapōleto* zginęła razem z [[G4881]] WTV-2AMI-3S **τοις** *tois* (tymi) [[G3588]] WTT-DPM **απειθησασιν** *apeithēsasin* którzy byli nieposłuszni – którzy nie ulegli [[G544]] WTV-AAP-DPM **δεξαμενη** *deksamenē* przyjąwszy [[G1209]] WTV-ADP-NSF **τους** *tous* [[G3588]] WTT-APM **κατασκοπους** *kataskopous* szpiegów – zwiadowców [[G2685]] [[N-APM]] **μετ** *met* wśród [[G3326]] [[PREP]] **ειρηνης** *eirēnēs* pokoju [[G1515]] [[N-GSF]]
###### **Hbr 11,32**
 **και** *kai* I [[G2532]] [[CONJ]] **τι** *ti* co [[G5101]] WTI-ASN **ετι** *eti* jeszcze [[G2089]] [[ADV]] **λεγω** *legō* mówiłbym [[G3004]] WTV-PAS-1S **επιλειψει** *epileipsei* zabraknie [[G1952]] WTV-FAI-3S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **με** *me* mi [[G3165]] WTP-1AS **διηγουμενον** *diēgoumenon* który jest opisywany [[G1334]] WTV-PNP-ASM **ο** *ho* [[G3588]] [[T-NSM]] **χρονος** *chronos* czas [[G5550]] [[N-NSM]] **περι** *peri* o [[G4012]] [[PREP]] **γεδεων** *gedeōn* Gedeonie – [ten, który ścina] [[G1066]] [[N-PRI]] **βαρακ** *barak* Baraku – [błyskawica] [[G913]] [[N-PRI]] **τε** *te* zarówno – także [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **σαμψων** *sampsōn* Samsonie – [człowiek słońca] [[G4546]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **ιεφθαε** *iefthae* Jeftem – [otwierać] [[G2422]] [[N-PRI]] **δαβιδ** *dabid* Dawidzie – [umiłowany] [[G1138]] [[N-PRI]] **τε** *te* zarówno – także [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **σαμουηλ** *samouēl* Samuelu – [imię Boga] [[G4545]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPM **προφητων** *profētōn* prorokach [[G4396]] WTN-GPM
###### **Hbr 11,33**
 **οι** *hoi* którzy [[G3739]] WTR-NPM **δια** *dia* przez [[G1223]] [[PREP]] **πιστεως** *pisteōs* wiarę [[G4102]] [[N-GSF]] **κατηγωνισαντο** *katēgōnisanto* zwalczyli [[G2610]] WTV-ADI-3P **βασιλειας** *basileias* królestwa [[G932]] WTN-APF **ειργασαντο** *eirgasanto* wypracowali [[G2038]] WTV-ADI-3P **δικαιοσυνην** *dikaiosynēn* sprawiedliwość [[G1343]] WTN-ASF **επετυχον** *epetychon* osiągnęli [[G2013]] WTV-2AAI-2P **επαγγελιων** *epangeliōn* obietnice [[G1860]] WTN-GPF **εφραξαν** *efraksan* zatrzymali – pohamowali [[G5420]] WTV-AAI-3P **στοματα** *stomata* usta – paszcze [[G4750]] WTN-APN **λεοντων** *leontōn* lwów [[G3023]] WTN-GPM
###### **Hbr 11,34**
 **εσβεσαν** *esbesan* ugasili [[G4570]] WTV-AAI-3P **δυναμιν** *dynamin* moc [[G1411]] WTN-ASF **πυρος** *pyros* ognia [[G4442]] [[N-GSN]] **εφυγον** *efygon* uciekli [[G5343]] WTV-2AAI-3P **στοματα** *stomata* (przed) ostrzem – (przed) ustami [[G4750]] WTN-APN **μαχαιρας** *machairas* miecza [[G3162]] [[N-GSF]] **ενεδυναμωθησαν** *enedynamōthēsan* zostali umocnieni – zostali napełnieni mocą [[G1743]] WTV-API-3P **απο** *apo* ze [[G575]] [[PREP]] **ασθενειας** *astheneias* słabości – bezsiły [[G769]] [[N-GSF]] **εγενηθησαν** *egenēthēsan* stali się [[G1096]] WTV-AOI-3P **ισχυροι** *ischyroi* mocni – silni [[G2478]] WTA-NPM **εν** *en* na [[G1722]] [[PREP]] **πολεμω** *polemō* wojnie – bitwie [[G4171]] WTN-DSM **παρεμβολας** *parembolas* obozy – hufce [[G3925]] WTN-APF **εκλιναν** *eklinan* zmusili do odwrotu – doprowadzili do upadku [[G2827]] WTV-AAI-3P **αλλοτριων** *allotriōn* obcych [[G245]] WTA-GPM
###### **Hbr 11,35**
 **ελαβον** *elabon* otrzymały – wzięli [[G2983]] WTV-2AAI-3P **γυναικες** *gynaikes* kobiety [[G1135]] [[N-NPF]] **εξ** *eks* z [[G1537]] [[PREP]] **αναστασεως** *anastaseōs* powstania – wzbudzenia [[G386]] [[N-GSF]] **τους** *tous* [[G3588]] WTT-APM **νεκρους** *nekrous* martwych [[G3498]] WTA-APM **αυτων** *autōn* ich [[G846]] WTP-GPF **αλλοι** *alloi* inni [[G243]] WTA-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **ετυμπανισθησαν** *etympanisthēsan* zostali torturowani – zostali zamęczeni [[G5178]] WTV-API-3P **ου** *ou* nie [[G3756]] [[PRT-N]] **προσδεξαμενοι** *prosdeksamenoi* przyjąwszy – spodziewając się [[G4327]] WTV-ADP-NPM **την** *tēn* [[G3588]] WTT-ASF **απολυτρωσιν** *apolytrōsin* odkupienie [[G629]] WTN-ASF **ινα** *hina* aby [[G2443]] [[CONJ]] **κρειττονος** *kreittonos* lepsze – znaczniejsze [[G2909]] WTA-GSF **αναστασεως** *anastaseōs* powstanie – wzbudzenie [[G386]] [[N-GSF]] **τυχωσιν** *tychōsin* uzyskaliby – dostąpiliby [[G5177]] WTV-2AAS-3P
###### **Hbr 11,36**
 **ετεροι** *heteroi* inni [[G2087]] WTA-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **εμπαιγμων** *empaigmōn* szydzeń – kpin [[G1701]] WTN-GPM **και** *kai* i [[G2532]] [[CONJ]] **μαστιγων** *mastigōn* udręk [[G3148]] WTN-GPF **πειραν** *peiran* próbę – doświadczenie [[G3984]] WTN-ASF **ελαβον** *elabon* przyjęli – otrzymali [[G2983]] WTV-2AAI-3P **ετι** *eti* jeszcze [[G2089]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **δεσμων** *desmōn* więzów [[G1199]] WTN-GPM **και** *kai* i [[G2532]] [[CONJ]] **φυλακης** *fylakēs* strażnicy – więzienia [[G5438]] [[N-GSF]]
###### **Hbr 11,37**
 **ελιθασθησαν** *elithasthēsan* zostali ukamienowani [[G3034]] WTV-API-3P **επρισθησαν** *epristhēsan* zostali przecięci – zostali przerzynani piłą [[G4249]] WTV-API-3P **επειρασθησαν** *epeirasthēsan* byli doświadczani – byli wystawiani na próbę [[G3985]] WTV-API-3P **εν** *en* przez [[G1722]] [[PREP]] **φονω** *fonō* morderstwo [[G5408]] WTN-DSM **μαχαιρας** *machairas* miecza [[G3162]] [[N-GSF]] **απεθανον** *apethanon* umarli [[G599]] WTV-2AAI-3P **περιηλθον** *periēlthon* obeszli wkoło [[G4022]] WTV-2AAI-3P **εν** *en* w [[G1722]] [[PREP]] **μηλωταις** *mēlōtais* owczych skórach [[G3374]] WTN-DPF **εν** *en* w [[G1722]] [[PREP]] **αιγειοις** *aigeiois* kozich [[G122]] WTA-DPN **δερμασιν** *dermasin* skórach [[G1192]] WTN-DPN **υστερουμενοι** *hysteroumenoi* którzy mają niedostatki [[G5302]] WTV-PPP-NPM **θλιβομενοι** *thlibomenoi* którzy są uciskani – którzy są trapieni [[G2346]] WTV-PPP-NPM **κακουχουμενοι** *kakouchoumenoi* którym wyrządza się zło – którzy są krzywdzeni [[G2558]] WTV-PPP-NPM
###### **Hbr 11,38**
 **ων** *hōn* których [[G3739]] WTR-GPM **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **αξιος** *aksios* godny [[G514]] [[A-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **κοσμος** *kosmos* świat [[G2889]] [[N-NSM]] **εν** *en* na [[G1722]] [[PREP]] **ερημιαις** *erēmiais* pustkowiach [[G2047]] WTN-DPF **πλανωμενοι** *planōmenoi* którzy są przymuszeni do błąkania się (po) [[G4105]] WTV-PPP-NPM **και** *kai* i [[G2532]] [[CONJ]] **ορεσιν** *oresin* górach [[G3735]] WTN-DPN **και** *kai* i [[G2532]] [[CONJ]] **σπηλαιοις** *spēlaiois* jaskiniach [[G4693]] WTN-DPN **και** *kai* i [[G2532]] [[CONJ]] **ταις** *tais* [[G3588]] WTT-DPF **οπαις** *opais* szczelinach [[G3692]] WTN-DPF **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]]
###### **Hbr 11,39**
 **και** *kai* I [[G2532]] [[CONJ]] **ουτοι** *houtoi* ci [[G3778]] WTD-NPM **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **μαρτυρηθεντες** *martyrēthentes* którzy zostali poświadczeni [[G3140]] WTV-APP-NPM **δια** *dia* przez [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **πιστεως** *pisteōs* wiarę [[G4102]] [[N-GSF]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εκομισαντο** *ekomisanto* dostali – odebrali [[G2865]] WTV-AMI-3P **την** *tēn* [[G3588]] WTT-ASF **επαγγελιαν** *epangelian* obietnicy [[G1860]] WTN-ASF
###### **Hbr 11,40**
 **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **περι** *peri* odnośnie [[G4012]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP **κρειττον** *kreitton* lepsze – znaczniejsze [[G2909]] WTA-ASN **τι** *ti* coś [[G5100]] WTX-ASN **προβλεψαμενου** *problepsamenou* który przewidział – który doprowadził [[G4265]] WTV-AMP-GSM **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **χωρις** *chōris* bez [[G5565]] [[ADV]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP **τελειωθωσιν** *teleiōthōsin* zostaliby uczynieni doskonałymi – zostaliby doprowadzeni do doskonałości [[G5048]] WTV-APS-3P
