# 2Kor 9 BT5
###### **2Kor 9,1**
 O posłudze zaś, którą się pełni dla świętych, nie potrzebuję wam pisać.
###### **2Kor 9,2**
 Znam bowiem waszą gorliwość, dzięki której chlubię się wami wśród Macedończyków: «***Achaja gotowa jest już od zeszłego roku***». I tak wasza gorliwość pobudziła wielu do współzawodnictwa.
###### **2Kor 9,3**
 Posłałem zaś braci, aby pod tym względem nie była daremna nasza chluba z was, abyście – jak to już powiedziałem – byli gotowi.
###### **2Kor 9,4**
 Gdyby bowiem przybyli ze mną Macedończycy i gdyby stwierdzili, żeście nie przygotowani, zawstydzilibyśmy się my – nie chcę już mówić, że i wy – z powodu takiego stanu rzeczy.
###### **2Kor 9,5**
 Uważałem przeto za konieczne prosić braci, aby przybyli wcześniej do was i przygotowali już przedtem obiecaną przez was darowiznę, która oby się okazała hojnością, a nie sknerstwem.
###### **2Kor 9,6**
 Tak bowiem jest: kto skąpo sieje, ten i skąpo zbiera, kto zaś hojnie sieje, ten hojnie też zbierać będzie.
###### **2Kor 9,7**
 Każdy niech przeto postąpi tak, jak mu nakazuje jego własne serce, nie żałując i nie czując się przymuszonym, albowiem radosnego dawcę miłuje Bóg.
###### **2Kor 9,8**
 A Bóg może zlać na was całą obfitość łaski, tak byście mając wszystkiego i zawsze pod dostatkiem, bogaci byli we wszystkie dobre uczynki,
###### **2Kor 9,9**
 według tego, co jest napisane: Rozproszył, dał ubogim, sprawiedliwość Jego trwa na wieki.
###### **2Kor 9,10**
 Ten zaś, który daje siewcy ziarno [do zasiewu i] chleb do jedzenia, dostarczy również wam ziarna i rozmnoży je, i zwiększy plon waszej sprawiedliwości.
###### **2Kor 9,11**
 Wzbogaceni we wszystko, będziecie pełni wszelkiej prostoty, która składa przez nas dziękczynienie Bogu.
###### **2Kor 9,12**
 Posługiwanie bowiem tej sprawie społecznej nie tylko uzupełnia to, na co nie stać świętych, lecz obfituje w liczne dzięki składane Bogu.
###### **2Kor 9,13**
 Ci, którzy oddają się tej posłudze, wielbią Boga za to, żeście posłuszni w wyznawaniu Ewangelii Chrystusa, a w prostocie stanowicie jedno z nimi i ze wszystkimi.
###### **2Kor 9,14**
 A w swych modlitwach za was okazują wam miłość z powodu przebogatej w was łaski Boga.
###### **2Kor 9,15**
 Dzięki Bogu za Jego dar niewypowiedziany.
# 2Kor 9 PAU
###### **2Kor 9,1**
 Zbyteczne jest pisanie do was o posłudze pełnionej względem świętych.
###### **2Kor 9,2**
 Wiem bowiem o waszym zaangażowaniu i chlubię się nim przed Macedończykami, którym mówię, że Achaja przygotowana jest już od roku. Wasza gorliwość zachęciła wielu.
###### **2Kor 9,3**
 Posyłam więc braci, aby nasze chlubienie się wami w tej sprawie nie okazało się złudne, ale - jak mówiłem - byście byli przygotowani.
###### **2Kor 9,4**
 Gdyby bowiem przyszli z nami Macedończycy i zastali was nieprzygotowanych, to z powodu naszej ufności do was musielibyśmy się wstydzić, nie mówiąc już o was.
###### **2Kor 9,5**
 Uznałem więc za konieczne zachęcić braci, aby do was przybyli i z wyprzedzeniem przygotowali obiecany przez was dar błogosławieństwa, aby był on rzeczywiście darem błogosławieństwa, a nie wyrazem sknerstwa.
###### **2Kor 9,6**
 Pamiętajcie o tym, że kto skąpo sieje, ten i skąpe zbierze plony, a kto hojnie sieje, ten zbierze plony obfite.
###### **2Kor 9,7**
 Niech każdy postąpi zgodnie z tym, co postanowił w sercu. Niech nie postępuje ze smutkiem ani pod przymusem, bo Bóg miłuje radosnego dawcę.
###### **2Kor 9,8**
 Bóg ma moc obdarzyć was obficie wszelką łaską, abyście zawsze mieli wszystkiego pod dostatkiem i byli bogaci we wszelkie dobre uczynki.
###### **2Kor 9,9**
 Tak jak jest napisane: Rozdzielił dary, obdarzył ubogich, Jego sprawiedliwość trwa na wieki.
###### **2Kor 9,10**
 Ten, który daje nasienie siewcy i chleb spożywającemu, dostarczy wam ziarna, rozmnoży je i zwiększy plon waszej sprawiedliwości.
###### **2Kor 9,11**
 Wzbogaceni we wszystko, będziecie mogli wykazać się wszelkiego rodzaju szczodrością, która przyczyni się przez nas do dziękowania Bogu,
###### **2Kor 9,12**
 gdyż ta święta posługa nie tylko zaradza ubóstwu świętych, ale pozwala składać Bogu obfite dziękczynienie.
###### **2Kor 9,13**
 Dzięki świadectwu tej posługi oddadzą oni chwałę Bogu za posłuszeństwo, które okazujecie Ewangelii Chrystusa, i za szczodrość waszego dzielenia się z nimi i ze wszystkimi.
###### **2Kor 9,14**
 Modląc się za was, będą czuli głęboką więź z wami ze względu na niezwykłą obfitość łaski, której Bóg wam udzielił.
###### **2Kor 9,15**
 Bogu niech będą dzięki za Jego niewysłowiony dar.
# 2Kor 9 BP
###### **2Kor 9,1**
 Uważam za zbyteczne pisać wam o posłudze na rzecz świętych.
###### **2Kor 9,2**
 Znam bowiem waszą ochotę i z tego powodu chlubię się wami przed Macedończykami mówiąc, że Achaja jest przygotowana od zeszłego roku. Wasza gorliwość pobudziła wielu do współzawodnictwa.
###### **2Kor 9,3**
 Posłałem zaś braci, abyśmy w tej sprawie bezpodstawnie nie chlubili się wami, abyście byli przygotowani, tak jak powiedziałem.
###### **2Kor 9,4**
 Gdyby przypadkiem przybyli ze mną Macedończycy i zastali was nie przygotowanych, zawstydzilibyśmy się - już nie mówiąc o was - z powodu tej ufności.
###### **2Kor 9,5**
 Uważałem przeto za konieczne poprosić braci, aby wcześniej przybyli do was i przygotowali uprzednio obiecany hojny dar. Gotowy już dar będzie oznaką hojności, a nie sknerstwa.
###### **2Kor 9,6**
 Pamiętajcie o tym, że kto skąpo sieje, ten będzie zbierał skąpe plony, a kto hojnie sieje, ten zbierze bogate plony.
###### **2Kor 9,7**
 Każdy niech tak postąpi, jak postanowił, nie z żalem lub z konieczności, ponieważ "chętnego dawcę Bóg" miłuje.
###### **2Kor 9,8**
 Bóg może was obdarzyć obfitymi łaskami, abyście mając zawsze wszystkiego tyle, ile wam potrzeba, spełniali jak najczęściej wszelkie dobre uczynki,
###### **2Kor 9,9**
 zgodnie z tym, co zostało napisane: "Rozdzielił i dał ubogim, sprawiedliwość Jego trwa na wieki".
###### **2Kor 9,10**
 A ten, który wydziela siewcy ziarno oraz chleba na pokarm dostarcza, pomnoży wasze ziarno i zwiększy owoce waszej sprawiedliwości.
###### **2Kor 9,11**
 Wzbogaceni we wszystko okażecie wszelaką hojność, która sprawia, że za naszym pośrednictwem składane jest Bogu dziękczynienie.
###### **2Kor 9,12**
 Posługa bowiem związana z tą społeczną potrzebą nie tylko zaradzi niedostatkom świętych, lecz również obficie zwiększy dziękczynienia, które wielu będzie składać Bogu.
###### **2Kor 9,13**
 Przekonani dowodami, jakich dostarczycie im przez tę posługę, będą chwalić Boga za wasze posłuszeństwo w wyznawaniu ewangelii o Chrystusie i za hojność, z jaką dzielicie się swoimi dobrami, zarówno z nimi, jak i ze wszystkimi.
###### **2Kor 9,14**
 W swojej gorącej modlitwie wyrażą tęsknotę za wami z powodu przeogromnej łaski Bożej, którą posiadacie.
###### **2Kor 9,15**
 Bogu niech będą dzięki za jego dar niewysłowiony.
# 2Kor 9 BR
###### **2Kor 9,1**
 O posłudze zaś, którą się pełni dla świętych, nie potrzebuję wam pisać.
###### **2Kor 9,2**
 Znam bowiem waszą gorliwość, dzięki której chlubię się wami wśród Macedończyków: Achaja gotowa jest już od zeszłego roku. I tak wasza gorliwość pobudziła wielu do współzawodnictwa.
###### **2Kor 9,3**
 Posłałem zaś braci, aby pod tym względem nie była daremna nasza chluba z was, abyście - jak to już powiedziałem - byli gotowi.
###### **2Kor 9,4**
 Gdyby bowiem przybyli ze mną Macedończycy i gdyby stwierdzili, żeście nie przygotowani, zawstydzilibyśmy się my - nie chcę już mówić, że i wy - z powodu takiego stanu rzeczy.
###### **2Kor 9,5**
 Uważałem przeto za konieczne prosić braci, aby przybyli wcześniej do was i przygotowali już przedtem obiecaną przez was darowiznę, która oby się okazała hojnością, a nie sknerstwem.
###### **2Kor 9,6**
 Tak bowiem jest: kto skąpo sieje, ten skąpo i zbiera, kto zaś hojnie sieje, tej hojnie też zbierać będzie.
###### **2Kor 9,7**
 Każdy niech przeto postąpi tak, jak mu nakazuje jego własne serce, nie żałując i nie czując się przymuszonym, albowiem radosnego dawcę miłuje Bóg.
###### **2Kor 9,8**
 A Bóg może zlać na was całą obfitość łaski, tak byście mając wszystkiego i zawsze pod dostatkiem, bogaci byli we wszystkie dobre uczynki
###### **2Kor 9,9**
 według tego, co jest napisane: Rozproszył, dał ubogim, sprawiedliwość Jego trwa na wieki.
###### **2Kor 9,10**
 Ten zaś, który daje ziarno siewcy, i chleba dostarczy ku pokrzepieniu, i ziarno rozmnoży, i zwiększy plon waszej sprawiedliwości.
###### **2Kor 9,11**
 Wzbogaceni we wszystko, będziecie pełni wszelkiej prostoty, która składa przez nas dziękczynienie Bogu.
###### **2Kor 9,12**
 Posługiwanie bowiem tej sprawie społecznej nie tylko uzupełnia to, na co nie stać świętych, lecz obfituje w liczne dzięki składane Bogu.
###### **2Kor 9,13**
 Ci, którzy oddają się tej posłudze, wielbią Boga za to, żeście posłuszni w wyznawaniu Ewangelii Chrystusa, a w prostocie stanowicie jedno z nimi i ze wszystkimi.
###### **2Kor 9,14**
 A w swych modlitwach za was okazują wam miłość z powodu przebogatej w was łaski Boga.
###### **2Kor 9,15**
 Dzięki Bogu za Jego dar niewypowiedziany.
# 2Kor 9 WUJ
###### **2Kor 9,1**
 Bo o posłudze, która się dzieje przeciw świętym niepotrzebna mi jest pisać do was.
###### **2Kor 9,2**
 Znam bowiem ochotne serce wasze: którem się przechwalam z was u Macedończyków. Iż Achaja gotowa jest od roku przeszłego, a ochota wasza wiele ich pobudziła.
###### **2Kor 9,3**
 I posłałem bracią, iżby w czem się pochwalamy z was nie było wyniszczono, z tej miary, abyście (jakom powiedział) gotowemi byli:
###### **2Kor 9,4**
 Aby gdyby zemną przyszli Macedończycy, a znaleźli was nie gotowe, nie zawstydaliśmy się my, iż nie rzekę wy, w tej rzeczy.
###### **2Kor 9,5**
 Za potrzebnąm tedy rozumiał prosić braciej, aby do was wprzód poszli, i pierwej zgotowali przed tem obiecane błogosławieństwo, aby to było gotowe tak jako błogosławieństwo, a nie jako łakomstwo.
###### **2Kor 9,6**
 A to powiadam: Kto skąpie sieje, skąpie też żąć będzie: a kto sieje w błogosławieństwach, z błogosławieństw też żąć będzie.
###### **2Kor 9,7**
 Każdy jako postanowił w sercu swojem, nie z zamarszczenia abo z przymuszenia: abowiem ochotnego dawcę Bóg miłuje.
###### **2Kor 9,8**
 A Bóg mocen jest uczynić, aby obfitowała w was wszystka łaska: abyście we wszystkiem zawsze mając wszystek dostatek, obfitowali ku wszelkiemu uczynkowi dobremu,
###### **2Kor 9,9**
 Jako napisano jest: Rozproszył, dał ubogim: sprawiedliwość jego trwa na wiek wieku.
###### **2Kor 9,10**
 A który dodaje nasienia siejącemu: doda też chleba ku jedzeniu: i rozmnoży nasienie wasze, i przysporzy przymnożenie urodzajów sprawiedliwości waszej.
###### **2Kor 9,11**
 Abyście na wszystkiem ubogaceni obfitowali ku wszelkiej prostości, która przez nas sprawuje dzięki Bogu.
###### **2Kor 9,12**
 Abowiem usługowanie urzędu tego nie tylko wypełnia to czego nie dostawa świętym, ale też obfituje przez wiele dziękowania w Panu.
###### **2Kor 9,13**
 Gdy przez doświadczenie tej posługi, Boga chwalą za posłuszeństwo wyznania waszego ku Ewanieljej Chrystusowej, i za szczerość w udzielaniu przeciwko nim, i przeciw wszystkim,
###### **2Kor 9,14**
 I w ich prośbie za was, pragnących was dla łaski Bożej obfitującej w was.
###### **2Kor 9,15**
 Bogu chwała za niewysłowiony dar jego.
# 2Kor 9 STERN
###### **2Kor 9,1**
 Nie ma właściwie potrzeby, abym wam pisał o tej ofierze dla ludu Bożego -
###### **2Kor 9,2**
 znam waszą żarliwość i chlubię się wami przed Macedończykami. Mówię im: "Achają jest gotowa od zeszłego roku" - i to wasz zapał pobudził większość z nich.
###### **2Kor 9,3**
 Ale teraz wysyłam braci, aby nasze chlubienie się wami pod tym względem nie okazało się puste, ażebyście byli gotowi, tak jak powiedziałem.
###### **2Kor 9,4**
 Bo jeśliby jacyś Macedończycy przybyli ze mną i zastali was nieprzygotowanymi, doznalibyśmy upokorzenia, żeśmy tacy byli pewni - nie mówiąc już o tym, jak wy byście się czuli.
###### **2Kor 9,5**
 Uznałem więc za konieczne, aby nakłonić tych braci, żeby udali się do was przede mną i zawczasu przygotowali wasz obiecany dar; w ten sposób będzie on gotowy, kiedy przybędę, i będzie prawdziwym darem, a nie czymś wymuszonym pod naciskiem.
###### **2Kor 9,6**
 A chodzi o to: ten, kto sieje skąpo, skąpo również zbiera.
###### **2Kor 9,7**
 Każdy powinien dawać wedle tego, co sobie postanowił w sercu, bez skąpstwa i bez przymusu, bo Bóg miłuje radosnego dawcę.
###### **2Kor 9,8**
 Ponadto Bóg ma moc zapewnić wam w obfitości wszelki dar łaski, tak że zawsze i pod każdym względem sami będziecie mieli wszystko, czego wam potrzeba, i będziecie w stanie obficie udzielać na każdą dobrą sprawę -
###### **2Kor 9,9**
 jak powiada Tanach: "Dał szczodrze ubogim, Jego cedaka trwa na wieki".
###### **2Kor 9,10**
 Ten, który zapewnia i ziarno siewcy, i chleb na pokarm, zapewni i pomnoży wasze ziarno i zwiększy plon waszej cedaki.
###### **2Kor 9,11**
 Zostaniecie wzbogaceni pod każdym względem, abyście mogli być szczodrzy we wszystkim. A za naszym pośrednictwem przez waszą szczodrość ludzie będą dziękować Bogu,
###### **2Kor 9,12**
 bo świadczenie tej świętej służby nie tylko zaspokaja potrzeby ludu Bożego, ale i obfituje w wielu dziękczynieniach, jakie będą zanoszone do Boga.
###### **2Kor 9,13**
 Ofiarowując tę służbę, dowodzicie tym ludziom, że oddajecie chwałę Bogu, rzeczywiście czyniąc to, czego od was wymaga uznanie Dobrej Nowiny Mesjasza, mianowicie szczodrze dzieląc się z nimi i z każdym.
###### **2Kor 9,14**
 A w swych modlitwach za was będą żywić ku wam gorące uczucia, że Bóg był dla was tak łaskawy.
###### **2Kor 9,15**
 Dzięki niech będą Bogu za Jego nieopisany dar!
# 2Kor 9 TRO
###### **2Kor 9,1**
 **περι** *peri* O [[G4012]] [[PREP]] **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **της** *tēs* [[G3588]] [[T-GSF]] **διακονιας** *diakonias* posłudze – służbie [[G1248]] [[N-GSF]] **της** *tēs* (tej) [[G3588]] [[T-GSF]] **εις** *eis* względem [[G1519]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **αγιους** *hagious* świętych [[G40]] WTA-APM **περισσον** *perisson* zbyt obfite [[G4053]] WTA-NSN **μοι** *moi* mi [[G3427]] WTP-1DS **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **το** *to* [[G3588]] WTT-NSN **γραφειν** *grafein* pisać [[G1125]] WTV-PAN **υμιν** *hymin* wam [[G5213]] WTP-2DP
###### **2Kor 9,2**
 **οιδα** *oida* Znam [[G1492]] WTV-RAI-1S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **προθυμιαν** *prothymian* gotowość – ochoczość [[G4288]] WTN-ASF **υμων** *hymōn* waszą [[G5216]] WTP-2GP **ην** *hēn* którą [[G3739]] WTR-ASF **υπερ** *hyper* co do [[G5228]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **καυχωμαι** *kauchōmai* chlubię się – chełpię się [[G2744]] WTV-PNI-1S **μακεδοσιν** *makedosin* Macedończykom [[G3110]] WTN-DPM **οτι** *hoti* że [[G3754]] [[CONJ]] **αχαια** *achaia* Achaja [[G882]] [[N-NSF]] **παρεσκευασται** *pareskeuastai* jest przygotowana [[G3903]] WTV-RPI-3S **απο** *apo* od [[G575]] [[PREP]] **περυσι** *perysi* ubiegłego roku [[G4070]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **εξ** *eks* z [[G1537]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **ζηλος** *zēlos* żarliwość – zapał [[G2205]] [[N-NSM]] **ηρεθισεν** *ērethisen* pobudziła – rozjątrzyła [[G2042]] [[V-AAI-3S]] **τους** *tous* [[G3588]] WTT-APM **πλειονας** *pleionas* liczniejszych – wielu [[G4119]] WTA-APM-C
###### **2Kor 9,3**
 **επεμψα** *epempsa* Posłałem [[G3992]] WTV-AAI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **τους** *tous* (tych) [[G3588]] WTT-APM **αδελφους** *adelfous* braci [[G80]] [[N-APM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **το** *to* [[G3588]] WTT-NSN **καυχημα** *kauchēma* chluba [[G2745]] WTN-NSN **ημων** *hēmōn* nasza [[G2257]] WTP-1GP **το** *to* (ta) [[G3588]] WTT-NSN **υπερ** *hyper* co do [[G5228]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **κενωθη** *kenōthē* zostałaby uczyniona próżną – zostałaby uczyniona pustą [[G2758]] WTV-APS-3S **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **μερει** *merei* części – dziale [[G3313]] WTN-DSN **τουτω** *toutō* tej [[G5129]] WTD-DSN **ινα** *hina* aby [[G2443]] [[CONJ]] **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **ελεγον** *elegon* mówiłem [[G3004]] WTV-IAI-1S **παρεσκευασμενοι** *pareskeuasmenoi* którzy są przygotowani [[G3903]] WTV-RPP-NPM **ητε** *ēte* bylibyście [[G5600]] WTV-PXS-2P
###### **2Kor 9,4**
 **μηπως** *mēpōs* aby czasem nie – aby nie jakoś [[G3381]] [[CONJ]] **εαν** *ean* jeśli [[G1437]] WTCOND **ελθωσιν** *elthōsin* przyszliby [[G2064]] WTV-2AAS-3P **συν** *syn* razem ze [[G4862]] [[PREP]] **εμοι** *emoi* mną [[G1698]] WTP-1DS **μακεδονες** *makedones* Macedończycy [[G3110]] WTN-NPM **και** *kai* i [[G2532]] [[CONJ]] **ευρωσιν** *heurōsin* znaleźliby [[G2147]] WTV-2AAS-3P **υμας** *hymas* was [[G5209]] WTP-2AP **απαρασκευαστους** *aparaskeuastous* nieprzygotowanymi [[G532]] WTA-APM **καταισχυνθωμεν** *kataischynthōmen* zostalibyśmy zawstydzeni – zostalibyśmy zhańbieni [[G2617]] WTV-APS-1P **ημεις** *hēmeis* my [[G2249]] WTP-1NP **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **λεγωμεν** *legōmen* mówiłbym [[G3004]] WTV-PAS-1P **υμεις** *hymeis* wy [[G5210]] WTP-2NP **εν** *en* na [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **υποστασει** *hypostasei* założeniu – zrozumieniu [[G5287]] [[N-DSF]] **ταυτη** *tautē* tej [[G3778]] WTD-DSF **της** *tēs* [[G3588]] [[T-GSF]] **καυχησεως** *kauchēseōs* chluby – chełpienia się [[G2746]] [[N-GSF]]
###### **2Kor 9,5**
 **αναγκαιον** *anagkaion* Konieczne – Niezbędne [[G316]] WTA-ASN **ουν** *oun* więc [[G3767]] [[CONJ]] **ηγησαμην** *hēgēsamēn* uznałem [[G2233]] WTV-ADI-1S **παρακαλεσαι** *parakalesai* zachęcić [[G3870]] [[V-AAN]] **τους** *tous* (tych) [[G3588]] WTT-APM **αδελφους** *adelfous* braci [[G80]] [[N-APM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **προελθωσιν** *proelthōsin* wcześniej przyszliby [[G4281]] WTV-2AAS-3P **εις** *eis* do [[G1519]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **και** *kai* i [[G2532]] [[CONJ]] **προκαταρτισωσιν** *prokatartisōsin* wcześniej przygotowaliby – wcześniej wydoskonaliliby [[G4294]] WTV-AAS-3P **την** *tēn* [[G3588]] WTT-ASF **προκατηγγελμενην** *prokatēngelmenēn* które jest przepowiedziane – które jest wcześniej ogłoszone [[G4293]] WTV-RPP-ASF **ευλογιαν** *eulogian* hojność – wysławienie [[G2129]] WTN-ASF **υμων** *hymōn* wasza [[G5216]] WTP-2GP **ταυτην** *tautēn* to [[G3778]] WTD-ASF **ετοιμην** *hetoimēn* gotowe [[G2092]] WTA-ASF **ειναι** *einai* być [[G1511]] WTV-PXN **ουτως** *houtōs* tak [[G3779]] [[ADV]] **ως** *hōs* jak [[G5613]] [[ADV]] **ευλογιαν** *eulogian* hojność – wysławienie [[G2129]] WTN-ASF **και** *kai* a [[G2532]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **ωσπερ** *hōsper* tak, jak [[G5618]] [[ADV]] **πλεονεξιαν** *pleoneksian* skąpstwo – zachłanność [[G4124]] WTN-ASF
###### **2Kor 9,6**
 **τουτο** *touto* To [[G5124]] WTD-NSN **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **σπειρων** *speirōn* siejący [[G4687]] [[V-PAP-NSM]] **φειδομενως** *feidomenōs* oszczędnie – skąpo [[G5340]] [[ADV]] **φειδομενως** *feidomenōs* oszczędnie – skąpo [[G5340]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **θερισει** *therisei* będzie żąć [[G2325]] WTV-FAI-3S **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **σπειρων** *speirōn* siejący [[G4687]] [[V-PAP-NSM]] **επ** *ep* w [[G1909]] [[PREP]] **ευλογιαις** *eulogiais* hojnościach – wysławieniach [[G2129]] WTN-DPF **επ** *ep* w [[G1909]] [[PREP]] **ευλογιαις** *eulogiais* hojnościach – wysławieniach [[G2129]] WTN-DPF **και** *kai* i [[G2532]] [[CONJ]] **θερισει** *therisei* będzie żąć [[G2325]] WTV-FAI-3S
###### **2Kor 9,7**
 **εκαστος** *hekastos* każdy [[G1538]] [[A-NSM]] **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **προαιρειται** *proaireitai* postanawia – zamyśla [[G4255]] WTV-PNI-3S **τη** *tē* [[G3588]] WTT-DSF **καρδια** *kardia* sercem [[G2588]] [[N-DSF]] **μη** *mē* nie [[G3361]] [[PRT-N]] **εκ** *ek* ze [[G1537]] [[PREP]] **λυπης** *lypēs* smutku [[G3077]] [[N-GSF]] **η** *ē* lub [[G2228]] WTPRT **εξ** *eks* z [[G1537]] [[PREP]] **αναγκης** *anagkēs* konieczności – przymusu [[G318]] [[N-GSF]] **ιλαρον** *hilaron* radosnego – wesołego [[G2431]] WTA-ASM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **δοτην** *dotēn* dawcę [[G1395]] [[N-ASM]] **αγαπα** *agapa* miłuje [[G25]] WTV-PAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]]
###### **2Kor 9,8**
 **δυνατος** *dynatos* Mocny – Potężny [[G1415]] [[A-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **πασαν** *pasan* każdą [[G3956]] WTA-ASF **χαριν** *charin* łaskę [[G5485]] WTN-ASF **περισσευσαι** *perisseusai* dać obficie [[G4052]] [[V-AAN]] **εις** *eis* ku [[G1519]] [[PREP]] **υμας** *hymas* wam [[G5209]] WTP-2AP **ινα** *hina* aby [[G2443]] [[CONJ]] **εν** *en* we [[G1722]] [[PREP]] **παντι** *panti* wszystkim [[G3956]] WTA-DSN **παντοτε** *pantote* zawsze – każdej chwili [[G3842]] [[ADV]] **πασαν** *pasan* całą [[G3956]] WTA-ASF **αυταρκειαν** *autarkeian* samowystarczalność – niezależność [[G841]] WTN-ASF **εχοντες** *echontes* mając [[G2192]] WTV-PAP-NPM **περισσευητε** *perisseuēte* obfitowalibyście [[G4052]] WTV-PAS-2P **εις** *eis* ku [[G1519]] [[PREP]] **παν** *pan* każdemu [[G3956]] WTA-ASN **εργον** *ergon* czynowi – dziełu [[G2041]] WTN-ASN **αγαθον** *agathon* dobremu [[G18]] WTA-ASN
###### **2Kor 9,9**
 **καθως** *kathōs* jak [[G2531]] [[ADV]] **γεγραπται** *gegraptai* jest napisane [[G1125]] WTV-RPI-3S **εσκορπισεν** *eskorpisen* rozproszył – rozrzucił [[G4650]] [[V-AAI-3S]] **εδωκεν** *edōken* dał [[G1325]] [[V-AAI-3S]] **τοις** *tois* [[G3588]] WTT-DPM **πενησιν** *penēsin* biednym [[G3993]] WTN-DPM **η** *hē* [[G3588]] [[T-NSF]] **δικαιοσυνη** *dikaiosynē* sprawiedliwość [[G1343]] [[N-NSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **μενει** *menei* trwa [[G3306]] WTV-PAI-3S **εις** *eis* na [[G1519]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **αιωνα** *aiōna* wiek [[G165]] [[N-ASM]]
###### **2Kor 9,10**
 **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **επιχορηγων** *epichorēgōn* dostarczający – zaopatrujący [[G2023]] [[V-PAP-NSM]] **σπερμα** *sperma* nasienie [[G4690]] WTN-ASN **τω** *tō* [[G3588]] WTT-DSM **σπειροντι** *speironti* siejącemu [[G4687]] WTV-PAP-DSM **και** *kai* i [[G2532]] [[CONJ]] **αρτον** *arton* (w) chleb [[G740]] [[N-ASM]] **εις** *eis* na [[G1519]] [[PREP]] **βρωσιν** *brōsin* pokarm [[G1035]] WTN-ASF **χορηγησαι** *chorēgēsai* oby zaopatrzył [[G5524]] WTV-AAO-3S **και** *kai* i [[G2532]] [[CONJ]] **πληθυναι** *plēthynai* oby pomnożył [[G4129]] WTV-AAO-3S **τον** *ton* [[G3588]] [[T-ASM]] **σπορον** *sporon* ziarno – siew [[G4703]] [[N-ASM]] **υμων** *hymōn* wasze [[G5216]] WTP-2GP **και** *kai* i [[G2532]] [[CONJ]] **αυξησαι** *auksēsai* oby dał wzrost [[G837]] WTV-AAO-3S **τα** *ta* [[G3588]] WTT-APN **γεννηματα** *gennēmata* plonom [[G1081]] WTN-APN **της** *tēs* [[G3588]] [[T-GSF]] **δικαιοσυνης** *dikaiosynēs* sprawiedliwości [[G1343]] [[N-GSF]] **υμων** *hymōn* waszej [[G5216]] WTP-2GP
###### **2Kor 9,11**
 **εν** *en* we [[G1722]] [[PREP]] **παντι** *panti* wszelkim [[G3956]] WTA-DSN **πλουτιζομενοι** *ploutizomenoi* którzy są ubogacani [[G4148]] WTV-PPP-NPM **εις** *eis* w [[G1519]] [[PREP]] **πασαν** *pasan* całej [[G3956]] WTA-ASF **απλοτητα** *haplotēta* prostocie – szczerości [[G572]] WTN-ASF **ητις** *hētis* która [[G3748]] WTR-NSF **κατεργαζεται** *katergazetai* sprawia [[G2716]] WTV-PNI-3S **δι** *di* przez [[G1223]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP **ευχαριστιαν** *eucharistian* dziękczynienie – wdzięczność [[G2169]] WTN-ASF **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM
###### **2Kor 9,12**
 **οτι** *hoti* Gdyż [[G3754]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **διακονια** *diakonia* posługa – służba [[G1248]] [[N-NSF]] **της** *tēs* [[G3588]] [[T-GSF]] **λειτουργιας** *leitourgias* publicznego dzieła – publicznej służby [[G3009]] [[N-GSF]] **ταυτης** *tautēs* tego [[G3778]] WTD-GSF **ου** *ou* nie [[G3756]] [[PRT-N]] **μονον** *monon* jedynie – tylko [[G3440]] [[ADV]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **προσαναπληρουσα** *prosanaplērousa* uzupełniającą [[G4322]] [[V-PAP-NSF]] **τα** *ta* [[G3588]] WTT-APN **υστερηματα** *hysterēmata* niedostatki – braki [[G5303]] WTN-APN **των** *tōn* [[G3588]] WTT-GPM **αγιων** *hagiōn* świętych [[G40]] WTA-GPM **αλλα** *alla* ale [[G235]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **περισσευουσα** *perisseuousa* dającą obfitość [[G4052]] [[V-PAP-NSF]] **δια** *dia* przez [[G1223]] [[PREP]] **πολλων** *pollōn* liczne – wiele [[G4183]] WTA-GPF **ευχαριστιων** *eucharistiōn* dziękczynienia – wdzięczności [[G2169]] WTN-GPF **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM
###### **2Kor 9,13**
 **δια** *dia* przez [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **δοκιμης** *dokimēs* wypróbowanie [[G1382]] [[N-GSF]] **της** *tēs* [[G3588]] [[T-GSF]] **διακονιας** *diakonias* posługi – służby [[G1248]] [[N-GSF]] **ταυτης** *tautēs* tej [[G3778]] WTD-GSF **δοξαζοντες** *doksazontes* oddający chwałę [[G1392]] WTV-PAP-NPM **τον** *ton* [[G3588]] [[T-ASM]] **θεον** *theon* Bogu [[G2316]] [[N-ASM]] **επι** *epi* z powodu [[G1909]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **υποταγη** *hypotagē* posłuszeństwa – podporządkowania się [[G5292]] [[N-DSF]] **της** *tēs* [[G3588]] [[T-GSF]] **ομολογιας** *homologias* wyznania – przyznania [[G3671]] [[N-GSF]] **υμων** *hymōn* waszego [[G5216]] WTP-2GP **εις** *eis* względem [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **ευαγγελιον** *euangelion* dobrej nowiny [[G2098]] WTN-ASN **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **απλοτητι** *haplotēti* prostoty – szczerości [[G572]] [[N-DSF]] **της** *tēs* [[G3588]] [[T-GSF]] **κοινωνιας** *koinōnias* wspólnoty [[G2842]] [[N-GSF]] **εις** *eis* względem [[G1519]] [[PREP]] **αυτους** *autous* nich [[G846]] [[P-APM]] **και** *kai* i [[G2532]] [[CONJ]] **εις** *eis* względem [[G1519]] [[PREP]] **παντας** *pantas* wszystkich [[G3956]] WTA-APM
###### **2Kor 9,14**
 **και** *kai* a [[G2532]] [[CONJ]] **αυτων** *autōn* (obok) nich [[G846]] WTP-GPM **δεησει** *deēsei* prośba [[G1162]] [[N-DSF]] **υπερ** *hyper* za [[G5228]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **επιποθουντων** *epipothountōn* pragnąc – tęskniąc [[G1971]] WTV-PAP-GPM **υμας** *hymas* was [[G5209]] WTP-2AP **δια** *dia* z powodu [[G1223]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **υπερβαλλουσαν** *hyperballousan* przewyższającej [[G5235]] WTV-PAP-ASF **χαριν** *charin* łaski [[G5485]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εφ** *ef* względem [[G1909]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP
###### **2Kor 9,15**
 **χαρις** *charis* Wdzięczność – Łaska [[G5485]] [[N-NSF]] **δε** *de* zaś [[G1161]] [[CONJ]] **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **επι** *epi* z powodu [[G1909]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **ανεκδιηγητω** *anekdiēgētō* niewysłowionego – niewycenionego [[G411]] WTA-DSF **αυτου** *autou* Jego [[G846]] [[P-GSM]] **δωρεα** *dōrea* daru – darowizny [[G1431]] [[N-DSF]]
