# Hbr 13 BT5
###### **Hbr 13,1**
 Niech trwa braterska miłość.
###### **Hbr 13,2**
 Nie zapominajcie też o gościnności, gdyż przez nią niektórzy, nie wiedząc, aniołom dali gościnę.
###### **Hbr 13,3**
 Pamiętajcie o uwięzionych, jakbyście byli sami uwięzieni, i o tych, co cierpią, bo i sami żyjecie w ciele.
###### **Hbr 13,4**
 We czci niech będzie małżeństwo pod każdym względem i łoże nieskalane, gdyż rozpustników i cudzołożników osądzi Bóg.
###### **Hbr 13,5**
 Postępowanie wasze niech będzie wolne od zachłanności na pieniądze: zadowalajcie się tym, co macie. Sam [Bóg] bowiem powiedział: Nie opuszczę cię ani nie pozostawię.
###### **Hbr 13,6**
 Śmiało więc możemy mówić:Pan jest wspomożycielem moim, nie ulęknę się, bo cóż może mi uczynić człowiek?
###### **Hbr 13,7**
 Pamiętajcie o swych przełożonych, którzy głosili wam słowo Boże, i rozpamiętując koniec ich życia, naśladujcie ich wiarę.
###### **Hbr 13,8**
 Jezus Chrystus – wczoraj i dziś, ten sam także na wieki.
###### **Hbr 13,9**
 Nie dajcie się uwieść różnym i obcym naukom, dobrze bowiem jest wzmacniać serce łaską, a nie pokarmami, które nie przynoszą korzyści tym, co się o nie ubiegają.
###### **Hbr 13,10**
 Mamy ołtarz, z którego nie mają prawa spożywać ci, którzy służą przybytkowi.
###### **Hbr 13,11**
 Ciała bowiem tych zwierząt, których krew arcykapłan wnosi do świątyni jako ofiarę przebłagalną, są spalane poza obozem.
###### **Hbr 13,12**
 Dlatego i Jezus, aby krwią swoją uświęcić lud, poniósł mękę poza miastem.
###### **Hbr 13,13**
 Również i my wyjdźmy do Niego poza obóz, dzieląc z Nim Jego urągowisko.
###### **Hbr 13,14**
 Nie mamy tutaj trwałego miasta, ale szukamy przyszłego.
###### **Hbr 13,15**
 Przez Niego więc składajmy Bogu ofiarę pochwalną nieustannie, to jest owoc warg, które wyznają Jego imię.
###### **Hbr 13,16**
 Nie zapominajcie o dobroczynności i wzajemnej pomocy, gdyż raduje się Bóg takimi ofiarami.
###### **Hbr 13,17**
 Bądźcie posłuszni waszym przełożonym i bądźcie im ulegli, ponieważ oni czuwają nad duszami waszymi i muszą zdać z tego sprawę. Niech to czynią z radością, a nie wzdychając, bo to nie byłoby z korzyścią dla was.
###### **Hbr 13,18**
 Módlcie się za nas, jesteśmy bowiem przekonani, że mamy czyste sumienie, starając się we wszystkim dobrze postępować.
###### **Hbr 13,19**
 Jeszcze goręcej was proszę o spowodowanie tego, bym co rychlej został wam przywrócony.
###### **Hbr 13,20**
 Bóg zaś pokoju, który na mocy krwi przymierza wiecznego wyprowadził spomiędzy zmarłych Wielkiego Pasterza owiec, Pana naszego, Jezusa,
###### **Hbr 13,21**
 niech was uzdolni do wszelkiego dobra, byście wypełnili Jego wolę; niech sprawi w was, co miłe jest w Jego oczach, przez Jezusa Chrystusa, któremu chwała na wieki wieków. Amen.
###### **Hbr 13,22**
 Proszę zaś was, bracia: Przyjmijcie to słowo zachęty, bo napisałem wam bardzo krótko.
###### **Hbr 13,23**
 Wiedzcie, że brat nasz, Tymoteusz, został zwolniony. Jeśli tylko wnet przybędzie, z nim razem zobaczę was.
###### **Hbr 13,24**
 Pozdrówcie wszystkich waszych przełożonych i wszystkich świętych. Pozdrawiają was [bracia] z Italii.
###### **Hbr 13,25**
 Łaska z wami wszystkimi! Amen.
# Hbr 13 PAU
###### **Hbr 13,1**
 Niech trwa braterska miłość.
###### **Hbr 13,2**
 Nie zapominajcie też o gościnności. Przecież dzięki niej niektórzy, nawet się nie domyślając, ugościli aniołów.
###### **Hbr 13,3**
 Pamiętajcie o więźniach, jakbyście sami byli więzieni, i o cierpiących, bo wy też żyjecie w ciele.
###### **Hbr 13,4**
 Małżeństwo niech będzie przez wszystkich szanowane, a łoże - nieskalane. Bóg bowiem osądzi rozpustników i cudzołożników.
###### **Hbr 13,5**
 Nie bądźcie chciwi na pieniądze, zadowalajcie się tym, co posiadacie, gdyż sam Bóg powiedział: Nie opuszczę cię ani nie porzucę!
###### **Hbr 13,6**
 Tak więc śmiało możemy mówić: Pan jest moim wspomożycielem, więc się nie boję. Cóż może uczynić mi człowiek?
###### **Hbr 13,7**
 Pamiętajcie o tych, co wam przewodzili, którzy głosili wam słowo Boże. Rozważając kres ich pielgrzymki, naśladujcie ich wiarę.
###### **Hbr 13,8**
 Jezus Chrystus wczoraj i dziś ten sam - i aż na wieki!
###### **Hbr 13,9**
 Nie dajcie się zwieść różnym obcym naukom. Lepiej bowiem umacniać serce łaską niż pokarmami, niemogącymi pomóc tym, którzy czynią z nich zasadę postępowania!
###### **Hbr 13,10**
 My mamy ołtarz ofiarny, z którego nie mogą spożywać pełniący służbę w dawnym namiocie.
###### **Hbr 13,11**
 Otóż najwyższy kapłan, aby złożyć ofiarę za grzechy, wnosi do świątyni krew zwierząt, których ciała pali się poza obozem.
###### **Hbr 13,12**
 Dlatego też Jezus, aby uświęcić lud swoją krwią, podjął mękę za bramą miasta.
###### **Hbr 13,13**
 Wyjdźmy do Niego poza obóz, uczestnicząc w Jego pohańbieniu!
###### **Hbr 13,14**
 Nie mamy tu bowiem trwałego miasta, lecz dążymy do przyszłego!
###### **Hbr 13,15**
 Zatem przez Niego ustawicznie składajmy ofiarę uwielbienia. Jest nią owoc warg wyznających Jego imię.
###### **Hbr 13,16**
 Nie zapominajcie o czynieniu dobra i o budowaniu wspólnoty, gdyż Bóg cieszy się takimi ofiarami!
###### **Hbr 13,17**
 Zaufajcie tym, co wam przewodzą i bądźcie im ulegli. Oni, jako odpowiedzialni za was osobiście, czuwają nad wami. Niech czynią to z radością, a nie z bólem, gdyż to byłoby dla was szkodliwe.
###### **Hbr 13,18**
 Módlcie się za nas. Ufamy bowiem, że nasze sumienie jest czyste, i pragniemy we wszystkim dobrze postępować.
###### **Hbr 13,19**
 Szczególnie proszę was o staranie, abym wkrótce mógł do was wrócić.
###### **Hbr 13,20**
 A Bóg pokoju, który przez krew wiecznego Przymierza wyprowadził spośród zmarłych wielkiego pasterza owiec, naszego Pana Jezusa,
###### **Hbr 13,21**
 udzieli wam wszelkiego dobra, abyście spełnili Jego wolę! A z nami niech czyni, co się Jemu podoba, przez Jezusa Chrystusa! Jemu chwała na wieki wieków. Amen.
###### **Hbr 13,22**
 Proszę was, bracia, przyjmijcie te słowa zachęty, które w skrócie wam przekazałem!
###### **Hbr 13,23**
 Wiedzcie, że nasz brat, Tymoteusz, został uwolniony. Jeśli wkrótce przybędzie, to wraz z nim chcę was odwiedzić.
###### **Hbr 13,24**
 Pozdrówcie wszystkich waszych przewodników i wszystkich świętych. Pozdrawiają was bracia z Italii.
###### **Hbr 13,25**
 Łaska z wami wszystkimi! Amen.
# Hbr 13 BP
###### **Hbr 13,1**
 Miłość braterska niech zawsze trwa.
###### **Hbr 13,2**
 Nie zapominajcie o gościnności, bo dzięki niej niektórzy, nie wiedząc o tym, ugościli aniołów.
###### **Hbr 13,3**
 Pamiętajcie o więźniach, jakbyście razem z nimi byli uwięzieni, o dręczonych, bo przecież i sami jesteście ludźmi.
###### **Hbr 13,4**
 Małżeństwo niech będzie we czci u wszystkich, a łoże małżeńskie niech będzie nieskalane, Bóg bowiem osądzi rozpustników i cudzołożników.
###### **Hbr 13,5**
 Unikajcie chciwości, bądźcie zadowoleni z tego, co posiadacie - On sam bowiem powiedział: "Ani cię nie opuszczę, ani też cię nie zostawię".
###### **Hbr 13,6**
 Będąc dobrej myśli, mówcie: "Pan jest mi obrońcą a nie będę się lękał, cóż mi zrobi człowiek?"
###### **Hbr 13,7**
 Pamiętajcie o waszych przełożonych, którzy głosili wam słowo Boże, a rozważając ostatnie chwile ich życia naśladujcie ich wiarę.
###### **Hbr 13,8**
 Jezus Chrystus jest ten sam wczoraj, dzisiaj i na wieki.
###### **Hbr 13,9**
 Nie dajcie się zwodzić rozmaitym obcym naukom, dobrze jest bowiem umacniać serce łaską, a nie pokarmami nic nie dającymi tym, którzy o nie zabiegają.
###### **Hbr 13,10**
 Mamy ołtarz, z którego nie mają prawa spożywać ci, którzy służą namiotowi.
###### **Hbr 13,11**
 Mięso tych zwierząt, których krew wnosi arcykapłan do sanktuarium jako ofiarę za grzech spala się przecież poza obozem.
###### **Hbr 13,12**
 Dlatego też Jezus, aby uświęcić lud własną krwią, poniósł mękę poza bramą [miasta].
###### **Hbr 13,13**
 Wyjdźmy przeto do Niego poza obóz, dzieląc z Nim Jego zniesławienie.
###### **Hbr 13,14**
 Nie mamy przecież tutaj trwałego miasta, ale dążymy do tego, które nas czeka w przyszłości.
###### **Hbr 13,15**
 Przez Niego więc składajmy Bogu ustawicznie ofiarę uwielbienia, to jest owoc ust, które wysławiają Jego imię.
###### **Hbr 13,16**
 Nie zapominajcie zaś o czynieniu dobra i zachowaniu jedności, bo takimi ofiarami cieszy się Bóg.
###### **Hbr 13,17**
 Ufajcie waszym przełożonym i bądźcie im posłuszni, bo oni odpowiadając za was czuwają nad waszymi duszami. Niech czynią to z radością a nie z narzekaniem, bo to przyniosłoby wam szkodę.
###### **Hbr 13,18**
 Módlcie się za nas, jesteśmy bowiem przekonani, że mamy czyste sumienie i pragniemy we wszystkim dobrze postępować.
###### **Hbr 13,19**
 Proszę, módlcie się zwłaszcza o to, abym mógł jak najszybciej do was powrócić.
###### **Hbr 13,20**
 A Bóg pokoju, Ten, który przez krew wiecznego przymierza wyprowadził spomiędzy umarłych wielkiego Pasterza owiec, Pana naszego Jezusa,
###### **Hbr 13,21**
 oby was udoskonalił we wszystkim, co dobre, abyście spełniali Jego wolę. Niech sprawia w was to, co jest Mu miłe, przez Jezusa Chrystusa, któremu chwała na wieki [wieków]. Amen.
###### **Hbr 13,22**
 Proszę zaś was, bracia, znieście cierpliwie te napomnienia, krótko je przecież ująłem.
###### **Hbr 13,23**
 Wiedzcie, że nasz brat Tymoteusz został uwolniony. Jeżeli się pospieszy, to razem was odwiedzimy.
###### **Hbr 13,24**
 Pozdrówcie wszystkich waszych przełożonych i wszystkich świętych. Pozdrawiają was [bracia] z Italii.
###### **Hbr 13,25**
 Łaska z wami wszystkimi!
# Hbr 13 BR
###### **Hbr 13,1**
 Trwajcie jak bracia we wzajemnej miłości!
###### **Hbr 13,2**
 Bądźcie gościnni dla tych, którzy do was przychodzą. Dzięki tej cnocie ludzie, nie wiedząc nawet o tym, podejmowali samych aniołów.
###### **Hbr 13,3**
 Pamiętajcie też o uwięzionych, tak jakbyście sami pozostawali w więzach, i o tych, którzy cierpią jakikolwiek ucisk, bo i sami jeszcze ciągle żyjecie w ciele [które może być poddanie uciskowi].
###### **Hbr 13,4**
 Małżeństwo winno być we czci u wszystkich, a współżycie małżeńskie niech będzie nieskalane, bo rozwiązłych i cudzołożników czeka surowy sąd Boży.
###### **Hbr 13,5**
 Nie dajcie się ponosić żądzy pieniądza. Poprzestawajcie na tym, co posiadacie, gdyż Bóg oświadczył: Nie opuszczę cię i nie pozostawię [bez opieki].
###### **Hbr 13,6**
 Tak więc śmiało możemy mówić: Pan jest mi pomocą, nie będę się lękał, bo cóż może uczynić mi człowiek.
###### **Hbr 13,7**
 Pamiętajcie o waszych dawnych przełożonych, którzy głosili wam kiedyś słowo Boże; podziwiajcie chwalebny kres ich życia, starajcie się naśladować ich wiarę.
###### **Hbr 13,8**
 A Jezus Chrystus jest ten sam wczoraj i dziś, i takim pozostanie na wieki.
###### **Hbr 13,9**
 Nie dajcie się omamić różnorakim a obcym nauczycielom. Serce ludzkie należy krzepić łaską, a nie pokarmami, które nie przynoszą żadnej korzyści tym, co ich pożądają.
###### **Hbr 13,10**
 Mamy ołtarz, z którego nie powinni korzystać ci, co służą w przybytku [dawnej świątyni].
###### **Hbr 13,11**
 Arcykapłan bowiem wnosi do świątyni jako ofiarę przebłagalną krew zabitych zwierząt, ich ciała zaś spala się poza obozem.
###### **Hbr 13,12**
 Również i Jezus, pragnąc uświęcić swoją krwią lud cały, cierpiał poza miastem.
###### **Hbr 13,13**
 Zatem i my winniśmy wyjść do Niego poza obóz, ażeby być z Nim w chwilach Jego pohańbienia.
###### **Hbr 13,14**
 Nie mamy bowiem tu na ziemi trwałego miasta, lecz oczekujemy na to, które ma przyjść.
###### **Hbr 13,15**
 Przez Niego też winniśmy składać Bogu ofiarę chwały, owoc warg naszych, którymi wielbimy Jego imię.
###### **Hbr 13,16**
 Nie zaniedbujcie się również w świadczeniu sobie dobra nawzajem, bo w takich ofiarach Bóg znajduje upodobanie.
###### **Hbr 13,17**
 Swoich przełożonych słuchajcie i bądźcie im poddani. Czuwają bowiem nad waszymi duszami i muszą, kiedyś zdać z tego sprawę przed Bogiem. Obyż mogli to uczynić z radością, a nie ze smutkiem, który i wam również nie wyszedłby na dobre.
###### **Hbr 13,18**
 Módlcie się za nas, choć jesteśmy, co prawda, przekonani, że mamy czyste sumienie, bo przecież we wszystkim staramy się postępować nienagannie.
###### **Hbr 13,19**
 Proszę was bardzo usilnie, dołóżcie wszelkich starań, abym został wam przywrócony jak najrychlej.
###### **Hbr 13,20**
 A Bóg pokoju, który przez krew przymierza wiecznego wywiódł spośród zmarłych Wielkiego Pasterza owiec, Pana naszego Jezusa,
###### **Hbr 13,21**
 niech was umocni we wszystkim, co dobre, byście mogli wypełniać Jego wolę; niech dokonuje w was tego, co miłe w Jego oczach, przez Jezusa Chrystusa, któremu chwała na wieki wieków. Amen.
###### **Hbr 13,22**
 Proszę was, bracia, przyjmijcie ode mnie te słowa pokrzepienia. Tylko tyle mogłem wam napisać.
###### **Hbr 13,23**
 Chciałbym wam też donieść, że brat nasz, Tymoteusz, został już zwolniony. Jeżeli zjawi się tu niedługo, zobaczę was tu razem z nim.
###### **Hbr 13,24**
 Pozdrówcie wszystkich przełożonych waszych i wszystkich ochrzczonych. Pozdrawiają was [bracia] z Italii.
###### **Hbr 13,25**
 Łaska Boża niech będzie z wami wszystkimi. Amen.
# Hbr 13 WUJ
###### **Hbr 13,1**
 Miłość braterstwa niechaj trwa w was.
###### **Hbr 13,2**
 A nie zapominajcie przyjmowania gości: Abowiem przez to nie wiedzieli niektórzy, anioły za goście przyjąwszy.
###### **Hbr 13,3**
 Pamiętajcie na więźnie, jakoby wespół więźniowie: i na utrapione, jakoby sami będąc w ciele.
###### **Hbr 13,4**
 Uczciwe małżeństwo we wszystkiem, i łoże niepokalane. Bo wszeteczniki i cudzołożniki Bóg będzie sądzić.
###### **Hbr 13,5**
 Obyczaje niech będą bez łakomstwa: przestawając na teraźniejszych rzeczach. Bo sam powiedział: Nie zaniecham cię, ani opuszczę.
###### **Hbr 13,6**
 Tak, iż śmiele mówimy: Pan mi pomocnikiem: nie będę się bał coby mi człowiek uczynił.
###### **Hbr 13,7**
 Pamiętajcie na przełożone wasze, którzy wam mówili słowo Boże: których przypatrując się dokonaniu obcowania, naśladujcie wiary.
###### **Hbr 13,8**
 Jezus Chrystus wczora i dziś: ten i na wieki.
###### **Hbr 13,9**
 Naukami rozmaitemi i obcemi nie unoście się. Abowiem nalepsza jest serce utwierdzić łaską, nie pokarmami: które nie pomogły tym co się imi bawili.
###### **Hbr 13,10**
 Mamy ołtarz: z którego nie mają mocy jeść, którzy przybytkowi służą.
###### **Hbr 13,11**
 Abowiem których bydląt krew bywa wnoszona do Świątnice przez nawyższego kapłana, tych ciała bywają palone za obozem.
###### **Hbr 13,12**
 Dla czego i Jezus, aby poświęcił lud przed własną krew, za bramą ucierpiał.
###### **Hbr 13,13**
 Wynidźmyż tedy do niego za obóz: nosząc urąganie jego.
###### **Hbr 13,14**
 Abowiem nie mamy tu miasta trwającego: ale przyszłego szukamy.
###### **Hbr 13,15**
 Przez niego tedy zawsze ofiarujmy Bogu ofiarę chwały, to jest, owoc warg wyznawających imieniowi jego.
###### **Hbr 13,16**
 A dobroczynności i udzielania spólnego nie przepominajcie. Abowiem takowemi ofiarami zasługujemy się Bogu.
###### **Hbr 13,17**
 Bądźcie posłuszni przełożonym waszym, i bądźcie im poddani. Abowiem oni czują, jako którzy za dusze nasze liczbę oddać mają. Aby to z weselem czynili, a nie wzdychając. Bo to wam nie pożyteczno.
###### **Hbr 13,18**
 Módlcie się za nami: abowiem ufamy, iż mamy dobre sumnienie: we wszem chcąc dobrze obcować.
###### **Hbr 13,19**
 A tem więcej proszę, abyście to czynili, iżbym wam rychlej był przywrócon.
###### **Hbr 13,20**
 A Bóg pokoju, który wywiódł od umarłych wielkiego pasterza owiec we krwi testamentu wiecznego, Pana naszego Jezusa Chrystusa:
###### **Hbr 13,21**
 Niechaj was sposobi do wszystkiego dobrego, abyście czynili wolą jego, sprawując w was coby się podobało przed nim przez Jezusa Chrystusa: któremu jest chwała na wieki wieków. Amen.
###### **Hbr 13,22**
 A proszę was bracia, abyście za dobre przyjęli słowo pocieszenia. Bom do was barzo krótko napisał.
###### **Hbr 13,23**
 Wiedzcie, iż brat nasz Tymotheusz wypuszczon: z którym (jeśli rychlej przydzie) oglądam was.
###### **Hbr 13,24**
 Pozdrówcie wszystki przełożone wasze, i wszystki święte. Pozdrawiają was bracia ze Włoch.
###### **Hbr 13,25**
 Łaska z wami wszystkimi. Amen.1
# Hbr 13 STERN
###### **Hbr 13,1**
 Niech kwitnie braterska przyjaźń,
###### **Hbr 13,2**
 lecz nie zapominajcie o życzliwości dla ludzi z zewnątrz, bo czyniąc tak, niektórzy, nieświadomi tego, okazywali gościnność aniołom.
###### **Hbr 13,3**
 Pamiętajcie o uwięzionych i poniewieranych, jakbyście sami byli z nimi w więzieniu i przechodzili katusze.
###### **Hbr 13,4**
 Małżeństwo godne jest czci pod każdym względem, a mówiąc ściślej, współżycie w ramach małżeństwa jest czyste. Lecz zaiste, ukarze Bóg wszeteczników i cudzołożników.
###### **Hbr 13,5**
 Strzeżcie swego życia przed umiłowaniem pieniędzy, a zadowalajcie się tym, co macie, bo sam Bóg rzekł: "Nigdy cię nie zawiodę ani nie porzucę".
###### **Hbr 13,6**
 Dlatego powiadamy ufnie: "Adonai moją pomocą, nie będę się lękał -co może zrobić mi człowiek?".
###### **Hbr 13,7**
 Pamiętajcie o waszych przewodnikach, którzy głosili wam naukę Bożą. Pomyślcie o owocach ich sposobu życia i naśladujcie ich ufność -
###### **Hbr 13,8**
 Jeszua Mesjasz jest ten sam wczoraj, dziś i na wieki.
###### **Hbr 13,9**
 Nie dajcie się pociągnąć rozmaitym dziwnym naukom, bo dobre jest to, aby serce umacniało się łaską, a nie pokarmami. Ludziom, którzy właśnie je postawili w centrum swego życia, nie przyniosło to korzyści.
###### **Hbr 13,10**
 Mamy ołtarz, z którego nie wolno spożywać tym, co służą w Namiocie.
###### **Hbr 13,11**
 Bo kohen hagadol wnosi krew zwierząt do Miejsca Najświętszego jako ofiarę za grzech, lecz ciała ich są spalane poza obozem.
###### **Hbr 13,12**
 Również Jeszua poniósł śmierć za bramą, aby uczynić lud świętym poprzez własną krew.
###### **Hbr 13,13**
 Dlatego wyjdźmy do Tego, który jest poza obozem, i dzielmy Jego pohańbienie.
###### **Hbr 13,14**
 Bo nie mamy tu trwałego miasta, przeciwnie, poszukujemy tego przyszłego.
###### **Hbr 13,15**
 Przez Niego zatem składajmy Bogu nieustannie ofiarę uwielbienia. Bo to jest naturalny owoc warg, które wyznają Jego imię.
###### **Hbr 13,16**
 Lecz nie zapominajcie czynić dobrze i dzielić się z innymi, bo w takich ofiarach Bóg ma upodobanie.
###### **Hbr 13,17**
 Bądźcie posłuszni waszym przywódcom i podporządkowujcie się im, bo oni czuwają nad waszym życiem, jako ci, którzy będą musieli zdać sprawę. Sprawcie więc, by było to dla nich zadaniem radosnym, nie zaś uciążliwym; bo to wam pożytku nie przyniesie.
###### **Hbr 13,18**
 Wytrwale módlcie się za nas, bo pewni jesteśmy, że mamy czyste sumienie i chcemy postępować właściwie we wszystkim, co robimy.
###### **Hbr 13,19**
 I tym bardziej błagam was, abyście to czynili, abym tym prędzej mógł być wam zwrócony.
###### **Hbr 13,20**
 Bóg szalomu wywiódł z martwych wielkiego Pasterza owiec, naszego Pana Jeszuę, przez krew wiecznego przymierza.
###### **Hbr 13,21**
 Niech Bóg wyposaży was we wszelkie dobro, jakiego potrzebujecie, aby pełnić Jego wolę, i niech uczyni w nas to, co się Jemu podoba, przez Jeszuę Mesjasza. Jemu niech będzie chwała na wieki wieków. Amen.
###### **Hbr 13,22**
 A nalegam, bracia, abyście przyjęli moje słowa napomnienia; bo tylko pokrótce wam napisałem.
###### **Hbr 13,23**
 Wiedzcie, że nasz brat Tymoteusz został uwolniony. Jeśli zdąży przybyć na czas, to przyprowadzę go z sobą, gdy przybędę, aby się z wami zobaczyć.
###### **Hbr 13,24**
 Pozdrówcie wszystkich, którzy wam przewodzą, i cały lud Boży. Ludzie z Italii ślą wam pozdrowienia.
###### **Hbr 13,25**
 Łaska z wami wszystkimi.1
# Hbr 13 TRO
###### **Hbr 13,1**
 **η** *hē* [[G3588]] [[T-NSF]] **φιλαδελφια** *filadelfia* Braterstwo – Miłowanie braci [[G5360]] [[N-NSF]] **μενετω** *menetō* niech pozostaje – niech trwa [[G3306]] WTV-PAM-3S
###### **Hbr 13,2**
 **της** *tēs* (o) [[G3588]] [[T-GSF]] **φιλοξενιας** *filoksenias* gościnności – miłości dla obcych [[G5381]] [[N-GSF]] **μη** *mē* nie [[G3361]] [[PRT-N]] **επιλανθανεσθε** *epilanthanesthe* zapominajcie [[G1950]] WTV-PNM-2P **δια** *dia* przez [[G1223]] [[PREP]] **ταυτης** *tautēs* tę [[G3778]] WTD-GSF **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ελαθον** *elathon* uszli uwadze [[G2990]] WTV-2AAI-3P **τινες** *tines* niektórzy [[G5100]] WTX-NPM **ξενισαντες** *ksenisantes* którzy gościli [[G3579]] WTV-AAP-NPM **αγγελους** *angelous* zwiastunów [[G32]] [[N-APM]]
###### **Hbr 13,3**
 **μιμνησκεσθε** *mimnēskesthe* Pamiętajcie [[G3403]] WTV-PNM-2P **των** *tōn* (o) [[G3588]] WTT-GPM **δεσμιων** *desmiōn* więźniach [[G1198]] WTN-GPM **ως** *hōs* jak [[G5613]] [[ADV]] **συνδεδεμενοι** *syndedemenoi* którzy są razem uwięzieni – którzy są razem związani [[G4887]] WTV-RPP-NPM **των** *tōn* (o) [[G3588]] WTT-GPM **κακουχουμενων** *kakouchoumenōn* którym wyrządza się zło – którzy są krzywdzeni [[G2558]] WTV-PPP-GPM **ως** *hōs* jak [[G5613]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **αυτοι** *autoi* oni [[G846]] WTP-NPM **οντες** *ontes* będąc [[G5607]] WTV-PXP-NPM **εν** *en* w [[G1722]] [[PREP]] **σωματι** *sōmati* ciele [[G4983]] WTN-DSN
###### **Hbr 13,4**
 **τιμιος** *timios* Szacowne – Poważane [[G5093]] [[A-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **γαμος** *gamos* małżeństwo [[G1062]] [[N-NSM]] **εν** *en* wśród [[G1722]] [[PREP]] **πασιν** *pasin* wszystkich [[G3956]] WTA-DPN **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **κοιτη** *koitē* łoże [[G2845]] [[N-NSF]] **αμιαντος** *amiantos* nieskazitelne – nieskalane [[G283]] WTA-NSF **πορνους** *pornous* rozpustników – wszeteczników [[G4205]] [[N-APM]] **δε** *de* zaś [[G1161]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **μοιχους** *moichous* cudzołożników [[G3432]] [[N-APM]] **κρινει** *krinei* osądzi [[G2919]] WTV-FAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]]
###### **Hbr 13,5**
 **αφιλαργυρος** *afilargyros* Niezamiłowany w pieniądzach – Niechciwy [[G866]] [[A-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **τροπος** *tropos* sposób [[G5158]] [[N-NSM]] **αρκουμενοι** *arkoumenoi* którzy są zadowoleni z – którym wystarcza [[G714]] WTV-PPP-NPM **τοις** *tois* (tymi) [[G3588]] WTT-DPN **παρουσιν** *parousin* które są obecne [[G3918]] WTV-PXP-DPN **αυτος** *autos* sam [[G846]] WTP-NSM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ειρηκεν** *eirēken* powiedział [[G2046]] WTV-RAI-3S-ATT **ου** *ou* nie [[G3756]] [[PRT-N]] **μη** *mē* [[G3361]] [[PRT-N]] **σε** *se* ciebie [[G4571]] WTP-2AS **ανω** *anō* porzuciłbym [[G447]] WTV-2AAS-1S **ουδ** *oud* ani [[G3761]] [[ADV]] **ου** *ou* nie [[G3756]] [[PRT-N]] **μη** *mē* [[G3361]] [[PRT-N]] **σε** *se* ciebie [[G4571]] WTP-2AS **εγκαταλιπω** *egkatalipō* opuściłbym – pozostawiłbym [[G1459]] WTV-2AAS-1S
###### **Hbr 13,6**
 **ωστε** *hōste* tak, że [[G5620]] [[CONJ]] **θαρρουντας** *tharrountas* wykazując śmiałość – mając odwagę [[G2292]] WTV-PAP-APM **ημας** *hēmas* my [[G2248]] WTP-1AP **λεγειν** *legein* mówić [[G3004]] WTV-PAN **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **εμοι** *emoi* mi [[G1698]] WTP-1DS **βοηθος** *boēthos* pomocnik – pomagający [[G998]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **φοβηθησομαι** *fobēthēsomai* będę się bał [[G5399]] WTV-FOI-1S **τι** *ti* co [[G5101]] WTI-ASN **ποιησει** *poiēsei* uczyni [[G4160]] WTV-FAI-3S **μοι** *moi* mi [[G3427]] WTP-1DS **ανθρωπος** *anthrōpos* człowiek [[G444]] [[N-NSM]]
###### **Hbr 13,7**
 **μνημονευετε** *mnēmoneuete* Pamiętajcie – Przypominajcie sobie [[G3421]] WTV-PAM-2P **των** *tōn* (o) [[G3588]] WTT-GPM **ηγουμενων** *hēgoumenōn* przewodzących – dowodzących [[G2233]] WTV-PNP-GPM **υμων** *hymōn* wami [[G5216]] WTP-2GP **οιτινες** *hoitines* którzy [[G3748]] WTR-NPM **ελαλησαν** *elalēsan* powiedzieli [[G2980]] WTV-AAI-3P **υμιν** *hymin* wam [[G5213]] WTP-2DP **τον** *ton* [[G3588]] [[T-ASM]] **λογον** *logon* Słowo [[G3056]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ων** *hōn* których [[G3739]] WTR-GPM **αναθεωρουντες** *anatheōrountes* rozpatrując – przyglądając [[G333]] WTV-PAP-NPM **την** *tēn* [[G3588]] WTT-ASF **εκβασιν** *ekbasin* wyjście [[G1545]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **αναστροφης** *anastrofēs* postępowania – obracania się [[G391]] [[N-GSF]] **μιμεισθε** *mimeisthe* naśladujcie [[G3401]] WTV-PNM-2P **την** *tēn* [[G3588]] WTT-ASF **πιστιν** *pistin* wiarę [[G4102]] WTN-ASF
###### **Hbr 13,8**
 **ιησους** *iēsous* Jezus – [JHWH jest zbawieniem] [[G2424]] [[N-NSM]] **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **χθες** *chthes* wczoraj [[G5504]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **σημερον** *sēmeron* dzisiaj [[G4594]] [[ADV]] **ο** *ho* [[G3588]] [[T-NSM]] **αυτος** *autos* Ten sam [[G846]] WTP-NSM **και** *kai* i [[G2532]] [[CONJ]] **εις** *eis* na [[G1519]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **αιωνας** *aiōnas* wieki [[G165]] [[N-APM]]
###### **Hbr 13,9**
 **διδαχαις** *didachais* Naukom – Nauczaniom [[G1322]] WTN-DPF **ποικιλαις** *poikilais* różnym – rozmaitym [[G4164]] WTA-DPF **και** *kai* i [[G2532]] [[CONJ]] **ξεναις** *ksenais* obcym [[G3581]] WTA-DPF **μη** *mē* nie [[G3361]] [[PRT-N]] **περιφερεσθε** *periferesthe* bądźcie noszeni [[G4064]] WTV-PPM-2P **καλον** *kalon* dobre – piękne [[G2570]] WTA-NSN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **χαριτι** *chariti* łasce [[G5485]] [[N-DSF]] **βεβαιουσθαι** *bebaiousthai* być utwierdzane – być umacniane [[G950]] WTV-PPN **την** *tēn* [[G3588]] WTT-ASF **καρδιαν** *kardian* serce [[G2588]] WTN-ASF **ου** *ou* nie [[G3756]] [[PRT-N]] **βρωμασιν** *brōmasin* pokarmom [[G1033]] WTN-DPN **εν** *en* w [[G1722]] [[PREP]] **οις** *hois* których [[G3739]] WTR-DPN **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ωφεληθησαν** *ōfelēthēsan* odnieśli korzyści [[G5623]] WTV-API-3P **οι** *hoi* (ci) [[G3588]] WTT-NPM **περιπατησαντες** *peripatēsantes* którzy postępowali – którzy chodzili [[G4043]] WTV-AAP-NPM
###### **Hbr 13,10**
 **εχομεν** *echomen* Mamy [[G2192]] WTV-PAI-1P **θυσιαστηριον** *thysiastērion* ołtarz [[G2379]] WTN-ASN **εξ** *eks* z [[G1537]] [[PREP]] **ου** *hou* którego [[G3739]] WTR-GSN **φαγειν** *fagein* zjeść [[G5315]] [[V-2AAN]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εχουσιν** *echousin* mają [[G2192]] WTV-PAI-3P **εξουσιαν** *eksousian* władzy [[G1849]] WTN-ASF **οι** *hoi* [[G3588]] WTT-NPM **τη** *tē* [[G3588]] WTT-DSF **σκηνη** *skēnē* namiotowi – przybytkowi [[G4633]] [[N-DSF]] **λατρευοντες** *latreuontes* służący [[G3000]] WTV-PAP-NPM
###### **Hbr 13,11**
 **ων** *hōn* Których [[G3739]] WTR-GPN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εισφερεται** *eisferetai* jest wnoszona – jest wprowadzana [[G1533]] WTV-PPI-3S **ζωων** *zōōn* zwierząt – istot żywych [[G2226]] WTN-GPN **το** *to* [[G3588]] WTT-NSN **αιμα** *haima* krew [[G129]] WTN-NSN **περι** *peri* za [[G4012]] [[PREP]] **αμαρτιας** *hamartias* grzech [[G266]] [[N-GSF]] **εις** *eis* do [[G1519]] [[PREP]] **τα** *ta* [[G3588]] WTT-APN **αγια** *hagia* świętych [[G39]] WTA-APN **δια** *dia* przez [[G1223]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **αρχιερεως** *archiereōs* arcykapłana [[G749]] [[N-GSM]] **τουτων** *toutōn* tych [[G5130]] WTD-GPN **τα** *ta* [[G3588]] WTT-NPN **σωματα** *sōmata* ciała [[G4983]] WTN-NPN **κατακαιεται** *katakaietai* jest spalane [[G2618]] WTV-PPI-3S **εξω** *eksō* poza – (na) zewnątrz [[G1854]] [[ADV]] **της** *tēs* [[G3588]] [[T-GSF]] **παρεμβολης** *parembolēs* obozem [[G3925]] [[N-GSF]]
###### **Hbr 13,12**
 **διο** *dio* Dlatego [[G1352]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **ιησους** *iēsous* Jezus – [JHWH jest zbawieniem] [[G2424]] [[N-NSM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **αγιαση** *hagiasē* uświęciłby [[G37]] WTV-AAS-3S **δια** *dia* przez [[G1223]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **ιδιου** *idiou* własną [[G2398]] WTA-GSM **αιματος** *haimatos* krew [[G129]] [[N-GSN]] **τον** *ton* [[G3588]] [[T-ASM]] **λαον** *laon* lud [[G2992]] [[N-ASM]] **εξω** *eksō* poza – (na) zewnątrz [[G1854]] [[ADV]] **της** *tēs* [[G3588]] [[T-GSF]] **πυλης** *pylēs* bramy [[G4439]] [[N-GSF]] **επαθεν** *epathen* wycierpiał [[G3958]] WTV-2AAI-3S
###### **Hbr 13,13**
 **τοινυν** *toinyn* Zatem [[G5106]] WTPRT **εξερχωμεθα** *ekserchōmetha* wychodzilibyśmy [[G1831]] WTV-PNS-1P **προς** *pros* do [[G4314]] [[PREP]] **αυτον** *auton* Niego [[G846]] WTP-ASM **εξω** *eksō* poza – (na) zewnątrz [[G1854]] [[ADV]] **της** *tēs* [[G3588]] [[T-GSF]] **παρεμβολης** *parembolēs* obozu [[G3925]] [[N-GSF]] **τον** *ton* [[G3588]] [[T-ASM]] **ονειδισμον** *oneidismon* zniewagę – obelgę [[G3680]] [[N-ASM]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **φεροντες** *ferontes* niosąc [[G5342]] WTV-PAP-NPM
###### **Hbr 13,14**
 **ου** *ou* nie [[G3756]] [[PRT-N]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εχομεν** *echomen* mamy [[G2192]] WTV-PAI-1P **ωδε** *hōde* tu [[G5602]] [[ADV]] **μενουσαν** *menousan* trwającego – pozostającego [[G3306]] WTV-PAP-ASF **πολιν** *polin* miasta [[G4172]] WTN-ASF **αλλα** *alla* ale [[G235]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **μελλουσαν** *mellousan* mającego nastąpić – mającego nadejść [[G3195]] WTV-PAP-ASF **επιζητουμεν** *epizētoumen* poszukujemy [[G1934]] WTV-PAI-1P
###### **Hbr 13,15**
 **δι** *di* przez [[G1223]] [[PREP]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ουν** *oun* więc [[G3767]] [[CONJ]] **αναφερωμεν** *anaferōmen* przynosilibyśmy [[G399]] WTV-PAS-1P **θυσιαν** *thysian* ofiarę [[G2378]] WTN-ASF **αινεσεως** *aineseōs* chwały – uwielbienia [[G133]] [[N-GSF]] **διαπαντος** *diapantos* przez cały [[G1275]] [[ADV]] **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **τουτ** *tout* to [[G5124]] WTD-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **καρπον** *karpon* owoc [[G2590]] [[N-ASM]] **χειλεων** *cheileōn* warg [[G5491]] WTN-GPN **ομολογουντων** *homologountōn* wyznających [[G3670]] WTV-PAP-GPM **τω** *tō* [[G3588]] WTT-DSN **ονοματι** *onomati* imieniu [[G3686]] WTN-DSN **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Hbr 13,16**
 **της** *tēs* [[G3588]] [[T-GSF]] **δε** *de* zaś [[G1161]] [[CONJ]] **ευποιιας** *eupoiias* (o) dobroczynności – (o) czynieniu dobra [[G2140]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **κοινωνιας** *koinōnias* wspólnocie [[G2842]] [[N-GSF]] **μη** *mē* nie [[G3361]] [[PRT-N]] **επιλανθανεσθε** *epilanthanesthe* zapominajcie [[G1950]] WTV-PNM-2P **τοιαυταις** *toiautais* (z) takich [[G5108]] WTD-DPF **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **θυσιαις** *thysiais* ofiar [[G2378]] WTN-DPF **ευαρεστειται** *euaresteitai* jest bardzo zadowolony [[G2100]] WTV-PPI-3S **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]]
###### **Hbr 13,17**
 **πειθεσθε** *peithesthe* Okazujcie posłuszeństwo – Ulegajcie [[G3982]] WTV-PMM-2P **τοις** *tois* [[G3588]] WTT-DPM **ηγουμενοις** *hēgoumenois* przewodzącym – dowodzącym [[G2233]] WTV-PNP-DPM **υμων** *hymōn* wami [[G5216]] WTP-2GP **και** *kai* i [[G2532]] [[CONJ]] **υπεικετε** *hypeikete* poddawajcie się [[G5226]] WTV-PAM-2P **αυτοι** *autoi* oni [[G846]] WTP-NPM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **αγρυπνουσιν** *agrypnousin* czuwają – trwają bez snu [[G69]] WTV-PAI-3P **υπερ** *hyper* nad [[G5228]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPF **ψυχων** *psychōn* duszami [[G5590]] WTN-GPF **υμων** *hymōn* waszymi [[G5216]] WTP-2GP **ως** *hōs* jak [[G5613]] [[ADV]] **λογον** *logon* rachunek – słowo [[G3056]] [[N-ASM]] **αποδωσοντες** *apodōsontes* którzy mają oddać [[G591]] WTV-FAP-NPM **ινα** *hina* aby [[G2443]] [[CONJ]] **μετα** *meta* z [[G3326]] [[PREP]] **χαρας** *charas* radością [[G5479]] [[N-GSF]] **τουτο** *touto* to [[G5124]] WTD-ASN **ποιωσιν** *poiōsin* czyniliby [[G4160]] WTV-PAS-3P **και** *kai* i [[G2532]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **στεναζοντες** *stenazontes* wzdychając – narzekając [[G4727]] WTV-PAP-NPM **αλυσιτελες** *alysiteles* niekorzystne [[G255]] WTA-NSN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **τουτο** *touto* to [[G5124]] WTD-NSN
###### **Hbr 13,18**
 **προσευχεσθε** *proseuchesthe* Módlcie się [[G4336]] WTV-PNM-2P **περι** *peri* o [[G4012]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP **πεποιθαμεν** *pepoithamen* jesteśmy przekonani – pokładamy ufność [[G3982]] WTV-2RAI-1P **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **οτι** *hoti* że [[G3754]] [[CONJ]] **καλην** *kalēn* dobre – piękne [[G2570]] WTA-ASF **συνειδησιν** *syneidēsin* sumienie [[G4893]] WTN-ASF **εχομεν** *echomen* mamy [[G2192]] WTV-PAI-1P **εν** *en* we [[G1722]] [[PREP]] **πασιν** *pasin* wszystkim [[G3956]] WTA-DPN **καλως** *kalōs* dobrze – pięknie [[G2573]] [[ADV]] **θελοντες** *thelontes* chcąc [[G2309]] WTV-PAP-NPM **αναστρεφεσθαι** *anastrefesthai* postępować – być obracanym [[G390]] WTV-PPN
###### **Hbr 13,19**
 **περισσοτερως** *perissoterōs* Obficiej [[G4056]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **παρακαλω** *parakalō* zachęcam [[G3870]] WTV-PAI-1S **τουτο** *touto* (by) to [[G5124]] WTD-ASN **ποιησαι** *poiēsai* uczynić [[G4160]] [[V-AAN]] **ινα** *hina* aby [[G2443]] [[CONJ]] **ταχιον** *tachion* szybciej – prędzej [[G5032]] [[ADV]]-C **αποκατασταθω** *apokatastathō* zostałbym przywrócony [[G600]] WTV-APS-2S **υμιν** *hymin* wam [[G5213]] WTP-2DP
###### **Hbr 13,20**
 **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **της** *tēs* [[G3588]] [[T-GSF]] **ειρηνης** *eirēnēs* pokoju [[G1515]] [[N-GSF]] **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **αναγαγων** *anagagōn* który wyprowadził [[G321]] WTV-2AAP-NSM **εκ** *ek* z [[G1537]] [[PREP]] **νεκρων** *nekrōn* martwych [[G3498]] WTA-GPM **τον** *ton* [[G3588]] [[T-ASM]] **ποιμενα** *poimena* Pasterza [[G4166]] [[N-ASM]] **των** *tōn* [[G3588]] WTT-GPN **προβατων** *probatōn* owiec [[G4263]] WTN-GPN **τον** *ton* (Tego) [[G3588]] [[T-ASM]] **μεγαν** *megan* wielkiego [[G3173]] WTA-ASM **εν** *en* w [[G1722]] [[PREP]] **αιματι** *haimati* krwi [[G129]] WTN-DSN **διαθηκης** *diathēkēs* przymierza [[G1242]] [[N-GSF]] **αιωνιου** *aiōniou* wiecznego [[G166]] WTA-GSF **τον** *ton* [[G3588]] [[T-ASM]] **κυριον** *kyrion* Pana [[G2962]] [[N-ASM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]]
###### **Hbr 13,21**
 **καταρτισαι** *katartisai* oby umocnił – oby wydoskonalił [[G2675]] WTV-AAO-3S **υμας** *hymas* was [[G5209]] WTP-2AP **εν** *en* w [[G1722]] [[PREP]] **παντι** *panti* każdym [[G3956]] WTA-DSN **εργω** *ergō* czynie – dziele [[G2041]] WTN-DSN **αγαθω** *agathō* dobrym [[G18]] WTA-DSN **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **ποιησαι** *poiēsai* uczynić [[G4160]] [[V-AAN]] **το** *to* [[G3588]] WTT-ASN **θελημα** *thelēma* wolę [[G2307]] WTN-ASN **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ποιων** *poiōn* czyniąc [[G4160]] [[V-PAP-NSM]] **εν** *en* w [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **το** *to* [[G3588]] WTT-ASN **ευαρεστον** *euareston* bardzo podobające się [[G2101]] WTA-ASN **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **αυτου** *autou* Nim [[G846]] [[P-GSM]] **δια** *dia* przez [[G1223]] [[PREP]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **ω** *hō* któremu [[G3739]] WTR-DSM **η** *hē* [[G3588]] [[T-NSF]] **δοξα** *doksa* chwała [[G1391]] [[N-NSF]] **εις** *eis* na [[G1519]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **αιωνας** *aiōnas* wieki [[G165]] [[N-APM]] **των** *tōn* [[G3588]] WTT-GPM **αιωνων** *aiōnōn* wieków [[G165]] WTN-GPM **αμην** *amēn* amen – [zaprawdę] [[G281]] WTHEB
###### **Hbr 13,22**
 **παρακαλω** *parakalō* Zachęcam [[G3870]] WTV-PAI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **υμας** *hymas* was [[G5209]] WTP-2AP **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **ανεχεσθε** *anechesthe* znoście [[G430]] WTV-PNM-2P **του** *tou* (to) [[G3588]] WTT-GSM **λογου** *logou* słowo [[G3056]] [[N-GSM]] **της** *tēs* [[G3588]] [[T-GSF]] **παρακλησεως** *paraklēseōs* zachęty – pociechy [[G3874]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **δια** *dia* przez [[G1223]] [[PREP]] **βραχεων** *bracheōn* krótkie – małe [[G1024]] WTA-GPN **επεστειλα** *epesteila* napisałem listem – przekazałem listem [[G1989]] WTV-AAI-1S **υμιν** *hymin* wam [[G5213]] WTP-2DP
###### **Hbr 13,23**
 **γινωσκετε** *ginōskete* Wiecie [[G1097]] WTV-PAI-2P **τον** *ton* (że) [[G3588]] [[T-ASM]] **αδελφον** *adelfon* brata [[G80]] [[N-ASM]] **τιμοθεον** *timotheon* Tymoteusz – [czczący Boga] [[G5095]] [[N-ASM]] **απολελυμενον** *apolelymenon* który jest wypuszczony – który jest uwolniony [[G630]] WTV-RPP-ASM **μεθ** *meth* z [[G3326]] [[PREP]] **ου** *hou* którym [[G3739]] WTR-GSM **εαν** *ean* jeśli [[G1437]] WTCOND **ταχιον** *tachion* szybciej – prędzej [[G5032]] [[ADV]]-C **ερχηται** *erchētai* przychodziłby [[G2064]] WTV-PNS-3S **οψομαι** *opsomai* zobaczę [[G3700]] WTV-FDI-1S **υμας** *hymas* was [[G5209]] WTP-2AP
###### **Hbr 13,24**
 **ασπασασθε** *aspasasthe* Pozdrówcie [[G782]] WTV-ADM-2P **παντας** *pantas* wszystkich [[G3956]] WTA-APM **τους** *tous* [[G3588]] WTT-APM **ηγουμενους** *hēgoumenous* przewodzących – dowodzących [[G2233]] WTV-PNP-APM **υμων** *hymōn* wami [[G5216]] WTP-2GP **και** *kai* i [[G2532]] [[CONJ]] **παντας** *pantas* wszystkich [[G3956]] WTA-APM **τους** *tous* [[G3588]] WTT-APM **αγιους** *hagious* świętych [[G40]] WTA-APM **ασπαζονται** *aspazontai* pozdrawiają [[G782]] WTV-PNI-3P **υμας** *hymas* was [[G5209]] WTP-2AP **οι** *hoi* (ci) [[G3588]] WTT-NPM **απο** *apo* z [[G575]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **ιταλιας** *italias* Italii – Włoch [[G2482]] [[N-GSF]]
###### **Hbr 13,25**
 **η** *hē* [[G3588]] [[T-NSF]] **χαρις** *charis* Łaska [[G5485]] [[N-NSF]] **μετα** *meta* z [[G3326]] [[PREP]] **παντων** *pantōn* wszystkimi [[G3956]] WTA-GPM **υμων** *hymōn* wami [[G5216]] WTP-2GP **αμην** *amēn* amen – [zaprawdę] [[G281]] WTHEB **προς** *pros* do [[G4314]] [[PREP]] **εβραιους** *hebraious* Hebrajczyków – [poza obszar] [[G1445]] WTA-APM **εγραφη** *egrafē* zostało napisane [[G1125]] WTV-2API-3S **απο** *apo* z [[G575]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **ιταλιας** *italias* Italii – Włoch [[G2482]] [[N-GSF]] **δια** *dia* przez [[G1223]] [[PREP]] **τιμοθεου** *timotheou* Tymoteusza – [czczący Boga] [[G5095]] [[N-GSM]]
