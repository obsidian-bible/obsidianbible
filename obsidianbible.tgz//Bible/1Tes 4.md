# 1Tes 4 BT5
###### **1Tes 4,1**
 Na koniec więc, bracia, prosimy was i napominamy w Panu Jezusie: zgodnie z tym, co od nas przejęliście o sposobie postępowania i podobania się Bogu – jak już zresztą postępujecie – stawajcie się coraz doskonalszymi!
###### **1Tes 4,2**
 Wiecie przecież, jakie nakazy daliśmy wam w imię Pana Jezusa.
###### **1Tes 4,3**
 Albowiem wolą Bożą jest wasze uświęcenie: powstrzymywanie się od rozpusty,
###### **1Tes 4,4**
 aby każdy umiał utrzymywać własne ciało w świętości i we czci,
###### **1Tes 4,5**
 a nie w pożądliwej namiętności, jak to czynią nie znający Boga poganie.
###### **1Tes 4,6**
 Niech nikt w tej sprawie nie wykracza i nie oszukuje brata swego, bo jak wam to przedtem powiedzieliśmy, zapewniając uroczyście: Pan jest mścicielem tego wszystkiego.
###### **1Tes 4,7**
 Albowiem nie powołał nas Bóg do nieczystości, ale do świętości.
###### **1Tes 4,8**
 A więc kto [te słowa] odrzuca, nie człowieka odrzuca, lecz Boga, który przecież daje wam swego Ducha Świętego.
###### **1Tes 4,9**
 Nie jest rzeczą konieczną, abyśmy wam pisali o miłości braterskiej, albowiem Bóg was samych naucza, byście się wzajemnie miłowali.
###### **1Tes 4,10**
 Czynicie to przecież w stosunku do wszystkich braci w całej Macedonii.
###### **1Tes 4,11**
 Zachęcam was jedynie, bracia, abyście coraz bardziej się doskonalili i starali zachować spokój, spełniać własne obowiązki i pracować swoimi rękami, jak to wam przykazaliśmy,
###### **1Tes 4,12**
 żebyście wobec tych, którzy pozostają na zewnątrz, postępowali szlachetnie, a nie będziecie potrzebować nikogo.
###### **1Tes 4,13**
 Nie chcemy, bracia, byście trwali w niewiedzy co do tych, którzy umierają, abyście się nie smucili jak wszyscy ci, którzy nie mają nadziei.
###### **1Tes 4,14**
 Jeśli bowiem wierzymy, że Jezus istotnie umarł i zmartwychwstał, to również tych, którzy umarli w Jezusie, Bóg wyprowadzi wraz z Nim.
###### **1Tes 4,15**
 To bowiem głosimy wam jako słowo Pańskie, że my, żywi, pozostawieni na przyjście Pana, nie wyprzedzimy tych, którzy pomarli.
###### **1Tes 4,16**
 Sam bowiem Pan zstąpi z nieba na hasło i na głos archanioła, i na dźwięk trąby Bożej, a zmarli w Chrystusie powstaną pierwsi.
###### **1Tes 4,17**
 Potem my, żywi, [tak] pozostawieni, wraz z nimi będziemy porwani w powietrze, na obłoki naprzeciw Pana, i w ten sposób na zawsze będziemy z Panem.
###### **1Tes 4,18**
 Przeto wzajemnie się pocieszajcie tymi słowami.
# 1Tes 4 PAU
###### **1Tes 4,1**
 Ponadto, bracia, prosimy i upominamy was w imię Pana Jezusa: postępujcie tak, jak wam przekazaliśmy, abyście podobali się Bogu. Owszem, już tak postępujecie, ale czyńcie to coraz lepiej!
###### **1Tes 4,2**
 Znacie przecież polecenia, jakie daliśmy wam w imię Pana Jezusa.
###### **1Tes 4,3**
 Jest wolą Boga, abyście byli święci. Powstrzymajcie się od nierządu.
###### **1Tes 4,4**
 Niech każdy z was wie, że własne ciało należy traktować z szacunkiem jako święte,
###### **1Tes 4,5**
 a nie z namiętnym pożądaniem, jak to czynią poganie, którzy nie znają Boga.
###### **1Tes 4,6**
 Niech nikt w tej sprawie nie popełnia wykroczeń i nie oszukuje swego brata, ponieważ Pan będzie karał za wszystkie takie czyny, jak to już powiedzieliśmy i zaświadczyliśmy.
###### **1Tes 4,7**
 Bóg bowiem nie powołał nas do nieczystości, lecz do świętości.
###### **1Tes 4,8**
 Kto więc to lekceważy, lekceważy nie człowieka, lecz Boga, który daje wam swego Ducha Świętego.
###### **1Tes 4,9**
 Nie musimy natomiast pisać wam o braterskiej miłości, gdyż sam Bóg was pouczył, abyście się wzajemnie miłowali.
###### **1Tes 4,10**
 Czynicie to przecież względem wszystkich braci w całej Macedonii. Zachęcamy was jedynie, bracia: czyńcie to coraz doskonalej!
###### **1Tes 4,11**
 Usiłujcie zachować spokój, jak wam nakazaliśmy, spełniajcie to, co do was należy, i sami pracujcie na swe utrzymanie,
###### **1Tes 4,12**
 abyście postępując szlachetnie wobec ludzi z zewnątrz, nie byli od nikogo zależni.
###### **1Tes 4,13**
 Nie chcemy, bracia, byście nie wiedzieli o losie tych, którzy umierają. Nie smućcie się zatem, jak inni, którzy nie mają nadziei.
###### **1Tes 4,14**
 Jeżeli bowiem wierzymy, że Jezus umarł i zmartwychwstał, to wraz z Nim Bóg przywróci do życia także tych, którzy zasnęli zjednoczeni z Jezusem.
###### **1Tes 4,15**
 To wam głosimy jako słowo Pańskie: my, którzy nadal żyjemy pozostawieni do przyjścia Pana, nie wyprzedzimy tych, którzy zasnęli.
###### **1Tes 4,16**
 Bowiem sam Pan zstąpi z nieba na wezwanie, na głos archanioła i dźwięk trąby Bożej. Wówczas ci, którzy umarli w Chrystusie, powstaną pierwsi.
###### **1Tes 4,17**
 Potem my, pozostawieni przy życiu, wraz z nimi będziemy porwani w obłoki, w powietrze, na spotkanie Pana. I tak zostaniemy z Panem na zawsze.
###### **1Tes 4,18**
 Tymi słowami pocieszajcie jedni drugich.
# 1Tes 4 BP
###### **1Tes 4,1**
 Bracia, w końcu więc prosimy was i zaklinamy w Panu Jezusie, abyście tak postępowali, Bogu się podobając, jak was pouczaliśmy. Tak więc postępujcie, a będziecie wzrastali w doskonałości.
###### **1Tes 4,2**
 Znacie bowiem nakazy, jakie daliśmy wam od Jezusa Chrystusa.
###### **1Tes 4,3**
 Bożą wolą jest wasza świętość, wystrzegajcie się rozpusty.
###### **1Tes 4,4**
 Niech każdy współżyje ze swoją żoną w świętości i czci,
###### **1Tes 4,5**
 a nie ulega naporowi żądzy, jak to czynią nie znający Boga poganie.
###### **1Tes 4,6**
 Niech nikt w tej dziedzinie nie narusza prawa bliźniego, gdyż Pan jest mścicielem tego wszystkiego, o czym was już przedtem pouczyliśmy, powołując się na Boga.
###### **1Tes 4,7**
 Bóg bowiem nie powołał nas do nieczystości, ale do świętości.
###### **1Tes 4,8**
 Kto więc odrzuca te słowa, odrzuca nakazy nie ludzi, lecz Boga, który udziela wam swego Ducha Świętego.
###### **1Tes 4,9**
 A co do wzajemnej miłości, nie ma potrzeby wam o tym pisać, gdy Bóg sam was pouczył, abyście się wzajemnie miłowali.
###### **1Tes 4,10**
 Czynicie tak przecież wobec wszystkich braci w całej Macedonii. Zachęcamy was jedynie, abyście wzrastali w doskonałości.
###### **1Tes 4,11**
 Starajcie się usilnie wieść życie skromne, obowiązki swoje wypełniać sumiennie i pracować własnymi rękoma, jak to wam przykazaliśmy.
###### **1Tes 4,12**
 Wówczas w oczach ludzi spoza Kościoła postępować będziecie z godnością i nie będziecie potrzebowali niczyjej pomocy.
###### **1Tes 4,13**
 Nie chcemy zaś, bracia, abyście nie wiedzieli o losie waszych zmarłych; nie smućcie się jak ci, którzy nadziei nie mają.
###### **1Tes 4,14**
 Jeżeli bowiem wierzymy, że Jezus umarł i zmartwychwstał, to musimy wierzyć, że Bóg przyprowadzi także zmarłych razem z Nim.
###### **1Tes 4,15**
 A mówimy to wam na podstawie słowa Pana, że my, żywi i pozostawieni na powtórne przyjście Pana, nie uprzedzimy zmarłych,
###### **1Tes 4,16**
 że na dany znak, na głos archanioła i dźwięk trąby Bożej, sam Pan zstąpi z nieba, a zmarli w Chrystusie powstaną pierwsi.
###### **1Tes 4,17**
 Następnie my, pozostawieni wśród żyjących, razem z nimi zostaniemy uniesieni w przestworza, na obłoki naprzeciwko Pana, i tak już na zawsze z Panem pozostaniemy.
###### **1Tes 4,18**
 Tą więc nauką pocieszajcie się wzajemnie.
# 1Tes 4 BR
###### **1Tes 4,1**
 Na koniec, bracia, prosimy was i polecamy wam bardzo stanowczo w imię Pana Jezusa, abyście - zgodnie z waszym dotychczasowym postępowaniem - stawali się coraz bardziej doskonałymi, stosownie do pouczeń, które otrzymaliście od nas w sprawie doskonalenia się duchowego i przypodobania się Bogu.
###### **1Tes 4,2**
 Wiecie przecież, jakie to zalecenia przekazaliśmy wam przez Pana Jezusa.
###### **1Tes 4,3**
 Otóż Bóg chce, żebyście byli świętymi, to znaczy, żebyście unikali rozpusty,
###### **1Tes 4,4**
 by każdy z was umiał utrzymać swe ciało w świętości i czci,
###### **1Tes 4,5**
 a nie poddawał się pożądliwym namiętnościom, jak to czynią poganie, którzy nie znają Boga.
###### **1Tes 4,6**
 W tych sprawach niech nikt nie dopuszcza się żadnych wykroczeń ani nie próbuje oszukiwać swego brata, gdyż powiedzieliśmy wam to już i przestrzegaliśmy was z całą stanowczością, że Pan sam wymierzy surową karę za wszystkie takie występki.
###### **1Tes 4,7**
 Powołał nas bowiem Bóg nie do rozpusty, lecz do świętości.
###### **1Tes 4,8**
 Tak więc kto odrzuca to pouczenie, odrzuca nie tylko człowieka, lecz Boga, który jest dawcą Ducha Świętego.
###### **1Tes 4,9**
 Nie muszę wam pisać o potrzebie miłości braterskiej, gdyż przez samego Boga zostaliście pouczeni, jak powinniście miłować jedni drugich.
###### **1Tes 4,10**
 Zgodnie zresztą z tym pouczeniem darzycie miłością wszystkich braci w całej Macedonii. My zaś ograniczymy się już tylko do zachęcenia was, abyście się w tej miłości doskonalili coraz bardziej.
###### **1Tes 4,11**
 Starajcie się zachować spokój, wypełniać wasze obowiązki i pracować własnymi rękami zgodnie z naszymi uprzednimi zaleceniami.
###### **1Tes 4,12**
 Zachowujcie się też godnie wobec tych, którzy nie należą do społeczności chrześcijańskiej, i nie bądźcie dla nikogo ciężarem.
###### **1Tes 4,13**
 Bracia, nie chcielibyśmy, żebyście trwali w niewiedzy co do losu tych, którzy umierają; [nie chcielibyśmy], żebyście popadali w smutek jak inni, którzy nie mają nadziei.
###### **1Tes 4,14**
 Jeśli bowiem wierzymy, że Jezus Chrystus [nie tylko] umarł [lecz także] i zmartwychwstał, to i tych, którzy umarli [w Jezusie], przez Jezusa przywróci Bóg ponownie do życia.
###### **1Tes 4,15**
 Otóż pragniemy was zapewnić, opierając się na pouczeniach Pańskich, że my, pozostawieni przy życiu do dnia przyjścia Pana, nie wyprzedzimy tych, którzy będą już wtedy zmarli.
###### **1Tes 4,16**
 Na głos archanioła i na dźwięk trąby Bożej Pan sam zstąpi z nieba, a zmarli w Chrystusie zmartwychwstaną pierwsi.
###### **1Tes 4,17**
 Potem my, pozostający jeszcze wtedy przy życiu wraz z nimi będziemy uniesieni w powietrze, w obłoki, na spotkanie z Panem, z którym tak już na zawsze pozostaniemy.
###### **1Tes 4,18**
 Właśnie tymi słowami powinniście się pokrzepiać nawzajem.
# 1Tes 4 WUJ
###### **1Tes 4,1**
 Na ostatek tedy bracia, żądamy was i prosiemy w Panu Jezusie, aby jakoście wzięli od nas, jako się macie sprawować, i Bogu podobać się, tak żebyście się i sprawowali: żebyście więcej obfitowali.
###### **1Tes 4,2**
 Bo wiecie, które rozkazania dałem wam przez Pana Jezusa.
###### **1Tes 4,3**
 Abowiem ta jest wola Boża, poświęcenie wasze: żebyście się powściągali od porubstwa,
###### **1Tes 4,4**
 Aby umiał każdy z was naczynie swe trzymać w świątobliwości i uczciwości:
###### **1Tes 4,5**
 Nie w namiętności żądze, jako i Pogani, którzy nie znają Boga,
###### **1Tes 4,6**
 Ażeby kto nie podchodził, ani oszukiwał w sprawie brata swego: abowiem mścicielem jest Pan wszystkiego tego, jakośmy wam przedtem powiadali, i oświadczali.
###### **1Tes 4,7**
 Bo nas Bóg nie wezwał ku nieczystości: ale ku poświęceniu.
###### **1Tes 4,8**
 A przeto, który tam gardzi, nie gardzi Człowiekiem, ale Bogiem, który też w nas dał Ducha swego świętego.
###### **1Tes 4,9**
 A o miłości braterstwa nie potrzeba nam do was pisać: abowiem wy sami od Boga jesteście nauczeni, abyście jedni drugie miłowali.
###### **1Tes 4,10**
 Abowiem to czynicie przeciw wszystkiej braciej we wszystkiej, Macedoniej. A prosimy was bracia iżbyście więcej obfitowali:
###### **1Tes 4,11**
 I starali się, abyście spokojnymi byli, a żebyście sprawy wasze sprawowali, i rękami swemi robili, jakośmy wam rozkazali:
###### **1Tes 4,12**
 A iżbyście uczciwie się obchodzili z temi, którzy są obcy, a niczyjego nic nie pożądali.
###### **1Tes 4,13**
 A nie chcemy bracia, abyście wiedzieć nie mieli o tych, którzy zasnęli, iż byście się nie smucili, jako i drudzy, którzy nadzieje nie mają.
###### **1Tes 4,14**
 Abowiem, jeśli wierzymy, iż Jezus umarł i zmartwychwstał: tak i Bóg te, którzy zasnęli przez Jezusa przyprowadzi z nim.
###### **1Tes 4,15**
 Abowiem to wam powiadamy w słowie Pańskiem, iż my którzy żyjemy którzyśmy pozostali, na przyście Pańskie nie uprzedzimy tych, którzy zasnęli.
###### **1Tes 4,16**
 Abowiem sam Pan z rozkazaniem i z głosem Archanielskim i z trąbą Bożą zstąpi z nieba: a pomarli, którzy są w Chrystusie, powstaną pierwszy.
###### **1Tes 4,17**
 Potem my: którzy żyjemy, którzy pozostajemy, pospołu pochwyceni będziemy z niemi w obłokach przeciw Chrystusowi na powietrze, a tak zawsze z Panem będziemy.
###### **1Tes 4,18**
 Przeto cieszcie się społem temi słowy.
# 1Tes 4 STERN
###### **1Tes 4,1**
 Dlatego, bracia, tak jak nauczyliście się od nas, jak trzeba żyć, aby podobać się Bogu, i jak w ten sposób dziś żyjecie, prosimy was - zaiste, zjednoczeni w Panem Jeszuą, zaklinamy was - abyście tym usilniej tak postępowali.
###### **1Tes 4,2**
 Bo wiecie, jakie pouczenia daliśmy wam mocą Pana Jeszui.
###### **1Tes 4,3**
 Tego chce Bóg, abyście byli święci, abyście wystrzegali się rozwiązłości,
###### **1Tes 4,4**
 aby każdy z was wiedział, jak panować nad swymi popędami w sposób święty i godny,
###### **1Tes 4,5**
 nie ulegając pożądliwym pragnieniom, jak poganie, którzy Boga nie znają.
###### **1Tes 4,6**
 Nikt nie powinien krzywdzić brata w tej dziedzinie ani go wykorzystywać, bo Pan karze wszystkich, którzy to czynią, jak to wam przedtem obszernie wyłuszczyliśmy.
###### **1Tes 4,7**
 Bóg bowiem nie powołał nas do życia nieczystego, lecz do świętego.
###### **1Tes 4,8**
 Kto zatem odrzuca tę naukę, odrzuca nie człowieka, ale Boga, Tego, który daje wam należącego do siebie Ruach Ha-Kodesz.
###### **1Tes 4,9**
 O miłości do braci nie potrzebujemy wam pisać, bo was samych Bóg pouczył, aby kochać się wzajemnie,
###### **1Tes 4,10**
 i rzeczywiście kochacie wszystkich braci w całej Macedonii. Ale zaklinamy was, bracia, czyńcie to tym usilniej.
###### **1Tes 4,11**
 Postawcie też sobie za cel, aby żyć spokojnie, pilnować swoich obowiązków i własną pracą zarabiać na chleb, tak jak wam mówiliśmy.
###### **1Tes 4,12**
 Wtedy wasze codzienne życie zyska uznanie ludzi z zewnątrz i od nikogo nie będziecie zależni.
###### **1Tes 4,13**
 A teraz, bracia, chcemy, abyście poznali prawdę co do tych, którzy umarli, żebyście czasem nie smucili się tak, jak inni ludzie,
###### **1Tes 4,14**
 którzy nie mają w czym złożyć nadziei. Bo skoro wierzymy, że Jeszua umarł i powstał z martwych, wierzymy też, że w ten sam sposób Bóg - przez Jeszuę - zabierze ze sobą tych, którzy umarli.
###### **1Tes 4,15**
 Kiedy to mówimy, opieramy się na słowie samego Pana: my, którzy pozostaniemy przy życiu z chwilą przyjścia Pana, z pewnością nie wyprzedzimy tych, którzy umarli.
###### **1Tes 4,16**
 Bo sam Pan zstąpi z nieba z gromkim okrzykiem, na wezwanie jednego z władców anielskich i na dźwięk szofaru Bożego. Ci, którzy umarli zjednoczeni z Mesjaszem, powstaną jako pierwsi,
###### **1Tes 4,17**
 potem my, którzy pozostaliśmy jako jeszcze żywi, zostaniemy pochwyceni wraz z nimi w obłoki na spotkanie z Panem w powietrzu, i w ten sposób zawsze będziemy z Panem.
###### **1Tes 4,18**
 Dodawajcie więc sobie otuchy tymi słowami.
# 1Tes 4 TRO
###### **1Tes 4,1**
 **το** *to* [[G3588]] WTT-NSN **λοιπον** *loipon* W końcu [[G3063]] WTA-NSN **ουν** *oun* więc [[G3767]] [[CONJ]] **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **ερωτωμεν** *erōtōmen* prosimy [[G2065]] WTV-PAI-1P **υμας** *hymas* was [[G5209]] WTP-2AP **και** *kai* i [[G2532]] [[CONJ]] **παρακαλουμεν** *parakaloumen* zachęcamy [[G3870]] WTV-PAI-1P **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **παρελαβετε** *parelabete* przyjęliście [[G3880]] WTV-2AAI-2P **παρ** *par* od [[G3844]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP **το** *to* [[G3588]] WTT-ASN **πως** *pōs* jak [[G4459]] [[ADV]] **δει** *dei* trzeba – jest konieczne [[G1163]] WTV-PQI-3S **υμας** *hymas* wam [[G5209]] WTP-2AP **περιπατειν** *peripatein* postępować – chodzić [[G4043]] WTV-PAN **και** *kai* i [[G2532]] [[CONJ]] **αρεσκειν** *areskein* przypodobać się [[G700]] WTV-PAN **θεω** *theō* Bogu [[G2316]] WTN-DSM **ινα** *hina* aby [[G2443]] [[CONJ]] **περισσευητε** *perisseuēte* obfitowalibyście – moglibyście przekroczyć [[G4052]] WTV-PAS-2P **μαλλον** *mallon* bardziej [[G3123]] [[ADV]]
###### **1Tes 4,2**
 **οιδατε** *oidate* Wiecie [[G1492]] WTV-RAI-2P **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **τινας** *tinas* jakie [[G5101]] WTI-APF **παραγγελιας** *parangelias* nakazy – pouczenia [[G3852]] WTN-APF **εδωκαμεν** *edōkamen* daliśmy [[G1325]] WTV-AAI-1P **υμιν** *hymin* wam [[G5213]] WTP-2DP **δια** *dia* przez – ze względu na [[G1223]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]]
###### **1Tes 4,3**
 **τουτο** *touto* To [[G5124]] WTD-NSN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **θελημα** *thelēma* wola [[G2307]] WTN-NSN **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ο** *ho* [[G3588]] [[T-NSM]] **αγιασμος** *hagiasmos* poświęcenie – uświęcenie [[G38]] [[N-NSM]] **υμων** *hymōn* wasze [[G5216]] WTP-2GP **απεχεσθαι** *apechesthai* (by) wstrzymywać się [[G567]] WTV-PMN **υμας** *hymas* wam [[G5209]] WTP-2AP **απο** *apo* od [[G575]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **πορνειας** *porneias* nierządu – wszeteczeństwa [[G4202]] [[N-GSF]]
###### **1Tes 4,4**
 **ειδεναι** *eidenai* (by) wiedzieć [[G1492]] WTV-RAN **εκαστον** *hekaston* każdy [[G1538]] WTA-ASM **υμων** *hymōn* (z) was [[G5216]] WTP-2GP **το** *to* [[G3588]] WTT-ASN **εαυτου** *heautou* swoje [[G1438]] WTF-3GSM **σκευος** *skeuos* naczynie [[G4632]] WTN-ASN **κτασθαι** *ktasthai* utrzymać – nabywać [[G2932]] WTV-PNN **εν** *en* w [[G1722]] [[PREP]] **αγιασμω** *hagiasmō* poświęceniu – uświęceniu [[G38]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **τιμη** *timē* szacunku – wartości [[G5092]] [[N-DSF]]
###### **1Tes 4,5**
 **μη** *mē* Nie [[G3361]] [[PRT-N]] **εν** *en* w [[G1722]] [[PREP]] **παθει** *pathei* zmysłowości – namiętności [[G3806]] WTN-DSN **επιθυμιας** *epithymias* pożądania – żądzy [[G1939]] [[N-GSF]] **καθαπερ** *kathaper* tak, jak [[G2509]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-NPN **εθνη** *ethnē* narody – poganie [[G1484]] WTN-NPN **τα** *ta* [[G3588]] WTT-NPN **μη** *mē* nie [[G3361]] [[PRT-N]] **ειδοτα** *eidota* znające [[G1492]] WTV-RAP-NPN **τον** *ton* [[G3588]] [[T-ASM]] **θεον** *theon* Boga [[G2316]] [[N-ASM]]
###### **1Tes 4,6**
 **το** *to* (by) [[G3588]] WTT-ASN **μη** *mē* nie [[G3361]] [[PRT-N]] **υπερβαινειν** *hyperbainein* wykraczać przeciwko [[G5233]] WTV-PAN **και** *kai* i [[G2532]] [[CONJ]] **πλεονεκτειν** *pleonektein* oszukiwać [[G4122]] WTV-PAN **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **πραγματι** *pragmati* sprawie [[G4229]] WTN-DSN **τον** *ton* [[G3588]] [[T-ASM]] **αδελφον** *adelfon* brata [[G80]] [[N-ASM]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **διοτι** *dioti* dlatego, że [[G1360]] [[CONJ]] **εκδικος** *ekdikos* mściciel [[G1558]] [[A-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **περι** *peri* o [[G4012]] [[PREP]] **παντων** *pantōn* wszystkich [[G3956]] WTA-GPM **τουτων** *toutōn* tych [[G5130]] WTD-GPM **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **προειπαμεν** *proeipamen* wcześniej powiedzieliśmy [[G4277]] WTV-AAI-1P **υμιν** *hymin* wam [[G5213]] WTP-2DP **και** *kai* i [[G2532]] [[CONJ]] **διεμαρτυραμεθα** *diemartyrametha* zaświadczyliśmy – oświadczyliśmy [[G1263]] WTV-ADI-1P
###### **1Tes 4,7**
 **ου** *ou* Nie [[G3756]] [[PRT-N]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εκαλεσεν** *ekalesen* wezwał [[G2564]] [[V-AAI-3S]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **επι** *epi* do [[G1909]] [[PREP]] **ακαθαρσια** *akatharsia* nieczystości [[G167]] [[N-DSF]] **αλλ** *all* ale [[G235]] [[CONJ]] **εν** *en* do [[G1722]] [[PREP]] **αγιασμω** *hagiasmō* poświęcenia – uświęcenia [[G38]] WTN-DSM
###### **1Tes 4,8**
 **τοιγαρουν** *toigaroun* Toteż – Przeto [[G5105]] WTPRT **ο** *ho* [[G3588]] [[T-NSM]] **αθετων** *athetōn* odrzucający [[G114]] [[V-PAP-NSM]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ανθρωπον** *anthrōpon* człowieka [[G444]] [[N-ASM]] **αθετει** *athetei* odrzuca [[G114]] WTV-PAI-3S **αλλα** *alla* ale [[G235]] [[CONJ]] **τον** *ton* [[G3588]] [[T-ASM]] **θεον** *theon* Boga [[G2316]] [[N-ASM]] **τον** *ton* [[G3588]] [[T-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **δοντα** *donta* który dał [[G1325]] WTV-2AAP-ASM **το** *to* [[G3588]] WTT-ASN **πνευμα** *pneuma* Ducha [[G4151]] WTN-ASN **αυτου** *autou* Jego [[G846]] [[P-GSM]] **το** *to* [[G3588]] WTT-ASN **αγιον** *hagion* Świętego [[G40]] WTA-ASN **εις** *eis* do [[G1519]] [[PREP]] **ημας** *hēmas* nas [[G2248]] WTP-1AP
###### **1Tes 4,9**
 **περι** *peri* O [[G4012]] [[PREP]] **δε** *de* zaś [[G1161]] [[CONJ]] **της** *tēs* [[G3588]] [[T-GSF]] **φιλαδελφιας** *filadelfias* braterstwie – miłowaniu braci [[G5360]] [[N-GSF]] **ου** *ou* nie [[G3756]] [[PRT-N]] **χρειαν** *chreian* potrzebę [[G5532]] WTN-ASF **εχετε** *echete* macie [[G2192]] WTV-PAI-2P **γραφειν** *grafein* pisać [[G1125]] WTV-PAN **υμιν** *hymin* wam [[G5213]] WTP-2DP **αυτοι** *autoi* sami [[G846]] WTP-NPM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **θεοδιδακτοι** *theodidaktoi* pouczeni przez Boga – nauczeni przez Boga [[G2312]] WTA-NPM **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **εις** *eis* do [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **αγαπαν** *agapan* miłować [[G25]] WTV-PAN **αλληλους** *allēlous* jedni drugich [[G240]] WTC-APM
###### **1Tes 4,10**
 **και** *kai* i [[G2532]] [[CONJ]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ποιειτε** *poieite* czynicie [[G4160]] WTV-PAI-2P **αυτο** *auto* to [[G846]] WTP-ASN **εις** *eis* względem [[G1519]] [[PREP]] **παντας** *pantas* wszystkich [[G3956]] WTA-APM **τους** *tous* [[G3588]] WTT-APM **αδελφους** *adelfous* braci [[G80]] [[N-APM]] **τους** *tous* (tych) [[G3588]] WTT-APM **εν** *en* w [[G1722]] [[PREP]] **ολη** *holē* całej [[G3650]] WTA-DSF **τη** *tē* [[G3588]] WTT-DSF **μακεδονια** *makedonia* Macedonii [[G3109]] [[N-DSF]] **παρακαλουμεν** *parakaloumen* zachęcamy [[G3870]] WTV-PAI-1P **δε** *de* zaś [[G1161]] [[CONJ]] **υμας** *hymas* was [[G5209]] WTP-2AP **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **περισσευειν** *perisseuein* (by) obfitować – (by) przekraczać [[G4052]] WTV-PAN **μαλλον** *mallon* bardziej [[G3123]] [[ADV]]
###### **1Tes 4,11**
 **και** *kai* i [[G2532]] [[CONJ]] **φιλοτιμεισθαι** *filotimeisthai* uważać za szacowne [[G5389]] WTV-PNN **ησυχαζειν** *hēsychazein* być cichym – być spokojnym [[G2270]] WTV-PAN **και** *kai* i [[G2532]] [[CONJ]] **πρασσειν** *prassein* robić – czynić [[G4238]] WTV-PAN **τα** *ta* [[G3588]] WTT-APN **ιδια** *idia* swoje [[G2398]] WTA-APN **και** *kai* i [[G2532]] [[CONJ]] **εργαζεσθαι** *ergazesthai* pracować [[G2038]] WTV-PNN **ταις** *tais* [[G3588]] WTT-DPF **ιδιαις** *idiais* własnymi [[G2398]] WTA-DPF **χερσιν** *chersin* rękami [[G5495]] WTN-DPF **υμων** *hymōn* waszymi [[G5216]] WTP-2GP **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **παρηγγειλαμεν** *parēngeilamen* nakazaliśmy [[G3853]] WTV-AAI-1P
###### **1Tes 4,12**
 **ινα** *hina* aby [[G2443]] [[CONJ]] **περιπατητε** *peripatēte* postępowalibyście – chodzilibyście [[G4043]] WTV-PAS-2P **ευσχημονως** *euschēmonōs* godnie – dostojnie [[G2156]] [[ADV]] **προς** *pros* względem [[G4314]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **εξω** *eksō* z zewnątrz [[G1854]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **μηδενος** *mēdenos* nikogo – niczego [[G3367]] [[A-GSN]] **χρειαν** *chreian* potrzebę [[G5532]] WTN-ASF **εχητε** *echēte* mielibyście [[G2192]] WTV-PAS-2P
###### **1Tes 4,13**
 **ου** *ou* Nie [[G3756]] [[PRT-N]] **θελω** *thelō* chcę [[G2309]] WTV-PAI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **υμας** *hymas* (by) wy [[G5209]] WTP-2AP **αγνοειν** *agnoein* nie rozumieć – nie być świadomym [[G50]] WTV-PAN **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **περι** *peri* o [[G4012]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **κεκοιμημενων** *kekoimēmenōn* którzy są uśpieni [[G2837]] WTV-RPP-GPM **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **λυπησθε** *lypēsthe* bylibyście smuceni [[G3076]] WTV-PPS-2P **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **λοιποι** *loipoi* pozostali [[G3062]] WTA-NPM **οι** *hoi* [[G3588]] WTT-NPM **μη** *mē* nie [[G3361]] [[PRT-N]] **εχοντες** *echontes* mający [[G2192]] WTV-PAP-NPM **ελπιδα** *elpida* nadziei [[G1680]] WTN-ASF
###### **1Tes 4,14**
 **ει** *ei* Jeśli [[G1487]] WTCOND **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **πιστευομεν** *pisteuomen* wierzymy [[G4100]] WTV-PAI-1P **οτι** *hoti* że [[G3754]] [[CONJ]] **ιησους** *iēsous* Jezus – [JHWH jest zbawieniem] [[G2424]] [[N-NSM]] **απεθανεν** *apethanen* umarł [[G599]] WTV-2AAI-3S **και** *kai* i [[G2532]] [[CONJ]] **ανεστη** *anestē* powstał – podniósł się [[G450]] WTV-2AAI-3S **ουτως** *houtōs* tak [[G3779]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **τους** *tous* (tych) [[G3588]] WTT-APM **κοιμηθεντας** *koimēthentas* którzy zostali uśpieni [[G2837]] WTV-APP-APM **δια** *dia* ze względu na – przez [[G1223]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **αξει** *aksei* poprowadzi [[G71]] WTV-FAI-3S **συν** *syn* razem z [[G4862]] [[PREP]] **αυτω** *autō* Nim [[G846]] WTP-DSM
###### **1Tes 4,15**
 **τουτο** *touto* To [[G5124]] WTD-ASN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **λεγομεν** *legomen* mówimy [[G3004]] WTV-PAI-1P **εν** *en* w [[G1722]] [[PREP]] **λογω** *logō* Słowie [[G3056]] WTN-DSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **οτι** *hoti* że [[G3754]] [[CONJ]] **ημεις** *hēmeis* my [[G2249]] WTP-1NP **οι** *hoi* [[G3588]] WTT-NPM **ζωντες** *zōntes* żyjący [[G2198]] WTV-PAP-NPM **οι** *hoi* [[G3588]] WTT-NPM **περιλειπομενοι** *perileipomenoi* będący nadal pozostawionymi [[G4035]] WTV-POP-NPM **εις** *eis* na [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **παρουσιαν** *parousian* przyjście [[G3952]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ου** *ou* nie [[G3756]] [[PRT-N]] **μη** *mē* [[G3361]] [[PRT-N]] **φθασωμεν** *fthasōmen* przybylibyśmy pierwsi od – wyprzedzilibyśmy [[G5348]] WTV-AAS-1P **τους** *tous* (tych) [[G3588]] WTT-APM **κοιμηθεντας** *koimēthentas* którzy zostali uśpieni [[G2837]] WTV-APP-APM
###### **1Tes 4,16**
 **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **αυτος** *autos* sam [[G846]] WTP-NSM **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **εν** *en* na [[G1722]] [[PREP]] **κελευσματι** *keleusmati* rozkaz – wezwanie [[G2752]] WTN-DSN **εν** *en* na [[G1722]] [[PREP]] **φωνη** *fōnē* głos [[G5456]] [[N-DSF]] **αρχαγγελου** *archangelou* władcy zwiastunów [[G743]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* na [[G1722]] [[PREP]] **σαλπιγγι** *salpingi* trąbę [[G4536]] [[N-DSF]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **καταβησεται** *katabēsetai* zejdzie – zstąpi [[G2597]] WTV-FDI-3S **απ** *ap* z [[G575]] [[PREP]] **ουρανου** *ouranou* nieba [[G3772]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **νεκροι** *nekroi* martwi [[G3498]] WTA-NPM **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **αναστησονται** *anastēsontai* powstaną – będą wzbudzeni [[G450]] WTV-FMI-3P **πρωτον** *prōton* najpierw [[G4412]] [[ADV]]
###### **1Tes 4,17**
 **επειτα** *epeita* Następnie [[G1899]] [[ADV]] **ημεις** *hēmeis* my [[G2249]] WTP-1NP **οι** *hoi* [[G3588]] WTT-NPM **ζωντες** *zōntes* żyjący [[G2198]] WTV-PAP-NPM **οι** *hoi* [[G3588]] WTT-NPM **περιλειπομενοι** *perileipomenoi* będący nadal pozostawionymi [[G4035]] WTV-POP-NPM **αμα** *hama* równocześnie [[G260]] [[ADV]] **συν** *syn* z [[G4862]] [[PREP]] **αυτοις** *autois* nimi [[G846]] WTP-DPM **αρπαγησομεθα** *harpagēsometha* zostaniemy porwani [[G726]] WTV-2FPI-1P **εν** *en* w [[G1722]] [[PREP]] **νεφελαις** *nefelais* chmurach – obłokach [[G3507]] WTN-DPF **εις** *eis* na [[G1519]] [[PREP]] **απαντησιν** *apantēsin* spotkanie [[G529]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **εις** *eis* w [[G1519]] [[PREP]] **αερα** *aera* powietrze [[G109]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **ουτως** *houtōs* tak [[G3779]] [[ADV]] **παντοτε** *pantote* zawsze – każdej chwili [[G3842]] [[ADV]] **συν** *syn* z [[G4862]] [[PREP]] **κυριω** *kyriō* Panem [[G2962]] WTN-DSM **εσομεθα** *esometha* będziemy [[G2071]] WTV-FXI-1P
###### **1Tes 4,18**
 **ωστε** *hōste* Tak, że – W związku z czym [[G5620]] [[CONJ]] **παρακαλειτε** *parakaleite* zachęcajcie [[G3870]] WTV-PAM-2P **αλληλους** *allēlous* jedni drugich [[G240]] WTC-APM **εν** *en* przez [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPM **λογοις** *logois* słowa [[G3056]] WTN-DPM **τουτοις** *toutois* te [[G5125]] WTD-DPM
