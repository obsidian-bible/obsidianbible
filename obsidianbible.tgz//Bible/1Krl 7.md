# 1Krl 7 BT5
###### **1Krl 7,1**
 Salomon zbudował też i sobie pałac. Trzynaście lat upłynęło, zanim wykończył cały swój pałac.
###### **1Krl 7,2**
 Zbudował również "Dom Lasu Libanu", sto łokci długi, pięćdziesiąt łokci szeroki i trzydzieści łokci wysoki, na trzech rzędach słupów cedrowych z ociosanymi belkami cedrowymi na tych słupach
###### **1Krl 7,3**
 i nakryty też drewnem cedrowym ponad bocznymi pomieszczeniami, które były na tych czterdziestu pięciu słupach, po piętnaście w każdym rzędzie.
###### **1Krl 7,4**
 Wnęki okienne także były w trzech rzędach: okno nad oknem, o trzy kroki.
###### **1Krl 7,5**
 Wszystkie otwory i okna były czworokątne: każde okno było naprzeciw okna, w trzech rzędach okien.
###### **1Krl 7,6**
 Uczynił też sień ze słupami, długą na pięćdziesiąt łokci i na trzydzieści łokci szeroką. Była ona przed nimi, a słupy były z okapem.
###### **1Krl 7,7**
 Ponadto urządził salę tronową, w której sądził, salę sądową obłożoną drewnem cedrowym od podłogi aż do sufitu.
###### **1Krl 7,8**
 A jego pałac, w którym mieszkał, tak samo wykonany, był za domem z salą, na innym dziedzińcu. Wybudował też pałac, podobny do tej sali, dla córki faraona, którą poślubił.
###### **1Krl 7,9**
 Wszystko to od wewnątrz i od zewnątrz, od fundamentu do wsparcia pułapu, łącznie z wielkim dziedzińcem, było z kamieni wyborowych, ciosanych według miary i rżniętych piłą.
###### **1Krl 7,10**
 Podmurówka była z kamieni wyborowych, kamieni wielkich na dziesięć i osiem łokci.
###### **1Krl 7,11**
 A nad nią kamienie wyborowe, według miary ciosane, i budulec cedrowy.
###### **1Krl 7,12**
 Również wielki dziedziniec miał dokoła trzy rzędy kamieni ciosanych i rząd ciosanych belek cedrowych, tak samo jak wewnętrzny dziedziniec świątyni Pana oraz sień świątyni.
###### **1Krl 7,13**
 Król Salomon polecił sprowadzić z Tyru Hirama.
###### **1Krl 7,14**
 Był on synem wdowy z pokolenia Neftalego. Ojciec zaś jego był brązownikiem pochodzącym z Tyru. Był on pełen mądrości, rozsądku i zręczności w wykonywaniu wszelkich wyrobów z brązu. Przybył więc do króla Salomona i wykonał zlecone przez niego prace.
###### **1Krl 7,15**
 A zatem odlał dwie kolumny z brązu. Jedna kolumna miała osiemnaście łokci wysokości, a dwanaście łokci obwodu, [tyleż] i druga kolumna.
###### **1Krl 7,16**
 Następnie wykonał dwie głowice na szczyty tych kolumn, ulane z brązu. Pięć łokci wynosiła wysokość głowicy jednej i pięć łokci wysokość głowicy drugiej.
###### **1Krl 7,17**
 Sploty na wzór sieci lub też misternie wykonane ogniwa roboty łańcuchowej znajdowały się na głowicach będących na szczycie kolumn: sploty na jednej i na drugiej głowicy.
###### **1Krl 7,18**
 Wykonał też jabłka granatu: dwa rzędy dokoła każdego splotu, aby okrywały te głowice umieszczone na szczycie. Tak samo zrobił na drugiej głowicy.
###### **1Krl 7,19**
 Głowice, będące na szczycie tych kolumn w sieni, miały kształt lilii wielkości czterech łokci.
###### **1Krl 7,20**
 Ponadto głowice na obydwu kolumnach, zarówno ponad spojeniami na tle splotów, jak i tuż przy nich, miały dokoła dwieście jabłek granatu na jednej głowicy i tak samo na drugiej głowicy.
###### **1Krl 7,21**
 Kolumny te postawił przy sieni głównej budowli. Kolumnie postawionej po prawej stronie nadał imię Jakin, a kolumnie postawionej po lewej stronie nadał imię Boaz.
###### **1Krl 7,22**
 A na wierzchu tych kolumn były rzeźby w kształcie lilii. Tak została ukończona robota nad tymi kolumnami.
###### **1Krl 7,23**
 Następnie sporządził odlew "morza" o średnicy dziesięciu łokci, okrągłego, o wysokości pięciu łokci i o obwodzie trzydziestu łokci.
###### **1Krl 7,24**
 Poniżej jego krawędzi opasywały je dokoła rozchylone kielichy kwiatowe. Na trzydzieści łokci otaczały "morze" w krąg. W jego odlewie były razem odlane dwa rzędy rozchylonych kielichów kwiatowych.
###### **1Krl 7,25**
 Stało ono na dwunastu wołach. Trzy zwracały się ku północy, trzy na zachód, trzy na południe i trzy na wschód. "Morze" to znajdowało się nad nimi u góry, a wszystkie ich zady [zwracały się] do wewnątrz.
###### **1Krl 7,26**
 Grubość jego była na [szerokość] dłoni, a brzeg był wykonany jak brzeg kielicha kwiatu lilii. Jego pojemność wynosiła dwa tysiące bat.
###### **1Krl 7,27**
 Zrobił ponadto dziesięć brązowych podstaw. Długość jednej podstawy wynosiła cztery łokcie, szerokość też cztery łokcie, a wysokość trzy łokcie.
###### **1Krl 7,28**
 Podstawy te były zrobione tak: miały one ramy i pręty między ramami.
###### **1Krl 7,29**
 A na tych prętach między ramami – lwy, woły i cheruby. Poza tym na ramach, zarówno nad, jak i pod lwami i wołami, zwisające girlandy.
###### **1Krl 7,30**
 Każda podstawa miała cztery koła z brązu na brązowych osiach. Ponadto ich cztery nogi miały ramiona pod kadzią. Ramiona te odlane były po drugiej stronie girland.
###### **1Krl 7,31**
 Między ramionami miała ona otwór na wysokości łokcia. Okrągły jej otwór był na kształt podstawy < na półtora łokcia >. Dokoła jej otworu też były płaskorzeźby. Jednakże jej pręty nie były okrągłe, ale czworokątne.
###### **1Krl 7,32**
 Cztery koła były pod prętami. Osie kół były [umocowane] przy podstawach. Wysokość koła wynosiła półtora łokcia.
###### **1Krl 7,33**
 Koła były tak zrobione, jak robi się koło do wozu, ale ich osie, dzwona, szprychy oraz piasty były wszystkie odlewane.
###### **1Krl 7,34**
 Na czterech rogach każdej podstawy były cztery jej ramiona. Ramiona z podstawą tworzyły całość.
###### **1Krl 7,35**
 Na wierzchu podstawy, dokoła na pół łokcia wysokości było zaokrąglenie. U wierzchu podstawy czopy i pręty tworzyły z nią całość.
###### **1Krl 7,36**
 Na wszystkich blachach i prętach wyrył dokoła cheruby, lwy i palmy, < a w wolnej przestrzeni girlandy >.
###### **1Krl 7,37**
 W taki oto sposób wykonał dziesięć podstaw z brązu: jednakowy odlew, jednakowy rozmiar i jednakowy kształt wszystkich.
###### **1Krl 7,38**
 Zrobił też dziesięć kadzi z brązu. Jedna kadź miała pojemność czterdziestu bat. Każda kadź miała cztery łokcie i każda z nich była w jednej z dziesięciu podstaw.
###### **1Krl 7,39**
 Pięć podstaw umieścił przy skrzydle świątyni po prawej i pięć przy skrzydle świątyni po lewej jej stronie. "Morze" zaś umieścił na południowy wschód od prawego skrzydła świątyni.
###### **1Krl 7,40**
 Hiram zrobił ponadto kadzie, łopatki i kropielnice. Tak Hiram skończył wykonywanie wszystkich prac, jakie miał do wykonania dla króla Salomona w domu Pańskim:
###### **1Krl 7,41**
 dwie kolumny z owalnymi głowicami na szczycie tych dwóch kolumn, następnie dwie siatki do pokrycia dwóch owalnych głowic na szczycie tych kolumn;
###### **1Krl 7,42**
 dalej, czterysta jabłek granatu na obydwu siatkach, po dwa rzędy jabłek granatu na każdej siatce;
###### **1Krl 7,43**
 następnie dziesięć podstaw i tyleż kadzi na tych podstawach;
###### **1Krl 7,44**
 również jedno "morze" z dwunastoma pod nim wołami,
###### **1Krl 7,45**
 a także kotły, łopatki i kropielnice. Wszystkie sprzęty, które Hiram zrobił królowi Salomonowi do świątyni Pańskiej, były z brązu polerowanego.
###### **1Krl 7,46**
 Odlewy te wykonywał w glinie nad Jordanem, między Sukkot i Sartan.
###### **1Krl 7,47**
 Potem Salomon ustawił wszystkie te sprzęty, bardzo liczne, tak iż wagi brązu nie można było obliczyć.
###### **1Krl 7,48**
 Ponadto Salomon sporządził wszystkie sprzęty do świątyni Pana. A mianowicie: złoty ołtarz, złoty stół na chleby pokładne,
###### **1Krl 7,49**
 pięć świeczników z czystego złota przed sanktuarium po prawej i pięć po lewej stronie, kwiaty, lampy, szczypce ze złota,
###### **1Krl 7,50**
 czarki, nożyce do oczyszczania lamp, kropielnice, czasze i popielnice z czystego złota, a także złote zawiasy przy drzwiach do wewnętrznej komnaty sanktuarium i przy drzwiach głównej budowli.
###### **1Krl 7,51**
 Tak ukończono całą pracę, której król Salomon dokonał w świątyni Pana. Salomon wniósł i umieścił w skarbcu świątyni Pańskiej święte dary ofiarowane przez swego ojca, Dawida: srebro, złoto i sprzęty.
# 1Krl 7 PAU
###### **1Krl 7,1**
 Swój pałac natomiast Salomon budował trzynaście lat, wliczając prace wykończeniowe.
###### **1Krl 7,2**
 Wybudował więc Dom Lasu Libanu, długi na sto łokci, szeroki na pięćdziesiąt łokci i wysoki na trzydzieści łokci. Na czterech rzędach kolumn cedrowych wspierały się jego belki z drewna cedrowego.
###### **1Krl 7,3**
 Był on pokryty dachem cedrowym, umocowanym na belkach nośnych. Wspierały się one na czterdziestu pięciu kolumnach, po piętnaście w każdym rzędzie.
###### **1Krl 7,4**
 Miał również trzy rzędy otworów okiennych, tak że poszczególne okna umieszczone były naprzeciw siebie w trzech szeregach.
###### **1Krl 7,5**
 Wszystkie drzwi wejściowe wraz z futrynami miały kształt czworokątny, natomiast okna wychodziły jedno naprzeciw drugiego w trzech poziomach.
###### **1Krl 7,6**
 Zrobił również salę kolumnową, tworzącą wejście do pałacu o długości pięćdziesięciu łokci i szerokości trzydziestu łokci, z głowicami na kolumnach.
###### **1Krl 7,7**
 Wybudował także salę sądową. Stał w niej tron, z którego ogłaszał wyroki. Była ona wyłożona drewnem cedrowym od podłogi aż do sufitu.
###### **1Krl 7,8**
 Pałac, w którym miał mieszkać, znajdujący się na innym dziedzińcu niż pałac z salą kolumnową, był wykonany tak samo. Według podobnego wzoru Salomon zbudował dom córce faraona, którą poślubił.
###### **1Krl 7,9**
 Wszystko to wykonano z bloków kamienia wyróżniającego się jakością, wyciosanych według miary i wyrównanych piłą od wewnętrznej i zewnętrznej strony muru. Ułożono je od fundamentów pod sam dach. Wyłożono nimi także wielki dziedziniec.
###### **1Krl 7,10**
 Fundamenty wykonane były z potężnych bloków skalnych o dobrej jakości, długich na dziesięć i osiem łokci.
###### **1Krl 7,11**
 Powyżej ułożono wielkie kamienie dopasowane według miary, a na nich drewno cedrowe.
###### **1Krl 7,12**
 Wokół wielkiego dziedzińca ułożono trzy warstwy ciosanych kamieni oraz warstwę belek cedrowych. Tak samo urządzono wewnętrzny dziedziniec domu PANA i wejście prowadzące do niego.
###### **1Krl 7,13**
 Król Salomon polecił sprowadzić z Tyrus Hirama,
###### **1Krl 7,14**
 który był synem wdowy z plemienia Neftalego. Jego ojciec natomiast pochodził z Tyru i był rzemieślnikiem pracującym w brązie. Sam Hiram był wyjątkowo uzdolnionym rzemieślnikiem, znającym się doskonale na wszystkich rodzajach prac w brązie. Przybył więc do króla Salomona i wykonał wszystkie zlecone przez niego prace.
###### **1Krl 7,15**
 Odlał zatem dwie kolumny z brązu. Jedna kolumna miała osiemnaście łokci wysokości i dwanaście łokci obwodu. Taka sama była druga kolumna.
###### **1Krl 7,16**
 Następnie wykonał dwie głowice dla zwieńczenia kolumn, odlane z brązu, z których każda miała pięć łokci wysokości.
###### **1Krl 7,17**
 Wykonał też dwa ornamenty na wzór sieci, mające zdobić głowice wieńczące kolumny. Jeden ornament dla każdej głowicy.
###### **1Krl 7,18**
 Zrobił dalej dwa wzory owoców granatu dokoła ornamentu przedstawiającego sieci, ozdabiając nimi głowicę wieńczącą kolumnę. Tak samo postąpił z drugą głowicą.
###### **1Krl 7,19**
 Głowice zwieńczające kolumny miały kształt lilii wodnych.
###### **1Krl 7,20**
 W dolnej części głowic, spoczywających na kolumnach, poniżej ornamentu przedstawiającego sieci, było dwieście owoców granatu, rozmieszczonych w rzędach wokół każdej z nich.
###### **1Krl 7,21**
 Następnie ustawił kolumny u wejścia do domu: jedną kolumnę postawił po prawej stronie i nazwał ją Jakin, drugą zaś postawił po lewej stronie i nazwał ją Boaz.
###### **1Krl 7,22**
 Tak więc wykonanie kolumn zostało ukończone.
###### **1Krl 7,23**
 Wykonał potem „morze” - okrągły zbiornik o średnicy dziesięciu łokci, licząc od krawędzi do krawędzi, o wysokości pięciu łokci i obwodzie trzydziestu łokci.
###### **1Krl 7,24**
 Poniżej jego krawędzi wykonano ornamenty w formie pąków kwiatów. Podwójny rząd takich ornamentów opasywał brzeg całego „morza”, po dziesięć na łokieć.
###### **1Krl 7,25**
 Było ono ustawione na dwunastu posągach wołów, z których trzy były zwrócone przodem na północ, trzy na zachód, trzy na południe i trzy na wschód, tyłem zaś do środka. Na nich wspierało się „morze”.
###### **1Krl 7,26**
 Jego ściany miały grubość jednej dłoni. Brzeg „morza” miał kształt kielicha kwiatu lilii. Jego pojemność wynosiła dwa tysiące bat.
###### **1Krl 7,27**
 Hiram zrobił ponadto dziesięć podstaw z brązu. Każda podstawa miała cztery łokcie długości, cztery łokcie szerokości i trzy łokcie wysokości.
###### **1Krl 7,28**
 Wykonano je w następujący sposób: pionowe listwy tworzyły boczne ściany przymocowane do ram.
###### **1Krl 7,29**
 Boczne ściany między ramami były ozdobione wizerunkami lwów, wołów i cherubów, podobnie jak i same ramy. Nad i pod wizerunkami biegł wzór z wieńców kwiatowych.
###### **1Krl 7,30**
 Każda podstawa miała cztery koła i osie z brązu. Z czterech jej rogów wychodziły wsporniki, mające podtrzymywać misę. Wsporniki miały z każdej strony wzór z wieńców.
###### **1Krl 7,31**
 Wewnątrz znajdował się otwór w kształcie wieńca na jeden łokieć głęboki, który z krawędzią biegnącą wokół niego, również pokrytą ornamentami, mierzył półtora łokcia. Pionowe listwy bocznych ścian nie były okrągłe, lecz czworokątne.
###### **1Krl 7,32**
 Cztery koła umieszczono pod bocznymi ścianami z listew, osie kół natomiast przymocowane były do podstawy, średnica każdego koła wynosiła półtora łokcia.
###### **1Krl 7,33**
 Koła zrobiono na wzór kół rydwanu, ale osie, obręcze, szprychy i piasty były wykonane z odlewu.
###### **1Krl 7,34**
 W czterech narożnikach każdej podstawy znajdowały się wsporniki, tworzące z nim jedną całość.
###### **1Krl 7,35**
 Górna część wózka miała kształt obręczy o szerokości połowy łokcia. Do niej przymocowane były wsporniki i listwy bocznych ścian.
###### **1Krl 7,36**
 Na blachach bocznych ścian oraz wspornikach wyrył wizerunki cherubów, lwów i palm, a w każdej wolnej przestrzeni dokoła wzory z wieńców kwiatowych.
###### **1Krl 7,37**
 W taki więc sposób wykonał dziesięć podstaw z brązu: każda w jednakowym odlewie miała jednakowy rozmiar i kształt.
###### **1Krl 7,38**
 Następnie zrobił dziesięć mis z brązu, z których każda mierzyła cztery łokcie i miała czterdzieści bat pojemności. W każdej z dziesięciu podstaw umieścił po jednej misie.
###### **1Krl 7,39**
 Pięć podstaw umieścił przy prawym skrzydle domu, a pięć przy lewym. „Morze” natomiast ustawił po prawej stronie domu od południowego wschodu.
###### **1Krl 7,40**
 Hiram wykonał również misy, łopatki i kropielnice. W ten sposób zakończył realizację następujących zamówień króla Salomona dla domu PANA:
###### **1Krl 7,41**
 dwie kolumny, dwie owalne głowice zwieńczające kolumny, dwa ornamenty w kształcie sieci dla ozdoby dwóch owalnych głowic wieńczących kolumny,
###### **1Krl 7,42**
 czterysta owoców granatu dla dwóch wzorów sieci po dwa rzędy owoców granatu w każdym jako ozdoba owalnych głowic zwieńczających kolumny,
###### **1Krl 7,43**
 dziesięć podstaw i dziesięć mis na podstawach
###### **1Krl 7,44**
 oraz „morze” z dwunastoma posągami wołów pod „morzem”,
###### **1Krl 7,45**
 a także misy, łopatki i kropielnice. Wszystkie te przedmioty, które wykonał Hiram do domu PANA na zlecenie króla Salomona, były z wygładzonego brązu.
###### **1Krl 7,46**
 Do wykonania odlewów, zamówionych przez króla, posłużył się glinianymi formami. Piec odlewniczy znajdował się w dolinie Jordanu, pomiędzy Sukkot a Sartan.
###### **1Krl 7,47**
 Salomon nie ważył wszystkich tych przedmiotów, gdyż ilość brązu użytego do ich wykonania była wprost nie do określenia.
###### **1Krl 7,48**
 Salomon wyposażył również dom PANA w inne przedmioty: złoty ołtarz i złoty stół do składania na nim chlebów poświęconych,
###### **1Krl 7,49**
 dziesięć świeczników z czystego złota z ozdobami w kształcie kwiatów. Umieścił świeczniki przed najbardziej wewnętrznym miejscem domu, pięć po prawej i pięć po lewej stronie. Wykonał także lampy i szczypce ze złota;
###### **1Krl 7,50**
 ponadto naczynia, szczypce do lamp, kropielnice, misy i kadzielnice z czystego złota. Również złote odrzwia u wejścia do najbardziej wewnętrznego miejsca domu, to jest do miejsca najświętszego, oraz odrzwia u wejścia do środkowej części domu.
###### **1Krl 7,51**
 Kiedy zakończono wszystkie prace podjęte przez króla Salomona w domu PANA, wówczas Salomon przyniósł ofiarowane przez swojego ojca Dawida dary: srebro, złoto i naczynia i umieścił je w skarbcu domu PANA.
# 1Krl 7 BP
###### **1Krl 7,1**
 Salomon budował swój pałac trzynaście lat, i [w tym czasie] cały swój pałac wykończył.
###### **1Krl 7,2**
 Wzniósł budynek, [zwany] Lasem Libańskim, długi na sto łokci, na pięćdziesiąt łokci szeroki i na trzydzieści łokci wysoki. Belki cedrowe wspierały się na trzech rzędach kolumn cedrowych.
###### **1Krl 7,3**
 Część górną, aż do cel, które [znajdowały się] nad kolumnami, pokrył [deskami] cedrowymi. [Kolumn] było czterdzieści pięć, po piętnaście w rzędzie.
###### **1Krl 7,4**
 Były trzy szeregi wnęk [okiennych] i trzy rzędy okien [umieszczonych] naprzeciw siebie.
###### **1Krl 7,5**
 Wszystkie wejścia i odrzwia miały kształt kwadratowy. Okna znajdowały się naprzeciw siebie w trzech rzędach.
###### **1Krl 7,6**
 Zbudował przedsionek kolumnowy na pięćdziesiąt łokci długi i trzydzieści łokci szeroki. Przed nim był portyk, kolumny i okap.
###### **1Krl 7,7**
 Zbudował salę tronową, w której wydawał wyroki; była to sala sądowa. Pokrył ją deskami cedrowymi od podłogi aż po sufit.
###### **1Krl 7,8**
 Pałac, w którym mieszkał, miał inny dziedziniec. Znajdował się za gmachem przedsionka [kolumnowego] i był wykonany w tym samym stylu. Wzniósł też pałac, podobny do owego przedsionka, dla córki faraona, którą pojął za żonę.
###### **1Krl 7,9**
 Wszystko to było [wykonane] z kamienia doborowego, obrobionego na miarę, ciętego piłą od strony wewnętrznej i zewnętrznej, od fundamentów aż po strop, a na zewnątrz aż po wielki dziedziniec.
###### **1Krl 7,10**
 Za fundament służyły kamienie doborowe, wielkie bloki kamienne na dziesięć łokci i głazy na osiem łokci.
###### **1Krl 7,11**
 Na nim zaś ku górze [wznosiły się] kamienie doborowe obrobione na miarę i [drzewo] cedrowe.
###### **1Krl 7,12**
 Wielki dziedziniec miał dookoła trzy rzędy kamienia ciosanego i rząd belek cedrowych, [podobnie jak] wewnętrzny dziedziniec Świątyni Jahwe i przedsionek Świątyni.
###### **1Krl 7,13**
 Król Salomon posłał i sprowadził Chirama z Tyru.
###### **1Krl 7,14**
 Był on synem wdowy z pokolenia Neftalego, a jego ojciec, brązownik, pochodził z Tyru. Posiadał mądrość, inteligencję i umiejętność wykonywania wszelakiej roboty w brązie. Przybył więc do króla Salomona i wykonał mu wszystkie prace.
###### **1Krl 7,15**
 Odlał dwie kolumny z brązu. Jedna kolumna miała osiemnaście łokci wysokości, a obwód [jej] wynosił dwanaście tokci. Taka sama była druga kolumna.
###### **1Krl 7,16**
 Wykonał dwie głowice - odlane z brązu - aby je umieścić na wierzchołkach kolumn. Jedna głowica miała pięć łokci wysokości i druga głowica miała pięć łokci wysokości.
###### **1Krl 7,17**
 Dla głowic, które mieściły się na szczytach kolumn, [zrobił] siatki, coś w rodzaju kraty, i plecionki w formie łańcuszków; siedem dla jednej głowicy i siedem dla drugiej głowicy.
###### **1Krl 7,18**
 Wykonał [też] jabłka granatu; na jednej siatce [były ich] dwa rzędy, aby pokrywały głowice znajdujące się na wierzchołkach kolumn. To samo wykonał dla drugiej głowicy.
###### **1Krl 7,19**
 Głowice, które wieńczyły wierzchołki kolumn w przedsionku, miały kształt lilii [wielkości] czterech łokci.
###### **1Krl 7,20**
 Głowice na obu kolumnach również w górnej części, w pobliżu zgrubienia, które wystawało ponad siatkę, [miały jabłka granatu]. Jabłka granatu były umieszczone w szeregach po dwieście [sztuk] dookoła [pierwszej głowicy i dwieście sztuk] dookoła drugiej głowicy.
###### **1Krl 7,21**
 Kolumny ustawił przed przedsionkiem miejsca Świętego. [Tę] kolumnę, [którą] postawił po prawej stronie, nazwał Jakin. [Tę] zaś kolumnę, [którą] postawił z lewej strony, nazwał Boaz.
###### **1Krl 7,22**
 Tak została zakończona praca [nad] kolumnami.
###### **1Krl 7,23**
 [Następnie] wykonał [w formie] odlewu morze o średnicy dziesięciu łokci. Było [ono] idealnie okrągłe i miało pięć łokci wysokości oraz trzydzieści łokci obwodu.
###### **1Krl 7,24**
 Pod jego krawędzią znajdowały się liście kolokwintu. Ułożone wokoło [po] dziesięć na łokieć, otaczały morze dookoła. Dwa szeregi liści kolokwintu [zdobiących morze] stanowiły z nim jeden i ten sam odlew.
###### **1Krl 7,25**
 Spoczywało ono na dwunastu wołach. Trzy spoglądały na północ, trzy na zachód, trzy na południe, a trzy na wschód. Morze spoczywało na nich, wszystkie zaś tylne części ich [ciała] były zwrócone do środka.
###### **1Krl 7,26**
 Jego grubość wynosiła dłoń, a jego krawędź miała kształt brzegu kielicha kwiatu lilii. Mieściło w sobie dwa tysiące bat.
###### **1Krl 7,27**
 Wykonał [również] dziesięć podstaw z brązu. Każda podstawa miała cztery łokcie długości, cztery łokcie szerokości i trzy łokcie wysokości.
###### **1Krl 7,28**
 Podstawa była wykonana w ten sposób: miała płaszczyzny, te płaszczyzny zaś były oddzielone od siebie obrzeżami.
###### **1Krl 7,29**
 Na płaszczyznach między obrzeżami były lwy, woły i cheruby. Tak samo na obrzeżach. Powyżej i poniżej lwów i wołów zwisały girlandy [kwiatów] wykonane [jako] rzeźby wklęsłe.
###### **1Krl 7,30**
 Każda podstawa miała cztery koła z brązu i osie z brązu. Ich cztery nogi miały sztaby [krzyżujące się] pod czaszą [zbiornika]. Sztaby te były odlewane; poza [złączem] każda była skręcona [w formie] spirali.
###### **1Krl 7,31**
 Otwór [czaszy] znajdował się wewnątrz korony [podstawy], która przekraczała [jeden] łokieć [wysokości]. Otwór ten był okrągły, wykonany w formie podstawki na półtora łokcia. Również na otworze znajdowały się płaskorzeźby, a ich obramowania były czworokątne, a nie okrągłe.
###### **1Krl 7,32**
 Pod płaszczyznami znajdowały się cztery koła. Osie kół tkwiły w podstawie. Wysokość każdego koła wynosiła półtora łokcia.
###### **1Krl 7,33**
 Kształt kół był podobny do koła rydwanu. Osie, dzwona, szprychy i piasty; wszystko to [było wykonane] z odlewu.
###### **1Krl 7,34**
 U czterech rogów każdej podstawy znajdowały się cztery podpórki. Podpórki stanowiły jedno z podstawą.
###### **1Krl 7,35**
 Wierzch podstawy na wysokości pół łokcia okalała [obręcz], w górnej części podstawy wystawały uchwyty i obrzeża.
###### **1Krl 7,36**
 Na gładkiej powierzchni uchwytów i na obrzeżach, [wszędzie] gdzie tylko było wolne miejsce, wy rzeźbił dookoła cheruby, lwy, palmy oraz girlandy.
###### **1Krl 7,37**
 W taki sam sposób wykonał dziesięć podstaw. Wszystkie miały taki sam odlew, ten sam wymiar i ten sam kształt.
###### **1Krl 7,38**
 Wykonał [także] dziesięć zbiorników z brązu. Jeden zbiornik mieścił czterdzieści bat, każdy zbiornik miał cztery łokcie; jeden zbiornik przypadał na jedna podstawę; na dziesięć podstaw [było dziesięć zbiorników].
###### **1Krl 7,39**
 Pięć podstaw umieścił po prawej stronie Świątyni, a pięć po lewej stronie Świątyni. Morze ustawił po prawej stronie Świątyni w części południowo-wschodniej.
###### **1Krl 7,40**
 Chiram wykonał [również] kociołki, łopaty i kropielnice. I zakończył Chiram całą pracę, której się podjął dla króla Salomona, [na użytek] Świątyni Jahwe, [to jest]:
###### **1Krl 7,41**
 dwie kolumny; kule głowic, które [zdobiły] szczyty obydwu kolumn; dwie siatki, okrywające kule głowic, wieńczących szczyty kolumn;
###### **1Krl 7,42**
 czterysta jabłek granatu do obu siatek, dwa rzędy jabłek granatu na każdą siatkę, aby okrywały obydwie kule głowic, wieńczących szczyty kolumn;
###### **1Krl 7,43**
 dziesięć podstaw i dziesięć zbiorników [mających stać] na podstawach;
###### **1Krl 7,44**
 jedno morze i dwanaście wołów [jako podstawa] pod morze;
###### **1Krl 7,45**
 oraz kociołki, łopaty i kropielnice. Wszystkie sprzęty, jakie wykonał Chiram dla króla Salomona [na użytek] Świątyni Jahwe, były z polerowanego brązu.
###### **1Krl 7,46**
 Król odlewał je w dolinie Jordanu, w ziemi gliniastej między Sukkot a Cartan.
###### **1Krl 7,47**
 Salomon sprawił [tak] bardzo wielką ilość wszystkich naczyń, [że] niepodobna było obliczyć wagi brązu.
###### **1Krl 7,48**
 Salomon sprawił wszystkie sprzęty, jakie [były potrzebne dla] Świątyni Jahwe: złoty ołtarz, złoty stół, na którym składano chleby pokładne,
###### **1Krl 7,49**
 świeczniki z czystego złota - pięć po prawej i pięć po lewej stronie przed miejscem Najświętszym, kwiaty, lampy i złote szczypce.
###### **1Krl 7,50**
 Misy, noże, kropielnice, chochle, popielnice z czystego złota i złote zawiasy do drzwi wewnętrznej Świątyni, [tj.] miejsca Najświętszego, i do drzwi Świątyni, [tj.] miejsca Świętego.
###### **1Krl 7,51**
 [Gdy] została ukończona wszelka praca, którą prowadził król Salomon przy Świątyni Jahwe, wniósł Salomon wota Dawida, swego ojca: srebro i złoto oraz naczynia i złożył [je] w skarbcach Świątyni Jahwe.
# 1Krl 7 BR
###### **1Krl 7,1**
 Swój własny pałac budował Salomon - licząc wszystkie roboty wykończeniowe - trzynaście lat.
###### **1Krl 7,2**
 Zbudował także Dom Lasu Libańskiego. Długość tego domu wynosiła sto łokci, szerokość pięćdziesiąt, a wysokość trzydzieści łokci. Wspierał się on na trzech rzędach słupów cedrowych, podtrzymujących cedrowe belki.
###### **1Krl 7,3**
 Dach, wykonany także z drewna cedrowego, pokrywał pomieszczenia, które były zbudowane - w liczbie czterdziestu pięciu - na słupach, po piętnaście w każdym rzędzie słupów.
###### **1Krl 7,4**
 W trzech rzędach również były rozmieszczone okna, i to w ten sposób, że każde trzy okna wychodziły naprzeciw innym trzem.
###### **1Krl 7,5**
 Wszystkie drzwi i okna były w czworokątnych obramowaniach. Każdy szereg trzech okien znajdował się naprzeciw innego podobnego szeregu.
###### **1Krl 7,6**
 Zrobił także portyk wsparty na słupach. Portyk miał pięćdziesiąt łokci długości, trzydzieści łokci szerokości. Przed portykiem znajdowało się jeszcze jedno pomieszczenie wsparte na słupach i pokryte dachem.
###### **1Krl 7,7**
 Znajdowała się tam również sala tronowa, gdzie król rozsądzał sprawy sporne. Była ona wyłożona drewnem cedrowym od podłogi aż do sufitu.
###### **1Krl 7,8**
 Za portykiem, na drugim dziedzińcu, znajdował się dom mieszkalny Salomona, zbudowany w taki sam sposób. Podobny dom kazał [król] zbudować dla córki faraona, którą wziął sobie za żonę.
###### **1Krl 7,9**
 Wszystkie te budowle - zarówno wewnątrz, jak i na zewnątrz, od fundamentów aż do stropu, łącznie z wielkim dziedzińcem - były wzniesione z najlepszego kamienia ciosanego i przycinanego piłami na miarę.
###### **1Krl 7,10**
 W fundamentach też znajdował się kamień przedniej jakości - były to duże bloki kamienne, długie na dziesięć albo osiem łokci.
###### **1Krl 7,11**
 Potem układano znów kamień dobrej jakości, przycinany według określonych rozmiarów, a na to szło drewno cedrowe.
###### **1Krl 7,12**
 Wielki dziedziniec był otoczony murem z trzech warstw kamienia ciosanego i jednego szeregu belek cedrowych, podobnie jak dziedziniec wewnętrzny świątyni Jahwe i jej portyk.
###### **1Krl 7,13**
 Po jakimś czasie polecił Salomon sprowadzić do siebie Hirama z Tyru.
###### **1Krl 7,14**
 [Hiram] był synem pewnej wdowy z pokolenia Neftalego. Jego ojciec pochodził z Tyru i był z zawodu brązownikiem. Był to człowiek mądry, bystry i umiejący robić najrozmaitsze przedmioty z brązu. Przybył on do Salomona i wykonał wszystkie zlecone mu prace.
###### **1Krl 7,15**
 To on właśnie sporządził dwie kolumny z brązu. Wysokość jednej kolumny wynosiła osiemnaście łokci. Były opasane drutem [który miał je wzmacniać] długości dwunastu łokci. Druga kolumna była taka sama.
###### **1Krl 7,16**
 Odlał także z brązu dwie głowice, mające wieńczyć kolumny. Wysokość jednej głowicy wynosiła pięć łokci, wysokość drugiej również pięć łokci.
###### **1Krl 7,17**
 Na obu głowicach, stanowiących zakończenie kolumn, były jakby sploty przypominające sieć lub ogniwa tworzące łańcuchy.
###### **1Krl 7,18**
 Dwa rzędy owoców granatu otaczały sploty na głowicach - na jednej głowicy i na drugiej - i pokrywały głowice znajdujące się na szczytach kolumn.
###### **1Krl 7,19**
 Głowice kolumn w przedsionku, przypominające kształtem kwiat lilii, były wysokie na cztery łokcie.
###### **1Krl 7,20**
 Głowica umieszczona na szczycie kolumny była otoczona dwustoma owocami granatu powyżej spojeń splotów. Dwieście owoców granatu znajdowało się także wokół głowicy drugiej kolumny.
###### **1Krl 7,21**
 Tak wyglądały kolumny przedsionka świątyni. Na kolumnie z prawej strony widniało imię Jakin, na kolumnie z lewej zaś - Boaz.
###### **1Krl 7,22**
 Na szczytach kolumn były umieszczone rzeźby w kształcie lilii. Takie było wykończenie kolumn.
###### **1Krl 7,23**
 Odlał także z brązu tak zwane morze. Miało ono średnicy dziesięć łokci i było dokładnie okrągłe. Jego wysokość wynosiła pięć łokci, a sznur, którym zmierzono obwód, był długi na trzydzieści łokci.
###### **1Krl 7,24**
 Pod obrzeżem morza były umieszczone dwa rzędy rozchylonych kielichów kwiatowych, po dziesięć na każdy łokieć. Kwiaty były wykonane z jednego odlewu.
###### **1Krl 7,25**
 Morze było podtrzymywane przez dwanaście wołów, z których trzy zwracały się na północ, trzy na zachód, trzy na południe i trzy na wschód. Na nich spoczywało morze, pokrywając cały grzbiet każdego wołu.
###### **1Krl 7,26**
 Grubość [ściany morza] była równa szerokości dłoni, a samo obrzeże przypominało wyglądem rozwinięty kwiat lilii. Pojemność morza wynosiła dwa tysiące batów.
###### **1Krl 7,27**
 Wykonał też dziesięć naczyń brązowych poruszających się na kółkach. Każde z nich miało cztery łokcie wysokości.
###### **1Krl 7,28**
 A oto jak owe naczynia były wykonane: były zrobione ramy, wzmocnione specjalnymi prętami.
###### **1Krl 7,29**
 Na prętach, pod ramami, były poumieszczane rzeźby lwów, wołów i cherubów. Nad ramami, tak nad, jak i pod lwami i wołami, zwisały girlandy.
###### **1Krl 7,30**
 Każde naczynie miało cztery brązowe kółka na osiach, wykonanych również z brązu. Cztery nogi były wzmocnione specjalnymi wspornikami. Wsporniki owe, odlane z brązu, były zamocowane pod spodem naczynia, ponad girlandą.
###### **1Krl 7,31**
 Na wysokości łokcia w środku girlandy znajdował się w naczyniach otwór. Był on okrągły i przypominał nieco podstawę kolumny, a jego średnica wynosiła półtora łokcia. Poniżej otworu widniały rzeźby. Pręty wzmacniające były o przekroju nie okrągłym, lecz czworokątnym.
###### **1Krl 7,32**
 Cztery kółka były zamocowane poniżej prętów, natomiast osie, na których obracały się kółka, wystawały z samego naczynia. Średnica każdego kółka wynosiła półtora łokcia.
###### **1Krl 7,33**
 Kółka wyglądały tak jak koła zwykłego wozu. Osie, na których się obracały, obręcze, szprychy i piasty były odlewane.
###### **1Krl 7,34**
 Na czterech rogach każdego naczynia znajdowały się wsporniki, które były wykonane z tego samego kawałka materiału co całe naczynie.
###### **1Krl 7,35**
 Górna część naczynia miała kształt okrągły na wysokość pół łokcia. Czopy i pręty górnej części były wykonane z jednego kawałka materiału.
###### **1Krl 7,36**
 Wszystkie blachy wzmacniające i pręty były pokryte płaskorzeźbami, które przedstawiały cheruby, lwy i palmy i pokrywały całą wolną przestrzeń. Dokoła zwisały girlandy kwiatów.
###### **1Krl 7,37**
 W taki to sposób były wykonane naczynia [poruszające się na kółkach]. Wszystkie były zrobione z takiego samego materiału, miały takie same rozmiary i taki sam kształt.
###### **1Krl 7,38**
 [Ten sam brązownik] wykonał też dziesięć kadzi z brązu. Każda mogła pomieścić czterdzieści batów. Średnica każdej kadzi wynosiła cztery łokcie. Jedna kadź znajdowała się na jednym z dziesięciu naczyń [opisanych wyżej].
###### **1Krl 7,39**
 Naczynia zostały rozstawione w ten sposób, że pięć z nich stanęło po prawej i pięć po lewej stronie świątyni. Tak zwane morze znalazło się po prawej stronie świątyni, w kierunku południowo-wschodnim.
###### **1Krl 7,40**
 Hiram sporządził ponadto zbiorniki, łopatki i kropielnice. W ten sposób doprowadził do końca wszystkie roboty, które Salomon zlecił mu w świątyni Jahwe.
###### **1Krl 7,41**
 Wykonał więc dwie kolumny, dwie owalne głowice, znajdujące się na szczytach tych kolumn, i dwa jakby z siatki pokrycia dwóch owalnych głowic na szczytach kolumn;
###### **1Krl 7,42**
 czterysta owoców granatu do obydwu pokryć, po dwa rzędy owoców granatu na każde pokrycie owalnych głowic, znajdujących się na szczytach kolumn;
###### **1Krl 7,43**
 dziesięć naczyń [poruszających się na kółkach] i dziesięć zbiorników umieszczonych na tych naczyniach;
###### **1Krl 7,44**
 morze, posągi dziesięciu wołów podtrzymujących morze;
###### **1Krl 7,45**
 poza tym zbiorniki, łopatki i kropielnice. Wszystkie te przedmioty, które Hiram wykonał na polecenie Salomona dla świątyni Jahwe, były z polerowanego brązu.
###### **1Krl 7,46**
 Król kazał je odlewać z gliny, dobywanej między Sukkot i Sartan.
###### **1Krl 7,47**
 Salomon nie kazał już nawet ważyć razem tych wszystkich przedmiotów, bo było ich bardzo dużo. Nie można było sprawdzić wagi brązu.
###### **1Krl 7,48**
 Na polecenie Salomona wykonano też wszystkie inne przedmioty znajdujące się w świątyni Jahwe. Oto one: ołtarz ze złota, stół złocony, służący do składania na nim chlebów pokładnych,
###### **1Krl 7,49**
 świeczniki ze szczerego złota, pięć z prawej i pięć z lewej strony, przed wejściem do Świętego Świętych, kwiaty, lampy, szczypce ze złota;
###### **1Krl 7,50**
 ponadto czary, nożyce, kubki, wazy, kadzielnice ze szczerego złota, złote zawiasy przy drzwiach prowadzących do wnętrza świątyni, czyli do Świętego Świętych, oraz do drzwi prowadzących do samej świątyni, czyli do Miejsca Świętego.
###### **1Krl 7,51**
 Takie to prace wykonał król Salomon w świątyni Jahwe. Ponadto kazał Salomon dostarczyć to wszystko, co ofiarował na świątynię jego ojciec, Dawid, a więc srebro, złoto i różne naczynia - wszystko to złożył w skarbcu świątyni Jahwe.
# 1Krl 7 WUJ
###### **1Krl 7,1**
 A dom swój budował Salomon trzynaście lat, i zupełnie go dokonał.
###### **1Krl 7,2**
 Zbudował też dom lasu libanu na sto łokci w zdłuż, a na pięćdziesiąt łokci w szerz, a na trzydzieści łokci w zwyż: i cztery chodniki między słupami Cedrowemi: bo był wyciął drzewa Cedrowe na słupy.
###### **1Krl 7,3**
 A tarcicami Cedrowemi pokrył wszystek sklep, który stał na czterdzieści i piąci słupiech. A jeden rząd miał słupów piętnaście.
###### **1Krl 7,4**
 Jeden przeciw drugiemu postawionych.
###### **1Krl 7,5**
 I przeciw sobie stojących, a był równy plac między słupami, a na słupiech drzewa na cztery granie we wszem równe.
###### **1Krl 7,6**
 I przysionek słupów uczynił pięćdziesiąt łokiet w zdłuż, a trzydzieści łokiet w szerz: i drugi przysionek przed więtszym przysionkiem, i słupy i kapitelle na słupiech.
###### **1Krl 7,7**
 Uczynił też przystanek stołeczny, w którym jest stolica sądowa; i przykrył drzewem Cedrowem ode tła aż do wierzchu,
###### **1Krl 7,8**
 A domek, w którym siadał na sąd, był w pośród przysionka, takąż robotą. Zbudował też dom córce Pharaonowej, (którą był wziął za żonę Salomon) takąż robotą jako i ten przysionek.
###### **1Krl 7,9**
 Wszystko kamieniem drogim, które pod sznur jakiś i miarę tak wewnątrz jako i zewnątrz przepiłowane było: od fundamentu, aż do wierzchu ścian, i zewnątrz aż do sieni więtszej,
###### **1Krl 7,10**
 A fundamenty z kamienia kosztownego, z kamienia wielkiego na dziesiąci abo na ośmi łokci.
###### **1Krl 7,11**
 A na wierzchu kamienie kosztowne w równej mierze ciosane były, i takież też z Cedru.
###### **1Krl 7,12**
 A sień więtsza okrągła ze trzech rzędów z kamienia ciosanego, a z jednego rzędu zheblowanego Cedru: także i w sieni domu Pańskiego wnętrznej w przysionku domu.
###### **1Krl 7,13**
 Posłał też król Salomon i wziął Hirama z Tyru.
###### **1Krl 7,14**
 Syna niewiasty wdowy z pokolenia Nephthali, z ojca Tyryjczyka, rzemieślnika około miedzi, pełnego mądrości, i rozumu, i nauki na wszelką robotę z miedzi. Który gdy przyszedł do króla Salomona, sprawił wszystkie roboty jego.
###### **1Krl 7,15**
 I urobił dwa słupy miedziane, jeden słup na ośmnaście łokci w zwyż: a sznur na dwanaście łokiet opasował obadwa słupy.
###### **1Krl 7,16**
 Uczynił też dwie kapitelle, które miano postawić na wierzchu słupów, ulane z miedzi: pięć łokiet w zwyż Capitellum jedno, i pięć łokiet w zwyż Capitellum drugie:
###### **1Krl 7,17**
 A jakoby na kształt sieci i łańcuszków społem między sobą dziwną robotą poplecionych. Obiedwie Capitella słupów lane były: siedm rzędów siatek na Capitellum jednym, a siedm siatek na Capitellum drugim.
###### **1Krl 7,18**
 I dokonał słupów i dwu rzędów w około każdej siatki, aby okryły Capitella, które były na wierzchu malogranatów: tymże sposobem uczynił na Capitellum drugim.
###### **1Krl 7,19**
 A Capitella, które były na wierzchu słupów, jakoby robotą liliej urobione były w przysionku na cztery łokcie.
###### **1Krl 7,20**
 I zasię inne Capitella na wierzchu słupów, zwierzchu podług miary słupa przeciw siatkom: a jabłek granatowych było dwieście rzędów około Capitellum drugiego:
###### **1Krl 7,21**
 I postawił dwa słupy w przysionku kościelnym: a postawiwszy słup prawy: nazwał go imieniem Jachin: także postawił słup drugi, i nazwał imię jego Booz.
###### **1Krl 7,22**
 A na wierzchu słupów robotę na kształt liliej postawił: i dokonała się robota słupów.
###### **1Krl 7,23**
 Uczynił też morze lane na dziesiąci łokiet od brzegu aż do brzegu, okrągłe w około: na piąci łokiet wysokość jego, a sznurek na trzydzieści łokiet opasował je w około.
###### **1Krl 7,24**
 A rzezanie pod krajem obchodziło je dziesiącią łokci obtaczając morze: dwa rzędy rzezania żłobkowatego lane były.
###### **1Krl 7,25**
 A stało na dwunaście wolech, z których trzej patrzali na północy, a trzej na zachód Słońca, a trzej na południe, a trzej na wschód Słońca, a morze na nich z wierzchu było: których pośladki wszystkie się wewnątrz kryły.
###### **1Krl 7,26**
 A mięsz umywalnie była na trzy wielkie palce, a kraj jej, jakoby kraj u kubka, a jako list rozwitej liliej: brało w się dwa tysiąca wiader:
###### **1Krl 7,27**
 I uczynił dziesięć podstawków miedzianych, każdy podstawek wzdłuż na cztery łokcie, a na cztery łokcie w szerz, a na trzy łokcie w zwyż.
###### **1Krl 7,28**
 A sama robota podstawków miejscy gładka była: a rzezanie między spojeniem.
###### **1Krl 7,29**
 A między koronkami i plecieńcami lwy i woły i Cheruby: i także przy spojeniu zwierzchu: a pod lwy i woły, jakoby rzemienie z miedzi wiszące.
###### **1Krl 7,30**
 I cztery koła do każdego podstawka, i osi miedziane: i na czterech stronach jakoby ramionka pod umywalnią ulane ku sobie wespół patrzące.
###### **1Krl 7,31**
 Brzeg też umywalnie był wewnątrz na wierzchu głowy, a co się ze wnątrz okazowało, było na jeden łokieć wszystko okrągłe, a miało także półtora łokcia: a na węgłach słupów były rozliczne rzezania: a środki między słupami na cztery granie, a nie okrągłe.
###### **1Krl 7,32**
 Cztery też koła, które u czterech rogach podstawku były, dzierżały się siebie pod podstawkiem jedno koło było na półtora łokcia wysokie.
###### **1Krl 7,33**
 A koła takie były jakie bywają u wozu: i osi ich, i szpice, i dzwona, i piasty wszystko lite.
###### **1Krl 7,34**
 Bo i one cztery ramionka na każdym węgle podstawka jednego z tegoż podstawka ulane i spojone były.
###### **1Krl 7,35**
 A na wierzchu podstawka była okrągłość niejaka na pół łokcia, tak urobiona, żeby na nie umywalnia mogła być włożona, mając rzezania swe i różne rycia sama z siebie.
###### **1Krl 7,36**
 Wyrzezał też na deszczakach onych, które były z miedzi i na węgłach, Cherubimy i lwy i palmy, jakoby na podobieństwo człowieka stojącego, że się nie wyryte ale przystawione w około widziały,
###### **1Krl 7,37**
 Tymże sposobem uczynił dziesięć podstawków jednego lania, i miary, i jednakiego rzezania.
###### **1Krl 7,38**
 Ktemu uczynił dziesięć umywalni miedzianych: czterdzieści batów brała jedna umywalnia, a była na cztery łokcie: a każdą umywalnią na każdym to jest na dziesięciu podstawkach postawił.
###### **1Krl 7,39**
 I postawił dziesięć podstawków, pięć po prawej strome kościoła, a pięć po lewej: a morze postawił na prawej stronie kościoła na wschód ku południu.
###### **1Krl 7,40**
 Nadziałał tedy Hiram kociełków, i mis, i kropidlnic, i dokonał wszystkiej roboty króla Salomona w kościele Pańskim,
###### **1Krl 7,41**
 Dwa słupy, i sznury Capitellów nad Capitellami słupów dwu, i dwie siatce, żeby okrywały dwa sznury, które były na wierzchu słupów.
###### **1Krl 7,42**
 I jabłek granatowych cztery sta na dwu siatkach: dwa rzędy jabłek granatowych na każdej siatce, ku okryciu sznurów Capitellów, które były na wierzchu słupów.
###### **1Krl 7,43**
 I podstawków dziesięć, i umywadlni dziesięć na podstawkach.
###### **1Krl 7,44**
 I morze jedno, i wołów dwanaście pod morzem,
###### **1Krl 7,45**
 I kociełki, misy i kropidlnice, wszystkie naczynia, które poczynił Hiram królowi Salomonowi w domu Pańskim, z mosiądzu były.
###### **1Krl 7,46**
 W równinie Jordanu odlewał je król na gliniastej ziemi, między Sochoth a Sarthan.
###### **1Krl 7,47**
 I postawił Salomon wszystkie naczynia: a dla wielkości zbytniej nie było wagi miedzi.
###### **1Krl 7,48**
 I sprawił Salomon wszystko naczynie w domu Pańskim: ołtarz złoty, i stół, na którymby pokładziono chleby pokładne, złoty:
###### **1Krl 7,49**
 I lichtarze złote, pięć na prawej, a pięć na lewej stronie, przeciwko wyrocznicy z szczerego złota: i kwiaty jako liliowe, i lampy na wierzch złote, i nożyczki złote,
###### **1Krl 7,50**
 I dzbany, i haczki, i kubki i moździerzyki, i kadzilnica z szczerego złota: i zawiasy u drzwi do domu wnętrznego świętego świętych, i drzwi domu kościelnego ze złota były.
###### **1Krl 7,51**
 I dokonał wszystkiej roboty, którą czynił Salomon w domu Pańskim, i wniósł co był poświęcił Dawid ociec jego, srebro i złoto i naczynia, i włożył do skarbu domu Pańskiego.
