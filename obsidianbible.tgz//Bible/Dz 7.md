# Dz 7 BT5
###### **Dz 7,1**
 «***Czy to prawda?***» – zapytał arcykapłan.
###### **Dz 7,2**
 A on odpowiedział: «***Słuchajcie, bracia i ojcowie: Bóg chwały ukazał się ojcu naszemu, Abrahamowi, gdy żył w Mezopotamii, zanim zamieszkał w Charanie.***
###### **Dz 7,3**
 ***I powiedział do niego: Opuść ziemię swoją i rodzinę swoją, a idź do ziemi, którą ci wskażę.***
###### **Dz 7,4**
 ***Wtedy wyszedł z ziemi chaldejskiej i zamieszkał w Charanie. A stąd po śmierci ojca przesiedlił go [Bóg] do tego kraju, który wy teraz zamieszkujecie.***
###### **Dz 7,5**
 ***Nie dał mu jednak w posiadanie ani piędzi tej ziemi. Obiecał tylko, że da ją w posiadanie jemu, a po nim jego potomstwu, chociaż nie miał jeszcze wtedy syna.***
###### **Dz 7,6**
 ***Powiedział Bóg tak: Potomkowie twoi będą wygnańcami na obczyźnie i przez czterysta lat ciemiężyć ich będą jako niewolników, i będą ich krzywdzić.***
###### **Dz 7,7**
 ***Lecz naród, którego będą niewolnikami, Ja sam sądzić będę – mówi Pan. Potem wyjdą i będą Mi służyli na tym miejscu.***
###### **Dz 7,8**
 ***I zawarł z nim przymierze obrzezania. Tak urodził mu się Izaak, którego obrzezał dnia ósmego, a Izaakowi – Jakub, a Jakubowi – dwunastu patriarchów.***
###### **Dz 7,9**
 ***Patriarchowie sprzedali Józefa do Egiptu, przez zazdrość, ale Bóg był z nim.***
###### **Dz 7,10**
 ***I uwolnił go od wszystkich ucisków, i dał łaskę oraz mądrość w oczach faraona, króla Egiptu. A ten ustanowił go zarządcą Egiptu i całego swego domu.***
###### **Dz 7,11**
 ***Nastał wtedy głód w całym Egipcie i Kanaanie i wielka bieda, i ojcowie nasi nie mieli co jeść.***
###### **Dz 7,12**
 ***Gdy Jakub dowiedział się, że w Egipcie jest zboże, wysłał ojców naszych pierwszy raz,***
###### **Dz 7,13**
 ***a za drugim razem Józef dał się poznać swoim braciom, faraon zaś dowiedział się o jego rodzie.***
###### **Dz 7,14**
 ***Posłał Józef po Jakuba i sprowadził ojca swego i całą rodzinę, w liczbie siedemdziesięciu pięciu osób.***
###### **Dz 7,15**
 ***Jakub przybył do Egiptu i umarł on sam, jak i nasi ojcowie.***
###### **Dz 7,16**
 ***Przeniesiono ich do Sychem i złożono w grobie, który Abraham kupił za srebro od synów Chamora w Sychem.***
###### **Dz 7,17**
 ***W miarę jak zbliżał się czas obietnicy, którą Bóg dał Abrahamowi, rozrastał się lud i rozmnażał w Egipcie,***
###### **Dz 7,18**
 ***aż doszedł do władzy inny król w Egipcie, który nic nie wiedział o Józefie.***
###### **Dz 7,19**
 ***Działał on podstępnie przeciwko naszemu narodowi i przymuszał ojców naszych do wyrzucania niemowląt, aby nie zostawały przy życiu.***
###### **Dz 7,20**
 ***Wówczas właśnie narodził się Mojżesz. Był on miły Bogu. Przez trzy miesiące karmiono go w domu ojca.***
###### **Dz 7,21**
 ***A gdy go wyrzucono, zabrała go córka faraona i przybrała go sobie za syna.***
###### **Dz 7,22**
 ***Mojżesza wprowadzono w całą mądrość egipską, i potężny był w słowie i czynie.***
###### **Dz 7,23**
 ***Gdy skończył lat czterdzieści, przyszło mu na myśl odwiedzić swych braci, synów Izraela.***
###### **Dz 7,24**
 ***I zobaczył jednego, któremu wyrządzano krzywdę. Stanął w jego obronie i zabiwszy Egipcjanina, pomścił skrzywdzonego.***
###### **Dz 7,25**
 ***Sądził, że bracia jego zrozumieją, iż Bóg przez jego ręce daje im wybawienie, lecz oni nie zrozumieli.***
###### **Dz 7,26**
 ***Następnego dnia zjawił się wśród nich, kiedy bili się między sobą, i usiłował ich pogodzić. "Ludzie, braćmi jesteście – zawołał – czemu krzywdzicie jeden drugiego?"***
###### **Dz 7,27**
 ***Ten jednak, który krzywdził bliźniego, odepchnął go. "Któż ciebie ustanowił panem i sędzią nad nami? – zawołał –***
###### **Dz 7,28**
 ***czy chcesz mnie zabić, tak jak wczoraj zabiłeś Egipcjanina?"***
###### **Dz 7,29**
 ***Na te słowa Mojżesz uciekł i żył jako cudzoziemiec w ziemi Madian, gdzie urodziło mu się dwóch synów.***
###### **Dz 7,30**
 ***Po czterdziestu latach ukazał mu się na pustyni góry Synaj Anioł Pański w płomieniu ognistego krzewu.***
###### **Dz 7,31**
 ***Zobaczywszy [go], Mojżesz podziwiał ten widok, lecz kiedy podszedł bliżej, aby się przyjrzeć, rozległ się głos Pana:***
###### **Dz 7,32**
 ***Jam jest Bóg twoich przodków, Bóg Abrahama i Izaaka, i Jakuba. Przeraził się Mojżesz i nie śmiał patrzeć.***
###### **Dz 7,33**
 ***Zdejmij sandały z nóg – powiedział do niego Pan – bo miejsce, na którym stoisz, jest ziemią świętą.***
###### **Dz 7,34**
 ***Długo patrzyłem na ucisk ludu mego w Egipcie i wysłuchałem jego westchnień, i zstąpiłem, aby ich wyzwolić. Przyjdź, poślę cię teraz do Egiptu.***
###### **Dz 7,35**
 ***Tego właśnie Mojżesza, którego wyparli się, mówiąc: Któż ciebie ustanowił panem i sędzią? – tego właśnie Bóg wysłał jako wodza i wybawcę pod opieką anioła, który się mu ukazał w krzewie.***
###### **Dz 7,36**
 ***On wyprowadził ich, czyniąc znaki i cuda w ziemi egipskiej nad Morzem Czerwonym i na pustyni przez lat czterdzieści.***
###### **Dz 7,37**
 ***Ten właśnie Mojżesz powiedział do potomków Izraela: Proroka jak ja wzbudzi wam Bóg spośród braci waszych.***
###### **Dz 7,38**
 ***On to w zgromadzeniu na pustyni pośredniczył między aniołem, który mówił do niego na górze Synaj, a naszymi ojcami. On otrzymał słowa żywe, aby wam je przekazać.***
###### **Dz 7,39**
 ***Nie chcieli go słuchać nasi ojcowie, ale odepchnęli go i zwrócili serca ku Egiptowi.***
###### **Dz 7,40**
  ***Zrób nam bogów – powiedzieli do Aarona – którzy będą szli przed nami, bo nie wiemy, co się stało z tym Mojżeszem, który wyprowadził nas z ziemi egipskiej.***
###### **Dz 7,41**
 ***Wówczas to zrobili sobie cielca i złożyli ofiarę bałwanowi, i cieszyli się dziełem swoich rąk.***
###### **Dz 7,42**
 ***Ale Bóg odwrócił się od nich i dopuścił, że czcili wojsko niebieskie, jak napisano w księdze Proroków: Czy składaliście Mi ofiary i dary na pustyni przez lat czterdzieści, domu Izraela?***
###### **Dz 7,43**
 ***Obnosiliście raczej namiot Molocha i gwiazdę bożka Refana, wyobrażenia, które zrobiliście, aby im cześć oddawać. Przesiedlę was za to poza Babilon.***
###### **Dz 7,44**
 ***Nasi ojcowie mieli na pustyni Namiot Świadectwa. Ten bowiem, który rozmawiał z Mojżeszem, rozkazał zbudować go według wzoru, jaki [Mojżesz] ujrzał.***
###### **Dz 7,45**
 ***Przyjęli go nasi ojcowie i pod wodzą Jozuego wnieśli do ziemi pogan, których Bóg wypędził przed ojcami naszymi, [i był tam] aż do czasów Dawida.***
###### **Dz 7,46**
 ***On znalazł łaskę u Pana i prosił, aby mógł wznieść przybytek dla Boga Jakuba.***
###### **Dz 7,47**
 ***Ale dopiero Salomon wybudował Mu dom.***
###### **Dz 7,48**
 ***Najwyższy jednak nie mieszka w dziełach rąk ludzkich, jak mówi Prorok:***
###### **Dz 7,49**
 ***Niebo jest moją stolicą, a ziemia podnóżkiem stóp moich. Jakiż dom zbudujecie Mi, mówi Pan, albo gdzież miejsce odpoczynku mego?***
###### **Dz 7,50**
 ***Czyż tego wszystkiego nie stworzyła moja ręka?***
###### **Dz 7,51**
 ***[Ludzie] twardego karku i opornych serc i uszu! Wy zawsze sprzeciwiacie się Duchowi Świętemu. Jak ojcowie wasi, tak i wy.***
###### **Dz 7,52**
 ***Któregoż z proroków nie prześladowali wasi ojcowie? Pozabijali nawet tych, którzy przepowiadali przyjście Sprawiedliwego. A wyście zdradzili Go teraz i zamordowali.***
###### **Dz 7,53**
 ***Wy, którzy otrzymaliście Prawo za pośrednictwem aniołów, lecz nie przestrzegaliście go***».
###### **Dz 7,54**
 Gdy to usłyszeli, zawrzały gniewem ich serca i zgrzytali zębami na niego.
###### **Dz 7,55**
 A on, pełen Ducha Świętego, patrzył w niebo i ujrzał chwałę Bożą i Jezusa, stojącego po prawicy Boga.
###### **Dz 7,56**
 I rzekł: «***Widzę niebo otwarte i Syna Człowieczego, stojącego po prawicy Boga***».
###### **Dz 7,57**
 A oni podnieśli wielki krzyk, zatkali sobie uszy i rzucili się na niego wszyscy razem.
###### **Dz 7,58**
 Wyrzucili go poza miasto i kamienowali, a świadkowie złożyli swe szaty u stóp młodzieńca, zwanego Szawłem.
###### **Dz 7,59**
 Tak kamienowali Szczepana, który modlił się: «***Panie Jezu, przyjmij ducha mego!***»
###### **Dz 7,60**
 A gdy osunął się na kolana, zawołał głośno: «***Panie, nie licz im tego grzechu!***» Po tych słowach skonał.
# Dz 7 PAU
###### **Dz 7,1**
 Wówczas najwyższy kapłan zapytał go: „Czy to prawda?”.
###### **Dz 7,2**
 A on odpowiedział: „Wysłuchajcie mnie, bracia i ojcowie! Bóg pełen majestatu ukazał się w Mezopotamii naszemu ojcu Abrahamowi, zanim ten zamieszkał w Charanie.
###### **Dz 7,3**
 Powiedział wtedy do niego: Opuść swoją ziemię i rodzinę, idź do kraju, który ci wskażę.
###### **Dz 7,4**
 On wyszedł z ziemi Chaldejczyków i zamieszkał w Charanie. Stamtąd po śmierci ojca Bóg kazał mu przenieść się do kraju, który obecnie zamieszkujecie.
###### **Dz 7,5**
 Nie dał mu jednak w posiadanie nawet kawałka tej ziemi. Przyrzekł tylko, że da ją jemu i jego potomstwu, chociaż nie miał on jeszcze wtedy dziecka.
###### **Dz 7,6**
 Powiedział mu Bóg, że jego potomkowie przebywać będą na obcej ziemi. Jej mieszkańcy uczynią ich niewolnikami i będą ich uciskać przez czterysta lat.
###### **Dz 7,7**
 I Bóg powiedział: Ja sam wymierzę karę ludowi, który ich uczyni niewolnikami. Wyjdą stamtąd i będą Mnie czcili na tym miejscu.
###### **Dz 7,8**
 Potem zawarł z Abrahamem przymierze obrzezania. I urodził mu się Izaak, a on ósmego dnia go obrzezał. Izaakowi urodził się Jakub, a Jakubowi dwunastu patriarchów.
###### **Dz 7,9**
 Patriarchowie zazdrościli Józefowi i sprzedali go do Egiptu. Lecz Bóg go nie opuścił.
###### **Dz 7,10**
 Wybawił go ze wszystkich nieszczęść. Dał mu mądrość i sprawił, że faraon, władca Egiptu, był dla niego życzliwy i ustanowił go namiestnikiem nad całym Egiptem i całym swoim dworem.
###### **Dz 7,11**
 Wtedy zapanowała wielka klęska głodu w Egipcie i Kanaanie. Ojcowie nasi nie mieli co jeść.
###### **Dz 7,12**
 Jakub dowiedział się jednak, że w Egipcie jest zboże i po raz pierwszy wysłał tam naszych przodków.
###### **Dz 7,13**
 Za drugim razem Józef dał się poznać swoim braciom. Wtedy faraon dowiedział się o jego pochodzeniu.
###### **Dz 7,14**
 Potem Józef posłał po swojego ojca Jakuba i całą rodzinę złożoną z siedemdziesięciu pięciu osób.
###### **Dz 7,15**
 Jakub przybył więc do Egiptu. Umarł tam on sam i nasi przodkowie.
###### **Dz 7,16**
 Przeniesiono ich do Sychem i pochowano w grobowcu, który Abraham kupił za srebro od synów Chamora.
###### **Dz 7,17**
 A gdy zbliżał się czas wypełnienia obietnicy, którą Bóg dał Abrahamowi, naród bardzo się rozrósł i rozmnożył w Egipcie.
###### **Dz 7,18**
 Wtedy zaczął panować w Egipcie inny władca, który nie znał Józefa.
###### **Dz 7,19**
 Był wrogo nastawiony do naszego narodu i krzywdził naszych przodków. Zmuszał ich do porzucania swoich niemowląt, aby w ten sposób ginęły.
###### **Dz 7,20**
 Wówczas urodził się Mojżesz, który był miły Bogu. Przez trzy miesiące karmiono go w domu ojca.
###### **Dz 7,21**
 A gdy go porzucono, wzięła go córka faraona i przybrała go sobie za syna.
###### **Dz 7,22**
 Mojżesza wykształcono we wszystkich naukach egipskich. Był mocny w słowach i czynach.
###### **Dz 7,23**
 A gdy skończył czterdzieści lat, postanowił odwiedzić swoich rodaków.
###### **Dz 7,24**
 Wtedy zobaczył, jak jednego z nich krzywdzono. Broniąc go, zabił Egipcjanina.
###### **Dz 7,25**
 Sądził, że jego rodacy zrozumieją, iż Bóg za jego pośrednictwem przynosi im wybawienie. Ale oni nie zrozumieli.
###### **Dz 7,26**
 Następnego dnia zobaczył, jak biją się między sobą i usiłował ich pogodzić. «Ludzie, przecież jesteście braćmi! - zawołał - Dlaczego krzywdzicie się wzajemnie?».
###### **Dz 7,27**
 Lecz ten, który krzywdził drugiego, odepchnął go od siebie i powiedział: «Kto ci dał władzę i uczynił cię sędzią nad nami?
###### **Dz 7,28**
 Czy mnie też chcesz zabić, jak wczoraj zabiłeś Egipcjanina?».
###### **Dz 7,29**
 Gdy Mojżesz to usłyszał, uciekł i przebywał jako cudzoziemiec w kraju Madianitów, gdzie urodziło mu się dwóch synów.
###### **Dz 7,30**
 Po czterdziestu latach na pustyni pod górą Synaj ukazał mu się anioł w ogniu płonącego krzewu.
###### **Dz 7,31**
 Gdy Mojżesz to zobaczył, zdziwił się. Podszedł bliżej, aby się dokładnie przyjrzeć i wtedy usłyszał słowa Pana:
###### **Dz 7,32**
 Ja jestem Bogiem twoich ojców; Bogiem Abrahama, Izaaka i Jakuba. Wtedy Mojżesz przeraził się i nie miał odwagi dłużej się temu przyglądać.
###### **Dz 7,33**
 A Pan mu powiedział: Zdejmij sandały z twoich nóg, gdyż miejsce, na którym stoisz, jest ziemią świętą.
###### **Dz 7,34**
 Już się dosyć napatrzyłem na krzywdy mojego ludu w Egipcie i wysłuchałem jego skarg. Dlatego zstąpiłem, aby go uwolnić. Teraz więc podejdź, poślę cię do Egiptu.
###### **Dz 7,35**
 Tego Mojżesza, którego odrzucili, mówiąc: Kto ci dał władzę i uczynił cię sędzią?, Bóg uczynił przywódcą. Wysłał go jako wybawcę i dał mu do pomocy anioła, który objawił mu się w krzewie.
###### **Dz 7,36**
 On wyprowadził ich, czyniąc cuda i znaki w Egipcie, nad Morzem Czerwonym i przez czterdzieści lat na pustyni.
###### **Dz 7,37**
 Tenże Mojżesz powiedział do Izraelitów: Bóg wzbudzi wam spośród was proroka podobnego do mnie.
###### **Dz 7,38**
 On na pustyni pośredniczył między aniołem, który mówił do niego na górze Synaj, a zgromadzeniem naszych przodków. On również otrzymał słowa życia, aby je nam przekazać.
###### **Dz 7,39**
 Ale nasi przodkowie nie chcieli go słuchać i odrzucili go, pragnąc wrócić do Egiptu.
###### **Dz 7,40**
 Powiedzieli do Aarona: Zrób nam bogów, którzy by szli przed nami. Bo nie wiemy, co stało się z Mojżeszem, który nas wyprowadził z Egiptu.
###### **Dz 7,41**
 Zrobili sobie wtedy cielca i złożyli ofiarę temu bożkowi. Cieszyli się dziełem swoich rąk.
###### **Dz 7,42**
 Wtedy Bóg odwrócił się od nich i pozwolił im czcić gwiazdy niebieskie, jak napisano w księdze proroków: Izraelici, czy to Mnie składaliście zwierzęta i ofiary podczas czterdziestoletniego pobytu na pustyni?
###### **Dz 7,43**
 Nie, lecz obnosiliście namiot Molocha, gwiazdę bożka Refana - te wyobrażenia, które uczyniliście, aby im oddawać cześć. Dlatego przesiedlę was poza Babilon.
###### **Dz 7,44**
 Nasi przodkowie mieli na pustyni Namiot Przymierza. Ten bowiem, który rozmawiał z Mojżeszem, kazał mu go uczynić według ukazanego mu wzoru.
###### **Dz 7,45**
 Nasi przodkowie przejęli go i pod wodzą Jozuego wnieśli do ziemi, z której Bóg przed nimi wypędził pogan. Tam namiot pozostał aż do czasów Dawida.
###### **Dz 7,46**
 Jego Bóg obdarzył łaską, a on prosił, aby mógł zbudować świątynię dla domu Jakuba.
###### **Dz 7,47**
 Jednak dopiero Salomon wybudował Mu dom.
###### **Dz 7,48**
 Ale Bóg Najwyższy nie mieszka w budowlach wzniesionych przez człowieka, jak mówi prorok:
###### **Dz 7,49**
 Niebo jest moim tronem, a ziemia podnóżkiem stóp moich. Jakiż dom możecie Mi zbudować - mówi Pan, i gdzie jest miejsce, w którym miałbym odpocząć?
###### **Dz 7,50**
 Przecież to wszystko uczyniła moja ręka.
###### **Dz 7,51**
 Ludzie twardego karku, opornych serc i uszu! Wy zawsze sprzeciwiacie się Duchowi Świętemu! Postępujecie jak wasi przodkowie!
###### **Dz 7,52**
 Którego z proroków nie prześladowali wasi przodkowie? Zabili tych, którzy zapowiadali przyjście Sprawiedliwego. A wy zdradziliście Go i zabiliście.
###### **Dz 7,53**
 Otrzymaliście Prawo za pośrednictwem aniołów, ale nie przestrzegaliście go”.
###### **Dz 7,54**
 Gdy oni usłyszeli te słowa, wpadli w gniew i zgrzytali na niego zębami.
###### **Dz 7,55**
 Lecz on pełen Ducha Świętego spojrzał w niebo. Ujrzał majestat Boga i Jezusa po prawej stronie Boga.
###### **Dz 7,56**
 Powiedział wówczas: „Widzę niebo otwarte i Syna Człowieczego stojącego po prawej stronie Boga”.
###### **Dz 7,57**
 A oni głośno krzyczeli i zatykali sobie uszy. Rzucili się na niego wszyscy razem i
###### **Dz 7,58**
 wyprowadzili go za miasto. Tam go kamienowali. A świadkowie złożyli swoje płaszcze przed młodzieńcem o imieniu Szaweł.
###### **Dz 7,59**
 Kamienowali Szczepana, który modlił się: „Panie Jezu! Przyjmij mego ducha”.
###### **Dz 7,60**
 Padając na kolana, zawołał głośno: „Panie, nie obciążaj ich tym grzechem!”. Po tych słowach skonał.
# Dz 7 BP
###### **Dz 7,1**
 Zapytał go arcykapłan: "Czy tak się sprawa przedstawia?"
###### **Dz 7,2**
 On zaś odpowiedział: "Ojcowie i bracia, słuchajcie! Bóg chwały ukazał się ojcu naszemu Abrahamowi, gdy przebywał w Mezopotamii, zanim zamieszkał w Charan.
###### **Dz 7,3**
 "I powiedział do niego: Wyjdź ze swej ziemi i opuść rodzinę, a idź do ziemi, którą ci ukażę".
###### **Dz 7,4**
 Opuścił wtedy ziemię chaldejską i zamieszkał w Charan, a stąd po śmierci ojca swego przeniósł się do tej ziemi, którą wy teraz zamieszkujecie.
###### **Dz 7,5**
 Nie dał mu jednak w posiadanie nawet skrawka ziemi, ale obiecał "dać ją później na własność jemu i jego potomstwu", chociaż Abraham nie miał jeszcze syna.
###### **Dz 7,6**
 Bóg powiedział: "Potomstwo jego będzie przechodniem w obcej ziemi i podbiją je w niewolę, źle się z nim obchodząc przez czterysta lat.
###### **Dz 7,7**
 A naród, któremu będą służyć, Ja osądzę" - mówi Bóg - "i wyjdzie potem, aby Mnie czcić na tym miejscu".
###### **Dz 7,8**
 Potem zawarł z nim Przymierze, którego znakiem było obrzezanie. Wtedy urodził mu się Izaak. I obrzezał go ósmego dnia. Tak samo Izaak [obrzezał] Jakuba, a Jakub dwunastu patriarchów.
###### **Dz 7,9**
 Patriarchowie z zazdrości sprzedali Józefa do Egiptu, ale Bóg go nie opuścił,
###### **Dz 7,10**
 uwalniając go od wszystkich utrapień. I dał mu wraz z mądrością życzliwość faraona, króla Egiptu, który ustanowił go zarządcą Egiptu i wszystkich posiadłości.
###### **Dz 7,11**
 Wtedy zapanowała wielka klęska głodu w Egipcie i Kanaan; ojcowie nasi nie mieli co jeść.
###### **Dz 7,12**
 Jakub dowiedział się, że w Egipcie jest żywność, wysłał więc najpierw naszych ojców.
###### **Dz 7,13**
 Za drugim razem Józef dał już się poznać braciom i w ten sposób faraon dowiedział się o jego pochodzeniu.
###### **Dz 7,14**
 Józef odesłał ich i wezwał ojca swego Jakuba i całą rodzinę, składającą się z siedemdziesięciu pięciu osób.
###### **Dz 7,15**
 Tak przeniósł się Jakub do Egiptu, gdzie umarł on sam i ojcowie nasi.
###### **Dz 7,16**
 Przeniesiono ich do Sychem i pochowano w grobowcu, który nabył tam Abraham za pieniądze od synów Hemora.
###### **Dz 7,17**
 Gdy nadchodził czas wypełnienia obietnicy, którą dał Bóg Abrahamowi, lud rozrósł się i rozmnożył w Egipcie.
###### **Dz 7,18**
 Trwało to aż do czasu nastania innego króla w Egipcie, który nie znał już Józefa.
###### **Dz 7,19**
 Działał on podstępnie przeciwko naszemu narodowi, źle traktując przodków, nakazał bowiem pozbawiać życia noworodki.
###### **Dz 7,20**
 W tym czasie urodził się Mojżesz, który był miły Bogu. Karmiono go przez trzy miesiące w domu ojca.
###### **Dz 7,21**
 Kiedy go wyrzucono, wzięła go córka faraona i wychowała jak własnego syna.
###### **Dz 7,22**
 Mojżesz zdobył w Egipcie wszechstronne wykształcenie, odznaczając się siłą słowa i czynu.
###### **Dz 7,23**
 Gdy skończył czterdzieści lat, zapragnął odwiedzić swoich braci Izraelitów.
###### **Dz 7,24**
 Zobaczył wtedy, jak któregoś z nich krzywdzono. Wziął go w obronę i pomścił udręczonego, zabijając Egipcjanina.
###### **Dz 7,25**
 Sądził bowiem, że znajdzie zrozumienie u swoich rodaków, że przez niego Bóg chce ich wybawić. Oni jednak nie zrozumieli go.
###### **Dz 7,26**
 Następnego dnia zjawił się wśród nich, gdy się kłócili między sobą, a usiłując ich pogodzić, powiedział: "Ludzie! Braćmi jesteście. Czemu krzywdzicie się wzajemnie?"
###### **Dz 7,27**
 Wtedy ten, który wyrządził krzywdę bliźniemu, odepchnął go i powiedział: "Któż ustanowił cię zwierzchnikiem i sędzią nad nami?
###### **Dz 7,28**
 Czy mnie też chcesz zabić, jak wczoraj zabiłeś Egipcjanina?"
###### **Dz 7,29**
 Usłyszawszy te słowa Mojżesz uciekł i zamieszkał jako cudzoziemiec w ziemi Madian, gdzie urodziło mu się dwóch synów.
###### **Dz 7,30**
 Kiedy upłynęło czterdzieści lat, na pustyni góry Synaj w płomieniu krzaka ognistego ukazał mu się anioł.
###### **Dz 7,31**
 Mojżesz przypatrywał się temu zdumiony, a gdy się zbliżał, by to dokładniej zobaczyć, rozległ się głos Pana:
###### **Dz 7,32**
 "Ja jestem Bogiem ojców twoich, Bogiem Abrahama, Izaaka i Jakuba". Przeraził się wtedy Mojżesz i nie śmiał nawet podnieść wzroku.
###### **Dz 7,33**
 Powiedział mu Pan: "Zdejmij obuwie z nóg twoich, bo miejsce, na którym stoisz, jest ziemią świętą.
###### **Dz 7,34**
 Napatrzyłem się na krzywdy ludu mojego w Egipcie i jęki jego dochodziły do Mnie, dlatego zstąpiłem, aby go uwolnić. Chodź więc, poślę cię do Egiptu".
###### **Dz 7,35**
 Posłał więc Bóg Mojżesza jako wodza i wybawcę, tego właśnie, którego zaparli się pytając: "Kto cię ustanowił wodzem i sędzią?" A dokonał tego z pomocą anioła, który ukazał mu się w krzaku.
###### **Dz 7,36**
 Mojżesz ich wyprowadził, dokonując znaków i cudów w ziemi egipskiej, na Morzu Czerwonym i przez czterdzieści lat na pustyni.
###### **Dz 7,37**
 Tenże Mojżesz powiedział synom Izraela: "Proroka powoła dla was Bóg, podobnie jak mnie, spośród braci waszych".
###### **Dz 7,38**
 To właśnie Mojżesz otrzymał słowa życia, by nam je przekazać wtedy, gdy zebrali się na pustyni ojcowie nasi i anioł, z którym on rozmawiał na górze Synaj.
###### **Dz 7,39**
 Ojcowie nasi nie chcieli go jednak słuchać, ale odepchnęli go, zwracając swe serca ku Egiptowi.
###### **Dz 7,40**
 Powiedzieli do Aarona: "Daj nam bogów, którzy będą nas prowadzić, bo nie wiemy, co się stało z Mojżeszem, który wyprowadził nas z ziemi egipskiej".
###### **Dz 7,41**
 Wtedy właśnie uczynili sobie cielca i złożyli ofiarę bożkowi, ciesząc się dziełami rąk swoich.
###### **Dz 7,42**
 Wtedy Bóg odwrócił się i dopuścił, że oddawali cześć ciałom niebieskim, jak napisane zostało w Księdze Proroków: "Ludu Izraela, czy nie składałeś mi darów i ofiar przez czterdzieści lat na pustyni?
###### **Dz 7,43**
 Dlaczego teraz obnosisz namiot Molocha? I gwiazdy boga twojego Remfana?" Na ich cześć "uczyniłeś obrazy, dlatego wyrzucę cię poza Babilon".
###### **Dz 7,44**
 Namiot Przymierza mieli ojcowie nasi na pustyni, zgodnie z poleceniem danym Mojżeszowi, aby go zbudował według wzoru, który widział.
###### **Dz 7,45**
 Po otrzymaniu go ojcowie nasi pod wodzą Jozuego wnieśli go do ziemi, z której Bóg wypędził pogan dla ojców naszych; tak też pozostało do czasów Dawida.
###### **Dz 7,46**
 Będąc w łasce u Boga, prosił o miejsce na dom dla Boga Jakuba.
###### **Dz 7,47**
 Dopiero jednak Salomon zbudował Mu dom.
###### **Dz 7,48**
 Ale Najwyższy nie mieszka w domach zbudowanych ręką ludzką, jak mówi prorok:
###### **Dz 7,49**
 "Tronem moim jest niebo, ziemia podnóżkiem nóg moich. Jaki dom możecie mi zbudować? - mówi Pan. Albo jakie miejsce może być dla mnie wytchnieniem?
###### **Dz 7,50**
 Przecież to wszystko moja ręka uczyniła".
###### **Dz 7,51**
 Ludzie twardego karku, nieczułych serc i głuchych uszu, zawsze opieraliście się Duchowi Świętemu, zarówno wy, jak i ojcowie wasi.
###### **Dz 7,52**
 Którego to z proroków nie prześladowali ojcowie wasi? Zabijali nawet tych, którzy przepowiadali przyjście Sprawiedliwego; a wy Go zdradziliście i zabiliście!
###### **Dz 7,53**
 Wy, którzy otrzymaliście prawo przez aniołów, a nie przestrzegaliście go!".
###### **Dz 7,54**
 Gdy go słuchali, zawrzało w ich sercach i zgrzytali zębami.
###### **Dz 7,55**
 Szczepan napełniony Duchem Świętym patrzył w niebo i widział chwałę Bożą oraz Jezusa po prawicy Bożej.
###### **Dz 7,56**
 Powiedział wtedy: "Oto widzę niebo otwarte i Syna Człowieczego po prawicy Bożej".
###### **Dz 7,57**
 Zaczęli przeraźliwie krzyczeć, pozatykali sobie uszy, rzucili się na niego, wyprowadzili za miasto i kamienowali.
###### **Dz 7,58**
 Świadkowie złożyli swoje szaty u stóp młodzieńca zwanego Szawłem.
###### **Dz 7,59**
 I kamienowali Szczepana, on zaś modlił się tymi słowami: "Panie Jezu, przyjmij ducha mego!"
###### **Dz 7,60**
 W końcu upadł na kolana i zawołał donośnym głosem: "Panie, nie poczytaj im tego za grzech!" Po tych słowach skonał.
# Dz 7 BR
###### **Dz 7,1**
 I zapytał go arcykapłan: Czy to prawda?
###### **Dz 7,2**
 A on odpowiedział: Słuchajcie, bracia i ojcowie! Bóg w swej chwale objawił się Ojcu naszemu Abrahamowi, gdy jeszcze żył w Mezopotamii, nim zamieszkał w Charanie.
###### **Dz 7,3**
 I powiedział wtedy do niego: Zostaw swoją ziemię i rodzinę i udaj się do ziemi, którą ci wskażę.
###### **Dz 7,4**
 Wyszedł tedy [Abraham] z ziemi chaldejskiej i zamieszkał w Charanie, skąd po śmierci ojca, posłuszny Bożemu pokoleniu, przeniósł się do kraju, który wy teraz zamieszkujecie.
###### **Dz 7,5**
 Nie dał mu jednak w posiadanie ani kawałka tej ziemi. Obiecał tylko, że ją przekaże najpierw jemu, a potem jego potomstwu, choć wtedy [Abraham] nie miał jeszcze żadnego potomka.
###### **Dz 7,6**
 Oto, co mu Bóg powiedział: Twoi potomkowie będą wygnańcami na obczyźnie, gdzie jako niewolników będą ich nękać przez czterysta lat.
###### **Dz 7,7**
 Lecz Ja sam osądzę ten naród, który będzie ich trzymał w niewoli - mówi Pan. W końcu wydostaną się z tej niewoli i będą Mi służyć na tym miejscu.
###### **Dz 7,8**
 I zawarł z nim przymierze, którego znakiem zewnętrznym było obrzezanie. Synem Abrahama był Izaak, obrzezany ósmego dnia po urodzeniu, Izaaka zaś - Jakub, od którego pochodzi dwunastu patriarchów.
###### **Dz 7,9**
 Przez zawiść patriarchowie sprzedali Józefa do Egiptu, ale Bóg był z nim.
###### **Dz 7,10**
 Uwolnił go od wszelkiego ucisku i obdarzył łaską szczególnej mądrości w obcowaniu z faraonem, królem Egiptu, który uczynił go zarządcą całego Egiptu oraz domu królewskiego.
###### **Dz 7,11**
 A kiedy nastał głód w calym Egipcie i Kanaanie, ojcowie nasi cierpieli wielki niedostatek i przymierali głodem.
###### **Dz 7,12**
 Wtedy Jakub dowiedziawszy się, że w Egipcie jest zboże, wysłał tam po raz pierwszy naszych ojców.
###### **Dz 7,13**
 Za drugim zaś razem Józef już dał się poznać swoim braciom, a faraon dowiedział się wszystkiego o jego rodzie.
###### **Dz 7,14**
 Posłał tedy Józef po Jakuba, sprowadził go [do Egiptu] i całą rodzinę z nim, razem około siedemdziesięciu pięciu osób.
###### **Dz 7,15**
 Przybył Jakub do Egiptu i tam też umarł on sam i nasi ojcowie.
###### **Dz 7,16**
 Przeniesiono ich do Sychem i złożono w grobie, który jeszcze Abraham kupił za srebro od synów Chamora w Sychem.
###### **Dz 7,17**
 Im bardziej zaś zbliżał się czas wypełnienia obietnicy danej przez Boga Abrahamowi, tym bardziej Rozrastał się i rozmnażał lud przebywający w Egipcie.
###### **Dz 7,18**
 Potem w Egipcie wstąpił na tron inny władca, nie znający w ogóle Józefa.
###### **Dz 7,19**
 Był on nastawiony wrogo do naszego narodu i zmuszał naszych ojców do wyrzucania ich niemowląt, aby nie pozostawały przy życiu.
###### **Dz 7,20**
 Wtedy to przyszedł na świat Mojżesz, który od samego początku znajdował upodobanie w oczach Boga. Przez trzy miesiące wychowywał się w domu swego ojca,
###### **Dz 7,21**
 kiedy zaś wyrzucono go z domu, został znaleziony przez córkę faraona, która przybrała go sobie za syna.
###### **Dz 7,22**
 Wykształcono Mojżesza we wszystkich naukach egipskich, tak że był potężny w słowie i w czynie.
###### **Dz 7,23**
 A gdy ukończył już lat czterdzieści, postanowił odwiedzić swych braci, synów Izraela.
###### **Dz 7,24**
 Raz zobaczył, jak jednemu z nich wyrządzano krzywdę. Stanął więc niezwłocznie w jego obronie i zabiwszy Egipcjanina, w ten sposób pomścił skrzywdzonego.
###### **Dz 7,25**
 Był przekonany, że jego bracia domyślają się, iż przez jego ręce Bóg zsyła im zbawienie. Ale oni tego nie zrozumieli wcale.
###### **Dz 7,26**
 Kiedy następnego dnia zjawił się wśród nich i usiłował pojednać bijących się ze sobą mówiąc: Ludzie, przecież braćmi jesteście, czemu wyrządzacie sobie krzywdę nawzajem?
###### **Dz 7,27**
 - to ten, który znieważał swego brata, odepchnął go, wołając przy tym: A któż to ustanowił cię panem i sędzią nad nami?
###### **Dz 7,28**
 Czy może i mnie chcesz zabić, tak jak wczoraj zabiłeś Egipcjanina?
###### **Dz 7,29**
 Usłyszawszy to, Mojżesz uciekł i błąkał się jak cudzoziemiec w krainie Madian. Tam też przyszło na świat jego dwu synów.
###### **Dz 7,30**
 Po czterdziestu latach, [pewnego dnia] na pustyni [w pobliżu] góry Synaj ukazał mu się w ognistym krzaku anioł Pański.
###### **Dz 7,31**
 Kiedy Mojżesz zobaczył go, zdumiał się bardzo, lecz gdy podszedł bliżej, żeby się mu dokładniej przyjrzeć, usłyszał takie oto słowa Pana:
###### **Dz 7,32**
 Ja jestem Bogiem twoich ojców, Bogiem Abrahama i Izaaka, i Jakuba. Na te słowa przeraził się Mojżesz i nie miał odwagi już więcej patrzeć.
###### **Dz 7,33**
 A Pan powiedział do niego: Zdejm obuwie z twoich nóg, bo miejsce, na którym stoisz - to ziemia święta.
###### **Dz 7,34**
 Długo patrzyłem na cierpienia mojego ludu w Egipcie. Wysłuchałem na koniec jego wołania i zstąpiłem, aby go uwolnić. Chodź tu, gdyż ciebie zamierzam posłać do Egiptu.
###### **Dz 7,35**
 W ten sposób tego właśnie Mojżesza, którego oni się wyparli, mówiąc: Któż to ustanowił cię panem i sędzią naszym? - Bóg wysłał jako przywódcę i wybawcę, oddając go pod opiekę anioła, który ukazał mu się w krzaku.
###### **Dz 7,36**
 I on to właśnie wyprowadził ich [z niewoli], czyniąc przy tym liczne znaki i cuda w ziemi egipskiej, nad Morzem Czerwonym i przez lat czterdzieści podczas wędrówki przez pustynię.
###### **Dz 7,37**
 To Mojżesz również powiedział do potomków Izraela: Proroka podobnego do mnie wzbudzi wam Bóg spośród braci waszych.
###### **Dz 7,38**
 On to przebywając z ludem na pustyni był pośrednikiem między aniołem, który przemawiał do niego na górze Synaj, a naszymi ojcami. On również otrzymał słowa nauki zapewniającej życie, po to, aby wam je przekazać.
###### **Dz 7,39**
 Lecz nasi ojcowie nie chcieli go słuchać: odtrącili go i zwrócili swe serca ku Egipcjanom,
###### **Dz 7,40**
 mówiąc do Aarona: Uczyń nam bogów, którzy by szli przed nami. Nie wiemy bowiem, co stało się z Mojżeszem, który nas wyprowadził z ziemi egipskiej.
###### **Dz 7,41**
 I zrobili sobie posąg cielca, składali ofiary temu idolowi i chełpili się dziełem rąk swoich.
###### **Dz 7,42**
 Wtedy Bóg odwrócił się od nich i dopuścił, że oddawali cześć ciałom niebieskim, zgodnie z tym, co napisane w księdze proroków: Czy to Mnie, o Izraelici, składaliście dary i ofiary podczas czterdziestoletniej wędrówki po pustyni?
###### **Dz 7,43**
 Nie, obnosiliście raczej namiot Molocha i gwiazdę przedstawiającą bożka Remfana, wyobrażenia, które uczyniliście, aby im właśnie cześć oddawać. Odrzucę was za to dalej niż Babilon.
###### **Dz 7,44**
 Nasi ojcowie mieli na pustyni Namiot Świadectwa, który został zbudowany przez Mojżesza na rozkaz Boga, według przedstawionego wzoru.
###### **Dz 7,45**
 Przejęli go nasi ojcowie i pod wodzą Jozuego wnieśli do ziemi uwolnionej przez Boga od jej dotychczasowych mieszkańców dla ojców naszych. Tam pozostawał ów przybytek aż do czasów Dawida,
###### **Dz 7,46**
 który cieszył się szczególnymi względami u Pana. On to prosił Boga, by dana mu była łaska zbudowania [nowego] przybytku dla Boga Jakuba.
###### **Dz 7,47**
 Jednakże dopiero Salomon Mu zbudował dom.
###### **Dz 7,48**
 Lecz Najwyższy nie mieszka - jak mówi prorok - w budowlach, wzniesionych rękami ludzkimi:
###### **Dz 7,49**
 Moim tronem jest niebo, a ziemia służy za podnóżek dla stóp moich. Jakiż dom wy możecie Mi zbudować - pyta Pan albo gdzie znajdziecie miejsce na odpoczynek dla Mnie?
###### **Dz 7,50**
 Czyż tego wszystkiego nie stworzyła moja ręka?
###### **Dz 7,51**
 O wy, ludzie twardego karku, opornych serc i uszu! Zawsze sprzeciwiacie się Duchowi Świętemu. Postępujecie tak samo, jak wasi ojcowie.
###### **Dz 7,52**
 Któryż to z proroków nie był prześladowany przez ojców waszych? Pozabijali nawet tych, którzy przepowiadali przyjście Sprawiedliwego. Teraz zaś wy zdradziliście Go i zgładziliście,
###### **Dz 7,53**
 wy, którzy za pośrednictwem aniołów otrzymaliście Prawo, ale wcale nie przestrzegaliście go.
###### **Dz 7,54**
 Usłyszawszy to unieśli się wielkim gniewem i aż poczęli zgrzytać na niego zębami.
###### **Dz 7,55**
 A on, pełen Ducha Świętego, wzniósł oczy ku niebu, oglądając chwałę Bożą i Jezusa stojącego po prawicy Boga.
###### **Dz 7,56**
 I rzekł: Widzę niebo otwarte i Syna Człowieczego, stojącego po prawicy Boga!
###### **Dz 7,57**
 Na to oni podnieśli wielki krzyk, zatkali sobie uszy i rzucili się wszyscy razem na niego.
###### **Dz 7,58**
 Wywlekli go poza miasto i obrzucili kamieniami, a świadkowie złożyli swoje szaty u stóp młodego człowieka imieniem Szaweł.
###### **Dz 7,59**
 I tak kamienowali Szczepana, który modlił się w ten sposób: Panie Jezu, przyjmij ducha mego.
###### **Dz 7,60**
 A kiedy już upadł na kolana, zawołał głośno: Panie, nie uważaj ich za winnych tego grzechu! I po tych słowach skonał. A Szaweł godził się na zamordowanie Szczepana.
# Dz 7 WUJ
###### **Dz 7,1**
 I rzekł Nawyższy kapłan: Jeśli się to tak ma?
###### **Dz 7,2**
 Który rzekł: Mężowie bracia i ojcowie, słuchajcie: Bóg chwały ukazał się ojcu naszemu Abrahamowi, gdy był w Mezopotamjej, przed tem niż mieszkał w Charan.
###### **Dz 7,3**
 I rzekł do niego: Wynidź z ziemie twej, iż twojej rodziny, a idź do ziemie, którąć ukażę.
###### **Dz 7,4**
 Tedy wyszedł z ziemie Chaldejskiej, i mieszkał w Charan: a ztamtąd, gdy umarł ociec jego, przeniósł go do tej ziemie, w której wy teraz mieszkacie.
###### **Dz 7,5**
 I nie dał mu w niej dziedzictwa i na krok nogi: a obiecał mu ją dać w osiadłość, i nasieniu jego po nim, gdy nie miał syna.
###### **Dz 7,6**
 I mówił mu Bóg: Że nasienie jego przychodniem będzie w cudzej ziemi: i podbiją je w niewolą, i źle się z niemi obchodzić będą przez cztery sta lat:
###### **Dz 7,7**
 A naród, któremu służyć będą, ja sądzić będę, rzekł Pan: a potem wynidą, i będą mi służyć na tem miejscu.
###### **Dz 7,8**
 I dał mu testament obrzezania: i tak zrodził Izaaka, i obrzezał go dnia ósmego: a Izaak Jakóba, a Jakób dwanaście Patryarchów.
###### **Dz 7,9**
 A Patryarchowie nienawidząc Józefa przedali do Egiptu: I był Bóg z nim.
###### **Dz 7,10**
 I wyrwał go ze wszystkich jego ucisków: a dał mu łaskę i mądrość przed oczyma Faraona króla Egiptskiego: i postanowił go nad Egiptem, i nad wszystkim domem swoim.
###### **Dz 7,11**
 I przyszedł głód na wszystek Egipt i Chanaan, i wielkie uciśnienie: i nie najdowali żywności Ojcowie naszy.
###### **Dz 7,12**
 A usłyszawszy Jakób, iż było zboże w Egiptcie, posiał ojce nasze pierwszy raz:
###### **Dz 7,13**
 A za którym razem poznany jest Józef od braciej swojej, i oznajmiony jest Faraonowi naród jego.
###### **Dz 7,14**
 A Józef posławszy, przyzwał ojca swego Jakóba, i wszystkiej rodziny swej w siedmidziesiąt i piąci duszach.
###### **Dz 7,15**
 I zstąpił Jakób do Egiptu: i umarł on i ojcowie naszy.
###### **Dz 7,16**
 I przeniesieni są do Sychem, i położeni są w grobie, który kupił Abraham za summę srebra u synów Hemora syna Sychem.
###### **Dz 7,17**
 A gdy się przybliżył czas obietnice, którą był przysiągł Bóg Abrahamowi: rozrodził się lud i rozmnożył w Egiptcie:
###### **Dz 7,18**
 Aż nastał inny król w Egiptcie, który nie znał Józefa.
###### **Dz 7,19**
 Ten podszedszy nasz naród, utrapił ojce nasze: żeby wyrzucali dziatki swe, aby nie żyły.
###### **Dz 7,20**
 Tegoż czasu narodził się Mojżesz, i był przyjemny Bogu: który wychowany był trzy miesiące w domu ojca swego.
###### **Dz 7,21**
 A gdy był wyrzucony, wzięła go córka Faraonowa, i wychowała go sobie za syna.
###### **Dz 7,22**
 I wyćwiczon był Mojżesz we wszelkiej mądrości Egiptskiej: i był możnym w słowiech i w uczynkach swoich.
###### **Dz 7,23**
 A gdy mu się wypełnił czas czterdzieścia lat, przyszło mu na myśl, aby nawiedził bracią swą syny Izraelskie.
###### **Dz 7,24**
 A widząc niektórego ukrzywdzonego, obronił go i pomścił się krzywdy onego, który krzywdę cierpiał, zabiwszy Egiptczyka.
###### **Dz 7,25**
 A mniemał, żeby rozumieli bracia, że Bóg daje im wybawienie przez rękę jego: lecz oni nie rozumieli.
###### **Dz 7,26**
 A nazajutrz ukazał się im, gdy się wadzili, i jednał je na pokój mówiąc: Mężowie, braciaście sobie: czemu jeden drugiego krzywdzicie?
###### **Dz 7,27**
 Lecz co krzywdził bliźniego, odegnał go, mówiąc: Któż cię postawił książęciem i sędzią nad nami?
###### **Dz 7,28**
 Izali mię ty chcesz zabić, jakoś wczora zabił Egiptczyka?
###### **Dz 7,29**
 I uciekł Mojżesz dla słowa tego: i stał się przychodniem w ziemi Madyańskiej, gdzie zrodził dwu synu.
###### **Dz 7,30**
 A gdy wyszło lat czterdzieści, ukazał się mu na puszczy góry Syna Anioł w ogniu płomienistym krza.
###### **Dz 7,31**
 Lecz Mojżesz, ujrzawszy, dziwował się widzeniu. A gdy przystępował, aby się przypatrzył, stał się do niego głos Pański, mówiąc:
###### **Dz 7,32**
 Jam jest Bóg ojców twoich, Bóg Abrahamów, Bóg Izaaków, i Bóg Jakóbów. A zadrżawszy Mojżesz, nie śmiał się przypatrować.
###### **Dz 7,33**
 I rzekł mu Pan: Zzuj obuwie nóg twoich: bo miejsce, na którem stoisz, jest ziemia święta.
###### **Dz 7,34**
 Widziałem widząc utrapienie ludu mego, który jest w Egiptcie, i słyszałem wzdychanie ich, i zstąpiłem, żebych je wybawił. A teraz chodź, a poślę cię do Egiptu.
###### **Dz 7,35**
 Tego Mojżesza, którego się zaprzeli, mówiąc: Kto cię postanowił książęciem i sędzią? tego Bóg książęciem i odkupicielem posłał, z ręką Anioła, który mu się ukazał we krzu.
###### **Dz 7,36**
 Ten je wywiódł, uczyniwszy cuda i znaki w ziemi Egiptskiej i w morzu Czerwonem, i na puszczy przez czterdzieści lat.
###### **Dz 7,37**
 Ten jest Mojżesz, który powiedział synom Izraelskim: Proroka wam wzbudzi Bóg z braciej waszej jako mnie: jego słuchać będziecie.
###### **Dz 7,38**
 Ten jest, który był w zgromadzeniu na puszczy, z Aniołem, który z nim mawiał na górze Syna, i z ojcy naszemi: który przyjął słowa żywota, aby nam dał.
###### **Dz 7,39**
 Któremu nie chcieli być posłuszni ojcowie naszy, ale odrzucili, i odwrócili się sercem swem do Egiptu:
###### **Dz 7,40**
 Mówiąc do Aarona: Uczyń nam bogi, którzyby szli przed nami: abowiem Mojżesz ten, który nas wywiódł z ziemie Egiptskiej, nie wiemy co mu się stało.
###### **Dz 7,41**
 I uczynili w one dni cielca, i ofiarowali ofiarę bałwanowi, i weselili się w dziełach rąk swoich.
###### **Dz 7,42**
 I odwrócił Bóg i podał je, aby służyli zastępom niebieskim: jako napisano jest w księgach prorockich: Zażeście mi ofiary i obiaty ofiarowali na puszczy przez czterdzieści lat, domie Izraelski?
###### **Dz 7,43**
 I przyjęliście namiot Molochów, i gwiazdę boga waszego Remfam, figury, któreście czynili, abyście im pokłon czynili. I przeniosę was za Babilon.
###### **Dz 7,44**
 Przybytek świadectwa był z ojcy naszemi na puszczy, jako rozrządził Bóg mówiący do Mojżesza: aby ji uczynił wedle kształtu, który widział.
###### **Dz 7,45**
 Który też wprowadzili przyjąwszy ojcowie naszy z Jezusem w osiadłość poganów, które Bóg wygnał przed obliczem ojców naszych, aż do dni Dawidowych:
###### **Dz 7,46**
 Który nalazł łaskę przed Bogiem, i prosił, aby znalazł przybytek Bogu Jakóbowemu.
###### **Dz 7,47**
 A Salomon zbudował jemu dom.
###### **Dz 7,48**
 Ale Nawyższy nie mieszka w uczynionych ręką, jako prorok powiada.
###### **Dz 7,49**
 Niebo jest mi stolicą, a ziemia podnóżkiem nóg moich. Cóż mi za dom zbudujecie, mówi Pan; abo które jest miejsce odpoczynienia mego?
###### **Dz 7,50**
 Zali ręka moja tego wszystkiego nie uczyniła?
###### **Dz 7,51**
 Twardego karku i nie obrzezanych serc i uszu, wy się zawżdy sprzeciwiacie Duchowi świętemu: jako ojcowie waszy, także i wy.
###### **Dz 7,52**
 Którego z proroków nie prześladowali ojcowie waszy? i zabili tych, którzy opowiadali o przyściu sprawiedliwego, któregoście wy teraz zdrajcami i mężobójcami byli:
###### **Dz 7,53**
 Którzyście wzięli zakon przez rozrządzenie Anielskie, a nie strzegliście.
###### **Dz 7,54**
 A słuchając tego, krajały się serca ich, i zgrzytali nań zębami.
###### **Dz 7,55**
 A będąc pełen Ducha ś., patrząc pilnie w niebo, ujrzał chwałę Bożą, i Jezusa stojącego po prawicy Bożej. I rzekł: Oto widzę niebiosa otworzone, a Syna człowieczego stojącego po prawicy Bożej.
###### **Dz 7,56**
 A krzyknąwszy głosem wielkim, zatulili sobie uszy, i rzucili się nań jednomyślnie.
###### **Dz 7,57**
 A wyrzuci wszy go z miasta, kamionowali: a świadkowie składali szaty swe u nóg młodzieńca, którego zwano Szawłem.
###### **Dz 7,58**
 I kamionowali Szczepana wzywającego a mówiącego: Panie Jezu, przymi ducha mojego.
###### **Dz 7,59**
 A klęknąwszy na kolana, zawołał głosem wielkim, mówiąc: Panie, nie przyczytaj im tego grzechu. A to rzekszy, zasnął w Panu.
###### **Dz 7,60**
 A Szaweł zezwalał na zabicie jego.
# Dz 7 STERN
###### **Dz 7,1**
 Kohen hagadol zapytał: "Czy prawdziwe są te oskarżenia?",
###### **Dz 7,2**
 Szczepan zaś rzekł: "Bracia i ojcowie, posłuchajcie mnie! Bóg chwały objawił się Awrahamowi awinu w Mezopotamii, zanim zamieszkał w Charanie,
###### **Dz 7,3**
 i powiedział mu: "Opuść swą ziemię i swój ród i idź do ziemi, którą ci wskażę".
###### **Dz 7,4**
 Opuścił więc kraj Chaldejczyków i zamieszkał w Charanie. Gdy zmarł jego ojciec, Bóg sprawił, że przeniósł się do tej ziemi, na której teraz żyjecie.
###### **Dz 7,5**
 Nie dał mu w niej żadnego dziedzictwa, ani piędzi ziemi, obiecał jednak, że da mu ją na własność i potomkom jego po nim, mimo że w tym czasie był bezdzietny.
###### **Dz 7,6**
 Oto, co powiedział mu Bóg: "Potomkowie twoi będą cudzoziemcami w obcej ziemi, gdzie będą w niewoli i ucisku przez czterysta lat.
###### **Dz 7,7**
 Lecz ja osądzę naród, który ich niewoli - rzekł Bóg - a później odejdą i będą mi oddawać cześć w tym miejscu".
###### **Dz 7,8**
 I dał mu b'rit-milę. Stał się on więc ojcem Jic'chaka i dokonał jego b'rit-mili ósmego dnia, a Jic'chak stał się ojcem Ja'akowa, Ja'akow zaś stał się ojcem Dwunastu Patriarchów.
###### **Dz 7,9**
 A Patriarchowie byli zazdrośni o Josefa i sprzedali go w niewolę do Egiptu. Ale Adonai był z nim,
###### **Dz 7,10**
 wybawił go z wszelkich jego ucisków i dał mu przychylność i mądrość w oczach faraona, króla Egiptu, który ustanowił go głównym zarządcą nad Egiptem i nad całym domem swoim.
###### **Dz 7,11**
 A nadszedł głód, który sprawił wiele cierpienia w całym Egipcie i Kena'anie.
###### **Dz 7,12**
 Lecz gdy Ja'akow usłyszał, że w Egipcie jest zboże, wysłał tam naszych ojców po raz pierwszy.
###### **Dz 7,13**
 Za drugim razem Josef dał się poznać swym braciom, a rodzina Josefa stała się znana faraonowi.
###### **Dz 7,14**
 Josef posłał wtedy po ojca swego Jaakowa i wszystkich swych krewnych, siedemdziesiąt pięć osób.
###### **Dz 7,15**
 I Ja'akow udał się do Egiptu, gdzie zmarł, podobnie jak inni nasi przodkowie.
###### **Dz 7,16**
 Ciała ich przeniesiono do Sz'chem i pochowano w grobowcu, który Awraham nabył za określoną kwotę od rodziny Chamora w Sz'chem.
###### **Dz 7,17**
 Kiedy zbliżał się czas wypełnienia obietnicy, jaką Bóg złożył Awrahamowi, liczba naszego ludu w Egipcie znacznie się powiększyła,
###### **Dz 7,18**
 aż powstał nad Egiptem nowy król, który nic nie wiedział o Josefie.
###### **Dz 7,19**
 W okrutnych knowaniach człowiek ów zmuszał ojców naszych, aby porzucali swe nowo narodzone dzieci poza domem, aby nie przeżyły.
###### **Dz 7,20**
 Właśnie wtedy urodził się Mosze, a był piękny w oczach Bożych. Przez trzy miesiące chował się w domu ojca,
###### **Dz 7,21**
 a gdy go wyniesiono z domu, wzięła go córka faraona i wychowała jako własnego syna.
###### **Dz 7,22**
 Kształcił się więc Mosze we wszelkiej mądrości Egipcjan i stał się potężny zarówno w słowie, jak i w czynie.
###### **Dz 7,23**
 Lecz kiedy miał czterdzieści lat, przyszło mu do głowy, aby odwiedzić swoich braci Isra'elim.
###### **Dz 7,24**
 Widząc, jak znęcano się nad jednym z nich, stanął w jego obronie i pomścił go, zabijając Egipcjanina.
###### **Dz 7,25**
 Sądził, że bracia jego zrozumieją, iż Bóg używa go, aby ich ocalić, ale oni nie rozumieli.
###### **Dz 7,26**
 Gdy pojawił się następnego dnia, a oni bili się między sobą, i starał się ich pogodzić, mówiąc: "Ludzie, braćmi jesteście! Czemu chcecie krzywdzić jeden drugiego?",
###### **Dz 7,27**
 wtedy ten, który znęcał się nad swym towarzyszem, odepchnął Moszego i rzekł: "Kto cię ustanowił władcą czy sędzią nad nami?
###### **Dz 7,28**
 Chcesz mnie zabić, tak jak wczoraj tego Egipcjanina?".
###### **Dz 7,29**
 Słysząc to, Mosze uciekł z kraju i stał się wygnańcem w ziemi Midian, i miał tam dwóch synów.
###### **Dz 7,30**
 Po kolejnych czterdziestu latach objawił mu się anioł na pustyni koło góry Synaj w płomieniach gorejącego krzewu ciernistego.
###### **Dz 7,31**
 Ujrzawszy to, Mosze zdumiał się tym widokiem, a gdy się przybliżył, żeby się lepiej przypatrzyć, rozległ się głos Adonai:
###### **Dz 7,32**
 "Jam jest Bóg twoich ojców, Bóg Awrahama, Jic'chaka i Ja'akowa". Lecz Mosze trząsł się ze strachu i nie ośmielił się spojrzeć.
###### **Dz 7,33**
 Powiedział mu Adonai: "Ściągnij sandały, bo miejsce, na którym stoisz, jest ziemią świętą.
###### **Dz 7,34**
 Zobaczyłem wyraźnie, jak lud mój cierpi ucisk w Egipcie, usłyszałem ich krzyk i zstąpiłem, aby ich ocalić, a teraz posyłam cię do Egiptu".
###### **Dz 7,35**
 Ten Mosze, którego oni odrzucili, mówiąc: "Kto cię ustanowił władcą czy sędzią nad nami?", to ten sam, którego Bóg posłał i jako władcę, i jako odkupiciela za sprawą anioła, który objawił mu się w ciernistym krzewie.
###### **Dz 7,36**
 Człowiek ten wywiódł ich, dokonując znaków i cudów w Egipcie, nad Morzem Czerwonym i na pustyni przez czterdzieści lat.
###### **Dz 7,37**
 To ten Mosze, który powiedział ludowi Israela: "Bóg wzbudzi wam proroka jak ja spośród braci waszych".
###### **Dz 7,38**
 To ten człowiek, który był w zgromadzeniu na pustyni, a z nim anioł, który przemówił do niego na górze Synaj, i nasi ojcowie; człowiek, któremu dano żywe słowa, aby je nam przekazał.
###### **Dz 7,39**
 Lecz ojcowie nasi nie chcieli go słuchać. Przeciwnie, odrzucili go i w swych sercach zwrócili się ku Egiptowi,
###### **Dz 7,40**
 mówiąc do Aharona: "Uczyń nam jakichś bogów, aby nas prowadzili, bo ten Mosze, który nas wywiódł z Egiptu - nie wiemy, co też się z nim stało".
###### **Dz 7,41**
 Wtedy właśnie uczynili bożka w kształcie cielca i złożyli mu ofiarę, i urządzili uroczystości ku czci tego, co własnymi rękoma wykonali.
###### **Dz 7,42**
 Bóg więc odwrócił się od nich i wydał ich na pastwę kultu gwiazd - jak napisano w księdze proroków: "Ludu Isra'ela, to nie mnie składaliście zabite zwierzęta i ofiary przez czterdzieści lat na pustyni!
###### **Dz 7,43**
 Nie, nosiliście namiot Molecha i gwiazdę boga swego Reifana, bożków, jakich uczyniliście, aby móc ich wielbić. Dlatego poślę was na wygnanie za Bawel".
###### **Dz 7,44**
 Ojcowie nasi mieli Namiot Świadectwa na pustyni. Został on wykonany dokładnie tak, jak nakazał jego wykonanie Bóg, który przemówił do Moszego, według wzorca, jaki Mosze widział.
###### **Dz 7,45**
 Później ojcowie nasi, którzy go otrzymali, wnieśli go wraz z J'hoszuą, gdy odebrali Ziemię narodom, które Bóg przed nimi wypędził. Tak było aż do dni Dawida.
###### **Dz 7,46**
 Cieszył się on Bożą łaskawością i pytał, czy może przygotować mieszkanie Bogu Ja'akowa,
###### **Dz 7,47**
 a dom zbudował Mu Szlomo.
###### **Dz 7,48**
 Lecz Ha'Elion nie mieszka w miejscach ręką uczynionych! Jak powiada prorok:
###### **Dz 7,49**
 "Niebo jest tronem moim - mówi Adonai -a ziemia jest podnóżkiem moim. Jakiż to dom możecie mi zbudować? Jakież miejsce obmyślić dla mojego odpoczynku?
###### **Dz 7,50**
 Czyż ja sam nie uczyniłem tego wszystkiego?".
###### **Dz 7,51**
 Ludu o twardym karku, o sercach i uszach nieobrzezanych! Ciągle sprzeciwiacie się Ruach Ha-Kodesz! To samo robicie co wasi ojcowie!
###### **Dz 7,52**
 Których to proroków ojcowie wasi nie prześladowali? Zabijali tych, którzy zawczasu mówili o przyjściu Caddika, a dziś staliście się Jego zdrajcami i zabójcami!
###### **Dz 7,53**
 Wy, którzy uznajecie Torę za przekazaną przez aniołów - aleście jej nie przestrzegali!".
###### **Dz 7,54**
 Słysząc to, byli dotknięci do żywego i zgrzytali na niego zębami.
###### **Dz 7,55**
 Lecz on, pełen Ruach Ha-Kodesz, spojrzał w niebo i ujrzał Bożą Sz'chinę, wraz z Jeszuą stojącym po prawicy Boga.
###### **Dz 7,56**
 "Spójrzcie! - zawołał. - Widzę niebo otwarte i Syna Człowieczego stojącego po prawicy Boga!".
###### **Dz 7,57**
 Na te słowa zaczęli wrzeszczeć co sił w płucach, żeby go nie słyszeć, i zgodnie rzucili się na niego,
###### **Dz 7,58**
 wywlekli go za miasto i zaczęli kamienować. A świadkowie złożyli swoje płaszcze u stóp pewnego młodzieńca imieniem Sza'ul.
###### **Dz 7,59**
 Gdy go kamienowali, Szczepan zawołał do Boga: "Panie Jeszuo! Przyjmij mego ducha!".
###### **Dz 7,60**
 I ukląkł, i zawołał: "Panie! Nie poczytaj im tego grzechu!" I skonał;
# Dz 7 TRO
###### **Dz 7,1**
 **ειπεν** *eipen* Powiedział [[G2036]] WTV-2AAI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **αρχιερευς** *archiereus* arcykapłan [[G749]] [[N-NSM]] **ει** *ei* czy [[G1487]] WTCOND **αρα** *ara* zatem – mianowicie [[G687]] WTPRT-I **ταυτα** *tauta* te [[G5023]] WTD-NPN **ουτως** *houtōs* tak [[G3779]] [[ADV]] **εχει** *echei* ma się [[G2192]] WTV-PAI-3S
###### **Dz 7,2**
 **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **εφη** *efē* powiedział [[G5346]] [[V-IXI-3S]] **ανδρες** *andres* mężowie [[G435]] WTN-VPM **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **και** *kai* i [[G2532]] [[CONJ]] **πατερες** *pateres* ojcowie [[G3962]] WTN-VPM **ακουσατε** *akousate* posłuchajcie [[G191]] WTV-AAM-2P **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **της** *tēs* [[G3588]] [[T-GSF]] **δοξης** *doksēs* chwały [[G1391]] [[N-GSF]] **ωφθη** *ōfthē* został ukazany – został uczyniony widocznym [[G3700]] [[V-API-3S]] **τω** *tō* [[G3588]] WTT-DSM **πατρι** *patri* ojcu [[G3962]] WTN-DSM **ημων** *hēmōn* naszemu [[G2257]] WTP-1GP **αβρααμ** *abraam* Abrahamowi – [ojciec wielu narodów] [[G11]] [[N-PRI]] **οντι** *onti* będącemu [[G5607]] WTV-PXP-DSM **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **μεσοποταμια** *mesopotamia* Mezopotamii – pomiędzy rzekami [[G3318]] [[N-DSF]] **πριν** *prin* zanim – pierwej [[G4250]] [[ADV]] **η** *ē* niż [[G2228]] WTPRT **κατοικησαι** *katoikēsai* zamieszkać [[G2730]] [[V-AAN]] **αυτον** *auton* on [[G846]] WTP-ASM **εν** *en* w [[G1722]] [[PREP]] **χαρραν** *charran* Haranie – [spalony] [[G5488]] [[N-PRI]]
###### **Dz 7,3**
 **και** *kai* I [[G2532]] [[CONJ]] **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **προς** *pros* do [[G4314]] [[PREP]] **αυτον** *auton* niego [[G846]] WTP-ASM **εξελθε** *ekselthe* wyjdź [[G1831]] WTV-2AAM-2S **εκ** *ek* z [[G1537]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]] **σου** *sou* twojej [[G4675]] WTP-2GS **και** *kai* i [[G2532]] [[CONJ]] **εκ** *ek* z [[G1537]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **συγγενειας** *syngeneias* rodziny [[G4772]] [[N-GSF]] **σου** *sou* twojej [[G4675]] WTP-2GS **και** *kai* i [[G2532]] [[CONJ]] **δευρο** *deuro* przyjdź – chodź [[G1204]] WTV-XXM-2S **εις** *eis* do [[G1519]] [[PREP]] **γην** *gēn* ziemi [[G1093]] WTN-ASF **ην** *hēn* którą- [[G3739]] WTR-ASF **αν** *an* kolwiek [[G302]] WTPRT **σοι** *soi* ci [[G4671]] WTP-2DS **δειξω** *deiksō* pokażę [[G1166]] WTV-FAI-1S
###### **Dz 7,4**
 **τοτε** *tote* Wtedy [[G5119]] [[ADV]] **εξελθων** *ekselthōn* wyszedłszy [[G1831]] WTV-2AAP-NSM **εκ** *ek* z [[G1537]] [[PREP]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]] **χαλδαιων** *chaldaiōn* Chaldejczyków – [syn Nachora] [[G5466]] WTN-GPM **κατωκησεν** *katōkēsen* zamieszkał [[G2730]] [[V-AAI-3S]] **εν** *en* w [[G1722]] [[PREP]] **χαρραν** *charran* Haranie – [spalony] [[G5488]] [[N-PRI]] **κακειθεν** *kakeithen* a stamtąd [[G2547]] [[ADV]]-C **μετα** *meta* po [[G3326]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **αποθανειν** *apothanein* umrzeć [[G599]] [[V-2AAN]] **τον** *ton* [[G3588]] [[T-ASM]] **πατερα** *patera* ojciec [[G3962]] [[N-ASM]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **μετωκισεν** *metōkisen* przesiedlił [[G3351]] [[V-AAI-3S]] **αυτον** *auton* go [[G846]] WTP-ASM **εις** *eis* do [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **γην** *gēn* ziemi [[G1093]] WTN-ASF **ταυτην** *tautēn* tej [[G3778]] WTD-ASF **εις** *eis* na [[G1519]] [[PREP]] **ην** *hēn* której [[G3739]] WTR-ASF **υμεις** *hymeis* wy [[G5210]] WTP-2NP **νυν** *nyn* teraz [[G3568]] [[ADV]] **κατοικειτε** *katoikeite* zamieszkujecie [[G2730]] WTV-PAI-2P
###### **Dz 7,5**
 **και** *kai* I [[G2532]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εδωκεν** *edōken* dał [[G1325]] [[V-AAI-3S]] **αυτω** *autō* mu [[G846]] WTP-DSM **κληρονομιαν** *klēronomian* dziedziczenia [[G2817]] WTN-ASF **εν** *en* w [[G1722]] [[PREP]] **αυτη** *autē* niej [[G846]] WTP-DSF **ουδε** *oude* ani [[G3761]] [[ADV]] **βημα** *bēma* podstawy [[G968]] WTN-ASN **ποδος** *podos* stopy [[G4228]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **επηγγειλατο** *epēngeilato* obiecał [[G1861]] WTV-ADI-3S **αυτω** *autō* mu [[G846]] WTP-DSM **δουναι** *dounai* dać [[G1325]] [[V-2AAN]] **εις** *eis* na [[G1519]] [[PREP]] **κατασχεσιν** *kataschesin* posiadanie – nabycie [[G2697]] WTN-ASF **αυτην** *autēn* jej [[G846]] [[P-ASF]] **και** *kai* i [[G2532]] [[CONJ]] **τω** *tō* [[G3588]] WTT-DSN **σπερματι** *spermati* nasieniu [[G4690]] WTN-DSN **αυτου** *autou* jego [[G846]] [[P-GSM]] **μετ** *met* po [[G3326]] [[PREP]] **αυτον** *auton* nim [[G846]] WTP-ASM **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **οντος** *ontos* gdy jest [[G5607]] WTV-PXP-GSN **αυτω** *autō* mu [[G846]] WTP-DSM **τεκνου** *teknou* dziecko [[G5043]] [[N-GSN]]
###### **Dz 7,6**
 **ελαλησεν** *elalēsen* Powiedział [[G2980]] [[V-AAI-3S]] **δε** *de* zaś [[G1161]] [[CONJ]] **ουτως** *houtōs* tak [[G3779]] [[ADV]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **οτι** *hoti* że [[G3754]] [[CONJ]] **εσται** *estai* będzie [[G2071]] WTV-FXI-3S **το** *to* [[G3588]] WTT-NSN **σπερμα** *sperma* nasienie [[G4690]] WTN-NSN **αυτου** *autou* jego [[G846]] [[P-GSM]] **παροικον** *paroikon* przechodnie – mieszkający obok [[G3941]] WTA-NSN **εν** *en* w [[G1722]] [[PREP]] **γη** *gē* ziemi [[G1093]] [[N-DSF]] **αλλοτρια** *allotria* obcej – cudzej [[G245]] WTA-DSF **και** *kai* i [[G2532]] [[CONJ]] **δουλωσουσιν** *doulōsousin* uczynią niewolnikiem – zniewolą [[G1402]] WTV-FAI-3P **αυτο** *auto* je [[G846]] WTP-ASN **και** *kai* i [[G2532]] [[CONJ]] **κακωσουσιν** *kakōsousin* będą wyrządzać zło – będą krzywdzić [[G2559]] WTV-FAI-3P **ετη** *etē* lat [[G2094]] WTN-APN **τετρακοσια** *tetrakosia* czterysta [[G5071]] WTA-APN
###### **Dz 7,7**
 **και** *kai* I [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-ASN **εθνος** *ethnos* naród [[G1484]] WTN-ASN **ω** *hō* któremu [[G3739]] WTR-DSM **εαν** *ean* jeśli [[G1437]] WTCOND **δουλευσωσιν** *douleusōsin* zostaliby niewolnikami – służyliby [[G1398]] WTV-AAS-3P **κρινω** *krinō* osądzę [[G2919]] WTV-FAI-1S **εγω** *egō* ja [[G1473]] WTP-1NS **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **μετα** *meta* po [[G3326]] [[PREP]] **ταυτα** *tauta* tych [[G5023]] WTD-APN **εξελευσονται** *ekseleusontai* wyjdą [[G1831]] WTV-FDI-3P **και** *kai* i [[G2532]] [[CONJ]] **λατρευσουσιν** *latreusousin* będą służyć [[G3000]] WTV-FAI-3P **μοι** *moi* Mi [[G3427]] WTP-1DS **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **τοπω** *topō* miejscu [[G5117]] WTN-DSM **τουτω** *toutō* tym [[G5129]] WTD-DSM
###### **Dz 7,8**
 **και** *kai* I [[G2532]] [[CONJ]] **εδωκεν** *edōken* dał [[G1325]] [[V-AAI-3S]] **αυτω** *autō* mu [[G846]] WTP-DSM **διαθηκην** *diathēkēn* przymierze [[G1242]] WTN-ASF **περιτομης** *peritomēs* obrzezania [[G4061]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **ουτως** *houtōs* tak [[G3779]] [[ADV]] **εγεννησεν** *egennēsen* zrodził [[G1080]] [[V-AAI-3S]] **τον** *ton* [[G3588]] [[T-ASM]] **ισαακ** *isaak* Izaaka – [śmiać się] [[G2464]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **περιετεμεν** *perietemen* obrzezał [[G4059]] WTV-2AAI-3S **αυτον** *auton* go [[G846]] WTP-ASM **τη** *tē* [[G3588]] WTT-DSF **ημερα** *hēmera* dnia [[G2250]] [[N-DSF]] **τη** *tē* [[G3588]] WTT-DSF **ογδοη** *ogdoē* ósmego [[G3590]] WTA-DSF **και** *kai* a [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **ισαακ** *isaak* Izaak – [śmiać się] [[G2464]] [[N-PRI]] **τον** *ton* [[G3588]] [[T-ASM]] **ιακωβ** *iakōb* Jakuba – [pięta] [[G2384]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **ιακωβ** *iakōb* Jakub – [pięta] [[G2384]] [[N-PRI]] **τους** *tous* [[G3588]] WTT-APM **δωδεκα** *dōdeka* dwunastu [[G1427]] WTA-NUI **πατριαρχας** *patriarchas* patriarchów [[G3966]] [[N-APM]]
###### **Dz 7,9**
 **και** *kai* A [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **πατριαρχαι** *patriarchai* patriarchowie [[G3966]] WTN-NPM **ζηλωσαντες** *zēlōsantes* pozazdrościwszy – uczestnicząc we wspólnych zawodach [[G2206]] WTV-AAP-NPM **τον** *ton* [[G3588]] [[T-ASM]] **ιωσηφ** *iōsēf* Józefa – [On powiększył] [[G2501]] [[N-PRI]] **απεδοντο** *apedonto* oddali [[G591]] WTV-2AMI-3P **εις** *eis* do [[G1519]] [[PREP]] **αιγυπτον** *aigypton* Egiptu – [lud Nilu] [[G125]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **μετ** *met* z [[G3326]] [[PREP]] **αυτου** *autou* nim [[G846]] [[P-GSM]]
###### **Dz 7,10**
 **και** *kai* i [[G2532]] [[CONJ]] **εξειλετο** *ekseileto* wyrwał [[G1807]] WTV-2AMI-3S **αυτον** *auton* go [[G846]] WTP-ASM **εκ** *ek* z [[G1537]] [[PREP]] **πασων** *pasōn* wszystkich [[G3956]] WTA-GPF **των** *tōn* [[G3588]] WTT-GPF **θλιψεων** *thlipseōn* ucisków – utrapień [[G2347]] WTN-GPF **αυτου** *autou* jego [[G846]] [[P-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **εδωκεν** *edōken* dał [[G1325]] [[V-AAI-3S]] **αυτω** *autō* mu [[G846]] WTP-DSM **χαριν** *charin* łaskę [[G5485]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **σοφιαν** *sofian* mądrość [[G4678]] WTN-ASF **εναντιον** *enantion* wobec [[G1726]] [[ADV]] **φαραω** *faraō* faraona [[G5328]] [[N-PRI]] **βασιλεως** *basileōs* króla [[G935]] [[N-GSM]] **αιγυπτου** *aigyptou* Egiptu – [lud Nilu] [[G125]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **κατεστησεν** *katestēsen* ustanowił [[G2525]] [[V-AAI-3S]] **αυτον** *auton* go [[G846]] WTP-ASM **ηγουμενον** *hēgoumenon* przewodzącym – dowodzącym [[G2233]] WTV-PNP-ASM **επ** *ep* nad [[G1909]] [[PREP]] **αιγυπτον** *aigypton* Egiptem – [lud Nilu] [[G125]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **ολον** *holon* całym [[G3650]] WTA-ASM **τον** *ton* [[G3588]] [[T-ASM]] **οικον** *oikon* domem [[G3624]] [[N-ASM]] **αυτου** *autou* jego [[G846]] [[P-GSM]]
###### **Dz 7,11**
 **ηλθεν** *ēlthen* Przyszedł [[G2064]] WTV-2AAI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **λιμος** *limos* głód [[G3042]] [[N-NSM]] **εφ** *ef* nad [[G1909]] [[PREP]] **ολην** *holēn* całą [[G3650]] WTA-ASF **την** *tēn* [[G3588]] WTT-ASF **γην** *gēn* ziemią [[G1093]] WTN-ASF **αιγυπτου** *aigyptou* egipską – [lud Nilu] [[G125]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **χανααν** *chanaan* Kanaanem – [upokorzony] [[G5477]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **θλιψις** *thlipsis* ucisk – utrapienie [[G2347]] [[N-NSF]] **μεγαλη** *megalē* wielki [[G3173]] WTA-NSF **και** *kai* i [[G2532]] [[CONJ]] **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **ευρισκον** *heuriskon* znajdowali [[G2147]] WTV-IAI-3P **χορτασματα** *chortasmata* żywności [[G5527]] WTN-APN **οι** *hoi* [[G3588]] WTT-NPM **πατερες** *pateres* ojcowie [[G3962]] WTN-NPM **ημων** *hēmōn* nasi [[G2257]] WTP-1GP
###### **Dz 7,12**
 **ακουσας** *akousas* Usłyszawszy [[G191]] WTV-AAP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **ιακωβ** *iakōb* Jakub – [pięta] [[G2384]] [[N-PRI]] **οντα** *onta* (że) będące [[G5607]] WTV-PXP-APN **σιτα** *sita* zboża – pszenice [[G4621]] [[N-APM]] **εν** *en* w [[G1722]] [[PREP]] **αιγυπτω** *aigyptō* Egipcie – [lud Nilu] [[G125]] [[N-DSF]] **εξαπεστειλεν** *eksapesteilen* posłał [[G1821]] [[V-AAI-3S]] **τους** *tous* [[G3588]] WTT-APM **πατερας** *pateras* ojców [[G3962]] [[N-APM]] **ημων** *hēmōn* naszych [[G2257]] WTP-1GP **πρωτον** *prōton* najpierw [[G4412]] [[ADV]]
###### **Dz 7,13**
 **και** *kai* I [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **δευτερω** *deuterō* drugim [[G1208]] WTA-DSM **ανεγνωρισθη** *anegnōristhē* dał się poznać – został ujawnionym [[G319]] [[V-API-3S]] **ιωσηφ** *iōsēf* Józef – [On powiększył] [[G2501]] [[N-PRI]] **τοις** *tois* [[G3588]] WTT-DPM **αδελφοις** *adelfois* braciom [[G80]] WTN-DPM **αυτου** *autou* jego [[G846]] [[P-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **φανερον** *faneron* widoczny – jawny [[G5318]] WTA-NSN **εγενετο** *egeneto* stał się [[G1096]] WTV-2ADI-3S **τω** *tō* [[G3588]] WTT-DSM **φαραω** *faraō* faraonowi [[G5328]] [[N-PRI]] **το** *to* [[G3588]] WTT-NSN **γενος** *genos* ród [[G1085]] WTN-NSN **του** *tou* [[G3588]] WTT-GSM **ιωσηφ** *iōsēf* Józef – [On powiększył] [[G2501]] [[N-PRI]]
###### **Dz 7,14**
 **αποστειλας** *aposteilas* Wysławszy [[G649]] WTV-AAP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **ιωσηφ** *iōsēf* Józef – [On powiększył] [[G2501]] [[N-PRI]] **μετεκαλεσατο** *metekalesato* wezwał do siebie – przywołał do siebie [[G3333]] WTV-AMI-3S **τον** *ton* [[G3588]] [[T-ASM]] **πατερα** *patera* ojca [[G3962]] [[N-ASM]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **ιακωβ** *iakōb* Jakuba – [pięta] [[G2384]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **πασαν** *pasan* całą [[G3956]] WTA-ASF **την** *tēn* [[G3588]] WTT-ASF **συγγενειαν** *syngeneian* rodzinę [[G4772]] WTN-ASF **αυτου** *autou* jego [[G846]] [[P-GSM]] **εν** *en* w [[G1722]] [[PREP]] **ψυχαις** *psychais* duszach [[G5590]] WTN-DPF **εβδομηκοντα** *hebdomēkonta* siedemdziesięciu [[G1440]] WTA-NUI **πεντε** *pente* pięciu [[G4002]] WTA-NUI
###### **Dz 7,15**
 **κατεβη** *katebē* Zszedł – Zstąpił [[G2597]] WTV-2AAI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **ιακωβ** *iakōb* Jakub – [pięta] [[G2384]] [[N-PRI]] **εις** *eis* do [[G1519]] [[PREP]] **αιγυπτον** *aigypton* Egiptu – [lud Nilu] [[G125]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **ετελευτησεν** *eteleutēsen* umarł [[G5053]] [[V-AAI-3S]] **αυτος** *autos* on [[G846]] WTP-NSM **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **πατερες** *pateres* ojcowie [[G3962]] WTN-NPM **ημων** *hēmōn* nasi [[G2257]] WTP-1GP
###### **Dz 7,16**
 **και** *kai* i [[G2532]] [[CONJ]] **μετετεθησαν** *metetethēsan* zostali przeniesieni – zostali przemieszczeni [[G3346]] WTV-API-3P **εις** *eis* do [[G1519]] [[PREP]] **σιχεμ** *sichem* Sychem – [grzbiet] [[G4966]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **ετεθησαν** *etethēsan* zostali położeni – zostali umieszczeni [[G5087]] WTV-API-3P **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **μνηματι** *mnēmati* grobowcu [[G3418]] WTN-DSN **ο** *ho* który [[G3739]] WTR-ASN **ωνησατο** *ōnēsato* kupił [[G5608]] WTV-ADI-3S **αβρααμ** *abraam* Abraham – [ojciec wielu narodów] [[G11]] [[N-PRI]] **τιμης** *timēs* (za) oszacowanie – (za) wartość [[G5092]] [[N-GSF]] **αργυριου** *argyriou* srebra [[G694]] [[N-GSN]] **παρα** *para* od [[G3844]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **υιων** *hyiōn* synów [[G5207]] WTN-GPM **εμορ** *emor* Hemora – [przepłukać] [[G1697]] [[N-PRI]] **του** *tou* [[G3588]] WTT-GSM **σιχεμ** *sichem* Sychemowego – [grzbiet] [[G4966]] [[N-PRI]]
###### **Dz 7,17**
 **καθως** *kathōs* Tak, jak [[G2531]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **ηγγιζεν** *ēngizen* zbliżał się – był blisko [[G1448]] WTV-IAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **χρονος** *chronos* czas [[G5550]] [[N-NSM]] **της** *tēs* [[G3588]] [[T-GSF]] **επαγγελιας** *epangelias* obietnicy [[G1860]] [[N-GSF]] **ης** *hēs* którą [[G3739]] [[R-GSF]] **ωμοσεν** *ōmosen* przysiągł [[G3660]] [[V-AAI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **τω** *tō* [[G3588]] WTT-DSM **αβρααμ** *abraam* Abrahamowi – [ojciec wielu narodów] [[G11]] [[N-PRI]] **ηυξησεν** *ēuksēsen* wzrósł [[G837]] [[V-AAI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **λαος** *laos* lud [[G2992]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **επληθυνθη** *eplēthynthē* został pomnożony [[G4129]] [[V-API-3S]] **εν** *en* w [[G1722]] [[PREP]] **αιγυπτω** *aigyptō* Egipcie – [lud Nilu] [[G125]] [[N-DSF]]
###### **Dz 7,18**
 **αχρις** *achris* aż do [[G891]] [[PREP]] **ου** *hou* którego [[G3739]] WTR-GSM **ανεστη** *anestē* powstał – podniósł się [[G450]] WTV-2AAI-3S **βασιλευς** *basileus* król [[G935]] [[N-NSM]] **ετερος** *heteros* inny [[G2087]] [[A-NSM]] **ος** *hos* który [[G3739]] WTR-NSM **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ηδει** *ēdei* poznał [[G1492]] WTV-LAI-3S **τον** *ton* [[G3588]] [[T-ASM]] **ιωσηφ** *iōsēf* Józefa – [On powiększył] [[G2501]] [[N-PRI]]
###### **Dz 7,19**
 **ουτος** *houtos* Ten [[G3778]] WTD-NSM **κατασοφισαμενος** *katasofisamenos* obszedłszy się podstępem – zacząwszy mędrkować na szkodę [[G2686]] WTV-ADP-NSM **το** *to* (z) [[G3588]] WTT-ASN **γενος** *genos* rodem [[G1085]] WTN-ASN **ημων** *hēmōn* naszym [[G2257]] WTP-1GP **εκακωσεν** *ekakōsen* wyrządził zło – skrzywdził [[G2559]] [[V-AAI-3S]] **τους** *tous* [[G3588]] WTT-APM **πατερας** *pateras* ojcom [[G3962]] [[N-APM]] **ημων** *hēmōn* naszym [[G2257]] WTP-1GP **του** *tou* (tak, że) [[G3588]] WTT-GSM **ποιειν** *poiein* czynić [[G4160]] WTV-PAN **εκθετα** *ektheta* wyrzuconymi [[G1570]] WTA-APN **τα** *ta* [[G3588]] WTT-APN **βρεφη** *brefē* niemowlęta [[G1025]] WTN-APN **αυτων** *autōn* ich [[G846]] WTP-GPM **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **μη** *mē* nie [[G3361]] [[PRT-N]] **ζωογονεισθαι** *zōogoneisthai* zachować przy życiu [[G2225]] WTV-PPN
###### **Dz 7,20**
 **εν** *en* W [[G1722]] [[PREP]] **ω** *hō* tej [[G3739]] WTR-DSM **καιρω** *kairō* porze [[G2540]] WTN-DSM **εγεννηθη** *egennēthē* został zrodzony [[G1080]] [[V-API-3S]] **μωσης** *mōsēs* Mojżesz – [wyciągnąć] [[G3475]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **αστειος** *asteios* miły – piękny [[G791]] [[A-NSM]] **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **ος** *hos* ten [[G3739]] WTR-NSM **ανετραφη** *anetrafē* został karmiony – został wychowywany [[G397]] WTV-2API-3S **μηνας** *mēnas* miesiące [[G3376]] [[N-APM]] **τρεις** *treis* trzy [[G5140]] WTA-APM **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **οικω** *oikō* domu [[G3624]] WTN-DSM **του** *tou* [[G3588]] WTT-GSM **πατρος** *patros* ojca [[G3962]] [[N-GSM]] **αυτου** *autou* jego [[G846]] [[P-GSM]]
###### **Dz 7,21**
 **εκτεθεντα** *ektethenta* Zostawszy wyrzuconym [[G1620]] WTV-APP-ASM **δε** *de* zaś [[G1161]] [[CONJ]] **αυτον** *auton* on [[G846]] WTP-ASM **ανειλετο** *aneileto* zabrała – podniosła [[G337]] WTV-2AMI-3S **αυτον** *auton* go [[G846]] WTP-ASM **η** *hē* [[G3588]] [[T-NSF]] **θυγατηρ** *thygatēr* córka [[G2364]] [[N-NSF]] **φαραω** *faraō* faraona [[G5328]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **ανεθρεψατο** *anethrepsato* wykarmiła – wychowała [[G397]] WTV-AMI-3S **αυτον** *auton* go [[G846]] WTP-ASM **εαυτη** *heautē* sobie [[G1438]] WTF-3DSF **εις** *eis* za [[G1519]] [[PREP]] **υιον** *hyion* syna [[G5207]] [[N-ASM]]
###### **Dz 7,22**
 **και** *kai* I [[G2532]] [[CONJ]] **επαιδευθη** *epaideuthē* został wychowany – został dyscyplinowany [[G3811]] [[V-API-3S]] **μωσης** *mōsēs* Mojżesz – [wyciągnąć] [[G3475]] [[N-NSM]] **παση** *pasē* całą [[G3956]] WTA-DSF **σοφια** *sofia* mądrością [[G4678]] [[N-DSF]] **αιγυπτιων** *aigyptiōn* Egipcjan [[G124]] WTA-GPM **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **δε** *de* zaś [[G1161]] [[CONJ]] **δυνατος** *dynatos* mocny [[G1415]] [[A-NSM]] **εν** *en* w [[G1722]] [[PREP]] **λογοις** *logois* słowach [[G3056]] WTN-DPM **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **εργοις** *ergois* czynach – dziełach [[G2041]] WTN-DPN
###### **Dz 7,23**
 **ως** *hōs* Jak [[G5613]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **επληρουτο** *eplērouto* został wypełniony [[G4137]] WTV-IPI-3S **αυτω** *autō* mu [[G846]] WTP-DSM **τεσσαρακονταετης** *tessarakontaetēs* czterdziestoletni [[G5063]] [[A-NSM]] **χρονος** *chronos* czas [[G5550]] [[N-NSM]] **ανεβη** *anebē* weszło – wstąpiło [[G305]] WTV-2AAI-3S **επι** *epi* do [[G1909]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **καρδιαν** *kardian* serca [[G2588]] WTN-ASF **αυτου** *autou* jego [[G846]] [[P-GSM]] **επισκεψασθαι** *episkepsasthai* odwiedzić – nawiedzić [[G1980]] WTV-ADN **τους** *tous* [[G3588]] WTT-APM **αδελφους** *adelfous* braci [[G80]] [[N-APM]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **τους** *tous* [[G3588]] WTT-APM **υιους** *hyious* synów [[G5207]] [[N-APM]] **ισραηλ** *israēl* Izraela – [ten, który walczył z Bogiem] [[G2474]] [[N-PRI]]
###### **Dz 7,24**
 **και** *kai* I [[G2532]] [[CONJ]] **ιδων** *idōn* zobaczywszy [[G1492]] WTV-2AAP-NSM **τινα** *tina* kogoś [[G5100]] WTX-ASM **αδικουμενον** *adikoumenon* doznającego niesprawiedliwości – który jest krzywdzony [[G91]] WTV-PPP-ASM **ημυνατο** *ēmynato* stanął w obronie – ujął się za [[G292]] WTV-ADI-3S **και** *kai* i [[G2532]] [[CONJ]] **εποιησεν** *epoiēsen* uczynił [[G4160]] [[V-AAI-3S]] **εκδικησιν** *ekdikēsin* pomstę [[G1557]] WTN-ASF **τω** *tō* [[G3588]] WTT-DSM **καταπονουμενω** *kataponoumenō* doznającemu udręczenia – doznającemu uznojenia [[G2669]] WTV-PPP-DSM **παταξας** *pataksas* uderzywszy – poraziwszy [[G3960]] WTV-AAP-NSM **τον** *ton* [[G3588]] [[T-ASM]] **αιγυπτιον** *aigyption* Egipcjanina [[G124]] WTA-ASM
###### **Dz 7,25**
 **ενομιζεν** *enomizen* Wnioskował – Sądził [[G3543]] WTV-IAI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **συνιεναι** *synienai* rozumieć – pojąć [[G4920]] WTV-PAN **τους** *tous* [[G3588]] WTT-APM **αδελφους** *adelfous* bracia [[G80]] [[N-APM]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **οτι** *hoti* że [[G3754]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **δια** *dia* przez [[G1223]] [[PREP]] **χειρος** *cheiros* rękę [[G5495]] [[N-GSF]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **διδωσιν** *didōsin* daje [[G1325]] WTV-PAI-3S **αυτοις** *autois* im [[G846]] WTP-DPM **σωτηριαν** *sōtērian* zbawienie – wyzwolenie [[G4991]] WTN-ASF **οι** *hoi* [[G3588]] WTT-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **συνηκαν** *synēkan* zrozumieli – pojęli [[G4920]] WTV-AAI-3P
###### **Dz 7,26**
 **τη** *tē* [[G3588]] WTT-DSF **δε** *de* zaś [[G1161]] [[CONJ]] **επιουση** *epiousē* następującemu [[G1966]] WTV-PXP-DSF **ημερα** *hēmera* dniowi [[G2250]] [[N-DSF]] **ωφθη** *ōfthē* został ukazany – został uczyniony widocznym [[G3700]] [[V-API-3S]] **αυτοις** *autois* im [[G846]] WTP-DPM **μαχομενοις** *machomenois* walczącym – sprzeczającym się [[G3164]] WTV-PNP-DPM **και** *kai* i [[G2532]] [[CONJ]] **συνηλασεν** *synēlasen* jednał [[G4900]] [[V-AAI-3S]] **αυτους** *autous* ich [[G846]] [[P-APM]] **εις** *eis* do [[G1519]] [[PREP]] **ειρηνην** *eirēnēn* pokoju [[G1515]] WTN-ASF **ειπων** *eipōn* powiedziawszy [[G2036]] WTV-2AAP-NSM **ανδρες** *andres* mężowie [[G435]] WTN-VPM **αδελφοι** *adelfoi* bracia [[G80]] WTN-NPM **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **υμεις** *hymeis* wy [[G5210]] WTP-2NP **ινα** *hina* po [[G2443]] [[CONJ]] **τι** *ti* co [[G5101]] WTI-ASN **αδικειτε** *adikeite* czynicie niesprawiedliwość – krzywdzicie [[G91]] WTV-PAI-2P **αλληλους** *allēlous* jeden drugiemu – sobie [[G240]] WTC-APM
###### **Dz 7,27**
 **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **αδικων** *adikōn* czyniący niesprawiedliwość – krzywdzący [[G91]] [[V-PAP-NSM]] **τον** *ton* [[G3588]] [[T-ASM]] **πλησιον** *plēsion* bliźniemu – tuż obok [[G4139]] [[ADV]] **απωσατο** *apōsato* odtrącił – odepchnął [[G683]] WTV-ADI-3S **αυτον** *auton* go [[G846]] WTP-ASM **ειπων** *eipōn* powiedziawszy [[G2036]] WTV-2AAP-NSM **τις** *tis* kto [[G5101]] WTI-NSM **σε** *se* cię [[G4571]] WTP-2AS **κατεστησεν** *katestēsen* ustanowił [[G2525]] [[V-AAI-3S]] **αρχοντα** *archonta* przywódcą – przełożonym [[G758]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **δικαστην** *dikastēn* sędzią [[G1348]] WTN-ASF **εφ** *ef* nad [[G1909]] [[PREP]] **ημας** *hēmas* nami [[G2248]] WTP-1AP
###### **Dz 7,28**
 **μη** *mē* Czy [[G3361]] [[PRT-N]] **ανελειν** *anelein* zabić – znieść [[G337]] [[V-2AAN]] **με** *me* mnie [[G3165]] WTP-1AS **συ** *sy* ty [[G4771]] WTP-2NS **θελεις** *theleis* chcesz [[G2309]] WTV-PAI-2S **ον** *hon* (w) który [[G3739]] WTR-ASM **τροπον** *tropon* sposób [[G5158]] [[N-ASM]] **ανειλες** *aneiles* zabiłeś – zniosłeś [[G337]] WTV-2AAI-2S **χθες** *chthes* wczoraj [[G5504]] [[ADV]] **τον** *ton* [[G3588]] [[T-ASM]] **αιγυπτιον** *aigyption* Egipcjanina [[G124]] WTA-ASM
###### **Dz 7,29**
 **εφυγεν** *efygen* Uciekł [[G5343]] WTV-2AAI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **μωσης** *mōsēs* Mojżesz – [wyciągnąć] [[G3475]] [[N-NSM]] **εν** *en* na [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **λογω** *logō* słowo [[G3056]] WTN-DSM **τουτω** *toutō* to [[G5129]] WTD-DSM **και** *kai* i [[G2532]] [[CONJ]] **εγενετο** *egeneto* stał się [[G1096]] WTV-2ADI-3S **παροικος** *paroikos* przechodniem – mieszkającym obok [[G3941]] [[A-NSM]] **εν** *en* w [[G1722]] [[PREP]] **γη** *gē* ziemi [[G1093]] [[N-DSF]] **μαδιαμ** *madiam* madiańskiej – [walka] [[G3099]] [[N-PRI]] **ου** *hou* gdzie [[G3757]] [[ADV]] **εγεννησεν** *egennēsen* zrodził [[G1080]] [[V-AAI-3S]] **υιους** *hyious* synów [[G5207]] [[N-APM]] **δυο** *dyo* dwóch [[G1417]] WTA-NUI
###### **Dz 7,30**
 **και** *kai* A [[G2532]] [[CONJ]] **πληρωθεντων** *plērōthentōn* gdy zostało wypełnione [[G4137]] WTV-APP-GPN **ετων** *etōn* lat [[G2094]] WTN-GPN **τεσσαρακοντα** *tessarakonta* czterdzieści [[G5062]] WTA-NUI **ωφθη** *ōfthē* został ukazany – został uczyniony widocznym [[G3700]] [[V-API-3S]] **αυτω** *autō* mu [[G846]] WTP-DSM **εν** *en* na [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **ερημω** *erēmō* pustkowiu [[G2048]] WTA-DSF **του** *tou* [[G3588]] WTT-GSN **ορους** *orous* góry [[G3735]] [[N-GSN]] **σινα** *sina* Synaj [[G4614]] [[N-PRI]] **αγγελος** *angelos* zwiastun [[G32]] [[N-NSM]] **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **εν** *en* w [[G1722]] [[PREP]] **φλογι** *flogi* płomieniu [[G5395]] [[N-DSF]] **πυρος** *pyros* ognia [[G4442]] [[N-GSN]] **βατου** *batou* krzaku cierniowego [[G942]] [[N-GSM]]
###### **Dz 7,31**
 **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **μωσης** *mōsēs* Mojżesz – [wyciągnąć] [[G3475]] [[N-NSM]] **ιδων** *idōn* zobaczywszy [[G1492]] WTV-2AAP-NSM **εθαυμασεν** *ethaumasen* zdziwił się [[G2296]] [[V-AAI-3S]] **το** *to* [[G3588]] WTT-ASN **οραμα** *horama* widzeniu – wizji [[G3705]] WTN-ASN **προσερχομενου** *proserchomenou* gdy podchodzi – gdy zbliża się [[G4334]] WTV-PNP-GSM **δε** *de* zaś [[G1161]] [[CONJ]] **αυτου** *autou* on [[G846]] [[P-GSM]] **κατανοησαι** *katanoēsai* przyjrzeć się [[G2657]] [[V-AAN]] **εγενετο** *egeneto* stał się [[G1096]] WTV-2ADI-3S **φωνη** *fōnē* głos [[G5456]] [[N-NSF]] **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **προς** *pros* do [[G4314]] [[PREP]] **αυτον** *auton* niego [[G846]] WTP-ASM
###### **Dz 7,32**
 **εγω** *egō* Ja [[G1473]] WTP-1NS **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **των** *tōn* [[G3588]] WTT-GPM **πατερων** *paterōn* ojców [[G3962]] WTN-GPM **σου** *sou* twoich [[G4675]] WTP-2GS **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **αβρααμ** *abraam* Abrahama – [ojciec wielu narodów] [[G11]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ισαακ** *isaak* Izaaka – [śmiać się] [[G2464]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ιακωβ** *iakōb* Jakuba – [pięta] [[G2384]] [[N-PRI]] **εντρομος** *entromos* drżący [[G1790]] [[A-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **γενομενος** *genomenos* który stał się [[G1096]] WTV-2ADP-NSM **μωσης** *mōsēs* Mojżesz – [wyciągnąć] [[G3475]] [[N-NSM]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ετολμα** *etolma* ośmielał się – odważał się [[G5111]] WTV-IAI-3S **κατανοησαι** *katanoēsai* przyjrzeć się [[G2657]] [[V-AAN]]
###### **Dz 7,33**
 **ειπεν** *eipen* Powiedział [[G2036]] WTV-2AAI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **αυτω** *autō* mu [[G846]] WTP-DSM **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **λυσον** *lyson* rozwiąż [[G3089]] WTV-AAM-2S **το** *to* [[G3588]] WTT-ASN **υποδημα** *hypodēma* sandał [[G5266]] WTN-ASN **των** *tōn* [[G3588]] WTT-GPM **ποδων** *podōn* stóp [[G4228]] WTN-GPM **σου** *sou* twoich [[G4675]] WTP-2GS **ο** *ho* [[G3588]] [[T-NSM]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **τοπος** *topos* miejsce [[G5117]] [[N-NSM]] **εν** *en* na [[G1722]] [[PREP]] **ω** *hō* którym [[G3739]] WTR-DSM **εστηκας** *hestēkas* stanąłeś [[G2476]] WTV-RAI-2S **γη** *gē* ziemia [[G1093]] [[N-NSF]] **αγια** *hagia* święta [[G40]] WTA-NSF **εστιν** *estin* jest [[G2076]] WTV-PXI-3S
###### **Dz 7,34**
 **ιδων** *idōn* Zobaczywszy [[G1492]] WTV-2AAP-NSM **ειδον** *eidon* zobaczyłem [[G1492]] WTV-2AAI-1S **την** *tēn* [[G3588]] WTT-ASF **κακωσιν** *kakōsin* złe traktowanie – krzywdę [[G2561]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **λαου** *laou* ludu [[G2992]] [[N-GSM]] **μου** *mou* mojego [[G3450]] WTP-1GS **του** *tou* [[G3588]] WTT-GSM **εν** *en* w [[G1722]] [[PREP]] **αιγυπτω** *aigyptō* Egipcie – [lud Nilu] [[G125]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **του** *tou* [[G3588]] WTT-GSM **στεναγμου** *stenagmou* wzdychanie – westchnienie [[G4726]] [[N-GSM]] **αυτων** *autōn* ich [[G846]] WTP-GPM **ηκουσα** *ēkousa* usłyszałem [[G191]] WTV-AAI-1S **και** *kai* i [[G2532]] [[CONJ]] **κατεβην** *katebēn* zszedłem – zstąpiłem [[G2597]] WTV-2AAI-1S **εξελεσθαι** *ekselesthai* wyrwać [[G1807]] WTV-2AMN **αυτους** *autous* ich [[G846]] [[P-APM]] **και** *kai* a [[G2532]] [[CONJ]] **νυν** *nyn* teraz [[G3568]] [[ADV]] **δευρο** *deuro* przyjdź – chodź [[G1204]] WTV-XXM-2S **αποστελω** *apostelō* wyślę [[G649]] WTV-FAI-1S **σε** *se* cię [[G4571]] WTP-2AS **εις** *eis* do [[G1519]] [[PREP]] **αιγυπτον** *aigypton* Egiptu – [lud Nilu] [[G125]] WTN-ASF
###### **Dz 7,35**
 **τουτον** *touton* Tego [[G5126]] WTD-ASM **τον** *ton* [[G3588]] [[T-ASM]] **μωυσην** *mōusēn* Mojżesza – [wyciągnąć] [[G3475]] [[N-ASM]] **ον** *hon* którego [[G3739]] WTR-ASM **ηρνησαντο** *ērnēsanto* wyparli się – odrzucili [[G720]] WTV-ADI-3P **ειποντες** *eipontes* powiedziawszy [[G2036]] WTV-2AAP-NPM **τις** *tis* kto [[G5101]] WTI-NSM **σε** *se* cię [[G4571]] WTP-2AS **κατεστησεν** *katestēsen* ustanowił [[G2525]] [[V-AAI-3S]] **αρχοντα** *archonta* przywódcą – przełożonym [[G758]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **δικαστην** *dikastēn* sędzią [[G1348]] WTN-ASF **τουτον** *touton* tego [[G5126]] WTD-ASM **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **αρχοντα** *archonta* przywódcę – przełożonego [[G758]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **λυτρωτην** *lytrōtēn* odkupiciela – wyzwoliciela [[G3086]] [[N-ASM]] **απεστειλεν** *apesteilen* wysłał [[G649]] [[V-AAI-3S]] **εν** *en* przez [[G1722]] [[PREP]] **χειρι** *cheiri* rękę [[G5495]] [[N-DSF]] **αγγελου** *angelou* zwiastuna [[G32]] [[N-GSM]] **του** *tou* [[G3588]] WTT-GSM **οφθεντος** *ofthentos* który został ukazany – który został uczyniony widocznym [[G3700]] WTV-APP-GSM **αυτω** *autō* mu [[G846]] WTP-DSM **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **βατω** *batō* krzaku cierniowym [[G942]] WTN-DSM
###### **Dz 7,36**
 **ουτος** *houtos* Ten [[G3778]] WTD-NSM **εξηγαγεν** *eksēgagen* wyprowadził [[G1806]] WTV-2AAI-3S **αυτους** *autous* ich [[G846]] [[P-APM]] **ποιησας** *poiēsas* uczyniwszy [[G4160]] WTV-AAP-NSM **τερατα** *terata* cuda [[G5059]] WTN-APN **και** *kai* i [[G2532]] [[CONJ]] **σημεια** *sēmeia* znaki [[G4592]] WTN-APN **εν** *en* w [[G1722]] [[PREP]] **γη** *gē* ziemi [[G1093]] [[N-DSF]] **αιγυπτου** *aigyptou* egipskiej – [lud Nilu] [[G125]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **ερυθρα** *erythra* Czerwonym [[G2063]] WTA-DSF **θαλασση** *thalassē* Morzu [[G2281]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **ερημω** *erēmō* pustkowiu [[G2048]] WTA-DSF **ετη** *etē* lat [[G2094]] WTN-NPN **τεσσαρακοντα** *tessarakonta* czterdzieści [[G5062]] WTA-NUI
###### **Dz 7,37**
 **ουτος** *houtos* Ten [[G3778]] WTD-NSM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ο** *ho* [[G3588]] [[T-NSM]] **μωυσης** *mōusēs* Mojżesz – [wyciągnąć] [[G3475]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **ειπων** *eipōn* który powiedział [[G2036]] WTV-2AAP-NSM **τοις** *tois* [[G3588]] WTT-DPM **υιοις** *hyiois* synom [[G5207]] WTN-DPM **ισραηλ** *israēl* Izraela – [ten, który walczył z Bogiem] [[G2474]] [[N-PRI]] **προφητην** *profētēn* proroka [[G4396]] [[N-ASM]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **αναστησει** *anastēsei* wzbudzi – podniesie [[G450]] WTV-FAI-3S **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **υμων** *hymōn* wasz [[G5216]] WTP-2GP **εκ** *ek* z [[G1537]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **αδελφων** *adelfōn* braci [[G80]] WTN-GPM **υμων** *hymōn* waszych [[G5216]] WTP-2GP **ως** *hōs* jak [[G5613]] [[ADV]] **εμε** *eme* mnie [[G1691]] WTP-1AS **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ακουσεσθε** *akousesthe* będziecie słuchać [[G191]] WTV-FDI-2P
###### **Dz 7,38**
 **ουτος** *houtos* Ten [[G3778]] WTD-NSM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ο** *ho* [[G3588]] [[T-NSM]] **γενομενος** *genomenos* który stał się [[G1096]] WTV-2ADP-NSM **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **εκκλησια** *ekklēsia* zgromadzeniu – (społeczności) wywołanych [[G1577]] [[N-DSF]] **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **ερημω** *erēmō* pustkowiu [[G2048]] WTA-DSF **μετα** *meta* ze [[G3326]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **αγγελου** *angelou* zwiastunem [[G32]] [[N-GSM]] **του** *tou* [[G3588]] WTT-GSM **λαλουντος** *lalountos* mówiący [[G2980]] WTV-PAP-GSM **αυτω** *autō* mu [[G846]] WTP-DSM **εν** *en* na [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **ορει** *orei* górze [[G3735]] WTN-DSN **σινα** *sina* Synaj [[G4614]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPM **πατερων** *paterōn* ojcami [[G3962]] WTN-GPM **ημων** *hēmōn* naszymi [[G2257]] WTP-1GP **ος** *hos* który [[G3739]] WTR-NSM **εδεξατο** *edeksato* otrzymał – przyjął [[G1209]] WTV-ADI-3S **λογια** *logia* słów – wypowiedzi [[G3051]] WTN-APN **ζωντα** *zōnta* żyjących [[G2198]] WTV-PAP-APN **δουναι** *dounai* dać [[G1325]] [[V-2AAN]] **ημιν** *hēmin* nam [[G2254]] WTP-1DP
###### **Dz 7,39**
 **ω** *hō* któremu [[G3739]] WTR-DSM **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ηθελησαν** *ēthelēsan* chcieli [[G2309]] WTV-AAI-3P **υπηκοοι** *hypēkooi* posłuszni [[G5255]] WTA-NPM **γενεσθαι** *genesthai* stać się [[G1096]] WTV-2ADN **οι** *hoi* [[G3588]] WTT-NPM **πατερες** *pateres* ojcowie [[G3962]] WTN-NPM **ημων** *hēmōn* nasi [[G2257]] WTP-1GP **αλλ** *all* ale [[G235]] [[CONJ]] **απωσαντο** *apōsanto* odtrącili – odepchnęli [[G683]] WTV-ADI-3P **και** *kai* i [[G2532]] [[CONJ]] **εστραφησαν** *estrafēsan* zawrócili – zostali odwróceni [[G4762]] WTV-2API-3P **ταις** *tais* [[G3588]] WTT-DPF **καρδιαις** *kardiais* sercami [[G2588]] WTN-DPF **αυτων** *autōn* ich [[G846]] WTP-GPM **εις** *eis* do [[G1519]] [[PREP]] **αιγυπτον** *aigypton* Egiptu – [lud Nilu] [[G125]] WTN-ASF
###### **Dz 7,40**
 **ειποντες** *eipontes* powiedziawszy [[G2036]] WTV-2AAP-NPM **τω** *tō* [[G3588]] WTT-DSM **ααρων** *aarōn* Aaronowi – [wywyższony] [[G2]] [[N-PRI]] **ποιησον** *poiēson* uczyń [[G4160]] WTV-AAM-2S **ημιν** *hēmin* nam [[G2254]] WTP-1DP **θεους** *theous* bogów [[G2316]] [[N-APM]] **οι** *hoi* którzy [[G3739]] WTR-NPM **προπορευσονται** *proporeusontai* poprzedzą – będą szli przed [[G4313]] WTV-FDI-3P **ημων** *hēmōn* nas [[G2257]] WTP-1GP **ο** *ho* [[G3588]] [[T-NSM]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **μωσης** *mōsēs* Mojżesz – [wyciągnąć] [[G3475]] [[N-NSM]] **ουτος** *houtos* ten [[G3778]] WTD-NSM **ος** *hos* który [[G3739]] WTR-NSM **εξηγαγεν** *eksēgagen* wyprowadził [[G1806]] WTV-2AAI-3S **ημας** *hēmas* nas [[G2248]] WTP-1AP **εκ** *ek* z [[G1537]] [[PREP]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]] **αιγυπτου** *aigyptou* egipskiej – [lud Nilu] [[G125]] [[N-GSF]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **οιδαμεν** *oidamen* wiemy [[G1492]] WTV-RAI-1P **τι** *ti* co [[G5101]] WTI-NSN **γεγονεν** *gegonen* stało się [[G1096]] WTV-2RAI-3S **αυτω** *autō* jemu [[G846]] WTP-DSM
###### **Dz 7,41**
 **και** *kai* i [[G2532]] [[CONJ]] **εμοσχοποιησαν** *emoschopoiēsan* uczynili cielca [[G3447]] WTV-AAI-3P **εν** *en* w [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **ημεραις** *hēmerais* dniach [[G2250]] WTN-DPF **εκειναις** *ekeinais* tych [[G1565]] WTD-DPF **και** *kai* i [[G2532]] [[CONJ]] **ανηγαγον** *anēgagon* zaprowadzili – zanieśli [[G321]] WTV-2AAI-3P-ATT **θυσιαν** *thysian* ofiarę [[G2378]] WTN-ASF **τω** *tō* [[G3588]] WTT-DSN **ειδωλω** *eidōlō* bożkowi – fałszywemu bogu [[G1497]] WTN-DSN **και** *kai* i [[G2532]] [[CONJ]] **ευφραινοντο** *eufrainonto* zostali rozweseleni – zostali ucieszeni [[G2165]] WTV-IPI-3P **εν** *en* w [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPN **εργοις** *ergois* czynach – dziełach [[G2041]] WTN-DPN **των** *tōn* [[G3588]] WTT-GPF **χειρων** *cheirōn* rąk [[G5495]] WTN-GPF **αυτων** *autōn* ich [[G846]] WTP-GPM
###### **Dz 7,42**
 **εστρεψεν** *estrepsen* Odwrócił się – Zwrócił [[G4762]] [[V-AAI-3S]] **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **παρεδωκεν** *paredōken* wydał [[G3860]] [[V-AAI-3S]] **αυτους** *autous* ich [[G846]] [[P-APM]] **λατρευειν** *latreuein* służyć [[G3000]] WTV-PAN **τη** *tē* [[G3588]] WTT-DSF **στρατια** *stratia* wojsku [[G4756]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSM **ουρανου** *ouranou* nieba [[G3772]] [[N-GSM]] **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **γεγραπται** *gegraptai* jest napisane [[G1125]] WTV-RPI-3S **εν** *en* w [[G1722]] [[PREP]] **βιβλω** *biblō* zwoju – księdze [[G976]] [[N-DSF]] **των** *tōn* [[G3588]] WTT-GPM **προφητων** *profētōn* proroków [[G4396]] WTN-GPM **μη** *mē* czy [[G3361]] [[PRT-N]] **σφαγια** *sfagia* zabijane – zarżnięte [[G4968]] WTN-APN **και** *kai* i [[G2532]] [[CONJ]] **θυσιας** *thysias* ofiary [[G2378]] WTN-APF **προσηνεγκατε** *prosēnegkate* przyprowadziliście – przynieśliście [[G4374]] WTV-AAI-2P **μοι** *moi* Mi [[G3427]] WTP-1DS **ετη** *etē* lat [[G2094]] WTN-APN **τεσσαρακοντα** *tessarakonta* czterdzieści [[G5062]] WTA-NUI **εν** *en* na [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **ερημω** *erēmō* pustkowiu [[G2048]] WTA-DSF **οικος** *oikos* dom [[G3624]] [[N-NSM]] **ισραηλ** *israēl* Izraela – [ten, który walczył z Bogiem] [[G2474]] [[N-PRI]]
###### **Dz 7,43**
 **και** *kai* I [[G2532]] [[CONJ]] **ανελαβετε** *anelabete* nosiliście [[G353]] WTV-2AAI-2P **την** *tēn* [[G3588]] WTT-ASF **σκηνην** *skēnēn* namiot – przybytek [[G4633]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **μολοχ** *moloch* Molocha – [król] [[G3434]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-ASN **αστρον** *astron* gwiazdę [[G798]] WTN-ASN **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **υμων** *hymōn* waszego [[G5216]] WTP-2GP **ρεμφαν** *remfan* Remfana [[G4481]] [[N-PRI]] **τους** *tous* [[G3588]] WTT-APM **τυπους** *typous* figury [[G5179]] [[N-APM]] **ους** *hous* które [[G3739]] WTR-APM **εποιησατε** *epoiēsate* uczyniliście [[G4160]] WTV-AAI-2P **προσκυνειν** *proskynein* oddawać cześć – kłaniać się [[G4352]] WTV-PAN **αυτοις** *autois* im [[G846]] WTP-DPM **και** *kai* i [[G2532]] [[CONJ]] **μετοικιω** *metoikiō* przesiedlę [[G3351]] WTV-FAI-1S-ATT **υμας** *hymas* was [[G5209]] WTP-2AP **επεκεινα** *epekeina* po tamtej stronie [[G1900]] [[ADV]] **βαβυλωνος** *babylōnos* Babilonu [[G897]] [[N-GSF]]
###### **Dz 7,44**
 **η** *hē* [[G3588]] [[T-NSF]] **σκηνη** *skēnē* Namiot – Przybytek [[G4633]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSN **μαρτυριου** *martyriou* świadectwa [[G3142]] [[N-GSN]] **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **τοις** *tois* [[G3588]] WTT-DPM **πατρασιν** *patrasin* ojcom [[G3962]] WTN-DPM **ημων** *hēmōn* naszym [[G2257]] WTP-1GP **εν** *en* na [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **ερημω** *erēmō* pustkowiu [[G2048]] WTA-DSF **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **διεταξατο** *dietaksato* zarządził – rozporządził [[G1299]] WTV-AMI-3S **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **λαλων** *lalōn* mówiący [[G2980]] [[V-PAP-NSM]] **τω** *tō* [[G3588]] WTT-DSM **μωση** *mōsē* Mojżeszowi – [wyciągnąć] [[G3475]] WTN-DSM **ποιησαι** *poiēsai* uczynić [[G4160]] [[V-AAN]] **αυτην** *autēn* go [[G846]] [[P-ASF]] **κατα** *kata* według [[G2596]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **τυπον** *typon* wzoru – typu [[G5179]] [[N-ASM]] **ον** *hon* który [[G3739]] WTR-ASM **εωρακει** *heōrakei* zobaczył [[G3708]] WTV-LAI-3S-ATT
###### **Dz 7,45**
 **ην** *hēn* który [[G3739]] WTR-ASF **και** *kai* i [[G2532]] [[CONJ]] **εισηγαγον** *eisēgagon* wprowadzili [[G1521]] WTV-2AAI-3P **διαδεξαμενοι** *diadeksamenoi* otrzymawszy kolejno – przejąwszy [[G1237]] WTV-ADP-NPM **οι** *hoi* [[G3588]] WTT-NPM **πατερες** *pateres* ojcowie [[G3962]] WTN-NPM **ημων** *hēmōn* nasi [[G2257]] WTP-1GP **μετα** *meta* z [[G3326]] [[PREP]] **ιησου** *iēsou* Jezusem – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **κατασχεσει** *kataschesei* nabyciu [[G2697]] [[N-DSF]] **των** *tōn* [[G3588]] WTT-GPN **εθνων** *ethnōn* pogan – narodów [[G1484]] WTN-GPN **ων** *hōn* których [[G3739]] WTR-GPN **εξωσεν** *eksōsen* wypędził – wypchnął [[G1856]] [[V-AAI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **απο** *apo* od [[G575]] [[PREP]] **προσωπου** *prosōpou* oblicza – twarzy [[G4383]] [[N-GSN]] **των** *tōn* [[G3588]] WTT-GPM **πατερων** *paterōn* ojców [[G3962]] WTN-GPM **ημων** *hēmōn* naszych [[G2257]] WTP-1GP **εως** *heōs* aż do [[G2193]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPF **ημερων** *hēmerōn* dni [[G2250]] WTN-GPF **δαβιδ** *dabid* Dawida – [umiłowany] [[G1138]] [[N-PRI]]
###### **Dz 7,46**
 **ος** *hos* Który [[G3739]] WTR-NSM **ευρεν** *heuren* znalazł [[G2147]] WTV-2AAI-3S **χαριν** *charin* łaskę [[G5485]] WTN-ASF **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Bogiem [[G2316]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **ητησατο** *ētēsato* poprosił [[G154]] WTV-AMI-3S **ευρειν** *heurein* znaleźć [[G2147]] [[V-2AAN]] **σκηνωμα** *skēnōma* namiot – osiedlenie [[G4638]] WTN-ASN **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **ιακωβ** *iakōb* Jakuba – [pięta] [[G2384]] [[N-PRI]]
###### **Dz 7,47**
 **σολομων** *solomōn* Salomon – [człowiek pokoju] [[G4672]] [[N-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **ωκοδομησεν** *ōkodomēsen* zbudował [[G3618]] [[V-AAI-3S]] **αυτω** *autō* Mu [[G846]] WTP-DSM **οικον** *oikon* dom [[G3624]] [[N-ASM]]
###### **Dz 7,48**
 **αλλ** *all* Ale [[G235]] [[CONJ]] **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **ο** *ho* [[G3588]] [[T-NSM]] **υψιστος** *hypsistos* Najwyższy [[G5310]] [[A-NSM]] **εν** *en* w [[G1722]] [[PREP]] **χειροποιητοις** *cheiropoiētois* ręką uczynionych [[G5499]] WTA-DPM **ναοις** *naois* świątyniach – przybytkach [[G3485]] WTN-DPM **κατοικει** *katoikei* zamieszkuje [[G2730]] WTV-PAI-3S **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **ο** *ho* [[G3588]] [[T-NSM]] **προφητης** *profētēs* prorok [[G4396]] [[N-NSM]] **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S
###### **Dz 7,49**
 **ο** *ho* [[G3588]] [[T-NSM]] **ουρανος** *ouranos* Niebo [[G3772]] [[N-NSM]] **μοι** *moi* Mi [[G3427]] WTP-1DS **θρονος** *thronos* tron [[G2362]] [[N-NSM]] **η** *hē* [[G3588]] [[T-NSF]] **δε** *de* zaś [[G1161]] [[CONJ]] **γη** *gē* ziemia [[G1093]] [[N-NSF]] **υποποδιον** *hypopodion* podnóżek [[G5286]] WTN-NSN **των** *tōn* [[G3588]] WTT-GPM **ποδων** *podōn* stóp [[G4228]] WTN-GPM **μου** *mou* moich [[G3450]] WTP-1GS **ποιον** *poion* jaki [[G4169]] WTI-ASM **οικον** *oikon* dom [[G3624]] [[N-ASM]] **οικοδομησετε** *oikodomēsete* zbudujecie [[G3618]] WTV-FAI-2P **μοι** *moi* Mi [[G3427]] WTP-1DS **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **η** *ē* lub [[G2228]] WTPRT **τις** *tis* które [[G5101]] WTI-NSM **τοπος** *topos* miejsce [[G5117]] [[N-NSM]] **της** *tēs* [[G3588]] [[T-GSF]] **καταπαυσεως** *katapauseōs* odpoczynku – odpocznienia [[G2663]] [[N-GSF]] **μου** *mou* mojego [[G3450]] WTP-1GS
###### **Dz 7,50**
 **ουχι** *ouchi* Czyż nie [[G3780]] WTPRT-I **η** *hē* [[G3588]] [[T-NSF]] **χειρ** *cheir* ręka [[G5495]] [[N-NSF]] **μου** *mou* moja [[G3450]] WTP-1GS **εποιησεν** *epoiēsen* uczyniła [[G4160]] [[V-AAI-3S]] **ταυτα** *tauta* te [[G5023]] WTD-APN **παντα** *panta* wszystkie [[G3956]] WTA-APN
###### **Dz 7,51**
 **σκληροτραχηλοι** *sklērotrachēloi* Twardego karku [[G4644]] WTA-VPM **και** *kai* i [[G2532]] [[CONJ]] **απεριτμητοι** *aperitmētoi* nieobrzezani [[G564]] WTA-VPM **τη** *tē* (na) [[G3588]] WTT-DSF **καρδια** *kardia* sercu [[G2588]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **τοις** *tois* [[G3588]] WTT-DPN **ωσιν** *ōsin* uszach [[G3775]] WTN-DPN **υμεις** *hymeis* wy [[G5210]] WTP-2NP **αει** *aei* zawsze [[G104]] [[ADV]] **τω** *tō* [[G3588]] WTT-DSN **πνευματι** *pneumati* Duchowi [[G4151]] WTN-DSN **τω** *tō* [[G3588]] WTT-DSN **αγιω** *hagiō* Świętemu [[G40]] WTA-DSN **αντιπιπτετε** *antipiptete* opieracie się – stawiacie opór [[G496]] WTV-PAI-2P **ως** *hōs* jak [[G5613]] [[ADV]] **οι** *hoi* [[G3588]] WTT-NPM **πατερες** *pateres* ojcowie [[G3962]] WTN-NPM **υμων** *hymōn* wasi [[G5216]] WTP-2GP **και** *kai* i [[G2532]] [[CONJ]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP
###### **Dz 7,52**
 **τινα** *tina* Którego [[G5101]] WTI-ASM **των** *tōn* (z) [[G3588]] WTT-GPM **προφητων** *profētōn* proroków [[G4396]] WTN-GPM **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εδιωξαν** *ediōksan* prześladowali – nastawali na [[G1377]] WTV-AAI-3P **οι** *hoi* [[G3588]] WTT-NPM **πατερες** *pateres* ojcowie [[G3962]] WTN-NPM **υμων** *hymōn* wasi [[G5216]] WTP-2GP **και** *kai* i [[G2532]] [[CONJ]] **απεκτειναν** *apekteinan* zabili [[G615]] WTV-AAI-3P **τους** *tous* (tych) [[G3588]] WTT-APM **προκαταγγειλαντας** *prokatangeilantas* którzy przepowiedzieli – którzy wcześniej ogłosili [[G4293]] WTV-AAP-APM **περι** *peri* o [[G4012]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **ελευσεως** *eleuseōs* przyjściu – nadejściu [[G1660]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **δικαιου** *dikaiou* Sprawiedliwego [[G1342]] WTA-GSM **ου** *hou* którego [[G3739]] WTR-GSM **νυν** *nyn* teraz [[G3568]] [[ADV]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **προδοται** *prodotai* zdrajcy [[G4273]] WTN-NPM **και** *kai* i [[G2532]] [[CONJ]] **φονεις** *foneis* mordercy [[G5406]] WTN-NPM **γεγενησθε** *gegenēsthe* jesteście postawieni [[G1096]] WTV-RPI-2P
###### **Dz 7,53**
 **οιτινες** *hoitines* którzy [[G3748]] WTR-NPM **ελαβετε** *elabete* otrzymaliście – wzięliście [[G2983]] WTV-2AAI-2P **τον** *ton* [[G3588]] [[T-ASM]] **νομον** *nomon* Prawo [[G3551]] [[N-ASM]] **εις** *eis* na [[G1519]] [[PREP]] **διαταγας** *diatagas* rozporządzenia [[G1296]] WTN-APF **αγγελων** *angelōn* zwiastunów [[G32]] WTN-GPM **και** *kai* i [[G2532]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εφυλαξατε** *efylaksate* strzegliście [[G5442]] WTV-AAI-2P
###### **Dz 7,54**
 **ακουοντες** *akouontes* Słysząc [[G191]] WTV-PAP-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **ταυτα** *tauta* te [[G5023]] WTD-APN **διεπριοντο** *dieprionto* byli rozpiłowani – byli przerzynani piłą [[G1282]] WTV-IPI-3P **ταις** *tais* (w) [[G3588]] WTT-DPF **καρδιαις** *kardiais* sercach [[G2588]] WTN-DPF **αυτων** *autōn* ich [[G846]] WTP-GPM **και** *kai* i [[G2532]] [[CONJ]] **εβρυχον** *ebrychon* zgrzytali [[G1031]] WTV-IAI-3P **τους** *tous* [[G3588]] WTT-APM **οδοντας** *odontas* zębami [[G3599]] [[N-APM]] **επ** *ep* na [[G1909]] [[PREP]] **αυτον** *auton* niego [[G846]] WTP-ASM
###### **Dz 7,55**
 **υπαρχων** *hyparchōn* Będąc [[G5225]] [[V-PAP-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **πληρης** *plērēs* pełen [[G4134]] [[A-NSM]] **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **αγιου** *hagiou* Świętego [[G40]] [[A-GSN]] **ατενισας** *atenisas* spojrzawszy wprost – skierowawszy wprost wzrok [[G816]] WTV-AAP-NSM **εις** *eis* do [[G1519]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **ουρανον** *ouranon* nieba [[G3772]] [[N-ASM]] **ειδεν** *eiden* zobaczył [[G1492]] WTV-2AAI-3S **δοξαν** *doksan* chwałę [[G1391]] WTN-ASF **θεου** *theou* Boga [[G2316]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]] **εστωτα** *hestōta* stojącego [[G2476]] WTV-RAP-ASM **εκ** *ek* z [[G1537]] [[PREP]] **δεξιων** *deksiōn* prawej strony – prawicy [[G1188]] WTA-GPM **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **Dz 7,56**
 **και** *kai* I [[G2532]] [[CONJ]] **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **θεωρω** *theōrō* widzę – oglądam [[G2334]] WTV-PAI-1S **τους** *tous* [[G3588]] WTT-APM **ουρανους** *ouranous* niebiosa [[G3772]] [[N-APM]] **ανεωγμενους** *aneōgmenous* które są otworzone [[G455]] WTV-RPP-APM **και** *kai* i [[G2532]] [[CONJ]] **τον** *ton* [[G3588]] [[T-ASM]] **υιον** *hyion* Syna [[G5207]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **ανθρωπου** *anthrōpou* człowieka [[G444]] [[N-GSM]] **εκ** *ek* z [[G1537]] [[PREP]] **δεξιων** *deksiōn* prawej strony – prawicy [[G1188]] WTA-GPM **εστωτα** *hestōta* stojącego [[G2476]] WTV-RAP-ASM **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **Dz 7,57**
 **κραξαντες** *kraksantes* Krzyknąwszy [[G2896]] WTV-AAP-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **φωνη** *fōnē* głosem [[G5456]] [[N-DSF]] **μεγαλη** *megalē* wielkim [[G3173]] WTA-DSF **συνεσχον** *syneschon* przycisnęli – objęli [[G4912]] WTV-2AAI-3P **τα** *ta* [[G3588]] WTT-APN **ωτα** *ōta* uszy [[G3775]] WTN-APN **αυτων** *autōn* ich [[G846]] WTP-GPM **και** *kai* i [[G2532]] [[CONJ]] **ωρμησαν** *hōrmēsan* ruszyli [[G3729]] WTV-AAI-3P **ομοθυμαδον** *homothymadon* jednomyślnie – jednogłośnie [[G3661]] [[ADV]] **επ** *ep* na [[G1909]] [[PREP]] **αυτον** *auton* niego [[G846]] WTP-ASM
###### **Dz 7,58**
 **και** *kai* I [[G2532]] [[CONJ]] **εκβαλοντες** *ekbalontes* wyrzuciwszy [[G1544]] WTV-2AAP-NPM **εξω** *eksō* na zewnątrz – poza [[G1854]] [[ADV]] **της** *tēs* [[G3588]] [[T-GSF]] **πολεως** *poleōs* miasta [[G4172]] [[N-GSF]] **ελιθοβολουν** *elithoboloun* kamienowali [[G3036]] WTV-IAI-3P **και** *kai* a [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **μαρτυρες** *martyres* świadkowie [[G3144]] WTN-NPM **απεθεντο** *apethento* odłożyli [[G659]] WTV-2AMI-3P **τα** *ta* [[G3588]] WTT-APN **ιματια** *himatia* szaty – płaszcze [[G2440]] WTN-APN **αυτων** *autōn* ich [[G846]] WTP-GPM **παρα** *para* przy [[G3844]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **ποδας** *podas* stopach [[G4228]] [[N-APM]] **νεανιου** *neaniou* młodzieńca [[G3494]] [[N-GSM]] **καλουμενου** *kaloumenou* który jest nazywany – który jest zwany [[G2564]] WTV-PPP-GSM **σαυλου** *saulou* Saulem – [zapytał] [[G4569]] [[N-GSM]]
###### **Dz 7,59**
 **και** *kai* I [[G2532]] [[CONJ]] **ελιθοβολουν** *elithoboloun* kamienowali [[G3036]] WTV-IAI-3P **τον** *ton* [[G3588]] [[T-ASM]] **στεφανον** *stefanon* Szczepana – [wieniec] [[G4736]] [[N-ASM]] **επικαλουμενον** *epikaloumenon* przywołującego [[G1941]] WTV-PMP-ASM **και** *kai* i [[G2532]] [[CONJ]] **λεγοντα** *legonta* mówiącego [[G3004]] WTV-PAP-ASM **κυριε** *kyrie* Panie [[G2962]] WTN-VSM **ιησου** *iēsou* Jezu – [JHWH jest zbawieniem] [[G2424]] WTN-VSM **δεξαι** *deksai* weź – przyjmij [[G1209]] WTV-ADM-2S **το** *to* [[G3588]] WTT-ASN **πνευμα** *pneuma* ducha [[G4151]] WTN-ASN **μου** *mou* mojego [[G3450]] WTP-1GS
###### **Dz 7,60**
 **θεις** *theis* Położywszy [[G5087]] WTV-2AAP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **γονατα** *gonata* kolana [[G1119]] WTN-APN **εκραξεν** *ekraksen* krzyknął [[G2896]] [[V-AAI-3S]] **φωνη** *fōnē* głosem [[G5456]] [[N-DSF]] **μεγαλη** *megalē* wielkim [[G3173]] WTA-DSF **κυριε** *kyrie* Panie [[G2962]] WTN-VSM **μη** *mē* nie [[G3361]] [[PRT-N]] **στησης** *stēsēs* postawiłbyś [[G2476]] WTV-AAS-2S **αυτοις** *autois* im [[G846]] WTP-DPM **την** *tēn* [[G3588]] WTT-ASF **αμαρτιαν** *hamartian* grzechu [[G266]] WTN-ASF **ταυτην** *tautēn* tego [[G3778]] WTD-ASF **και** *kai* i [[G2532]] [[CONJ]] **τουτο** *touto* to [[G5124]] WTD-ASN **ειπων** *eipōn* powiedziawszy [[G2036]] WTV-2AAP-NSM **εκοιμηθη** *ekoimēthē* został uśpiony [[G2837]] [[V-API-3S]]
