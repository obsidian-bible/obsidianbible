# Ap 8 BT5
###### **Ap 8,1**
 A gdy otworzył pieczęć siódmą, zapanowała w niebie cisza prawie na pół godziny.
###### **Ap 8,2**
 I ujrzałem siedmiu aniołów, którzy stoją przed Bogiem, a dano im siedem trąb.
###### **Ap 8,3**
 I przyszedł inny anioł, i stanął przy ołtarzu, trzymając złote naczynie na żar,i dano mu wiele kadzideł, aby złożył je w ofierzez modlitwami wszystkich świętych, na złoty ołtarz, który jest przed tronem.
###### **Ap 8,4**
 I wzniósł się dym kadzidełz modlitwami świętych – z ręki anioła przed Boga.
###### **Ap 8,5**
 Anioł zaś wziął naczynie na żar, napełnił je ogniem z ołtarzai zrzucił na ziemię, a nastąpiły gromy, głosy, błyskawice, trzęsienie ziemi.
###### **Ap 8,6**
 A siedmiu aniołów, mających siedem trąb, przygotowało się, aby zatrąbić.
###### **Ap 8,7**
 Pierwszy zatrąbił. A powstały grad i ogień – pomieszane z krwią, i spadły na ziemię. A spłonęła trzecia część ziemii spłonęła trzecia część drzew, i spłonęła wszystka trawa zielona.
###### **Ap 8,8**
 Drugi anioł zatrąbił:i jakby wielka góra zionąca ogniem została w mo-rze rzucona, a trzecia część morza stała się krwią
###### **Ap 8,9**
 i wyginęła w morzu trzecia część stworzeń– te, które mają dusze –i trzecia część okrętów uległa zniszczeniu.
###### **Ap 8,10**
 Trzeci anioł zatrąbił:i spadła z nieba wielka gwiazda, płonąca jak pochodnia, a spadła na trzecią część rzek i na źródła wód.
###### **Ap 8,11**
 A imię gwiazdy brzmi Piołun. I trzecia część wód stała się piołunem, i wielu ludzi pomarło od wód, bo stały się gorzkie.
###### **Ap 8,12**
 Czwarty anioł zatrąbił:i została rażona trzecia część słońcai trzecia część księżyca, i trzecia część gwiazd, tak iż zaćmiła się trzecia ich częśći dzień nie jaśniał w trzeciej swej części, i noc – podobnie.
###### **Ap 8,13**
 A ujrzałemi usłyszałem jednego orła lecącego przez środek nieba, jak mówił donośnym głosem:«***Biada, biada, biada mieszkańcom ziemiz powodu pozostałych głosów trąb trzech aniołów, którzy mają [jeszcze] trąbić!***»
# Ap 8 PAU
###### **Ap 8,1**
 Gdy Baranek otworzył siódmą pieczęć, w niebie nastała cisza na około pół godziny.
###### **Ap 8,2**
 I ujrzałem siedmiu aniołów stojących przed Bogiem, którym dano siedem trąb.
###### **Ap 8,3**
 Przybył też inny anioł i stanął przy ołtarzu, trzymając złotą kadzielnicę. Dano mu dużo kadzideł, aby razem z modlitwami wszystkich świętych ofiarował je na złotym ołtarzu, który jest przed tronem.
###### **Ap 8,4**
 A dym kadzideł z ręki anioła wzniósł się do Boga wraz z modlitwami świętych.
###### **Ap 8,5**
 Następnie anioł wziął kadzielnicę, napełnił ją ogniem z ołtarza i rzucił na ziemię. Wówczas zagrzmiały gromy, głosy, błyskawice i trzęsienie ziemi.
###### **Ap 8,6**
 Siedmiu aniołów, którzy mieli siedem trąb, przygotowywało się do trąbienia.
###### **Ap 8,7**
 Zatrąbił pierwszy. Na ziemię spadł grad i ogień zmieszany z krwią. Trzecia część ziemi została spalona, trzecia część drzew została spalona i wszelka trawa zielona została spalona.
###### **Ap 8,8**
 Zatrąbił drugi anioł. Do morza wrzucono jakby wielką górę płonącego ognia i trzecia część morza stała się krwią.
###### **Ap 8,9**
 Jedna trzecia stworzeń morskich zginęła i jedna trzecia statków uległa zniszczeniu.
###### **Ap 8,10**
 Zatrąbił trzeci anioł. Z nieba spadła wielka gwiazda świecąca jak pochodnia, która upadła na trzecią część rzek i na źródła wód.
###### **Ap 8,11**
 Gwiazdę nazwano „Piołun” i jedna trzecia wód zmieniła się w piołun, a wielu ludzi zmarło z powodu wód, które stały się gorzkie.
###### **Ap 8,12**
 Zatrąbił czwarty anioł. Zdruzgotano jedną trzecią słońca, jedną trzecią księżyca i jedną trzecią gwiazd, tak że trzecia ich część się zaćmiła, a dzień - podobnie jak noc - utracił jedną trzecią swego światła.
###### **Ap 8,13**
 Zobaczyłem też i usłyszałem orła lecącego środkiem nieba, który wołał potężnym głosem: „Biada! Biada! Biada mieszkańcom ziemi z powodu głosów trąby pozostałych trzech aniołów, którzy wkrótce zatrąbią!”.
# Ap 8 BP
###### **Ap 8,1**
 A gdy otworzył siódmą pieczęć, zapanowała w niebie cisza jakby na pół godziny.
###### **Ap 8,2**
 Potem ujrzałem siedmiu aniołów, którzy stoją przed Bogiem. Dano im siedem trąb.
###### **Ap 8,3**
 I przyszedł inny anioł, i stanął przy ołtarzu, mając złote naczynie na żar. I dano mu wiele kadzideł, aby złożył je w ofierze, jako modlitwy wszystkich świętych, na złotym ołtarzu, który jest przed tronem.
###### **Ap 8,4**
 I wzniósł się dym kadzideł, jako modlitwy świętych, z ręki anioła przed Bogiem.
###### **Ap 8,5**
 Anioł zaś wziął naczynie na żar, napełnił je ogniem z ołtarza i zrzucił na ziemię. I zahuczały gromy, zajaśniały błyskawice i zatrzęsła się ziemia.
###### **Ap 8,6**
 A siedmiu aniołów, mających siedem trąb, przygotowało się, aby zatrąbić.
###### **Ap 8,7**
 Pierwszy zatrąbił: a powstał grad i ogień - pomieszane z krwią - i spadły na ziemię. I spłonęła trzecia część ziemi, i spłonęła trzecia część drzew, i spłonęła wszystka trwa zielona.
###### **Ap 8,8**
 Drugi anioł zatrąbił: i jakby wielka góra płonąca ogniem została rzucona w morze, a trzecia część morza zamieniła się w krew
###### **Ap 8,9**
 i wyginęła w morzu trzecia część stworzeń - te, które są ożywione - i trzecia część okrętów uległa zniszczeniu.
###### **Ap 8,10**
 Trzeci anioł zatrąbił: i spadła z nieba wielka gwiazda, płonąca jak pochodnia, a spadła na trzecią część rzek i na źródła wód.
###### **Ap 8,11**
 A gwiazda nazywa się Piołun. I trzecia część wód zamieniła się w piołun, i wielu ludzi pomarło od wód, bo stały się gorzkie.
###### **Ap 8,12**
 Czwarty anioł zatrąbił: i została rażona trzecia część słońca i trzecia część księżyca, i trzecia część gwiazd, tak iż zaćmiła się trzecia ich część i dzień nie jaśniał w trzeciej swej części, i noc - podobnie.
###### **Ap 8,13**
 Potem ujrzałem i usłyszałem jednego orła lecącego przez środek nieba, mówiącego donośnym głosem: "Biada, biada, biada mieszkańcom ziemi z powodu głosów trąby trzech pozostałych aniołów, którzy mają [jeszcze] trąbić!"
# Ap 8 BR
###### **Ap 8,1**
 A kiedy [Baranek] otworzył siódmą pieczęć, zapanowała w niebie cisza na około pół godziny.
###### **Ap 8,2**
 Wtedy zobaczyłem siedmiu aniołów, którzy stali przed Bogiem. I wręczono im siedem trąb.
###### **Ap 8,3**
 A potem przyszedł jeszcze jeden anioł ze złotym naczyniem na żar ofiarny i stanął przy ołtarzu. Dano mu wiele kadzidła - symbol modlitwy wszystkich świętych - aby je złożył w ofierze na złotym ołtarzu, który jest przed tronem.
###### **Ap 8,4**
 I wzniósł się dym kadzidła, jakby modlitwy świętych, z rąk anioła do Boga.
###### **Ap 8,5**
 Potem wziął anioł owo naczynie na żar kadzidła, napełnił je rozpalonymi węglami z ołtarza. A kiedy wyrzucił [węgle] na ziemię, nastąpiły grzmoty, huk potężny, błyskawice i trzęsienie ziemi.
###### **Ap 8,6**
 W tym czasie siedmiu aniołów, mających siedem trąb, przygotowywało się do trąbienia.
###### **Ap 8,7**
 Kiedy zatrąbił pierwszy z nich, zaczął spadać na ziemię grad i ogień - pomieszane z krwią. Spłonęła trzecia część ziemi; spłonęła trzecia część drzew; spłonęła wszystka zielona trawa.
###### **Ap 8,8**
 A kiedy zatrąbił drugi anioł, wtedy została wyrzucona w morze jakby ogromna góra cała w płomieniach. I trzecia część morza zamieniła się w krew.
###### **Ap 8,9**
 Wyginęła w morzu trzecia część wszystkich stworzeń żyjących i uległa zagładzie trzecia część okrętów.
###### **Ap 8,10**
 A kiedy zatrąbił trzeci anioł, wtedy spadła z nieba wielka gwiazda, płonąca jak pochodnia. Spadła na trzecią część rzek i na źródła wód.
###### **Ap 8,11**
 Gwiazda nazywa się Piołun. Trzecia część wody zamieniła się natychmiast w piołun i wielu ludzi zmarło od tej wody, ponieważ była gorzka.
###### **Ap 8,12**
 A kiedy zatrąbił czwarty anioł, wtedy została jakby rażona czymś trzecia część słońca, trzecia część księżyca i trzecia część gwiazd. Zaćmiła się wskutek tego trzecia ich część; dzień stracił trzecią część swej jasności, a tak samo i noc.
###### **Ap 8,13**
 Potem widziałem i słyszałem orła lecącego przed środek nieba i oznajmiającego donośnym głosem: Biada, biada, biada mieszkańcom ziemi! Zabrzmią bowiem trąby jeszcze trzech aniołów, którzy mają trąbić.
# Ap 8 WUJ
###### **Ap 8,1**
 A gdy otworzył siódmą pieczęć, stało się milczenie na niebie, jakoby pół godziny.
###### **Ap 8,2**
 I widziałem siedm aniołów stojących przed oczyma Bożemi: a dano im siedm trąb.
###### **Ap 8,3**
 A drugi anioł przyszedł, stanął przed ołtarzem, mając kadziedlnicę złotą: i dano mu wiele kadzenia, aby oddał z modlitew wszech świętych na ołtarz złoty, który jest przed stolicą Bożą.
###### **Ap 8,4**
 I wstąpił dym kadzenia z modlitew świętych z ręki anioła przed Boga.
###### **Ap 8,5**
 I wziął anioł kadziedlnicę, i napełnił ją ogniem z ołtarza, i rzucił na ziemię: i stały się gromy i głosy, i łyskawice, i trzęsienie ziemie wielkie.
###### **Ap 8,6**
 A siedm aniołów, którzy mieli siedm trąb, nagotowali się, aby trąbili,
###### **Ap 8,7**
 I pierwszy anioł zatrąbił, i stał się grad i ogień zmieszane ze krwią, zrzucone jest na ziemię: trzecia część ziemie zgorzała, i trzecia część drzew zgorzała, i wszelka trawa zielona zgorzała.
###### **Ap 8,8**
 I wtóry anioł zatrąbił: a jakoby wielka góra ogniem pałająca, wrzucona jest w morze, i stała się krwią trzecia część morza:
###### **Ap 8,9**
 I pozdychała trzecia część stworzenia tego, co miało dusze w morzu, i trzecia część okrętów zginęła.
###### **Ap 8,10**
 I zatrąbił anioł trzeci, i spadła z nieba gwiazda wielka, gorająca jako pochodnia, i upadła na trzecią część rzek, i na źródła wód:
###### **Ap 8,11**
 A imię gwiazdy, nazywają Piołyn: i obróciła się trzecia część wód w piołyn: a wiele ludzi pomarło od wód, iż gorzkie się stały.
###### **Ap 8,12**
 I zatrąbił anioł czwarty, i zarażona jest trzecia część słońca, i trzecia część księżyca, i trzecia część gwiazd, tak iż się ich trzecia część zaćmiła, i trzecia część dnia nie świeciła, i nocy także.
###### **Ap 8,13**
 I widziałem, i słyszałem głos jednego orła lecącego przez pośród nieba, mówiącego głosem wielkim: Biada, biada, biada mieszkającym na ziemi: od innych głosów trzech aniołów, którzy zatrąbić mieli.
# Ap 8 STERN
###### **Ap 8,1**
 Kiedy Baranek złamał siódmą pieczęć, zapadła w niebie cisza - zdawało się, że na pół godziny.
###### **Ap 8,2**
 Potem ujrzałem siedmiu aniołów, którzy stoją przed Bogiem, i dano im siedem szofarów.
###### **Ap 8,3**
 Przyszedł inny anioł i stanął przy ołtarzu ze złotą kadzielnicą, i dano mu mnóstwo kadzidła, aby je dodał do modlitw całego ludu Bożego
###### **Ap 8,4**
 na złotym ołtarzu przed tronem. Dym kadzidła wzniósł się z ręki anioła w górę przed Boga wraz z modlitwami ludu Bożego.
###### **Ap 8,5**
 Wtedy anioł wziął kadzielnicę, napełnił ją ogniem z ołtarza i rzucił w dół na ziemię, i nastąpiły grzmoty, głosy, błyskawice i trzęsienie ziemi.
###### **Ap 8,6**
 A siedmiu aniołów z siedmioma szofarami szykowało się, aby w nie zadąć.
###### **Ap 8,7**
 Pierwszy zadął w swój szofar, i nadszedł grad i ogień zmieszany z krwią, i został rzucony na ziemię. Spłonęła jedna trzecia ziemi, jedna trzecia drzew i cała zielona trawa.
###### **Ap 8,8**
 Zadął w swój szofar drugi anioł, i coś przypominającego gigantyczną płonącą górę zostało ciśnięte w morze. Jedna trzecia morza zmieniła się w krew,
###### **Ap 8,9**
 jedna trzecia żywych stworzeń w morzu zginęła i jedna trzecia statków została zniszczona.
###### **Ap 8,10**
 Trzeci anioł zadął w swój szofar, i wielka gwiazda, płonąc jak pochodnia, spadła z nieba na jedną trzecią rzek i na źródła wód.
###### **Ap 8,11**
 Imię tej gwiazdy brzmiało "Gorycz", i jedna trzecia wody zrobiła się gorzka, a wielu ludzi zmarło od wody, która zrobiła się gorzka.
###### **Ap 8,12**
 Zadął w swój szofar czwarty anioł, i została porażona jedna trzecia słońca, a także jedna trzecia księżyca i jedna trzecia gwiazd, tak że jedna trzecia z nich ściemniała i dzień miał o jedną trzecią mniej światła, podobnie i noc.
###### **Ap 8,13**
 I spojrzałem, i usłyszałem głośny okrzyk samotnego orła, który leciał przez środek nieba: "Biada! Biada! Biada mieszkańcom ziemi z powodu pozostałych dźwięków rogu trzech aniołów, którzy mają jeszcze zadąć w swe szofary!".
# Ap 8 TRO
###### **Ap 8,1**
 **και** *kai* I [[G2532]] [[CONJ]] **οτε** *hote* kiedy [[G3753]] [[ADV]] **ηνοιξεν** *ēnoiksen* otworzył [[G455]] [[V-AAI-3S]] **την** *tēn* [[G3588]] WTT-ASF **σφραγιδα** *sfragida* pieczęć [[G4973]] WTN-ASF **την** *tēn* [[G3588]] WTT-ASF **εβδομην** *hebdomēn* siódmą [[G1442]] WTA-ASF **εγενετο** *egeneto* stała się [[G1096]] WTV-2ADI-3S **σιγη** *sigē* cisza – milczenie [[G4602]] [[N-NSF]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **ουρανω** *ouranō* niebie [[G3772]] WTN-DSM **ως** *hōs* jak [[G5613]] [[ADV]] **ημιωριον** *hēmiōrion* pół godziny [[G2256]] WTN-ASN
###### **Ap 8,2**
 **και** *kai* I [[G2532]] [[CONJ]] **ειδον** *eidon* zobaczyłem [[G1492]] WTV-2AAI-1S **τους** *tous* [[G3588]] WTT-APM **επτα** *hepta* siedmiu [[G2033]] WTA-NUI **αγγελους** *angelous* zwiastunów [[G32]] [[N-APM]] **οι** *hoi* którzy [[G3739]] WTR-NPM **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Bogiem [[G2316]] [[N-GSM]] **εστηκασιν** *hestēkasin* stali [[G2476]] WTV-RAI-3P **και** *kai* i [[G2532]] [[CONJ]] **εδοθησαν** *edothēsan* zostały dane [[G1325]] WTV-API-3P **αυτοις** *autois* im [[G846]] WTP-DPM **επτα** *hepta* siedem [[G2033]] WTA-NUI **σαλπιγγες** *salpinges* trąb [[G4536]] [[N-NPF]]
###### **Ap 8,3**
 **και** *kai* I [[G2532]] [[CONJ]] **αλλος** *allos* inny [[G243]] [[A-NSM]] **αγγελος** *angelos* zwiastun [[G32]] [[N-NSM]] **ηλθεν** *ēlthen* przyszedł [[G2064]] WTV-2AAI-3S **και** *kai* i [[G2532]] [[CONJ]] **εσταθη** *hestathē* został postawiony [[G2476]] [[V-API-3S]] **επι** *epi* przy [[G1909]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **θυσιαστηριον** *thysiastērion* ołtarzu [[G2379]] WTN-ASN **εχων** *echōn* mając [[G2192]] [[V-PAP-NSM]] **λιβανωτον** *libanōton* kadzielnicę [[G3031]] WTA-ASM **χρυσουν** *chrysoun* złotą [[G5552]] WTA-ASM **και** *kai* i [[G2532]] [[CONJ]] **εδοθη** *edothē* zostało dane [[G1325]] [[V-API-3S]] **αυτω** *autō* mu [[G846]] WTP-DSM **θυμιαματα** *thymiamata* kadzideł [[G2368]] WTN-NPN **πολλα** *polla* wiele [[G4183]] WTA-NPN **ινα** *hina* aby [[G2443]] [[CONJ]] **δωση** *dōsē* dałby [[G1325]] WTV-AAS-3S **ταις** *tais* [[G3588]] WTT-DPF **προσευχαις** *proseuchais* modlitwom [[G4335]] WTN-DPF **των** *tōn* [[G3588]] WTT-GPM **αγιων** *hagiōn* świętych [[G40]] WTA-GPM **παντων** *pantōn* wszystkich [[G3956]] WTA-GPM **επι** *epi* na [[G1909]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **θυσιαστηριον** *thysiastērion* ołtarz [[G2379]] WTN-ASN **το** *to* [[G3588]] WTT-ASN **χρυσουν** *chrysoun* złoty [[G5552]] WTA-ASN **το** *to* [[G3588]] WTT-ASN **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronem [[G2362]] [[N-GSM]]
###### **Ap 8,4**
 **και** *kai* I [[G2532]] [[CONJ]] **ανεβη** *anebē* wszedł – wstąpił [[G305]] WTV-2AAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **καπνος** *kapnos* dym [[G2586]] [[N-NSM]] **των** *tōn* [[G3588]] WTT-GPN **θυμιαματων** *thymiamatōn* kadzideł [[G2368]] WTN-GPN **ταις** *tais* [[G3588]] WTT-DPF **προσευχαις** *proseuchais* modlitw [[G4335]] WTN-DPF **των** *tōn* [[G3588]] WTT-GPM **αγιων** *hagiōn* świętych [[G40]] WTA-GPM **εκ** *ek* z [[G1537]] [[PREP]] **χειρος** *cheiros* ręki [[G5495]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **αγγελου** *angelou* zwiastuna [[G32]] [[N-GSM]] **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Bogiem [[G2316]] [[N-GSM]]
###### **Ap 8,5**
 **και** *kai* I [[G2532]] [[CONJ]] **ειληφεν** *eilēfen* wziął [[G2983]] WTV-RAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **αγγελος** *angelos* zwiastun [[G32]] [[N-NSM]] **το** *to* [[G3588]] WTT-ASN **λιβανωτον** *libanōton* kadzielnicę [[G3031]] WTA-ASM **και** *kai* i [[G2532]] [[CONJ]] **εγεμισεν** *egemisen* napełnił [[G1072]] [[V-AAI-3S]] **αυτο** *auto* ją [[G846]] WTP-ASN **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **πυρος** *pyros* ognia [[G4442]] [[N-GSN]] **του** *tou* [[G3588]] WTT-GSN **θυσιαστηριου** *thysiastēriou* ołtarza [[G2379]] [[N-GSN]] **και** *kai* i [[G2532]] [[CONJ]] **εβαλεν** *ebalen* rzucił [[G906]] WTV-2AAI-3S **εις** *eis* na [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **γην** *gēn* ziemię [[G1093]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **εγενοντο** *egenonto* stały się [[G1096]] WTV-2ADI-3P **φωναι** *fōnai* dźwięki – głosy [[G5456]] [[N-NPF]] **και** *kai* i [[G2532]] [[CONJ]] **βρονται** *brontai* grzmoty [[G1027]] [[N-NPF]] **και** *kai* i [[G2532]] [[CONJ]] **αστραπαι** *astrapai* błyskawice [[G796]] [[N-NPF]] **και** *kai* i [[G2532]] [[CONJ]] **σεισμος** *seismos* trzęsienie ziemi [[G4578]] [[N-NSM]]
###### **Ap 8,6**
 **και** *kai* I [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **επτα** *hepta* siedmiu [[G2033]] WTA-NUI **αγγελοι** *angeloi* zwiastunów [[G32]] WTN-NPM **οι** *hoi* [[G3588]] WTT-NPM **εχοντες** *echontes* mających [[G2192]] WTV-PAP-NPM **τας** *tas* [[G3588]] WTT-APF **επτα** *hepta* siedem [[G2033]] WTA-NUI **σαλπιγγας** *salpingas* trąb [[G4536]] WTN-APF **ητοιμασαν** *hētoimasan* przygotowali [[G2090]] WTV-AAI-3P **εαυτους** *heautous* siebie [[G1438]] WTF-3APM **ινα** *hina* aby [[G2443]] [[CONJ]] **σαλπισωσιν** *salpisōsin* zatrąbiliby [[G4537]] WTV-AAS-3P
###### **Ap 8,7**
 **και** *kai* I [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **πρωτος** *prōtos* pierwszy [[G4413]] [[A-NSM]] **αγγελος** *angelos* zwiastun [[G32]] [[N-NSM]] **εσαλπισεν** *esalpisen* zatrąbił [[G4537]] [[V-AAI-3S]] **και** *kai* i [[G2532]] [[CONJ]] **εγενετο** *egeneto* stał się [[G1096]] WTV-2ADI-3S **χαλαζα** *chalaza* grad [[G5464]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **πυρ** *pyr* ogień [[G4442]] WTN-NSN **μεμιγμενα** *memigmena* który jest zmieszany [[G3396]] WTV-RPP-NPN **αιματι** *haimati* krwią [[G129]] WTN-DSN **και** *kai* i [[G2532]] [[CONJ]] **εβληθη** *eblēthē* został rzucony [[G906]] [[V-API-3S]] **εις** *eis* na [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **γην** *gēn* ziemię [[G1093]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **τριτον** *triton* trzecia [[G5154]] WTA-NSN **των** *tōn* (część) [[G3588]] WTT-GPN **δενδρων** *dendrōn* drzew [[G1186]] WTN-GPN **κατεκαη** *katekaē* została spalona [[G2618]] WTV-2API-3S **και** *kai* i [[G2532]] [[CONJ]] **πας** *pas* cała [[G3956]] [[A-NSM]] **χορτος** *chortos* trawa [[G5528]] [[N-NSM]] **χλωρος** *chlōros* zielona [[G5515]] [[A-NSM]] **κατεκαη** *katekaē* została spalona [[G2618]] WTV-2API-3S
###### **Ap 8,8**
 **και** *kai* I [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **δευτερος** *deuteros* drugi [[G1208]] [[A-NSM]] **αγγελος** *angelos* zwiastun [[G32]] [[N-NSM]] **εσαλπισεν** *esalpisen* zatrąbił [[G4537]] [[V-AAI-3S]] **και** *kai* i [[G2532]] [[CONJ]] **ως** *hōs* jak [[G5613]] [[ADV]] **ορος** *oros* góra [[G3735]] WTN-NSN **μεγα** *mega* wielka [[G3173]] WTA-NSN **πυρι** *pyri* ogniem [[G4442]] WTN-DSN **καιομενον** *kaiomenon* która jest zapalona [[G2545]] WTV-PPP-NSN **εβληθη** *eblēthē* została rzucona [[G906]] [[V-API-3S]] **εις** *eis* w [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **θαλασσαν** *thalassan* morze [[G2281]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **εγενετο** *egeneto* stała się [[G1096]] WTV-2ADI-3S **το** *to* [[G3588]] WTT-NSN **τριτον** *triton* trzecia [[G5154]] WTA-NSN **της** *tēs* (część) [[G3588]] [[T-GSF]] **θαλασσης** *thalassēs* morza [[G2281]] [[N-GSF]] **αιμα** *haima* krew [[G129]] WTN-NSN
###### **Ap 8,9**
 **και** *kai* i [[G2532]] [[CONJ]] **απεθανεν** *apethanen* umarła [[G599]] WTV-2AAI-3S **το** *to* [[G3588]] WTT-NSN **τριτον** *triton* trzecia [[G5154]] WTA-NSN **των** *tōn* (część) [[G3588]] WTT-GPN **κτισματων** *ktismatōn* stworzeń [[G2938]] WTN-GPN **των** *tōn* [[G3588]] WTT-GPN **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **θαλασση** *thalassē* morzu [[G2281]] [[N-DSF]] **τα** *ta* [[G3588]] WTT-NPN **εχοντα** *echonta* mających [[G2192]] WTV-PAP-NPN **ψυχας** *psychas* dusze [[G5590]] WTN-APF **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **τριτον** *triton* trzecia [[G5154]] WTA-NSN **των** *tōn* (część) [[G3588]] WTT-GPN **πλοιων** *ploiōn* statków – łodzi [[G4143]] WTN-GPN **διεφθαρη** *dieftharē* została zniszczona [[G1311]] WTV-2API-3S
###### **Ap 8,10**
 **και** *kai* I [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **τριτος** *tritos* trzeci [[G5154]] [[A-NSM]] **αγγελος** *angelos* zwiastun [[G32]] [[N-NSM]] **εσαλπισεν** *esalpisen* zatrąbił [[G4537]] [[V-AAI-3S]] **και** *kai* i [[G2532]] [[CONJ]] **επεσεν** *epesen* spadła [[G4098]] WTV-2AAI-3S **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **ουρανου** *ouranou* nieba [[G3772]] [[N-GSM]] **αστηρ** *astēr* gwiazda [[G792]] [[N-NSM]] **μεγας** *megas* wielka [[G3173]] [[A-NSM]] **καιομενος** *kaiomenos* która jest zapalona [[G2545]] [[V-PPP-NSM]] **ως** *hōs* jak [[G5613]] [[ADV]] **λαμπας** *lampas* lampa [[G2985]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **επεσεν** *epesen* spadła [[G4098]] WTV-2AAI-3S **επι** *epi* na [[G1909]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **τριτον** *triton* trzecią [[G5154]] WTA-ASN **των** *tōn* (część) [[G3588]] WTT-GPM **ποταμων** *potamōn* rzek [[G4215]] WTN-GPM **και** *kai* i [[G2532]] [[CONJ]] **επι** *epi* na [[G1909]] [[PREP]] **τας** *tas* [[G3588]] WTT-APF **πηγας** *pēgas* źródła [[G4077]] WTN-APF **υδατων** *hydatōn* wód [[G5204]] WTN-GPN
###### **Ap 8,11**
 **και** *kai* I [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **ονομα** *onoma* imię [[G3686]] WTN-NSN **του** *tou* [[G3588]] WTT-GSM **αστερος** *asteros* gwiazdy [[G792]] [[N-GSM]] **λεγεται** *legetai* jest nazywane [[G3004]] WTV-PPI-3S **αψινθος** *apsinthos* piołun [[G894]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **γινεται** *ginetai* staje się [[G1096]] WTV-PNI-3S **το** *to* [[G3588]] WTT-NSN **τριτον** *triton* trzecia [[G5154]] WTA-NSN **των** *tōn* (część) [[G3588]] WTT-GPN **υδατων** *hydatōn* wód [[G5204]] WTN-GPN **εις** *eis* w [[G1519]] [[PREP]] **αψινθον** *apsinthon* piołunie [[G894]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **πολλοι** *polloi* liczni – wielu [[G4183]] WTA-NPM **ανθρωπων** *anthrōpōn* (z) ludzi [[G444]] WTN-GPM **απεθανον** *apethanon* umarli [[G599]] WTV-2AAI-3P **εκ** *ek* od [[G1537]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **υδατων** *hydatōn* wód [[G5204]] WTN-GPN **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **επικρανθησαν** *epikranthēsan* zostały uczynione gorzkimi [[G4087]] WTV-API-3P
###### **Ap 8,12**
 **και** *kai* I [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **τεταρτος** *tetartos* czwarty [[G5067]] [[A-NSM]] **αγγελος** *angelos* zwiastun [[G32]] [[N-NSM]] **εσαλπισεν** *esalpisen* zatrąbił [[G4537]] [[V-AAI-3S]] **και** *kai* i [[G2532]] [[CONJ]] **επληγη** *eplēgē* została uderzona [[G4141]] WTV-2API-3S **το** *to* [[G3588]] WTT-NSN **τριτον** *triton* trzecia [[G5154]] WTA-NSN **του** *tou* (część) [[G3588]] WTT-GSM **ηλιου** *hēliou* słońca [[G2246]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **τριτον** *triton* trzecia [[G5154]] WTA-NSN **της** *tēs* (część) [[G3588]] [[T-GSF]] **σεληνης** *selēnēs* księżyca [[G4582]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **τριτον** *triton* trzecia [[G5154]] WTA-NSN **των** *tōn* (część) [[G3588]] WTT-GPM **αστερων** *asterōn* gwiazd [[G792]] WTN-GPM **ινα** *hina* aby [[G2443]] [[CONJ]] **σκοτισθη** *skotisthē* zostałaby zaćmiona – zostałaby pogrążona w ciemności [[G4654]] WTV-APS-3S **το** *to* (część) [[G3588]] WTT-NSN **τριτον** *triton* trzecia [[G5154]] WTA-NSN **αυτων** *autōn* ich [[G846]] WTP-GPM **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **ημερα** *hēmera* dzień [[G2250]] [[N-NSF]] **μη** *mē* nie [[G3361]] [[PRT-N]] **φαινη** *fainē* ukazałaby się – uwidaczniałby się [[G5316]] WTV-PAS-3S **το** *to* (część) [[G3588]] WTT-ASN **τριτον** *triton* trzecia [[G5154]] WTA-ASN **αυτης** *autēs* jego [[G846]] [[P-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **νυξ** *nyks* noc [[G3571]] [[N-NSF]] **ομοιως** *homoiōs* podobnie [[G3668]] [[ADV]]
###### **Ap 8,13**
 **και** *kai* I [[G2532]] [[CONJ]] **ειδον** *eidon* zobaczyłem [[G1492]] WTV-2AAI-1S **και** *kai* i [[G2532]] [[CONJ]] **ηκουσα** *ēkousa* usłyszałem [[G191]] WTV-AAI-1S **ενος** *henos* jednego [[G1520]] WTA-GSM **αγγελου** *angelou* zwiastuna [[G32]] [[N-GSM]] **πετωμενου** *petōmenou* lecącego [[G4072]] WTV-PNP-GSM **εν** *en* w [[G1722]] [[PREP]] **μεσουρανηματι** *mesouranēmati* środku nieba [[G3321]] WTN-DSN **λεγοντος** *legontos* mówiącego [[G3004]] WTV-PAP-GSM **φωνη** *fōnē* głosem [[G5456]] [[N-DSF]] **μεγαλη** *megalē* wielkim [[G3173]] WTA-DSF **ουαι** *ouai* biada [[G3759]] WTINJ **ουαι** *ouai* biada [[G3759]] WTINJ **ουαι** *ouai* biada [[G3759]] WTINJ **τοις** *tois* [[G3588]] WTT-DPM **κατοικουσιν** *katoikousin* zamieszkującym [[G2730]] WTV-PAP-DPM **επι** *epi* na [[G1909]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]] **εκ** *ek* od [[G1537]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **λοιπων** *loipōn* pozostałych [[G3062]] WTA-GPM **φωνων** *fōnōn* dźwięków – głosów [[G5456]] WTN-GPM **της** *tēs* [[G3588]] [[T-GSF]] **σαλπιγγος** *salpingos* trąby [[G4536]] [[N-GSF]] **των** *tōn* [[G3588]] WTT-GPM **τριων** *triōn* trzech [[G5140]] WTA-GPM **αγγελων** *angelōn* zwiastunów [[G32]] WTN-GPM **των** *tōn* [[G3588]] WTT-GPM **μελλοντων** *mellontōn* zamierzających [[G3195]] WTV-PAP-GPM **σαλπιζειν** *salpizein* trąbić [[G4537]] WTV-PAN
