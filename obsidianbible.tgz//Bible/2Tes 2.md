# 2Tes 2 BT5
###### **2Tes 2,1**
 W sprawie przyjścia Pana naszego, Jezusa Chrystusa, i naszego zgromadzenia się wokół Niego prosimy was, bracia,
###### **2Tes 2,2**
 abyście się nie dali zbyt łatwo zachwiać w waszym rozumieniu ani zastraszyć bądź przez ducha, bądź przez mowę, bądź przez list, rzekomo od nas pochodzący, jakoby już nastawał dzień Pański.
###### **2Tes 2,3**
 Niech was w żaden sposób nikt nie zwodzi, bo [dzień ten nie nadejdzie], dopóki nie przyjdzie najpierw odstępstwo i nie objawi się człowiek grzechu, syn zatracenia,
###### **2Tes 2,4**
 który się sprzeciwia i wynosi ponad wszystko, co nazywane jest Bogiem lub co odbiera cześć, tak że zasiądzie w świątyni Boga, dowodząc, że sam jest Bogiem.
###### **2Tes 2,5**
 Czy nie pamiętacie, jak mówiłem wam o tym, gdy wśród was przebywałem?
###### **2Tes 2,6**
  Wiecie, co go teraz powstrzymuje, aby objawił się w swoim czasie.
###### **2Tes 2,7**
 Albowiem już działa tajemnica bezbożności. Niech tylko ten, co teraz powstrzymuje, ustąpi miejsca,
###### **2Tes 2,8**
 a wówczas ukaże się Niegodziwiec, którego Pan Jezus zgładzi tchnieniem swoich ust i wniwecz obróci [samym] objawieniem swego przyjścia.
###### **2Tes 2,9**
 Pojawieniu się jego towarzyszyć będzie działanie szatana, z całą mocą, wśród znaków i fałszywych cudów,
###### **2Tes 2,10**
 z wszelkim zwodzeniem ku nieprawości tych, którzy idą na zagładę, ponieważ nie przyjęli miłości prawdy, aby dostąpić zbawienia.
###### **2Tes 2,11**
 Dlatego Bóg dopuszcza działanie na nich oszustwa, tak iż uwierzą kłamstwu,
###### **2Tes 2,12**
 aby byli osądzeni wszyscy, którzy nie uwierzyli prawdzie, ale upodobali sobie nieprawość.
###### **2Tes 2,13**
 Lecz my zawsze winniśmy dziękować Bogu za was, bracia umiłowani przez Pana, że wybrał was Bóg jako pierwociny do zbawienia przez uświęcenie w Duchu i przez wiarę w prawdę.
###### **2Tes 2,14**
 Po to wezwał was przez nasze głoszenie Ewangelii, abyście dostąpili chwały Pana naszego, Jezusa Chrystusa.
###### **2Tes 2,15**
 Przeto, bracia, trwajcie niewzruszenie i trzymajcie się tradycji, o których zostaliście pouczeni bądź ży-wym słowem, bądź za pośrednictwem naszego listu.
###### **2Tes 2,16**
 Sam zaś Pan nasz, Jezus Chrystus, i Bóg, Ojciec nasz, który nas umiłował i przez łaskę udzielił nam wiecznego pocieszenia i dobrej nadziei,
###### **2Tes 2,17**
 niech pocieszy serca wasze i niech utwierdzi w każdym działaniu i dobrej mowie.
# 2Tes 2 PAU
###### **2Tes 2,1**
 Co do przyjścia naszego Pana Jezusa Chrystusa i naszego zgromadzenia się przy Nim, prosimy was, bracia:
###### **2Tes 2,2**
 Nie dajcie się zbyt łatwo zmylić w przekonaniach ani zastraszyć przez fałszywe proroctwo, pogłoski czy list rzekomo od nas pochodzący, jakoby już nadchodził Dzień Pana.
###### **2Tes 2,3**
 Niech nikt was w taki sposób nie zwodzi. Najpierw bowiem przyjdzie odstępstwo i objawi się człowiek niegodziwy, zatraceniec,
###### **2Tes 2,4**
 który będzie występował przeciw wszystkiemu i wynosił się ponad wszystko, co boskie i godne czci. Wreszcie zasiądzie w świątyni Bożej, uważając się za samego Boga.
###### **2Tes 2,5**
 Czy nie pamiętacie, że wam o tym mówiłem, będąc wśród was?
###### **2Tes 2,6**
 Wiecie, co go teraz powstrzymuje, aż do czasu, w którym się objawi.
###### **2Tes 2,7**
 Tajemnica nieprawości już bowiem działa. Wystarczy, że ustąpi ten, co powstrzymuje jej działanie,
###### **2Tes 2,8**
 a objawi się niegodziwiec, którego Pan Jezus zniszczy tchnieniem swoich ust i zgładzi majestatem swego przyjścia.
###### **2Tes 2,9**
 A przyjście niegodziwca będzie jak działanie szatana w całej mocy wśród znaków i fałszywych cudów.
###### **2Tes 2,10**
 Zwiedzie on wszelką nieuczciwością tych, którzy są na drodze do zagłady, ponieważ nie umiłowali prawdy prowadzącej do zbawienia.
###### **2Tes 2,11**
 Dlatego Bóg pozwoli, aby zostali oni oszukani i uwierzyli kłamstwu.
###### **2Tes 2,12**
 I tak będą osądzeni wszyscy, którzy nie uwierzyli prawdzie, lecz woleli postępować nieuczciwie.
###### **2Tes 2,13**
 Bracia, umiłowani przez Pana! Powinniśmy dziękować Bogu zawsze za was wszystkich, za to, że wybrał was jako pierwszych, aby was zbawić przez uświęcenie w Duchu i wiarę w prawdę.
###### **2Tes 2,14**
 Bóg wezwał was przez naszą Ewangelię do udziału w chwale naszego Pana, Jezusa Chrystusa.
###### **2Tes 2,15**
 Bracia, bądźcie wytrwali i zachowujcie tradycje, o których zostaliście pouczeni zarówno słowem, jak i naszym listem.
###### **2Tes 2,16**
 Sam nasz Pan, Jezus Chrystus, i Bóg, nasz Ojciec, który nas umiłował i obdarzył nieustanną pociechą i niezawodną nadzieją przez łaskę,
###### **2Tes 2,17**
 niech was pociesza i utwierdza we wszelkim dobrym czynie i słowie.
# 2Tes 2 BP
###### **2Tes 2,1**
 Bracia! W sprawach dotyczących przyjścia Pana naszego Jezusa Chrystusa i naszego z Nim spotkania prosimy was,
###### **2Tes 2,2**
 nie dajcie się wyprowadzić zbyt łatwo z równowagi ducha ani nie trwóżcie się z powodu jakiegoś objawienia prorockiego, nauczania lub przypisywanego nam listu, jakoby już nadchodził dzień Pański.
###### **2Tes 2,3**
 Niech was nikt w żaden sposób nie wprowadza w błąd. Bo najpierw musi dojść do odstępstwa i objawi się człowiek grzechu, syn zatracenia,
###### **2Tes 2,4**
 przeciwnik, wynoszący się ponad wszystko, co nazwane jest Bogiem lub odbiera cześć Boską. Zasiądzie on nawet w świątyni Boga dowodząc, że sam jest Bogiem.
###### **2Tes 2,5**
 Czy nie pamiętacie, że wam mówiłem o tym, przebywając jeszcze z wami?
###### **2Tes 2,6**
 Wiecie przecież o tej przeszkodzie, która nie pozwala mu działać, aż czas jego nadejdzie.
###### **2Tes 2,7**
 Nieprawość już potajemnie rozwija swoją działalność, najpierw jednak musi ustąpić ten, który ją powstrzymuje.
###### **2Tes 2,8**
 Wtedy wystąpi jawnie ów gwałciciel prawa, ale Pan Jezus powali go tchnieniem ust swoich, zniszczy go w chwili swojego przyjścia.
###### **2Tes 2,9**
 Działalności jego towarzyszyć będą za sprawą szatana cuda kłamliwe, znaki i dziwy.
###### **2Tes 2,10**
 Tych, którzy nie umiłowali prawdy mającej ich zbawić, zwiedzie wszelkimi pokusami zła ku ich zgubie.
###### **2Tes 2,11**
 Bóg dopuści, że omamieni błędem wciągnięci zostaną w sidła i dadzą wiarę kłamstwu.
###### **2Tes 2,12**
 Tak wszyscy, którzy nie uwierzyli prawdzie, lecz upodobali sobie zło, zostaną potępieni.
###### **2Tes 2,13**
 My zaś powinniśmy nieustannie składać Bogu dzięki, umiłowani przez Pana bracia, że Bóg wybrał was pierwszych do zbawienia przez Ducha Świętego i wierność prawdzie.
###### **2Tes 2,14**
 Bo wybrał was przez nasze głoszenie ewangelii do osiągnięcia chwały Pana naszego Jezusa Chrystusa.
###### **2Tes 2,15**
 Trwajcie więc, bracia, niewzruszenie w nauce, którą otrzymaliście czy przez ustne nauczanie, czy to przez nasz list.
###### **2Tes 2,16**
 A sam Pan nasz Jezus Chrystus i Bóg, Ojciec nasz, który nas ukochał i obdarzył nas wieczną radością i ufną nadzieją,
###### **2Tes 2,17**
 niech krzepi wasze serca i umocni w każdym dobrym czynie i słowie.
# 2Tes 2 BR
###### **2Tes 2,1**
 Gdy zaś chodzi o sprawę przyjścia Pana naszego Jezusa Chrystusa i nasze zgromadzenie się przy Nim, to prosimy was, bracia,
###### **2Tes 2,2**
 żebyście się nie dali ani zachwiać zbyt łatwo w waszych dotychczasowych przekonaniach, ani zastraszyć przez tych, którzy twierdzą, że dzień Pański już nadchodzi, powołując się przy tym albo na rzekome natchnienie Ducha, albo na [charyzmatyczne] mowy [prorockie], albo na list rzekomo od nas pochodzący.
###### **2Tes 2,3**
 Nie dajcie się zwieść nikomu w żaden sposób. Wiadomo bowiem, że dzień Pański nie nadejdzie, dopóki nie stwierdzi się wielkiego odstępstwa [od wiary] i nie przyjdzie człowiek grzechu, syn zatracenia.
###### **2Tes 2,4**
 Będzie się on sprzeciwiał i wynosił ponad wszystko, co człowiek nazywa Bogiem i co adoruje jako Boga. W końcu zasiądzie nawet w świątyni Bożej i będzie się podawał za samego Boga.
###### **2Tes 2,5**
 Zresztą czy nie pamiętacie, jak wam już o tym mówiłem, kiedy wśród was przebywałem?
###### **2Tes 2,6**
 Tymczasem jednak istnieje jeszcze coś, co uniemożliwia jego pełne wystąpienie aż do określonego momentu.
###### **2Tes 2,7**
 Tajemnica bezbożności już bowiem okazuje swoją moc i skoro tylko ustąpi ten, który ową potęgę powstrzymuje,
###### **2Tes 2,8**
 wówczas ukaże się Niegodziwiec w całej pełni. Ale Pan zgładzi go tchnieniem swoich ust i zniszczy samą potęgą swego przyjścia.
###### **2Tes 2,9**
 Przyjdzie zaś ów Niegodziwiec wyposażony w moc Szatana i będzie dokonywał wielu rzeczy niezwykłych i fałszywych cudów.
###### **2Tes 2,10**
 Będzie się posługiwał złem we wszelkich jego postaciach, byle tylko uwieść tych, którzy idą na zatracenie, ponieważ nie przyjęli z miłością prawdy mającej doprowadzić ich do wiecznego zbawienia.
###### **2Tes 2,11**
 I dlatego właśnie Bóg zezwala, by ulegli oszustwom, by uwierzyli kłamstwu.
###### **2Tes 2,12**
 W ten sposób bowiem zasłużą sobie na wyrok potępienia ci wszyscy, którzy zamiast uwierzyć prawdzie, znaleźli upodobanie w nieprawości.
###### **2Tes 2,13**
 Bracia, powinniśmy nieustannie dziękować Bogu za was, których Pan tak umiłował, że wybrał Bóg was jako pierwszych do osiągnięcia zbawienia przez Ducha [Świętego] i przez waszą wiarę w prawdę.
###### **2Tes 2,14**
 Po to bowiem wezwał was Bóg przez nasze głoszenie Ewangelii, abyście mieli udział w chwale Pana naszego Jezusa Chrystusa.
###### **2Tes 2,15**
 Przeto, bracia, nie dajcie się zachwiać, trzymajcie się mocno pouczeń, które przekazaliśmy wam bądź ustnie, bądź za pośrednictwem naszego listu.
###### **2Tes 2,16**
 Sam zaś Pan nasz Jezus Chrystus i Bóg nasz Ojciec - Ten, który nas umiłował i przez łaskę udzielił nam niewymownego pocieszenia i rzeczywistej nadziei -
###### **2Tes 2,17**
 niech pokrzepi wasze serca, niech was utwierdzi w chęci zarówno czynienia, jak i mówienia dobrze.
# 2Tes 2 WUJ
###### **2Tes 2,1**
 A prosimy was bracia przez przyście Pana naszego Jezusa Chrystusa i naszego zgromadzenia do niego:
###### **2Tes 2,2**
 Abyście się nie prędko unosili od rozumu waszego, ani byli ustraszeni, ani przez ducha, ani przez mowę, ani przez list, jakoby od nas posłany, jakoby nadchodził dzień Pański.
###### **2Tes 2,3**
 Niech was nikt nie zwodzi żadnym sposobem: abowiem nie przyjdzie, jeśli pierwej nie przyjdzie odstąpienie, i będzie objawion człowiek grzechu, syn zatracenia:
###### **2Tes 2,4**
 Który się sprzeciwia i wynosi się nad to wszystko co zowią Bogiem, abo co chwalą: tak, że usiędzie w kościele Bożym, okazując się jakoby był Bogiem.
###### **2Tes 2,5**
 Nie pamiętacie, iż gdym jeszcze u was był, tom wam powiadał?
###### **2Tes 2,6**
 A teraz wiecie co zatrzymawa: aby był objawion czasu swego.
###### **2Tes 2,7**
 Abowiem się już sprawuje tajemnica nieprawości: tylko aby ten, który trzyma teraz, dzierżał aż odięt będzie z pośrodku.
###### **2Tes 2,8**
 A tedy objawion będzie on złośnik: którego Pan Jezus zabije duchem ust swoich: i zatraci objawieniem przyścia swego tego,
###### **2Tes 2,9**
 Którego przyście jest wedle skuteczności szatańskiej, z wszelaką mocą, i znaki i cudami kłamliwemi,
###### **2Tes 2,10**
 I z wszelkiem zwiedzieniem nieprawości w tych, którzy giną, przeto iż miłości prawdy nie przyjęli, aby byli zbawieni.
###### **2Tes 2,11**
 Dla tego pośle im Bóg skuteczność oszukania, aby wierzyli kłamstwu:
###### **2Tes 2,12**
 Iżby byli osądzeni wszyscy, którzy nie uwierzyli prawdzie, ale przyzwolili na nieprawość.
###### **2Tes 2,13**
 Lecz my powinniśmy Bogu dziękować zawsze za was bracia umiłowani od Boga, iż was wybrał Bóg pierwiastkami ku zbawieniu, przez poświęcenie ducha i przez wiarę prawdy:
###### **2Tes 2,14**
 Na którą też was wezwał przez Ewanielią naszę, ku nabyciu chwały Pana naszego Jezusa Chrystusa.
###### **2Tes 2,15**
 Przeto bracia stójcie: a trzymajcie podania, którycheście się nauczyli, choć przez mowę, choć przez list nasz.
###### **2Tes 2,16**
 A sam Pan nasz Jezus Chrystus, i Bóg a Ociec nasz, który nas umiłował, i dał pocieszenie wieczne, i nadzieję dobrą przez łaskę:
###### **2Tes 2,17**
 Niech napomina serca wasze, i utwierdza we wszelakim uczynku i w mowie dobrej.
# 2Tes 2 STERN
###### **2Tes 2,1**
 Lecz w związku z nadejściem Pana naszego Jeszui Mesjasza i naszym wspólnym zgromadzeniem się na spotkanie z Nim prosimy was, bracia,
###### **2Tes 2,2**
 abyście się nie dali łatwo zbić z tropu w swoim myśleniu ani zaniepokoić się z powodu już to ducha, już to wygłoszonego orędzia, już to listu rzekomo od nas, twierdzącego, że Dzień Pana już nadszedł.
###### **2Tes 2,3**
 Nie pozwólcie, żeby was kto zwiódł w jakikolwiek sposób. Bo Dzień ten nie przyjdzie wcześniej, nim nastanie Odstępstwo i objawi się człowiek, który odcina się od Tory, ten przeznaczony do zguby.
###### **2Tes 2,4**
 Sprzeciwi się on wszystkiemu, co ludzie zwą bogiem albo czynią przedmiotem czci, wywyższy się ponad to wszystko, tak że zasiądzie w Świątyni Bożej i ogłosi się Bogiem.
###### **2Tes 2,5**
 Czy nie pamiętacie, że gdy jeszcze byłem u was, mówiłem wam o tych sprawach?
###### **2Tes 2,6**
 A teraz wiecie, co stoi na przeszkodzie, tak aby się on objawił w swoim czasie.
###### **2Tes 2,7**
 Bo już w tej chwili potajemnie działa owo odcięcie się od Tory, ale będzie ono potajemne tylko do chwili, aż ten, który stoi na przeszkodzie, zejdzie z drogi.
###### **2Tes 2,8**
 Wtedy objawi się ten, który ucieleśnia w sobie odcięcie się od Tory, ten, którego Pan Jeszua zabije tchnieniem swoich ust i zniszczy chwałą swego przyjścia.
###### **2Tes 2,9**
 Kiedy przyjdzie ów człowiek, który trzyma się z dala od Tory, Przeciwnik da mu moc czynienia wszelakich fałszywych cudów, znaków i dziwów.
###### **2Tes 2,10**
 Da mu zdolność zwodzenia na wszelakie nikczemne sposoby tych, którzy zmierzają na zatracenie, bo nie przyjęli miłości prawdy, która mogła ich zbawić.
###### **2Tes 2,11**
 Dlatego Bóg sprawia, że błądzą, aby uwierzyli Kłamstwu.
###### **2Tes 2,12**
 Wskutek tego zostaną potępieni wszyscy, którzy nie uwierzyli prawdzie, ale upodobali sobie niegodziwość.
###### **2Tes 2,13**
 Ale my musimy nieustannie dziękować Bogu za was, bracia, których miłuje Pan, gdyż Bóg wybrał was jako pierwociny wyzwolenia, dając wam świętość pochodzącą od Ducha i wierność pochodzącą od prawdy.
###### **2Tes 2,14**
 Wezwał was do tego naszą Dobrą Nowiną, abyście dostąpili chwały naszego Pana Jeszui Mesjasza.
###### **2Tes 2,15**
 Dlatego, bracia, trwajcie niezachwianie i trzymajcie się tradycji, których was uczyliśmy, już to mówiąc o nich, już to listownie.
###### **2Tes 2,16**
 I niech sam Pan nasz Jeszua Mesjasz i Bóg Ojciec, który nas ukochał i łaską swą dał nam wieczne pocieszenie i dobrą nadzieję,
###### **2Tes 2,17**
 pocieszy wasze serca i umocni was w każdym dobrym słowie i czynie.
# 2Tes 2 TRO
###### **2Tes 2,1**
 **ερωτωμεν** *erōtōmen* Prosimy [[G2065]] WTV-PAI-1P **δε** *de* zaś [[G1161]] [[CONJ]] **υμας** *hymas* was [[G5209]] WTP-2AP **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **υπερ** *hyper* co do [[G5228]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **παρουσιας** *parousias* przyjścia [[G3952]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **επισυναγωγης** *episynagōgēs* zgromadzenia się – zebrania się [[G1997]] [[N-GSF]] **επ** *ep* przy [[G1909]] [[PREP]] **αυτον** *auton* Nim [[G846]] WTP-ASM
###### **2Tes 2,2**
 **εις** *eis* względem [[G1519]] [[PREP]] **το** *to* (tego) [[G3588]] WTT-ASN **μη** *mē* aby nie [[G3361]] [[PRT-N]] **ταχεως** *tacheōs* szybko [[G5030]] [[ADV]] **σαλευθηναι** *saleuthēnai* zostać potrząśniętymi – zostać zachwianymi [[G4531]] WTV-APN **υμας** *hymas* wy [[G5209]] WTP-2AP **απο** *apo* od [[G575]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **νοος** *noos* umysłu – rozumu [[G3563]] [[N-GSM]] **μητε** *mēte* ani [[G3383]] [[CONJ]] **θροεισθαι** *throeisthai* dawać się straszyć – być trwożonymi [[G2360]] WTV-PPN **μητε** *mēte* ani [[G3383]] [[CONJ]] **δια** *dia* przez [[G1223]] [[PREP]] **πνευματος** *pneumatos* ducha [[G4151]] [[N-GSN]] **μητε** *mēte* ani [[G3383]] [[CONJ]] **δια** *dia* przez [[G1223]] [[PREP]] **λογου** *logou* słowo [[G3056]] [[N-GSM]] **μητε** *mēte* ani [[G3383]] [[CONJ]] **δι** *di* przez [[G1223]] [[PREP]] **επιστολης** *epistolēs* list [[G1992]] [[N-GSF]] **ως** *hōs* jak [[G5613]] [[ADV]] **δι** *di* przez [[G1223]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP **ως** *hōs* jak [[G5613]] [[ADV]] **οτι** *hoti* że [[G3754]] [[CONJ]] **ενεστηκεν** *enestēken* nastał [[G1764]] WTV-RAI-3S **η** *hē* [[G3588]] [[T-NSF]] **ημερα** *hēmera* dzień [[G2250]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **2Tes 2,3**
 **μη** *mē* aby nie [[G3361]] [[PRT-N]] **τις** *tis* ktoś [[G5100]] WTX-NSM **υμας** *hymas* was [[G5209]] WTP-2AP **εξαπατηση** *eksapatēsē* zwiódłby [[G1818]] WTV-AAS-3S **κατα** *kata* przez [[G2596]] [[PREP]] **μηδενα** *mēdena* żaden [[G3367]] WTA-ASM **τροπον** *tropon* sposób [[G5158]] [[N-ASM]] **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **εαν** *ean* jeśli [[G1437]] WTCOND **μη** *mē* nie [[G3361]] [[PRT-N]] **ελθη** *elthē* przyszłoby [[G2064]] WTV-2AAS-3S **η** *hē* [[G3588]] [[T-NSF]] **αποστασια** *apostasia* odstępstwo [[G646]] [[N-NSF]] **πρωτον** *prōton* najpierw [[G4412]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **αποκαλυφθη** *apokalyfthē* zostałby objawiony [[G601]] WTV-APS-3S **ο** *ho* [[G3588]] [[T-NSM]] **ανθρωπος** *anthrōpos* człowiek [[G444]] [[N-NSM]] **της** *tēs* [[G3588]] [[T-GSF]] **αμαρτιας** *hamartias* grzechu [[G266]] [[N-GSF]] **ο** *ho* [[G3588]] [[T-NSM]] **υιος** *hyios* syn [[G5207]] [[N-NSM]] **της** *tēs* [[G3588]] [[T-GSF]] **απωλειας** *apōleias* zguby – zatracenia [[G684]] [[N-GSF]]
###### **2Tes 2,4**
 **ο** *ho* [[G3588]] [[T-NSM]] **αντικειμενος** *antikeimenos* będący przeciwnym [[G480]] WTV-PNP-NSM **και** *kai* i [[G2532]] [[CONJ]] **υπεραιρομενος** *uperairomenos* który jest wznoszony – który jest podnoszony [[G5229]] [[V-PPP-NSM]] **επι** *epi* ponad [[G1909]] [[PREP]] **παν** *pan* wszystko [[G3956]] WTA-ASN **το** *to* [[G3588]] WTT-ASN **λεγομενον** *legomenon* który jest nazywany [[G3004]] WTV-PPP-ASN **θεον** *theon* bogiem [[G2316]] [[N-ASM]] **η** *ē* lub [[G2228]] WTPRT **σεβασμα** *sebasma* przedmiotem kultu – przedmiotem czci [[G4574]] WTN-ASN **ωστε** *hōste* tak, że [[G5620]] [[CONJ]] **αυτον** *auton* go [[G846]] WTP-ASM **εις** *eis* w [[G1519]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **ναον** *naon* świątyni – przybytek [[G3485]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ως** *hōs* jak [[G5613]] [[ADV]] **θεον** *theon* bóg [[G2316]] [[N-ASM]] **καθισαι** *kathisai* usiąść [[G2523]] [[V-AAN]] **αποδεικνυντα** *apodeiknynta* pokazując – wskazując [[G584]] WTV-PAP-ASM **εαυτον** *heauton* siebie samego [[G1438]] WTF-3ASM **οτι** *hoti* że [[G3754]] [[CONJ]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **θεος** *theos* bóg [[G2316]] [[N-NSM]]
###### **2Tes 2,5**
 **ου** *ou* Nie [[G3756]] [[PRT-N]] **μνημονευετε** *mnēmoneuete* pamiętacie – przypominacie sobie [[G3421]] WTV-PAI-2P **οτι** *hoti* że [[G3754]] [[CONJ]] **ετι** *eti* jeszcze [[G2089]] [[ADV]] **ων** *ōn* będąc [[G5607]] [[V-PXP-NSM]] **προς** *pros* u [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **ταυτα** *tauta* te [[G5023]] WTD-APN **ελεγον** *elegon* mówiłem [[G3004]] WTV-IAI-1S **υμιν** *hymin* wam [[G5213]] WTP-2DP
###### **2Tes 2,6**
 **και** *kai* I [[G2532]] [[CONJ]] **νυν** *nyn* teraz [[G3568]] [[ADV]] **το** *to* (to) [[G3588]] WTT-ASN **κατεχον** *katechon* powstrzymujące – zatrzymujące [[G2722]] WTV-PAP-ASN **οιδατε** *oidate* znacie [[G1492]] WTV-RAI-2P **εις** *eis* aż do [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **αποκαλυφθηναι** *apokalyfthēnai* zostać objawionym [[G601]] WTV-APN **αυτον** *auton* on [[G846]] WTP-ASM **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **εαυτου** *heautou* swojej [[G1438]] WTF-3GSM **καιρω** *kairō* porze [[G2540]] WTN-DSM
###### **2Tes 2,7**
 **το** *to* [[G3588]] WTT-NSN **γαρ** *gar* Bowiem [[G1063]] [[CONJ]] **μυστηριον** *mystērion* tajemnica [[G3466]] WTN-NSN **ηδη** *ēdē* już [[G2235]] [[ADV]] **ενεργειται** *energeitai* działa [[G1754]] WTV-PMI-3S **της** *tēs* [[G3588]] [[T-GSF]] **ανομιας** *anomias* bezprawia – nieprawości [[G458]] [[N-GSF]] **μονον** *monon* jedynie – tylko [[G3440]] [[ADV]] **ο** *ho* (ten) [[G3588]] [[T-NSM]] **κατεχων** *katechōn* powstrzymujący – zatrzymujący [[G2722]] [[V-PAP-NSM]] **αρτι** *arti* teraz [[G737]] [[ADV]] **εως** *heōs* dopóki [[G2193]] [[CONJ]] **εκ** *ek* ze [[G1537]] [[PREP]] **μεσου** *mesou* środka [[G3319]] [[A-GSN]] **γενηται** *genētai* stałby się [[G1096]] WTV-2ADS-3S
###### **2Tes 2,8**
 **και** *kai* I [[G2532]] [[CONJ]] **τοτε** *tote* wtedy [[G5119]] [[ADV]] **αποκαλυφθησεται** *apokalyfthēsetai* zostanie objawiony [[G601]] WTV-FPI-3S **ο** *ho* [[G3588]] [[T-NSM]] **ανομος** *anomos* nieprawy – bezprawny [[G459]] [[A-NSM]] **ον** *hon* którego [[G3739]] WTR-ASM **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **αναλωσει** *analōsei* zniszczy [[G355]] WTV-FAI-3S **τω** *tō* [[G3588]] WTT-DSN **πνευματι** *pneumati* duchem [[G4151]] WTN-DSN **του** *tou* [[G3588]] WTT-GSN **στοματος** *stomatos* ust [[G4750]] [[N-GSN]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **καταργησει** *katargēsei* udaremni – uzna za bezużytecznego [[G2673]] WTV-FAI-3S **τη** *tē* (dla) [[G3588]] WTT-DSF **επιφανεια** *epifaneia* objawienia się – pokazania się [[G2015]] [[N-DSF]] **της** *tēs* [[G3588]] [[T-GSF]] **παρουσιας** *parousias* przyjścia [[G3952]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **2Tes 2,9**
 **ου** *hou* którego [[G3739]] WTR-GSM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **η** *hē* [[G3588]] [[T-NSF]] **παρουσια** *parousia* przyjście [[G3952]] [[N-NSF]] **κατ** *kat* według [[G2596]] [[PREP]] **ενεργειαν** *energeian* działania [[G1753]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **σατανα** *satana* szatana – [przeciwnik] [[G4567]] [[N-GSM]] **εν** *en* w [[G1722]] [[PREP]] **παση** *pasē* całej [[G3956]] WTA-DSF **δυναμει** *dynamei* mocy [[G1411]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **σημειοις** *sēmeiois* znakach [[G4592]] WTN-DPN **και** *kai* i [[G2532]] [[CONJ]] **τερασιν** *terasin* cudach [[G5059]] WTN-DPN **ψευδους** *pseudous* kłamstwa [[G5579]] [[N-GSN]]
###### **2Tes 2,10**
 **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **παση** *pasē* całym [[G3956]] WTA-DSF **απατη** *apatē* oszustwie – zwodzeniu [[G539]] [[N-DSF]] **της** *tēs* [[G3588]] [[T-GSF]] **αδικιας** *adikias* niesprawiedliwości – bezprawia [[G93]] [[N-GSF]] **εν** *en* w [[G1722]] [[PREP]] **τοις** *tois* (tych) [[G3588]] WTT-DPM **απολλυμενοις** *apollymenois* którzy giną [[G622]] WTV-PEP-DPM **ανθ** *anth* za [[G473]] [[PREP]] **ων** *hōn* to [[G3739]] WTR-GPM **την** *tēn* (że) [[G3588]] WTT-ASF **αγαπην** *agapēn* miłości [[G26]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **αληθειας** *alētheias* prawdy [[G225]] [[N-GSF]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εδεξαντο** *edeksanto* przyjęli [[G1209]] WTV-ADI-3P **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **σωθηναι** *sōthēnai* zostać zbawionymi – zostać uratowanymi [[G4982]] WTV-APN **αυτους** *autous* oni [[G846]] [[P-APM]]
###### **2Tes 2,11**
 **και** *kai* i [[G2532]] [[CONJ]] **δια** *dia* dla- [[G1223]] [[PREP]] **τουτο** *touto* tego [[G5124]] WTD-ASN **πεμψει** *pempsei* pośle [[G3992]] WTV-FAI-3S **αυτοις** *autois* im [[G846]] WTP-DPM **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ενεργειαν** *energeian* działanie [[G1753]] WTN-ASF **πλανης** *planēs* zwiedzenia – błędu [[G4106]] [[N-GSF]] **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **πιστευσαι** *pisteusai* uwierzyć [[G4100]] [[V-AAN]] **αυτους** *autous* oni [[G846]] [[P-APM]] **τω** *tō* [[G3588]] WTT-DSN **ψευδει** *pseudei* kłamstwu [[G5579]] WTN-DSN
###### **2Tes 2,12**
 **ινα** *hina* aby [[G2443]] [[CONJ]] **κριθωσιν** *krithōsin* zostaliby osądzeni [[G2919]] WTV-APS-3P **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **οι** *hoi* [[G3588]] WTT-NPM **μη** *mē* nie [[G3361]] [[PRT-N]] **πιστευσαντες** *pisteusantes* którzy uwierzyli [[G4100]] WTV-AAP-NPM **τη** *tē* [[G3588]] WTT-DSF **αληθεια** *alētheia* prawdzie [[G225]] [[N-DSF]] **αλλ** *all* ale [[G235]] [[CONJ]] **ευδοκησαντες** *eudokēsantes* którzy znaleźli upodobanie [[G2106]] WTV-AAP-NPM **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **αδικια** *adikia* niesprawiedliwości – bezprawiu [[G93]] [[N-DSF]]
###### **2Tes 2,13**
 **ημεις** *hēmeis* My [[G2249]] WTP-1NP **δε** *de* zaś [[G1161]] [[CONJ]] **οφειλομεν** *ofeilomen* powinniśmy [[G3784]] WTV-PAI-1P **ευχαριστειν** *eucharistein* dziękować [[G2168]] WTV-PAN **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **παντοτε** *pantote* zawsze – w każdej chwili [[G3842]] [[ADV]] **περι** *peri* za [[G4012]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **ηγαπημενοι** *ēgapēmenoi* którzy jesteście umiłowani [[G25]] WTV-RPP-NPM **υπο** *hypo* przez [[G5259]] [[PREP]] **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **οτι** *hoti* że [[G3754]] [[CONJ]] **ειλετο** *eileto* wybrał sobie [[G138]] WTV-2AMI-3S **υμας** *hymas* was [[G5209]] WTP-2AP **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **απ** *ap* od [[G575]] [[PREP]] **αρχης** *archēs* początku [[G746]] [[N-GSF]] **εις** *eis* ku [[G1519]] [[PREP]] **σωτηριαν** *sōtērian* zbawieniu – wyzwoleniu [[G4991]] WTN-ASF **εν** *en* w [[G1722]] [[PREP]] **αγιασμω** *hagiasmō* poświęceniu – uświęceniu [[G38]] WTN-DSM **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **και** *kai* i [[G2532]] [[CONJ]] **πιστει** *pistei* wierze [[G4102]] [[N-DSF]] **αληθειας** *alētheias* prawdy [[G225]] [[N-GSF]]
###### **2Tes 2,14**
 **εις** *eis* do [[G1519]] [[PREP]] **ο** *ho* czego [[G3739]] WTR-ASN **εκαλεσεν** *ekalesen* wezwał [[G2564]] [[V-AAI-3S]] **υμας** *hymas* was [[G5209]] WTP-2AP **δια** *dia* przez [[G1223]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **ευαγγελιου** *euangeliou* dobrą nowinę [[G2098]] [[N-GSN]] **ημων** *hēmōn* naszą [[G2257]] WTP-1GP **εις** *eis* ku [[G1519]] [[PREP]] **περιποιησιν** *peripoiēsin* pozyskaniu dla siebie – nabyciu dla siebie [[G4047]] WTN-ASF **δοξης** *doksēs* chwały [[G1391]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **2Tes 2,15**
 **αρα** *ara* Zatem – Dlatego [[G686]] WTPRT **ουν** *oun* więc [[G3767]] [[CONJ]] **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **στηκετε** *stēkete* stójcie – trwajcie [[G4739]] WTV-PAM-2P **και** *kai* i [[G2532]] [[CONJ]] **κρατειτε** *krateite* trzymajcie się [[G2902]] WTV-PAM-2P **τας** *tas* [[G3588]] WTT-APF **παραδοσεις** *paradoseis* przekazów – tradycji [[G3862]] WTN-APF **ας** *has* których [[G3739]] WTR-APF **εδιδαχθητε** *edidachthēte* zostaliście nauczeni [[G1321]] WTV-API-2P **ειτε** *eite* czy to [[G1535]] [[CONJ]] **δια** *dia* przez [[G1223]] [[PREP]] **λογου** *logou* słowo [[G3056]] [[N-GSM]] **ειτε** *eite* czy to [[G1535]] [[CONJ]] **δι** *di* przez [[G1223]] [[PREP]] **επιστολης** *epistolēs* list [[G1992]] [[N-GSF]] **ημων** *hēmōn* nasz [[G2257]] WTP-1GP
###### **2Tes 2,16**
 **αυτος** *autos* Sam [[G846]] WTP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **ημων** *hēmōn* nasz [[G2257]] WTP-1GP **ιησους** *iēsous* Jezus – [JHWH jest zbawieniem] [[G2424]] [[N-NSM]] **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **πατηρ** *patēr* Ojciec [[G3962]] [[N-NSM]] **ημων** *hēmōn* nasz [[G2257]] WTP-1GP **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **αγαπησας** *agapēsas* który umiłował [[G25]] WTV-AAP-NSM **ημας** *hēmas* nas [[G2248]] WTP-1AP **και** *kai* i [[G2532]] [[CONJ]] **δους** *dous* który dał [[G1325]] WTV-2AAP-NSM **παρακλησιν** *paraklēsin* zachętę [[G3874]] WTN-ASF **αιωνιαν** *aiōnian* wieczną [[G166]] WTA-ASF **και** *kai* i [[G2532]] [[CONJ]] **ελπιδα** *elpida* nadzieję [[G1680]] WTN-ASF **αγαθην** *agathēn* dobrą [[G18]] WTA-ASF **εν** *en* w [[G1722]] [[PREP]] **χαριτι** *chariti* łasce [[G5485]] [[N-DSF]]
###### **2Tes 2,17**
 **παρακαλεσαι** *parakalesai* oby zachęcił [[G3870]] WTV-AAO-3S **υμων** *hymōn* wasze [[G5216]] WTP-2GP **τας** *tas* [[G3588]] WTT-APF **καρδιας** *kardias* serca [[G2588]] WTN-APF **και** *kai* i [[G2532]] [[CONJ]] **στηριξαι** *stēriksai* oby utwierdził – oby postawił mocno [[G4741]] WTV-AAO-3S **υμας** *hymas* was [[G5209]] WTP-2AP **εν** *en* w [[G1722]] [[PREP]] **παντι** *panti* każdym [[G3956]] WTA-DSM **λογω** *logō* słowie [[G3056]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **εργω** *ergō* dziele [[G2041]] WTN-DSN **αγαθω** *agathō* dobrym [[G18]] WTA-DSN
