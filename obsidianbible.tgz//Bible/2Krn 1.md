# 2Krn 1 BT5
###### **2Krn 1,1**
 Umocnił się potem Salomon, syn Dawida, w swojej władzy królewskiej, a Pan, Bóg jego, był z nim i bardzo go wywyższył.
###### **2Krn 1,2**
 Przemówił wówczas Salomon do całego Izraela, do tysiączników i setników, do sędziów i do wszystkich książąt całego Izraela, naczelników rodów.
###### **2Krn 1,3**
  Poszedł potem Salomon i z nim całe zgromadzenie na wyżynę, która jest w Gibeonie, ponieważ tam był Namiot Spotkania z Bogiem sporządzony przez Mojżesza, sługę Pańskiego, na pustyni.
###### **2Krn 1,4**
 Jednakże Arkę Bożą przeniósł Dawid z Kiriat-Jearim na miejsce przez siebie przygotowane dla niej, rozbił bowiem dla niej namiot w Jerozolimie.
###### **2Krn 1,5**
 Tam przed przybytkiem Pana znajdował się ołtarz z brązu, który wykonał Besaleel, syn Uriego, syna Chura. Do Pana po radę poszedł Salomon wraz ze zgromadzeniem.
###### **2Krn 1,6**
 Wszedł tam Salomon przed oblicze Pana na ów ołtarz z brązu, który należy do Namiotu Spotkania, i kazał złożyć na nim tysiąc ofiar całopalnych.
###### **2Krn 1,7**
 Tej to nocy ukazał się Bóg Salomonowi i rzekł: «***Proś o to, co mam ci dać***».
###### **2Krn 1,8**
 A Salomon odrzekł Bogu: «***Tyś okazywał mojemu ojcu, Dawidowi, wielką łaskę, a mnie uczyniłeś w miejsce jego królem.***
###### **2Krn 1,9**
 ***Teraz, Panie Boże, niech się wypełni Twoje słowo dane mojemu ojcu, Dawidowi, bo Ty sprawiłeś, iż jestem królem nad narodem tak licznym, jak proch ziemi.***
###### **2Krn 1,10**
 ***Teraz udziel mi mądrości i wiedzy, abym mógł występować wobec tego ludu; któż bowiem zdoła sądzić ten lud Twój tak wielki?***»
###### **2Krn 1,11**
 Wówczas odpowiedział Bóg Salomonowi: «***Ponieważ to jest w twoim sercu, a nie prosiłeś o bogactwo, o skarby i chwałę, ani o śmierć tych, którzy cię nienawidzą, ani o długie życie, ale prosiłeś dla siebie o mądrość i wiedzę, aby sądzić mój lud, nad którym ustanowiłem cię królem,***
###### **2Krn 1,12**
 ***przeto daję ci mądrość i wiedzę, ponadto obdaruję cię bogactwem, skarbami i chwałą, jakich nie mieli królowie przed tobą i nie będą mieli po tobie***».
###### **2Krn 1,13**
 Odszedł wówczas Salomon z wyżyny, która jest w Gibeonie, sprzed Namiotu Spotkania, do Jerozolimy i panował nad Izraelem.
###### **2Krn 1,14**
 Powiększył następnie Salomon liczbę rydwanów oraz jezdnych, tak że miał tysiąc czterysta rydwanów i dwanaście tysięcy jezdnych. Rozmieścił ich w miastach rydwanów i przy królu w Jerozolimie.
###### **2Krn 1,15**
 Złożył zaś król srebra i złota w Jerozolimie jak kamieni, a cedrów tak wiele, jak sykomor w Szefeli.
###### **2Krn 1,16**
 Konie, które posiadał, Salomon sprowadzał z Egiptu i z Koa; wędrowni kupcy króla sprowadzali je za pieniądze z Koa.
###### **2Krn 1,17**
 Przybywali i przywozili z Egiptu: rydwany za sześćset syklów, konie zaś za sto pięćdziesiąt. Tak samo za ich pośrednictwem sprowadzano je dla wszystkich królów chittyckich i aramejskich.
###### **2Krn 1,18**
 Rozkazał też Salomon, aby wybudowano dom dla imienia Pańskiego, a dla niego samego pałac królewski.
# 2Krn 1 PAU
###### **2Krn 1,1**
 Salomon, syn Dawida, utwierdzał swoją władzę królewską. PAN, jego Bóg, był z nim, aby umacniać jego wielkość.
###### **2Krn 1,2**
 Salomon przemawiał do całego Izraela: do tysiączników i setników, do sędziów, do wszystkich przywódców całego Izraela, naczelników rodów.
###### **2Krn 1,3**
 Salomon wraz z całym zgromadzeniem udał się do Gabaonu, na wzgórze, gdzie znajdował się Namiot Spotkania z Bogiem, zbudowany na pustyni przez sługę PANA, Mojżesza.
###### **2Krn 1,4**
 Lecz Dawid przeniósł Arkę Bożą z Kiriat-Jearim do namiotu, który przygotował i postawił dla niej w Jerozolimie.
###### **2Krn 1,5**
 Przed mieszkaniem PANA, do którego Salomon udał się wraz ze zgromadzeniem po radę, znajdował się ołtarz z brązu, wykonany przez Besalela, syna Uriego, syna Chura.
###### **2Krn 1,6**
 Salomon stanął przed PANEM, przed ołtarzem z brązu, który znajdował się przed Namiotem Spotkania, i złożył na nim tysiąc ofiar całopalnych.
###### **2Krn 1,7**
 Tej samej nocy Bóg ukazał się Salomonowi i rzekł do niego: „Proś, o co chcesz, a dam tobie”.
###### **2Krn 1,8**
 Salomon odpowiedział Bogu: „Ty uczyniłeś wielką łaskę mojemu ojcu Dawidowi, a mnie ustanowiłeś jego następcą.
###### **2Krn 1,9**
 Teraz, PANIE Boże, niech się spełni Twoja obietnica dana mojemu ojcu, ponieważ ustanowiłeś mnie królem nad narodem tak licznym jak ziarnka piasku na ziemi.
###### **2Krn 1,10**
 Obdarz mnie więc mądrością i wiedzą, abym umiał przewodzić temu ludowi. Któż bowiem zdoła rządzić Twoim ludem, który jest tak wielki?”.
###### **2Krn 1,11**
 Bóg odpowiedział Salomonowi: „Ponieważ z twego serca nie wypłynęła prośba ani o bogactwa, ani o skarby, ani o sławę, ani o śmierć twoich wrogów, ani o długie życie, lecz poprosiłeś o mądrość i wiedzę, by rządzić moim ludem, nad którym ustanowiłem cię królem,
###### **2Krn 1,12**
 dlatego obdarzam cię mądrością i wiedzą. Ponadto daję ci bogactwo, skarby i sławę. Władcy takiego jak ty nie było przed tobą ani po tobie nie będzie”.
###### **2Krn 1,13**
 Następnie Salomon powrócił ze wzgórza w Gabaonie, gdzie znajdował się Namiot Spotkania, do Jerozolimy. I panował nad Izraelem.
###### **2Krn 1,14**
 Salomon zwiększył liczbę rydwanów i koni. Posiadał tysiąc czterysta rydwanów oraz dwanaście tysięcy jeźdźców, stacjonujących w miastach-garnizonach oraz przy królu w Jerozolimie.
###### **2Krn 1,15**
 Za czasów Salomona srebro i złoto stały się w Jerozolimie tak powszechne jak zwykłe kamienie, a drewno cedrowe - jak drewno z sykomor, które rosną w niżej położonej dolinie.
###### **2Krn 1,16**
 Sprowadzano również dla Salomona konie z Egiptu i z Koe. Kupcy królewscy nabywali je w Koe.
###### **2Krn 1,17**
 Za rydwan sprowadzany z Egiptu płacili wtedy sześćset syklów srebra, a za konia sto pięćdziesiąt. Oni również zaopatrywali królów chetyckich i królów Aramu.
###### **2Krn 1,18**
 Salomon polecił zbudować dom dla imienia PANA i pałac królewski dla siebie.
# 2Krn 1 BP
###### **2Krn 1,1**
 Salomon, syn Dawida, umocnił się na swym królestwie, a Bóg jego, Jahwe, był z nim i uczynił go niezmiernie potężnym.
###### **2Krn 1,2**
 I przemówił Salomon do całego Izraela: do tysiączników i setników, do sędziów i wszystkich książąt całego Izraela, i do naczelników rodów.
###### **2Krn 1,3**
 Następnie udał się Salomon wraz z całym zgromadzeniem na wyżynę, która jest w Gibeonie; tam bowiem znajdował się Namiot Zjednoczenia z Bogiem, który jeszcze na pustyni zbudował Mojżesz, sługa Jahwe.
###### **2Krn 1,4**
 Arkę Bożą przeniósł jednak Dawid z Kirjat-Jearim na miejsce, które dla niej przygotował; zbudował bowiem dla niej Namiot w Jeruzalem.
###### **2Krn 1,5**
 Przed Przybytkiem Jahwe znajdował się tam ołtarz spiżowy, który zbudował Becalel, syn Uriego, syna Chura; do tego to [ołtarza] przybył Salomon i zgromadzenie.
###### **2Krn 1,6**
 Przystąpił tedy Salomon wobec Jahwe do ołtarza spiżowego, który był przed Namiotem Zjednoczenia, i złożył tysiąc ofiar całopalnych.
###### **2Krn 1,7**
 Tejże nocy ukazał się Bóg Salomonowi i rzekł do niego: Proś, o co chcesz, a dam tobie.
###### **2Krn 1,8**
 Rzekł wówczas Salomon do Boga: Okazałeś ojcu memu Dawidowi wielką łaskawość, a mnie ustanowiłeś po nim królem.
###### **2Krn 1,9**
 A teraz, o Jahwe, Boże [mój], spełnia się obietnica Twoja dana ojcu mojemu Dawidowi, boś uczynił mnie królem nad ludem licznym jak proch ziemi.
###### **2Krn 1,10**
 Daj mi więc teraz mądrość i rozeznanie, abym umiał rządzić jako władca tym ludem; któż bowiem potrafi sądzić ten lud Twój tak wielki?
###### **2Krn 1,11**
 Odpowiedział Bóg Salomonowi: Ponieważ nie prosiłeś o bogactwa, majętności, sławę ani też o zgubę nieprzyjaciół twoich czy o długie życie, lecz prosiłeś dla siebie o mądrość i umiejętność, abyś mógł sądzić mój lud, nad którym ustanowiłem cię królem,
###### **2Krn 1,12**
 dlatego daję ci mądrość i wiedzę, a ponadto jeszcze bogactwa, umiejętności i sławę tak [wielkie], jakich nie miał żaden z królów, którzy byli przed tobą, ani z tych, którzy po tobie nastąpią.
###### **2Krn 1,13**
 Powrócił następnie Salomon z wyżyny, która znajdowała się w Gibeonie, od Namiotu Zjednoczenia do Jeruzalem, i królował nad Izraelem.
###### **2Krn 1,14**
 Zgromadził potem Salomon rydwany i jezdnych i miał 1400 rydwanów i 12 000 jezdnych, których rozmieścił w miastach rydwanów i przy sobie w Jeruzalem.
###### **2Krn 1,15**
 Sprawił też król, że srebra i złota było w Jeruzalem [tak dużo], jak kamieni, a cedrów, jak sykomor, których wielkie mnóstwo rośnie na [równinie] Szefeli.
###### **2Krn 1,16**
 Konie Salomona pochodziły z Egiptu i z Koa; kupcy królewscy nabywali je w Koa za srebro.
###### **2Krn 1,17**
 Przybywali oni przywożąc z Egiptu rydwan za cenę sześciuset syklów srebra, a konie za sto pięćdziesiąt. Podobnie też wszyscy królowie chittyccy i aramejscy sprowadzali je za ich pośrednictwem.
###### **2Krn 1,18**
 Rozkazał następnie Salomon zbudować Dom dla Imienia Jahwe, a dla siebie pałac królewski.
# 2Krn 1 BR
###### **2Krn 1,1**
 I umacniał się Salomon, syn Dawida, w swojej królewskiej władzy, a Jahwe, jego Bóg, był z nim i wynosił go coraz wyżej.
###### **2Krn 1,2**
 Rozkazywał Salomon całemu Izraelowi, wszystkim dowódcom oddziałów liczących po tysiąc albo po stu ludzi, sędziom, książętom całego Izraela i naczelnikom rodów.
###### **2Krn 1,3**
 Chodził też Salomon z całym zgromadzeniem na wyżynę gibeońską, gdzie znajdował się Namiot Spotkania z Bogiem, zbudowany przez sługę Bożego Mojżesza, kiedy jeszcze przebywał on na pustyni.
###### **2Krn 1,4**
 Natomiast arkę Bożą Dawid przeprowadził z Kiriat-Jearim na miejsce, które sam dla niej przygotował. Dawid zbudował bowiem dla arki specjalny namiot w Jerozolimie.
###### **2Krn 1,5**
 Znajdował się tam również (na wzgórzu) przed przybytkiem Jahwe ołtarz brązowy, zbudowany przez Besaleela, syna Uriego, syn Chura. Przychodził tam Salomon z całym zgromadzeniem, aby wspólnie szukać Jahwe.
###### **2Krn 1,6**
 Tam też, na ołtarzu brązowym, który wznosił się przed Jahwe w pobliżu Namiotu Spotkania, złożył Salomon pewnego razu tysiąc ofiar całopalnych.
###### **2Krn 1,7**
 Zaraz następnej nocy Bóg ukazał się Salomonowi i rzekł mu: Powiedz, co chcesz, żebym ci dał.
###### **2Krn 1,8**
 A Salomon odpowiedział Bogu: Tyle dobroci okazałeś już ojcu mojemu, Dawidowi, i zechciałeś, żebym ja objął po nim władzę.
###### **2Krn 1,9**
 Spraw zatem, Panie, Boże mój, aby się wypełniły słowa Twoje, wypowiedziane do ojca mojego, Dawida, skoro już zechciałeś, abym sprawował władzę nad ludem, który jest tak liczny jak proch ziemi.
###### **2Krn 1,10**
 Racz mi tedy udzielić daru mądrości i rozumienia, abym umiał kierować Twoim ludem. Bo któż potrafi (sam z siebie) rządzić Twoim ludem, tak wielkim?
###### **2Krn 1,11**
 Powiedział tedy Bóg do Salomona: Ponieważ takie jest pragnienie twojego serca, ponieważ nie prosisz o bogactwa ani o skarby, ani o sławę, ani o zgubę dla swoich wrogów, co więcej, nie prosisz nawet o długie życie, ale o dar mądrości i rozumienia, żebyś umiał postępować z ludem, nad którym dałem ci władzę -
###### **2Krn 1,12**
 daję ci i mądrość, i dar rozumienia. Prócz tego dam ci bogactwa i skarby, i sławę tak wielką, jakiej nikt nie miał przed tobą i po tobie mieć nie będzie.
###### **2Krn 1,13**
 Potem wrócił Salomon z wyżyny gibeońskiej, sprzed Namiotu Spotkania, do Jerozolimy i sprawował władzę nad Izraelem.
###### **2Krn 1,14**
 Nagromadził też Salomon wiele rydwanów i zebrał licznych jeźdźców. W sumie miał Salomon tysiąc czterysta rydwanów i dwanaście tysięcy jeźdźców; rozmieścił ich w miastach, w których przechowywano rydwany, niedaleko od siedziby króla w Jerozolimie.
###### **2Krn 1,15**
 Doprowadził król również do tego, że srebra i złota było w Jerozolimie tak dużo jak zwykłych kamieni, a cedrów tyle co sykomor rosnących na równinie.
###### **2Krn 1,16**
 Konie kupował Salomon w Egipcie i w Koa. Kupcy Salomona sprowadzali je stamtąd całymi stadami po dogodnych cenach.
###### **2Krn 1,17**
 Przybywali do Egiptu i kupowali tam rydwany, płacąc po sześćset sykli srebra za sztukę, a po pięćdziesiąt sykli za konia. W ten sam sposób, przez tych samych ludzi, nabywali (konie i rydwany) wszyscy królowie chetyccy i aramejscy.
###### **2Krn 1,18**
 Salomon postanowił zbudować świątynię dla Imienia Jahwe i pałac królewski dla samego siebie.
# 2Krn 1 WUJ
###### **2Krn 1,1**
 Zmocnił się tedy Salomon syn Dawidów w królestwie swem: a Pan Bóg jego był z nim, i uwielbił go wysoce.
###### **2Krn 1,2**
 I przykazał Salomon wszystkiemu Izraelowi, tysiącznikom i setnikom, i wodzom, i sędziom wszystkiego Izraela, i przełożonym domów:
###### **2Krn 1,3**
 I szedł ze wszystkiem zgromadzeniem na wyżynę Gabaon, gdzie był przybytek przymierza Bożego, który sprawił Mojżesz sługa Boży na puszczy.
###### **2Krn 1,4**
 A skrzynię Bożą przywiódł był Dawid z Kariathiarim na miejsce, które jej był zgotował, i gdzie jej był rozbił namiot, to jest w Jeruzalem.
###### **2Krn 1,5**
 Ołtarz też miedziany, który był urobił Bezeleel, syn Ur, syna Hur, był tam przed przybytkiem Pańskim: którego też szukał Salomon i wszystko zgromadzenie,
###### **2Krn 1,6**
 I przystąpił Salomon do ołtarza miedzianego przed przybytkiem przymierza Pańskiego, i ofiarował na nim tysiąc ofiar.
###### **2Krn 1,7**
 A oto tejże nocy ukazał się mu Bóg, mówiąc: Żądaj czego chcesz, abych ci dał.
###### **2Krn 1,8**
 I rzekł Salomon do Boga: Tyś okazał nad Dawidem ojcem moim miłosierdzie wielkie: i postanowiłeś mię królem miasto niego,
###### **2Krn 1,9**
 Teraz tedy Panie Boże, niech się wypełni słowo twoje, któreś obiecał Dawidowi ojcu memu: boś ty mnie uczynił królem nad ludem twoim wielkim, który jest tak nie przeliczony jako proch ziemie.
###### **2Krn 1,10**
 Daj mi mądrość i umiejętność, żebym wchodził i wychodził przed ludem twoim: bo któż może ten twój lud, który tak wielki jest, przystojnie sądzić?
###### **2Krn 1,11**
 I rzekł Bóg do Salomona: że się to więcej sercu twemu podobało, a nie prosiłeś bogactw, i majętności, i sławy, ani dusz tych, którzy cię nienawidzieli, ale ani o wiele dni żywota; aleś prosił mądrości i umiejętności, abyś mógł sądzić lud mój, nad którymem cię postanowił królem:
###### **2Krn 1,12**
 Mądrość i umiejętność dana jest tobie: a bogactwa i majętność i sławę dam ci tak, iż żaden z królów ani przed tobą, ani po tobie będzie podobien tobie.
###### **2Krn 1,13**
 A tak się wrócił Salomon z wyżyny Gabaon do Jeruzalem przed przybytek przymierza, i królował nad Izraelem.
###### **2Krn 1,14**
 I zebrał sobie wozy i jezdne, i miał tysiąc i czterysta wozów, i dwanaście tysięcy jezdnych: i kazał im mieszkać w miastach poczwórnych wozów, a z królem w Jeruzalem.
###### **2Krn 1,15**
 I dodawał król srebra i złota w Jeruzalem jako kamieni, a cedrów jako Sikomorów, których barzo siła po polach roście.
###### **2Krn 1,16**
 Przywodzono mu też koni z Egiptu, i z Koi, od kupców królewskich którzy zajeżdżali i kupowali, za pieniądze.
###### **2Krn 1,17**
 Cztery woźniki za sześć set srebrników, a konia za sto pięćdziesiąt: także też ze wszystkich królestw Hethejskich, i od królów Syryjskich kupowano.
