# 1Krn 9 BT5
###### **1Krn 9,1**
 Wszyscy Izraelici byli umieszczeni w wykazach rodowych. Oto oni spisani zostali w Księdze Królów Izraela i Judy. Byli oni uprowadzeni na wygnanie do Babilonu z powodu swych występków.
###### **1Krn 9,2**
 Pierwszymi mieszkańcami, którzy z Izraela weszli do swych posiadłości w swoich miastach, byli kapłani, lewici i niewolnicy świątynni.
###### **1Krn 9,3**
 W Jerozolimie zamieszkiwali potomkowie Judy, Beniamina, Efraima i Manassesa.
###### **1Krn 9,4**
 Utaj, syn Ammihuda, syna Omriego, syna Imriego, syna Baniego, jednego z synów Peresa, syna Judy.
###### **1Krn 9,5**
 Z Szilonitów: pierworodny Asajasz i jego synowie.
###### **1Krn 9,6**
 Z synów Zeracha: Jeuel i sześciuset dziewięćdziesięciu ich braci.
###### **1Krn 9,7**
 Z synów Beniamina: Sallu, syn Meszullama, syna Hodawiasza, syna Hassenuy.
###### **1Krn 9,8**
 Jibnejasz, syn Jerochama; Ela, syn Uzziego, syna Mikriego; Meszullam, syn Szefatiasza, syna Reuela, syna Jibniasza.
###### **1Krn 9,9**
 Braci ich według ich rodowodów było dziewięciuset pięćdziesięciu sześciu. Wszyscy ci mężowie byli naczelnikami swoich rodów.
###### **1Krn 9,10**
 Z kapłanów: Jedajasz, Jojarib, Jakin.
###### **1Krn 9,11**
 Azariasz, syn Chilkiasza, syna Meszullama, syna Sadoka, syna Merajota, syna Achituba, zwierzchnika domu Bożego.
###### **1Krn 9,12**
 Adajasz, syn Jerochama, syna Paszchura, syna Malkiasza; Masaj, syn Adiela, syna Jachzery, syna Meszullama, syna Meszillemita, syna Immera.
###### **1Krn 9,13**
 Braci ich, naczelników swoich rodów, było tysiąc siedmiuset sześćdziesięciu dzielnych wojowników zatrudnionych przy obsłudze domu Bożego.
###### **1Krn 9,14**
 Z lewitów: Szemajasz, syn Chaszszuba, syna Azrikama, syna Chaszabiasza, z synów Merariego.
###### **1Krn 9,15**
 Bakbakar, Cheresz, Galal, Mattaniasz, syn Miki, syna Zikriego, syna Asafa.
###### **1Krn 9,16**
 Obadiasz, syn Szemajasza, syna Galala, syna Jedutuna, i Berekiasz, syn Asy, syna Elkany, który mieszkał w osiedlach Netofatytów.
###### **1Krn 9,17**
 Odźwierni: Szallum, Akkub, Talmon, Achiman i ich bracia. Szallum był przełożonym.
###### **1Krn 9,18**
 Jest on nim jeszcze teraz w Bramie Królewskiej, od wschodu. Ci byli odźwiernymi w obozach lewitów.
###### **1Krn 9,19**
 Szallum, syn Korego, syna Ebiasafa, syna Koracha, i bracia jego z domu jego ojca, Korachici, zatrudnieni służbą [Bożą], byli stróżami progów namiotu, a ich ojcowie strzegli wejścia do obozu Pańskiego.
###### **1Krn 9,20**
 Pinchas, syn Eleazara, był dawniej ich przełożonym – Pan [niech będzie] z nim!
###### **1Krn 9,21**
 Zachariasz, syn Meszelemiasza, był odźwiernym przy wejściu do Namiotu Spotkania.
###### **1Krn 9,22**
 Wszystkich wybranych na odźwiernych przy bramach było dwustu dwunastu. Byli oni zapisani w wykazach rodowych w swoich osiedlach. Stałe zaś ich obowiązki ustanowił Dawid i Samuel "Widzący".
###### **1Krn 9,23**
 Zarówno oni, jak i ich synowie czuwali nad bramami domu Pańskiego, domu Namiotu, aby pełnić straż.
###### **1Krn 9,24**
 Z czterech stron znajdowali się odźwierni: od wschodu, zachodu, północy i południa.
###### **1Krn 9,25**
 Bracia ich, mieszkający w swoich osiedlach, przychodzili od czasu do czasu, by przez siedem dni być z nimi,
###### **1Krn 9,26**
 ponieważ w stałej służbie byli czterej przełożeni odźwiernych. Byli to lewici odpowiedzialni za komnaty i skarbce domu Bożego.
###### **1Krn 9,27**
 Nocowali w obrębie domu Bożego, do nich bowiem należała piecza i obowiązek otwierania go każdego rana.
###### **1Krn 9,28**
 Niektórzy z nich mieli pieczę nad sprzętami używanymi do służby Bożej, bo wnosili je policzone i w tejże liczbie wynosili.
###### **1Krn 9,29**
 Inni spośród nich czuwali nad przyborami i nad wszystkimi naczyniami świętymi, nad najczystszą mąką, winem, oliwą, kadzidłem i balsamami.
###### **1Krn 9,30**
 A synowie kapłanów przyprawiali pachnące mieszanki do balsamów.
###### **1Krn 9,31**
 Mattitiasz, spośród lewitów, ten, który był pierworodnym Szalluma Korachity, miał sobie powierzony na stałe wypiek ciasta na ofiary.
###### **1Krn 9,32**
 Spośród synów Kehata, spośród ich braci, niektórzy mieli za zadanie ustawiać chleby pokładne w każdy szabat.
###### **1Krn 9,33**
 A ci, którzy byli śpiewakami, naczelnikami rodzin lewickich, pozostawali w komnatach wolni od innych zajęć, ponieważ dniem i nocą przypadała na nich służba.
###### **1Krn 9,34**
 Ci byli naczelnikami rodów lewickich według swego pokrewieństwa, a mieszkali w Jerozolimie.
###### **1Krn 9,35**
 W Gibeonie zamieszkał ojciec Gibeonu, Jejel, a jego żona miała na imię Maaka.
###### **1Krn 9,36**
 Jego synem pierworodnym był Abdon, potem Sur, Kisz, Baal, Ner, Nadab,
###### **1Krn 9,37**
 Gedor, Achio, Zachariasz i Miklot.
###### **1Krn 9,38**
 Miklot był ojcem Szimmeama. Oni również mieszkali w pobliżu swych krewnych ze swoimi braćmi w Jerozolimie.
###### **1Krn 9,39**
 Ner był ojcem Kisza, Kisz – Saula, Saul był ojcem Jonatana, Malkiszuy, Abinadaba i Eszbaala.
###### **1Krn 9,40**
 Synem Jonatana był Meribbaal, a Meribbaal był ojcem Miki.
###### **1Krn 9,41**
 Synowie Miki: Piton, Melek i Tachrea.
###### **1Krn 9,42**
 Achaz był ojcem Jary; Jara – Alemeta, Azmaweta i Zimriego; Zimri był ojcem Mosy.
###### **1Krn 9,43**
 Mosa był ojcem Binei; synem jego był Refajasz, synem jego Eleasa, synem jego Asel.
###### **1Krn 9,44**
 Asel miał sześciu synów; a ich imiona: Azrikam, Bokru, Izmael, Szeariasz, Obadiasz i Chanan. To są synowie Asela.
# 1Krn 9 PAU
###### **1Krn 9,1**
 Wszyscy Izraelici byli spisani według przynależności rodowej i zapisani w Księdze królów Izraela i Judy. Z powodu swej niegodziwości zostali uprowadzeni do Babilonu.
###### **1Krn 9,2**
 Pierwszymi, którzy powrócili do swych posiadłości w miastach byli Izraelici, kapłani, lewici i słudzy świątyni.
###### **1Krn 9,3**
 W Jerozolimie zamieszkali potomkowie Judy, Beniamina, Efraima i Manassesa.
###### **1Krn 9,4**
 Utaj, syn Ammihuda, syna Omriego, syna Imriego, syna Baniego, jednego z synów Peresa, syna Judy.
###### **1Krn 9,5**
 Z Szilonitów: pierworodny Asajasz i jego synowie.
###### **1Krn 9,6**
 Z Zerachitów: Jeuel i sześciuset dziewięćdziesięciu braci.
###### **1Krn 9,7**
 Z Beniaminitów: Sallu, syn Meszullama, syna Hodawiasza, syna Hassenuy.
###### **1Krn 9,8**
 Jebnejasz, syn Jerochama, Ela, syn Uzziego, syna Mikriego, Meszullam, syn Szefatiasza, syna Reuela, syna Jebniasza.
###### **1Krn 9,9**
 Zgodnie ze spisami rodowymi ich braci było dziewięciuset pięćdziesięciu sześciu. Wzmiankowani powyżej byli przywódcami rodów.
###### **1Krn 9,10**
 Z kapłanów: Jedajasz, Jojarib, Jakin.
###### **1Krn 9,11**
 Azariasz, zwierzchnik domu, syn Chilkiasza, syna Meszullama, syna Sadoka, syna Merajota, syna Achituba.
###### **1Krn 9,12**
 Adajasz, syn Jerochama, syna Paszchura, syna Malkiasza; Masaj, syn Adiela, syna Jachzery, syna Meszullama, syna Meszillemita, syna Immera.
###### **1Krn 9,13**
 W sumie ich braci, przywódców rodów i mężczyzn odznaczających się odwagą, sprawujących służbę świątynną, było tysiąc siedmiuset sześćdziesięciu.
###### **1Krn 9,14**
 Z lewitów: Szemejasz, syn Chaszszuba, syna Azrikama, syna Chaszabiasza z rodu Merariego;
###### **1Krn 9,15**
 Bakbakar, Cheresz, Galal, Mattaniasz, syn Miki, syna Zikriego, syna Asafa;
###### **1Krn 9,16**
 Obadiasz, syn Szemajasza, syna Galala, syna Jedutuna, i Berekiasz, syn Asy, syna Elkany, który mieszkał w posiadłościach Netofatytów.
###### **1Krn 9,17**
 Strażnicy przy bramach: Szallum, Akkub, Talmon, Achiman i ich bracia. Szallum był ich przełożonym,
###### **1Krn 9,18**
 a równocześnie strażnikiem we wschodniej Bramie Królewskiej. Strażnikami w dzielnicy lewitów byli:
###### **1Krn 9,19**
 Szallum, syn Korego, syna Ebiasafa, syna Koracha, oraz jego bracia pochodzący z rodu jego ojca. Strzegli oni wejścia do Namiotu, podobnie jak ich ojcowie strzegli wejścia do obozu PANA.
###### **1Krn 9,20**
 Pinchas, syn Eleazara, był dawniej ich przełożonym, a PAN był z nim.
###### **1Krn 9,21**
 Zachariasz, syn Meszelemiasza, był strażnikiem przy wejściu do Namiotu Spotkania.
###### **1Krn 9,22**
 Wszystkich wybranych na strażników przy bramach było dwustu dwunastu. Byli oni spisani w wykazach rodowych miast, z których pochodzili. Ich obowiązki określił Dawid oraz Samuel, widzący.
###### **1Krn 9,23**
 Zarówno oni, jak i ich synowie czuwali przy bramach domu PANA, przy Namiocie jako pełniący straż.
###### **1Krn 9,24**
 Strażnicy bram stali z czterech stron: od wschodu, od zachodu, od północy i od południa.
###### **1Krn 9,25**
 Ich bracia, mieszkający w swoich wioskach, przychodzili co jakiś czas i zostawali z nimi przez siedem dni.
###### **1Krn 9,26**
 Na stałej służbie byli czterej przełożeni strażników. Byli to lewici odpowiedzialni za pomieszczenia i skarbce domu.
###### **1Krn 9,27**
 Spędzali oni noce w obrębie domu, ich obowiązkiem było bowiem czuwanie nad nim i otwieranie go każdego ranka.
###### **1Krn 9,28**
 Niektórzy z nich opiekowali się sprzętami używanymi podczas liturgii, przynosząc je i wynosząc w tej samej liczbie.
###### **1Krn 9,29**
 Inni czuwali nad przedmiotami, naczyniami świątynnymi, nad mąką, winem, oliwą, kadzidłem i balsamem.
###### **1Krn 9,30**
 Niektórzy spośród synów kapłanów przygotowywali pachnące mieszanki balsamu.
###### **1Krn 9,31**
 Lewita Mattitiasz, pierworodny syn Szalluma Korachity, był odpowiedzialny za stały wypiek ciasta ofiarnego.
###### **1Krn 9,32**
 Niektórzy z Kehatytów, ich rodaków, byli odpowiedzialni za przygotowanie w każdy szabat chlebów poświęconych.
###### **1Krn 9,33**
 Pozostali, przywódcy lewickich rodów śpiewaczych, byli zwolnieni od innych zajęć. Przebywali oni na terenie świątyni, aby dniem i nocą służyć Panu.
###### **1Krn 9,34**
 Oto spis przywódców rodów Lewitów mieszkających w Jerozolimie.
###### **1Krn 9,35**
 W Gabaonie mieszkał Jeiel, ojciec Gabaona, wraz ze swą żoną o imieniu Maaka.
###### **1Krn 9,36**
 Jego pierworodnym synem był Abdon, a następni to: Sur, Kisz, Baal, Ner, Nadab,
###### **1Krn 9,37**
 Gedor, Achio, Zachariasz i Miklot.
###### **1Krn 9,38**
 Miklotowi urodził się Szimam. Oni również mieszkali w Jerozolimie ze swymi braćmi.
###### **1Krn 9,39**
 Ner był ojcem Kisza, a Kisz - Saula. Saul był ojcem Jonatana, Malkiszuy, Abinadaba i Eszbaala.
###### **1Krn 9,40**
 Jonatan był ojcem Meribbaala, a Meribbaal - ojcem Miki.
###### **1Krn 9,41**
 Synami Miki byli: Piton, Melek, Tarea i Achaz.
###### **1Krn 9,42**
 Achaz był ojcem Joaddy, a Joadda - Alemeta, Azmaweta i Zimriego. Zimri zaś był ojcem Mosy.
###### **1Krn 9,43**
 Mosa był ojcem Binei. Binea - ojcem Rafajasza. Rafajasz - ojcem Eleasy. Eleasa zaś - ojcem Asela.
###### **1Krn 9,44**
 Asel miał sześciu synów, oto ich imiona: Azrikam, Bokru, Izmael, Szeariasz, Obadiasz i Chanan. Ci właśnie byli synami Asela.
# 1Krn 9 BP
###### **1Krn 9,1**
 Wszyscy Izraelici byli spisani w rodowodach, które się znajdują w Księdze Królów Izraela. Juda z powodu swojej niewierności został uprowadzony do Babilonu.
###### **1Krn 9,2**
 Pierwszymi mieszkańcami, którzy [powrócili] do swych posiadłości i do miast swoich, byli Izraelici, kapłani, lewici i oddani na [służbę Świątyni].
###### **1Krn 9,3**
 W Jeruzalem zamieszkali następujący potomkowie Judy, Beniamina, Efraima i Manassego:
###### **1Krn 9,4**
 Utaj, syn Ammihuda, syna Omriego, syna Imriego, syna Baniego, z potomków Pereca, który był synem Judy.
###### **1Krn 9,5**
 Z [potomków] Sziloniego: pierworodny Asaja i jego synowie.
###### **1Krn 9,6**
 Z potomków Zeracha: Jeuel i bracia jego [razem] 690.
###### **1Krn 9,7**
 Z potomków Beniamina: Sallu, syn Meszullama, syna Hodawji, syna Hassenui;
###### **1Krn 9,8**
 dalej Jibneja, syn Jerochama, i Ela, syn Uzziego, który był synem Mikriego, a także Meszullam, syn Szefatji, który był synem Reuela, syna Jibnijji.
###### **1Krn 9,9**
 Braci ich według rodowodu było 956. a wszyscy oni byli naczelnikami swych rodów.
###### **1Krn 9,10**
 Spośród kapłanów [zamieszkali w Jeruzalem]: Jedaja, Jehojarib, Jakin
###### **1Krn 9,11**
 i Azarja, syn Chilkijji, syna Meszullama, syna Cadoka, syna Merajota, syna Achituba przełożonego w Domu Bożym.
###### **1Krn 9,12**
 Również Adaja, syn Jerochama, syna Paszchura, syna Malkijji, syna Masaja, syna Adiela, syna Jachzery, syna Meszullama, syna Meszillemita, syna Immera,
###### **1Krn 9,13**
 oraz bracia ich, którzy byli naczelnikami rodów, [w liczbie] 1760. [mężów] bardzo dzielnych w pełnieniu służby w Domu Bożym.
###### **1Krn 9,14**
 Spośród lewitów [zamieszkali w Jeruzalem]: Szemaja, syn Chaszszuba, syna Azrikama, syna Chaszabji, z potomków Merariego.
###### **1Krn 9,15**
 Bakbaker, Cheresz, Galal, Mattanja, syn Miki, syna Zikriego, syna Asafa,
###### **1Krn 9,16**
 Obadja, syn Szemaji, syna Galala, syna Jedutuna, oraz Berekja, syn Asy, syna Elkany, który mieszkał w osiedlach Netofatytów.
###### **1Krn 9,17**
 Następnie odźwierni: Szallum, Akkub, Talmon i Achiman, a ich brat Szallum był zwierzchnikiem
###### **1Krn 9,18**
 i aż dotąd [pełni straż] przy bramie Królewskiej od strony wschodniej. Ci byli odźwiernymi [według kolejności] zmian lewickich.
###### **1Krn 9,19**
 Szallum, syn Korego, syna Ebjasafa, syna Koracha, i bracia z domu jego ojca Korachici, pełnili służbę jako stróże progów Namiotu, a ojcowie ich byli stróżami wejścia do obozu Jahwe.
###### **1Krn 9,20**
 Pinchas, syn Eleazara, był niegdyś ich zwierzchnikiem. - Niech Jahwe będzie z nim! -
###### **1Krn 9,21**
 Zekarja, syn Meszelemji, był stróżem bramy Namiotu Zjednoczenia.
###### **1Krn 9,22**
 Wszystkich powołanych na stróżów bram było dwustu dwunastu. Oni to zostali zapisani w rodowodach swoich osiedli. Na urząd ten powołali ich ze względu na ich wierność: Dawid i Samuel "widzący".
###### **1Krn 9,23**
 Oni to oraz ich synowie trzymali straż przy bramach Domu Bożego i Domu Namiotu.
###### **1Krn 9,24**
 Trzymali oni straż z czterech stron: od wschodu, zachodu, północy i południa.
###### **1Krn 9,25**
 Bracia ich mieszkali w swoich osiedlach i winni byli od czasu do czasu przybyć do nich na siedem dni;
###### **1Krn 9,26**
 stałą bowiem służbę pełniło tylko czterech zwierzchników nad strażnikami. Byli oni lewitami i mieli pieczę nad zabudowaniami i skarbcem Domu Bożego.
###### **1Krn 9,27**
 Noce spędzali przy Domu Bożym, im bowiem była powierzona straż [nad Domem Bożym] i oni otwierali go co dzień rano.
###### **1Krn 9,28**
 Część spośród nich miała pieczę nad naczyniami [służącymi do] kultu; liczono je przy wnoszeniu i wynoszeniu.
###### **1Krn 9,29**
 Inni mieli pieczę nad sprzętami, nad wszystkimi sprzętami świętymi, [troszczyli się] o najprzedniejszą mąkę, wino, olej, kadzidło i wonności,
###### **1Krn 9,30**
 natomiast tylko synowie kapłanów mogli sporządzać pachnące olejki z wonności.
###### **1Krn 9,31**
 Jeden spośród lewitów, Mattitja, pierworodny Szalluma Korachity, czuwał nad przygotowaniem ofiarnego pieczywa.
###### **1Krn 9,32**
 Niektórzy ich bracia spośród Kehatytów troszczyli się o chleby ofiarowane [Bogu], które przygotowywali na każdy szabat.
###### **1Krn 9,33**
 Ci zaś, którzy byli śpiewakami - naczelnicy rodów lewickich mieszkali w pokojach [Świątyni] i byli wolni od innych zajęć, ze względu na służbę, która im przypadała we dnie i w nocy.
###### **1Krn 9,34**
 Byli oni naczelnikami rodów lewickich, naczelnikami według ich rodowodów. Naczelnicy ci mieszkali w Jeruzalem.
###### **1Krn 9,35**
 W Gibeonie mieszkał ojciec Gibeonitów Jeiel, a żona jego miała na imię Maaka.
###### **1Krn 9,36**
 Jego synem pierworodnym był Abdon, [następnymi] Cur, Kisz, Baal, Ner, Nadab,
###### **1Krn 9,37**
 Gedor, Achjo, Zekarja i Miklot.
###### **1Krn 9,38**
 Miklot był ojcem Szimama. Również oni wraz ze swymi braćmi mieszkali w Jeruzalem, naprzeciw swych braci.
###### **1Krn 9,39**
 Ner był ojcem Kisza, a Kisz ojcem Saula, a Saul ojcem Jonatana, Malkiszui, Abinadaba i Eszbaala.
###### **1Krn 9,40**
 Synem Jonatana był Meribbaal, a Meribbaal był ojcem Miki.
###### **1Krn 9,41**
 Synami Miki byli: Pitom, Melek, Tachrea,
###### **1Krn 9,42**
 Achaz zaś był ojcem Jary, a Jara był ojcem Alemeta, Azmaweta i Zimriego. Zimri był ojcem Mocy.
###### **1Krn 9,43**
 Mocą był ojcem Biny, którego synem był Refaja; jego synem był Elasa, który znów miał syna Acela.
###### **1Krn 9,44**
 Acel miał sześciu synów o takich imionach: Azrikam, Bokru, Jiszmael, Szearja, Obadja i Chanan. Oni to byli synami Acala.
# 1Krn 9 BR
###### **1Krn 9,1**
 W ten sposób wszyscy Izraelici zostali objęci swoimi rodowodami, a rodowody spisano w Księdze Królów Izraelskich. Natomiast synowie Judy, z powodu występków, których się dopuścili, zostali uprowadzeni do niewoli babilońskiej.
###### **1Krn 9,2**
 Pierwszymi mieszkańcami, którzy z czasem powrócili do swoich posiadłości, byli Izraelici, [przede wszystkim ich] kapłani, lewici oraz [inni] słudzy świątyni.
###### **1Krn 9,3**
 W Jerozolimie zamieszkali następujący potomkowie Judy, Beniamina, Efraima i Manassesa:
###### **1Krn 9,4**
 Utaj, syn Ammihuda, syna Omriego, syna Imriego, syna Baniego, który był jednym z synów Peresa, syna Judy.
###### **1Krn 9,5**
 Spośród Szilonitów: pierworodny Asajasz i jego synowie.
###### **1Krn 9,6**
 Spośród Zerachitów: Jeuel i sześciuset dziewięćdziesięciu ich braci.
###### **1Krn 9,7**
 Spośród synów Beniamina: Sallu, syn Meszullama, syna Hodawiasza, syna Hassenui,
###### **1Krn 9,8**
 Jibnejasz, syn Jerochama, Ela, syn Uzziego, syna Mikriego, Meszullam, syn Szefatiasza, syna Reuela, syna Jibniasza.
###### **1Krn 9,9**
 Wszystkich ich braci, spisanych w rodowodach, było dziewięciuset pięćdziesięciu sześciu. Wszyscy byli naczelnikami swoich rodów.
###### **1Krn 9,10**
 Z kapłanów [byli tam]: Jedajasz, Jojarib, Jakin,
###### **1Krn 9,11**
 Azariasz, syn Chilkiasza, syna Meszullama, syna Sadoka, syna Merajota, syna Achituba, który był zwierzchnikiem domu Bożego;
###### **1Krn 9,12**
 Adajasz, syn Jerochama, syna Paszchura, syna Malkiasza; Masaj, syn Adiela, syna Jachzery, syna Meszullama, syna Meszillemita, syna Immera.
###### **1Krn 9,13**
 Razem ze wszystkimi braćmi było ich tysiąc siedmiuset sześćdziesięciu. Wszyscy ci dzielni wojownicy byli zajęci obsługą domu Bożego.
###### **1Krn 9,14**
 Spośród lewitów: Szemajasz, syn Chaszszuba, syna Azrikama, syna Chaszabiasza, jednego z synów Merariego;
###### **1Krn 9,15**
 ponadto: Bakbakar, Cheresz, Galal, Mattaniasz, syn Miki, syna Zikriego, syna Asafa;
###### **1Krn 9,16**
 poza tym: Obadiasz, syn Szemajasza, syna Galala, syna Jedutuna, i Berekiasz, syn Asy, syna Elkany, do którego należały osiedla Netofatytów.
###### **1Krn 9,17**
 Wreszcie wśród odźwiernych byli tam: Szallum, Akkub, Talmon, Achiman oraz ich bracia. Ich przełożonym był Szallum
###### **1Krn 9,18**
 i jest nim po dzień dzisiejszy, pełniący służbę przy Bramie Królewskiej, po stronie wschodniej. Ci więc byli odźwiernymi w obozach lewitów.
###### **1Krn 9,19**
 Szallum, syn Korego, syna Ebiasafa, syna Koracha, i wszyscy jego bracia z domu jego ojca, Korachici, byli powołani do posługi w świątyni i pełnili swoją służbę u progów namiotu, a ich ojcowie strzegli wejścia do obozu Jahwe.
###### **1Krn 9,20**
 Kiedyś ich przełożonym był syn Eleazara Pinchas - Jahwe niech będzie z nim.
###### **1Krn 9,21**
 Zachariasz, syn Meszelemiasza, pełnił służbę odźwiernego przy wejściu do Namiotu Spotkania.
###### **1Krn 9,22**
 Mężów przeznaczonych do pełnienia straży przy bramach było dwustu dwunastu. Wszyscy byli zapisani w wykazach rodowych swoich miast, a ich urząd został wprowadzony przez Dawida i przez Samuela 'widzącego'.
###### **1Krn 9,23**
 Oni sami oraz ich synowie pozostawali zawsze przy bramach świątyni Jahwe i przy wejściu do namiotu, pełniąc tam swoja służbę.
###### **1Krn 9,24**
 Odźwierni byli rozmieszczeni z czterech stron [namiotu]: od wschodu, od zachodu, od północy i od południa.
###### **1Krn 9,25**
 Ich bracia, pozostający w swoich osiedlach, mieli do nich przychodzić od czasu do czasu i pozostawać z nimi przez tydzień.
###### **1Krn 9,26**
 Czterej przełożeni odźwiernych - zazwyczaj lewici - musieli bowiem nieustannie pełnić swoją służbę. Oni też mieli w swojej pieczy komnaty oraz skarbce domu Jahwe.
###### **1Krn 9,27**
 Mieszkali [w namiotach] wokół domu Bożego, którego pilnowali i który mieli otwierać każdego dnia rano.
###### **1Krn 9,28**
 Niektórzy spośród lewitów mieli pod swoją opieką przedmioty używane przy sprawowaniu kultu: oni wydawali te przedmioty i licząc starannie, przyjmowali z powrotem.
###### **1Krn 9,29**
 Inni nadzorcy sprzętu świątynnego czuwali nad wszystkimi naczyniami przybytku; troszczyli się o najczystszą mąkę i wino tudzież o oliwę, kadzidło i wszystkie wonności.
###### **1Krn 9,30**
 Synowie kapłanów przygotowywali mieszaninę z różnych rodzajów wonności.
###### **1Krn 9,31**
 Jeden z lewitów, Mattitiasz, pierworodny syn Szalluma Korachity, był odpowiedzialny za wypiek ciasta na różne ofiary.
###### **1Krn 9,32**
 Niektórzy spośród synów Kehata byli wyznaczeni do przygotowywania chlebów pokładnych na każdy szabat.
###### **1Krn 9,33**
 Tyle o śpiewakach, naczelnikach poszczególnych rodzin lewickich, którzy, zwolnieni od innych zajęć, pozostawali ciągle w komnatach [przyświątynnych], gdyż pełnili swoją służbę dniem i nocą.
###### **1Krn 9,34**
 Tyle o naczelnikach rodzin lewickich według ich rodowodów. Wszyscy oni mieszkali w Jerozolimie.
###### **1Krn 9,35**
 W Gibeonie żył Jejel, ojciec Gibeona. Jego żona miała na imię Maaka, a
###### **1Krn 9,36**
 synami Jejela byli: Abdon jako pierworodny, potem Sur, Kisz, Baal, Ner, Nadab,
###### **1Krn 9,37**
 Gedor, Achio, Zachariasz i Miklot.
###### **1Krn 9,38**
 Miklot był ojcem Szimmeama. Oni również, razem ze swymi braćmi, mieszkali w Jerozolimie, w pobliżu swych krewnych.
###### **1Krn 9,39**
 Ner był ojcem Kisza, Kisz ojcem Saula, Saul ojcem Jonatana, Malkiszui, Abinadaba i Eszbaala.
###### **1Krn 9,40**
 Synem Jonatana był Meribbaal, a Meribbaal był ojcem Miki.
###### **1Krn 9,41**
 Synami Miki byli: Piton, Melek i Tachrea.
###### **1Krn 9,42**
 Achaz był ojcem Jary, Jara ojcem Alemeta, Azmaweta i Zimriego, Zimri zaś ojcem Mosy.
###### **1Krn 9,43**
 Mosa był ojcem Binei, Binea ojcem Refajasza, Refajasz ojcem Eleasa, Eleas ojcem Asela.
###### **1Krn 9,44**
 Asel miał sześciu synów. Oto ich imiona: Azrikam, Bokru, Izmael, Szeariasz, Obadiasz i Chanan. Takie są imiona synów Asela.
# 1Krn 9 WUJ
###### **1Krn 9,1**
 Wszystek tedy lud Izraelski policzon jest: a suma ich napisana jest w księgach królów Izraelskich i Judzkich: a byli przeniesieni do Babilonu dla przestępstwa swego.
###### **1Krn 9,2**
 Lecz którzy pierwszy mieszkali w ósiadłościach w mieściech swoich? Izrael i kapłani i Lewitowie i Nathynejczykowie.
###### **1Krn 9,3**
 Mieszkali w Jeruzalem z synów Juda, i z synów Benjamin, z synów też Ephraim i Manasse.
###### **1Krn 9,4**
 Othej syn Ammiud syna Amri, syna Omrai, syna Bonni, z synów Phares syna Juda.
###### **1Krn 9,5**
 A z Silon Asaja pierworodny i synowie jego.
###### **1Krn 9,6**
 A z synów Zare: Jehuel i bracia ich, sześćset i dziewięćdziesiąt.
###### **1Krn 9,7**
 A z synów Benjamin: Salo syn Mosollam, syna Odwia, syna Asana:
###### **1Krn 9,8**
 I Jobania syn Jeroham i Ela syn Ozy, syna Mochory: i Mosollam syn Saphatiasza syna Rachuel, syna Jebaniasza,
###### **1Krn 9,9**
 I bracia fch według domów ich, dziewięć set pięćdziesiąt i sześć. Ci wszyscy książęta rodów wedle domów ojców swych.
###### **1Krn 9,10**
 Z kapłanów lepak: Jedaja, Jojarib, i Jachin:
###### **1Krn 9,11**
 Azariasz też syn Helcyasza, syna Moholam, syna Sadok, syna Marajoth, syna Achitob, kapłan wielki domu Bożego.
###### **1Krn 9,12**
 A Adajas syn Jeroham syna Phassur, syna Melchiasza i Maasai syn Adiel, syna Jezra, syna Mosollam, syna Mosolamith, syna Emer,
###### **1Krn 9,13**
 Braciej też ich książąt wedle domów ich, tysiąc siedm set i sześćdziesiąt, barzo mocnych siłą ku odprawowaniu dzieła posługi w domu Bożym.
###### **1Krn 9,14**
 A z Lewitów Semeja syn Hassub syna Esrikam, syna Hasebia z synów Merari.
###### **1Krn 9,15**
 Bakbakar też cieśla, i Galal, i Mathania syn Micha, syna Zechri, syna Asaph.
###### **1Krn 9,16**
 I Obdia syn Semejasza, syna Galal, syna Idithun i Barahia syn Asa, syna Elkana, który mieszkał w sieniach Nethophaty.
###### **1Krn 9,17**
 A odźwierni: Sellum, i Akkub, I Thelmon, i Ahimam: i brat ich Sellum, przedniejszy,
###### **1Krn 9,18**
 Aż do onego czasu, w bramie królewskiej na wschód słońca, strzegali na przemiany swe z synów Lewi.
###### **1Krn 9,19**
 A Sellum syn Kore, syna Abiasaph, syna Kore, z bracią swą, i z domem ojca swego, ci są Koritowie nad sprawą służby, stróże sieni przybytku: a familie ich na przemiany strzegące weścia obozu Pańskiego.
###### **1Krn 9,20**
 A Phinees syn Eleazarów był książęciem ich przed Panem.
###### **1Krn 9,21**
 Zacharyasz lepak syn Mosollama odźwierny drzwi przybytku świadectwa.
###### **1Krn 9,22**
 Ci wszyscy wybrani za odźwierne u drzwi, dwieście i dwanaście: i popisani we wsiach własnych: których postanowili Dawid i Samuel Widzący, w wierności ich.
###### **1Krn 9,23**
 Tak same, jako i syny ich we drzwiach domu Pańskiego, i w przybytku na przemianach swoich.
###### **1Krn 9,24**
 Wedle czterech wiatrów byli odźwierni: to jest na wschód, i na zachód, i na północy, i na południe.
###### **1Krn 9,25**
 A bracia ich mieszkali we wsiach, i przychodzili na soboty swoje od czasu aż do czasu.
###### **1Krn 9,26**
 Tym czterem Lewitom zwierzony był wszystek poczet odźwiernych, a byli nad gmachami i nad skarby domu Pańskiego.
###### **1Krn 9,27**
 Około kościoła też Pańskiego mieszkali na strażach swych: żeby czasu swego otwarzali rano drzwi.
###### **1Krn 9,28**
 Z tych też rodzaju byli nad naczyniem służby: bo pod liczbą naczynie i wnoszono i wynoszono.
###### **1Krn 9,29**
 Z tychże i którzy mieli powierzone naczynia świątnice, mieli w mocy białą mąkę, i wino, i oliwę, i kadzidło i wonności.
###### **1Krn 9,30**
 A synowie kapłanów olejki z wonnych rzeczy sprawowali.
###### **1Krn 9,31**
 A Mathathiasz Lewit pierworodny Sellum Korit, był przełożony nad temi rzeczami, które w panwiach smażono.
###### **1Krn 9,32**
 A z synów Kaath braciej ich, byli nad chleby pokładnemi, aby zawsze świeże na każdą Sobotę gotowali.
###### **1Krn 9,33**
 Ci są książęta śpiewaków wedle domów Lewitów, którzy w gmachach mieszkali, aby we dnie i w nocy ustawicznie swej posłudze dosyć czynili.
###### **1Krn 9,34**
 Głowy Lewitów, wedle domów swych przedniejszy, mieszkali w Jeruzalem.
###### **1Krn 9,35**
 A w Gabaonie mieszkali ojciec Gabaon Jehiel, a imię żony jego Maacha.
###### **1Krn 9,36**
 Syn pierworodny jego Abdon, i Sur, i Cis, i Baal, i Ner, i Nadab,
###### **1Krn 9,37**
 Gedor też i Ahio, i Zadbaryasz, i Macelloth,
###### **1Krn 9,38**
 A Macellot zrodził Samaan: ci mieszkali naprzeciwko braciej swej w Jeruzalem, z bracią swą.
###### **1Krn 9,39**
 A Ner zrodził. Cis: a Cis zrodził Saula: a Saul zrodził Jonathana, i Melchisua, i Abinadab, i Esbaal.
###### **1Krn 9,40**
 A syn Jonathanów Meribbaal: a Meribbaal zrodził Micha.
###### **1Krn 9,41**
 Synowie zaś Micha, Phithon, i Melech, i Tharaa, i Ahaz.
###### **1Krn 9,42**
 Ahaz lepak zrodził Jare, a Jara zrodził Alamath, i Asmoth, i Zamri, a Zamri zrodził Mosa,
###### **1Krn 9,43**
 Mosa lepak zrodził Banaa: którego syn Raphaja, zrodził Elasa, z którego poszedł Asel.
###### **1Krn 9,44**
 A Asel miał sześci synów, temi imiony, Ezrikam, Bokru, Ismahel, Saria, Obdia, i Hanan. Ci są synowie Asel.
