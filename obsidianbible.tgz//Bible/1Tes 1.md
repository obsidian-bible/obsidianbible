# 1Tes 1 BT5
###### **1Tes 1,1**
 Paweł, Sylwan i Tymoteusz do Kościoła Tesaloniczan w Bogu Ojcu i Panu Jezusie Chrystusie. Łaska wam i pokój!
###### **1Tes 1,2**
 Zawsze dziękujemy Bogu za was wszystkich, wspominając o was nieustannie w naszych modlitwach,
###### **1Tes 1,3**
 pomni przed Bogiem i Ojcem naszym na wasze dzieło wiary, na trud miłości i na wytrwałą nadzieję w Panu naszym, Jezusie Chrystusie.
###### **1Tes 1,4**
 Wiemy, bracia przez Boga umiłowani, o wybraniu waszym,
###### **1Tes 1,5**
 bo nasze głoszenie Ewangelii wśród was nie dokonało się samym tylko słowem, lecz mocą i [działaniem] Ducha Świętego oraz wielką siłą przekonania. Wiecie bowiem, jacy dla was byliśmy, przebywając wśród was.
###### **1Tes 1,6**
 A wy, przyjmując słowo pośród wielkiego ucisku, z radością Ducha Świętego, staliście się naśladowcami naszymi i Pana,
###### **1Tes 1,7**
 tak że okazaliście się wzorem dla wszystkich wierzących w Macedonii i Achai.
###### **1Tes 1,8**
 Dzięki wam nauka Pańska stała się głośna nie tylko w Macedonii i Achai, ale wasza wiara w Boga wszędzie dała się poznać, tak że nawet nie potrzebujemy o tym mówić.
###### **1Tes 1,9**
 Albowiem oni sami opowiadają o nas, jakiego to przyjęcia doznaliśmy od was i jak nawróciliście się od bożków do Boga, by służyć Bogu żywemu i prawdziwemu
###### **1Tes 1,10**
 i oczekiwać z niebios Jego Syna, którego wskrzesił z martwych, Jezusa, naszego wybawcę od nadchodzącego gniewu.
# 1Tes 1 PAU
###### **1Tes 1,1**
 Paweł, Sylwan i Tymoteusz do Kościoła Tesaloniczan w Bogu Ojcu i Panu Jezusie Chrystusie. Łaska wam i pokój!
###### **1Tes 1,2**
 Dziękujemy Bogu zawsze za was wszystkich i pamiętamy o was nieustannie w naszych modlitwach.
###### **1Tes 1,3**
 Wspominamy przed Bogiem, naszym Ojcem, wasze dzieło wiary, trud miłości i stałość nadziei w naszym Panu, Jezusie Chrystusie.
###### **1Tes 1,4**
 Wiecie, bracia umiłowani przez Boga, że On was wybrał.
###### **1Tes 1,5**
 Głosiliśmy wam bowiem Ewangelię nie tylko słowem, ale w mocy Ducha Świętego i z pełnym przekonaniem. Wiecie przecież, jacy byliśmy wobec was, gdy przebywaliśmy z wami.
###### **1Tes 1,6**
 Wy staliście się naśladowcami naszymi i Pana, kiedy przyjęliście słowo pośród licznych utrapień, radując się w Duchu Świętym.
###### **1Tes 1,7**
 Tak oto staliście się wzorem dla wszystkich wierzących w Macedonii i Achai.
###### **1Tes 1,8**
 Od was bowiem słowo Pańskie rozszerzyło się nie tylko w Macedonii i Achai, lecz wasza wiara w Boga stała się znana wszędzie, tak że my nie potrzebujemy o tym mówić.
###### **1Tes 1,9**
 Ludzie sami opowiadają, jak zostaliśmy przez was przyjęci i jak zwróciliście się ku Bogu, odwracając się od bożków, aby służyć Bogu żywemu i prawdziwemu
###### **1Tes 1,10**
 i oczekiwać z nieba Jego Syna, Jezusa, wskrzeszonego z martwych. On nas wybawi od nadchodzącego gniewu.
# 1Tes 1 BP
###### **1Tes 1,1**
 Paweł, Sylwan i Tymoteusz przesyłają pozdrowienia Kościołowi Tesaloniczan w Bogu Ojcu i Panu Jezusie Chrystusie: Łaska wam i pokój.
###### **1Tes 1,2**
 Składamy Bogu nieustanne dzięki za was wszystkich, wspominając was w naszych modlitwach.
###### **1Tes 1,3**
 Pamiętamy ciągle przed Bogiem i Ojcem naszym o dziełach, jakich dokonuje wasza wiara, o waszej czynnej miłości i wytrwałej nadziei w Panu naszym Jezusie Chrystusie.
###### **1Tes 1,4**
 Wiemy też, bracia umiłowani przez Boga, że należycie do Jego wybranych.
###### **1Tes 1,5**
 Ewangelię naszą głosiliśmy wam nie tylko słowami, lecz również mocą Ducha Świętego i z głębokim przekonaniem. Wiecie przecież, jakimi byliśmy dla was, gdyśmy u was przebywali.
###### **1Tes 1,6**
 A wy, przyjmując słowo w ucisku wielkim, z radością Ducha Świętego, zostaliście naśladowcami naszymi i naśladowcami Pana do tego stopnia,
###### **1Tes 1,7**
 że staliście się wzorem dla wszystkich wierzących w Macedonii i Achai.
###### **1Tes 1,8**
 Dzięki wam słowo Pańskie rozeszło się nie tylko po Macedonii i Achai, ale wieść o waszej wierze w Boga dotarła wszędzie, tak że nie trzeba nawet o tym mówić.
###### **1Tes 1,9**
 Ludzie bowiem sami opowiadają, jakiego przyjęcia doznaliśmy u was i jak, porzuciwszy bożków, zwróciliście się do Boga, żeby służyć Bogu żywemu i prawdziwemu
###### **1Tes 1,10**
 i oczekiwać przyjścia z niebios Jego Syna, którego Bóg wskrzesił z martwych, Jezusa. On nas obroni przed mającym nadejść gniewem.
# 1Tes 1 BR
###### **1Tes 1,1**
 Paweł, Sylwan i Tymoteusz do wiernych Kościoła tesalonickiego stanowiących jedno z Bogiem Ojcem i z Panem Jezusem Chrystusem. Niech zstąpi na was łaska i pokój.
###### **1Tes 1,2**
 Nie przestajemy dziękować Bogu za was, pamiętając ciągle w naszych modlitwach
###### **1Tes 1,3**
 przed Bogiem i Ojcem naszym o tym, jak bardzo czynna jest wasza wiara, jak piękne są dzieła waszej miłości i jak wytrwała jest nadzieja, którą pokładacie w Panu Jezusie Chrystusie.
###### **1Tes 1,4**
 Wiemy, bracia, że Bóg was umiłował i wybrał sobie.
###### **1Tes 1,5**
 Nie tylko bowiem głosiliśmy wam Ewangelię mocą naszego słowa, lecz korzystaliście także ze wsparcia Ducha Świętego, z pełnym przekonaniem o prawdziwości Ewangelii. Wiecie też, jak zabiegaliśmy o wasze dobro, kiedyśmy wśród was przebywali.
###### **1Tes 1,6**
 A wy, za naszym przykładem, staliście się naśladowcami Pana, bo przyjęliście słowo [Boże] pośród wielu ucisków, z radością, która pochodzi od Ducha Świętego.
###### **1Tes 1,7**
 W ten sposób okazaliście się wzorem dla wszystkich wiernych w Macedonii i Achai.
###### **1Tes 1,8**
 Dzięki wam bowiem słowo Pańskie mogło być usłyszane w Macedonii i Achai, a wieści o waszej wierze docierały wszędzie, tak że już nawet nie mamy potrzeby o tym mówić.
###### **1Tes 1,9**
 Wszyscy opowiadają o tym, jak to zostaliśmy przez was przyjęci i jak odwróciliście się od bożków pogańskich, by służyć Bogu żywemu i prawdziwemu,
###### **1Tes 1,10**
 oczekując na przyjście z nieba Jego Syna, Jezusa, zmartwychwstałego, naszego wybawcę od przyszłego gniewu.
# 1Tes 1 WUJ
###### **1Tes 1,1**
 Paweł i Sylwan i Tymotheusz kościołowi Thessaloniczan w Bogu Ojcu, i w Panie Jezusie Chrystusie. Łaska wam i pokój.
###### **1Tes 1,2**
 Dziękujemy Bogu zawsze za was wszystkie: wspominając was w modlitwach naszych bez przestanku:
###### **1Tes 1,3**
 Pamiętając na dzieło wiary waszej, i pracę, i miłość, i cierpliwość nadzieje Pana naszego Jezusa Chrystusa, przed Bogiem Ojcem naszym:
###### **1Tes 1,4**
 Wiedząc bracia umiłowani od Boga, o wybraniu waszem:
###### **1Tes 1,5**
 Iż Ewanielia nasza nie była do was tylko w mowie, ale i w mocy, i w Duchu świętym, i w zupełności wielkiej: jako wiecie jakiemiśmy byli między wami dla was.
###### **1Tes 1,6**
 A wy staliście się naśladowcami naszemi, i Pańskim: przyjąwszy słowo w wielkiem uciśnieniu, z weselem Ducha świętego:
###### **1Tes 1,7**
 Tak, iżeście się stali wzorem wszystkim wierzącym w Macedoniej i w Achajej.
###### **1Tes 1,8**
 Abowiem od was rozsławiona jest mowa Pańska: nie tylko w Macedoniej i w Achajej, ale na wszelkiem miejscu, wiara wasza, która jest ku Bogu rozeszła się tak, iż nam nie trzeba nic mówić.
###### **1Tes 1,9**
 Bo sami o nas opowiadają jakieśmy weszcie do was mieli: i jakoście się nawrócili do Boga od bałwanów abyście służyli Bogu żywemu i prawdziwemu,
###### **1Tes 1,10**
 I oczekiwali Syna jego, z niebios (którego wzbudził z martwych) Jezusa, który nas wyrwał od gniewu przyszłego.
# 1Tes 1 STERN
###### **1Tes 1,1**
 Sza'ul, Sila i Tymoteusz do Wspólnoty Mesjanicznej w Tesalonice, zjednoczonej z Bogiem Ojcem i Panem Jeszuą Mesjaszem: łaska wam i szalom.
###### **1Tes 1,2**
 Zawsze dziękujemy Bogu za was wszystkich, regularnie wymieniając was w modlitwach,
###### **1Tes 1,3**
 wspominając przed Bogiem, Ojcem naszym, to, co w was sprawił nasz Pan Jeszua Mesjasz - że ufność wasza rodzi czyny, miłość wasza - ciężki znój, a nadzieja wasza - wytrwałość.
###### **1Tes 1,4**
 Wiemy, bracia, że Bóg was ukochał i wybrał,
###### **1Tes 1,5**
 że Dobra Nowina, którąśmy przynieśli, stała się dla was sprawą nie samych tylko słów, ale i mocy, Ruach Ha-Kodesz i pełnego przeświadczenia, bo też wiecie, jak żyliśmy ze względu na was, gdyśmy byli wśród was.
###### **1Tes 1,6**
 Rzeczywiście staliście się naśladowcami naszymi i Pana i mimo że przechodziliście ciężki ucisk, przyjęliście Słowo z radością płynącą z Ruach Ha-Kodesz.
###### **1Tes 1,7**
 W ten sposób staliście się wzorem dla wszystkich wierzących w Macedonii i w Achai,
###### **1Tes 1,8**
 bo orędzie Pana rozbrzmiało nie tylko w Macedonii i Achai, ale wszędzie, gdzie dowiedziano się o waszej ufności do Boga. Skutek jest taki, że nie potrzebujemy nic mówić,
###### **1Tes 1,9**
 bo oni sami bez przerwy mówią nam o przyjęciu, jakie nam zgotowaliście, i jak od bałwanów odwróciliście się do Boga, aby służyć prawdziwemu Bogu, Temu, który żyje,
###### **1Tes 1,10**
 i wyczekiwać Jego Syna Jeszui, którego On wskrzesił z martwych, aż ukaże się z nieba i ocali nas przed nadciągającą furią sądu Bożego.
# 1Tes 1 TRO
###### **1Tes 1,1**
 **παυλος** *paulos* Paweł – [mały] [[G3972]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **σιλουανος** *silouanos* Sylwan – [leśny] [[G4610]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **τιμοθεος** *timotheos* Tymoteusz – [czczący Boga] [[G5095]] [[N-NSM]] **τη** *tē* [[G3588]] WTT-DSF **εκκλησια** *ekklēsia* zgromadzeniu – (społeczności) wywołanych [[G1577]] [[N-DSF]] **θεσσαλονικεων** *thessalonikeōn* Tesaloniczan [[G2331]] WTN-GPM **εν** *en* w [[G1722]] [[PREP]] **θεω** *theō* Bogu [[G2316]] WTN-DSM **πατρι** *patri* Ojcu [[G3962]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **χαρις** *charis* łaska [[G5485]] [[N-NSF]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **και** *kai* i [[G2532]] [[CONJ]] **ειρηνη** *eirēnē* pokój [[G1515]] [[N-NSF]] **απο** *apo* od [[G575]] [[PREP]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **πατρος** *patros* Ojca [[G3962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **και** *kai* i [[G2532]] [[CONJ]] **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **1Tes 1,2**
 **ευχαριστουμεν** *eucharistoumen* Dziękujemy [[G2168]] WTV-PAI-1P **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **παντοτε** *pantote* zawsze – w każdej chwili [[G3842]] [[ADV]] **περι** *peri* za [[G4012]] [[PREP]] **παντων** *pantōn* wszystkich [[G3956]] WTA-GPM **υμων** *hymōn* was [[G5216]] WTP-2GP **μνειαν** *mneian* wspomnienie [[G3417]] WTN-ASF **υμων** *hymōn* (o) was [[G5216]] WTP-2GP **ποιουμενοι** *poioumenoi* czyniąc [[G4160]] WTV-PMP-NPM **επι** *epi* w [[G1909]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPF **προσευχων** *proseuchōn* modlitwach [[G4335]] WTN-GPF **ημων** *hēmōn* naszych [[G2257]] WTP-1GP
###### **1Tes 1,3**
 **αδιαλειπτως** *adialeiptōs* nieustannie [[G89]] [[ADV]] **μνημονευοντες** *mnēmoneuontes* pamiętając – przypominając sobie [[G3421]] WTV-PAP-NPM **υμων** *hymōn* (o) waszym [[G5216]] WTP-2GP **του** *tou* [[G3588]] WTT-GSN **εργου** *ergou* dziele [[G2041]] [[N-GSN]] **της** *tēs* [[G3588]] [[T-GSF]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **του** *tou* [[G3588]] WTT-GSM **κοπου** *kopou* trudzie [[G2873]] [[N-GSM]] **της** *tēs* [[G3588]] [[T-GSF]] **αγαπης** *agapēs* miłości [[G26]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **της** *tēs* [[G3588]] [[T-GSF]] **υπομονης** *hypomonēs* wytrwałości [[G5281]] [[N-GSF]] **της** *tēs* [[G3588]] [[T-GSF]] **ελπιδος** *elpidos* nadziei [[G1680]] [[N-GSF]] **του** *tou* (co, do) [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **εμπροσθεν** *emprosthen* przed [[G1715]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Bogiem [[G2316]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **πατρος** *patros* Ojcem [[G3962]] [[N-GSM]] **ημων** *hēmōn* naszym [[G2257]] WTP-1GP
###### **1Tes 1,4**
 **ειδοτες** *eidotes* wiedząc [[G1492]] WTV-RAP-NPM **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **ηγαπημενοι** *ēgapēmenoi* którzy są umiłowani [[G25]] WTV-RPP-NPM **υπο** *hypo* przez [[G5259]] [[PREP]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **την** *tēn* [[G3588]] WTT-ASF **εκλογην** *eklogēn* wybranie [[G1589]] WTN-ASF **υμων** *hymōn* wasze [[G5216]] WTP-2GP
###### **1Tes 1,5**
 **οτι** *hoti* że [[G3754]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **ευαγγελιον** *euangelion* dobra nowina [[G2098]] WTN-NSN **ημων** *hēmōn* nasza [[G2257]] WTP-1GP **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εγενηθη** *egenēthē* stała się [[G1096]] [[V-AOI-3S]] **εις** *eis* w [[G1519]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **εν** *en* w [[G1722]] [[PREP]] **λογω** *logō* Słowie [[G3056]] WTN-DSM **μονον** *monon* jedynie – tylko [[G3440]] [[ADV]] **αλλα** *alla* ale [[G235]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **δυναμει** *dynamei* mocy [[G1411]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **πνευματι** *pneumati* Duchu [[G4151]] WTN-DSN **αγιω** *hagiō* Świętym [[G40]] WTA-DSN **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **πληροφορια** *plēroforia* pełni [[G4136]] [[N-DSF]] **πολλη** *pollē* wielkiej [[G4183]] WTA-DSF **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **οιδατε** *oidate* wiecie [[G1492]] WTV-RAI-2P **οιοι** *hoioi* jakimi [[G3634]] WTK-NPM **εγενηθημεν** *egenēthēmen* staliśmy się [[G1096]] WTV-AOI-1P **εν** *en* w [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **δι** *di* dla [[G1223]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP
###### **1Tes 1,6**
 **και** *kai* A [[G2532]] [[CONJ]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **μιμηται** *mimētai* naśladowcy [[G3402]] WTN-NPM **ημων** *hēmōn* nasi [[G2257]] WTP-1GP **εγενηθητε** *egenēthēte* staliście się [[G1096]] WTV-AOI-2P **και** *kai* i [[G2532]] [[CONJ]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **δεξαμενοι** *deksamenoi* przyjąwszy [[G1209]] WTV-ADP-NPM **τον** *ton* [[G3588]] [[T-ASM]] **λογον** *logon* Słowo [[G3056]] [[N-ASM]] **εν** *en* w [[G1722]] [[PREP]] **θλιψει** *thlipsei* ucisku – utrapieniu [[G2347]] [[N-DSF]] **πολλη** *pollē* wielkim [[G4183]] WTA-DSF **μετα** *meta* z [[G3326]] [[PREP]] **χαρας** *charas* radością [[G5479]] [[N-GSF]] **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **αγιου** *hagiou* Świętego [[G40]] [[A-GSN]]
###### **1Tes 1,7**
 **ωστε** *hōste* tak, że [[G5620]] [[CONJ]] **γενεσθαι** *genesthai* stać się [[G1096]] WTV-2ADN **υμας** *hymas* wam [[G5209]] WTP-2AP **τυπους** *typous* wzorem (dla) [[G5179]] [[N-APM]] **πασιν** *pasin* wszystkich [[G3956]] WTA-DPM **τοις** *tois* [[G3588]] WTT-DPM **πιστευουσιν** *pisteuousin* wierzących [[G4100]] WTV-PAP-DPM **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **μακεδονια** *makedonia* Macedonii [[G3109]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **τη** *tē* [[G3588]] WTT-DSF **αχαια** *achaia* Achai [[G882]] [[N-DSF]]
###### **1Tes 1,8**
 **αφ** *af* Od [[G575]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εξηχηται** *eksēchētai* jest rozniesione – rozbrzmiało [[G1837]] WTV-RPI-3S **ο** *ho* [[G3588]] [[T-NSM]] **λογος** *logos* Słowo [[G3056]] [[N-NSM]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ου** *ou* nie [[G3756]] [[PRT-N]] **μονον** *monon* jedynie – tylko [[G3440]] [[ADV]] **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **μακεδονια** *makedonia* Macedonii [[G3109]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **αχαια** *achaia* Achai [[G882]] [[N-DSF]] **αλλα** *alla* ale [[G235]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **παντι** *panti* każdym [[G3956]] WTA-DSM **τοπω** *topō* miejscu [[G5117]] WTN-DSM **η** *hē* [[G3588]] [[T-NSF]] **πιστις** *pistis* wiara [[G4102]] [[N-NSF]] **υμων** *hymōn* wasza [[G5216]] WTP-2GP **η** *hē* [[G3588]] [[T-NSF]] **προς** *pros* względem [[G4314]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **θεον** *theon* Boga [[G2316]] [[N-ASM]] **εξεληλυθεν** *ekselēlythen* wyszła [[G1831]] WTV-RAI-3S **ωστε** *hōste* że [[G5620]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **χρειαν** *chreian* potrzebę [[G5532]] WTN-ASF **ημας** *hēmas* nam [[G2248]] WTP-1AP **εχειν** *echein* mieć [[G2192]] WTV-PAN **λαλειν** *lalein* mówić [[G2980]] WTV-PAN **τι** *ti* coś [[G5100]] WTX-ASN
###### **1Tes 1,9**
 **αυτοι** *autoi* sami [[G846]] WTP-NPM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **περι** *peri* o [[G4012]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP **απαγγελλουσιν** *apangellousin* oznajmiają – informują [[G518]] WTV-PAI-3P **οποιαν** *hopoian* jakie [[G3697]] WTA-ASF **εισοδον** *eisodon* wejście [[G1529]] WTN-ASF **εσχομεν** *eschomen* mieliśmy [[G2192]] WTV-2AAI-1P **προς** *pros* do [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **και** *kai* i [[G2532]] [[CONJ]] **πως** *pōs* jak [[G4459]] [[ADV]] **επεστρεψατε** *epestrepsate* nawróciliście się – zawróciliście [[G1994]] WTV-AAI-2P **προς** *pros* do [[G4314]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **θεον** *theon* Boga [[G2316]] [[N-ASM]] **απο** *apo* od [[G575]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **ειδωλων** *eidōlōn* bożków – fałszywych bogów [[G1497]] WTN-GPN **δουλευειν** *douleuein* (by) być niewolnikami – (by) służyć [[G1398]] WTV-PAN **θεω** *theō* Bogu [[G2316]] WTN-DSM **ζωντι** *zōnti* żyjącemu [[G2198]] WTV-PAP-DSM **και** *kai* i [[G2532]] [[CONJ]] **αληθινω** *alēthinō* prawdziwemu [[G228]] WTA-DSM
###### **1Tes 1,10**
 **και** *kai* I [[G2532]] [[CONJ]] **αναμενειν** *anamenein* oczekiwać [[G362]] WTV-PAN **τον** *ton* [[G3588]] [[T-ASM]] **υιον** *hyion* Syna [[G5207]] [[N-ASM]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **εκ** *ek* z [[G1537]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **ουρανων** *ouranōn* niebios [[G3772]] WTN-GPM **ον** *hon* którego [[G3739]] WTR-ASM **ηγειρεν** *ēgeiren* wzbudził – podniósł [[G1453]] [[V-AAI-3S]] **εκ** *ek* z [[G1537]] [[PREP]] **νεκρων** *nekrōn* martwych [[G3498]] WTA-GPM **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]] **τον** *ton* [[G3588]] [[T-ASM]] **ρυομενον** *ryomenon* który ratuje – który wyrywa [[G4506]] WTV-PNP-ASM **ημας** *hēmas* nas [[G2248]] WTP-1AP **απο** *apo* z [[G575]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **οργης** *orgēs* gniewu [[G3709]] [[N-GSF]] **της** *tēs* [[G3588]] [[T-GSF]] **ερχομενης** *erchomenēs* przychodzącego [[G2064]] WTV-PNP-GSF
