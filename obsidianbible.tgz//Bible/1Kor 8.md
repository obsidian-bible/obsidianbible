# 1Kor 8 BT5
###### **1Kor 8,1**
 Jeżeli chodzi o pokarmy składane bożkom w ofierze, to oczywiście wszyscy posiadamy "wiedzę". Lecz "wiedza" unosi pychą, miłość zaś buduje.
###### **1Kor 8,2**
 Gdyby ktoś mniemał, że coś "wie", to jeszcze nie wie, jak wiedzieć należy.
###### **1Kor 8,3**
 Jeżeli zaś ktoś miłuje Boga, ten jest również uznany przez Boga.
###### **1Kor 8,4**
 Zatem jeśli chodzi o spożywanie pokarmów, które już były złożone bożkom na ofiarę, wiemy dobrze, że nie ma na świecie ani żadnych bożków, ani żadnego boga, prócz Boga jedynego.
###### **1Kor 8,5**
 A choćby byli na niebie i na ziemi tak zwani bogowie – jest zresztą mnóstwo takich bogów i panów –
###### **1Kor 8,6**
 dla nas istnieje tylko jeden Bóg, Ojciec, od którego wszystko pochodzi i dla którego my istniejemy, oraz jeden Pan, Jezus Chrystus, przez którego wszystko się stało i dzięki któremu także my jesteśmy.
###### **1Kor 8,7**
 Lecz nie wszystkim dana jest "wiedza". Niektórzy jeszcze do tej pory spożywają pokarmy bożkom złożone, w przekonaniu, że chodzi o bożka, i w ten sposób kala się ich słabe sumienie.
###### **1Kor 8,8**
 A przecież pokarm nie przybliży nas do Boga. Ani nie będziemy ubożsi, gdy przestaniemy jeść, ani też jedząc, nie wzrośniemy w znaczenie.
###### **1Kor 8,9**
 Baczcie jednak, aby to, iż wiecie, [jak należy postępować], nie stało się dla słabych powodem do zgorszenia.
###### **1Kor 8,10**
 Gdyby bowiem ujrzał ktoś ciebie, oświeconego "wiedzą", jak zasiadasz do uczty bałwochwalczej, czy to nie skłoni również kogoś o słabszym sumieniu do spożywania z ofiar składanych bożkom?
###### **1Kor 8,11**
 I tak to właśnie "wiedza" twoja sprowadza zgubę na słabego brata, za którego umarł Chrystus.
###### **1Kor 8,12**
 W ten sposób, grzesząc przeciwko braciom i rażąc ich słabe sumienia, grzeszycie przeciwko [samemu] Chrystusowi.
###### **1Kor 8,13**
 Jeżeli więc pokarm gorszy brata mego, przenigdy nie będę jadł mięsa, by nie gorszyć brata.
# 1Kor 8 PAU
###### **1Kor 8,1**
 Wszystkim wiadomo, że w sprawie ofiar pokarmowych, składanych bożkom, mamy swoje zdanie. Wiedza nadyma, miłość zaś buduje.
###### **1Kor 8,2**
 Jeśli komuś się wydaje, że coś wie, to jeszcze nie wie, jak trzeba wiedzieć.
###### **1Kor 8,3**
 Kto natomiast miłuje Boga, jest przez Niego uznany.
###### **1Kor 8,4**
 Jeśli chodzi o pokarmy składane bożkom, wiemy dobrze, że bożków w świecie nie ma, gdyż nie istnieją żadne bóstwa. Jest tylko jeden Bóg.
###### **1Kor 8,5**
 Chociaż mówi się o bogach w niebie i na ziemi, a nawet że jest wielu bogów i panów,
###### **1Kor 8,6**
 to dla nas jest tylko jeden Bóg Ojciec, od którego wszystko pochodzi, a my jesteśmy dla Niego. I jeden jest Pan, Jezus Chrystus, przez którego jest wszystko i my jesteśmy przez Niego.
###### **1Kor 8,7**
 Niestety nie wszyscy mają tę wiedzę. Niektórzy pod wpływem dotychczasowego przekonania związanego z bożkami spożywają te pokarmy, jakby one rzeczywiście były ofiarowane bożkom, a ich błędne sumienie się plami.
###### **1Kor 8,8**
 Pokarm jednak nie zbliża nas do Boga. Nie jedząc go, nie staniemy się słabsi, a spożywanie go nie wzmacnia nas.
###### **1Kor 8,9**
 Uważajcie jednak, by wasza wolność nie stała się powodem potknięcia dla słabszych.
###### **1Kor 8,10**
 Jeśli bowiem ktoś zobaczy ciebie mającego wiedzę, że zjadasz pokarmy ofiarowane bożkom, to czy sumienie tego, który jest słabszy, nie zezwoli mu na spożywanie pokarmów składanych bożkom?
###### **1Kor 8,11**
 W ten sposób twoja wiedza zgubi słabego brata, za którego umarł Chrystus.
###### **1Kor 8,12**
 Tak to, grzesząc przeciwko braciom i wykrzywiając ich wątpliwe sumienie, grzeszycie przeciw Chrystusowi.
###### **1Kor 8,13**
 Jeżeli więc pokarm przyczynia się do upadku mojego brata, nigdy nie będę jadł mięsa, by nie stać się dla mojego brata powodem upadku.
# 1Kor 8 BP
###### **1Kor 8,1**
 Z kolei sprawa ofiar składanych bożkom. Wiadomo, że wszyscy mamy o tym należytą wiedzę. Wiedza jednak nadyma pychą, miłość natomiast buduje.
###### **1Kor 8,2**
 Jeżeli komuś wydaje się nawet, że coś wie, to nie pojął on jeszcze, w jaki sposób należy z tej wiedzy korzystać.
###### **1Kor 8,3**
 A jeżeli ktoś kocha Boga, tego Bóg uznaje za swego.
###### **1Kor 8,4**
 W wypadku więc pokarmów pochodzących z ofiar składanych bożkom wiemy, że nie ma na świecie żadnego bożka i żadnego bóstwa. Jest tylko jeden Bóg.
###### **1Kor 8,5**
 Chociaż mówi się o istnieniu bogów czy to na niebie, czy to na ziemi - jakby rzeczywiście było wielu bogów i panów -
###### **1Kor 8,6**
 to dla nas istnieje tylko jeden Bóg Ojciec. Wszystko pochodzi od Niego, a my dla Niego żyjemy. Jeden jest również Pan - Jezus Chrystus, dzięki któremu wszystko istnieje i przez którego my także jesteśmy.
###### **1Kor 8,7**
 Nie wszyscy mają jednak odpowiednią wiedzę. Niektórzy na skutek przyzwyczajenia się do kultu bożków jeszcze teraz spożywają mięso pochodzące z ofiar w przekonaniu, że jest to pokarm sakralny, ofiarowany bożkom i na skutek tego ich błędne sumienie plami się grzechem.
###### **1Kor 8,8**
 Sam pokarm nie zbliża nas do Boga. Gdy przestajemy jeść, niczego nie tracimy, a gdy jemy, niczego nie zyskujemy.
###### **1Kor 8,9**
 Uważajcie jednak, aby wasza swoboda w tej dziedzinie nie była powodem zgorszenia dla tych, którzy mają błędne sumienie.
###### **1Kor 8,10**
 Gdyby bowiem ktoś o błędnym sumieniu zobaczył ciebie, który uchodzisz za posiadającego odpowiednią wiedzę, jak zasiadasz do stołu w świątyni pogańskiej, czy nie skłoniłoby to jego do spożywania pokarmów pochodzących z ofiar składanych bożkom?
###### **1Kor 8,11**
 Na skutek tego twoja wiedza sprowadziłaby zgubę na brata o błędnym sumieniu, za którego przecież umarł Chrystus.
###### **1Kor 8,12**
 W ten sposób grzesząc przeciw braciom i raniąc ich błędne sumienie, grzeszycie przeciw Chrystusowi.
###### **1Kor 8,13**
 Jeżeli więc pokarm gorszy mego brata, przenigdy nie będę jadł mięsa, aby go nie zgorszyć.
# 1Kor 8 BR
###### **1Kor 8,1**
 Jeżeli chodzi o pokarmy składane bożkom w ofierze, to oczywiście wszyscy posiadamy wiedzę. Lecz wiedza unosi pychą, miłość zaś buduje.
###### **1Kor 8,2**
 Gdyby ktoś mniemał, że coś wie, to jeszcze nie wie, jak wiedzieć należy.
###### **1Kor 8,3**
 Jeżeli zaś ktoś kocha Boga, to jest również uznany przez Boga.
###### **1Kor 8,4**
 Zatem jeśli chodzi o spożywanie pokarmów, które już były złożone bożkom na ofiarę, wiemy dobrze, że nie ma na świecie ani żadnych bożków, ani żadnego boga prócz Boga jedynego.
###### **1Kor 8,5**
 A choćby byli na niebie i na ziemi tak zwani bogowie - jest zresztą mnóstwo takich bogów i panów -
###### **1Kor 8,6**
 dla nas istnieje tylko jeden Bóg Ojciec, od którego wszystko pochodzi i dla którego my istniejemy, oraz jeden Pan Jezus Chrystus, przez którego wszystko się stało i dzięki któremu także my jesteśmy.
###### **1Kor 8,7**
 Lecz nie wszystkim dana jest wiedza. Niektórzy jeszcze do tej pory spożywają pokarmy bożkom złożone, w przekonaniu, że chodzi o bożka, i w ten sposób kala się ich słabe sumienie.
###### **1Kor 8,8**
 A przecież pokarm nie przybliży nas do Boga. Ani nie będziemy ubożsi, gdy przestaniemy jeść, ani też jedząc nie wzrośniemy w znaczenie.
###### **1Kor 8,9**
 Baczcie jednak, aby to, iż wiecie, jak należy postępować, nie stało się dla słabych powodem do zgorszenia.
###### **1Kor 8,10**
 Gdyby bowiem ujrzał ktoś ciebie, oświeconego wiedzą, jak zasiadasz do uczty bałwochwalczej, czyżby to nie skłoniło również kogoś słabego w sumieniu do spożywania z ofiar składanych bożkom?
###### **1Kor 8,11**
 I tak to właśnie wiedza twoja sprowadziłaby zgubę na słabego brata, za którego umarł Chrystus.
###### **1Kor 8,12**
 W ten sposób grzesząc przeciwko braciom i rażąc ich słabe sumienia, grzeszycie przeciwko samemu Chrystusowi.
###### **1Kor 8,13**
 Jeżeli więc pokarm gorszy brata mego, przenigdy nie będę jadł mięsa, by nie gorszyć brata.
# 1Kor 8 WUJ
###### **1Kor 8,1**
 A o tem co się bałwanom ofiaruje, wiemy, iż wszyscy umiejętność mamy. Umiejętność nadyma, a miłość buduje.
###### **1Kor 8,2**
 A jeśli kto mniema, żeby co umiał, jeszcze nie wie, jako mu umieć potrzeba.
###### **1Kor 8,3**
 Lecz jeśli kto miłuje Boga, ten poznan jest od niego.
###### **1Kor 8,4**
 A o pokarmiech, które bałwanom ofiarują, wiemy, iż bałwan nic nie jest na świecie, a iż żaden Bóg nie jest jedno jeden.
###### **1Kor 8,5**
 Abowiem choć są, które bogi zowią, bądź w niebie, bądź na ziemi (jakoż jest wiele bogów, i wiele panów).
###### **1Kor 8,6**
 Wszakże nam jeden Bóg, Ociec, z którego wszystko, a my do niego: i jeden Pan Jezus Chrystus, przez którego wszystko, a my przezeń.
###### **1Kor 8,7**
 Ale nie we wszystkich jest wiadomość. A niektórzy dotychmiast z sumieniem z strony bałwana, jako rzecz bałwanom ofiarowaną jadają: a sumienie ich będąc mdłe, pokalane bywa.
###### **1Kor 8,8**
 Lecz nas pokarm nie zaleca Bogu abowiem ani jeślibyśmy jedli, będziemy obfitować, ani jeślibyśmy nie jedli, schodzić nam będzie.
###### **1Kor 8,9**
 A patrzcie, aby snadź ta wolność wasza nie była ku zgorszeniu mdłym.
###### **1Kor 8,10**
 Abowiem, jeśliby kto ujrzał tego, który ma wiadomość, w bałwochwalnicy u stołu siedzącego: izali sumienie jego, będąc mdłe, nie weźmie pochopu do jedzenia rzeczy bałwanom ofiarowanych?
###### **1Kor 8,11**
 I zginie za oną twoją wiadomością brat mdły, dla którego Chrystus umarł?
###### **1Kor 8,12**
 A grzesząc tak przeciw braciej, i zraniając mdłe ich sumienie, przeciw Chrystusowi grzeszycie.
###### **1Kor 8,13**
 A przeto, jeśli pokarm obraża brata mego: nie będę jadł mięsa na wieki, abym brata mego nie zgorszył.
# 1Kor 8 STERN
###### **1Kor 8,1**
 Co zaś do pokarmów składanych na ofiarę bożkom: wiemy, że - jak to mówicie -"wszyscy mamy wiedzę". Owszem, tak jest, ale "wiedza" nadyma człowieka pychą; miłość tymczasem buduje.
###### **1Kor 8,2**
 Człowiek, który sądzi, że coś "wie", nie wie jeszcze tego tak, jak powinien.
###### **1Kor 8,3**
 Jednakże jeśli ktoś kocha Boga, Bóg zna go.
###### **1Kor 8,4**
 Co się zatem tyczy spożywania pokarmów poświęconych bożkom, "wiemy", że - jak powiadacie - "bożek nie istnieje naprawdę na świecie, a jest tylko jeden Bóg".
###### **1Kor 8,5**
 Bo nawet jeśli są tak zwani bogowie, już to w niebie, już to na ziemi - bo w istocie "bogów" i "panów" jest w bród -
###### **1Kor 8,6**
 to dla nas jeden jest tylko Bóg, Ojciec, od którego wszystko pochodzi i dla którego istniejemy, oraz jeden Pan, Jeszua Mesjasz, przez którego wszystko zostało stworzone i przez którego mamy istnienie.
###### **1Kor 8,7**
 Nie każdy jednak ma tę wiedzę. Ponadto niektórzy ludzie są wciąż jeszcze tak przyzwyczajeni do bożków, że jedząc pokarm, który był im poświęcony, wyobrażają sobie, że bożek wywarł nań rzeczywiście jakiś wpływ; i ich sumienie jako słabe zostaje pokalane.
###### **1Kor 8,8**
 A przecież pokarm nie polepszy naszych stosunków z Bogiem - nie będą ani uboższe, gdy się powstrzymamy, ani bogatsze, gdy zjemy.
###### **1Kor 8,9**
 Uważajcie jednak, żeby wasze panowanie nad sytuacją nie stało się zgorszeniem dla słabych.
###### **1Kor 8,10**
 Wy tę "wiedzę" macie; ale przypuśćmy, że ktoś o słabym sumieniu zobaczy, jak siedzicie i posilacie się w świątyni bożka. Czyż nie zostanie opacznie podbudowany, aby spożywać ten pokarm poświęcony bożkom?
###### **1Kor 8,11**
 I tak przez twoją "wiedzę" słaby ten człowiek zostanie zgubiony - brat, za którego umarł Mesjasz.
###### **1Kor 8,12**
 Dlatego kiedy grzeszysz przeciw bratu, raniąc jego słabe sumienie, grzeszysz przeciw Mesjaszowi!
###### **1Kor 8,13**
 Krótko mówiąc, jeśli pokarm miałby być pułapką dla mojego brata, nigdy już nie zjem mięsa, żeby czasem nie przywieść brata do grzechu.
# 1Kor 8 TRO
###### **1Kor 8,1**
 **περι** *peri* O [[G4012]] [[PREP]] **δε** *de* zaś [[G1161]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPN **ειδωλοθυτων** *eidōlothytōn* ofiarowanych bóstwom – ofiarowanych wizerunkom [[G1494]] WTA-GPN **οιδαμεν** *oidamen* wiemy [[G1492]] WTV-RAI-1P **οτι** *hoti* że [[G3754]] [[CONJ]] **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **γνωσιν** *gnōsin* poznanie – wiedzę [[G1108]] WTN-ASF **εχομεν** *echomen* mamy [[G2192]] WTV-PAI-1P **η** *hē* [[G3588]] [[T-NSF]] **γνωσις** *gnōsis* poznanie – wiedza [[G1108]] [[N-NSF]] **φυσιοι** *fysioi* nadyma [[G5448]] WTV-PAI-3S **η** *hē* [[G3588]] [[T-NSF]] **δε** *de* zaś [[G1161]] [[CONJ]] **αγαπη** *agapē* miłość [[G26]] [[N-NSF]] **οικοδομει** *oikodomei* buduje [[G3618]] WTV-PAI-3S
###### **1Kor 8,2**
 **ει** *ei* Jeśli [[G1487]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **τις** *tis* ktoś [[G5100]] WTX-NSM **δοκει** *dokei* uważa – mniema [[G1380]] WTV-PAI-3S **ειδεναι** *eidenai* (że) znać [[G1492]] WTV-RAN **τι** *ti* coś [[G5100]] WTX-ASN **ουδεπω** *oudepō* jeszcze [[G3764]] [[ADV]] **ουδεν** *ouden* niczego [[G3762]] WTA-ASN **εγνωκεν** *egnōken* zna [[G1097]] WTV-RAI-3S **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **δει** *dei* trzeba – jest konieczne [[G1163]] WTV-PQI-3S **γνωναι** *gnōnai* poznać [[G1097]] [[V-2AAN]]
###### **1Kor 8,3**
 **ει** *ei* Jeśli [[G1487]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **τις** *tis* ktoś [[G5100]] WTX-NSM **αγαπα** *agapa* miłuje [[G25]] WTV-PAI-3S **τον** *ton* [[G3588]] [[T-ASM]] **θεον** *theon* Boga [[G2316]] [[N-ASM]] **ουτος** *houtos* ten [[G3778]] WTD-NSM **εγνωσται** *egnōstai* jest poznany [[G1097]] WTV-RPI-3S **υπ** *hyp* przez [[G5259]] [[PREP]] **αυτου** *autou* Niego [[G846]] [[P-GSM]]
###### **1Kor 8,4**
 **περι** *peri* O [[G4012]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **βρωσεως** *brōseōs* pokarmach [[G1035]] [[N-GSF]] **ουν** *oun* więc [[G3767]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPN **ειδωλοθυτων** *eidōlothytōn* ofiarowanych bóstwom – ofiarowanych wizerunkom [[G1494]] WTA-GPN **οιδαμεν** *oidamen* wiemy [[G1492]] WTV-RAI-1P **οτι** *hoti* że [[G3754]] [[CONJ]] **ουδεν** *ouden* niczym [[G3762]] WTA-NSN **ειδωλον** *eidōlon* bożek – fałszywy bóg [[G1497]] WTN-NSN **εν** *en* w [[G1722]] [[PREP]] **κοσμω** *kosmō* świecie [[G2889]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **οτι** *hoti* że [[G3754]] [[CONJ]] **ουδεις** *oudeis* żaden [[G3762]] [[A-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ετερος** *heteros* inny [[G2087]] [[A-NSM]] **ει** *ei* jeśli [[G1487]] WTCOND **μη** *mē* nie [[G3361]] [[PRT-N]] **εις** *heis* Jeden [[G1520]] [[A-NSM]]
###### **1Kor 8,5**
 **και** *kai* A [[G2532]] [[CONJ]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ειπερ** *eiper* jeśli właśnie [[G1512]] WTCOND **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **λεγομενοι** *legomenoi* którzy są nazywani [[G3004]] WTV-PPP-NPM **θεοι** *theoi* bogowie [[G2316]] WTN-NPM **ειτε** *eite* czy to [[G1535]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **ουρανω** *ouranō* niebie [[G3772]] WTN-DSM **ειτε** *eite* czy to [[G1535]] [[CONJ]] **επι** *epi* na [[G1909]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]] **ωσπερ** *hōsper* tak, jak [[G5618]] [[ADV]] **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **θεοι** *theoi* bogowie [[G2316]] WTN-NPM **πολλοι** *polloi* liczni – wielu [[G4183]] WTA-NPM **και** *kai* i [[G2532]] [[CONJ]] **κυριοι** *kyrioi* panowie [[G2962]] WTN-NPM **πολλοι** *polloi* liczni – wielu [[G4183]] WTA-NPM
###### **1Kor 8,6**
 **αλλ** *all* ale [[G235]] [[CONJ]] **ημιν** *hēmin* nam [[G2254]] WTP-1DP **εις** *heis* jeden [[G1520]] [[A-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **πατηρ** *patēr* Ojciec [[G3962]] [[N-NSM]] **εξ** *eks* od [[G1537]] [[PREP]] **ου** *hou* którego [[G3739]] WTR-GSM **τα** *ta* [[G3588]] WTT-NPN **παντα** *panta* wszystkie [[G3956]] WTA-NPN **και** *kai* i [[G2532]] [[CONJ]] **ημεις** *hēmeis* my [[G2249]] WTP-1NP **εις** *eis* do [[G1519]] [[PREP]] **αυτον** *auton* Niego [[G846]] WTP-ASM **και** *kai* i [[G2532]] [[CONJ]] **εις** *heis* jeden [[G1520]] [[A-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **ιησους** *iēsous* Jezus – [JHWH jest zbawieniem] [[G2424]] [[N-NSM]] **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **δι** *di* przez [[G1223]] [[PREP]] **ου** *hou* którego [[G3739]] WTR-GSM **τα** *ta* [[G3588]] WTT-NPN **παντα** *panta* wszystkie [[G3956]] WTA-NPN **και** *kai* i [[G2532]] [[CONJ]] **ημεις** *hēmeis* my [[G2249]] WTP-1NP **δι** *di* przez [[G1223]] [[PREP]] **αυτου** *autou* Niego [[G846]] [[P-GSM]]
###### **1Kor 8,7**
 **αλλ** *all* Ale [[G235]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εν** *en* we [[G1722]] [[PREP]] **πασιν** *pasin* wszystkich [[G3956]] WTA-DPM **η** *hē* (to) [[G3588]] [[T-NSF]] **γνωσις** *gnōsis* poznanie – wiedza [[G1108]] [[N-NSF]] **τινες** *tines* niektórzy – ktoś [[G5100]] WTX-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **τη** *tē* (z) [[G3588]] WTT-DSF **συνειδησει** *syneidēsei* sumienia [[G4893]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSN **ειδωλου** *eidōlou* bożka – fałszywego boga [[G1497]] [[N-GSN]] **εως** *heōs* aż do [[G2193]] [[CONJ]] **αρτι** *arti* teraz [[G737]] [[ADV]] **ως** *hōs* jak [[G5613]] [[ADV]] **ειδωλοθυτον** *eidōlothyton* ofiarowane bóstwu – ofiarowane wizerunkowi [[G1494]] WTA-NSN **εσθιουσιν** *esthiousin* jedzą [[G2068]] WTV-PAI-3P **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **συνειδησις** *syneidēsis* sumienie [[G4893]] [[N-NSF]] **αυτων** *autōn* ich [[G846]] WTP-GPM **ασθενης** *asthenēs* słabe – bezsilne [[G772]] WTA-NSF **ουσα** *ousa* będąc [[G5607]] WTV-PXP-NSF **μολυνεται** *molynetai* jest splamione [[G3435]] WTV-PPI-3S
###### **1Kor 8,8**
 **βρωμα** *brōma* Pokarm [[G1033]] WTN-NSN **δε** *de* zaś [[G1161]] [[CONJ]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **ου** *ou* nie [[G3756]] [[PRT-N]] **παριστησιν** *paristēsin* stawia przy [[G3936]] WTV-PAI-3S **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **ουτε** *oute* ani [[G3777]] [[CONJ]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εαν** *ean* jeśli [[G1437]] WTCOND **φαγωμεν** *fagōmen* zjedlibyśmy [[G5315]] WTV-2AAS-1P **περισσευομεν** *perisseuomen* obfitujemy [[G4052]] WTV-PAI-1P **ουτε** *oute* ani [[G3777]] [[CONJ]] **εαν** *ean* jeśli [[G1437]] WTCOND **μη** *mē* nie [[G3361]] [[PRT-N]] **φαγωμεν** *fagōmen* zjedlibyśmy [[G5315]] WTV-2AAS-1P **υστερουμεθα** *hysteroumetha* jesteśmy w niedostatku – jesteśmy pozbawieni [[G5302]] WTV-PPI-1P
###### **1Kor 8,9**
 **βλεπετε** *blepete* Uważajcie – Patrzcie [[G991]] WTV-PAM-2P **δε** *de* zaś [[G1161]] [[CONJ]] **μηπως** *mēpōs* aby czasem nie – aby nie jakoś [[G3381]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **εξουσια** *eksousia* prawo – władza [[G1849]] [[N-NSF]] **υμων** *hymōn* wasze [[G5216]] WTP-2GP **αυτη** *hautē* to [[G3778]] WTD-NSF **προσκομμα** *proskomma* potknięcie się [[G4348]] WTN-NSN **γενηται** *genētai* stałaby się [[G1096]] WTV-2ADS-3S **τοις** *tois* (dla) [[G3588]] WTT-DPM **ασθενουσιν** *asthenousin* którzy są słabi – którzy są bez siły [[G770]] WTV-PAP-DPM
###### **1Kor 8,10**
 **εαν** *ean* Jeśli [[G1437]] WTCOND **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **τις** *tis* ktoś [[G5100]] WTX-NSM **ιδη** *idē* zobaczyłby [[G1492]] WTV-2AAS-3S **σε** *se* cię [[G4571]] WTP-2AS **τον** *ton* [[G3588]] [[T-ASM]] **εχοντα** *echonta* mającego [[G2192]] WTV-PAP-ASM **γνωσιν** *gnōsin* poznanie – wiedzę [[G1108]] WTN-ASF **εν** *en* w [[G1722]] [[PREP]] **ειδωλειω** *eidōleiō* świątyni bogów – miejscu wizerunków [[G1493]] WTN-DSN **κατακειμενον** *katakeimenon* leżącego [[G2621]] WTV-PNP-ASM **ουχι** *ouchi* czyż nie [[G3780]] WTPRT-I **η** *hē* [[G3588]] [[T-NSF]] **συνειδησις** *syneidēsis* sumienie [[G4893]] [[N-NSF]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **ασθενους** *asthenous* słabe – bezsilne [[G772]] WTA-GSM **οντος** *ontos* będące [[G5607]] WTV-PXP-GSM **οικοδομηθησεται** *oikodomēthēsetai* zostanie zbudowane [[G3618]] WTV-FPI-3S **εις** *eis* do [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **τα** *ta* [[G3588]] WTT-APN **ειδωλοθυτα** *eidōlothyta* ofiarowanych bóstwom – ofiarowanych wizerunkom [[G1494]] WTA-APN **εσθιειν** *esthiein* jeść [[G2068]] WTV-PAN
###### **1Kor 8,11**
 **και** *kai* i [[G2532]] [[CONJ]] **απολειται** *apoleitai* będzie gubiony [[G622]] WTV-2FMI-3S **ο** *ho* [[G3588]] [[T-NSM]] **ασθενων** *asthenōn* który jest słaby – będący bez siły [[G770]] [[V-PAP-NSM]] **αδελφος** *adelfos* brat [[G80]] [[N-NSM]] **επι** *epi* w [[G1909]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **ση** *sē* twoim [[G4674]] WTS-2DSF **γνωσει** *gnōsei* poznaniu – wiedzy [[G1108]] [[N-DSF]] **δι** *di* przez [[G1223]] [[PREP]] **ον** *hon* którego [[G3739]] WTR-ASM **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **απεθανεν** *apethanen* umarł [[G599]] WTV-2AAI-3S
###### **1Kor 8,12**
 **ουτως** *houtōs* Tak [[G3779]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **αμαρτανοντες** *hamartanontes* grzesząc [[G264]] WTV-PAP-NPM **εις** *eis* wśród [[G1519]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **αδελφους** *adelfous* braci [[G80]] [[N-APM]] **και** *kai* i [[G2532]] [[CONJ]] **τυπτοντες** *typtontes* uderzając [[G5180]] WTV-PAP-NPM **αυτων** *autōn* ich [[G846]] WTP-GPM **την** *tēn* [[G3588]] WTT-ASF **συνειδησιν** *syneidēsin* sumienie [[G4893]] WTN-ASF **ασθενουσαν** *asthenousan* które jest słabe – będące bez siły [[G770]] WTV-PAP-ASF **εις** *eis* w [[G1519]] [[PREP]] **χριστον** *christon* Pomazańcu [[G5547]] [[N-ASM]] **αμαρτανετε** *hamartanete* grzeszycie [[G264]] WTV-PAI-2P
###### **1Kor 8,13**
 **διοπερ** *dioper* Przeto – Dlatego [[G1355]] [[CONJ]] **ει** *ei* jeśli [[G1487]] WTCOND **βρωμα** *brōma* pokarm [[G1033]] WTN-NSN **σκανδαλιζει** *skandalizei* gorszy – prowadzi do obrazy [[G4624]] WTV-PAI-3S **τον** *ton* [[G3588]] [[T-ASM]] **αδελφον** *adelfon* brata [[G80]] [[N-ASM]] **μου** *mou* mojego [[G3450]] WTP-1GS **ου** *ou* nie [[G3756]] [[PRT-N]] **μη** *mē* [[G3361]] [[PRT-N]] **φαγω** *fagō* zjadłbym [[G5315]] WTV-2AAS-1S **κρεα** *krea* mięsa [[G2907]] WTN-APN **εις** *eis* na [[G1519]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **αιωνα** *aiōna* wiek [[G165]] [[N-ASM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **τον** *ton* [[G3588]] [[T-ASM]] **αδελφον** *adelfon* brata [[G80]] [[N-ASM]] **μου** *mou* mojego [[G3450]] WTP-1GS **σκανδαλισω** *skandalisō* zgorszyłbym – uraziłbym [[G4624]] WTV-AAS-1S
