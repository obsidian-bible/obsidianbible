# Hi 2 BT5
###### **Hi 2,1**
 Pewnego dnia, gdy synowie Boży poszli stawić się przed Panem, szatan też poszedł z nimi.
###### **Hi 2,2**
 I rzekł Pan do szatana: «***Skąd przychodzisz?***» Szatan odpowiedział Panu: «***Przemierzałem ziemię i wędrowałem po niej***».
###### **Hi 2,3**
 Rzekł Pan szatanowi: «***Zwróciłeś uwagę na sługę mego, Hioba? Bo nie ma na całej ziemi drugiego, kto by był tak prawy, sprawiedliwy, bogobojny i unikający zła jak on. Jeszcze trwa w swej prawości, choć mnie nakłoniłeś do zrujnowania go, na próżno***».
###### **Hi 2,4**
 Na to szatan odpowiedział Panu: «***Skóra za skórę. Wszystko, co człowiek posiada, odda za swoje życie.***
###### **Hi 2,5**
 ***Wyciągnij, proszę, rękę i dotknij jego kości i ciała. Na pewno Ci w twarz będzie złorzeczył***».
###### **Hi 2,6**
 I rzekł Pan do szatana: «***Oto jest w twej mocy. Życie mu tylko zachowaj!***»
###### **Hi 2,7**
 Odszedł szatan sprzed oblicza Pańskiego i obsypał Hioba trądem złośliwym, od palca stopy aż po czubek głowy.
###### **Hi 2,8**
 [Hiob] wziął więc skorupę, by się nią drapać, siedząc na popiele.
###### **Hi 2,9**
 Rzekła mu żona: «***Jeszcze trwasz mocno w swej prawości? Złorzecz Bogu i umieraj!***»
###### **Hi 2,10**
 Hiob jej odpowiedział: «***Mówisz jak kobieta szalona. Dobro przyjęliśmy z ręki Boga. Czemu zła przyjąć nie możemy?***» W tym wszystkim Hiob nie zgrzeszył swymi ustami.
###### **Hi 2,11**
 Usłyszeli trzej przyjaciele Hioba o wszystkim, co na niego spadło, i przyszli, każdy z nich z miejscowości swojej: Elifaz z Temanu, Bildad z Szuach i Sofar z Naamy. Porozumieli się, by przyjść, boleć nad nim i pocieszać go.
###### **Hi 2,12**
 Skoro jednak spojrzeli z daleka, nie mogli go poznać. Wykrzyknęli i zapłakali. Każdy z nich rozdarł swe szaty i rzucał proch w górę, na głowę.
###### **Hi 2,13**
 Siedzieli z nim na ziemi siedem dni i siedem nocy, nikt nie wyrzekł słowa, bo widzieli ogrom jego bólu.
# Hi 2 PAU
###### **Hi 2,1**
 Zdarzyło się któregoś dnia, że synowie Boży przybyli, aby się stawić przed PANEM. Przybył także szatan i stanął pośród nich, aby się stawić przed PANEM.
###### **Hi 2,2**
 PAN zapytał szatana: „Skąd przychodzisz?”. Szatan odpowiedział PANU: „Okrążyłem ziemię i przemierzyłem ją wzdłuż i wszerz”.
###### **Hi 2,3**
 Na co PAN go spytał: „Czy zwróciłeś uwagę na mojego sługę Hioba? Nie ma przecież na ziemi drugiego człowieka tak doskonałego i prawego, bogobojnego i stroniącego od zła. Trwa on w swojej doskonałości, choć nakłoniłeś Mnie, abym go niszczył bez powodu”.
###### **Hi 2,4**
 Szatan odpowiedział PANU: „Coś za coś; wszystko, co człowiek posiada, odda za swoje życie.
###### **Hi 2,5**
 Wyciągnij tylko rękę i dotknij jego ciała i kości. Na pewno będzie Ci w twarz złorzeczył”.
###### **Hi 2,6**
 Na to PAN rzekł do szatana: „Oto jest w twoich rękach. Ale życia mu nie odbieraj”.
###### **Hi 2,7**
 I odszedł szatan od PANA. Potem szatan poraził Hioba bolesnymi wrzodami na całym ciele.
###### **Hi 2,8**
 Wziął więc Hiob skorupę, aby się nią drapać, i usiadł w popiele.
###### **Hi 2,9**
 I rzekła do niego żona: „Nadal chcesz trwać w swej doskonałości? Złorzecz Bogu i umieraj!”.
###### **Hi 2,10**
 Ale on jej odparł: „Mówisz jak głupia. Jeśli przyjmowaliśmy od Boga dobro, dlaczego nie mielibyśmy przyjąć zła?”. Także wtedy Hiob nie zgrzeszył swoimi wargami.
###### **Hi 2,11**
 Trzej przyjaciele Hioba usłyszeli o całym nieszczęściu, które spadło na niego, i przyszli, każdy ze swej krainy: Elifaz z Temanu, Bildad z Szuach i Sofar z Naamy. Umówili się bowiem, że przyjdą, aby okazać mu współczucie i pocieszyć go.
###### **Hi 2,12**
 Już z daleka dostrzegli go, ale nie poznali. Podnieśli krzyk i zaczęli płakać, rozdzierając szaty. Potem posypali głowy popiołem.
###### **Hi 2,13**
 Siedem dni i siedem nocy siedzieli przy nim na ziemi. Żaden z nich nie wypowiedział do niego nawet jednego słowa, bo widzieli, że jego ból jest bardzo wielki.
# Hi 2 BP
###### **Hi 2,1**
 A kiedy [znowu] pewnego dnia synowie Boży przyszli, aby stawić się przed Jahwe, przyszedł z nimi szatan, by także stawić się przed Jahwe.
###### **Hi 2,2**
 A Jahwe rzekł do szatana: Skąd przychodzisz? Szatan odpowiedział Jahwe: Krążyłem po ziemi i wędrowałem po niej.
###### **Hi 2,3**
 Na to Jahwe zapytał szatana: Czyś dostrzegł tam sługę mojego Joba? Bo nie ma na ziemi nikogo podobnego jemu. Jest to człowiek bez skazy, prawy, bojący się Boga i unikający zła. On trwa w swej nieskazitelności, mimo że pobudziłeś mnie przeciw niemu, abym go doświadczył bez powodu.
###### **Hi 2,4**
 A na to szatan odpowiedział Jahwe: Skórę za skórę i wszystko, cokolwiek człowiek posiada, odda, aby ocalić swoje życie.
###### **Hi 2,5**
 Ale wyciągnij jeszcze raz na niego swą rękę, dotknij jego kości i ciała, a zaręczam Cię, że w oczy będzie Ci złorzeczył.
###### **Hi 2,6**
 I rzekł Jahwe do szatana: Oto daję ci go w twoje ręce, tylko życie mu zachowaj.
###### **Hi 2,7**
 I odszedł szatan sprzed oblicza Jahwe, i dotknął Joba złośliwymi wrzodami od palców stopy aż po czubek głowy.
###### **Hi 2,8**
 A [Job] wziął skorupę, aby się nią drapać, i usiadł na popiele.
###### **Hi 2,9**
 I rzekła mu jego żona: Wciąż trwasz jeszcze w swej nieskazitelności? Złorzecz Bogu i umieraj.
###### **Hi 2,10**
 Odpowiedział jej Job: Mówisz, jakbyś była szalona. Jeśli przyjmowaliśmy od Boga dobro, dlaczego nie mielibyśmy przyjąć zła? Także w tym wszystkim Job nie zgrzeszył swoją mową.
###### **Hi 2,11**
 Trzej przyjaciele Joba usłyszeli o całym nieszczęściu, które spadło na niego, i przyszli do niego, każdy ze swojego kraju: Elifaz z Temanu, Bildad z Szuach i Cofar z Naama.
###### **Hi 2,12**
 Już z daleka utkwili w nim oczy, a przyglądając się, nie poznali go. Podnieśli krzyk i płakali. Każdy z nich rozdarł szatę swoją i narzucił popiołu na swoją głowę.
###### **Hi 2,13**
 Potem usiedli przy nim na ziemi i siedzieli tak przez siedem dni i siedem nocy. I żaden z nich nie wyrzekł do niego ani słowa, bo widzieli, jak wielka była jego boleść.
# Hi 2 BR
###### **Hi 2,1**
 I oto pewnego dnia zdarzyło się, że gdy przeszli, aby się stawić przed Panem, synowie Boga, pojawił się także wśród nich szatan.
###### **Hi 2,2**
 I zapytał Pan szatana: Skąd przychodzisz? A szatan odpowiedział Panu: Przemierzyłem całą ziemię wzdłuż i wszerz.
###### **Hi 2,3**
 Powiedział tedy Pan do szatana: Czy zwróciłeś uwagę na sługę mojego, Hioba? Drugiego takiego nie ma nigdzie na ziemi. Jest to mąż niezwykle szlachetny i sprawiedliwy, żyje bogobojnie, unikając wszelkiego zła. Nadal jest on niezmiennie pobożny, choć nakłoniłeś mnie żebym go - bez żadnego powodu - zrujnował.
###### **Hi 2,4**
 Odpowiadając na to rzekł szatan do Pana: Skóra za skórę! Człowiek gotów jest oddać za swoje życie wszystko, co posiada.
###### **Hi 2,5**
 Ale spróbuj tylko podnieść Twoją rękę na niego, dotknij tylko jego kości albo ciała, a zaraz będzie Ci w oczy złorzeczył.
###### **Hi 2,6**
 Powiedział tedy Pan do szatana: Dobrze! Pozwalam ci wziąć go w twoje ręce. Tylko nie pozbawiaj go życia.
###### **Hi 2,7**
 Odszedł więc szatan sprzed oblicza Boga i dotknął Hioba straszliwym trądem, który objął całe jego ciało, od palców stóp aż do wierzchołka głowy.
###### **Hi 2,8**
 Usiadł Hiob na stercie gnoju i wziął do ręki kawałek skorupy, żeby się nią drapać.
###### **Hi 2,9**
 Wtedy powiedziała do niego jego żona: Czy nadal będziesz trwał z takim uporem przy swojej pobożności? Lepiej powiedz raz Bogu całą prawdę i skończ ze sobą!
###### **Hi 2,10**
 Lecz on odpowiedział: Mówisz jak szalona! Skoro przyjmujemy od Boga dobro, to czyż nie powinniśmy przyjąć z Jego ręki także i zła? Znosząc to wszystko, Hiob nigdy nie wypowiedział nawet jednego grzesznego słowa przeciwko Bogu.
###### **Hi 2,11**
 O wszystkich nieszczęściach, jakie spadły na Hioba, dowiedzieli się jego trzej przyjaciele. Przyszli więc do Hioba, każdy ze swych stron ojczystych: Elifaz z Temanu, Bildad z Szuach i Sofar z Naamy. Uzgodnili między sobą, że przyjdą, aby mu okazać współczucie i podtrzymać go na duchu.
###### **Hi 2,12**
 Ale przypatrując mu się z daleka wcale nie mogli go poznać. Gdy podeszli bliżej, zaczęli krzyczeć z przerażenia i płakać nad nim. Każdy z nich rozdarł swoje szaty i rzucał ku niebu popiół nad swoją głową.
###### **Hi 2,13**
 Potem usiedli przy nim i tak siedzieli na ziemi przez siedem dni i siedem nocy. Żaden nie wypowiedział do niego ani jednego słowa, wiedzieli bowiem, jak bardzo cierpi.
# Hi 2 WUJ
###### **Hi 2,1**
 I stało się, gdy niektórego dnia przyszli synowie Boży, i stali przed Panem, przyszedł też szathan między nie: i stał przed oczyma jego,
###### **Hi 2,2**
 Że Pan rzekł do szathana, zkąd idziesz? który odpowiadając rzekł: Zkrążyłem ziemię, i schodziłem ją.
###### **Hi 2,3**
 I rzekł Pan do szathana: A przypatrzyłżeś się słudze memu Jobowi, że mu niemasz podobnego na ziemi, mąż szczery, i prosty, a bojący się Boga, i odstępujący od złego, a jeszcze zachowujący niewinność? a tyś mię pobudził przeciw jemu, żebym go trapił bez przyczyny.
###### **Hi 2,4**
 Któremu szathan odpowiadając rzekł: Skórę za skórę, i wszystko co ma człowiek, da za duszę swoję:
###### **Hi 2,5**
 Ale ściągni rękę twoję, a dotkni kości jego i ciała, a tedy ujrzysz, żeć w oczy błogosławić będzie.
###### **Hi 2,6**
 I rzekł Pan do szathana: Oto w ręce twojej jest, a wszakoż zachowaj duszę jego.
###### **Hi 2,7**
 Wyszedszy tedy szathan od oblicza Pana, zaraził Joba wrzodem barzo złym, od stopy nogi aż do wierzchu głowy jego:
###### **Hi 2,8**
 Który ropę skorupą oskrobywał siedząc na gnoju.
###### **Hi 2,9**
 I rzekła mu żona jego: A jeszczeż trwasz w prostocie twojej? Błogosław Bogu, a umrzy.
###### **Hi 2,10**
 Który rzekł do niej: Jako jedna z niewiast szalonych rzekłaś: Jeśliśmy przyjęli dobra z ręki Bożej, złego czemubyśmy przyjmować nie mieli? W tem wszystkiem Job nie zgrzeszył usty swemi.
###### **Hi 2,11**
 Usłyszawszy tedy trzej przyjaciele Jobowi wszystko złe, które nań przypadło, przyszli każdy z miejsca swego, Eliphas Themanitczyk, i Baldad Suhitczyk, i Sophar Naamathczyk. Bo się byli zmówili, żeby pospołu przyszedszy nawiedzili go i cieszyli.
###### **Hi 2,12**
 A podniósszy zdaleka oczy swe nie poznali go, i zakrzyknąwszy płakali, a rozdarwszy szaty swe, sypali proch na głowy swe ku niebu.
###### **Hi 2,13**
 I siedzieli z nim na ziemi siedm dni i siedm nocy, a żaden do niego słowa nie mówił: bo widzieli, że boleść była gwałtowna.
