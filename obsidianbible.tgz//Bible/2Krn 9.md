# 2Krn 9 BT5
###### **2Krn 9,1**
 Również i królowa Saby, usłyszawszy o sławie Salomona, przybyła, aby przez roztrząsanie trudnych zagadnień wypróbować Salomona w Jerozolimie. [Przybyła] ze świetnym orszakiem, z wielbłądami dźwigającymi wonności i bardzo dużo złota oraz drogocennych kamieni. Następnie przyszła do Salomona i odbyła z nim rozmowę o wszystkim, co postanowiła.
###### **2Krn 9,2**
 Salomon zaś udzielił jej wyjaśnień dotyczących wszystkich zagadnień przez nią poruszonych. Nie było zagadnienia nie znanego Salomonowi, którego by jej nie wyjaśnił.
###### **2Krn 9,3**
 Gdy królowa Saby ujrzała całą mądrość Salomona oraz pałac, który zbudował,
###### **2Krn 9,4**
 jak również zaopatrzenie jego stołu w potrawy i napoje, i mieszkanie jego dworu, stanowiska usługujących mu, jego szaty, jego podczaszych i ich ubiory, i całopalenia, które składał w świątyni Pańskiej – wówczas wpadła w zachwyt.
###### **2Krn 9,5**
 Dlatego przemówiła do króla: «***Prawdziwe były wieści, które usłyszałam w moim kraju o twoich dziełach i o twej mądrości.***
###### **2Krn 9,6**
 ***Jednak nie dowierzałam tym wieściom, dopóki sama nie przyjechałam i nie zobaczyłam na własne oczy, że nawet połowy mi nie opowiedziano o ogromie twej mądrości. Przewyższyłeś wszystko, co o tobie słyszałam.***
###### **2Krn 9,7**
 ***Szczęśliwe twoje żony, szczęśliwi twoi słudzy! Oni wciąż stoją przed twoim obliczem i wsłuchują się w twoją mądrość.***
###### **2Krn 9,8**
 ***Niech będzie błogosławiony Pan, Bóg Twój, który ciebie upodobał sobie, aby cię osadzić na swoim tronie jako króla [oddanego] Panu, Bogu swemu. Z miłości, jaką Twój Bóg żywi względem Izraela, [chcąc] zapewnić mu trwanie na wieki, ustanowił cię nad nim królem, abyś wykonywał prawo i sprawiedliwość***».
###### **2Krn 9,9**
 Następnie dała królowi sto dwadzieścia talentów złota i bardzo dużo wonności oraz drogocennych kamieni. Nigdy nie było więcej wonności od tych, które królowa Saby dała królowi Salomonowi.
###### **2Krn 9,10**
 Także słudzy Hurama i słudzy Salomona, którzy przywozili złoto z Ofiru, sprowadzali drewno sandałowe i drogocenne kamienie.
###### **2Krn 9,11**
 Z tego drewna sandałowego król zrobił podłogi do świątyni Pańskiej i do pałacu królewskiego oraz cytry i harfy dla śpiewaków. Takich, jak te, nie widziano przedtem w ziemi judzkiej.
###### **2Krn 9,12**
 Król Salomon zaś podarował królowej Saby wszystko, do czego okazała upodobanie i czego pragnęła, i dał jej więcej, aniżeli sama przywiozła królowi. Niebawem wyruszyła w drogę powrotną do swego kraju wraz ze swymi sługami.
###### **2Krn 9,13**
 Waga złota, które co rok dostarczano Salomonowi, wynosiła sześćset sześćdziesiąt sześć talentów złota,
###### **2Krn 9,14**
 oprócz opłat handlarzy i kupców wędrownych, którzy je wnosili. Wszyscy królowie arabscy i namiestnicy krajowi przynosili złoto i srebro Salomonowi.
###### **2Krn 9,15**
 Sporządził zatem król Salomon dwieście tarcz z kutego złota, a na każdą tarczę wychodziło sześćset [syklów] kutego złota.
###### **2Krn 9,16**
 Ponadto trzysta puklerzy z kutego złota; na każdy puklerz wychodziło trzysta [syklów] złota. Umieścił je król w "Domu Lasu Libanu".
###### **2Krn 9,17**
 Następnie król sporządził wielki tron z kości słoniowej, który wyłożył czystym złotem.
###### **2Krn 9,18**
 Tron miał sześć stopni i podnóżek ze złota oraz poręcze po obu stronach siedzenia, a przy poręczach stały dwa lwy.
###### **2Krn 9,19**
 Na sześciu stopniach stało tam po obu stronach dwanaście lwów. Czegoś takiego nie wykonano w żadnym królestwie.
###### **2Krn 9,20**
 Wszystkie też naczynia, z których pił król Salomon, były złote, również szczerozłote były wszelkie naczynia "Domu Lasu Libanu". Nie było srebra: nie ceniono go w czasach Salomona.
###### **2Krn 9,21**
 Król bowiem posiadał okręty, które ze sługami Hurama pływały do Tarszisz. Co trzy lata przybywały okręty z Tarszisz, przywożąc złoto i srebro, kość słoniową oraz małpy i pawie.
###### **2Krn 9,22**
 Dzięki temu król Salomon bogactwem i mądrością przewyższał wszystkich królów ziemi.
###### **2Krn 9,23**
 Wszyscy więc królowie ziemi udawali się do Salomona, by posłuchać mądrości, jaką Bóg obdarzył jego serce.
###### **2Krn 9,24**
 Każdy zaś z nich składał corocznie swój dar: naczynia srebrne i naczynia złote, szaty czy też zbroje lub wonności, konie albo muły.
###### **2Krn 9,25**
 Miał więc Salomon cztery tysiące przegród dla koni i rydwanów oraz dwanaście tysięcy jezdnych. Rozmieścił ich w miastach rydwanów i przy królu w Jerozolimie.
###### **2Krn 9,26**
 Panował on wówczas nad wszystkimi królami od Rzeki aż do ziemi filistyńskiej i aż do granicy Egiptu.
###### **2Krn 9,27**
 Srebra zaś król złożył w Jerozolimie tyle, ile kamieni, a cedrów – ile sykomor na Szefeli.
###### **2Krn 9,28**
 Przywożono też dla Salomona konie z Egiptu i ze wszystkich krajów.
###### **2Krn 9,29**
 A czyż pozostałe dzieje Salomona, od pierwszych do ostatnich, nie są opisane w Kronice Proroka Natana i w Proroctwie Achiasza z Szilo, i w Widzeniu "Widzącego" Jedo w sprawie Jeroboama, syna Nebata?
###### **2Krn 9,30**
 Królował zatem Salomon w Jerozolimie nad całym Izraelem w ciągu czterdziestu lat.
###### **2Krn 9,31**
 Spoczął Salomon ze swoimi przodkami i pochowano go w Mieście Dawida, jego ojca. A jego syn, Roboam, został w jego miejsce królem.
# 2Krn 9 PAU
###### **2Krn 9,1**
 Kiedy królowa Saby usłyszała o Salomonie, przybyła do Jerozolimy z wielkim i wspaniałym orszakiem, z wielbłądami niosącymi wonności, dużą ilość złota i drogocenne kamienie. Chciała wystawić Salomona na próbę, przez postawienie mu trudnych pytań. Po przybyciu do Salomona, rozmawiała z nim o wszystkim, co głęboko ją nurtowało.
###### **2Krn 9,2**
 Salomon odpowiedział jej na wszystkie pytania. Nie było takiej sprawy, której Salomon nie umiałby jej wyjaśnić.
###### **2Krn 9,3**
 Kiedy królowa Saby przekonała się o mądrości Salomona i zobaczyła zbudowany przez niego pałac,
###### **2Krn 9,4**
 potrawy podawane na jego stół, mieszkania urzędników królewskich, umiejętności i stroje jego służby oraz jego podczaszych i ich stroje, jak również ofiary całopalne, które składał w domu PANA, aż oniemiała z podziwu.
###### **2Krn 9,5**
 Powiedziała do króla: „Prawdą było to, co usłyszałam w moim kraju o twoich dziełach i twojej mądrości.
###### **2Krn 9,6**
 Nie wierzyłam temu, co mówiono, dopóki nie przybyłam i nie zobaczyłam tego na własne oczy. Teraz widzę, że nie powiedziano mi nawet połowy o twojej wielkiej mądrości. Przewyższasz to, co o tobie słyszałam.
###### **2Krn 9,7**
 O jakże szczęśliwe twoje żony! Jakże szczęśliwi twoi słudzy, którzy zawsze znajdują się w twojej obecności i wsłuchują się w twoją mądrość.
###### **2Krn 9,8**
 Niech będzie błogosławiony PAN, twój Bóg, który zechciał dać tobie swój tron i ustanowić ciebie królem dla PANA, twojego Boga. Ponieważ twój Bóg kocha i na wieki umacnia Izraela, ciebie ustanowił jego królem, abyś umacniał prawo i sprawiedliwość”.
###### **2Krn 9,9**
 Następnie królowa Saby ofiarowała królowi sto dwadzieścia talentów złota, wielką ilość wonności oraz drogocennych kamieni. Nigdy nie zgromadzono więcej wonności od tych, które podarowała ona królowi Salomonowi.
###### **2Krn 9,10**
 Również poddani Hirama i poddani Salomona, którzy przywieźli złoto z Ofiru, sprowadzili drewno sandałowe i drogocenne kamienie.
###### **2Krn 9,11**
 Z drewna sandałowego król polecił wykonać schody do domu PANA i królewskiego pałacu oraz cytry i harfy dla śpiewaków. Nigdy wcześniej nie widziano w Judzie czegoś podobnego.
###### **2Krn 9,12**
 Król Salomon podarował królowej Saby wszystko, czego zapragnęła i o co poprosiła. Było tego więcej niż ona podarowała królowi. Następnie razem ze swoim orszakiem wyruszyła w drogę powrotną do swojego kraju.
###### **2Krn 9,13**
 Co roku do skarbca Salomona wpływało sześćset sześćdziesiąt sześć talentów złota,
###### **2Krn 9,14**
 a ponadto podatki od kupców i handlarzy oraz daniny od królów arabskich i zarządców prowincji, którzy przywozili Salomonowi złoto i srebro.
###### **2Krn 9,15**
 Salomon wykuł w złocie dwieście wielkich tarcz, ważących po sześćset syklów,
###### **2Krn 9,16**
 oraz trzysta małych, okrągłych tarcz, po trzysta syklów złota każda. Król umieścił je w Domu Lasu Libanu.
###### **2Krn 9,17**
 Potem król polecił zrobić wielki tron z kości słoniowej, który pokryto najczystszym złotem.
###### **2Krn 9,18**
 Do tronu prowadziło sześć stopni, a przed nim stał złoty podnóżek. Tron miał dwa oparcia, a po obu jego stronach, przy oparciach, stały dwa posągi lwów.
###### **2Krn 9,19**
 Dwanaście lwów stało po obu stronach sześciu stopni prowadzących do tronu. W żadnym królestwie nie było podobnego tronu.
###### **2Krn 9,20**
 Wszystkie puchary, jakie posiadał król Salomon, były ze złota, a wszystkie naczynia Domu Lasu Libańskiego były z najczystszego złota. Srebro bowiem w czasach Salomona nie było uważane za wartościowe.
###### **2Krn 9,21**
 Statki Salomona z załogą Hirama pływały do Tarszisz. Co trzy lata powracały z Tarszisz, przywożąc złoto, srebro, kość słoniową, małpy i pawie.
###### **2Krn 9,22**
 Salomon przewyższył bogactwem i mądrością wszystkich władców ziemi.
###### **2Krn 9,23**
 Wszyscy władcy ziemi pragnęli spotkać Salomona, aby czerpać z mądrości, jaką Bóg go obdarzył.
###### **2Krn 9,24**
 Każdy z nich co roku ofiarowywał mu w darze przedmioty ze srebra i złota, ubrania, broń, wonności, konie i muły.
###### **2Krn 9,25**
 Salomon posiadał stajnie dla czterech tysięcy koni i rydwanów oraz dwanaście tysięcy jeźdźców. Rozmieścił ich zarówno w miastach rydwanów, jak również u siebie, w Jerozolimie.
###### **2Krn 9,26**
 Panował nad wszystkimi książętami od Eufratu po ziemię Filistynów i aż do granicy Egiptu.
###### **2Krn 9,27**
 Sprawił on, że w Jerozolimie srebro było tak pospolite jak kamienie, a cedry tak liczne jak sykomory na Szefeli.
###### **2Krn 9,28**
 Z Egiptu i z innych krajów sprowadzano dla niego konie.
###### **2Krn 9,29**
 Pozostałe czyny Salomona, od początku jego panowania aż do końca, czy nie są spisane w pismach proroka Natana, w Księdze proroctw Achiasza Szilonity i w Księdze widzącego Jeddo, który miał widzenia dotyczące Jeroboama, syna Nebata?
###### **2Krn 9,30**
 Przez czterdzieści lat Salomon panował nad Izraelem w Jerozolimie.
###### **2Krn 9,31**
 Zasnął jak jego przodkowie i został pochowany w Mieście Dawidowym. Władzę po nim objął jego syn Roboam.
# 2Krn 9 BP
###### **2Krn 9,1**
 Do królowej Saby dotarł rozgłos sławy Salomona. Przybyła więc do Jeruzalem, by doświadczyć [mądrości] Salomona przez zagadki. Przyjechała z licznym pocztem, z wielbłądami wiozącymi wonności, bardzo dużo złota i drogich kamieni. Przyszła do Salomona i rozmawiała z nim o wszystkim, co jej na sercu leżało.
###### **2Krn 9,2**
 Salomon zaś odpowiedział na wszystkie jej pytania i nie było dla Salomona rzeczy tak tajemnej, by nie zdołał jej wyjaśnić.
###### **2Krn 9,3**
 Gdy królowa Saby przekonała się o mądrości Salomona i [ujrzała] dom, który zbudował,
###### **2Krn 9,4**
 potrawy jego stołu i mieszkania urzędników, dalej świtę przyboczną i jej ubiór, podczaszych jego oraz ich strój, wreszcie ofiary, jakie składał w Świątyni Jahwe - zdumiała się bardzo.
###### **2Krn 9,5**
 Rzekła tedy do króla: Prawdziwe są zatem wieści, które dotarły do mnie w moim kraju o twoich czynach i o twojej mądrości.
###### **2Krn 9,6**
 Nie wierzyłam ich słowom, zanim sama nie przybyłam i nie zobaczyłam na własne oczy, że oto nawet połowy mi nie powiedziano o twej niezmiernej mądrości; przeszedłeś wszystko, co mi o tobie opowiedziano.
###### **2Krn 9,7**
 Szczęśliwi mężowie twoi i szczęśliwi słudzy twoi, którzy stale przebywają przy tobie i słuchają [słów] twojej mądrości.
###### **2Krn 9,8**
 Niech będzie błogosławiony Jahwe, Bóg twój, który mając upodobanie w tobie posadził cię na swym tronie jako króla przed Jahwe, Bogiem twoim. To dlatego, że Bóg twój, miłując Izraela i chcąc go umocnić na wieki, ustanowił cię królem nad nim, abyś pełnił prawo i sprawiedliwość.
###### **2Krn 9,9**
 I ofiarowała królowi sto dwadzieścia talentów złota, a także bardzo wiele wonności i drogich kamieni. A nie było nigdy wonności równych tym, jakie wówczas królowa Saby ofiarowała królowi Salomonowi.
###### **2Krn 9,10**
 Prócz tego również słudzy Chirama i Salomona, którzy przywozili z Ofiru złoto, przywieźli także drzewo sandałowe i drogie kamienie.
###### **2Krn 9,11**
 Z drzewa sandałowego zrobił król schody do Świątyni Jahwe i do pałacu królewskiego oraz cytry i harfy dla śpiewaków; czegoś podobnego nie widziano nigdy przedtem w ziemi judzkiej.
###### **2Krn 9,12**
 Król Salomon dał też królowej Saby wszystko, czegokolwiek zapragnęła i o co prosiła, znacznie więcej niż ona sama przywiozła królowi. Po czym zaraz ze swym orszakiem powróciła do swego kraju.
###### **2Krn 9,13**
 Waga złota, które co roku składano Salomonowi, wynosiła 666 talentów,
###### **2Krn 9,14**
 oprócz tego, co wpływało od kupców i handlarzy; również wszyscy królowie Arabii i zarządcy kraju przywozili złoto i srebro dla Salomona.
###### **2Krn 9,15**
 Kazał więc król Salomon sporządzić dwieście wielkich tarcz z kutego złota, a na każdą zużyto sześćset [syklów] kutego złota.
###### **2Krn 9,16**
 Prócz tego trzysta puklerzy również ze złota kutego, przy czym zużyto na każdy puklerz trzysta [syklów] złota; umieścił je król w Domu Lasu Libanu.
###### **2Krn 9,17**
 Wykonał też król wielki tron z kości słoniowej i pokrył go szczerym złotem.
###### **2Krn 9,18**
 Tron miał sześć stopni i podnóżek ze złota, przytwierdzony do tronu. Po obydwu stronach siedzenia były poręcze, a dwa lwy stały przy poręczach.
###### **2Krn 9,19**
 Dwanaście lwów stało na sześciu stopniach po jednej i po drugiej stronie. Czegoś podobnego nie wykonano w żadnym królestwie.
###### **2Krn 9,20**
 Złote były również wszystkie naczynia, z których pił król Salomon, i szczerozłote były też wszystkie sprzęty w Domu Lasu Libanu; srebro nie miało prawie żadnej wartości w czasach Salomona.
###### **2Krn 9,21**
 Miał też król okręty, które ze sługami Chirama płynęły do Tarszisz; co trzy lata powracały okręty z Tarszisz przywożąc złoto i srebro, kość słoniową, małpy i pawie.
###### **2Krn 9,22**
 I tak król Salomon wyniesiony był ponad wszystkich królów ziemi przez swe bogactwa i mądrość.
###### **2Krn 9,23**
 Wszyscy więc królowie ziemi pragnęli ujrzeć Salomona i korzystać z mądrości, którą Bóg złożył w jego sercu.
###### **2Krn 9,24**
 A każdy z nich przynosił co roku swój dar: przedmioty srebrne i złote, szaty, zbroje, wonności, konie i muły.
###### **2Krn 9,25**
 Miał Salomon 4000 zaprzęgów koni do rydwanów oraz 12 000 jezdnych. Porozmieszczał ich po miastach rydwanów i przy królu w Jeruzalem.
###### **2Krn 9,26**
 Panował nad wszystkimi królami od Rzeki aż do ziemi Filistynów i do granicy Egiptu.
###### **2Krn 9,27**
 I sprawił król, że srebro stało się w Jeruzalem pospolite jak kamienie, a cedry tak liczne, jak sykomory na Szefeli.
###### **2Krn 9,28**
 Sprowadzono też dla Salomona konie z Egiptu i ze wszystkich innych krajów.
###### **2Krn 9,29**
 A czyż pozostałe dzieje Salomona od początku do końca nie zostały opisane w księdze proroka Natana, w proroctwie Achijji Szilonity i w widzeniach Iddy "widzącego", który [prorokował] przeciw Jeroboamowi, synowi Nebata?
###### **2Krn 9,30**
 Przez czterdzieści lat panował Salomon w Jeruzalem nad całym Izraelem.
###### **2Krn 9,31**
 I zasnął Salomon z ojcami swymi, a pochowano go w mieście jego ojca, Dawida, a po nim został królem jego syn, Roboam.
# 2Krn 9 BR
###### **2Krn 9,1**
 Królowa Saby dowiedziawszy się o sławie, jaka otaczała Salomona, przybyła do niego do Jerozolimy, pragnąc za pomocą różnych zagadek przekonać się o jego mądrości. Towarzyszył jej wspaniały orszak, a liczne wielbłądy dźwigały ogromne ilości wonności, złota i drogich kamieni. Stanęła przed Salomonem i zaczęła z nim rozmawiać o wszystkim, co leżało jej na sercu.
###### **2Krn 9,2**
 Salomon odpowiadał wyczerpująco na wszystkie jej pytania i nie było sprawy, której nie potrafiłby jej wyjaśnić.
###### **2Krn 9,3**
 Kiedy królowa Saby przekonała się już sama, że Salomon jest rzeczywiście bardzo mądry; kiedy obejrzała zbudowany przez niego pałac;
###### **2Krn 9,4**
 kiedy zobaczyła, co jada i jak mieszkają jego urzędnicy; jakie mają pomieszczenia i szaty jego słudzy; kiedy przyjrzała się ofiarom, jakie składano w świątyni Jahwe, wprost nie posiadała się ze zdumienia.
###### **2Krn 9,5**
 Wreszcie powiedziała do króla: Tak więc prawdą jest to wszystko, co słyszałam w swoim kraju o twoich dziełach i o twojej mądrości!
###### **2Krn 9,6**
 Nie wierzyłam w to, co mówiono, dopóki nie przyszłam tu i nie zobaczyłam wszystkiego na własne oczy. Otóż widzę teraz, że nawet połowy nie opowiedziano mi o twojej mądrości. Przewyższasz po wielekroć to wszystko, co o tobie się opowiada.
###### **2Krn 9,7**
 Szczęśliwe twoje żony, szczęśliwi twoi słudzy, którym dane jest być zawsze przy tobie i podziwiać twoją mądrość!
###### **2Krn 9,8**
 Niech będzie błogosławiony Jahwe, twój Bóg, za to, że znalazł upodobanie w tobie i posadził cię na tronie jako króla (służącego) Jahwe, twojemu Bogu. Twój Bóg ustanowił cię królem nad całym Izraelem, abyś przestrzegał prawa i sprawiedliwości, dlatego że miłuje On ten naród i pragnie, żeby trwał na wieki.
###### **2Krn 9,9**
 Potem wręczyła królowi sto dwadzieścia talentów złota oraz bardzo wielką ilość wonności i drogich kamieni. Nigdy nie zgromadzono naraz tyle wonności, ile królowa Saby przekazała królowi Salomonowi.
###### **2Krn 9,10**
 Słudzy Hurama oraz słudzy Salomona, którzy dostarczyli z Ofiru złoto, przywieźli także drewno sandałowe i drogie kamienie.
###### **2Krn 9,11**
 Z drewna sandałowego kazał król wykonać poręcze przy schodach do świątyni jahwe i do pałacu królewskiego, a nadto harfy i lutnie dla śpiewaków. W krainie judzkiej nigdy przedtem nie oglądano podobnego drewna.
###### **2Krn 9,12**
 Król Salomon zaś dał królowej Saby wszystko, czego tylko zapragnęła lub o co wyraźnie go poprosiła - wszystkiego znacznie więcej niż to, co ona przekazała w darze królowi. Potem ruszył w drogę i udała się, razem ze swymi sługami, do własnej krainy.
###### **2Krn 9,13**
 W sumie złota, które corocznie wpływało do (skarbca) Salomona, było sześćset sześćdziesiąt sześć talentów,
###### **2Krn 9,14**
 nie licząc tego, co wpływało z opłat od wędrownych handlarzy i kupców. Wszyscy królowie Arabii i zarządcy całego kraju dostarczali Salomonowi złota i srebra.
###### **2Krn 9,15**
 Kazał Salomon sporządzić dwieście wielkich tarcz, zużywając na każdą z nich sześćset sykli kutego złota.
###### **2Krn 9,16**
 Ponadto trzysta małych tarcz, z których każda ważyła trzysta sykli kutego złota. Wszystkie tarcze polecił król złożyć w Domu Lasu Libańskiego.
###### **2Krn 9,17**
 Na rozkaz króla został wykonany tron z kości słoniowej, cały okryty złotem.
###### **2Krn 9,18**
 Przed tronem znajdowały się schody (mające) sześć stopni oraz podnóżek, przymocowany do tronu. Po obydwu stronach tronu były oparcia dla rąk, przy czym dwa lwy podtrzymywały owe poręcze,
###### **2Krn 9,19**
 dwanaście zaś lwów było umieszczonych wzdłuż schodów, po sześć z każdej strony. Żaden władca nie miał u siebie czegoś podobnego.
###### **2Krn 9,20**
 Wszystkie naczynia, używane do picia (w pałacu) Salomona, były wykonane ze złota, wszystkie przedmioty w Domu Lasu Libańskiego były także z najczystszego złota. Niczego nie robiono ze srebra, którego nie ceniono sobie tak bardzo w czasach Salomona.
###### **2Krn 9,21**
 Król posiadał okręty, które - ze sługami Hurama na pokładach - udawały się do Tarszisz. Co trzy lata przypływały z Tarszisz okręty, przywożąc złoto, srebro, kość słoniową, małpy i pawie.
###### **2Krn 9,22**
 Bogactwami i mądrością przewyższał król Salomon wszystkich władców ziemi.
###### **2Krn 9,23**
 Wszyscy królowie ziemi odwiedzali Salomona, aby móc podziwiać mądrość, którą Bóg włożył w jego serce.
###### **2Krn 9,24**
 Każdy przekazywał mu wtedy podarki ze srebra i złota, cenne szaty, broń, wonności, konie i muły. I tak bywało każdego roku.
###### **2Krn 9,25**
 Miał Salomon stajnie na cztery tysiące koni, przeznaczonych do ciągnienia rydwanów, dwanaście tysięcy jeźdźców, którzy byli rozmieszczeni zarówno po miastach, gdzie znajdowały się rydwany, jak i w pobliżu króla, w Jerozolimie.
###### **2Krn 9,26**
 Podlegali mu wszyscy ówcześni władcy, od Rzeki aż po krainę Filistynów i po granice z Egiptem.
###### **2Krn 9,27**
 Doprowadził król do tego, że w Jerozolimie złota było tyle co zwykłych kamieni, a cedrów tyle co sykomor rosnących na Szefeli.
###### **2Krn 9,28**
 Konie dla Salomona sprowadzano z Egiptu i ze wszystkich innych krajów.
###### **2Krn 9,29**
 Pozostałe dzieje Salomona, zarówno te wcześniejsze, jak i późniejsze, są opisane w Kronikach proroka Natana, w Proroctwie Achiasza z Szilo oraz w Widzeniach 'widzącego' Jeddo w sprawie Jeroboama, syna Nebata.
###### **2Krn 9,30**
 Salomon sprawował w Jerozolimie władzę nad całym izraelem przez lat czterdzieści.
###### **2Krn 9,31**
 Kiedy odszedł Salomon do swoich przodków, pochowano go w mieście jego ojca, Dawida. Władzę po nim objął jego syn Roboam.
# 2Krn 9 WUJ
###### **2Krn 9,1**
 Królowa też Saba usłyszawszy sławę Salomonowe, przyjachała, aby go w gadkach doświadczała, do Jeruzalem z wielkiemi bogactwy, i wielbłądy, którzy nieśli rzeczy wonne, i złota barzo wiele, i kamienie drogie. A gdy przyszła do Salomona, mówiła z nim wszystko cokolwiek było w sercu jej.
###### **2Krn 9,2**
 I wyłożył jej Salomon wszystko co zadała była: i nie było nic czegoby jej jaśnie nie pokazał.
###### **2Krn 9,3**
 Która gdy ujrzała, to jest mądrość Salomonowe, i dom, który był zbudował.
###### **2Krn 9,4**
 Także i potrawy stołu jego, i mieszkania sług, i urzędy dworzanów jego, i szaty ich, podczasze też i szaty ich, i ofiary, które ofiarował w domu Pańskim, nie stawało w niej dusze od zdumienia.
###### **2Krn 9,5**
 I rzekła do króla: Prawdziwe są słowa, którem słyszała w ziemi swej o cnotach, i o mądrości twojej.
###### **2Krn 9,6**
 A nie wierzyłam powiadającym, ażem sama przyjachała i oglądały oczy moje, i doznałam, że mi ledwie połowicę mądrości twej powiadano: przeszedłeś sławę cnotami twemi.
###### **2Krn 9,7**
 Szczęśliwi mężowie twoi, i szczęśliwi słudzy twoi, którzy stoją przed tobą na każdy czas, a słuchają mądrości twojej.
###### **2Krn 9,8**
 Niechajże będzie Pan Bóg twój błogosławiony, który cię raczył postanowić na stolicy swej królem Pana Boga twego. Iż Bóg miłuje Izraela, i chce go zachować na wieki, przeto cię postanowił królem nad nim, abyś czynił sądy i sprawiedliwość.
###### **2Krn 9,9**
 I dała królowi sto i dwadzieścia talentów złota, i barzo wiele rzeczy wonnych, i kamienia barzo drogiego: nie było takowych rzeczy wonnych, jako te, które królowa Saba dała królowi Salomonowi.
###### **2Krn 9,10**
 Lecz i słudzy Hiram z sługami Salomonowemi przynieśli złota z Ophir i drzewa Thyinowego i kamienia barzo drogiego:
###### **2Krn 9,11**
 Z którego uczynił król, to jest z drzewa Thyinowego wschody w domu Pańskim, i w domu królewskim, i cytry, i arfy śpiewakom. Nigdy nie widziano w ziemi Judzkiej drzewa takowego.
###### **2Krn 9,12**
 A król Salomon dał królowej Sabie wszystko czego chciała i czego żądała, a daleko więcej niż co była do niego przyniosła: która wróciwszy się, jachała do ziemie swej z służebniki swymi.
###### **2Krn 9,13**
 A waga była złota, które przywożono Salomonowi na każdy rok, sześć set sześćdziesiąt sześć talentów złota:
###### **2Krn 9,14**
 Oprócz tej summy, którą posłowie z rozmaitych narodów, i kupcy zwykli byli przynaszać. I wszyscy królowie Arabscy i książęta ziem, którzy znaszali złoto i srebro Salomonowi.
###### **2Krn 9,15**
 Uczynił tedy król Salomon dwieście kopij złotych z summy sześci set czerwonych złotych, które na każdą kopiją wychodziły.
###### **2Krn 9,16**
 Ktemu trzysta puklerzów złotych, z trzech set czerwonych złotych, któremi powłaczano każdy puklerz, i schował je król w zbrojowniej, która była osadzona gajem.
###### **2Krn 9,17**
 Sprawił też król stolicę wielką z kości słoniowej, i oprawił ją szczerem złotem.
###### **2Krn 9,18**
 Sześć też stopniów, po których wstępowano na stolicę, i podnóżek złoty, i dwoje poręcza z obu stron, a dwa lwy stojące u poręcza:
###### **2Krn 9,19**
 Ale i innych dwanaście lewków stojących na sześci stopniach z obu stron: nie było takiej stolice we wszystkich królestwach.
###### **2Krn 9,20**
 Wszystkie też naczynia stołu królewskiego były złote, i naczynia w domu Lasu Libanu ze złota szczerego. Bo srebra na on czas za nic nie miano.
###### **2Krn 9,21**
 Abowiem okręty królewskie chodziły do Tharsis z sługami Hiram, raz we trzy lata: i przynosili ztamtąd złoto i srebro, i kość słoniową, i koczkodany i pawy.
###### **2Krn 9,22**
 Uwielmożony tedy jest Salomon nad wszystkie króle ziemskie przez bogactwo i sławę.
###### **2Krn 9,23**
 I wszyscy królowie ziemscy pragnęli widzieć twarz Salamonowę, aby słuchali mądrości, którą był dał Bóg w serce jego:
###### **2Krn 9,24**
 I przynosili mu dary, naczynia srebrne i złote, i szaty i zbroje, i rzeczy wonne, konie i muły na każdy rok.
###### **2Krn 9,25**
 Miał też Salomon czterdzieści tysięcy koni w stajniach, a wozów i jezdnych dwanaście tysięcy, i postawił je w miastach wozów poczwórnych i gdzie król był w Jeruzalem,
###### **2Krn 9,26**
 Używał też władzy nad wszystkiemi królmi od rzeki Euphraty, aż do ziemie Philistyńskiej, i aż do granice Egiptskiej.
###### **2Krn 9,27**
 I dodawał tak wielką obfitość srebra w Jeruzalem jako kamienia: a cedrów takie mnóstwo jako płonnych fig, które rostą po polach.
###### **2Krn 9,28**
 I przywodzono mu konie z Egiptu, i ze wszystkich krain.
###### **2Krn 9,29**
 A ostatek spraw Salomonowych pierwszych i poślednich spisane są w słowiech Nathana proroka, i w księgach Ahiasza Silonczyka, i w widzeniu Addo widzącego, przeciw Jeroboamowi synowi Nabathowemu.
###### **2Krn 9,30**
 I królował Salomon w Jeruzalem nad wszystkim Izraelem czterdzieści lat.
###### **2Krn 9,31**
 I zasnął z ojcy swemi, i pogrzebli go w Mieście Dawidowem: i królował Roboam syn jego miasto niego.
