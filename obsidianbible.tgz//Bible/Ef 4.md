# Ef 4 BT5
###### **Ef 4,1**
 Zachęcam was zatem ja, więzień w Panu, abyście postępowali w sposób godny powołania, do jakiego zostaliście wezwani,
###### **Ef 4,2**
 z całą pokorą i cichością, z cierpliwością, znosząc siebie nawzajem w miłości.
###### **Ef 4,3**
 Usiłujcie zachować jedność Ducha dzięki więzi, jaką jest pokój.
###### **Ef 4,4**
 Jedno jest Ciało i jeden Duch, bo też zostaliście wezwani do jednej nadziei, jaką daje wasze powołanie.
###### **Ef 4,5**
 Jeden jest Pan, jedna wiara, jeden chrzest.
###### **Ef 4,6**
 Jeden jest Bóg i Ojciec wszystkich, który [jest i działa] ponad wszystkimi, przez wszystkich i we wszystkich.
###### **Ef 4,7**
 Każdemu zaś z nas została dana łaska według miary daru Chrystusowego.
###### **Ef 4,8**
 Dlatego mówi Pismo: Wstąpiwszy na wysokości, wziął do niewoli jeńców, rozdał ludziom dary.
###### **Ef 4,9**
 Słowo zaś "wstąpił" cóż oznacza, jeśli nie to, że również zstąpił do niższych części ziemi?
###### **Ef 4,10**
 Ten, który zstąpił, jest i Tym, który wstąpił ponad wszystkie niebiosa, aby wszystko napełnić.
###### **Ef 4,11**
 On też ustanowił jednych apostołami, innych prorokami, innych ewangelistami, innych pasterzami i nauczycielami,
###### **Ef 4,12**
 aby przysposobili świętych do wykonywania posługi dla budowania Ciała Chrystusowego,
###### **Ef 4,13**
 aż dojdziemy wszyscy razem do jedności wiary i pełnego poznania Syna Bożego, do człowieka doskonałego, do miary wielkości według Pełni Chrystusa.
###### **Ef 4,14**
 [Chodzi o to], abyśmy już nie byli dziećmi, którymi miotają fale i porusza każdy powiew nauki, na skutek oszustwa ze strony ludzi i przebiegłości w sprowadzaniu na manowce fałszu.
###### **Ef 4,15**
 Natomiast, żyjąc prawdziwie w miłości, sprawmy, by wszystko wzrastało ku Temu, który jest Głową – ku Chrystusowi.
###### **Ef 4,16**
 Od Niego [poczynając] całe Ciało – zespalane i utrzymywane w łączności więzią umacniającą każdy z członków stosownie do jego miary – przyczynia sobie wzrostu dla budowania siebie w miłości.
###### **Ef 4,17**
 To zatem mówię i zaklinam się na Pana, abyście już nie postępowali tak, jak postępują poganie, z ich próżnym myśleniem,
###### **Ef 4,18**
 umysłem pogrążeni w mroku, obcy dla życia Bożego, na skutek tkwiącej w nich niewiedzy, na skutek zatwardziałości serca.
###### **Ef 4,19**
 Oni to, doprowadziwszy siebie do nieczułości [sumienia], oddali się rozpuście, popełniając zachłannie wszelkiego rodzaju grzechy nieczyste.
###### **Ef 4,20**
 Wy zaś nie tak nauczyliście się Chrystusa.
###### **Ef 4,21**
 Słyszeliście przecież o Nim i zostaliście pouczeni w Nim, zgodnie z prawdą, jaka jest w Jezusie,
###### **Ef 4,22**
 że – co się tyczy poprzedniego sposobu życia – trzeba porzucić dawnego człowieka, który ulega zepsuciu na skutek zwodniczych żądz,
###### **Ef 4,23**
 odnawiać się duchem w waszym myśleniu
###### **Ef 4,24**
 i przyoblec się w człowieka nowego, stworzonego na obraz Boga, w sprawiedliwości i prawdziwej świętości.
###### **Ef 4,25**
 Dlatego, odrzuciwszy kłamstwo, niech każdy z was mówi prawdę swemu bliźniemu, bo jesteście nawzajem dla siebie członkami.
###### **Ef 4,26**
 Gniewajcie się, a nie grzeszcie: niech nad waszym gniewem nie zachodzi słońce.
###### **Ef 4,27**
 Ani nie dawajcie miejsca diabłu!
###### **Ef 4,28**
 Kto dotąd kradł, niech już przestanie kraść, lecz raczej niech pracuje uczciwie własnymi rękami, by miał z czego użyczać potrzebującemu.
###### **Ef 4,29**
 Niech nie wychodzi z waszych ust żadna mowa szkodliwa, lecz tylko budująca, zależnie od potrzeby, by wyświadczała dobro słuchającym.
###### **Ef 4,30**
 I nie zasmucajcie Bożego Ducha Świętego, którym zostaliście opieczętowani na dzień odkupienia.
###### **Ef 4,31**
 Niech zniknie spośród was wszelka gorycz, uniesienie, gniew, wrzaskliwość, znieważanie – wraz z wszelką złością.
###### **Ef 4,32**
 Bądźcie dla siebie nawzajem dobrzy i miłosierni. Przebaczajcie sobie, tak jak i Bóg wam przebaczył w Chrystusie.
# Ef 4 PAU
###### **Ef 4,1**
 Błagam was ja, więzień w Panu, abyście postępowali w sposób godny powołania, jakim zostaliście wezwani.
###### **Ef 4,2**
 Z całą pokorą, delikatnością i cierpliwością znoście jedni drugich w miłości.
###### **Ef 4,3**
 Starajcie się zachować jedność Ducha, złączeni więzią pokoju.
###### **Ef 4,4**
 Jedno jest Ciało i jeden Duch, jak jedna jest nadzieja waszego powołania, do której zostaliście wezwani.
###### **Ef 4,5**
 Jeden jest Pan, jedna wiara, jeden chrzest,
###### **Ef 4,6**
 jeden Bóg i Ojciec wszystkich. On jest ponad wszystkimi, przez wszystkich i we wszystkich.
###### **Ef 4,7**
 Każdemu z nas została dana łaska według miary daru Chrystusa.
###### **Ef 4,8**
 Dlatego powiedziano: Gdy wstąpił na wysokości, wziął do niewoli jeńców, rozdał ludziom dary.
###### **Ef 4,9**
 Czy jednak wstąpił, nie znaczy również, że zstąpił do niższych części ziemi?
###### **Ef 4,10**
 Ten, który zstąpił, jest Tym samym, który wstąpił ponad wszystkie nieba, aby wszystko napełnić.
###### **Ef 4,11**
 On także ustanowił apostołów, proroków, ewangelistów, pasterzy i nauczycieli,
###### **Ef 4,12**
 aby przygotowali świętych do pełnienia posługi budowania Ciała Chrystusa,
###### **Ef 4,13**
 aż wszyscy osiągniemy jedność wiary i poznanie Syna Bożego, doskonałe człowieczeństwo, miarę wielkości według pełni Chrystusa.
###### **Ef 4,14**
 Obyśmy nie byli już dziećmi niesionymi przez fale i poddanymi prądom błędnej nauki głoszonej przez ludzi przewrotnych i przebiegłych, którzy łudzą fałszem.
###### **Ef 4,15**
 Bądźmy natomiast szczerzy w miłości i wzrastajmy pod każdym względem ku Temu, który jest Głową - ku Chrystusowi.
###### **Ef 4,16**
 Z Niego całe Ciało - złączone i powiązane dzięki mocy właściwej każdej części - wzrasta, budując siebie w miłości.
###### **Ef 4,17**
 To mówię i zaświadczam w Panu, abyście już nie postępowali jak poganie w swej bezmyślności.
###### **Ef 4,18**
 Oni są zamroczeni w swych myślach i pozbawieni udziału w życiu Bożym z powodu swej niewiedzy i zatwardziałości serca.
###### **Ef 4,19**
 Stracili też wrażliwość i samych siebie wydali rozpuście i wszelkiej nieokiełznanej nieczystości.
###### **Ef 4,20**
 Wy jednak nie tak nauczyliście się Chrystusa.
###### **Ef 4,21**
 Słyszeliście bowiem o Nim i w Nim zostaliście pouczeni zgodnie z prawdą w Jezusie,
###### **Ef 4,22**
 że należy odrzucić starego człowieka z jego wcześniejszym sposobem życia, człowieka niszczonego przez zwodnicze żądze.
###### **Ef 4,23**
 Pozwólcie się odnawiać Duchowi w waszym myśleniu
###### **Ef 4,24**
 i przyobleczcie się w nowego człowieka, stworzonego zamysłem Boga w sprawiedliwości i prawdziwej świętości.
###### **Ef 4,25**
 Dlatego odrzućcie kłamstwo i niech każdy mówi prawdę swemu bliźniemu, bo wszyscy tworzymy jedno.
###### **Ef 4,26**
 Gniewajcie się, ale nie grzeszcie: niech słońce nie zachodzi nad waszym gniewem.
###### **Ef 4,27**
 I nie dawajcie miejsca diabłu!
###### **Ef 4,28**
 Kto kradnie, niech przestanie kraść i niech raczej pracą własnych rąk zdobywa dobra, którymi będzie mógł wspomagać potrzebujących.
###### **Ef 4,29**
 Niech z waszych ust nie wychodzi żadne nieprzyzwoite słowo, lecz tylko dobre, budujące, aby stosownie do potrzeb dawało łaskę słuchającym.
###### **Ef 4,30**
 Nie zasmucajcie Bożego Ducha Świętego, w którym zostaliście opieczętowani na dzień zbawienia.
###### **Ef 4,31**
 Niech zniknie spośród was wszelka gorycz, rozdrażnienie, gniew, krzyk, bluźnierstwo i wszelkie zło.
###### **Ef 4,32**
 Bądźcie dla siebie nawzajem łagodni i miłosierni. Jedni drugim wybaczajcie, tak jak Bóg wybaczył wam w Chrystusie.
# Ef 4 BP
###### **Ef 4,1**
 Ja, więzień w Panu, zachęcam was przeto, abyście postępowali w sposób godny powołania, do którego zostaliście wezwani:
###### **Ef 4,2**
 z całą pokorą, łagodnością i cierpliwością, znosząc się nawzajem z miłości.
###### **Ef 4,3**
 Starajcie się strzec jedności ducha za pomocą więzi, którą jest pokój.
###### **Ef 4,4**
 Jest jedno Ciało i jeden Duch, jak jest tylko jedna nadzieja, którą daje wasze powołanie.
###### **Ef 4,5**
 Jest tylko jeden Pan, jedna wiara, jeden chrzest;
###### **Ef 4,6**
 jeden Bóg i Ojciec wszystkich, który [jest i działa] ponad wszystkimi, przez wszystkich i we wszystkich.
###### **Ef 4,7**
 Każdemu z nas została dana łaska według miary daru Chrystusowego.
###### **Ef 4,8**
 Dlatego mówi Pismo: "Wstępując na wysokości, powiódł z sobą jeńców, rozdał ludziom dary".
###### **Ef 4,9**
 Co znaczy to, że "wstąpił"? Czyż nie to, że [najpierw] zstąpił na niskości ziemskie?
###### **Ef 4,10**
 Ten, który zstąpił, jest i Tym, który wstąpił ponad niebiosa, aby wszystko napełnić.
###### **Ef 4,11**
 On to ustanowił jednych apostołami, innych prorokami, [jeszcze] innych ewangelistami, pasterzami i nauczycielami,
###### **Ef 4,12**
 aby przygotowali świętych do dzieła posługi, do budowy Ciała Chrystusowego,
###### **Ef 4,13**
 aż do osiągnięcia jedności w wierze i poznaniu Syna Bożego, do osiągnięcia doskonałego człowieczeństwa i wielkości na miarę Pełni Chrystusa.
###### **Ef 4,14**
 Już nie będziemy dziećmi, które się zdają na igraszkę fal i poddają prądom nauki prowadzącej przez oszustwa i przebiegłość ludzką na manowce.
###### **Ef 4,15**
 Ale żyjąc według zasad miłości, będziemy dorastali pod każdym względem do Niego, czyli Chrystusa, który jest Głową.
###### **Ef 4,16**
 W Nim całe Ciało zespala się i wiąże dzięki spełnianiu przez poszczególne członki wyznaczonych funkcji. Tak dokonuje się wzrost Ciała, które buduje się samo w sobie przez miłość.
###### **Ef 4,17**
 A więc mówię [wam] i zaklinam w Panu, abyście już dłużej nie postępowali jak poganie, którzy żyją w próżności umysłu,
###### **Ef 4,18**
 a przebywając w mrokach poznania, nie mają dostępu do życia Bożego z powodu trwającej w nich niewiedzy i zatwardziałości serca.
###### **Ef 4,19**
 Zatracili oni wyczucie tego, co szlachetne, tarzają się w rozpuście, oddając się bez opamiętania wszelkiego rodzaju nieczystości.
###### **Ef 4,20**
 Ale wy nie tak poznawaliście Chrystusa.
###### **Ef 4,21**
 Słyszeliście o Nim i zostaliście pouczeni zgodnie z prawdą, która jest w Nim w Jezusie:
###### **Ef 4,22**
 [że trzeba] zrzucić z siebie starego człowieka z jego dawnym sposobem życia, którego zwodnicze żądze doprowadzają do upadku,
###### **Ef 4,23**
 odnowić ducha i myśli,
###### **Ef 4,24**
 przyoblec się w nowego człowieka, stworzonego na obraz Boga w sprawiedliwości i prawdziwej świętości.
###### **Ef 4,25**
 Dlatego odrzuciwszy kłamstwo, niech każdy mówi prawdę bliźniemu swemu, bo jesteście członkami jednego Ciała.
###### **Ef 4,26**
 Możecie się gniewać, ale nie grzeszcie. Słońce niech nie zachodzi nad waszym gniewem,
###### **Ef 4,27**
 nie dawajcie przystępu diabłu.
###### **Ef 4,28**
 Kto kradł, niech zaprzestanie kradzieży i zabierze się do pracy, zdobywa własnym trudem pieniądze, aby mógł udzielać potrzebującemu.
###### **Ef 4,29**
 Niech z ust waszych nie wychodzi żadne brzydkie słowo, lecz tylko dobre, potrzebne ku zbudowaniu, by przyniosło łaskę tym, którzy go słuchają.
###### **Ef 4,30**
 I nie zasmucajcie Ducha Świętego Boga, który was opatrzył [swoją] pieczęcią na dzień odkupienia.
###### **Ef 4,31**
 Wszelka gorycz, wybuchowość, gniew, krzyki i przekleństwa, i jakiekolwiek zło niech u was zniknie.
###### **Ef 4,32**
 Bądźcie dla drugich dobrzy i miłosierni. Wybaczajcie sobie nawzajem, jak i wam przebaczył Bóg w Chrystusie.
# Ef 4 BR
###### **Ef 4,1**
 Proszę was zatem ja, więzień dla sprawy Pana, żebyście postępowali w sposób godny powołania, jakie zostało do was skierowane.
###### **Ef 4,2**
 Bądźcie zawsze pokorni, łagodni, cierpliwi. Znoście jedni drugich z [prawdziwą] miłością.
###### **Ef 4,3**
 Starajcie się trwać w jedności, którą zapewnia wam Duch [Święty], troszcząc się nawzajem o zachowanie pokoju.
###### **Ef 4,4**
 Jedno bowiem [stanowicie] ciało, jeden jest też Duch [Święty], podobnie jak jedna tylko jest nadzieja, którą żyjecie dzięki waszemu powołaniu.
###### **Ef 4,5**
 Jeden jest również Pan, jedna wiara, jeden chrzest;
###### **Ef 4,6**
 jeden Bóg i Ojciec wszystkich. On to rządzi wszystkimi, działa przez wszystkich i trwa we wszystkich.
###### **Ef 4,7**
 Każdy zaś z nas otrzymał jakąś szczególną łaskę jako dar udzielony mu przez Chrystusa,
###### **Ef 4,8**
 zgodnie z tym, co mówi Pismo: Kiedy wstąpił na wysokości, zabrał ze sobą więźniów i rozdał ludziom swe dary.
###### **Ef 4,9**
 Lecz co znaczą słowa: wstąpił na wysokości? Otóż wynika z nich, że najpierw zstąpił do najniższych regionów ziemi.
###### **Ef 4,10**
 To ten sam najpierw zstąpił [na niziny], a potem wstąpił na wysokości niebieskie, aby napełnić [sobą] cały Wszechświat.
###### **Ef 4,11**
 On to również ustanowił jednych apostołami, drugich prorokami, innych ewangelistami, a jeszcze innych duszpasterzami i nauczycielami.
###### **Ef 4,12**
 Wszystko zaś po to, aby lud wierny mógł lepiej wypełniać swoją posługę i przyczyniać się do budowania Ciała Chrystusowego,
###### **Ef 4,13**
 tak iżbyśmy wszyscy stanowili jedno w wierze i byli pełni poznania Syna Bożego; abyśmy też doszli do prawdziwej dojrzałości [duchowej], do rozmiarów owej doskonałości, jaką jest Pełnia Chrystusa.
###### **Ef 4,14**
 W ten sposób przestaniemy już być dziećmi, unoszonymi przez różne fale i rzucanymi to tu, to tam byle podmuchem pseudopouczeń, wygłaszanych przez ludzi nieuczciwych i przebiegłych w sprowadzaniu innych na manowce fałszu.
###### **Ef 4,15**
 Tymczasem my, żyjąc prawdziwie miłością, mamy sprawiać, by wszystko wzrastało ustawicznie ku Chrystusowi, który jest Głową.
###### **Ef 4,16**
 Z Niego też całe Ciało - zespolone i utrzymywane w jedności dzięki owemu powiązaniu, umacniającemu na swój sposób każdy z członków oddzielnie - wzrasta coraz widoczniej i buduje siebie w miłości.
###### **Ef 4,17**
 Tak więc proszę was i zaklinam w imię Pana, żebyście nie postępowali tak jak poganie, którzy poddają się swoim bezsensownym przekonaniom,
###### **Ef 4,18**
 zaciemniającym tylko ich umysły. Nie mają oni żadnego udziału w życiu, które nam Bóg daje, gdyż trwają w absolutnej niewiedzy wskutek całkowitej zatwardziałości serca.
###### **Ef 4,19**
 Zatracili poczucie wstydu, oddali się rozpuście, popełniając w swym wyuzdaniu wszelkiego rodzaju grzechy nieczyste.
###### **Ef 4,20**
 Otóż wy uczyliście się nie takiego Chrystusa.
###### **Ef 4,21**
 Słyszeliście przecież o Nim i zostaliście pouczeni o prawdzie, która jest w Jezusie.
###### **Ef 4,22**
 Wiecie też, że trzeba wam wyzbyć się waszego dawnego człowieka, który niszczał wskutek ulegania złym pragnieniom.
###### **Ef 4,23**
 Macie się stać całkowicie nowymi w waszym i umyśle, i sercu.
###### **Ef 4,24**
 Macie się przyoblec w człowieka nowego, stworzonego według Boga, w sprawiedliwości i prawdziwej świętości.
###### **Ef 4,25**
 Dlatego też brzydźcie się wszelkim kłamstwem. Niech każdy z was mówi prawdę swemu bliźniemu, bo przecież wszyscy razem jesteśmy członkami tego samego Ciała.
###### **Ef 4,26**
 [Gdybyście zaś popadli w gniew, to nawet] gniewając się, nie grzeszcie i nie trwajcie w owym gniewie przez dzień cały.
###### **Ef 4,27**
 Nie dopuśćcie do tego, by diabeł wziął nad wami górę.
###### **Ef 4,28**
 Jeżeli ktoś kradł, niech już przestanie kraść i niech się zabierze do uczciwej pracy, aby miał z czego udzielać wsparcia potrzebującym.
###### **Ef 4,29**
 Niech z ust waszych nie wychodzi żadne złe słowo; mówcie tylko to, co pożyteczne, co służy zbudowaniu innych według potrzeby i czyni zadość pragnieniom tych, którzy słuchają waszego słowa.
###### **Ef 4,30**
 Nie zasmucajcie Świętego Ducha Bożego, którym zostaliście niejako opieczętowani, by trwać w nadziei osiągnięcia pełnego odkupienia.
###### **Ef 4,31**
 Niech zniknie spośród was duch wszelkiego zgorzknienia, irytacji, gniewu, zgiełku, zniewag wzajemnych i wszelkiej złości.
###### **Ef 4,32**
 Bądźcie zaś jedni dla drugich dobrzy i miłosierni, przebaczajcie sobie nawzajem, ponieważ i Bóg przebaczył wam wszystko w Chrystusie.
# Ef 4 WUJ
###### **Ef 4,1**
 Proszę was tedy ja więzień w Panu, abyście chodzili godnie powołaniu, któremeście powołani.
###### **Ef 4,2**
 Ze wszelaką pokorą i cichością, z cierpliwością, znosząc jeden drugiego w miłości,
###### **Ef 4,3**
 Starając się, abyście zachowali jedność ducha w związce pokoju.
###### **Ef 4,4**
 Jedno ciało, i jeden duch: jako jesteście wezwani w jednej nadziei wezwania waszego.
###### **Ef 4,5**
 Jeden Pan, jedna wiara, jeden chrzest.
###### **Ef 4,6**
 Jeden Bóg i Ociec wszystkich, który jest nade wszystkie i po wszystkim, i we wszystkich nas.
###### **Ef 4,7**
 Lecz każdemu z nas dana jest łaska wedle miary daru Chrystusowego.
###### **Ef 4,8**
 Dla tego mówi: Wstąpiwszy na wysokość, wiódł więzienie poimane, dał dary ludziam.
###### **Ef 4,9**
 A to że wstąpił, cóż jest, jedno iż pierwej był zstąpił do niższych części ziemie?
###### **Ef 4,10**
 Który zstąpił, tenżeć jest, który też wstąpił nad wszystkie niebiosa, aby napełnił wszystko.
###### **Ef 4,11**
 I tenże dał niektóre Apostoły, a niektóre Proroki, a drugie Ewangelisty: a inne pasterze i doktory:
###### **Ef 4,12**
 Ku wykonaniu świętych, ku robocie posługowania, ku budowaniu ciała Chrystusowego:
###### **Ef 4,13**
 Ażbyśmy się wszyscy zeszli w jedność wiary i poznania syna Bożego, w męża doskonałego, w miarę wieku zupełności Chrystusowej.
###### **Ef 4,14**
 Abyśmy już nie byli dziećmi chwiejącemi się, i nie byli uniesieni od każdego wiatru nauki przez złość ludzką, przez Chytrość na oszukanie błędu.
###### **Ef 4,15**
 A czyniąc prawdę w miłości, żebyśmy rośli w nim we wszystkim, który jest głowa, Chrystus:
###### **Ef 4,16**
 A którego wszystko ciało złożone i spojone będąc, przez wszystkie stawy dodawania, wedle skuteczności podług miary każdego członka, czyni pomnożenie ciała ku zbudowaniu samego siebie w miłości.
###### **Ef 4,17**
 To tedy powiadam i oświadczam się w Panu: abyście już nie chodzili jako i Poganie chodzą, w próżności umysłu swego,
###### **Ef 4,18**
 Ciemnościami zaćmiony mając rozum, oddaleni od żywota Bożego dla nieumiejętności, która w nich jest, dla zaślepienia serca ich:
###### **Ef 4,19**
 Którzy, przyszedszy w rozpacz, udali samych siebie na niewstydliwość ku popełnieniu wszelakiej nieczystości, ku łakomstwu.
###### **Ef 4,20**
 Lecz wy nie takeście się Chrystusa nauczyli:
###### **Ef 4,21**
 Jeśliżeście go jednak słuchali, i w nim jesteście wyuczeni (jako jest prawda w Jezusie).
###### **Ef 4,22**
 Abyście złożyli według dawnego obcowania starego człowieka, który się psuje według żądz błędu.
###### **Ef 4,23**
 A odnówcie się duchem umysłu waszego:
###### **Ef 4,24**
 I obleczcie się w nowego człowieka, który wedle Boga stworzony jest w sprawiedliwości, i świętobliwości prawdy.
###### **Ef 4,25**
 A przetoż złożywszy kłamstwo, mówcie każdy prawdę z bliźnim swoim: bo jesteście członkami jeden drugiego.
###### **Ef 4,26**
 Gniewajcie się, a nie grzeszcie: Słońce niechaj nie zapada na rozgniewanie wasze.
###### **Ef 4,27**
 Nie dawajcie miejsca djabłu.
###### **Ef 4,28**
 Który kradł, niechaj już nie kradnie: lecz raczejniech pracuje, robiąc rękoma swemi co jest dobrego, aby miał zkąd udzielić mającemu potrzebę.
###### **Ef 4,29**
 Wszelka mowa zła niech z ust waszych nie pochodzi ale jeśli która dobra ku zbudowaniu wiary, aby łaskę zjednała słuchającym.
###### **Ef 4,30**
 A nie zasmucajcie Ducha świętego Bożego: w którym zapieczętowani jesteście na dzień odkupienia.
###### **Ef 4,31**
 Wszelaka gorzkość, i gniew, i zagniewanie, i wrzask i bluźnienie niech będzie odjęte od was z wszelaką złością.
###### **Ef 4,32**
 Ale bądźcie łaskawi jedni przeciw drugim, miłosierni, odpuszczając jeden drugiemu, jako i Bóg w Chrystusie wam odpuścił.
# Ef 4 STERN
###### **Ef 4,1**
 Dlatego ja, więzień zjednoczony z Panem, błagam was, abyście wiedli życie godne powołania, do którego zostaliście wezwani.
###### **Ef 4,2**
 Zawsze bądźcie pokorni, łagodni i cierpliwi, znosząc jedni drugich w miłości
###### **Ef 4,3**
 i z całych sił starając się zachować jedność, jaką daje Duch przez zespalającą moc szalomu.
###### **Ef 4,4**
 Jest jedno ciało i jeden Duch, tak jak kiedy zostaliście powołani, powołano was do jednej nadziei.
###### **Ef 4,5**
 I jeden jest Pan, jedna ufność, jedno zanurzenie
###### **Ef 4,6**
 i jeden też Bóg, Ojciec wszystkich, który włada nad wszystkimi, działa przez wszystkich i jest we wszystkich.
###### **Ef 4,7**
 Każdemu jednak z nas darmo dano łaskę odmierzoną według obfitości Mesjasza.
###### **Ef 4,8**
 Dlatego jest powiedziane: "Kiedy wstąpił na wysokości, poprowadził niewolę w niewolę i dał dary ludziom".
###### **Ef 4,9**
 A sformułowanie "wstąpił" cóż innego może oznaczać, jeśli nie to, że najpierw zstąpił do niższych partii, czyli na ziemię?
###### **Ef 4,10**
 Ten, który zstąpił, jest zarazem Tym, który wstąpił, wysoko nad całe niebiosa, aby napełnić wszystko.
###### **Ef 4,11**
 Ponadto dał niektórych ludzi jako wysłanników, niektórych jako proroków, niektórych jako głosicieli Dobrej Nowiny, a niektórych jako pasterzy i nauczycieli.
###### **Ef 4,12**
 Ich zadaniem jest wyposażyć lud Boży do dzieła posługiwania, które buduje ciało Mesjasza,
###### **Ef 4,13**
 aż wszyscy dojdziemy do jedności wynikającej z ufania Synowi Bożemu i poznania Go, w pełnej dorosłości, według normy dojrzałości wyznaczonej przez doskonałość Mesjasza.
###### **Ef 4,14**
 Wtedy nie będziemy już więcej dziećmi miotanymi przez fale i targanymi przez każdy poryw nauki, zdanymi na łaskę ludzi przebiegłych w obmyślaniu sposobów zwodzenia.
###### **Ef 4,15**
 Natomiast mówiąc prawdę w miłości, pod każdym względem będziemy wrastać w Tego, który jest głową, w Mesjasza.
###### **Ef 4,16**
 Pod Jego nadzorem całe ciało jest dopasowywane i spajane w jedno za pomocą każdego stawu, a każda część funkcjonuje, aby wypełnić swe zadanie. W ten sposób ciało rośnie i buduje siebie w miłości.
###### **Ef 4,17**
 Dlatego powiadam - w jedności z Panem nalegam wręcz: nie żyjcie już więcej jak poganie, z ich jałowym sposobem myślenia.
###### **Ef 4,18**
 Ich inteligencję spowiła ciemność i obce jest im życie Boże z powodu niewiedzy, która w nich jest, a wynika z opierania się woli Bożej.
###### **Ef 4,19**
 Zatracili wszelkie uczucie, zdali się więc na pastwę zmysłowości, oddając się wszelakiej nieczystości i zawsze chcąc jeszcze więcej.
###### **Ef 4,20**
 Ale nie tego nauczyliście się od Mesjasza!
###### **Ef 4,21**
 Jeśliście naprawdę Go słuchali i byli o Nim pouczeni, to dowiedzieliście się, że ponieważ w Jeszui znajduje się prawda,
###### **Ef 4,22**
 to co się tyczy waszego poprzedniego sposobu życia, musicie zedrzeć z siebie starą naturę, bo przez swe zwodnicze pragnienia wasza stara natura przegniła do cna,
###### **Ef 4,23**
 musicie natomiast pozwalać na nieustanne odnawianie waszego ducha i umysłu
###### **Ef 4,24**
 i przyoblec się w nową naturę, stworzoną jako zbożna, wyrażającą się w sprawiedliwości i świętości, które wypływają z prawdy.
###### **Ef 4,25**
 Odrzucając zatem fałsz, niech każdy mówi prawdę swemu bliźniemu, bo jesteśmy ze sobą w bliskiej więzi jako członki jednego ciała.
###### **Ef 4,26**
 Gniewajcie się, ale nie grzeszcie, nie pozwólcie, by słońce zaszło, nim uporacie się z przyczyną waszego gniewu;
###### **Ef 4,27**
 w przeciwnym razie zostawiacie furtkę Przeciwnikowi.
###### **Ef 4,28**
 Złodziej musi przestać kraść, niech za to żyje uczciwie z własnego mozołu. W ten sposób będzie mógł dzielić się z potrzebującymi.
###### **Ef 4,29**
 Niech żadna szkodliwa mowa nie wychodzi z waszych ust, a tylko słowa dobre, pomocne w zaspokojeniu potrzeby, słowa, które przyniosą korzyść słuchającym ich.
###### **Ef 4,30**
 Nie zasmucajcie Bożego Ruach Ha-Kodesz, bo On was opieczętował jako swą własność aż do dnia ostatecznego odkupienia.
###### **Ef 4,31**
 Wyzbądźcie się wszelkiej zgorzkniałości, wściekłości, gniewu, aroganckiej pewności siebie i oszczerstwa wraz z wszelką złośliwością.
###### **Ef 4,32**
 Bądźcie natomiast dla siebie nawzajem uprzejmi, życzliwi; i przebaczajcie jeden drugiemu, tak jak w Mesjaszu przebaczył wam Bóg.
# Ef 4 TRO
###### **Ef 4,1**
 **παρακαλω** *parakalō* Zachęcam [[G3870]] WTV-PAI-1S **ουν** *oun* więc [[G3767]] [[CONJ]] **υμας** *hymas* was [[G5209]] WTP-2AP **εγω** *egō* ja [[G1473]] WTP-1NS **ο** *ho* [[G3588]] [[T-NSM]] **δεσμιος** *desmios* więzień [[G1198]] [[N-NSM]] **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **αξιως** *aksiōs* (by) godnie [[G516]] [[ADV]] **περιπατησαι** *peripatēsai* postępować – chodzić [[G4043]] [[V-AAN]] **της** *tēs* (względem) [[G3588]] [[T-GSF]] **κλησεως** *klēseōs* powołania [[G2821]] [[N-GSF]] **ης** *hēs* (w) którym [[G3739]] [[R-GSF]] **εκληθητε** *eklēthēte* zostaliście wezwani [[G2564]] WTV-API-2P
###### **Ef 4,2**
 **μετα** *meta* z [[G3326]] [[PREP]] **πασης** *pasēs* całą [[G3956]] WTA-GSF **ταπεινοφροσυνης** *tapeinofrosynēs* pokorą – uniżonością [[G5012]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **πραοτητος** *praotētos* łagodnością – uprzejmością [[G4236]] [[N-GSF]] **μετα** *meta* z [[G3326]] [[PREP]] **μακροθυμιας** *makrothymias* cierpliwością – wyrozumiałością [[G3115]] [[N-GSF]] **ανεχομενοι** *anechomenoi* znosząc [[G430]] WTV-PNP-NPM **αλληλων** *allēlōn* jedni drugich [[G240]] WTC-GPM **εν** *en* w [[G1722]] [[PREP]] **αγαπη** *agapē* miłości [[G26]] [[N-DSF]]
###### **Ef 4,3**
 **σπουδαζοντες** *spoudazontes* starając się usilnie – wykazując gorliwość [[G4704]] WTV-PAP-NPM **τηρειν** *tērein* zachowywać – strzec [[G5083]] WTV-PAN **την** *tēn* [[G3588]] WTT-ASF **ενοτητα** *henotēta* jedności [[G1775]] WTN-ASF **του** *tou* [[G3588]] WTT-GSN **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **συνδεσμω** *syndesmō* spójni – związaniu [[G4886]] WTN-DSM **της** *tēs* [[G3588]] [[T-GSF]] **ειρηνης** *eirēnēs* pokoju [[G1515]] [[N-GSF]]
###### **Ef 4,4**
 **εν** *hen* jedno [[G1520]] WTA-NSN **σωμα** *sōma* ciało [[G4983]] WTN-NSN **και** *kai* i [[G2532]] [[CONJ]] **εν** *hen* jeden [[G1520]] WTA-NSN **πνευμα** *pneuma* Duch [[G4151]] WTN-NSN **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **εκληθητε** *eklēthēte* zostaliście wezwani [[G2564]] WTV-API-2P **εν** *en* w [[G1722]] [[PREP]] **μια** *mia* jednej [[G1520]] WTA-DSF **ελπιδι** *elpidi* nadziei [[G1680]] [[N-DSF]] **της** *tēs* [[G3588]] [[T-GSF]] **κλησεως** *klēseōs* powołania [[G2821]] [[N-GSF]] **υμων** *hymōn* waszego [[G5216]] WTP-2GP
###### **Ef 4,5**
 **εις** *heis* jeden [[G1520]] [[A-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **μια** *mia* jedna [[G1520]] WTA-NSF **πιστις** *pistis* wiara [[G4102]] [[N-NSF]] **εν** *hen* jedno [[G1520]] WTA-NSN **βαπτισμα** *baptisma* zanurzenie [[G908]] WTN-NSN
###### **Ef 4,6**
 **εις** *heis* jeden [[G1520]] [[A-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **πατηρ** *patēr* Ojciec [[G3962]] [[N-NSM]] **παντων** *pantōn* wszystkich [[G3956]] WTA-GPM **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **επι** *epi* przy [[G1909]] [[PREP]] **παντων** *pantōn* wszystkich [[G3956]] WTA-GPM **και** *kai* i [[G2532]] [[CONJ]] **δια** *dia* przez [[G1223]] [[PREP]] **παντων** *pantōn* wszystkich [[G3956]] WTA-GPM **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* we [[G1722]] [[PREP]] **πασιν** *pasin* wszystkich [[G3956]] WTA-DPM **υμιν** *hymin* was [[G5213]] WTP-2DP
###### **Ef 4,7**
 **ενι** *heni* jednemu [[G1520]] WTA-DSM **δε** *de* zaś [[G1161]] [[CONJ]] **εκαστω** *hekastō* każdemu [[G1538]] WTA-DSM **ημων** *hēmōn* (z) nas [[G2257]] WTP-1GP **εδοθη** *edothē* została dana [[G1325]] [[V-API-3S]] **η** *hē* [[G3588]] [[T-NSF]] **χαρις** *charis* łaska [[G5485]] [[N-NSF]] **κατα** *kata* według [[G2596]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **μετρον** *metron* miary [[G3358]] WTN-ASN **της** *tēs* [[G3588]] [[T-GSF]] **δωρεας** *dōreas* daru – darowizny [[G1431]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **Ef 4,8**
 **διο** *dio* Dlatego [[G1352]] [[CONJ]] **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **αναβας** *anabas* wstąpiwszy [[G305]] WTV-2AAP-NSM **εις** *eis* na [[G1519]] [[PREP]] **υψος** *hypsos* wysokość [[G5311]] WTN-ASN **ηχμαλωτευσεν** *ēchmalōteusen* wziął do niewoli – zniewolił [[G162]] [[V-AAI-3S]] **αιχμαλωσιαν** *aichmalōsian* wziętych do niewoli – zniewolonych [[G161]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **εδωκεν** *edōken* dał [[G1325]] [[V-AAI-3S]] **δοματα** *domata* dary [[G1390]] WTN-APN **τοις** *tois* [[G3588]] WTT-DPM **ανθρωποις** *anthrōpois* ludziom [[G444]] WTN-DPM
###### **Ef 4,9**
 **το** *to* (To) [[G3588]] WTT-NSN **δε** *de* zaś [[G1161]] [[CONJ]] **ανεβη** *anebē* wstąpił – wszedł [[G305]] WTV-2AAI-3S **τι** *ti* czym [[G5101]] WTI-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ει** *ei* jeśli [[G1487]] WTCOND **μη** *mē* nie [[G3361]] [[PRT-N]] **οτι** *hoti* że [[G3754]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **κατεβη** *katebē* zstąpił – zszedł [[G2597]] WTV-2AAI-3S **πρωτον** *prōton* najpierw [[G4412]] [[ADV]] **εις** *eis* do [[G1519]] [[PREP]] **τα** *ta* (tych) [[G3588]] WTT-APN **κατωτερα** *katōtera* będącymi niższymi – będących bardziej na dole [[G2737]] WTA-APN-C **μερη** *merē* części [[G3313]] WTN-APN **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]]
###### **Ef 4,10**
 **ο** *ho* (Tym) [[G3588]] [[T-NSM]] **καταβας** *katabas* który zstąpił – który zszedł [[G2597]] WTV-2AAP-NSM **αυτος** *autos* Ten Sam [[G846]] WTP-NSM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* (Tym) [[G3588]] [[T-NSM]] **αναβας** *anabas* który wstąpił [[G305]] WTV-2AAP-NSM **υπερανω** *hyperanō* powyżej [[G5231]] [[ADV]] **παντων** *pantōn* całe [[G3956]] WTA-GPM **των** *tōn* [[G3588]] WTT-GPM **ουρανων** *ouranōn* niebiosa [[G3772]] WTN-GPM **ινα** *hina* aby [[G2443]] [[CONJ]] **πληρωση** *plērōsē* wypełniłby [[G4137]] WTV-AAS-3S **τα** *ta* [[G3588]] WTT-APN **παντα** *panta* wszystkie [[G3956]] WTA-APN
###### **Ef 4,11**
 **και** *kai* i [[G2532]] [[CONJ]] **αυτος** *autos* Ten Sam [[G846]] WTP-NSM **εδωκεν** *edōken* dał [[G1325]] [[V-AAI-3S]] **τους** *tous* (tych) [[G3588]] WTT-APM **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **αποστολους** *apostolous* (jako) wysłanników [[G652]] [[N-APM]] **τους** *tous* [[G3588]] WTT-APM **δε** *de* zaś [[G1161]] [[CONJ]] **προφητας** *profētas* (jako) proroków [[G4396]] [[N-APM]] **τους** *tous* (tych) [[G3588]] WTT-APM **δε** *de* zaś [[G1161]] [[CONJ]] **ευαγγελιστας** *euangelistas* głosicieli dobrej nowiny [[G2099]] [[N-APM]] **τους** *tous* (tych) [[G3588]] WTT-APM **δε** *de* zaś [[G1161]] [[CONJ]] **ποιμενας** *poimenas* pasterzy [[G4166]] [[N-APM]] **και** *kai* i [[G2532]] [[CONJ]] **διδασκαλους** *didaskalous* nauczycieli [[G1320]] [[N-APM]]
###### **Ef 4,12**
 **προς** *pros* ku [[G4314]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **καταρτισμον** *katartismon* wydoskonaleniu [[G2677]] [[N-ASM]] **των** *tōn* [[G3588]] WTT-GPM **αγιων** *hagiōn* świętych [[G40]] WTA-GPM **εις** *eis* w [[G1519]] [[PREP]] **εργον** *ergon* dziele [[G2041]] WTN-ASN **διακονιας** *diakonias* posługi – służby [[G1248]] [[N-GSF]] **εις** *eis* w [[G1519]] [[PREP]] **οικοδομην** *oikodomēn* budowaniu [[G3619]] WTN-ASF **του** *tou* [[G3588]] WTT-GSN **σωματος** *sōmatos* ciała [[G4983]] [[N-GSN]] **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **Ef 4,13**
 **μεχρι** *mechri* aż [[G3360]] [[ADV]] **καταντησωμεν** *katantēsōmen* doszlibyśmy – przyszlibyśmy [[G2658]] WTV-AAS-1P **οι** *hoi* [[G3588]] WTT-NPM **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **εις** *eis* do [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **ενοτητα** *henotēta* jedności [[G1775]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **της** *tēs* [[G3588]] [[T-GSF]] **επιγνωσεως** *epignōseōs* poznania [[G1922]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **υιου** *hyiou* Syna [[G5207]] [[N-GSM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εις** *eis* do [[G1519]] [[PREP]] **ανδρα** *andra* męża [[G435]] [[N-ASM]] **τελειον** *teleion* dojrzałego – doskonałego [[G5046]] WTA-ASM **εις** *eis* do [[G1519]] [[PREP]] **μετρον** *metron* miary [[G3358]] WTN-ASN **ηλικιας** *hēlikias* dojrzałości – wieku [[G2244]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSN **πληρωματος** *plērōmatos* wypełnienia [[G4138]] [[N-GSN]] **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **Ef 4,14**
 **ινα** *hina* aby [[G2443]] [[CONJ]] **μηκετι** *mēketi* już więcej nie [[G3371]] [[ADV]] **ωμεν** *ōmen* bylibyśmy [[G5600]] WTV-PXS-1P **νηπιοι** *nēpioi* niemowlęta [[G3516]] WTA-NPM **κλυδωνιζομενοι** *klydōnizomenoi* którzy są rzucani przez fale – którzy są kołysani [[G2831]] WTV-PNP-NPM **και** *kai* i [[G2532]] [[CONJ]] **περιφερομενοι** *periferomenoi* które są unoszone dookoła – które są obnoszone [[G4064]] WTV-PPP-NPM **παντι** *panti* każdym [[G3956]] WTA-DSM **ανεμω** *anemō* wiatrem [[G417]] WTN-DSM **της** *tēs* [[G3588]] [[T-GSF]] **διδασκαλιας** *didaskalias* nauki – nauczania [[G1319]] [[N-GSF]] **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **κυβεια** *kybeia* oszustwie – grze w kości [[G2940]] [[N-DSF]] **των** *tōn* [[G3588]] WTT-GPM **ανθρωπων** *anthrōpōn* ludzi [[G444]] WTN-GPM **εν** *en* w [[G1722]] [[PREP]] **πανουργια** *panourgia* przebiegłości – przewrotności [[G3834]] [[N-DSF]] **προς** *pros* przy [[G4314]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **μεθοδειαν** *methodeian* przebiegłości – matactwie [[G3180]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **πλανης** *planēs* zwiedzenia – błędu [[G4106]] [[N-GSF]]
###### **Ef 4,15**
 **αληθευοντες** *alētheuontes* mówiąc prawdę [[G226]] WTV-PAP-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **αγαπη** *agapē* miłości [[G26]] [[N-DSF]] **αυξησωμεν** *auksēsōmen* wzroślibyśmy [[G837]] WTV-AAS-1P **εις** *eis* w [[G1519]] [[PREP]] **αυτον** *auton* Niego [[G846]] WTP-ASM **τα** *ta* [[G3588]] WTT-APN **παντα** *panta* wszyscy [[G3956]] WTA-APN **ος** *hos* który [[G3739]] WTR-NSM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **η** *hē* [[G3588]] [[T-NSF]] **κεφαλη** *kefalē* Głowa [[G2776]] [[N-NSF]] **ο** *ho* [[G3588]] [[T-NSM]] **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]]
###### **Ef 4,16**
 **εξ** *eks* z [[G1537]] [[PREP]] **ου** *hou* którego [[G3739]] WTR-GSM **παν** *pan* całe [[G3956]] WTA-NSN **το** *to* [[G3588]] WTT-NSN **σωμα** *sōma* ciało [[G4983]] WTN-NSN **συναρμολογουμενον** *synarmologoumenon* które jest spajane – które jest zespalane [[G4883]] WTV-PPP-NSN **και** *kai* i [[G2532]] [[CONJ]] **συμβιβαζομενον** *symbibazomenon* które jest zespalane [[G4822]] WTV-PPP-NSN **δια** *dia* przez [[G1223]] [[PREP]] **πασης** *pasēs* każde [[G3956]] WTA-GSF **αφης** *hafēs* zetknięcie [[G860]] [[N-GSF]] **της** *tēs* [[G3588]] [[T-GSF]] **επιχορηγιας** *epichorēgias* zaopatrzenia – wsparcia [[G2024]] [[N-GSF]] **κατ** *kat* według [[G2596]] [[PREP]] **ενεργειαν** *energeian* działania [[G1753]] WTN-ASF **εν** *en* w [[G1722]] [[PREP]] **μετρω** *metrō* mierze [[G3358]] WTN-DSN **ενος** *henos* jednej [[G1520]] WTA-GSM **εκαστου** *hekastou* każdej [[G1538]] WTA-GSM **μερους** *merous* części [[G3313]] [[N-GSN]] **την** *tēn* [[G3588]] WTT-ASF **αυξησιν** *auksēsin* wzrost [[G838]] WTN-ASF **του** *tou* [[G3588]] WTT-GSN **σωματος** *sōmatos* ciała [[G4983]] [[N-GSN]] **ποιειται** *poieitai* czyni sobie [[G4160]] WTV-PMI-3S **εις** *eis* ku [[G1519]] [[PREP]] **οικοδομην** *oikodomēn* budowaniu [[G3619]] WTN-ASF **εαυτου** *heautou* swojemu [[G1438]] WTF-3GSM **εν** *en* w [[G1722]] [[PREP]] **αγαπη** *agapē* miłości [[G26]] [[N-DSF]]
###### **Ef 4,17**
 **τουτο** *touto* To [[G5124]] WTD-ASN **ουν** *oun* więc [[G3767]] [[CONJ]] **λεγω** *legō* mówię [[G3004]] WTV-PAI-1S **και** *kai* i [[G2532]] [[CONJ]] **μαρτυρομαι** *martyromai* świadczę [[G3143]] WTV-PNI-1S **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **μηκετι** *mēketi* już więcej nie [[G3371]] [[ADV]] **υμας** *hymas* wy [[G5209]] WTP-2AP **περιπατειν** *peripatein* postępować – chodzić [[G4043]] WTV-PAN **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-NPN **λοιπα** *loipa* pozostali [[G3062]] WTA-NPN **εθνη** *ethnē* poganie – narody [[G1484]] WTN-NPN **περιπατει** *peripatei* postępuje (postępują) – chodzi (postępują) [[G4043]] WTV-PAI-3S **εν** *en* w [[G1722]] [[PREP]] **ματαιοτητι** *mataiotēti* próżności – czczości [[G3153]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSM **νοος** *noos* umysłu – rozumu [[G3563]] [[N-GSM]] **αυτων** *autōn* ich [[G846]] WTP-GPN
###### **Ef 4,18**
 **εσκοτισμενοι** *eskotismenoi* którzy mają zaćmione – które mają pogrążone w ciemności [[G4654]] WTV-RPP-NPM **τη** *tē* [[G3588]] WTT-DSF **διανοια** *dianoia* myśl (myśli) – umysł (umysły) [[G1271]] [[N-DSF]] **οντες** *ontes* będąc [[G5607]] WTV-PXP-NPM **απηλλοτριωμενοι** *apēllotriōmenoi* którzy są obcymi – którzy są wyobcowani [[G526]] WTV-RPP-NPM **της** *tēs* (od) [[G3588]] [[T-GSF]] **ζωης** *zōēs* życia [[G2222]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **δια** *dia* z powodu [[G1223]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **αγνοιαν** *agnoian* niewiedzy – nieświadomości [[G52]] WTN-ASF **την** *tēn* [[G3588]] WTT-ASF **ουσαν** *ousan* będącej [[G5607]] WTV-PXP-ASF **εν** *en* w [[G1722]] [[PREP]] **αυτοις** *autois* nich [[G846]] WTP-DPM **δια** *dia* przez [[G1223]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **πωρωσιν** *pōrōsin* zatwardziałość – skamienienie [[G4457]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **καρδιας** *kardias* serca [[G2588]] [[N-GSF]] **αυτων** *autōn* ich [[G846]] WTP-GPM
###### **Ef 4,19**
 **οιτινες** *hoitines* którzy [[G3748]] WTR-NPM **απηλγηκοτες** *apēlgēkotes* stając się nieczułymi [[G524]] WTV-RAP-NPM **εαυτους** *heautous* siebie samych [[G1438]] WTF-3APM **παρεδωκαν** *paredōkan* oddali – wydali [[G3860]] WTV-AAI-3P **τη** *tē* [[G3588]] WTT-DSF **ασελγεια** *aselgeia* rozpuście – wyuzdaniu [[G766]] [[N-DSF]] **εις** *eis* w [[G1519]] [[PREP]] **εργασιαν** *ergasian* robieniu [[G2039]] WTN-ASF **ακαθαρσιας** *akatharsias* nieczystości [[G167]] [[N-GSF]] **πασης** *pasēs* każdej [[G3956]] WTA-GSF **εν** *en* w [[G1722]] [[PREP]] **πλεονεξια** *pleoneksia* chciwości – zachłanności [[G4124]] [[N-DSF]]
###### **Ef 4,20**
 **υμεις** *hymeis* Wy [[G5210]] WTP-2NP **δε** *de* zaś [[G1161]] [[CONJ]] **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **ουτως** *houtōs* tak [[G3779]] [[ADV]] **εμαθετε** *emathete* nauczyliście się [[G3129]] WTV-2AAI-2P **τον** *ton* [[G3588]] [[T-ASM]] **χριστον** *christon* Pomazańca [[G5547]] [[N-ASM]]
###### **Ef 4,21**
 **ειγε** *eige* jeśli rzeczywiście – jeśli oczywiście [[G1489]] WTCOND **αυτον** *auton* Go [[G846]] WTP-ASM **ηκουσατε** *ēkousate* usłyszeliście [[G191]] WTV-AAI-2P **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **αυτω** *autō* Nim [[G846]] WTP-DSM **εδιδαχθητε** *edidachthēte* zostaliście nauczeni [[G1321]] WTV-API-2P **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **αληθεια** *alētheia* prawda [[G225]] [[N-NSF]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM
###### **Ef 4,22**
 **αποθεσθαι** *apothesthai* (by) odłożyć [[G659]] WTV-2AMN **υμας** *hymas* wy [[G5209]] WTP-2AP **κατα** *kata* co do [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **προτεραν** *proteran* wcześniejszego [[G4387]] WTA-ASF **αναστροφην** *anastrofēn* postępowania – obracania się [[G391]] WTN-ASF **τον** *ton* [[G3588]] [[T-ASM]] **παλαιον** *palaion* starego [[G3820]] WTA-ASM **ανθρωπον** *anthrōpon* człowieka [[G444]] [[N-ASM]] **τον** *ton* (tego) [[G3588]] [[T-ASM]] **φθειρομενον** *ftheiromenon* który jest niszczony [[G5351]] WTV-PPP-ASM **κατα** *kata* według [[G2596]] [[PREP]] **τας** *tas* [[G3588]] WTT-APF **επιθυμιας** *epithymias* pożądliwości – żądz [[G1939]] WTN-APF **της** *tēs* [[G3588]] [[T-GSF]] **απατης** *apatēs* oszustwa – zwodzenia [[G539]] [[N-GSF]]
###### **Ef 4,23**
 **ανανεουσθαι** *ananeousthai* dawać się odnawiać [[G365]] WTV-PPN **δε** *de* zaś [[G1161]] [[CONJ]] **τω** *tō* [[G3588]] WTT-DSN **πνευματι** *pneumati* duchowi [[G4151]] WTN-DSN **του** *tou* [[G3588]] WTT-GSM **νοος** *noos* umysłu – rozumu [[G3563]] [[N-GSM]] **υμων** *hymōn* waszego [[G5216]] WTP-2GP
###### **Ef 4,24**
 **και** *kai* i [[G2532]] [[CONJ]] **ενδυσασθαι** *endysasthai* przyoblec się – wdziać na siebie [[G1746]] WTV-AMN **τον** *ton* (w) [[G3588]] [[T-ASM]] **καινον** *kainon* nowego [[G2537]] WTA-ASM **ανθρωπον** *anthrōpon* człowieka [[G444]] [[N-ASM]] **τον** *ton* (tego) [[G3588]] [[T-ASM]] **κατα** *kata* według [[G2596]] [[PREP]] **θεον** *theon* Boga [[G2316]] [[N-ASM]] **κτισθεντα** *ktisthenta* który został stworzony [[G2936]] WTV-APP-ASM **εν** *en* w [[G1722]] [[PREP]] **δικαιοσυνη** *dikaiosynē* sprawiedliwości [[G1343]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **οσιοτητι** *hosiotēti* świętości – pobożności [[G3742]] [[N-DSF]] **της** *tēs* [[G3588]] [[T-GSF]] **αληθειας** *alētheias* prawdy [[G225]] [[N-GSF]]
###### **Ef 4,25**
 **διο** *dio* Dlatego [[G1352]] [[CONJ]] **αποθεμενοι** *apothemenoi* odłożywszy [[G659]] WTV-2AMP-NPM **το** *to* [[G3588]] WTT-ASN **ψευδος** *pseudos* kłamstwo [[G5579]] WTN-ASN **λαλειτε** *laleite* mówcie [[G2980]] WTV-PAM-2P **αληθειαν** *alētheian* prawdę [[G225]] WTN-ASF **εκαστος** *hekastos* każdy [[G1538]] [[A-NSM]] **μετα** *meta* z [[G3326]] [[PREP]] **του** *tou* (tym) [[G3588]] WTT-GSM **πλησιον** *plēsion* po sąsiedzku – tuż obok [[G4139]] [[ADV]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **εσμεν** *esmen* jesteśmy [[G2070]] WTV-PXI-1P **αλληλων** *allēlōn* jedni drugich [[G240]] WTC-GPM **μελη** *melē* członki [[G3196]] WTN-NPN
###### **Ef 4,26**
 **οργιζεσθε** *orgizesthe* Bądźcie zagniewanymi [[G3710]] WTV-PPM-2P **και** *kai* i [[G2532]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **αμαρτανετε** *hamartanete* grzeszcie [[G264]] WTV-PAM-2P **ο** *ho* [[G3588]] [[T-NSM]] **ηλιος** *hēlios* słońce [[G2246]] [[N-NSM]] **μη** *mē* nie [[G3361]] [[PRT-N]] **επιδυετω** *epidyetō* niech zachodzi [[G1931]] WTV-PAM-3S **επι** *epi* przed [[G1909]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **παροργισμω** *parorgismō* gniewaniem się [[G3950]] WTN-DSM **υμων** *hymōn* waszym [[G5216]] WTP-2GP
###### **Ef 4,27**
 **μητε** *mēte* ani [[G3383]] [[CONJ]] **διδοτε** *didote* dawajcie [[G1325]] WTV-PAM-2P **τοπον** *topon* miejsca [[G5117]] [[N-ASM]] **τω** *tō* [[G3588]] WTT-DSM **διαβολω** *diabolō* oszczercy – diabłu [[G1228]] WTA-DSM
###### **Ef 4,28**
 **ο** *ho* [[G3588]] [[T-NSM]] **κλεπτων** *kleptōn* Kradnący [[G2813]] [[V-PAP-NSM]] **μηκετι** *mēketi* już więcej nie [[G3371]] [[ADV]] **κλεπτετω** *kleptetō* niech kradnie [[G2813]] WTV-PAM-3S **μαλλον** *mallon* bardziej [[G3123]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **κοπιατω** *kopiatō* niech trudzi się [[G2872]] WTV-PAM-3S **εργαζομενος** *ergazomenos* wypracowując [[G2038]] WTV-PNP-NSM **το** *to* [[G3588]] WTT-ASN **αγαθον** *agathon* dobre [[G18]] WTA-ASN **ταις** *tais* (własnymi) [[G3588]] WTT-DPF **χερσιν** *chersin* rękami [[G5495]] WTN-DPF **ινα** *hina* aby [[G2443]] [[CONJ]] **εχη** *echē* miałby [[G2192]] WTV-PAS-3S **μεταδιδοναι** *metadidonai* przekazywać [[G3330]] WTV-PAN **τω** *tō* [[G3588]] WTT-DSM **χρειαν** *chreian* potrzebę [[G5532]] WTN-ASF **εχοντι** *echonti* mającemu [[G2192]] WTV-PAP-DSM
###### **Ef 4,29**
 **πας** *pas* Każde [[G3956]] [[A-NSM]] **λογος** *logos* słowo [[G3056]] [[N-NSM]] **σαπρος** *sapros* zgniłe – bezużyteczne [[G4550]] [[A-NSM]] **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **στοματος** *stomatos* ust [[G4750]] [[N-GSN]] **υμων** *hymōn* waszych [[G5216]] WTP-2GP **μη** *mē* nie [[G3361]] [[PRT-N]] **εκπορευεσθω** *ekporeuesthō* niech wychodzi [[G1607]] WTV-PNM-3S **αλλ** *all* ale [[G235]] [[CONJ]] **ει** *ei* jeśli [[G1487]] WTCOND **τις** *tis* jakieś [[G5100]] WTX-NSM **αγαθος** *agathos* dobre [[G18]] [[A-NSM]] **προς** *pros* do [[G4314]] [[PREP]] **οικοδομην** *oikodomēn* budowania [[G3619]] WTN-ASF **της** *tēs* (gdy) [[G3588]] [[T-GSF]] **χρειας** *chreias* trzeba [[G5532]] [[N-GSF]] **ινα** *hina* aby [[G2443]] [[CONJ]] **δω** *dō* dałoby [[G1325]] WTV-2AAS-3S **χαριν** *charin* łaskę [[G5485]] WTN-ASF **τοις** *tois* [[G3588]] WTT-DPM **ακουουσιν** *akouousin* słuchającym [[G191]] WTV-PAP-DPM
###### **Ef 4,30**
 **και** *kai* i [[G2532]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **λυπειτε** *lypeite* smućcie [[G3076]] WTV-PAM-2P **το** *to* [[G3588]] WTT-ASN **πνευμα** *pneuma* Ducha [[G4151]] WTN-ASN **το** *to* [[G3588]] WTT-ASN **αγιον** *hagion* Świętego [[G40]] WTA-ASN **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εν** *en* w [[G1722]] [[PREP]] **ω** *hō* którym [[G3739]] WTR-DSN **εσφραγισθητε** *esfragisthēte* zostaliście opieczętowani [[G4972]] WTV-API-2P **εις** *eis* w [[G1519]] [[PREP]] **ημεραν** *hēmeran* dzień [[G2250]] WTN-ASF **απολυτρωσεως** *apolytrōseōs* odkupienia [[G629]] [[N-GSF]]
###### **Ef 4,31**
 **πασα** *pasa* Każda [[G3956]] WTA-NSF **πικρια** *pikria* gorycz – gorzkość [[G4088]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **θυμος** *thymos* wzburzenie – szał [[G2372]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **οργη** *orgē* gniew [[G3709]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **κραυγη** *kraugē* krzyk – wrzask [[G2906]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **βλασφημια** *blasfēmia* bluźnierstwo – krzywdzące mówienie [[G988]] [[N-NSF]] **αρθητω** *arthētō* niech zostanie zabrane – niech zostanie usunięte [[G142]] WTV-APM-3S **αφ** *af* od [[G575]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **συν** *syn* razem z [[G4862]] [[PREP]] **παση** *pasē* każdą [[G3956]] WTA-DSF **κακια** *kakia* złością – niegodziwością [[G2549]] [[N-DSF]]
###### **Ef 4,32**
 **γινεσθε** *ginesthe* Stawajcie się [[G1096]] WTV-PNM-2P **δε** *de* zaś [[G1161]] [[CONJ]] **εις** *eis* ku [[G1519]] [[PREP]] **αλληλους** *allēlous* jedni drugim [[G240]] WTC-APM **χρηστοι** *chrēstoi* łagodni – przyjemni [[G5543]] WTA-NPM **ευσπλαγχνοι** *eusplagchnoi* miłosierni – litościwi [[G2155]] WTA-NPM **χαριζομενοι** *charizomenoi* darowując [[G5483]] WTV-PNP-NPM **εαυτοις** *heautois* sobie samym [[G1438]] WTF-3DPM **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **εχαρισατο** *echarisato* okazał łaskę – darował [[G5483]] WTV-ADI-3S **υμιν** *hymin* wam [[G5213]] WTP-2DP
