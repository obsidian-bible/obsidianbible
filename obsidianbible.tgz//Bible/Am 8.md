# Am 8 BT5
###### **Am 8,1**
 To mi ukazał Pan Bóg:oto kosz dojrzałych owoców.
###### **Am 8,2**
 I zapytał: «***Co ty widzisz, Amosie?***»Odpowiedziałem: «***Kosz dojrzałych owoców***».Rzekł Pan do mnie:«***Dojrzał do kary lud mój izraelski. Już mu nie przepuszczę.***
###### **Am 8,3**
 ***Tego dnia pieśni dworskie zamienią się w lamenty– wyrocznia Pana Boga –mnóstwo trupów, na każdym miejscu je rozrzucę. Cisza!***»
###### **Am 8,4**
 Słuchajcie tego wy, którzy gnębicie ubogiego, a bezrolnego pozostawiacie bez pracy,
###### **Am 8,5**
 którzy mówicie: «***Kiedyż minie nów księżyca,byśmy mogli sprzedawać zboże, i kiedy szabat, byśmy mogli otworzyć spichlerz?A będziemy zmniejszać efę, powiększać sykli wagę podstępnie fałszować.***
###### **Am 8,6**
 ***Będziemy kupować biednego za srebro, a ubogiego za parę sandałów, i plewy pszeniczne będziemy sprzedawać***».
###### **Am 8,7**
 Poprzysiągł Pan na dumę Jakuba:«***Nie zapomnę nigdy wszystkich ich uczynków***».
###### **Am 8,8**
 Czyż z tego powodu ziemia nie zadrżyi czyż nie będą lamentować wszyscy jej miesz-kańcy? Wzbierze ona cała jak Nil, wzburzy się i opadnie jak Nil egipski.
###### **Am 8,9**
 Owego dnia– wyrocznia Pana Boga – zajdzie słońce w południe i w jasny dzień zaciemnię ziemię.
###### **Am 8,10**
 Zamienię święta wasze w żałobę, a wszystkie wasze pieśni w lamentacje; nałożę na wszystkie biodra wory, a wszystkie głowy ogolęi uczynię żałobę jak po jedynaku, a dni ostatnie jakby dniem goryczy.
###### **Am 8,11**
 Oto nadejdą dni – wyrocznia Pana Boga – gdy ześlę głód na ziemię, nie głód chleba ani pragnienie wody, lecz głód słuchania słów Pańskich.
###### **Am 8,12**
 Wtedy błąkać się będą od morza do morza, z północy na wschód będą krążyli, by znaleźć słowo Pańskie, lecz go nie znajdą.
###### **Am 8,13**
 W dzień ten pomdleją z pragnieniapiękne dziewice i młodzieńcy.
###### **Am 8,14**
 Ci, którzy przysięgają na Winę Samariii mówią: «***Na życie twego boga, Danie!na życie boga, Beer-Szebo!***» – upadną i już nie powstaną.
# Am 8 PAU
###### **Am 8,1**
 To mi ukazał PAN BÓG: oto kosz dojrzałych owoców.
###### **Am 8,2**
 I zapytał: „Co widzisz, Amosie?”. Odpowiedziałem: „Kosz dojrzałych owoców”. PAN powiedział do mnie: „Dojrzał do kary mój lud izraelski, już mu więcej nie przebaczę.
###### **Am 8,3**
 Pieśniami świątynnymi będą lamentować tego dnia - wyrocznia PANA BOGA. Oto mnóstwo trupów, rozrzuconych wszędzie. Cisza!”.
###### **Am 8,4**
 Słuchajcie tego wy, którzy depczecie ubogiego i niszczycie biednych ziemi,
###### **Am 8,5**
 którzy mówicie: „Kiedy minie Nów księżyca, byśmy mogli sprzedawać zboże? Kiedy minie szabat, byśmy mogli sprzedawać pszenicę, zmniejszając efę, i powiększać sykla, fałszując wagę.
###### **Am 8,6**
 Będziemy kupować biednego za srebro, a ubogiego za parę sandałów i sprzedawać plewy pszeniczne”.
###### **Am 8,7**
 Przysiągł PAN na chwałę Jakuba: „Nigdy nie zapomnę żadnego z ich uczynków”.
###### **Am 8,8**
 Czyż nie zadrży ziemia z tego powodu i czy nie będą lamentować wszyscy jej mieszkańcy? Nie wzbierze ona jak wody Nilu, nie wzburzy się i nie opadnie jak rzeka Egiptu?
###### **Am 8,9**
 Wyrocznia PANA BOGA: W tym dniu słońce zajdzie w południe i w środku dnia zapadną ciemności na ziemi.
###### **Am 8,10**
 Zamienię wasze święta w żałobę, a wszystkie wasze pieśni w lamentacje; nałożę wory na wszystkie biodra i ogolę każdą głowę. Sprowadzę żałobę jak po stracie jedynaka, a to, co nastąpi, będzie dniem goryczy.
###### **Am 8,11**
 Wyrocznia PANA BOGA: Oto nadejdą dni, gdy ześlę głód na kraj, nie tyle głód chleba czy pragnienie wody, co głód słuchania słów PANA.
###### **Am 8,12**
 Wtedy będą się błąkać od morza do morza, krążyć z północy na wschód, aby szukać słowa PANA, lecz go nie znajdą.
###### **Am 8,13**
 W tym dniu omdleją z pragnienia piękne dziewice i młodzieńcy.
###### **Am 8,14**
 Upadną i już nie powstaną ci, którzy przysięgają na obrzydliwego bożka Samarii i mówią: „Na życie twego boga, Danie!”. lub: „Na życie boga Beer-Szeby!”.
# Am 8 BP
###### **Am 8,1**
 To mi ukazał Jahwe-Pan: kosz z dojrzałymi owocami.
###### **Am 8,2**
 I rzekł do mnie: "Co widzisz, Amosie?" Odpowiedziałem: "Kosz z dojrzałymi owocami". A na to Jahwe powiedział do mnie: "Nadszedł kres dla narodu mego, Izraela, już mu dłużej nie będę pobłażał.
###### **Am 8,3**
 W owym dniu pieśni w pałacu zamienią się w jęki - powiedział Jahwe-Pan - będzie mnóstwo trupów porzuconych gdzie bądź".
###### **Am 8,4**
 Słuchajcie tego, wy, co uciskacie biednego i co czyhacie na zgubę ubogich w kraju,
###### **Am 8,5**
 wy, którzy powiadacie: "Kiedyż to minie nów księżyca, abyśmy mogli sprzedać swoje zboże, i szabat, abyśmy mogli otworzyć spichrze pełne zboża; abyśmy mogli umniejszać efę, a powiększać sykl, i oszukiwać za pomocą fałszywej wagi;
###### **Am 8,6**
 abyśmy mogli kupować nędzarzy za pieniądze, a biednych za parę obuwia, i sprzedawać nawet poślad zboża?"
###### **Am 8,7**
 Jahwe poprzysiągł na dumę Jakuba: "Nigdy nie zapomnę żadnego ich uczynku!"
###### **Am 8,8**
 Czyż wobec tego ziemi nie ogarnie drżenie, a wszyscy jej mieszkańcy nie pogrążą się w smutku? Podniesie się cała jak Nil (i znowu się cofnie) i opadnie jak Nil w Egipcie.
###### **Am 8,9**
 W owym dniu - mówi Jahwe-Pan - rozkażę słońcu zajść w południe i okryję ziemię ciemnością w jasny dzień;
###### **Am 8,10**
 święta wasze zamienię w żałobę, a wszystkie wasze śpiewy w lament; opaszę wszystkie biodra worem, a każdą głowę naznaczę łysiną. Sprowadzę żałobę, jak po jedynaku; a koniec będzie podobny do dnia pełnego goryczy.
###### **Am 8,11**
 Oto nadchodzą dni - mówi Jahwe-Pan - gdy ześlę głód na ziemię: nie głód chleba ani pragnienie wody, lecz [głód] usłyszenia słowa Jahwe.
###### **Am 8,12**
 Zataczając się będą chodzili od morza do morza i błąkać się będą od północy aż na wschód w poszukiwaniu słowa Jahwe, ale go nie znajdą.
###### **Am 8,13**
 Wtedy omdlewać będą z pragnienia piękne dziewice i kwiat waszej młodzieży;
###### **Am 8,14**
 upadną i już się nie podźwigną ci, co przysięgają na grzech Samarii i którzy mówią: "Na życie twego boga, Dan!" "Jako żyw twój ulubieniec, Beerszebo!"
# Am 8 BR
###### **Am 8,1**
 A oto, co pokazał mi Pan w kolejnym widzeniu: Zobaczyłem kosz pełen dojrzałych owoców.
###### **Am 8,2**
 A (Pan) mnie zapytał: Co widzisz, Amosie? Odpowiedziałem więc: Widzę kosz pełen dojrzałych owoców. Wtedy Pan rzekł do mnie: Lud mój jest już dojrzały do zagłady. Tym razem już im nie przebaczę.
###### **Am 8,3**
 W dniu owym radosne pieśni pałacowe zmienią się w żałobne lamentacje. Tak powiedział Pan. Wszędzie leży pełno trupów, są porozrzucane dokoła. Cisza.
###### **Am 8,4**
 Posłuchajcie mnie, wy, którzy uciskacie słabych, wy, którzy ubogich gnębicie w całym kraju.
###### **Am 8,5**
 Pytacie z niecierpliwością: Kiedyż skończą się święta nowiu księżyca? - chcielibyśmy już zacząć sprzedawać nasze zboże. Kiedyż skończy się szabat? - chcielibyśmy otworzyć nasze śpichlerze, umniejszać miary, a podnosić ceny fałszując odważniki.
###### **Am 8,6**
 Chcemy znów za pieniądze kupować bezbronnych, biedaków - za jedną sandałów parę, pieniądze brać będziemy nawet za śmieci ze zboża.
###### **Am 8,7**
 Poprzysiągł Pan tedy na dumę Jakuba: Żadnego z twoich uczynków nigdy nie zapomnę.
###### **Am 8,8**
 Czy już dlatego tylko nie zadrży cała ziemia? Czyż smutek nie powinien ogarnąć wszystkich jej mieszkańców? Czyż nie powinna się wzburzyć jak Nil cała ziemia, a potem znów opaść jak owa potężna Egiptu rzeka?
###### **Am 8,9**
 W dniu owym - wyrocznia Boga i Pana - sprawię, że słońce już w południe zajdzie i w pełni dnia ciemności rozciągnę nad ziemią.
###### **Am 8,10**
 Wasze święta radosne w żałobę zamienię i wszystkie wasze pieśni - w smutne lamentacje. Wszystkich przyodzieję w wory pokutników i sprawię, ze z głów powypadają ludziom wszystkie włosy. I cały kraj okryję bolesną żałobą, taką jak po śmierci syna jedynaka. I bedą dni ostatnie jakby dniem gorzkiej śmierci.
###### **Am 8,11**
 Oto nadchodzą dni - wyrocznia Boga i Pana - w których ześlę na kraj cały głód bardzo dotkliwy. Nie będzie to jednak głód chleba ani wody pragnienie, lecz prawdziwa tęsknota za słowem Pańskim.
###### **Am 8,12**
 Będą się ludzie wtedy błąkać od morza do morza, od strony północnej ciągnąć ku wschodowi i wszędzie szukać będą Pańskiego słowa, lecz znaleźć go nie będą umieli.
###### **Am 8,13**
 W dniu owym padać będą z pragnienia piękne młode dziewczęta i równie piękni młodzieńcy.
###### **Am 8,14**
 Wszyscy ci, co przysięgali na samarytańskie podobizny bożków, ci, co mówią: Na życie twego boga, Danie!, na życie twego umiłowanego Beer-Szebo, wszyscy oni padną wtedy na ziemię i już się z niej nie podniosą.
# Am 8 WUJ
###### **Am 8,1**
 To mi ukazał Pan Bóg: a oto hak owocu.
###### **Am 8,2**
 I rzekł: Co ty widzisz Amos? i rzekłem: Hak owocu. I rzekł Pan do mnie: Przyszedł koniec na lud mój Izraelski, nie przydam więcej, abym go minął.
###### **Am 8,3**
 A będą skrzypieć zawiasy kościelne w on dzień, mówi Pan Bóg: wiele ich pomrze: na każdem miejscu milczenie rozrzucone będzie.
###### **Am 8,4**
 Słuchajcie tego, którzy trapicie ubogiego, a czynicie, że giną niedostateczni na ziemi,
###### **Am 8,5**
 Mówiąc: kiedy minie miesiąc, i będziem przedawali towary: i sobota, i otworzymy zboże, abyśmy umniejszali miary, a przyczyniali sykla, i podrzucali szale zdradliwe,
###### **Am 8,6**
 Abyśmy dostali za srebro nędzników, a ubogich za boty, a żebyśmy plewy pszeniczne przedali.
###### **Am 8,7**
 Przysiągł Pan przeciw pysze Jakóbowej: jeźliże zapomnię aż do końca wszystkich uczynków ich.
###### **Am 8,8**
 Izali dla tego nie poruszy się ziemia, a płakać będzie wszelki obywatel jej, i wzbierze wszystek jako rzeka, i będzie wygnany i zbieży jako potok Egiptski.
###### **Am 8,9**
 I będzie dnia onego, mówi Pan Bóg: zajdzie słońce w południe, i uczynię, że się zaćmi ziemia w dzień jasności:
###### **Am 8,10**
 I obrócę święta wasze w płacz, a wszystkie pieśni wasze w narzekanie: i oblokę wór na wszelki grzbiet wasz, a na każdą głowę obłysienie: i położę ją jako żałobę jednorodzonego, a ostateczne rzeczy jej jako dzień gorzki.
###### **Am 8,11**
 Oto dni idą, mówi Pan: i puszczę głód na ziemię: nie głód chleba, ani pragnienie wody: ale słuchania słowa Pańskiego.
###### **Am 8,12**
 I wzruszą się od morza, aż do morza, i od północy aż na wschód, będą obchodzić szukając słowa Pańskiego, a nie najdą.
###### **Am 8,13**
 Onego dnia zemdleją panienki piękne, młodzieńcy dla pragnienia.
###### **Am 8,14**
 Którzy przysięgają przez grzech Samaryi, a mówią: Żywie Bóg twój Dan, i żywie też droga w Bersabei upadną a nie powstaną więcej.
