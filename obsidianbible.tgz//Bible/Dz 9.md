# Dz 9 BT5
###### **Dz 9,1**
 Szaweł ciągle jeszcze siał grozę i dyszał żądzą zabijania uczniów Pańskich. Udał się do arcykapłana
###### **Dz 9,2**
 i poprosił go o listy do synagog w Damaszku, aby mógł uwięzić i przyprowadzić do Jeruzalem mężczyzn i kobiety, zwolenników tej drogi, jeśliby jakichś znalazł.
###### **Dz 9,3**
 Gdy zbliżał się już w swojej podróży do Damaszku, olśniła go nagle światłość z nieba.
###### **Dz 9,4**
 A gdy upadł na ziemię, usłyszał głos, który mówił: «***Szawle, Szawle, dlaczego Mnie prześladujesz?***»
###### **Dz 9,5**
 «***Kto jesteś, Panie?***» – powiedział. A On: «***Ja jestem Jezus, którego ty prześladujesz.***
###### **Dz 9,6**
 ***Wstań i wejdź do miasta, tam ci powiedzą, co masz czynić***».
###### **Dz 9,7**
 Ludzie, którzy mu towarzyszyli w drodze, oniemieli ze zdumienia, słyszeli bowiem głos, lecz nie widzieli nikogo.
###### **Dz 9,8**
 Szaweł podniósł się z ziemi, a kiedy otworzył oczy, nic nie widział. Zaprowadzili go więc do Damaszku, trzymając za ręce.
###### **Dz 9,9**
 Przez trzy dni nic nie widział i ani nie jadł, ani nie pił.
###### **Dz 9,10**
 W Damaszku znajdował się pewien uczeń, imieniem Ananiasz. «***Ananiaszu!***» – przemówił do niego Pan w widzeniu. A on odrzekł: «***Jestem, Panie!***»
###### **Dz 9,11**
 A Pan do niego: «***Idź na ulicę Prostą i zapytaj w domu Judy o Szawła z Tarsu, bo właśnie się [tam] modli***».
###### **Dz 9,12**
 (I ujrzał [Szaweł] w widzeniu, jak człowiek imieniem Ananiasz wszedł i położył na niego ręce, aby przejrzał.)
###### **Dz 9,13**
 «***Panie – odpowiedział Ananiasz – słyszałem z wielu stron, jak dużo złego wyrządził ten człowiek świętym Twoim w Jerozolimie.***
###### **Dz 9,14**
 ***I ma on tutaj władzę od arcykapłanów, aby więzić wszystkich, którzy wzywają Twego imienia***».
###### **Dz 9,15**
 «***Idź***» – odpowiedział mu Pan – «***bo wybrałem sobie tego człowieka jako narzędzie. On zaniesie imię moje do pogan i królów, i do synów Izraela.***
###### **Dz 9,16**
 ***I ukażę mu, jak wiele będzie musiał wycierpieć dla mego imienia***».
###### **Dz 9,17**
 Wtedy Ananiasz poszedł. Wszedł do domu, położył na niego ręce i powiedział: «***Szawle, bracie, Pan Jezus, Ten, co ukazał ci się na drodze, którą szedłeś, przysłał mnie, abyś przejrzał i został napełniony Duchem Świętym***».
###### **Dz 9,18**
 Natychmiast jakby łuski spadły z jego oczu i odzyskał wzrok, i został ochrzczony.
###### **Dz 9,19**
 A gdy spożył posiłek, wzmocnił się.
###### **Dz 9,20**
 Jakiś czas spędził z uczniami w Damaszku i zaraz zaczął głosić w synagogach, że Jezus jest Synem Bożym.
###### **Dz 9,21**
 Wszyscy, którzy go słyszeli, mówili zdumieni: «***Czy to nie ten sam, który w Jeruzalem prześladował wyznawców tego imienia i przybył tu po to, aby ich uwięzić i zaprowadzić do arcykapłana?***»
###### **Dz 9,22**
 A Szaweł występował coraz odważniej i szerzył zamieszanie wśród Żydów mieszkających w Damaszku, dowodząc: «***Ten jest Mesjaszem***».
###### **Dz 9,23**
 Po upływie dłuższego czasu Żydzi postanowili go zgładzić.
###### **Dz 9,24**
 Szaweł dowiedział się o ich zamiarach. A strzegli bram we dnie i w nocy, aby go zgładzić.
###### **Dz 9,25**
 Uczniowie więc spuścili go nocą w koszu na sznurze przez mur i wyprawili.
###### **Dz 9,26**
 Kiedy przybył do Jeruzalem, próbował przyłączyć się do uczniów, lecz wszyscy bali się go, nie wierząc, że jest uczniem.
###### **Dz 9,27**
 Dopiero Barnaba przygarnął go i zaprowadził do Apostołów, i opowiedział im, jak w drodze [Szaweł] ujrzał Pana, który przemówił do niego, i z jaką siłą przekonania występował w Damaszku w imię Jezusa.
###### **Dz 9,28**
 Dzięki temu przebywał z nimi w Jerozolimie, z siłą przekonania przemawiając w imię Pana.
###### **Dz 9,29**
 Przemawiał też i rozprawiał z hellenistami, którzy usiłowali go zgładzić.
###### **Dz 9,30**
 Bracia jednak, dowiedziawszy się o tym, odprowadzili go do Cezarei i wysłali do Tarsu.
###### **Dz 9,31**
 A Kościół cieszył się pokojem w całej Judei, Galilei i Samarii. Rozwijał się i żył bogobojnie, i obfitował w pociechę Ducha Świętego.
###### **Dz 9,32**
 Kiedy Piotr odwiedzał wszystkich, przyszedł też do świętych, którzy mieszkali w Liddzie.
###### **Dz 9,33**
 Znalazł tam pewnego człowieka, imieniem Eneasz, który był sparaliżowany i od ośmiu lat leżał w łóżku.
###### **Dz 9,34**
 «***Eneaszu***» – powiedział do niego Piotr – «***Jezus Chrystus cię uzdrawia, wstań i zaściel swoje łóżko!***» I natychmiast wstał.
###### **Dz 9,35**
 Widzieli go wszyscy mieszkańcy Liddy i Szaronu i nawrócili się do Pana.
###### **Dz 9,36**
 Mieszkała też w Jafie pewna uczennica imieniem Tabita, co znaczy Gazela. Czyniła ona dużo dobrego i dawała hojne jałmużny.
###### **Dz 9,37**
 Wtedy właśnie zachorowała i umarła. Obmyto ją i położono w izbie na piętrze.
###### **Dz 9,38**
 Lidda leżała blisko Jafy; gdy więc uczniowie dowiedzieli się, że jest tam Piotr, wysłali do niego dwóch posłańców z prośbą: «***Przyjdź do nas niezwłocznie***».
###### **Dz 9,39**
 Piotr poszedł z nimi, a gdy przybył, zaprowadzili go do izby na górze. Otoczyły go wszystkie wdowy i pokazywały mu ze łzami w oczach chitony i płaszcze, które zrobiła im Gazela za swego życia.
###### **Dz 9,40**
 Po usunięciu wszystkich Piotr upadł na kolana i modlił się. Potem zwrócił się do zwłok i rzekł: «***Tabito, wstań!***» A ona otwarła oczy i zobaczywszy Piotra, usiadła.
###### **Dz 9,41**
 Piotr podał jej rękę i podniósł ją. Zawołał świętych i wdowy, i ujrzeli ją żywą.
###### **Dz 9,42**
 Wieść o tym rozeszła się po całej Jafie, i wielu uwierzyło w Pana.
###### **Dz 9,43**
 [Piotr] zaś jeszcze przez dłuższy czas przebywał w Jafie u niejakiego Szymona, garbarza.
# Dz 9 PAU
###### **Dz 9,1**
 Szaweł natomiast wciąż pałał nienawiścią i chęcią mordowania uczniów Pana. Poszedł więc do najwyższego kapłana
###### **Dz 9,2**
 i poprosił o listy polecające do synagog w Damaszku. Chciał bowiem odszukać zwolenników tej drogi, zarówno mężczyzn, jak i kobiety, aby ich pojmać i przyprowadzić do Jeruzalem.
###### **Dz 9,3**
 Był właśnie w podróży i zbliżał się już do Damaszku, gdy nagle poraziło go światło z nieba.
###### **Dz 9,4**
 Upadł na ziemię i usłyszał słowa: „Szawle, Szawle! Dlaczego Mnie prześladujesz?”.
###### **Dz 9,5**
 A on zapytał: „Kim jesteś, Panie?”. I usłyszał: „Ja jestem Jezus, którego ty prześladujesz.
###### **Dz 9,6**
 Wstań i idź do miasta. Tam dowiesz się, co masz czynić”.
###### **Dz 9,7**
 A ludzie, którzy z nim podróżowali, oniemieli ze zdumienia, gdyż słyszeli głos, lecz nikogo nie widzieli.
###### **Dz 9,8**
 Szaweł podniósł się z ziemi. Otworzył oczy, ale nic nie widział. Trzymając go za ręce, doprowadzili go do Damaszku.
###### **Dz 9,9**
 Tam przez trzy dni nic nie widział. Nie jadł też ani nie pił.
###### **Dz 9,10**
 Przebywał zaś w Damaszku pewien uczeń o imieniu Ananiasz. Pan powiedział do niego w widzeniu: „Ananiaszu!”. A on odpowiedział: „Słucham, Panie!”.
###### **Dz 9,11**
 Pan mu rozkazał: „Idź natychmiast na ulicę Prostą i odszukaj w domu Judy Szawła z Tarsu. On modli się w tej chwili”.
###### **Dz 9,12**
 A Szaweł miał widzenie. Ujrzał Ananiasza, który wchodzi do domu i kładzie na nim ręce, aby odzyskał wzrok.
###### **Dz 9,13**
 Wówczas Ananiasz odrzekł: „Słyszałem od wielu ludzi, ile zła wyrządził ten człowiek Twoim świętym w Jeruzalem.
###### **Dz 9,14**
 Otrzymał on od wyższych kapłanów pełnomocnictwo, aby także tutaj więzić tych, którzy wyznają Twoje imię”.
###### **Dz 9,15**
 Lecz Pan mu odpowiedział: „Idź! Wybrałem go sobie za narzędzie. On zaniesie moje imię do pogan i królów, i narodu izraelskiego.
###### **Dz 9,16**
 Objawię mu także, jak wiele będzie musiał wycierpieć z powodu mego imienia”.
###### **Dz 9,17**
 Wówczas Ananiasz poszedł. Wszedł do owego domu, położył na niego ręce i powiedział: „Szawle, bracie! Pan Jezus, który ukazał ci się w czasie podróży, przysyła mnie do ciebie, abyś odzyskał wzrok i aby napełnił cię Duch Święty”.
###### **Dz 9,18**
 A natychmiast jakby łuski spadły mu z oczu i znów zaczął widzieć. Potem wstał i przyjął chrzest.
###### **Dz 9,19**
 A następnie wzmocnił się, spożywając posiłek. Przez kilka dni pozostał u uczniów w Damaszku.
###### **Dz 9,20**
 Zaraz potem zaczął nauczać w synagogach, że Jezus jest Synem Bożym.
###### **Dz 9,21**
 Wszyscy, którzy go słuchali, byli tym zaskoczeni i pytali: „Czyż nie jest to ten sam człowiek, który w Jeruzalem prześladował wyznawców Jezusa? Czyż nie przybył także tutaj po to, aby ich uwięzić i zaprowadzić przed wyższych kapłanów?”.
###### **Dz 9,22**
 A Szaweł coraz bardziej się umacniał i wywoływał zamieszanie wśród Żydów mieszkających w Damaszku, dowodząc, że Jezus jest Chrystusem.
###### **Dz 9,23**
 Po upływie dłuższego czasu Żydzi postanowili go zabić.
###### **Dz 9,24**
 Szaweł dowiedział się jednak o ich zamiarze. A ponieważ oni dniem i nocą strzegli bram miasta, aby go zabić,
###### **Dz 9,25**
 w nocy uczniowie spuścili go w koszu z murów miasta.
###### **Dz 9,26**
 Kiedy przybył do Jeruzalem, chciał przyłączyć się do uczniów. Ale wszyscy się go bali, gdyż nie wierzyli, że naprawdę został uczniem.
###### **Dz 9,27**
 Dopiero Barnaba przyjął go i zaprowadził do apostołów. Opowiedział im, jak w czasie podróży ujrzał Pana i co mu powiedział. A także o tym, jak w Damaszku z wielką odwagą nauczał w imię Jezusa.
###### **Dz 9,28**
 Od tej chwili przebywał z nimi w Jeruzalem i śmiało przemawiał w imię Pana.
###### **Dz 9,29**
 Nauczał i rozprawiał też z hellenistami, którzy jednak usiłowali go zgładzić.
###### **Dz 9,30**
 Lecz gdy bracia dowiedzieli się o tym, odprowadzili go do Cezarei i wysłali do Tarsu.
###### **Dz 9,31**
 A Kościół cieszył się pokojem w całej Judei, Galilei i Samarii. Rozwijał się i wzrastał w bojaźni Pańskiej. I wzmacniał się pociechą Ducha Świętego.
###### **Dz 9,32**
 Piotr odwiedzał wszystkich. Przyszedł też do świętych mieszkających w Liddzie.
###### **Dz 9,33**
 Spotkał tam człowieka o imieniu Eneasz, który był sparaliżowany i od ośmiu lat nie wstawał z łóżka.
###### **Dz 9,34**
 Piotr mu powiedział: „Eneaszu, Jezus Chrystus uzdrawia cię. Wstań i pościel łóżko!”. A on natychmiast wstał.
###### **Dz 9,35**
 Wszyscy zaś mieszkańcy Liddy i Saronu, którzy to widzieli, nawrócili się do Pana.
###### **Dz 9,36**
 W Jafie mieszkała uczennica imieniem Tabita, to znaczy Gazela. Czyniła ona dużo dobrego i pomagała ubogim.
###### **Dz 9,37**
 Właśnie w tym czasie zachorowała i umarła. Obmyto jej ciało i położono w pokoju na piętrze.
###### **Dz 9,38**
 Lidda znajdowała się blisko Jafy. Uczniowie dowiedzieli się, że jest tam Piotr. Wysłali więc dwóch ludzi i prosili: „Przyjdź szybko do nas!”.
###### **Dz 9,39**
 Piotr zaraz poszedł z nimi. Gdy zaprowadzono go na piętro, podeszły do niego wdowy i płacząc, pokazały mu płaszcze i tuniki, które zrobiła im Gazela.
###### **Dz 9,40**
 Piotr wyprosił stamtąd wszystkich, upadł na kolana i modlił się. Potem powiedział: „Tabito, wstań!”. Ona otworzyła oczy, spojrzała na Piotra i usiadła.
###### **Dz 9,41**
 A On podał jej rękę i podniósł ją. Potem zawołał świętych oraz wdowy i pokazał im, że ona żyje.
###### **Dz 9,42**
 Wiadomość o tym rozeszła się po całej Jafie i wielu uwierzyło w Pana.
###### **Dz 9,43**
 Piotr zaś jeszcze przez dłuższy czas pozostał w Jafie w domu garbarza Szymona.
# Dz 9 BP
###### **Dz 9,1**
 A Szaweł nadal pałał nienawiścią i chęcią mordowania uczniów Pana. Udał się do arcykapłana
###### **Dz 9,2**
 i poprosił go o listy do synagog w Damaszku, aby mógł uwięzić i przyprowadzić do Jerozolimy wyznawców Jezusa, mężczyzn i kobiety, gdyby ich znalazł.
###### **Dz 9,3**
 W drodze, gdy zbliżał się już do Damaszku, olśniło go nagle światło z nieba;
###### **Dz 9,4**
 upadł wtedy na ziemię i usłyszał głos, skierowany do siebie: "Szawle, Szawle, czemu Mnie prześladujesz?"
###### **Dz 9,5**
 A on zapytał: "Kim jesteś, Panie?" "Ja jestem Jezusem, którego ty prześladujesz - odpowiedział. -
###### **Dz 9,6**
 Wstań, idź do miasta, a tam ci powiedzą, co powinieneś czynić".
###### **Dz 9,7**
 Ludzie towarzyszący mu w drodze stanęli jak wryci, słyszeli bowiem głos, ale nikogo nie widzieli.
###### **Dz 9,8**
 Szaweł zaś podniósł się z ziemi, a gdy otworzył oczy, nic nie widział. Wtedy wzięli go pod ręce i przyprowadzili do Damaszku.
###### **Dz 9,9**
 Przez trzy dni nic nie widział, nie jadł i nie pił.
###### **Dz 9,10**
 W Damaszku mieszkał uczeń Ananiasz; do niego w widzeniu zwrócił się Pan: "Ananiaszu". "Jestem, Panie" - odpowiedział.
###### **Dz 9,11**
 "Wstań, idź na ulicę Prostą - powiedział do niego - i zapytaj w domu Judy o Szawła z Tarasu - on się tam modli".
###### **Dz 9,12**
 (Zobaczył Szaweł w widzeniu Ananiasza, jak wchodzi, wkłada ręce, by przywrócić mu wzrok).
###### **Dz 9,13**
 "Panie - odpowiedział Ananiasz - słyszałem od wielu, ile zła ten człowiek wyrządził świętym Twoim w Jerozolimie.
###### **Dz 9,14**
 Ma nawet polecenie od arcykapłanów, by więzić wszystkich Twoich wyznawców".
###### **Dz 9,15**
 Pan mu odpowiedział: "Idź, bo on jest narzędziem przeze Mnie wybranym, on zaniesie imię moje narodom, królom i synom Izraela.
###### **Dz 9,16**
 Ja mu ukażę, co będzie musiał wycierpieć dla imienia mego".
###### **Dz 9,17**
 Wtedy Ananiasz poszedł, udał się do owego domu, położył na nim ręce i powiedział: "Szawle, bracie, Pan Jezus, Ten, co ukazał ci się w drodze, którą szedłeś, przysłał mnie, abyś odzyskał wzrok i napełnił cię Duch Święty".
###### **Dz 9,18**
 Nagle z jego oczu spadły jakby łuski, odzyskał wzrok, wstał potem i przyjął chrzest,
###### **Dz 9,19**
 następnie spożył pokarm i odzyskał siły. Przez kilka dni pozostał w Damaszku u uczniów.
###### **Dz 9,20**
 Tam też w synagogach nauczał, że Jezus jest Synem Bożym.
###### **Dz 9,21**
 Wszyscy słuchający go dziwili się i pytali: "Czy to nie ten, który prześladował w Jerozolimie wyznawców tego imienia, i właśnie po to tu przybył, aby ich uwięzić i zaprowadzić do arcykapłanów?"
###### **Dz 9,22**
 Lecz Szaweł występował coraz odważniej, wywołując zamieszanie wśród Żydów mieszkających w Damaszku, bo dowodził, że (Jezus) jest Mesjaszem.
###### **Dz 9,23**
 Po upływie dłuższego czasu Żydzi postanowili go zabić.
###### **Dz 9,24**
 Szaweł dowiedział się o ich zamiarze. Aby móc go zgładzić, strzegli nawet bram we dnie i w nocy.
###### **Dz 9,25**
 Ale uczniowie jego w nocy spuścili go w koszu przez mur.
###### **Dz 9,26**
 Gdy przybył do Jerozolimy, starał się przyłączyć do uczniów, ale wszyscy bali się go, nie wierząc, że jest uczniem.
###### **Dz 9,27**
 Wtedy Barnaba przyszedł z nim do apostołów i opowiedział im o tym, jak to w drodze Szaweł widział Pana, który przemówił do niego, i z jakim zapałem nauczał w Damaszku w imię Jezusa.
###### **Dz 9,28**
 Odtąd czuł się w Jerozolimie wśród nich swobodnie, nauczał w imię Pana,
###### **Dz 9,29**
 rozprawiał i dyskutował z helenistami, którzy próbowali go zabić.
###### **Dz 9,30**
 Gdy bracia się o tym dowiedzieli, odprowadzili go do Cezarei i wysłali do Tarsu.
###### **Dz 9,31**
 A Kościół w całej Judei, Galilei i Samarii zażywał pokoju. Rozwijał się, trwał w bojaźni Pańskiej pocieszany przez Ducha Świętego.
###### **Dz 9,32**
 Piotr odwiedzając wszystkich, przyszedł do świętych mieszkających w Lyddzie.
###### **Dz 9,33**
 Spotkał tam człowieka imieniem Eneasz, który będąc paralitykiem od ośmiu lat leżał w łóżku.
###### **Dz 9,34**
 I powiedział do niego: "Eneaszu, Jezus Chrystus cię uzdrawia. Wstań i zaściel swoje łóżko", a on wstał natychmiast.
###### **Dz 9,35**
 Gdy zobaczyli go wszyscy mieszkańcy Lyddy i Saronu, nawrócili się do Pana.
###### **Dz 9,36**
 W Joppie mieszkała uczennica imieniem Tabita, to znaczy Gazela. Spełniała wiele dobrych uczynków i rozdawała jałmużnę.
###### **Dz 9,37**
 W tych właśnie dniach zachorowała i umarła; obmyto ją i położono w pokoju na górze.
###### **Dz 9,38**
 A Joppa leżała w pobliżu Lyddy. Gdy uczniowie dowiedzieli się, że przebywa tam Piotr, wysłali do niego dwóch ludzi z prośbą: "Nie zwlekaj z przyjściem do nas".
###### **Dz 9,39**
 Piotr więc poszedł razem z nimi. Gdy przyszedł, zaprowadzili go na piętro. Wtedy podeszły do niego z płaczem wszystkie wdowy i pokazywały mu chitony i okrycia, wykonane przez Gazelę.
###### **Dz 9,40**
 Piotr prosił, by wszyscy wyszli z mieszkania, upadł na kolana i modlił się, a potem zwrócił się do umarłej ze słowami: "Tabito, wstań". Ona zaś otworzyła oczy, zobaczyła Piotra i usiadła.
###### **Dz 9,41**
 Podał jej rękę, by mogła wstać, zawołał świętych i wdowy i pokazał, że żyje.
###### **Dz 9,42**
 Gdy cała Joppa się o tym dowiedziała, wielu uwierzyło w Pana.
###### **Dz 9,43**
 Przez dłuższy czas Piotr przebywał w Joppie u Szymona garbarza.
# Dz 9 BR
###### **Dz 9,1**
 A Szaweł siał wszędzie postrach i zionął pragnieniem zabijania uczniów Pańskich. Sam udał się do arcykapłana
###### **Dz 9,2**
 i poprosił o specjalne listy - pełnomocnictwa do synagog w Damaszku, aby mógł pojmać i przyprowadzić do Jerozolimy zarówno mężczyzn, jak i kobiety, zwolenników - jeśliby się okazało, że są tam tacy - tej nowej drogi życia.
###### **Dz 9,3**
 Był właśnie w drodze do Damaszku i znajdował się już niedaleko miasta, gdy oto poraziła go nagle światłość z nieba.
###### **Dz 9,4**
 Upadł na ziemię i usłyszał głos, który mówił do niego: Szawle, Szawle, dlaczego mnie prześladujesz?
###### **Dz 9,5**
 A on zapytał: Kim jesteś, Panie? I usłyszał w odpowiedzi: Ja jestem Jezus, którego ty prześladujesz.
###### **Dz 9,6**
 Podnieś się i idź, do miasta, a tam już powiedzą ci, co masz dalej czynić.
###### **Dz 9,7**
 Ludzie, którzy mu towarzyszli w drodze, osłupieli ze zdumienia; słyszeli bowiem jakiś głos, lecz nikogo nie widzieli.
###### **Dz 9,8**
 A Szaweł, gdy już podniósł się z ziemi i otworzył oczy, nic nie widział. Tak więc trzymając go za ręce, wprowadzono go do Damaszku,
###### **Dz 9,9**
 gdzie przez trzy dni nic nie widział i nie jadł ani nie pił.
###### **Dz 9,10**
 W Damaszku zaś znajdował się pewien uczeń [Chrystusa] imieniem Ananiasz. I zawołał do niego w widzeniu Pan: Ananiaszu! A on odrzekł: Jestem, Panie.
###### **Dz 9,11**
 A Pan wydał mu takie polecenie: Idź na ulicę Prostą i zapytaj w domu niejakiego Judy o Szawła z Tarsu. On właśnie modli się w tej chwili,
###### **Dz 9,12**
 a przedtem już miał widzenie, jak pewien człowiek imieniem Ananiasz wszedł do niego i położył na nim swe ręce, aby odzyskał wzrok.
###### **Dz 9,13**
 Odpowiedział Ananiasz: Panie, zewsząd słyszy się o tym, jak wiele zła wyrządził ten człowiek Twoim świętym w Jerozolimie.
###### **Dz 9,14**
 Ma on również specjalne pełnomocnictwo od arcykapłanów, aby uwięzić także i tu wszystkich, którzy wzywają Twego imienia.
###### **Dz 9,15**
 Lecz Pan rzekł ponownie: Idź gdyż właśnie ten człowiek, będzie moim szczególnym narzędziem. To on zaniesie wieść o moim imieniu do pogan, do ich władców i do całego Izraela.
###### **Dz 9,16**
 Ja również pokażę mu, jak wiele będzie musiał wycierpieć dla mojego imienia.
###### **Dz 9,17**
 Ruszył Ananiasz w drogę, przybył do [wskazanego] domu, położył ręce na Szwła i powiedział: Szawle, bracie, Pan Jezus, który ci się ukazał w czasie twojej podróży, przysłał mnie, abyś wzrok odzyskał i został napełniony Duchem Świętym.
###### **Dz 9,18**
 I natychmiast jakby łuski spadły z jego oczu i odzyskał wzrok. Potem został ochrzczony.
###### **Dz 9,19**
 Kiedy zaś go nakarmiono, nabrał siły.
###### **Dz 9,20**
 I przez jakiś czas pozostał z uczniami w Damaszku. Zaraz też zaczął głosić po synagogach, że Jezus jest Synem Bożym.
###### **Dz 9,21**
 A wszyscy, którzy słuchali jego słów, pytali ze zdumieniem: Czyż to nie ten, który w Jerozolimie tak surowo prześladował wyznawców tego Imienia i po to również przybył tu, żeby ich wtrącać do więzienia i przekazywać arcykapłanom?
###### **Dz 9,22**
 Tymczasem Szaweł nauczał z coraz większą odwagą, wykazując, że Ten jest Mesjaszem, czym powodował dużo zamieszania wśród Żydów mieszkających w Damaszku.
###### **Dz 9,23**
 Dlatego też po upływie dłuższego czasu Żydzi postanowili go zgładzić.
###### **Dz 9,24**
 Szaweł dowiedział się jednak o ich planach. Ponieważ zaś strzeżono bram miasta we dnie i w nocy, aby go zgładzić,
###### **Dz 9,25**
 uczniowie spuścili go pewnej nocy w koszu na sznurze przez mur i tak się uratował.
###### **Dz 9,26**
 A kiedy przybył do Jerozolimy, usiłował przyłączyć się do uczniów, ale wszędzie budził podejrzenie: nie wierzono, że jest uczniem.
###### **Dz 9,27**
 Dopiero Barnaba przyjął go, i zaprowadził do apostołów; im też opowiedział, jak w czasie podróży [Szaweł] ujrzał Pana, który do niego przemówił, i z jaką odwagą oraz przekonaniem nauczał w imię Jezusa w Damaszku.
###### **Dz 9,28**
 Od tej chwili mógł już przebywać z nimi w Jerozolimie,
###### **Dz 9,29**
 gdzie nauczał i rozprawiał z hellenistami, którz usiłowali go zgładzić.
###### **Dz 9,30**
 Lecz gdy bracia dowiedzieli się o tym, odprowadzili go do Cezarei, a stamtąd wysłali do Tarsu.
###### **Dz 9,31**
 Tymczasem w gminach całej Judei, Galilei i Samarii panował spokój. Kościół umacniał się, żył w bojaźni Bożej i cieszył się pomocą Ducha Świętego.
###### **Dz 9,32**
 Odwiedzając wszystkich wiernych, przybył Piotr pewnego dnia również do tych, którzy mieszkali w Liddzie.
###### **Dz 9,33**
 Spotkał tam człowieka imieniem Eneasz. Był on sparaliżowany i od ośmiu lat już pozostawał w łóżku.
###### **Dz 9,34**
 Powiedział tedy Piotr do niego: Eneaszu, Jezus Chrystus przywraca ci zdrowie. Wstań i sprzątnij swoje łoże. I natychmiast powstał Eneasz,
###### **Dz 9,35**
 co widząc wszyscy mieszkańcy Liddy i Saronu nawrócili się do Pana.
###### **Dz 9,36**
 A w Jafie mieszkała pewna niewiasta wierząca Tabita, co znaczy Dorkas. Czyniła ona wiele dobrego, a zwłaszcza hojnie wspierała ubogich.
###### **Dz 9,37**
 Otóż wtedy właśnie zachorowała i zmarła owa niewiasta. Obmyto jej ciało i ułożono w izbie, w górnej części domu.
###### **Dz 9,38**
 Lidda leży niedaleko Jafy. Gdy więc uczniowie dowiedzieli się, że przebywa tam Piotr, posłali do niego dwu ludzi z prośbą: Przybądź do nas natychmiast!
###### **Dz 9,39**
 Wyruszył tedy Piotr w drogę, a gdy przybył na miejsce, zaprowadzono go do izby na górze, gdzie zaraz otoczyły go wdowy, pokazując mu ze łzami w oczach chitony i suknie, które zrobiła Dorkas jeszcze za życia.
###### **Dz 9,40**
 Usunąwszy wszystkich, Piotr upadł na kolana i począł się modlić. A potem zwrócił się do zmarłej mówiąc: Tabito, wstań! Ona zaś otworzyła oczy i zobaczywszy Piotra usiadła.
###### **Dz 9,41**
 Wtedy Piotr wyciągnął do niej rękę i podniósł ją. Potem zawołał wiernych i wdowy; wszyscy stwierdzili, że była żywa,
###### **Dz 9,42**
 o czym wieść rozeszła się natychmiast po całej Jafie i wielu uwierzyło w Pana.
###### **Dz 9,43**
 Piotr zaś jeszcze przez dłuższy czas przebywał w Jafie u niejakiego Szymona garbarza.
# Dz 9 WUJ
###### **Dz 9,1**
 A Szaweł parskając jeszcze groźbami i morderstwem przeciw uczniom Pańskim: przyszedł do Nawyższego kapłana,
###### **Dz 9,2**
 Prosił od niego listów do Damaszku do bożnic: iż jeśliby które znalazł tej drogi męże i niewiasty, aby związane przywiódł do Jeruzalem.
###### **Dz 9,3**
 A gdy jachał: stało się, że się przybliżał do Damaszku, i sprędka zewsząd oświeciła go światłość z nieba.
###### **Dz 9,4**
 A padszy na ziemię, usłyszał głos mówiący do siebie: Szawle, Szawle, przecz mię prześladujesz?
###### **Dz 9,5**
 Który rzekł: Ktoś jest Panie? A on, Jam jest Jezus, którego ty prześladujesz: Trudno jest tobie przeciw ościeniowi wierzgać.
###### **Dz 9,6**
 A drżąc i zdumiewając się rzekł, Panie co chcesz, abych czynił? A Pan do niego, Wstań a wnidź do miasta, a tam ci powiedzą co będziesz miał czynić.
###### **Dz 9,7**
 A mężowie oni, którzy z nim byli, stali zdumiawszy się: głos wprawdzie słysząc, lecz żadnego nie widząc.
###### **Dz 9,8**
 I wstał Szaweł z ziemie, a otworzywszy oczy nic nie widział. A prowadząc go za ręce, wwiedli do Damaszku.
###### **Dz 9,9**
 I był tam trzy dni nie widząc: i nie jadł ani pił.
###### **Dz 9,10**
 A uczeń niektóry był w Damaszku imieniem Ananiasz, i rzekł Pan do niego w widzeniu: Ananiaszu. A on rzekł: Otom ja Panie.
###### **Dz 9,11**
 A Pan do niego: Wstań, a idź na ulicę, którą zową Prostą: a szukaj w domu Judy Szawła imieniem Tarseńczyka: abowiem oto się modli.
###### **Dz 9,12**
 A widział męża Ananiasza imieniem wchodzącego, i ręce na się wkładającego, aby wzrok zasię wziął.
###### **Dz 9,13**
 I odpowiedział Ananiasz: Panie, słyszałem od wiela o tym mężu, jako wiele złego czynił świętym twym w Jeruzalem:
###### **Dz 9,14**
 I tu ma moc od Nawyższych kapłanów wiązać wszystkie którzy wzywają imienia twego.
###### **Dz 9,15**
 A Pan rzekł do niego: Idź, abowiem ten mi jest naczyniem wybranem: aby nosił imię moje przed narody i królmi i syny Izraelskiemi.
###### **Dz 9,16**
 Bo mu ja ukażę, jako wiele potrzeba mu cierpieć dla imienia mego.
###### **Dz 9,17**
 I poszedł Ananiasz, i wszedł w dom: a włożywszy nań ręce, rzekł: Szawle bracie, Pan mię posłał Jezus, któryć się ukazał w drodze, którąś szedł: abyś przejrzał, a był napełnion Duchem świętym.
###### **Dz 9,18**
 A natychmiast spadły z oczu jego jako łuski, i zaś przejrzał: a wstawszy ochrzczon jest.
###### **Dz 9,19**
 A wziąwszy pokarm posilił się. I był z uczniami, którzy byli w Damaszku przez kilka dni.
###### **Dz 9,20**
 A natychmiast w bóżnicach opowiadał Jezusa, że ten jest Synem Bożym.
###### **Dz 9,21**
 I zdumiewali się wszyscy, którzy słuchali, i mówili: Izali nie ten jest, który burzył w Jeruzalem te, którzy wzywali tego imienia: i tu na to przyszedł, aby je powiązawszy wiódł do przedniejszych kapłanów?
###### **Dz 9,22**
 A Szaweł zmacniał się daleko więcej, i zawstydzał Żydy, którzy mieszkali w Damaszku, twierdząc, iż ten jest Chrystus.
###### **Dz 9,23**
 A gdy się wypełniło dni nie mało, uczynili radę spoinie Żydowie, aby go zabili.
###### **Dz 9,24**
 Lecz oznajmiono Szawłowi zdrady ich. A strzegli u bram we dnie i w nocy, aby go zabili.
###### **Dz 9,25**
 Ale uczniowie wziąwszy go w nocy, przez mur wypuścili go, spuściwszy w koszu.
###### **Dz 9,26**
 A gdy przyszedł do Jeruzalem, kusił się przyłączyć do uczniów: a wszyscy się go bali, nie wierząc, żeby był uczniem.
###### **Dz 9,27**
 Lecz Barnabasz wziąwszy go przywiódł do Apostołów: i powiedział im jako w drodze widział Pana: a iż mówił do niego: I jako w Damaszku bezpiecznie sobie poczynał w imię Jezusowe.
###### **Dz 9,28**
 I był w Jeruzalem wchodząc i wychodząc, a bezpiecznie sobie poczynając w imię Pańskie.
###### **Dz 9,29**
 Mówił też z pogany, i gadał się z Greki: a oni się starali jakoby go zabić.
###### **Dz 9,30**
 Czego dowiedziawszy się bracia, odprowadzili go do Cezarjej. i odesłali do Tarsu.
###### **Dz 9,31**
 A kościół po wszystkiej Żydowskiej ziemi i Galilejej i Samarjej miał pokój, i budował się chodząc w bojaźni Pańskiej, a pociechą Ducha świętego napełniał się.
###### **Dz 9,32**
 I stało się, iż Piotr, gdy obchodził wszystkie, przyszedł do świętych, którzy mieszkali w Liddzie.
###### **Dz 9,33**
 I nalazł tam człowieka niektórego imieniem Eneasza od ósmi lat na łożu leżącego, który był ruszony powietrzem.
###### **Dz 9,34**
 I rzekł mu Piotr: Eneaszu, uzdrawia cię Pan Jezus Chrystus: wstań a pościel sobie. I natychmiast wstał.
###### **Dz 9,35**
 I patrzyli nań wszyscy, którzy mieszkali w Liddzie i w Saronie: którzy się nawrócili do Pana.
###### **Dz 9,36**
 A była w Joppie niektóra uczenniczka imieniem Tabitha, która wyłożywszy zowie się Dorkas. Ta była pełna dobrych uczynków i jałmużny, które czyniła.
###### **Dz 9,37**
 I stało się w one dni, że zaniemogszy umarła. Którą gdy omyli, położyli ją na wieczerniku.
###### **Dz 9,38**
 A iż Lidda była blizko Joppy, uczniowie usłyszawszy że był Piotr w niej, posłali do niego dwu mężów, prosząc, Nie leń się przyść aż do nas.
###### **Dz 9,39**
 A wstawszy Piotr szedł z niemi: a gdy przyszedł wwiedli go na salę. I obstąpiły go wszystkie wdowy płacząc, i ukazując mu suknie i zwierzchnie odzienia, które im robiła Dorkas.
###### **Dz 9,40**
 A wygnawszy wszystkie przez, Piotr poklęknąwszy na kolana modlił się: a obróciwszy się do ciała rzekł: Tabitho wstań. A ona otworzyła oczy swoje, i ujrzawszy Piotra, usiadła.
###### **Dz 9,41**
 A podawszy jej rękę, podniósł ją. A wezwawszy świętych i wdów, oddał ją żywą.
###### **Dz 9,42**
 I stało się wiadomo po wszystkiej Joppie: i wiele ich uwierzyło w Pana.
###### **Dz 9,43**
 I stało się, że przez wiele dni mieszkał w Joppie, u niektórego Symona Skórnika.
# Dz 9 STERN
###### **Dz 9,1**
 Sza'ul tymczasem, wciąż dysząc chęcią mordu przeciwko talmidim Pana, poszedł do kohena hagadola
###### **Dz 9,2**
 i poprosił o listy do synagog w Dammeseku, które by go upoważniły do pojmania każdego, kogo znajdzie - i mężczyzn, i kobiety - kto by należał do "Drogi", i sprowadzenia go z powrotem do Jeruszalaim.
###### **Dz 9,3**
 Był w drodze i zbliżał się do Dammeseku, gdy wtem zajaśniała wokół niego światłość z nieba.
###### **Dz 9,4**
 Padając na ziemię, usłyszał głos, który mówił do niego: "Szaulu! Szaulu! Czemu mnie wciąż prześladujesz?".
###### **Dz 9,5**
 "Kim jesteś, Panie?" - spytał. "Jestem Jeszua, a ty mnie prześladujesz.
###### **Dz 9,6**
 Ale wstań i wejdź do miasta, a powiedzą ci, co masz robić".
###### **Dz 9,7**
 Jego towarzysze podróży oniemieli, słysząc głos i nikogo nie widząc.
###### **Dz 9,8**
 Pomogli Sza'ulowi podnieść się z ziemi, lecz gdy otworzył oczy, nic nie widział. Trzymając go więc za rękę, wprowadzili go do Dammeseku.
###### **Dz 9,9**
 Przez trzy dni nie odzyskał wzroku i ani nie jadł, ani nie pił.
###### **Dz 9,10**
 Był w Dammeseku pewien talmid o imieniu Chanania; a w widzeniu powiedział mu Pan: "Chananio!". Odparł: "Oto jestem, Panie".
###### **Dz 9,11**
 Pan rzekł mu: "Wstań i idź na ulicę Prostą, do domu J'hudy, i zapytaj o człowieka z Tarsu imieniem Sza'ul; bo modli się on,
###### **Dz 9,12**
 i ujrzał w widzeniu człowieka imieniem Chanania, jak wchodzi, kładzie na nim ręce i przywraca mu wzrok".
###### **Dz 9,13**
 Lecz Chanania odrzekł: "Panie, wielu mówiło mi o tym człowieku, ile krzywd wyrządził Twojemu ludowi w Jeruszalaim;
###### **Dz 9,14**
 a teraz ma pełnomocnictwo od głównych kohanim, aby pojmać każdego, kto wzywa Twego imienia".
###### **Dz 9,15**
 Ale Pan powiedział mu: "Idź, bo człowiek ten to moje wybrane narzędzie, aby zanieść imię moje do goim, a nawet do władców ich, a także do synów Israela.
###### **Dz 9,16**
 Bo sam mu pokażę, jak wiele będzie musiał wycierpieć dla mojego imienia".
###### **Dz 9,17**
 Wyszedł więc Chanania i poszedł do tego domu. Kładąc na nim ręce, rzekł: "Bracie Sza'ulu, Pan, Jeszua, ten, który objawił ci się na drodze, kiedy tu zdążałeś, posłał mnie, abyś odzyskał wzrok i został napełniony Ruach Ha-Kodesz'.
###### **Dz 9,18**
 W tym momencie jakby łuski opadły z oczu Sza'ula i odzyskał wzrok. Wstał i został zanurzony,
###### **Dz 9,19**
 potem posilił się nieco i odzyskał siły. Sza'ul spędził kilka dni z talmidim w Dammeseku
###### **Dz 9,20**
 i od razu zaczął głosić w synagogach, że Jeszua jest Synem Bożym.
###### **Dz 9,21**
 Zdumiewali się wszyscy, którzy go słyszeli. Mówili: "Czyż to nie ten człowiek starał się w Jeruszalaim niszczyć tych, którzy wzywają tego imienia? Zresztą czy nie po to właśnie tu przybył, ażeby pojmać ich i zawieść z powrotem przed głównych kohanim?".
###### **Dz 9,22**
 Lecz Sza'ul był coraz bardziej pełen mocy i wśród Żydów mieszkających w Dammeseku wywoływał wielkie poruszenie swoim dowodzeniem, że Jeszua jest Mesjaszem.
###### **Dz 9,23**
 Dłuższy czas potem zebrali się niewierzący Żydzi i powzięli plany, aby go zabić,
###### **Dz 9,24**
 lecz Sza'ul dowiedział się o ich spisku. Dzień i noc obserwowali bramy, aby go zgładzić,
###### **Dz 9,25**
 ale pod osłoną nocy jego talmidim wzięli go i spuścili po murze miejskim, opuszczając go w wielkim koszu.
###### **Dz 9,26**
 Dotarłszy do Jeruszalaim, próbował przyłączyć się do talmidim; ale wszyscy oni bali się go, nie wierząc, że jest talmidem.
###### **Dz 9,27**
 Bar-Nabba wziął go jednak i zaprowadził do wysłanników. Opowiedział im, jak Sza'ul podczas podróży ujrzał Pana, że Pan przemówił do niego i o tym, jak w Dammeseku Sza'ul śmiało przemawiał w imieniu Jeszui.
###### **Dz 9,28**
 Pozostał więc z nimi i chodził po całym Jeruszalaim, nie przestając przemawiać śmiało w imieniu Pana.
###### **Dz 9,29**
 Rozmawiał i dyskutował z Żydami greckojęzycznymi, ale oni podjęli próby, aby go zabić.
###### **Dz 9,30**
 Kiedy bracia dowiedzieli się o tym, sprowadzili go do Cezarei i odesłali do Tarsu.
###### **Dz 9,31**
 Wtedy Wspólnota Mesjaniczna w całej J'hudzie, Galil i Szomron cieszyła się pokojem i budowała się. Żyli w bojaźni Pana, prowadzeni przez Ruach Ha-Kodesz; a ich liczba stale się mnożyła.
###### **Dz 9,32**
 Przemierzając okolicę, Kefa dotarł do wierzących w Lyd.
###### **Dz 9,33**
 Był tam człowiek imieniem Eneasz, od ośmiu lat przykuty do łóżka, bo był sparaliżowany.
###### **Dz 9,34**
 Kefa rzekł mu: "Eneaszu! Jeszua Mesjasz cię uzdrawia! Wstań i pościel swoje łóżko!". I od razu wstał.
###### **Dz 9,35**
 Wszyscy mieszkańcy Lyd i Szaronu widzieli go i zwrócili się do Pana. A była w Jafo pewna talmida imieniem Tawita
###### **Dz 9,36**
 (co znaczy "gazela"); zawsze czyniła cedakę i inne dobre uczynki.
###### **Dz 9,37**
 I zdarzyło się akurat, że zachorowała i umarła. Obmywszy ją, położyli ją w pokoju na górze.
###### **Dz 9,38**
 Lyd leży koło Jafo, i talmidim usłyszeli, że jest tam Kefa, posłali więc do niego dwóch ludzi, błagając: "Prosimy, przyjdź do nas niezwłocznie".
###### **Dz 9,39**
 Kefa wstał i poszedł z nimi. Kiedy przybyli na miejsce, zaprowadzili go do pokoju na górze. Wszystkie wdowy stanęły koło niego, szlochając i pokazując suknie i płaszcze, jakie uszyła Tawita, będąc jeszcze pośród nich.
###### **Dz 9,40**
 Ale Kefa wyprosił je wszystkie na zewnątrz, ukląkł i modlił się. Potem, zwracając się do ciała, rzekł: "Tawito! Wstań!". Otworzyła oczy, a widząc Kefę, usiadła.
###### **Dz 9,41**
 Podał jej rękę i pomógł wstać, po czym zawoławszy wierzących i wdowy, oddał im ją żywą.
###### **Dz 9,42**
 Rozeszło się to po całym Jafo i wielu ludzi złożyło swą ufność w Panu.
###### **Dz 9,43**
 Kefa pozostał w Jafo jeszcze jakiś czas u człowieka imieniem Szim'on, garbarza.
# Dz 9 TRO
###### **Dz 9,1**
 **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* Zaś [[G1161]] [[CONJ]] **σαυλος** *saulos* Saul – [zapytał] [[G4569]] [[N-NSM]] **ετι** *eti* jeszcze [[G2089]] [[ADV]] **εμπνεων** *empneōn* dysząc [[G1709]] [[V-PAP-NSM]] **απειλης** *apeilēs* groźbą [[G547]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **φονου** *fonou* morderstwem [[G5408]] [[N-GSM]] **εις** *eis* do [[G1519]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **μαθητας** *mathētas* uczniów [[G3101]] [[N-APM]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **προσελθων** *proselthōn* podszedłszy – zbliżywszy się [[G4334]] WTV-2AAP-NSM **τω** *tō* (do) [[G3588]] WTT-DSM **αρχιερει** *archierei* arcykapłana [[G749]] WTN-DSM
###### **Dz 9,2**
 **ητησατο** *ētēsato* poprosił [[G154]] WTV-AMI-3S **παρ** *par* od [[G3844]] [[PREP]] **αυτου** *autou* niego [[G846]] [[P-GSM]] **επιστολας** *epistolas* listy [[G1992]] WTN-APF **εις** *eis* do [[G1519]] [[PREP]] **δαμασκον** *damaskon* Damaszku [[G1154]] WTN-ASF **προς** *pros* do [[G4314]] [[PREP]] **τας** *tas* [[G3588]] WTT-APF **συναγωγας** *synagōgas* zgromadzeń – synagog [[G4864]] WTN-APF **οπως** *hopōs* żeby [[G3704]] [[ADV]] **εαν** *ean* jeśli [[G1437]] WTCOND **τινας** *tinas* jakichś [[G5100]] WTX-APM **ευρη** *heurē* znalazłby [[G2147]] WTV-2AAS-3S **της** *tēs* (tej) [[G3588]] [[T-GSF]] **οδου** *hodou* drogi [[G3598]] [[N-GSF]] **οντας** *ontas* będących [[G5607]] WTV-PXP-APM **ανδρας** *andras* mężów [[G435]] [[N-APM]] **τε** *te* zarówno – także [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **γυναικας** *gynaikas* kobiety [[G1135]] WTN-APF **δεδεμενους** *dedemenous* którzy są związani [[G1210]] WTV-RPP-APM **αγαγη** *agagē* poprowadziłby [[G71]] WTV-2AAS-3S **εις** *eis* do [[G1519]] [[PREP]] **ιερουσαλημ** *ierousalēm* Jeruzalem – [dziedzictwo pokoju] [[G2419]] [[N-PRI]]
###### **Dz 9,3**
 **εν** *en* W [[G1722]] [[PREP]] **δε** *de* zaś [[G1161]] [[CONJ]] **τω** *tō* [[G3588]] WTT-DSM **πορευεσθαι** *poreuesthai* iść [[G4198]] WTV-PNN **εγενετο** *egeneto* stało się [[G1096]] WTV-2ADI-3S **αυτον** *auton* mu [[G846]] WTP-ASM **εγγιζειν** *engizein* zbliżać się [[G1448]] WTV-PAN **τη** *tē* (do) [[G3588]] WTT-DSF **δαμασκω** *damaskō* Damaszku [[G1154]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **εξαιφνης** *eksaifnēs* nagle [[G1810]] [[ADV]] **περιηστραψεν** *periēstrapsen* otoczyło blaskiem – objęło blaskiem [[G4015]] [[V-AAI-3S]] **αυτον** *auton* go [[G846]] WTP-ASM **φως** *fōs* światło [[G5457]] WTN-NSN **απο** *apo* z [[G575]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **ουρανου** *ouranou* nieba [[G3772]] [[N-GSM]]
###### **Dz 9,4**
 **και** *kai* i [[G2532]] [[CONJ]] **πεσων** *pesōn* upadłszy [[G4098]] WTV-2AAP-NSM **επι** *epi* na [[G1909]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **γην** *gēn* ziemię [[G1093]] WTN-ASF **ηκουσεν** *ēkousen* usłyszał [[G191]] [[V-AAI-3S]] **φωνην** *fōnēn* głos [[G5456]] WTN-ASF **λεγουσαν** *legousan* mówiący [[G3004]] WTV-PAP-ASF **αυτω** *autō* mu [[G846]] WTP-DSM **σαουλ** *saoul* Saulu – [zapytał] [[G4549]] [[N-PRI]] **σαουλ** *saoul* Saulu – [zapytał] [[G4549]] [[N-PRI]] **τι** *ti* czemu [[G5101]] WTI-ASN **με** *me* Mnie [[G3165]] WTP-1AS **διωκεις** *diōkeis* prześladujesz – nastajesz [[G1377]] WTV-PAI-2S
###### **Dz 9,5**
 **ειπεν** *eipen* Powiedział [[G2036]] WTV-2AAI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **τις** *tis* kim [[G5101]] WTI-NSM **ει** *ei* jesteś [[G1488]] WTV-PXI-2S **κυριε** *kyrie* Panie [[G2962]] WTN-VSM **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **εγω** *egō* Ja [[G1473]] WTP-1NS **ειμι** *eimi* jestem [[G1510]] WTV-PXI-1S **ιησους** *iēsous* Jezus – [JHWH jest zbawieniem] [[G2424]] [[N-NSM]] **ον** *hon* którego [[G3739]] WTR-ASM **συ** *sy* ty [[G4771]] WTP-2NS **διωκεις** *diōkeis* prześladujesz – nastajesz [[G1377]] WTV-PAI-2S **σκληρον** *sklēron* trudno – twardo [[G4642]] WTA-NSN **σοι** *soi* ci [[G4671]] WTP-2DS **προς** *pros* ku [[G4314]] [[PREP]] **κεντρα** *kentra* ościeniom [[G2759]] WTN-APN **λακτιζειν** *laktizein* wierzgać – kopać [[G2979]] WTV-PAN
###### **Dz 9,6**
 **τρεμων** *tremōn* Drżąc [[G5141]] [[V-PAP-NSM]] **τε** *te* zarówno – także [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **θαμβων** *thambōn* będąc zdumionym – będąc zadziwionym [[G2284]] [[V-PAP-NSM]] **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **κυριε** *kyrie* Panie [[G2962]] WTN-VSM **τι** *ti* co [[G5101]] WTI-ASN **με** *me* mi [[G3165]] WTP-1AS **θελεις** *theleis* chcesz [[G2309]] WTV-PAI-2S **ποιησαι** *poiēsai* uczynić [[G4160]] [[V-AAN]] **και** *kai* a [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **προς** *pros* do [[G4314]] [[PREP]] **αυτον** *auton* niego [[G846]] WTP-ASM **αναστηθι** *anastēthi* powstań [[G450]] WTV-2AAM-2S **και** *kai* i [[G2532]] [[CONJ]] **εισελθε** *eiselthe* wejdź [[G1525]] WTV-2AAM-2S **εις** *eis* do [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **πολιν** *polin* miasta [[G4172]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **λαληθησεται** *lalēthēsetai* zostanie powiedziane [[G2980]] WTV-FPI-3S **σοι** *soi* ci [[G4671]] WTP-2DS **τι** *ti* co [[G5101]] WTI-ASN **σε** *se* tobie [[G4571]] WTP-2AS **δει** *dei* trzeba – jest konieczne [[G1163]] WTV-PQI-3S **ποιειν** *poiein* czynić [[G4160]] WTV-PAN
###### **Dz 9,7**
 **οι** *hoi* [[G3588]] WTT-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **ανδρες** *andres* mężowie [[G435]] WTN-NPM **οι** *hoi* [[G3588]] WTT-NPM **συνοδευοντες** *synodeuontes* towarzyszący – podróżujący razem z [[G4922]] WTV-PAP-NPM **αυτω** *autō* mu [[G846]] WTP-DSM **ειστηκεισαν** *heistēkeisan* stanęli [[G2476]] WTV-LAI-3P **εννεοι** *enneoi* oniemiali [[G1769]] WTA-NPM **ακουοντες** *akouontes* słysząc [[G191]] WTV-PAP-NPM **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **της** *tēs* [[G3588]] [[T-GSF]] **φωνης** *fōnēs* głos [[G5456]] [[N-GSF]] **μηδενα** *mēdena* nikogo [[G3367]] WTA-ASM **δε** *de* zaś [[G1161]] [[CONJ]] **θεωρουντες** *theōrountes* oglądając [[G2334]] WTV-PAP-NPM
###### **Dz 9,8**
 **ηγερθη** *ēgerthē* Został wzbudzony – Został podniesiony [[G1453]] [[V-API-3S]] **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **σαυλος** *saulos* Saul – [zapytał] [[G4569]] [[N-NSM]] **απο** *apo* z [[G575]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]] **ανεωγμενων** *aneōgmenōn* gdy są otworzone [[G455]] WTV-RPP-GPM **δε** *de* zaś [[G1161]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPM **οφθαλμων** *ofthalmōn* oczy [[G3788]] WTN-GPM **αυτου** *autou* jego [[G846]] [[P-GSM]] **ουδενα** *oudena* nic [[G3762]] WTA-ASM **εβλεπεν** *eblepen* widział [[G991]] WTV-IAI-3S **χειραγωγουντες** *cheiragōgountes* prowadząc za rękę [[G5496]] WTV-PAP-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **αυτον** *auton* go [[G846]] WTP-ASM **εισηγαγον** *eisēgagon* wprowadzili [[G1521]] WTV-2AAI-3P **εις** *eis* do [[G1519]] [[PREP]] **δαμασκον** *damaskon* Damaszku [[G1154]] WTN-ASF
###### **Dz 9,9**
 **και** *kai* I [[G2532]] [[CONJ]] **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **ημερας** *hēmeras* dni [[G2250]] WTN-APF **τρεις** *treis* trzy [[G5140]] WTA-APF **μη** *mē* nie [[G3361]] [[PRT-N]] **βλεπων** *blepōn* widzący [[G991]] [[V-PAP-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εφαγεν** *efagen* zjadł [[G5315]] WTV-2AAI-3S **ουδε** *oude* ani [[G3761]] [[ADV]] **επιεν** *epien* pił [[G4095]] WTV-2AAI-3S
###### **Dz 9,10**
 **ην** *ēn* Był [[G2258]] [[V-IXI-3S]] **δε** *de* zaś [[G1161]] [[CONJ]] **τις** *tis* pewien – jakiś [[G5100]] WTX-NSM **μαθητης** *mathētēs* uczeń [[G3101]] [[N-NSM]] **εν** *en* w [[G1722]] [[PREP]] **δαμασκω** *damaskō* Damaszku [[G1154]] [[N-DSF]] **ονοματι** *onomati* imieniem [[G3686]] WTN-DSN **ανανιας** *hananias* Ananiasz – [JH przyjął] [[G367]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **προς** *pros* do [[G4314]] [[PREP]] **αυτον** *auton* niego [[G846]] WTP-ASM **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **εν** *en* w [[G1722]] [[PREP]] **οραματι** *horamati* widzeniu – wizji [[G3705]] WTN-DSN **ανανια** *hanania* Ananiaszu – [JH przyjął] [[G367]] WTN-VSM **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **εγω** *egō* ja [[G1473]] WTP-1NS **κυριε** *kyrie* Panie [[G2962]] WTN-VSM
###### **Dz 9,11**
 **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **προς** *pros* do [[G4314]] [[PREP]] **αυτον** *auton* niego [[G846]] WTP-ASM **αναστας** *anastas* wstawszy – podniósłszy się [[G450]] WTV-2AAP-NSM **πορευθητι** *poreuthēti* pójdź [[G4198]] WTV-AOM-2S **επι** *epi* na [[G1909]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **ρυμην** *rymēn* ulicę [[G4505]] WTN-ASF **την** *tēn* [[G3588]] WTT-ASF **καλουμενην** *kaloumenēn* która jest nazywana – która jest zwana [[G2564]] WTV-PPP-ASF **ευθειαν** *eutheian* Prostą [[G2117]] WTA-ASF **και** *kai* i [[G2532]] [[CONJ]] **ζητησον** *zētēson* odszukaj [[G2212]] WTV-AAM-2S **εν** *en* w [[G1722]] [[PREP]] **οικια** *oikia* domu [[G3614]] [[N-DSF]] **ιουδα** *iouda* Judasza – [wielbić] [[G2455]] [[N-GSM]] **σαυλον** *saulon* Saula – [zapytał] [[G4569]] [[N-ASM]] **ονοματι** *onomati* imieniem [[G3686]] WTN-DSN **ταρσεα** *tarsea* Tarsyjczyk – [prawd. płaski kosz] [[G5018]] [[N-ASM]] **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **προσευχεται** *proseuchetai* modli się [[G4336]] WTV-PNI-3S
###### **Dz 9,12**
 **και** *kai* I [[G2532]] [[CONJ]] **ειδεν** *eiden* zobaczył [[G1492]] WTV-2AAI-3S **εν** *en* w [[G1722]] [[PREP]] **οραματι** *horamati* widzeniu – wizji [[G3705]] WTN-DSN **ανδρα** *andra* męża [[G435]] [[N-ASM]] **ονοματι** *onomati* imieniem [[G3686]] WTN-DSN **ανανιαν** *hananian* Ananiasz – [JH przyjął] [[G367]] [[N-ASM]] **εισελθοντα** *eiselthonta* który wszedł [[G1525]] WTV-2AAP-ASM **και** *kai* i [[G2532]] [[CONJ]] **επιθεντα** *epithenta* który włożył na [[G2007]] WTV-2AAP-ASM **αυτω** *autō* niego [[G846]] WTP-DSM **χειρα** *cheira* rękę [[G5495]] WTN-ASF **οπως** *hopōs* żeby [[G3704]] [[ADV]] **αναβλεψη** *anablepsē* przejrzałby – znowu widziałby [[G308]] WTV-AAS-3S
###### **Dz 9,13**
 **απεκριθη** *apekrithē* Odpowiedział [[G611]] WTV-ADI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **ανανιας** *hananias* Ananiasz – [JH przyjął] [[G367]] [[N-NSM]] **κυριε** *kyrie* Panie [[G2962]] WTN-VSM **ακηκοα** *akēkoa* słyszałem [[G191]] WTV-2RAI-1S **απο** *apo* od [[G575]] [[PREP]] **πολλων** *pollōn* wielu [[G4183]] WTA-GPM **περι** *peri* o [[G4012]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **ανδρος** *andros* mężu [[G435]] [[N-GSM]] **τουτου** *toutou* tym [[G5127]] WTD-GSM **οσα** *hosa* ile – jak [[G3745]] WTK-APN **κακα** *kaka* zła [[G2556]] WTA-APN **εποιησεν** *epoiēsen* uczynił [[G4160]] [[V-AAI-3S]] **τοις** *tois* [[G3588]] WTT-DPM **αγιοις** *hagiois* świętym [[G40]] WTA-DPM **σου** *sou* Twoim [[G4675]] WTP-2GS **εν** *en* w [[G1722]] [[PREP]] **ιερουσαλημ** *ierousalēm* Jeruzalem – [dziedzictwo pokoju] [[G2419]] [[N-PRI]]
###### **Dz 9,14**
 **και** *kai* I [[G2532]] [[CONJ]] **ωδε** *hōde* tutaj [[G5602]] [[ADV]] **εχει** *echei* ma [[G2192]] WTV-PAI-3S **εξουσιαν** *eksousian* władzę [[G1849]] WTN-ASF **παρα** *para* od [[G3844]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **αρχιερεων** *archiereōn* arcykapłanów [[G749]] WTN-GPM **δησαι** *dēsai* związać [[G1210]] [[V-AAN]] **παντας** *pantas* wszystkich [[G3956]] WTA-APM **τους** *tous* [[G3588]] WTT-APM **επικαλουμενους** *epikaloumenous* przywołujących [[G1941]] WTV-PMP-APM **το** *to* [[G3588]] WTT-ASN **ονομα** *onoma* imię [[G3686]] WTN-ASN **σου** *sou* Twoje [[G4675]] WTP-2GS
###### **Dz 9,15**
 **ειπεν** *eipen* Powiedział [[G2036]] WTV-2AAI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **προς** *pros* do [[G4314]] [[PREP]] **αυτον** *auton* niego [[G846]] WTP-ASM **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **πορευου** *poreuou* idź [[G4198]] WTV-PNM-2S **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **σκευος** *skeuos* naczynie [[G4632]] WTN-NSN **εκλογης** *eklogēs* wybrania [[G1589]] [[N-GSF]] **μοι** *moi* Mi [[G3427]] WTP-1DS **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ουτος** *houtos* ten [[G3778]] WTD-NSM **του** *tou* [[G3588]] WTT-GSM **βαστασαι** *bastasai* zanieść [[G941]] [[V-AAN]] **το** *to* [[G3588]] WTT-ASN **ονομα** *onoma* imię [[G3686]] WTN-ASN **μου** *mou* Moje [[G3450]] WTP-1GS **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **εθνων** *ethnōn* narody – pogan [[G1484]] WTN-GPN **και** *kai* i [[G2532]] [[CONJ]] **βασιλεων** *basileōn* królów [[G935]] WTN-GPM **υιων** *hyiōn* synów [[G5207]] WTN-GPM **τε** *te* zarówno – także [[G5037]] WTPRT **ισραηλ** *israēl* Izraela – [ten, który walczył z Bogiem] [[G2474]] [[N-PRI]]
###### **Dz 9,16**
 **εγω** *egō* Ja [[G1473]] WTP-1NS **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **υποδειξω** *hypodeiksō* pokażę [[G5263]] WTV-FAI-1S **αυτω** *autō* mu [[G846]] WTP-DSM **οσα** *hosa* ile – jak [[G3745]] WTK-APN **δει** *dei* trzeba – jest konieczne [[G1163]] WTV-PQI-3S **αυτον** *auton* mu [[G846]] WTP-ASM **υπερ** *hyper* dla [[G5228]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **ονοματος** *onomatos* imienia [[G3686]] [[N-GSN]] **μου** *mou* mojego [[G3450]] WTP-1GS **παθειν** *pathein* wycierpieć [[G3958]] [[V-2AAN]]
###### **Dz 9,17**
 **απηλθεν** *apēlthen* Odszedł [[G565]] WTV-2AAI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **ανανιας** *hananias* Ananiasz – [JH przyjął] [[G367]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **εισηλθεν** *eisēlthen* wszedł [[G1525]] WTV-2AAI-3S **εις** *eis* do [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **οικιαν** *oikian* domu [[G3614]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **επιθεις** *epitheis* włożywszy [[G2007]] WTV-2AAP-NSM **επ** *ep* na [[G1909]] [[PREP]] **αυτον** *auton* niego [[G846]] WTP-ASM **τας** *tas* [[G3588]] WTT-APF **χειρας** *cheiras* ręce [[G5495]] WTN-APF **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **σαουλ** *saoul* Saulu – [zapytał] [[G4549]] [[N-PRI]] **αδελφε** *adelfe* bracie [[G80]] WTN-VSM **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **απεσταλκεν** *apestalken* wysyłał [[G649]] WTV-RAI-3S **με** *me* mnie [[G3165]] WTP-1AS **ιησους** *iēsous* Jezus – [JHWH jest zbawieniem] [[G2424]] [[N-NSM]] **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **οφθεις** *oftheis* który został ukazany – który został uczyniony widocznym [[G3700]] WTV-APP-NSM **σοι** *soi* ci [[G4671]] WTP-2DS **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **οδω** *hodō* drodze [[G3598]] [[N-DSF]] **η** *hē* którą [[G3739]] WTR-DSF **ηρχου** *ērchou* przychodziłeś [[G2064]] WTV-INI-2S **οπως** *hopōs* żeby [[G3704]] [[ADV]] **αναβλεψης** *anablepsēs* przejrzałbyś – znowu widziałbyś [[G308]] WTV-AAS-2S **και** *kai* i [[G2532]] [[CONJ]] **πλησθης** *plēsthēs* zostałbyś napełniony [[G4130]] WTV-APS-2S **πνευματος** *pneumatos* Duchem [[G4151]] [[N-GSN]] **αγιου** *hagiou* Świętym [[G40]] [[A-GSN]]
###### **Dz 9,18**
 **και** *kai* I [[G2532]] [[CONJ]] **ευθεως** *eutheōs* zaraz – natychmiast [[G2112]] [[ADV]] **απεπεσον** *apepeson* odpadły – spadły [[G634]] WTV-2AAI-3P **απο** *apo* z [[G575]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **οφθαλμων** *ofthalmōn* oczu [[G3788]] WTN-GPM **αυτου** *autou* jego [[G846]] [[P-GSM]] **ωσει** *hōsei* jakby [[G5616]] [[ADV]] **λεπιδες** *lepides* łuski [[G3013]] [[N-NPF]] **ανεβλεψεν** *aneblepsen* przejrzał – znowu widział [[G308]] [[V-AAI-3S]] **τε** *te* zarówno – także [[G5037]] WTPRT **παραχρημα** *parachrēma* od razu – natychmiast [[G3916]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **αναστας** *anastas* wstawszy – podniósłszy się [[G450]] WTV-2AAP-NSM **εβαπτισθη** *ebaptisthē* został zanurzony [[G907]] [[V-API-3S]]
###### **Dz 9,19**
 **και** *kai* I [[G2532]] [[CONJ]] **λαβων** *labōn* wziąwszy [[G2983]] WTV-2AAP-NSM **τροφην** *trofēn* pożywienie – pokarm [[G5160]] WTN-ASF **ενισχυσεν** *enischysen* umocnił się – wzmocni się [[G1765]] [[V-AAI-3S]] **εγενετο** *egeneto* stał się [[G1096]] WTV-2ADI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **σαυλος** *saulos* Saul – [zapytał] [[G4569]] [[N-NSM]] **μετα** *meta* z [[G3326]] [[PREP]] **των** *tōn* (tymi) [[G3588]] WTT-GPM **εν** *en* w [[G1722]] [[PREP]] **δαμασκω** *damaskō* Damaszku [[G1154]] [[N-DSF]] **μαθητων** *mathētōn* uczniami [[G3101]] WTN-GPM **ημερας** *hēmeras* dni [[G2250]] WTN-APF **τινας** *tinas* jakieś [[G5100]] WTX-APF
###### **Dz 9,20**
 **και** *kai* I [[G2532]] [[CONJ]] **ευθεως** *eutheōs* zaraz – natychmiast [[G2112]] [[ADV]] **εν** *en* w [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **συναγωγαις** *synagōgais* zgromadzeniach – synagogach [[G4864]] WTN-DPF **εκηρυσσεν** *ekēryssen* ogłaszał [[G2784]] WTV-IAI-3S **τον** *ton* [[G3588]] [[T-ASM]] **χριστον** *christon* Pomazaniec [[G5547]] [[N-ASM]] **οτι** *hoti* że [[G3754]] [[CONJ]] **ουτος** *houtos* Ten [[G3778]] WTD-NSM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ο** *ho* [[G3588]] [[T-NSM]] **υιος** *hyios* Syn [[G5207]] [[N-NSM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **Dz 9,21**
 **εξισταντο** *eksistanto* Zdumiewali się – Dziwili się [[G1839]] WTV-IMI-3P **δε** *de* zaś [[G1161]] [[CONJ]] **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **οι** *hoi* [[G3588]] WTT-NPM **ακουοντες** *akouontes* słuchający [[G191]] WTV-PAP-NPM **και** *kai* i [[G2532]] [[CONJ]] **ελεγον** *elegon* mówili [[G3004]] WTV-IAI-3P **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **ουτος** *houtos* Ten [[G3778]] WTD-NSM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ο** *ho* [[G3588]] [[T-NSM]] **πορθησας** *porthēsas* który niszczył [[G4199]] WTV-AAP-NSM **εν** *en* w [[G1722]] [[PREP]] **ιερουσαλημ** *ierousalēm* Jeruzalem – [dziedzictwo pokoju] [[G2419]] [[N-PRI]] **τους** *tous* [[G3588]] WTT-APM **επικαλουμενους** *epikaloumenous* przywołujących [[G1941]] WTV-PMP-APM **το** *to* [[G3588]] WTT-ASN **ονομα** *onoma* imię [[G3686]] WTN-ASN **τουτο** *touto* to [[G5124]] WTD-ASN **και** *kai* a [[G2532]] [[CONJ]] **ωδε** *hōde* tutaj [[G5602]] [[ADV]] **εις** *eis* względem [[G1519]] [[PREP]] **τουτο** *touto* tego [[G5124]] WTD-ASN **εληλυθει** *elēlythei* przyszedł [[G2064]] WTV-LAI-3S **ινα** *hina* aby [[G2443]] [[CONJ]] **δεδεμενους** *dedemenous* którzy są związani [[G1210]] WTV-RPP-APM **αυτους** *autous* oni [[G846]] [[P-APM]] **αγαγη** *agagē* poprowadziłby [[G71]] WTV-2AAS-3S **επι** *epi* do [[G1909]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **αρχιερεις** *archiereis* arcykapłanów [[G749]] [[N-APM]]
###### **Dz 9,22**
 **σαυλος** *saulos* Saul – [zapytał] [[G4569]] [[N-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **μαλλον** *mallon* bardziej [[G3123]] [[ADV]] **ενεδυναμουτο** *enedynamouto* został umacniany – został napełniony mocą [[G1743]] WTV-IPI-3S **και** *kai* i [[G2532]] [[CONJ]] **συνεχυνεν** *synechynen* zdumiewał – oszołamiał [[G4797]] WTV-IAI-3S **τους** *tous* [[G3588]] WTT-APM **ιουδαιους** *ioudaious* Judejczyków – [wielbić] [[G2453]] WTA-APM **τους** *tous* [[G3588]] WTT-APM **κατοικουντας** *katoikountas* zamieszkujących [[G2730]] WTV-PAP-APM **εν** *en* w [[G1722]] [[PREP]] **δαμασκω** *damaskō* Damaszku [[G1154]] [[N-DSF]] **συμβιβαζων** *symbibazōn* dowodząc – dedukując [[G4822]] [[V-PAP-NSM]] **οτι** *hoti* że [[G3754]] [[CONJ]] **ουτος** *houtos* Ten [[G3778]] WTD-NSM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ο** *ho* [[G3588]] [[T-NSM]] **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]]
###### **Dz 9,23**
 **ως** *hōs* Gdy [[G5613]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **επληρουντο** *eplērounto* zostały wypełnione [[G4137]] WTV-IPI-3P **ημεραι** *hēmerai* dni [[G2250]] [[N-NPF]] **ικαναι** *hikanai* dość liczne [[G2425]] [[A-NPF]] **συνεβουλευσαντο** *synebouleusanto* radzili – zaplanowali [[G4823]] WTV-AMI-3P **οι** *hoi* [[G3588]] WTT-NPM **ιουδαιοι** *ioudaioi* Judejczycy – [wielbić] [[G2453]] WTA-NPM **ανελειν** *anelein* zabić – znieść [[G337]] [[V-2AAN]] **αυτον** *auton* go [[G846]] WTP-ASM
###### **Dz 9,24**
 **εγνωσθη** *egnōsthē* Został poznany – Dał się poznać [[G1097]] [[V-API-3S]] **δε** *de* zaś [[G1161]] [[CONJ]] **τω** *tō* [[G3588]] WTT-DSM **σαυλω** *saulō* Saulowi – [zapytał] [[G4569]] WTN-DSM **η** *hē* [[G3588]] [[T-NSF]] **επιβουλη** *epiboulē* spisek – zmowa [[G1917]] [[N-NSF]] **αυτων** *autōn* ich [[G846]] WTP-GPM **παρετηρουν** *paretēroun* śledzili – pilnowali [[G3906]] WTV-IAI-3P **τε** *te* także – zarówno [[G5037]] WTPRT **τας** *tas* [[G3588]] WTT-APF **πυλας** *pylas* bram [[G4439]] WTN-APF **ημερας** *hēmeras* dniem [[G2250]] [[N-GSF]] **τε** *te* zarówno – także [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **νυκτος** *nyktos* nocą [[G3571]] [[N-GSF]] **οπως** *hopōs* żeby [[G3704]] [[ADV]] **αυτον** *auton* go [[G846]] WTP-ASM **ανελωσιν** *anelōsin* zabiliby – znieśliby [[G337]] WTV-AAS-3P
###### **Dz 9,25**
 **λαβοντες** *labontes* Wziąwszy [[G2983]] WTV-2AAP-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **αυτον** *auton* go [[G846]] WTP-ASM **οι** *hoi* [[G3588]] WTT-NPM **μαθηται** *mathētai* uczniowie [[G3101]] WTN-NPM **νυκτος** *nyktos* nocą [[G3571]] [[N-GSF]] **καθηκαν** *kathēkan* spuścili [[G2524]] WTV-AAI-3P **δια** *dia* przez [[G1223]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **τειχους** *teichous* mur [[G5038]] [[N-GSN]] **χαλασαντες** *chalasantes* spuściwszy – zsunąwszy [[G5465]] WTV-AAP-NPM **εν** *en* w [[G1722]] [[PREP]] **σπυριδι** *spyridi* koszu [[G4711]] [[N-DSF]]
###### **Dz 9,26**
 **παραγενομενος** *paragenomenos* Przybywszy [[G3854]] WTV-2ADP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **σαυλος** *saulos* Saul – [zapytał] [[G4569]] [[N-NSM]] **εις** *eis* do [[G1519]] [[PREP]] **ιερουσαλημ** *ierousalēm* Jeruzalem – [dziedzictwo pokoju] [[G2419]] [[N-PRI]] **επειρατο** *epeirato* próbował [[G3987]] WTV-INI-3S **κολλασθαι** *kollasthai* być przyłączonym [[G2853]] WTV-PPN **τοις** *tois* (do) [[G3588]] WTT-DPM **μαθηταις** *mathētais* uczniów [[G3101]] WTN-DPM **και** *kai* i [[G2532]] [[CONJ]] **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **εφοβουντο** *efobounto* bali się [[G5399]] WTV-INI-3P **αυτον** *auton* go [[G846]] WTP-ASM **μη** *mē* nie [[G3361]] [[PRT-N]] **πιστευοντες** *pisteuontes* wierząc [[G4100]] WTV-PAP-NPM **οτι** *hoti* że [[G3754]] [[CONJ]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **μαθητης** *mathētēs* uczeń [[G3101]] [[N-NSM]]
###### **Dz 9,27**
 **βαρναβας** *barnabas* Barnaba – [syn pocieszenia] [[G921]] [[N-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **επιλαβομενος** *epilabomenos* chwyciwszy [[G1949]] WTV-2ADP-NSM **αυτον** *auton* go [[G846]] WTP-ASM **ηγαγεν** *ēgagen* przyprowadził [[G71]] WTV-2AAI-3S **προς** *pros* do [[G4314]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **αποστολους** *apostolous* wysłanników [[G652]] [[N-APM]] **και** *kai* i [[G2532]] [[CONJ]] **διηγησατο** *diēgēsato* opowiedział – opisał [[G1334]] WTV-ADI-3S **αυτοις** *autois* im [[G846]] WTP-DPM **πως** *pōs* jak [[G4459]] [[ADV]] **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **οδω** *hodō* drodze [[G3598]] [[N-DSF]] **ειδεν** *eiden* zobaczył [[G1492]] WTV-2AAI-3S **τον** *ton* [[G3588]] [[T-ASM]] **κυριον** *kyrion* Pana [[G2962]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **οτι** *hoti* że [[G3754]] [[CONJ]] **ελαλησεν** *elalēsen* powiedział [[G2980]] [[V-AAI-3S]] **αυτω** *autō* mu [[G846]] WTP-DSM **και** *kai* i [[G2532]] [[CONJ]] **πως** *pōs* jak [[G4459]] [[ADV]] **εν** *en* w [[G1722]] [[PREP]] **δαμασκω** *damaskō* Damaszku [[G1154]] [[N-DSF]] **επαρρησιασατο** *eparrēsiasato* powiedział otwarcie – powiedział śmiało [[G3955]] WTV-ADI-3S **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **ονοματι** *onomati* imieniu [[G3686]] WTN-DSN **του** *tou* [[G3588]] WTT-GSM **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]]
###### **Dz 9,28**
 **και** *kai* I [[G2532]] [[CONJ]] **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **μετ** *met* z [[G3326]] [[PREP]] **αυτων** *autōn* nimi [[G846]] WTP-GPM **εισπορευομενος** *eisporeuomenos* wchodzący [[G1531]] WTV-PNP-NSM **και** *kai* i [[G2532]] [[CONJ]] **εκπορευομενος** *ekporeuomenos* wychodzący [[G1607]] WTV-PNP-NSM **εν** *en* w [[G1722]] [[PREP]] **ιερουσαλημ** *ierousalēm* Jeruzalem – [dziedzictwo pokoju] [[G2419]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **παρρησιαζομενος** *parrēsiazomenos* mówiąc otwarcie – mówiąc śmiało [[G3955]] WTV-PNP-NSM **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **ονοματι** *onomati* imieniu [[G3686]] WTN-DSN **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]]
###### **Dz 9,29**
 **ελαλει** *elalei* Mówił [[G2980]] WTV-IAI-3S **τε** *te* zarówno – także [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **συνεζητει** *synezētei* dociekał razem – dyskutował [[G4802]] WTV-IAI-3S **προς** *pros* względem [[G4314]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **ελληνιστας** *hellēnistas* Greków – Hellenistów [[G1675]] [[N-APM]] **οι** *hoi* [[G3588]] WTT-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **επεχειρουν** *epecheiroun* usiłowali – próbowali [[G2021]] WTV-IAI-3P **αυτον** *auton* go [[G846]] WTP-ASM **ανελειν** *anelein* zabić – znieść [[G337]] [[V-2AAN]]
###### **Dz 9,30**
 **επιγνοντες** *epignontes* Dowiedziawszy się [[G1921]] WTV-2AAP-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **αδελφοι** *adelfoi* bracia [[G80]] WTN-NPM **κατηγαγον** *katēgagon* odprowadzili [[G2609]] WTV-2AAI-3P **αυτον** *auton* go [[G846]] WTP-ASM **εις** *eis* do [[G1519]] [[PREP]] **καισαρειαν** *kaisareian* Cezarei [[G2542]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **εξαπεστειλαν** *eksapesteilan* posłali [[G1821]] WTV-AAI-3P **αυτον** *auton* go [[G846]] WTP-ASM **εις** *eis* do [[G1519]] [[PREP]] **ταρσον** *tarson* Tarsu – [prawd. płaski kosz] [[G5019]] WTN-ASF
###### **Dz 9,31**
 **αι** *hai* [[G3588]] [[T-NPF]] **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **ουν** *oun* więc [[G3767]] [[CONJ]] **εκκλησιαι** *ekklēsiai* zgromadzenia – (społeczności) wywołanych [[G1577]] [[N-NPF]] **καθ** *kath* w [[G2596]] [[PREP]] **ολης** *holēs* całej [[G3650]] WTA-GSF **της** *tēs* [[G3588]] [[T-GSF]] **ιουδαιας** *ioudaias* Judei – [[wielbić] ziemię] [[G2449]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **γαλιλαιας** *galilaias* Galilei – [przesunąć] [[G1056]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **σαμαρειας** *samareias* Samarii – [zachować] [[G4540]] [[N-GSF]] **ειχον** *eichon* miały [[G2192]] WTV-IAI-3P **ειρηνην** *eirēnēn* pokój [[G1515]] WTN-ASF **οικοδομουμεναι** *oikodomoumenai* które są budowane [[G3618]] WTV-PPP-NPF **και** *kai* i [[G2532]] [[CONJ]] **πορευομεναι** *poreuomenai* które idą [[G4198]] WTV-PNP-NPF **τω** *tō* [[G3588]] WTT-DSM **φοβω** *fobō* strachem – bojaźnią [[G5401]] WTN-DSM **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **τη** *tē* [[G3588]] WTT-DSF **παρακλησει** *paraklēsei* pociechą – zachętą [[G3874]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSN **αγιου** *hagiou* Świętego [[G40]] [[A-GSN]] **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **επληθυνοντο** *eplēthynonto* były pomnażane [[G4129]] WTV-IPI-3P
###### **Dz 9,32**
 **εγενετο** *egeneto* Stało się [[G1096]] WTV-2ADI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **πετρον** *petron* Piotr – [kamyk] [[G4074]] [[N-ASM]] **διερχομενον** *dierchomenon* przechodząc [[G1330]] WTV-PNP-ASM **δια** *dia* przez [[G1223]] [[PREP]] **παντων** *pantōn* wszystkich [[G3956]] WTA-GPN **κατελθειν** *katelthein* zejść – zstąpić [[G2718]] [[V-2AAN]] **και** *kai* i [[G2532]] [[CONJ]] **προς** *pros* do [[G4314]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **αγιους** *hagious* świętych [[G40]] WTA-APM **τους** *tous* [[G3588]] WTT-APM **κατοικουντας** *katoikountas* zamieszkujących [[G2730]] WTV-PAP-APM **λυδδαν** *lyddan* Lyddę [[G3069]] WTN-ASF
###### **Dz 9,33**
 **ευρεν** *heuren* Znalazł [[G2147]] WTV-2AAI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **εκει** *ekei* tam [[G1563]] [[ADV]] **ανθρωπον** *anthrōpon* człowieka [[G444]] [[N-ASM]] **τινα** *tina* pewnego – jakiegoś [[G5100]] WTX-ASM **αινεαν** *ainean* Eneasza [[G132]] [[N-ASM]] **ονοματι** *onomati* imieniem [[G3686]] WTN-DSN **εξ** *eks* od [[G1537]] [[PREP]] **ετων** *etōn* lat [[G2094]] WTN-GPN **οκτω** *oktō* ośmiu [[G3638]] WTA-NUI **κατακειμενον** *katakeimenon* leżącego [[G2621]] WTV-PNP-ASM **επι** *epi* na [[G1909]] [[PREP]] **κραββατω** *krabbatō* macie – posłaniu [[G2895]] WTN-DSM **ος** *hos* który [[G3739]] WTR-NSM **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **παραλελυμενος** *paralelymenos* który jest sparaliżowany – który jest omdlały [[G3886]] WTV-RPP-NSM
###### **Dz 9,34**
 **και** *kai* I [[G2532]] [[CONJ]] **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **αυτω** *autō* mu [[G846]] WTP-DSM **ο** *ho* [[G3588]] [[T-NSM]] **πετρος** *petros* Piotr – [kamyk] [[G4074]] [[N-NSM]] **αινεα** *ainea* Eneaszu [[G132]] WTN-VSM **ιαται** *iatai* uzdrawia – leczy [[G2390]] WTV-PNI-3S **σε** *se* cię [[G4571]] WTP-2AS **ιησους** *iēsous* Jezus – [JHWH jest zbawieniem] [[G2424]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **αναστηθι** *anastēthi* powstań [[G450]] WTV-2AAM-2S **και** *kai* i [[G2532]] [[CONJ]] **στρωσον** *strōson* pościel [[G4766]] WTV-AAM-2S **σεαυτω** *seautō* sobie [[G4572]] WTF-2DSM **και** *kai* i [[G2532]] [[CONJ]] **ευθεως** *eutheōs* zaraz – natychmiast [[G2112]] [[ADV]] **ανεστη** *anestē* powstał – podniósł się [[G450]] WTV-2AAI-3S
###### **Dz 9,35**
 **και** *kai* I [[G2532]] [[CONJ]] **ειδον** *eidon* zobaczyli [[G1492]] WTV-2AAI-3P **αυτον** *auton* go [[G846]] WTP-ASM **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **οι** *hoi* [[G3588]] WTT-NPM **κατοικουντες** *katoikountes* zamieszkujący [[G2730]] WTV-PAP-NPM **λυδδαν** *lyddan* Lyddę [[G3069]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **τον** *ton* [[G3588]] [[T-ASM]] **σαρωνα** *sarōna* Saron – [zadowolony] [[G4565]] [[N-ASM]] **οιτινες** *hoitines* którzy [[G3748]] WTR-NPM **επεστρεψαν** *epestrepsan* nawrócili się [[G1994]] WTV-AAI-3P **επι** *epi* do [[G1909]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **κυριον** *kyrion* Pana [[G2962]] [[N-ASM]]
###### **Dz 9,36**
 **εν** *en* W [[G1722]] [[PREP]] **ιοππη** *ioppē* Joppie – [piękne] [[G2445]] [[N-DSF]] **δε** *de* zaś [[G1161]] [[CONJ]] **τις** *tis* pewna – jakaś [[G5100]] WTX-NSM **ην** *ēn* była [[G2258]] [[V-IXI-3S]] **μαθητρια** *mathētria* uczennica [[G3102]] [[N-NSF]] **ονοματι** *onomati* imieniem [[G3686]] WTN-DSN **ταβιθα** *tabitha* Tabita – [gazela] [[G5000]] [[N-PRI]] **η** *hē* która [[G3739]] WTR-NSF **διερμηνευομενη** *diermēneuomenē* tłumacząc – wykładając [[G1329]] WTV-PPP-NSF **λεγεται** *legetai* jest nazywana [[G3004]] WTV-PPI-3S **δορκας** *dorkas* Dorkas – Gazela [[G1393]] [[N-NSF]] **αυτη** *autē* ta [[G846]] WTP-NSF **ην** *ēn* była [[G2258]] [[V-IXI-3S]] **πληρης** *plērēs* pełna [[G4134]] WTA-NSF **αγαθων** *agathōn* dobrych [[G18]] WTA-GPN **εργων** *ergōn* dzieł – uczynków [[G2041]] WTN-GPN **και** *kai* i [[G2532]] [[CONJ]] **ελεημοσυνων** *eleēmosynōn* jałmużn [[G1654]] WTN-GPF **ων** *hōn* które [[G3739]] WTR-GPF **εποιει** *epoiei* czyniła [[G4160]] WTV-IAI-3S
###### **Dz 9,37**
 **εγενετο** *egeneto* Stało się [[G1096]] WTV-2ADI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **ημεραις** *hēmerais* dniach [[G2250]] WTN-DPF **εκειναις** *ekeinais* tych [[G1565]] WTD-DPF **ασθενησασαν** *asthenēsasan* która stała się słabą – która stała się bezsilną [[G770]] WTV-AAP-ASF **αυτην** *autēn* ona [[G846]] [[P-ASF]] **αποθανειν** *apothanein* umrzeć [[G599]] [[V-2AAN]] **λουσαντες** *lousantes* umywszy [[G3068]] WTV-AAP-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **αυτην** *autēn* ją [[G846]] [[P-ASF]] **εθηκαν** *ethēkan* położyli [[G5087]] WTV-AAI-3P **εν** *en* na [[G1722]] [[PREP]] **υπερωω** *hyperōō* sali na piętrze – górnej izbie [[G5253]] WTN-DSN
###### **Dz 9,38**
 **εγγυς** *engys* Blisko [[G1451]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **ουσης** *ousēs* będąc [[G5607]] WTV-PXP-GSF **λυδδης** *lyddēs* Lydda [[G3069]] [[N-GSF]] **τη** *tē* [[G3588]] WTT-DSF **ιοππη** *ioppē* Joppy – [piękne] [[G2445]] [[N-DSF]] **οι** *hoi* [[G3588]] WTT-NPM **μαθηται** *mathētai* uczniowie [[G3101]] WTN-NPM **ακουσαντες** *akousantes* usłyszawszy [[G191]] WTV-AAP-NPM **οτι** *hoti* że [[G3754]] [[CONJ]] **πετρος** *petros* Piotr – [kamyk] [[G4074]] [[N-NSM]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **εν** *en* w [[G1722]] [[PREP]] **αυτη** *autē* niej [[G846]] WTP-DSF **απεστειλαν** *apesteilan* wysłali [[G649]] WTV-AAI-3P **δυο** *dyo* dwóch [[G1417]] WTA-NUI **ανδρας** *andras* mężów [[G435]] [[N-APM]] **προς** *pros* do [[G4314]] [[PREP]] **αυτον** *auton* niego [[G846]] WTP-ASM **παρακαλουντες** *parakalountes* prosząc – zachęcając [[G3870]] WTV-PAP-NPM **μη** *mē* nie [[G3361]] [[PRT-N]] **οκνησαι** *oknēsai* opóźniać się – ociągać się [[G3635]] [[V-AAN]] **διελθειν** *dielthein* przejść [[G1330]] [[V-2AAN]] **εως** *heōs* aż do [[G2193]] [[CONJ]] **αυτων** *autōn* nich [[G846]] WTP-GPM
###### **Dz 9,39**
 **αναστας** *anastas* Wstawszy – Podniósłszy się [[G450]] WTV-2AAP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **πετρος** *petros* Piotr – [kamyk] [[G4074]] [[N-NSM]] **συνηλθεν** *synēlthen* przyszedł razem z [[G4905]] WTV-2AAI-3S **αυτοις** *autois* nimi [[G846]] WTP-DPM **ον** *hon* który [[G3739]] WTR-ASM **παραγενομενον** *paragenomenon* przyszedłszy [[G3854]] WTV-2ADP-ASM **ανηγαγον** *anēgagon* zaprowadzili [[G321]] WTV-2AAI-3P-ATT **εις** *eis* do [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **υπερωον** *hyperōon* sali na piętrze – górnej izby [[G5253]] WTN-ASN **και** *kai* i [[G2532]] [[CONJ]] **παρεστησαν** *parestēsan* stanęły obok [[G3936]] WTV-AAI-3P **αυτω** *autō* niego [[G846]] WTP-DSM **πασαι** *pasai* wszystkie [[G3956]] [[A-NPF]] **αι** *hai* [[G3588]] [[T-NPF]] **χηραι** *chērai* wdowy [[G5503]] [[N-NPF]] **κλαιουσαι** *klaiousai* płacząc [[G2799]] WTV-PAP-NPF **και** *kai* i [[G2532]] [[CONJ]] **επιδεικνυμεναι** *epideiknymenai* pokazując [[G1925]] WTV-PMP-NPF **χιτωνας** *chitōnas* tuniki [[G5509]] [[N-APM]] **και** *kai* i [[G2532]] [[CONJ]] **ιματια** *himatia* szaty – płaszcze [[G2440]] WTN-APN **οσα** *hosa* ile – jakie [[G3745]] WTK-APN **εποιει** *epoiei* czyniła [[G4160]] WTV-IAI-3S **μετ** *met* z [[G3326]] [[PREP]] **αυτων** *autōn* nimi [[G846]] WTP-GPF **ουσα** *ousa* będąc [[G5607]] WTV-PXP-NSF **η** *hē* [[G3588]] [[T-NSF]] **δορκας** *dorkas* Dorkas – Gazela [[G1393]] [[N-NSF]]
###### **Dz 9,40**
 **εκβαλων** *ekbalōn* Wyrzuciwszy [[G1544]] WTV-2AAP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **εξω** *eksō* na zewnątrz – poza [[G1854]] [[ADV]] **παντας** *pantas* wszystkich [[G3956]] WTA-APM **ο** *ho* [[G3588]] [[T-NSM]] **πετρος** *petros* Piotr – [kamyk] [[G4074]] [[N-NSM]] **θεις** *theis* położywszy [[G5087]] WTV-2AAP-NSM **τα** *ta* [[G3588]] WTT-APN **γονατα** *gonata* kolana [[G1119]] WTN-APN **προσηυξατο** *prosēuksato* pomodlił się [[G4336]] WTV-ADI-3S **και** *kai* i [[G2532]] [[CONJ]] **επιστρεψας** *epistrepsas* zwróciwszy się [[G1994]] WTV-AAP-NSM **προς** *pros* do [[G4314]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **σωμα** *sōma* ciała [[G4983]] WTN-ASN **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **ταβιθα** *tabitha* Tabito – [gazela] [[G5000]] [[N-PRI]] **αναστηθι** *anastēthi* powstań [[G450]] WTV-2AAM-2S **η** *hē* (ta) [[G3588]] [[T-NSF]] **δε** *de* zaś [[G1161]] [[CONJ]] **ηνοιξεν** *ēnoiksen* otworzyła [[G455]] [[V-AAI-3S]] **τους** *tous* [[G3588]] WTT-APM **οφθαλμους** *ofthalmous* oczy [[G3788]] [[N-APM]] **αυτης** *autēs* jej [[G846]] [[P-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **ιδουσα** *idousa* zobaczywszy [[G1492]] WTV-2AAP-NSF **τον** *ton* [[G3588]] [[T-ASM]] **πετρον** *petron* Piotra – [kamyk] [[G4074]] [[N-ASM]] **ανεκαθισεν** *anekathisen* usiadła [[G339]] [[V-AAI-3S]]
###### **Dz 9,41**
 **δους** *dous* Dawszy [[G1325]] WTV-2AAP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **αυτη** *autē* jej [[G846]] WTP-DSF **χειρα** *cheira* rękę [[G5495]] WTN-ASF **ανεστησεν** *anestēsen* wzbudził – podniósł [[G450]] [[V-AAI-3S]] **αυτην** *autēn* ją [[G846]] [[P-ASF]] **φωνησας** *fōnēsas* zawoławszy [[G5455]] WTV-AAP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **τους** *tous* [[G3588]] WTT-APM **αγιους** *hagious* świętych [[G40]] WTA-APM **και** *kai* i [[G2532]] [[CONJ]] **τας** *tas* [[G3588]] WTT-APF **χηρας** *chēras* wdowy [[G5503]] WTN-APF **παρεστησεν** *parestēsen* postawił obok – postawił przy [[G3936]] [[V-AAI-3S]] **αυτην** *autēn* ją [[G846]] [[P-ASF]] **ζωσαν** *zōsan* żyjącą [[G2198]] WTV-PAP-ASF
###### **Dz 9,42**
 **γνωστον** *gnōston* znajome [[G1110]] WTA-NSN **δε** *de* zaś [[G1161]] [[CONJ]] **εγενετο** *egeneto* stało się [[G1096]] WTV-2ADI-3S **καθ** *kath* według [[G2596]] [[PREP]] **ολης** *holēs* całej [[G3650]] WTA-GSF **της** *tēs* [[G3588]] [[T-GSF]] **ιοππης** *ioppēs* Joppy – [piękna] [[G2445]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **πολλοι** *polloi* liczni – wielu [[G4183]] WTA-NPM **επιστευσαν** *episteusan* uwierzyli [[G4100]] WTV-AAI-3P **επι** *epi* w [[G1909]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **κυριον** *kyrion* Pana [[G2962]] [[N-ASM]]
###### **Dz 9,43**
 **εγενετο** *egeneto* Stało się [[G1096]] WTV-2ADI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **ημερας** *hēmeras* dni [[G2250]] WTN-APF **ικανας** *hikanas* dość liczne [[G2425]] WTA-APF **μειναι** *meinai* pozostać [[G3306]] [[V-AAN]] **αυτον** *auton* on [[G846]] WTP-ASM **εν** *en* w [[G1722]] [[PREP]] **ιοππη** *ioppē* Joppie – [piękne] [[G2445]] [[N-DSF]] **παρα** *para* u [[G3844]] [[PREP]] **τινι** *tini* pewnego – jakiegoś [[G5100]] WTX-DSM **σιμωνι** *simōni* Szymona – [słyszeć] [[G4613]] WTN-DSM **βυρσει** *byrsei* garbarza [[G1038]] WTN-DSM
