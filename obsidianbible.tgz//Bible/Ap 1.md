# Ap 1 BT5
###### **Ap 1,1**
 Objawienie Jezusa Chrystusa, które dał Mu Bóg, aby ukazać swym sługom, co musi stać się niebawem,i [co] On, wysławszy swojego anioła, oznajmił przez niego za pomocą znakówsłudze swojemu, Janowi.
###### **Ap 1,2**
 Ten poświadcza, że słowem Bożymi świadectwem Jezusa Chrystusajest wszystko, co widział.
###### **Ap 1,3**
 Błogosławiony, który odczytuje, i ci, którzy słuchają słów proroctwa, a strzegą tego, co w nim napisane, bo chwila jest bliska.
###### **Ap 1,4**
 Jan do siedmiu Kościołów, które są w Azji:Łaska wam i pokójod Tego, Który jest i Który był, i Który przychodzi,i od siedmiu Duchów, które są przed Jego tronem,
###### **Ap 1,5**
 i od Jezusa Chrystusa, Świadka Wiernego, Pierworodnego [wśród] umarłychi Władcy królów ziemi.Temu, który nas miłujei który przez swą krew uwolnił nas od naszych grzechów,
###### **Ap 1,6**
 i uczynił nas królestwem – kapłanami dla Boga i Ojca swojego, Jemu chwała i moc na wieki wieków! Amen.
###### **Ap 1,7**
 Oto nadchodzi z obłokamii ujrzy Go wszelkie oko i wszyscy, którzy Go przebili. I będą Go opłakiwać wszystkie pokolenia ziemi.Tak: Amen.
###### **Ap 1,8**
 Ja jestem Alfa i Omega, mówi Pan Bóg, Który jest, Który był i Który przychodzi, Wszechmogący.
###### **Ap 1,9**
 Ja, Jan, wasz brati współuczestnik w ucisku i królestwie, i wytrwaniu w Jezusie, byłem na wyspie, zwanej Patmos, z powodu słowa Bożego i świadectwa Jezusa.
###### **Ap 1,10**
 Doznałem zachwycenia w dzień Pańskii posłyszałem za sobą potężny głos, jak gdyby trąby
###### **Ap 1,11**
 mówiącej:«***Co widzisz, napisz w księdzei poślij siedmiu Kościołom: do Efezu, Smyrny, Pergamonu, Tiatyry, Sardes, Filadelfii i Laodycei***».
###### **Ap 1,12**
 I obróciłem się, by patrzeć, co to za głos do mnie mówił; a obróciwszy się, ujrzałem siedem złotych świeczników
###### **Ap 1,13**
  i pośród świeczników kogoś podobnego do Syna Człowieczego, przyobleczonego [w szatę] do stópi przepasanego na piersiach złotym pasem.
###### **Ap 1,14**
 Głowa Jego i włosy – białe jak biała wełna, jak śnieg, a oczy Jego jak płomień ognia.
###### **Ap 1,15**
 Stopy Jego podobne do drogocennego metalu, jak gdyby w piecu rozżarzonego, a głos Jego jak głos wielu wód.
###### **Ap 1,16**
 W prawej swej ręce miał siedem gwiazdi z Jego ust wychodził miecz obosieczny, ostry. A Jego wygląd – jak słońce, kiedy jaśnieje w swej mocy.
###### **Ap 1,17**
 Kiedy Go ujrzałem, do stóp Jego padłem jak martwy, a On położył na mnie prawą rękę, mówiąc:«***Przestań się lękać! Ja jestem Pierwszy i Ostatni,***
###### **Ap 1,18**
 ***i Żyjący. Byłem umarły, a oto jestem żyjący na wieki wiekówi mam klucze śmierci i Otchłani.***
###### **Ap 1,19**
 ***Napisz więc to, co widziałeś i co jest, i co potem musi się stać.***
###### **Ap 1,20**
 ***Co do tajemnicy siedmiu gwiazd, które ujrzałeś w mojej prawej ręce, i co do siedmiu złotych świeczników:siedem gwiazd – to są aniołowie siedmiu Kościołów, a siedem świeczników – to jest siedem Kościołów.***
# Ap 1 PAU
###### **Ap 1,1**
 Objawienie Jezusa Chrystusa, które dał mu Bóg, aby pokazać swoim sługom, co wkrótce musi się wydarzyć. On posłał swojego anioła, aby ukazał to Jego słudze, Janowi.
###### **Ap 1,2**
 Ten poświadczył słowo Boże i świadectwo Jezusa Chrystusa, zgodnie z tym, co widział.
###### **Ap 1,3**
 Szczęśliwy, kto odczytuje, i ci, którzy słyszą słowa proroctwa oraz przestrzegają tego, co jest w nim napisane, bo czas jest bliski.
###### **Ap 1,4**
 Jan do siedmiu Kościołów, które są w Azji: Łaska wam i pokój od Tego, który jest, który był i który przychodzi oraz od siedmiu Duchów, które są przed Jego tronem,
###### **Ap 1,5**
 i od Jezusa Chrystusa, wiernego świadka, Pierworodnego spośród umarłych i Władcy królów ziemi. Temu, który nas miłuje i który swoją krwią uwolnił nas od naszych grzechów
###### **Ap 1,6**
 oraz uczynił nas królestwem, kapłanami dla Boga, swego Ojca, Jemu chwała i panowanie na wieki wieków. Amen.
###### **Ap 1,7**
 Oto przychodzi wśród obłoków i każdy Go zobaczy, również ci, którzy Go przebili. Wszystkie narody ziemi będą nad Nim lamentować. Tak! Amen!
###### **Ap 1,8**
 „Ja jestem Alfa i Omega” - mówi Pan Bóg, który jest, który był i który przychodzi, Wszechmocny!
###### **Ap 1,9**
 Ja, Jan, wasz brat, złączony z wami przez ucisk, królestwo i wytrwałość w Jezusie, z powodu słowa Bożego i świadectwa Jezusa znalazłem się na wyspie zwanej Patmos.
###### **Ap 1,10**
 W dzień Pana ogarnął mnie Duch i usłyszałem za sobą głos potężny jak dźwięk trąby,
###### **Ap 1,11**
 który mówił: „To, co widzisz, opisz w księdze i prześlij do siedmiu Kościołów: do Efezu, Smyrny, Pergamonu, Tiatyry, Sard, Filadelfii i Laodycei”.
###### **Ap 1,12**
 Obejrzałem się, żeby zobaczyć, co za głos do mnie mówił. Gdy się obejrzałem, zobaczyłem siedem złotych świeczników,
###### **Ap 1,13**
 a pośród świeczników kogoś podobnego do Syna Człowieczego, ubranego w szatę długą do stóp i przepasanego na piersiach złotym pasem.
###### **Ap 1,14**
 Jego głowa i włosy były białe jak biała wełna, jak śnieg, a oczy jak płomień ognia.
###### **Ap 1,15**
 Jego stopy były podobne do drogocennego metalu oczyszczonego w tyglu, a Jego głos - jak szum wielkich wód.
###### **Ap 1,16**
 W prawej ręce trzymał siedem gwiazd, a z Jego ust wychodził ostry miecz obosieczny. Jego wygląd podobny był do słońca świecącego pełnią swego blasku.
###### **Ap 1,17**
 Gdy Go ujrzałem, padłem jak martwy do Jego stóp. On jednak położył na mnie swoją prawą rękę i powiedział: „Nie bój się! Ja jestem Pierwszy i Ostatni,
###### **Ap 1,18**
 i Żyjący. Byłem umarły, a oto jestem Żyjący na wieki wieków. Mam też klucze śmierci i krainy umarłych.
###### **Ap 1,19**
 Opisz więc to, co widziałeś, co jest i co stanie się potem.
###### **Ap 1,20**
 Tajemnica siedmiu gwiazd, które zobaczyłeś w mojej prawej ręce i siedmiu złotych świeczników jest taka: siedem gwiazd to aniołowie siedmiu Kościołów, a siedem świeczników to siedem Kościołów.
# Ap 1 BP
###### **Ap 1,1**
 Objawienie Jezusa Chrystusa, które dał Mu Bóg, aby ukazać swym sługom, co musi stać się niebawem, a [On] wysławszy swojego anioła oznajmił przez niego za pomocą znaków słudze swojemu Janowi.
###### **Ap 1,2**
 Ten poświadcza, że wszystko, co widział, jest słowem Bożym i świadectwem Jezusa Chrystusa.
###### **Ap 1,3**
 Szczęśliwy, który czyta, i [ci] którzy słuchają słów Proroctwa, a strzegą tego, co w nich napisane, bo chwila jest bliska.
###### **Ap 1,4**
 Jan do siedmiu Kościołów, które są w Azji: Łaska wam i pokój od Tego, który jest, który był i który przychodzi, i od siedmiu Duchów, które są przed Jego tronem,
###### **Ap 1,5**
 i od Jezusa Chrystusa, Świadka Wiernego, Pierworodnego umarłych i Władcy królów ziemi. Temu, który nas miłuje i który przez swoją krew uwolnił nas od naszych grzechów
###### **Ap 1,6**
 i uczynił nas królestwem - kapłanami dla Boga, Ojca swojego, Jemu chwała i moc na wieki wieków. Amen.
###### **Ap 1,7**
 Oto nadchodzi z obłokami i ujrzy Go wszelkie oko i wszyscy, którzy Go przebili. I będą Go opłakiwać wszystkie pokolenia ziemi. Tak [jest]: Amen.
###### **Ap 1,8**
 Jam jest Alfa i Omega, mówi Pan Bóg, który jest, który był i który przychodzi, Władca wszech rzeczy.
###### **Ap 1,9**
 Ja, Jan, wasz brat i współuczestnik w ucisku i królestwie, i wytrwałości w Jezusie, byłem na wyspie, zwanej Patmos, z powodu słowa Bożego i świadectwa Jezusa.
###### **Ap 1,10**
 Doznałem zachwycenia w dzień Pański i posłyszałem za sobą potężny głos jak gdyby trąby
###### **Ap 1,11**
 mówiącej: "Co widzisz, zapisz w księdze i poślij siedmiu Kościołom: do Efezu, Smyrny, Pergamu, Tiatyry, Sardów, Filadelfii i Laodycei".
###### **Ap 1,12**
 I obróciłem się, chcąc widzieć, co za głos do mnie mówił, a obróciwszy się ujrzałem siedem złotych świeczników,
###### **Ap 1,13**
 i pośród świeczników kogoś podobnego do Syna Człowieczego, obleczonego [w szatę] do stóp i przepasanego na piersiach złotym pasem.
###### **Ap 1,14**
 Głowa Jego i włosy białe jak biała wełna, jak śnieg, a oczy Jego jak płomień ognisty.
###### **Ap 1,15**
 Stopy Jego podobne do drogocennego metalu jak gdyby w piecu rozżarzonego, a głos Jego jak głos wielu wód.
###### **Ap 1,16**
 W prawej ręce miał siedem gwiazd i z Jego ust wychodził miecz obosieczny, ostry. A Jego wygląd - jak słońce, kiedy jaśnieje w swej mocy.
###### **Ap 1,17**
 Kiedym Go ujrzał, upadłem do Jego stóp jak martwy, a On położył na mnie prawą rękę, mówiąc: "Przestań się lękać! Jam jest Pierwszy i Ostatni,
###### **Ap 1,18**
 i żyjący. Byłem umarły, a oto jestem żyjący na wieki wieków i mam klucze śmierci i Otchłani.
###### **Ap 1,19**
 Zapisz więc to, co widziałeś, i to, co jest, i to, co potem musi się stać.
###### **Ap 1,20**
 A oto tajemnica siedmiu gwiazd, któreś ujrzał w mojej prawej ręce, i siedmiu złotych świeczników: siedem gwiazd - to aniołowie siedmiu Kościołów, a siedem świeczników - to siedem Kościołów".
# Ap 1 BR
###### **Ap 1,1**
 Objawienie, które Bóg przekazał Jezusowi Chrystusowi, aby zapowiedzieć swoim sługom, co miało się stać niebawem. Poprzez wysłannika swego, anioła, oznajmił wszystko, za pomocą specjalnych znaków, słudze swojemu Janowi.
###### **Ap 1,2**
 Ten zaś potwierdza [prawdziwość] słowa Bożego i świadczy o wszystkich czynach Jezusa Chrystusa, które widział.
###### **Ap 1,3**
 Błogosławiony każdy, kto czyta i słyszy słowa tego proroctwa i zachowuje wszystko, co jest w nim napisane. Czas [wypełnienia się] jest już bowiem bliski.
###### **Ap 1,4**
 Jan - do siedmiu Kościołów w Azji. Łaska wam i pokój od Tego, Który jest, Który był i Który przyjdzie, oraz od siedmiu Duchów, które są przed Jego tronem,
###### **Ap 1,5**
 a także od Jezusa Chrystusa, który jest Świadkiem wiernym, Pierworodnym pośród umarłych i Władcą wszystkich królów ziemi. On to umiłował nas, przez swoją krew uwolnił nas od naszych grzechów
###### **Ap 1,6**
 i uczynił z nas królestwo kapłanów mających służyć Bogu i Ojcu swojemu. Jemu chwała i moc na wieki wieków. Amen.
###### **Ap 1,7**
 Oto nadchodzi wśród obłoków. Zobaczą Go wszyscy, także ci, którzy Go przebili włócznią. I będą Go opłakiwać wszystkie pokolenia ziemi. Zaiste tak będzie. Amen.
###### **Ap 1,8**
 Ja jestem Alfa i Omega - mówi Pan Bóg - Ja jestem Tym, Który jest, Który był i Który przyjdzie. Ja jestem wszechmocnym.
###### **Ap 1,9**
 Ja, Jan, brat i uczestnik waszych udręk, ale i współkrólowania oraz cierpliwego współoczekiwania w Jezusie, kiedy przebywałem na wyspie Patmos [zesłany tam] dlatego, że głosiłem słowo Boże i świadczyłem o Jezusie,
###### **Ap 1,10**
 pewnego dnia Pańskiego popadłem w zachwyt i usłyszałem za sobą głos jakby potężnej trąby,
###### **Ap 1,11**
 wydającej mi taki oto nakaz: Wszystko, co widzisz, opisz w specjalnej księdze i poślij ją do siedmiu Kościołów: do Efezu, do Smyrny, do Pergamu, do Tiatyry, do Sardów, do Filadelfii i do Laodycei.
###### **Ap 1,12**
 Wówczas obróciłem się, żeby zobaczyć, kto do mnie mówi. I ujrzałem siedem złotych świeczników,
###### **Ap 1,13**
 a wśród nich kogoś, kto był podobny do Syna Człowieczego. Miał na sobie szatę długą aż do ziemi i był przepasany wokół piersi złotym pasem.
###### **Ap 1,14**
 Głowa jego i włosy były białe jak wybielona wełna lub jak śnieg, a oczy miał płomieniste jak ognie.
###### **Ap 1,15**
 Stopy - niby z cennego metalu rozżarzonego w ogniu, a głos rozbrzmiewał niczym szum wód potężnych.
###### **Ap 1,16**
 W prawej ręce trzymał siedem gwiazd, z ust wystawał mu miecz obosieczny. Całym zaś wyglądem swoim lśnił jak słońce w swej mocy.
###### **Ap 1,17**
 Ujrzawszy Go upadłem Mu jak martwy do stóp, a On położył na mnie swą prawą rękę i powiedział: Nie bój się! Ja jestem Pierwszy i Ostatni.
###### **Ap 1,18**
 Jestem żywy. Byłem już umarły, ale znów żyję [teraz już] na wieki wieków. Mam również klucze do królestwa śmierci i otchłani.
###### **Ap 1,19**
 Napisz więc wszystko, coś widział: co jest już i co ma nastąpić.
###### **Ap 1,20**
 A oto znaczenie siedmiu gwiazd, które trzymam w mym prawym ręku, i siedmiu złotych świeczników: siedem gwiazd - to aniołowie siedmiu Kościołów, siedem świeczników zaś - to siedem Kościołów.
# Ap 1 WUJ
###### **Ap 1,1**
 Objawienie Jezusa Chrystusa, które jemu dał Bóg, aby objawił sługom swym co się ma dziać w rychle: i oznajmił, posławszy przez anioła swojego słudze swemu Janowi,
###### **Ap 1,2**
 Który świadectwo wydał słowu Bożemu, i świadectwo Jezusa Chrystusa, cokolwiek widział.
###### **Ap 1,3**
 Błogosławiony który czyta, i słucha słów proroctwa tego: i zachowywa to co w niem jest napisano: abowiem czas jest blizko.
###### **Ap 1,4**
 Jan siedmi kościołom, które są w Azjej. Łaska wam i pokój od tego, który jest, i który był, i który przydzie, i od siedmi duchów, którzy są przed oblicznością stolice jego.
###### **Ap 1,5**
 I od Jezusa Chrystusa, który jest wierny świadek, pierworodny umarłych, i książę królów ziemie, który nas umiłował, i omył nas z grzechów naszych we krwi swojej,
###### **Ap 1,6**
 I uczynił nas królestwem i kapłany Bogu i Ojcu swemu, jemu chwała i władza na wieki wieków. Amen.
###### **Ap 1,7**
 Oto idzie z obłokami, i ujrzy go wszelkie oko, i którzy go przebili, i bić się będą dla niego wszystkie pokolenia ziemie: Tak, Amen.
###### **Ap 1,8**
 Jam jest Alpha i Omega, początek i koniec, mówi Pan Bóg, który jest, i który był, i który przydzie wszechmogący.
###### **Ap 1,9**
 Ja Jan, brat wasz i uczestnik ucisku, i w królestwie, i w cierpliwości w Chrystusie Jezusie, byłem na wyspie, którą zowią Patmos, dla słowa Bożego, i świadectwa Jezusa.
###### **Ap 1,10**
 Byłem w duchu w dzień Pański, i słyszałem głos za sobą wielki jako trąby
###### **Ap 1,11**
 Mówiącej: Co widzisz, napisz w księgi: i pośli siędmi kościołom, które są w Azjej, Ephezowi, i Smyrnie, i Pergamowi, i Thiatyrze, i Sardowi, i Philadelphjej, i Laodycej.
###### **Ap 1,12**
 I obróciłem się, abym obaczył głos, który mówił ze mną. A obróciwszy się ujrzałem siedm lichtarzów złotych:
###### **Ap 1,13**
 A w pośrodku siedmi lichtarzów złotych podobnego Synowi człowieczemu, obleczonego w długą szatę, i przepasanego u piersi pasem złotym.
###### **Ap 1,14**
 A głowa jego i włosy były białe jako wełna biała, i jako śnieg, a oczy jego jako płomień ognia.
###### **Ap 1,15**
 A nogi jego podobne mosiądzowi, jakoby w piecu rozpalonemu: a głos jego jako głos wiela wód:
###### **Ap 1,16**
 A miał w swej prawej ręce siedm gwiazd. A z ust jego miecz z obu stron ostry wychodził: a oblicze jego, jako słońce świeci w swej mocy.
###### **Ap 1,17**
 A gdym go ujrzał, upadłem do nóg jego jako martwy. I włożył prawą rękę swoję na mię, mówiąc: Nie bój się. Jam jest pierwszy i ostateczny.
###### **Ap 1,18**
 I żywy, i byłem umarły, a oto jestem żywiący na wieki wieków, i mam klucze śmierci i piekła.
###### **Ap 1,19**
 Napisz tedy coś widział, i co jest, i co się dziać ma na potem.
###### **Ap 1,20**
 Tajemnicę siedmi gwiazd, któreś widział w prawej ręce mojej, i siedm lichtarzów złotych. Siedm gwiazd, są aniołowie siedmi kościołów: a siedm lichtarzów, są siedm kościołów.
# Ap 1 STERN
###### **Ap 1,1**
 Oto objawienie, które Bóg dał Jeszui Mesjaszowi, aby mógł On ukazać swoim sługom, co musi stać się już wkrótce. Oznajmił On to, posyłając swego anioła do sługi swego Jochanana,
###### **Ap 1,2**
 który zaświadczył na rzecz Słowa Bożego i świadectwa Jeszui Mesjasza w sprawie tego, co widział.
###### **Ap 1,3**
 Błogosławiony ten, kto czyta, i ci, którzy słuchają słów tego proroctwa, jeśli tylko zachowują to, co w nim zapisano! Bo czas jest bliski!
###### **Ap 1,4**
 Jochanan do siedmiu wspólnot mesjanicznych w prowincji Azja: łaska wam i szalom od Tego, który jest, który był i który nadchodzi; od siedmiorakiego Ducha przed Jego tronem
###### **Ap 1,5**
 i od Jeszui Mesjasza, wiernego świadka, pierworodnego spośród umarłych i władcy królów ziemi. Jego to, Tego, który nas miłuje, który wyzwolił nas z naszych grzechów za cenę swojej krwi,
###### **Ap 1,6**
 który sprawił, że staliśmy się królestwem, czyli kohanim dla Boga, Jego Ojca, Jego niech będzie chwała i panowanie na wieki wieków. Amen.
###### **Ap 1,7**
 Spójrzcie! On nadchodzi wśród obłoków! Ujrzy Go każde oko, także ci, którzy Go przebili, i wszystkie plemiona Ziemi będą Go opłakiwać. Tak! Amen!
###### **Ap 1,8**
 "Ja jestem A i Z - mówi Adonai -Bóg wojsk niebieskich, Ten, który jest, który był i który nadchodzi".
###### **Ap 1,9**
 Ja, Jochanan, jestem waszym bratem i współuczestnikiem w cierpieniu, godności królewskiej oraz wytrwałości, jakie płyną ze zjednoczenia z Jeszuą. Zesłano mnie na wyspę zwaną Patmos za głoszenie nauki Boga i świadczenie o Jeszui.
###### **Ap 1,10**
 W Duchu znalazłem się w Dniu Pana i usłyszałem za sobą głos donośny, niczym trąba,
###### **Ap 1,11**
 który mówił: "Zapisz, co widzisz, na zwoju i poślij to siedmiu wspólnotom mesjanicznym - Efezowi, Smyrnie, Pergamonowi, Tiatyrze, Sardis, Filadelfii i Laodycei!".
###### **Ap 1,12**
 Obejrzałem się, żeby zobaczyć, kto do mnie mówi, a gdy się odwróciłem, ujrzałem siedem złotych menor,
###### **Ap 1,13**
 a między menorami był ktoś podobny do Syna Człowieczego, odziany w szatę aż do stóp, przepasany złotą szarfą na piersiach.
###### **Ap 1,14**
 Jego głowa i włosy były białe jak śnieżnobiała wełna, Jego oczy jak ognisty płomień,
###### **Ap 1,15**
 Jego stopy niczym polerowany mosiądz oczyszczany w piecu hutniczym, a Jego głos jak dźwięk rwących wód.
###### **Ap 1,16**
 W prawej ręce trzymał siedem gwiazd, z Jego ust wychodził ostry miecz obosieczny, a Jego oblicze było jak słońce świecące pełnią swej mocy.
###### **Ap 1,17**
 Gdy Go ujrzałem, padłem u Jego stóp jak martwy. Położył na mnie swą prawicę i rzekł: "Nie bój się! Jam jest Pierwszy i Ostatni,
###### **Ap 1,18**
 Żyjący. Byłem umarły, ale spójrz! Żyję na wieki wieków! I dzierżę klucze do Śmierci i Sz'olu.
###### **Ap 1,19**
 Zapisz więc, co widzisz, i to, co jest teraz, i to, co nastąpi potem.
###### **Ap 1,20**
 A oto ukryte znaczenie siedmiu gwiazd, które widziałeś w mojej prawej ręce, i siedmiu złotych menor: siedem gwiazd to aniołowie siedmiu wspólnot mesjanicznych, a siedem menor to siedem wspólnot mesjanicznych.
# Ap 1 TRO
###### **Ap 1,1**
 **αποκαλυψις** *apokalypsis* Objawienie [[G602]] [[N-NSF]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **ην** *hēn* które [[G3739]] WTR-ASF **εδωκεν** *edōken* dał [[G1325]] [[V-AAI-3S]] **αυτω** *autō* mu [[G846]] WTP-DSM **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **δειξαι** *deiksai* (by) pokazać [[G1166]] [[V-AAN]] **τοις** *tois* [[G3588]] WTT-DPM **δουλοις** *doulois* niewolnikom – sługom [[G1401]] WTN-DPM **αυτου** *autou* Jego [[G846]] [[P-GSM]] **α** *ha* co [[G3739]] WTR-APN **δει** *dei* trzeba – jest konieczne [[G1163]] WTV-PQI-3S **γενεσθαι** *genesthai* stać się [[G1096]] WTV-2ADN **εν** *en* w [[G1722]] [[PREP]] **ταχει** *tachei* szybkości – pośpiechu [[G5034]] WTN-DSN **και** *kai* i [[G2532]] [[CONJ]] **εσημανεν** *esēmanen* oznaczył – wskazał [[G4591]] [[V-AAI-3S]] **αποστειλας** *aposteilas* wysławszy [[G649]] WTV-AAP-NSM **δια** *dia* przez [[G1223]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **αγγελου** *angelou* zwiastuna [[G32]] [[N-GSM]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **τω** *tō* [[G3588]] WTT-DSM **δουλω** *doulō* niewolnikowi – słudze [[G1401]] WTN-DSM **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ιωαννη** *iōannē* Janowi – [JHWH jest łaskawy] [[G2491]] WTN-DSM
###### **Ap 1,2**
 **ος** *hos* który [[G3739]] WTR-NSM **εμαρτυρησεν** *emartyrēsen* poświadczył [[G3140]] [[V-AAI-3S]] **τον** *ton* [[G3588]] [[T-ASM]] **λογον** *logon* Słowo [[G3056]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **μαρτυριαν** *martyrian* świadectwo [[G3141]] WTN-ASF **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **οσα** *hosa* ile – jak [[G3745]] WTK-APN **τε** *te* zarówno – także [[G5037]] WTPRT **ειδεν** *eiden* zobaczył [[G1492]] WTV-2AAI-3S
###### **Ap 1,3**
 **μακαριος** *makarios* szczęśliwy – błogosławiony [[G3107]] [[A-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **αναγινωσκων** *anaginōskōn* czytający [[G314]] [[V-PAP-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **ακουοντες** *akouontes* słuchający [[G191]] WTV-PAP-NPM **τους** *tous* [[G3588]] WTT-APM **λογους** *logous* słów [[G3056]] [[N-APM]] **της** *tēs* [[G3588]] [[T-GSF]] **προφητειας** *profēteias* proroctwa [[G4394]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **τηρουντες** *tērountes* zachowujący – strzegący [[G5083]] WTV-PAP-NPM **τα** *ta* [[G3588]] WTT-APN **εν** *en* w [[G1722]] [[PREP]] **αυτη** *autē* nim [[G846]] WTP-DSF **γεγραμμενα** *gegrammena* które jest napisane [[G1125]] WTV-RPP-APN **ο** *ho* [[G3588]] [[T-NSM]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **καιρος** *kairos* pora [[G2540]] [[N-NSM]] **εγγυς** *engys* blisko [[G1451]] [[ADV]]
###### **Ap 1,4**
 **ιωαννης** *iōannēs* Jan – [JHWH jest łaskawy] [[G2491]] [[N-NSM]] **ταις** *tais* [[G3588]] WTT-DPF **επτα** *hepta* siedmiu [[G2033]] WTA-NUI **εκκλησιαις** *ekklēsiais* zgromadzeniom – (społecznościom) wywołanych [[G1577]] WTN-DPF **ταις** *tais* [[G3588]] WTT-DPF **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **ασια** *asia* Azji [[G773]] [[N-DSF]] **χαρις** *charis* łaska [[G5485]] [[N-NSF]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **και** *kai* i [[G2532]] [[CONJ]] **ειρηνη** *eirēnē* pokój [[G1515]] [[N-NSF]] **απο** *apo* od [[G575]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **ο** *ho* (Tego) [[G3588]] [[T-NSM]] **ων** *ōn* który jest [[G5607]] [[V-PXP-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **ερχομενος** *erchomenos* który przychodzi [[G2064]] WTV-PNP-NSM **και** *kai* i [[G2532]] [[CONJ]] **απο** *apo* od [[G575]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **επτα** *hepta* siedmiu [[G2033]] WTA-NUI **πνευματων** *pneumatōn* duchów [[G4151]] WTN-GPN **α** *ha* które [[G3739]] WTR-NPN **εστιν** *estin* jest (są) [[G2076]] WTV-PXI-3S **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronem [[G2362]] [[N-GSM]] **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Ap 1,5**
 **και** *kai* i [[G2532]] [[CONJ]] **απο** *apo* od [[G575]] [[PREP]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **ο** *ho* [[G3588]] [[T-NSM]] **μαρτυς** *martys* świadek [[G3144]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **πιστος** *pistos* wierny [[G4103]] [[A-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **πρωτοτοκος** *prōtotokos* pierworodny [[G4416]] [[A-NSM]] **εκ** *ek* z [[G1537]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **νεκρων** *nekrōn* martwych [[G3498]] WTA-GPM **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **αρχων** *archōn* przywódca – przełożony [[G758]] [[N-NSM]] **των** *tōn* [[G3588]] WTT-GPM **βασιλεων** *basileōn* królów [[G935]] WTN-GPM **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]] **τω** *tō* [[G3588]] WTT-DSM **αγαπησαντι** *agapēsanti* który umiłował [[G25]] WTV-AAP-DSM **ημας** *hēmas* nas [[G2248]] WTP-1AP **και** *kai* i [[G2532]] [[CONJ]] **λουσαντι** *lousanti* który umył [[G3068]] WTV-AAP-DSM **ημας** *hēmas* nas [[G2248]] WTP-1AP **απο** *apo* z [[G575]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPF **αμαρτιων** *hamartiōn* grzechów [[G266]] WTN-GPF **ημων** *hēmōn* naszych [[G2257]] WTP-1GP **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **αιματι** *haimati* krwi [[G129]] WTN-DSN **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Ap 1,6**
 **και** *kai* i [[G2532]] [[CONJ]] **εποιησεν** *epoiēsen* uczynił [[G4160]] [[V-AAI-3S]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **βασιλεις** *basileis* królami [[G935]] [[N-APM]] **και** *kai* i [[G2532]] [[CONJ]] **ιερεις** *hiereis* kapłanami [[G2409]] [[N-APM]] **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **πατρι** *patri* Ojcu [[G3962]] WTN-DSM **αυτου** *autou* Jego [[G846]] [[P-GSM]] **αυτω** *autō* Jemu [[G846]] WTP-DSM **η** *hē* [[G3588]] [[T-NSF]] **δοξα** *doksa* chwała [[G1391]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **κρατος** *kratos* moc – siła [[G2904]] WTN-NSN **εις** *eis* na [[G1519]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **αιωνας** *aiōnas* wieki [[G165]] [[N-APM]] **των** *tōn* [[G3588]] WTT-GPM **αιωνων** *aiōnōn* wieków [[G165]] WTN-GPM **αμην** *amēn* amen – [zaprawdę] [[G281]] WTHEB
###### **Ap 1,7**
 **ιδου** *idou* Oto [[G2400]] WTV-2AAM-2S **ερχεται** *erchetai* przychodzi [[G2064]] WTV-PNI-3S **μετα** *meta* z [[G3326]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPF **νεφελων** *nefelōn* chmurami – obłokami [[G3507]] WTN-GPF **και** *kai* i [[G2532]] [[CONJ]] **οψεται** *opsetai* zobaczy [[G3700]] WTV-FDI-3S **αυτον** *auton* Go [[G846]] WTP-ASM **πας** *pas* każde [[G3956]] [[A-NSM]] **οφθαλμος** *ofthalmos* oko [[G3788]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **οιτινες** *hoitines* którzy [[G3748]] WTR-NPM **αυτον** *auton* Go [[G846]] WTP-ASM **εξεκεντησαν** *eksekentēsan* przebili – przebodli [[G1574]] WTV-AAI-3P **και** *kai* i [[G2532]] [[CONJ]] **κοψονται** *kopsontai* będą uderzać się (w piersi) [[G2875]] WTV-FDI-3P **επ** *ep* przez [[G1909]] [[PREP]] **αυτον** *auton* Niego [[G846]] WTP-ASM **πασαι** *pasai* wszystkie [[G3956]] [[A-NPF]] **αι** *hai* [[G3588]] [[T-NPF]] **φυλαι** *fylai* plemiona [[G5443]] [[N-NPF]] **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]] **ναι** *nai* tak [[G3483]] WTPRT **αμην** *amēn* amen – [zaprawdę] [[G281]] WTHEB
###### **Ap 1,8**
 **εγω** *egō* Ja [[G1473]] WTP-1NS **ειμι** *eimi* jestem [[G1510]] WTV-PXI-1S **το** *to* [[G3588]] WTT-NSN **α** *ha* alfa [[G1]] WTN-LI **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **ω** *ō* omega [[G5598]] WTN-LI **αρχη** *archē* początek [[G746]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **τελος** *telos* koniec [[G5056]] WTN-NSN **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **ων** *ōn* który jest [[G5607]] [[V-PXP-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **ερχομενος** *erchomenos* który przychodzi [[G2064]] WTV-PNP-NSM **ο** *ho* [[G3588]] [[T-NSM]] **παντοκρατωρ** *pantokratōr* Wszechmogący – Wszechwładca [[G3841]] [[N-NSM]]
###### **Ap 1,9**
 **εγω** *egō* Ja [[G1473]] WTP-1NS **ιωαννης** *iōannēs* Jan – [JHWH jest łaskawy] [[G2491]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **αδελφος** *adelfos* brat [[G80]] [[N-NSM]] **υμων** *hymōn* wasz [[G5216]] WTP-2GP **και** *kai* i [[G2532]] [[CONJ]] **συγκοινωνος** *sygkoinōnos* współuczestnik [[G4791]] [[A-NSM]] **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **θλιψει** *thlipsei* ucisku – utrapieniu [[G2347]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **βασιλεια** *basileia* Królestwie [[G932]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **υπομονη** *hypomonē* wytrwałości [[G5281]] [[N-DSF]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **εγενομην** *egenomēn* stałem się [[G1096]] WTV-2ADI-1S **εν** *en* na [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **νησω** *nēsō* wyspie [[G3520]] [[N-DSF]] **τη** *tē* [[G3588]] WTT-DSF **καλουμενη** *kaloumenē* która jest nazywana – która jest zwana [[G2564]] WTV-PPP-DSF **πατμω** *patmō* Patmos [[G3963]] [[N-DSF]] **δια** *dia* z powodu [[G1223]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **λογον** *logon* Słowa [[G3056]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **δια** *dia* przez [[G1223]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **μαρτυριαν** *martyrian* świadectwo [[G3141]] WTN-ASF **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **Ap 1,10**
 **εγενομην** *egenomēn* Stałem się [[G1096]] WTV-2ADI-1S **εν** *en* w [[G1722]] [[PREP]] **πνευματι** *pneumati* Duchu [[G4151]] WTN-DSN **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **κυριακη** *kyriakē* Pański [[G2960]] WTA-DSF **ημερα** *hēmera* dzień [[G2250]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **ηκουσα** *ēkousa* usłyszałem [[G191]] WTV-AAI-1S **οπισω** *opisō* za [[G3694]] [[ADV]] **μου** *mou* mną [[G3450]] WTP-1GS **φωνην** *fōnēn* głos [[G5456]] WTN-ASF **μεγαλην** *megalēn* wielki [[G3173]] WTA-ASF **ως** *hōs* jak [[G5613]] [[ADV]] **σαλπιγγος** *salpingos* trąby [[G4536]] [[N-GSF]]
###### **Ap 1,11**
 **λεγουσης** *legousēs* mówiący [[G3004]] WTV-PAP-GSF **εγω** *egō* Ja [[G1473]] WTP-1NS **ειμι** *eimi* jestem [[G1510]] WTV-PXI-1S **το** *to* [[G3588]] WTT-NSN **α** *ha* alfa [[G1]] WTN-LI **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **ω** *hō* omega [[G5598]] WTN-LI **ο** *ho* [[G3588]] [[T-NSM]] **πρωτος** *prōtos* pierwszy [[G4413]] [[A-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **εσχατος** *eschatos* ostatni [[G2078]] [[A-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* co [[G3739]] WTR-ASN **βλεπεις** *blepeis* widzisz [[G991]] WTV-PAI-2S **γραψον** *grapson* napisz [[G1125]] WTV-AAM-2S **εις** *eis* w [[G1519]] [[PREP]] **βιβλιον** *biblion* zwoju [[G975]] WTN-ASN **και** *kai* i [[G2532]] [[CONJ]] **πεμψον** *pempson* poślij [[G3992]] WTV-AAM-2S **ταις** *tais* [[G3588]] WTT-DPF **επτα** *hepta* siedmiu [[G2033]] WTA-NUI **εκκλησιαις** *ekklēsiais* zgromadzeniom – (społecznościom) wywołanych [[G1577]] WTN-DPF **ταις** *tais* [[G3588]] WTT-DPF **εν** *en* w [[G1722]] [[PREP]] **ασια** *asia* Azji [[G773]] [[N-DSF]] **εις** *eis* do [[G1519]] [[PREP]] **εφεσον** *efeson* Efezu [[G2181]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **εις** *eis* do [[G1519]] [[PREP]] **σμυρναν** *smyrnan* Smyrny – [mirra] [[G4667]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **εις** *eis* do [[G1519]] [[PREP]] **περγαμον** *pergamon* Pergamonu – [wieża] [[G4010]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **εις** *eis* do [[G1519]] [[PREP]] **θυατειρα** *thyateira* Tiatyry [[G2363]] WTN-APN **και** *kai* i [[G2532]] [[CONJ]] **εις** *eis* do [[G1519]] [[PREP]] **σαρδεις** *sardeis* Sardes [[G4554]] WTN-APF **και** *kai* i [[G2532]] [[CONJ]] **εις** *eis* do [[G1519]] [[PREP]] **φιλαδελφειαν** *filadelfeian* Filadelfii – [kochać braci] [[G5359]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **εις** *eis* do [[G1519]] [[PREP]] **λαοδικειαν** *laodikeian* Laodycei – [prawo ludu] [[G2993]] WTN-ASF
###### **Ap 1,12**
 **και** *kai* I [[G2532]] [[CONJ]] **επεστρεψα** *epestrepsa* odwróciłem się [[G1994]] WTV-AAI-1S **βλεπειν** *blepein* widzieć [[G991]] WTV-PAN **την** *tēn* [[G3588]] WTT-ASF **φωνην** *fōnēn* głos [[G5456]] WTN-ASF **ητις** *hētis* który [[G3748]] WTR-NSF **ελαλησεν** *elalēsen* mówił [[G2980]] [[V-AAI-3S]] **μετ** *met* ze [[G3326]] [[PREP]] **εμου** *emou* mną [[G1700]] WTP-1GS **και** *kai* i [[G2532]] [[CONJ]] **επιστρεψας** *epistrepsas* odwróciwszy się [[G1994]] WTV-AAP-NSM **ειδον** *eidon* zobaczyłem [[G1492]] WTV-2AAI-1S **επτα** *hepta* siedem [[G2033]] WTA-NUI **λυχνιας** *lychnias* świeczników – stojaków lamp [[G3087]] WTN-APF **χρυσας** *chrysas* złotych [[G5552]] WTA-APF
###### **Ap 1,13**
 **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **μεσω** *mesō* środku [[G3319]] WTA-DSN **των** *tōn* [[G3588]] WTT-GPF **επτα** *hepta* siedmiu [[G2033]] WTA-NUI **λυχνιων** *lychniōn* świeczników – stojaków lamp [[G3087]] WTN-GPF **ομοιον** *homoion* podobnego [[G3664]] WTA-ASM **υιω** *hyiō* Synowi [[G5207]] WTN-DSM **ανθρωπου** *anthrōpou* człowieka [[G444]] [[N-GSM]] **ενδεδυμενον** *endedymenon* który jest przyobleczony w – który jest odziany w [[G1746]] WTV-RMP-ASM **ποδηρη** *podērē* sięgającą stóp [[G4158]] WTA-ASM **και** *kai* i [[G2532]] [[CONJ]] **περιεζωσμενον** *periezōsmenon* który jest przepasany – który jest opasany [[G4024]] WTV-RPP-ASM **προς** *pros* na [[G4314]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPM **μαστοις** *mastois* piersiach [[G3149]] WTN-DPM **ζωνην** *zōnēn* pasem [[G2223]] WTN-ASF **χρυσην** *chrysēn* złotym [[G5552]] WTA-ASF
###### **Ap 1,14**
 **η** *hē* [[G3588]] [[T-NSF]] **δε** *de* zaś [[G1161]] [[CONJ]] **κεφαλη** *kefalē* głowa [[G2776]] [[N-NSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **αι** *hai* [[G3588]] [[T-NPF]] **τριχες** *triches* włosy [[G2359]] [[N-NPF]] **λευκαι** *leukai* białe [[G3022]] [[A-NPF]] **ωσει** *hōsei* jakby [[G5616]] [[ADV]] **εριον** *erion* wełna [[G2053]] WTN-NSN **λευκον** *leukon* biała [[G3022]] WTA-NSN **ως** *hōs* jak [[G5613]] [[ADV]] **χιων** *chiōn* śnieg [[G5510]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **οφθαλμοι** *ofthalmoi* oczy [[G3788]] WTN-NPM **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ως** *hōs* jak [[G5613]] [[ADV]] **φλοξ** *floks* płomień [[G5395]] [[N-NSF]] **πυρος** *pyros* ognia [[G4442]] [[N-GSN]]
###### **Ap 1,15**
 **και** *kai* I [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **ποδες** *podes* stopy [[G4228]] WTN-NPM **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ομοιοι** *homoioi* podobne [[G3664]] WTA-NPM **χαλκολιβανω** *chalkolibanō* kadzidłu z mosiądzu – roztopionemu mosiądzu [[G5474]] WTN-DSN **ως** *hōs* jak [[G5613]] [[ADV]] **εν** *en* w [[G1722]] [[PREP]] **καμινω** *kaminō* piecu [[G2575]] [[N-DSF]] **πεπυρωμενοι** *pepyrōmenoi* które są rozpalone – które są rozżarzone [[G4448]] WTV-RPP-NPM **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **φωνη** *fōnē* głos [[G5456]] [[N-NSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ως** *hōs* jak [[G5613]] [[ADV]] **φωνη** *fōnē* głos [[G5456]] [[N-NSF]] **υδατων** *hydatōn* wód [[G5204]] WTN-GPN **πολλων** *pollōn* wielu [[G4183]] WTA-GPN
###### **Ap 1,16**
 **και** *kai* i [[G2532]] [[CONJ]] **εχων** *echōn* mający [[G2192]] [[V-PAP-NSM]] **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **δεξια** *deksia* prawej [[G1188]] WTA-DSF **αυτου** *autou* Jego [[G846]] [[P-GSM]] **χειρι** *cheiri* ręce [[G5495]] [[N-DSF]] **αστερας** *asteras* gwiazd [[G792]] [[N-APM]] **επτα** *hepta* siedem [[G2033]] WTA-NUI **και** *kai* i [[G2532]] [[CONJ]] **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **στοματος** *stomatos* ustach [[G4750]] [[N-GSN]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ρομφαια** *romfaia* miecz [[G4501]] [[N-NSF]] **διστομος** *distomos* obosieczny [[G1366]] [[A-NSM]] **οξεια** *okseia* ostry [[G3691]] WTA-NSF **εκπορευομενη** *ekporeuomenē* wychodzący [[G1607]] WTV-PNP-NSF **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **οψις** *opsis* twarz – oblicze [[G3799]] [[N-NSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ως** *hōs* jak [[G5613]] [[ADV]] **ο** *ho* [[G3588]] [[T-NSM]] **ηλιος** *hēlios* słońce [[G2246]] [[N-NSM]] **φαινει** *fainei* świeci – ukazuje się [[G5316]] WTV-PAI-3S **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **δυναμει** *dynamei* mocy [[G1411]] [[N-DSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Ap 1,17**
 **και** *kai* I [[G2532]] [[CONJ]] **οτε** *hote* gdy [[G3753]] [[ADV]] **ειδον** *eidon* zobaczyłem [[G1492]] WTV-2AAI-1S **αυτον** *auton* Go [[G846]] WTP-ASM **επεσα** *epesa* upadłem [[G4098]] WTV-2AAI-1S **προς** *pros* do [[G4314]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **ποδας** *podas* stóp [[G4228]] [[N-APM]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ως** *hōs* jak [[G5613]] [[ADV]] **νεκρος** *nekros* martwy [[G3498]] [[A-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **επεθηκεν** *epethēken* nałożył [[G2007]] [[V-AAI-3S]] **την** *tēn* [[G3588]] WTT-ASF **δεξιαν** *deksian* prawą [[G1188]] WTA-ASF **αυτου** *autou* Jego [[G846]] [[P-GSM]] **χειρα** *cheira* rękę [[G5495]] WTN-ASF **επ** *ep* na [[G1909]] [[PREP]] **εμε** *eme* mnie [[G1691]] WTP-1AS **λεγων** *legōn* mówiąc [[G3004]] [[V-PAP-NSM]] **μοι** *moi* mi [[G3427]] WTP-1DS **μη** *mē* nie [[G3361]] [[PRT-N]] **φοβου** *fobou* bój się [[G5399]] WTV-PNM-2S **εγω** *egō* Ja [[G1473]] WTP-1NS **ειμι** *eimi* jestem [[G1510]] WTV-PXI-1S **ο** *ho* [[G3588]] [[T-NSM]] **πρωτος** *prōtos* pierwszy [[G4413]] [[A-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **εσχατος** *eschatos* ostatni [[G2078]] [[A-NSM]]
###### **Ap 1,18**
 **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **ζων** *zōn* żyjący [[G2198]] [[V-PAP-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **εγενομην** *egenomēn* stałem się [[G1096]] WTV-2ADI-1S **νεκρος** *nekros* martwy [[G3498]] [[A-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **ζων** *zōn* żyjący [[G2198]] [[V-PAP-NSM]] **ειμι** *eimi* jestem [[G1510]] WTV-PXI-1S **εις** *eis* na [[G1519]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **αιωνας** *aiōnas* wieki [[G165]] [[N-APM]] **των** *tōn* [[G3588]] WTT-GPM **αιωνων** *aiōnōn* wieków [[G165]] WTN-GPM **αμην** *amēn* amen – [zaprawdę] [[G281]] WTHEB **και** *kai* i [[G2532]] [[CONJ]] **εχω** *echō* mam [[G2192]] WTV-PAI-1S **τας** *tas* [[G3588]] WTT-APF **κλεις** *kleis* klucze [[G2807]] WTN-APF **του** *tou* [[G3588]] WTT-GSM **αδου** *hadou* piekła – Hadesu [[G86]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **του** *tou* [[G3588]] WTT-GSM **θανατου** *thanatou* śmierci [[G2288]] [[N-GSM]]
###### **Ap 1,19**
 **γραψον** *grapson* Napisz [[G1125]] WTV-AAM-2S **α** *ha* co [[G3739]] WTR-APN **ειδες** *eides* zobaczyłeś [[G1492]] WTV-2AAI-2S **και** *kai* i [[G2532]] [[CONJ]] **α** *ha* które [[G3739]] WTR-APN **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **και** *kai* i [[G2532]] [[CONJ]] **α** *ha* które [[G3739]] WTR-APN **μελλει** *mellei* jest blisko [[G3195]] WTV-PAI-3S **γινεσθαι** *ginesthai* stać się [[G1096]] WTV-PNN **μετα** *meta* po [[G3326]] [[PREP]] **ταυτα** *tauta* tych [[G5023]] WTD-APN
###### **Ap 1,20**
 **το** *to* [[G3588]] WTT-NSN **μυστηριον** *mystērion* Tajemnica [[G3466]] WTN-NSN **των** *tōn* [[G3588]] WTT-GPM **επτα** *hepta* siedmiu [[G2033]] WTA-NUI **αστερων** *asterōn* gwiazd [[G792]] WTN-GPM **ων** *ōn* które [[G3739]] WTR-GPM **ειδες** *eides* zobaczyłeś – ujrzałeś [[G1492]] WTV-2AAI-2S **επι** *epi* na [[G1909]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **δεξιας** *deksias* prawej – prawicy [[G1188]] WTA-GSF **μου** *mou* mojej [[G3450]] WTP-1GS **και** *kai* i [[G2532]] [[CONJ]] **τας** *tas* [[G3588]] WTT-APF **επτα** *hepta* siedem [[G2033]] WTA-NUI **λυχνιας** *lychnias* świeczników – stojaków lamp [[G3087]] WTN-APF **τας** *tas* [[G3588]] WTT-APF **χρυσας** *chrysas* złotych [[G5552]] WTA-APF **οι** *hoi* [[G3588]] WTT-NPM **επτα** *hepta* siedem [[G2033]] WTA-NUI **αστερες** *asteres* gwiazd [[G792]] WTN-NPM **αγγελοι** *angeloi* zwiastunowie [[G32]] WTN-NPM **των** *tōn* [[G3588]] WTT-GPF **επτα** *hepta* siedmiu [[G2033]] WTA-NUI **εκκλησιων** *ekklēsiōn* zgromadzeń – (społeczności) wywołanych [[G1577]] WTN-GPF **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **και** *kai* i [[G2532]] [[CONJ]] **αι** *hai* [[G3588]] [[T-NPF]] **επτα** *hepta* siedem [[G2033]] WTA-NUI **λυχνιαι** *lychniai* świeczników – stojaków lamp [[G3087]] [[N-NPF]] **ας** *has* które [[G3739]] WTR-APF **ειδες** *eides* zobaczyłeś [[G1492]] WTV-2AAI-2S **επτα** *hepta* siedmioma [[G2033]] WTA-NUI **εκκλησιαι** *ekklēsiai* zgromadzeniami – (społecznościami) wywołanych [[G1577]] [[N-NPF]] **εισιν** *eisin* są [[G1526]] WTV-PXI-3P
