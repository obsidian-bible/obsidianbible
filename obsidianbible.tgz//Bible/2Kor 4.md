# 2Kor 4 BT5
###### **2Kor 4,1**
 Przeto oddani posługiwaniu zleconemu nam przez miłosierdzie, nie upadamy na duchu.
###### **2Kor 4,2**
 Unikamy postępowania ukrywającego sprawy hańbiące, nie uciekamy się do żadnych podstępów ani nie fałszujemy słowa Bożego, lecz ukazywaniem prawdy poddajemy siebie samych w obliczu Boga osądowi sumienia każdego człowieka.
###### **2Kor 4,3**
 A jeśli nawet Ewangelia nasza jest ukryta, to tylko dla tych, którzy idą na zatracenie,
###### **2Kor 4,4**
 dla niewiernych, których umysły zaślepił bóg tego świata, aby nie olśnił ich blask Ewangelii chwały Chrystusa, który jest obrazem Boga.
###### **2Kor 4,5**
 Nie głosimy bowiem siebie samych, lecz Chrystusa Jezusa jako Pana, a nas – jako sługi wasze przez Jezusa.
###### **2Kor 4,6**
 Albowiem Bóg, Ten, który rozkazał ciemnościom, by zajaśniały światłem, zabłysnął w naszych sercach, by olśnić nas jasnością poznania chwały Bożej na obliczu < Jezusa > Chrystusa.
###### **2Kor 4,7**
 Przechowujemy zaś ten skarb w naczyniach glinianych, aby z Boga była owa przeogromna moc, a nie z nas.
###### **2Kor 4,8**
 Zewsząd cierpienia znosimy, lecz nie poddajemy się zwątpieniu; żyjemy w niedostatku, lecz nie rozpaczamy;
###### **2Kor 4,9**
 znosimy prześladowania, lecz nie czujemy się osamotnieni, obalają nas na ziemię, lecz nie giniemy.
###### **2Kor 4,10**
 Nosimy nieustannie w ciele naszym konanie Jezusa, aby życie Jezusa objawiało się w naszym ciele.
###### **2Kor 4,11**
 Ciągle bowiem my, którzy żyjemy, jesteśmy wydawani na śmierć z powodu Jezusa, aby życie Jezusa objawiało się w naszym śmiertelnym ciele.
###### **2Kor 4,12**
 Tak więc działa w nas śmierć, podczas gdy w was – życie.
###### **2Kor 4,13**
 A że mamy tego samego ducha wiary, według którego napisano: Uwierzyłem, dlatego przemówiłem, my także wierzymy i dlatego mówimy,
###### **2Kor 4,14**
 przekonani, że Ten, który wskrzesił Jezusa, z Jezusem przywróci życie także nam i stawi nas przed sobą razem z wami.
###### **2Kor 4,15**
 Wszystko to bowiem dla was, ażeby łaska, obfitująca we wdzięczność wielu, pomnażała się Bogu na chwałę.
###### **2Kor 4,16**
 Dlatego to nie poddajemy się zwątpieniu, chociaż bowiem niszczeje nasz człowiek zewnętrzny, to jednak ten, który jest wewnątrz, odnawia się z dnia na dzień.
###### **2Kor 4,17**
 Niewielkie bowiem utrapienia nasze obecnego czasu gotują bezmiar chwały przyszłego wieku
###### **2Kor 4,18**
 dla nas, którzy się wpatrujemy nie w to, co widzialne, lecz w to, co niewidzialne. To bowiem, co widzialne, przemija, to zaś, co niewidzialne, trwa wiecznie.
# 2Kor 4 PAU
###### **2Kor 4,1**
 Dlatego pełnimy tę posługę, którą dzięki miłosierdziu otrzymaliśmy, i nie zniechęcamy się.
###### **2Kor 4,2**
 Odrzucamy fałszywy wstyd, nie postępujemy przewrotnie i nie wypaczamy słowa Bożego, lecz jawnie głosimy prawdę i poddajemy samych siebie pod osąd każdego ludzkiego sumienia, działając w obliczu Boga.
###### **2Kor 4,3**
 Jeśli nawet nasza Ewangelia jest przed kimś zakryta, to tylko przed tymi, którzy są na drodze do zagłady,
###### **2Kor 4,4**
 gdyż bóg tego świata zaślepił ich pozbawione wiary umysły, aby nie zobaczyli blasku Ewangelii o chwale Chrystusa, który jest obrazem Boga.
###### **2Kor 4,5**
 Nie głosimy bowiem samych siebie, ale Jezusa Chrystusa Pana. Jeśli zaś chodzi o nas, to jesteśmy waszymi sługami ze względu na Jezusa.
###### **2Kor 4,6**
 Bóg, który powiedział: „Z ciemności zajaśnieje światłość”, zajaśniał w naszych sercach, aby zabłysło poznanie chwały Bożej, która jest na obliczu Jezusa Chrystusa.
###### **2Kor 4,7**
 Mamy zaś ten skarb w glinianych naczyniach, aby nie z nas, lecz z Boga była ta przeogromna moc.
###### **2Kor 4,8**
 W różny sposób jesteśmy uciskani, ale nie załamujemy się tym; jesteśmy bezradni, ale nie pogrążamy się w rozpaczy;
###### **2Kor 4,9**
 prześladują nas, ale nie zostaliśmy opuszczeni; przewracają nas, ale nie giniemy.
###### **2Kor 4,10**
 Nieustannie nosimy w ciele konanie Jezusa, aby także życie Jezusa ujawniło się w naszym ciele.
###### **2Kor 4,11**
 My, którzy żyjemy, jesteśmy nieustannie wydawani na śmierć z powodu Jezusa, aby życie Jezusa ujawniło się w naszym śmiertelnym ciele.
###### **2Kor 4,12**
 W taki sposób działa w nas śmierć, a w was życie.
###### **2Kor 4,13**
 Mamy zaś tego samego ducha wiary, o którym jest napisane: Uwierzyłem, dlatego przemówiłem. My także wierzymy i dlatego mówimy.
###### **2Kor 4,14**
 Jesteśmy przekonani, że Ten, który wskrzesił Pana Jezusa, i nas wskrzesi razem z Jezusem i postawi przed sobą razem z wami.
###### **2Kor 4,15**
 Wszystko to znosimy dla was, aby coraz większa łaska pomnażała dziękczynienie wielu na chwałę Boga.
###### **2Kor 4,16**
 Dlatego nie zniechęcamy się i chociaż nasz człowiek zewnętrzny niszczeje, to nasz człowiek wewnętrzny odnawia się każdego dnia.
###### **2Kor 4,17**
 Nasze obecne niewielkie i przemijające utrapienie prowadzi nas do niewysłowionej chwały wiecznej.
###### **2Kor 4,18**
 Nie wpatrujemy się więc w to, co widzialne, ale w to, co niewidzialne. To bowiem, co widzialne, przemija, to natomiast, co niewidzialne, trwa wiecznie.
# 2Kor 4 BP
###### **2Kor 4,1**
 Dlatego nie zniechęcamy się, skoro z miłosierdzia Bożego wypełniamy ten rodzaj posługi.
###### **2Kor 4,2**
 Unikamy rzeczy, które się wstydliwie ukrywa, a w postępowaniu nie kierujemy się chytrością i nie fałszujemy słowa Bożego. Natomiast głosząc jawnie prawdę poddajemy się w obliczu Boga ocenie każdego człowieka.
###### **2Kor 4,3**
 Jeżeli nawet w ewangelii, którą głosimy, nie wszystko jest jasne, to tylko dla tych, którzy idą na potępienie,
###### **2Kor 4,4**
 dla niewierzących, których umysły zaślepił bóg tego świata, aby nie dostrzegli światła dobrej nowiny o chwale Chrystusa, który jest obrazem Boga.
###### **2Kor 4,5**
 Nie głosimy siebie, lecz Jezusa Chrystusa jako Pana, a siebie uważamy za wasze sługi dzięki Jezusowi.
###### **2Kor 4,6**
 Albowiem Bóg, który rozkazał, aby z ciemności zabłysło światło, sam rozjaśnił nasze serca światłością poznania chwały Bożej na obliczu Chrystusa.
###### **2Kor 4,7**
 Skarb ten przechowujemy w glinianych naczyniach, po to, aby [wiedziano], że ta przeogromna moc pochodzi od Boga, a nie z nas.
###### **2Kor 4,8**
 Zewsząd doznajemy utrapień, lecz nie jesteśmy tym przytłoczeni, przeżywamy wątpliwości, ale nie rozpaczamy.
###### **2Kor 4,9**
 Znosimy prześladowania, lecz nie jesteśmy opuszczeni, obalają nas na ziemię, ale nie giniemy.
###### **2Kor 4,10**
 Zawsze nosimy w sobie umieranie Jezusa, aby i życie Jezusa pokazało się w nas.
###### **2Kor 4,11**
 Nieustannie bowiem my, którzy żyjemy, jesteśmy wydawani na śmierć z powodu Jezusa, aby i życie Jezusa pokazało się w naszym śmiertelnym ciele.
###### **2Kor 4,12**
 Tak więc w nas działa śmierć, a w was życie.
###### **2Kor 4,13**
 Mamy tego samego ducha wiary, o którym napisano: "Uwierzyłem, dlatego przemówiłem". My również wierzymy i dlatego przemawiamy.
###### **2Kor 4,14**
 Wiemy przecież, że Ten, który wskrzesił Pana Jezusa, i nas razem z Jezusem wskrzesi i wraz z wami postawi przed swoim trybunałem.
###### **2Kor 4,15**
 Wszystko to czynimy dla was, aby łaska pomnożona na skutek wzrastającej liczby wiernych spotęgowała dziękczynienie na chwałę Bożą.
###### **2Kor 4,16**
 Dlatego nie zniechęcamy się. Chociaż nasze doczesne ludzkie ciało ulega zniszczeniu, to jednak życie wewnętrzne odnawia się z dnia na dzień.
###### **2Kor 4,17**
 Lekkie bowiem utrapienia, które teraz znosimy, przyniosą w wieczności bardzo wielką chwałę nam,
###### **2Kor 4,18**
 którzy wpatrujemy się nie w to, co widzialne, lecz w to, co niewidzialne. To, co widzialne, trwa tylko do czasu, a to, co niewidzialne, trwa wiecznie.
# 2Kor 4 BR
###### **2Kor 4,1**
 Przeto oddani posługiwaniu zleconemu nam przez miłosierdzie, nie upadamy na duchu.
###### **2Kor 4,2**
 Unikamy postępowania ukrywającego sprawy hańbiące, nie uciekamy się do żadnych podstępów ani nie fałszujemy słowa Bożego, lecz okazywaniem prawdy przedstawiamy siebie samych w obliczu Boga osądowi sumienia każdego człowieka.
###### **2Kor 4,3**
 A jeśli nawet Ewangelia nasza jest ukryta, to tylko dla tych, którzy idą na zatracenie,
###### **2Kor 4,4**
 dla niewiernych, których umysły zaślepił bóg tego świata, aby nie olśnił ich blask Ewangelii chwały Chrystusa, który jest obrazem Boga.
###### **2Kor 4,5**
 Nie głosimy bowiem siebie samych, lecz Chrystusa Jezusa jako Pana, a nas - jako sługi wasze przez Jezusa.
###### **2Kor 4,6**
 Albowiem Bóg, Ten, który rozkazał ciemnościom, by zajaśniały światłem, zabłysnął w naszych sercach, by olśnić nas jasnością poznania chwały Bożej na obliczu Chrystusa.
###### **2Kor 4,7**
 Przechowujemy zaś ten skarb w naczyniach glinianych, aby z Boga była owa przeogromna moc, a nie z nas.
###### **2Kor 4,8**
 Zewsząd cierpienia znosimy, lecz nie poddajemy się zwątpieniu; żyjemy w niedostatku, lecz nie rozpaczamy;
###### **2Kor 4,9**
 znosimy prześladowania, lecz nie czujemy się osamotnieni; obalają nas na ziemię, lecz nie giniemy.
###### **2Kor 4,10**
 Nosimy nieustannie w ciele naszym konanie Jezusa, aby życie Jezusa objawiało się w naszym ciele.
###### **2Kor 4,11**
 Ciągle bowiem jesteśmy wydawani na śmierć z powodu Jezusa, aby życie Jezusa było widoczne w naszym śmiertelnym ciele.
###### **2Kor 4,12**
 Tak więc działa w nas śmierć, podczas gdy w was - życie.
###### **2Kor 4,13**
 Cieszę się przeto owym duchem wiary, wedle którego napisano: Uwierzyłem, dlatego przemówiłem; my także wierzymy i dlatego mówimy,
###### **2Kor 4,14**
 przekonani, że Ten, który wskrzesił Jezusa, z Jezusem przywróci życie także nam i stawi nas przed sobą razem z wami.
###### **2Kor 4,15**
 Wszystko to bowiem dla was, ażeby łaska, obfitująca we wdzięczność wielu, pomnażała się Bogu na chwałę.
###### **2Kor 4,16**
 Dlatego to nie poddajemy się zwątpieniu, chociaż bowiem niszczeje nasz człowiek zewnętrzny, to jednak ten, który jest wewnątrz, odnawia się z dnia na dzień.
###### **2Kor 4,17**
 Niewielkie bowiem utrapienia nasze obecnego czasu gotują bezmiar chwały przyszłego wieku
###### **2Kor 4,18**
 dla nas, którzy się wpatrujemy nie w to, co widzialne, lecz w to, co niewidzialne. To bowiem, co widzialne, przemija, to zaś, co niewidzialne, trwa wiecznie.
# 2Kor 4 WUJ
###### **2Kor 4,1**
 Dla tego mając usługowanie, wedle tego jakośmy otrzymali miłosierdzie, nie ustawamy,
###### **2Kor 4,2**
 Ale odrzucamy pokrytą sromotę, nie chodząc w chytrości, ani fałszując słowa Bożego: ale okazaniem prawdy zalecając się samych do wszelkiego sumnienia ludzi przed Bogiem.
###### **2Kor 4,3**
 A jeśli też jest zakryta Ewangelia nasza, jest zakryta w tych, którzy giną,
###### **2Kor 4,4**
 W których Bóg świata tego oślepił zmysły niewiernych, aby im nie świeciło oświecenie Ewanieljej chwały Chrystusowej, który jest obrazem Boga.
###### **2Kor 4,5**
 Bo nie sami siebie opowiadamy, ale Jezusa Chrystusa Pana naszego: a nas sługami waszemi przez Jezusa.
###### **2Kor 4,6**
 Abowiem Bóg, który rzekł, aby z ciemności światłość zaświeciła, ten zaświecił w sercach naszych, ku oświeceniu wiadomości jasności Bożej, w obliczu Jezusa Chrystusa.
###### **2Kor 4,7**
 A mamy ten skarb w naczyniach glinianych: aby wywyższenie było mocy Bożej, a nie z nas.
###### **2Kor 4,8**
 We wszystkiem utrapienie cierpiemy, ale nie jesteśmy ściśnieni: ubożejemy, ale nie bywamy zubożeni:
###### **2Kor 4,9**
 Prześladowanie cierpiemy, ale nie bywamy opuszczeni: bywamy powaleni, ale nie giniemy:
###### **2Kor 4,10**
 Zawsze umartwienie Jezusa z sobą nosząc w ciele naszem: aby i żywot Jezusów w naszych cielech był okazany.
###### **2Kor 4,11**
 Abowiem my, którzy żywiemy, zawsze bywamy wydani na śmierć dla Jezusa: aby i żywot Jezusów był okazan w śmiertelnem ciele naszem.
###### **2Kor 4,12**
 A tak w nas okazuje śmierć skutek swój, a żywot w was.
###### **2Kor 4,13**
 Lecz mając tegoż Ducha wiary, jako jest napisano: Uwierzyłem, przetożem mówił: i my wierzymy, dla czego mówiemy:
###### **2Kor 4,14**
 Wiedząc, iż który wzbudził Jezusa, i nas wzbudzi z Jezusem, i postawi z wami.
###### **2Kor 4,15**
 Abowiem wszystko dla was: aby łaska obfitująca, w dziękczynieniu przez wielu obfitowała ku chwale Bożej.
###### **2Kor 4,16**
 Dla tego nie ustawamy: ale chociaż ten, który zewnątrz jest nasz człowiek, psuje się: wszakże ten, który wewnątrz jest, odnawia się ode dnia do dnia.
###### **2Kor 4,17**
 Abowiem to, które teraz jest prędziuczko przemijające i lekkie nasze utrapienie, nader na wysokości wagę chwały wiekuistą w nas sprawuje,
###### **2Kor 4,18**
 Gdyż my nie upatrujemy tego co widzieć, ale czego niewidzieć. Abowiem rzeczy, które widziemy, są doczesne: a których nie widziemy, są wieczne.
# 2Kor 4 STERN
###### **2Kor 4,1**
 Bóg okazał nam takie miłosierdzie, że nie tracimy odwagi, wykonując dzieło, jakie nam powierzył.
###### **2Kor 4,2**
 I nie przystajemy na uciekanie się do haniebnych, podstępnych sposobów, na zwodzenie i przekręcanie orędzia Bożego. Przeciwnie, nie pozostawiając wątpliwości co do tego, jaka jest prawda, polecamy siebie sumieniu każdego przed obliczem Boga.
###### **2Kor 4,3**
 Jeśli zatem nasza Dobra Nowina rzeczywiście jest zakryta, to jest zakryta tylko przed tymi, którzy giną.
###### **2Kor 4,4**
 Nie dochodzą oni do ufności, bo bóg 'olam haze zaślepił ich umysły, aby nie mogli ujrzeć światłości jaśniejącej z Dobrej Nowiny o chwale Mesjasza, który jest obrazem Boga.
###### **2Kor 4,5**
 Głosimy bowiem nie siebie samych, ale Mesjasza Jeszuę jako Pana, siebie zaś jako waszych niewolników ze względu na Jeszuę.
###### **2Kor 4,6**
 Bo ten Bóg, który niegdyś rzekł: "Niech światłość jaśnieje z ciemności", sprawił, że światłość Jego zajaśniała w naszych sercach, światłość poznania chwały Bożej jaśniejącej na obliczu Mesjasza Jeszui.
###### **2Kor 4,7**
 My jednak mamy ten skarb w glinianych naczyniach, aby jasne było, że bezmierna ta moc pochodzi od Boga, a nie od nas.
###### **2Kor 4,8**
 Doznajemy wszelakiego ucisku, ale nie jesteśmy zdruzgotani; udręczeni, lecz nie zrozpaczeni;
###### **2Kor 4,9**
 prześladowani, lecz nie opuszczeni; powaleni, lecz nie zniszczeni.
###### **2Kor 4,10**
 Zawsze nosimy w naszym ciele konanie Jeszui, aby życie Jeszui również objawiło się w naszym ciele.
###### **2Kor 4,11**
 Bo my, którzy żyjemy, zawsze jesteśmy wydawani na śmierć ze względu na Jeszuę, ażeby życie Jeszui mogło się objawić w naszych śmiertelnych ciałach.
###### **2Kor 4,12**
 I tak śmierć działa w nas, podczas gdy w was - życie.
###### **2Kor 4,13**
 Jak powiada Tanach: "Zaufałem, dlatego przemówiłem". Ponieważ mamy tego samego Ducha, który uzdolnią nas do ufania, ufamy też i dlatego przemawiamy;
###### **2Kor 4,14**
 wiemy bowiem, że Ten, który wskrzesił Pana Jeszuę, wskrzesi też nas wraz z Jeszuą i wprowadzi nas wraz z wami przed swoje oblicze.
###### **2Kor 4,15**
 Wszystko to ze względu na was, aby dzięki łasce płynącej ku coraz większej liczbie ludzi dziękczynienie obfitowało i przynosiło chwałę Bogu.
###### **2Kor 4,16**
 Dlatego nie tracimy odwagi. Choć nasze zewnętrzne ja zmierza ku zniszczeniu, nasze wewnętrzne ja codziennie się odnawia.
###### **2Kor 4,17**
 Bo te nieuciążliwe i chwilowe uciski prowadzą nas ku wiekuistej chwale o nieopisanej wspaniałości.
###### **2Kor 4,18**
 Skupiamy się nie na tym, co widoczne, ale na tym, co niewidoczne, bo rzeczy widoczne są doczesne, ale rzeczy niewidoczne są wieczne.
# 2Kor 4 TRO
###### **2Kor 4,1**
 **δια** *dia* Przez [[G1223]] [[PREP]] **τουτο** *touto* to [[G5124]] WTD-ASN **εχοντες** *echontes* mając [[G2192]] WTV-PAP-NPM **την** *tēn* [[G3588]] WTT-ASF **διακονιαν** *diakonian* posługę – służbę [[G1248]] WTN-ASF **ταυτην** *tautēn* tę [[G3778]] WTD-ASF **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **ηλεηθημεν** *ēleēthēmen* dostąpiliśmy litości – dostąpiliśmy miłosierdzia [[G1653]] WTV-API-1P **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εκκακουμεν** *ekkakoumen* zniechęcamy się – słabniemy [[G1573]] WTV-PAI-1P
###### **2Kor 4,2**
 **αλλ** *all* ale [[G235]] [[CONJ]] **απειπαμεθα** *apeipametha* wyrzekamy się [[G550]] WTV-2AMI-1P **τα** *ta* [[G3588]] WTT-APN **κρυπτα** *krypta* ukrytych [[G2927]] WTA-APN **της** *tēs* [[G3588]] [[T-GSF]] **αισχυνης** *aischynēs* wstydu – hańby [[G152]] [[N-GSF]] **μη** *mē* nie [[G3361]] [[PRT-N]] **περιπατουντες** *peripatountes* chodząc [[G4043]] WTV-PAP-NPM **εν** *en* w [[G1722]] [[PREP]] **πανουργια** *panourgia* przebiegłości – przewrotności [[G3834]] [[N-DSF]] **μηδε** *mēde* ani [[G3366]] [[CONJ]] **δολουντες** *dolountes* fałszując – podrabiając [[G1389]] WTV-PAP-NPM **τον** *ton* [[G3588]] [[T-ASM]] **λογον** *logon* Słowo [[G3056]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **αλλα** *alla* ale [[G235]] [[CONJ]] **τη** *tē* [[G3588]] WTT-DSF **φανερωσει** *fanerōsei* ukazanie się – uwidocznienie [[G5321]] [[N-DSF]] **της** *tēs* [[G3588]] [[T-GSF]] **αληθειας** *alētheias* prawdy [[G225]] [[N-GSF]] **συνιστωντες** *synistōntes* stawiając – polecając [[G4921]] WTV-PAP-NPM **εαυτους** *heautous* siebie samych [[G1438]] WTF-3APM **προς** *pros* ku [[G4314]] [[PREP]] **πασαν** *pasan* całemu [[G3956]] WTA-ASF **συνειδησιν** *syneidēsin* sumieniu [[G4893]] WTN-ASF **ανθρωπων** *anthrōpōn* ludzi [[G444]] WTN-GPM **ενωπιον** *enōpion* wobec [[G1799]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **2Kor 4,3**
 **ει** *ei* Jeśli [[G1487]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **κεκαλυμμενον** *kekalymmenon* która jest zakryta – która jest zasłonięta [[G2572]] WTV-RPP-NSN **το** *to* [[G3588]] WTT-NSN **ευαγγελιον** *euangelion* dobra nowina [[G2098]] WTN-NSN **ημων** *hēmōn* nasza [[G2257]] WTP-1GP **εν** *en* na [[G1722]] [[PREP]] **τοις** *tois* (tych) [[G3588]] WTT-DPM **απολλυμενοις** *apollymenois* którzy giną [[G622]] WTV-PEP-DPM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **κεκαλυμμενον** *kekalymmenon* która jest zakryta – która jest zasłonięta [[G2572]] WTV-RPP-NSN
###### **2Kor 4,4**
 **εν** *en* w [[G1722]] [[PREP]] **οις** *hois* których [[G3739]] WTR-DPM **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* bóg [[G2316]] [[N-NSM]] **του** *tou* [[G3588]] WTT-GSM **αιωνος** *aiōnos* wieku [[G165]] [[N-GSM]] **τουτου** *toutou* tego [[G5127]] WTD-GSM **ετυφλωσεν** *etyflōsen* zaślepił [[G5186]] [[V-AAI-3S]] **τα** *ta* [[G3588]] WTT-APN **νοηματα** *noēmata* myśli – pomyśleń [[G3540]] WTN-APN **των** *tōn* [[G3588]] WTT-GPM **απιστων** *apistōn* niewierzących [[G571]] WTA-GPM **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **μη** *mē* nie [[G3361]] [[PRT-N]] **αυγασαι** *augasai* świecić [[G826]] [[V-AAN]] **αυτοις** *autois* im [[G846]] WTP-DPM **τον** *ton* [[G3588]] [[T-ASM]] **φωτισμον** *fōtismon* światło [[G5462]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSN **ευαγγελιου** *euangeliou* dobrej nowiny [[G2098]] [[N-GSN]] **της** *tēs* [[G3588]] [[T-GSF]] **δοξης** *doksēs* chwały [[G1391]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **ος** *hos* który [[G3739]] WTR-NSM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **εικων** *eikōn* obraz [[G1504]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **2Kor 4,5**
 **ου** *ou* Nie [[G3756]] [[PRT-N]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εαυτους** *heautous* siebie samych [[G1438]] WTF-3APM **κηρυσσομεν** *kēryssomen* głosimy [[G2784]] WTV-PAI-1P **αλλα** *alla* ale [[G235]] [[CONJ]] **χριστον** *christon* Pomazańca [[G5547]] [[N-ASM]] **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]] **κυριον** *kyrion* Pana [[G2962]] [[N-ASM]] **εαυτους** *heautous* siebie samych [[G1438]] WTF-3APM **δε** *de* zaś [[G1161]] [[CONJ]] **δουλους** *doulous* (jako) niewolników – (jako) sługi [[G1401]] [[N-APM]] **υμων** *hymōn* waszych [[G5216]] WTP-2GP **δια** *dia* przez [[G1223]] [[PREP]] **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]]
###### **2Kor 4,6**
 **οτι** *hoti* Bowiem [[G3754]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **ειπων** *eipōn* powiedziawszy [[G2036]] WTV-2AAP-NSM **εκ** *ek* z [[G1537]] [[PREP]] **σκοτους** *skotous* ciemności [[G4655]] [[N-GSN]] **φως** *fōs* światło [[G5457]] WTN-ASN **λαμψαι** *lampsai* zaświecić – zajaśnieć [[G2989]] [[V-AAN]] **ος** *hos* który [[G3739]] WTR-NSM **ελαμψεν** *elampsen* zaświecił – zajaśniał [[G2989]] [[V-AAI-3S]] **εν** *en* w [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **καρδιαις** *kardiais* sercach [[G2588]] WTN-DPF **ημων** *hēmōn* naszych [[G2257]] WTP-1GP **προς** *pros* ku [[G4314]] [[PREP]] **φωτισμον** *fōtismon* światłu [[G5462]] [[N-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **γνωσεως** *gnōseōs* poznania [[G1108]] [[N-GSF]] **της** *tēs* [[G3588]] [[T-GSF]] **δοξης** *doksēs* chwały [[G1391]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εν** *en* w [[G1722]] [[PREP]] **προσωπω** *prosōpō* obliczu – twarzy [[G4383]] WTN-DSN **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **2Kor 4,7**
 **εχομεν** *echomen* Mamy [[G2192]] WTV-PAI-1P **δε** *de* zaś [[G1161]] [[CONJ]] **τον** *ton* [[G3588]] [[T-ASM]] **θησαυρον** *thēsauron* skarb [[G2344]] [[N-ASM]] **τουτον** *touton* ten [[G5126]] WTD-ASM **εν** *en* w [[G1722]] [[PREP]] **οστρακινοις** *ostrakinois* glinianych [[G3749]] WTA-DPN **σκευεσιν** *skeuesin* naczyniach [[G4632]] WTN-DPN **ινα** *hina* aby [[G2443]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **υπερβολη** *hyperbolē* nadmiar [[G5236]] [[N-NSF]] **της** *tēs* [[G3588]] [[T-GSF]] **δυναμεως** *dynameōs* mocy [[G1411]] [[N-GSF]] **η** *ē* byłby [[G5600]] WTV-PXS-3S **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **και** *kai* a [[G2532]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **εξ** *eks* z [[G1537]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP
###### **2Kor 4,8**
 **εν** *en* We [[G1722]] [[PREP]] **παντι** *panti* wszystkim [[G3956]] WTA-DSM **θλιβομενοι** *thlibomenoi* którzy są uciskani – którzy są trapieni [[G2346]] WTV-PPP-NPM **αλλ** *all* ale [[G235]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **στενοχωρουμενοι** *stenochōroumenoi* którzy są przytłoczeni – którzy są ściskani [[G4729]] WTV-PPP-NPM **απορουμενοι** *aporoumenoi* będąc zakłopotani – będąc w niepewności [[G639]] WTV-PMP-NPM **αλλ** *all* ale [[G235]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εξαπορουμενοι** *eksaporoumenoi* którzy są zrozpaczeni – którzy są wyzbyci wyjścia [[G1820]] WTV-PNP-NPM
###### **2Kor 4,9**
 **διωκομενοι** *diōkomenoi* Którzy są prześladowani – Którzy są ścigani [[G1377]] WTV-PPP-NPM **αλλ** *all* ale [[G235]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εγκαταλειπομενοι** *egkataleipomenoi* którzy są opuszczeni – którzy są pozostawieni w tyle [[G1459]] WTV-PPP-NPM **καταβαλλομενοι** *kataballomenoi* którzy są powaleni – którzy są obaleni [[G2598]] WTV-PPP-NPM **αλλ** *all* ale [[G235]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **απολλυμενοι** *apollymenoi* którzy giną [[G622]] WTV-PEP-NPM
###### **2Kor 4,10**
 **παντοτε** *pantote* zawsze – każdej chwili [[G3842]] [[ADV]] **την** *tēn* [[G3588]] WTT-ASF **νεκρωσιν** *nekrōsin* śmierć – umartwienie [[G3500]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **σωματι** *sōmati* ciele [[G4983]] WTN-DSN **περιφεροντες** *periferontes* noszący – obnoszący [[G4064]] WTV-PAP-NPM **ινα** *hina* aby [[G2443]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **ζωη** *zōē* życie [[G2222]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSM **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **σωματι** *sōmati* ciele [[G4983]] WTN-DSN **ημων** *hēmōn* naszym [[G2257]] WTP-1GP **φανερωθη** *fanerōthē* zostałoby ujawnione – zostałoby uczynione widocznym [[G5319]] WTV-APS-3S
###### **2Kor 4,11**
 **αει** *aei* Zawsze [[G104]] [[ADV]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ημεις** *hēmeis* my [[G2249]] WTP-1NP **οι** *hoi* [[G3588]] WTT-NPM **ζωντες** *zōntes* żyjący [[G2198]] WTV-PAP-NPM **εις** *eis* na [[G1519]] [[PREP]] **θανατον** *thanaton* śmierć [[G2288]] [[N-ASM]] **παραδιδομεθα** *paradidometha* jesteśmy wydawani [[G3860]] WTV-PPI-1P **δια** *dia* z powodu [[G1223]] [[PREP]] **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **ζωη** *zōē* życie [[G2222]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSM **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **φανερωθη** *fanerōthē* zostałoby objawione – zostałoby uczynione widocznym [[G5319]] WTV-APS-3S **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **θνητη** *thnētē* śmiertelnym – umieralnym [[G2349]] WTA-DSF **σαρκι** *sarki* ciele [[G4561]] [[N-DSF]] **ημων** *hēmōn* naszym [[G2257]] WTP-1GP
###### **2Kor 4,12**
 **ωστε** *hōste* Tak, że [[G5620]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **θανατος** *thanatos* śmierć [[G2288]] [[N-NSM]] **εν** *en* w [[G1722]] [[PREP]] **ημιν** *hēmin* nas [[G2254]] WTP-1DP **ενεργειται** *energeitai* działa [[G1754]] WTV-PMI-3S **η** *hē* [[G3588]] [[T-NSF]] **δε** *de* zaś [[G1161]] [[CONJ]] **ζωη** *zōē* życie [[G2222]] [[N-NSF]] **εν** *en* w [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP
###### **2Kor 4,13**
 **εχοντες** *echontes* Mając [[G2192]] WTV-PAP-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **το** *to* (tego) [[G3588]] WTT-ASN **αυτο** *auto* samego [[G846]] WTP-ASN **πνευμα** *pneuma* ducha [[G4151]] WTN-ASN **της** *tēs* [[G3588]] [[T-GSF]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **κατα** *kata* według [[G2596]] [[PREP]] **το** *to* (tego) [[G3588]] WTT-ASN **γεγραμμενον** *gegrammenon* co jest napisane [[G1125]] WTV-RPP-ASN **επιστευσα** *episteusa* uwierzyłem [[G4100]] WTV-AAI-1S **διο** *dio* dlatego [[G1352]] [[CONJ]] **ελαλησα** *elalēsa* mówiłem [[G2980]] WTV-AAI-1S **και** *kai* i [[G2532]] [[CONJ]] **ημεις** *hēmeis* my [[G2249]] WTP-1NP **πιστευομεν** *pisteuomen* wierzymy [[G4100]] WTV-PAI-1P **διο** *dio* dlatego [[G1352]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **λαλουμεν** *laloumen* mówimy [[G2980]] WTV-PAI-1P
###### **2Kor 4,14**
 **ειδοτες** *eidotes* wiedząc [[G1492]] WTV-RAP-NPM **οτι** *hoti* że [[G3754]] [[CONJ]] **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **εγειρας** *egeiras* który wzbudził – który podniósł [[G1453]] WTV-AAP-NSM **τον** *ton* [[G3588]] [[T-ASM]] **κυριον** *kyrion* Pana [[G2962]] [[N-ASM]] **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **δια** *dia* przez [[G1223]] [[PREP]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **εγερει** *egerei* wzbudzi – podniesie [[G1453]] WTV-FAI-3S **και** *kai* i [[G2532]] [[CONJ]] **παραστησει** *parastēsei* postawi [[G3936]] WTV-FAI-3S **συν** *syn* razem z [[G4862]] [[PREP]] **υμιν** *hymin* wami [[G5213]] WTP-2DP
###### **2Kor 4,15**
 **τα** *ta* [[G3588]] WTT-NPN **γαρ** *gar* Bowiem [[G1063]] [[CONJ]] **παντα** *panta* wszystkie [[G3956]] WTA-NPN **δι** *di* ze względu na – przez [[G1223]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **ινα** *hina* aby [[G2443]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **χαρις** *charis* łaska [[G5485]] [[N-NSF]] **πλεονασασα** *pleonasasa* zaobfitowawszy [[G4121]] WTV-AAP-NSF **δια** *dia* ze względu na – dla [[G1223]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **πλειονων** *pleionōn* większe – coraz liczniejsze [[G4119]] WTA-GPN-C **την** *tēn* [[G3588]] WTT-ASF **ευχαριστιαν** *eucharistian* dziękczynienie – wdzięczność [[G2169]] WTN-ASF **περισσευση** *perisseusē* obfitowałoby [[G4052]] WTV-AAS-3S **εις** *eis* ku [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **δοξαν** *doksan* chwale [[G1391]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **2Kor 4,16**
 **διο** *dio* Dlatego [[G1352]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εκκακουμεν** *ekkakoumen* zniechęcamy się – słabniemy [[G1573]] WTV-PAI-1P **αλλ** *all* ale [[G235]] [[CONJ]] **ει** *ei* jeśli [[G1487]] WTCOND **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* (ten) [[G3588]] [[T-NSM]] **εξω** *eksō* z zewnątrz [[G1854]] [[ADV]] **ημων** *hēmōn* nasz [[G2257]] WTP-1GP **ανθρωπος** *anthrōpos* człowiek [[G444]] [[N-NSM]] **διαφθειρεται** *diaftheiretai* jest niszczony – jest rujnowany [[G1311]] WTV-PPI-3S **αλλ** *all* ale [[G235]] [[CONJ]] **ο** *ho* (ten) [[G3588]] [[T-NSM]] **εσωθεν** *esōthen* wewnętrzny [[G2081]] [[ADV]] **ανακαινουται** *anakainoutai* jest odnawiany – jest przywracany [[G341]] WTV-PPI-3S **ημερα** *hēmera* dniem [[G2250]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **ημερα** *hēmera* dniem [[G2250]] [[N-DSF]]
###### **2Kor 4,17**
 **το** *to* [[G3588]] WTT-NSN **γαρ** *gar* Bowiem [[G1063]] [[CONJ]] **παραυτικα** *parautika* chwilowy – szybki [[G3910]] [[ADV]] **ελαφρον** *elafron* lekki [[G1645]] WTA-NSN **της** *tēs* [[G3588]] [[T-GSF]] **θλιψεως** *thlipseōs* ucisk – utrapienie [[G2347]] [[N-GSF]] **ημων** *hēmōn* nasz [[G2257]] WTP-1GP **καθ** *kath* w [[G2596]] [[PREP]] **υπερβολην** *hyperbolēn* nadmiarze [[G5236]] WTN-ASF **εις** *eis* ku [[G1519]] [[PREP]] **υπερβολην** *hyperbolēn* nadmiarowi [[G5236]] WTN-ASF **αιωνιον** *aiōnion* wieczny [[G166]] WTA-ASN **βαρος** *baros* ciężar [[G922]] WTN-ASN **δοξης** *doksēs* chwały [[G1391]] [[N-GSF]] **κατεργαζεται** *katergazetai* sprawia [[G2716]] WTV-PNI-3S **ημιν** *hēmin* nam [[G2254]] WTP-1DP
###### **2Kor 4,18**
 **μη** *mē* Nie [[G3361]] [[PRT-N]] **σκοπουντων** *skopountōn* bacząc – przyglądając się [[G4648]] WTV-PAP-GPM **ημων** *hēmōn* nam [[G2257]] WTP-1GP **τα** *ta* (tym) [[G3588]] WTT-APN **βλεπομενα** *blepomena* które są widzialne – które są obserwowane [[G991]] WTV-PPP-APN **αλλα** *alla* ale [[G235]] [[CONJ]] **τα** *ta* (tym) [[G3588]] WTT-APN **μη** *mē* nie [[G3361]] [[PRT-N]] **βλεπομενα** *blepomena* które są widzialne – które są obserwowane [[G991]] WTV-PPP-APN **τα** *ta* (te) [[G3588]] WTT-NPN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **βλεπομενα** *blepomena* które są widzialne – które są obserwowane [[G991]] WTV-PPP-NPN **προσκαιρα** *proskaira* chwilowe [[G4340]] WTA-NPN **τα** *ta* (te) [[G3588]] WTT-NPN **δε** *de* zaś [[G1161]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **βλεπομενα** *blepomena* które są widzialne – które są obserwowane [[G991]] WTV-PPP-NPN **αιωνια** *aiōnia* wieczne [[G166]] WTA-NPN
