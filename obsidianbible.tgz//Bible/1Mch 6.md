###### **1Mch 6,1**
 W czasie swojej wyprawy po górnej krainie król Antioch dowiedział się, że w Persji, w Elimais, jest miasto sławne z bogactwa, ze srebra i złota,
###### **1Mch 6,2**
 że jest tam nadzwyczaj bogata świątynia, a w niej złote hełmy, pancerze i zbroja, jaką pozostawił tam król macedoński Aleksander, syn Filipa, który panował najpierw nad Grekami.
###### **1Mch 6,3**
 Udał się więc tam, usiłował zdobyć miasto i złupić je, to mu się jednak nie powiodło, gdyż mieszkańcy miasta poznali jego zamiary.
###### **1Mch 6,4**
 Stanęli do walki przeciwko niemu, a on musiał się wycofać. Z wielkim smutkiem powrócił stamtąd i udał się do Babilonu.
###### **1Mch 6,5**
 Do Persji przybył do niego jakiś posłaniec z wiadomością, że pobito wojska, które były wysłane do ziemi judzkiej;
###### **1Mch 6,6**
 przede wszystkim wyruszył Lizjasz na czele ogromnego wojska i został przez nich pobity; oni zaś stali się naprawdę mocni dzięki broni, wojsku, a także dzięki wielkim łupom, które zabrali pobitemu wojsku;
###### **1Mch 6,7**
 zburzyli ohydę, którą wybudowano na ołtarzu w Jerozolimie, świątynię dokoła otoczyli wysokimi murami jak poprzednio, a także jego miasto, Bet-Sur.
###### **1Mch 6,8**
 Gdy król usłyszał o tych wypadkach, zdumiał się i przeraził do tego stopnia, że padł na łoże i ze smutku się rozchorował, bo nie tak się stało, jak sobie życzył.
###### **1Mch 6,9**
 Przez wiele dni tam przebywał, gdyż przyszedł na niego ciężki smutek i nawet pomyślał, że umrze.
###### **1Mch 6,10**
 Przywołał więc wszystkich swoich przyjaciół i powiedział do nich: «***Sen odszedł od moich oczu, a troska gniecie me serce;***
###### **1Mch 6,11**
 ***powiedziałem więc w swoim sercu: Doszedłem do tak wielkiej udręki i niepewności, w jakiej obecnie się znajduję, a przecież w używaniu władzy byłem łaskawy i miłosierny.***
###### **1Mch 6,12**
 ***Teraz jednak przypominam sobie całe zło, którego dopuściłem się w Jerozolimie. Zabrałem bowiem wszystkie srebrne i złote naczynia, które tam się znajdowały, i bez przyczyny wydałem rozkaz, aby wytępić wszystkich mieszkańców ziemi judzkiej.***
###### **1Mch 6,13**
 ***Wiem, że dlatego właśnie spotkało mnie to nieszczęście, i oto od wielkiego smutku ginę na obcej ziemi***».
###### **1Mch 6,14**
 Wtedy przywołał Filipa, jednego ze swych przyjaciół, i ustanowił go zarządcą nad całym swoim królestwem.
###### **1Mch 6,15**
 Potem wręczył mu diadem, płaszcz swój i sygnet, aby wychował jego syna, Antiocha, i wyuczył go tak, aby umiał rządzić.
###### **1Mch 6,16**
 Tam też król Antioch zakończył życie w sto czterdziestym dziewiątym roku.
###### **1Mch 6,17**
 Gdy Lizjasz dowiedział się, że król zakończył życie, ustanowił królem jego syna, Antiocha, którego wychowywał od samej młodości. Nadał mu też przydomek Eupator.
###### **1Mch 6,18**
 Ci, którzy przebywali na zamku, robili wokoło świątyni zasadzki na Izraela. Na każdym kroku wyrządzali im krzywdy, a wspomagali pogan.
###### **1Mch 6,19**
 Juda więc postanowił ich wytępić i zwołał cały lud, aby dokonać przeciw nim oblężenia.
###### **1Mch 6,20**
 Zeszli się wszyscy razem i rozpoczęli oblężenie jego w sto pięćdziesiątym roku. Sprowadzono też kusze i machiny oblężnicze.
###### **1Mch 6,21**
 Ale spomiędzy oblężonych wydostało się kilku, a przystali do nich niektórzy bezbożni Izraelici,
###### **1Mch 6,22**
 i poszli do króla, mówiąc: «***Ile jeszcze czasu upłynie, nim wydasz wyrok i pomścisz naszych braci?***
###### **1Mch 6,23**
 ***Twojemu ojcu chętnie służyliśmy, wykonywaliśmy jego rozkazy i postępowaliśmy zgodnie z jego poleceniami.***
###### **1Mch 6,24**
 ***Dlatego oblężono nas na zamku, dlatego też synowie narodu naszego stali się wrogami dla nas. Ponadto mordowali każdego z naszych, kogo schwytali, i zrabowali nasze posiadłości.***
###### **1Mch 6,25**
 ***Wyciągnęli ręce nie tylko przeciwko nam, ale także przeciwko wszystkim okolicznym krainom.***
###### **1Mch 6,26**
 ***A oto dzisiaj oblegają zamek w Jeruzalem, aby go zdobyć. Obwarowali nawet świątynię i Bet-Sur.***
###### **1Mch 6,27**
 ***Jeżeli ze swej strony nie uprzedzisz ich jak najprędzej, to jeszcze gorszych rzeczy się dopuszczą i nie będziesz już mógł ich powstrzymać***».
###### **1Mch 6,28**
 Gdy król to usłyszał, rozgniewał się i zwołał na naradę wszystkich swoich przyjaciół, wodzów swego [pieszego] wojska i dowodzących konnicą.
###### **1Mch 6,29**
 Z innych państw i z wysp zamorskich przybywali do niego najemni żołnierze,
###### **1Mch 6,30**
 a liczba jego wojska wynosiła sto tysięcy piechoty, dwadzieścia tysięcy konnicy i trzydzieści dwa słonie wyćwiczone w walce.
###### **1Mch 6,31**
 Przeszli oni przez Idumeę i koło Bet-Sur rozłożyli się obozem. Przez wiele dni walczyli i budowali machiny oblężnicze, ale [obrońcy] robili wypady, palili je i walczyli mężnie.
###### **1Mch 6,32**
 Wtedy Juda odstąpił od zamku i rozłożył się obozem pod Bet-Zacharia naprzeciwko królewskiego obozu.
###### **1Mch 6,33**
 Wczesnym rankiem król wyruszył i szybko wyprowadził wojsko w stronę Bet-Zacharia. Wojska ustawiły się do bitwy i zagrano na trąbach.
###### **1Mch 6,34**
 Słoniom pokazano sok winnych jagód i morwy, aby je rozjuszyć do bitwy.
###### **1Mch 6,35**
 Bestie poprzydzielano do falang i przy każdym słoniu ustawiono tysiąc żołnierzy ubranych w łańcuszkowe pancerze i mających głowy okryte hełmami z brązu. Ponadto do każdej bestii przydzielono po pięciuset wyborowych jeźdźców.
###### **1Mch 6,36**
 Oni już przedtem byli do bestii przydzieleni: gdzie ona była, tam byli i oni, gdzie ona szła, tam szli i oni razem z nią i nigdy od niej nie odstępowali.
###### **1Mch 6,37**
 Na każdej bestii za pomocą specjalnych urządzeń była umocowana drewniana wieża, która ją okrywała, a na niej wojenne narzędzia i czterech żołnierzy, którzy z niej walczyli, a oprócz tego kierujący nią Hindus.
###### **1Mch 6,38**
 Pozostała część konnicy ustawiła się po jednej i po drugiej stronie, na dwóch skrzydłach wojska, ażeby wrogów nękać, a zabezpieczyć falangi.
###### **1Mch 6,39**
 Gdy słońce rozbłysło na złotych i brązowych tarczach, rozbłysły od nich góry i świeciły jak ogniste pochodnie.
###### **1Mch 6,40**
 Jedna część królewskiego wojska rozciągnęła się na zboczu góry, a inni byli w dolinie. Tak zaczęli bitwę pewni siebie i w całkowitym porządku.
###### **1Mch 6,41**
 Zadrżeli wszyscy, którzy usłyszeli głos nadciągającej ogromnej ich liczby i chrzęst zbroi. Było to bowiem wojsko bardzo wielkie i mocne.
###### **1Mch 6,42**
 Przybliżył się także Juda ze swoim wojskiem gotów do boju; i z wojska królewskiego padło sześciuset żołnierzy.
###### **1Mch 6,43**
 Eleazar Auaran zauważył, że jedna z bestii ma na sobie królewskie pancerze. Była ona większa od wszystkich innych bestii. Sądził on, że na niej jest król.
###### **1Mch 6,44**
 Poświęcił się więc, żeby uratować swój naród, a sobie zapewnić wieczną sławę.
###### **1Mch 6,45**
 Odważnie i szybko przedostał się do niej przez środek falangi, zadając śmierć na prawo i na lewo, tak że odstępowano od niego na jedną i drugą stronę.
###### **1Mch 6,46**
 Wtedy podszedł pod słonia, przebił go od spodu i zabił, a ten padając na ziemię, przywalił go. Tak oddał tam życie.
###### **1Mch 6,47**
 Gdy oni zobaczyli siłę królewską i napór jego wojska, wycofali się.
###### **1Mch 6,48**
 Część królewskiego wojska wyszła przeciwko nim w stronę Jeruzalem. Król zaś rozłożył obóz, aby walczyć przeciw Judei i przeciw górze Syjon.
###### **1Mch 6,49**
 Z tymi, którzy byli w Bet-Sur, zawarł pokój. Wyszli oni z miasta, bo w kraju był rok szabatowy, a nie mieli dość żywności na to, aby mogli dłużej wytrzymać w zamknięciu.
###### **1Mch 6,50**
 Król więc zajął Bet-Sur i pozostawił w nim załogę do strzeżenia go.
###### **1Mch 6,51**
 Sam zaś rozpoczął oblężenie świątyni, które trwało przez długi czas. Ustawił tam kusze i machiny oblężnicze, mianowicie: balisty do wyrzucania ognia i kamieni, balisty do rzucania strzał i proce.
###### **1Mch 6,52**
 Oni jednak przeciwko ich machinom oblężniczym zrobili swoje machiny wojenne i bronili się przez długi czas.
###### **1Mch 6,53**
 W spiżarniach brakowało im jednak żywności, bo był to siódmy rok, a resztę zapasów zjedli ci, którzy przed narodami pogańskimi schronili się do Judei.
###### **1Mch 6,54**
 W świątyni więc pozostało już tylko niewielu żołnierzy, bo głód im bardzo dokuczał, i porozchodzili się – każdy do swojej miejscowości.
###### **1Mch 6,55**
 Wtedy Lizjasz dowiedział się, że Filip, którego król Antioch jeszcze za życia ustanowił wychowawcą swego syna, Antiocha, aby go nauczyć rządzić królestwem,
###### **1Mch 6,56**
 powrócił z Persji i Medii razem z wojskiem, które było przy królu, i stara się o objęcie władzy.
###### **1Mch 6,57**
 Wobec tego [Lizjasz] zaczął się śpieszyć i skłonił się do odwrotu. Rzekł więc do króla, do dowódców wojska i do żołnierzy: «***Co dnia słabniemy, żywności mamy mało, a miejsce, które oblegamy, jest warowne. Ponadto zaś sprawy królestwa na nas czekają.***
###### **1Mch 6,58**
 ***Teraz więc podajmy prawicę tym ludziom, zawrzyjmy pokój z nimi i z całym ich narodem.***
###### **1Mch 6,59**
 ***Pozwólmy, niech postępują zgodnie ze swoimi obyczajami – jak poprzednio. Rozgniewali się oni bowiem i zrobili to wszystko z powodu tych obyczajów, które znieśliśmy***».
###### **1Mch 6,60**
 Słowa te spodobały się królowi i dowódcom. Zatem wysłał poselstwo w sprawie zawarcia pokoju, a oni je przyjęli.
###### **1Mch 6,61**
 Gdy król i dowódcy złożyli im zaprzysiężoną [rękojmię], wtedy wyszli z warowni.
###### **1Mch 6,62**
 Król udał się na górę Syjon, a kiedy zobaczył, jak to miejsce zostało obwarowane, złamał przysięgę, którą złożył poprzednio, a mur dokoła kazał zburzyć.
###### **1Mch 6,63**
 Potem szybko odjechał i udał się do Antiochii. Zastał tam Filipa panującego nad miastem; rozpoczął z nim walkę i miasto zdobył siłą.
# 1Mch 6 PAU
###### **1Mch 6,1**
 Król Antioch przechodził przez wszystkie górskie prowincje i usłyszał, że w Persji, w mieście Elimais, słynnym z bogactwa, srebra i złota,
###### **1Mch 6,2**
 jest bardzo bogata świątynia. Znajdują się tam złote zbroje, pancerze i tarcze, które pozostawił tam Aleksander, syn Filipa, król Macedoński, który najpierw panował nad Grekami.
###### **1Mch 6,3**
 Przybył więc tam i starał się zdobyć miasto, aby je złupić, ale nie zdołał, ponieważ mieszkańcy miasta odkryli jego zamiary
###### **1Mch 6,4**
 i powstali do walki przeciwko niemu. Musiał więc odejść stamtąd i bardzo zawiedziony powracał do Babilonii.
###### **1Mch 6,5**
 Jeszcze w Persji przybył do niego jakiś człowiek z wiadomością, że wojska, które wkroczyły do ziemi Judy, zostały zmuszone do ucieczki.
###### **1Mch 6,6**
 Zwłaszcza Lizjasz, który udał się tam z silnym wojskiem, uciekł na ich widok, a tamci, zabierając pokonanym przez siebie wojskom broń, sprzęt wojenny i liczne łupy, bardzo się wzmocnili.
###### **1Mch 6,7**
 Zburzyli obrzydliwość, którą król zbudował na ołtarzu w Jerozolimie, a świątynię i jego miasto Bet-Sur ponownie otoczyli wysokimi murami.
###### **1Mch 6,8**
 Gdy król usłyszał te wieści, osłupiał i był wstrząśnięty. Upadł na łóżko i zachorował z rozpaczy, ponieważ nie stało się tak, jak tego sobie życzył.
###### **1Mch 6,9**
 Pozostał tam wiele dni, bo nieustannie przytłaczał go smutek, a nawet wydawało mu się, że umrze.
###### **1Mch 6,10**
 Przywołał więc wszystkich swoich przyjaciół i powiedział im: „Sen oddalił się od moich oczu, a moje serce jest przygnębione.
###### **1Mch 6,11**
 Powiedziałem sobie: Oto do jakiego doszedłem utrapienia i w jakim zamęcie się znalazłem, a przecież byłem życzliwy i miłowano mnie za sposób sprawowania władzy.
###### **1Mch 6,12**
 Teraz jednak przypomniałem sobie nieszczęścia, które wyrządziłem w Jerozolimie. Zabrałem srebrne i złote naczynia, które tam się znajdowały, i bez powodu kazałem wygubić mieszkańców Judy.
###### **1Mch 6,13**
 Wiem, że to właśnie dlatego dotknęły mnie te nieszczęścia. Oto w wielkim smutku ginę na obcej ziemi”.
###### **1Mch 6,14**
 Następnie przywołał Filipa, jednego ze swoich przyjaciół, i ustanowił go rządcą nad całym swoim królestwem.
###### **1Mch 6,15**
 Przekazał mu diadem, swoją szatę i pierścień, aby wychował jego syna Antiocha i przygotował go do objęcia władzy.
###### **1Mch 6,16**
 Król Antioch zmarł tam w sto czterdziestym dziewiątym roku.
###### **1Mch 6,17**
 Gdy Lizjasz dowiedział się o śmierci króla, ustanowił królem jego syna Antiocha, którego wychowywał od dzieciństwa. Nadał mu imię Eupator.
###### **1Mch 6,18**
 Ci, którzy przebywali w twierdzy, ze wszystkich stron utrudniali Izraelitom dostęp do świątyni. Starali się im szkodzić, a wspierali pogan.
###### **1Mch 6,19**
 Juda postanowił więc ich wytępić. Zwołał cały lud, aby rozpocząć oblężenie.
###### **1Mch 6,20**
 W sto pięćdziesiątym roku zebrali się wszyscy, zbudowali wyrzutnie i machiny oblężnicze i rozpoczęli oblężenie.
###### **1Mch 6,21**
 Niektórzy wydostali się z oblężenia, a jacyś bezbożni Izraelici dołączyli do nich.
###### **1Mch 6,22**
 Udali się do króla i powiedzieli: „Jak długo jeszcze będziesz zwlekał z wymierzeniem sprawiedliwości i pomsty za naszych braci?
###### **1Mch 6,23**
 My chętnie służyliśmy twojemu ojcu, postępowaliśmy zgodnie z jego postanowieniami i wypełnialiśmy jego rozkazy,
###### **1Mch 6,24**
 dlatego nasi rodacy odłączyli się od nas i przystąpili do oblężenia. Ponadto zabijali każdego z nas, kogo schwytali, a nasz majątek rozgrabili.
###### **1Mch 6,25**
 Podnieśli rękę nie tylko na nas, lecz także na wszystkie okoliczne krainy.
###### **1Mch 6,26**
 A dzisiaj oblegają twierdzę w Jerozolimie i chcą wziąć ją w posiadanie. Obwarowali świątynię i Bet-Sur.
###### **1Mch 6,27**
 Jeśli teraz im się nie przeciwstawisz, zrobią jeszcze gorsze rzeczy, a wtedy nie będziesz już mógł ich powstrzymać”.
###### **1Mch 6,28**
 Król rozgniewał się, kiedy to usłyszał. Zebrał wszystkich swoich przyjaciół, dowódców piechoty i jazdy.
###### **1Mch 6,29**
 Z innych królestw i z wysp morskich sprowadził wojska najemne.
###### **1Mch 6,30**
 Całe jego wojsko liczyło sto tysięcy pieszych, dwadzieścia tysięcy jeźdźców i trzydzieści dwa słonie wyćwiczone do walki.
###### **1Mch 6,31**
 Przeszli przez Idumeę i uderzyli na Bet-Sur. Walki trwały przez wiele dni. Zbudowali machiny oblężnicze, ale obrońcy robili wypady, podpalali je i mężnie walczyli.
###### **1Mch 6,32**
 Tymczasem Juda odstąpił od twierdzy i rozbił obóz przy Bet-Zacharia, naprzeciwko obozu króla.
###### **1Mch 6,33**
 Wczesnym rankiem król wyruszył i szybko wyprowadził wojsko w stronę Bet-Zacharia. Wojska zajęły pozycje do bitwy i zadęto w trąby.
###### **1Mch 6,34**
 Słoniom pokazano sok z winogron i czarnych jeżyn, aby pobudzić je do walki.
###### **1Mch 6,35**
 Zwierzęta przydzielono do oddziałów i przy każdym słoniu postawiono tysiąc żołnierzy w pancerzach z ogniw łańcuszkowych i w hełmach z brązu na głowach. Ponadto do każdego zwierzęcia przydzielono pięciuset doborowych jeźdźców.
###### **1Mch 6,36**
 Poprzedzali oni zwierzę, gdzie tylko się znalazło. Zawsze mu towarzyszyli i nie oddalali się od niego.
###### **1Mch 6,37**
 Na każdym zwierzęciu dla ochrony była umocowana drewniana wieża, do której przytwierdzono narzędzia do walki. Znajdowało się na nim także czterech uzbrojonych ludzi gotowych do walki, a ponadto Hindus.
###### **1Mch 6,38**
 Resztę jazdy rozmieścił na obu skrzydłach wojska, z jednej i drugiej strony, aby nękali nieprzyjaciół i osłaniali piechotę.
###### **1Mch 6,39**
 Kiedy słońce zabłysło na tarczach ze złota i brązu, zajaśniały od nich góry i rozświetliły się jak ogniste pochodnie.
###### **1Mch 6,40**
 Część królewskiego wojska zajęła pozycje na zboczach, a inni w dolinach. Posuwali się naprzód pewni siebie i w zwartym szyku.
###### **1Mch 6,41**
 Zadrżeli wszyscy, którzy słyszeli odgłos nadciągających tłumów i szczęk oręża. Była to bowiem armia bardzo liczna i silna.
###### **1Mch 6,42**
 Ruszył Juda ze swym wojskiem do bitwy i zginęło sześciuset ludzi z królewskiej armii.
###### **1Mch 6,43**
 Eleazar Auaran zauważył, że pancerz jednego ze zwierząt odznacza się królewskim przepychem i że przewyższa ono inne zwierzęta. Sądził więc, że jest na nim król.
###### **1Mch 6,44**
 Poświęcił siebie, aby ocalić swój lud i zdobyć wieczną sławę.
###### **1Mch 6,45**
 Odważnie przedzierał się ku niemu przez środek oddziału, zadając śmiertelne ciosy na prawo i lewo, tak że nieprzyjaciele rozstępowali się przed nim na dwie strony.
###### **1Mch 6,46**
 Potem schylił się, wszedł pod słonia i zabił go. Zginął jednak przywalony padającym na ziemię zwierzęciem.
###### **1Mch 6,47**
 Izraelici wycofali się, widząc potęgę króla i impet jego wojsk.
###### **1Mch 6,48**
 Żołnierze królewscy ruszyli przeciwko nim w kierunku Jerozolimy. Król zajął Judeę i oblegał górę Syjon.
###### **1Mch 6,49**
 Zawarł pokój z obrońcami Bet-Sur, którzy opuścili miasto, gdyż brakowało w nim żywności, niezbędnej, aby przetrzymać oblężenie. Był to bowiem rok szabatowy dla ziemi.
###### **1Mch 6,50**
 Król zajął więc Bet-Sur i umieścił tam na straży załogę.
###### **1Mch 6,51**
 Następnie przez wiele dni oblegał świątynię. Rozmieścił tam wyrzutnie i machiny wojenne, wyrzutnie ognia i kamieni, urządzenia do miotania strzał i kamiennych pocisków.
###### **1Mch 6,52**
 Ale obrońcy także zbudowali machiny i przy ich pomocy przez wiele dni walczyli, przeciwstawiając się machinom wroga.
###### **1Mch 6,53**
 Lecz w magazynach zabrakło żywności, ponieważ był to rok szabatowy, a zgromadzone zapasy zjedli ci, którzy ocaleli spośród obcych narodów i znaleźli schronienie w Judei.
###### **1Mch 6,54**
 W świątyni pozostało niewielu mężczyzn, ponieważ z powodu głodu rozeszli się do swoich miejscowości.
###### **1Mch 6,55**
 Wtedy Lizjasz dowiedział się, że Filip, którego król Antioch jeszcze za życia ustanowił wychowawcą swego syna Antiocha, aby przygotowywał go do objęcia władzy,
###### **1Mch 6,56**
 powrócił z Persji i Medii wraz z wojskiem, które poszło z królem, i że ten Filip zabiega o przejęcie rządów.
###### **1Mch 6,57**
 Lizjasz chciał więc szybko odstąpić od oblężenia i dlatego powiedział królowi, dowódcom wojska i żołnierzom: „Każdego dnia ponosimy straty, mamy niewiele jedzenia, miejsce, które oblegamy, jest umocnione, a sprawy królestwa przynaglają nas.
###### **1Mch 6,58**
 Teraz więc okażmy tym ludziom litość i zawrzyjmy pokój z nimi i z całym ich narodem.
###### **1Mch 6,59**
 Pozwólmy im postępować według ich praw, jak to było wcześniej, bo z powodu ich praw, które odrzuciliśmy, rozgniewali się i zrobili to wszystko”.
###### **1Mch 6,60**
 Mowa ta spodobała się królowi oraz dowódcom. Zaproponował więc im zawarcie pokoju, a oni wyrazili zgodę.
###### **1Mch 6,61**
 Opuścili jednak twierdzę dopiero wtedy, gdy król i dowódcy złożyli im przysięgę.
###### **1Mch 6,62**
 Król wszedł na górę Syjon, ale kiedy zobaczył umocnienie tego miejsca, złamał złożoną przysięgę i nakazał zburzyć okalający je mur.
###### **1Mch 6,63**
 Potem szybko odszedł i powrócił do Antiochii. Zastał tam Filipa, który przejął władzę w mieście. Walczył przeciwko niemu i zdobył miasto siłą.
# 1Mch 6 BP
###### **1Mch 6,1**
 Ciągnąc przez północne kraje dowiedział się król Antioch, że jest w Persji miasto Elimais, słynne z bogactw, srebra i złota
###### **1Mch 6,2**
 oraz z przebogatej świątyni, w której znajdowały się złote zbroje, tarcze i broń, pozostawione tam przez króla macedońskiego Aleksandra, syna Filipa, pierwszego króla Greków.
###### **1Mch 6,3**
 Przybył tam i zamierzał zdobyć i złupić miasto, czego jednak nie zdołał uczynić, gdyż mieszkańcy miasta przejrzawszy jego zamiary
###### **1Mch 6,4**
 stanęli do walki. Musiał więc stamtąd odejść i bardzo zawiedziony powrócił do Babilonu.
###### **1Mch 6,5**
 Do Persji przybył pewien człowiek, który doniósł mu, że wojska wysłane do ziemi judzkiej zostały rozbite.
###### **1Mch 6,6**
 Lizjasz, który pierwszy wyruszył na czele potężnego wojska, pokonany został [przez Żydów]. Oni zaś stali się silniejsi dzięki broni, wojsku i wielkim łupom zabranym z obozu pokonanej armii.
###### **1Mch 6,7**
 Usunęli też obrzydliwość, którą zbudował na ołtarzu jerozolimskim, oraz na nowo otoczyli wysokimi murami święty Przybytek i jego [króla] miasto Betsur.
###### **1Mch 6,8**
 Król słysząc te słowa zadziwił się i zaniepokoił niezmiernie, tak że padł na łoże i zaniemógł ze zmartwienia, ponieważ nie stało się tak, jak tego pragnął.
###### **1Mch 6,9**
 Pozostawał tam wiele dni, gdyż na nowo ogarnęło go wielkie przygnębienie, tak że spodziewał się nawet śmierci.
###### **1Mch 6,10**
 Wezwał więc wszystkich swoich przyjaciół i rzekł do nich: "Sen uleciał z moich oczu, a serce zamiera od troski.
###### **1Mch 6,11**
 Rozważałem w duszy, jak wielkie są utrapienia i niepewność mego obecnego położenia, a przecież w czasie swego panowania byłem szlachetny i sprawiedliwy.
###### **1Mch 6,12**
 Teraz jednak przychodzi mi na myśl zło wyrządzone Jerozolimie. Zabrałem bowiem wszystkie srebrne i złote naczynia, które się w niej znajdowały, wysłałem też [wojsko], aby bez powodu zgładzić wszystkich mieszkańców Judei.
###### **1Mch 6,13**
 Zrozumiałem, że było to powodem nieszczęść, które mnie nawiedziły. I oto z wielkiej zgryzoty ginę na obczyźnie."
###### **1Mch 6,14**
 Przywołał też Filipa, jednego ze swych przyjaciół, i postawił go na czele całego królestwa.
###### **1Mch 6,15**
 Przekazał mu diadem, płaszcz i sygnet oraz zlecił mu, aby zajął się wychowaniem jego syna Antiocha i wykształcił go na dobrego władcę.
###### **1Mch 6,16**
 Tam też zmarł król Antioch w roku sto czterdziestym dziewiątym.
###### **1Mch 6,17**
 Na wieść o śmierci króla Lizjasz ustanowił następcą jego syna Antiocha, którego wychowywał od młodości, i nadał mu przydomek Eupator.
###### **1Mch 6,18**
 Żołnierze umieszczeni w twierdzy napadali na Żydów wokół Świątyni stale ich krzywdząc i pomagając poganom.
###### **1Mch 6,19**
 Dlatego postanowił Juda pozbyć się ich. Zwołał więc wszystek lud, by ich otoczyć.
###### **1Mch 6,20**
 Zebrali się razem i w roku sto pięćdziesiątym rozpoczęli oblężenie zamku. [Juda] przygotował urządzenia do wyrzucania pocisków oraz machiny oblężnicze.
###### **1Mch 6,21**
 Kilku spośród oblężonych zdołało uciec. Przyłączyła się do nich garstka bezbożnych Izraelitów
###### **1Mch 6,22**
 i udali się [razem] do króla mówiąc: "Kiedy wreszcie wydasz na nich wyrok i pomścisz naszych braci?
###### **1Mch 6,23**
 Chętnie służyliśmy twemu ojcu, wypełnialiśmy jego rozkazy i postępowaliśmy zgodnie z jego wskazaniami.
###### **1Mch 6,24**
 Dlatego synowie naszego ludu oblegli [twierdzę] i stali się naszymi wrogami. Zamordowali tych spośród nas, którzy dostali się w ich ręce, i zagarnęli nasze mienie.
###### **1Mch 6,25**
 Nie tylko przeciwko nam wyciągnęli swą rękę, lecz przeciw wszystkim sąsiednim krajom.
###### **1Mch 6,26**
 Oto teraz otoczyli twierdzę jerozolimską, aby nią zawładnąć. Obwarowali nawet Świątynię i Betsur.
###### **1Mch 6,27**
 Jeżeli natychmiast ich nie ubiegniesz, rozzuchwalą się jeszcze bardziej i już nigdy nie zdołasz ich powstrzymać."
###### **1Mch 6,28**
 Rozgniewany tymi wieściami król zwołał wszystkich swoich przyjaciół - dowódców piechoty i jazdy.
###### **1Mch 6,29**
 Przybyli również do niego najemni żołnierze z innych państw i wysp morskich.
###### **1Mch 6,30**
 Armia jego liczyła sto tysięcy piechoty, dwadzieścia tysięcy jazdy oraz trzydzieści dwa słonie wyćwiczone do boju.
###### **1Mch 6,31**
 Przeszedłszy przez Idumeę rozbili obóz pod Betsur. Zrobili machiny oblężnicze i przez wiele dni toczyli walki. Lecz [oblężeni] palili machiny w czasie wypadów i walczyli bardzo dzielnie.
###### **1Mch 6,32**
 Juda musiał odstąpić od zamku i rozłożył się obozem pod Betzacharia, naprzeciw wojsk królewskich.
###### **1Mch 6,33**
 Król wyruszył rano i szybko poprowadził wojsko w kierunku Betzacharia. Oddziały ustawiły się w szyku bojowym, po czym zadęto w trąby.
###### **1Mch 6,34**
 Słoniom pokazano sok winnych jagód i morwy, aby je podniecić do walki.
###### **1Mch 6,35**
 Zwierzęta przydzielono do oddziałów tak, że przy każdym słoniu postawiono tysiąc żołnierzy w pancerzach łańcuszkowych i mających spiżowe hełmy na głowach. Ponadto do każdej bestii przydzielono pięciuset wyborowych jeźdźców.
###### **1Mch 6,36**
 Oni już wcześniej byli przy zwierzęciu, nie odstępując go ani na chwilę, i szli tam, gdzie ono szło.
###### **1Mch 6,37**
 Każdy słoń był chroniony przez drewnianą wieżę, umocowaną specjalnymi urządzeniami. Z każdej wieży walczyło czterech żołnierzy i [kierujący zwierzęciem] Hindus.
###### **1Mch 6,38**
 Pozostałe oddziały jazdy ustawił [król] po jednej i po drugiej strome, na obu skrzydłach wojska, aby je ubezpieczały i nękały [przeciwnika].
###### **1Mch 6,39**
 Blask słońca odbity w złotych i spiżowych tarczach rozjaśnił góry, które zapłonęły niczym zapalone pochodnie.
###### **1Mch 6,40**
 Jedna część królewskiego wojska rozwinęła się na zboczu wzgórza, a druga na równinie. Szli naprzód pewnie, we wzorowym szyku.
###### **1Mch 6,41**
 Wszyscy zadrżeli słysząc odgłos ogromnej masy nadciągającego wojska i szczęk oręża. Była to bowiem armia wielka i silna.
###### **1Mch 6,42**
 Juda wystąpił ze swym wojskiem do walki. Siły królewskie straciły sześciuset ludzi.
###### **1Mch 6,43**
 Eleazar Auaran zauważył, że jedno ze zwierząt górujące nad innymi ma na sobie królewskie pancerze. Sądził więc, że jest na nim król.
###### **1Mch 6,44**
 Poświęcił się, aby ratować swój naród i zyskać wieczną sławę.
###### **1Mch 6,45**
 Śmiało przedostał się do niego przez środek oddziału, rozdając śmiertelne ciosy na prawo i lewo, tak że rozstępowali się przed nim na obie strony.
###### **1Mch 6,46**
 Wszedł pod słonia i zabił go ciosem od dołu. Zginął jednak przywalony padającym na ziemię zwierzęciem.
###### **1Mch 6,47**
 [Żydzi], widząc potęgę królewską i natarcie wojska, wycofali się przed nim.
###### **1Mch 6,48**
 Część wojska królewskiego ruszyła w stronę Jerozolimy, aby się z nimi [Izraelitami] spotkać. Król zaś z wojskiem ustawił szyki w stronę Judei i góry Syjon.
###### **1Mch 6,49**
 Z mieszkańcami Betsur zawarł pokój. Wyszli oni z miasta, gdyż w kraju był rok szabatowy i z powodu braku żywności nie byli w stanie znieść długiego oblężenia.
###### **1Mch 6,50**
 Zajął więc król Betsur i zostawił tam na straży załogę.
###### **1Mch 6,51**
 Sam zaś rozpoczął długotrwałe oblężenie Świątyni. Ustawił tu urządzenia do wyrzucania pocisków i machiny oblężnicze, miotacze ognia i kamieni, skorpiony do miotania pocisków i proce.
###### **1Mch 6,52**
 Przeciw ich machinom [oblężeni] również zbudowali własne machiny i bronili się długi czas.
###### **1Mch 6,53**
 Brakowało jednak żywności w magazynach, gdyż był to siódmy rok, a resztę zapasów zjedli ci, którzy schronili się do Judei spomiędzy narodów pogańskich.
###### **1Mch 6,54**
 Pozostało więc w Świątyni jedynie niewielu obrońców, gdyż bardzo się im dawał we znaki głód, i rozeszli się do swych rodzinnych miejscowości.
###### **1Mch 6,55**
 Lizjasz dowiedział się, że Filip, którego król Antioch jeszcze za życia ustanowił wychowawcą swego syna Antiocha, aby go przysposobił do sprawowania rządów,
###### **1Mch 6,56**
 powrócił z Persji i Medii na czele wojska, które wyszło z królem, i próbuje przejąć władzę w swe ręce.
###### **1Mch 6,57**
 Chcąc tedy jak najszybciej odstąpić od oblężenia, [Lizjasz] przemówił do króla, dowódców wojska i ludu: "Codziennie ponosimy straty i żywności pozostało nam już niewiele, a miejsce, które oblegamy, jest warowne. Ponadto musimy uporządkować sprawy królestwa.
###### **1Mch 6,58**
 Podajmy więc tym ludziom prawicę i zawrzyjmy pokój z nimi i z całym ich narodem.
###### **1Mch 6,59**
 Pozwólmy im, aby jak dawniej zachowywali swe zwyczaje. Powodem bowiem ich gniewu i czynów, jakich się dopuścili, było to, że zakazywaliśmy im żyć wedle własnych obyczajów."
###### **1Mch 6,60**
 słowa te spodobały się królowi i dowódcom. Wysłał zatem posłów [do oblężonych] z propozycją zawarcia pokoju, a oni ją przyjęli.
###### **1Mch 6,61**
 Gdy król i dowódcy zatwierdzili [układ] przysięgą, wyszli z twierdzy.
###### **1Mch 6,62**
 Król zaś wszedł na górę Syjon i gdy zobaczył, jak to miejsce zostało obwarowane, złamał złożoną przysięgę i rozkazał zburzyć ciągnące się wokoło mury.
###### **1Mch 6,63**
 Potem wycofał się pospiesznie i wrócił do Antiochii, gdzie zastał Filipa panującego nad miastem. Stoczył z nim bitwę i siłą opanował miasto.
# 1Mch 6 BR
###### **1Mch 6,1**
 Tymczasem król Antioch przemierzał prowincje wschodnie. Posłyszał on o Elimais, mieście perskim słynącym z obfitości srebra i złota,
###### **1Mch 6,2**
 jak również z bardzo bogatej świątyni, w której macedoński król Aleksander, syn Filipa, pierwszego króla greckiego, zostawił złote tarcze, zbroje i różną broń.
###### **1Mch 6,3**
 Otóż przybył tam Antioch i próbował zdobyć i złupić całe miasto, lecz mu się nie udało, gdyż mieszkańcy miasta dowiedzieli się wcześniej o jego zamiarach
###### **1Mch 6,4**
 i zdołali stawić skutecznie zbrojny opór, tak że musiał się z pośpiechem wycofać a w drodze powrotnej do Babilonu poniósł dotkliwą klęskę.
###### **1Mch 6,5**
 Kiedy był jeszcze w Persji, dotarł do niego goniec z wiadomością, że wojska, które wkroczyły do Judei, zostały pobite.
###### **1Mch 6,6**
 Także Lizjasz, który wyruszył na czele bardzo silnego oddziału przeciwko Żydom, doznał bolesnej porażki. Oni zaś, Żydzi, uzupełnili swoje uzbrojenie i znacznie zwiększyli swą moc rażenia dzięki łupom, które wzięli na zwyciężonych wojskach.
###### **1Mch 6,7**
 Znów usunęli ohydę-posąg, który został kiedyś postawiony na ołtarzu w Jerozolimie, a cały teren świątyni otoczyli wysokim, jak kiedyś, murem. Podobnie wysoki mur wznieśli wokół miasta Bet-Sur.
###### **1Mch 6,8**
 Na wieść o tym ogarnęło króla przygnębienie i niepokój. Zasłabł nagle do tego stopnia, że musiał się położyć. Bardzo zmartwił się, że zostały pokrzyżowane jego plany.
###### **1Mch 6,9**
 I tak upłynęło wiele dni. Król popadł w coraz większe przygnębienie i zaczął już myśleć, że wkrótce będzie musiał umrzeć.
###### **1Mch 6,10**
 Wreszcie zwołał swoich przyjaciół i powiedział do nich: Spać już nie mogę, bo zmogły mnie różne troski.
###### **1Mch 6,11**
 Sam się zastanawiam, jak doszło do tego ucisku i utrapienia. Przez cały czas mojego panowania starałem się przecież być ludzki i łagodny.
###### **1Mch 6,12**
 Teraz jednak przypominam sobie wszystko zło, którego dopuściłem się w Jerozolimie. Zrabowałem wtedy wszystkie naczynia ze srebra i złota, co więcej, bez żadnego powodu wydałem rozkaz, żeby wymordowano wszystkich mieszkańców Judei.
###### **1Mch 6,13**
 To dlatego - już teraz wiem dobrze - spadły na mnie wszystkie te nieszczęścia i muszę umrzeć pełen zgryzoty na tej obcej ziemi.
###### **1Mch 6,14**
 Potem przywołał do siebie Filipa, jednego ze swoich przyjaciół, i jemu przekazał władzę nad całym swoim królestwem.
###### **1Mch 6,15**
 Włożył mu na głowę swój diadem królewski, dał mu swe szaty i sygnet z pieczęcią. Powierzył mu także opiekę nad swoim synem Antiochem i troskę o jego wychowanie do czasu objęcia przez niego władzy.
###### **1Mch 6,16**
 I umarł tam król Antioch w roku sto czterdziestym dziewiątym.
###### **1Mch 6,17**
 Kiedy Lizjasz dowiedział się o śmierci króla, wyznaczył na jego następcę Antiocha, o którego wychowanie troszczył się przez wszystkie lata jego młodości. Nadał mu przydomek Eupator.
###### **1Mch 6,18**
 Załoga twierdzy jerozolimskiej urządzała wokół świątyni zasadzki na Izraelitów, bezustannie ich nękała, chcąc na nich sprowadzić jakieś nieszczęście, a poganom udzielić wsparcia.
###### **1Mch 6,19**
 Dlatego Juda postanowił ich usunąć stamtąd i nakazał wszystkim zdolnym do walki mężom rozpocząć oblężenie twierdzy.
###### **1Mch 6,20**
 Zebrano się więc i rozpoczęto - było to w roku sto pięćdziesiątym - oblężenie.
###### **1Mch 6,21**
 Niektórym jednak spośród załogi twierdzy udało się przedrzeć przez pierścień oblegających, a dołączyło do nich, co gorsza, wielu bezbożnych Izraelitów.
###### **1Mch 6,22**
 Udali się oni razem do króla i zapytali: Jak długo jeszcze będziesz zwlekał z przyznaniem naszych praw kiedy wreszcie pomścisz naszych braci?
###### **1Mch 6,23**
 Służyliśmy twojemu ojcu z wielkim oddaniem. Postępowaliśmy tak, jak on nam kazał, wprowadzając w życie jego polecenia.
###### **1Mch 6,24**
 Dlatego to nasi rodacy stali się nam obcy. Co więcej, mordowali każdego, kogo tylko spośród nas spotkali, i zagrabili całe nasze mienie.
###### **1Mch 6,25**
 Zresztą podnieśli rękę nie tylko na nas, lecz także na wszystkich swoich sąsiadów.
###### **1Mch 6,26**
 A teraz nadciągnęli pod twierdzę jerozolimską i usiłują ją zdobyć. Poza tym obwarowali świątynię i miasto Bet-Sur.
###### **1Mch 6,27**
 Jeżeli nie przeciwstawisz się im natychmiast, posuną się jeszcze dalej i wtedy nie będziesz już mógł ich powstrzymać.
###### **1Mch 6,28**
 Usłyszawszy to, król rozgniewał się bardzo. Kazał wezwać do siebie wszystkich swoich przyjaciół, a także dowódców oddziałów pieszych i konnicy.
###### **1Mch 6,29**
 Również z innych krajów i wysp przybyły do niego najemne oddziały.
###### **1Mch 6,30**
 Z nich wszystkich utworzył wojsko liczące sto tysięcy wojowników pieszych, dwadzieścia tysięcy jeźdźców i trzydzieści dwa słonie bojowe.
###### **1Mch 6,31**
 Przeszli przez całą Idumeę i rozbili obóz koło Bet-Sur, które przez dość długi czas usiłowali zdobyć przy użyciu machin oblężniczych. Ale oblężeni robili wypady, palili owe machiny i bronili się bardzo dzielnie.
###### **1Mch 6,32**
 W końcu odstąpił Juda od twierdzy jerozolimskiej i rozbił namioty pod Bet-Zacharia, naprzeciwko obozu królewskiego.
###### **1Mch 6,33**
 Zaraz też następnego dnia o świcie król wyruszył i szybkim marszem poprowadził swoje wojska na Bet-Zacharia. Wojska stanęły naprzeciwko siebie, gotowe do bitwy, i zadęto w trąby.
###### **1Mch 6,34**
 Słonie podniecono moszczem z winogron i owoców morwy, żeby je pobudzić do walki.
###### **1Mch 6,35**
 Potem poprzydzielano słonie poszczególnym oddziałom, tak że jeden słoń przypadał na tysiąc wojowników, którzy mieli na sobie zbroje z łańcuchów, a na głowach brązowe hełmy. Poza tym przy każdym słoniu znajdował się oddział złożony z pięciuset doborowych jeźdźców.
###### **1Mch 6,36**
 Już przedtem trzymali się oni zawsze blisko owych słoni i szli tam, dokąd one się kierowały.
###### **1Mch 6,37**
 Każde zwierzę niosło na sobie wieżę drewnianą, bardzo starannie do niego przymocowaną, czterech wojowników, którzy z tej wieży walczyli, oraz jednego Hindusa, który kierował słoniem.
###### **1Mch 6,38**
 Pozostałych jeźdźców ustawił król na zewnątrz, na obydwu skrzydłach całego wojska. Mieli oni prowadzić działania zaczepne i osłaniać własne szeregi.
###### **1Mch 6,39**
 Kiedy promienie słońca zaczęły się załamywać na złotych i brązowych tarczach, oświetliły pobliskie wzgórze, tak że zaczęły świecić jak ogniste pochodnie.
###### **1Mch 6,40**
 Część wojsk królewskich zajęła pozycje na wzgórzu, część zaś u jego stóp, na równinie. Tak też pewni siebie i nie zmieniając szyku, rozpoczęli walkę.
###### **1Mch 6,41**
 I zadrżeli wszyscy, którzy słyszeli chrzęst broni i zobaczyli takie mnóstwo wojska idące do ataku. Wojowników było rzeczywiście bardzo wielu i wszyscy byli dobrze uzbrojeni.
###### **1Mch 6,42**
 Juda ruszył ze swoimi oddziałami także ku przodowi i doszło do starcia, w którym poległo sześciuset wojowników królewskich.
###### **1Mch 6,43**
 W pewnej chwili Eleazar Auaran zauważył słonia, którego zbroja odznaczała się królewskim przepychem, a samo zwierzę wyróżniało się wielkością spośród innych. Eleazar był przekonany, że na tym właśnie słoniu siedzi król.
###### **1Mch 6,44**
 Postanowił tedy poświęcić własne życie, żeby ratować cały lud i wsławić swoje imię.
###### **1Mch 6,45**
 Rzucił się więc odważnie w jego stronę, przedzierając się pomiędzy szeregami walczących wrogów. Zadawał przy tym tyle śmiertelnych ciosów na lewo i na prawo, że ustępowano mu z drogi, czyniąc wolne przejście.
###### **1Mch 6,46**
 Tak dotarł aż do owego słonia, przedostał się pod niego i przebił go włócznią od spodu. Słoń, waląc się na ziemię, przygniótł go swoim ciałem i zmiażdżył.
###### **1Mch 6,47**
 Kiedy Żydzi zobaczyli siłę, z jaką napierały wojska królewskie, zaczęli się wycofywać.
###### **1Mch 6,48**
 Wówczas wojska królewskie udały się w stronę Jerozolimy, aby zagrodzić Żydom drogę i pokonać ich w walce. Rozbił król namioty u stóp góry Syjon.
###### **1Mch 6,49**
 Z załogą zaś twierdzy Bet-Sur zawarł pokój. Wtedy oblegani wyszli z miasta. Przez czas oblężenia wyczerpały się już bowiem całkowicie zapasy żywności, a w kraju rozpoczął się rok szabatowy.
###### **1Mch 6,50**
 Król polecił zająć Bet-Sur i obsadził w nim załogę, zapewniając sobie w ten sposób bezpieczeństwo.
###### **1Mch 6,51**
 Potem przez wiele dni oblegał świątynię. Polecił sprowadzić różne urządzenia oblężnicze, do wzniecania pożaru i miotania kamieni, łuki i proce.
###### **1Mch 6,52**
 Ale Żydzi również poustawiali machiny wojenne i przez długi czas stawiali opór.
###### **1Mch 6,53**
 Niestety, spiżarnie były puste, bo trwał właśnie rok siódmy. Resztki żywności, jakie jeszcze były w spichlerzach, spożyli ci, którzy zostali wyrwani z rąk obcych ludów i wrócili do Judei.
###### **1Mch 6,54**
 Obrońcy świątyni cierpieli więc dotkliwy głód. Ubywało ich tedy każdego dnia, bo rozchodzili się do własnych miejscowości. W końcu pozostała ich w świątyni garstka.
###### **1Mch 6,55**
 Lizjasz usłyszał, że Filip, którego król Antioch jeszcze za życia wyznaczył na wychowawcę swojego syna, Antiocha, do czasu objęcia przez niego samodzielnych rządów,
###### **1Mch 6,56**
 powrócił z Persji i Medii razem z oddziałami wojskowymi, towarzyszącymi kiedyś królowi, teraz już nie żyjącemu, i że zamierza przejąć władzę.
###### **1Mch 6,57**
 Wydał zatem rozkaz, do dowódców wojskowych i do wojowników zwrócił się z tymi słowami: Nasze położenie staje się z każdym dniem coraz trudniejsze. Mamy już bardzo mało żywności, a twierdza, którą oblegamy, jest nie do zdobycia. Poza tym musimy się przecież troszczyć o całe państwo.
###### **1Mch 6,58**
 Wyciągnijmy zatem do tych ludzi rękę i zawrzyjmy pokój z nimi i z całym narodem.
###### **1Mch 6,59**
 Pozwólmy im żyć według ich obyczajów, tak jak dawniej żyli. Wystąpili bowiem przeciwko nam i uczynili to wszystko dlatego, że chcieliśmy im odebrać ich prawo.
###### **1Mch 6,60**
 Podobała się ta rada królowi i dowódcom wojskowym. I zaproponowano Żydom pokój, a oni się na to zgodzili.
###### **1Mch 6,61**
 Z twierdzy jednak wyszli dopiero wtedy, kiedy król i dowódcy wojskowi złożyli im przysięgę.
###### **1Mch 6,62**
 Lecz kiedy król wszedł na górę Syjon i zobaczył wszystkie jej umocnienia, złamał dopiero co złożoną przysięgę i wydał rozkaz zburzenia murów otaczających całą górę.
###### **1Mch 6,63**
 Potem szybko ruszył w kierunku Antiochii Ale miasto było już we władaniu Filipa. Przystąpił tedy do walk i wziął miasto siłą.
# 1Mch 6 WUJ
