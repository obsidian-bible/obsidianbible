# Flp 4 BT5
###### **Flp 4,1**
 Przeto, bracia umiłowani, za którymi tęsknię – radości i chwało moja! – tak trwajcie mocno w Panu, umiłowani!
###### **Flp 4,2**
 Wzywam Ewodię i wzywam Syntychę, aby były jednej myśli w Panu.
###### **Flp 4,3**
 Także proszę i ciebie, prawdziwy Syzygu, pomagaj im, bo one razem ze mną trudziły się dla Ewangelii wraz z Klemensem i pozostałymi moimi współpracownikami, których imiona są w księdze życia.
###### **Flp 4,4**
 Radujcie się zawsze w Panu; jeszcze raz powtarzam: radujcie się!
###### **Flp 4,5**
 Niech będzie znana wszystkim ludziom wasza wyrozumiała łagodność: Pan jest blisko!
###### **Flp 4,6**
 O nic się już nie martwcie, ale w każdej sprawie wasze prośby przedstawiajcie Bogu w modlitwie i błaganiu z dziękczynieniem.
###### **Flp 4,7**
 A pokój Boży, który przewyższa wszelki umysł, będzie strzegł waszych serc i myśli w Chrystusie Jezusie.
###### **Flp 4,8**
 Na koniec, bracia, wszystko, co jest prawdziwe, co godne, co sprawiedliwe, co czyste, co miłe, co zasługuje na uznanie: jeśli jest jakąś cnotą i czynem chwalebnym – to bierzcie pod rozwagę.
###### **Flp 4,9**
 Czyńcie to, czego się nauczyliście, co przejęliście, co usłyszeliście i co zobaczyliście u mnie, a Bóg pokoju będzie z wami.
###### **Flp 4,10**
 Bardzo się też rozradowałem w Panu, że wreszcie rozkwitło wasze staranie o mnie, bo istotnie staraliście się, lecz nie mieliście do tego sposobności.
###### **Flp 4,11**
 Nie mówię tego bynajmniej z powodu niedostatku: ja bowiem nauczyłem się wystarczać sobie w warunkach, w jakich jestem.
###### **Flp 4,12**
 Umiem cierpieć biedę, umiem też korzystać z obfitości. Do wszystkich w ogóle warunków jestem zaprawiony: i być sytym, i głód cierpieć, korzystać z obfitości i doznawać niedostatku.
###### **Flp 4,13**
 Wszystko mogę w Tym, który mnie umacnia.
###### **Flp 4,14**
 W każdym razie dobrze uczyniliście, biorąc udział w moim ucisku.
###### **Flp 4,15**
  Wy, Filipianie, wiecie przecież, że na początku [głoszenia] Ewangelii, gdy opuściłem Macedonię, żaden z Kościołów poza wami jednymi nie prowadził ze mną otwartego rachunku przychodów i rozchodów,
###### **Flp 4,16**
 bo do Tesaloniki nawet raz i drugi przysłaliście na moje potrzeby.
###### **Flp 4,17**
 Mówię zaś to bynajmniej nie dlatego, że pragnę daru, lecz pragnę owocu, który wzrasta na wasze dobro.
###### **Flp 4,18**
 Stwierdzam, że wszystko mam, i to w obfitości: jestem zaopatrzony, otrzymawszy przez Epafrodyta od was wdzięczną woń, ofiarę przyjemną, miłą Bogu.
###### **Flp 4,19**
 A Bóg mój według swego bogactwa zaspokoi wspaniale w Chrystusie Jezusie każdą waszą potrzebę.
###### **Flp 4,20**
 Bogu zaś i Ojcu naszemu chwała na wieki wieków. Amen.
###### **Flp 4,21**
 Pozdrówcie każdego świętego w Chrystusie Jezusie. Pozdrawiają was bracia, którzy są ze mną.
###### **Flp 4,22**
 Pozdrawiają was wszyscy święci, zwłaszcza ci z domu cezara.
###### **Flp 4,23**
 Łaska Pana naszego, Jezusa Chrystusa, [niech będzie] z duchem waszym! Amen.
# Flp 4 PAU
###### **Flp 4,1**
 Tak więc, bracia moi umiłowani i utęsknieni, moja radości i mój wieńcu zwycięstwa, trwajcie w Panu, umiłowani!
###### **Flp 4,2**
 Zachęcam Ewodię i Syntychę, aby były jednomyślne w Panu.
###### **Flp 4,3**
 Proszę także ciebie, szlachetny Syzygu, pomagaj im, gdyż razem ze mną, z Klemensem i pozostałymi moimi współpracownikami, których imiona znajdują się w księdze życia, walczyły w obronie Ewangelii.
###### **Flp 4,4**
 Radujcie się zawsze w Panu! Jeszcze raz mówię: radujcie się!
###### **Flp 4,5**
 Niech wasza łagodność będzie znana wszystkim ludziom. Pan jest blisko.
###### **Flp 4,6**
 O nic się nie martwcie, lecz we wszystkim przedstawiajcie wasze prośby Bogu, modląc się i błagając z dziękczynieniem.
###### **Flp 4,7**
 A pokój Boży, który przewyższa wszelkie poznanie, będzie strzegł waszych serc i myśli w Chrystusie Jezusie.
###### **Flp 4,8**
 W końcu, bracia, miejcie na uwadze wszystko, co jest prawdziwe, co godne czci i sprawiedliwe, co czyste, miłe i szlachetne, wszystko, co jest cnotą i zasługuje na pochwałę.
###### **Flp 4,9**
 Czyńcie to, czego się nauczyliście i co przyjęliście, co usłyszeliście i zobaczyliście we mnie. A Bóg pokoju niech będzie z wami.
###### **Flp 4,10**
 Ucieszyłem się bardzo w Panu, że wreszcie możecie zatroszczyć się o mnie, ponieważ już wcześniej o tym myśleliście, lecz nie mieliście do tego okazji.
###### **Flp 4,11**
 Nie chcę przez to powiedzieć, że cierpię niedostatek, gdyż nauczyłem się zadowalać tym, co mam.
###### **Flp 4,12**
 Umiem żyć biednie i bogato. Potrafię dostosować się do każdej sytuacji: i jeść do syta, i głodować, i żyć bogato, i żyć ubogo.
###### **Flp 4,13**
 Wszystko mogę w Tym, który mnie umacnia.
###### **Flp 4,14**
 Słusznie jednak uczyniliście, że wzięliście udział w moich trudnościach.
###### **Flp 4,15**
 Przecież wy, Filipianie, wiecie, że gdy po opuszczeniu Macedonii zaczynałem głosić Ewangelię, nikt inny tylko wy spośród wszystkich Kościołów uczestniczyliście w moich przychodach i wydatkach.
###### **Flp 4,16**
 Nawet do Tesaloniki kilka razy przysłaliście mi pomoc, gdy byłem w potrzebie.
###### **Flp 4,17**
 Nie znaczy to, że znów szukam wsparcia, lecz chciałbym, aby wasze czyny przyniosły jak największe owoce.
###### **Flp 4,18**
 Teraz bowiem mam wszystko, a nawet więcej, niż potrzebuję. Niczego mi nie brakuje, gdyż otrzymałem od Epafrodyta przesłane przez was dary, które są jak miła woń, jak ofiara życzliwie przyjęta przez Boga.
###### **Flp 4,19**
 A mój Bóg, według swego bogactwa, zaspokoi wszystkie wasze potrzeby, gdy będzie w chwale w Chrystusie Jezusie.
###### **Flp 4,20**
 Naszemu Bogu i Ojcu chwała na wieki wieków. Amen.
###### **Flp 4,21**
 Pozdrówcie każdego świętego w Chrystusie Jezusie. Pozdrawiają was bracia, którzy są ze mną.
###### **Flp 4,22**
 Pozdrawiają was wszyscy święci, a zwłaszcza ci, którzy pochodzą z dworu cesarskiego.
###### **Flp 4,23**
 Łaska Pana Jezusa Chrystusa z duchem waszym. Amen.
# Flp 4 BP
###### **Flp 4,1**
 Przeto, bracia moi umiłowani i utęsknieni, radości moja i chwało, trwajcie niewzruszenie w Panu, ukochani.
###### **Flp 4,2**
 Napominam Ewodię i napominam Syntychę, aby były jednomyślne w Panu.
###### **Flp 4,3**
 Proszę także i ciebie, wierny Sydzygu, wspieraj je, bo trudziły się dla ewangelii razem ze mną, z Klemensem i innymi moimi współpracownikami, których imiona są w księdze życia.
###### **Flp 4,4**
 Radujcie się zawsze w Panu. Powtarzam raz jeszcze: radujcie się.
###### **Flp 4,5**
 Skromność wasza niech będzie znana wszystkim ludziom. Pan jest blisko!
###### **Flp 4,6**
 O nic przesadnie się nie troskajcie, lecz wszystkie wasze potrzeby polecajcie Bogu w modlitwie błagalnej [połączonej] z dziękczynieniem.
###### **Flp 4,7**
 A pokój Boży, który przewyższa wszelki umysł, niech strzeże w Chrystusie Jezusie serc i myśli waszych.
###### **Flp 4,8**
 Wreszcie, bracia, niech myśli wasze zwracają się ku temu wszystkiemu, co prawdziwe, godne, sprawiedliwe, czyste, miłe i chlubne, co cnotliwe i zasługujące na pochwałę.
###### **Flp 4,9**
 Czyńcie to, czegoście się nauczyli, co przyjęliście, coście usłyszeli i zobaczyli u mnie, a Bóg pokoju będzie z wami.
###### **Flp 4,10**
 Bardzo się ucieszyłem w Panu, że znowu rozkwitła wasza miłość w trosce o mnie. Zawsze staraliście się o to, ale nie mieliście ku temu sposobności.
###### **Flp 4,11**
 Nie mówię tego bynajmniej z powodu niedostatku. Nauczyłem się bowiem przestawać na tym, co mam.
###### **Flp 4,12**
 Potrafię żyć w nędzy i umiem żyć w dostatku. Zakosztowałem w życiu wszystkiego: wiem, co znaczy być sytym i głodnym, opływać w dostatki i cierpieć niedostatek.
###### **Flp 4,13**
 Wszystko mogę w tym, który mnie umacnia.
###### **Flp 4,14**
 W każdym razie dobrze uczyniliście, przychodząc mi z pomocą w udręce.
###### **Flp 4,15**
 Sami przecież wiecie, moi Filipianie, że w początkach ewangelizacji, gdy wyszedłem z Macedonii, poza wami żaden [inny] Kościół nie brał udziału w moim rozrachunku: daję - biorę.
###### **Flp 4,16**
 Już nawet do Tesaloniki raz po raz przysyłaliście mi pomoc.
###### **Flp 4,17**
 Wspominam o tym nie po to, żebym pragnął daru, myślę o obfitej zapłacie, jaką zapisano na wasze dobro.
###### **Flp 4,18**
 Teraz bowiem mam wszystko, i to w obfitości: jestem dobrze zapatrzony otrzymawszy od was przez Epafrodyta wdzięczną wonność, ofiarę miłą i podobającą się Bogu.
###### **Flp 4,19**
 Bóg mój wspaniałomyślnie zaspokoi wszelką waszą potrzebę w Chrystusie Jezusie.
###### **Flp 4,20**
 Bogu i Ojcu naszemu chwała na wieki. Amen.
###### **Flp 4,21**
 Pozdrówcie każdego świętego w Chrystusie Jezusie. Pozdrawiają was bracia, którzy są ze mną.
###### **Flp 4,22**
 Pozdrawiają was wszyscy święci, zwłaszcza ci z domu Cezara.
###### **Flp 4,23**
 Łaska Pana Jezusa Chrystusa z wami wszystkimi. Amen.
# Flp 4 BR
###### **Flp 4,1**
 Przeto, umiłowani bracia moi, których tak bardzo chciałbym znów zobaczyć i którzy jesteście dla mnie źródłem radości i chwały, trwajcie niezachwianie w jedności z Panem.
###### **Flp 4,2**
 Wzywam też Ewodię i proszę Syntychę, aby były jednomyślne w Panu.
###### **Flp 4,3**
 Proszę też i ciebie, prawdziwy Syzygu, byś im pomagał, gdyż wspólnie ze mną trudziły się dla Ewangelii, podobnie zresztą jak Klemens i pozostali moi towarzysze pracy, których imiona znajdują się w księdze życia.
###### **Flp 4,4**
 Radujcie się zawsze w Panu, jeszcze raz mówię: radujcie się.
###### **Flp 4,5**
 Niech wszyscy ludzie znają waszą dobroć. Pan jest [już] blisko.
###### **Flp 4,6**
 O nic nie bądźcie zbyt zatroskani, lecz każdą sprawę przedstawiajcie Panu, prosząc usilnie o to, co wam potrzebne, i dziękując [za to, co otrzymacie].
###### **Flp 4,7**
 A pokój Boży, który przewyższa wszystko, co człowiek może zrozumieć, będzie strzegł waszych myśli i serc w ich zjednoczeniu z Jezusem Chrystusem.
###### **Flp 4,8**
 W końcu, bracia, zabiegajcie o to wszystko, co prawdziwe, co godne [chrześcijanina], co sprawiedliwe, co czyste, co [Bogu] miłe i co zasługuje na uznanie; co uchodzi za cnotę i jest czynem godnym chwały.
###### **Flp 4,9**
 Starajcie się wprowadzać w życie to, czego nauczyliście się ode mnie, coście już przejęli, co usłyszeliście i co zobaczyliście u mnie. A Bóg, który jest dawcą pokoju, będzie z wami.
###### **Flp 4,10**
 Ucieszyłem się też wielką radością w Panu, że mieliście wreszcie sposobność okazać wasze staranie o mnie. Wiem bowiem, że byliście o mnie zatroskani, ale dotychczas nie nadarzała się okazja, by mi dać tego dowody.
###### **Flp 4,11**
 Mówię o tym nie dlatego, że czegoś potrzebuję. Nauczyłem się już bowiem poprzestawać na tym, co posiadam.
###### **Flp 4,12**
 Umiem znosić niedostatek, potrafię też żyć jak należy w dostatkach. Umiem pogodzić się ze wszystkim w moim życiu: czy to wtedy, gdy jestem syty, czy wtedy, kiedy głód cierpię, zarówno wtedy, gdy obfituję w dobra zewnętrzne, jak i wtedy, kiedy odczuwam ich brak.
###### **Flp 4,13**
 Mogę wszystko w Tym, który mnie umacnia.
###### **Flp 4,14**
 Ale dobrzeście zrobili, przychodząc mi z pomocą w moich uciskach.
###### **Flp 4,15**
 Wy, Filipianie, wiecie przecież dobrze, że gdy zaczynałem głosić Ewangelię i opuściłem Macedonię, to żadna gmina, prócz was jednych, nie uczestniczyła w moich stratach i zyskach.
###### **Flp 4,16**
 Już kiedy znalazłem się w Tesalonice, raz i drugi przesłaliście mi pomoc, której potrzebowałem.
###### **Flp 4,17**
 Jeżeli mówię o tym teraz, to nie dlatego, że pragnę [znów] jakiegoś materialnego datku, lecz dlatego, że chciałbym dopisać jakby nową pozycję na liście waszych zysków.
###### **Flp 4,18**
 Mnie zaś w tej chwili niczego nie brakuje, owszem, nawet obfituję we wszystko. To, co mi dostarczył Epafrodyt, jest jakby wdzięczna woń [ofiary], dar przyjemny, ze wszech miar miły Bogu.
###### **Flp 4,19**
 [Za to] Bóg mój niezmierzony w swych bogactwach zaspokoi całkowicie każdą waszą potrzebę w Chrystusie Jezusie.
###### **Flp 4,20**
 Bogu, Ojcu naszemu, niech będzie chwała na wieki wieków.Amen.
###### **Flp 4,21**
 Pozdrówcie w Chrystusie Jezusie wszystkich wiernych ludu Bożego. Pozdrawiają was bracia, którzy są ze mną.
###### **Flp 4,22**
 Pozdrawiają was wszyscy wierni, tu obecni, a zwłaszcza ci, co mieszkają w pałacu cesarskim.
###### **Flp 4,23**
 Łaska Pana naszego Jezusa Chrystusa niech będzie z duchem waszym. Amen.
# Flp 4 WUJ
###### **Flp 4,1**
 A tak bracia moi namilszy, i wielce pożądani, wesele moje i korono moja: tak stójcie w Panu, namilszy.
###### **Flp 4,2**
 Ewodjej żądam, i Syntychi proszę, aby toż rozumiały w Panie.
###### **Flp 4,3**
 A proszę i ciebie towarzyszu prawdziwy, pomagaj tym, które w Ewanieljej społu zemną pracowały, z Klementem, i z innemi pomocniki mojemi, których imiona są w księgach żywota.
###### **Flp 4,4**
 Weselcie się zawsze w Panu: powtóre mówię, weselcie się.
###### **Flp 4,5**
 Skromność wasza niech będzie wiadoma wszystkim ludziom. Pan blizko jest.
###### **Flp 4,6**
 Nie troszcież się niócz: ale we wszelkiej modlitwie i prośbie z dziękowaniem niech żądania wasze będą u Boga oznajmione.
###### **Flp 4,7**
 A pokój Boży, który przewyższa wszelki zmysł, niechaj strzeże serc waszych i myśli waszych w Chrystusie Jezusie.
###### **Flp 4,8**
 Na ostatek, bracia, cokolwiek jest prawdziwego, cokolwiek wstydliwego, cokolwiek sprawiedliwego, cokolwiek świętego, cokolwiek przyjemnego, cokolwiek dobrej sławy: jeśli która cnota, jeśli która chwała karności, to obmyślajcie.
###### **Flp 4,9**
 Czegoście się też nauczyli, i przyjęli, i słyszeli, i widzieliście we mnie, to czyńcie: a Bóg pokoju będzie z wami.
###### **Flp 4,10**
 A uweseliłem się wielce w Panu, iżeście wżdy kiedy znowu zakwitnęli starać o mnie: jakoż i staraliście się: aleście zabawieni byli.
###### **Flp 4,11**
 Nie mówię jakoby dla niedostatku. Abowiem nauczyłem się ja przestawać w czemem jest.
###### **Flp 4,12**
 Umiem i uniżać się, umiem i obfitować: (wszędy, i we wszem jestem wyćwiczony) i nasyconym być, łaknąć, i obfitować, i niedostatek cierpieć.
###### **Flp 4,13**
 Wszystko mogę w tym, który mię umacnia.
###### **Flp 4,14**
 Wszakże dobrzeście uczynili, użyczywszy uciskowi mojemu.
###### **Flp 4,15**
 A wiecie i wy Philippensowie, i na początku Ewanieljej, gdym wyszedł z Macedoniej, żaden mi kościół nie spółkował zemną w rachunku, datku, i wziętku, jedno wy sami:
###### **Flp 4,16**
 Ponieważ i do Thessaloniki, raz i dwa posłaliście mi na potrzeby.
###### **Flp 4,17**
 Nie iżbym szukał datku: ale szukam owocu, któryby obfitował na liczbie waszej.
###### **Flp 4,18**
 I mam wszystko, i obfituję: jestem napełnion, wziąwszy od Epaphrodyta coście posłali, wonność wdzięczności, ofiarę przyjemną, Bogu miłą.
###### **Flp 4,19**
 A Bóg mój niechaj napełni wszelkie żądanie wasze według bogactw swoich w chwale, w Chrystusie Jezusie.
###### **Flp 4,20**
 A Bogu i Ojcu naszemu chwała na wieki wieków. Amen.
###### **Flp 4,21**
 Pozdrówcie każdego świętego w Chrystusie Jezusie.
###### **Flp 4,22**
 Pozdrawiają was bracia, którzy są zemną. Pozdrawiają was wszyscy święci: a zwłaszcza, którzy są z Cesarskiego domu.
###### **Flp 4,23**
 Łaska Pana naszego Jezusa Chrystusa z Duchem waszym. Amen.1
# Flp 4 STERN
###### **Flp 4,1**
 A zatem bracia, wy, których kocham i za którymi tęsknię, radości moja i moja korono, drodzy moi przyjaciele, niewzruszenie trwajcie w jedności z Panem.
###### **Flp 4,2**
 Błagam Ewodię i błagam Syntyche, żeby zgadzały się ze sobą w jedności z Panem.
###### **Flp 4,3**
 Proszę też ciebie, wierny Syzygu, abyś pomógł tym kobietom, bo ciężko pracowały, głosząc ze mną Dobrą Nowinę, razem z Klemensem i resztą mych współpracowników, których imiona są w Księdze Życia.
###### **Flp 4,4**
 Radujcie się w jedności z Panem, zawsze! Powtórzę jeszcze raz: radujcie się!
###### **Flp 4,5**
 Niech wszyscy widzą, jak rozsądni i łagodni jesteście. Pan jest blisko!
###### **Flp 4,6**
 Nie martwcie się o nic, przeciwnie, przedstawiajcie wasze prośby Bogu w modlitwie i błaganiu, z dziękczynieniem.
###### **Flp 4,7**
 A wtedy Boży szalom, przechodzący wszelkie zrozumienie, będzie chronił wasze serca i umysły w jedności z Mesjaszem Jeszuą.
###### **Flp 4,8**
 Na koniec, bracia, skupcie myśli na tym, co prawdziwe, szlachetne, sprawiedliwe, czyste, miłe i godne podziwu, na jakiejś cnocie lub na czymś godnym pochwały.
###### **Flp 4,9**
 Czyńcie wytrwale to, czegoście się ode mnie nauczyli, co słyszeliście i widzieliście, że robię, a wtedy Bóg, który daje szalom, będzie z wami.
###### **Flp 4,10**
 W jedności z Panem wielce się raduję, że teraz, po tak długim czasie, daliście znowu wyraz swojej trosce o mnie. Oczywiście martwiliście się o mnie cały czas, ale nie mieliście okazji, żeby to okazać.
###### **Flp 4,11**
 Mówię to nie po to, aby zwrócić wam uwagę na jakąś swoją potrzebę, bo jeśli o mnie idzie, nauczyłem się być zadowolonym w każdych okolicznościach.
###### **Flp 4,12**
 Wiem, co to znaczy cierpieć nędzę, i wiem, co to znaczy mieć więcej niż potrzeba - we wszystkim i pod każdym względem poznałem sekret bycia sytym i bycia głodnym, obfitowania i cierpienia niedostatku.
###### **Flp 4,13**
 Mogę wszystko przez Tego, który daje mi moc.
###### **Flp 4,14**
 Ale to miło z waszej strony, że uczestniczycie w moim ucisku.
###### **Flp 4,15**
 Wy, Filipianie, sami wiecie, że w początkach mojej działalności - szerzenia Dobrej Nowiny - kiedy opuściłem Macedonię, żadne zgromadzenie nie miało ze mną udziału w dawaniu i otrzymywaniu - jedynie wy.
###### **Flp 4,16**
 Bo rzeczywiście w Tesalonice, kiedy potrzebowałem, dwa razy posłaliście mi pomoc.
###### **Flp 4,17**
 Nie domagam się tego daru, lecz raczej staram się o to, co zostanie dopisane do rachunku na waszym koncie.
###### **Flp 4,18**
 Zapłacono mi więcej niż pełną miarę - zostałem nasycony, bo otrzymałem od Epafrodyta dary, które posłaliście - są one aromatyczną wonią, miłą ofiarą, taką, w której Bóg ma upodobanie.
###### **Flp 4,19**
 Ponadto mój Bóg zaspokoi każdą waszą potrzebę według swego chwalebnego bogactwa, w jedności z Mesjaszem Jeszuą.
###### **Flp 4,20**
 A Bogu, naszemu Ojcu, niech będzie chwała na wieki wieków. Amen.
###### **Flp 4,21**
 Pozdrówcie każdego spośród ludu Bożego w Mesjaszu Jeszui. Bracia, którzy są ze mną, przesyłają wam pozdrowienia.
###### **Flp 4,22**
 Cały lud Boży śle pozdrowienia, zwłaszcza zaś ci z domu cesarskiego.
###### **Flp 4,23**
 Łaska Pana Jeszui Mesjasza niech będzie z duchem waszym.1
# Flp 4 TRO
###### **Flp 4,1**
 **ωστε** *hōste* Tak, że [[G5620]] [[CONJ]] **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **μου** *mou* moi [[G3450]] WTP-1GS **αγαπητοι** *agapētoi* umiłowani [[G27]] WTA-NPM **και** *kai* i [[G2532]] [[CONJ]] **επιποθητοι** *epipothētoi* wytęsknieni – upragnieni [[G1973]] WTA-NPM **χαρα** *chara* radość [[G5479]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **στεφανος** *stefanos* wieniec – korona [[G4735]] [[N-NSM]] **μου** *mou* mój [[G3450]] WTP-1GS **ουτως** *houtōs* tak [[G3779]] [[ADV]] **στηκετε** *stēkete* stójcie – trwajcie [[G4739]] WTV-PAM-2P **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **αγαπητοι** *agapētoi* umiłowani [[G27]] WTA-VPM
###### **Flp 4,2**
 **ευοδιαν** *euodian* Ewodię – [dobra droga] [[G2136]] WTN-ASF **παρακαλω** *parakalō* zachęcam [[G3870]] WTV-PAI-1S **και** *kai* i [[G2532]] [[CONJ]] **συντυχην** *syntychēn* Syntychę – [powodzenie] [[G4941]] WTN-ASF **παρακαλω** *parakalō* zachęcam [[G3870]] WTV-PAI-1S **το** *to* [[G3588]] WTT-ASN **αυτο** *auto* to samo [[G846]] WTP-ASN **φρονειν** *fronein* myśleć – rozumieć [[G5426]] WTV-PAN **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM
###### **Flp 4,3**
 **και** *kai* A [[G2532]] [[CONJ]] **ερωτω** *erōtō* proszę [[G2065]] WTV-PAI-1S **και** *kai* i [[G2532]] [[CONJ]] **σε** *se* ciebie [[G4571]] WTP-2AS **συζυγε** *syzyge* będący we wspólnym jarzmie [[G4805]] WTA-VSM **γνησιε** *gnēsie* szczery – prawowity [[G1103]] WTA-VSM **συλλαμβανου** *syllambanou* pomagaj [[G4815]] WTV-PMM-2S **αυταις** *autais* im [[G846]] WTP-DPF **αιτινες** *haitines* które [[G3748]] WTR-NPF **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **ευαγγελιω** *euangeliō* dobrej nowinie [[G2098]] WTN-DSN **συνηθλησαν** *synēthlēsan* walczyły razem ze [[G4866]] WTV-AAI-3P **μοι** *moi* mną [[G3427]] WTP-1DS **μετα** *meta* z [[G3326]] [[PREP]] **και** *kai* i [[G2532]] [[CONJ]] **κλημεντος** *klēmentos* Klemensem – [człowiek o łagodnym usposobieniu] [[G2815]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPM **λοιπων** *loipōn* pozostałymi [[G3062]] WTA-GPM **συνεργων** *synergōn* współpracownikami [[G4904]] WTA-GPM **μου** *mou* moimi [[G3450]] WTP-1GS **ων** *hōn* których [[G3739]] WTR-GPM **τα** *ta* [[G3588]] WTT-NPN **ονοματα** *onomata* imiona [[G3686]] WTN-NPN **εν** *en* w [[G1722]] [[PREP]] **βιβλω** *biblō* zwoju – księdze [[G976]] [[N-DSF]] **ζωης** *zōēs* życia [[G2222]] [[N-GSF]]
###### **Flp 4,4**
 **χαιρετε** *chairete* Radujcie się – Cieszcie się [[G5463]] WTV-PAM-2P **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **παντοτε** *pantote* zawsze – każdej chwili [[G3842]] [[ADV]] **παλιν** *palin* znowu [[G3825]] [[ADV]] **ερω** *erō* powiem [[G2046]] WTV-FAI-1S **χαιρετε** *chairete* radujcie się – cieszcie się [[G5463]] WTV-PAM-2P
###### **Flp 4,5**
 **το** *to* [[G3588]] WTT-NSN **επιεικες** *epieikes* Życzliwość – Uprzejmość [[G1933]] WTA-NSN **υμων** *hymōn* wasza [[G5216]] WTP-2GP **γνωσθητω** *gnōsthētō* niech zostanie poznana – niech da się poznać [[G1097]] WTV-APM-3S **πασιν** *pasin* wszystkim [[G3956]] WTA-DPM **ανθρωποις** *anthrōpois* ludziom [[G444]] WTN-DPM **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **εγγυς** *engys* blisko [[G1451]] [[ADV]]
###### **Flp 4,6**
 **μηδεν** *mēden* Nic [[G3367]] WTA-ASN **μεριμνατε** *merimnate* martwcie się – troszczcie się [[G3309]] WTV-PAM-2P **αλλ** *all* ale [[G235]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **παντι** *panti* każdej [[G3956]] WTA-DSN **τη** *tē* [[G3588]] WTT-DSF **προσευχη** *proseuchē* modlitwie [[G4335]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **τη** *tē* [[G3588]] WTT-DSF **δεησει** *deēsei* prośbie [[G1162]] [[N-DSF]] **μετα** *meta* z [[G3326]] [[PREP]] **ευχαριστιας** *eucharistias* dziękczynieniem – wdzięcznością [[G2169]] [[N-GSF]] **τα** *ta* [[G3588]] WTT-APN **αιτηματα** *aitēmata* prośby [[G155]] WTN-APN **υμων** *hymōn* wasze [[G5216]] WTP-2GP **γνωριζεσθω** *gnōrizesthō* niech jest poznane (niech są poznane) [[G1107]] WTV-PPM-3S **προς** *pros* u [[G4314]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **θεον** *theon* Boga [[G2316]] [[N-ASM]]
###### **Flp 4,7**
 **και** *kai* A [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **ειρηνη** *eirēnē* pokój [[G1515]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **η** *hē* [[G3588]] [[T-NSF]] **υπερεχουσα** *hyperechousa* przewyższający – górujący nad [[G5242]] [[V-PAP-NSF]] **παντα** *panta* wszelki [[G3956]] WTA-ASM **νουν** *noun* umysł – rozum [[G3563]] [[N-ASM]] **φρουρησει** *frourēsei* będzie pilnował [[G5432]] WTV-FAI-3S **τας** *tas* [[G3588]] WTT-APF **καρδιας** *kardias* serc [[G2588]] WTN-APF **υμων** *hymōn* waszych [[G5216]] WTP-2GP **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **νοηματα** *noēmata* myśli – pomyśleń [[G3540]] WTN-APN **υμων** *hymōn* waszych [[G5216]] WTP-2GP **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM
###### **Flp 4,8**
 **το** *to* [[G3588]] WTT-NSN **λοιπον** *loipon* W końcu [[G3063]] WTA-NSN **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **οσα** *hosa* ile [[G3745]] WTK-NPN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **αληθη** *alēthē* prawdziwe – szczere [[G227]] WTA-NPN **οσα** *hosa* ile [[G3745]] WTK-NPN **σεμνα** *semna* szlachetne – szanowne [[G4586]] WTA-NPN **οσα** *hosa* ile [[G3745]] WTK-NPN **δικαια** *dikaia* sprawiedliwe [[G1342]] WTA-NPN **οσα** *hosa* ilu [[G3745]] WTK-NPN **αγνα** *hagna* czyste – nieskalane [[G53]] WTA-NPN **οσα** *hosa* ile [[G3745]] WTK-NPN **προσφιλη** *prosfilē* miłe – przyjazne [[G4375]] WTA-NPN **οσα** *hosa* ile [[G3745]] WTK-NPN **ευφημα** *eufēma* godne polecenia – przychylne [[G2163]] WTA-NPN **ει** *ei* jeśli [[G1487]] WTCOND **τις** *tis* coś [[G5100]] WTX-NSF **αρετη** *aretē* cnota [[G703]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **ει** *ei* jeśli [[G1487]] WTCOND **τις** *tis* coś [[G5100]] WTX-NSM **επαινος** *epainos* pochwała [[G1868]] [[N-NSM]] **ταυτα** *tauta* te [[G5023]] WTD-APN **λογιζεσθε** *logizesthe* rozsądzajcie – liczcie sobie [[G3049]] WTV-PNM-2P
###### **Flp 4,9**
 **α** *ha* Co [[G3739]] WTR-APN **και** *kai* i [[G2532]] [[CONJ]] **εμαθετε** *emathete* nauczyliście się [[G3129]] WTV-2AAI-2P **και** *kai* i [[G2532]] [[CONJ]] **παρελαβετε** *parelabete* przyjęliście [[G3880]] WTV-2AAI-2P **και** *kai* i [[G2532]] [[CONJ]] **ηκουσατε** *ēkousate* usłyszeliście [[G191]] WTV-AAI-2P **και** *kai* i [[G2532]] [[CONJ]] **ειδετε** *eidete* zobaczyliście [[G1492]] WTV-2AAI-2P **εν** *en* we [[G1722]] [[PREP]] **εμοι** *emoi* mnie [[G1698]] WTP-1DS **ταυτα** *tauta* te [[G5023]] WTD-APN **πρασσετε** *prassete* robicie – czynicie [[G4238]] WTV-PAI-2P **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **της** *tēs* [[G3588]] [[T-GSF]] **ειρηνης** *eirēnēs* pokoju [[G1515]] [[N-GSF]] **εσται** *estai* będzie [[G2071]] WTV-FXI-3S **μεθ** *meth* z [[G3326]] [[PREP]] **υμων** *hymōn* wami [[G5216]] WTP-2GP
###### **Flp 4,10**
 **εχαρην** *echarēn* Uradowałem się – Ucieszyłem się [[G5463]] WTV-2AOI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **μεγαλως** *megalōs* niezmiernie – wielce [[G3171]] [[ADV]] **οτι** *hoti* że [[G3754]] [[CONJ]] **ηδη** *ēdē* już [[G2235]] [[ADV]] **ποτε** *pote* niegdyś – kiedyś [[G4218]] WTPRT **ανεθαλετε** *anethalete* rozkwitliście – rozwinęliście [[G330]] WTV-2AAI-2P **το** *to* (to) [[G3588]] WTT-ASN **υπερ** *hyper* o [[G5228]] [[PREP]] **εμου** *emou* mnie [[G1700]] WTP-1GS **φρονειν** *fronein* myśleć – rozumieć [[G5426]] WTV-PAN **εφ** *ef* nad [[G1909]] [[PREP]] **ω** *hō* którym [[G3739]] WTR-DSN **και** *kai* i [[G2532]] [[CONJ]] **εφρονειτε** *efroneite* myśleliście – rozumieliście [[G5426]] WTV-IAI-2P **ηκαιρεισθε** *ēkaireisthe* nie mieliście sposobności [[G170]] WTV-INI-2P **δε** *de* zaś [[G1161]] [[CONJ]]
###### **Flp 4,11**
 **ουχ** *ouch* Nie [[G3756]] [[PRT-N]] **οτι** *hoti* że [[G3754]] [[CONJ]] **καθ** *kath* z [[G2596]] [[PREP]] **υστερησιν** *hysterēsin* niedostatku – braku [[G5304]] WTN-ASF **λεγω** *legō* mówię [[G3004]] WTV-PAI-1S **εγω** *egō* ja [[G1473]] WTP-1NS **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εμαθον** *emathon* nauczyłem się [[G3129]] WTV-2AAI-1S **εν** *en* w [[G1722]] [[PREP]] **οις** *hois* czym [[G3739]] WTR-DPM **ειμι** *eimi* jestem [[G1510]] WTV-PXI-1S **αυταρκης** *autarkēs* zadowolony – samowystarczalny [[G842]] [[A-NSM]] **ειναι** *einai* być [[G1511]] WTV-PXN
###### **Flp 4,12**
 **οιδα** *oida* Wiem (jak) – Umiem [[G1492]] WTV-RAI-1S **και** *kai* i [[G2532]] [[CONJ]] **ταπεινουσθαι** *tapeinousthai* być poniżonym – być uniżonym [[G5013]] WTV-PPN **οιδα** *oida* wiem (jak) – umiem [[G1492]] WTV-RAI-1S **και** *kai* i [[G2532]] [[CONJ]] **περισσευειν** *perisseuein* obfitować [[G4052]] WTV-PAN **εν** *en* w [[G1722]] [[PREP]] **παντι** *panti* każdym [[G3956]] WTA-DSM **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* we [[G1722]] [[PREP]] **πασιν** *pasin* wszystkich [[G3956]] WTA-DPM **μεμυημαι** *memyēmai* jestem wtajemniczony [[G3453]] WTV-RPI-1S **και** *kai* i [[G2532]] [[CONJ]] **χορταζεσθαι** *chortazesthai* być nasycany pokarmem [[G5526]] WTV-PPN **και** *kai* i [[G2532]] [[CONJ]] **πειναν** *peinan* głodować – łaknąć [[G3983]] WTV-PAN **και** *kai* i [[G2532]] [[CONJ]] **περισσευειν** *perisseuein* obfitować [[G4052]] WTV-PAN **και** *kai* i [[G2532]] [[CONJ]] **υστερεισθαι** *hystereisthai* być w niedostatku [[G5302]] WTV-PPN
###### **Flp 4,13**
 **παντα** *panta* Wszystkie [[G3956]] WTA-APN **ισχυω** *ischyō* mogę – jestem silny [[G2480]] WTV-PAI-1S **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* (Tym) [[G3588]] WTT-DSM **ενδυναμουντι** *endynamounti* umacniającym – napełniającym mocą [[G1743]] WTV-PAP-DSM **με** *me* mnie [[G3165]] WTP-1AS **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM
###### **Flp 4,14**
 **πλην** *plēn* Jednakże [[G4133]] [[ADV]] **καλως** *kalōs* dobrze – pięknie [[G2573]] [[ADV]] **εποιησατε** *epoiēsate* uczyniliście [[G4160]] WTV-AAI-2P **συγκοινωνησαντες** *sygkoinōnēsantes* stawszy się współuczestnikami [[G4790]] WTV-AAP-NPM **μου** *mou* mojego [[G3450]] WTP-1GS **τη** *tē* [[G3588]] WTT-DSF **θλιψει** *thlipsei* ucisku – utrapienia [[G2347]] [[N-DSF]]
###### **Flp 4,15**
 **οιδατε** *oidate* Wiecie [[G1492]] WTV-RAI-2P **δε** *de* zaś [[G1161]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **φιλιππησιοι** *filippēsioi* Filipianie – [miłujący konie] [[G5374]] WTN-VPM **οτι** *hoti* że [[G3754]] [[CONJ]] **εν** *en* na [[G1722]] [[PREP]] **αρχη** *archē* początku [[G746]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSN **ευαγγελιου** *euangeliou* dobrej nowiny [[G2098]] [[N-GSN]] **οτε** *hote* gdy [[G3753]] [[ADV]] **εξηλθον** *eksēlthon* wyszedłem [[G1831]] WTV-2AAI-1S **απο** *apo* z [[G575]] [[PREP]] **μακεδονιας** *makedonias* Macedonii [[G3109]] [[N-GSF]] **ουδεμια** *oudemia* żadne [[G3762]] WTA-NSF **μοι** *moi* mi [[G3427]] WTP-1DS **εκκλησια** *ekklēsia* zgromadzenie – (społeczność) wywołanych [[G1577]] [[N-NSF]] **εκοινωνησεν** *ekoinōnēsen* stała się wspólnikiem [[G2841]] [[V-AAI-3S]] **εις** *eis* w [[G1519]] [[PREP]] **λογον** *logon* rachunku – słowie [[G3056]] [[N-ASM]] **δοσεως** *doseōs* rozchodu – dania [[G1394]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **ληψεως** *lēpseōs* przychodu – wzięcia [[G3028]] [[N-GSF]] **ει** *ei* jeśli [[G1487]] WTCOND **μη** *mē* nie [[G3361]] [[PRT-N]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **μονοι** *monoi* jedyni [[G3441]] WTA-NPM
###### **Flp 4,16**
 **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **θεσσαλονικη** *thessalonikē* Tesalonice [[G2332]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **απαξ** *hapaks* raz [[G530]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **δις** *dis* dwukrotnie [[G1364]] [[ADV]] **εις** *eis* na [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **χρειαν** *chreian* potrzebę [[G5532]] WTN-ASF **μοι** *moi* mi [[G3427]] WTP-1DS **επεμψατε** *epempsate* posłaliście [[G3992]] WTV-AAI-2P
###### **Flp 4,17**
 **ουχ** *ouch* Nie [[G3756]] [[PRT-N]] **οτι** *hoti* że [[G3754]] [[CONJ]] **επιζητω** *epizētō* poszukuję [[G1934]] WTV-PAI-1S **το** *to* [[G3588]] WTT-ASN **δομα** *doma* daru [[G1390]] WTN-ASN **αλλ** *all* ale [[G235]] [[CONJ]] **επιζητω** *epizētō* poszukuję [[G1934]] WTV-PAI-1S **τον** *ton* [[G3588]] [[T-ASM]] **καρπον** *karpon* owocu [[G2590]] [[N-ASM]] **τον** *ton* [[G3588]] [[T-ASM]] **πλεοναζοντα** *pleonazonta* rosnącego – obfitującego [[G4121]] WTV-PAP-ASM **εις** *eis* na [[G1519]] [[PREP]] **λογον** *logon* rachunku [[G3056]] [[N-ASM]] **υμων** *hymōn* waszym [[G5216]] WTP-2GP
###### **Flp 4,18**
 **απεχω** *apechō* Otrzymuję [[G568]] WTV-PAI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **παντα** *panta* wszystkie [[G3956]] WTA-APN **και** *kai* i [[G2532]] [[CONJ]] **περισσευω** *perisseuō* obfituję [[G4052]] WTV-PAI-1S **πεπληρωμαι** *peplērōmai* jestem wypełniony – jestem zaopatrzony [[G4137]] WTV-RPI-1S **δεξαμενος** *deksamenos* przyjąwszy [[G1209]] WTV-ADP-NSM **παρα** *para* od [[G3844]] [[PREP]] **επαφροδιτου** *epafroditou* Epafrodyta – [uroczy] [[G1891]] [[N-GSM]] **τα** *ta* (tę) [[G3588]] WTT-APN **παρ** *par* od [[G3844]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **οσμην** *osmēn* woń [[G3744]] WTN-ASF **ευωδιας** *euōdias* aromatu – słodkiego zapachu [[G2175]] [[N-GSF]] **θυσιαν** *thysian* ofiarę [[G2378]] WTN-ASF **δεκτην** *dektēn* przychylną – godną przyjęcia [[G1184]] WTA-ASF **ευαρεστον** *euareston* bardzo podobającą się [[G2101]] WTA-ASF **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM
###### **Flp 4,19**
 **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **μου** *mou* mój [[G3450]] WTP-1GS **πληρωσει** *plērōsei* wypełni [[G4137]] WTV-FAI-3S **πασαν** *pasan* każdą [[G3956]] WTA-ASF **χρειαν** *chreian* potrzebę [[G5532]] WTN-ASF **υμων** *hymōn* waszą [[G5216]] WTP-2GP **κατα** *kata* według [[G2596]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **πλουτον** *plouton* bogactwa [[G4149]] [[N-ASM]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **εν** *en* w [[G1722]] [[PREP]] **δοξη** *doksē* chwale [[G1391]] [[N-DSF]] **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM
###### **Flp 4,20**
 **τω** *tō* [[G3588]] WTT-DSM **δε** *de* zaś [[G1161]] [[CONJ]] **θεω** *theō* Bogu [[G2316]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **πατρι** *patri* Ojcu [[G3962]] WTN-DSM **ημων** *hēmōn* naszemu [[G2257]] WTP-1GP **η** *hē* [[G3588]] [[T-NSF]] **δοξα** *doksa* chwała [[G1391]] [[N-NSF]] **εις** *eis* na [[G1519]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **αιωνας** *aiōnas* wieki [[G165]] [[N-APM]] **των** *tōn* [[G3588]] WTT-GPM **αιωνων** *aiōnōn* wieków [[G165]] WTN-GPM **αμην** *amēn* amen – [zaprawdę] [[G281]] WTHEB
###### **Flp 4,21**
 **ασπασασθε** *aspasasthe* Pozdrówcie [[G782]] WTV-ADM-2P **παντα** *panta* każdego [[G3956]] WTA-ASM **αγιον** *hagion* świętego [[G40]] WTA-ASM **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM **ασπαζονται** *aspazontai* pozdrawiają [[G782]] WTV-PNI-3P **υμας** *hymas* was [[G5209]] WTP-2AP **οι** *hoi* (ci) [[G3588]] WTT-NPM **συν** *syn* razem ze [[G4862]] [[PREP]] **εμοι** *emoi* mną [[G1698]] WTP-1DS **αδελφοι** *adelfoi* bracia [[G80]] WTN-NPM
###### **Flp 4,22**
 **ασπαζονται** *aspazontai* Pozdrawiają [[G782]] WTV-PNI-3P **υμας** *hymas* was [[G5209]] WTP-2AP **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **οι** *hoi* [[G3588]] WTT-NPM **αγιοι** *hagioi* święci [[G40]] WTA-NPM **μαλιστα** *malista* najbardziej [[G3122]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **οι** *hoi* (ci) [[G3588]] WTT-NPM **εκ** *ek* z [[G1537]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **καισαρος** *kaisaros* Cezara [[G2541]] [[N-GSM]] **οικιας** *oikias* domu [[G3614]] [[N-GSF]]
###### **Flp 4,23**
 **η** *hē* [[G3588]] [[T-NSF]] **χαρις** *charis* Łaska [[G5485]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **μετα** *meta* z [[G3326]] [[PREP]] **παντων** *pantōn* wszystkimi [[G3956]] WTA-GPM **υμων** *hymōn* wami [[G5216]] WTP-2GP **αμην** *amēn* amen – [zaprawdę] [[G281]] WTHEB **προς** *pros* do [[G4314]] [[PREP]] **φιλιππησιους** *filippēsious* Filipian – [miłujący konie] [[G5374]] [[N-APM]] **εγραφη** *egrafē* zostało napisane [[G1125]] WTV-2API-3S **απο** *apo* z [[G575]] [[PREP]] **ρωμης** *rōmēs* Rzymu [[G4516]] [[N-GSF]] **δι** *di* przez [[G1223]] [[PREP]] **επαφροδιτου** *epafroditou* Epafrodyta – [uroczy] [[G1891]] [[N-GSM]]
