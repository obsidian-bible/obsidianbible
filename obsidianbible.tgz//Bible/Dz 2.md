# Dz 2 BT5
###### **Dz 2,1**
 Kiedy nadszedł wreszcie dzień Pięćdziesiątnicy, znajdowali się wszyscy razem na tym samym miejscu.
###### **Dz 2,2**
 Nagle dał się słyszeć z nieba szum, jakby uderzenie gwałtownego wichru, i napełnił cały dom, w którym przebywali.
###### **Dz 2,3**
 Ukazały się im też jakby języki ognia, które się rozdzielały, i na każdym z nich spoczął [jeden].
###### **Dz 2,4**
 I wszyscy zostali napełnieni Duchem Świętym, i zaczęli mówić obcymi językami, tak jak im Duch pozwalał mówić.
###### **Dz 2,5**
 Przebywali wtedy w Jeruzalem pobożni Żydzi ze wszystkich narodów pod słońcem.
###### **Dz 2,6**
 Kiedy więc powstał ów szum, zbiegli się tłumnie i zdumieli, bo każdy słyszał, jak [tamci] przemawiali w jego własnym języku.
###### **Dz 2,7**
 «***Czyż ci wszyscy, którzy przemawiają, nie są Galilejczykami?***» – mówili pełni zdumienia i podziwu.
###### **Dz 2,8**
 «***Jakżeż więc każdy z nas słyszy swój własny język ojczysty? –***
###### **Dz 2,9**
  ***Partowie i Medowie, i Elamici, i mieszkańcy Mezopotamii, Judei oraz Kapadocji, Pontu i Azji,***
###### **Dz 2,10**
 ***Frygii oraz Pamfilii, Egiptu i tych części Libii, które leżą blisko Cyreny, i przybysze z Rzymu,***
###### **Dz 2,11**
 ***Żydzi oraz prozelici, Kreteńczycy i Arabowie – słyszymy ich głoszących w naszych językach wielkie dzieła Boże***».
###### **Dz 2,12**
 Zdumiewali się wszyscy i nie wiedzieli, co myśleć: «***Co to ma znaczyć?***» – mówili jeden do drugiego.
###### **Dz 2,13**
 «***Upili się młodym winem***» – drwili inni.
###### **Dz 2,14**
 Wtedy stanął Piotr razem z Jedenastoma i przemówił do nich donośnym głosem: «***Mężowie Judejczycy i wszyscy mieszkańcy Jeruzalem, przyjmijcie do wiadomości i posłuchajcie uważnie mych słów!***
###### **Dz 2,15**
 ***Ci ludzie nie są pijani, jak przypuszczacie, bo jest dopiero trzecia godzina dnia,***
###### **Dz 2,16**
 ***ale spełnia się właśnie to, co powiedział prorok Joel:***
###### **Dz 2,17**
  ***W ostatnich dniach – mówi Bóg – wyleję Ducha mojego na wszelkie ciało, i będą prorokować synowie wasi i córki wasze, młodzieńcy wasi widzenia mieć będą, a starcy – sny.***
###### **Dz 2,18**
 ***Nawet na niewolników i niewolnice moje wyleję w owych dniach Ducha mego, i będą prorokowali.***
###### **Dz 2,19**
 ***I sprawię dziwy na górze – na niebie, i znaki na dole – na ziemi. Krew i ogień, i kłęby dymu,***
###### **Dz 2,20**
 ***słońce zamieni się w ciemności, a księżyc w krew, zanim nadejdzie dzień Pański, wielki i wspaniały.***
###### **Dz 2,21**
 ***Każdy, kto wzywać będzie imienia Pańskiego, będzie zbawiony.***
###### **Dz 2,22**
  ***Mężowie izraelscy, słuchajcie tego, co mówię: Jezusa Nazarejczyka, Męża, którego posłannictwo Bóg potwierdził wam niezwykłymi czynami, cudami i znakami, jakich Bóg przez Niego dokonał wśród was, o czym sami wiecie,***
###### **Dz 2,23**
 ***tego Męża, który z woli, postanowienia i przewidzenia Boga został wydany, przybiliście rękami bezbożnych do krzyża i zabiliście.***
###### **Dz 2,24**
 ***Lecz Bóg wskrzesił Go, zerwawszy więzy śmierci, gdyż niemożliwe było, aby ona panowała nad Nim, bo Dawid mówi o Nim:***
###### **Dz 2,25**
  ***Miałem Pana zawsze przed oczami, gdyż stoi po mojej prawicy, abym się nie zachwiał.***
###### **Dz 2,26**
 ***Dlatego ucieszyło się moje serce i rozradował się mój język, także i moje ciało spoczywać będzie w nadziei,***
###### **Dz 2,27**
 ***że nie zostawisz duszy mojej w Otchłani ani nie dasz Świętemu Twemu ulec rozkładowi.***
###### **Dz 2,28**
 ***Dałeś mi poznać drogi życia i napełnisz mnie radością przed obliczem Twoim.***
###### **Dz 2,29**
 ***Bracia, wolno powiedzieć do was otwarcie, że patriarcha Dawid umarł i został pochowany w grobie, który znajduje się u nas aż po dzień dzisiejszy.***
###### **Dz 2,30**
 ***Więc jako prorok, który wiedział, że Bóg przysiągł mu uroczyście, iż jego Potomek zasiądzie na jego tronie,***
###### **Dz 2,31**
 ***widział przyszłość i przepowiedział zmartwychwstanie Mesjasza, że ani nie pozostanie w Otchłani, ani ciało Jego nie ulegnie rozkładowi.***
###### **Dz 2,32**
 ***Tego właśnie Jezusa wskrzesił Bóg, a my wszyscy jesteśmy tego świadkami.***
###### **Dz 2,33**
 ***Wyniesiony na miejsce po prawicy Boga, otrzymał od Ojca obietnicę Ducha Świętego i zesłał Go,***
###### **Dz 2,34**
 ***jak to sami widzicie i słyszycie. Bo Dawid nie wstąpił do nieba, a jednak powiada: Rzekł Pan do Pana mego: Siądź po prawicy mojej,***
###### **Dz 2,35**
 ***aż położę nieprzyjaciół Twoich jako podnóżek stóp Twoich.***
###### **Dz 2,36**
 ***Niech więc cały dom Izraela wie z niewzruszoną pewnością, że tego Jezusa, którego ukrzyżowaliście, uczynił Bóg i Panem, i Mesjaszem***».
###### **Dz 2,37**
 Gdy to usłyszeli, przejęli się do głębi serca: «***Cóż mamy czynić, bracia?***» – zapytali Piotra i pozostałych Apostołów.
###### **Dz 2,38**
 «***Nawróćcie się***» – powiedział do nich Piotr – «***i niech każdy z was przyjmie chrzest w imię Jezusa Chrystusa na odpuszczenie grzechów waszych, a otrzymacie w darze Ducha Świętego.***
###### **Dz 2,39**
 ***Bo dla was jest obietnica i dla dzieci waszych, i dla wszystkich, którzy są daleko, a których Pan, Bóg nasz, powoła***».
###### **Dz 2,40**
 W wielu też innych słowach dawał świadectwo i napominał: «***Ratujcie się spośród tego przewrotnego pokolenia!***»
###### **Dz 2,41**
 Ci więc, którzy przyjęli jego naukę, zostali ochrzczeni. I przyłączyło się owego dnia około trzech tysięcy dusz.
###### **Dz 2,42**
 Trwali oni w nauce Apostołów i we wspólnocie, w łamaniu chleba i w modlitwach.
###### **Dz 2,43**
 Bojaźń ogarniała każdego, gdyż Apostołowie czynili wiele znaków i cudów.
###### **Dz 2,44**
 Ci wszyscy, którzy uwierzyli, przebywali razem i wszystko mieli wspólne.
###### **Dz 2,45**
 Sprzedawali majątki i dobra i rozdzielali je każdemu według potrzeby.
###### **Dz 2,46**
 Codziennie trwali jednomyślnie w świątyni, a łamiąc chleb po domach, spożywali posiłek w radości i prostocie serca.
###### **Dz 2,47**
 Wielbili Boga, a cały lud odnosił się do nich życzliwie. Pan zaś przymnażał im codziennie tych, którzy dostępowali zbawienia.

# Dz 2 PAU
###### **Dz 2,1**
 Kiedy nadszedł dzień Pięćdziesiątnicy, byli wszyscy w tym samym miejscu.
###### **Dz 2,2**
 Nagle rozległ się szum z nieba, jakby gwałtownie wiejącego wiatru. I napełnił cały dom, w którym przebywali.
###### **Dz 2,3**
 Zobaczyli też języki podobne do ognia. Rozdzielały się one i na każdym z nich spoczął jeden.
###### **Dz 2,4**
 Wszystkich napełnił Duch Święty. Zaczęli mówić różnymi językami, tak jak im Duch pozwalał się wypowiadać.
###### **Dz 2,5**
 Przebywali wtedy w Jeruzalem mieszkańcy Judei i pobożni Żydzi ze wszystkich krajów świata.
###### **Dz 2,6**
 Kiedy usłyszeli ten szum, zebrali się tłumnie. Zdumieli się, gdyż każdy z nich słyszał, że przemawiają jego własną mową.
###### **Dz 2,7**
 Dziwiąc się temu bardzo, mówili: „Czyż ci wszyscy, którzy przemawiają, nie są Galilejczykami?
###### **Dz 2,8**
 Jak to więc możliwe, że każdy z nas słyszy swą ojczystą mowę?
###### **Dz 2,9**
 Są tu Partowie, Medowie, Elamici, mieszkańcy Mezopotamii, Judei, Kapadocji, Pontu, Azji,
###### **Dz 2,10**
 Frygii, Pamfilii, Egiptu, części Libii położonej w pobliżu Cyreny i przybysze z Rzymu.
###### **Dz 2,11**
 Są Żydzi oraz prozelici, Kreteńczycy oraz Arabowie, a słyszymy, jak w naszych językach mówią o wielkich dziełach Boga”.
###### **Dz 2,12**
 Wszyscy byli tym zaskoczeni i nie wiedzieli, co myśleć. Dlatego pytali jeden drugiego: „Co to znaczy?”.
###### **Dz 2,13**
 Inni jednak drwili, mówiąc: „Upili się młodym winem”.
###### **Dz 2,14**
 Wtedy wystąpił Piotr w otoczeniu Jedenastu. Donośnym głosem powiedział: „Judejczycy i wszyscy mieszkańcy Jeruzalem! Posłuchajcie uważnie, co wam powiem.
###### **Dz 2,15**
 Ci ludzie nie są wcale pijani, jak sądzicie. Jest dopiero trzecia godzina dnia.
###### **Dz 2,16**
 Ale spełnia się właśnie zapowiedź proroka Joela.
###### **Dz 2,17**
 Tak mówi Bóg: W dniach ostatecznych wyleję mojego Ducha na każde stworzenie. I będą prorokować wasi synowie i wasze córki, młodzieńcy wasi będą mieć widzenia, a starcy - sny.
###### **Dz 2,18**
 Także na moje sługi i na moje służebnice w tych dniach wyleję mojego Ducha i będą prorokować.
###### **Dz 2,19**
 Uczynię cuda wysoko - na niebie i znaki nisko - na ziemi: krew, ogień i słupy dymu.
###### **Dz 2,20**
 Słońce zmieni się w ciemność, a księżyc w krew, zanim nadejdzie Dzień Pana, dzień wielki i wspaniały.
###### **Dz 2,21**
 A każdy, kto wezwie imienia Pana, zostanie zbawiony.
###### **Dz 2,22**
 Izraelici! Posłuchajcie mnie uważnie. Jezus z Nazaretu był człowiekiem, którego Bóg uwierzytelnił wśród was poprzez cuda i niezwykłe znaki, jakich przez Niego dokonywał, o czym sami wiecie.
###### **Dz 2,23**
 Z woli i postanowienia Bożego został On wydany. A wy rękami tych, którzy nie uznają Bożego prawa, ukrzyżowaliście Go i zabiliście.
###### **Dz 2,24**
 Ale Bóg wskrzesił Go i uwolnił od więzów śmierci. Nie było bowiem możliwe, aby ona nad Nim panowała.
###### **Dz 2,25**
 Przecież Dawid powiedział o Nim: Zawsze mam Pana przed oczami, On jest po mojej prawej stronie, abym się nie zachwiał.
###### **Dz 2,26**
 Dlatego cieszę się w sercu i bardzo raduję, gdyż moje ciało będzie spoczywać w nadziei.
###### **Dz 2,27**
 Nie pozostawisz mnie bowiem w krainie umarłych, i nie dopuścisz, aby Twój święty uległ rozkładowi.
###### **Dz 2,28**
 Wskazałeś mi drogi, które prowadzą do życia, a Twoja obecność napełnia mnie radością.
###### **Dz 2,29**
 Bracia! Przypominam wam patriarchę Dawida. Umarł on i został pogrzebany. I aż do dnia dzisiejszego jego grób znajduje się u nas.
###### **Dz 2,30**
 Ponieważ jako prorok wiedział, że Bóg przysiągł mu, iż jeden z jego potomków zasiądzie na jego tronie
###### **Dz 2,31**
 i przewidywał zmartwychwstanie Chrystusa, przepowiedział, że On nie zostanie pozostawiony w krainie umarłych ani Jego ciało nie ulegnie rozkładowi w grobie.
###### **Dz 2,32**
 Tego właśnie Jezusa Bóg wskrzesił, a my wszyscy o tym świadczymy.
###### **Dz 2,33**
 Kiedy został wywyższony mocą prawej ręki Boga i otrzymał od Ojca obiecanego Ducha Świętego, wylał Go, jak to sami widzicie i słyszycie.
###### **Dz 2,34**
 Dawid nie wstąpił do nieba, a jednak mówi: Pan powiedział do mojego Pana: Usiądź po mojej prawej stronie,
###### **Dz 2,35**
 aż położę twych wrogów jako podnóżek pod twoje stopy.
###### **Dz 2,36**
 Cały Izrael powinien wiedzieć, że Jezusa, którego ukrzyżowaliście, Bóg uczynił Panem i Chrystusem!”.
###### **Dz 2,37**
 Słowa te dogłębnie nimi wstrząsnęły. Dlatego pytali Piotra i pozostałych apostołów: „Bracia! Co mamy czynić?”.
###### **Dz 2,38**
 Piotr odpowiedział: „Nawróćcie się i każdy z was niech przyjmie chrzest w imię Jezusa Chrystusa na odpuszczenie grzechów. Wtedy otrzymacie dar Ducha Świętego.
###### **Dz 2,39**
 Bo obietnica Boża dotyczy was i waszych dzieci oraz tych wszystkich, którzy są daleko, a których Pan, Bóg nasz, powoła do siebie”.
###### **Dz 2,40**
 W wielu też innych słowach dawał świadectwo i napominał: „Oderwijcie się od tych przewrotnych ludzi!”.
###### **Dz 2,41**
 A ci, którzy przyjęli jego naukę, zostali ochrzczeni. W tym dniu przyłączyło się do nich około trzech tysięcy ludzi.
###### **Dz 2,42**
 Wszyscy postępowali zgodnie z nauką apostołów, żyli we wspólnocie braterskiej, łamali chleb i modlili się.
###### **Dz 2,43**
 A wszystkich ogarniał lęk, gdyż apostołowie czynili wiele cudów i znaków.
###### **Dz 2,44**
 Wszyscy wierzący stanowili jedno i wszystko mieli wspólne.
###### **Dz 2,45**
 Sprzedawali swoje posiadłości i majątki i rozdzielali je wszystkim stosownie do potrzeb.
###### **Dz 2,46**
 Codziennie jednomyślnie gromadzili się w świątyni. Łamali chleb po domach, a pokarm przyjmowali z radością i prostotą serca.
###### **Dz 2,47**
 Wielbili Boga, a wszyscy ludzie odnosili się do nich życzliwie. Pan zaś codziennie pomnażał liczbę tych, którzy mieli być zbawieni.
# Dz 2 BP
###### **Dz 2,1**
 W dniu Pięćdziesiątnicy znowu wszyscy się razem tam zebrali.
###### **Dz 2,2**
 Aż tu nagle powstał szum z nieba, jakby zerwał się gwałtowny wiatr i napełnił cały dom, w którym przebywali.
###### **Dz 2,3**
 Wtedy zobaczyli, że nad głowami każdego z nich pojawiły się jakby języki ognia.
###### **Dz 2,4**
 A Duch Święty napełnił ich wszystkich, i zaczęli mówić obcymi językami, jak im Duch dawał.
###### **Dz 2,5**
 Znajdowali się wówczas w Jerozolimie mieszkańcy Judei i ludzie pobożni ze wszystkich narodowości.
###### **Dz 2,6**
 Narastająca wrzawa ściągnęła mnóstwo ludzi, których zaskoczyło to, że każdy z nich słyszał, jak mówili w jego ojczystym języku.
###### **Dz 2,7**
 Zaskoczeni ze zdziwieniem pytali: "Czyż ci wszyscy, którzy rozprawiają, nie są Galilejczykami?
###### **Dz 2,8**
 Jak to się dzieje, że każdy z nas słyszy swoją rodzimą mowę?
###### **Dz 2,9**
 My Partowie, Medowie, Elamici, mieszkańcy Mezopotamii, Judei i Kapadocji, Pontu, Azji,
###### **Dz 2,10**
 Frygii i Pamfilii, Egiptu, części Libii położonej koło Cyreny i pielgrzymi z Rzymu,
###### **Dz 2,11**
 Żydzi i prozelici, mieszkańcy Krety i Arabowie, słyszymy, jak oni mówią w naszych językach o niezwykłych dziełach Bożych".
###### **Dz 2,12**
 Byli tym wszyscy zaskoczeni i oszołomieni, pytając jeden drugiego: "Co to znaczy?"
###### **Dz 2,13**
 Niektórzy szydzili i mówili: "Upili się młodym winem".
###### **Dz 2,14**
 Piotr, w otoczeniu Jedenastu, zabrał głos: "Judejczycy i wszyscy mieszkańcy Jerozolimy! Słuchajcie, co wam powiem, a dowiecie się,
###### **Dz 2,15**
 że oni nie są pijani, jak wy sądzicie, przecież to jest dopiero trzecia godzina dnia,
###### **Dz 2,16**
 ale to się właśnie spełnia przepowiednia proroka Joela:
###### **Dz 2,17**
 "Tak będzie, mówi Bóg. W ostatnich dniach ześlę Ducha mego na każdego człowieka, synowie i córki wasze mówić będą z natchnienie Bożego, młodzież wasza mieć będzie widzenia, a starsi sny mieć będą.
###### **Dz 2,18**
 W tym też czasie ześlę Ducha mego na niewolników i niewolnice, którzy będą również mówić z natchnienia Bożego.
###### **Dz 2,19**
 Ukażę takie rzeczy dziwne na niebie, na ziemi zaś znaki z krwi, ognia i dymu.
###### **Dz 2,20**
 Słońce się zaćmi, a księżyc stanie się czerwony jak krew, zanim nadejdzie dzień Pański wielki i wspaniały.
###### **Dz 2,21**
 A zbawiony zostanie każdy, kto wzywać będzie imienia Pańskiego"
###### **Dz 2,22**
 Izraelici, słuchajcie: Ukrzyżowaliście Jezusa z Nazaretu, Człowieka, którego posłannictwo Bóg nam potwierdził nadziemską mocą i zdumiewającymi znakami, o czym doskonale wiecie,
###### **Dz 2,23**
 chociaż został On wydany w ręce niesprawiedliwych z wyraźnej woli i wyroku Bożego.
###### **Dz 2,24**
 A jednak zmartwychwstał, uwolnił Go Bóg z więzów śmierci, gdyż było niemożliwe, by ona Go pokonała.
###### **Dz 2,25**
 Powiedział bowiem o Nim Dawid: "Zawsze blisko widziałem Pana, Nie zachwieję się, bo jest po prawicy mojej.
###### **Dz 2,26**
 Dlatego mam radość w sercu i na ustach, zwłaszcza że ciało moje nie dozna rozkładu.
###### **Dz 2,27**
 Bo nie zostawisz duszy mej w otchłani i nie pozwolisz, by święty twój uległ zniszczeniu.
###### **Dz 2,28**
 Nauczyłeś mnie dróg życia, a obecność Twoja napełnia mnie radością".
###### **Dz 2,29**
 Bracia! Niech mi wolno będzie wyraźnie powiedzieć, że patriarcha Dawid, który umarł i został pochowany, a grób jego u nas dotychczas się znajduje,
###### **Dz 2,30**
 jako prorok mówił o zmartwychwstaniu Mesjasza; pamiętał bowiem o szczególnej obietnicy Bożej, że potomek jego zasiądzie na tronie. Powiedział o Nim:
###### **Dz 2,31**
 "Nie zostanie bowiem w otchłani ani ciało Jego nie ulegnie zniszczeniu".
###### **Dz 2,32**
 Tego właśnie Jezusa Bóg wskrzesił, czego my wszyscy jesteśmy świadkami.
###### **Dz 2,33**
 Wyniósł Go także Bóg na swoją prawicę, a On zesłał obiecanego przez Ojca Ducha Świętego, co widzicie i słyszycie.
###### **Dz 2,34**
 Nie Dawid przecież wstąpił do nieba, sam bowiem mówi: "Powiedział Pan do mego Pana: Usiądź po prawicy mojej,
###### **Dz 2,35**
 a nieprzyjaciół twoich położę jako podnóżek pod twoje stopy"
###### **Dz 2,36**
 Niech więc nikt w Izraelu nie ma żadnej wątpliwości, że Jezusa, którego wyście ukrzyżowali, Bóg uczynił Panem i Mesjaszem".
###### **Dz 2,37**
 Słowa te wstrząsnęły nimi głęboko. Zapytali więc Piotra i pozostałych apostołów: "Bracia, co mamy czynić?"
###### **Dz 2,38**
 A Piotr do nich: "Starajcie się o wewnętrzną przemianę i niech każdy z was ochrzci się w imię Jezusa Chrystusa dla odpuszczenia grzechów, a otrzymacie dar Ducha Świętego.
###### **Dz 2,39**
 Macie bowiem obietnicę wy i dzieci wasze oraz wszyscy, których z oddali wezwie Pan, Bóg nasz".
###### **Dz 2,40**
 Przytoczył im jeszcze wiele innych świadectw i zachęcał: "Uwolnijcie się od przewrotności tego pokolenia".
###### **Dz 2,41**
 Ci, którzy przyjęli jego naukę, zostali ochrzczeni, a liczba ich w tym dniu wzrosła do trzech tysięcy osób.
###### **Dz 2,42**
 W postępowaniu kierowali się nauką apostołów, żyli we wspólnocie, łamali chleb i modlili się.
###### **Dz 2,43**
 Wiele też zdumiewających znaków czynili apostołowie, a lęk ogarniał wszystkich.
###### **Dz 2,44**
 Wszyscy wierzący przebywali razem i mieli wszystko wspólne;
###### **Dz 2,45**
 sprzedawali posiadłości i dobra, dzieląc je między wszystkich, stosownie do potrzeb.
###### **Dz 2,46**
 Codziennie wspólnie przebywali w świątyni, po domach łamali chleb, z radością i prostotą serca brali udział w posiłkach.
###### **Dz 2,47**
 Chwalili Boga i mieli uznanie u wszystkich. A Pan codziennie dołączał do nich tych, którzy mieli być zbawieni.
# Dz 2 BR
###### **Dz 2,1**
 A kiedy nadszedł dzień Pięćdziesiątnicy, wszyscy znajdowali się razem na tym samym miejscu.
###### **Dz 2,2**
 Naraz dał się słyszeć pochodzący z nieba szum, jakby uderzenie gwałtownego wichru, który napełnił cały dom, gdzie wszyscy przebywali.
###### **Dz 2,3**
 Równocześnie pojawiły się nad nimi jakby język
###### **Dz 2,4**
 z ognia; rozdzieliły się i po jednym spoczęły, na każdym z osobna. Wtedy wszyscy zostali napełnieni Duchem Świętym i zaczęli mówić obcymi językami, tak jak sam Duch pozwalał im mówić.
###### **Dz 2,5**
 Przebywali zaś wtedy w Jerozolimie Żydzi pobożni ze wszystkich narodów zamieszkujących ziemię.
###### **Dz 2,6**
 Kiedy więc powstał ów szum, zbiegli się gromadnie. Ogarnęło ich przy tym wielkie zdumienie, bo oto każdy słyszał, jak przemawiano jego własnym językiem.
###### **Dz 2,7**
 I pytali pełni zdumienia i podziwu: Czyż ci przemawiający nie są wszyscy Galilejczyczykami?
###### **Dz 2,8**
 Jak więc się to dzieje, że każdy z nas słyszy swój własny język?
###### **Dz 2,9**
 - Partowie i Medowie, Elamici i mieszkańcy Mezopotamii, Judei oraz Kapadocji, Pontu i Azji,
###### **Dz 2,10**
 Frygii, Pamfilii, Egiptu i regionów Libii położonych blisko Cyreny oraz przybysze z Rzymu.
###### **Dz 2,11**
 Wreszcie Żydzi i prozelici, Kreteńczycy i Arabowie - wszyscy słyszymy, jak w naszych własnych językach opowiadają o wielkich dziełach Boga.
###### **Dz 2,12**
 Pełni zdumienia, nie wiedząc, co o tym sądzić, pytali jedni drugich: Co to ma znaczyć?
###### **Dz 2,13**
 A inni wyśmiewali się mówiąc: Upili się młodym winem.
###### **Dz 2,14**
 Wtedy powstał Piotr razem z Jedenastoma i przemówił do nich głosem donośnym. Mówił zaś tak: Judejczycy i wszyscy mieszkańcy Jerozolimy, proszę was o chwilę uwagi i o dokładne wysłuchanie tego, co wam powiem.
###### **Dz 2,15**
 Ludzie, których tu widzicie, nie są pijani, choć się niektórym spośród was tak wydaje. Jest przecież dopiero trzecia godzina.
###### **Dz 2,16**
 Lecz to wiedzcie, że spełnia się na nich przepowiednia proroka Joela:
###### **Dz 2,17**
 Za dni ostatnich - mówił Pan - wyleją Ducha mojego na wszystkich ludzi. Wasi synowie i córki wasze będę prorokować, młodzi ludzie będą mieć widzenia, a starzy - sny.
###### **Dz 2,18**
 Nawet na sługi i służebnice moje wyleję w owych czasach mego Ducha i będą prorokować.
###### **Dz 2,19**
 Ukażę też rzeczy przedziwne w górze - na niebie i znaki nisko - na ziemi: krew, ogień i obłoki dymu.
###### **Dz 2,20**
 Słońce się zaćmi, księżyc - krwią zajdzie przed nadejściem dnia Pań-skiego, wielkiego i wspaniałego.
###### **Dz 2,21**
 Każdy zaś, kto będzie wzywał Imienia Pańskiego, dostąpi zbawienia.
###### **Dz 2,22**
 Izraelici, posłuchajcie mnie. Jezus z Nazaretu był człowiekiem, którego posłannictwo potwierdził sam Bóg przez to, że za Jego sprawą dokonał na waszych oczach wielu niezwykłych czynów, cudów i znaków, o czym sami dobrze wiecie.
###### **Dz 2,23**
 Otóż On to właśnie, zgodnie z odwiecznym planem powziętym przez Boga, został wam wydany, a wy, posługując się bezbożnikami, przybiliście Go do krzyża i pozbawiliście życia.
###### **Dz 2,24**
 Ale Bóg zmartwychwskrzesił Go, uwolnił od więzów śmierci, gdyż było nie do pomyślenia, żeby wzięła nad Nim górę,
###### **Dz 2,25**
 skoro już Dawid, Jego mając na uwadze, tak powiedział: Nieustannie mam Pana przed mymi oczyma, bo jest On zawsze przy moim boku, żebym się nie zachwiał.
###### **Dz 2,26**
 Dlatego cieszy się moje serce i moje usta pełne są radości, a moje ciało będzie spoczywać w nadziei.
###### **Dz 2,27**
 Nie pozostawisz bowiem mej duszy w Otchłani i nie dopuścisz do tego, aby Twój, Święty uległ rozkładowi.
###### **Dz 2,28**
 Ukazałeś mi drogi, które wiodą do życia, a Twoja obecność napełnia mnie radością.
###### **Dz 2,29**
 Bracia, bez żadnego wahania przypominam wam to, że praojciec Dawid umarł i został złożony w grobie, który znajduje się u nas aż po dzień dzisiejszy.
###### **Dz 2,30**
 Lecz był on także prorokiem i wiedział, że zgodnie z uroczystą przysięgą Boga jego potomek będzie kiedyś zasiadał na jego tronie.
###### **Dz 2,31**
 Przyszłość była dlań odkryta i przepowiadał właśnie zmartwychwstanie Mesjasza, gdy mówił, że nie pozostanie w Otchłani i że Jego ciało nie ulegnie rozkładowi.
###### **Dz 2,32**
 Otóż tego Jezusa Bóg zmartwychwskrzesił, o czym my wszyscy dajemy świadectwo.
###### **Dz 2,33**
 Został On wywyższony [i zasiadł] po prawicy Boga. Otrzymał też od Ojca obietnicę Ducha Świętego i zesłał Go [na nas], jak to sami widzicie i słyszycie.
###### **Dz 2,34**
 Bo przecież Dawid nie wstąpił sam do nieba, a jednak powiedział: Rzekł Pan do Pana mego: siądź po prawicy mojej,
###### **Dz 2,35**
 aż położę nieprzyjaciół Twoich podnóżkiem stóp Twoich.
###### **Dz 2,36**
 Niech więc cały naród izraelski trwa w przekonaniu niewzruszonym, że Bóg uczynił i Panem, i Mesjaszem tego właśnie Jezusa, którego wyście ukrzyżowali.
###### **Dz 2,37**
 Gdy usłyszeli te słowa, przejęli się do głębi serca i zapytali Piotra i pozostałych apostołów: Cóż mamy czynić, bracia?
###### **Dz 2,38**
 I rzekł do nich Piotr: Nawróćcie się i niech każdy z was przyjmie chrzest w imię Jezusa Chrystusa na odpuszczenie grzechów waszych. Wtedy też otrzymacie w darze Ducha Świętego.
###### **Dz 2,39**
 Bo obietnica Boża dotyczy was, waszych dzieci i tych wszystkich, którzy są daleko, lecz zostali powołani przez Boga.
###### **Dz 2,40**
 Potem mówił im Piotr jeszcze wiele innych rzeczy i tak ich upominał: Starajcie się wyrwać spośród tych przewrotnych ludzi.
###### **Dz 2,41**
 W ten sposób ci, którzy przyjęli jego naukę, zostali ochrzczeni. I przyłączyło się do nich tego dnia około trzech tysięcy ludzi.
###### **Dz 2,42**
 Wszyscy trzymali się wiernie nauki apostołów, trwali w łączności braterskiej, uczestniczyli w łamaniu chleba i oddawali się modlitwie.
###### **Dz 2,43**
 Każdy też odczuwał bojaźń, gdyż apostołowie dokonywali wielu znaków i cudów.
###### **Dz 2,44**
 Wszyscy, którzy uwierzyli, przebywali razem i wszystko mieli współne.
###### **Dz 2,45**
 Sprzedawali też to, co posiadali, a pieniądze rozdzielali wszystkim według potrzeb każdego z osobna.
###### **Dz 2,46**
 Codziennie zbierali się razem w świątyni [na wspólną modlitwę], a po domach, łamiąc chleb, spożywali dary Boże z radością i prostotą serca.
###### **Dz 2,47**
 Wielbili Boga i cieszyli się życzliwością całego ludu. A Pan pomnażał co dzień liczbę tych, którzy dostępowali zbawienia.
# Dz 2 WUJ
###### **Dz 2,1**
 A gdy się spełniały dni Pięć dziesiątnice, byli wszyscy wespołek na temże miejscu.
###### **Dz 2,2**
 I stał się z prędka z nieba szum, jakoby przypadającego wiatru gwałtownego: i napełnił wszystek dom, gdzie siedzieli.
###### **Dz 2,3**
 I ukazały się im rozdzielone języki jakoby ognia, i usiadł na każdym z nich z osobna:
###### **Dz 2,4**
 I napełnieni byli wszyscy Ducha świętego: i poczęli mówić rozmaitemi językami, jako im Duch Święty wymawiać dawał,
###### **Dz 2,5**
 A byli w Jeruzalem mieszkający Żydowie, mężowie nabożni, ze wszego narodu, który jest pod niebem.
###### **Dz 2,6**
 A gdy się stał ten głos, zbieżało się mnóstwo, i strwożyło się na myśli, że każdy słyszał je swym językiem mówiące.
###### **Dz 2,7**
 A zdumiewali się wszyscy, i dziwowali, mówiąc: Izali, oto, ci wszyscy, którzy mówią, nie są Galilejczycy?
###### **Dz 2,8**
 A jakożeśmy słyszeli każdy z nas swój język, w którymechmy się urodzili?
###### **Dz 2,9**
 Parthowie, i Medowie, i Elamitowie, i mieszkający w Mesopotamjej, w Żydowskiej ziemi, i w Kapadocjej, w Pontcie, i w Azjej.
###### **Dz 2,10**
 W Frygjej, i w Pamphiljej, w Egipcie, i w stronach Libjej, która jest podle Cyreny, i przychodniowie Rzymscy:
###### **Dz 2,11**
 Żydowie też i nowo nawróceni, Kreteńczycy i Arabczycy: słyszeliśmy je mówiące języki naszemi wielmożne sprawy Boże.
###### **Dz 2,12**
 I zdumiewali się wszyscy, i dziwowali, mówiąc jeden do drugiego: Cóż to ma być?
###### **Dz 2,13**
 A drudzy naśmiewając się mówili: Że muszczu pełni są ci.
###### **Dz 2,14**
 A stanąwszy Piotr z jedenaścią, podniósł głos swój, i mówił im: Mężowie Żydowscy i wszyscy, którzy mieszkacie w Jeruzalem, niech to wam jawno będzie, a przyjmicie do uszu słowa moje.
###### **Dz 2,15**
 Abowiem nie są pijani ci, jako wy mniemacie: gdyż jest trzecia godzina na dzień:
###### **Dz 2,16**
 Ale to jest co rzeczono jest przez proroka Joela:
###### **Dz 2,17**
 I będzie w ostateczne dni (mówi Pan) wyleję z Ducha mego na wszelkie ciało: a prorokować będą synowie waszy i córki wasze: a młodzieńcy waszy widzenia będą widzieć: a starcom waszym sny się śnić będą.
###### **Dz 2,18**
 A iście w one dni, na sługi me, i na służebnice moje wyleję z Ducha mego, i będą prorokować:
###### **Dz 2,19**
 I dam cuda na niebie wzgórę, i znaki na ziemi nizko, krew, i ogień, i kurzawę dymu.
###### **Dz 2,20**
 Słońce się obróci w ciemności, a księżyc w krew przedtem niż przydzie dzień Pański wielki i jawny.
###### **Dz 2,21**
 I będzie: wszelki, którybykolwiek wzywał imienia Pańskiego, zbawion będzie.
###### **Dz 2,22**
 Mężowie Izraelscy, słuchajcież słów tych. Jezusa Nazareńskiego, męża od Boga pochwalonego u was mocam i cudami, i znakami, które czynił Bóg przezeń między wami, jako i wy wiecie:
###### **Dz 2,23**
 Tego. naznaczoną radą i przejrzeniem Bożem wydanego, przez ręce niezbożników umęczywszy zatraciliście.
###### **Dz 2,24**
 Którego Bóg wzbudził rozwiązawszy boleści piekła: jakoż była rzecz niepodobna, aby od niego miał być on zatrzyman.
###### **Dz 2,25**
 Abowiem Dawid o nim mówi: Upatrowałem zawżdy Pana przed sobą, bo mi jest po prawicy, abych nie był wzruszon.
###### **Dz 2,26**
 Dla tegoż się rozweseliło serce moje, a rozradował się język mój: nadto i ciało moje odpoczynie w nadziei.
###### **Dz 2,27**
 Abowiem nie zostawisz dusze mojej w piekle: ani dasz świętemu twemu oglądać skażenia.
###### **Dz 2,28**
 Oznajmiłeś mi drogi żywota: i napełnisz mię radością z obliczem twojem.
###### **Dz 2,29**
 Mężowie bracia, niech się godzi bezpiecznie mówić do was o Patryarsze Dawidzie, że umarł, i pogrzebion jest: i grób jego jest u nas, aż do dnia dzisiejszego.
###### **Dz 2,30**
 Będąc tedy prorokiem, i wiedząc, że mu Bóg przysięgą przysiągł, iż z owocu biodry jego miał siedzieć na stolicy jego:
###### **Dz 2,31**
 Przeglądając powiedział o zmartwychwstaniu Chrystusowem: iż ani zostawion jest w piekle: ani ciało jego ujrzało zepsowania.
###### **Dz 2,32**
 Tego Jezusa wzbudził Bóg: czego my wszyscy jesteśmy świadkowie.
###### **Dz 2,33**
 Prawicą tedy Bożą podwyższony, a obietnicę Ducha świętego wziąwszy od Ojca, wylał tego, którego wy widzicie i słyszycie.
###### **Dz 2,34**
 Abowiem Dawid nie wstąpił do nieba: lecz sam powiada, Rzekł Pan Panu memu, siądź na prawicy mojej:
###### **Dz 2,35**
 Aż położę nieprzyjacioły twe podnóżkiem nóg twoich.
###### **Dz 2,36**
 Niechaj tedy wie za pewne wszystek dom Izraelski, iż go i Panem, i Chrystusem uczynił Bóg, tego Jezusa, któregoście wy ukrzyżowali.
###### **Dz 2,37**
 A usłyszawszy to, skruszeni są na sercu: i rzekli do Piotra i do innych Apostołów: Cóż mamy czynić mężowie bracia?
###### **Dz 2,38**
 A Piotr do nich: Pokutę czyńcie (prawi), a niech ochrzczon będzie każdy z was w imię Jezusa Chrystusa, na odpuszczenie grzechów waszych: a weźmiecie dar Ducha świętego.
###### **Dz 2,39**
 Abowiem wam jest obietnica i dziatkom waszym, i wszystkim, którzy są daleko, którekolwiek przyzowie Pan Bóg nasz.
###### **Dz 2,40**
 I wielą innych słów świadczył, i napominał ich, mówiąc: Wyzwólcie się od tego narodu przewrotnego.
###### **Dz 2,41**
 Którzy tedy przyjęli mowę jego, ochrzczeni są: i przystało dnia onego jakoby trzy tysiące dusz.
###### **Dz 2,42**
 I trwali w nauce Apostolskiej, i w uczestnictwie łamania chleba, i w modlitwach.
###### **Dz 2,43**
 I przychodziła na każdą duszę bojaźń: wiele się też dziwów i znaków przez Apostoły działo w Jeruzalem: i była wielka bojaźń we wszystkich.
###### **Dz 2,44**
 Wszyscy też, którzy wierzyli, byli pospołu: i wszystko mieli spólne.
###### **Dz 2,45**
 Osiadłości i majętności przedawali, i podzielali nimi wszystkie, jako każdemu było potrzeba.
###### **Dz 2,46**
 Co dzień też trwając jednomyślnie w kościele, a łamiąc chleb po domiech, pożywali pokarmu z radością i w prostocie serdecznej:
###### **Dz 2,47**
 Chwaląc Boga, i mając łaskę u wszego ludu. A Pan co dzień przymnaża do kupy, którzy mieli być zbawieni.
# Dz 2 STERN
###### **Dz 2,1**
 Nadeszło święto Szawu'ot, a wszyscy wierzący zebrali się razem w jednym miejscu.
###### **Dz 2,2**
 Nagle rozległ się odgłos z nieba, jakby huk porywistego wichru, i napełnił cały dom, w którym siedzieli.
###### **Dz 2,3**
 I zobaczyli coś, co wyglądało na języki ognia, które rozdzieliły się i spoczęły na każdym z nich.
###### **Dz 2,4**
 Wszyscy zostali napełnieni Ruach Ha-Kodesz i zaczęli mówić innymi językami, tak jak im Duch pozwalał mówić.
###### **Dz 2,5**
 A byli w Jeruszalaim pobożni Żydzi z każdego narodu pod słońcem.
###### **Dz 2,6**
 Kiedy usłyszeli ten odgłos, zebrał się tłum; i nie wiedzieli, co myśleć, bo każdy słyszał, jak wierzący mówią w jego własnym języku.
###### **Dz 2,7**
 W osłupieniu pytali: "Jak to możliwe? Czy ci wszyscy, którzy przemawiają, nie są z Galil?
###### **Dz 2,8**
 Jak to możliwe, że słyszymy ich mówiących w naszych rodzimych językach?
###### **Dz 2,9**
 Jesteśmy Partami, Medami, Elamitami; mieszkańcami Mezopotamii, J'hudy, Kapadocji, Pontu, Azji,
###### **Dz 2,10**
 Frygii, Pamfilii, Egiptu, części Libii koło Cyreny; przybyszami z Rzymu;
###### **Dz 2,11**
 rodowitymi Żydami i prozelitami; Żydami z Krety i z Arabii...! Jak to możliwe, że słyszymy, jak mówią naszymi językami o wielkich dziełach Boga?".
###### **Dz 2,12**
 Zdumieni i oszołomieni, wszyscy pytali jeden przez drugiego: "Cóż to może znaczyć?".
###### **Dz 2,13**
 Ale inni drwili sobie z nich, mówiąc: "Za dużo wina sobie popili!".
###### **Dz 2,14**
 Wtedy powstał Kefa wraz z Jedenastoma i podnosząc głos, zwrócił się do nich: "Judejczycy i wy wszyscy zebrani tutaj w Jeruszalaim! Powiem wam, co to znaczy! Słuchajcie mnie uważnie!
###### **Dz 2,15**
 Ludzie ci nie są pijani, jak przypuszczacie - jest dopiero dziewiąta rano.
###### **Dz 2,16**
 Nie, lecz o tym właśnie powiedziano przez proroka Joela:
###### **Dz 2,17**
 "Mówi Adonai: W Dniach Ostatnich wyleję na wszystkich z mojego Ducha. Synowie wasi i wasze córki będą prorokować, wasi młodzieńcy będą mieć widzenia, starcy wasi będą śnili sny.
###### **Dz 2,18**
 Nawet na niewolników moich, i mężczyzn, i kobiety wyleję w tych dniach z Ducha mego, i będą prorokować.
###### **Dz 2,19**
 I sprawię cuda na niebie w górze i znaki na ziemi w dole: krew, ogień i gęsty dym.
###### **Dz 2,20**
 Słońce pociemnieje, a księżyc stanie się krwią, nim nadejdzie wielki i straszliwy Dzień Adonai.
###### **Dz 2,21**
 A wtedy kto wezwie imienia Adonai, będzie zbawiony".
###### **Dz 2,22**
 Mężowie Israela! Posłuchajcie mnie! Jeszua z Naceret był człowiekiem, który okazał wobec was, że jest od Boga, w potężnych dziełach, cudach i znakach, których na waszych oczach Bóg przez Niego dokonał. Dobrze o tym wiecie.
###### **Dz 2,23**
 Człowiek ten został pojmany zgodnie z powziętym z góry Bożym planem i wiedzą, i za pośrednictwem ludzi niezwiązanych przez Torę przybiliście Go do pala i zabiliście!
###### **Dz 2,24**
 Lecz Bóg wskrzesił Go i wyzwolił od cierpienia śmierci; bo niemożliwe było, aby śmierć mogła utrzymać Go w swej mocy.
###### **Dz 2,25**
 Dawid bowiem tak mówi o Nim: "Widziałem Adonai zawsze przed sobą, bo jest On po mojej prawicy, tak że się nie zachwieję.
###### **Dz 2,26**
 Z tej przyczyny ucieszyło się moje serce, a język mój rozradował się; teraz zaś również ciało moje będzie żyć w pewności nadziei,
###### **Dz 2,27**
 że nie porzucisz mnie w Sz'olu i nie pozwolisz swemu Świętemu ujrzeć zniszczenia.
###### **Dz 2,28**
 Dałeś mi poznać drogi życia; napełnisz mnie radością z Twojej obecności".
###### **Dz 2,29**
 Wiem, bracia, że mogę powiedzieć wam otwarcie, iż patriarcha Dawid umarł i został pogrzebany - jego grób jest u nas do dziś.
###### **Dz 2,30**
 Ponieważ zatem był prorokiem i wiedział, że Bóg złożył mu przysięgę, iż jeden z jego potomków zasiądzie na jego tronie,
###### **Dz 2,31**
 zapowiadał zmartwychwstanie Mesjasza - że to On nie został porzucony w Sz'olu i Jego ciało nie ujrzało zniszczenia.
###### **Dz 2,32**
 Bóg wskrzesił tego Jeszuę! A my wszyscy jesteśmy tego świadkami!
###### **Dz 2,33**
 Ponadto został On wywyższony po prawicy Bożej; otrzymał od Ojca to, co obiecał, mianowicie Ruach Ha-Kodesz, i wylał ten dar, co teraz widzicie i słyszycie.
###### **Dz 2,34**
 Bo Dawid nie wstąpił do nieba. Ale powiada:
###### **Dz 2,35**
 " Adonai powiedział do mego Pana: Usiądź po mojej prawicy, aż uczynię Twoich nieprzyjaciół podnóżkiem dla Twoich stóp".
###### **Dz 2,36**
 Niech zatem wie cały dom Israela ponad wszelką wątpliwość, że uczynił Go Bóg i Panem, i Mesjaszem - tego Jeszuę, któregoście stracili na palu!".
###### **Dz 2,37**
 Słysząc to, byli dotknięci do żywego; i mówili do Kefy i pozostałych wysłanników: "Bracia, co mamy robić?".
###### **Dz 2,38**
 Kefa odrzekł im: "Odwróćcie się od grzechu, powróćcie do Boga i niech mocą władzy Jeszui Mesjasza każdy z was zostanie zanurzony w przebaczenie waszych grzechów, a otrzymacie dar Ruach Ha-Kodesz!
###### **Dz 2,39**
 Jest bowiem obietnica dla was, dla waszych dzieci i dla tych z dala - ilu tylko Adonai, Bóg nasz, powoła!".
###### **Dz 2,40**
 Przekonywał też wieloma innymi argumentami i nie przestawał ich zaklinać: "Ratujcie się spośród tego przewrotnego pokolenia".
###### **Dz 2,41**
 Ci zatem, którzy przyjęli to, co mówił, zostali zanurzeni, i do grupy dołączyło tego dnia około trzech tysięcy ludzi.
###### **Dz 2,42**
 Wiernie trwali oni w nauce wysłanników, we wspólnocie, w łamaniu chleba i w modlitwach.
###### **Dz 2,43**
 Wszystkich przepełniał lęk, a przez wysłanników działo się wiele cudów i znaków.
###### **Dz 2,44**
 Wszyscy ci, którzy ufali Jeszui, przebywali razem i wszystko mieli wspólne;
###### **Dz 2,45**
 sprzedawali nawet swój dobytek i majątek, a pieniądze rozdawali wszystkim potrzebującym.
###### **Dz 2,46**
 Nadal wiernie i jednomyślnie spotykając się codziennie na dziedzińcu Świątyni i łamiąc chleb w niektórych domach, dzielili się żywnością radośnie i w szczerości serca,
###### **Dz 2,47**
 chwaląc Boga i ciesząc się szacunkiem wszystkich ludzi. A Pan dzień po dniu przydawał im tych, którzy dostępowali zbawienia.
# Dz 2 TRO
###### **Dz 2,1**
 **και** *kai* I [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **συμπληρουσθαι** *symplērousthai* być wypełnionym [[G4845]] WTV-PPN **την** *tēn* [[G3588]] WTT-ASF **ημεραν** *hēmeran* dniu [[G2250]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **πεντηκοστης** *pentēkostēs* Pięćdziesiątnicy [[G4005]] [[N-GSF]] **ησαν** *ēsan* byli [[G2258]] WTV-IXI-3P **απαντες** *hapantes* wszyscy [[G537]] WTA-NPM **ομοθυμαδον** *homothymadon* jednomyślnie – jednogłośnie [[G3661]] [[ADV]] **επι** *epi* na [[G1909]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **αυτο** *auto* tym samym [[G846]] WTP-ASN
###### **Dz 2,2**
 **και** *kai* I [[G2532]] [[CONJ]] **εγενετο** *egeneto* stał się [[G1096]] WTV-2ADI-3S **αφνω** *afnō* nagle – nieoczekiwanie [[G869]] [[ADV]] **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **ουρανου** *ouranou* nieba [[G3772]] [[N-GSM]] **ηχος** *ēchos* dźwięk – szum [[G2279]] [[N-NSM]] **ωσπερ** *hōsper* tak, jak [[G5618]] [[ADV]] **φερομενης** *feromenēs* niosącego się [[G5342]] WTV-PEP-GSF **πνοης** *pnoēs* wiatru – tchu [[G4157]] [[N-GSF]] **βιαιας** *biaias* gwałtownego – potężnego [[G972]] WTA-GSF **και** *kai* i [[G2532]] [[CONJ]] **επληρωσεν** *eplērōsen* wypełnił [[G4137]] [[V-AAI-3S]] **ολον** *holon* cały [[G3650]] WTA-ASM **τον** *ton* [[G3588]] [[T-ASM]] **οικον** *oikon* dom [[G3624]] [[N-ASM]] **ου** *hou* gdzie [[G3757]] [[ADV]] **ησαν** *ēsan* byli [[G2258]] WTV-IXI-3P **καθημενοι** *kathēmenoi* siedząc [[G2521]] WTV-PNP-NPM
###### **Dz 2,3**
 **και** *kai* I [[G2532]] [[CONJ]] **ωφθησαν** *ōfthēsan* zostały ukazane – zostały uczynione widocznymi [[G3700]] WTV-API-3P **αυτοις** *autois* im [[G846]] WTP-DPM **διαμεριζομεναι** *diamerizomenai* rozdzielające [[G1266]] WTV-PEP-NPF **γλωσσαι** *glōssai* języki [[G1100]] [[N-NPF]] **ωσει** *hōsei* jakby [[G5616]] [[ADV]] **πυρος** *pyros* ognia [[G4442]] [[N-GSN]] **εκαθισεν** *ekathisen* usiadł [[G2523]] [[V-AAI-3S]] **τε** *te* także – zarówno [[G5037]] WTPRT **εφ** *ef* na [[G1909]] [[PREP]] **ενα** *hena* jednym [[G1520]] WTA-ASM **εκαστον** *hekaston* każdym [[G1538]] WTA-ASM **αυτων** *autōn* (z) nich [[G846]] WTP-GPM
###### **Dz 2,4**
 **και** *kai* I [[G2532]] [[CONJ]] **επλησθησαν** *eplēsthēsan* zostali napełnieni [[G4130]] WTV-API-3P **απαντες** *hapantes* wszyscy [[G537]] WTA-NPM **πνευματος** *pneumatos* Duchem [[G4151]] [[N-GSN]] **αγιου** *hagiou* Świętym [[G40]] [[A-GSN]] **και** *kai* i [[G2532]] [[CONJ]] **ηρξαντο** *ērksanto* zaczęli [[G756]] WTV-ADI-3P **λαλειν** *lalein* mówić [[G2980]] WTV-PAN **ετεραις** *heterais* innymi [[G2087]] WTA-DPF **γλωσσαις** *glōssais* językami [[G1100]] WTN-DPF **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **το** *to* [[G3588]] WTT-NSN **πνευμα** *pneuma* Duch [[G4151]] WTN-NSN **εδιδου** *edidou* dawał [[G1325]] WTV-IAI-3S **αυτοις** *autois* im [[G846]] WTP-DPM **αποφθεγγεσθαι** *apofthengesthai* wypowiadać [[G669]] WTV-PNN
###### **Dz 2,5**
 **ησαν** *ēsan* Byli [[G2258]] WTV-IXI-3P **δε** *de* zaś [[G1161]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **ιερουσαλημ** *ierousalēm* Jeruzalem – [dziedzictwo pokoju] [[G2419]] [[N-PRI]] **κατοικουντες** *katoikountes* zamieszkujący [[G2730]] WTV-PAP-NPM **ιουδαιοι** *ioudaioi* Judejczycy – [wielbić] [[G2453]] WTA-NPM **ανδρες** *andres* mężowie [[G435]] WTN-NPM **ευλαβεις** *eulabeis* pobożni [[G2126]] WTA-NPM **απο** *apo* z [[G575]] [[PREP]] **παντος** *pantos* każdego [[G3956]] [[A-GSN]] **εθνους** *ethnous* narodu [[G1484]] [[N-GSN]] **των** *tōn* [[G3588]] WTT-GPN **υπο** *hypo* pod [[G5259]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **ουρανον** *ouranon* niebem [[G3772]] [[N-ASM]]
###### **Dz 2,6**
 **γενομενης** *genomenēs* gdy stał się [[G1096]] WTV-2ADP-GSF **δε** *de* zaś [[G1161]] [[CONJ]] **της** *tēs* [[G3588]] [[T-GSF]] **φωνης** *fōnēs* głos [[G5456]] [[N-GSF]] **ταυτης** *tautēs* ten [[G3778]] WTD-GSF **συνηλθεν** *synēlthen* zeszło się [[G4905]] WTV-2AAI-3S **το** *to* [[G3588]] WTT-NSN **πληθος** *plēthos* mnóstwo – mnogość [[G4128]] WTN-NSN **και** *kai* i [[G2532]] [[CONJ]] **συνεχυθη** *synechythē* zostało zdumione – zostało oszołomienie [[G4797]] [[V-API-3S]] **οτι** *hoti* że [[G3754]] [[CONJ]] **ηκουον** *ēkouon* słyszeli [[G191]] WTV-IAI-3P **εις** *heis* jeden [[G1520]] [[A-NSM]] **εκαστος** *hekastos* każdy [[G1538]] [[A-NSM]] **τη** *tē* [[G3588]] WTT-DSF **ιδια** *idia* własną [[G2398]] WTA-DSF **διαλεκτω** *dialektō* mową [[G1258]] [[N-DSF]] **λαλουντων** *lalountōn* mówiących [[G2980]] WTV-PAP-GPM **αυτων** *autōn* ich [[G846]] WTP-GPM
###### **Dz 2,7**
 **εξισταντο** *eksistanto* Zdumiewali się – Dziwili się [[G1839]] WTV-IMI-3P **δε** *de* zaś [[G1161]] [[CONJ]] **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **και** *kai* i [[G2532]] [[CONJ]] **εθαυμαζον** *ethaumazon* dziwili się [[G2296]] WTV-IAI-3P **λεγοντες** *legontes* mówiąc [[G3004]] WTV-PAP-NPM **προς** *pros* do [[G4314]] [[PREP]] **αλληλους** *allēlous* jedni drugich [[G240]] WTC-APM **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **ουτοι** *houtoi* ci [[G3778]] WTD-NPM **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **οι** *hoi* [[G3588]] WTT-NPM **λαλουντες** *lalountes* mówiący [[G2980]] WTV-PAP-NPM **γαλιλαιοι** *galilaioi* Galilejczycy – [przesunąć] [[G1057]] WTN-NPM
###### **Dz 2,8**
 **και** *kai* I [[G2532]] [[CONJ]] **πως** *pōs* jak [[G4459]] [[ADV]]-I **ημεις** *hēmeis* my [[G2249]] WTP-1NP **ακουομεν** *akouomen* słyszymy [[G191]] WTV-PAI-1P **εκαστος** *hekastos* każdy [[G1538]] [[A-NSM]] **τη** *tē* [[G3588]] WTT-DSF **ιδια** *idia* własną [[G2398]] WTA-DSF **διαλεκτω** *dialektō* mowę [[G1258]] [[N-DSF]] **ημων** *hēmōn* naszą [[G2257]] WTP-1GP **εν** *en* w [[G1722]] [[PREP]] **η** *hē* której [[G3739]] WTR-DSF **εγεννηθημεν** *egennēthēmen* zostaliśmy urodzeni [[G1080]] WTV-API-1P
###### **Dz 2,9**
 **παρθοι** *parthoi* Partowie [[G3934]] WTN-NPM **και** *kai* i [[G2532]] [[CONJ]] **μηδοι** *mēdoi* Medowie [[G3370]] WTN-NPM **και** *kai* i [[G2532]] [[CONJ]] **ελαμιται** *elamitai* Elamici [[G1639]] WTN-NPM **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **κατοικουντες** *katoikountes* zamieszkujący [[G2730]] WTV-PAP-NPM **την** *tēn* [[G3588]] WTT-ASF **μεσοποταμιαν** *mesopotamian* Mezopotamię – Pomiędzy rzekami [[G3318]] WTN-ASF **ιουδαιαν** *ioudaian* Judeę – [wielbić] [[G2449]] WTN-ASF **τε** *te* zarówno – także [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **καππαδοκιαν** *kappadokian* Kapadocję [[G2587]] WTN-ASF **ποντον** *ponton* Pont – [morze] [[G4195]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **ασιαν** *asian* Azję [[G773]] WTN-ASF
###### **Dz 2,10**
 **φρυγιαν** *frygian* Frygię [[G5435]] WTN-ASF **τε** *te* zarówno – także [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **παμφυλιαν** *pamfylian* Pamfilię [[G3828]] WTN-ASF **αιγυπτον** *aigypton* Egipt – [lud Nilu] [[G125]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **μερη** *merē* części – działy [[G3313]] WTN-APN **της** *tēs* [[G3588]] [[T-GSF]] **λιβυης** *libyēs* Libii [[G3033]] [[N-GSF]] **της** *tēs* (tej) [[G3588]] [[T-GSF]] **κατα** *kata* naprzeciw [[G2596]] [[PREP]] **κυρηνην** *kyrēnēn* Cyreny [[G2957]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **επιδημουντες** *epidēmountes* przebywający w kraju [[G1927]] WTV-PAP-NPM **ρωμαιοι** *rōmaioi* Rzymianie [[G4514]] WTA-NPM **ιουδαιοι** *ioudaioi* Judejczycy – [wielbić] [[G2453]] WTA-NPM **τε** *te* zarówno – także [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **προσηλυτοι** *prosēlytoi* prozelici [[G4339]] WTN-NPM
###### **Dz 2,11**
 **κρητες** *krētes* Kreteńczycy [[G2912]] WTN-NPM **και** *kai* i [[G2532]] [[CONJ]] **αραβες** *arabes* Arabowie – [płaskowyż pustynny] [[G690]] WTN-NPM **ακουομεν** *akouomen* słyszymy [[G191]] WTV-PAI-1P **λαλουντων** *lalountōn* mówiących [[G2980]] WTV-PAP-GPM **αυτων** *autōn* ich [[G846]] WTP-GPM **ταις** *tais* [[G3588]] WTT-DPF **ημετεραις** *hēmeterais* naszymi [[G2251]] WTS-1DPF **γλωσσαις** *glōssais* językami [[G1100]] WTN-DPF **τα** *ta* [[G3588]] WTT-APN **μεγαλεια** *megaleia* wielkie rzeczy [[G3167]] WTA-APN **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **Dz 2,12**
 **εξισταντο** *eksistanto* Zdumiewali się – Dziwili się [[G1839]] WTV-IMI-3P **δε** *de* zaś [[G1161]] [[CONJ]] **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **και** *kai* i [[G2532]] [[CONJ]] **διηπορουν** *diēporoun* byli w niepokoju – byli w niepewności [[G1280]] WTV-IAI-3P **αλλος** *allos* inny – jeden [[G243]] [[A-NSM]] **προς** *pros* do [[G4314]] [[PREP]] **αλλον** *allon* innego – jednego [[G243]] WTA-ASM **λεγοντες** *legontes* mówiąc [[G3004]] WTV-PAP-NPM **τι** *ti* co- – czym- [[G5101]] WTI-ASN **αν** *an* kolwiek [[G302]] WTPRT **θελοι** *theloi* oby chce [[G2309]] WTV-PAO-3S **τουτο** *touto* to [[G5124]] WTD-ASN **ειναι** *einai* być [[G1511]] WTV-PXN
###### **Dz 2,13**
 **ετεροι** *heteroi* Inni [[G2087]] WTA-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **χλευαζοντες** *chleuazontes* drwiąc – szydząc [[G5512]] WTV-PAP-NPM **ελεγον** *elegon* mówili [[G3004]] WTV-IAI-3P **οτι** *hoti* że [[G3754]] [[CONJ]] **γλευκους** *gleukous* słodkim winem – młodym winem [[G1098]] [[N-GSN]] **μεμεστωμενοι** *memestōmenoi* którzy są napełnieni – którzy są wypełnieni [[G3325]] WTV-RPP-NPM **εισιν** *eisin* są [[G1526]] WTV-PXI-3P
###### **Dz 2,14**
 **σταθεις** *statheis* Zostawszy postawionym [[G2476]] WTV-APP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **πετρος** *petros* Piotr – [kamyk] [[G4074]] [[N-NSM]] **συν** *syn* z [[G4862]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPM **ενδεκα** *hendeka* jedenastoma [[G1733]] WTA-NUI **επηρεν** *epēren* podniósł [[G1869]] [[V-AAI-3S]] **την** *tēn* [[G3588]] WTT-ASF **φωνην** *fōnēn* głos [[G5456]] WTN-ASF **αυτου** *autou* jego [[G846]] [[P-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **απεφθεγξατο** *apefthegksato* wypowiedział [[G669]] WTV-ADI-3S **αυτοις** *autois* (do) nich [[G846]] WTP-DPM **ανδρες** *andres* mężowie [[G435]] WTN-VPM **ιουδαιοι** *ioudaioi* Judejczycy – [wielbić] [[G2453]] WTA-VPM **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* (ci) [[G3588]] WTT-NPM **κατοικουντες** *katoikountes* zamieszkujący [[G2730]] WTV-PAP-NPM **ιερουσαλημ** *ierousalēm* (w) Jeruzalem – [dziedzictwo pokoju] [[G2419]] [[N-PRI]] **απαντες** *hapantes* wszyscy [[G537]] WTA-NPM **τουτο** *touto* to [[G5124]] WTD-NSN **υμιν** *hymin* wam [[G5213]] WTP-2DP **γνωστον** *gnōston* znajome [[G1110]] WTA-NSN **εστω** *estō* niech jest [[G2077]] WTV-PXM-3S **και** *kai* i [[G2532]] [[CONJ]] **ενωτισασθε** *enōtisasthe* wysłuchajcie – włóżcie sobie do uszu [[G1801]] WTV-ADM-2P **τα** *ta* [[G3588]] WTT-APN **ρηματα** *rēmata* wypowiedzi [[G4487]] WTN-APN **μου** *mou* moje [[G3450]] WTP-1GS
###### **Dz 2,15**
 **ου** *ou* Nie [[G3756]] [[PRT-N]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ως** *hōs* jak [[G5613]] [[ADV]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **υπολαμβανετε** *hypolambanete* przypuszczacie – podejrzewacie [[G5274]] WTV-PAI-2P **ουτοι** *houtoi* ci [[G3778]] WTD-NPM **μεθυουσιν** *methyousin* są pijani [[G3184]] WTV-PAI-3P **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ωρα** *hōra* godzina [[G5610]] [[N-NSF]] **τριτη** *tritē* trzecia [[G5154]] WTA-NSF **της** *tēs* [[G3588]] [[T-GSF]] **ημερας** *hēmeras* dnia [[G2250]] [[N-GSF]]
###### **Dz 2,16**
 **αλλα** *alla* ale [[G235]] [[CONJ]] **τουτο** *touto* to [[G5124]] WTD-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **το** *to* [[G3588]] WTT-NSN **ειρημενον** *eirēmenon* co jest powiedziane [[G2046]] WTV-RPP-NSN-ATT **δια** *dia* przez [[G1223]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **προφητου** *profētou* proroka [[G4396]] [[N-GSM]] **ιωηλ** *iōēl* Joela – [JHWH jest Bogiem] [[G2493]] [[N-PRI]]
###### **Dz 2,17**
 **και** *kai* I [[G2532]] [[CONJ]] **εσται** *estai* będzie [[G2071]] WTV-FXI-3S **εν** *en* w [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **εσχαταις** *eschatais* ostatnich [[G2078]] WTA-DPF **ημεραις** *hēmerais* dniach [[G2250]] WTN-DPF **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **εκχεω** *ekcheō* wyleję [[G1632]] WTV-FAI-1S **απο** *apo* z [[G575]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **μου** *mou* mojego [[G3450]] WTP-1GS **επι** *epi* na [[G1909]] [[PREP]] **πασαν** *pasan* każde [[G3956]] WTA-ASF **σαρκα** *sarka* ciało [[G4561]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **προφητευσουσιν** *profēteusousin* będą prorokować [[G4395]] WTV-FAI-3P **οι** *hoi* [[G3588]] WTT-NPM **υιοι** *hyioi* synowie [[G5207]] WTN-NPM **υμων** *hymōn* wasi [[G5216]] WTP-2GP **και** *kai* i [[G2532]] [[CONJ]] **αι** *hai* [[G3588]] [[T-NPF]] **θυγατερες** *thygateres* córki [[G2364]] [[N-NPF]] **υμων** *hymōn* wasze [[G5216]] WTP-2GP **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **νεανισκοι** *neaniskoi* młodzieńcy [[G3495]] WTN-NPM **υμων** *hymōn* wasi [[G5216]] WTP-2GP **ορασεις** *horaseis* widzenia – wizje [[G3706]] WTN-APF **οψονται** *opsontai* zobaczą [[G3700]] WTV-FDI-3P **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **πρεσβυτεροι** *presbyteroi* starsi [[G4245]] WTA-NPM **υμων** *hymōn* wasi [[G5216]] WTP-2GP **ενυπνια** *enypnia* snami [[G1798]] WTN-APN **ενυπνιασθησονται** *enypniasthēsontai* zostaną snom oddani [[G1797]] WTV-FPI-3P
###### **Dz 2,18**
 **και** *kai* i [[G2532]] [[CONJ]] **γε** *ge* rzeczywiście – prawdziwie [[G1065]] WTPRT **επι** *epi* na [[G1909]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **δουλους** *doulous* niewolników – sługi [[G1401]] [[N-APM]] **μου** *mou* moje [[G3450]] WTP-1GS **και** *kai* i [[G2532]] [[CONJ]] **επι** *epi* na [[G1909]] [[PREP]] **τας** *tas* [[G3588]] WTT-APF **δουλας** *doulas* niewolnice – służebnice [[G1399]] WTN-APF **μου** *mou* moje [[G3450]] WTP-1GS **εν** *en* w [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **ημεραις** *hēmerais* dniach [[G2250]] WTN-DPF **εκειναις** *ekeinais* tych [[G1565]] WTD-DPF **εκχεω** *ekcheō* wyleję [[G1632]] WTV-FAI-1S **απο** *apo* z [[G575]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **μου** *mou* mojego [[G3450]] WTP-1GS **και** *kai* i [[G2532]] [[CONJ]] **προφητευσουσιν** *profēteusousin* będą prorokować [[G4395]] WTV-FAI-3P
###### **Dz 2,19**
 **και** *kai* I [[G2532]] [[CONJ]] **δωσω** *dōsō* dam [[G1325]] WTV-FAI-1S **τερατα** *terata* cuda [[G5059]] WTN-APN **εν** *en* na [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **ουρανω** *ouranō* niebie [[G3772]] WTN-DSM **ανω** *anō* w górze [[G507]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **σημεια** *sēmeia* znaki [[G4592]] WTN-APN **επι** *epi* na [[G1909]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]] **κατω** *katō* na dole [[G2736]] [[ADV]] **αιμα** *haima* krew [[G129]] WTN-ASN **και** *kai* i [[G2532]] [[CONJ]] **πυρ** *pyr* ogień [[G4442]] WTN-ASN **και** *kai* i [[G2532]] [[CONJ]] **ατμιδα** *atmida* wyziew – para [[G822]] WTN-ASF **καπνου** *kapnou* dymu [[G2586]] [[N-GSM]]
###### **Dz 2,20**
 **ο** *ho* [[G3588]] [[T-NSM]] **ηλιος** *hēlios* Słońce [[G2246]] [[N-NSM]] **μεταστραφησεται** *metastrafēsetai* zostanie obrócone [[G3344]] WTV-2FPI-3S **εις** *eis* w [[G1519]] [[PREP]] **σκοτος** *skotos* ciemność [[G4655]] WTN-ASN **και** *kai* a [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **σεληνη** *selēnē* księżyc [[G4582]] [[N-NSF]] **εις** *eis* w [[G1519]] [[PREP]] **αιμα** *haima* krew [[G129]] WTN-ASN **πριν** *prin* zanim – pierwej [[G4250]] [[ADV]] **η** *hē* niż [[G2228]] WTPRT **ελθειν** *elthein* przyjść [[G2064]] [[V-2AAN]] **την** *tēn* [[G3588]] WTT-ASF **ημεραν** *hēmeran* dzień [[G2250]] WTN-ASF **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **την** *tēn* (ten) [[G3588]] WTT-ASF **μεγαλην** *megalēn* wielki [[G3173]] WTA-ASF **και** *kai* i [[G2532]] [[CONJ]] **επιφανη** *epifanē* chwalebny – wspaniały [[G2016]] WTA-ASF
###### **Dz 2,21**
 **και** *kai* I [[G2532]] [[CONJ]] **εσται** *estai* będzie [[G2071]] WTV-FXI-3S **πας** *pas* każdy [[G3956]] [[A-NSM]] **ος** *hos* który- [[G3739]] WTR-NSM **αν** *an* kolwiek [[G302]] WTPRT **επικαλεσηται** *epikalesētai* przywołałby [[G1941]] WTV-AMS-3S **το** *to* [[G3588]] WTT-ASN **ονομα** *onoma* imię [[G3686]] WTN-ASN **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **σωθησεται** *sōthēsetai* zostanie zbawiony – zostanie uratowany [[G4982]] WTV-FPI-3S
###### **Dz 2,22**
 **ανδρες** *andres* Mężowie [[G435]] WTN-VPM **ισραηλιται** *israēlitai* Izraelici – [ten, który walczył z Bogiem] [[G2475]] WTN-VPM **ακουσατε** *akousate* posłuchajcie [[G191]] WTV-AAM-2P **τους** *tous* [[G3588]] WTT-APM **λογους** *logous* słów [[G3056]] [[N-APM]] **τουτους** *toutous* tych [[G5128]] WTD-APM **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]] **τον** *ton* [[G3588]] [[T-ASM]] **ναζωραιον** *nazōraion* Nazarejczyka [[G3480]] [[N-ASM]] **ανδρα** *andra* męża [[G435]] [[N-ASM]] **απο** *apo* od [[G575]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **αποδεδειγμενον** *apodedeigmenon* który jest pokazany [[G584]] WTV-RPP-ASM **εις** *eis* ku [[G1519]] [[PREP]] **υμας** *hymas* wam [[G5209]] WTP-2AP **δυναμεσιν** *dynamesin* mocami [[G1411]] WTN-DPF **και** *kai* i [[G2532]] [[CONJ]] **τερασιν** *terasin* cudami [[G5059]] WTN-DPN **και** *kai* i [[G2532]] [[CONJ]] **σημειοις** *sēmeiois* znakami [[G4592]] WTN-DPN **οις** *hois* które [[G3739]] WTR-DPN **εποιησεν** *epoiēsen* uczynił [[G4160]] [[V-AAI-3S]] **δι** *di* przez [[G1223]] [[PREP]] **αυτου** *autou* Niego [[G846]] [[P-GSM]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **εν** *en* w [[G1722]] [[PREP]] **μεσω** *mesō* pośród [[G3319]] WTA-DSN **υμων** *hymōn* was [[G5216]] WTP-2GP **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **αυτοι** *autoi* sami [[G846]] WTP-NPM **οιδατε** *oidate* wiecie [[G1492]] WTV-RAI-2P
###### **Dz 2,23**
 **τουτον** *touton* Tego [[G5126]] WTD-ASM **τη** *tē* [[G3588]] WTT-DSF **ωρισμενη** *hōrismenē* który jest ustanowiony – który jest ustalony [[G3724]] WTV-RPP-DSF **βουλη** *boulē* postanowieniem – radą [[G1012]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **προγνωσει** *prognōsei* wcześniejszym poznaniem – wyprzedzającą wiedzą [[G4268]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εκδοτον** *ekdoton* wydanego [[G1560]] WTA-ASM **λαβοντες** *labontes* wziąwszy [[G2983]] WTV-2AAP-NPM **δια** *dia* przez [[G1223]] [[PREP]] **χειρων** *cheirōn* ręce [[G5495]] WTN-GPF **ανομων** *anomōn* bezprawnych – nieprawych [[G459]] WTA-GPM **προσπηξαντες** *prospēksantes* przytwierdziwszy – przymocowawszy [[G4362]] WTV-AAP-NPM **ανειλετε** *aneilete* zabiliście – znieśliście [[G337]] WTV-2AAI-2P
###### **Dz 2,24**
 **ον** *hon* którego [[G3739]] WTR-ASM **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ανεστησεν** *anestēsen* wzbudził – podniósł [[G450]] [[V-AAI-3S]] **λυσας** *lysas* rozwiązawszy – zniszczywszy [[G3089]] WTV-AAP-NSM **τας** *tas* [[G3588]] WTT-APF **ωδινας** *ōdinas* bóle [[G5604]] WTN-APF **του** *tou* [[G3588]] WTT-GSM **θανατου** *thanatou* śmierci [[G2288]] [[N-GSM]] **καθοτι** *kathoti* ponieważ [[G2530]] [[ADV]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ην** *ēn* było [[G2258]] [[V-IXI-3S]] **δυνατον** *dynaton* możliwe [[G1415]] WTA-NSN **κρατεισθαι** *krateisthai* być chwyconym – być trzymanym [[G2902]] WTV-PPN **αυτον** *auton* On [[G846]] WTP-ASM **υπ** *hyp* przez [[G5259]] [[PREP]] **αυτου** *autou* nią [[G846]] [[P-GSM]]
###### **Dz 2,25**
 **δαβιδ** *dabid* Dawid – [umiłowany] [[G1138]] [[N-PRI]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **εις** *eis* o [[G1519]] [[PREP]] **αυτον** *auton* Nim [[G846]] WTP-ASM **προωρωμην** *proōrōmēn* przewidziałem – widziałem przed sobą [[G4308]] WTV-IMI-1S **τον** *ton* [[G3588]] [[T-ASM]] **κυριον** *kyrion* Pana [[G2962]] [[N-ASM]] **ενωπιον** *enōpion* przede [[G1799]] [[ADV]] **μου** *mou* mną [[G3450]] WTP-1GS **δια** *dia* przez [[G1223]] [[PREP]] **παντος** *pantos* cały [[G3956]] WTA-GSM **οτι** *hoti* że [[G3754]] [[CONJ]] **εκ** *ek* po [[G1537]] [[PREP]] **δεξιων** *deksiōn* prawej stronie – prawicy [[G1188]] WTA-GPM **μου** *mou* mojej [[G3450]] WTP-1GS **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **σαλευθω** *saleuthō* zostałbym wstrząśnięty – zostałbym zachwiany [[G4531]] WTV-APS-1S
###### **Dz 2,26**
 **δια** *dia* Przez [[G1223]] [[PREP]] **τουτο** *touto* to [[G5124]] WTD-ASN **ευφρανθη** *eufranthē* zostało rozweselone – zostało ucieszone [[G2165]] [[V-API-3S]] **η** *hē* [[G3588]] [[T-NSF]] **καρδια** *kardia* serce [[G2588]] [[N-NSF]] **μου** *mou* moje [[G3450]] WTP-1GS **και** *kai* i [[G2532]] [[CONJ]] **ηγαλλιασατο** *ēgalliasato* rozweselił się [[G21]] WTV-ADI-3S **η** *hē* [[G3588]] [[T-NSF]] **γλωσσα** *glōssa* język [[G1100]] [[N-NSF]] **μου** *mou* mój [[G3450]] WTP-1GS **ετι** *eti* jeszcze [[G2089]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **σαρξ** *sarks* ciało [[G4561]] [[N-NSF]] **μου** *mou* moje [[G3450]] WTP-1GS **κατασκηνωσει** *kataskēnōsei* rozbije namiot [[G2681]] WTV-FAI-3S **επ** *ep* w [[G1909]] [[PREP]] **ελπιδι** *elpidi* nadziei [[G1680]] [[N-DSF]]
###### **Dz 2,27**
 **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εγκαταλειψεις** *egkataleipseis* opuścisz – pozostawisz [[G1459]] WTV-FAI-2S **την** *tēn* [[G3588]] WTT-ASF **ψυχην** *psychēn* duszy – życia [[G5590]] WTN-ASF **μου** *mou* mojej [[G3450]] WTP-1GS **εις** *eis* w [[G1519]] [[PREP]] **αδου** *hadou* piekle – Hadesie [[G86]] [[N-GSM]] **ουδε** *oude* ani [[G3761]] [[ADV]] **δωσεις** *dōseis* dasz [[G1325]] WTV-FAI-2S **τον** *ton* (aby) [[G3588]] [[T-ASM]] **οσιον** *hosion* świętobliwy – święty [[G3741]] WTA-ASM **σου** *sou* twój [[G4675]] WTP-2GS **ιδειν** *idein* zobaczyć [[G1492]] [[V-2AAN]] **διαφθοραν** *diafthoran* rozkład – zepsucie [[G1312]] WTN-ASF
###### **Dz 2,28**
 **εγνωρισας** *egnōrisas* Oznajmiłeś – Dałeś poznać [[G1107]] WTV-AAI-2S **μοι** *moi* mi [[G3427]] WTP-1DS **οδους** *hodous* drogi [[G3598]] WTN-APF **ζωης** *zōēs* życia [[G2222]] [[N-GSF]] **πληρωσεις** *plērōseis* wypełnisz [[G4137]] WTV-FAI-2S **με** *me* mnie [[G3165]] WTP-1AS **ευφροσυνης** *eufrosynēs* radością – weselem [[G2167]] [[N-GSF]] **μετα** *meta* z [[G3326]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **προσωπου** *prosōpou* oblicza – twarzy [[G4383]] [[N-GSN]] **σου** *sou* Twojego [[G4675]] WTP-2GS
###### **Dz 2,29**
 **ανδρες** *andres* Mężowie [[G435]] WTN-VPM **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **εξον** *ekson* które wolno – które jest dozwolone [[G1832]] WTV-PQP-NSN **ειπειν** *eipein* powiedzieć [[G2036]] [[V-2AAN]] **μετα** *meta* ze [[G3326]] [[PREP]] **παρρησιας** *parrēsias* śmiałością [[G3954]] [[N-GSF]] **προς** *pros* do [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **περι** *peri* o [[G4012]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **πατριαρχου** *patriarchou* patriarsze [[G3966]] [[N-GSM]] **δαβιδ** *dabid* Dawidzie – [umiłowany] [[G1138]] [[N-PRI]] **οτι** *hoti* że [[G3754]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **ετελευτησεν** *eteleutēsen* umarł [[G5053]] [[V-AAI-3S]] **και** *kai* i [[G2532]] [[CONJ]] **εταφη** *etafē* został pogrzebany [[G2290]] WTV-2API-3S **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **μνημα** *mnēma* grobowiec [[G3418]] WTN-NSN **αυτου** *autou* jego [[G846]] [[P-GSM]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **εν** *en* wśród [[G1722]] [[PREP]] **ημιν** *hēmin* nas [[G2254]] WTP-1DP **αχρι** *achri* aż do [[G891]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **ημερας** *hēmeras* dnia [[G2250]] [[N-GSF]] **ταυτης** *tautēs* tego [[G3778]] WTD-GSF
###### **Dz 2,30**
 **προφητης** *profētēs* prorok [[G4396]] [[N-NSM]] **ουν** *oun* więc [[G3767]] [[CONJ]] **υπαρχων** *hyparchōn* będąc [[G5225]] [[V-PAP-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ειδως** *eidōs* wiedząc [[G1492]] WTV-RAP-NSM **οτι** *hoti* że [[G3754]] [[CONJ]] **ορκω** *horkō* przysięgą [[G3727]] WTN-DSM **ωμοσεν** *ōmosen* przysiągł [[G3660]] [[V-AAI-3S]] **αυτω** *autō* mu [[G846]] WTP-DSM **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **εκ** *ek* z [[G1537]] [[PREP]] **καρπου** *karpou* owocu [[G2590]] [[N-GSM]] **της** *tēs* [[G3588]] [[T-GSF]] **οσφυος** *osfyos* lędźwi – biodra [[G3751]] [[N-GSF]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **το** *to* [[G3588]] WTT-ASN **κατα** *kata* według [[G2596]] [[PREP]] **σαρκα** *sarka* ciała [[G4561]] WTN-ASF **αναστησειν** *anastēsein* wzbudzić – podnieść [[G450]] WTV-FAN **τον** *ton* [[G3588]] [[T-ASM]] **χριστον** *christon* Pomazańca [[G5547]] [[N-ASM]] **καθισαι** *kathisai* posadzić [[G2523]] [[V-AAN]] **επι** *epi* na [[G1909]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronie [[G2362]] [[N-GSM]] **αυτου** *autou* jego [[G846]] [[P-GSM]]
###### **Dz 2,31**
 **προιδων** *proidōn* Przewidziawszy wcześniej – Zobaczywszy przed sobą [[G4275]] WTV-2AAP-NSM **ελαλησεν** *elalēsen* powiedział [[G2980]] [[V-AAI-3S]] **περι** *peri* o [[G4012]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **αναστασεως** *anastaseōs* powstaniu – wzbudzeniu [[G386]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **οτι** *hoti* że [[G3754]] [[CONJ]] **ου** *hou* nie [[G3756]] [[PRT-N]] **κατελειφθη** *kateleifthē* została pozostawiona – została opuszczona [[G2641]] [[V-API-3S]] **η** *hē* [[G3588]] [[T-NSF]] **ψυχη** *psychē* dusza – życie [[G5590]] [[N-NSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **εις** *eis* w [[G1519]] [[PREP]] **αδου** *hadou* piekle – Hadesie [[G86]] [[N-GSM]] **ουδε** *oude* ani [[G3761]] [[ADV]] **η** *hē* [[G3588]] [[T-NSF]] **σαρξ** *sarks* ciało [[G4561]] [[N-NSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ειδεν** *eiden* zobaczyło – widziało [[G1492]] WTV-2AAI-3S **διαφθοραν** *diafthoran* rozkład – zepsucie [[G1312]] WTN-ASF
###### **Dz 2,32**
 **τουτον** *touton* Tego [[G5126]] WTD-ASM **τον** *ton* [[G3588]] [[T-ASM]] **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]] **ανεστησεν** *anestēsen* wzbudził – podniósł [[G450]] [[V-AAI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ου** *hou* czego [[G3739]] WTR-GSM **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **ημεις** *hēmeis* my [[G2249]] WTP-1NP **εσμεν** *esmen* jesteśmy [[G2070]] WTV-PXI-1P **μαρτυρες** *martyres* świadkowie [[G3144]] WTN-NPM
###### **Dz 2,33**
 **τη** *tē* [[G3588]] WTT-DSF **δεξια** *deksia* Prawicą [[G1188]] WTA-DSF **ουν** *oun* więc [[G3767]] [[CONJ]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **υψωθεις** *hypsōtheis* zostawszy wywyższonym [[G5312]] WTV-APP-NSM **την** *tēn* [[G3588]] WTT-ASF **τε** *te* zarówno – także [[G5037]] WTPRT **επαγγελιαν** *epangelian* obietnicę [[G1860]] WTN-ASF **του** *tou* [[G3588]] WTT-GSN **αγιου** *hagiou* Świętego [[G40]] [[A-GSN]] **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **λαβων** *labōn* wziąwszy [[G2983]] WTV-2AAP-NSM **παρα** *para* od [[G3844]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **πατρος** *patros* Ojca [[G3962]] [[N-GSM]] **εξεχεεν** *eksecheen* wylał [[G1632]] [[V-AAI-3S]] **τουτο** *touto* to [[G5124]] WTD-ASN **ο** *ho* co [[G3739]] WTR-ASN **νυν** *nyn* teraz [[G3568]] [[ADV]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **βλεπετε** *blepete* widzicie [[G991]] WTV-PAI-2P **και** *kai* i [[G2532]] [[CONJ]] **ακουετε** *akouete* słyszycie [[G191]] WTV-PAI-2P
###### **Dz 2,34**
 **ου** *ou* Nie [[G3756]] [[PRT-N]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **δαβιδ** *dabid* Dawid – [umiłowany] [[G1138]] [[N-PRI]] **ανεβη** *anebē* wszedł – wstąpił [[G305]] WTV-2AAI-3S **εις** *eis* do [[G1519]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **ουρανους** *ouranous* niebios [[G3772]] [[N-APM]] **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **αυτος** *autos* sam [[G846]] WTP-NSM **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **τω** *tō* [[G3588]] WTT-DSM **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **μου** *mou* mojemu [[G3450]] WTP-1GS **καθου** *kathou* siądź [[G2521]] WTV-PNM-2S **εκ** *ek* po [[G1537]] [[PREP]] **δεξιων** *deksiōn* prawej stronie – prawicy [[G1188]] WTA-GPM **μου** *mou* mojej [[G3450]] WTP-1GS
###### **Dz 2,35**
 **εως** *heōs* aż [[G2193]] [[CONJ]] **αν** *an* (kiedy)kolwiek [[G302]] WTPRT **θω** *thō* położyłbym [[G5087]] WTV-2AAS-1S **τους** *tous* [[G3588]] WTT-APM **εχθρους** *echthrous* wrogów – nieprzyjaciół [[G2190]] WTA-APM **σου** *sou* Twoich [[G4675]] WTP-2GS **υποποδιον** *hypopodion* (jako) podnóżek [[G5286]] WTN-ASN **των** *tōn* [[G3588]] WTT-GPM **ποδων** *podōn* stóp [[G4228]] WTN-GPM **σου** *sou* Twoich [[G4675]] WTP-2GS
###### **Dz 2,36**
 **ασφαλως** *asfalōs* Niezawodnie – Ostrożnie [[G806]] [[ADV]] **ουν** *oun* więc [[G3767]] [[CONJ]] **γινωσκετω** *ginōsketō* niech wie [[G1097]] WTV-PAM-3S **πας** *pas* każdy [[G3956]] [[A-NSM]] **οικος** *oikos* dom [[G3624]] [[N-NSM]] **ισραηλ** *israēl* Izraela – [ten, który walczył z Bogiem] [[G2474]] [[N-PRI]] **οτι** *hoti* że [[G3754]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **κυριον** *kyrion* Panem [[G2962]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **χριστον** *christon* Pomazańcem [[G5547]] [[N-ASM]] **αυτον** *auton* Go [[G846]] WTP-ASM **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **εποιησεν** *epoiēsen* uczynił [[G4160]] [[V-AAI-3S]] **τουτον** *touton* Tego [[G5126]] WTD-ASM **τον** *ton* [[G3588]] [[T-ASM]] **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]] **ον** *hon* którego [[G3739]] WTR-ASM **υμεις** *hymeis* wy [[G5210]] WTP-2NP **εσταυρωσατε** *estaurōsate* ukrzyżowaliście [[G4717]] WTV-AAI-2P
###### **Dz 2,37**
 **ακουσαντες** *akousantes* Usłyszawszy [[G191]] WTV-AAP-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **κατενυγησαν** *katenygēsan* zostały przekute – zostały przebite [[G2660]] WTV-2API-3P **τη** *tē* [[G3588]] WTT-DSF **καρδια** *kardia* serce (serca) [[G2588]] [[N-DSF]] **ειπον** *eipon* powiedzieli [[G2036]] WTV-2AAI-3P **τε** *te* zarówno – także [[G5037]] WTPRT **προς** *pros* do [[G4314]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **πετρον** *petron* Piotra – [kamyk] [[G4074]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **τους** *tous* [[G3588]] WTT-APM **λοιπους** *loipous* pozostałych [[G3062]] WTA-APM **αποστολους** *apostolous* wysłanników [[G652]] [[N-APM]] **τι** *ti* co [[G5101]] WTI-ASN **ποιησομεν** *poiēsomen* uczynimy [[G4160]] WTV-FAI-1P **ανδρες** *andres* mężowie [[G435]] WTN-VPM **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM
###### **Dz 2,38**
 **πετρος** *petros* Piotr – [kamyk] [[G4074]] [[N-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **εφη** *efē* powiedział [[G5346]] [[V-IXI-3S]] **προς** *pros* do [[G4314]] [[PREP]] **αυτους** *autous* nich [[G846]] [[P-APM]] **μετανοησατε** *metanoēsate* opamiętajcie się – zmieńcie myślenie [[G3340]] WTV-AAM-2P **και** *kai* i [[G2532]] [[CONJ]] **βαπτισθητω** *baptisthētō* niech zostanie zanurzony [[G907]] WTV-APM-3S **εκαστος** *hekastos* każdy [[G1538]] [[A-NSM]] **υμων** *hymōn* (z) was [[G5216]] WTP-2GP **επι** *epi* w [[G1909]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **ονοματι** *onomati* imieniu [[G3686]] WTN-DSN **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **εις** *eis* na – ku [[G1519]] [[PREP]] **αφεσιν** *afesin* uwolnienie – wyzwolenie [[G859]] WTN-ASF **αμαρτιων** *hamartiōn* grzechów [[G266]] WTN-GPF **και** *kai* a [[G2532]] [[CONJ]] **ληψεσθε** *lēpsesthe* weźmiecie – przyjmiecie [[G2983]] WTV-FDI-2P **την** *tēn* [[G3588]] WTT-ASF **δωρεαν** *dōrean* dar – darowiznę [[G1431]] WTN-ASF **του** *tou* [[G3588]] WTT-GSN **αγιου** *hagiou* Świętego [[G40]] [[A-GSN]] **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]]
###### **Dz 2,39**
 **υμιν** *hymin* Wam [[G5213]] WTP-2DP **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **η** *hē* [[G3588]] [[T-NSF]] **επαγγελια** *epangelia* obietnica [[G1860]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **τοις** *tois* [[G3588]] WTT-DPN **τεκνοις** *teknois* dzieciom [[G5043]] WTN-DPN **υμων** *hymōn* waszym [[G5216]] WTP-2GP **και** *kai* i [[G2532]] [[CONJ]] **πασιν** *pasin* wszystkim [[G3956]] WTA-DPM **τοις** *tois* [[G3588]] WTT-DPM **εις** *eis* do [[G1519]] [[PREP]] **μακραν** *makran* dalekich [[G3112]] [[ADV]] **οσους** *hosous* ilu- [[G3745]] WTK-APM **αν** *an* kolwiek [[G302]] WTPRT **προσκαλεσηται** *proskalesētai* przywołałby – wezwałby [[G4341]] WTV-ADS-3S **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ημων** *hēmōn* nasz [[G2257]] WTP-1GP
###### **Dz 2,40**
 **ετεροις** *heterois* Innymi [[G2087]] WTA-DPM **τε** *te* zarówno – także [[G5037]] WTPRT **λογοις** *logois* słowami [[G3056]] WTN-DPM **πλειοσιν** *pleiosin* liczniejszymi [[G4119]] WTA-DPM-C **διεμαρτυρετο** *diemartyreto* zaświadczył – oświadczył [[G1263]] WTV-INI-3S **και** *kai* i [[G2532]] [[CONJ]] **παρεκαλει** *parekalei* zachęcał – prosił [[G3870]] WTV-IAI-3S **λεγων** *legōn* mówiąc [[G3004]] [[V-PAP-NSM]] **σωθητε** *sōthēte* zostańcie zbawionymi – zostańcie uratowanymi [[G4982]] WTV-APM-2P **απο** *apo* z [[G575]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **γενεας** *geneas* pokolenia [[G1074]] [[N-GSF]] **της** *tēs* [[G3588]] [[T-GSF]] **σκολιας** *skolias* wypaczonego – wykrzywionego [[G4646]] WTA-GSF **ταυτης** *tautēs* tego [[G3778]] WTD-GSF
###### **Dz 2,41**
 **οι** *hoi* (ci) [[G3588]] WTT-NPM **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **ουν** *oun* więc [[G3767]] [[CONJ]] **ασμενως** *asmenōs* z radością [[G780]] [[ADV]] **αποδεξαμενοι** *apodeksamenoi* którzy przyjęli – którzy przywitali z radością [[G588]] WTV-ADP-NPM **τον** *ton* [[G3588]] [[T-ASM]] **λογον** *logon* słowo [[G3056]] [[N-ASM]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **εβαπτισθησαν** *ebaptisthēsan* zostali zanurzeni [[G907]] WTV-API-3P **και** *kai* i [[G2532]] [[CONJ]] **προσετεθησαν** *prosetethēsan* zostali przyłączeni – zostali dodani [[G4369]] WTV-API-3P **τη** *tē* (w) [[G3588]] WTT-DSF **ημερα** *hēmera* dniu [[G2250]] [[N-DSF]] **εκεινη** *ekeinē* tym [[G1565]] WTD-DSF **ψυχαι** *psychai* dusze [[G5590]] [[N-NPF]] **ωσει** *hōsei* jakby [[G5616]] [[ADV]] **τρισχιλιαι** *trischiliai* trzy tysiące [[G5153]] [[A-NPF]]
###### **Dz 2,42**
 **ησαν** *ēsan* Byli [[G2258]] WTV-IXI-3P **δε** *de* zaś [[G1161]] [[CONJ]] **προσκαρτερουντες** *proskarterountes* trwającymi niezłomnie [[G4342]] WTV-PAP-NPM **τη** *tē* (w) [[G3588]] WTT-DSF **διδαχη** *didachē* nauce – nauczaniu [[G1322]] [[N-DSF]] **των** *tōn* [[G3588]] WTT-GPM **αποστολων** *apostolōn* wysłanników [[G652]] WTN-GPM **και** *kai* i [[G2532]] [[CONJ]] **τη** *tē* [[G3588]] WTT-DSF **κοινωνια** *koinōnia* wspólnocie [[G2842]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **τη** *tē* [[G3588]] WTT-DSF **κλασει** *klasei* łamaniu [[G2800]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSM **αρτου** *artou* chleba [[G740]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **ταις** *tais* [[G3588]] WTT-DPF **προσευχαις** *proseuchais* modlitwach [[G4335]] WTN-DPF
###### **Dz 2,43**
 **εγενετο** *egeneto* Stała się [[G1096]] WTV-2ADI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **παση** *pasē* każdej [[G3956]] WTA-DSF **ψυχη** *psychē* duszy [[G5590]] [[N-DSF]] **φοβος** *fobos* strach – bojaźń [[G5401]] [[N-NSM]] **πολλα** *polla* wielki [[G4183]] WTA-NPN **τε** *te* zarówno – także [[G5037]] WTPRT **τερατα** *terata* cuda [[G5059]] WTN-NPN **και** *kai* i [[G2532]] [[CONJ]] **σημεια** *sēmeia* znaki [[G4592]] WTN-NPN **δια** *dia* przez [[G1223]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **αποστολων** *apostolōn* wysłanników [[G652]] WTN-GPM **εγινετο** *egineto* stawał się (stawały się) [[G1096]] WTV-INI-3S
###### **Dz 2,44**
 **παντες** *pantes* Wszyscy [[G3956]] WTA-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **πιστευοντες** *pisteuontes* wierzący [[G4100]] WTV-PAP-NPM **ησαν** *ēsan* byli [[G2258]] WTV-IXI-3P **επι** *epi* na [[G1909]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **αυτο** *auto* tym samym [[G846]] WTP-ASN **και** *kai* i [[G2532]] [[CONJ]] **ειχον** *eichon* mieli [[G2192]] WTV-IAI-3P **απαντα** *hapanta* wszystkie [[G537]] WTA-APN **κοινα** *koina* wspólne [[G2839]] WTA-APN
###### **Dz 2,45**
 **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **κτηματα** *ktēmata* posiadłości [[G2933]] WTN-APN **και** *kai* i [[G2532]] [[CONJ]] **τας** *tas* [[G3588]] WTT-APF **υπαρξεις** *hyparkseis* majątki [[G5223]] WTN-APF **επιπρασκον** *epipraskon* sprzedawali [[G4097]] WTV-IAI-3P **και** *kai* i [[G2532]] [[CONJ]] **διεμεριζον** *diemerizon* rozdzielili [[G1266]] WTV-IAI-3P **αυτα** *auta* je [[G846]] WTP-APN **πασιν** *pasin* wszystkim [[G3956]] WTA-DPM **καθοτι** *kathoti* według tego, jak- [[G2530]] [[ADV]] **αν** *an* kolwiek [[G302]] WTPRT **τις** *tis* ktoś [[G5100]] WTX-NSM **χρειαν** *chreian* potrzebę [[G5532]] WTN-ASF **ειχεν** *eichen* miał [[G2192]] WTV-IAI-3S
###### **Dz 2,46**
 **καθ** *kath* Co- [[G2596]] [[PREP]] **ημεραν** *hēmeran* dziennie [[G2250]] WTN-ASF **τε** *te* zarówno – także [[G5037]] WTPRT **προσκαρτερουντες** *proskarterountes* trwając niezłomnie [[G4342]] WTV-PAP-NPM **ομοθυμαδον** *homothymadon* jednomyślnie – jednogłośnie [[G3661]] [[ADV]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **ιερω** *hierō* świątyni [[G2411]] WTN-DSN **κλωντες** *klōntes* łamiąc [[G2806]] WTV-PAP-NPM **τε** *te* zarówno – także [[G5037]] WTPRT **κατ** *kat* po [[G2596]] [[PREP]] **οικον** *oikon* domie [[G3624]] [[N-ASM]] **αρτον** *arton* chleb [[G740]] [[N-ASM]] **μετελαμβανον** *metelambanon* przyjmowali – otrzymywali [[G3335]] WTV-IAI-3P **τροφης** *trofēs* pożywienia – pokarmu [[G5160]] [[N-GSF]] **εν** *en* w [[G1722]] [[PREP]] **αγαλλιασει** *agalliasei* wesołości – radosnym uniesieniu [[G20]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **αφελοτητι** *afelotēti* prostocie – szczerości [[G858]] [[N-DSF]] **καρδιας** *kardias* serca [[G2588]] [[N-GSF]]
###### **Dz 2,47**
 **αινουντες** *ainountes* chwaląc – wielbiąc [[G134]] WTV-PAP-NPM **τον** *ton* [[G3588]] [[T-ASM]] **θεον** *theon* Boga [[G2316]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **εχοντες** *echontes* mając [[G2192]] WTV-PAP-NPM **χαριν** *charin* łaskę [[G5485]] WTN-ASF **προς** *pros* względem [[G4314]] [[PREP]] **ολον** *holon* całego [[G3650]] WTA-ASM **τον** *ton* [[G3588]] [[T-ASM]] **λαον** *laon* ludu [[G2992]] [[N-ASM]] **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **προσετιθει** *prosetithei* przyłączał – dodawał [[G4369]] WTV-IAI-3S **τους** *tous* [[G3588]] WTT-APM **σωζομενους** *sōzomenous* którzy są zbawiani – którzy są ratowani [[G4982]] WTV-PPP-APM **καθ** *kath* co- [[G2596]] [[PREP]] **ημεραν** *hēmeran* dziennie [[G2250]] WTN-ASF **τη** *tē* (do) [[G3588]] WTT-DSF **εκκλησια** *ekklēsia* zgromadzenia – (społeczności) wywołanych [[G1577]] [[N-DSF]] **επι** *epi* na [[G1909]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **αυτο** *auto* to samo [[G846]] WTP-ASN
