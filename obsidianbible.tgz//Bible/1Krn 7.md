# 1Krn 7 BT5
###### **1Krn 7,1**
  Synowie Issachara: Tola, Pua, Jaszub i Szimron, czterej.
###### **1Krn 7,2**
 Synowie Toli: Uzzi, Refajasz, Jeriel, Jachmaj, Jibsam i Samuel, naczelnicy rodów Toli, dzielni wojownicy – za czasów Dawida liczba ich wynosiła według ich rodowodów dwadzieścia dwa tysiące sześciuset.
###### **1Krn 7,3**
 Synowie Uzzjego: Izrachiasz, a synowie Izrachiasza: Mikael, Obadiasz, Joel, Jiszszijasz, pięciu, wszyscy naczelnicy rodów.
###### **1Krn 7,4**
 Przy nich były hufce zbrojne do walki, według spisów i według ich rodów liczące trzydzieści sześć tysięcy, mieli bowiem wiele żon i synów.
###### **1Krn 7,5**
 A bracia ich we wszystkich rodach Issachara, dzielni wojownicy, liczyli osiemdziesiąt siedem tysięcy; wszyscy zapisani w rodowodach.
###### **1Krn 7,6**
 [Synowie] Beniamina: Bela, Beker i Jediael, trzej.
###### **1Krn 7,7**
 Synowie Beli: Esbon, Uzzjel, Jerimot i Iri, pięciu, naczelnicy rodów, dzielni wojownicy, według swoich wykazów rodowych liczyli dwadzieścia dwa tysiące trzydziestu czterech.
###### **1Krn 7,8**
 Synowie Bekera: Zemira, Joasz, Eliezer, Elioenaj, Omri, Jeremot, Abiasz, Anatot i Alamet; ci wszyscy są synami Bekera.
###### **1Krn 7,9**
 Według wykazów rodowych dla swego pokolenia, naczelnicy rodów, dzielni wojownicy, liczyli dwadzieścia tysięcy dwustu.
###### **1Krn 7,10**
 Synowie Jediaela: Bilhan, a synowie Bilhana: Jeusz, Beniamin, Ehud, Kenaana, Zetan, Tarszisz i Achiszachar.
###### **1Krn 7,11**
 Wszyscy ci byli synami Jediaela: naczelnicy rodów, dzielni wojownicy, liczyli siedemnaście tysięcy dwustu, gdy wychodzili w szyku na wojnę.
###### **1Krn 7,12**
 Szuppim i Chuppim; synowie Ira: Chuszim, jego syn Acher.
###### **1Krn 7,13**
 Synowie Neftalego: Jachasjel, Guni, Jeser i Szallum, potomkowie z Bilhy.
###### **1Krn 7,14**
 Synowie Manassesa: Asriel, którego urodziła drugorzędna jego żona, Aramejka. Urodziła ona Makira, ojca Gileada.
###### **1Krn 7,15**
 Makir wziął żony dla Chuppima i Szuppima. Imię jego siostry było Maaka. Imię drugiego syna Selofchad, lecz Selofchad miał tylko córki.
###### **1Krn 7,16**
 Maaka, żona Makira, urodziła syna i dała mu imię Peresz. A bratu jego było na imię Szeresz, którego synami byli Ulam i Rekem.
###### **1Krn 7,17**
 Syn Ulama: Bedan. Ci byli synami Gileada, syna Makira, syna Manassesa.
###### **1Krn 7,18**
 Ich siostra, Hammoleket, urodziła Iszhoda, Abiezera i Machlę.
###### **1Krn 7,19**
 Synami Szemidy byli: Achian, Szekem, Likchi i Aniam.
###### **1Krn 7,20**
 Synowie Efraima: synem jego Szutelach, synem jego Bered, synem jego Tachat, synem jego Eleada, synem jego Tachat,
###### **1Krn 7,21**
 synem jego Zabad, synem jego Szutelach, a także Ezer i Elead. Zabili ich ludzie z Gat, urodzeni w tym kraju, bo tamci zstąpili z góry, aby zabrać ich stada.
###### **1Krn 7,22**
 Efraim, ich ojciec, przez długi czas obchodził żałobę i przychodzili bracia jego, aby go pocieszyć.
###### **1Krn 7,23**
 Potem zbliżył się do swej żony, która poczęła i urodziła syna, i dał mu imię Beria, ponieważ stało się nieszczęście w jego domu.
###### **1Krn 7,24**
 Jego córką była Szeera, która zbudowała Bet-Choron dolne i górne oraz Uzzen-Szeera.
###### **1Krn 7,25**
 < Synami jego byli > Refach i Reszef, synem jego Telach, synem jego Tachan,
###### **1Krn 7,26**
 synem jego Ladan, synem jego Ammihud, synem jego Eliszama,
###### **1Krn 7,27**
 synem jego Nun, synem jego Jozue.
###### **1Krn 7,28**
 Ich posiadłości i ich siedziby były w Betel i miejscowościach przynależnych; w Naaran ku wschodowi, a ku zachodowi w Gezer i miejscowościach przynależnych, w Sychem i miejscowościach przynależnych, aż do Ajji i miast przynależnych.
###### **1Krn 7,29**
 W rękach synów Manassesa były: Bet-Szean i miejscowości przynależne, Taanak i miejscowości przynależne, Megiddo i miejscowości przynależne, Dor i miejscowości przynależne. W tych mieszkali synowie Józefa, syna Izraela.
###### **1Krn 7,30**
 Synowie Asera: Jimna, Jiszwa, Jiszwi, Beria i siostra ich Serach.
###### **1Krn 7,31**
 Synowie Berii: Cheber i Malkiel; ten był ojcem Birzaita.
###### **1Krn 7,32**
 Cheber był ojcem Jafleta, Szemera, Chotama i siostry ich Szuy.
###### **1Krn 7,33**
 Synowie Jafleta: Pasak, Bimhal i Aszwat; to są synowie Jafleta.
###### **1Krn 7,34**
 Synowie Szemera: Achi, Rohga, Chubba i Aram.
###### **1Krn 7,35**
 Synowie brata jego, Helema: Sofach, Jimna, Szelesz i Amal.
###### **1Krn 7,36**
 Synowie Sofacha: Suach, Charnefer, Szual, Beri i Jimra;
###### **1Krn 7,37**
 Beser, Hod, Szamma, Szilsza, Jitran i Beera.
###### **1Krn 7,38**
 Synowie Jetera: Jefunne, Pispa i Ara.
###### **1Krn 7,39**
 Synowie Ulli: Arach, Channiel i Risja.
###### **1Krn 7,40**
 Wszyscy ci synowie Asera, naczelnicy rodów, znamienici mężowie, dzielni wojownicy, główni wśród książąt, a według spisów liczyli w swoich rodowodach dwadzieścia sześć tysięcy wojska zdolnego do walki.
# 1Krn 7 PAU
###### **1Krn 7,1**
 Czterej synowie Issachara to: Tola, Pua, Jaszub i Szimron.
###### **1Krn 7,2**
 Potomkami Toli byli: Uzzi, Refajasz, Jeriel, Jachmaj, Jebsam i Samuel. Byli oni przywódcami rodów Tolitów i dzielnymi wojownikami. Za czasów Dawida, zgodnie ze spisem według przynależności rodowej, Tolitów było dwadzieścia dwa tysiące sześciuset.
###### **1Krn 7,3**
 Potomków Uzziego było pięciu: Izrachiasz i jego synowie - Mikael, Obadiasz, Joel, Jeszijasz. Wszyscy oni byli przywódcami rodów.
###### **1Krn 7,4**
 Wystawiali do walki armię liczącą trzydzieści sześć tysięcy ludzi, podzieloną na rody i rodziny, bo mieli wiele żon i synów.
###### **1Krn 7,5**
 Całe plemię Issachara liczyło osiemdziesiąt siedem tysięcy dzielnych wojowników, należących do wszystkich rodów i zapisanych w księgach rodowych.
###### **1Krn 7,6**
 Trzej synowie Beniamina to: Bela, Beker i Jediael.
###### **1Krn 7,7**
 Potomkami Beli byli: Esbon, Uzzi, Uzzjel, Jerimot i Iri. Tych pięciu było przywódcami rodów, doborowymi wojownikami. Zgodnie z wykazami ich rody liczyły dwadzieścia dwa tysiące trzydziestu czterech mężczyzn.
###### **1Krn 7,8**
 Potomkami Bekera byli: Zemira, Joasz, Eliezer, Elioenaj, Omri, Jeremot, Abiasz, Anatot i Alamet - wszyscy oni byli Bekerytami.
###### **1Krn 7,9**
 Zgodnie z wykazami rodowymi przywódców rodów i dzielnych wojowników było dwadzieścia tysięcy dwustu.
###### **1Krn 7,10**
 Potomkami Jediaela byli Bilhan i jego synowie: Jeusz, Beniamin, Ehud, Kenaana, Zetan, Tarszisz i Achiszachar.
###### **1Krn 7,11**
 Wszystkich potomków Jediaela, przywódców rodów oraz dzielnych wojowników zdolnych do walki, było siedemnaście tysięcy dwustu.
###### **1Krn 7,12**
 Synami Ira byli: Szuppim i Chuppim. Chuszim był synem Achera.
###### **1Krn 7,13**
 Potomkami Neftalego byli: Jachasjel, Guni, Jeser i Szallum, synowie Bilhy.
###### **1Krn 7,14**
 Potomkowie Manassesa: jego syn Asriel, którego urodziła mu jego drugorzędna żona, Aramejka. Ona także wydała na świat Makira, ojca Gileada.
###### **1Krn 7,15**
 Makir wziął żony dla Szuppima i Chuppima, jego siostrą zaś była Maaka. Drugiemu synowi Manassesa było na imię Selofchad i miał on tylko córki.
###### **1Krn 7,16**
 Maaka, żona Makira, urodziła mu syna, któremu dała imię Peresz. Jego brat zaś miał na imię Szeresz i był ojcem Ulama i Rekema.
###### **1Krn 7,17**
 Synem Ulama był Bedan. To są potomkowie Gileada, syna Makira, syna Manassesa.
###### **1Krn 7,18**
 Jego siostra Hammoleket urodziła Iszhoda, Abiezera i Machlę.
###### **1Krn 7,19**
 Synami Szemidy byli: Achian, Szekem, Likchi i Aniam.
###### **1Krn 7,20**
 Potomkami Efraima byli: Szutelach, jego syn Bered, jego syn Tachat, jego syn Eleada, jego syn Tachat,
###### **1Krn 7,21**
 jego syn Zabad, jego syn Szutelach, a także Ezer i Elead. Zabili ich ludzie z Gat, urodzeni na tej ziemi, gdy tamci zeszli, aby zabrać ich stada.
###### **1Krn 7,22**
 Ich ojciec Efraim długo trwał w żałobie po nich, a jego bracia przychodzili go pocieszać.
###### **1Krn 7,23**
 Potem współżył ze swoją żoną, ona poczęła i urodziła mu syna. Nadano mu imię Beria, ponieważ stało się nieszczęście w jego domu.
###### **1Krn 7,24**
 Miał też córkę Szeerę, która zbudowała Bet-Choron dolne i górne oraz Uzzen-Szeera.
###### **1Krn 7,25**
 Miał jeszcze innych synów: Refacha i Reszefa, ojca Telacha, ojca Tachana.
###### **1Krn 7,26**
 Synem Tachana był Ladan, synem zaś Ladana - Ammihud, Ammihud był ojcem Eliszamy.
###### **1Krn 7,27**
 Eliszama był ojcem Nuna, którego synem był Jozue.
###### **1Krn 7,28**
 Ich posiadłości i siedziby obejmowały Betel wraz z przynależnymi miejscowościami, Naaran na wschód oraz Gezer od zachodu wraz z podległymi osiedlami, Sychem i podległe mu osiedla aż po Ajję z przysiółkami.
###### **1Krn 7,29**
 Plemię Manassesa posiadało Bet-Szean wraz z podległymi przysiółkami, Taanak wraz z podległymi osadami, Megiddo wraz z przynależnymi osiedlami i Dor wraz z przynależnymi osadami. W tych wszystkich miastach mieszkali potomkowie Józefa, syna Izraela.
###### **1Krn 7,30**
 Dzieci Asera: Jemna, Jeszwa, Jeszwi, Beria oraz ich siostra Serach.
###### **1Krn 7,31**
 Synowie Berii: Cheber i Malkiel, który był ojcem Birzaita.
###### **1Krn 7,32**
 Cheber zaś był ojcem Jafleta, Szemera, Chotama oraz ich siostry Szuy.
###### **1Krn 7,33**
 Synowie Jafleta: Pasak, Bimhal i Aszwat - to są synowie Jafleta.
###### **1Krn 7,34**
 Synowie Szemera: Achi, Rohga, Chubba i Aram.
###### **1Krn 7,35**
 Synowie jego brata Helema: Sofach, Jemna, Szelesz i Amal.
###### **1Krn 7,36**
 Synowie Sofacha: Suach, Charnefer, Szual, Beri i Jemra,
###### **1Krn 7,37**
 Beser, Hod, Szamma, Szilsza, Jetran i Beera.
###### **1Krn 7,38**
 Synowie Jetera: Jefunne, Pispa i Ara.
###### **1Krn 7,39**
 Synowie Ulli: Arach, Channiel i Risja.
###### **1Krn 7,40**
 Wszystkich potomków Asera, przywódców rodów, ludzi sławnych, doskonałych wojowników, pierwszych wśród książąt, było w sumie, zgodnie z wykazami rodowymi, dwadzieścia sześć tysięcy zdolnych do walki.
# 1Krn 7 BP
###### **1Krn 7,1**
 Synami Issachara byli: Tola, Pua, Jaszub i Szimron [ci] czterej.
###### **1Krn 7,2**
 Synami Toli byli: Uzzi, Refaja, Jeriel, Jachmaj, Jibsam i Szemuel, naczelnicy rodów Toli, [mężowie] bardzo dzielni. Liczba ich według rodowodów wynosiła w czasach Dawida 22 600.
###### **1Krn 7,3**
 Synem Uzziego był Jizrachja; synami Jizrachji byli: Mikael, Obadia, Joel oraz Jiszszijja, razem pięciu, a wszyscy byli naczelnikami rodów.
###### **1Krn 7,4**
 Wystawiali oni według swoich rodów i według domów oddziały zbrojne do walki w liczbie 36 000; mieli bowiem wiele żon i dzieci.
###### **1Krn 7,5**
 Braci ich ze wszystkich rodów pokolenia Issachara, [mężów] bardzo dzielnych, wszystkich zapisanych w rodowodach było 87 000.
###### **1Krn 7,6**
 [Synami] Beniamina byli: Bela, Beker, Jediael, [ci] trzej.
###### **1Krn 7,7**
 Synami zaś Beli byli: Ecbon, Uzzi, Uzziel, Jerimot i Iri, pięciu naczelników rodów, mężów walecznych. Według spisu rodowodów było ich wszystkich 22 034.
###### **1Krn 7,8**
 Synami Bekera byli: Zemira, Joasz, Eliezer, Elioenaj, Omri, Jeremot, Abijja, Anatot i Alemet. Ci wszyscy byli synami Bekera.
###### **1Krn 7,9**
 Było ich wszystkich zliczonych w rodowodach według ich rodów 20 200. Oni to byli bardzo dzielnymi [mężami] i naczelnikami swych rodów.
###### **1Krn 7,10**
 Synem Jediaela był Bilhan. Synami zaś Bilhana byli: Jeusz, Beniamin, Ehud, Kenaana, Zetan, Tarszisz i Achiszachar.
###### **1Krn 7,11**
 Ci wszyscy synowie Jediaela byli naczelnikami rodów i bardzo dzielnymi [mężami]. [Naliczono ich] 17 200 [mężów] zdolnych do walki.
###### **1Krn 7,12**
 Szuppim i Chuppim byli synami Ira; Chuszim był synem Achera.
###### **1Krn 7,13**
 Synami Neftalego byli: Jachaciel, Guni, Jecer i Szallum. Byli oni synami Bilhy.
###### **1Krn 7,14**
 Synami Manassego byli: Asriel, którego urodziła Aramejka - jego drugorzędna żona. Urodziła ona również Makira, który był ojcem Gileada.
###### **1Krn 7,15**
 Makir wziął żony dla Chuppima i Szuppima, a siostrze jego było na imię Maaka. Drugi [syn] miał na imię Celofchad. Celofchad jednak miał tylko córki.
###### **1Krn 7,16**
 Maaka, żona Makira, urodziła syna i nadała mu imię Peresz; bratu jego było na imię Szeresz, a jego synami byli Ulam i Rekem.
###### **1Krn 7,17**
 Synem Ulama był Bedan. Ci oto są synami Gileada, syna Makira, który był synem Manassego.
###### **1Krn 7,18**
 Siostra jego Hammoleket urodziła Iszhoda, Abiezera i Machlę.
###### **1Krn 7,19**
 Synami Szemidy byli: Achian, Szekem, Likchi i Aniam.
###### **1Krn 7,20**
 Synami Efraima byli: Szutelach, jego synem był Bered, który miał syna Tachata, ten zaś miał syna Eladę, a jego synem był Tachat.
###### **1Krn 7,21**
 Jego synem był Zabad, jego synem Szutelach, jego synami Ezer i Elad. Zabili ich ludzie z Gat, którzy urodzili się w kraju; zeszli oni bowiem, aby zająć ich stada.
###### **1Krn 7,22**
 Ojciec ich, Efraim, opłakiwał ich przez wiele lat i bracia jego przybyli, aby go pocieszyć.
###### **1Krn 7,23**
 Potem współżył z żoną swoją, która poczęła i urodziła syna; nadał mu imię Beria, ponieważ wydarzyło się nieszczęście w jego domu.
###### **1Krn 7,24**
 Jego córką była Szeera. Ona to zbudowała Dolne i Górne Bet-Choron oraz Uzen-Szeera.
###### **1Krn 7,25**
 Jego synem był Refach i Reszef, a jego synem Telach, tego zaś synem był Tachan.
###### **1Krn 7,26**
 Jego synem był Ladan, jego synem Ammihud, jego synem Eliszama,
###### **1Krn 7,27**
 jego synem Non, a tego synem Jehoszua.
###### **1Krn 7,28**
 Ich posiadłość i miejsce zamieszkania stanowiły: Betel i należące do niego miejscowości, od strony wschodniej Naaram, od strony zachodniej Gezer i zależne od niego miejscowości, Sychem i zależne od niego miejscowości aż do Ajji i zależnych od niej miejscowości.
###### **1Krn 7,29**
 W ręku potomków Manassego znajdowały się: Bet-Szean wraz z zależnymi od niego miejscowościami, Taanak i zależne od niego miejscowości, Megiddo i zależne od niego miejscowości, Dor i zależne od niego miejscowości. W nich to mieszkali potomkowie Józefa, syna Izraela.
###### **1Krn 7,30**
 Synami Aszera byli: Jimna, Jiszwa, Jiszwi i Beria. Siostrą ich była Serach.
###### **1Krn 7,31**
 Synami Berii byli: Cheber i Malkiel, który był ojcem Birzaita.
###### **1Krn 7,32**
 Cheber był ojcem Jafleta, Szomera, Chotama oraz ich siostry Szuy.
###### **1Krn 7,33**
 Synami Jafleta byli: Pasak, Bimhal i Aszwat. Ci byli synami Jafleta.
###### **1Krn 7,34**
 Synami Szemera byli: Achi, Rohga, Jechubba i Aram.
###### **1Krn 7,35**
 Synami Helema, jego brata byli: Cofach, Jimna, Szelesz i Amal.
###### **1Krn 7,36**
 Synami Cofacha byli: Suach, Charnefer, Szual, Beri, Jimra,
###### **1Krn 7,37**
 Becer, Hod, Szamma, Szilsza, Jitran i Beera.
###### **1Krn 7,38**
 Synami Jetera byli: Jefunne, Pispa i Ara.
###### **1Krn 7,39**
 Synami Ulli byli: Arach, Channiel i Ricja.
###### **1Krn 7,40**
 Wszyscy ci synowie Aszera byli naczelnikami rodów, mężami znakomitymi, dzielnymi wojownikami, najprzedniejszymi wśród książąt. Wymienionych w rodowodzie, zdolnych do walki mężów, było 26 000.
# 1Krn 7 BR
###### **1Krn 7,1**
 A oto czterej synowie Issachara: Tola, Pua, Jaszub i Szimron.
###### **1Krn 7,2**
 Synami Toli byli: Uzzi, Refajasz, Jeriel, Jachmaj, Jibsam i Samuel; wszyscy ci byli naczelnikami poszczególnych rodów i zasłynęli jako dzielni wojownicy. W czasach Dawida liczba wszystkich potomków Toli wynosiła, według ich rodowodów, dwadzieścia dwa tysiące sześciuset.
###### **1Krn 7,3**
 Synem Uzziego był Izrachiasz, a synami Izrachiasza Mikael, Obadiasz, Joel, Jiszszijasz - razem pięciu - wszyscy pełniący urząd naczelników rodów.
###### **1Krn 7,4**
 Stali oni na czele oddziałów zbrojnych gotowych do walki. Ich liczba, według poszczególnych rodów i rodzin, wynosiła, razem z wszystkimi żonami i synami, trzydzieści sześć tysięcy.
###### **1Krn 7,5**
 Ich braci, dzielnych wojowników, z wszystkich rodów Issachara było osiemdziesiąt siedem tysięcy. Wszyscy są zapisani w swoich rodowodach.
###### **1Krn 7,6**
 A oto trzej synowie Beniamina: Bela, Beker i Jediael.
###### **1Krn 7,7**
 Synami zaś Beli byli: Ebson, Uzzi, Uzzjel, Jerimot oraz Iri - razem pięciu; wszyscy byli naczelnikami rodów i dzielnymi wojownikami. Wszystkich potomków Beli było, według wykazów rodowych, dwadzieścia dwa tysiące trzydziestu czterech.
###### **1Krn 7,8**
 Synami Bekera byli: Zemira, Joasz, Eliezer, Elieonaj, Omri, Jeremot, Abiasz, Anatot i Alamet - ci byli synami Bekera.
###### **1Krn 7,9**
 Według wykazów rodowych ich pokolenia wszystkich, jak obliczali naczelnicy rodów, dzielnych wojowników było dwadzieścia tysięcy dwustu.
###### **1Krn 7,10**
 Synem Jediaela był Bilhan, a synami Bilhana: Jeusz, Beniamin, Ehud, Kenaana, Zetan, Tarszisz i Achiszachar.
###### **1Krn 7,11**
 Wszyscy byli potomkami Jediaela, naczelnikami rodów, dzielnymi wojownikami. Gdy wyruszali w szyku bojowym na wojnę, było ich łącznie siedemnaście tysięcy dwustu.
###### **1Krn 7,12**
 Szuppim i Chyppim byli synami Ira, a Chuszim był synem Achera.
###### **1Krn 7,13**
 Synami Neftalego byli: Jachasjel, Guni, Jeser i Szalum. Ich matką była Bilha.
###### **1Krn 7,14**
 Synem Manassesa był Asriel, którego urodziła nałożnica Manassesa, z pochodzenia Aramejka. Była ona również matką Makira, ojca Gileada.
###### **1Krn 7,15**
 Makir znalazł z czasem żony dla Chuppima i Szuppima. Jego siostra miała na imię Maaka, a drugi [po Asrielu] syn [Manassesa] nazywał się Selofchad; Selofchad nie miał synów, lecz same córki.
###### **1Krn 7,16**
 Maaka, żona Makira, urodziła syna, któremu nadała imię Peresz. Jego brat nazywał się Szeresz i miał dwóch synów: Ulama i Rekema.
###### **1Krn 7,17**
 Synem Ulama był Bedan. Wszyscy oni byli potomkami Gileada, syna Makira, syna Manassesa.
###### **1Krn 7,18**
 Ich siostra, Hammoleket, miała trzech synów: Iszhoda, Abiezera i Machlę.
###### **1Krn 7,19**
 Synami Szemidy byli: Achian, Szekem, Likchi i Aniam.
###### **1Krn 7,20**
 Synem Efraima był Szutelach, który był ojcem Bereda, Bered zaś był ojcem Tachata, Tachat ojcem Eleada, Elead ojcem Tachata.
###### **1Krn 7,21**
 Tachat był ojcem Zabada, Zabad ojcem Szutelacha, Ezera i Eleada. Ci ostatni zostali zabici przez mieszkańców Gat, których napadli, chcąc zabrać ich stada.
###### **1Krn 7,22**
 Efraim, ich ojciec, po ich stracie długo trwał w żałobie, także jego bracia przychodzili żeby go pocieszać.
###### **1Krn 7,23**
 Po jakimś czasie zbliżył się do swojej żony, która poczęła i urodziła mu syna. Nadał mu imię Beria, bo narodził się w czasie, gdy na jego dom spadły nieszczęścia.
###### **1Krn 7,24**
 Córka Beriego Szeera zbudowała Bet-Choron niższe i wyższe oraz Uzzen-Szeera.
###### **1Krn 7,25**
 Synami Efraima byli Refach i Reszef. Reszef był ojcem Telacha, a Telach ojcem Tachana.
###### **1Krn 7,26**
 Tachan był ojcem Ladana, a Ladan ojcem Ammihuda, Ammihud zaś ojcem Eliaszama.
###### **1Krn 7,27**
 Eliaszam był ojcem Nuna, a Nun ojcem Jozuego.
###### **1Krn 7,28**
 Ich posiadłości z miejscami zamieszkania znajdowały się w Betel i miastach okolicznych, a ciągnęły się na wschód aż do miasta Naaran, na zachodzie zaś sięgały Gezer i miejscowości mu podległych, a ponadto obejmowały Sychem i ziemie okoliczne, aż do Ajji i pobliskich miast.
###### **1Krn 7,29**
 W rękach synów Manassesa znajdowały się: Bet-Szean i miejscowości pobliskie, Taanak i okolice, Megiddo i miejscowości temu miastu podległe oraz Dor i miejscowości mu przynależne. Na ziemiach tych mieszkali potomkowie Józefa, syna Izraela.
###### **1Krn 7,30**
 Synami Asera byli: Jimna, Jiszwa, Jiszwi i Beria. Siostra ich miała na imię Serach.
###### **1Krn 7,31**
 Beria miał dwóch synów: Chebera i Malkiela; Malkiel był ojcem Birzaita.
###### **1Krn 7,32**
 Synami Chebera byli: Jaflet, Szemer i Chotam. Siostra ich miała na imię Szua.
###### **1Krn 7,33**
 Jaflet miał trzech synów: Pasaka, Bimhala i Aszwata. Tak nazywali się synowie Jafleta.
###### **1Krn 7,34**
 Synami Szemera byli: Achi, Rohga, Chubba i Aram,
###### **1Krn 7,35**
 synami zaś jego brata, Helema, byli: Sofach, Jimna, Szelesz i Amal.
###### **1Krn 7,36**
 Synami Sofacha byli: Suach, Charnefer, Szual, Beri, Jimra,
###### **1Krn 7,37**
 Beser, Hod, Szamma, Szilsza, Jitran i Beera.
###### **1Krn 7,38**
 Synami Jetera byli: Jefunne, Pispa i Ara.
###### **1Krn 7,39**
 Synami Ulli byli: Arach, Channiel oraz Risja.
###### **1Krn 7,40**
 Wszyscy ci potomkowie Asera byli naczelnikami rodów, szanowanymi [przez braci], dzielnymi wojownikami, najznakomitszymi wśród znakomitych [synów Asera]. Wszystkich owych mężów, zdolnych do noszenia broni na wypadek wojny, było, według ich spisów rodowych, dwadzieścia sześć tysięcy.
# 1Krn 7 WUJ
###### **1Krn 7,1**
 A synowie Issachar: Thola, i Phua, Jasub, i Simeron, czterzej.
###### **1Krn 7,2**
 Synowie Thole: Ozy i Raphaja, i Jeriel, i Jemai, i Jebsem, i Samuel, przedniejszy wedle domów rodzin swoich. Z rodzaju Thole mężów walecznych naliczono za dni Dawidowych dwadzieścia i dwa tysiąca i sześć set.
###### **1Krn 7,3**
 Synowie Ozy: Izrahia, z którego poszli, Michael, i Obadia, i Joel, i Jesia pięć, wszyscy książęta.
###### **1Krn 7,4**
 A z nimi według domów i narodów ich, przepasani na wojnę mężów barzo mocnych trzydzieści i sześć tysięcy, bo mieli wiele żon i synów.
###### **1Krn 7,5**
 Braciej też ich według wszech rodzin Issachar dużych do bitwy, ośmdziesiąt i siedm tysięcy naliczono,
###### **1Krn 7,6**
 Synowie Benjamin: Bela, i Bechor, i Jadiel, trzej.
###### **1Krn 7,7**
 Synowie Bele: Esbon: i Ozy, i Oziel, i Jerymoth, i Urai, pięć książąt domów, i do boju barzo mocnych: a poczet ich dwadzieścia dwa tysiąca i czterzej a trzydzieści:
###### **1Krn 7,8**
 A synowie Bechorowi: Zamira, i Joas, i Eliezer, i Elioenai, i Amri, i Jerymoth, i Abia, i Anathoth, i Almath: ci wszyscy synowie Bechor.
###### **1Krn 7,9**
 A naliczono wedle domów ich z książąt rodów ich na wojnę barzo mocnych dwadzieścia tysięcy i dwieście.
###### **1Krn 7,10**
 A synowie Jadihel: Balan: A synowie Balan: Jehus, i Benjamin, i Aod, i Chanana, i Zethan, i Tharsis, i Ahisahar.
###### **1Krn 7,11**
 Ci wszyscy synowie Jadihel, książęta rodów swych, męże barzo mocni, siedmnaście tysięcy i dwieście na wojnę wychodzących.
###### **1Krn 7,12**
 Sepham też, i Hapham synowie Hir: i Hasim synowie Aher.
###### **1Krn 7,13**
 A synowie Nephthali: Jasiel, i Guni, i Jeser, i Sellum, synowie Bale.
###### **1Krn 7,14**
 A syn Manasse: Esriel: a nałożnica jego Syryanka urodziła Machira ojca Galaad.
###### **1Krn 7,15**
 Machir lepak wziął żony synom swym Happhim, i Saphan: a miał siostrę imieniem Maachę, imię zaś wtórego, Salphaad, i urodziły się córki Salphaadowi,
###### **1Krn 7,16**
 I porodziła Maacha żona Machir syna, i nazwała imię jego Phares: a imię brata jego Zares: a synowie jego, Ulam, i Recem.
###### **1Krn 7,17**
 A syn Ulam: Badan. Ci są synowie Galaad, syna Machir, syna Manasse.
###### **1Krn 7,18**
 A siostra jego królowa urodziła męża, pięknego, i Abiezera, i Mohola.
###### **1Krn 7,19**
 A byli synowie Semida: Ahin, i Sechem, i Lecy, i Aniam.
###### **1Krn 7,20**
 A synowie Ephraim: Suthala, Bared syn jego, Thahath syn jego, Elada syn jego, Thahath syn jego, tego syn Zabad,
###### **1Krn 7,21**
 A tego syn Suthala, a tego syn Ezer i Elad: pobili je mężowie Geth obywatele, iż byli wtargnęli, aby byli najechali majętności ich.
###### **1Krn 7,22**
 Przetoż Ephraim ockc ich płakał przez wiele dni, i przychodzili bracia jego, aby go cieszyli.
###### **1Krn 7,23**
 I wszedł do żony swej: która poczęła i porodziła syna, i nazwał imię jego Beria, przeto, że się urodził w utrapieniu domu jego.
###### **1Krn 7,24**
 A córka jego była Sara, która zbudowała Bethoron niższy i wyższy, i Ozensara.
###### **1Krn 7,25**
 A syn jego Rapha, i Reseph, i Thale, z którego poszedł Thaan.
###### **1Krn 7,26**
 Który zrodził Laadana, tego też syn Ammiud, który zrodził Elisam,
###### **1Krn 7,27**
 Z którego poszedł Nun, który miał syna Jozue.
###### **1Krn 7,28**
 A osiadłość ich i mieszkanie Bethel z córkami jego, a na wschód, Noran, a na zachód, Gazer i córki jego, aż do Azy z córkami jego.
###### **1Krn 7,29**
 A podle synów Manasse, Bethsan i córki jego, Thanach i córki jego, Mageddo i córki jego: Dor i córki jego: w tych mieszkali synowie Józefa syna Izrael.
###### **1Krn 7,30**
 Synowie Aser: Jemna, i Jesua, i Jessui, i Baria, i Sara siostra ich.
###### **1Krn 7,31**
 A synowie Baria: Heber, i Melchiel: ten jest ociec Barsaith.
###### **1Krn 7,32**
 A Heber zrodził Jephlath, i Somer, i Hotham, i Sua siostrę ich.
###### **1Krn 7,33**
 Synowie Jephlath: Phosech, i Chamaal, i Asoth: ci synowie Jephlat.
###### **1Krn 7,34**
 A synowie Somer: Ahi, i Roaga, i Haba, i Aram.
###### **1Krn 7,35**
 A synowie Helem brata jego: Supha, i Jemna, i Selles, i Amal.
###### **1Krn 7,36**
 Synowie Supha: Sue, Harnapher, i Sual, i Beri, i Jamra.
###### **1Krn 7,37**
 Bosor, i Hod, i Sama, i Salusa, i Jethran, i Bera.
###### **1Krn 7,38**
 Synowie Jether: Jephone, i Phaspha, i Ara.
###### **1Krn 7,39**
 A synowie Olle: Aree, i Haniel, i Resia.
###### **1Krn 7,40**
 Ci wszyscy synowie Aser książęta rodów, przebrani i namocniejszy wodzowie wodzów: a liczba ich lat, ku bitwie sposobnych, dwadzieścia i sześć tysięcy.
