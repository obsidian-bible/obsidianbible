# Ef 6 BT5
###### **Ef 6,1**
 Dzieci, bądźcie posłuszne w Panu waszym rodzicom, bo to jest sprawiedliwe.
###### **Ef 6,2**
  Czcij ojca twego i matkę – jest to pierwsze przykazanie z obietnicą –
###### **Ef 6,3**
 aby ci było dobrze i abyś długo żył na ziemi.
###### **Ef 6,4**
 A [wy], ojcowie, nie pobudzajcie do gniewu waszych dzieci, lecz wychowujcie je w karności, napominając, jak [chce] Pan.
###### **Ef 6,5**
 Niewolnicy, ze czcią i bojaźnią, w prostocie serca bądźcie posłuszni waszym doczesnym panom jak Chrystusowi,
###### **Ef 6,6**
 nie służąc tylko dla oka, by ludziom się podobać, lecz jako niewolnicy Chrystusa, którzy z duszy pełnią wolę Bożą.
###### **Ef 6,7**
 Z ochotą służcie, jak gdybyście [służyli] Panu, a nie ludziom,
###### **Ef 6,8**
 świadomi tego, że każdy, jeśli uczyni coś dobrego, otrzyma to z powrotem od Pana – czy to niewolnik, czy wolny.
###### **Ef 6,9**
 A wy, panowie, tak samo wobec nich postępujcie: zaniechajcie groźby, świadomi tego, że w niebie jest Pan zarówno ich, jak wasz, a u Niego nie ma względu na osoby.
###### **Ef 6,10**
 Na koniec bądźcie mocni w Panu – siłą Jego potęgi.
###### **Ef 6,11**
 Przyobleczcie pełną zbroję Bożą, byście mogli się ostać wobec podstępnych zakusów diabła.
###### **Ef 6,12**
 Nie toczymy bowiem walki przeciw krwi i ciału, lecz przeciw Zwierzchnościom, przeciw Władzom, przeciw rządcom świata tych ciemności, przeciw duchowym pierwiastkom zła na wyżynach niebieskich.
###### **Ef 6,13**
 Dlatego przywdziejcie pełną zbroję Bożą, abyście się zdołali przeciwstawić w dzień zły i ostać, zwalczywszy wszystko.
###### **Ef 6,14**
 Stańcie więc [do walki], przepasawszy biodra wasze prawdą i przyoblókłszy pancerz, którym jest sprawiedliwość,
###### **Ef 6,15**
 a obuwszy nogi w gotowość [głoszenia] dobrej nowiny o pokoju.
###### **Ef 6,16**
 W każdym położeniu bierzcie wiarę jako tarczę, dzięki której zdołacie zgasić wszystkie rozżarzone pociski Złego.
###### **Ef 6,17**
 Weźcie też hełm zbawienia i miecz Ducha, to jest słowo Boże –
###### **Ef 6,18**
 wśród wszelakiej modlitwy i błagania. Przy każdej sposobności módlcie się w Duchu! Nad tym właśnie czuwajcie najusilniej i proście za wszystkich świętych
###### **Ef 6,19**
 i za mnie, aby dane mi było słowo, gdy usta otworzę, by jawnie i swobodnie głosić tajemnicę Ewangelii,
###### **Ef 6,20**
 dla której sprawuję poselstwo jako więzień – żebym jawnie ją wypowiedział, tak jak winienem.
###### **Ef 6,21**
 Żebyście zaś wiedzieli i wy o moich sprawach, co robię, wszystko wam oznajmi Tychik, umiłowany brat i wierny sługa w Panu,
###### **Ef 6,22**
 którego wysłałem do was po to, byście wy poznali nasze sprawy, a on pokrzepił wasze serca.
###### **Ef 6,23**
 Pokój braciom i miłość wraz z wiarą, od Boga Ojca i Pana naszego, Jezusa Chrystusa.
###### **Ef 6,24**
 Łaska [niech będzie] ze wszystkimi, którzy miłują Pana naszego, Jezusa Chrystusa, w nieskazitelności. 
# Ef 6 PAU
###### **Ef 6,1**
 Dzieci, bądźcie posłuszne waszym rodzicom w Panu, gdyż jest to sprawiedliwe.
###### **Ef 6,2**
 Czcij swojego ojca i matkę - to jest pierwsze przykazanie z obietnicą -
###### **Ef 6,3**
 aby ci się dobrze powodziło i abyś cieszył się długim życiem na ziemi.
###### **Ef 6,4**
 A wy, ojcowie, nie rozdrażniajcie waszych dzieci, lecz wychowujcie je w karności i posłuszeństwie Panu.
###### **Ef 6,5**
 Niewolnicy, bądźcie posłuszni ziemskim panom ze czcią i drżeniem, w prostocie swego serca - jak Chrystusowi.
###### **Ef 6,6**
 Nie służcie na pokaz jak ci, którzy ludziom pragną się przypodobać, ale jak niewolnicy Chrystusa, wypełniający ochoczo wolę Bożą.
###### **Ef 6,7**
 Służcie z życzliwością jak Panu, a nie jak ludziom.
###### **Ef 6,8**
 Wiedzcie, że jeśli ktoś uczyni coś dobrego, Pan to zwróci i niewolnikom, i wolnym.
###### **Ef 6,9**
 A wy, panowie, postępujcie tak samo wobec nich, unikając gróźb. Wiedzcie, że zarówno oni, jak i wy macie w niebie Pana, który nie ma względu na osoby.
###### **Ef 6,10**
 W końcu bądźcie mocni w Panu Jego potężną siłą.
###### **Ef 6,11**
 Włóżcie pełną zbroję Bożą, abyście zdołali przeciwstawić się zasadzkom diabła.
###### **Ef 6,12**
 Nie walczymy bowiem przeciw krwi i ciału, ale przeciwko zwierzchnościom i władzom, przeciwko władcom tego świata ciemności, przeciwko złym duchom na wyżynach niebieskich.
###### **Ef 6,13**
 Dlatego nałóżcie pełną zbroję Bożą, abyście w dzień zły mogli stawić opór i ostali się dzięki pokonaniu wszelkich przeszkód.
###### **Ef 6,14**
 Stańcie więc i przepaszcie wasze biodra prawdą, załóżcie pancerz sprawiedliwości,
###### **Ef 6,15**
 a na nogi włóżcie gotowość głoszenia dobrej nowiny pokoju.
###### **Ef 6,16**
 Zawsze miejcie tarczę wiary, dzięki której będziecie mogli gasić wszelkie ogniste pociski Złego.
###### **Ef 6,17**
 Przyjmijcie też hełm zbawienia oraz miecz Ducha, którym jest Słowo Boże.
###### **Ef 6,18**
 Przy każdej okazji módlcie się w Duchu, zanosząc prośby i błagania. W tym celu wytrwale czuwajcie na modlitwie za wszystkich świętych
###### **Ef 6,19**
 i za mnie, aby dane mi było słowo, gdy otworzę me usta do odważnego głoszenia tajemnicy Ewangelii,
###### **Ef 6,20**
 abym śmiało ją głosił, tak jak powinienem. Jestem jej posłem jako więzień.
###### **Ef 6,21**
 Tychik, umiłowany brat i wierny sługa w Panu, oznajmi wam wszystko, abyście i wy wiedzieli, co się ze mną dzieje i co robię.
###### **Ef 6,22**
 Jego posłałem wam, abyście dowiedzieli się o naszych sprawach i aby on pocieszył wasze serca.
###### **Ef 6,23**
 Pokój braciom i miłość wraz z wiarą od Boga, Ojca i Pana, Jezusa Chrystusa.
###### **Ef 6,24**
 Łaska z wszystkimi, którzy miłują Pana naszego, Jezusa Chrystusa, miłością nieprzemijającą.
# Ef 6 BP
###### **Ef 6,1**
 Dzieci, bądźcie posłuszne swoim rodzicom ze względu na Pana, gdyż tego wymaga sprawiedliwość.
###### **Ef 6,2**
 "Czcij swojego ojca i swoją matkę" - to pierwsze przykazanie, które łączy się z obietnicą:
###### **Ef 6,3**
 "abyś długo żył na świecie i aby ci dobrze się powodziło".
###### **Ef 6,4**
 Wy zaś, ojcowie, nie stwarzajcie okazji do złego u swoich dzieci, lecz wychowujcie je w duchu karności i posłuszeństwa wobec Pana.
###### **Ef 6,5**
 Niewolnicy, bądźcie posłuszni [tym], którzy są waszymi panami w sprawach doczesnych. [Odnoście się do nich] z szacunkiem i bojaźnią, w prostocie swego serca, jak do Chrystusa.
###### **Ef 6,6**
 Nie służcie im dla oka i dla ludzkiej pochwały, lecz jako niewolnicy Chrystusa, którzy świadomie pełnią wolę Bożą.
###### **Ef 6,7**
 Służcie z życzliwością jako Panu, a nie ludziom.
###### **Ef 6,8**
 Bądźcie przekonani, że każdy, czy to niewolnik, czy wolny, jeśli czyni dobrze, otrzyma od Pana nagrodę.
###### **Ef 6,9**
 Wy zaś, panowie, tak samo odnoście się do nich i zaniechajcie groźby, świadomi tego, że tak ich, jak wasz Pan jest w niebie, a On nie ma względu na osoby.
###### **Ef 6,10**
 W końcu umacniajcie się w Panu siłą Jego wielkiej potęgi.
###### **Ef 6,11**
 Włóżcie na siebie zbroję Bożą, abyście mogli przeciwstawić się zakusom diabła.
###### **Ef 6,12**
 Nie walczymy z ludźmi, ale ze zwierzchnościami, władzami, rządcami świata ciemności i złymi duchami w przestworzach.
###### **Ef 6,13**
 Dlatego włóżcie na siebie pełną zbroję Bożą, abyście mogli w złym dniu stawić opór, a pokonawszy wszystko, ostać się zwycięsko.
###### **Ef 6,14**
 Stańcie więc [do walki] przepasawszy swoje biodra prawdą, włożywszy pancerz sprawiedliwości,
###### **Ef 6,15**
 a na nogi obuwie dla gotowości [niesienia] ewangelii o pokoju.
###### **Ef 6,16**
 W każdej sytuacji osłaniajcie się tarczą wiary, dzięki której będziecie mogli ochronić się przed wszystkimi ognistymi pociskami przeciwnika.
###### **Ef 6,17**
 Weźcie przyłbicę zbawienia i miecz Ducha to znaczy słowo Boże.
###### **Ef 6,18**
 Przy wszelkiej sposobności, w każdej prośbie o pomoc módlcie się do Ducha [Świętego]. I tak czuwajcie z całą wytrwałością w modlitwie błagalnej za wszystkich świętych
###### **Ef 6,19**
 i za mnie, aby dana mi była możność otwarcia ust do głoszenia nauki, do jawnego obwieszczenia radosnej nowiny,
###### **Ef 6,20**
 dla której sprawuję poselstwo jako więzień, abym mógł ją głosić jawnie, jak do tego jestem zobowiązany.
###### **Ef 6,21**
 Chiałbym też, abyście wiedzieli, co dzieje się ze mną i co porabiam. Opowie wam to Tychik, umiłowany brat i wierny sługa w Panu.
###### **Ef 6,22**
 Wysłałem go, aby was powiadomił o moich sprawach i pokrzepił was na duchu.
###### **Ef 6,23**
 Braciom pokój i miłość z wiarą od Boga Ojca i naszego Pana Jezusa Chrystusa.
###### **Ef 6,24**
 Łaska z wszystkimi, którzy wiernie miłują naszego Pana Jezusa Chrystusa.
# Ef 6 BR
###### **Ef 6,1**
 Dzieci, waszym obowiązkiem wobec Boga jest słuchać rodziców. Domaga się tego [zwykła] sprawiedliwość.
###### **Ef 6,2**
 Czcij ojca twego i matkę - to pierwsze przykazanie, a z nim wiąże się taka oto obietnica:
###### **Ef 6,3**
 aby ci było dobrze i abyś długo żył na tej ziemi.
###### **Ef 6,4**
 Wy zaś, ojcowie, ze swej strony nie traktujcie swych dzieci tak, by musiały się gniewać. Wychowujcie je pouczając i karcąc w duchu Pańskim.
###### **Ef 6,5**
 Niewolnicy, bądźcie posłuszni z czcią i z bojaźnią, lecz w prostocie serca waszym doczesnym panom, tak jak samemu Chrystusowi.
###### **Ef 6,6**
 Postępujcie tak nie tylko dlatego, by przypodobać się ludziom, lecz by pokazać, że jesteście niewolnikami Chrystusowymi, pełniącymi ze szczerego serca wolę Bożą.
###### **Ef 6,7**
 Spełniajcie swoje obowiązki z całym zapałem, tak jakbyście służyli Panu, a nie ludziom.
###### **Ef 6,8**
 Bądźcie też przekonani, że każdy - czy to niewolnik, czy wolny - jeśli uczyni coś dobrego, otrzyma również [w postaci dobra] zapłatę od Pana.
###### **Ef 6,9**
 Podobnie i wy, panowie, [postępujcie uczciwie z waszymi niewolnikami]: przestańcie im ciągle grozić, pamiętając, że w niebie czeka na was zarówno ich, jak i wasz Pan, a wszyscy ludzie są dla Niego równi.
###### **Ef 6,10**
 Wreszcie szukajcie umocnienia w waszym zjednoczeniu z Panem i w Jego niezmierzonej potędze.
###### **Ef 6,11**
 Przywdziejcie na siebie pełną zbroję Bożą, byście mogli oprzeć się wszystkim, nawet najbardziej podstępnym atakom diabła.
###### **Ef 6,12**
 Prowadzimy bowiem walkę nie ze zwykłymi ludźmi, lecz mamy stawiać czoło Zwierzchnościom i Władzom, rządcom świata tych ciemności oraz mocom duchowym zła na wyżynach niebieskich.
###### **Ef 6,13**
 Dlatego okryjcie się dokładnie zbroją Bożą, abyście, gdy nadejdzie ów dzień zły, mogli odeprzeć zwycięsko [ataki zła] i ostać się zwyciężywszy wszystko.
###### **Ef 6,14**
 Przygotujcie się więc do walki! Przepaszcie swe biodra prawdą, przyodziejcie się w pancerz sprawiedliwości,
###### **Ef 6,15**
 a nogi obujcie w gotowość głoszenia Dobrej Nowiny pokoju.
###### **Ef 6,16**
 Wiara niech wam zawsze służy za tarczę, którą zdołacie unieszkodliwić wszystkie, najbardziej nawet rozpalone pociski Złego.
###### **Ef 6,17**
 [Na głowę] załóżcie hełm zbawienia, [do ręki] weźcie miecz Ducha, to jest słowo Boże.
###### **Ef 6,18**
 Wszystko to czyńcie modląc się i prosząc Boga o pomoc. Módlcie się zresztą nieustannie, poddając się działaniu Ducha [Świętego]. Bądźcie bardzo czujni i módlcie się za wszystkich wiernych.
###### **Ef 6,19**
 Módlcie się również i za mnie, aby za Bożą pomocą nie zabrakło mi słów odpowiednich, gdy będę miał nauczać, bym mógł jawnie i swobodnie głosić tajemnicę Ewangelii.
###### **Ef 6,20**
 Dla niej to właśnie spełniam jakby poselstwo, pozostając teraz w więzach. Módlcie się więc, abym mógł głosić ją swobodnie, jak powinienem to czynić.
###### **Ef 6,21**
 Tychik, umiłowany brat i wierny sługa w Panu, opowie wam wszystko, co robię, żebyście i wy wiedzieli, co dzieje się ze mną.
###### **Ef 6,22**
 Właśnie po to wysyłam go do was, żeby wam opowiedział o moich sprawach i dodał otuchy waszym sercom.
###### **Ef 6,23**
 Bóg Ojciec i Pan nasz Jezus Chrystus niech was obdarzą, bracia, pokojem, miłością i wiarą.
###### **Ef 6,24**
 Łaska niech będzie ze wszystkimi, którzy miłują miłością nieskazitelną Pana naszego Jezusa Chrystusa.
# Ef 6 WUJ
###### **Ef 6,1**
 Synowie, bądźcie posłuszni rodzicom waszym w Panu: Bo to jest sprawiedliwa.
###### **Ef 6,2**
 Czci ojca twego i matkę twoję: (które jest pierwsze przykazanie z obietnicą).
###### **Ef 6,3**
 Abyć się dobrze działo, i abyś był długowieczny na ziemi.
###### **Ef 6,4**
 A wy ojcowie nie pobudzajcie ku gniewowi synów waszych: ale je wychowywajcie w karności i w grozie Pańskiej.
###### **Ef 6,5**
 Słudzy posłuszni bądźcie panom wedle ciała, z bojaźnią i ze drżeniem, w prostości serca waszego, jako Chrystusowi:
###### **Ef 6,6**
 Nie na oko służąc, jakoby ludziom się podobając, ale jako słudzy Chrystusowi, czyniąc wolą Bożą z serca:
###### **Ef 6,7**
 Z dobrą wolą służąc, jako Panu a nie ludziom.
###### **Ef 6,8**
 Wiedząc, iż każdy cokolwiek uczyni dobrego, to odniesie od Pana, choć niewolnik, choć wolny,
###### **Ef 6,9**
 A wy panowie toż im czyńcie, odpuszczając groźby: wiedząc iż i ich i was Pan, jest w niebiesiech: a niemasz u niego względu na osoby.
###### **Ef 6,10**
 Naostatek bracia, zmacniajcie się w Panu, i w sile mocy jego.
###### **Ef 6,11**
 Obleczcie się w zupełną zbroję Bożą: abyście mogli stać przeciwko zasadkam djabelskim.
###### **Ef 6,12**
 Abowiem nie mamy biedzenia przeciw ciału i krwi, ale przeciwko książętam i władzam, przeciwko rządzcom świata tych ciemności, przeciwko duchownym złościam, w niebieskich.
###### **Ef 6,13**
 A przetoż weźcie zupełną zbroję Bożą: abyście mogli sprzeciwić się w dzień zły, i we wszystkiem doskonali stać.
###### **Ef 6,14**
 Stójcież tedy przepasawszy biodra wasze prawdą, a oblokszy pancerz sprawiedliwości,
###### **Ef 6,15**
 I obuwszy nogi w gotowość Ewanieljej pokoju:
###### **Ef 6,16**
 We wszystkiem biorąc tarczą wiary, którąbyście mogli wszystkie strzały ogniste złośliwego zgasić.
###### **Ef 6,17**
 I przyłbicę zbawienia weźmicie, i miecz ducha (które jest słowo Boże).
###### **Ef 6,18**
 W każdej modlitwie i prośbie modląc się na każdy czas w duchu: i w nim czując ze wszelaką ustawicznością i prośbą za wszystkie święte:
###### **Ef 6,19**
 I za mię, aby mi była dana mowa w otworzeniu ust moich z dufnością, abym oznajmiał tajemnicę Ewanieljej.
###### **Ef 6,20**
 Dla której poselstwo sprawuję w łańcuchu, tak żebym o nię śmiały był, jako mi mówić potrzeba.
###### **Ef 6,21**
 A iżbyście i wy wiedzieli co się zemną dzieje, co czynię: wszystko sam oznajmi Tychikus, namilszy brat i wierny sługa w Panie:
###### **Ef 6,22**
 Któregom posłał do was na to samo? abyście wiedzieli co się z nami dzieje, ażeby pocieszył serca wasze.
###### **Ef 6,23**
 Pokój braciej i miłość z wiarą od Boga Ojca, i Pana Jezusa Chrystusa.
###### **Ef 6,24**
 Łaska ze wszystkiemi, którzy miłują Pana naszego Jezusa Chrystusa w nieskazitelności, Amen.1
# Ef 6 STERN
###### **Ef 6,1**
 Dzieci, waszą powinnością w jedności z Panem jest posłuszeństwo rodzicom, bo tak się godzi.
###### **Ef 6,2**
 "Czcij swego ojca i matkę" - oto pierwsze Przykazanie zawierające obietnicę -
###### **Ef 6,3**
 "aby ci się dobrze powodziło i abyś żył długo w Ziemi".
###### **Ef 6,4**
 Ojcowie, nie denerwujcie swoich dzieci i nie wzbudzajcie w nich goryczy, ale wychowujcie je w karności Pana i w Jego ukierunkowaniu.
###### **Ef 6,5**
 Niewolnicy, bądźcie posłuszni swoim ludzkim panom z tą samą bojaźnią, drżeniem i szczerością, z jakimi jesteście posłuszni Mesjaszowi.
###### **Ef 6,6**
 Bądźcie posłuszni nie tylko po to, aby sobie pozyskać ich przychylność, służąc tylko wtedy, gdy patrzą, ale służcie jako niewolnicy Mesjasza, z całego serca czyniąc to, czego chce Bóg.
###### **Ef 6,7**
 Pracujcie chętnie jako niewolnicy, jako ci, którzy służą nie tyle ludziom, co Panu.
###### **Ef 6,8**
 Pamiętajcie, że kto wykonuje dobre dzieło - czy to niewolnik, czy wolny - zostanie nagrodzony przez Pana.
###### **Ef 6,9**
 Wy zaś, panowie, tak samo traktujcie swych niewolników. Nie zastraszajcie ich. Pamiętajcie, że w niebie i wy, i oni macie jednego Władcę nad sobą, a On nie faworyzuje nikogo.
###### **Ef 6,10**
 W końcu umacniajcie się w jedności z Panem, w jedności z Jego potężną siłą!
###### **Ef 6,11**
 Wykorzystujcie wszelką zbroję i oręż, jakie zapewnia Bóg, abyście byli w stanie przeciwstawić się podstępnej taktyce Przeciwnika.
###### **Ef 6,12**
 Bo nie walczymy z ludźmi, ale z władcami, zwierzchnościami i kosmicznymi potęgami rządzącymi tą ciemnością, z duchowymi siłami zła w sferze niebios.
###### **Ef 6,13**
 Przywdziejcie więc każdy element wojennego rynsztunku, jaki zapewnia Bóg, abyście kiedy przyjdzie dzień zły, byli w stanie stawić opór, a gdy bitwa już będzie wygrana, okaże się, że utrzymaliście swoje pozycje.
###### **Ef 6,14**
 Trwajcie więc! Przepaszcie biodra pasem prawdy, przywdziejcie sprawiedliwość jako pancerz,
###### **Ef 6,15**
 a na stopy włóżcie gotowość, jaka pochodzi z Dobrej Nowiny o szalomie.
###### **Ef 6,16**
 Zawsze noście tarczę ufności, którą będziecie w stanie gasić wszystkie płonące strzały Złego.
###### **Ef 6,17**
 I weźcie hełm wyzwolenia, a także miecz dany przez Ducha, czyli Słowo Boże,
###### **Ef 6,18**
 kiedy się modlicie w każdym czasie, wszelakimi modlitwami i prośbami, w Duchu, czujnie i wytrwale, za cały lud Boży.
###### **Ef 6,19**
 A módlcie się i za mnie, aby ilekroć otworzę usta, została mi dana śmiałość w objawianiu tajemnicy Dobrej Nowiny,
###### **Ef 6,20**
 której jestem ambasadorem w kajdanach. Módlcie się, abym mówił śmiało, tak jak powinienem.
###### **Ef 6,21**
 A żebyście i wy wiedzieli, jak się miewam i co robię, Tychik, drogi brat i wierny pracownik Pana, opowie wam o wszystkim.
###### **Ef 6,22**
 Właśnie dlatego go do was posłałem, abyście wiedzieli, jak się nam powodzi, i aby was on pocieszył i umocnił.
###### **Ef 6,23**
 Szalom braciom. Niech Bóg Ojciec i Pan Jeszua Mesjasz dadzą wam miłość i ufność.
###### **Ef 6,24**
 Łaska wszystkim, którzy kochają naszego Pana Jeszuę Mesjasza miłością nieśmiertelną.1
# Ef 6 TRO
###### **Ef 6,1**
 **τα** *ta* [[G3588]] WTT-NPN **τεκνα** *tekna* Dzieci [[G5043]] WTN-NPN **υπακουετε** *hypakouete* bądźcie posłuszne [[G5219]] WTV-PAM-2P **τοις** *tois* [[G3588]] WTT-DPM **γονευσιν** *goneusin* rodzicom [[G1118]] WTN-DPM **υμων** *hymōn* waszym [[G5216]] WTP-2GP **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **τουτο** *touto* to [[G5124]] WTD-NSN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **δικαιον** *dikaion* sprawiedliwe [[G1342]] WTA-NSN
###### **Ef 6,2**
 **τιμα** *tima* Szanuj – Poważaj [[G5091]] WTV-PAM-2S **τον** *ton* [[G3588]] [[T-ASM]] **πατερα** *patera* ojca [[G3962]] [[N-ASM]] **σου** *sou* twojego [[G4675]] WTP-2GS **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **μητερα** *mētera* matkę [[G3384]] WTN-ASF **ητις** *hētis* co [[G3748]] WTR-NSF **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **εντολη** *entolē* przykazanie [[G1785]] [[N-NSF]] **πρωτη** *prōtē* pierwsze [[G4413]] WTA-NSF **εν** *en* w [[G1722]] [[PREP]] **επαγγελια** *epangelia* obietnicy [[G1860]] [[N-DSF]]
###### **Ef 6,3**
 **ινα** *hina* aby [[G2443]] [[CONJ]] **ευ** *eu* dobrze [[G2095]] [[ADV]] **σοι** *soi* ci [[G4671]] WTP-2DS **γενηται** *genētai* stałoby się [[G1096]] WTV-2ADS-3S **και** *kai* i [[G2532]] [[CONJ]] **εση** *esē* będziesz [[G2071]] WTV-FXI-2S **μακροχρονιος** *makrochronios* długowieczny [[G3118]] [[A-NSM]] **επι** *epi* na [[G1909]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]]
###### **Ef 6,4**
 **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **πατερες** *pateres* ojcowie [[G3962]] WTN-NPM **μη** *mē* nie [[G3361]] [[PRT-N]] **παροργιζετε** *parorgizete* doprowadzajcie do gniewu [[G3949]] WTV-PAM-2P **τα** *ta* [[G3588]] WTT-APN **τεκνα** *tekna* dzieci [[G5043]] WTN-APN **υμων** *hymōn* waszych [[G5216]] WTP-2GP **αλλ** *all* ale [[G235]] [[CONJ]] **εκτρεφετε** *ektrefete* pielęgnujcie – wychowujcie [[G1625]] WTV-PAM-2P **αυτα** *auta* je [[G846]] WTP-APN **εν** *en* w [[G1722]] [[PREP]] **παιδεια** *paideia* karceniu – karności [[G3809]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **νουθεσια** *nouthesia* napomnieniu – wkładaniu do rozumu [[G3559]] [[N-DSF]] **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]]
###### **Ef 6,5**
 **οι** *hoi* [[G3588]] WTT-NPM **δουλοι** *douloi* Niewolnicy – Słudzy [[G1401]] WTN-NPM **υπακουετε** *hypakouete* bądźcie posłuszni [[G5219]] WTV-PAM-2P **τοις** *tois* (tym) [[G3588]] WTT-DPM **κυριοις** *kyriois* panom [[G2962]] WTN-DPM **κατα** *kata* według [[G2596]] [[PREP]] **σαρκα** *sarka* ciała [[G4561]] WTN-ASF **μετα** *meta* ze [[G3326]] [[PREP]] **φοβου** *fobou* strachem – bojaźnią [[G5401]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **τρομου** *tromou* drżeniem [[G5156]] [[N-GSM]] **εν** *en* w [[G1722]] [[PREP]] **απλοτητι** *haplotēti* prostocie – szczerości [[G572]] [[N-DSF]] **της** *tēs* [[G3588]] [[T-GSF]] **καρδιας** *kardias* serca [[G2588]] [[N-GSF]] **υμων** *hymōn* waszego [[G5216]] WTP-2GP **ως** *hōs* jak [[G5613]] [[ADV]] **τω** *tō* [[G3588]] WTT-DSM **χριστω** *christō* Pomazańcowi [[G5547]] WTN-DSM
###### **Ef 6,6**
 **μη** *mē* nie [[G3361]] [[PRT-N]] **κατ** *kat* w [[G2596]] [[PREP]] **οφθαλμοδουλειαν** *ofthalmodouleian* służbie na pokaz – służbie dla oka [[G3787]] WTN-ASF **ως** *hōs* jak [[G5613]] [[ADV]] **ανθρωπαρεσκοι** *anthrōpareskoi* przypochlebiający się ludziom [[G441]] WTA-NPM **αλλ** *all* ale [[G235]] [[CONJ]] **ως** *hōs* jak [[G5613]] [[ADV]] **δουλοι** *douloi* niewolnicy – słudzy [[G1401]] WTN-NPM **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **ποιουντες** *poiountes* czyniący [[G4160]] WTV-PAP-NPM **το** *to* [[G3588]] WTT-ASN **θελημα** *thelēma* wolę [[G2307]] WTN-ASN **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εκ** *ek* z [[G1537]] [[PREP]] **ψυχης** *psychēs* duszy [[G5590]] [[N-GSF]]
###### **Ef 6,7**
 **μετ** *met* z [[G3326]] [[PREP]] **ευνοιας** *eunoias* dobrej woli – życzliwością [[G2133]] [[N-GSF]] **δουλευοντες** *douleuontes* służący [[G1398]] WTV-PAP-NPM **ως** *hōs* jak [[G5613]] [[ADV]] **τω** *tō* [[G3588]] WTT-DSM **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **και** *kai* a [[G2532]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ανθρωποις** *anthrōpois* ludziom [[G444]] WTN-DPM
###### **Ef 6,8**
 **ειδοτες** *eidotes* wiedzący [[G1492]] WTV-RAP-NPM **οτι** *hoti* że [[G3754]] [[CONJ]] **ο** *ho* co [[G3739]] WTR-ASN **εαν** *ean* jeśli [[G1437]] WTCOND **τι** *ti* coś [[G5100]] WTX-ASN **εκαστος** *hekastos* każdy [[G1538]] [[A-NSM]] **ποιηση** *poiēsē* uczyniłby [[G4160]] WTV-AAS-3S **αγαθον** *agathon* dobrego [[G18]] WTA-ASN **τουτο** *touto* to [[G5124]] WTD-ASN **κομιειται** *komieitai* otrzyma – dostanie [[G2865]] WTV-FDI-3S-ATT **παρα** *para* od [[G3844]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ειτε** *eite* czy to [[G1535]] [[CONJ]] **δουλος** *doulos* niewolnik – sługa [[G1401]] [[N-NSM]] **ειτε** *eite* czy [[G1535]] [[CONJ]] **ελευθερος** *eleutheros* wolny [[G1658]] [[A-NSM]]
###### **Ef 6,9**
 **και** *kai* A [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **κυριοι** *kyrioi* panowie [[G2962]] WTN-NPM **τα** *ta* (to) [[G3588]] WTT-APN **αυτα** *auta* samo [[G846]] WTP-APN **ποιειτε** *poieite* czyńcie [[G4160]] WTV-PAM-2P **προς** *pros* względem [[G4314]] [[PREP]] **αυτους** *autous* nich [[G846]] [[P-APM]] **ανιεντες** *anientes* porzucając [[G447]] WTV-PAP-NPM **την** *tēn* [[G3588]] WTT-ASF **απειλην** *apeilēn* groźbę [[G547]] WTN-ASF **ειδοτες** *eidotes* wiedząc [[G1492]] WTV-RAP-NPM **οτι** *hoti* że [[G3754]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **υμων** *hymōn* wasz [[G5216]] WTP-2GP **αυτων** *autōn* ich [[G846]] WTP-GPM **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **εν** *en* w [[G1722]] [[PREP]] **ουρανοις** *ouranois* niebiosach [[G3772]] WTN-DPM **και** *kai* i [[G2532]] [[CONJ]] **προσωποληψια** *prosōpolēpsia* stronniczość – branie według twarzy [[G4382]] [[N-NSF]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **παρ** *par* u [[G3844]] [[PREP]] **αυτω** *autō* Niego [[G846]] WTP-DSM
###### **Ef 6,10**
 **το** *to* [[G3588]] WTT-NSN **λοιπον** *loipon* W końcu [[G3063]] WTA-NSN **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **μου** *mou* moi [[G3450]] WTP-1GS **ενδυναμουσθε** *endynamousthe* bądźcie umacniani – bądźcie napełnieni mocą [[G1743]] WTV-PPM-2P **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **κρατει** *kratei* mocy – sile [[G2904]] WTN-DSN **της** *tēs* [[G3588]] [[T-GSF]] **ισχυος** *ischyos* siły [[G2479]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Ef 6,11**
 **ενδυσασθε** *endysasthe* Przywdziejcie – Wdziejcie na siebie [[G1746]] WTV-AMM-2P **την** *tēn* [[G3588]] WTT-ASF **πανοπλιαν** *panoplian* pełną zbroję – całą zbroję [[G3833]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **προς** *pros* ku [[G4314]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **δυνασθαι** *dynasthai* móc [[G1410]] WTV-PNN **υμας** *hymas* wy [[G5209]] WTP-2AP **στηναι** *stēnai* ostać się [[G2476]] [[V-2AAN]] **προς** *pros* wobec [[G4314]] [[PREP]] **τας** *tas* [[G3588]] WTT-APF **μεθοδειας** *methodeias* przebiegłości – matactw [[G3180]] WTN-APF **του** *tou* [[G3588]] WTT-GSM **διαβολου** *diabolou* oszczercy – diabła [[G1228]] WTA-GSM
###### **Ef 6,12**
 **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ημιν** *hēmin* nam [[G2254]] WTP-1DP **η** *hē* [[G3588]] [[T-NSF]] **παλη** *palē* walka – zapasy [[G3823]] [[N-NSF]] **προς** *pros* z [[G4314]] [[PREP]] **αιμα** *haima* krwią [[G129]] WTN-ASN **και** *kai* i [[G2532]] [[CONJ]] **σαρκα** *sarka* ciałem [[G4561]] WTN-ASF **αλλα** *alla* ale [[G235]] [[CONJ]] **προς** *pros* ze [[G4314]] [[PREP]] **τας** *tas* [[G3588]] WTT-APF **αρχας** *archas* zwierzchnościami – władcami [[G746]] WTN-APF **προς** *pros* z [[G4314]] [[PREP]] **τας** *tas* [[G3588]] WTT-APF **εξουσιας** *eksousias* władzami [[G1849]] WTN-APF **προς** *pros* z [[G4314]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **κοσμοκρατορας** *kosmokratoras* rządcami świata [[G2888]] [[N-APM]] **του** *tou* [[G3588]] WTT-GSN **σκοτους** *skotous* ciemności [[G4655]] [[N-GSN]] **του** *tou* [[G3588]] WTT-GSM **αιωνος** *aiōnos* wieku [[G165]] [[N-GSM]] **τουτου** *toutou* tego [[G5127]] WTD-GSM **προς** *pros* z [[G4314]] [[PREP]] **τα** *ta* [[G3588]] WTT-APN **πνευματικα** *pneumatika* duchowymi [[G4152]] WTA-APN **της** *tēs* [[G3588]] [[T-GSF]] **πονηριας** *ponērias* niegodziwością (niegodziwościami) [[G4189]] [[N-GSF]] **εν** *en* w [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPN **επουρανιοις** *epouraniois* niebiosach [[G2032]] WTA-DPN
###### **Ef 6,13**
 **δια** *dia* Przez [[G1223]] [[PREP]] **τουτο** *touto* to [[G5124]] WTD-ASN **αναλαβετε** *analabete* weźcie [[G353]] WTV-2AAM-2P **την** *tēn* [[G3588]] WTT-ASF **πανοπλιαν** *panoplian* pełną zbroję – całą zbroję [[G3833]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **δυνηθητε** *dynēthēte* moglibyście [[G1410]] WTV-ADS-2P **αντιστηναι** *antistēnai* przeciwstawić się – stanąć przeciw [[G436]] [[V-2AAN]] **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **ημερα** *hēmera* dniu [[G2250]] [[N-DSF]] **τη** *tē* [[G3588]] WTT-DSF **πονηρα** *ponēra* niegodziwym – złym [[G4190]] WTA-DSF **και** *kai* i [[G2532]] [[CONJ]] **απαντα** *hapanta* wszystkie [[G537]] WTA-APN **κατεργασαμενοι** *katergasamenoi* sprawiwszy – wykonawszy [[G2716]] WTV-ADP-NPM **στηναι** *stēnai* ostać się [[G2476]] [[V-2AAN]]
###### **Ef 6,14**
 **στητε** *stēte* Stójcie [[G2476]] WTV-2AAM-2P **ουν** *oun* więc [[G3767]] [[CONJ]] **περιζωσαμενοι** *perizōsamenoi* przepasawszy – opasawszy sobie [[G4024]] WTV-AMP-NPM **την** *tēn* [[G3588]] WTT-ASF **οσφυν** *osfyn* biodro [[G3751]] WTN-ASF **υμων** *hymōn* wasze [[G5216]] WTP-2GP **εν** *en* w [[G1722]] [[PREP]] **αληθεια** *alētheia* prawdzie [[G225]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **ενδυσαμενοι** *endysamenoi* przyoblekłszy się w – wdziawszy na siebie [[G1746]] WTV-AMP-NPM **τον** *ton* [[G3588]] [[T-ASM]] **θωρακα** *thōraka* pancerz [[G2382]] [[N-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **δικαιοσυνης** *dikaiosynēs* sprawiedliwości [[G1343]] [[N-GSF]]
###### **Ef 6,15**
 **και** *kai* i [[G2532]] [[CONJ]] **υποδησαμενοι** *hypodēsamenoi* obuwszy – podwiązawszy [[G5265]] WTV-AMP-NPM **τους** *tous* [[G3588]] WTT-APM **ποδας** *podas* stopy [[G4228]] [[N-APM]] **εν** *en* w [[G1722]] [[PREP]] **ετοιμασια** *hetoimasia* gotowości [[G2091]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSN **ευαγγελιου** *euangeliou* dobrej nowiny [[G2098]] [[N-GSN]] **της** *tēs* [[G3588]] [[T-GSF]] **ειρηνης** *eirēnēs* pokoju [[G1515]] [[N-GSF]]
###### **Ef 6,16**
 **επι** *epi* we [[G1909]] [[PREP]] **πασιν** *pasin* wszystkim [[G3956]] WTA-DPN **αναλαβοντες** *analabontes* podniósłszy – wziąwszy [[G353]] WTV-2AAP-NPM **τον** *ton* [[G3588]] [[T-ASM]] **θυρεον** *thyreon* tarczę [[G2375]] [[N-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **εν** *en* w [[G1722]] [[PREP]] **ω** *hō* której [[G3739]] WTR-DSM **δυνησεσθε** *dynēsesthe* będziecie mogli [[G1410]] WTV-FDI-2P **παντα** *panta* wszystkie [[G3956]] WTA-APN **τα** *ta* [[G3588]] WTT-APN **βελη** *belē* pociski [[G956]] WTN-APN **του** *tou* [[G3588]] WTT-GSM **πονηρου** *ponērou* niegodziwego – złego [[G4190]] WTA-GSM **τα** *ta* (te) [[G3588]] WTT-APN **πεπυρωμενα** *pepyrōmena* które są rozpalone – które są rozżarzone [[G4448]] WTV-RPP-APN **σβεσαι** *sbesai* zgasić [[G4570]] [[V-AAN]]
###### **Ef 6,17**
 **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **περικεφαλαιαν** *perikefalaian* hełm [[G4030]] WTN-ASF **του** *tou* [[G3588]] WTT-GSN **σωτηριου** *sōtēriou* zbawienia [[G4992]] [[A-GSN]] **δεξασθε** *deksasthe* przyjmijcie – weźcie [[G1209]] WTV-ADM-2P **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **μαχαιραν** *machairan* miecz [[G3162]] WTN-ASF **του** *tou* [[G3588]] WTT-GSN **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **ο** *ho* to [[G3739]] WTR-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ρημα** *rēma* przesłanie – wypowiedź [[G4487]] WTN-NSN **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **Ef 6,18**
 **δια** *dia* przez [[G1223]] [[PREP]] **πασης** *pasēs* każdą [[G3956]] WTA-GSF **προσευχης** *proseuchēs* modlitwę [[G4335]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **δεησεως** *deēseōs* prośbie [[G1162]] [[N-GSF]] **προσευχομενοι** *proseuchomenoi* modląc się [[G4336]] WTV-PNP-NPM **εν** *en* w [[G1722]] [[PREP]] **παντι** *panti* każdej [[G3956]] WTA-DSM **καιρω** *kairō* porze [[G2540]] WTN-DSM **εν** *en* w [[G1722]] [[PREP]] **πνευματι** *pneumati* Duchu [[G4151]] WTN-DSN **και** *kai* i [[G2532]] [[CONJ]] **εις** *eis* w [[G1519]] [[PREP]] **αυτο** *auto* tym [[G846]] WTP-ASN **τουτο** *touto* to [[G5124]] WTD-ASN **αγρυπνουντες** *agrypnountes* będąc czujnym – trwając bez snu [[G69]] WTV-PAP-NPM **εν** *en* w [[G1722]] [[PREP]] **παση** *pasē* całej [[G3956]] WTA-DSF **προσκαρτερησει** *proskarterēsei* uporczywości – niezłomnym trwaniu [[G4343]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **δεησει** *deēsei* prośbą [[G1162]] [[N-DSF]] **περι** *peri* o [[G4012]] [[PREP]] **παντων** *pantōn* wszystkich [[G3956]] WTA-GPM **των** *tōn* [[G3588]] WTT-GPM **αγιων** *hagiōn* świętych [[G40]] WTA-GPM
###### **Ef 6,19**
 **και** *kai* i [[G2532]] [[CONJ]] **υπερ** *hyper* za [[G5228]] [[PREP]] **εμου** *emou* mnie [[G1700]] WTP-1GS **ινα** *hina* aby [[G2443]] [[CONJ]] **μοι** *moi* mi [[G3427]] WTP-1DS **δοθειη** *dotheiē* oby zostało dane [[G1325]] WTV-APO-3S **λογος** *logos* słowo [[G3056]] [[N-NSM]] **εν** *en* w [[G1722]] [[PREP]] **ανοιξει** *anoiksei* otworzeniu [[G457]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSN **στοματος** *stomatos* ust [[G4750]] [[N-GSN]] **μου** *mou* moich [[G3450]] WTP-1GS **εν** *en* w [[G1722]] [[PREP]] **παρρησια** *parrēsia* śmiałości – otwartości [[G3954]] [[N-DSF]] **γνωρισαι** *gnōrisai* (by) oznajmić – (by) dać poznać [[G1107]] [[V-AAN]] **το** *to* [[G3588]] WTT-ASN **μυστηριον** *mystērion* tajemnicę [[G3466]] WTN-ASN **του** *tou* [[G3588]] WTT-GSN **ευαγγελιου** *euangeliou* dobrej nowiny [[G2098]] [[N-GSN]]
###### **Ef 6,20**
 **υπερ** *hyper* względem [[G5228]] [[PREP]] **ου** *hou* której [[G3739]] WTR-GSN **πρεσβευω** *presbeuō* jestem posłany – sprawuję poselstwo [[G4243]] WTV-PAI-1S **εν** *en* w [[G1722]] [[PREP]] **αλυσει** *halysei* łańcuchach – kajdanach [[G254]] [[N-DSF]] **ινα** *hina* aby [[G2443]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **αυτω** *autō* niej [[G846]] WTP-DSN **παρρησιασωμαι** *parrēsiasōmai* powiedziałbym otwarcie [[G3955]] WTV-ADS-1S **ως** *hōs* jak [[G5613]] [[ADV]] **δει** *dei* trzeba – jest konieczne [[G1163]] WTV-PQI-3S **με** *me* mi [[G3165]] WTP-1AS **λαλησαι** *lalēsai* powiedzieć [[G2980]] [[V-AAN]]
###### **Ef 6,21**
 **ινα** *hina* Aby [[G2443]] [[CONJ]] **δε** *de* zaś [[G1161]] [[CONJ]] **ειδητε** *eidēte* wiedzielibyście [[G1492]] WTV-RAS-2P **και** *kai* i [[G2532]] [[CONJ]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **τα** *ta* (te) [[G3588]] WTT-APN **κατ** *kat* co do [[G2596]] [[PREP]] **εμε** *eme* mnie [[G1691]] WTP-1AS **τι** *ti* co [[G5101]] WTI-ASN **πρασσω** *prassō* robię – czynię [[G4238]] WTV-PAI-1S **παντα** *panta* wszystkie [[G3956]] WTA-APN **υμιν** *hymin* wam [[G5213]] WTP-2DP **γνωρισει** *gnōrisei* oznajmi – da poznać [[G1107]] WTV-FAI-3S **τυχικος** *tychikos* Tychikus – [przypadkowy] [[G5190]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **αγαπητος** *agapētos* umiłowany [[G27]] [[A-NSM]] **αδελφος** *adelfos* brat [[G80]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **πιστος** *pistos* wierny [[G4103]] [[A-NSM]] **διακονος** *diakonos* sługa [[G1249]] [[N-NSM]] **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM
###### **Ef 6,22**
 **ον** *hon* którego [[G3739]] WTR-ASM **επεμψα** *epempsa* posłałem [[G3992]] WTV-AAI-1S **προς** *pros* do [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **εις** *eis* względem [[G1519]] [[PREP]] **αυτο** *auto* samego [[G846]] WTP-ASN **τουτο** *touto* tego [[G5124]] WTD-ASN **ινα** *hina* aby [[G2443]] [[CONJ]] **γνωτε** *gnōte* poznalibyście [[G1097]] WTV-2AAS-2P **τα** *ta* (o tych) [[G3588]] WTT-APN **περι** *peri* co do [[G4012]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP **και** *kai* i [[G2532]] [[CONJ]] **παρακαλεση** *parakalesē* zachęciłby [[G3870]] WTV-AAS-3S **τας** *tas* [[G3588]] WTT-APF **καρδιας** *kardias* serca [[G2588]] WTN-APF **υμων** *hymōn* wasze [[G5216]] WTP-2GP
###### **Ef 6,23**
 **ειρηνη** *eirēnē* Pokój [[G1515]] [[N-NSF]] **τοις** *tois* [[G3588]] WTT-DPM **αδελφοις** *adelfois* braciom [[G80]] WTN-DPM **και** *kai* i [[G2532]] [[CONJ]] **αγαπη** *agapē* miłość [[G26]] [[N-NSF]] **μετα** *meta* z [[G3326]] [[PREP]] **πιστεως** *pisteōs* wiarą [[G4102]] [[N-GSF]] **απο** *apo* od [[G575]] [[PREP]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **πατρος** *patros* Ojca [[G3962]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **Ef 6,24**
 **η** *hē* [[G3588]] [[T-NSF]] **χαρις** *charis* Łaska [[G5485]] [[N-NSF]] **μετα** *meta* z [[G3326]] [[PREP]] **παντων** *pantōn* wszystkimi [[G3956]] WTA-GPM **των** *tōn* [[G3588]] WTT-GPM **αγαπωντων** *agapōntōn* miłującymi [[G25]] WTV-PAP-GPM **τον** *ton* [[G3588]] [[T-ASM]] **κυριον** *kyrion* Pana [[G2962]] [[N-ASM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]] **χριστον** *christon* Pomazańca [[G5547]] [[N-ASM]] **εν** *en* w [[G1722]] [[PREP]] **αφθαρσια** *aftharsia* niezniszczalności – nieskazitelności [[G861]] [[N-DSF]] **προς** *pros* do [[G4314]] [[PREP]] **εφεσιους** *efesious* Efezjan [[G2180]] WTA-APM **εγραφη** *egrafē* zostało napisane [[G1125]] WTV-2API-3S **απο** *apo* z [[G575]] [[PREP]] **ρωμης** *rōmēs* Rzymu [[G4516]] [[N-GSF]] **δια** *dia* przez [[G1223]] [[PREP]] **τυχικου** *tychikou* Tychikusa – [przypadkowy] [[G5190]] [[N-GSM]]
