# Dz 8 BT5
###### **Dz 8,1**
 Szaweł zaś zgadzał się na zabicie go. W tym dniu wybuchło wielkie prześladowanie w Kościele jerozolimskim. Wszyscy, z wyjątkiem Apostołów, rozproszyli się po okolicach Judei i Samarii.
###### **Dz 8,2**
 Szczepana zaś pochowali ludzie pobożni z wielkim żalem.
###### **Dz 8,3**
 A Szaweł niszczył Kościół, wchodząc do domów, porywał mężczyzn i kobiety i wtrącał do więzienia.
###### **Dz 8,4**
 Ci, którzy się rozproszyli, głosili w drodze słowo.
###### **Dz 8,5**
 Filip przybył do miasta Samarii i głosił im Chrystusa.
###### **Dz 8,6**
 Tłumy słuchały z uwagą i skupieniem słów Filipa, ponieważ widziały znaki, które czynił.
###### **Dz 8,7**
 Z wielu bowiem opętanych wychodziły z donośnym krzykiem duchy nieczyste, wielu też sparaliżowanych i chromych zostało uzdrowionych.
###### **Dz 8,8**
 Wielka zaś radość zapanowała w tym mieście.
###### **Dz 8,9**
 Pewien człowiek, imieniem Szymon, który dawniej zajmował się czarną magią, wprawiał w zdumienie lud Samarii, mówiąc, że jest kimś niezwykłym.
###### **Dz 8,10**
 Poważali go wszyscy od najmniejszego do największego: «***Ten jest mocą Bożą, którą zowią wielką***» – mówili.
###### **Dz 8,11**
 A liczyli się z nim dlatego, że już od dość długiego czasu wprawiał ich w podziw swoimi magicznymi sztukami.
###### **Dz 8,12**
 Lecz kiedy uwierzyli Filipowi, który głosił dobrą nowinę o królestwie Bożym oraz o imieniu Jezusa Chrystusa, zarówno mężczyźni, jak i kobiety przyjmowali chrzest.
###### **Dz 8,13**
 Uwierzył również sam Szymon, a kiedy przyjął chrzest, towarzyszył wszędzie Filipowi i zdumiewał się bardzo na widok dokonywanych cudów i znaków.
###### **Dz 8,14**
  Kiedy Apostołowie w Jerozolimie dowiedzieli się, że Samaria przyjęła słowo Boże, wysłali do niej Piotra i Jana,
###### **Dz 8,15**
 którzy przyszli i modlili się za nich, aby mogli otrzymać Ducha Świętego.
###### **Dz 8,16**
 Bo na żadnego z nich jeszcze nie zstąpił. Byli jedynie ochrzczeni w imię Pana Jezusa.
###### **Dz 8,17**
 Wtedy więc kładli [Apostołowie] na nich ręce, a oni otrzymywali Ducha Świętego.
###### **Dz 8,18**
  Kiedy Szymon ujrzał, że Apostołowie przez nakładanie rąk udzielali Ducha Świętego, przyniósł im pieniądze.
###### **Dz 8,19**
 «***Dajcie i mnie tę władzę – powiedział – aby każdy, na kogo położę ręce, otrzymał Ducha Świętego***».
###### **Dz 8,20**
 «***Niech pieniądze twoje przepadną razem z tobą***» – odpowiedział mu Piotr – «***gdyż sądziłeś, że dar Boży nabyć można za pieniądze.***
###### **Dz 8,21**
 ***Nie masz żadnego udziału w tym dziele, bo serce twoje nie jest prawe wobec Boga.***
###### **Dz 8,22**
 ***Odwróć się więc od swego grzechu i proś Pana, a może ci odpuści twój zamiar.***
###### **Dz 8,23**
 ***Bo widzę, że jesteś żółcią gorzką i wiązką nieprawości***».
###### **Dz 8,24**
 A Szymon odpowiedział: «***Módlcie się za mną do Pana, aby nie spotkało mnie nic z tego, co powiedzieliście***».
###### **Dz 8,25**
 Kiedy dali świadectwo i opowiedzieli słowo Pańskie, udali się w drogę powrotną do Jerozolimy i głosili Ewangelię w wielu wioskach samarytańskich.
###### **Dz 8,26**
 «***Wstań i pójdź około południa na drogę, która prowadzi z Jerozolimy do Gazy: jest ona pusta***» – powiedział anioł Pański do Filipa.
###### **Dz 8,27**
 A on poszedł. Właśnie wtedy przybył do Jerozolimy oddać pokłon [Bogu] Etiop, dworzanin królowej etiopskiej Kandaki, zarządzający całym jej skarbcem,
###### **Dz 8,28**
 i wracał, czytając w swoim wozie proroka Izajasza.
###### **Dz 8,29**
 «***Podejdź i przyłącz się do tego wozu***» – powiedział Duch do Filipa.
###### **Dz 8,30**
 Gdy Filip podbiegł, usłyszał, że tamten czyta proroka Izajasza: «***Czy rozumiesz, co czytasz?***» – zapytał.
###### **Dz 8,31**
 A tamten odpowiedział: «***Jakżeż mogę [rozumieć], jeśli mi nikt nie wyjaśni?***» I zaprosił Filipa, aby wsiadł i spoczął przy nim.
###### **Dz 8,32**
 A czytał ten urywek Pisma: Prowadzą Go jak owcę na rzeź, i jak baranek, który milczy, gdy go strzygą, tak On nie otwiera ust swoich.
###### **Dz 8,33**
 W Jego uniżeniu odmówiono Mu słuszności. Któż zdoła opisać ród Jego? Bo Jego życie zabiorą z ziemi.
###### **Dz 8,34**
 «***Proszę cię, o kim to Prorok mówi, o sobie czy o kimś innym?***» – zapytał Filipa dworzanin.
###### **Dz 8,35**
 A Filip otworzył usta i wyszedłszy od tego [tekstu] Pisma, opowiedział mu Dobrą Nowinę o Jezusie.
###### **Dz 8,36**
 W czasie podróży przybyli nad jakąś wodę: «***Oto woda – powiedział dworzanin – cóż stoi na przeszkodzie, abym został ochrzczony?***» 
###### **Dz 8,37**
< >
###### **Dz 8,38**
 I kazał zatrzymać wóz, i obaj, Filip i dworzanin, weszli do wody. I ochrzcił go.
###### **Dz 8,39**
 A kiedy wyszli z wody, Duch Pański porwał Filipa i dworzanin już więcej go nie widział. Jechał zaś z radością swoją drogą.
###### **Dz 8,40**
 A Filip znalazł się w Azocie i głosił Ewangelię, przechodząc przez wszystkie miasta, aż dotarł do Cezarei.
# Dz 8 PAU
###### **Dz 8,1**
 A Szaweł uważał to zabójstwo za słuszne. Zaczęło się wtedy gwałtowne prześladowanie Kościoła w Jerozolimie. Dlatego wszyscy wierzący, z wyjątkiem apostołów, rozproszyli się po terenach Judei i Samarii.
###### **Dz 8,2**
 Pobożni ludzie, opłakując śmierć Szczepana, pochowali go.
###### **Dz 8,3**
 A Szaweł niszczył Kościół. Wpadał do domów, porywał mężczyzn i kobiety i wtrącał ich do więzienia.
###### **Dz 8,4**
 Ci, którzy się rozproszyli, w różnych miejscach głosili Ewangelię.
###### **Dz 8,5**
 Filip udał się do Samarii i jej mieszkańcom mówił o Chrystusie.
###### **Dz 8,6**
 Tłumy gromadziły się wokół niego i słuchały go z uwagą, ponieważ widziały znaki, które czynił.
###### **Dz 8,7**
 Bo z wielu opętanych wychodziły z krzykiem duchy nieczyste. Wielu też ludzi sparaliżowanych i kalekich zostało uzdrowionych.
###### **Dz 8,8**
 Wielka radość zapanowała w tym mieście.
###### **Dz 8,9**
 Od dawna mieszkał tam człowiek o imieniu Szymon. Zajmował się magią i wprawiał w zdumienie mieszkańców Samarii. Podawał się za kogoś niezwykłego.
###### **Dz 8,10**
 Poważali go wszyscy, zarówno młodzi, jak i starzy. Mówili, że w tym człowieku objawia się wielka moc Boża.
###### **Dz 8,11**
 Garnęli się do niego, bo już od dłuższego czasu zadziwiał ich magicznymi sztuczkami.
###### **Dz 8,12**
 Lecz kiedy uwierzyli Filipowi, który głosił Ewangelię o królestwie Bożym i imieniu Jezusa Chrystusa, zarówno mężczyźni, jak i kobiety przyjmowali chrzest.
###### **Dz 8,13**
 Uwierzył nawet sam Szymon i przyjął chrzest. Nie odstępował od Filipa i dziwił się cudom i znakom, jakich on dokonywał.
###### **Dz 8,14**
 Apostołowie w Jerozolimie dowiedzieli się o tym, że mieszkańcy Samarii przyjęli słowo Boże. Wysłali więc do nich Piotra i Jana.
###### **Dz 8,15**
 A oni przyszli i modlili się za nich, aby otrzymali Ducha Świętego.
###### **Dz 8,16**
 Bo na żadnego z nich jeszcze nie zstąpił. Byli jedynie ochrzczeni w imię Pana Jezusa.
###### **Dz 8,17**
 Nakładali na nich ręce, a oni otrzymywali Ducha Świętego.
###### **Dz 8,18**
 A kiedy Szymon zobaczył, że przez nałożenie rąk apostołowie udzielają Ducha Świętego, przyniósł pieniądze
###### **Dz 8,19**
 i poprosił: „Dajcie i mnie taką moc, abym, nakładając ręce, rozdzielał wszystkim Ducha Świętego”.
###### **Dz 8,20**
 Piotr odpowiedział: „Niech pieniądze twoje przepadną razem z tobą. Sądziłeś, że można kupić dar Boży.
###### **Dz 8,21**
 Nie będziesz miał nic wspólnego z tym dziełem, gdyż nie jesteś uczciwy wobec Boga.
###### **Dz 8,22**
 Odwróć się od grzechu i proś Pana, a może ci przebaczy twoje pragnienie.
###### **Dz 8,23**
 Widzę bowiem, że jesteś bardzo zły i trwasz w więzach nieuczciwości”.
###### **Dz 8,24**
 Wtedy Szymon zaczął prosić: „Błagajcie za mną Pana, aby nie spotkało mnie to, o czym mówiliście”.
###### **Dz 8,25**
 Kiedy dali świadectwo i opowiedzieli słowo Pana, wyruszyli w drogę powrotną do Jerozolimy. I w wielu miejscowościach samarytańskich głosili Ewangelię.
###### **Dz 8,26**
 Anioł Pański powiedział Filipowi: „Idź około południa na drogę prowadzącą z Jeruzalem do Gazy. Jest ona pusta”.
###### **Dz 8,27**
 A on poszedł. Właśnie wtedy przejeżdżał tamtędy Etiopczyk, wysoki urzędnik zarządzający skarbem królowej Etiopii, Kandaki. Przybył on do Jeruzalem, aby oddać cześć Bogu.
###### **Dz 8,28**
 Jechał na wozie i czytał proroka Izajasza.
###### **Dz 8,29**
 Duch zaś powiedział do Filipa: „Podejdź i uchwyć się jego wozu!”.
###### **Dz 8,30**
 Gdy Filip podbiegł, usłyszał, że tamten czyta proroka Izajasza. Zapytał więc: „Czy rozumiesz, co czytasz?”.
###### **Dz 8,31**
 A on odpowiedział: „Jakże mogę zrozumieć, skoro nikt mi tego nie wyjaśnił?”. Zaprosił więc Filipa, aby usiadł obok niego.
###### **Dz 8,32**
 A czytał następujący fragment Pisma: Prowadzą go jak owcę na zabicie, a On jak baranek, gdy go strzygą, milczy i nie otwiera ust swoich.
###### **Dz 8,33**
 Został poniżony i wyjęty spod prawa. Któż może opowiedzieć o Jego pokoleniu, skoro Jego życie zabrane zostało z ziemi?
###### **Dz 8,34**
 A urzędnik zapytał Filipa: „Powiedz mi, proszę, o kim pisze prorok? O sobie samym czy też o kimś innym?”.
###### **Dz 8,35**
 Wtedy Filip, wychodząc od przeczytanego tekstu Pisma, opowiedział mu Ewangelię o Jezusie.
###### **Dz 8,36**
 W czasie dalszej podróży przybyli nad jakąś wodę. Wtedy urzędnik powiedział: „Patrz! Woda. Co przeszkadza, bym został ochrzczony?”.
###### **Dz 8,37**
 [Odpowiedział Filip: „Można, jeśli wierzysz z całego serca”. A urzędnik rzekł: „Wierzę, że Jezus Chrystus jest Synem Bożym”]
###### **Dz 8,38**
 Kazał zatrzymać wóz i obaj - Filip i urzędnik - zeszli do wody. Tam Filip go ochrzcił.
###### **Dz 8,39**
 A kiedy wyszli z wody, Duch Pański porwał Filipa. Urzędnik już go więcej nie zobaczył. Z radością wyruszył w dalszą drogę.
###### **Dz 8,40**
 Filip zaś znalazł się w Azocie. Głosił Ewangelię w wielu miastach i dotarł aż do Cezarei.
# Dz 8 BP
###### **Dz 8,1**
 Szaweł zaś zgadzał się na jego śmierć. A było to w czasie wielkiego prześladowania Kościoła w Jerozolimie. Wszyscy oprócz apostołów rozproszyli się po terenach Judei i Samarii.
###### **Dz 8,2**
 Z płaczem i bólem pochowali Szczepana pobożni ludzie.
###### **Dz 8,3**
 Szaweł zaś burząc Kościół wpadał do domów, wyciągał mężczyzn i kobiety i wtrącał do więzienia.
###### **Dz 8,4**
 Rozproszeni po różnych miejscach głosili dobrą nowinę.
###### **Dz 8,5**
 I tak Filip doszedł do miasta Samarii i nauczał tam o Chrystusie.
###### **Dz 8,6**
 Tłumy z ogromną uwagą i zainteresowaniem słuchały słów Filipa patrząc na znaki, które czynił.
###### **Dz 8,7**
 Z wielu bowiem opętanych z wielkim krzykiem wychodziły duchy nieczyste, wielu paralityków i kalek zostało uzdrowionych,
###### **Dz 8,8**
 co wywołało wielką radość w tym mieście.
###### **Dz 8,9**
 Mieszkał w tym mieście od dawna człowiek imieniem Szymon, zajmujący się magią. Uważał się za kogoś wielkiego i podziwiany był przez Samarytan.
###### **Dz 8,10**
 Słuchali go więc wszyscy od małego do wielkiego i mówili: "Ten jest wielką mocą Bożą".
###### **Dz 8,11**
 Od dawna go słuchali, zwodził ich bowiem magicznymi sztuczkami.
###### **Dz 8,12**
 Gdy jednak uwierzyli Filipowi, który głosił dobrą nowinę o królestwie Bożym i o imieniu Jezusa Chrystusa, dali się ochrzcić zarówno mężczyźni, jak i kobiety.
###### **Dz 8,13**
 Uwierzył nawet sam Szymon, został ochrzczony i nie odstępował od Filipa, był bowiem pełen podziwu na widok nadziemskiej mocy i wielu znaków, których [Filip] dokonywał.
###### **Dz 8,14**
 Kiedy apostołowie znajdujący się w Jerozolimie dowiedzieli się, że w Samarii przyjęto słowo Boże, wysłali tam Piotra i Jana,
###### **Dz 8,15**
 którzy modlili się nad nimi, aby otrzymali Ducha Świętego;
###### **Dz 8,16**
 dotychczas bowiem na nikogo z nich nie zstąpił, byli tylko ochrzczeni w imię Jezusa.
###### **Dz 8,17**
 I wtedy ci, na których wkładali ręce, otrzymywali Ducha Świętego.
###### **Dz 8,18**
 Kiedy Szymon zobaczył, że przez wkładanie rąk apostołowie udzielają Ducha Świętego, przyniósł im pieniądze i powiedział:
###### **Dz 8,19**
 "Udzielcie i mnie tej władzy, abym przez wkładanie rąk mógł także udzielać Ducha Świętego".
###### **Dz 8,20**
 Wtedy Piotr powiedział do niego: "Niech zginą twoje pieniądze i ty razem z nimi, sądziłeś bowiem, że dar Boży można nabyć za pieniądze.
###### **Dz 8,21**
 Nie możesz mieć żadnego udziału w tym dziele, gdyż w sercu twoim nie ma szczerości wobec Boga.
###### **Dz 8,22**
 Odwróć się od tego zła i proś Pana, a może ci przebaczy zamiar, który zrodził się w twoim sercu.
###### **Dz 8,23**
 Bo widzę, że jesteś pełen żółci i uwikłany w nieprawości".
###### **Dz 8,24**
 Szymon odpowiedział na to: "Módlcie się za mnie do Pana, aby nie spotkało mnie to, o czym mówiliście".
###### **Dz 8,25**
 Kiedy już dali świadectwo słowu Pańskiemu, które głosili, udali się w powrotną drogę do Jerozolimy, w wielu jeszcze wioskach samarytańskich głosząc dobrą nowinę.
###### **Dz 8,26**
 Anioł Pański powiedział Filipowi: "Wstań i około południa udaj się na drogę, prowadzącą z Jerozolimy do Gazy; będzie ona pusta".
###### **Dz 8,27**
 Wstał więc i poszedł. W tym czasie Etiopczyk, wysoki urzędnik królowej etiopskiej Kandaki, zarządzający całym jej skarbem, powracał z Jerozolimy. Był tam złożyć hołd Bogu.
###### **Dz 8,28**
 Siedząc na wozie, czytał proroka Izajasza.
###### **Dz 8,29**
 Powiedział Duch do Filipa: "Zbliż się i idź przy wozie".
###### **Dz 8,30**
 Gdy Filip dobiegł, usłyszał, że czyta proroka Izajasza. Zapytał więc: "Czy ty rozumiesz, co czytasz?"
###### **Dz 8,31**
 Odpowiedział: "Skąd bym mógł, skoro mi nikt nie objaśni" i poprosił Filipa, aby wsiadł do wozu.
###### **Dz 8,32**
 A urywek Pisma, który czytał, był następujący: "Jak owca na zabicie prowadzona, jak milczący baranek, gdy go strzygą, tak on nie otwiera ust.
###### **Dz 8,33**
 W chwili uniżenia nie przyznano mu słuszności, któż opisze jego ród, bo życie jego z ziemi będzie wymazane".
###### **Dz 8,34**
 Zapytał dworzanin Filipa: "Proszę cię, o kim to prorok mówi, o sobie, czy o kimś innym?"
###### **Dz 8,35**
 Nawiązując do przeczytanego tekstu opowiedział mu Filip dobrą nowinę o Jezusie.
###### **Dz 8,36**
 Jadąc tą drogą, przybyli nad jakąś wodę; wtedy powiedział dworzanin: "Patrz, woda! Czy istnieje jakaś przeszkoda, abyś mnie ochrzcił?"
###### **Dz 8,37**
 [Odpowiedział Filip: „Można, jeśli wierzysz z całego serca”. A urzędnik rzekł: „Wierzę, że Jezus Chrystus jest Synem Bożym”]
###### **Dz 8,38**
 Zatrzymał więc wóz, weszli do wody i Filip ochrzcił dworzanina.
###### **Dz 8,39**
 Gdy wyszli z wody, Duch porwał Filipa i już go więcej dworzanin nie zobaczył, z radością jednak jechał dalej tą drogą.
###### **Dz 8,40**
 Filip zaś znalazł się w Azot i chodząc po różnych miastach głosił dobrą nowinę, aż doszedł do Cezarei.
# Dz 8 BR
###### **Dz 8,1**
 W tym samym czasie rozpoczęło się krwawe prześladowanie chrześcijan w Jerozolimie. Wszyscy, z wyjątkiem apostołów, rozbiegli się po różnych zakątkach Judei i Samarii.
###### **Dz 8,2**
 Pobożni zaś chrześcijanie, ubolewając bardzo, pochowali Szczepana.
###### **Dz 8,3**
 A Szaweł dokładał wszelkich starań, by zniszczyć Kościół: wpadał znienacka do domów, porywał mężczyzn i kobiety i wtrącał ich do więzienia.
###### **Dz 8,4**
 Ci zaś, którzy się rozproszyli, głosili słowo przechodząc z miejsca na miejsce.
###### **Dz 8,5**
 [Tak na przykład] Filip przybył do Samarii i tam głosił Chrystusa.
###### **Dz 8,6**
 Słuchały go w skupieniu tłumy ludzi, ponieważ widziano znaki, które czynił.
###### **Dz 8,7**
 Wielu bowiem opętanych z krzykiem opuszczały złe duchy, wielu też sparaliżowanych i chromych odzyskiwało zdrowie,
###### **Dz 8,8**
 tak iż wkrótce zapanowała w tym mieście wielka radość.
###### **Dz 8,9**
 A pewien człowiek, imieniem Szymon, zajmujący się jeszcze do niedawna czarami, wprawiał w zdumienie prosty lud Samarii, twierdząc, że ma do spełnienia jakieś niezwykłe posłannictwo.
###### **Dz 8,10**
 Poważali go wszyscy, od najmłodszych do najstarszych, mówiąc: Człowiek ten to zaiste wielka potęga Boża.
###### **Dz 8,11**
 Darzono go zaś tak wielkim szacunkiem dlatego, że już od dość długiego czasu zadziwiał ich swoimi sztuczkami.
###### **Dz 8,12**
 Lecz skoro tylko trafiła im do przekonania głoszona przez Filipa nauka o królestwie Bożym i o imieniu Jezusa Chrystusa, zarówno mężczyźni, jak i kobiety zaczęli przyjmować chrzest.
###### **Dz 8,13**
 Uwierzył w końcu sam Szymon i przyjąwszy chrzest towarzyszył wszędzie Filipowi, i zdumienie go ogarniało na widok rozlicznych cudów i znaków.
###### **Dz 8,14**
 A kiedy przebywający w Jerozolimie apostołowie dowiedzieli się, że Samaria przyjmuje słowo Boże, wysłali do nich Piotra i Jana.
###### **Dz 8,15**
 Ci zaś przybywszy tam modlili się, by i na nich zechciał zstąpić Duch Święty.
###### **Dz 8,16**
 Bo dotychczas jeszcze na żadnego z nich nie zstąpił Duch Święty. Byli tylko ochrzczeni w imię Pana Jezusa.
###### **Dz 8,17**
 [Piotr i Jan] wkładali tedy na nich ręce, a oni w ten sposób otrzymywali Ducha Świętego.
###### **Dz 8,18**
 A kiedy Szymon zobaczył, że przez włożenie rąk udzielali Ducha Świętego, przyniósł im pewną sumę pieniędzy
###### **Dz 8,19**
 i powiedział: Dajcie i mnie taką władzę, ażeby każdy, na kogo włożę ręce, mógł otrzymać Ducha Świętego.
###### **Dz 8,20**
 Lecz Piotr odpowiedział mu: Obyś przepadł razem z twoimi pieniędzmi, jeśli sądzisz, że dar Boży można kupić za pieniądze.
###### **Dz 8,21**
 Nie masz nic wspólnego z tym dziełem, bo twoje serce nie jest otwarte wobec Boga!
###### **Dz 8,22**
 Porzuć więc twoje niecne zamiary i proś Pana, a może ci przebaczy to, że w ogóle miałeś takie myśli.
###### **Dz 8,23**
 Widzę bowiem, jesteś pełen gorzkiej nieprawości i cały pozostajesz w grzechach.
###### **Dz 8,24**
 Powiedział tedy Szymon: Proście sami Pana, aby mnie nie spotkało nic z tego, o czym mówiliście przed chwilą.
###### **Dz 8,25**
 Złożywszy w ten sposób [apostolskie] świadectwo i ogłosiwszy słowo Pana, ruszyli w drogę powrotną do Jerozolimy. Po drodze głosili Ewangelię w wielu wioskach Samarii.
###### **Dz 8,26**
 [W pewnym momencie] anioł Pański powiedział do Filipa: Wstań i udaj się na południe drogą, która prowadzi z Jerozolimy do Gazy przez pustkowie.
###### **Dz 8,27**
 I poszedł [Filip]. A właśnie w tym samym czasie przybył do Jerozolimy, by złożyć pokłon Bogu, pewien Etiop, urzędnik królowej etiopskiej Kandaki, mający pieczę nad całym jej skarbcem.
###### **Dz 8,28**
 A gdy już wracał, czytał w swoim powozie księgę proroka Izajasza.
###### **Dz 8,29**
 Wtedy Duch [Pański] powiedział do Filipa: Podejdź bliżej i pozostań blisko tego wozu.
###### **Dz 8,30**
 Zbliżywszy się Filip usłyszał, jak tamten czytał proroka Izajasza. I zapytał go: Czy ty rozumiesz to, co czytasz?
###### **Dz 8,31**
 A tamten odpowiedział: Jakżeż mogę rozumieć, skoro nikt mi tego nie wyjaśnił? I poprosił Filipa, żeby wsiadł do jego powozu i zajął miejsce obok.
###### **Dz 8,32**
 Czytał zaś te oto słowa Pisma: Prowadzą Go jak owcę na rzeź, a On jest jak baranek, który milczy, gdy go strzygą; wcale nie otwiera ust swoich.
###### **Dz 8,33**
 Został poniżony i nikt nie przyznał Mu słuszności. Któż będzie mógł opisać ród Jego? Bo przecież położono już kres Jego życiu na ziemi.
###### **Dz 8,34**
 I zapytał dworzanin Filipa: Powiedz mi, proszę cię, o kim tu mówi prorok: o sobie samym czy o kimś innym?
###### **Dz 8,35**
 A Filip wychodząc od tego miejsca Pisma opowiedział mu całą Dobrą Nowinę o Jezusie.
###### **Dz 8,36**
 I tak podróżując przybyli nad jakąś wodę. Wtedy powiedział dworzanin: Oto mamy już wodę; czy stoi jeszcze coś na przeszkodzie, żebym mógł być ochrzczony?
###### **Dz 8,37**
 (Odpowiedział mu Filip: Nic, jeśli tylko wierzysz z całego serca. A on odpowiedział: Wierzę, że Jezus Chrystus jest Synem Bożym.)
###### **Dz 8,38**
 Kazał też zaraz zatrzymać wóz, po czym obaj, Filip i dworzanin, zeszli do wody. I ochrzcił go [Filip].
###### **Dz 8,39**
 Kiedy zaś wyszli z wody, Duch Pański porwał Filipa i już więcej nie widział go dworzanin, który w radości wielkiej odbywał swoją dalszą podróż.
###### **Dz 8,40**
 Filip zaś przybył do Azotu, a potem głosząc Ewangelię szedł od miasta do miasta, aż dotarł w końcu do
# Dz 8 WUJ
###### **Dz 8,1**
 I stało się onego dnia wielkie prześladowanie przeciw kościołowi, który był w Jeruzalem, i rozproszyli się wszyscy po krainach Żydowskiej ziemie, i Samarjej, oprócz Apostołów.
###### **Dz 8,2**
 I pogrzebli Szczepana ludzie bogobojni, i uczynili nad nim wielkie płakanie.
###### **Dz 8,3**
 A Szaweł burzył kościół: wchadzając w domy, i ciągnąc męże i niewiasty, podawał do więzienia.
###### **Dz 8,4**
 Którzy tedy byli rozproszeni, chodzili opowiadając słowo Boże.
###### **Dz 8,5**
 A Filip zaszedszy do miasta Samaryjskiego opowiadał im Chrystusa.
###### **Dz 8,6**
 A rzesze przychylały się do tego co Filip powiadał, jednomyślnie słuchając, i widząc znaki, które czynił.
###### **Dz 8,7**
 Abowiem wiele duchów nieczystych, tych, którzy je mieli, wychodziło wołając głosem wielkim. Wiele też powietrzem ruszonych i chromych byli uzdrowieni.
###### **Dz 8,8**
 Stało się tedy wielkie wesele w onem mieście,
###### **Dz 8,9**
 A niektóry mąż imieniem Symon, który przedtem był w onem mieście Czarnoksiężnik, zwodząc lud w Samarjej, powiadając się być kim wielkim:
###### **Dz 8,10**
 Którego słuchali wszyscy, od namniejszego, aż do nawiętszego, mówiąc; Ten jest moc Bożą, którą zowią wielka.
###### **Dz 8,11**
 A słuchali go przeto, iż od dawnego czasu poszalił je był Czarnoksięztwy swemi.
###### **Dz 8,12**
 A gdy uwierzyli Filipowi opowiadającemu o królestwie Bożem, w imię Jezusa Chrystusa chrzcili się mężowie i niewiasty.
###### **Dz 8,13**
 Tedy i sam też Symon uwierzył: a ochrzciwszy się trwał przy Filipie. Widząc też, że się znaki i mocy barzo wielkie działy, zdumiewając się dziwował.
###### **Dz 8,14**
 A usłyszawszy Apostołowie, którzy byli w Jeruzalem, iż Samarya przyjęła słowo Boże: posłali do nich Piotra i Jana.
###### **Dz 8,15**
 Którzy, gdy przyszli, modlili się za nimi, aby wzięli Ducha świętego.
###### **Dz 8,16**
 Abowiem jeszcze nie przyszedł był na żadnego z nich: ale tylko ochrzczeni byli w imię Pana Jezusowe.
###### **Dz 8,17**
 Tedy na nie wkładali ręce, i brali Ducha świętego.
###### **Dz 8,18**
 A ujrzawszy Symon, że przez wkładanie rąk Apostolskich był dawan Duch święty: ofiarował im pieniądze,
###### **Dz 8,19**
 Mówiąc: Dajcie i mnie tę moc, aby na któregobychkolwiek ręce włożył, wziął Ducha świętego.
###### **Dz 8,20**
 A Piotr rzekł do niego: Pieniądze twe niech z tobą będą na zginienie: żeś mniemał, iżby dar Boży miał być za pieniądze nabywany.
###### **Dz 8,21**
 Niemasz cząstki ani działu w tej mowie: bowiem serce twe nie jest proste przed Bogiem.
###### **Dz 8,22**
 Pokutujże tedy za tę złość twoję: a proś Boga, jeślić snać odpuszczona będzie ta myśl serca twego.
###### **Dz 8,23**
 Abowiem cię widzę być w żółci gorzkości, i związaniu nieprawości.
###### **Dz 8,24**
 A odpowiedziawszy Symon rzekł: Módlcie się wy za mną do Pana, aby na mię nic z tego nie przyszło coście powiedzieli.
###### **Dz 8,25**
 A tak oni świadectwo wydawszy i opowiedziawszy słowo Pańskie, wracali się do Jeruzalem: i w wielu krainach Samarytańskich Ewangelią opowiadali.
###### **Dz 8,26**
 A anioł Pański mówił do Filipa, rzekąc: Wstań a idź ku południowi, na drogę, która od Jeruzalem bieży ku Gazie, Ta jest spustoszała.
###### **Dz 8,27**
 I wstawszy szedł. A oto mąż Ethyoptanin Rzezaniec możny Kandaki królowej Ethyopskiej, który był nad wszystkiemi skarby jej, przyjachał był pokłonić się do Jeruzalem:
###### **Dz 8,28**
 I wracał się siedząc na wozie swym, a czytając Izajasza proroka.
###### **Dz 8,29**
 I rzekł duch Filipowi: Przystąp, a przyłącz się do wozu tego.
###### **Dz 8,30**
 A przybiegłszy Filip, usłyszał go czytającego Izajasza proroka, i rzekł: Mniemasz, że rozumiesz co czytasz?
###### **Dz 8,31**
 Który rzekł: a jako mogę, jeśli mi kto nie pokaże? I prosił Filipa, aby wsiadł i siedział z nim.
###### **Dz 8,32**
 A miejsce pisma, które czytał, to było: Jako owca na zabicie wiedzion jest: a jako baranek bez głosu przed tym, który go strzyże, tak nie otworzył ust swoich.
###### **Dz 8,33**
 W uniżeniu jego sąd podniesion jest: A rodzaj jego kto wypowie? abowiem z ziemie zgładzony będzie żywot jego.
###### **Dz 8,34**
 A odpowiedziawszy Rzezaniec Filipowi rzekł: Proszę cię o kim to prorok mówi? o sobie, czyli o kim innym?
###### **Dz 8,35**
 A Filip otworzywszy usta swe, i począwszy od tego pisma, opowiadał mu Jezusa.
###### **Dz 8,36**
 A gdy jachali drogą, przyszli do jednej wody, i rzekł Rzezaniec: Oto woda. Co mi jest na przeszkodzie, abych nie był ochrzczon?
###### **Dz 8,37**
 I rzekł Filip: Jeśli wierzysz ze wszystkiego serca, wolnoć. A odpowiedziawszy rzekł: Wierzę, iż Jezus Chrystus jest Syn Boży.
###### **Dz 8,38**
 I kazał stanąć wozowi: i wstąpili obadwa w wodę, Filip i Rzezaniec: i ochrzcił go.
###### **Dz 8,39**
 A gdy wyszli z wody, Duch Boży porwał Filipa, i nie widział go więcej Rzezaniec: ale jachał swą drogą, weseląc się.
###### **Dz 8,40**
 A Filip znalezion jest w Azocie: a przechodząc opowiadał Ewangelią wszystkim miastom, aż przyszedł do Cezarjej.
# Dz 8 STERN
###### **Dz 8,1**
 a Sza'ul pochwalał to morderstwo. Poczynając od tego dnia, nastało dotkliwe prześladowanie wspólnoty mesjanicznej w Jeruszalaim; wszyscy prócz wysłanników rozproszyli się po terenach J'hudy i Szomron.
###### **Dz 8,2**
 Jacyś pobożni ludzie pochowali Szczepana i gorzko go opłakiwali.
###### **Dz 8,3**
 Ale Sza'ul postawił sobie za cel zniszczyć Wspólnotę Mesjaniczną: wchodził do domu za domem, wyciągał stamtąd mężczyzn i kobiety i wtrącał ich do więzienia.
###### **Dz 8,4**
 Ci jednak, którzy się rozproszyli, gdziekolwiek szli, obwieszczali Dobrą Nowinę o Słowie.
###### **Dz 8,5**
 A Filip poszedł do pewnego miasta w Szomron i głosił im Mesjasza,
###### **Dz 8,6**
 tłumy zaś uważnie słuchały tego, co Filip mówił, bo słyszeli i widzieli cudowne znaki, jakich dokonywał.
###### **Dz 8,7**
 Z wielu bowiem ludzi wychodziły z krzykiem duchy nieczyste, również wielu sparaliżowanych i kalekich doznawało uzdrowienia,
###### **Dz 8,8**
 tak że była w tym mieście wielka radość.
###### **Dz 8,9**
 Był jednak w mieście człowiek imieniem Szim'on, który od pewnego czasu uprawiał magię i zadziwiał lud Szomron, podając się za kogoś wielkiego.
###### **Dz 8,10**
 Wszyscy go słuchali, od najmniejszego do największego, mówiąc: "Człowiek ten to moc Boża zwana "Mocą Wielką"".
###### **Dz 8,11**
 Szli za nim, bo już od dłuższego czasu zdumiewał ich swą magią.
###### **Dz 8,12**
 Kiedy jednak uwierzyli Filipowi, gdy ogłaszał Dobrą Nowinę o Królestwie Bożym i o imieniu Jeszui Mesjasza, zostali zanurzeni, mężczyźni i kobiety.
###### **Dz 8,13**
 Ponadto sam Szim'on uwierzył, a gdy został zanurzony, przystał do Filipa; i zdumiewał się, widząc cudowne znaki i wielkie dzieła mocy, jakie się wciąż wydarzały.
###### **Dz 8,14**
 Kiedy wysłannicy w Jeruszalaim usłyszeli, że Szomron przyjęło Słowo Boże, posłali im Kefę i Jochanana,
###### **Dz 8,15**
 którzy zeszli tam i modlili się za nich, ażeby otrzymali Ruach Ha-Kodesz.
###### **Dz 8,16**
 Bo jak dotąd nie zstąpił On jeszcze na nikogo z nich, zostali tylko zanurzeni w imię Pana Jeszui.
###### **Dz 8,17**
 I gdy Kefa i Jochanan kładli na nich ręce, ci otrzymywali Ruach Ha-Kodesz.
###### **Dz 8,18**
 Szim'on zobaczył, że Duch zostaje dany, gdy wysłannicy kładą na nich ręce, i zaproponował im pieniądze.
###### **Dz 8,19**
 "Dajcie i mnie tę moc - powiedział - ażeby każdy, na kim położę ręce, otrzymał Ruach Ha-Kodesz".
###### **Dz 8,20**
 Ale Kefa odrzekł mu: "Niech sczeźnie twoje srebro - i ty wraz z nim, jeśli myślisz, że można kupić darmo udzielany dar Boży!
###### **Dz 8,21**
 Nie masz żadnego udziału w tej sprawie, bo w oczach Boga serce twoje jest przewrotne.
###### **Dz 8,22**
 Nawróć się więc z tej swojej nikczemności i módl się do Pana. Może jeszcze ci przebaczy, że taką myśl pielęgnujesz w sercu.
###### **Dz 8,23**
 Bo widzę, żeś jest całkiem zgorzkniały i zupełnie pod władzą grzechu!".
###### **Dz 8,24**
 Odrzekł Szim'on: "Módlcie się za mnie do Pana, aby nie spotkało mnie nic z tego, o czym mówiliście".
###### **Dz 8,25**
 Potem, gdy już złożyli obszerne świadectwo i ogłosili Słowo Pańskie, Kefa i Jochanan ruszyli z powrotem do Jeruszalaim, rozgłaszając Dobrą Nowinę w wielu wioskach Szomron.
###### **Dz 8,26**
 Anioł Adonai powiedział do Filipa: "Wstań i idź na południe, na drogę, która schodzi od strony Jeruszalaim do 'Azy, drogę pustynną".
###### **Dz 8,27**
 Wstał więc i poszedł. Po drodze spostrzegł pewnego Etiopczyka, eunucha, który był urzędnikiem odpowiedzialnym za cały skarbiec Kandake, czyli królowej, etiopskiej. Pojechał do Jeruszalaim, aby oddać cześć Bogu,
###### **Dz 8,28**
 a teraz, wracając do domu, siedział w swoim wozie i czytał z proroka Jesza'jahu.
###### **Dz 8,29**
 Duch rzekł do Filipa: "Podejdź do tego wozu i trzymaj się blisko niego".
###### **Dz 8,30**
 Gdy Filip podbiegł tam, usłyszał, że Etiopczyk czyta z Jesza'jahu proroka. "Czy rozumiesz, co czytasz?" - zapytał.
###### **Dz 8,31**
 "Jak mam rozumieć - odparł - skoro mi nikt nie wyjaśni?" I zaprosił Filipa, żeby wspiął się i usiadł przy nim.
###### **Dz 8,32**
 A czytał z tego oto fragmentu Tanach: "Był On jak owca na rzeź prowadzona, jak baranek milczący przed tym, który go strzyże - ust nie otwiera.
###### **Dz 8,33**
 Upokorzono Go i sprawiedliwości Mu odmówiono. Któż opowie o potomkach Jego, skoro życie Jego zostało zabrane z ziemi?".
###### **Dz 8,34**
 Rzekł eunuch do Filipa: "Mam do ciebie pytanie: czy prorok mówi o sobie, czy o kimś innym?".
###### **Dz 8,35**
 I Filip zaczął mówić - wychodząc od tego fragmentu, przeszedł do opowiedzenia mu Dobrej Nowiny o Jeszui.
###### **Dz 8,36**
 A gdy jechali drogą, dotarli do miejsca, gdzie było trochę wody, i eunuch rzekł: "Spójrz, jest woda! Czy coś stoi na przeszkodzie, abym mógł zostać zanurzony?".
###### **Dz 8,37**
 *
###### **Dz 8,38**
 Kazał zatrzymać wóz, po czym obaj, Filip i eunuch, zeszli do wody i Filip go zanurzył.
###### **Dz 8,39**
 Kiedy wyszli z wody, Duch Pański porwał Filipa. Eunuch nie ujrzał go już, bo pojechał swoją drogą, pełen radości.
###### **Dz 8,40**
 Lecz Filip pojawił się w Aszdodzie i dalej głosił Dobrą Nowinę, obchodząc wszystkie miasta, aż dotarł do Cezarei.
# Dz 8 TRO
###### **Dz 8,1**
 **σαυλος** *saulos* Saul – [zapytał] [[G4569]] [[N-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **συνευδοκων** *syneudokōn* zgadzający się [[G4909]] [[V-PAP-NSM]] **τη** *tē* (z) [[G3588]] WTT-DSF **αναιρεσει** *anairesei* zabiciem [[G336]] [[N-DSF]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **εγενετο** *egeneto* stało się [[G1096]] WTV-2ADI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **εκεινη** *ekeinē* tym [[G1565]] WTD-DSF **τη** *tē* [[G3588]] WTT-DSF **ημερα** *hēmera* dniu [[G2250]] [[N-DSF]] **διωγμος** *diōgmos* prześladowanie [[G1375]] [[N-NSM]] **μεγας** *megas* wielkie [[G3173]] [[A-NSM]] **επι** *epi* na [[G1909]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **εκκλησιαν** *ekklēsian* zgromadzenie – (społeczność) wywołanych [[G1577]] WTN-ASF **την** *tēn* [[G3588]] WTT-ASF **εν** *en* w [[G1722]] [[PREP]] **ιεροσολυμοις** *ierosolymois* Jerozolimie – [dziedzictwo pokoju] [[G2414]] WTN-DPN **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **τε** *te* zarówno – także [[G5037]] WTPRT **διεσπαρησαν** *diesparēsan* byli rozproszeni [[G1289]] WTV-API-3P **κατα** *kata* po [[G2596]] [[PREP]] **τας** *tas* [[G3588]] WTT-APF **χωρας** *chōras* krainach [[G5561]] WTN-APF **της** *tēs* [[G3588]] [[T-GSF]] **ιουδαιας** *ioudaias* Judei – [[wielbić] ziemię] [[G2449]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **σαμαρειας** *samareias* Samarii – [zachować] [[G4540]] [[N-GSF]] **πλην** *plēn* oprócz [[G4133]] [[ADV]] **των** *tōn* [[G3588]] WTT-GPM **αποστολων** *apostolōn* wysłanników [[G652]] WTN-GPM
###### **Dz 8,2**
 **συνεκομισαν** *synekomisan* Pogrzebali [[G4792]] WTV-AAI-3P **δε** *de* zaś [[G1161]] [[CONJ]] **τον** *ton* [[G3588]] [[T-ASM]] **στεφανον** *stefanon* Szczepana – [wieniec] [[G4736]] [[N-ASM]] **ανδρες** *andres* mężowie [[G435]] WTN-NPM **ευλαβεις** *eulabeis* pobożni [[G2126]] WTA-NPM **και** *kai* i [[G2532]] [[CONJ]] **εποιησαντο** *epoiēsanto* uczynili [[G4160]] WTV-AMI-3P **κοπετον** *kopeton* bicie się w piersi – lament [[G2870]] [[N-ASM]] **μεγαν** *megan* wielki [[G3173]] WTA-ASM **επ** *ep* nad [[G1909]] [[PREP]] **αυτω** *autō* nim [[G846]] WTP-DSM
###### **Dz 8,3**
 **σαυλος** *saulos* Saul – [zapytał] [[G4569]] [[N-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **ελυμαινετο** *elymaineto* tępił – niszczył [[G3075]] WTV-INI-3S **την** *tēn* [[G3588]] WTT-ASF **εκκλησιαν** *ekklēsian* zgromadzenie – (społeczność) wywołanych [[G1577]] WTN-ASF **κατα** *kata* po [[G2596]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **οικους** *oikous* domach [[G3624]] [[N-APM]] **εισπορευομενος** *eisporeuomenos* wchodząc [[G1531]] WTV-PNP-NSM **συρων** *syrōn* ciągnąc [[G4951]] [[V-PAP-NSM]] **τε** *te* zarówno – także [[G5037]] WTPRT **ανδρας** *andras* mężów [[G435]] [[N-APM]] **και** *kai* i [[G2532]] [[CONJ]] **γυναικας** *gynaikas* kobiety [[G1135]] WTN-APF **παρεδιδου** *paredidou* przekazywał [[G3860]] WTV-IAI-3S **εις** *eis* do [[G1519]] [[PREP]] **φυλακην** *fylakēn* strażnicy – więzienia [[G5438]] WTN-ASF
###### **Dz 8,4**
 **οι** *hoi* (Ci) [[G3588]] WTT-NPM **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **ουν** *oun* więc [[G3767]] [[CONJ]] **διασπαρεντες** *diasparentes* którzy zostali rozproszeni [[G1289]] WTV-2APP-NPM **διηλθον** *diēlthon* przyszedł (przyszli) [[G1330]] WTV-2AAI-3S **ευαγγελιζομενοι** *euangelizomenoi* głosząc dobrą nowinę [[G2097]] WTV-PMP-NPM **τον** *ton* [[G3588]] [[T-ASM]] **λογον** *logon* Słowo [[G3056]] [[N-ASM]]
###### **Dz 8,5**
 **φιλιππος** *filippos* Filip – [miłujący konie] [[G5376]] [[N-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **κατελθων** *katelthōn* zszedłszy – zstąpiwszy [[G2718]] WTV-2AAP-NSM **εις** *eis* do [[G1519]] [[PREP]] **πολιν** *polin* miasta [[G4172]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **σαμαρειας** *samareias* Samarii – [zachować] [[G4540]] [[N-GSF]] **εκηρυσσεν** *ekēryssen* ogłaszał [[G2784]] WTV-IAI-3S **αυτοις** *autois* im [[G846]] WTP-DPM **τον** *ton* [[G3588]] [[T-ASM]] **χριστον** *christon* Pomazańca [[G5547]] [[N-ASM]]
###### **Dz 8,6**
 **προσειχον** *proseichon* Zważały – Zwracały uwagę [[G4337]] WTV-IAI-3P **τε** *te* zarówno – także [[G5037]] WTPRT **οι** *hoi* [[G3588]] WTT-NPM **οχλοι** *ochloi* tłumy [[G3793]] WTN-NPM **τοις** *tois* [[G3588]] WTT-DPN **λεγομενοις** *legomenois* co jest mówione [[G3004]] WTV-PPP-DPN **υπο** *hypo* przez [[G5259]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **φιλιππου** *filippou* Filipa – [miłujący konie] [[G5376]] [[N-GSM]] **ομοθυμαδον** *homothymadon* jednomyślnie – jednogłośnie [[G3661]] [[ADV]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **ακουειν** *akouein* słuchać [[G191]] WTV-PAN **αυτους** *autous* oni [[G846]] [[P-APM]] **και** *kai* i [[G2532]] [[CONJ]] **βλεπειν** *blepein* widzieć [[G991]] WTV-PAN **τα** *ta* [[G3588]] WTT-APN **σημεια** *sēmeia* znaki [[G4592]] WTN-APN **α** *ha* które [[G3739]] WTR-APN **εποιει** *epoiei* czynił [[G4160]] WTV-IAI-3S
###### **Dz 8,7**
 **πολλων** *pollōn* Liczni – Wielu [[G4183]] WTA-GPM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **των** *tōn* (z) [[G3588]] WTT-GPM **εχοντων** *echontōn* mających [[G2192]] WTV-PAP-GPM **πνευματα** *pneumata* duchy [[G4151]] WTN-APN **ακαθαρτα** *akatharta* nieczyste [[G169]] WTA-APN **βοωντα** *boōnta* wołające [[G994]] WTV-PAP-NPN **μεγαλη** *megalē* wielkim [[G3173]] WTA-DSF **φωνη** *fōnē* głosem [[G5456]] [[N-DSF]] **εξηρχετο** *eksērcheto* wychodził (wychodziły) [[G1831]] WTV-INI-3S **πολλοι** *polloi* liczni – wielu [[G4183]] WTA-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **παραλελυμενοι** *paralelymenoi* którzy są sparaliżowani – którzy są osłabieni [[G3886]] WTV-RPP-NPM **και** *kai* i [[G2532]] [[CONJ]] **χωλοι** *chōloi* kulawi – chromi [[G5560]] WTA-NPM **εθεραπευθησαν** *etherapeuthēsan* zostali uleczeni [[G2323]] WTV-API-3P
###### **Dz 8,8**
 **και** *kai* I [[G2532]] [[CONJ]] **εγενετο** *egeneto* stała się [[G1096]] WTV-2ADI-3S **χαρα** *chara* radość [[G5479]] [[N-NSF]] **μεγαλη** *megalē* wielka [[G3173]] WTA-NSF **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **πολει** *polei* mieście [[G4172]] [[N-DSF]] **εκεινη** *ekeinē* tym [[G1565]] WTD-DSF
###### **Dz 8,9**
 **ανηρ** *anēr* Mąż [[G435]] [[N-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **τις** *tis* pewien – jakiś [[G5100]] WTX-NSM **ονοματι** *onomati* imieniem [[G3686]] WTN-DSN **σιμων** *simōn* Szymon – [słyszeć] [[G4613]] [[N-NSM]] **προυπηρχεν** *proupērchen* był wcześniej [[G4391]] WTV-IAI-3S **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **πολει** *polei* mieście [[G4172]] [[N-DSF]] **μαγευων** *mageuōn* praktykujący magię – uprawiający czary [[G3096]] [[V-PAP-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **εξιστων** *eksistōn* zdumiewający – oszałamiający [[G1839]] [[V-PAP-NSM]] **το** *to* [[G3588]] WTT-ASN **εθνος** *ethnos* naród [[G1484]] WTN-ASN **της** *tēs* [[G3588]] [[T-GSF]] **σαμαρειας** *samareias* Samarii – [zachować] [[G4540]] [[N-GSF]] **λεγων** *legōn* mówiąc [[G3004]] [[V-PAP-NSM]] **ειναι** *einai* (że) być [[G1511]] WTV-PXN **τινα** *tina* kimś [[G5100]] WTX-ASM **εαυτον** *heauton* on sam [[G1438]] WTF-3ASM **μεγαν** *megan* wielkim [[G3173]] WTA-ASM
###### **Dz 8,10**
 **ω** *hō* (na) którego [[G3739]] WTR-DSM **προσειχον** *proseichon* zważali – zwracali uwagę [[G4337]] WTV-IAI-3P **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **απο** *apo* od [[G575]] [[PREP]] **μικρου** *mikrou* małego [[G3398]] WTA-GSM **εως** *heōs* aż do [[G2193]] [[CONJ]] **μεγαλου** *megalou* wielkiego [[G3173]] WTA-GSM **λεγοντες** *legontes* mówiąc [[G3004]] WTV-PAP-NPM **ουτος** *houtos* ten [[G3778]] WTD-NSM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **η** *hē* [[G3588]] [[T-NSF]] **δυναμις** *dynamis* moc [[G1411]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **η** *hē* [[G3588]] [[T-NSF]] **μεγαλη** *megalē* wielka [[G3173]] WTA-NSF
###### **Dz 8,11**
 **προσειχον** *proseichon* Zważali – Zwracali uwagę [[G4337]] WTV-IAI-3P **δε** *de* zaś [[G1161]] [[CONJ]] **αυτω** *autō* (na) niego [[G846]] WTP-DSM **δια** *dia* z powodu [[G1223]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **ικανω** *hikanō* dość duży [[G2425]] WTA-DSM **χρονω** *chronō* czas [[G5550]] WTN-DSM **ταις** *tais* [[G3588]] WTT-DPF **μαγειαις** *mageiais* praktykowaniem magii – uprawianiem czarów [[G3095]] WTN-DPF **εξεστακεναι** *eksestakenai* zdumiewać – dziwić się [[G1839]] WTV-RAN **αυτους** *autous* ich [[G846]] [[P-APM]]
###### **Dz 8,12**
 **οτε** *hote* Gdy [[G3753]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **επιστευσαν** *episteusan* uwierzyli [[G4100]] WTV-AAI-3P **τω** *tō* [[G3588]] WTT-DSM **φιλιππω** *filippō* Filipowi – [miłujący konie] [[G5376]] WTN-DSM **ευαγγελιζομενω** *euangelizomenō* głoszącemu dobrą nowinę [[G2097]] WTV-PMP-DSM **τα** *ta* [[G3588]] WTT-APN **περι** *peri* o [[G4012]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **βασιλειας** *basileias* Królestwie [[G932]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **του** *tou* [[G3588]] WTT-GSN **ονοματος** *onomatos* imieniu [[G3686]] [[N-GSN]] **του** *tou* [[G3588]] WTT-GSM **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **εβαπτιζοντο** *ebaptizonto* byli zanurzani [[G907]] WTV-IPI-3P **ανδρες** *andres* mężowie [[G435]] WTN-NPM **τε** *te* zarówno – także [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **γυναικες** *gynaikes* kobiety [[G1135]] [[N-NPF]]
###### **Dz 8,13**
 **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **σιμων** *simōn* Szymon – [słyszeć] [[G4613]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **αυτος** *autos* on [[G846]] WTP-NSM **επιστευσεν** *episteusen* uwierzył [[G4100]] [[V-AAI-3S]] **και** *kai* i [[G2532]] [[CONJ]] **βαπτισθεις** *baptistheis* zostawszy zanurzonym [[G907]] WTV-APP-NSM **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **προσκαρτερων** *proskarterōn* trwającym niezłomnie [[G4342]] [[V-PAP-NSM]] **τω** *tō* (przy) [[G3588]] WTT-DSM **φιλιππω** *filippō* Filipie – [miłujący konie] [[G5376]] WTN-DSM **θεωρων** *theōrōn* oglądając – widząc [[G2334]] [[V-PAP-NSM]] **τε** *te* zarówno – także [[G5037]] WTPRT **δυναμεις** *dynameis* moce [[G1411]] WTN-APF **και** *kai* i [[G2532]] [[CONJ]] **σημεια** *sēmeia* znaki [[G4592]] WTN-APN **γινομενα** *ginomena* stające się [[G1096]] WTV-PNP-APN **εξιστατο** *eksistato* był zdumiony – był zdziwiony [[G1839]] WTV-IMI-3S
###### **Dz 8,14**
 **ακουσαντες** *akousantes* Usłyszawszy [[G191]] WTV-AAP-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **εν** *en* w [[G1722]] [[PREP]] **ιεροσολυμοις** *ierosolymois* Jerozolimie – [dziedzictwo pokoju] [[G2414]] WTN-DPN **αποστολοι** *apostoloi* wysłannicy [[G652]] WTN-NPM **οτι** *hoti* że [[G3754]] [[CONJ]] **δεδεκται** *dedektai* przyjęła [[G1209]] WTV-RNI-3S **η** *hē* [[G3588]] [[T-NSF]] **σαμαρεια** *samareia* Samaria – [zachować] [[G4540]] [[N-NSF]] **τον** *ton* [[G3588]] [[T-ASM]] **λογον** *logon* Słowo [[G3056]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **απεστειλαν** *apesteilan* wysłali [[G649]] WTV-AAI-3P **προς** *pros* do [[G4314]] [[PREP]] **αυτους** *autous* nich [[G846]] [[P-APM]] **τον** *ton* [[G3588]] [[T-ASM]] **πετρον** *petron* Piotra – [kamyk] [[G4074]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **ιωαννην** *iōannēn* Jana – [JHWH jest łaskawy] [[G2491]] [[N-ASM]]
###### **Dz 8,15**
 **οιτινες** *hoitines* którzy [[G3748]] WTR-NPM **καταβαντες** *katabantes* zszedłszy – zstąpiwszy [[G2597]] WTV-2AAP-NPM **προσηυξαντο** *prosēuksanto* modlili się [[G4336]] WTV-ADI-3P **περι** *peri* o [[G4012]] [[PREP]] **αυτων** *autōn* nich [[G846]] WTP-GPM **οπως** *hopōs* żeby [[G3704]] [[ADV]] **λαβωσιν** *labōsin* otrzymaliby – wzięliby [[G2983]] WTV-2AAS-3P **πνευμα** *pneuma* Ducha [[G4151]] WTN-ASN **αγιον** *hagion* Świętego [[G40]] WTA-ASN
###### **Dz 8,16**
 **ουπω** *oupō* Jeszcze nie [[G3768]] [[ADV]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **επ** *ep* na [[G1909]] [[PREP]] **ουδενι** *oudeni* nikogo [[G3762]] WTA-DSM **αυτων** *autōn* (z) nich [[G846]] WTP-GPM **επιπεπτωκος** *epipeptōkos* spadający [[G1968]] WTV-RAP-NSN **μονον** *monon* jedynie – tylko [[G3440]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **βεβαπτισμενοι** *bebaptismenoi* którzy są zanurzeni [[G907]] WTV-RPP-NPM **υπηρχον** *hypērchon* byli [[G5225]] WTV-IAI-3P **εις** *eis* w [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **ονομα** *onoma* imię [[G3686]] WTN-ASN **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]]
###### **Dz 8,17**
 **τοτε** *tote* Wtedy [[G5119]] [[ADV]] **επετιθουν** *epetithoun* nałożyli [[G2007]] WTV-IAI-3P **τας** *tas* [[G3588]] WTT-APF **χειρας** *cheiras* ręce [[G5495]] WTN-APF **επ** *ep* na [[G1909]] [[PREP]] **αυτους** *autous* nich [[G846]] [[P-APM]] **και** *kai* i [[G2532]] [[CONJ]] **ελαμβανον** *elambanon* otrzymywali [[G2983]] WTV-IAI-3P **πνευμα** *pneuma* Ducha [[G4151]] WTN-ASN **αγιον** *hagion* Świętego [[G40]] WTA-ASN
###### **Dz 8,18**
 **θεασαμενος** *theasamenos* Zobaczywszy [[G2300]] WTV-ADP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **σιμων** *simōn* Szymon – [słyszeć] [[G4613]] [[N-NSM]] **οτι** *hoti* że [[G3754]] [[CONJ]] **δια** *dia* przez [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **επιθεσεως** *epitheseōs* nałożenie – włożenie [[G1936]] [[N-GSF]] **των** *tōn* [[G3588]] WTT-GPF **χειρων** *cheirōn* rąk [[G5495]] WTN-GPF **των** *tōn* [[G3588]] WTT-GPM **αποστολων** *apostolōn* wysłanników [[G652]] WTN-GPM **διδοται** *didotai* jest dawany [[G1325]] WTV-PPI-3S **το** *to* [[G3588]] WTT-ASN **πνευμα** *pneuma* Duch [[G4151]] WTN-ASN **το** *to* [[G3588]] WTT-ASN **αγιον** *hagion* Święty [[G40]] WTA-ASN **προσηνεγκεν** *prosēnegken* przyniósł [[G4374]] [[V-AAI-3S]] **αυτοις** *autois* im [[G846]] WTP-DPM **χρηματα** *chrēmata* pieniądze – bogactwa [[G5536]] WTN-APN
###### **Dz 8,19**
 **λεγων** *legōn* mówiąc [[G3004]] [[V-PAP-NSM]] **δοτε** *dote* dajcie [[G1325]] WTV-2AAM-2P **καμοι** *kamoi* i mnie [[G2504]] WTP-1DS-C **την** *tēn* [[G3588]] WTT-ASF **εξουσιαν** *eksousian* władzę [[G1849]] WTN-ASF **ταυτην** *tautēn* tę [[G3778]] WTD-ASF **ινα** *hina* aby [[G2443]] [[CONJ]] **ω** *hō* któremu [[G3739]] WTR-DSM **εαν** *ean* jeśli [[G1437]] WTCOND **επιθω** *epithō* nałożyłbym [[G2007]] WTV-2AAS-1S **τας** *tas* [[G3588]] WTT-APF **χειρας** *cheiras* ręce [[G5495]] WTN-APF **λαμβανη** *lambanē* otrzymałby – wziąłby [[G2983]] WTV-PAS-3S **πνευμα** *pneuma* Ducha [[G4151]] WTN-ASN **αγιον** *hagion* Świętego [[G40]] WTA-ASN
###### **Dz 8,20**
 **πετρος** *petros* Piotr – [kamyk] [[G4074]] [[N-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **προς** *pros* do [[G4314]] [[PREP]] **αυτον** *auton* niego [[G846]] WTP-ASM **το** *to* [[G3588]] WTT-NSN **αργυριον** *argyrion* srebro [[G694]] WTN-NSN **σου** *sou* twoje [[G4675]] WTP-2GS **συν** *syn* razem z [[G4862]] [[PREP]] **σοι** *soi* tobą [[G4671]] WTP-2DS **ειη** *eiē* oby jest [[G1498]] WTV-PXO-3S **εις** *eis* ku [[G1519]] [[PREP]] **απωλειαν** *apōleian* zgubie – zatraceniu [[G684]] WTN-ASF **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **δωρεαν** *dōrean* dar – darowiznę [[G1431]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ενομισας** *enomisas* wnioskowałeś – sądziłeś [[G3543]] WTV-AAI-2S **δια** *dia* przez [[G1223]] [[PREP]] **χρηματων** *chrēmatōn* pieniądze [[G5536]] WTN-GPN **κτασθαι** *ktasthai* nabywać – posiadać [[G2932]] WTV-PNN
###### **Dz 8,21**
 **ουκ** *ouk* Nie [[G3756]] [[PRT-N]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **σοι** *soi* ci [[G4671]] WTP-2DS **μερις** *meris* część – udział [[G3310]] [[N-NSF]] **ουδε** *oude* ani [[G3761]] [[ADV]] **κληρος** *klēros* dziedzictwo – los [[G2819]] [[N-NSM]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **λογω** *logō* słowie [[G3056]] WTN-DSM **τουτω** *toutō* tym [[G5129]] WTD-DSM **η** *hē* [[G3588]] [[T-NSF]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **καρδια** *kardia* serce [[G2588]] [[N-NSF]] **σου** *sou* twoje [[G4675]] WTP-2GS **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ευθεια** *eutheia* proste [[G2117]] WTA-NSF **ενωπιον** *enōpion* wobec – przed [[G1799]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **Dz 8,22**
 **μετανοησον** *metanoēson* Opamiętaj się – Zmień myślenie [[G3340]] WTV-AAM-2S **ουν** *oun* więc [[G3767]] [[CONJ]] **απο** *apo* od [[G575]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **κακιας** *kakias* złości – niegodziwości [[G2549]] [[N-GSF]] **σου** *sou* twojej [[G4675]] WTP-2GS **ταυτης** *tautēs* tej [[G3778]] WTD-GSF **και** *kai* i [[G2532]] [[CONJ]] **δεηθητι** *deēthēti* poproś [[G1189]] WTV-AOM-2S **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ει** *ei* czy [[G1487]] WTCOND **αρα** *ara* zatem – w związku z tym [[G686]] WTPRT **αφεθησεται** *afethēsetai* zostanie odpuszczony [[G863]] WTV-FPI-3S **σοι** *soi* ci [[G4671]] WTP-2DS **η** *hē* [[G3588]] [[T-NSF]] **επινοια** *epinoia* zamiar – zamysł [[G1963]] [[N-NSF]] **της** *tēs* [[G3588]] [[T-GSF]] **καρδιας** *kardias* serca [[G2588]] [[N-GSF]] **σου** *sou* twojego [[G4675]] WTP-2GS
###### **Dz 8,23**
 **εις** *eis* Ku [[G1519]] [[PREP]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **χολην** *cholēn* żółci [[G5521]] WTN-ASF **πικριας** *pikrias* goryczy – gorzkości [[G4088]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **συνδεσμον** *syndesmon* związaniu [[G4886]] [[N-ASM]] **αδικιας** *adikias* niesprawiedliwości – bezprawia [[G93]] [[N-GSF]] **ορω** *horō* widzę [[G3708]] WTV-PAI-1S **σε** *se* cię [[G4571]] WTP-2AS **οντα** *onta* będącego [[G5607]] WTV-PXP-ASM
###### **Dz 8,24**
 **αποκριθεις** *apokritheis* Odpowiedziawszy [[G611]] WTV-AOP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **σιμων** *simōn* Szymon – [słyszeć] [[G4613]] [[N-NSM]] **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **δεηθητε** *deēthēte* poproście [[G1189]] WTV-AOM-2P **υμεις** *hymeis* wy [[G5210]] WTP-2NP **υπερ** *hyper* za [[G5228]] [[PREP]] **εμου** *emou* mnie [[G1700]] WTP-1GS **προς** *pros* do [[G4314]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **κυριον** *kyrion* Pana [[G2962]] [[N-ASM]] **οπως** *hopōs* żeby [[G3704]] [[ADV]] **μηδεν** *mēden* nic [[G3367]] WTA-NSN **επελθη** *epelthē* przyszłoby [[G1904]] WTV-2AAS-3S **επ** *ep* na [[G1909]] [[PREP]] **εμε** *eme* mnie [[G1691]] WTP-1AS **ων** *hōn* co [[G3739]] WTR-GPN **ειρηκατε** *eirēkate* powiedzieliście [[G2046]] WTV-RAI-2P-ATT
###### **Dz 8,25**
 **οι** *hoi* (Ci) [[G3588]] WTT-NPM **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **ουν** *oun* więc [[G3767]] [[CONJ]] **διαμαρτυραμενοι** *diamartyramenoi* zaświadczywszy – oświadczywszy [[G1263]] WTV-ADP-NPM **και** *kai* i [[G2532]] [[CONJ]] **λαλησαντες** *lalēsantes* powiedziawszy [[G2980]] WTV-AAP-NPM **τον** *ton* [[G3588]] [[T-ASM]] **λογον** *logon* Słowo [[G3056]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **υπεστρεψαν** *hypestrepsan* wracali [[G5290]] WTV-AAI-3P **εις** *eis* do [[G1519]] [[PREP]] **ιερουσαλημ** *ierousalēm* Jeruzalem – [dziedzictwo pokoju] [[G2419]] [[N-PRI]] **πολλας** *pollas* wielu [[G4183]] WTA-APF **τε** *te* zarówno – także [[G5037]] WTPRT **κωμας** *kōmas* wioskom – miasteczkom [[G2968]] WTN-APF **των** *tōn* [[G3588]] WTT-GPM **σαμαρειτων** *samareitōn* Samarytańskim – [zachować] [[G4541]] WTN-GPM **ευηγγελισαντο** *euēngelisanto* ogłosili dobrą nowinę [[G2097]] WTV-AMI-3P
###### **Dz 8,26**
 **αγγελος** *angelos* Zwiastun [[G32]] [[N-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ελαλησεν** *elalēsen* powiedział [[G2980]] [[V-AAI-3S]] **προς** *pros* do [[G4314]] [[PREP]] **φιλιππον** *filippon* Filipa – [miłujący konie] [[G5376]] [[N-ASM]] **λεγων** *legōn* mówiąc [[G3004]] [[V-PAP-NSM]] **αναστηθι** *anastēthi* powstań [[G450]] WTV-2AAM-2S **και** *kai* i [[G2532]] [[CONJ]] **πορευου** *poreuou* idź [[G4198]] WTV-PNM-2S **κατα** *kata* na [[G2596]] [[PREP]] **μεσημβριαν** *mesēmbrian* południe [[G3314]] WTN-ASF **επι** *epi* do [[G1909]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **οδον** *hodon* drogi [[G3598]] WTN-ASF **την** *tēn* [[G3588]] WTT-ASF **καταβαινουσαν** *katabainousan* schodzącej – zstępującej [[G2597]] WTV-PAP-ASF **απο** *apo* od [[G575]] [[PREP]] **ιερουσαλημ** *ierousalēm* Jeruzalem – [dziedzictwo pokoju] [[G2419]] [[N-PRI]] **εις** *eis* ku [[G1519]] [[PREP]] **γαζαν** *gazan* Gazie – [silny] [[G1048]] WTN-ASF **αυτη** *hautē* ta [[G3778]] WTD-NSF **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ερημος** *erēmos* pusta [[G2048]] WTA-NSF
###### **Dz 8,27**
 **και** *kai* I [[G2532]] [[CONJ]] **αναστας** *anastas* wstawszy – podniósłszy się [[G450]] WTV-2AAP-NSM **επορευθη** *eporeuthē* poszedł [[G4198]] [[V-AOI-3S]] **και** *kai* i [[G2532]] [[CONJ]] **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **ανηρ** *anēr* mąż [[G435]] [[N-NSM]] **αιθιοψ** *aithiops* Etiopczyk [[G128]] [[N-NSM]] **ευνουχος** *eunouchos* eunuch – trzebieniec [[G2135]] [[N-NSM]] **δυναστης** *dynastēs* władca – możny [[G1413]] [[N-NSM]] **κανδακης** *kandakēs* Kandaki [[G2582]] [[N-GSF]] **της** *tēs* [[G3588]] [[T-GSF]] **βασιλισσης** *basilissēs* królowej [[G938]] [[N-GSF]] **αιθιοπων** *aithiopōn* Etiopczyków [[G128]] WTN-GPM **ος** *hos* który [[G3739]] WTR-NSM **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **επι** *epi* nad [[G1909]] [[PREP]] **πασης** *pasēs* całym [[G3956]] WTA-GSF **της** *tēs* [[G3588]] [[T-GSF]] **γαζης** *gazēs* skarbem [[G1047]] [[N-GSF]] **αυτης** *autēs* jej [[G846]] [[P-GSF]] **ος** *hos* który [[G3739]] WTR-NSM **εληλυθει** *elēlythei* przyszedł [[G2064]] WTV-LAI-3S **προσκυνησων** *proskynēsōn* mając zamiar oddać cześć – mając zamiar pokłonić się [[G4352]] WTV-FAP-NSM **εις** *eis* w [[G1519]] [[PREP]] **ιερουσαλημ** *ierousalēm* Jeruzalem – [dziedzictwo pokoju] [[G2419]] [[N-PRI]]
###### **Dz 8,28**
 **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **τε** *te* zarówno – także [[G5037]] WTPRT **υποστρεφων** *hypostrefōn* wracający [[G5290]] [[V-PAP-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **καθημενος** *kathēmenos* siedzący [[G2521]] WTV-PNP-NSM **επι** *epi* na [[G1909]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **αρματος** *harmatos* rydwanie – wozie [[G716]] [[N-GSN]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **ανεγινωσκεν** *aneginōsken* czytał [[G314]] WTV-IAI-3S **τον** *ton* [[G3588]] [[T-ASM]] **προφητην** *profētēn* proroka [[G4396]] [[N-ASM]] **ησαιαν** *ēsaian* Izajasza – [JH zbawia] [[G2268]] [[N-ASM]]
###### **Dz 8,29**
 **ειπεν** *eipen* Powiedział [[G2036]] WTV-2AAI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **πνευμα** *pneuma* Duch [[G4151]] WTN-NSN **τω** *tō* [[G3588]] WTT-DSM **φιλιππω** *filippō* Filipowi – [miłujący konie] [[G5376]] WTN-DSM **προσελθε** *proselthe* podejdź – zbliż się [[G4334]] WTV-2AAM-2S **και** *kai* i [[G2532]] [[CONJ]] **κολληθητι** *kollēthēti* zostań przyłączony [[G2853]] WTV-APM-2S **τω** *tō* (do) [[G3588]] WTT-DSN **αρματι** *harmati* rydwanu – wozu [[G716]] WTN-DSN **τουτω** *toutō* tego [[G5129]] WTD-DSN
###### **Dz 8,30**
 **προσδραμων** *prosdramōn* Podbiegłszy [[G4370]] WTV-2AAP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **φιλιππος** *filippos* Filip – [miłujący konie] [[G5376]] [[N-NSM]] **ηκουσεν** *ēkousen* usłyszał [[G191]] [[V-AAI-3S]] **αυτου** *autou* go [[G846]] [[P-GSM]] **αναγινωσκοντος** *anaginōskontos* czytającego [[G314]] WTV-PAP-GSM **τον** *ton* [[G3588]] [[T-ASM]] **προφητην** *profētēn* proroka [[G4396]] [[N-ASM]] **ησαιαν** *ēsaian* Izajasza – [JH zbawia] [[G2268]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **αρα** *ara* zatem – mianowicie [[G687]] WTPRT-I **γε** *ge* rzeczywiście – prawdziwie [[G1065]] WTPRT **γινωσκεις** *ginōskeis* wiesz – znasz [[G1097]] WTV-PAI-2S **α** *ha* co [[G3739]] WTR-APN **αναγινωσκεις** *anaginōskeis* czytasz – odczytujesz [[G314]] WTV-PAI-2S
###### **Dz 8,31**
 **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **πως** *pōs* jak- [[G4459]] [[ADV]]-I **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **αν** *an* kolwiek [[G302]] WTPRT **δυναιμην** *dynaimēn* oby mogę [[G1410]] WTV-PNO-1S **εαν** *ean* jeśli [[G1437]] WTCOND **μη** *mē* nie [[G3361]] [[PRT-N]] **τις** *tis* ktoś [[G5100]] WTX-NSM **οδηγηση** *odēgēsē* poprowadziłby [[G3594]] WTV-AAS-3S **με** *me* mnie [[G3165]] WTP-1AS **παρεκαλεσεν** *parekalesen* zaprosił [[G3870]] [[V-AAI-3S]] **τε** *te* zarówno – także [[G5037]] WTPRT **τον** *ton* [[G3588]] [[T-ASM]] **φιλιππον** *filippon* Filipa – [miłujący konie] [[G5376]] [[N-ASM]] **αναβαντα** *anabanta* (żeby) wszedłszy – (żeby) wstąpiwszy [[G305]] WTV-2AAP-ASM **καθισαι** *kathisai* usiąść [[G2523]] [[V-AAN]] **συν** *syn* razem z [[G4862]] [[PREP]] **αυτω** *autō* nim [[G846]] WTP-DSM
###### **Dz 8,32**
 **η** *hē* [[G3588]] [[T-NSF]] **δε** *de* zaś [[G1161]] [[CONJ]] **περιοχη** *periochē* urywek – fragment [[G4042]] [[N-NSF]] **της** *tēs* [[G3588]] [[T-GSF]] **γραφης** *grafēs* Pisma [[G1124]] [[N-GSF]] **ην** *hēn* który [[G3739]] WTR-ASF **ανεγινωσκεν** *aneginōsken* czytał [[G314]] WTV-IAI-3S **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **αυτη** *hautē* ten [[G3778]] WTD-NSF **ως** *hōs* jak [[G5613]] [[ADV]] **προβατον** *probaton* owca [[G4263]] WTN-NSN **επι** *epi* na [[G1909]] [[PREP]] **σφαγην** *sfagēn* rzeź – zabicie [[G4967]] WTN-ASF **ηχθη** *ēchthē* był prowadzony [[G71]] [[V-API-3S]] **και** *kai* i [[G2532]] [[CONJ]] **ως** *hōs* jak [[G5613]] [[ADV]] **αμνος** *amnos* baranek [[G286]] [[N-NSM]] **εναντιον** *enantion* wobec [[G1726]] [[ADV]] **του** *tou* (tego) [[G3588]] WTT-GSM **κειροντος** *keirontos* który strzyże [[G2751]] WTV-PAP-GSM **αυτον** *auton* Go [[G846]] WTP-ASM **αφωνος** *afōnos* niemy – bez głosu [[G880]] [[A-NSM]] **ουτως** *houtōs* tak [[G3779]] [[ADV]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ανοιγει** *anoigei* otwiera [[G455]] WTV-PAI-3S **το** *to* [[G3588]] WTT-ASN **στομα** *stoma* ust [[G4750]] WTN-ASN **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Dz 8,33**
 **εν** *en* W [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **ταπεινωσει** *tapeinōsei* uniżeniu – poniżeniu [[G5014]] [[N-DSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **η** *hē* [[G3588]] [[T-NSF]] **κρισις** *krisis* sąd [[G2920]] [[N-NSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ηρθη** *ērthē* został podniesiony [[G142]] [[V-API-3S]] **την** *tēn* [[G3588]] WTT-ASF **δε** *de* zaś [[G1161]] [[CONJ]] **γενεαν** *genean* pokolenie [[G1074]] WTN-ASF **αυτου** *autou* Jego [[G846]] [[P-GSM]] **τις** *tis* kto [[G5101]] WTI-NSM **διηγησεται** *diēgēsetai* opowie – opisze [[G1334]] WTV-FDI-3S **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **αιρεται** *airetai* jest zabierane – jest usuwane [[G142]] WTV-PPI-3S **απο** *apo* z [[G575]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]] **η** *hē* [[G3588]] [[T-NSF]] **ζωη** *zōē* życie [[G2222]] [[N-NSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Dz 8,34**
 **αποκριθεις** *apokritheis* Odpowiedziawszy [[G611]] WTV-AOP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **ευνουχος** *eunouchos* eunuch – trzebieniec [[G2135]] [[N-NSM]] **τω** *tō* [[G3588]] WTT-DSM **φιλιππω** *filippō* Filipowi – [miłujący konie] [[G5376]] WTN-DSM **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **δεομαι** *deomai* proszę [[G1189]] WTV-PNI-1S **σου** *sou* cię [[G4675]] WTP-2GS **περι** *peri* o [[G4012]] [[PREP]] **τινος** *tinos* kim [[G5101]] WTI-GSM **ο** *ho* [[G3588]] [[T-NSM]] **προφητης** *profētēs* prorok [[G4396]] [[N-NSM]] **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **τουτο** *touto* to [[G5124]] WTD-ASN **περι** *peri* o [[G4012]] [[PREP]] **εαυτου** *heautou* sobie samym [[G1438]] WTF-3GSM **η** *ē* lub [[G2228]] WTPRT **περι** *peri* o [[G4012]] [[PREP]] **ετερου** *heterou* innym [[G2087]] WTA-GSM **τινος** *tinos* kimś [[G5100]] WTX-GSM
###### **Dz 8,35**
 **ανοιξας** *anoiksas* Otworzywszy [[G455]] WTV-AAP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **φιλιππος** *filippos* Filip – [miłujący konie] [[G5376]] [[N-NSM]] **το** *to* [[G3588]] WTT-ASN **στομα** *stoma* usta [[G4750]] WTN-ASN **αυτου** *autou* jego [[G846]] [[P-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **αρξαμενος** *arksamenos* zacząwszy [[G756]] WTV-AMP-NSM **απο** *apo* od [[G575]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **γραφης** *grafēs* Pisma [[G1124]] [[N-GSF]] **ταυτης** *tautēs* tego [[G3778]] WTD-GSF **ευηγγελισατο** *euēngelisato* ogłosił dobrą nowinę [[G2097]] WTV-AMI-3S **αυτω** *autō* mu [[G846]] WTP-DSM **τον** *ton* (o) [[G3588]] [[T-ASM]] **ιησουν** *iēsoun* Jezusie – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]]
###### **Dz 8,36**
 **ως** *hōs* Jak [[G5613]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **επορευοντο** *eporeuonto* jechali – podróżowali [[G4198]] WTV-INI-3P **κατα** *kata* po [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **οδον** *hodon* drodze [[G3598]] WTN-ASF **ηλθον** *ēlthon* przyszli [[G2064]] WTV-2AAI-3P **επι** *epi* do [[G1909]] [[PREP]] **τι** *ti* jakiejś – pewnej [[G5100]] WTX-ASN **υδωρ** *hydōr* wody [[G5204]] WTN-ASN **και** *kai* i [[G2532]] [[CONJ]] **φησιν** *fēsin* mówi [[G5346]] WTV-PXI-3S **ο** *ho* [[G3588]] [[T-NSM]] **ευνουχος** *eunouchos* eunuch – trzebieniec [[G2135]] [[N-NSM]] **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **υδωρ** *hydōr* woda [[G5204]] WTN-NSN **τι** *ti* co [[G5101]] WTI-NSN **κωλυει** *kōlyei* zabrania – przeszkadza [[G2967]] WTV-PAI-3S **με** *me* mi [[G3165]] WTP-1AS **βαπτισθηναι** *baptisthēnai* zostać zanurzonym [[G907]] WTV-APN
###### **Dz 8,37**
 **ειπεν** *eipen* Powiedział [[G2036]] WTV-2AAI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **φιλιππος** *filippos* Filip – [miłujący konie] [[G5376]] [[N-NSM]] **ει** *ei* jeśli [[G1487]] WTCOND **πιστευεις** *pisteueis* wierzysz [[G4100]] WTV-PAI-2S **εξ** *eks* z [[G1537]] [[PREP]] **ολης** *holēs* całego [[G3650]] WTA-GSF **της** *tēs* [[G3588]] [[T-GSF]] **καρδιας** *kardias* serca [[G2588]] [[N-GSF]] **εξεστιν** *eksestin* wolno – jest dozwolone [[G1832]] WTV-PQI-3S **αποκριθεις** *apokritheis* odpowiedziawszy [[G611]] WTV-AOP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **πιστευω** *pisteuō* wierzę [[G4100]] WTV-PAI-1S **τον** *ton* [[G3588]] [[T-ASM]] **υιον** *hyion* Synem [[G5207]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ειναι** *einai* być [[G1511]] WTV-PXN **τον** *ton* [[G3588]] [[T-ASM]] **ιησουν** *iēsoun* Jezus – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]] **χριστον** *christon* Pomazaniec [[G5547]] [[N-ASM]]
###### **Dz 8,38**
 **και** *kai* I [[G2532]] [[CONJ]] **εκελευσεν** *ekeleusen* rozkazał [[G2753]] [[V-AAI-3S]] **στηναι** *stēnai* stanąć [[G2476]] [[V-2AAN]] **το** *to* [[G3588]] WTT-ASN **αρμα** *harma* rydwan – wóz [[G716]] WTN-ASN **και** *kai* i [[G2532]] [[CONJ]] **κατεβησαν** *katebēsan* zeszli – zstąpili [[G2597]] WTV-2AAI-3P **αμφοτεροι** *amfoteroi* oboje [[G297]] WTA-NPM **εις** *eis* do [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **υδωρ** *hydōr* wody [[G5204]] WTN-ASN **ο** *ho* [[G3588]] [[T-NSM]] **τε** *te* zarówno – także [[G5037]] WTPRT **φιλιππος** *filippos* Filip – [miłujący konie] [[G5376]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **ευνουχος** *eunouchos* eunuch – trzebieniec [[G2135]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **εβαπτισεν** *ebaptisen* zanurzył [[G907]] [[V-AAI-3S]] **αυτον** *auton* go [[G846]] WTP-ASM
###### **Dz 8,39**
 **οτε** *hote* Gdy [[G3753]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **ανεβησαν** *anebēsan* weszli – wstąpili [[G305]] WTV-2AAI-3P **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **υδατος** *hydatos* wody [[G5204]] [[N-GSN]] **πνευμα** *pneuma* Duch [[G4151]] WTN-NSN **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ηρπασεν** *hērpasen* porwał [[G726]] [[V-AAI-3S]] **τον** *ton* [[G3588]] [[T-ASM]] **φιλιππον** *filippon* Filipa – [miłujący konie] [[G5376]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ειδεν** *eiden* zobaczył [[G1492]] WTV-2AAI-3S **αυτον** *auton* go [[G846]] WTP-ASM **ουκετι** *ouketi* już dłużej nie [[G3765]] [[ADV]] **ο** *ho* [[G3588]] [[T-NSM]] **ευνουχος** *eunouchos* eunuch – trzebieniec [[G2135]] [[N-NSM]] **επορευετο** *eporeueto* jechał – podróżował [[G4198]] WTV-INI-3S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **οδον** *hodon* drogą [[G3598]] WTN-ASF **αυτου** *autou* jego [[G846]] [[P-GSM]] **χαιρων** *chairōn* radując się – ciesząc się [[G5463]] [[V-PAP-NSM]]
###### **Dz 8,40**
 **φιλιππος** *filippos* Filip – [miłujący konie] [[G5376]] [[N-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **ευρεθη** *heurethē* został znaleziony [[G2147]] [[V-API-3S]] **εις** *eis* w [[G1519]] [[PREP]] **αζωτον** *azōton* Azocie [[G108]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **διερχομενος** *dierchomenos* przechodząc [[G1330]] WTV-PNP-NSM **ευηγγελιζετο** *euēngelizeto* głosił dobrą nowinę [[G2097]] WTV-IMI-3S **τας** *tas* [[G3588]] WTT-APF **πολεις** *poleis* miastom [[G4172]] WTN-APF **πασας** *pasas* wszystkim [[G3956]] WTA-APF **εως** *heōs* aż do [[G2193]] [[CONJ]] **του** *tou* [[G3588]] WTT-GSM **ελθειν** *elthein* przyjść [[G2064]] [[V-2AAN]] **αυτον** *auton* on [[G846]] WTP-ASM **εις** *eis* ku [[G1519]] [[PREP]] **καισαρειαν** *kaisareian* Cezarei [[G2542]] WTN-ASF
