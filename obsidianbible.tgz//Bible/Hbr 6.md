# Hbr 6 BT5
###### **Hbr 6,1**
 Dlatego, pominąwszy podstawowe nauki o Chrystusie, przenieśmy się do tego, co doskonałe, nie kładąc ponownie fundamentu, jaki stanowią: pokuta za uczynki martwe i [wyznanie] wiary w Boga,
###### **Hbr 6,2**
 nauka o chrztach i nakładaniu rąk, o powstaniu z martwych i sądzie wiecznym.
###### **Hbr 6,3**
 A i to uczynimy, jeśli Bóg pozwoli.
###### **Hbr 6,4**
  Nie można bowiem tych – którzy raz zostali oświeceni, a nawet zakosztowali daru niebieskiego i stali się współuczestnikami Ducha Świętego,
###### **Hbr 6,5**
 zakosztowali również wspaniałości słowa Bożego i mocy przyszłego wieku,
###### **Hbr 6,6**
 a [jednak] odpadli – odnowić ku nawróceniu. Krzyżują bowiem w sobie Syna Bożego i wystawiają Go na pośmiewisko.
###### **Hbr 6,7**
 Ziemia zaś, która pije deszcz często na nią spadający i rodzi użyteczne rośliny dla tych, co ją uprawiają, otrzymuje błogosławieństwo od Boga.
###### **Hbr 6,8**
 A ta, która rodzi ciernie i osty, jest nieużyte-czna i bliska przekleństwa, kresem zaś jej spalenie.
###### **Hbr 6,9**
 Ale chociaż tak mówimy, to jednak po was, najmilsi, spodziewamy się czegoś lepszego i bliskiego zbawienia.
###### **Hbr 6,10**
 Nie jest bowiem Bóg niesprawiedliwy, aby zapomniał o czynie waszym i miłości, którą okazaliście dla imienia Jego, gdy usługiwaliście świętym i jeszcze usługujecie.
###### **Hbr 6,11**
 Pragniemy zaś, by każdy z was okazywał tę samą gorliwość w doskonaleniu nadziei aż do końca,
###### **Hbr 6,12**
 abyście nie stali się ospałymi, ale naśladowali tych, którzy przez wiarę i cierpliwość stają się dziedzicami obietnic.
###### **Hbr 6,13**
 Albowiem gdy Bóg Abrahamowi uczynił obietnicę, nie mając nikogo większego, na kogo mógłby przysiąc, poprzysiągł na samego siebie,
###### **Hbr 6,14**
 mówiąc: Zaiste, hojnie cię po-błogosławię i ponad miarę rozmnożę.
###### **Hbr 6,15**
 A ponieważ [Abraham] tak cierpliwie oczekiwał, otrzymał to, co było obiecane.
###### **Hbr 6,16**
 Ludzie przysięgają na kogoś wyższego, a przysięga dla stwierdzenia [prawdy] jest zakończeniem każdego sporu między nimi.
###### **Hbr 6,17**
 Dlatego Bóg, pragnąc okazać dziedzicom obietnicy ponad wszelką miarę niezmienność swego postanowienia, wzmocnił je przysięgą,
###### **Hbr 6,18**
 abyśmy przez dwie rzeczy niezmienne, co do których niemożliwe jest, by skłamał Bóg, mieli trwałą pociechę, my, którzyśmy się uciekli do uchwycenia zaofiarowanej nadziei.
###### **Hbr 6,19**
 Trzymajmy się jej jak bezpiecznej i silnej dla duszy kotwicy, która przenika poza zasłonę,
###### **Hbr 6,20**
 gdzie Jezus jako poprzednik wszedł za nas, stawszy się arcykapłanem na wieki na wzór Melchizedeka.
# Hbr 6 PAU
###### **Hbr 6,1**
 Zostawmy jednak podstawy nauki o Chrystusie i przejdźmy do spraw dojrzałości. Nie kładźmy ponownie fundamentu, którym jest: odwrócenie się od martwych uczynków, wiara w Boga,
###### **Hbr 6,2**
 nauka o obmyciach, nakładaniu rąk, powstaniu z martwych i sądzie wiecznym.
###### **Hbr 6,3**
 Tak właśnie uczynimy, jeśli Bóg pozwoli!
###### **Hbr 6,4**
 Ci bowiem, którzy raz otrzymali światło, zakosztowali daru nieba, stali się uczestnikami Ducha Świętego
###### **Hbr 6,5**
 i zakosztowali dobrego słowa Boga oraz przejawów mocy przyszłego wieku,
###### **Hbr 6,6**
 a mimo to odpadli, nie są w stanie sami się nawrócić! Krzyżują oni w sobie na nowo Syna Bożego i wystawiają na szyderstwo.
###### **Hbr 6,7**
 Gdy ziemia pije obficie spadający na nią deszcz i rodzi rośliny pożyteczne dla tych, którzy je uprawiają, otrzymuje błogosławieństwo od Boga.
###### **Hbr 6,8**
 Jeśli zaś wydaje ciernie i osty, jest bez wartości i bliska przekleństwa, a w końcu będzie spalona.
###### **Hbr 6,9**
 Jednak co do was, umiłowani, choć tak mówimy, jesteśmy przekonani, że czeka was lepszy los - zbawienie.
###### **Hbr 6,10**
 Bóg przecież nie może być niesprawiedliwy, by miał zapomnieć o waszym trudzie i miłości, jaką okazaliście Jego imieniu, gdy usługiwaliście świętym i nadal służycie.
###### **Hbr 6,11**
 Pragniemy jednak, aby każdy z was nadal wykazywał taką gorliwość, aż do całkowitego spełnienia się nadziei!
###### **Hbr 6,12**
 Nie bądźcie ociężali, lecz naśladujcie tych, którzy przez wiarę i cierpliwość stają się dziedzicami obietnic.
###### **Hbr 6,13**
 Kiedy Bóg dawał obietnicę Abrahamowi, to ponieważ nie mógł złożyć przysięgi na kogoś większego, przysiągł na samego siebie:
###### **Hbr 6,14**
 Będę cię obficie błogosławił i niezmiernie cię rozmnożę.
###### **Hbr 6,15**
 I tak dzięki cierpliwości Abraham uzyskał obietnicę.
###### **Hbr 6,16**
 Otóż ludzie przysięgają na kogoś większego, a zakończenie każdego sporu wzmacniają przysięgą.
###### **Hbr 6,17**
 W tym sensie Bóg, chcąc dobitnie ukazać dziedzicom obietnicy niezmienność swej decyzji, zagwarantował ją przysięgą.
###### **Hbr 6,18**
 Przez te dwa niezmienne akty - a niemożliwe, żeby Bóg skłamał - otrzymaliśmy silną zachętę, aby uciec się do Niego, chwytając się rzuconej nam nadziei.
###### **Hbr 6,19**
 Jest ona jakby niezawodną i mocną kotwicą dla duszy, przenikającą poza wewnętrzną zasłonę.
###### **Hbr 6,20**
 Tam właśnie dotarł przed nami Jezus, stając się najwyższym kapłanem na wieki na wzór Melchizedeka.
# Hbr 6 BP
###### **Hbr 6,1**
 Stąd też, pomijając podstawy nauki o Chrystusie, przystąpmy do spraw poważniejszych, byśmy nie zakładali od nowa fundamentu, [którym jest] zerwanie z uczynkami martwymi, wiara w Boga,
###### **Hbr 6,2**
 nauka dotycząca obmyć, wkładania rąk, zmartwychwstania umarłych czy sądu wiecznego.
###### **Hbr 6,3**
 Przystąpmy zatem z Bożą pomocą do tego dzieła.
###### **Hbr 6,4**
 Otóż niemożliwe jest, aby ci, którzy raz zostali oświeceni, zakosztowali daru niebieskiego, stali się uczestnikami Ducha Świętego
###### **Hbr 6,5**
 i zakosztowali dobrego słowa Bożego oraz przejawów mocy przyszłego wieku,
###### **Hbr 6,6**
 a mimo to odpadli - ponownie się nawrócili. Oni dla siebie znów ukrzyżowali i zelżyli Syna Bożego.
###### **Hbr 6,7**
 Przecież ziemia, która wchłania często padający deszcz i wydaje roślinność użyteczną dla tych, co ją uprawiają, uczestniczy w błogosławieństwie Bożym.
###### **Hbr 6,8**
 Ta zaś, która "przynosi ciernie i osty", jest nieużyteczna i grozi jej przekleństwo, a losem jej wypalenie [przez słońce].
###### **Hbr 6,9**
 O was, umiłowani, chociaż tak mówimy, mamy jednak lepsze mniemanie, które pozwala ufać w wasze zbawienie.
###### **Hbr 6,10**
 Bóg nie jest bowiem niesprawiedliwy i nie zapomni o dziełach waszej miłości, jaką okazywaliście, gdy ze względu na Niego wspomagaliście i nadal wspomagacie świętych.
###### **Hbr 6,11**
 Pragniemy zaś, żeby każdy z was do końca troskliwie zabiegał o coraz doskonalszą nadzieję.
###### **Hbr 6,12**
 Żebyście nie stawali się opieszali, lecz naśladowali tych, którzy dla swej wiary i wielkoduszności odziedziczyli obietnice.
###### **Hbr 6,13**
 Kiedy bowiem Bóg dawał obietnice Abrahamowi, nie widząc nikogo większego od siebie, na kogo mógłby przysiąc, "przysięgał na samego siebie",
###### **Hbr 6,14**
 mówiąc: "Zaprawdę, obficie cię ubłogosławię i niepomiernie rozmnożę".
###### **Hbr 6,15**
 Tak więc wytrwawszy w cierpliwości [Abraham] otrzymał obietnicę.
###### **Hbr 6,16**
 Ludzie przecież przysięgają na kogoś wyższego i przysięga stanowi dla nich ostateczne potwierdzenie w każdej spornej sprawie.
###### **Hbr 6,17**
 Kiedy więc Bóg chciał okazać dziedzicom obietnicy, że Jego postanowienie jest trwałe, sam stał się poręczycielem przysięgi,
###### **Hbr 6,18**
 abyśmy dzięki tym dwom niezmiennym wydarzeniom, w których Bóg nie może kłamać, uciekając się do Niego mieli niezachwianą pewność, że umocnimy się w danej nam nadziei.
###### **Hbr 6,19**
 Jest ona dla nas jakby duchową kotwicą niezawodną i pewną, a sięgającą do wnętrza, "poza zasłonę",
###### **Hbr 6,20**
 dokąd, poprzedzając nas, wszedł Jezus, który stał się "na podobieństwo Melchizedecha" arcykapłanem "na wieki".
# Hbr 6 BR
###### **Hbr 6,1**
 Dlatego przejdźmy już od owych pierwszych założeń nauki Chrystusa do tego, co bardziej doskonałe, nie wracając więcej do rzeczy tak podstawowych, jak konieczność porzucenia martwych uczynków, składanie wyznania wiary w Boga,
###### **Hbr 6,2**
 wskazania dotyczące obmyć i wkładania rąk, nauka o zmartwychwstaniu zmarłych i o sądzie wiecznym.
###### **Hbr 6,3**
 [Tak więc do dzieła!] Jeśli Bóg pozwoli, dokonamy również i tych rzeczy bardziej wzniosłych.
###### **Hbr 6,4**
 Jeśli bowiem ktoś już raz otrzymał światło wiary, poznał wartość darów niebieskich, znalazł się w szczególnej jedności z Duchem Świętym, rozsmakował się we wspaniałości słowa Bożego
###### **Hbr 6,5**
 i doświadczył sam cudownych przejawów mocy Bożej znamiennej dla czasów przyszłego życia,
###### **Hbr 6,6**
 a potem taki człowiek mimo wszystko odpadnie od wiary, to jest wprost niemożliwe sprowadzić go ponownie na drogę [prawdziwego] życia, gdyż dokonało się w nim jakby drugie ukrzyżowanie i wystawienie na urągowisko Syna Bożego.
###### **Hbr 6,7**
 A ziemia, która wchłania deszcz obficie na nią spadający i rodzi rośliny pożyteczne dla człowieka, co ją uprawia, otrzymuje błogosławieństwo Boże.
###### **Hbr 6,8**
 Lecz kiedy wydaje tylko ciernie i osty, nie przedstawia żadnej wartości; grozi jej rychłe przekleństwo Boże i całkowita zagłada.
###### **Hbr 6,9**
 Ale chociaż tak mówimy, najmilsi, to przecież spodziewamy się po was czegoś zgoła lepszego: jesteśmy przekonani, że osiągniecie zbawienie.
###### **Hbr 6,10**
 Nie można bowiem nawet przypuszczać, żeby Bóg był niesprawiedliwy; żeby mógł nie pamiętać o dziełach waszej miłości, której dawaliście liczne dowody dla Jego imienia, usługując i kiedyś, i teraz jeszcze Jego świętym.
###### **Hbr 6,11**
 Tak bardzo pragniemy, aby nikt z was nie osłabł w gorliwości, ale by każdy trwał w niezachwianej nadziei aż do końca;
###### **Hbr 6,12**
 żebyście, zamiast popadać w ospałość, wiernie naśladowali tych, którzy przez swoją wiarę i cierpliwość otrzymują dziedzictwo obietnic Bożych.
###### **Hbr 6,13**
 Bóg zaś, gdy dawał obietnicę Abrahamowi i nie miał nic większego, na co mógłby przysiąc, poprzysiągł na siebie samego
###### **Hbr 6,14**
 mówiąc: Zaprawdę pobłogosławię cię hojnie i ponad miarę rozmnożę.
###### **Hbr 6,15**
 [Abraham zaś], ponieważ tak cierpliwie oczekiwał [na spełnienie się obietnicy], otrzymał to, co było mu obiecane.
###### **Hbr 6,16**
 Człowiek składając przysięgę odwołuje się zwykle do istoty wyższej od siebie, a przysięga gwarantująca prawdziwość jakiegoś twierdzenia kończy zazwyczaj spory, jakie zdarzają się między ludźmi.
###### **Hbr 6,17**
 Dlatego Bóg, pragnąc wykazać że to, co ludziom obiecał, jest absolutnie nieodwołalne, umacnia swoje obietnice przysięgą.
###### **Hbr 6,18**
 Otóż te dwa akty Boże [obietnica i przysięga], nieodwołalne i wykluczające jakąkolwiek możliwość rozminięcia się Boga z prawdą, powinny być dla nas źródłem prawdziwego pokrzepienia, o ile tylko trwać będziemy niezachwianie przy zaofiarowanej nam przez Boga nadziei.
###### **Hbr 6,19**
 Nadzieja ta jest dla naszej duszy niczym silna i absolutnie pewna kotwica, która sięga poza zasłonę świątyni -
###### **Hbr 6,20**
 aż tam, gdzie Jezus, przygotowując nam drogę, wszedł za nas stawszy się 'arcykapłanem na wieki' na wzór Melchizedeka.
# Hbr 6 WUJ
###### **Hbr 6,1**
 Przeto zaniechawszy mowy poczynania Chrystusowego, miejmy się do doskonalszych rzeczy: nie znowu zakładając gruntu pokuty od uczynków martwych, i wiary ku Bogu,
###### **Hbr 6,2**
 Nauki chrzczenia, rąk też wkładania, i powstania z martwych, i sądu wiekuistego.
###### **Hbr 6,3**
 I to uczynimy jeśli Bóg dopuści.
###### **Hbr 6,4**
 Abowiem nie podobna jest, aby ci, którzy raz są oświeceni, skosztowali też daru niebieskiego, i uczestniki się stali Ducha świętego.
###### **Hbr 6,5**
 Skosztowali nie mniej dobrego słowa Bożego, i mocy przyszłego wieku,
###### **Hbr 6,6**
 A upadli: aby zaś byli odnowieni ku pokucie, znowu krzyżujący sami sobie syna Bożego, i na pośmiewisko mający.
###### **Hbr 6,7**
 Bo ziemia, która deszcz często na się padający pije, i rodzi ziele użyteczne tym, przez które bywa sprawowana, bierze błogosławieństwo od Boga.
###### **Hbr 6,8**
 Lecz która rodzi ciernie i osty, odrzucona jest, i blizka przeklęctwa, której koniec na spalenie.
###### **Hbr 6,9**
 Ale tuszymy tobie o was coś lepszego namilejszy i zbawienia bliższego, chociaż tak mówimy.
###### **Hbr 6,10**
 Abowiem nie jest niesprawiedliwy Bóg, aby zapamiętał roboty waszej, i miłości, którąście okazali w imię jego, którzyście posługowali świętym i posługujecie.
###### **Hbr 6,11**
 A żądamy, aby każdy z was toż staranie okazał ku wypełnieniu nadzieje aż do końca:
###### **Hbr 6,12**
 Abyście się nie stali gnuśnymi, ale naśladowcami tych, którzy przez wiarę i cierpliwość odziedziczą obietnice.
###### **Hbr 6,13**
 Abowiem Bóg obiecawszy Abrahamowi, iż nie miał nikogo, przez któregoby przysiągł więtszego, przysiągł przez samego siebie,
###### **Hbr 6,14**
 Mówiąc: Jeśli niebłogosławiąc błogosławić cię będę, i rozmnażając nie rozmnożę cię.
###### **Hbr 6,15**
 A tak długo cierpliwie czekawszy, dostał obietnice.
###### **Hbr 6,16**
 Abowiem ludzie przez więtszego niż sami przysięgają: a każdego sporu ich koniec ku potwierdzeniu, jest przysięga.
###### **Hbr 6,17**
 Wczem chcąc Bóg dziedzicom obietnice obficiej okazać nieodmienność rady swej, przysięgę uczynił:
###### **Hbr 6,18**
 Abyśmy przez dwie rzeczy nieodmienne, w których być nie może, żeby Bóg kłamał namocniejszą pociechę mieli, którzyśmy się ku odzierżeniu wystawionej nadzieje uciekli,
###### **Hbr 6,19**
 Którą mamy jako kotficę dusze bezpieczną i mocną, i wchodzącą aż we wnętrzności zasłony,
###### **Hbr 6,20**
 Gdzie przewodnik za nas wszedł Jezus, według porządku Melchisedechowego, Nawyższym kapłanem stawszy się na wieki.
# Hbr 6 STERN
###### **Hbr 6,1**
 Dlatego zostawiając za sobą początkowe nauki o Mesjaszu, przejdźmy ku dojrzałości, nie kładąc ponownie fundamentu o odwróceniu się od czynów prowadzących ku śmierci, zaufaniu Bogu
###### **Hbr 6,2**
 oraz pouczeń o obmyciach, s'misze, powstaniu z martwych i karze wiecznej.
###### **Hbr 6,3**
 A jeśli Bóg da, uczynimy to.
###### **Hbr 6,4**
 Bo gdy ludzie już raz zostali oświeceni, skosztowali daru niebieskiego, stali się uczestnikami Ruach Ha-Kodesz
###### **Hbr 6,5**
 i skosztowali dobroci Słowa Bożego oraz mocy 'olam haba -
###### **Hbr 6,6**
 i wtedy odpadli - niemożliwe jest takie ich odnowienie, aby odwrócili się od swych grzechów, dopóki sami wciąż raz po raz uśmiercają Syna Bożego na palu i wciąż wystawiają Go na pośmiewisko.
###### **Hbr 6,7**
 Bo ziemia, która chłonie częste opady, a potem wydaje plon przydatny właścicielom, otrzymuje błogosławieństwo od Boga,
###### **Hbr 6,8**
 jeśli jednak ciągle rodzi ciernie i osty, to nie przechodzi pomyślnie próby i bliska jest bycia przeklętą; koniec końców zostanie spalona.
###### **Hbr 6,9**
 A mimo że w ten sposób mówimy, drodzy przyjaciele, to jesteśmy przekonani, że wy posiadacie te lepsze rzeczy, które towarzyszą wyzwoleniu.
###### **Hbr 6,10**
 Bóg bowiem nie jest tak niesprawiedliwy, żeby miał zapomnieć o waszym trudzie i miłości, jaką Mu okazaliście w swej dotychczasowej służbie Jego ludowi, a także w waszej służbie obecnie.
###### **Hbr 6,11**
 Chcemy jednakże, aby każdy z was wytrwale wykazywał tę samą pilność aż do samego końca, kiedy nasza nadzieja się urzeczywistni;
###### **Hbr 6,12**
 abyście nie otępieli, ale byście byli naśladowcami tych, którzy przez swą ufność i cierpliwość otrzymują to, co obiecano.
###### **Hbr 6,13**
 Bo gdy Bóg dał obietnicę Awrahamowi, złożył przysięgę, że uczyni, co obiecał; a ponieważ nie było nikogo większego od Niego, na kogo mógłby przysiąc, to przysiągł na samego siebie
###### **Hbr 6,14**
 i rzekł: "Z pewnością pobłogosławię cię i z pewnością dam ci wielu potomków".
###### **Hbr 6,15**
 I tak, czekając cierpliwie, Awraham ujrzał wypełnienie obietnicy.
###### **Hbr 6,16**
 A ludzie przysięgają na kogoś większego od siebie, potwierdzenie zaś przysięgą kładzie kres wszelkim sporom.
###### **Hbr 6,17**
 Dlatego kiedy Bóg chciał jeszcze bardziej przekonująco wykazać niezmienność swych zamiarów wobec tych, którzy mieli otrzymać to, co obiecał, do obietnicy dodał przysięgę,
###### **Hbr 6,18**
 abyśmy przez dwie rzeczy niezmienne, z których w żadnej nie może Bóg skłamać, my, którzyśmy umknęli, aby uchwycić się mocno nadziei nam ukazanej, doznali mocnego pokrzepienia.
###### **Hbr 6,19**
 Mamy tę nadzieję jako pewną i bezpieczną dla nas kotwicę, nadzieję, która przenika wprost ku temu, co znajduje się za parochetem,
###### **Hbr 6,20**
 gdzie w naszym imieniu wstąpił jako nasz poprzednik Jeszua, który stał się kohenem gadolem na wieki, aby Go przyrównywano do Malki-Cedeka.
# Hbr 6 TRO
###### **Hbr 6,1**
 **διο** *dio* Dlatego [[G1352]] [[CONJ]] **αφεντες** *afentes* opuściwszy [[G863]] WTV-2AAP-NPM **τον** *ton* [[G3588]] [[T-ASM]] **της** *tēs* (te na) [[G3588]] [[T-GSF]] **αρχης** *archēs* początku [[G746]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **λογον** *logon* słowo [[G3056]] [[N-ASM]] **επι** *epi* do [[G1909]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **τελειοτητα** *teleiotēta* doskonałości – dojrzałości [[G5047]] WTN-ASF **φερωμεθα** *ferōmetha* bylibyśmy przyniesieni [[G5342]] WTV-PPS-1P **μη** *mē* nie [[G3361]] [[PRT-N]] **παλιν** *palin* znów [[G3825]] [[ADV]] **θεμελιον** *themelion* fundament [[G2310]] [[N-ASM]] **καταβαλλομενοι** *kataballomenoi* kładąc sobie [[G2598]] WTV-PMP-NPM **μετανοιας** *metanoias* nawrócenia – zmiany myślenia [[G3341]] [[N-GSF]] **απο** *apo* od [[G575]] [[PREP]] **νεκρων** *nekrōn* martwych [[G3498]] WTA-GPN **εργων** *ergōn* dzieł – uczynków [[G2041]] WTN-GPN **και** *kai* i [[G2532]] [[CONJ]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **επι** *epi* w [[G1909]] [[PREP]] **θεον** *theon* Boga [[G2316]] [[N-ASM]]
###### **Hbr 6,2**
 **βαπτισμων** *baptismōn* (o) zanurzeniach – (o) obmywaniach [[G909]] WTN-GPM **διδαχης** *didachēs* naukę – nauczanie [[G1322]] [[N-GSF]] **επιθεσεως** *epitheseōs* (o) nałożeniu – (o) włożeniu [[G1936]] [[N-GSF]] **τε** *te* zarówno – także [[G5037]] WTPRT **χειρων** *cheirōn* rąk [[G5495]] WTN-GPF **αναστασεως** *anastaseōs* (o) powstaniu – (o) wzbudzeniu [[G386]] [[N-GSF]] **τε** *te* zarówno – także [[G5037]] WTPRT **νεκρων** *nekrōn* martwych [[G3498]] WTA-GPM **και** *kai* i [[G2532]] [[CONJ]] **κριματος** *krimatos* (o) sądzie – (o) wyroku [[G2917]] [[N-GSN]] **αιωνιου** *aiōniou* wiecznym [[G166]] [[A-GSN]]
###### **Hbr 6,3**
 **και** *kai* i [[G2532]] [[CONJ]] **τουτο** *touto* to [[G5124]] WTD-ASN **ποιησομεν** *poiēsomen* uczynimy [[G4160]] WTV-FAI-1P **εανπερ** *eanper* jeśli [[G1437]] WTCOND **επιτρεπη** *epitrepē* pozwoliłby [[G2010]] WTV-PAS-3S **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]]
###### **Hbr 6,4**
 **αδυνατον** *adynaton* Niemożliwe [[G102]] WTA-NSN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **τους** *tous* (by) [[G3588]] WTT-APM **απαξ** *hapaks* raz [[G530]] [[ADV]] **φωτισθεντας** *fōtisthentas* którzy zostali oświeceni [[G5461]] WTV-APP-APM **γευσαμενους** *geusamenous* którzy skosztowali – którzy zasmakowali [[G1089]] WTV-ADP-APM **τε** *te* zarówno – także [[G5037]] WTPRT **της** *tēs* [[G3588]] [[T-GSF]] **δωρεας** *dōreas* daru – darowizny [[G1431]] [[N-GSF]] **της** *tēs* [[G3588]] [[T-GSF]] **επουρανιου** *epouraniou* niebiańskiego [[G2032]] WTA-GSF **και** *kai* i [[G2532]] [[CONJ]] **μετοχους** *metochous* uczestnicy – towarzysze [[G3353]] WTA-APM **γενηθεντας** *genēthentas* którzy stali się [[G1096]] WTV-AOP-APM **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **αγιου** *hagiou* Świętego [[G40]] [[A-GSN]]
###### **Hbr 6,5**
 **και** *kai* i [[G2532]] [[CONJ]] **καλον** *kalon* dobrą – piękną [[G2570]] WTA-ASN **γευσαμενους** *geusamenous* skosztowawszy – zasmakowawszy [[G1089]] WTV-ADP-APM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ρημα** *rēma* wypowiedź [[G4487]] WTN-ASN **δυναμεις** *dynameis* mocy [[G1411]] WTN-APF **τε** *te* zarówno – także [[G5037]] WTPRT **μελλοντος** *mellontos* mającego przyjść – mającego nastąpić [[G3195]] WTV-PAP-GSM **αιωνος** *aiōnos* wieku [[G165]] [[N-GSM]]
###### **Hbr 6,6**
 **και** *kai* a [[G2532]] [[CONJ]] **παραπεσοντας** *parapesontas* odpadłszy mimo to – upadłszy mimo to [[G3895]] WTV-2AAP-APM **παλιν** *palin* znów [[G3825]] [[ADV]] **ανακαινιζειν** *anakainizein* odnawiać – przywrócić [[G340]] WTV-PAN **εις** *eis* ku [[G1519]] [[PREP]] **μετανοιαν** *metanoian* nawróceniu – zmianie myślenia [[G3341]] WTN-ASF **ανασταυρουντας** *anastaurountas* znowu krzyżujących – ponownie krzyżujących [[G388]] WTV-PAP-APM **εαυτοις** *heautois* (dla) siebie samych [[G1438]] WTF-3DPM **τον** *ton* [[G3588]] [[T-ASM]] **υιον** *hyion* Syna [[G5207]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **παραδειγματιζοντας** *paradeigmatizontas* wystawiających na pokaz – wystawiających na widok publiczny [[G3856]] WTV-PAP-APM
###### **Hbr 6,7**
 **γη** *gē* Ziemia [[G1093]] [[N-NSF]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **πιουσα** *piousa* wypiwszy [[G4095]] WTV-2AAP-NSF **τον** *ton* (ten) [[G3588]] [[T-ASM]] **επ** *ep* na [[G1909]] [[PREP]] **αυτης** *autēs* nią [[G846]] [[P-GSF]] **πολλακις** *pollakis* wielokrotnie – częstokroć [[G4178]] [[ADV]] **ερχομενον** *erchomenon* przychodzący [[G2064]] WTV-PNP-ASM **υετον** *hyeton* deszcz [[G5205]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **τικτουσα** *tiktousa* rodząca [[G5088]] [[V-PAP-NSF]] **βοτανην** *botanēn* ziele – roślinność [[G1008]] WTN-ASF **ευθετον** *eutheton* odpowiednie – użyteczne [[G2111]] WTA-ASF **εκεινοις** *ekeinois* tamtym [[G1565]] WTD-DPM **δι** *di* dla [[G1223]] [[PREP]] **ους** *hous* których [[G3739]] WTR-APM **και** *kai* i [[G2532]] [[CONJ]] **γεωργειται** *geōrgeitai* jest uprawiana – jest użyźniana [[G1090]] WTV-PPI-3S **μεταλαμβανει** *metalambanei* otrzymuje [[G3335]] WTV-PAI-3S **ευλογιας** *eulogias* błogosławienie – wysławienie [[G2129]] [[N-GSF]] **απο** *apo* od [[G575]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **Hbr 6,8**
 **εκφερουσα** *ekferousa* wynosząc – wydobywając [[G1627]] [[V-PAP-NSF]] **δε** *de* zaś [[G1161]] [[CONJ]] **ακανθας** *akanthas* ciernie [[G173]] WTN-APF **και** *kai* i [[G2532]] [[CONJ]] **τριβολους** *tribolous* osty [[G5146]] [[N-APM]] **αδοκιμος** *adokimos* niewypróbowane – zdyskwalifikowane [[G96]] [[A-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **καταρας** *kataras* przekleństwo [[G2671]] [[N-GSF]] **εγγυς** *engys* blisko [[G1451]] [[ADV]] **ης** *hēs* tego [[G3739]] [[R-GSF]] **το** *to* [[G3588]] WTT-NSN **τελος** *telos* koniec [[G5056]] WTN-NSN **εις** *eis* w [[G1519]] [[PREP]] **καυσιν** *kausin* spaleniu [[G2740]] WTN-ASF
###### **Hbr 6,9**
 **πεπεισμεθα** *pepeismetha* Jesteśmy przekonani [[G3982]] WTV-RPI-1P **δε** *de* zaś [[G1161]] [[CONJ]] **περι** *peri* odnośnie [[G4012]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **αγαπητοι** *agapētoi* umiłowani [[G27]] WTA-VPM **τα** *ta* (o) [[G3588]] WTT-APN **κρειττονα** *kreittona* lepszych – znaczniejszych [[G2909]] WTA-APN **και** *kai* i [[G2532]] [[CONJ]] **εχομενα** *echomena* które są nadchodzące [[G2192]] WTV-PPP-APN **σωτηριας** *sōtērias* zbawienie – wyzwolenie [[G4991]] [[N-GSF]] **ει** *ei* jeśli [[G1487]] WTCOND **και** *kai* i [[G2532]] [[CONJ]] **ουτως** *houtōs* tak [[G3779]] [[ADV]] **λαλουμεν** *laloumen* mówimy [[G2980]] WTV-PAI-1P
###### **Hbr 6,10**
 **ου** *ou* nie [[G3756]] [[PRT-N]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **αδικος** *adikos* niesprawiedliwy [[G94]] [[A-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **επιλαθεσθαι** *epilathesthai* (by) zapomnieć [[G1950]] WTV-2ADN **του** *tou* [[G3588]] WTT-GSN **εργου** *ergou* dzieła [[G2041]] [[N-GSN]] **υμων** *hymōn* waszego [[G5216]] WTP-2GP **και** *kai* i [[G2532]] [[CONJ]] **του** *tou* (o) [[G3588]] WTT-GSM **κοπου** *kopou* trudzie [[G2873]] [[N-GSM]] **της** *tēs* [[G3588]] [[T-GSF]] **αγαπης** *agapēs* miłości [[G26]] [[N-GSF]] **ης** *hēs* który [[G3739]] [[R-GSF]] **ενδειξασθε** *endeiksasthe* okazujcie – wykazujcie [[G1731]] WTV-AMM-2P **εις** *eis* w [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **ονομα** *onoma* imieniu [[G3686]] WTN-ASN **αυτου** *autou* Jego [[G846]] [[P-GSM]] **διακονησαντες** *diakonēsantes* usłużywszy [[G1247]] WTV-AAP-NPM **τοις** *tois* [[G3588]] WTT-DPM **αγιοις** *hagiois* świętym [[G40]] WTA-DPM **και** *kai* i [[G2532]] [[CONJ]] **διακονουντες** *diakonountes* służąc [[G1247]] WTV-PAP-NPM
###### **Hbr 6,11**
 **επιθυμουμεν** *epithymoumen* Pragniemy [[G1937]] WTV-PAI-1P **δε** *de* zaś [[G1161]] [[CONJ]] **εκαστον** *hekaston* (by) każdy [[G1538]] WTA-ASM **υμων** *hymōn* (z) was [[G5216]] WTP-2GP **την** *tēn* [[G3588]] WTT-ASF **αυτην** *autēn* tę samą [[G846]] [[P-ASF]] **ενδεικνυσθαι** *endeiknysthai* okazywać – wykazywać [[G1731]] WTV-PMN **σπουδην** *spoudēn* gorliwość – zapał [[G4710]] WTN-ASF **προς** *pros* względem [[G4314]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **πληροφοριαν** *plēroforian* pełni [[G4136]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **ελπιδος** *elpidos* nadziei [[G1680]] [[N-GSF]] **αχρι** *achri* aż do [[G891]] [[PREP]] **τελους** *telous* końca [[G5056]] [[N-GSN]]
###### **Hbr 6,12**
 **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **νωθροι** *nōthroi* ociężali – tępi [[G3576]] WTA-NPM **γενησθε** *genēsthe* stalibyście się [[G1096]] WTV-2ADS-2P **μιμηται** *mimētai* naśladowcy [[G3402]] WTN-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **των** *tōn* (tych) [[G3588]] WTT-GPM **δια** *dia* przez [[G1223]] [[PREP]] **πιστεως** *pisteōs* wiarę [[G4102]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **μακροθυμιας** *makrothymias* cierpliwość – wyrozumiałość [[G3115]] [[N-GSF]] **κληρονομουντων** *klēronomountōn* dziedziczących – dostających w udziale [[G2816]] WTV-PAP-GPM **τας** *tas* [[G3588]] WTT-APF **επαγγελιας** *epangelias* obietnice [[G1860]] WTN-APF
###### **Hbr 6,13**
 **τω** *tō* [[G3588]] WTT-DSM **γαρ** *gar* Bowiem [[G1063]] [[CONJ]] **αβρααμ** *abraam* Abrahamowi – [ojciec wielu narodów] [[G11]] [[N-PRI]] **επαγγειλαμενος** *epangeilamenos* obiecawszy [[G1861]] WTV-ADP-NSM **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **επει** *epei* skoro – jako, że [[G1893]] [[CONJ]] **κατ** *kat* na [[G2596]] [[PREP]] **ουδενος** *oudenos* nikogo [[G3762]] WTA-GSM **ειχεν** *eichen* miał [[G2192]] WTV-IAI-3S **μειζονος** *meizonos* większego [[G3173]] WTA-GSM-C **ομοσαι** *omosai* przysiąc [[G3660]] [[V-AAN]] **ωμοσεν** *ōmosen* przysiągł [[G3660]] [[V-AAI-3S]] **καθ** *kath* na [[G2596]] [[PREP]] **εαυτου** *heautou* siebie samego [[G1438]] WTF-3GSM
###### **Hbr 6,14**
 **λεγων** *legōn* mówiąc [[G3004]] [[V-PAP-NSM]] **η** *hē* czy [[G2229]] WTPRT **μην** *mēn* z pewnością [[G3375]] WTPRT **ευλογων** *eulogōn* błogosławiąc – wysławiając [[G2127]] [[V-PAP-NSM]] **ευλογησω** *eulogēsō* pobłogosławię – wysławię [[G2127]] WTV-FAI-1S **σε** *se* cię [[G4571]] WTP-2AS **και** *kai* i [[G2532]] [[CONJ]] **πληθυνων** *plēthynōn* mnożąc [[G4129]] [[V-PAP-NSM]] **πληθυνω** *plēthynō* rozmnożę [[G4129]] WTV-FAI-1S **σε** *se* cię [[G4571]] WTP-2AS
###### **Hbr 6,15**
 **και** *kai* i [[G2532]] [[CONJ]] **ουτως** *houtōs* tak [[G3779]] [[ADV]] **μακροθυμησας** *makrothymēsas* który stał się cierpliwym – który stał się wyrozumiałym [[G3114]] WTV-AAP-NSM **επετυχεν** *epetychen* osiągnął [[G2013]] WTV-2AAI-3S **της** *tēs* [[G3588]] [[T-GSF]] **επαγγελιας** *epangelias* obietnicę [[G1860]] [[N-GSF]]
###### **Hbr 6,16**
 **ανθρωποι** *anthrōpoi* Ludzie [[G444]] WTN-NPM **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **κατα** *kata* na [[G2596]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **μειζονος** *meizonos* większego [[G3173]] WTA-GSM-C **ομνυουσιν** *omnyousin* przysięgają [[G3660]] WTV-PAI-3P **και** *kai* i [[G2532]] [[CONJ]] **πασης** *pasēs* każdego [[G3956]] WTA-GSF **αυτοις** *autois* (dla) nich [[G846]] WTP-DPM **αντιλογιας** *antilogias* sporu – buntu [[G485]] [[N-GSF]] **περας** *peras* kres [[G4009]] WTN-NSN **εις** *eis* ku [[G1519]] [[PREP]] **βεβαιωσιν** *bebaiōsin* utwierdzeniu – umocnieniu [[G951]] WTN-ASF **ο** *ho* [[G3588]] [[T-NSM]] **ορκος** *horkos* przysięga [[G3727]] [[N-NSM]]
###### **Hbr 6,17**
 **εν** *en* w [[G1722]] [[PREP]] **ω** *hō* tym [[G3739]] WTR-DSM **περισσοτερον** *perissoteron* obficiej [[G4054]] WTA-NSN-C **βουλομενος** *boulomenos* chcąc [[G1014]] WTV-PNP-NSM **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **επιδειξαι** *epideiksai* (by) pokazać [[G1925]] [[V-AAN]] **τοις** *tois* [[G3588]] WTT-DPM **κληρονομοις** *klēronomois* dziedzicom [[G2818]] WTN-DPM **της** *tēs* [[G3588]] [[T-GSF]] **επαγγελιας** *epangelias* obietnicy [[G1860]] [[N-GSF]] **το** *to* [[G3588]] WTT-ASN **αμεταθετον** *ametatheton* niezmienne [[G276]] WTA-ASN **της** *tēs* [[G3588]] [[T-GSF]] **βουλης** *boulēs* postanowienia – rady [[G1012]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **εμεσιτευσεν** *emesiteusen* poręczył – zagwarantował [[G3315]] [[V-AAI-3S]] **ορκω** *horkō* przysięgą [[G3727]] WTN-DSM
###### **Hbr 6,18**
 **ινα** *hina* aby [[G2443]] [[CONJ]] **δια** *dia* przez [[G1223]] [[PREP]] **δυο** *dyo* dwie [[G1417]] WTA-NUI **πραγματων** *pragmatōn* sprawy [[G4229]] WTN-GPN **αμεταθετων** *ametathetōn* niezmienne [[G276]] WTA-GPN **εν** *en* w [[G1722]] [[PREP]] **οις** *hois* których [[G3739]] WTR-DPN **αδυνατον** *adynaton* niemożliwe [[G102]] WTA-NSN **ψευσασθαι** *pseusasthai* (by) skłamać [[G5574]] WTV-ADN **θεον** *theon* Bóg [[G2316]] [[N-ASM]] **ισχυραν** *ischyran* silną – mocną [[G2478]] WTA-ASF **παρακλησιν** *paraklēsin* zachętę [[G3874]] WTN-ASF **εχωμεν** *echōmen* mielibyśmy [[G2192]] WTV-PAS-1P **οι** *hoi* [[G3588]] WTT-NPM **καταφυγοντες** *katafygontes* zbiegłszy – schroniwszy się [[G2703]] WTV-2AAP-NPM **κρατησαι** *kratēsai* (by) chwycić się [[G2902]] [[V-AAN]] **της** *tēs* [[G3588]] [[T-GSF]] **προκειμενης** *prokeimenēs* która jest wyłożona [[G4295]] WTV-PNP-GSF **ελπιδος** *elpidos* nadzieją [[G1680]] [[N-GSF]]
###### **Hbr 6,19**
 **ην** *hēn* którą [[G3739]] WTR-ASF **ως** *hōs* jak [[G5613]] [[ADV]] **αγκυραν** *agkyran* kotwicę [[G45]] WTN-ASF **εχομεν** *echomen* mamy [[G2192]] WTV-PAI-1P **της** *tēs* [[G3588]] [[T-GSF]] **ψυχης** *psychēs* duszy – życia [[G5590]] [[N-GSF]] **ασφαλη** *asfalē* niezawodną [[G804]] WTA-ASF **τε** *te* zarówno – także [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **βεβαιαν** *bebaian* mocną [[G949]] WTA-ASF **και** *kai* i [[G2532]] [[CONJ]] **εισερχομενην** *eiserchomenēn* wchodzącą [[G1525]] WTV-PNP-ASF **εις** *eis* do [[G1519]] [[PREP]] **το** *to* (tej) [[G3588]] WTT-ASN **εσωτερον** *esōteron* bardziej wewnętrznej [[G2082]] WTA-ASN **του** *tou* [[G3588]] WTT-GSN **καταπετασματος** *katapetasmatos* zasłony [[G2665]] [[N-GSN]]
###### **Hbr 6,20**
 **οπου** *hopou* gdzie – dokąd [[G3699]] [[ADV]] **προδρομος** *prodromos* przewodnik – przybiegający wpierw [[G4274]] [[A-NSM]] **υπερ** *hyper* w imieniu [[G5228]] [[PREP]] **ημων** *hēmōn* naszym [[G2257]] WTP-1GP **εισηλθεν** *eisēlthen* wszedł [[G1525]] WTV-2AAI-3S **ιησους** *iēsous* Jezus – [JHWH jest zbawieniem] [[G2424]] [[N-NSM]] **κατα** *kata* według [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **ταξιν** *taksin* porządku [[G5010]] WTN-ASF **μελχισεδεκ** *melchisedek* Melchisedeka – [król sprawiedliwości] [[G3198]] [[N-PRI]] **αρχιερευς** *archiereus* arcykapłan [[G749]] [[N-NSM]] **γενομενος** *genomenos* który stał się [[G1096]] WTV-2ADP-NSM **εις** *eis* na [[G1519]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **αιωνα** *aiōna* wiek [[G165]] [[N-ASM]]
