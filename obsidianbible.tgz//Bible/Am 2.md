# Am 2 BT5
###### **Am 2,1**
 Tak mówi Pan:Z powodu trzech występków Moabui z powodu czterechnie odwrócę tego [wyroku],gdyż on spalił kości króla Edomu na wapno.
###### **Am 2,2**
 Ześlę więc ogień na Moab, i strawi pałace Kerijjotu,zginie Moab podczas wrzawy wojennej, podczas okrzyków, przy dźwięku rogu.
###### **Am 2,3**
 Usunę spośród niego władcę, a razem z nim wszystkich jego książąt wytracę –rzekł Pan.
###### **Am 2,4**
 Tak mówi Pan:Z powodu trzech występków Judyi z powodu czterechnie odwrócę tego [wyroku],gdyż odrzucili Prawo Panai przykazań Jego nie strzegli. Zwiodły ich kłamliwe ich bożki, za którymi poszli ich przodkowie.
###### **Am 2,5**
 Ześlę więc ogień na Judę, i strawi pałace Jeruzalem.
###### **Am 2,6**
 Tak mówi Pan:Z powodu trzech występków Izraelai z powodu czterechnie odwrócę tego [wyroku],gdyż sprzedają za srebro sprawiedliwego, a ubogiego za parę sandałów;
###### **Am 2,7**
 w proch ziemi wdeptują głowy biedaków, i ubogich kierują na bezdroża; ojciec i syn chodzą do tej samej dziewczyny, aby znieważać święte imię moje.
###### **Am 2,8**
 Na płaszczach zastawnych wylegują się przy każdym ołtarzui wino wymuszone grzywną pijąw domu swego Boga.
###### **Am 2,9**
 Ja to przed nimi zgładziłem Amorytów, którzy byli wysocy jak cedry, a mocni jak dęby. I zniszczyłem owoc ich z góry, a z dołu korzenie.
###### **Am 2,10**
 I Ja to wyprowadziłem was z Egiptu, wiodłem przez pustynię przez lat czterdzieści, byście posiedli ziemię Amorytów.
###### **Am 2,11**
 Wzbudzałem wśród waszych synów proroków, a wśród waszych młodzieńców – nazirejczyków. Czyż nie było tak, synowie Izraela? – wyrocznia Pana.
###### **Am 2,12**
 A wy dawaliście pić wino nazirejczykomi prorokom rozkazywaliście: «***Nie prorokujcie!***»
###### **Am 2,13**
 Oto Ja zmiażdżę was tak, jak miażdży wóz napełniony snopami.
###### **Am 2,14**
 Szybkobiegacz nie będzie miał gdzie uciec, mocarz nie okaże swej siły, a bohater nie ocali życia;
###### **Am 2,15**
 łucznik się nie ostoi, szybkonogi nie umkniei jeździec na koniu nie ocali życia;
###### **Am 2,16**
 nawet najmężniejszy z bohaterów będzie wtym dniu nagi uciekał– wyrocznia Pana.
# Am 2 PAU
###### **Am 2,1**
 Tak mówi PAN: Z powodu trzech występków Moabu i z powodu czterech nie odwołam tego wyroku. Ponieważ spalił kości króla Edomu na wapno.
###### **Am 2,2**
 Dlatego ześlę ogień na Moab, by spalił pałace Keriotu. Moab zginie podczas wrzawy wojennej, wśród okrzyków i przy dźwięku rogu.
###### **Am 2,3**
 Zniszczę jego władcę, a wraz z nim zabiję wszystkich jego książąt - powiedział PAN.
###### **Am 2,4**
 Tak mówi PAN: Z powodu trzech występków Judy i z powodu czterech nie odwołam tego wyroku, gdyż odrzucili prawo PANA i nie przestrzegali Jego przykazań. Zwiodły ich własne kłamstwa, za którymi chodzili ich ojcowie.
###### **Am 2,5**
 Ześlę więc ogień na Judę, by spalił pałace Jerozolimy.
###### **Am 2,6**
 Tak mówi PAN: Z powodu trzech występków Izraela i z powodu czterech nie odwołam tego wyroku, gdyż sprzedają sprawiedliwego za srebro, a ubogiego za parę sandałów.
###### **Am 2,7**
 Wdeptują głowy biednych w proch ziemi i drogę ubogich wykrzywiają. Ojciec i syn chodzą do tej samej dziewczyny, znieważając tym moje święte imię.
###### **Am 2,8**
 Na płaszczach danych im w zastaw wylegują się przy każdym ołtarzu i wino wymuszone grzywną piją w domu swojego boga.
###### **Am 2,9**
 To Ja przed nimi zgładziłem Amorytów, wysokich jak cedry i mocnych jak dęby. Od góry zniszczyłem ich owoce, a z dołu ich korzenie.
###### **Am 2,10**
 To Ja wyprowadziłem was z Egiptu, czterdzieści lat prowadziłem przez pustynię, aby dać wam w posiadanie ziemię Amorytów.
###### **Am 2,11**
 I wzbudziłem proroków spośród waszych synów, i nazirejczyków spośród waszych młodzieńców. Czyż nie tak było, Izraelici? - wyrocznia PANA.
###### **Am 2,12**
 A wy poiliście winem nazirejczyków i prorokom zakazywaliście prorokować.
###### **Am 2,13**
 Oto Ja wgniotę was w ziemię, jak gniecie wóz pełen snopów.
###### **Am 2,14**
 Biegacz nie będzie mógł uciec, mocarz nie okaże swojej siły, bohater nie ocali życia,
###### **Am 2,15**
 łucznik się nie ostoi, biegacz nie umknie, jeździec nie ocali życia.
###### **Am 2,16**
 Najmężniejszy z bohaterów będzie w tym dniu uciekał nagi - wyrocznia PANA.
# Am 2 BP
###### **Am 2,1**
 Tak mówi Jahwe: - Dla trzech i dla czterech zbrodni Moabu nie odmienię postanowienia, bo spalili kości króla Edomu na popiół.
###### **Am 2,2**
 Rzucę ogień na Moab, aby strawił pałace Kerijotu; Moab zginie w zamieszaniu, wśród zgiełku, przy odgłosie trąb.
###### **Am 2,3**
 Zgładzę tego, kto nad nim panuje, a wszystkich jego książąt zabiję wraz z nim - mówi Jahwe.
###### **Am 2,4**
 Tak mówi Jahwe: - Dla trzech i dla czterech zbrodni Judy nie odmienię postanowienia, bo odrzucili Prawo Jahwe i nie przestrzegali przykazań Jego, lecz dali się zwieść swym bóstwom fałszywym, którym [już] ich ojcowie hołdowali.
###### **Am 2,5**
 Rzucę ogień na Judę, by strawił pałace Jeruzalem.
###### **Am 2,6**
 Tak mówi Jahwe: - Dla trzech i dla czterech zbrodni Izraela nie zmienię postanowienia, bo sprzedają niewinnego za pieniądze, a biednego za parę obuwia;
###### **Am 2,7**
 depcą po głowie biednych jak po prochu ziemi i usuwają ubogich z drogi; syn i ojciec chodzą do tej samej dziewki, by znieważyć święte Imię moje;
###### **Am 2,8**
 kładą się na szatach, wziętych w zastaw, przy każdym ołtarzu i raczą się winem tych, których skazano na grzywnę, w Domu swego Boga.
###### **Am 2,9**
 A Ja wytępiłem przed wami Amorytów, dorównujących wzrostem cedrom, a mocnych jak dęby; zniszczyłem u góry ich owoce, u dołu zaś ich korzenie.
###### **Am 2,10**
 Wywiodłem was z Egiptu i prowadziłem czterdzieści lat po pustyni, by dać wam w posiadanie ziemię Amorytów.
###### **Am 2,11**
 Powoływałem proroków spośród waszych synów i nazirejczyków spośród waszych młodzieńców. Czyż nie jest tak, synowie Izraela? - mówi Jahwe.
###### **Am 2,12**
 A wyście nazirejczyków częstowali winem, a do proroków zwracaliście się z żądaniem: "Przestańcie prorokować!"
###### **Am 2,13**
 Oto osadzę was na miejscu, jak osiada wóz naładowany snopami.
###### **Am 2,14**
 Wtedy szybkiemu nie uda się ucieczka, mocnemu na nic się nie zda jego siła i nawet bohater nie ocali swego życia;
###### **Am 2,15**
 łucznik się nie utrzyma, szybki biegacz się nie uratuje i nawet jeździec na koniu nie ocali swego życia;
###### **Am 2,16**
 najdzielniejszy nawet z bohaterów uciekać będzie nago tego dnia - mówi Jahwe.
# Am 2 BR
###### **Am 2,1**
 I tak oto mówi Pan: Z powodu trzech występków Moabu i z powodu czterech, nie cofnę tego, co już powiedziałem. Ponieważ Moab w wapno kości króla Edomu przemienił,
###### **Am 2,2**
 ześlę przeto ogień na Moab i strawi pałace Keriotu. I zginie Moab wśród wojennej wrzawy, przy wtórze okrzyków bitewnych i dźwięku rogów.
###### **Am 2,3**
 I zniszczę moabskiego władcę, a wszystkie jego książęta razem z nim pozabijam - tak bowiem Pan rozkazał.
###### **Am 2,4**
 Tak oto mówi Pan: Z powodu trzech występków Judy i z powodu czterech nie cofnę tego, co już powiedziałem. Ponieważ nie słuchaliście pouczeń Pana i nie zachowywaliście praw Jego: ponieważ daliście się sprowadzić na manowce przez fałszywych bogów, za którymi poszli już ojcowie wasi,
###### **Am 2,5**
 ześlę przeto ogień na Judę i strawi pałace Jerozolimy.
###### **Am 2,6**
 Tak mówi Pan: Z powodu trzech występków Izraela i z powodu czterech nie cofnę tego, co już powiedziałem. Sprzedawaliście bowiem za pieniądze niewinnego, a biedaka za parę sandałów,
###### **Am 2,7**
 maluczkiego deptaliście na ziemi słabym zaś odmawialiście racji. Ojciec i syn odwiedzają tę samą kobietę, aby bezcześcić moje święte imię.
###### **Am 2,8**
 Na płaszczach danych w zastaw wylegują się przy każdym ołtarzu, wino kupują za pieniądz wzięty z opłat karnych i w domu swego Boga piją, ile pragną.
###### **Am 2,9**
 Ja byłem tym, co na ich oczach Amorytów wygładził, owych mężów potężnych jak cedry, silnych zaś jak ogromne dęby. Zniszczyłem ich owoce od góry, od dołu zaś wszystkie korzenie.
###### **Am 2,10**
 Ja byłem tym, który was wyprowadził z Egiptu i przez lat czterdzieści byłem z wami na pustyni, po to, byście kraj Amorytów wzięli w posiadanie.
###### **Am 2,11**
 Prorokami uczyniłem niektórych z waszych synów, a nazirejczykami niektórych młodzieńców. Czyż nie jest tak, o Izraela synowie? - wyrocznia Pana.
###### **Am 2,12**
 A wyście nazirejczykom wino pić dawali, prorokom zaś zakazaliście pełnić ich urząd prorocki.
###### **Am 2,13**
 Sprawię więc teraz, że ziemia zachwieje się wam pod stopami, jak chwieje się wóz wypełniony obficie snopami.
###### **Am 2,14**
 A wtedy najbardziej szybcy nie zdołają uciec i najmocniejszi całkiem z sił opadną, i nawet najwaleczniejszy nie zdoła się uratować.
###### **Am 2,15**
 Nie ostoi się także ani jeden łucznik, najszybszym biegaczom nie pomogą nogi, jeźdźca zaś nie zdoła ocalić koń jego.
###### **Am 2,16**
 I najdzielniejsi spośród wojowników nago w dniu owym uciekać będą - wyrocznia Pana.
# Am 2 WUJ
###### **Am 2,1**
 To mówi Pan: Dla trzech złości Moab, i dla czterzech nie nawrócę go: dla tego, że spalił kości króla Idumejskiego aż na popiół.
###### **Am 2,2**
 I puszczę ogień na Moab, i spali domy Karioth, i umrze w grzmocie Moab, w brzmieniu trąby:
###### **Am 2,3**
 I wytracę sędziego z pośrodku jego, i wszystkie książęta jego pobiję z nim, mówi Pan.
###### **Am 2,4**
 To mówi Pan: Dla trzech złości Judy, i dla czterzech nie nawrócę go: przeto że odrzucił zakon Pański, a przykazania jego nie zachował: bo je zwiodły bałwany ich, za któremi chodzili ojcowie ich.
###### **Am 2,5**
 I puszczę ogień na Judę, i pożrze domy Jeruzalem.
###### **Am 2,6**
 To mówi Pan: Dla trzech złości Izraelowych, i dla czterzech nie nawrócę go: dla tego że przedał za srebro sprawiedliwego, a ubogiego za boty.
###### **Am 2,7**
 Którzy trą barziej niż proch ziemski głowy ubogich, a drogę poniżonych mijają: i syn, i ojciec jego chodzili do dziewki, aby gwałcili imię święte moje.
###### **Am 2,8**
 I na szatach zastawnych siadali podle każdego ołtarza, a wino skazanych pili w domu Boga swego.
###### **Am 2,9**
 A jam wygładził Amorrhejczyki od oblicza ich: którego wysokość cedrów wysokość: a on duży jako dąb: i starłem owoc jego z wierzchu, a korzenie jego ze spodku.
###### **Am 2,10**
 Jam jest, którym uczynił, żeście wyszli z ziemie Egiptskiej, a wodziłem was po puszczy czterdzieści lat, żebyście posiedli ziemię Amorrhejczyka.
###### **Am 2,11**
 I wzbudziłem z synów waszych proroki, a z młodzieńców waszych Nazarejczyki: izali nie tak jest synowie Izraelowi, mówi Pan?
###### **Am 2,12**
 A będziecie Nazarejczykom podawać wino: a prorokom rozkażecie, mówiąc: nie prorokujcie.
###### **Am 2,13**
 Otóż ja będę skrzypiał pod wami jako skrzypi wóz nałożony sianem.
###### **Am 2,14**
 I zginie ucieczka od prędkiego, a mocny nie otrzyma siły swojej: i mocarz nie wyzwoli dusze swojej.
###### **Am 2,15**
 I dzierżący łuk nie ostoi się: a prędki nogami swemi nie będzie wybawion: a kto wsiada na koń, nie zachowa dusze swej.
###### **Am 2,16**
 I kto mężnego serca między mocarzami, nago uciekać będzie dnia onego, mówi Pan.
