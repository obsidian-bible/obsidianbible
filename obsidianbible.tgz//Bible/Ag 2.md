# Ag 2 BT5
###### **Ag 2,1**
 Dnia dwudziestego pierwszego, miesiąca siód-mego Pan skierował te słowa do proroka Aggeusza:
###### **Ag 2,2**
 «*** Powiedz to Zorobabelowi, synowi Szealtiela, namiestnikowi Judy, i arcykapłanowi Jozuemu, synowi Josadaka, a także Reszcie ludu:
###### **Ag 2,3**
 Czy jest między wami ktoś, kto widział ten dom w jego dawnej chwale? A jak się on wam teraz przedstawia? Czyż nie wydaje się wam, jakby go w ogóle nie było?
###### **Ag 2,4**
 Teraz jednak nabierz ducha, Zorobabelu – wyrocznia Pana – nabierz ducha, arcykapłanie Jozue, synu Josadaka, nabierz też ducha, cały ludu ziemi! – wyrocznia Pana. Pracujcie, bo Ja jestem z wami, wyrocznia Pana Zastępów.
###### **Ag 2,5**
 Zgodnie z przymierzem, które zawarłem z wami, gdy wyszliście z Egiptu, duch mój stale przebywa pośród was; nie lękajcie się!
###### **Ag 2,6**
 Bo tak mówi Pan Zastępów: Jeszcze raz, [będzie to] jedna chwila, a Ja poruszę niebiosa i ziemię, morze i ląd.
###### **Ag 2,7**
 Poruszę wszystkie narody, tak że napłyną kosztowności wszystkich narodów, i napełnię chwałą ten dom, mówi Pan Zastępów.
###### **Ag 2,8**
 Do Mnie należy srebro i do Mnie złoto – wyrocznia Pana Zastępów.
###### **Ag 2,9**
 Przyszła chwała tego domu będzie większa od dawnej, mówi Pan Zastępów; na tym miejscu Ja udzielę pokoju***» – wyrocznia Pana Zastępów.
###### **Ag 2,10**
 Dnia dwudziestego czwartego, [miesiąca] dziewiątego, w drugim roku [rządów] Dariusza, Pan skierował te słowa do proroka Aggeusza:
###### **Ag 2,11**
 «***Tak mówi Pan Zastępów: Zapytaj kapłanów o rozstrzygnięcie takiej kwestii:
###### **Ag 2,12**
 Gdyby ktoś zawinął poświęcone mięso w róg swej szaty i dotknął tą szatą chleba albo gotowanej strawy, albo wina bądź oliwy, albo w ogóle jakiegoś pokarmu, czy wówczas będzie on poświęcony?***» Na to kapłani odrzekli: «***Nie***».
###### **Ag 2,13**
 Aggeusz więc pytał dalej: «***Gdyby ktoś nieczysty z powodu zmarłego dotknął się którejś z tych rzeczy, czy będzie zanieczyszczona?***» Na to kapłani odrzekli: «***Będzie zanieczyszczona***».
###### **Ag 2,14**
 Aggeusz zaś tak ciągnął dalej: «***Tak jest z tym ludem, tak z tym narodem przed moim obliczem – wyrocznia Pana. Tak też jest z każdym dziełem ich rąk; nawet i to, co składają tam w ofierze, jest nieczyste.
###### **Ag 2,15**
 Rozważcie tylko czasy obecne i minione. Zanim ułożono kamień na kamieniu w świątyni Pańskiej,
###### **Ag 2,16**
 zanim one były, gdy się przyszło do stogu na dwadzieścia [miar], było tam tylko dziesięć, gdy się przyszło do tłoczni, by zaczerpnąć pięćdziesiąt [miar], było ich tylko dwadzieścia.
###### **Ag 2,17**
 To Ja dotknąłem was zwarzeniem zbóż od gorąca, posuchą i gradem, [dotknąłem] wszelkie dzieło waszych rąk, a nie było między wami [nawracających się] do Mnie – wyrocznia Pana.
###### **Ag 2,18**
 Rozważcie tylko dobrze czasy obecne i przeszłe, <od dnia dwudziestego czwartego, [miesiąca] dziewiątego do dnia, w którym położono [fundamenty] pod świątynię Pańską. Rozważcie tylko dobrze!>
###### **Ag 2,19**
 Czy nasienie jest jeszcze w spichlerzu? [Nie]. Ale ani winorośl, ani figowiec, ani drzewo granatu, ani oliwka nie przyniosły jeszcze owocu. Od tego dnia Ja będę wam błogosławił!***»
###### **Ag 2,20**
 Po raz drugi Pan skierował te słowa do Aggeusza dnia dwudziestego czwartego [tego] miesiąca:
###### **Ag 2,21**
 «*** Powiedz to namiestnikowi Judy, Zorobabelowi: Ja poruszę niebiosa i ziemię.
###### **Ag 2,22**
 Wywrócę trony królestw i skruszę potęgę władczych narodów, przewrócę rydwan i jego woźnicę; padną konie i ich jeźdźcy, każdy polegnie od miecza swego brata.
###### **Ag 2,23**
 W tym dniu – wyrocznia Pana Zastępów – wezmę ciebie, sługo mój, Zorobabelu, synu Szealtiela – wyrocznia Pana – i uczynię z ciebie jakby sygnet, bo sobie upodobałem w tobie***» – wyrocznia Pana Zastępów.
# Ag 2 PAU
###### **Ag 2,1**
 Dwudziestego pierwszego dnia, siódmego miesiąca, PAN przemówił przez proroka Aggeusza:
###### **Ag 2,2**
 „Powiedz namiestnikowi Judy Zorobabelowi, synowi Szealtiela, i najwyższemu kapłanowi Jozuemu, synowi Josadaka, oraz reszcie ludu:
###### **Ag 2,3**
 Czy jest jeszcze wśród was ktoś, kto widział ten dom w jego dawnej chwale? Widzicie, jaki jest teraz? Czy nie wydaje się wam, że w porównaniu z tamtym, jakby go wcale nie było?
###### **Ag 2,4**
 Lecz teraz: Odwagi, Zorobabelu! - wyrocznia PANA. Odwagi, najwyższy kapłanie, Jozue, synu Josadaka! Odwagi, cały ludu tej ziemi! - wyrocznia PANA. Do dzieła! Gdyż Ja jestem z wami! - wyrocznia PANA Zastępów.
###### **Ag 2,5**
 Zgodnie z obietnicą, którą wam dałem, gdy wychodziliście z Egiptu, mój duch jest stale wśród was. Nie bójcie się!
###### **Ag 2,6**
 Gdyż tak mówi PAN Zastępów: Jeszcze tylko krótka chwila, a poruszę niebo i ziemię, morze i stały ląd.
###### **Ag 2,7**
 Ja poruszę wszystkie narody, tak że napłyną kosztowności wszystkich narodów i napełnię ten dom chwałą - mówi PAN Zastępów.
###### **Ag 2,8**
 Moje jest srebro i moje jest złoto - wyrocznia PANA Zastępów.
###### **Ag 2,9**
 Chwała przyszłego domu będzie większa niż dawniej - mówi PAN Zastępów. W tym właśnie miejscu będę obdarzał pokojem - wyrocznia PANA Zastępów”.
###### **Ag 2,10**
 Dwudziestego czwartego dnia, dziewiątego miesiąca, w drugim roku panowania Dariusza, PAN przemówił do proroka Aggeusza:
###### **Ag 2,11**
 „Tak mówi PAN Zastępów: Zapytaj, proszę, kapłanów o orzeczenie w takiej sprawie:
###### **Ag 2,12**
 Gdy ktoś niesie poświęcone mięso zawinięte w swoje ubranie i dotknie tym ubraniem chleba albo gotowanej potrawy, albo wina czy oliwy, albo w ogóle jakiegoś pokarmu, to czy wtedy staje się on poświęcony?”. Kapłani odpowiedzieli: „Nie”.
###### **Ag 2,13**
 Aggeusz pytał dalej: „Gdy ktoś, kto stał się nieczysty wskutek zetknięcia ze zmarłym, dotknie którejś z tych rzeczy, to czy staje się ona nieczysta?”. Kapłani odpowiedzieli: „Tak”.
###### **Ag 2,14**
 Wtedy odezwał się Aggeusz i rzekł: „Taki jest ten lud i taki jest ten naród według Mnie - wyrocznia PANA; takie są wszystkie ich dzieła i cokolwiek składają w ofierze - jest to nieczyste.
###### **Ag 2,15**
 Teraz jednak bądźcie uważni, zaczynając od dziś i na przyszłość. Zanim w świątyni PANA ułożono kamień na kamieniu -
###### **Ag 2,16**
 jak wam się wiodło? Przyszedł ktoś do stosu ziarna, w którym miało być dwadzieścia miar, lecz było tam tylko dziesięć. Przyszedł ktoś do kadzi z młodym winem, by zaczerpnąć pięćdziesiąt miar, lecz było tam tylko dwadzieścia.
###### **Ag 2,17**
 Sprawiłem, że plony waszej pracy zniszczyła rdza zbożowa, pleśń i grad, a jednak nie ma was przy Mnie - wyrocznia PANA.
###### **Ag 2,18**
 Rozważcie czasy obecne i minione: od dwudziestego czwartego dnia, dziewiątego miesiąca, to jest od dnia, w którym położono fundamenty pod świątynię PANA. Bądźcie uważni:
###### **Ag 2,19**
 Nie ma jeszcze ziarna w spichlerzu, a winorośl, figowiec, drzewo granatu, oliwka jeszcze nie wydały owocu. Od dziś jednak będę wam błogosławił”.
###### **Ag 2,20**
 Dwudziestego czwartego dnia tego miesiąca po raz drugi przemówił PAN do Aggeusza:
###### **Ag 2,21**
 „Powiedz namiestnikowi Judy Zorobabelowi: Poruszę niebo i ziemię.
###### **Ag 2,22**
 Powalę trony królestw i zniszczę moc królestw pogańskich. Przewrócę rydwany wraz z ich woźnicami. Padną wierzchowce i jeźdźcy, jeden polegnie od miecza drugiego.
###### **Ag 2,23**
 W tym dniu - wyrocznia PANA Zastępów, wezmę ciebie, mój sługo Zorobabelu, synu Szealtiela - wyrocznia PANA, i uczynię cię jakby sygnetem, bo wybrałem ciebie - wyrocznia PANA Zastępów”.
# Ag 2 BP
###### **Ag 2,1**
 dnia dwudziestego pierwszego, miesiąca siódmego, przemówił Jahwe przez proroka Aggeusza:
###### **Ag 2,2**
 Zwróć się do zarządcy Judei, Zorobabela, syna Salatiela, do arcykapłana Jozuego, syna Jocedeka, i do całej ocalałej części narodu w te słowa:
###### **Ag 2,3**
 Kto ostał się jeszcze między wami, co widział tę Świątynię w jej dawnej wspaniałości? A jaką wydaje wam się teraz? Nie jestże niczym w waszych oczach?
###### **Ag 2,4**
 Ale teraz odwagi, Zorobabelu! - mówi Jahwe. Odwagi, Jozue, synu Jocedeka, arcykapłanie! Odwagi, wszyscy mieszkańcy tej ziemi - tak mówi Jahwe - i zabierzcie się do dzieła, bo Ja jestem z wami! - tak mówi Jahwe Zastępów.
###### **Ag 2,5**
 Zgodnie z Przymierzem, jakie zawarłem z wami, kiedyście wyszli z Egiptu, Duch mój jest zawsze między wami. Nie obawiajcie się!
###### **Ag 2,6**
 Tak bowiem mówi Jahwe Zastępów: Jeszcze raz (niezadługo) poruszę niebo i ziemię, morze i ląd.
###### **Ag 2,7**
 Poruszę wszystkie narody, a napłyną kosztowności od wszystkich ludów, i napełnię ten Dom chwałą - mówi Jahwe Zastępów.
###### **Ag 2,8**
 Moje jest srebro i moje jest złoto - mówi Jahwe Zastępów.
###### **Ag 2,9**
 Przyszła chwała tej Świątyni będzie większa niż dawniejsza - mówi Jahwe Zastępów; na tym też miejscu użyczać będę pokoju - mówi Jahwe Zastępów.
###### **Ag 2,10**
 [Dnia] dwudziestego czwartego, [miesiąca] dziewiątego, w drugim roku [panowania] króla Dariusza, przemówił Jahwe przez proroka Aggeusza:
###### **Ag 2,11**
 Tak mówi Jahwe Zastępów: Zwróć się do kapłanów o rozstrzygnięcie prawne w takiej sprawie:
###### **Ag 2,12**
 "Jeśli ktoś niesie poświęcone mięso owinięte w połę swego płaszcza, a dotknie tą połą chleba, jakiejś gotowanej strawy, wina lub oliwy albo jakiejkolwiek innej potrawy - czy to, [czego dotknął], zostanie poświęcone?" Kapłani odpowiedzieli: Nie.
###### **Ag 2,13**
 Aggeusz pytał dalej: A jeśli ktoś, kto przez zetknięcie się ze zwłokami stał się nieczysty, dotknie się tego wszystkiego - czy stanie się to nieczyste? Kapłani odpowiedzieli: Tak, to stanie się nieczyste.
###### **Ag 2,14**
 Wtedy Aggeusz rzekł: Tacy są właśnie ci ludzie w moich oczach, taki jest właśnie ten naród - mówi Jahwe; takie jest także każde dzieło ich rąk i to, co tam składają w ofierze, wszystko to nieczyste.
###### **Ag 2,15**
 A teraz rozważcie dobrze [czas] od dnia dzisiejszego do dni minionych! Gdy nie kładziono jeszcze w Świątyni kamienia na kamieniu -
###### **Ag 2,16**
 jak wam się wtedy wiodło ? Przyszło się do brogu zboża mieszczącego dwadzieścia [miar], a było ich tylko dziesięć; przyszło się do tłoczni, by czerpać (z kadzi) pięćdziesiąt [miar], a było ich tylko dwadzieścia.
###### **Ag 2,17**
 Dotknąłem rdzą zbożową, śniecią i gradem wszystkie dzieła waszych rąk, a wyście się do mnie nie nawrócili - mówi Jahwe.
###### **Ag 2,18**
 Rozważcie dobrze [czas] od dnia dzisiejszego do dni minionych! (Od dnia dwudziestego czwartego, miesiąca dziewiątego, to jest od dnia, w którym położono fundamenty pod Świątynię Jahwe).
###### **Ag 2,19**
 Czy ziarno siewne znajduje się jeszcze w spichlerzu? A czy szczep winny, drzewo figowe, granatowe i oliwne odtąd nie będą rodziły? Od dnia dzisiejszego będę [was] darzył błogosławieństwem.
###### **Ag 2,20**
 Dnia dwudziestego czwartego [tegoż] miesiąca przemówił Jahwe po raz wtóry przez Aggeusza:
###### **Ag 2,21**
 Oznajmij Zorobabelowi, zarządcy Judei:
###### **Ag 2,22**
 powalę trony królewskie i skruszę potęgę królestw pogańskich; powywracam wozy razem z woźnicami; jeźdźcy ze swymi wierzchowcami padną, jeden od miecza drugiego.
###### **Ag 2,23**
 W owym dniu - mówi Jahwe Zastępów - wezmę ciebie, Zorobabelu, synu Salatiela, sługo mój - mówi Jahwe - i uczynię cię jakby sygnetem; bo cię wybrałem - mówi Jahwe Zastępów.
# Ag 2 BR
###### **Ag 2,1**
 Dnia dwudziestego pierwszego, siódmego miesiąca Pan przemówił w ten sposób przez proroka swego, Aggeusza:
###### **Ag 2,2**
 Powiesz Zorobabelowi, synowi Szealtiela, namiestnikowi judzkiemu, oraz arcykapłanowi Jozuemu, synowi Josadaka, i wszystkim ocalałym z ludu:
###### **Ag 2,3**
 Czy jest jeszcze wśród was ktoś taki, kto widział światyjnię w jej dawnej wspaniałości? A co z niej teraz pozostało? Czyż nie można powiedzieć, że nie zostało z niej nic?
###### **Ag 2,4**
 Lecz nabierz ducha, Zorobabelu - mówi Pan - odwagi, arcykapłanie Jozue, synu Josadaka, odwagi, wszyscy mieszkańcy kraju - wyrocznia Pana! Wszyscy odważnie zbierzcie się do pracy: Ja bowiem jestem z wami, wyrocznia Pan Zastępów.
###### **Ag 2,5**
 Przymierze, które z wami zawarłem, gdy was wyprowadzałem z Egiptu, jest nadal ważne, a mój duch znajduje się pośród was! Nie bójcie się więc niczego!
###### **Ag 2,6**
 Bo tak oto mówi Pan Zastępów: Już niedługo, a sprawię, że zadrżą niebiosa i ziemia oraz morza i ląd stały.
###### **Ag 2,7**
 Drżeć też będą z przerażeniem wszystkie narody. Zaczną wtedy napływać skarby od wszystkich ludów i napełnię ten dom chwałą, mówi Pan Zastępów.
###### **Ag 2,8**
 Do Mnie należy srebro i złoto - wyrocznia Pana Zastępów.
###### **Ag 2,9**
 Przyszła wspaniałość tego domu będzie większa niż ta, którą cieszył się kiedyś - taka jest wyrocznia Pana Zastępów. Na miejsce to zaś ześlę pełnię pokoju - wyrocznia Pana Zastępów.
###### **Ag 2,10**
 W drugim roku panowania króla Dariusza, dnia dwudziestego czwartego dziewiątego miesiąca Pan przemówił do proroka Aggeusza.
###### **Ag 2,11**
 Oto, co mówi Pan Zastępów: Zapytaj kapłanów o radę w takiej sprawie:
###### **Ag 2,12**
 Jeżeli ktoś zawinie w połę własnego płaszcza kawałek mięsa złożonego na ofiarę, a potem dotknie tym płaszczem niechcący chleba albo jakiejś gotowanej strawy, wina, oleju lub innego jedzenia, to czy tym samym owe rzeczy dotknięte zostaną poświęcone? Kapłani odpowiedzieli: Nie!
###### **Ag 2,13**
 Wtedy Aggeusz zapytał: A gdyby którejś z tych rzeczy dotknął człowiek nieczysty, dlatego że otarł się przedtem o ciało zmarłego, to czy rzeczy te również staną się nieczyste? Odpowiedzieli kapłani: Tak, staną się nieczyste.
###### **Ag 2,14**
 Rzekł tedy Aggeusz: Tak też jest w oczach moich z całym tym narodem i z całym ludem - wyrocznia Pana - i tak jest ze wszystkim, co one czynią: nieczyste jest wszystko, co przynoszą na ofiarę.
###### **Ag 2,15**
 Teraz jednak patrzcie uważnie na to wszystko, co będzie się dziać, poczynając od dnia dziesiejszego.
###### **Ag 2,16**
 Pomyślcie, jak się wam wiodło, nim położono kamień na kamieniu pod budowę świątyni? Kiedy przychodziło się do stogu, który powinien liczyć dwadzieścia efa, to okazywało się, że miał on tylko dziesięć efa. Gdy przyszło się do tłoczni, żeby zaczerpnąć piećdziesiąt bat (winnego moszczu), to okazywało się, że było tam zaledwie dwadzieścia bat.
###### **Ag 2,17**
 Suszą niszczyłem wam zboża, nękałem was upałami, gradem niszcząc w ten sposób wszystkie wasze trudy i bezskuteczną czyniąc wszelką waszą pracę. A wy mimo to nie nawracaliście się ku Mnie - wyrocznia Pana. -
###### **Ag 2,18**
 Uważajcie dobrze na to, co będzie się dziać poczynając od dnia dzisiejszego, to jest od dnia dwudziestego czwartego dziewiątego miesiąca, czyli od chwili położenia kamienia węgielnego pod świątynię Pańską. Zobaczcie dobrze,
###### **Ag 2,19**
 czy ziarno do zasiewu jest jeszcze w śpichlerzach, czy w dalszym ciągu nie będą rodzić owoców winne krzewy, drzewa figowe i granatowe oraz śliwki? Od dziś zacznę wam znów błogosławić.
###### **Ag 2,20**
 Dnia dwudziestego czwartego (tego samego) miesiąca Pan przemówił po raz drugi do Aggeusza:
###### **Ag 2,21**
 Powiedz tak Zorobabelowi, namiestnikowi judzkiemu: Ja sprawię, że poruszy się całe niebo i ziemia.
###### **Ag 2,22**
 Obalę trony królów i skruszę potęgę całych królestw i narodów. Powywracam rydwany razem z ich jeźdźcami. Legną na ziemi rumaki wraz z wojownikami, jeden zabity mieczem drugiego.
###### **Ag 2,23**
 W dniu owym - wyrocznia Pana Zastępów - wezmę ciebie, sługo mój, Zorobabelu, synu Szealtiela -wyrocznia Pana - i uczynię cię moim sygnetem, bo w tobie upodobałem sobie- taka jest wyrocznia Pana Zastępów.
# Ag 2 WUJ
###### **Ag 2,1**
 Siódmego miesiąca, dwudziestego i pierwszego dnia miesiąca, stało się słowo Pańskie w ręce Aggeusza proroka, mówiąc.
###### **Ag 2,2**
 Mów do Zorobabela syna Salathiel książęcia Judzkiego, i do Jezusa syna Josedek kapłana wielkiego, I do innych z ludu, rzekąc:
###### **Ag 2,3**
 Kto się między wami został, który widział dom ten w ozdobie jego pierwszej? a teraz co się wam ten widzi? Izali nie tak jest jakoby nie był w oczach waszych?
###### **Ag 2,4**
 A teraz zmocni się Zorobabel, mówi Pan: i zmocni się też Jezu, synu Josedek kapłanie wielki, i zmocni się wszystek ludu ziemie, mówi Bóg zastępów: a czyńcie (bo ja jestem z wami, mówi Pan zastępów).
###### **Ag 2,5**
 Słowo, którem postanowił z wami, gdyście wychodzili z ziemie Egiptskiej: a duch mój będzie w pośrodku was, nie bójcie się.
###### **Ag 2,6**
 Bo to mówi pan zastępów: Jeszcze jedna mała chwila jest, a ja poruszę niebo, i ziemię, i morze, i suchą.
###### **Ag 2,7**
 I poruszę wszystkie narody: A PRZYDZIE POŻĄDANY wszem narodom, i napełnię dom ten chwałą, mówi Pan zastępów.
###### **Ag 2,8**
 Moje jest srebro, i moje jest złoto, mówi Pan zastępów.
###### **Ag 2,9**
 Większa będzie chwała domu tego pośledniego, niż pierwszego, mówi Pan zastępów. A na tem miejscu dam pokój, mówi Pan zastępów.
###### **Ag 2,10**
 Dwudziestego i czwartego dnia dziewiątego miesiąca, roku wtórego Daryusza króla: stało się słowo Pańskie do Aggeusza proroka, mówiąc:
###### **Ag 2,11**
 To mówi Pan zastępów: Pytaj kapłanów o zakon, mówiąc:
###### **Ag 2,12**
 Jeśliby wziął człowiek mięso poświęcone w podołek szaty swej, a dotknął się krajem jej chleba, abo potrawy, abo wina, abo oliwy, abo wszelkiego pokarmu: izali się oświeci? i odpowiadając kapłani rzekli: Nie.
###### **Ag 2,13**
 I rzekł Aggeusz: Jeśli się dotknie zmazany duszą czegokolwiek z tych, izali zmazane nie będzie? i odpowiedzieli kapłani, i rzekli: Będzie zmazane.
###### **Ag 2,14**
 I odpowiedział Aggeusz, i rzekł: Tak ci ten lud, i tak ten naród przed obliczem mojem, mówi Pan: i tak wszelkie dzieło uczynki rąk ich: i wszystko co tam ofiarowali, splugawione będzie.
###### **Ag 2,15**
 A tak połóżcie serca wasze odednia tego i wyższej, póki nie położono kamienia na kamień w kościele Pańskim.
###### **Ag 2,16**
 Gdyście przychodzili do stogu dwadzieścia korców, a bywało dziesięć: a gdyście wchodzili do prasy, abyście wytłoczyli pięćdziesiąt łagwic, a było dwadzieścia.
###### **Ag 2,17**
 Skarałem was wiatrem palącym, i suszą, i gradem, wszystkie prace rąk waszych: a nie był między wami, ktoby się ku mnie nawrócił mówi Pan.
###### **Ag 2,18**
 Połóżcie serca wasze, od tego dnia i na potem, od dwudziestego i czwartego dnia miesiąca dziewiątego: odednia którego założono fundamenty kościoła Pańskiego, połóżcie na serca wasze.
###### **Ag 2,19**
 Izali już nasienie wzrosło: a jeszcze winnica i figa, i granatowe jabłka, i drzewo oliwne nie zakwitło? odednia tego błogosławić będę.
###### **Ag 2,20**
 I stało się słowo Pańskie po wtóre do Aggeusza, dwudziestego i czwartego dnia miesiąca, mówiąc:
###### **Ag 2,21**
 Mów do Zorobabela książęcia Judzkiego, rzekąc: Ja poruszę niebo społem i ziemię.
###### **Ag 2,22**
 A wywrócę stolicę królestw, a skruszę moc królestwa pogańskiego: i wywrócę poczwórny i wsiadającego nań, że pozdychają konie i wsiadacze ich, mąż od miecza brata swego.
###### **Ag 2,23**
 W on dzień, mówi Pan zastępów, wezmę ciebie Zorobabelu synu Salathiel sługo mój, mówi Pan: i położę cię jako sygnet, bom cię obrał, mówi Pan zastępów.1
