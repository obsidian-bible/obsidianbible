# Ez 5 BT5
###### **Ez 5,1**
 ***Synu człowieczy, weź sobie ostry miecz i użyj go jako brzytwy, i ogol nim sobie głowę i brodę; następnie weź dokładną wagę i podziel [zgolone włosy].***
###### **Ez 5,2**
 ***Jedną ich część spalisz w ogniu w obrębie miasta, gdy nadejdą dni oblężenia; potem weźmiesz następną część i posiekasz ją mieczem dokoła [miasta], a trzecią część rozrzucisz z wiatrem, ponieważ chcę miecza dobyć na nich.***
###### **Ez 5,3**
 ***Weź z nich tylko małą ilość i zawiń w poły swego płaszcza.***
###### **Ez 5,4**
 ***Z tych weźmiesz jeszcze trochę i wrzucisz je do ognia, aby w nim spłonęły, z tego wyjdzie ogień na cały dom Izraela.***
###### **Ez 5,5**
 ***Tak mówi Pan Bóg: Oto jest Jerozolima, którą umieściłem między poganami, otoczona obcymi krajami.***
###### **Ez 5,6**
 ***Ale wystąpiła przeciw moim prawom z większą przewrotnością aniżeli poganie i przeciw moim ustawom bardziej aniżeli kraje, które ją otaczają, ponieważ wzgardzili Izraelici moimi prawami i nie postępowali według moich ustaw.***
###### **Ez 5,7**
 ***Dlatego tak mówi Pan Bóg: Ponieważ byliście bardziej zbuntowani niż poganie, którzy was otaczają, i nie postępowaliście według moich ustaw, i nie strzegliście moich praw, a nawet nie przestrzegaliście praw narodów, które was otaczają***
###### **Ez 5,8**
 ***dlatego tak mówi Pan Bóg: Oto i Ja występuję przeciwko tobie i na oczach pogan wykonam na tobie wyrok.***
###### **Ez 5,9**
 ***Z powodu twoich obrzydliwości dokonam na tobie tego, czego nigdy nie czyniłem i już nigdy nie uczynię.***
###### **Ez 5,10**
 ***Dlatego ojcowie będą jedli synów pośrodku ciebie, a synowie jeść będą swoich ojców; wykonam nad tobą sądy, wszystkie resztki twoje rozsieję na wszystkie wiatry.***
###### **Ez 5,11**
 ***Dlatego na moje życie oświadczam – wyrocznia Pana Boga: Ponieważ świątynię moją splugawiłaś wszystkimi twoimi ohydami i wszystkimi twymi obrzydliwościami, Ja także odrzucę bez oglądania się na litość i Ja także nie będę oszczędzał.***
###### **Ez 5,12**
 ***Jedna trzecia twoja pomrze od zarazy i zginie pośrodku ciebie z głodu; jedna trzecia padnie wokół ciebie od miecza, a jedną trzecią rozpędzę na wszystkie wiatry, nadto miecza na nich dobędę.***
###### **Ez 5,13**
 ***Wtedy uśmierzy się mój gniew. Uspokoję na nich moją zapalczywość i zaniecham gniewu. Potem poznają, że Ja, Pan, przemówiłem w mojej zapalczywości, gdy dałem upust mojemu gniewowi na nich.***
###### **Ez 5,14**
 ***Zrobię z ciebie pustynię i pośmiewisko narodów, które cię otaczają, na oczach wszystkich przechodniów.***
###### **Ez 5,15**
 ***Staniesz się pośmiewiskiem i przedmiotem szyderstwa, ostrzeżeniem i postrachem dla narodów, które cię otaczają, gdy wykonam na tobie wszystkie sądy z gniewem i zapalczywością, i srogimi karami. Ja, Pan, powiedziałem.***
###### **Ez 5,16**
 ***Gdy wypuszczę przeciwko wam strzały głodu jako niszczycielki, które mają za cel zagładę, gdy je wypuszczę na waszą zagładę, pomnożę między wami głód i złamię wam podporę chleba.***
###### **Ez 5,17**
 ***Ześlę na was głód i dzikie zwierzęta, które pozbawią was dzieci; i mór, i śmierć gwałtowna przyjdzie na ciebie, i miecz sprowadzę na ciebie. Ja, Pan, powiedziałem***».
# Ez 5 PAU
###### **Ez 5,1**
 „Synu człowieczy, weź sobie ostry miecz, użyj go jako brzytwy i ogol nim sobie głowę i brodę. Potem weź wagę i podziel włosy.
###### **Ez 5,2**
 Jedną trzecią spalisz w ogniu w środku miasta, gdy skończą się dni oblężenia. Jedną trzecią potniesz mieczem wokół niego, a jedną trzecią rzucisz na wiatr. Ja zaś dobędę na nich miecza.
###### **Ez 5,3**
 Weźmiesz też niewielką ilość włosów i zawiniesz je w róg swojego płaszcza.
###### **Ez 5,4**
 Z nich znowu weźmiesz część, rzucisz je do ognia i spalisz. Z niego wyjdzie ogień, który obejmie cały lud izraelski.
###### **Ez 5,5**
 Tak mówi PAN BÓG: To jest Jerozolima! Umieściłem ją wśród narodów, pośrodku krain.
###### **Ez 5,6**
 Ale ona zbuntowała się przeciwko moim prawom bardziej niż inne narody i przeciwko moim nakazom bardziej niż otaczające ją kraje. Odrzucili moje prawa i nie postępowali według moich nakazów.
###### **Ez 5,7**
 Dlatego tak mówi PAN BÓG: Buntowaliście się bardziej niż otaczające was narody, nie postępowaliście według moich nakazów i nie wypełnialiście moich praw, kierując się prawami narodów, które są wokół was.
###### **Ez 5,8**
 Dlatego tak mówi PAN BÓG: Oto Ja także występuję przeciwko tobie! Osądzę cię w obecności innych narodów.
###### **Ez 5,9**
 Z powodu wszystkich twoich obrzydliwości uczynię z tobą to, czego do tej pory nie czyniłem i czego już później czynić nie będę.
###### **Ez 5,10**
 Ojcowie będą jedli dzieci, a dzieci będą jadły swoich ojców. Dokonam sądu nad tobą, rozproszę na wszystkie strony całą twoją resztę.
###### **Ez 5,11**
 Dlatego oświadczam na moje życie - wyrocznia PANA BOGA: skoro splamiłaś moją świątynię ohydami i wszystkimi obrzydliwościami, to i Ja będę się brzydził tobą. Nie spojrzę ze współczuciem i nie przebaczę.
###### **Ez 5,12**
 Trzecia część twoich ludzi umrze od zarazy i zginie z głodu w twoich granicach. Trzecia część padnie od miecza wokół ciebie, a trzecią część rozproszę na wszystkie strony i dobędę na nich miecza.
###### **Ez 5,13**
 Lecz ustanie mój gniew, powstrzymam moje oburzenie na nich i uspokoję się. Wtedy przekonają się, że Ja, PAN, powiedziałem to w mojej zapalczywości, gdy pałałem na nich gniewem.
###### **Ez 5,14**
 Zamienię cię w ruinę i w hańbę wobec sąsiednich narodów i wobec każdego przechodnia.
###### **Ez 5,15**
 Staniesz się hańbą i pośmiewiskiem, przestrogą i zgrozą dla okolicznych narodów, gdy wykonam na tobie wyroki w gniewie i oburzeniu, poddając cię surowej karze - Ja, PAN, to powiedziałem.
###### **Ez 5,16**
 Wypuszczę na was srogie strzały głodu niosącego zagładę. Wyślę je ku waszej zgubie. Wzmogę głód wśród was i zniszczę wasze zapasy chleba.
###### **Ez 5,17**
 Ześlę na was głód i drapieżne zwierzęta. Osierocę cię. Dosięgnie cię zaraza i krew. Sprowadzę na ciebie miecz - Ja, PAN, to powiedziałem”.
# Ez 5 BP
###### **Ez 5,1**
 Ty zaś, synu człowieczy, weź sobie ostry miecz, użyj go [jako] brzytwy fryzjerskiej i przeciągnij nim po swej głowie i po swojej brodzie. Weź [następnie] wagę i rozdziel je [włosy].
###### **Ez 5,2**
 Gdy wypełnią się dni oblężenia, trzecią część spalisz w ogniu wewnątrz miasta, trzecią część weźmiesz i potniesz mieczem wokół niego, a trzecią część rzucisz na wiatr. Ja zaś dobędę miecza na nich.
###### **Ez 5,3**
 [Przedtem jednak] weźmiesz stamtąd małą ilość i zawiniesz ją w róg swej szaty.
###### **Ez 5,4**
 z tych znowu weźmiesz [część] i rzucisz je w środek ognia, i spalisz je w ogniu. Z niego wyjdzie ogień na cały Dom Izraela.
###### **Ez 5,5**
 Tak mówi Pan, Jahwe: To jest Jerozolima! Umieściłem ją w środku narodów i krainy ją otaczają.
###### **Ez 5,6**
 Ale z powodu przewrotności zbuntowała się przeciwko mojemu prawu bardziej niż [obce] narody i przeciw moim przykazaniom bardziej niż kraje, które ją otaczają, albowiem wzgardzili moim prawem i nie postępowali według moich przykazań.
###### **Ez 5,7**
 Dlatego tak mówi Pan, Jahwe: Ponieważ buntowaliście się bardziej niż [obce] narody, które są wkoło was, nie postępowaliście według moich przykazań i nie wypełnialiście mego prawa, a praktykowaliście zwyczaje narodów sąsiadujących z wami,
###### **Ez 5,8**
 dlatego tak mówi Pan, Jahwe: Oto Ja także jestem przeciw tobie. Na oczach narodów odprawię sąd pośród ciebie.
###### **Ez 5,9**
 Z powodu wszystkich twoich obrzydliwości uczynię ci to, czego nie uczyniłem i nic podobnego więcej nie uczynię,
###### **Ez 5,10**
 [mianowicie] że wewnątrz ciebie ojcowie będą pożerali dzieci, a dzieci będą pożerały swoich ojców. Odprawię nad tobą sąd i rozproszę na wszystkie wiatry to, co z ciebie pozostanie.
###### **Ez 5,11**
 [Jak prawdą jest, że] Ja żyję - wyrocznia Pana, Jahwe - tak [uczynię] dlatego, ponieważ zbezcześciłeś moje sanktuarium wszystkimi swymi ohydami i wszystkimi swoimi obrzydliwościami. Ja także cofnę [moją łaskawość] i nie spojrzę litościwie moimi oczami. Ja także nie okażę miłosierdzia.
###### **Ez 5,12**
 Jedna trzecia twoich umrze od zarazy i wyginie z głodu wewnątrz ciebie. Trzecia część padnie od miecza wokół ciebie, a trzecią część rozproszę na wszystkie wiatry i miecza na nich dobędę.
###### **Ez 5,13**
 I dopełni się mój gniew. Wywrę na nich moją złość i uśmierzę ją. Skoro urzeczywistnię na nich moją złość, wtedy poznają, że Ja, Jahwe, powiedziałem w mej zapalczywości.
###### **Ez 5,14**
 Zamienię cię w ruinę i w pośmiewisko narodów, które są wkoło ciebie, dla oczu każdego przechodnia.
###### **Ez 5,15**
 Gdy odprawię nad tobą sąd w gniewie, w złości i porywczym karaniu, staniesz się hańbą i pośmiewiskiem, przestrogą i zgrozą dla narodów, które cię otaczają. - Ja, Jahwe, powiedziałem. -
###### **Ez 5,16**
 Gdy wypuszczę przeciw wam srogie strzały głodu, niosące zagładę, które wyślę ku waszej zgubie i wzmogę głód przeciw wam, wtedy złamię wam laskę chleba.
###### **Ez 5,17**
 Ześlę na was głód, dzikie zwierzęta, [które] cię osierocą. Zaraza i krew przewalą się przez ciebie i miecz sprowadzę na ciebie. - Ja, Jahwe, powiedziałem.
# Ez 5 BR
###### **Ez 5,1**
 Synu człowieczy, weź dobrze naostrzony miecz! Niech ci posłuży za brzytwę. Ogól nim sobie włosy na głowie i brodę. Potem weź wagę i zważ ogolone włosy!
###### **Ez 5,2**
 Jedną trzecią tych włosów spal w samym środku miasta w dniu zakończenia jego oblężenia. Jedną trzecią rozproszysz mieczem po mieście, a jedną trzecią rzucisz na wiatr w tym czasie, kiedy Ja będę na nich dobywał miecza.
###### **Ez 5,3**
 Trochę włosów weź i zawiń w połę swojego płaszcza!
###### **Ez 5,4**
 Stąd weź jeszcze kilka włosów i rzuć je do ognia i spal. Ogień z nich obejmie cały Dom Izraela.
###### **Ez 5,5**
 Oto, co mówi Pan Bóg: To jest Jerozolima. Umieściłem ją między narodami, pośrodku obcych krain.
###### **Ez 5,6**
 Lecz ona okazała się niegodziwa i sprzeciwiała się moim prawom bardziej niż inne narody i moim przepisom częściej niż okoliczne kraje. Nie zważała na moje pouczenia i nie postępowała według mojego prawa.
###### **Ez 5,7**
 I dlatego tak oto mówi Bóg i Pan: Ponieważ byliście bezbożni bardziej niż poganie i nie zachowywaliście moich nakazów i nie przestrzegaliście moich praw ani praw otaczających was narodów
###### **Ez 5,8**
 dlatego oto co mówi Pan: Wyruszam teraz przeciwko tobie, Jerozolimo! Na oczach ludów pogańskich wydam na ciebie wyrok.
###### **Ez 5,9**
 Postąpię z tobą według wszystkich twoich zbrodni i uczynię ci to, czego jeszcze nigdy nikomu nie uczyniłem i nie uczynię w przyszłości.
###### **Ez 5,10**
 Wśród twoich budowli, o Jerozolimo, ojcowie będą spożywać ciała własnych dzieci - ciała swych ojców. Otóż Ja sam przeprowadzę nad tobą sąd - a resztki twoich mieszkańców rozproszę na cztery strony świata.
###### **Ez 5,11**
 Dlatego, na życie moje - mówi Pan Bóg - ponieważ przybytek mój zbezcześciłeś twoimi bożkami i odrażającymi występkami, postanowiłem zrównać cię z ziemią. Żaden widok nie będzie Mnie przyprawiał o litość i nie oszczędzę nikogo.
###### **Ez 5,12**
 Jedna trzecia twoich mieszkańców zginie od zarazy i pomrze w mieście z głodu. Jedna trzecia jeszcze przed twoimi murami zginie od miecza. Wreszcie jedną trzecią rozproszę na wszystkie strony i będę ich własnym mieczem ścigał.
###### **Ez 5,13**
 Dopiero wtedy ochłonę z gniewu. Uspokoi się moja zapalczywość i znajdę dla siebie zadośćuczynienie.
###### **Ez 5,14**
 Na oczach wszystkich przechodniów zamienię cię w pustkowie i uczynię pośmiewiskiem dla okolicznych narodów.
###### **Ez 5,15**
 Pośmiewiskiem staniesz się i wzgardą a przestrogą i groźbą dla otaczających cię narodów, gdy zapłoną nad tobą mój gniew, zapalczywość i surowość kary. Ja, Pan, wszystko to ci powiedziałem.
###### **Ez 5,16**
 Już wypuściłem w twoją stronę nękające cię i niosące zagładę strzały głodu. Wysyłam je, żeby was wygładzić, pozbawiam was zapasów chleba, aby powiększyć klęskę głodu.
###### **Ez 5,17**
 Ześlę na was klęskę głodu oraz stada dzikich zwierząt, które będą porywały wasze dzieci. Cierpieć będziecie z powodu zarazy i przelewu krwi. Podniosłem na ciebie mój miecz. Ja, Pan, wszystko to ci powiedziałem.
# Ez 5 WUJ
###### **Ez 5,1**
 A ty synu człowieczy weźmi sobie miecz ostry, golący włosy: i weźmiesz ji, i będziesz powłaczał po głowie twojej, i po brodzie twojej: i weźmiesz sobie szale wagi, a rozdzielisz je.
###### **Ez 5,2**
 Trzecią część spalisz ogniem w pośród miasta wedle wypełnienia dni oblężenia: i weźmiesz trzecią część, i zsiekasz mieczem około niego: a drugą trzecią część roztrzęsiesz na wiatr, a miecza dobędę za nimi.
###### **Ez 5,3**
 I weźmiesz z nich małą liczbę, i zawiążesz je w końcu płaszcza twego.
###### **Ez 5,4**
 A z tych jeszcze weźmiesz i wrzucisz je w pośród ognia, i spalisz je w ogniu: a z niego wynidzie ogień na wszystek dom Izraelów.
###### **Ez 5,5**
 To mówi Pan Bóg: To jest Jeruzalem, w pośród narodów położyłem ji, a w około niego ziemie.
###### **Ez 5,6**
 I wzgardziło sądy moje, że się stało niezbożniejsze niźli narodowie: i przykazanie moje więcej niźli te ziemie, które są około niego. Bo sądy moje porzucili, a w przykazaniu mojem nie chodzili.
###### **Ez 5,7**
 Przetoż to mówi Pan Bóg: żeście przewyższyli narody, które są około was, a nie chodziliście w przykazaniach moich, a sądów moich nie zachowaliście, wedle też sądów narodów które są około was, nie czyniliście:
###### **Ez 5,8**
 Przetoż to mówi Pan Bóg: Oto ja na cię, a ja sam uczynię w pośrodku ciebie sądy przed oczyma narodów.
###### **Ez 5,9**
 A uczynię w tobie czegom nie uczynił, i którym rzeczam podobnych czynić nie będę więcej, dla wszech obrzydłości twoich.
###### **Ez 5,10**
 Przeto ojcowie będą jeść syny w pośrodku ciebie, a synowie będą jeść ojce swe: i będę czynił w tobie sądy, i rozsypę wszystkie ostatki twoje na każdy wiatr.
###### **Ez 5,11**
 Przeto żywę ja, mówi Pan Bóg: Jeśli nie dla tego, iżeś świątynię moję zgwałciło wszelakiem obrażeniem twojem, i wszelakiemi obrzydłościami twemi: ja też połamię, a nie przepuści oko moje, a nie zlituję się.
###### **Ez 5,12**
 Trzecia część ciebie morem pomrze, i głodem wyginie w pośrodku ciebie: a trzecia część ciebie od miecza polezę około ciebie: a trzecią część twoję na wszelki wiatr rozproszę, a miecza dobędę za nimi.
###### **Ez 5,13**
 I wykonam zapalczywość moję i uspokoję rozgniewanie moję na nie, a ucieszę się: i doznają, że ja Pan mówiłem w rzewniwości mojej, gdy wykonam rozgniewanie moje w nich.
###### **Ez 5,14**
 I dam cię na spustoszenie i na hańbę narodom, które są około ciebie przed obliczem każdego mijającego.
###### **Ez 5,15**
 I będziesz hańbą, i bluźnieniem, przykładem, i zdumieniem między narodami, które są około ciebie, gdy uczynię w tobie sądy w zapalczywości, i w rozgniewaniu, i w fukach gniewliwych.
###### **Ez 5,16**
 Ja Pan mówiłem: Gdy wypuszczę strzały głodu złe na nie: które będą śmiertelne, a które wypuszczę, abych was wytracił: i głód zbiorę na was, a połamię u was laskę chleba.
###### **Ez 5,17**
 I puszczę na was głód, i zwierzęta złe, aż do wytracenia: a powietrze i krew przechodzić będą przez cię, i miecz przywiodę na cię. Ja Pan mówiłem.
