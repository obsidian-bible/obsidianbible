# Hbr 4 BT5
###### **Hbr 4,1**
 Lękajmy się przeto, gdy jeszcze trwa obietnica wejścia do Jego odpoczynku, aby ktoś z was nie mniemał, iż jest jej pozbawiony.
###### **Hbr 4,2**
 Albowiem i my otrzymaliśmy dobrą nowinę, tak jak i tamci, lecz tamtym słowo usłyszane nie było pomocne, gdyż nie łączyli się przez wiarę z tymi, którzy je usłyszeli.
###### **Hbr 4,3**
 Wchodzimy istotnie do odpoczynku my, którzy uwierzyliśmy, jak to powiedział:Toteż przysiągłem w swym gniewie:Nie wejdą do mego odpoczynku, aczkolwiek dzieła były dokonane od stworzenia świata.
###### **Hbr 4,4**
 Powiedział bowiem [Bóg] na pewnym miejscu o siódmym dniu w ten sposób: I odpoczął Bóg w siódmym dniu po wszystkich dziełach swoich.
###### **Hbr 4,5**
 I znowu tamże: Nie wejdą do mego odpoczynku.
###### **Hbr 4,6**
 Wynika więc z tego, że wejdą tam niektórzy, gdyż ci, co wcześniej otrzymali dobrą nowinę, nie weszli z powodu nieposłuszeństwa,
###### **Hbr 4,7**
 dlatego Bóg na nowo wyznacza pewien dzień – dziś – po upływie dłuższego czasu, mówiąc przez Dawida, jak to przedtem zostało powiedziane:Dziś, jeśli głos Jego usłyszycie, nie zatwardzajcie serc waszych!
###### **Hbr 4,8**
 Gdyby bowiem Jozue wprowadził ich do odpoczynku, nie mówiłby potem o innym dniu.
###### **Hbr 4,9**
 A zatem pozostaje odpoczynek szabatu dla ludu Bożego.
###### **Hbr 4,10**
 Kto bowiem wszedł do jego odpoczynku, odpocznie po swych czynach, jak Bóg po swoich.
###### **Hbr 4,11**
 Śpieszmy się więc wejść do owego odpoczynku, aby nikt nie poszedł za tym samym przykładem nieposłuszeństwa.
###### **Hbr 4,12**
 Żywe bowiem jest słowo Boże, skuteczne i ostrzejsze niż wszelki miecz obosieczny, przenikające aż do rozdzielenia duszy i ducha, stawów i szpiku, zdolne osądzić pragnienia i myśli serca.
###### **Hbr 4,13**
 Nie ma stworzenia, które by dla Niego było niewidzialne; przeciwnie, wszystko odkryte jest i odsłonięte przed oczami Tego, któremu musimy zdać rachunek.
###### **Hbr 4,14**
 Mając więc arcykapłana wielkiego, który przeszedł przez niebiosa, Jezusa, Syna Bożego, trwajmy mocno w wyznawaniu wiary.
###### **Hbr 4,15**
 Nie takiego bowiem mamy arcykapłana, który by nie mógł współczuć naszym słabościom, lecz poddanego próbie pod każdym względem podobnie [jak my] – z wyjątkiem grzechu.
###### **Hbr 4,16**
 Przybliżmy się więc z ufnością do tronu łaski, abyśmy doznali miłosierdzia i znaleźli łaskę pomocy w stosownej chwili.
# Hbr 4 PAU
###### **Hbr 4,1**
 Skoro zatem trwa nadal obietnica wejścia do Jego odpoczynku, strzeżmy się, aby ktoś z was nie został jej pozbawiony!
###### **Hbr 4,2**
 I my bowiem otrzymaliśmy radosną nowinę, podobnie jak tamci. Tamtym jednak usłyszane słowo nie przyniosło żadnej korzyści, ponieważ nie pozostali w jedności z tymi, co słuchali.
###### **Hbr 4,3**
 My zaś, którzy uwierzyliśmy, wchodzimy do odpoczynku! Powiedział bowiem: Toteż przysiągłem zagniewany, że nie wejdą do mego odpoczynku, chociaż dzieła Jego były już dokonane od początku świata.
###### **Hbr 4,4**
 Powiedziano gdzieś na temat siódmego dnia w ten sposób: W siódmym dniu Bóg odpoczął po całym swoim dziele.
###### **Hbr 4,5**
 Tutaj natomiast: Nie wejdą do mego odpoczynku.
###### **Hbr 4,6**
 Tak więc, ponieważ niektórzy mają do niego wejść, a ci, którzy wcześniej otrzymali dobrą nowinę, nie weszli z powodu swej niewierności,
###### **Hbr 4,7**
 Bóg ustala ponownie pewien dzień - dzisiaj - mówiąc znacznie później przez Dawida w przytoczonym już proroctwie: Dzisiaj, jeśli głos Jego usłyszycie, nie zatwardzajcie serc waszych!
###### **Hbr 4,8**
 Gdyby bowiem Jozue zapewnił im odpoczynek, Bóg nie mówiłby po tylu dniach o jakimś innym.
###### **Hbr 4,9**
 Pozostaje więc odpoczynek sobotni dla ludu Bożego.
###### **Hbr 4,10**
 Ten bowiem, kto wszedł do Jego odpoczynku, podobnie jak Bóg odpoczął od swoich dzieł.
###### **Hbr 4,11**
 Starajmy się więc wejść do tego odpoczynku, aby już nikogo nie skłonił do upadku ów przykład niewierności!
###### **Hbr 4,12**
 Słowo Boże jest bowiem żywe i skuteczne, ostrzejsze od każdego obosiecznego miecza. Przenika ono aż do rozdzielenia duszy i ducha, stawów i szpiku, rozsądza myśli i zamiary serca.
###### **Hbr 4,13**
 Żadne stworzenie nie ukryje się przed nim, gdyż wszystko jest odkryte i jawne oczom Tego, któremu musimy zdać sprawę.
###### **Hbr 4,14**
 Skoro więc nasz najwyższy kapłan, Jezus, Syn Boży, jest tak wielki i dotarł do nieba, trzymajmy się mocno wyznania wiary.
###### **Hbr 4,15**
 Nie takiego bowiem mamy najwyższego kapłana, który nie mógłby współczuć nam w słabościach. Przeciwnie, podobnie jak my doświadczył On wszystkiego - oprócz grzechu.
###### **Hbr 4,16**
 Śmiało więc zbliżmy się do tronu łaski, aby otrzymać miłosierdzie i znaleźć łaskę w stosownej chwili!
# Hbr 4 BP
###### **Hbr 4,1**
 Lękajmy się więc, aby - skoro trwa jeszcze obietnica wejścia do tego odpoczynku - nie okazało się, że ktoś z was przyszedł za późno.
###### **Hbr 4,2**
 Otrzymaliśmy bowiem dobrą nowinę tak samo jak i oni, lecz im nie pomogło usłyszane słowo, ponieważ nie połączyło się z wiarą tych, co słuchali.
###### **Hbr 4,3**
 Wchodzimy bowiem do odpoczynku jako ci, którzy uwierzyli, zgodnie z tym, co powiedział [Bóg]: "Przysiągłem w mym gniewie: Na pewno nie wejdą do mego odpoczynku", chociaż Jego dzieła istnieją od założenia świata.
###### **Hbr 4,4**
 Powiedział gdzieś bowiem o tym siódmym dniu: "I odpoczął Bóg w siódmym dniu od wszystkich swych dzieł".
###### **Hbr 4,5**
 A tu znów: "Na pewno nie wejdą do mojego odpoczynku".
###### **Hbr 4,6**
 Ponieważ więc ktoś jeszcze ma wejść do niego, a ci, którym najpierw zwiastowano dobrą nowinę, nie weszli z powodu niewiary,
###### **Hbr 4,7**
 zatem znowu wyznacza pewien dzień - "dzisiaj" - u Dawida, po długim czasie mówiąc tak, jak było powiedziane przedtem: "Dzisiaj, gdy usłyszycie głos Jego, nie znieczulajcie serc waszych".
###### **Hbr 4,8**
 Gdyby bowiem Jozue dał im odpoczynek, nie byłoby mowy po tylu dniach o innym.
###### **Hbr 4,9**
 Przeto pozostaje jeszcze odpoczynek sobotni dla ludu Bożego.
###### **Hbr 4,10**
 Ten bowiem, kto wejdzie do Jego odpoczynku, odpocznie od swych czynów, tak jak Bóg od swych własnych.
###### **Hbr 4,11**
 Pospieszmy się więc z wejściem do owego odpoczynku, żeby ktoś nie zginął przez niewiarę, jak to zostało pokazane na przykładzie nieposłuszeństwa.
###### **Hbr 4,12**
 Przecież słowo Boże jest żywe, skuteczne i ostrzejsze niż obosieczny miecz i tak przenikliwe, że aż rozdziela spojenia i rdzenie duszy i ducha, a zdolne jest rozsądzać myśli i zamiary serca.
###### **Hbr 4,13**
 Żadne stworzenie nie ukryje się przed Nim, lecz wszystko jest obnażone i odsłonięte dla oczu Tego, przed którym mamy zdać sprawę.
###### **Hbr 4,14**
 Mając zatem wielkiego arcykapłana, który wszedł do nieba, Jezusa, Syna Bożego, mocno trwajmy przy wierze.
###### **Hbr 4,15**
 Nie mamy przecież arcykapłana, który nie potrafiłby współczuć w naszych słabościach, ale takiego, który podobnie jak my doznał tego wszystkiego, czego my doznajemy z wyjątkiem grzechu.
###### **Hbr 4,16**
 Przystąpmy więc z ufnością do tronu łaski, abyśmy otrzymali zmiłowanie i znaleźli pomocną łaskę w potrzebie.
# Hbr 4 BR
###### **Hbr 4,1**
 Powinniśmy się tedy lękać, abyśmy nie musieli sądzić, że nie wolno nam korzystać z odpocznienia Jezusa, gdy jeszcze trwa obietnica wejścia do tego odpocznienia.
###### **Hbr 4,2**
 Albowiem myśmy również usłyszeli dobrą nowinę, podobnie jak ongiś tamci na pustyni. Lecz tamtym słowo to na nic się nie zdało, gdyż nie łączyli się przez wiarę z tymi, którzy je słyszeli.
###### **Hbr 4,3**
 Otóż my wejdziemy do owego odpocznienia, ponieważ przejęliśmy się tymi oto Jego słowami: I poprzysiągłem w gniewie, że nigdy nie wejdą tam, gdzie mogliby odpocząć razem ze Mną. Trzeba jednak pamiętać, że dzieła Jego były dokonane, już gdy świat zaczynał istnieć.
###### **Hbr 4,4**
 O siódmym dniu powiedział bowiem Bóg w ten sposób: A dnia siódmego odpoczął Bóg po wszystkich swoich trudach.
###### **Hbr 4,5**
 Zresztą przy tej okazji znów ostrzegał: Nie wejdą tam, gdzie mogliby odpocząć razem ze Mną.
###### **Hbr 4,6**
 Wynika z tego, że wejdą tam inni, skoro nie weszli ci, którzy otrzymawszy wcześniej dobrą nowinę nie weszli z powodu swego nieposłuszeństwa.
###### **Hbr 4,7**
 Dlatego Bóg wyznacza ponownie swoiste dzisiaj, powtarzając po upływie dłuższego czasu przez usta Dawida słowa już dawno przedtem wypowiedziane: Dziś, gdy usłyszycie głos Jego, nie zamykajcie serc waszych.
###### **Hbr 4,8**
 Gdyby Jozue zdołał wprowadzić lud do miejsca owego odpocznienia, nie mówiłby chyba potem [Bóg] o jeszcze jednym dniu.
###### **Hbr 4,9**
 Tak więc lud Boży cieszy się posiadaniem odpoczynku szabatniego [na wzór owego pierwotnego odpocznienia Boga].
###### **Hbr 4,10**
 I tak kto wejdzie tam, gdzie odpoczywa się z Bogiem, znajdzie wytchnienie po trudach swego życia, tak jak Bóg odpoczął po swoich dziełach.
###### **Hbr 4,11**
 Starajmy się przeto wejść do owego odpocznienia; zabiegajmy o to, żeby nikt nie poszedł za przykładem tych, którzy zbuntowali się na pustyni.
###### **Hbr 4,12**
 Słowo Boże jest bowiem żywe i skuteczne, ostrzejsze nad wszelki miecz o dwu ostrzach. Dlatego przenika aż tam, gdzie duch styka się z duszą, a szpik ze stawem kości, i osądza najskrytsze pragnienia i zamysły ludzkiego serca.
###### **Hbr 4,13**
 Żadne stworzenie nie może ukryć się przed Jego wejrzeniem; wszystko jest jawne i odkryte wobec Tego, przed którym musimy zdać sprawę.
###### **Hbr 4,14**
 Mając tedy w Jezusie, Synu Bożym, wielkiego arcykapłana, który przeniknął nawet niebiosa, trwajmy mocno przy naszym wyznaniu wiary.
###### **Hbr 4,15**
 Mamy bowiem nie takiego arcykapłana, który nie byłby w stanie współczuć naszym słabościom, lecz takiego, który - jeśli pominie się grzech - podobnie jak my jest obeznany z wszelkimi słabościami.
###### **Hbr 4,16**
 Przystąpmy więc pełni ufności do tronu łaski, by doznać miłosierdzia i łaski, gdy będziemy w potrzebie
# Hbr 4 WUJ
###### **Hbr 4,1**
 Przetoż się bójmy, aby snąć zaniechawszy obietnice weszcia do odpoczynienia jego, nie zdał się który z was, że go niemasz.
###### **Hbr 4,2**
 Abowiem i nam opowiedziano jest, jako i onym. Ale nie pomogła onym mowa słuchania, nie przymieszana do wiary tego co słyszeli.
###### **Hbr 4,3**
 Abowiem wnidziemy do odpoczynienia, którzyśmy uwierzyli: jako powiedział: Jako, przysiągł w gniewie moim, jeśliż wnidą do odpoczynienia mojego: choć dzieła od założenia świata były dokończone.
###### **Hbr 4,4**
 Abowiem rzekł na niektórem miejscu o siódmym dniu tak: I odpoczął Bóg dnia siódmego od wszystkich dzieł swoich.
###### **Hbr 4,5**
 A na tem zaś: Jeśli wnidą do odpoczynienia mojego.
###### **Hbr 4,6**
 Gdyż tedy zostawa, że niektórzy mają wniść do onego, a ci, którym pierwej opowiedziano było, nie weszli dla niedowiarstwa:
###### **Hbr 4,7**
 Zasię naznacza dzień niektóry: Dzisia, mówiąc przez Dawida, po tak długim czasie, jako się wyżej rzekło. Dziś jeślibyście głos jego usłyszeli: nie zatwardzajcie serc waszych.
###### **Hbr 4,8**
 Abowiem, jeśliby im był Jezus dał odpoczynienie, nigdyby o inszym dniu napotem nie mówił.
###### **Hbr 4,9**
 A tak zostawa sobotowanie ludowi Bożemu.
###### **Hbr 4,10**
 Abowiem który wszedł do odpoczynienia jego, ten też odpoczynął od dziełów swych, jako Bóg od swoich.
###### **Hbr 4,11**
 Spieszmy się tedy, abyśmy weszli do onego odpoczynienia: iżby kto w tenże przykład niedowiarstwa nie wpadł.
###### **Hbr 4,12**
 Bo żywa jest mowa Boża i skuteczna, i przeraźliwsza niżeli wszelaki miecz po obu stron ostry: i przenikająca aż do rozdzielenia dusze i ducha, stawów też i szpików, i rozeznawająca myśli i przedsięwzięcia serdeczne.
###### **Hbr 4,13**
 A niemasz żadnego stworzenia niewidzialnego przed oblicznością jego: lecz wszystkie rzeczy obnażone są i odkryte oczom jego, do którego nam mowa.
###### **Hbr 4,14**
 Mając tedy nawyższego kapłana wielkiego, który przeszedł niebiosa Jezusa Syna Bożego: trzymajmy się wyznania.
###### **Hbr 4,15**
 Abowiem nie mamy nawyższego kapłana, któryby się nie mógł ulitować nad krewkościami naszemi: lecz kuszonego we wszystkiem na podobieństwo oprócz grzechu.
###### **Hbr 4,16**
 Przystąpmy tedy z ufnością do stolice łaski: abyśmy otrzymali miłosierdzie, i łaskę naleźli ku pogodnemu ratunku.
# Hbr 4 STERN
###### **Hbr 4,1**
 Dlatego niech przerażeniem napawa nas ta możliwość, że choć trwa obietnica wejścia do Jego odpoczynku, to o każdym z was może się okazać, że zawiódł;
###### **Hbr 4,2**
 bo Dobra Nowina była głoszona również nam tak samo jak i im. Ale orędzie, które słyszeli, na nic dobrego im się nie zdało, bo ci, którzy je słyszeli, nie połączyli go z ufnością.
###### **Hbr 4,3**
 Bo to my, którzy zaufaliśmy, wchodzimy do odpoczynku. Jest tak, jak On rzekł: "W gniewie poprzysiągłem, że nie wejdą do odpoczynku mego". Poprzysiągł On to, mimo że dzieła Jego istniały od założenia wszechświata.
###### **Hbr 4,4**
 Bo w pewnym miejscu tak powiedziano o siódmym dniu: "I odpoczął Bóg siódmego dnia od wszystkich dzieł swoich".
###### **Hbr 4,5**
 I jeszcze raz obecny nasz tekst mówi: "Nie wejdą do odpoczynku mego".
###### **Hbr 4,6**
 Skoro zatem dla niektórych wciąż pozostaje perspektywa wejścia do niego, ci zaś, którzy wcześniej otrzymali Dobrą Nowinę, nie weszli,
###### **Hbr 4,7**
 to ponownie ustanawia On pewien dzień: "Dzisiaj", mówiąc przez Dawida, już dużo później, w tekście już podanym: "Dzisiaj, jeśli usłyszycie głos Boży, nie zatwardzajcie swoich serc".
###### **Hbr 4,8**
 Bo jeśliby J'hoszua dał im odpoczynek, nie mówiłby później Bóg o innym "dniu".
###### **Hbr 4,9**
 Pozostaje zatem jeszcze dla ludu Bożego przestrzeganie szabbatu.
###### **Hbr 4,10**
 Bo kto wszedł do Bożego odpoczynku, ten również odpoczął od swoich dzieł, tak jak Bóg od swoich.
###### **Hbr 4,11**
 Czyńmy zatem, co w naszej mocy, aby wejść do tego odpoczynku, ażeby nikt nie zawiódł wskutek nieposłuszeństwa tego samego rodzaju.
###### **Hbr 4,12**
 Doprawdy, Słowo Boże jest żywe! Ono działa, a jest ostrzejsze niż wszelki miecz obosieczny - dociera wprost do styku duszy z duchem i stawów ze szpikiem i prędko osądza wewnętrzne myśli i postawy serca.
###### **Hbr 4,13**
 Przed Bogiem nie ukryje się nic, co stworzone, lecz wszystko jest obnażone i otwarte przed oczami Tego, przed którym musimy zdać sprawę.
###### **Hbr 4,14**
 Ponieważ zatem mamy wielkiego kohena gadola, który przeszedł przez najwyższe niebo, Jeszuę, Syna Bożego, trzymajmy się mocno tego, co wyznajemy jako prawdę.
###### **Hbr 4,15**
 Bo nie takiego mamy kohena gadola, który nie jest w stanie rozumieć naszych słabości; bo pod każdym względem był kuszony tak jak my, różnica w tym jedynie, że nie grzeszył.
###### **Hbr 4,16**
 Dlatego ufnie zbliżmy się do tronu, z którego Bóg udziela łaski, abyśmy otrzymali miłosierdzie i znaleźli łaskę, gdy będziemy w potrzebie.
# Hbr 4 TRO
###### **Hbr 4,1**
 **φοβηθωμεν** *fobēthōmen* Balibyśmy się – Lękalibyście się [[G5399]] WTV-AOS-1P **ουν** *oun* więc [[G3767]] [[CONJ]] **μηποτε** *mēpote* by czasem nie [[G3379]] [[ADV]] **καταλειπομενης** *kataleipomenēs* która jest pozostawioną – która jest opuszczoną [[G2641]] WTV-PPP-GSF **επαγγελιας** *epangelias* obietnica [[G1860]] [[N-GSF]] **εισελθειν** *eiselthein* (by) wejść [[G1525]] [[V-2AAN]] **εις** *eis* do [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **καταπαυσιν** *katapausin* odpoczynku – odpocznienia [[G2663]] WTN-ASF **αυτου** *autou* Jego [[G846]] [[P-GSM]] **δοκη** *dokē* uważałby – myślałby [[G1380]] WTV-PAS-3S **τις** *tis* ktoś [[G5100]] WTX-NSM **εξ** *eks* z [[G1537]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **υστερηκεναι** *hysterēkenai* mieć braki [[G5302]] WTV-RAN
###### **Hbr 4,2**
 **και** *kai* i [[G2532]] [[CONJ]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εσμεν** *esmen* jesteśmy [[G2070]] WTV-PXI-1P **ευηγγελισμενοι** *euēngelismenoi* którzy są odbiorcami dobrej nowiny [[G2097]] WTV-RPP-NPM **καθαπερ** *kathaper* tak, jak [[G2509]] [[ADV]] **κακεινοι** *kakeinoi* i ci [[G2548]] WTD-NPM-C **αλλ** *all* ale [[G235]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ωφελησεν** *ōfelēsen* pomogło [[G5623]] [[V-AAI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **λογος** *logos* słowo [[G3056]] [[N-NSM]] **της** *tēs* [[G3588]] [[T-GSF]] **ακοης** *akoēs* wieści – słuchania [[G189]] [[N-GSF]] **εκεινους** *ekeinous* tym [[G1565]] WTD-APM **μη** *mē* nie [[G3361]] [[PRT-N]] **συγκεκραμενος** *sygkekramenos* który jest złączony – który jest zjednoczony [[G4786]] WTV-RPP-NSM **τη** *tē* (w) [[G3588]] WTT-DSF **πιστει** *pistei* wierze [[G4102]] [[N-DSF]] **τοις** *tois* (z tymi) [[G3588]] WTT-DPM **ακουσασιν** *akousasin* którzy usłyszeli [[G191]] WTV-AAP-DPM
###### **Hbr 4,3**
 **εισερχομεθα** *eiserchometha* Wchodzimy [[G1525]] WTV-PNI-1P **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εις** *eis* do [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **καταπαυσιν** *katapausin* odpoczynku – odpocznienia [[G2663]] WTN-ASF **οι** *hoi* [[G3588]] WTT-NPM **πιστευσαντες** *pisteusantes* uwierzywszy [[G4100]] WTV-AAP-NPM **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **ειρηκεν** *eirēken* powiedział [[G2046]] WTV-RAI-3S-ATT **ως** *hōs* jak [[G5613]] [[ADV]] **ωμοσα** *ōmosa* przysiągłem [[G3660]] WTV-AAI-1S **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **οργη** *orgē* gniewie [[G3709]] [[N-DSF]] **μου** *mou* moim [[G3450]] WTP-1GS **ει** *ei* jeśli [[G1487]] WTCOND **εισελευσονται** *eiseleusontai* wejdą [[G1525]] WTV-FDI-3P **εις** *eis* do [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **καταπαυσιν** *katapausin* odpoczynku – odpocznienia [[G2663]] WTN-ASF **μου** *mou* mojego [[G3450]] WTP-1GS **καιτοι** *kaitoi* pomimo [[G2543]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPN **εργων** *ergōn* dzieł – uczynków [[G2041]] WTN-GPN **απο** *apo* od [[G575]] [[PREP]] **καταβολης** *katabolēs* założenia [[G2602]] [[N-GSF]] **κοσμου** *kosmou* świata [[G2889]] [[N-GSM]] **γενηθεντων** *genēthentōn* które stały się [[G1096]] WTV-AOP-GPN
###### **Hbr 4,4**
 **ειρηκεν** *eirēken* Powiedział [[G2046]] WTV-RAI-3S-ATT **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **που** *pou* gdzieś [[G4225]] WTPRT **περι** *peri* odnośnie [[G4012]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **εβδομης** *hebdomēs* siódmego [[G1442]] WTA-GSF **ουτως** *houtōs* tak [[G3779]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **κατεπαυσεν** *katepausen* odpoczął [[G2664]] [[V-AAI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **ημερα** *hēmera* dniu [[G2250]] [[N-DSF]] **τη** *tē* [[G3588]] WTT-DSF **εβδομη** *hebdomē* siódmym [[G1442]] WTA-DSF **απο** *apo* od [[G575]] [[PREP]] **παντων** *pantōn* wszystkich [[G3956]] WTA-GPN **των** *tōn* [[G3588]] WTT-GPN **εργων** *ergōn* dzieł – uczynków [[G2041]] WTN-GPN **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Hbr 4,5**
 **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **τουτω** *toutō* tym [[G5129]] WTD-DSM **παλιν** *palin* znów [[G3825]] [[ADV]] **ει** *ei* jeśli [[G1487]] WTCOND **εισελευσονται** *eiseleusontai* wejdą [[G1525]] WTV-FDI-3P **εις** *eis* do [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **καταπαυσιν** *katapausin* odpoczynku – odpocznienia [[G2663]] WTN-ASF **μου** *mou* mojego [[G3450]] WTP-1GS
###### **Hbr 4,6**
 **επει** *epei* skoro – jako, że [[G1893]] [[CONJ]] **ουν** *oun* więc [[G3767]] [[CONJ]] **απολειπεται** *apoleipetai* jest pozostające [[G620]] WTV-PPI-3S **τινας** *tinas* (aby) niektórzy – (aby) jacyś [[G5100]] WTX-APM **εισελθειν** *eiselthein* wejść [[G1525]] [[V-2AAN]] **εις** *eis* do [[G1519]] [[PREP]] **αυτην** *autēn* tego [[G846]] [[P-ASF]] **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* (ci) [[G3588]] WTT-NPM **προτερον** *proteron* wcześniej [[G4386]] [[ADV]] **ευαγγελισθεντες** *euangelisthentes* którym ogłoszono dobrą nowinę [[G2097]] WTV-APP-NPM **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εισηλθον** *eisēlthon* weszli [[G1525]] WTV-2AAI-3P **δι** *di* z powodu [[G1223]] [[PREP]] **απειθειαν** *apeitheian* nieposłuszeństwa – nieuległości [[G543]] WTN-ASF
###### **Hbr 4,7**
 **παλιν** *palin* znowu [[G3825]] [[ADV]] **τινα** *tina* jakiś [[G5100]] WTX-ASF **οριζει** *horizei* ustanawia – ustala [[G3724]] WTV-PAI-3S **ημεραν** *hēmeran* dzień [[G2250]] WTN-ASF **σημερον** *sēmeron* dzisiaj [[G4594]] [[ADV]] **εν** *en* przez [[G1722]] [[PREP]] **δαβιδ** *dabid* Dawida – [umiłowany] [[G1138]] [[N-PRI]] **λεγων** *legōn* mówiąc [[G3004]] [[V-PAP-NSM]] **μετα** *meta* po [[G3326]] [[PREP]] **τοσουτον** *tosouton* tak wielkim [[G5118]] WTD-ASM **χρονον** *chronon* czasie [[G5550]] [[N-ASM]] **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **ειρηται** *eirētai* jest powiedziane [[G2046]] WTV-RPI-3S **σημερον** *sēmeron* dzisiaj [[G4594]] [[ADV]] **εαν** *ean* jeśli [[G1437]] WTCOND **της** *tēs* [[G3588]] [[T-GSF]] **φωνης** *fōnēs* głosu [[G5456]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ακουσητε** *akousēte* usłyszelibyście [[G191]] WTV-AAS-2P **μη** *mē* nie [[G3361]] [[PRT-N]] **σκληρυνητε** *sklērynēte* zatwardzalibyście – czynilibyście twardym [[G4645]] WTV-PAS-2P **τας** *tas* [[G3588]] WTT-APF **καρδιας** *kardias* serc [[G2588]] WTN-APF **υμων** *hymōn* waszych [[G5216]] WTP-2GP
###### **Hbr 4,8**
 **ει** *ei* Jeśli [[G1487]] WTCOND **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **αυτους** *autous* im [[G846]] [[P-APM]] **ιησους** *iēsous* Jezus – [JHWH jest zbawieniem] [[G2424]] [[N-NSM]] **κατεπαυσεν** *katepausen* zapewnił odpoczynek [[G2664]] [[V-AAI-3S]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **αν** *an* (kiedy)kolwiek [[G302]] WTPRT **περι** *peri* o [[G4012]] [[PREP]] **αλλης** *allēs* innym [[G243]] WTA-GSF **ελαλει** *elalei* mówił [[G2980]] WTV-IAI-3S **μετα** *meta* po [[G3326]] [[PREP]] **ταυτα** *tauta* tych [[G5023]] WTD-APN **ημερας** *hēmeras* dniu [[G2250]] [[N-GSF]]
###### **Hbr 4,9**
 **αρα** *ara* Zatem – Dlatego [[G686]] WTPRT **απολειπεται** *apoleipetai* jest pozostającym [[G620]] WTV-PPI-3S **σαββατισμος** *sabbatismos* odpocznienie szabatowe – odpocznienie [tygodniowe] [[G4520]] [[N-NSM]] **τω** *tō* [[G3588]] WTT-DSM **λαω** *laō* ludowi [[G2992]] WTN-DSM **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **Hbr 4,10**
 **ο** *ho* (ten) [[G3588]] [[T-NSM]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εισελθων** *eiselthōn* wszedłszy [[G1525]] WTV-2AAP-NSM **εις** *eis* do [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **καταπαυσιν** *katapausin* odpoczynku – odpocznienia [[G2663]] WTN-ASF **αυτου** *autou* Jego [[G846]] [[P-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **αυτος** *autos* sam [[G846]] WTP-NSM **κατεπαυσεν** *katepausen* odpoczął [[G2664]] [[V-AAI-3S]] **απο** *apo* od [[G575]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **εργων** *ergōn* dzieł – uczynków [[G2041]] WTN-GPN **αυτου** *autou* jego [[G846]] [[P-GSM]] **ωσπερ** *hōsper* tak, jak [[G5618]] [[ADV]] **απο** *apo* od [[G575]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **ιδιων** *idiōn* własnych – swoich [[G2398]] WTA-GPN **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]]
###### **Hbr 4,11**
 **σπουδασωμεν** *spoudasōmen* Postaralibyśmy się – Bylibyśmy gorliwi [[G4704]] WTV-AAS-1P **ουν** *oun* więc [[G3767]] [[CONJ]] **εισελθειν** *eiselthein* wejść [[G1525]] [[V-2AAN]] **εις** *eis* do [[G1519]] [[PREP]] **εκεινην** *ekeinēn* tego [[G1565]] WTD-ASF **την** *tēn* [[G3588]] WTT-ASF **καταπαυσιν** *katapausin* odpoczynku – odpocznienia [[G2663]] WTN-ASF **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **αυτω** *autō* tym samym [[G846]] WTP-DSN **τις** *tis* ktoś [[G5100]] WTX-NSM **υποδειγματι** *hypodeigmati* przykładem [[G5262]] WTN-DSN **πεση** *pesē* upadłby [[G4098]] WTV-2AAS-3S **της** *tēs* [[G3588]] [[T-GSF]] **απειθειας** *apeitheias* nieposłuszeństwu – nieuległości [[G543]] [[N-GSF]]
###### **Hbr 4,12**
 **ζων** *zōn* Żyjące [[G2198]] [[V-PAP-NSM]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **λογος** *logos* Słowo [[G3056]] [[N-NSM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **ενεργης** *energēs* sprawne [[G1756]] [[A-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **τομωτερος** *tomōteros* ostrzejsze – bardziej tnące [[G5114]] [[A-NSM]]-C **υπερ** *hyper* niż [[G5228]] [[PREP]] **πασαν** *pasan* każdy [[G3956]] WTA-ASF **μαχαιραν** *machairan* miecz [[G3162]] WTN-ASF **διστομον** *distomon* obosieczny [[G1366]] WTA-ASF **και** *kai* i [[G2532]] [[CONJ]] **διικνουμενος** *diiknoumenos* przenikające [[G1338]] WTV-PNP-NSM **αχρι** *achri* aż do [[G891]] [[PREP]] **μερισμου** *merismou* podziału [[G3311]] [[N-GSM]] **ψυχης** *psychēs* duszy – życia [[G5590]] [[N-GSF]] **τε** *te* zarówno – także [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **πνευματος** *pneumatos* ducha [[G4151]] [[N-GSN]] **αρμων** *harmōn* stawów [[G719]] WTN-GPM **τε** *te* zarówno – także [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **μυελων** *myelōn* szpików [[G3452]] WTN-GPM **και** *kai* i [[G2532]] [[CONJ]] **κριτικος** *kritikos* zdolne do osądzenia [[G2924]] [[A-NSM]] **ενθυμησεων** *enthymēseōn* zamysłów [[G1761]] WTN-GPF **και** *kai* i [[G2532]] [[CONJ]] **εννοιων** *ennoiōn* myśli – rozumień [[G1771]] WTN-GPF **καρδιας** *kardias* serca [[G2588]] [[N-GSF]]
###### **Hbr 4,13**
 **και** *kai* i [[G2532]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **κτισις** *ktisis* stworzenie [[G2937]] [[N-NSF]] **αφανης** *afanēs* niewidoczne [[G852]] WTA-NSF **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **αυτου** *autou* nim [[G846]] [[P-GSM]] **παντα** *panta* wszystkie [[G3956]] WTA-NPN **δε** *de* zaś [[G1161]] [[CONJ]] **γυμνα** *gymna* nagie [[G1131]] WTA-NPN **και** *kai* i [[G2532]] [[CONJ]] **τετραχηλισμενα** *tetrachēlismena* mające odsłoniętą szyję [[G5136]] WTV-RPP-NPN **τοις** *tois* [[G3588]] WTT-DPM **οφθαλμοις** *ofthalmois* oczyma [[G3788]] WTN-DPM **αυτου** *autou* jego [[G846]] [[P-GSM]] **προς** *pros* względem [[G4314]] [[PREP]] **ον** *hon* którego [[G3739]] WTR-ASM **ημιν** *hēmin* nam [[G2254]] WTP-1DP **ο** *ho* [[G3588]] [[T-NSM]] **λογος** *logos* słowo – sprawa [[G3056]] [[N-NSM]]
###### **Hbr 4,14**
 **εχοντες** *echontes* Mając [[G2192]] WTV-PAP-NPM **ουν** *oun* więc [[G3767]] [[CONJ]] **αρχιερεα** *archierea* arcykapłana [[G749]] [[N-ASM]] **μεγαν** *megan* wielkiego [[G3173]] WTA-ASM **διεληλυθοτα** *dielēlythota* który przyszedł [[G1330]] WTV-2RAP-ASM **τους** *tous* (do) [[G3588]] WTT-APM **ουρανους** *ouranous* niebios [[G3772]] [[N-APM]] **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]] **τον** *ton* [[G3588]] [[T-ASM]] **υιον** *hyion* Syna [[G5207]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **κρατωμεν** *kratōmen* chwycilibyśmy [[G2902]] WTV-PAS-1P **της** *tēs* [[G3588]] [[T-GSF]] **ομολογιας** *homologias* wyznanie – przyznanie [[G3671]] [[N-GSF]]
###### **Hbr 4,15**
 **ου** *ou* nie [[G3756]] [[PRT-N]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εχομεν** *echomen* mamy [[G2192]] WTV-PAI-1P **αρχιερεα** *archierea* arcykapłana [[G749]] [[N-ASM]] **μη** *mē* nie [[G3361]] [[PRT-N]] **δυναμενον** *dynamenon* mogącego [[G1410]] WTV-PNP-ASM **συμπαθησαι** *sympathēsai* współczuć [[G4834]] [[V-AAN]] **ταις** *tais* (w) [[G3588]] WTT-DPF **ασθενειαις** *astheneiais* słabościach – bezsiłach [[G769]] WTN-DPF **ημων** *hēmōn* naszych [[G2257]] WTP-1GP **πεπειρασμενον** *pepeirasmenon* który jest doświadczony – który jest wypróbowany [[G3985]] WTV-RPP-ASM **δε** *de* zaś [[G1161]] [[CONJ]] **κατα** *kata* we [[G2596]] [[PREP]] **παντα** *panta* wszystkim [[G3956]] WTA-APN **καθ** *kath* według [[G2596]] [[PREP]] **ομοιοτητα** *homoiotēta* podobieństwa [[G3665]] WTN-ASF **χωρις** *chōris* oprócz – z wyjątkiem [[G5565]] [[ADV]] **αμαρτιας** *hamartias* grzechu [[G266]] [[N-GSF]]
###### **Hbr 4,16**
 **προσερχωμεθα** *proserchōmetha* Podchodzilibyśmy – Zbliżalibyśmy się [[G4334]] WTV-PNS-1P **ουν** *oun* więc [[G3767]] [[CONJ]] **μετα** *meta* ze [[G3326]] [[PREP]] **παρρησιας** *parrēsias* śmiałością [[G3954]] [[N-GSF]] **τω** *tō* (do) [[G3588]] WTT-DSM **θρονω** *thronō* tronu [[G2362]] WTN-DSM **της** *tēs* [[G3588]] [[T-GSF]] **χαριτος** *charitos* łaski [[G5485]] [[N-GSF]] **ινα** *hina* aby [[G2443]] [[CONJ]] **λαβωμεν** *labōmen* otrzymalibyśmy [[G2983]] WTV-2AAS-1P **ελεον** *eleon* miłosierdzie – litość [[G1656]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **χαριν** *charin* łaskę [[G5485]] WTN-ASF **ευρωμεν** *heurōmen* znaleźlibyśmy [[G2147]] WTV-2AAS-1P **εις** *eis* w [[G1519]] [[PREP]] **ευκαιρον** *eukairon* odpowiednim czasie – stosownym czasie [[G2121]] WTA-ASF **βοηθειαν** *boētheian* pomoc [[G996]] WTN-ASF
