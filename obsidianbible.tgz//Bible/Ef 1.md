# Ef 1 BT5
###### **Ef 1,1**
 Paweł, z woli Bożej apostoł Chrystusa Jezusa – do świętych, którzy są < w Efezie >, i do wiernych w Chrystusie Jezusie:
###### **Ef 1,2**
 Łaska wam i pokój od Boga, Ojca naszego, i od Pana Jezusa Chrystusa!
###### **Ef 1,3**
 Niech będzie błogosławiony Bóg i Ojciec Pana naszego, Jezusa Chrystusa; On napełnił nas wszelkim błogosławieństwem duchowym na wyżynach niebieskich – w Chrystusie.
###### **Ef 1,4**
 W Nim bowiem wybrał nas przed założeniem świata, abyśmy byli święci i nieskalani przed Jego obliczem. Z miłości
###### **Ef 1,5**
 przeznaczył nas dla siebie jako przybranych synów poprzez Jezusa Chrystusa, według postanowienia swej woli,
###### **Ef 1,6**
 ku chwale majestatu swej łaski, którą obdarzył nas w Umiłowanym.
###### **Ef 1,7**
 W Nim mamy odkupienie przez Jego krew – odpuszczenie występków, według bogactwa Jego łaski.
###### **Ef 1,8**
 Szczodrze ją na nas wylał w postaci wszelkiej mądrości i zrozumienia,
###### **Ef 1,9**
 przez to, że nam oznajmił tajemnicę swej woli według swego postanowienia, które przedtem w Nim powziął
###### **Ef 1,10**
 dla dokonania pełni czasów, aby wszystko na nowo zjednoczyć w Chrystusie jako Głowie: to, co w niebiosach, i to, co na ziemi.
###### **Ef 1,11**
 W Nim dostąpiliśmy udziału my również, z góry przeznaczeni zamiarem Tego, który dokonuje wszystkiego zgodnie z zamysłem swej woli,
###### **Ef 1,12**
 byśmy istnieli ku chwale Jego majestatu – my, którzy już przedtem nadzieję złożyliśmy w Chrystusie.
###### **Ef 1,13**
 W Nim także i wy, usłyszawszy słowo prawdy, Dobrą Nowinę o waszym zbawieniu, w Nim również – uwierzywszy, zostaliście naznaczeni pieczęcią, Duchem Świętym, który był obiecany.
###### **Ef 1,14**
 On jest zadatkiem naszego dziedzictwa w oczekiwaniu na odkupienie, które nas uczyni własnością [Boga], ku chwale Jego majestatu.
###### **Ef 1,15**
 Przeto i ja, usłyszawszy o waszej wierze w Pana Jezusa i o miłości względem wszystkich świętych,
###### **Ef 1,16**
 nie zaprzestaję dziękczynienia, wspominając was w moich modlitwach.
###### **Ef 1,17**
 [Proszę w nich], aby Bóg Pana naszego, Jezusa Chrystusa, Ojciec chwały, dał wam ducha mądrości i objawienia w głębszym poznawaniu Jego samego.
###### **Ef 1,18**
 [Niech da] wam światłe oczy serca, byście wiedzieli, czym jest nadzieja, do której On wzywa, czym bogactwo chwały Jego dziedzictwa wśród świętych
###### **Ef 1,19**
 i czym przeogromna Jego moc względem nas wierzących – na podstawie działania Jego potęgi i siły.
###### **Ef 1,20**
 Wykazał On je, gdy wskrzesił Go z martwych i posadził po swojej prawicy na wyżynach niebieskich,
###### **Ef 1,21**
 ponad wszelką Zwierzchnością i Władzą, i Mocą, i Panowaniem, i ponad wszelkim innym imieniem, wzywanym nie tylko w tym wieku, ale i w przyszłym.
###### **Ef 1,22**
 I wszystko poddał pod Jego stopy, a Jego samego ustanowił nade wszystko Głową dla Kościoła,
###### **Ef 1,23**
 który jest Jego Ciałem, pełnią Tego, który napełnia wszystko wszelkimi sposobami.
# Ef 1 PAU
###### **Ef 1,1**
 Paweł, z woli Boga apostoł Chrystusa Jezusa, do świętych w Efezie i do wierzących w Chrystusa Jezusa:
###### **Ef 1,2**
 łaska wam i pokój od Boga, naszego Ojca, i od Pana Jezusa Chrystusa.
###### **Ef 1,3**
 Niech będzie błogosławiony Bóg, Ojciec naszego Pana Jezusa Chrystusa! On udzielił nam z wyżyn niebieskich wszelkiego błogosławieństwa duchowego w Chrystusie.
###### **Ef 1,4**
 On wybrał nas w Nim przed stworzeniem świata, abyśmy byli przed Nim święci i nieskalani w miłości.
###### **Ef 1,5**
 On przeznaczył nas, abyśmy się stali Jego przybranymi dziećmi przez Jezusa Chrystusa. Takie było upodobanie Jego woli,
###### **Ef 1,6**
 aby był uwielbiony majestat Jego łaski, którą obdarzył nas w Umiłowanym.
###### **Ef 1,7**
 W Nim mamy odkupienie przez krew Jego: odpuszczenie występków dzięki bogactwu Jego łaski.
###### **Ef 1,8**
 Obdarzył nas nią obficie wraz z wszelką mądrością i zrozumieniem,
###### **Ef 1,9**
 gdy dał nam poznać tajemnicę swej woli. Tak sobie upodobał i w Nim postanowił,
###### **Ef 1,10**
 że dla dokonania pełni czasów wszystko podda Chrystusowi jako Głowie: to, co w niebie, i to, co na ziemi.
###### **Ef 1,11**
 W Nim także my zostaliśmy wybrani i już wcześniej przeznaczeni przez Tego, który wszystko czyni według postanowienia swej woli,
###### **Ef 1,12**
 abyśmy wielbili majestat Jego łaski - my, którzy już wcześniej złożyliśmy nadzieję w Chrystusie.
###### **Ef 1,13**
 W Nim także wy usłyszeliście słowo prawdy, Ewangelię o waszym zbawieniu. W Nim uwierzyliście i zostaliście naznaczeni pieczęcią, Świętym Duchem obietnicy,
###### **Ef 1,14**
 Duchem, który jest poręczycielem naszego dziedzictwa, odkupienia tych, których On nabył, aby był uwielbiony Jego majestat.
###### **Ef 1,15**
 Dlatego i ja, słysząc o waszej wierze w Pana Jezusa i o waszej miłości do wszystkich świętych,
###### **Ef 1,16**
 nie przestaję za was dziękować. Pamiętam o was w moich modlitwach,
###### **Ef 1,17**
 aby Bóg naszego Pana, Jezusa Chrystusa, Ojciec chwały, dał wam ducha mądrości i objawienia, byście Go lepiej poznali.
###### **Ef 1,18**
 Niech da wam światłe oczy serca, abyście wiedzieli, czym jest nadzieja Jego powołania, czym bogactwo chwały Jego dziedzictwa w świętych
###### **Ef 1,19**
 i czym nadzwyczajny ogrom Jego mocy dla nas wierzących, o czym świadczy siła Jego potęgi.
###### **Ef 1,20**
 Ukazał ją w Chrystusie, gdy wskrzesił Go z martwych i posadził po swojej prawej stronie na wyżynach niebieskich
###### **Ef 1,21**
 ponad wszelką zwierzchnością i władzą, mocą i panowaniem, i ponad wszelkim imieniem wzywanym nie tylko w tym wieku, ale i w przyszłym.
###### **Ef 1,22**
 Wszystko poddał pod Jego stopy i ustanowił Go Głową całego Kościoła,
###### **Ef 1,23**
 który jest Jego Ciałem i Pełnią Tego, który wypełnia wszystko we wszystkim.
# Ef 1 BP
###### **Ef 1,1**
 Paweł, z woli Boga apostoł Chrystusa Jezusa, do świętych, którzy są [w Efezie] i do wiernych w Chrystusie Jezusie.
###### **Ef 1,2**
 Łaska wam i pokój od Boga, naszego Ojca, i od Pana Jezusa Chrystusa.
###### **Ef 1,3**
 Uwielbiony (niech będzie) Bóg i Ojciec naszego Pana Jezusa Chrystusa. On z wyżyn niebieskich obsypał nas wszelkim błogosławieństwem duchowym w Chrystusie.
###### **Ef 1,4**
 W Nim wybrał nas przed stworzeniem świata, abyśmy byli święci i nieskalani w Jego obecności, w miłości.
###### **Ef 1,5**
 Przeznaczył nas za przyczyną Jezusa Chrystusa - zgodnie z postanowieniem swojej woli - dla siebie, do synostwa Bożego,
###### **Ef 1,6**
 dla ukazania wspaniałości swojej łaski, którą obdarzył nas w Umiłowanym.
###### **Ef 1,7**
 W Nim, przez Jego Krew, mamy odkupienie, odpuszczenie grzechów stosownie do bogactwa Jego łaski,
###### **Ef 1,8**
 której szczodrze nam udzielił wraz z pełnią mądrości i zrozumienia.
###### **Ef 1,9**
 On pozwolił nam poznać tajemnicę swej woli zgodnie z powziętym co do Niego planem,
###### **Ef 1,10**
 aby go wykonać, gdy nadejdzie pełnia czasu: [aby] wszystko na nowo zjednoczyć w Chrystusie jako Głowie, i to, co na niebie, i to, co na ziemi.
###### **Ef 1,11**
 W Nim też jesteśmy powołani do udziału w dziedzictwie i zgodnie z zamysłem Jego woli przeznaczeni do tego,
###### **Ef 1,12**
 abyśmy istnieli ku chwale Jego majestatu, my którzyśmy już dawno złożyli nadzieję w Chrystusie.
###### **Ef 1,13**
 Dzięki Niemu i wy, usłyszawszy naukę o prawdzie, radosną nowinę o waszym zbawieniu, przyjęliście wiarę i zostaliście naznaczeni pieczęcią Ducha Świętego - Obietnicy.
###### **Ef 1,14**
 On jest zadatkiem naszego dziedzictwa i przygotowuje odkupienie [ludu], który] [Bóg] nabył sobie na własność, na chwałę swojego majestatu.
###### **Ef 1,15**
 Toteż ja, usłyszawszy o waszej wierze w Pana Jezusa oraz miłości do wszystkich świętych,
###### **Ef 1,16**
 nie przestaję dziękować [Bogu], pamiętając o was w moich modlitwach.
###### **Ef 1,17**
 [Modlę się], aby Bóg naszego Pana Jezusa Chrystusa, Ojciec chwały, dał wam ducha mądrości i objawienia dla Jego poznania.
###### **Ef 1,18**
 Niech otworzy oczy [waszego] serca, abyście wiedzieli, czym jest wasze powołanie do nadziei, czym jest bogactwo chwały Jego dziedzictwa wśród świętych,
###### **Ef 1,19**
 czym jest niewysłowiony ogrom Jego mocy dla nas wierzących.
###### **Ef 1,20**
 Jest to [ta sama] wszechwładna moc, którą okazał w Chrystusie, kiedy wskrzesił Go z martwych i w niebie po swojej prawicy posadził
###### **Ef 1,21**
 ponad wszelką zwierzchnością, władzą, mocą, panowaniem i ponad każdą istotą, jaka może być wymieniona nie tylko teraz, ale i w przyszłości.
###### **Ef 1,22**
 Wszystko też Mu położył pod stopy, a Jego samego [postawił] ponad wszelkim stworzeniem i ustanowił Głową Kościoła,
###### **Ef 1,23**
 który jest Jego Ciałem, pełnią Tego, który napełnia wszystko we wszystkim.
# Ef 1 BR
###### **Ef 1,1**
 Paweł, z woli Bożej apostoł Chrystusa Jezusa, do tych, co tworzą lud Boży w (Efezie) i żyją wiarą w zjednoczeniu z Jezusem Chrystusem.
###### **Ef 1,2**
 Bóg, Ojciec nasz, i Pan Jezus Chrystus niech was obdarzą łaską i pokojem.
###### **Ef 1,3**
 Niech będzie uwielbiony Bóg, Ojciec Pana naszego Jezusa Chrystusa. On to napełnił nas wszelkim błogosławieństwem duchowym w sprawach dotyczących nieba w naszym zjednoczeniu z Chrystusem.
###### **Ef 1,4**
 W Nim to jeszcze przed stworzeniem świata wybrał nas, abyśmy należeli do Niego abyśmy byli święci i bez skazy w Jego oczach.W swej miłości
###### **Ef 1,5**
 przeznaczył nas już przedtem na swoich synów przez Jezusa Chrystusa, zgodnie z postanowieniem, które było wyrazem Jego upodobania.
###### **Ef 1,6**
 A wszystko to w celu ukazania blasku tej chwały, którą nas już obdarzył w swoim umiłowanym Synu.
###### **Ef 1,7**
 W Nim właśnie za cenę Jego krwi zostaliśmy wykupieni, a nasze grzechy zostały nam darowane dzięki bezmiarom Jego łaski.
###### **Ef 1,8**
 Zesłał ją na nas obficie przez to, że obdarzył nas pełnią mądrości i zrozumienia
###### **Ef 1,9**
 i że pozwolił nam poznać tajemnicę swej woli, zgodnej z postanowieniem uprzednio w Nim uczynionym,
###### **Ef 1,10**
 aby gdy nadejdzie pełnia czasu, znów wszystko - i to, co na niebie, i to, co na ziemi - zjednoczyć w Chrystusie jako Głowie.
###### **Ef 1,11**
 W dziele tym my również dostąpiliśmy udziału, gdyż Bóg przeznaczył nas do tego już wcześniej, zgodnie z własnym postanowieniem. Bóg bowiem dokonuje wszystkiego według upodobania własnej woli,
###### **Ef 1,12**
 abyśmy naszym istnieniem ukazywali chwałę Jego majestatu, my, którzyśmy już przedtem nadzieję naszą złożyli w Chrystusie.
###### **Ef 1,13**
 Wy również usłyszawszy głoszoną wam prawdę Dobrej Nowiny obwieszczającej wam zbawienie, wy również uwierzyliście i w Nim zostaliście opatrzeni pieczęcią, Duchem Świętym, który wam był już przedtem obiecany
###### **Ef 1,14**
 i który daje nam gwarancję, że będziemy mieli udział [w dobrach] odkupienia, to jest we wzięciu nas na własność [przez Boga] ku większej chwale Jego majestatu.
###### **Ef 1,15**
 Dlatego też i ja, słysząc o waszej wierze w Pana Jezusa i o miłości ku wszystkim, którzy należą do Boga,
###### **Ef 1,16**
 nie przestaję dziękować Bogu za was, pamiętając o was ciągle w moich modlitwach.
###### **Ef 1,17**
 Proszę też Boga Pana naszego Jezusa Chrystusa, Ojca chwały, by zesłał na was Ducha mądrości i [zrozumienia] objawienia się Boga samego, tak byście mogli Go poznać.
###### **Ef 1,18**
 Modlę się też i o wasze wewnętrzne oświecenie, byście mogli pojąć, czym jest nadzieja waszego powołania, czym bogactwo chwały przeznaczonej dla tych, którzy do Niego należą,
###### **Ef 1,19**
 czym wreszcie Jego moc niezwykła, którą posługuje się dla dobra wierzących
###### **Ef 1,20**
 i którą okazał w Chrystusie, gdy zmartwychwskrzesił Go, pozwalając Mu zasiąść po swojej prawicy na wyżynach niebieskich,
###### **Ef 1,21**
 ponad wszelką Zwierzchnością, Władzą, Mocą i Panowaniem, i ponad wszelkim Imieniem, jakie mogłoby zaistnieć nie tylko w tym życiu, ale i w przyszłym.
###### **Ef 1,22**
 Wszystko złożył [Bóg] pod Jego stopy, a Jego samego uczynił Głową wszelkiego Kościoła,
###### **Ef 1,23**
 który jest Jego Ciałem. To właśnie [w Kościele] przebywa Chrystus w całej swojej pełni, napełniając wszystko we wszelki sposób.
# Ef 1 WUJ
###### **Ef 1,1**
 Paweł Apostoł Jezusa Chrystusa przez wolą Bożą: wszystkim świętym którzy są w Efezie: i wiernym w Chrystusie Jezusie.
###### **Ef 1,2**
 Łaska wam i pokój od Boga Ojca naszego, i Pana Jezusa Chrystusa.
###### **Ef 1,3**
 Błogosławiony Bóg i Ociec Pana naszego Jezusa Chrystusa, który nas błogosławił wszelakiem błogosławieństwem duchownem w niebieskich w Chrystusie:
###### **Ef 1,4**
 Jako nas wybrał w nim przed założeniem świata, abyśmy byli świętemi i niepokalanemi przed oczyma jego w miłości.
###### **Ef 1,5**
 Który nas przeznaczył ku przysposobieniu za syny, przez Jezusa Chrystusa, ku sobie: wedle postanowienia wolej swojej:
###### **Ef 1,6**
 Ku chwale sławy łaski swojej, przez którą nas przyjemnemi uczynił w umiłowanym Synie swoim.
###### **Ef 1,7**
 W którym mamy odkupienie przez krew jego odpuszczenie grzechów wedle bogactw łaski jego.
###### **Ef 1,8**
 Która nader obfitowała przeciw nam we wszelakiej mądrości i roztropności,
###### **Ef 1,9**
 Aby nam oznajmił tajemnicę wolej swojej, wedle upodobania swojego, które postanowił w nim,
###### **Ef 1,10**
 W rozrządzeniu zupełności czasów, aby w Chrystusie wszystko naprawił, co na niebiesiech i co na ziemi jest, w nim.
###### **Ef 1,11**
 W którym też my losem wezwani jesteśmy: przeznaczeni wedle postanowienia jego, który sprawuje wszystko, wedle rady wolej swojej:
###### **Ef 1,12**
 Abyśmy byli ku chwale sławy jego my, którzyśmy w przód nadzieję pokładali w Chrystusie:
###### **Ef 1,13**
 W którym i wy, usłyszawszy słowo prawdy, (Ewanielią zbawienia waszego): w którego też uwierzywszy, jesteście zapieczętowani Duchem obietnice świętym,
###### **Ef 1,14**
 Który jest zadatkiem dziedzictwa naszego, na okup nabycia, ku chwale sławy jego.
###### **Ef 1,15**
 Dla tego i ja usłyszawszy wiarę waszę, która jest w Panie Jezusie, i miłość ku wszystkim świętym:
###### **Ef 1,16**
 Nie przestawam dziękować za was, zmiankę o was czyniąc w modlitwach moich,
###### **Ef 1,17**
 Aby Bóg, Pana naszego Jezusa Chrystusa Ociec chwały, dał wam Ducha mądrości i objawienia, w uznaniu jego,
###### **Ef 1,18**
 Oświecone oczy serca waszego, abyście wiedzieli, która jest nadzieja wezwania jego, i które bogactwa chwały dziedzictwa jego w świętych,
###### **Ef 1,19**
 I która jest przewyższająca wielkość mocy jego przeciwko nam, którzy wierzymy: według skuteczności mocy siły jego,
###### **Ef 1,20**
 Którą sprawił w Chrystusie, wzbudziwszy go z martwych, i posadziwszy na prawicy swojej na niebiesiech:
###### **Ef 1,21**
 Nad wszelakie księstwa i władzą i moc, panowanie, i wszelkie imię, które się mianuje nietylko w tym wieku, ale też i w przyszłym.
###### **Ef 1,22**
 I wszystko poddał pod nogi jego: a jego dał głową nas wszystkim kościołem,
###### **Ef 1,23**
 Który jest ciałem jego, napełnieniem tego, który wszystko we wszystkich wypełnion bywa.
# Ef 1 STERN
###### **Ef 1,1**
 Sza'ul, z woli Bożej wysłannik Mesjasza Jeszui, do ludu Bożego mieszkającego w Efezie, czyli do tych, którzy pokładają ufność w Mesjaszu Jeszui:
###### **Ef 1,2**
 łaska wam i szalom od Boga, Ojca naszego, i od Pana Jeszui Mesjasza.
###### **Ef 1,3**
 Pochwalony niech będzie Adonai, Ojciec Pana naszego Jeszui Mesjasza, który w Mesjaszu pobłogosławił nas wszelkim duchowym błogosławieństwem w niebie.
###### **Ef 1,4**
 W Mesjaszu wybrał nas On w miłości przed stworzeniem wszechświata, abyśmy byli święci i bez skazy przed Jego obliczem.
###### **Ef 1,5**
 Z góry postanowił, że przez Jeszuę Mesjasza będziemy Jego synami - tak jak Mu się spodobało i jak zamierzył -
###### **Ef 1,6**
 abyśmy przynieśli Mu chlubę współmierną do chwały łaski, jaką nam dał w swym Umiłowanym.
###### **Ef 1,7**
 W jedności z Nim, przez przelanie Jego krwi, jesteśmy wyzwoleni - nasze grzechy są odpuszczone, zgodnie z bogactwem łaski,
###### **Ef 1,8**
 jaką nas hojnie obdarował. We wszelkiej swej mądrości i przenikliwości
###### **Ef 1,9**
 dał nam poznać swój ukryty plan, który ułożył zawczasu według własnej woli w związku z Mesjaszem
###### **Ef 1,10**
 i który urzeczywistni, kiedy przyjdzie na to czas - plan, aby wszystko w niebie i na ziemi poddać Mesjaszowi.
###### **Ef 1,11**
 Również w jedności z Nim otrzymaliśmy dziedzictwo, my, których z góry wyłoniono zgodnie z zamiarem Tego, który sprawia wszystko według postanowienia swojej woli,
###### **Ef 1,12**
 abyśmy my, którzyśmy już wcześniej złożyli nadzieję w Mesjaszu, przynieśli Mu chlubę godną Jego chwały.
###### **Ef 1,13**
 Ponadto wy, którzyście słyszeli orędzie prawdy, Dobrą Nowinę oferującą wam wyzwolenie, i złożyliście ufność w Mesjaszu, zostaliście przez Niego opieczętowani obiecanym Ruach Ha-Kodesz,
###### **Ef 1,14**
 który zabezpiecza wasze dziedzictwo do chwili, aż wejdziemy w jego posiadanie i w ten sposób przyniesiemy Mu chlubę godną Jego chwały.
###### **Ef 1,15**
 Toteż odkąd tylko usłyszałem o waszej ufności złożonej w Panu Jeszui i o waszej miłości do całego ludu Bożego,
###### **Ef 1,16**
 nie przestaję za was dziękować. W modlitwach ciągle proszę
###### **Ef 1,17**
 Boga naszego Pana Jeszui Mesjasza, chwalebnego Ojca, aby wam dał ducha mądrości i objawienia, abyście mieli pełne poznanie Jego.
###### **Ef 1,18**
 Modlę się, aby dał światło oczom waszych serc, abyście rozumieli nadzieję, do której was wezwał, bogactwo chwały dziedzictwa, które obiecał swemu ludowi,
###### **Ef 1,19**
 i niewyobrażalną wielkość Jego mocy, działającej w nas, którzy Mu ufamy. Działa ona tą samą potężną siłą, jakiej użył On,
###### **Ef 1,20**
 gdy działał w Mesjaszu, aby wskrzesić Go z martwych i posadzić po swojej prawicy w niebie,
###### **Ef 1,21**
 wysoko ponad każdym władcą, zwierzchnością, mocą, panowaniem i ponad wszelkim innym imieniem, jakiego można wzywać już to w 'olam haze, już to w olam haba.
###### **Ef 1,22**
 I wszystko poddał pod Jego stopy, i uczynił Go głową ponad wszystkim we Wspólnocie Mesjanicznej,
###### **Ef 1,23**
 która jest Jego ciałem, pełnym wyrażeniem Tego, który wypełnia całe stworzenie.
# Ef 1 TRO
###### **Ef 1,1**
 **παυλος** *paulos* Paweł – [mały] [[G3972]] [[N-NSM]] **αποστολος** *apostolos* wysłannik [[G652]] [[N-NSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **δια** *dia* przez – ze względu na [[G1223]] [[PREP]] **θεληματος** *thelēmatos* wolę [[G2307]] [[N-GSN]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **τοις** *tois* [[G3588]] WTT-DPM **αγιοις** *hagiois* świętym [[G40]] WTA-DPM **τοις** *tois* [[G3588]] WTT-DPM **ουσιν** *ousin* będącym [[G5607]] WTV-PXP-DPM **εν** *en* w [[G1722]] [[PREP]] **εφεσω** *efesō* Efezie [[G2181]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **πιστοις** *pistois* wierzącym [[G4103]] WTA-DPM **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańca [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] WTN-DSM
###### **Ef 1,2**
 **χαρις** *charis* łaska [[G5485]] [[N-NSF]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **και** *kai* i [[G2532]] [[CONJ]] **ειρηνη** *eirēnē* pokój [[G1515]] [[N-NSF]] **απο** *apo* od [[G575]] [[PREP]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **πατρος** *patros* Ojca [[G3962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **και** *kai* i [[G2532]] [[CONJ]] **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **Ef 1,3**
 **ευλογητος** *eulogētos* Błogosławiony – Wysławiony [[G2128]] [[A-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **πατηρ** *patēr* Ojciec [[G3962]] [[N-NSM]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **ευλογησας** *eulogēsas* który pobłogosławił – który wysławił [[G2127]] WTV-AAP-NSM **ημας** *hēmas* nas [[G2248]] WTP-1AP **εν** *en* w [[G1722]] [[PREP]] **παση** *pasē* całym [[G3956]] WTA-DSF **ευλογια** *eulogia* błogosławieństwie – wysławieniu [[G2129]] [[N-DSF]] **πνευματικη** *pneumatikē* duchowym [[G4152]] WTA-DSF **εν** *en* w [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPN **επουρανιοις** *epouraniois* niebiosach [[G2032]] WTA-DPN **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM
###### **Ef 1,4**
 **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **εξελεξατο** *ekseleksato* wybrał sobie [[G1586]] WTV-AMI-3S **ημας** *hēmas* nas [[G2248]] WTP-1AP **εν** *en* w [[G1722]] [[PREP]] **αυτω** *autō* Nim [[G846]] WTP-DSM **προ** *pro* przed [[G4253]] [[PREP]] **καταβολης** *katabolēs* założeniem [[G2602]] [[N-GSF]] **κοσμου** *kosmou* świata [[G2889]] [[N-GSM]] **ειναι** *einai* (by) być [[G1511]] WTV-PXN **ημας** *hēmas* my [[G2248]] WTP-1AP **αγιους** *hagious* świętymi [[G40]] WTA-APM **και** *kai* i [[G2532]] [[CONJ]] **αμωμους** *amōmous* nienagannymi – niewinnymi [[G299]] WTA-APM **κατενωπιον** *katenōpion* przed [[G2714]] [[PREP]] **αυτου** *autou* Nim [[G846]] [[P-GSM]] **εν** *en* w [[G1722]] [[PREP]] **αγαπη** *agapē* miłości [[G26]] [[N-DSF]]
###### **Ef 1,5**
 **προορισας** *proorisas* Przeznaczywszy [[G4309]] WTV-AAP-NSM **ημας** *hēmas* nas [[G2248]] WTP-1AP **εις** *eis* dla [[G1519]] [[PREP]] **υιοθεσιαν** *hyiothesian* usynowienia [[G5206]] WTN-ASF **δια** *dia* przez [[G1223]] [[PREP]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **εις** *eis* względem [[G1519]] [[PREP]] **αυτον** *auton* Niego [[G846]] WTP-ASM **κατα** *kata* według [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **ευδοκιαν** *eudokian* upodobania [[G2107]] WTN-ASF **του** *tou* [[G3588]] WTT-GSN **θεληματος** *thelēmatos* woli [[G2307]] [[N-GSN]] **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Ef 1,6**
 **εις** *eis* Ku [[G1519]] [[PREP]] **επαινον** *epainon* pochwale [[G1868]] [[N-ASM]] **δοξης** *doksēs* chwały – blasku [[G1391]] [[N-GSF]] **της** *tēs* [[G3588]] [[T-GSF]] **χαριτος** *charitos* łaski [[G5485]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **εν** *en* w [[G1722]] [[PREP]] **η** *hē* (której) [[G3739]] WTR-DSF **εχαριτωσεν** *echaritōsen* obdarzył łaską – napełnił łaską [[G5487]] [[V-AAI-3S]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* (Tym) [[G3588]] WTT-DSM **ηγαπημενω** *ēgapēmenō* który jest umiłowany [[G25]] WTV-RPP-DSM
###### **Ef 1,7**
 **εν** *en* w [[G1722]] [[PREP]] **ω** *hō* którym [[G3739]] WTR-DSM **εχομεν** *echomen* mamy [[G2192]] WTV-PAI-1P **την** *tēn* [[G3588]] WTT-ASF **απολυτρωσιν** *apolytrōsin* odkupienie [[G629]] WTN-ASF **δια** *dia* przez [[G1223]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **αιματος** *haimatos* krew [[G129]] [[N-GSN]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **την** *tēn* [[G3588]] WTT-ASF **αφεσιν** *afesin* uwolnienie – wyzwolenie [[G859]] WTN-ASF **των** *tōn* (od) [[G3588]] WTT-GPN **παραπτωματων** *paraptōmatōn* upadków – występków [[G3900]] WTN-GPN **κατα** *kata* według [[G2596]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **πλουτον** *plouton* bogactwa [[G4149]] [[N-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **χαριτος** *charitos* łaski [[G5485]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Ef 1,8**
 **ης** *hēs* której [[G3739]] [[R-GSF]] **επερισσευσεν** *eperisseusen* dał obfitość – okazał hojnie [[G4052]] [[V-AAI-3S]] **εις** *eis* ku [[G1519]] [[PREP]] **ημας** *hēmas* nam [[G2248]] WTP-1AP **εν** *en* w [[G1722]] [[PREP]] **παση** *pasē* całej [[G3956]] WTA-DSF **σοφια** *sofia* mądrości [[G4678]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **φρονησει** *fronēsei* zrozumieniu – pomyśleniu [[G5428]] [[N-DSF]]
###### **Ef 1,9**
 **γνωρισας** *gnōrisas* oznajmiwszy – dawszy poznać [[G1107]] WTV-AAP-NSM **ημιν** *hēmin* nam [[G2254]] WTP-1DP **το** *to* [[G3588]] WTT-ASN **μυστηριον** *mystērion* tajemnicę [[G3466]] WTN-ASN **του** *tou* [[G3588]] WTT-GSN **θεληματος** *thelēmatos* woli [[G2307]] [[N-GSN]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **κατα** *kata* według [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **ευδοκιαν** *eudokian* upodobania [[G2107]] WTN-ASF **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ην** *hēn* którego [[G3739]] WTR-ASF **προεθετο** *proetheto* postanowił sobie – powziąć sobie [[G4388]] WTV-2AMI-3S **εν** *en* w [[G1722]] [[PREP]] **αυτω** *autō* Nim [[G846]] WTP-DSM
###### **Ef 1,10**
 **εις** *eis* w [[G1519]] [[PREP]] **οικονομιαν** *oikonomian* zarządzaniu sprawami domowymi [[G3622]] WTN-ASF **του** *tou* [[G3588]] WTT-GSN **πληρωματος** *plērōmatos* wypełnienia [[G4138]] [[N-GSN]] **των** *tōn* [[G3588]] WTT-GPM **καιρων** *kairōn* pór [[G2540]] WTN-GPM **ανακεφαλαιωσασθαι** *anakefalaiōsasthai* połączyć – sprowadzić sobie pod jedną głowę [[G346]] WTV-ADN **τα** *ta* (te) [[G3588]] WTT-APN **παντα** *panta* wszystkie [[G3956]] WTA-APN **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **τα** *ta* [[G3588]] WTT-APN **τε** *te* zarówno [[G5037]] WTPRT **εν** *en* w [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPM **ουρανοις** *ouranois* niebiosach [[G3772]] WTN-DPM **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **επι** *epi* na [[G1909]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]]
###### **Ef 1,11**
 **εν** *en* W [[G1722]] [[PREP]] **αυτω** *autō* Nim [[G846]] WTP-DSM **εν** *en* w [[G1722]] [[PREP]] **ω** *hō* którym [[G3739]] WTR-DSM **και** *kai* i [[G2532]] [[CONJ]] **εκληρωθημεν** *eklērōthēmen* otrzymaliśmy dział – zostaliśmy wybrani losem [[G2820]] WTV-API-1P **προορισθεντες** *prooristhentes* którzy zostaliśmy przeznaczeni [[G4309]] WTV-APP-NPM **κατα** *kata* według [[G2596]] [[PREP]] **προθεσιν** *prothesin* wcześniejszego ustawienia – wcześniejszego postanowienia [[G4286]] WTN-ASF **του** *tou* (Tego) [[G3588]] WTT-GSM **τα** *ta* [[G3588]] WTT-APN **παντα** *panta* wszystkie [[G3956]] WTA-APN **ενεργουντος** *energountos* który działa [[G1754]] WTV-PAP-GSM **κατα** *kata* według [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **βουλην** *boulēn* postanowienia – rady [[G1012]] WTN-ASF **του** *tou* [[G3588]] WTT-GSN **θεληματος** *thelēmatos* woli [[G2307]] [[N-GSN]] **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Ef 1,12**
 **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **ειναι** *einai* być [[G1511]] WTV-PXN **ημας** *hēmas* nam [[G2248]] WTP-1AP **εις** *eis* ku [[G1519]] [[PREP]] **επαινον** *epainon* pochwale [[G1868]] [[N-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **δοξης** *doksēs* chwały – blasku [[G1391]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **τους** *tous* [[G3588]] WTT-APM **προηλπικοτας** *proēlpikotas* którzy wcześniej oparliśmy nadzieję [[G4276]] WTV-RAP-APM **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM
###### **Ef 1,13**
 **εν** *en* w [[G1722]] [[PREP]] **ω** *hō* którym [[G3739]] WTR-DSM **και** *kai* i [[G2532]] [[CONJ]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **ακουσαντες** *akousantes* usłyszawszy [[G191]] WTV-AAP-NPM **τον** *ton* [[G3588]] [[T-ASM]] **λογον** *logon* Słowo [[G3056]] [[N-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **αληθειας** *alētheias* prawdy [[G225]] [[N-GSF]] **το** *to* [[G3588]] WTT-ASN **ευαγγελιον** *euangelion* dobrą nowinę [[G2098]] WTN-ASN **της** *tēs* (o) [[G3588]] [[T-GSF]] **σωτηριας** *sōtērias* zbawieniu – wyzwoleniu [[G4991]] [[N-GSF]] **υμων** *hymōn* waszym [[G5216]] WTP-2GP **εν** *en* w [[G1722]] [[PREP]] **ω** *hō* którym – które [[G3739]] WTR-DSM **και** *kai* i [[G2532]] [[CONJ]] **πιστευσαντες** *pisteusantes* uwierzywszy [[G4100]] WTV-AAP-NPM **εσφραγισθητε** *esfragisthēte* zostaliście opieczętowani [[G4972]] WTV-API-2P **τω** *tō* [[G3588]] WTT-DSN **πνευματι** *pneumati* Duchem [[G4151]] WTN-DSN **της** *tēs* [[G3588]] [[T-GSF]] **επαγγελιας** *epangelias* obietnicy [[G1860]] [[N-GSF]] **τω** *tō* (tym) [[G3588]] WTT-DSN **αγιω** *hagiō* Świętym [[G40]] WTA-DSN
###### **Ef 1,14**
 **ος** *hos* który [[G3739]] WTR-NSM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **αρραβων** *arrabōn* zadatek – poręka [[G728]] [[N-NSM]] **της** *tēs* [[G3588]] [[T-GSF]] **κληρονομιας** *klēronomias* dziedziczenia [[G2817]] [[N-GSF]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **εις** *eis* ku [[G1519]] [[PREP]] **απολυτρωσιν** *apolytrōsin* odkupieniu [[G629]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **περιποιησεως** *peripoiēseōs* nabycia dla siebie – pozyskania dla siebie [[G4047]] [[N-GSF]] **εις** *eis* ku [[G1519]] [[PREP]] **επαινον** *epainon* pochwale [[G1868]] [[N-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **δοξης** *doksēs* chwały – blasku [[G1391]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Ef 1,15**
 **δια** *dia* Z powodu [[G1223]] [[PREP]] **τουτο** *touto* tego [[G5124]] WTD-ASN **καγω** *kagō* i ja [[G2504]] WTP-1NS-C **ακουσας** *akousas* usłyszawszy [[G191]] WTV-AAP-NSM **την** *tēn* (o tej) [[G3588]] WTT-ASF **καθ** *kath* w [[G2596]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **πιστιν** *pistin* wierze [[G4102]] WTN-ASF **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **κυριω** *kyriō* Pana [[G2962]] WTN-DSM **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* (o) [[G3588]] WTT-ASF **αγαπην** *agapēn* miłości [[G26]] WTN-ASF **την** *tēn* [[G3588]] WTT-ASF **εις** *eis* ku [[G1519]] [[PREP]] **παντας** *pantas* wszystkim [[G3956]] WTA-APM **τους** *tous* [[G3588]] WTT-APM **αγιους** *hagious* świętym [[G40]] WTA-APM
###### **Ef 1,16**
 **ου** *ou* nie [[G3756]] [[PRT-N]] **παυομαι** *pauomai* powstrzymuję się [[G3973]] WTV-PMI-1S **ευχαριστων** *eucharistōn* dziękując [[G2168]] [[V-PAP-NSM]] **υπερ** *hyper* za [[G5228]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **μνειαν** *mneian* wspomnienie [[G3417]] WTN-ASF **υμων** *hymōn* (o) was [[G5216]] WTP-2GP **ποιουμενος** *poioumenos* czyniąc [[G4160]] WTV-PMP-NSM **επι** *epi* w [[G1909]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPF **προσευχων** *proseuchōn* modlitwach [[G4335]] WTN-GPF **μου** *mou* moich [[G3450]] WTP-1GS
###### **Ef 1,17**
 **ινα** *hina* aby [[G2443]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **ο** *ho* [[G3588]] [[T-NSM]] **πατηρ** *patēr* Ojciec [[G3962]] [[N-NSM]] **της** *tēs* [[G3588]] [[T-GSF]] **δοξης** *doksēs* chwały [[G1391]] [[N-GSF]] **δωη** *dōē* dałby [[G1325]] WTV-2AAS-3S **υμιν** *hymin* wam [[G5213]] WTP-2DP **πνευμα** *pneuma* Ducha [[G4151]] WTN-ASN **σοφιας** *sofias* mądrości [[G4678]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **αποκαλυψεως** *apokalypseōs* objawienia [[G602]] [[N-GSF]] **εν** *en* w [[G1722]] [[PREP]] **επιγνωσει** *epignōsei* poznaniu [[G1922]] [[N-DSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Ef 1,18**
 **πεφωτισμενους** *pefōtismenous* które są oświetlone [[G5461]] WTV-RPP-APM **τους** *tous* [[G3588]] WTT-APM **οφθαλμους** *ofthalmous* oczy [[G3788]] [[N-APM]] **της** *tēs* [[G3588]] [[T-GSF]] **διανοιας** *dianoias* myśli – umysłu [[G1271]] [[N-GSF]] **υμων** *hymōn* waszej [[G5216]] WTP-2GP **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **ειδεναι** *eidenai* wiedzieć [[G1492]] WTV-RAN **υμας** *hymas* wam [[G5209]] WTP-2AP **τις** *tis* jaka [[G5101]] WTI-NSF **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **η** *hē* [[G3588]] [[T-NSF]] **ελπις** *elpis* nadzieja [[G1680]] [[N-NSF]] **της** *tēs* [[G3588]] [[T-GSF]] **κλησεως** *klēseōs* powołania [[G2821]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **τις** *tis* jakie [[G5101]] WTI-NSM **ο** *ho* [[G3588]] [[T-NSM]] **πλουτος** *ploutos* bogactwo [[G4149]] [[N-NSM]] **της** *tēs* [[G3588]] [[T-GSF]] **δοξης** *doksēs* chwały [[G1391]] [[N-GSF]] **της** *tēs* [[G3588]] [[T-GSF]] **κληρονομιας** *klēronomias* dziedziczenia [[G2817]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **εν** *en* wśród [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPM **αγιοις** *hagiois* świętych [[G40]] WTA-DPM
###### **Ef 1,19**
 **και** *kai* I [[G2532]] [[CONJ]] **τι** *ti* jaka [[G5101]] WTI-NSN **το** *to* [[G3588]] WTT-NSN **υπερβαλλον** *hyperballon* przekraczająca [[G5235]] WTV-PAP-NSN **μεγεθος** *megethos* wielkość – ogrom [[G3174]] WTN-NSN **της** *tēs* [[G3588]] [[T-GSF]] **δυναμεως** *dynameōs* mocy [[G1411]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **εις** *eis* w [[G1519]] [[PREP]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **τους** *tous* [[G3588]] WTT-APM **πιστευοντας** *pisteuontas* wierzących [[G4100]] WTV-PAP-APM **κατα** *kata* według [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **ενεργειαν** *energeian* działania [[G1753]] WTN-ASF **του** *tou* [[G3588]] WTT-GSN **κρατους** *kratous* mocy – siły [[G2904]] [[N-GSN]] **της** *tēs* [[G3588]] [[T-GSF]] **ισχυος** *ischyos* siły [[G2479]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Ef 1,20**
 **ην** *hēn* którą [[G3739]] WTR-ASF **ενηργησεν** *enērgēsen* działał [[G1754]] [[V-AAI-3S]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **εγειρας** *egeiras* wzbudziwszy – podniósłszy [[G1453]] WTV-AAP-NSM **αυτον** *auton* Go [[G846]] WTP-ASM **εκ** *ek* z [[G1537]] [[PREP]] **νεκρων** *nekrōn* martwych [[G3498]] WTA-GPM **και** *kai* i [[G2532]] [[CONJ]] **εκαθισεν** *ekathisen* posadził [[G2523]] [[V-AAI-3S]] **εν** *en* na [[G1722]] [[PREP]] **δεξια** *deksia* prawicy [[G1188]] WTA-DSF **αυτου** *autou* Jego [[G846]] [[P-GSM]] **εν** *en* w [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPN **επουρανιοις** *epouraniois* niebiosach [[G2032]] WTA-DPN
###### **Ef 1,21**
 **υπερανω** *hyperanō* Powyżej [[G5231]] [[ADV]] **πασης** *pasēs* każdej [[G3956]] WTA-GSF **αρχης** *archēs* zwierzchności – władcy [[G746]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **εξουσιας** *eksousias* władzy [[G1849]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **δυναμεως** *dynameōs* mocy [[G1411]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **κυριοτητος** *kyriotētos* panowania – zwierzchności [[G2963]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **παντος** *pantos* każdego [[G3956]] [[A-GSN]] **ονοματος** *onomatos* imienia [[G3686]] [[N-GSN]] **ονομαζομενου** *onomazomenou* które jest wymienione – które jest nazywane [[G3687]] WTV-PPP-GSN **ου** *ou* nie [[G3756]] [[PRT-N]] **μονον** *monon* jedynie – tylko [[G3440]] [[ADV]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **αιωνι** *aiōni* wieku [[G165]] WTN-DSM **τουτω** *toutō* tym [[G5129]] WTD-DSM **αλλα** *alla* ale [[G235]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **μελλοντι** *mellonti* nadchodzącym [[G3195]] WTV-PAP-DSM
###### **Ef 1,22**
 **και** *kai* i [[G2532]] [[CONJ]] **παντα** *panta* wszystkie [[G3956]] WTA-APN **υπεταξεν** *hypetaksen* poddał – podporządkował [[G5293]] [[V-AAI-3S]] **υπο** *hypo* pod [[G5259]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **ποδας** *podas* stopy [[G4228]] [[N-APM]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **αυτον** *auton* Jego [[G846]] WTP-ASM **εδωκεν** *edōken* dał [[G1325]] [[V-AAI-3S]] **κεφαλην** *kefalēn* (jako) głowę [[G2776]] WTN-ASF **υπερ** *hyper* ponad [[G5228]] [[PREP]] **παντα** *panta* wszystkie [[G3956]] WTA-APN **τη** *tē* [[G3588]] WTT-DSF **εκκλησια** *ekklēsia* zgromadzeniu – (społeczności) wywołanych [[G1577]] [[N-DSF]]
###### **Ef 1,23**
 **ητις** *hētis* które [[G3748]] WTR-NSF **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **το** *to* [[G3588]] WTT-NSN **σωμα** *sōma* ciało [[G4983]] WTN-NSN **αυτου** *autou* Jego [[G846]] [[P-GSM]] **το** *to* [[G3588]] WTT-NSN **πληρωμα** *plērōma* wypełnienie [[G4138]] WTN-NSN **του** *tou* (Tego) [[G3588]] WTT-GSN **παντα** *panta* wszystkie [[G3956]] WTA-APN **εν** *en* we [[G1722]] [[PREP]] **πασιν** *pasin* wszystkim [[G3956]] WTA-DPN **πληρουμενου** *plēroumenou* wypełniającego sobie [[G4137]] WTV-PMP-GSM-T
