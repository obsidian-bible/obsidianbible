# Ezd 8 BT5
###### **Ezd 8,1**
 Oto głowy rodów oraz wpisani do rodowodów, którzy za panowania króla Artakserksesa wyszli ze mną z Babilonu:
###### **Ezd 8,2**
 z synów Pinchasa: Gerszom; z synów Itamara: Daniel; z synów Dawida: Chattusz,
###### **Ezd 8,3**
 syn Szekaniasza; z synów Parosza: Zachariasz, z którym zapisanych było stu pięćdziesięciu mężczyzn;
###### **Ezd 8,4**
 z synów Pachat-Moaba: Elioenaj, syn Zerachiasza, a z nim dwustu mężczyzn;
###### **Ezd 8,5**
 z synów Zattua: Szekaniasz, syn Jachazjela, a z nim trzystu mężczyzn;
###### **Ezd 8,6**
 z synów Adina: Ebed, syn Jonatana, a z nim pięćdziesięciu mężczyzn;
###### **Ezd 8,7**
 z synów Elama: Izajasz, syn Ataliasza, a z nim siedemdziesięciu mężczyzn;
###### **Ezd 8,8**
 z synów Szefatiasza: Zebadiasz, syn Mikaela, a z nim osiemdziesięciu mężczyzn;
###### **Ezd 8,9**
 z synów Joaba: Obadiasz, syn Jechiela, a z nim dwustu osiemnastu mężczyzn;
###### **Ezd 8,10**
 z synów Baniego: Szelomit, syn Josifiasza, a z nim stu sześćdziesięciu mężczyzn;
###### **Ezd 8,11**
 z synów Bebaja: Zachariasz, syn Bebaja, a z nim dwudziestu ośmiu mężczyzn;
###### **Ezd 8,12**
 z synów Azgada: Jochanan, syn Hakkatana, a z nim stu dziesięciu mężczyzn;
###### **Ezd 8,13**
 z synów Adonikama ostatni, a oto ich imiona: Elifelet, Jejel i Szemajasz, z nimi zaś sześćdziesięciu mężczyzn,
###### **Ezd 8,14**
 i z synów Bigwaja: Utaj, syn Zabbuda, a z nim siedemdziesięciu mężczyzn.
###### **Ezd 8,15**
 I zebrałem ich nad rzeką płynącą ku Ahawa. I gdy tam przez trzy dni obozowaliśmy, przyjrzałem się ludowi i kapłanom, a nie znalazłem tam żadnego lewity.
###### **Ezd 8,16**
 Toteż wyprawiłem Eliezera, Ariela, Szemajasza, Elnatana, Jariba, Elnatana, Natana, Zachariasza i Meszullama jako doświadczonych naczelników
###### **Ezd 8,17**
 i skierowałem ich do Iddo, naczelnika w miejscowości Kasifia, i przez nich kazałem powiedzieć Iddo i braciom jego, osiadłym w miejscowości Kasifia, by sprowadzili nam sługi dla domu Boga naszego.
###### **Ezd 8,18**
 A ponieważ łaskawa ręka Boga naszego była nad nami, przyprowadzili nam męża mądrego spośród synów Machliego, syna Lewiego, syna Izraela, mianowicie Szerebiasza wraz z synami jego i braćmi: osiemnaście osób;
###### **Ezd 8,19**
 dalej, Chaszabiasza, a z nim, spośród synów Merariego: brata jego, Izajasza, i ich synów: dwadzieścia osób;
###### **Ezd 8,20**
 a spośród niewolników świątynnych, których Dawid i książęta dali na posługę lewitom, osób dwieście dwadzieścia. Wszyscy oni zostali spisani imiennie.
###### **Ezd 8,21**
 I tam – nad rzeką Ahawą – ogłosiłem post, byśmy się umartwili przed Bogiem naszym celem uproszenia od Niego szczęśliwej drogi dla nas, dla dzieci naszych i dla całego dobytku naszego.
###### **Ezd 8,22**
 Wstydziłem się bowiem prosić króla o siłę zbrojną i jazdę, by w drodze nas ratowała od nieprzyjaciela; natomiast powiedzieliśmy królowi: «***Ręka Boga naszego jest łaskawie nad wszystkimi, którzy do Niego się zwracają, a srogi gniew Jego kieruje się przeciw wszystkim, którzy od Niego odchodzą***».
###### **Ezd 8,23**
 Pościliśmy więc i błagaliśmy Boga naszego o to, i dał się nam uprosić.
###### **Ezd 8,24**
 Wtedy wydzieliłem spośród przywódców kapłanów: dwunastu; dalej, Szerebiasza i Chaszabiasza, a z nimi spośród braci ich – dziesięciu,
###### **Ezd 8,25**
 i odważyłem im srebro, złoto i sprzęty, ową darowiznę dla domu Boga naszego, którą ofiarowali: król, radcy jego, książęta jego i cały tam obecny Izrael.
###### **Ezd 8,26**
 I odważyłem im sześćset pięćdziesiąt talentów srebra i sto sprzętów srebrnych, każdy po dwa talenty; sto talentów złota,
###### **Ezd 8,27**
 pucharów złotych dwadzieścia, każdy po tysiąc darejków, i sprzętów ze wspaniałego złocistego spiżu – dwa, przedmioty cenne jak złoto.
###### **Ezd 8,28**
 I powiedziałem im: «***Wy jesteście poświęceni dla Pana i te sprzęty są poświęcone, i to srebro, i złoto jest darowizną dla Pana, Boga ojców naszych.***
###### **Ezd 8,29**
 ***Strzeżcie tego pilnie, aż odważycie to przed przywódcami kapłanów i lewitów oraz przed przywódcami rodów izraelskich w Jerozolimie, w komnatach domu Pańskiego***».
###### **Ezd 8,30**
 Wtedy kapłani i lewici odebrali odważone srebro, złoto i sprzęty, aby je przynieść do Jerozolimy, do domu Boga naszego.
###### **Ezd 8,31**
 I od rzeki Ahawy wyruszyliśmy dwunastego dnia miesiąca pierwszego, aby się udać do Jerozolimy. A ręka Boga naszego była nad nami i On uchronił nas w drodze od wrogów i rozbojników.
###### **Ezd 8,32**
 Gdy przybyliśmy do Jerozolimy, wypoczywaliśmy tam przez trzy dni.
###### **Ezd 8,33**
 Czwartego dnia w domu Boga naszego odważono srebro, złoto i sprzęty; te przedmioty – w obecności Eleazara, syna Pinchasa, jak i lewitów: Jozabada, syna Jozuego, i Noadiasza, syna Binnuja – zostały przekazane kapłanowi Meremotowi, synowi Uriasza,
###### **Ezd 8,34**
 w całości według liczby i wagi; równocześnie zostało spisane wszystko, co odważono.
###### **Ezd 8,35**
 Powracający z niewoli wygnańcy złożyli Bogu Izraela jako całopalenia: dwanaście cielców za całego Izraela, dziewięćdziesiąt sześć baranów, siedemdziesiąt siedem jagniąt, dwanaście kozłów za grzech – to wszystko jako całopalenie dla Pana.
###### **Ezd 8,36**
 I wręczyli rozporządzenia króla satrapom królewskim i namiestnikom Transeufratei, a ci udzielili pomocy ludowi oraz domowi Bożemu.
# Ezd 8 PAU
###### **Ezd 8,1**
 Oto przywódcy rodów według ich pochodzenia, którzy wyruszyli ze mną za panowania Artakserksesa, króla Babilonii:
###### **Ezd 8,2**
 z rodu Pinchasa - Gerszom, z rodu Itamara - Daniel, z rodu Dawida - Chattusz,
###### **Ezd 8,3**
 z rodu Szekaniasza z rodu Parosza - Zachariasz, który wpisał na listę ze sobą stu pięćdziesięciu mężczyzn,
###### **Ezd 8,4**
 z rodu Pachat-Moaba - Elioenaj, syn Zerachiasza, i z nim dwustu mężczyzn,
###### **Ezd 8,5**
 z rodu Zattua - Szekaniasz, syn Jachaziela, i z nim trzystu mężczyzn,
###### **Ezd 8,6**
 z rodu Adina, Ebed, syn Jonatana, i z nim pięćdziesięciu mężczyzn,
###### **Ezd 8,7**
 z rodu Elama - Izajasz, syn Ataliasza, i z nim siedemdziesięciu mężczyzn,
###### **Ezd 8,8**
 z rodu Szefatiasza - Zebadiasz, syn Mikaela, i z nim osiemdziesięciu mężczyzn,
###### **Ezd 8,9**
 z rodu Joaba - Obadiasz, syn Jechiela, i z nim dwustu osiemnastu mężczyzn,
###### **Ezd 8,10**
 z rodu Baniego - Szelomit, syn Josifiasza, i z nim stu sześćdziesięciu mężczyzn,
###### **Ezd 8,11**
 z rodu Bebaja - Zachariasz, syn Bebaja, i z nim dwudziestu ośmiu mężczyzn,
###### **Ezd 8,12**
 z rodu Azgada - Jochanan, syn Hakkatana, i z nim stu dziesięciu mężczyzn,
###### **Ezd 8,13**
 z rodu Adonikama - ostatni potomkowie: Elifelet, Jejel i Szemajasz, i z nimi sześćdziesięciu mężczyzn,
###### **Ezd 8,14**
 z rodu Bigwaja - Utaj, syn Zabbuda, i z nim siedemdziesięciu mężczyzn.
###### **Ezd 8,15**
 Zgromadziłem ich nad rzeką wpadającą do Achawy. Pozostaliśmy tam trzy dni, podczas których poznałem tych ludzi i kapłanów, lecz nie znalazłem wśród nich lewitów.
###### **Ezd 8,16**
 Posłałem więc do przywódców: Eliezera, Ariela, Szemajasza, Elnatana, Jariba, Elnatana, Natana, Zachariasza i Meszullama, oraz do budowniczych: Jojariba i Elnatana.
###### **Ezd 8,17**
 Poleciłem im udać się do naczelnika Iddo w miejscowości Kasifia z posłaniem, jakie im przekazałem dla Iddo i jego braci mieszkających w Kasifia, a mianowicie, aby nam przysłali sługi do domu naszego Boga.
###### **Ezd 8,18**
 Towarzyszyła nam łaskawa opieka naszego Boga, gdyż przysłali nam mądrego człowieka z rodu Machliego, syna Lewiego, syna Izraela, a mianowicie Szerebiasza z jego synami i braćmi w liczbie osiemnastu osób.
###### **Ezd 8,19**
 Ponadto Chaszabiasza i z nim Merariego wraz z jego braćmi i synami w liczbie dwudziestu osób,
###### **Ezd 8,20**
 oraz dwieście dwadzieścia osób spośród sług świątyni, których Dawid i dostojnicy przeznaczyli do pomocy lewitom. Oni też zostali imiennie wpisani na listę.
###### **Ezd 8,21**
 Potem zarządziłem tam post nad rzeką Achawą, abyśmy się ukorzyli przed naszym Bogiem i uprosili u Niego szczęśliwą drogę dla nas, naszych dzieci i dobytku.
###### **Ezd 8,22**
 Wstydziłem się bowiem prosić króla o eskortę i jeźdźców, by chronili nas w drodze przed nieprzyjacielem, gdyż powiedzieliśmy królowi: „Opieka Boga łaskawie towarzyszy tym, którzy się do Niego uciekają, a Jego srogi gniew obraca się przeciw tym, którzy Go porzucają”.
###### **Ezd 8,23**
 Pościliśmy więc i prosiliśmy o to naszego Boga, a On okazał nam swoją dobroć.
###### **Ezd 8,24**
 Następ nie wybrałem spośród kapłanów dwunastu przywódców oraz Szerebiasza i Chaszabiasza z ich dziesięcioma braćmi.
###### **Ezd 8,25**
 Odważyłem im srebro, złoto i naczynia, czyli dary dla domu naszego Boga ofiarowane przez króla, jego doradców, dostojników i przez wszystkich obecnych tam Izraelitów.
###### **Ezd 8,26**
 Odważyłem im sześćset pięćdziesiąt talentów srebra i sto naczyń srebrnych, każde po dwa talenty, sto talentów złota
###### **Ezd 8,27**
 i dwadzieścia pucharów złotych, każdy po tysiąc darejek i dwa naczynia ze szlachetnego brązu, cennego jak złoto.
###### **Ezd 8,28**
 Poleciłem im: „Wy jesteście poświęceni PANU i naczynia są poświęcone, a srebro i złoto są dobrowolnie ofiarowane PANU, Bogu waszych przodków.
###### **Ezd 8,29**
 Strzeżcie więc ich troskliwie, dopóki ich nie odważycie i nie przekażecie przywódcom kapłanów i lewitów oraz przywódcom rodów Izraela w Jerozolimie, w pomieszczeniach domu PANA”.
###### **Ezd 8,30**
 Wówczas kapłani i lewici zabrali odważone srebro, złoto i naczynia, aby zanieść je do Jerozolimy, do domu naszego Boga.
###### **Ezd 8,31**
 W dwunastym dniu pierwszego miesiąca wyruszyliśmy z obozowiska nad rzeką Achawą, rozpoczynając podróż do Jerozolimy. Towarzyszyła nam opieka naszego Boga i chroniła nas w drodze przed napaściami wrogów i zbójców.
###### **Ezd 8,32**
 Gdy przybyliśmy do Jerozolimy, odpoczywaliśmy tam przez trzy dni.
###### **Ezd 8,33**
 Czwartego dnia odważyliśmy srebro, złoto i naczynia dla domu naszego Boga i przekazaliśmy je kapłanowi Meremotowi, synowi Uriasza, i Eleazarowi, synowi Pinchasa, w obecności lewitów Jozabada, syna Jozuego, i Noadiasza, syna Binnuja.
###### **Ezd 8,34**
 Przekazaliśmy wszystko według liczby i wagi, zapisując równocześnie wagę każdego przedmiotu.
###### **Ezd 8,35**
 Wracający repatrianci złożyli Bogu Izraela następujące ofiary całopalne: dwanaście cielców za całego Izraela, dziewięćdziesiąt sześć baranów, siedemdziesiąt siedem jagniąt i dwanaście kozłów jako ofiarę przebłagalną za grzechy - wszystko jako całopalenie dla PANA.
###### **Ezd 8,36**
 Wręczyli także namiestnikom króla i zarządcom prowincji Transeufratei rozporządzenie królewskie, aby wspomagali lud i otaczali szacunkiem dom Boży.
# Ezd 8 BP
###### **Ezd 8,1**
 A oto przywódcy rodów i pochodzenie tych, którzy za panowania Artakserksesa wyruszyli ze mną z Babel:
###### **Ezd 8,2**
 Spośród synów Pinchasa - Gerszom; spośród synów Itamara - Daniel; spośród synów Dawida - Chattusz,
###### **Ezd 8,3**
 syn Szekanji; spośród synów Parosza - Zekarja, z którym zostało zapisanych stu pięćdziesięciu mężczyzn;
###### **Ezd 8,4**
 spośród synów Pachat-Moaba - Eljoenaj, syn Zerachji, a wraz z nim dwustu mężczyzn;
###### **Ezd 8,5**
 spośród synów Zattua - Szekanja, syn Jachaziela, a z nim trzystu mężczyzn;
###### **Ezd 8,6**
 spośród synów Adina - Ebed, syn Jonatana, a z nim pięćdziesięciu mężczyzn;
###### **Ezd 8,7**
 spośród synów Elama - Jeszaja, syn Atalji, a z nim siedemdziesięciu mężczyzn;
###### **Ezd 8,8**
 spośród synów Szefatji - Zebadja, syn Mikaela, a z nim osiemdziesięciu mężczyzn;
###### **Ezd 8,9**
 spośród synów Joaba - Obadja, syn Jechiela, a z nim dwustu osiemnastu mężczyzn;
###### **Ezd 8,10**
 spośród synów Baniego - Szelomit, syn Josifji, a z nim stu sześćdziesięciu mężczyzn;
###### **Ezd 8,11**
 spośród synów Bebaja - Zekarja, syn Bebaja, a z nim dwudziestu ośmiu mężczyzn;
###### **Ezd 8,12**
 spośród synów Azgada - Jochanan, syn Hakkatana, a a z nim stu dziesięciu mężczyzn;
###### **Ezd 8,13**
 spośród synów Adonikama - młodsi synowie, a oto ich imiona: Elifelet, Jeiel, Szemaja, a z nimi sześćdziesięciu mężczyzn;
###### **Ezd 8,14**
 spośród synów Bigwaja - Utaj i Zabbud, a z nim siedemdziesięciu mężczyzn.
###### **Ezd 8,15**
 Zgromadziłem ich nad rzeką, która płynie koło Achawa, a gdyśmy tam obozowali przez trzy dni, stwierdziłem, że jest lud i że są kapłani, ale nie znalazłem tam nikogo spośród lewitów.
###### **Ezd 8,16**
 Posłałem więc Eliezera, Ariela, Szemaję, Ematana, Natana, Zekarję i Meszullama, roztropnych przywódców [rodów] (Jojariba i Elnatana)
###### **Ezd 8,17**
 i dałem im polecenie do Iddy, przełożonego miejscowości Kasifja. Włożyłem im w usta słowa, które mieli powiedzieć do Iddy i jego braci (należących do Świątyni) osiadłych w miejscowości Kasifja, aby zechcieli nam przysłać sługi dla Świątyni naszego Boga.
###### **Ezd 8,18**
 Ponieważ dobrotliwa ręka naszego Boga czuwała nad nami, przyprowadzili nam oni pewnego mądrego męża spośród synów Machliego, syna Lewiego, syna Izraela, mianowicie Szerebję wraz z jego synami i braćmi - razem osiemnastu mężów;
###### **Ezd 8,19**
 następnie Chaszabję, a z nim Jeszaję spośród synów Merariego wraz z jego braćmi i ich synami - razem dwudziestu mężów;
###### **Ezd 8,20**
 ponadto spośród niewolników Świątyni, których Dawid i książęta przydzielili do posług lewitom - dwustu dwudziestu sług Świątyni. Wszyscy oni byli [do tego zadania] wyznaczeni imiennie.
###### **Ezd 8,21**
 Tam też nad rzeką Achawa ogłosiłem post, aby ukorzyć się przed naszym Bogiem i aby uprosić u Niego szczęśliwą podróż dla nas, naszych dzieci i dla naszego całego dobytku.
###### **Ezd 8,22**
 Wstydziłbym się bowiem prosić króla o zbrojną drużynę i o jazdę dla naszej ochrony przed wrogami w czasie drogi. Owszem, powiedzieliśmy królowi wprost przeciwnie: "Ręka naszego Boga czuwa dobrotliwie nad wszystkimi, którzy Go szukają; moc Jego i gniew uderzają w tych wszystkich, którzy się od Niego odwracają."
###### **Ezd 8,23**
 Tak tedy pościliśmy i szukaliśmy [pomocy] u naszego Boga w tej sprawie. A On nas wysłuchał.
###### **Ezd 8,24**
 Następnie wybrałem dwunastu spośród przedniejszych kapłanów, a także Szerebję i Chaszabję, a wraz z nimi dziesięciu innych spośród ich braci.
###### **Ezd 8,25**
 Odważyłem im srebro, złoto i święte naczynia, datki ofiarne dla Świątyni naszego Boga, które złożyli król, jego doradcy i książęta, jak również wszyscy Izraelici, którzy się tam znajdowali.
###### **Ezd 8,26**
 Odważyłem więc i przekazałem do ich rąk sześćset pięćdziesiąt talentów srebra, sto srebrnych naczyń o wadze dwu talentów, sto talentów złota,
###### **Ezd 8,27**
 dwadzieścia złotych kielichów o wadze tysiąca darejków i dwa naczynia ze szlachetnego brązu, równie cenne jak złoto.
###### **Ezd 8,28**
 I rzekłem im: Wy jesteście poświęceni Jahwe i naczynia te są święte, a srebro i złoto są darem dla Jahwe, Boga ojców waszych.
###### **Ezd 8,29**
 Czuwajcie zatem nad nimi i strzeżcie ich do czasu, aż je odważycie w skarbcu Świątyni Jahwe wobec przełożonych kapłanów i lewitów i wobec przełożonych rodów izraelskich w Jeruzalem.
###### **Ezd 8,30**
 Wzięli więc kapłani i lewici odważone srebro, złoto i naczynia, aby je przenieść do Jeruzalem, do Świątyni naszego Boga.
###### **Ezd 8,31**
 Dnia dwunastego pierwszego miesiąca wyruszyliśmy znad rzeki Achawa, by udać się do Jeruzalem. Ręka naszego Boga czuwała nad nami. On nas ochraniał przed wrogami i łupieżcami w czasie drogi.
###### **Ezd 8,32**
 Tak przybyliśmy do Jeruzalem, gdzie odpoczywaliśmy przez trzy dni.
###### **Ezd 8,33**
 Dnia czwartego odważono srebro i złoto oraz naczynia w Świątyni Boga naszego i złożono je na ręce kapłana Meremota, syna Urijji, wobec Eleazara, syna Pinchasa. Przy nich znajdowali się także lewici Jozabad, syn Jozuego, i Noadja, syn Binnuja.
###### **Ezd 8,34**
 Wszystko [zostało przekazane] według liczby i wagi, a ciężar ogólny został wówczas zapisany.
###### **Ezd 8,35**
 Następnie wszyscy, którzy powrócili z wygnania, synowie niewoli, złożyli Bogu Izraela ofiary całopalne: dwanaście cielców za cały Izrael, dziewięćdziesiąt sześć baranów, siedemdziesiąt siedem jagniąt i dwanaście kozłów jako zadośćuczynienie za grzech, wszystko jako ofiarę całopalną dla Jahwe.
###### **Ezd 8,36**
 I przekazali rozkazy króla jego satrapom i zarządcom kraju za Eufratem, a ci wspomagali lud i Świątynię Boga.
# Ezd 8 BR
###### **Ezd 8,1**
 A oto przywódcy rodów - i rodowody - tych, którzy wyruszyli ze mną z Babilonu za panowania króla Artakserksesa.
###### **Ezd 8,2**
 Z synów Pinchasa - Gerszom; z synów Itamara - Daniel; z synów Dawida - Chattusz,
###### **Ezd 8,3**
 syn Szekaniasza; z synów Parosza - Zachariasz, z którym było zapisanych stu pięćdziesięciu innych mężczyzn;
###### **Ezd 8,4**
 z synów Pachat-Moaba - Elioenaj, syn Zerachiasza, a z nim dwustu mężczyzn;
###### **Ezd 8,5**
 z synów Zattusza - Szekaniasz, syn Jachaziela, a z nim trzystu mężczyzn;
###### **Ezd 8,6**
 z synów Adina - Ebed, syn Jonatana, a z nim pięćdziesięciu mężczyzn;
###### **Ezd 8,7**
 z synów Elama - Izjasz, syn Ataliasza, a z nim siedemdziesięciu mężczyzn;
###### **Ezd 8,8**
 z synów Szefatiasza - Zebadiasz, syn Mikaela, a z nim osiemdziesięciu mężczyzn;
###### **Ezd 8,9**
 z synów Joaba - Obadiasz, syn Jechiela, a z nim dwustu osiemnastu mężczyzn;
###### **Ezd 8,10**
 z synów Baniego - Szelomit, syn Josifiasza, a z nim stu sześćdziesięciu mężczyzn;
###### **Ezd 8,11**
 z synów Bebaja - Zachariasz, syn Bebaja, a z nim dwudziestu ośmiu mężczyzn;
###### **Ezd 8,12**
 z synów Azgada - Jochanan, syn Hakkatana, a z nim stu dziesięciu mężczyzn;
###### **Ezd 8,13**
 z synów Adonikama - tylko najmłodsi, mianowicie: Elifelet, Jejel i Szemajasz, a z nimi sześćdziesięciu mężczyzn;
###### **Ezd 8,14**
 i wreszcie z synów Bigwaja - Utaj, syn Zabbuda, a z nim siedemdziesięciu mężczyzn.
###### **Ezd 8,15**
 Zebrałem ich wszystkich nad rzeką płynącą ku Ahawa, gdzie rozbiliśmy obóz i pozostaliśmy trzy dni. Okazało się wówczas, że przebywa tam tylko lud i kapłani, natomiast nie ma nikogo spośród synów Lewiego.
###### **Ezd 8,16**
 Wezwałem tedy do siebie przywódców, Eliezera, Ariela, Szemajasza, Elnatana, Jariba, Elnatana, Natana, Zachariasza i Meszullama,
###### **Ezd 8,17**
 i wysłałem ich do Iddo, który był zarządcą miejscowości Kasifia. Kazałem powiedzieć zarządcy Iddo i jego braciom mieszkającym w Kasifia, żeby przysłali nam sługi do świątyni naszego Boga.
###### **Ezd 8,18**
 A ponieważ dobroczynna prawica naszego Boga była nad nami, przysłali nam niejakiego Szerebiasza, męża roztropnego. Był on jednym z synów Machliego, syna Lewiego, syna Izraela. Razem z Szerebiaszem przyszli jego synowie i bracia. W sumie było ich osiemnastu.
###### **Ezd 8,19**
 Przyszli ponadto, spośród synów Merariego, Chaszabiasz i jego brat Izajasz, obaj z własnymi synami, razem dwudziestu mężczyzn.
###### **Ezd 8,20**
 Wreszcie dwudziestu mężczyzn również spośród sług świątyni, których jeszcze Dawid i ówcześni przywódcy przeznaczyli do wspomagania lewitów. Wszyscy zostali spisani według imion.
###### **Ezd 8,21**
 Jeszcze tam nad rzeką Ahawą zarządziłem post. Pragnęliśmy bowiem umartwić się przed obliczem Boga naszego, by wyprosić sobie u Niego błogosławieństwo na drogę dla nas, dla naszych dzieci i dla wszystkiego, co stanowiło naszą własność.
###### **Ezd 8,22**
 Wstydziłem się bowiem prosić króla, by nam przydzielił jakąś uzbrojoną straż i konnicę, która by nas w czasie drogi osłaniała przed wrogami. Już wcześniej bowiem powiedzieliśmy królowi: Prawica naszego Boga przychodzi z pomocą tym, którzy szukają Boga, natomiast Jego potęga i gniew są przeciwko tym, którzy od Niego odeszli.
###### **Ezd 8,23**
 Dlatego pościliśmy, wzywając naszego Boga. I On nas wysłuchał.
###### **Ezd 8,24**
 Wybrałem tedy dwunastu starszych spośród kapłanów, dołączyłem do nich Szerebiasza i Chaszabiasza oraz dziesięciu spośród ich braci.
###### **Ezd 8,25**
 Na ich oczach zważyłem srebro, złoto oraz wszystkie przedmioty, które zostały przekazane na świątynię naszego Boga jako dar od króla, jego doradców, przywódców narodu oraz od wszystkich Izraelitów, którzy się tam znajdowali.
###### **Ezd 8,26**
 Po zważeniu przekazałem na ich ręce sześćset pięćdziesiąt talentów srebra, przedmioty ze srebra ważące łącznie sto talentów, sto talentów złota,
###### **Ezd 8,27**
 dwadzieścia pucharów złotych, z których każdy był wart tysiąc darejków, i dwie wazy z pięknego polerowanego brązu, drogiego jak złoto.
###### **Ezd 8,28**
 I powiedziałem im tak: Jesteście poświęceni dla Jahwe, podobnie jak te wszystkie przedmioty. To srebro zaś i złoto zostały złożone jako ofiara dobrowolna dla Jahwe, Boga waszych ojców.
###### **Ezd 8,29**
 Bądźcie mężni i strzeżcie tego wszystkiego, a potem zważcie na oczach przełożonych kapłanów i lewitów oraz przywódców rodów izraelskich w Jerozolimie, w pomieszczeniach świątyni Jahwe.
###### **Ezd 8,30**
 Odebrali tedy kapłani i lewici odważone srebro, złoto i wszystkie przedmioty, ażeby dostarczyć je do Jerozolimy, do świątyni naszego Boga.
###### **Ezd 8,31**
 A myśmy wyruszyli znad rzeki Ahawy dnia dwunastego pierwszego miesiąca, udając się do Jerozolimy. Prawica Boga naszego była zawsze nad nami i osłaniała nas w czasie drogi przed naszymi wrogami i różnymi nieszczęściami.
###### **Ezd 8,32**
 Dotarłszy do Jerozolimy, odpoczywaliśmy przez trzy dni.
###### **Ezd 8,33**
 Dnia czwartego srebro, złoto i wszystkie naczynia zostały zważone w świątyni naszego Boga i przekazane na ręce kapłana Maremota, syna Uriasza. Byli przy tym także obecni: Eleazar, syn Pinchasa, i lewici: Jozabad, syn Jozuego, i Noadiasz, syn Binnuja.
###### **Ezd 8,34**
 Wszystko zostało przekazane według liczby przedmiotów i ogólnej wagi, która została wtedy starannie zapisana.
###### **Ezd 8,35**
 Ci, którzy powrócili z wygnania, jako ofiarę całopalenia na cześć Boga Izraela złożyli dwanaście cielców w imieniu całego Izraela, dziewięćdziesiąt sześć baranów, siedemdziesiąt siedem jagniąt i dwanaście kozłów na ofiarę za grzechy. Taka była ofiara całopalenia na cześć Jahwe.
###### **Ezd 8,36**
 Wręczyli też urzędnikom królewskim i zarządcom kraju za Rzeką rozporządzenie królewskie. Ci zaś, wspierali swoją pomocą cały lud oraz świątynię Pańską.
# Ezd 8 WUJ
###### **Ezd 8,1**
 Ci tedy są przedniejszy domów, i ród onych, którzy wyszli zemną za królowania Artaxerxa króla z Babilonu.
###### **Ezd 8,2**
 Z synów Phinees, Gersom. Z synów Ithamar, Daniel. Z synów Dawidowych, Hattus.
###### **Ezd 8,3**
 Z synów Sechemiaszowych synów Pharos, Zacharyasz: a z nim naliczono mężów sto pięćdziesiąt.
###### **Ezd 8,4**
 Z synów Phahath Moab Elioenaj syn Zarehet, a z nim dwieście mężów.
###### **Ezd 8,5**
 Z synów Sechemiaszowych syn Ezechiel, a z nim trzy sta mężów.
###### **Ezd 8,6**
 Z synów Adan, Abed syn Jonathan, a z nim pięćdziesiąt mężów.
###### **Ezd 8,7**
 Z synów Alam, Isajasz syn Athaliaszów, a z nim siedmdziesiąt mężów.
###### **Ezd 8,8**
 Z synów Saphatiaszowych, Zebedia syn Michael, a z nim ośmdziesiąt mężów.
###### **Ezd 8,9**
 Z synów Joab, Obedia syn Jahiel, a z nim dwieście ośmnaście mężów.
###### **Ezd 8,10**
 Z synów Selomith, syn Josphiów, a z nim sto sześćdziesiąt mężów.
###### **Ezd 8,11**
 Z synów Bebai, Zacharyasz syn Bebai, a z nim dwadzieścia ośm mężów.
###### **Ezd 8,12**
 Z synów Azgad, Johanan syn Ekcetan, a z nim sto i dziesięć mężów.
###### **Ezd 8,13**
 Z synów Adonikam, którzy byli ostateczni, a te imiona ich: Elipheleth, i Jehiel, i Samajas, a z nimi sześćdziesiąt mężów.
###### **Ezd 8,14**
 Z synów Begui, Uthaj, i Zachur, a z nimi siedmdziesiąt mężów.
###### **Ezd 8,15**
 A zgromadziłem je do rzeki, która wchodzi do Ahawa, i mieszkaliśmy tam trzy dni: i szukałem między ludem i kapłany, synów Lewi, i nie nalazłem tam.
###### **Ezd 8,16**
 A tak posłałem Eliezer i Ariel, i Semejasza, i Elnathan, i Jarib, i drugiego Elnathan i Nathan, i Zacharyasza, i Mosollam, przełożone, i Jojarib, i Elnathan mędrce.
###### **Ezd 8,17**
 I posłałem ich do Eddo, który jest pierwszy na miejscu Chasphiiej, i włożyłem w usta ich słowa któreby mówili do Eddo i do bracie j jego Nathynejczyków, na miejscu Chasphiiej, aby nam przywiedli sługi domu Boga naszego.
###### **Ezd 8,18**
 I przywiedli nam, przez rękę Boga naszego dobrą nad nami, męża nauczonego, z synów Moholi syna Lewi syna Izrael, i Sarabiasza i syny jego i braciej jego ośmnaście.
###### **Ezd 8,19**
 I Hasabiasza, a z nim Isajasza synów Merari, i braciej jego, i synów jego dwadzieścia:
###### **Ezd 8,20**
 I z Nathynejczyków, które był dał Dawid i książęta na posługi Lewitom, Nathynejczyków dwieście dwadzieścia: wszyscy dymiony swemi byli mianowani.
###### **Ezd 8,21**
 I zapowiedziałem tam post u rzeki Ahawa, abyśmy się dręczyli przed Panem Bogiem naszym, a prosili od niego drogi prostej sobie i synom naszym, i wszystkiej majętności naszej.
###### **Ezd 8,22**
 Bom się wstydał prosić u króla pomocy i jezdnych, którzyby nas bronili od nieprzyjaciela na drodze: bośmy mówili królowi: Ręka Boga naszego jest nad wszystkimi, którzy go szukają w dobroci: a panowanie jego i moc jego i zapalczywość, nad wszystkimi, którzy go opuszczają.
###### **Ezd 8,23**
 I pościliśmy i prosiliśmy Boga naszego o to, i powiodło się nam szczęśliwie.
###### **Ezd 8,24**
 I odłączyłem z książąt kapłańskich dwanaście, Sarabiasza i Hasabiasza, a z nimi z braciej ich dziesięć.
###### **Ezd 8,25**
 I odważyłem im srebro i złoto, i naczynie poświęcone domu Boga naszego, które był ofiarował król i rady jego, i książęta jego i wszystek Izrael z tych, którzy się byli naleźli:
###### **Ezd 8,26**
 I odważyłem w ich ręku srebra talentów sześć set pięćdziesiąt, i sto naczynia srebrnego, złota sto talentów:
###### **Ezd 8,27**
 A czasz złotych dwadzieścia, które miały po ty, siać czerwonych złotych, a naczynia miedzi jasnej barzo dobrej dwoje, piękne jako złoto.
###### **Ezd 8,28**
 I rzekłem im: Wyście święci Pańscy, i naczynie święte, i srebro i złoto, które dobrowolnie jest ofiarowane Panu Bogu ojców waszych.
###### **Ezd 8,29**
 Czujcież a strzeżcie, aż odważycie przed książęty Kapłanów i Lewitów, i przed książęty domów Izraelskich w Jeruzalem, do skarbu domu Pańskiego.
###### **Ezd 8,30**
 I wzięli kapłani i Lewitowie wagę srebra i złota i naczynia, żeby odnieśli do Jeruzalem do domu Boga naszego.
###### **Ezd 8,31**
 A tak ruszyliśmy się od rzeki Ahawa dwunastego dnia księżyca pierwszego, abyśmy szli do Jeruzalem: a ręka Boga naszego była nad nami, i wybawił nas i ręki nie przyjaciela i czyhającego na drodze.
###### **Ezd 8,32**
 I przyszliśmy do Jeruzalem, i mieszkaliśmy tam trzy dni.
###### **Ezd 8,33**
 A czwartego dnia odważono srebro i złoto, i naczynie w domu Boga naszego przez rękę Meremoth syna Uryasza kapłana, a z nim Eleazar syn Phineesów, a z nimi Jozabed syn Jozuego i Noadaja syn Bennoi Lewitowie,
###### **Ezd 8,34**
 Według liczby i wagi wszystkich rzeczy: i spisano wszystkę wagę czasu onego.
###### **Ezd 8,35**
 Ale i którzy byli przyszli z poimania, synowie przeprowadzenia, ofiarowali całopalenia Bogu Izraelowemu, cielców dwanaście, za wszystek lud Izraelski, baranów dziewięćdziesiąt sześć, baranków siedmdziesiąt siedm, kozłów za grzech dwanaście: wszystko na całopalenie Panu,
###### **Ezd 8,36**
 A wyroki królewskie oddali Panom, którzy byli od oczu królewskich i książętam za rzeką, i wywyższyli lud i dom Boży,
