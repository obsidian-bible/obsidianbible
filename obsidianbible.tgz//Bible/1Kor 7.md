# 1Kor 7 BT5
###### **1Kor 7,1**
 Co do spraw, o których pisaliście, to dobrze jest mężczyźnie nie łączyć się z kobietą.
###### **1Kor 7,2**
 Ze względu jednak na niebezpieczeństwo rozpusty niech każdy ma swoją żonę, a każda swojego męża.
###### **1Kor 7,3**
 Mąż niech oddaje powinność żonie, podobnie też żona mężowi.
###### **1Kor 7,4**
 Żona nie rozporządza własnym ciałem, lecz jej mąż; podobnie też i mąż nie rozporządza własnym ciałem, ale żona.
###### **1Kor 7,5**
 Nie unikajcie jedno drugiego, chyba że na pewien czas, za obopólną zgodą, by oddać się modlitwie; potem znów wróćcie do siebie, aby – wskutek niewstrzemięźliwości waszej – nie kusił was szatan.
###### **1Kor 7,6**
 To, co mówię, pochodzi z wyrozumiałości, a nie z nakazu.
###### **1Kor 7,7**
 Pragnąłbym, aby wszyscy byli jak i ja sam, lecz każdy jest obdarowany przez Boga inaczej: jeden tak, a drugi tak.
###### **1Kor 7,8**
 Tym zaś, którzy nie wstąpili w związki małżeńskie, oraz tym, którzy już owdowieli, mówię: dobrze będzie, jeśli pozostaną jak i ja.
###### **1Kor 7,9**
 Lecz jeśliby nie potrafili zapanować nad sobą, niech wstępują w związki małżeńskie. Lepiej jest bowiem żyć w małżeństwie, niż płonąć.
###### **1Kor 7,10**
 Tym zaś, którzy trwają w związkach małżeńskich, nakazuję nie ja, lecz Pan: Żona niech nie odchodzi od swego męża!
###### **1Kor 7,11**
 Gdyby zaś odeszła, niech pozostanie samotna albo niech się pojedna ze swym mężem. Mąż również niech nie oddala żony.
###### **1Kor 7,12**
 Pozostałym zaś mówię ja, nie Pan: Jeśli któryś z braci ma żonę niewierzącą i ta chce razem z nim mieszkać, niech jej nie oddala.
###### **1Kor 7,13**
 Podobnie jeśli jakaś żona ma niewierzącego męża i ten chce razem z nią mieszkać, niech się z nim nie rozstaje.
###### **1Kor 7,14**
 Uświęca się bowiem mąż niewierzący dzięki swej żonie, podobnie jak uświęca się niewierząca żona przez "brata". W przeciwnym wypadku dzieci wasze byłyby nieczyste, teraz zaś są święte.
###### **1Kor 7,15**
 Lecz jeśliby strona niewierząca chciała odejść, niech odejdzie! Nie jest skrępowany ani "brat", ani "siostra" w tym wypadku. Albowiem do życia w pokoju powołał nas Bóg.
###### **1Kor 7,16**
 A skądże zresztą możesz wiedzieć, żono, że zbawisz twego męża? Albo czy jesteś pewien, mężu, że zbawisz twoją żonę?
###### **1Kor 7,17**
 Zresztą niech każdy postępuje tak, jak mu Pan wyznaczył, zgodnie z tym, do czego Bóg go powołał. Ja tak właśnie nauczam we wszystkich Kościołach.
###### **1Kor 7,18**
 Jeśli ktoś został powołany jako obrzezany, niech nie pozbywa się znaku obrzezania; jeśli zaś ktoś został powołany jako nieobrzezany, niech się nie poddaje obrzezaniu.
###### **1Kor 7,19**
 Niczym jest zarówno obrzezanie, jak i nieobrzezanie, a ważne jest tylko zachowywanie przykazań Bożych.
###### **1Kor 7,20**
 Każdy przeto niech pozostanie w takim stanie, w jakim został powołany.
###### **1Kor 7,21**
 Zostałeś powołany jako niewolnik? Nie martw się! Owszem, nawet jeśli możesz stać się wolnym, raczej skorzystaj [z twego niewolnictwa]!
###### **1Kor 7,22**
 Albowiem ten, kto został powołany w Panu jako niewolnik, jest wyzwoleńcem Pana. Podobnie i ten, kto został powołany jako wolny, staje się niewolnikiem Chrystusa.
###### **1Kor 7,23**
 Za [wielką] bowiem cenę zostaliście nabyci. Nie bądźcie więc niewolnikami ludzi!
###### **1Kor 7,24**
 Bracia, niech przeto każdy trwa u Boga w takim stanie, w jakim został powołany.
###### **1Kor 7,25**
 Nie mam zaś nakazu Pańskiego co do dziewic, lecz daję radę jako ten, który – wskutek doznanego od Pana miłosierdzia – godzien jest, aby mu wierzono.
###### **1Kor 7,26**
 Uważam, iż przy obecnych utrapieniach dobrze jest tak zostać, dobrze to dla człowieka tak żyć.
###### **1Kor 7,27**
 Jesteś związany z żoną? Nie usiłuj odłączać się od niej! Jesteś wolny? Nie szukaj żony!
###### **1Kor 7,28**
 Ale jeśli się ożenisz, nie grzeszysz. Podobnie i dziewica, jeśli wychodzi za mąż, nie grzeszy. Tacy jednak cierpieć będą udręki ciała, a ja chciałbym ich wam oszczędzić.
###### **1Kor 7,29**
 Mówię [wam], bracia, czas jest krótki. Trzeba więc, aby ci, którzy mają żony, tak żyli, jakby byli nieżonaci,
###### **1Kor 7,30**
 a ci, którzy płaczą, tak jakby nie płakali, ci zaś, którzy się radują, tak jakby się nie radowali; ci zaś, którzy nabywają, jak gdyby nie posiadali;
###### **1Kor 7,31**
 ci, którzy używają tego świata, tak jakby z niego nie korzystali. Przemija bowiem postać tego świata.
###### **1Kor 7,32**
 A ja chciałbym, żebyście byli wolni od utrapień. Człowiek bezżenny troszczy się o sprawy Pana, o to, jak by się przypodobać Panu.
###### **1Kor 7,33**
 Ten zaś, kto wstąpił w związek małżeński, zabiega o sprawy świata, o to, jak by się przypodobać żonie.
###### **1Kor 7,34**
 I doznaje rozterki. Podobnie i kobieta: niezamężna i dziewica troszczy się o sprawy Pana, o to, by była święta i ciałem, i duchem. Ta zaś, która wyszła za mąż, zabiega o sprawy świata, o to, jak by się przypodobać mężowi.
###### **1Kor 7,35**
 Mówię to dla waszego pożytku, nie zaś, by zastawiać na was pułapkę; ale po to, byście godnie i z upodobaniem trwali przy Panu.
###### **1Kor 7,36**
  Jeżeli ktoś jednak uważa, że nieuczciwość popełnia wobec swej dziewicy, jako że przeszły już jej lata, i jest przekonany, że tak powinien postąpić, niech czyni, co chce: nie zgrzeszy; niech się pobiorą.
###### **1Kor 7,37**
 Lecz jeśli ktoś, bez jakiegokolwiek przymusu, w pełni panując nad swoją wolą, postanowił sobie mocno w sercu zachować nietkniętą swoją dziewicę, dobrze czyni.
###### **1Kor 7,38**
 Tak więc dobrze czyni, kto poślubia swoją dziewicę, a jeszcze lepiej ten, kto jej nie poślubia.
###### **1Kor 7,39**
 Żona związana jest tak długo, jak długo żyje jej mąż. Kiedy mąż umrze, może poślubić, kogo chce, byleby w Panu.
###### **1Kor 7,40**
 Szczęśliwsza jednak będzie, jeżeli pozostanie tak, jak jest, zgodnie z moją radą. A wydaje mi się, że ja też mam Ducha Bożego.
# 1Kor 7 PAU
###### **1Kor 7,1**
 Co do spraw, o których pisaliście: to dobrze jest, gdy mężczyzna nie wiąże się z kobietą.
###### **1Kor 7,2**
 Ze względu jednak na niebezpieczeństwo rozpusty niech każdy ma swoją żonę, a każda kobieta swojego męża.
###### **1Kor 7,3**
 Mąż niech pełni swą powinność wobec żony, podobnie i żona wobec męża.
###### **1Kor 7,4**
 Żona nie rozporządza własnym ciałem, lecz jej mąż; podobnie mąż nie rozporządza własnym ciałem, ale jego żona.
###### **1Kor 7,5**
 Nie unikajcie się nawzajem, chyba że za obopólną zgodą, na jakiś czas, aby oddać się modlitwie. Potem znów bądźcie razem, aby szatan nie kusił was rozpustą.
###### **1Kor 7,6**
 Mówię o tym nie w formie nakazu, ale w duchu wyrozumiałości.
###### **1Kor 7,7**
 Chciałbym, aby wszyscy ludzie żyli jak ja, ale każdy ma swój własny charyzmat od Boga, jeden taki, drugi inny.
###### **1Kor 7,8**
 Do tych, którzy nie żyją w małżeństwie, i do wdów mówię: Dobrze będzie dla nich, jeśli jak ja pozostaną w tym stanie.
###### **1Kor 7,9**
 Jeśli jednak temu nie sprostają, niech wstępują w związek małżeński. Lepiej jest bowiem zawrzeć małżeństwo, niż płonąć pożądliwością!
###### **1Kor 7,10**
 Tym natomiast, którzy już wstąpili w związek małżeński, nakazuję nie ja, ale Pan: Żonie nie wolno odchodzić od męża,
###### **1Kor 7,11**
 a jeśli już odejdzie, niech pozostanie niezamężna albo niech pojedna się z mężem. Tak samo mąż niech nie odchodzi od żony.
###### **1Kor 7,12**
 Pozostałym mówię ja, nie Pan: Jeśli któryś z braci ma żonę niewierzącą i ta chce z nim mieszkać, niech jej nie odrzuca.
###### **1Kor 7,13**
 Tak samo żona, jeśli ma niewierzącego męża i ten chce z nią mieszkać, niech go nie odrzuca.
###### **1Kor 7,14**
 Niewierzący mąż uświęca się bowiem dzięki żonie i uświęca się niewierząca żona dzięki temu bratu. Gdyby było inaczej, wasze dzieci byłyby nieczyste, a tak są święte.
###### **1Kor 7,15**
 Gdyby jednak niewierzący chciał odejść, niech odejdzie. W tym przypadku brat lub siostra nie są skrępowani. Bóg przecież powołał was do życia w pokoju!
###### **1Kor 7,16**
 Skąd wiesz, żono, że zbawisz męża? Albo, mężu, czy wiesz, że zbawisz żonę?
###### **1Kor 7,17**
 Poza tym, niech każdy tak postępuje, jak mu wyznaczył Pan. Niech działa zgodnie z Bożym powołaniem. Takie polecenie daję we wszystkich Kościołach.
###### **1Kor 7,18**
 Gdy Bóg powołał kogoś jako obrzezanego, niech się tego nie zapiera. Gdy ktoś jest nieobrzezany, niech nie poddaje się obrzezaniu.
###### **1Kor 7,19**
 Ani obrzezanie, ani nieobrzezanie nic nie znaczą. Ważne jest przestrzeganie przykazań Bożych.
###### **1Kor 7,20**
 Niech każdy trwa w tym stanie, w jakim go Bóg powołał.
###### **1Kor 7,21**
 Zostałeś powołany jako niewolnik? Nie przejmuj się. Jeśli możesz stać się wolnym, skorzystaj z tego.
###### **1Kor 7,22**
 Kogo bowiem Pan powołał jako niewolnika, jest wyzwoleńcem Pana; tak samo też wolny jest niewolnikiem Chrystusa.
###### **1Kor 7,23**
 Za wielką cenę wykupił was Bóg! Nie bądźcie niewolnikami ludzi!
###### **1Kor 7,24**
 Bracia! Niech każdy trwa przed Bogiem w tym stanie, w jakim został powołany.
###### **1Kor 7,25**
 Nie mam nakazu od Pana co do dziewic. Obdarzony miłosierdziem przez Pana, który jest wiarygodny, daję im taką radę.
###### **1Kor 7,26**
 Myślę, że w obecnej trudnej sytuacji pożyteczne jest pozostać w takim stanie. Dobrze jest dla człowieka trwać w takim stanie.
###### **1Kor 7,27**
 Jesteś żonaty? Nie opuszczaj żony. Jesteś wolny? Nie szukaj żony.
###### **1Kor 7,28**
 Jeśli jednak się ożenisz, nie popełnisz grzechu. I jeśli dziewica wyjdzie za mąż, nie popełni grzechu. Tacy jednak będą podlegać udrękom ciała, a ja chciałbym was od nich uchronić.
###### **1Kor 7,29**
 Bracia! Mówię wam: czas jest krótki. Niech więc ci, którzy mają żony, tak żyją, jakby ich nie mieli.
###### **1Kor 7,30**
 Ci, którzy płaczą, jakby nie płakali. Ci, którzy się cieszą, jakby się nie cieszyli. Ci, którzy kupują, jakby nie nabywali.
###### **1Kor 7,31**
 Ci, którzy korzystają z tego świata, jakby z niego nie korzystali: bo przemija postać tego świata!
###### **1Kor 7,32**
 A ja chcę, żebyście byli wolni od trosk. Człowiek bezżenny zabiega o sprawy Pana, aby podobać się Panu.
###### **1Kor 7,33**
 Człowiek żonaty zabiega natomiast o sprawy świata, aby podobać się żonie.
###### **1Kor 7,34**
 I jest w rozterce. Podobnie kobieta: niezamężna i dziewica zabiega o sprawy Pana, by było święte jej ciało i duch. Mężatka zabiega o sprawy świata, aby podobać się mężowi.
###### **1Kor 7,35**
 Wszystko to mówię dla waszego dobra, a nie by zastawiać na was pułapkę. Mówię po to, abyście bez przerwy służyli Panu godnie i wytrwale.
###### **1Kor 7,36**
 Jeśli ktoś ma obawy, czy jest uczciwy wobec powierzonej sobie dziewicy, ponieważ mija jej młodość, niech podejmie decyzję: nie grzeszy, jeśli się pobiorą.
###### **1Kor 7,37**
 Ten jednak, kto utwierdził się w przekonaniu bez żadnego przymusu, panuje nad swoją wolą i podjął przemyślaną decyzję, by zachować swoją dziewicę - pięknie postąpi.
###### **1Kor 7,38**
 Ten, kto poślubia swoją dziewicę, czyni pięknie, ale ten, co się nie ożeni, czyni lepiej.
###### **1Kor 7,39**
 Żona jest związana z mężem tak długo, dopóki on żyje. Gdy mąż umrze, jest wolna, może poślubić kogo zechce, byleby w Panu.
###### **1Kor 7,40**
 Według mojego przekonania będzie jednak szczęśliwsza, gdy wytrwa w swoim stanie. A uważam, że i ja mam Ducha Bożego.
# 1Kor 7 BP
###### **1Kor 7,1**
 Przechodzę teraz do spraw, o których pisaliście. Otóż dobrze jest dla mężczyzny, jeżeli nie żyje z kobietą.
###### **1Kor 7,2**
 Ze względu jednak na niebezpieczeństwo rozpusty niech każdy ma swoją żonę, a każda kobieta swojego męża.
###### **1Kor 7,3**
 Niech mąż oddaje powinność małżeńską żonie, a żona mężowi.
###### **1Kor 7,4**
 Żona nie może swobodnie dysponować własnym ciałem, lecz jej mąż. Podobnie i mąż nie może swobodnie dysponować własnym ciałem, lecz jego żona.
###### **1Kor 7,5**
 Nie uchylajcie się od współżycia małżeńskiego, chyba za wspólną zgodą i tylko na pewien czas, aby poświęcić się modlitwie. Potem znowu podejmijcie współżycie, aby nie kusił was szatan, wykorzystując waszą niepowściągliwość.
###### **1Kor 7,6**
 Mówię wam o tych sprawach nie w formie nakazu, lecz z wyrozumiałością.
###### **1Kor 7,7**
 Pragnąłbym bowiem, aby wszyscy ludzie żyli tak jak ja. Każdy jednak otrzymuje od Boga własny dar: jeden taki, a drugi inny.
###### **1Kor 7,8**
 Ci, którzy nie zawarli związków małżeńskich, i wdowy dobrze postąpią, gdy tak jak ja wytrwają w tym stanie.
###### **1Kor 7,9**
 Jeśli jednak nie są powściągliwi, niech wstąpią w związki małżeńskie. Lepiej jest bowiem zawrzeć małżeństwo, niż płonąć ogniem pożądliwości.
###### **1Kor 7,10**
 Do tych zaś, którzy wstąpili w związek małżeński, zwracam się z nakazem nie swoim, lecz danym przez Pana: niech żona nie odchodzi od męża.
###### **1Kor 7,11**
 Jeśliby zaś odeszła, niech pozostanie samotna lub ponownie połączy się ze swoim mężem. Podobnie i mąż niech nie oddala od siebie żony.
###### **1Kor 7,12**
 Pozostałym małżeństwom oświadczam ja, a nie Pan: Jeżeli któryś z braci ma żonę niewierzącą, a ona zgadza się z nim nadal mieszkać, niech jej nie oddala.
###### **1Kor 7,13**
 Podobnie jeżeli jakaś kobieta wierząca ma niewierzącego męża, a ten zgadza się mieszkać z nią, niech nie zrywa z nim związku małżeńskiego.
###### **1Kor 7,14**
 Mąż niewierzący zostaje bowiem uświęcony przez żonę, a żona niewierząca przez brata. Gdyby było inaczej, wasze dzieci byłyby nieczyste, a tymczasem są święte.
###### **1Kor 7,15**
 Gdyby jednak strona niewierząca chciała odejść, niech odejdzie. W takim wypadku ani brat, ani siostra nie są skrępowani jak niewolnicy, ponieważ Bóg powołał was do życia w pokoju.
###### **1Kor 7,16**
 Skąd bowiem wiesz, żono, że zbawisz męża? Albo skąd wiesz, mężu, że zbawisz żonę?
###### **1Kor 7,17**
 Zresztą niech każdy pozostaje w tym stanie, który mu Bóg przeznaczył i do którego powołał. W ten sposób rozporządzam we wszystkich Kościołach.
###### **1Kor 7,18**
 Jeżeli ktoś został powołany do wiary jako obrzezany, niech znaku obrzezania nie ukrywa. Jeżeli ktoś został powołany jako nie obrzezany, niech się obrzezaniu nie poddaje.
###### **1Kor 7,19**
 Zarówno obrzezanie jak i nieobrzezanie nie ma bowiem znaczenia, liczy się tylko przestrzeganie przykazań Bożych.
###### **1Kor 7,20**
 Każdy niechaj wytrwa w tym stanie, w jakim zastało go powołanie do wiary.
###### **1Kor 7,21**
 Zostałeś powołany jako niewolnik? Nie martw się tym! Jeśli możesz nawet uzyskać wolność, nie ubiegaj się o nią, lecz wykorzystaj swój stan.
###### **1Kor 7,22**
 Ponieważ ten, kto został powołany w Panu jako niewolnik, jest wyzwoleńcem Pana. Podobnie i ten, który został powołany jako wolny, jest niewolnikiem Chrystusa.
###### **1Kor 7,23**
 Bóg nabył was na własność za wielką cenę. Nie bądźcie zatem niewolnikami ludzi!
###### **1Kor 7,24**
 Bracia! Niech każdy wytrwa przez Bogiem w tym stanie, w jakim zastało go powołanie do wiary.
###### **1Kor 7,25**
 Nie mam natomiast nakazu od Pana dotyczącego dziewic. Daję jednak radę jako człowiek zasługujący na zaufanie, dzięki miłosierdziu jakiego doznałem od Pana.
###### **1Kor 7,26**
 Uważam więc, że dziewictwo jest dobre w obecnej trudnej sytuacji. Dobrze jest dla mężczyzny, aby trwał w tym stanie.
###### **1Kor 7,27**
 Jesteś związany z żoną? Nie szukaj uwolnienia! Jesteś wolny? Nie szukaj żony!
###### **1Kor 7,28**
 Jeśli jednak zawrzesz związek małżeński, nie zgrzeszysz. Podobnie i dziewica, jeśli wychodzi za mąż, nie grzeszy. Tacy jednak będą doznawać w życiu udręki ze strony ciała, a ja chciałbym jej wam zaoszczędzić.
###### **1Kor 7,29**
 Mówię wam, bracia: czas [życia ludzkiego] jest krótki. Trzeba więc, aby żonaci tak żyli, jakby żon nie mieli,
###### **1Kor 7,30**
 płaczący, jakby nie płakali, cieszący się, jakby się nie cieszyli, kupujący, jakby niczego na stałe nie posiadali,
###### **1Kor 7,31**
 korzystający z tego świata, jakby z niego nie korzystali. Przemija bowiem postać tego świata.
###### **1Kor 7,32**
 Chciałbym, żebyście byli wolni od trosk. Ten, kto nie ma żony, troszczy się tylko o sprawy Pana i zabiega o to, aby się Panu podobać.
###### **1Kor 7,33**
 Natomiast mężczyzna żonaty troszczy się o sprawy świata i zabiega o to, aby podobać się żonie.
###### **1Kor 7,34**
 Musi więc dzielić sprawy Pana i sprawy ziemskie. Podobnie kobieta niezamężna oraz dziewica troszczy się tylko o sprawy Pana i o to, aby była święta zarówno ciałem, jak i duchem. Natomiast ta, która wyszła za mąż, troszczy się o sprawy świata i o to, aby podobać się mężowi.
###### **1Kor 7,35**
 A mówię o tym dla waszego osobistego dobra, ze względu na piękno tego stanu i możliwość trwania przy Panu bez rozproszeń, a nie po to, aby zastawić na was pułapkę.
###### **1Kor 7,36**
 Jeżeli jednak ktoś uważa, że nie postępuje uczciwie wobec powierzonej jego opiece dziewicy, widząc jak przekracza ona wiek odpowiedni do zawarcia małżeństwa, niech czyni, co chce. Nie grzeszy. Niech się pobierają.
###### **1Kor 7,37**
 Kto natomiast nie zmuszony żadną koniecznością i w pełni panując nad swoją wolą powziął mocną decyzję, że zachowa swą dziewicę w tym stanie, dobrze uczyni.
###### **1Kor 7,38**
 Wobec tego dobrze czyni ten, kto poślubia swą dziewicę, lecz ten, kto jej nie poślubia, czyni lepiej.
###### **1Kor 7,39**
 Żona związana jest węzłem małżeńskim, dopóki żyje jej mąż. Jeżeli mąż umrze, może swobodnie poślubić, kogo tylko zechce pod warunkiem, że będzie to małżeństwo w Panu.
###### **1Kor 7,40**
 Będzie jednak szczęśliwsza, jeżeli pozostanie tak, jak jest. Taka jest moja rada; a wydaje mi się, że i ja mam Ducha Bożego.
# 1Kor 7 BR
###### **1Kor 7,1**
 Co do spraw, o których pisaliście, to dobrze jest mężczyźnie nie łączyć się z kobietą.
###### **1Kor 7,2**
 Ze względu jednak na niebezpieczeństwo rozpusty niech każdy ma swoją żonę, a każda swojego męża.
###### **1Kor 7,3**
 Mąż niech oddaje powinność żonie, podobnie też żona mężowi.
###### **1Kor 7,4**
 Żona nie rozporządza własnym ciałem, lecz jej mąż; podobnie też i mąż nie rozporządza własnym ciałem, ale żona.
###### **1Kor 7,5**
 Nie unikajcie jedno drugiego, chyba że na pewien czas, za obopólną zgodą, by oddać się modlitwie; potem znów wróćcie do siebie, aby - wskutek niewstrzemięźliwości waszej - nie kusił was szatan.
###### **1Kor 7,6**
 To, co mówię, pochodzi z wyrozumiałości, a nie z nakazu.
###### **1Kor 7,7**
 Pragnąłbym, aby wszyscy byli jak i ja, lecz każdy jest obdarowany przez Boga inaczej: jeden tak, a drugi tak.
###### **1Kor 7,8**
 Tym zaś, którzy nie wstąpili w związki małżeńskie, oraz tym, którzy już owdowieli, mówię: dobrze będzie, jeżeli pozostaną jak i ja.
###### **1Kor 7,9**
 Lecz jeśli nie potrafiliby zapanować nad sobą, niech wstępują w związki małżeńskie. Lepiej jest bowiem żyć w małżeństwie niż płonąć.
###### **1Kor 7,10**
 Tym zaś, którzy trwają w związkach małżeńskich, nakazuję nie ja, lecz Pan: Żona niech nie odchodzi od swego męża.
###### **1Kor 7,11**
 Gdyby zaś odeszła, niech pozostanie samotną albo niech się pojedna ze swym mężem. Mąż również niech nie oddala się od żony.
###### **1Kor 7,12**
 Pozostałym zaś mówię ja, nie Pan: Jeśli któryś z braci ma żonę niewierzącą i ta chce razem z nim mieszkać, niech jej nie oddala.
###### **1Kor 7,13**
 Podobnie jeśli jakaś żona ma niewierzącego męża i ten chce razem z nią mieszkać, niech się z nim nie rozstaje.
###### **1Kor 7,14**
 Uświęca się bowiem mąż niewierzący dzięki swej żonie, podobnie jak świętość osiągnie niewierząca żona przez brata. W przeciwnym wypadku dzieci wasze byłyby nieczyste, teraz zaś są czyste.
###### **1Kor 7,15**
 Lecz jeśliby strona niewierząca chciała odejść, niech odejdzie. Nie jest skrępowany ani brat, ani siostra w tym wypadku. Albowiem do życia w pokoju powołał nas Bóg.
###### **1Kor 7,16**
 A skądże zresztą możesz wiedzieć, żono, że zbawisz twego męża? Albo czy jesteś pewien, mężu, że zbawisz twoją żonę?
###### **1Kor 7,17**
 Zresztą niech każdy postępuje tak, jak mu Pan wyznaczył, zgodnie z tym, do czego Bóg go powołał. Ja tak właśnie nauczałem we wszystkich Kościołach.
###### **1Kor 7,18**
 Jeśli ktoś został powołany jako obrzezany, niech nie pozbywa się znaku obrzezania; jeśli zaś ktoś został powołany jako nie obrzezany, niech się nie poddaje obrzezaniu.
###### **1Kor 7,19**
 Niczym jest zarówno obrzezanie, jak i nieobrzezanie, a ważne jest tylko zachowywanie przykazań Bożych.
###### **1Kor 7,20**
 Każdy przeto niech pozostanie w takim stanie, w jakim został powołany.
###### **1Kor 7,21**
 Zostałeś powołany jako niewolnik? Nie martw się! Owszem, nawet jeśli możesz stać się wolnym, raczej skorzystaj [z tego niewolnictwa].
###### **1Kor 7,22**
 Albowiem ten, kto został powołany w Panu jako niewolnik, jest wyzwoleńcem Pana. Podobnie i ten, kto został powołany jako wolny, staje się niewolnikiem Chrystusa.
###### **1Kor 7,23**
 Za [wielką] bowiem cenę zostaliście nabyci. Nie bądźcie więc niewolnikami ludzi.
###### **1Kor 7,24**
 Bracia, niech przeto każdy trwa u Boga w takim stanie, w jakim został powołany.
###### **1Kor 7,25**
 Nie mam zaś nakazu Pańskiego co do dziewic, lecz daję radę jako ten, który - wskutek doznanego od Pana miłosierdzia - godzien jest, aby mu wierzono.
###### **1Kor 7,26**
 Uważam, iż przy obecnych utrapieniach dobrze jest tak zostać, dobrze to dla człowieka tak żyć.
###### **1Kor 7,27**
 Jesteś związany z żoną? Nie usiłuj odłączać się od niej. Jesteś wolny? Nie szukaj żony.
###### **1Kor 7,28**
 Ale jeśli się ożenisz, nie grzeszysz. Podobnie i dziewica, jeśli wychodzi za mąż, nie grzeszy. Tacy jednak cierpieć będą udręki w ciele, a ja chciałbym ich wam oszczędzić.
###### **1Kor 7,29**
 Mówię wam, bracia: czas jest krótki. Trzeba więc, aby ci, którzy mają żony, tak żyli, jakby byli nieżonaci,
###### **1Kor 7,30**
 a ci, którzy płaczą, tak jakby nie płakali, ci zaś, którzy się radują, tak jakby się nie radowali, ci zaś, którzy nabywają, jak gdyby nie posiadali;
###### **1Kor 7,31**
 ci, którzy używają tego świata, tak jakby z niego nie korzystali. Przemija bowiem postać tego świata.
###### **1Kor 7,32**
 A ja chciałbym, żebyście byli wolni od utrapień. Człowiek bezżenny troszczy się o sprawy Pana, o to, jak by przypodobać się Panu.
###### **1Kor 7,33**
 Ten zaś, kto wstąpił w związek małżeński, zabiega o sprawy świata, o to, jak by się przypodobać żonie.
###### **1Kor 7,34**
 I doznaje rozterki. Podobnie i kobieta: niezamężna i dziewica troszczy się o sprawy Pana, o to, by była święta i ciałem, i duchem. Ta zaś, która wyszła za mąż, zabiega o sprawy świata, o to, jak by się przypodobać mężowi.
###### **1Kor 7,35**
 Mówię to dla waszego pożytku, nie zaś, by zastawiać na was pułapkę; po to, byście godnie i z upodobaniem trwali przy Panu.
###### **1Kor 7,36**
 Jeżeli ktoś jednak uważa, że nieuczciwość popełnia wobec swej dziewicy, jako że przeszły już jej lata, i jest przekonany, że tak powinien postąpić, niech czyni, co chce: nie zgrzeszy; niech się pobiorą.
###### **1Kor 7,37**
 Lecz jeśli ktoś, bez jakiegokolwiek przymusu, w pełni panując nad swoją wolą, postanowił sobie mocno w sercu zachować nietkniętą swoją dziewicę, dobrze czyni.
###### **1Kor 7,38**
 Tak więc dobrze czyni, kto poślubia swoją dziewicę, a jeszcze lepiej ten, kto jej nie poślubia.
###### **1Kor 7,39**
 Żona związana jest tak długo, jak długo żyje jej mąż. Kiedy mąż umrze, może poślubić, kogo chce, byleby w Panu.
###### **1Kor 7,40**
 Szczęśliwsza jednak będzie, jeżeli pozostanie tak, jak jest, zgodnie z moją radą. A wydaje mi się, że ja też mam Ducha Bożego.
# 1Kor 7 WUJ
###### **1Kor 7,1**
 Lecz o tem coście mi pisali: Dobrze jest człowiekowi nie tykać się niewiasty.
###### **1Kor 7,2**
 Ale dla porubstwa, niech każdy ma swoję żonę, a każda niech ma swego męża.
###### **1Kor 7,3**
 Mąż niechaj żonie powinność oddaje: także też i żona mężowi.
###### **1Kor 7,4**
 Żona nie ma w mocy ciała swego, ale mąż. Także i mąż niema w mocy swej, ciała swego, ale żona.
###### **1Kor 7,5**
 Nie odmawiajcie jeden drugiemu: chybaby z zezwolenia do czasu, abyście się modlitwą bawili: a zasię wracajcie się do tegoż, aby was szatan nie kusił, dla waszej niestrzymawałości.
###### **1Kor 7,6**
 A to mówię według folgowania, nie według rozkazania.
###### **1Kor 7,7**
 Abowiem chcę, abyście wy wszyscy byli jakom ja sam, ale każdy ma własny dar od Boga: jeden tak a drugi tak.
###### **1Kor 7,8**
 A mówię nie żonatym i wdowom: Dobrze im jest, jeśliżeby tak trwali jako i ja.
###### **1Kor 7,9**
 Ale jeśli się nie wstrzymawają: niech w małżeństwo wstąpią. Bo lepiej jest w małżeństwo wstąpić, niżeli być palonym.
###### **1Kor 7,10**
 A tym, którzy są w małżeństwie, rozkazuję nie ja, ale Pan: iżby żona od męża nie odchodziła.
###### **1Kor 7,11**
 A jeśliby odeszła, żeby trwała bez męża, abo się z mężem pojędnała. A mąż żony niech nie opuszcza.
###### **1Kor 7,12**
 Bo inszym, ja mówię; nie Pan. Jeśli który brat ma żonę niewierną, a ta z nim zezwala mieszkać: niechaj jej nie opuszcza.
###### **1Kor 7,13**
 I żona, jeśli która wierna, ma męża niewiernego, a on zezwala mieszkać z nią: niechaj nie opuszcza męża.
###### **1Kor 7,14**
 Abowiem poświęcon jest mąż niewierny przez żonę wierną: i żona niewierna poświęcona jest przez męża wiernego. Bo inaczej dziatki wasze byłyby nieczystemi: a teraz świętemi są.
###### **1Kor 7,15**
 A jeśli niewierny odchodzi, niechże odejdzie. Abowiem nie jest poddany niewolstwu brat abo siostra w takowych rzeczach, a do pokoju wezwał nas Bóg.
###### **1Kor 7,16**
 Abowiem zkąd wiesz żono, jeśli męża zbawisz? abo zkąd wiesz mężu, jeśli żonę zbawisz?
###### **1Kor 7,17**
 Ale jako każdemu udzielił Pan, jako każdego wezwał Bóg, tak niech postępuje, i jako we wszystkich kościołach uczę.
###### **1Kor 7,18**
 Obrzezanym kto wezwany jest? niechajże nie przywodzi odrzezku. W odrzezku kto wezwany jest? niechaj się nie obrzezuje.
###### **1Kor 7,19**
 Obrzezanie nic nie jest, i odrzezek nic nie jest: ale zachowanie Bożego przykazania.
###### **1Kor 7,20**
 Każdy, w którem wezwaniu jest wezwan, w term niechaj trwa.
###### **1Kor 7,21**
 Jesteś wezwan niewolnikiem? nie dbajże: ale jeśli też możesz być wolnym, raczej używaj.
###### **1Kor 7,22**
 Abowiem kto niewolnikiem wezwany jest w Panie: jest wyzwolonym Pańskim: także który jest wezwan wolnym, jest niewolnikiem Chrystusowym.
###### **1Kor 7,23**
 Zapłatąście kupieni, nie stawajcie się niewolniki ludzkimi.
###### **1Kor 7,24**
 Każdy, w czem jest wezwan, bracia, w tem niech trwa przed Bogiem.
###### **1Kor 7,25**
 A o pannach nie mam rozkazania Pańskiego: ale radę daję, jako ten, którym od Pana miłosierdzia dostąpił, abych był wiernym.
###### **1Kor 7,26**
 Mniemam tedy to być rzeczą dobrą, dla teraźniejszej potrzeby iż dobra jest rzecz człowiekowi tak być.
###### **1Kor 7,27**
 Przywiązaneś do żony? nie szukajże rozwiązania. Rozwiązanyś od żony? nie szukajże żony.
###### **1Kor 7,28**
 A jeślibyś wziął żonę, nie zgrzeszyłeś. Jeśliby też panna szła za mąż, nie zgrzeszyła. Wszakże trapienie ciała mieć będą takowi. A ja wam folguję.
###### **1Kor 7,29**
 To tedy powiadam bracia, czas krótki jest: to zostaje, aby i którzy żony mają, byli jakoby nie mieli.
###### **1Kor 7,30**
 A którzy płaczą, jakoby nie płakali.: a którzy się weselą, jakoby się nie weselili: a którzy kupują, jakoby nie dzierżeli:
###### **1Kor 7,31**
 A którzy używają świata tego, jakoby nie używali. Bo przemija kształt świata tego.
###### **1Kor 7,32**
 A chcę, abyście byli bez pieczołowania. Kto bez żony jest, stara się o to co Pańskiego jest, jakoby się podobał Bogu.
###### **1Kor 7,33**
 A który z żoną jest, stara się o to, co światu należy, jakoby się podobał żonie: i rozdzielon jest.
###### **1Kor 7,34**
 I białogłowa nie mężata i panna, myśli o tem co Pańskiego jest, aby była święta ciałem i duchem. A która szła za mąż, myśli co światu należy: jakoby się podobała mężowi.
###### **1Kor 7,35**
 A toć mówię ku pożytkowi waszemu nie abym na was sidło wrzucił, ale ku temu co jest poczciwego, i coby was sposobiło do modlenia się Panu bez przeszkody.
###### **1Kor 7,36**
 A jeśli sobie kto za sromotę ma z strony panny swojej, iż lata przeszła, a tak musi być: co chce niech czyni. Nie grzeszy, jeśli pójdzie za mąż.
###### **1Kor 7,37**
 Bo kto postanowił mocnie w sercu swem, potrzeby nie mając, a mając w mocy swą własną wolą, i to postanowił w sercu swem, aby zachował pannę swą, dobrze czyni.
###### **1Kor 7,38**
 A tak i który daje w małżeństwo pannę swoję, dobrze czyni: i który nie daje, lepiej czyni.
###### **1Kor 7,39**
 Żona przywiązana jest do zakonu, póki żywie mąż jej: a jeśliby zasnął mąż jej, wolna jest: niech idzie za kogo chce: tylko w Panie.
###### **1Kor 7,40**
 Ale błogosławieńsza będzie, jeśliby tak została, wedle mojej rady. A mniemam, że i ja mam Ducha Bożego.
# 1Kor 7 STERN
###### **1Kor 7,1**
 A teraz co do pytań, o jakich pisaliście: "Czy dobrze jest dla mężczyzny trzymać się z dala od kobiet?".
###### **1Kor 7,2**
 Otóż ze względu na niebezpieczeństwa rozwiązłości niech każdy mężczyzna ma swoją żonę i każda kobieta swojego męża.
###### **1Kor 7,3**
 Mąż powinien oddawać żonie to, do czego jest uprawniona w małżeństwie, i żona powinna czynić to samo dla męża.
###### **1Kor 7,4**
 Żona nie ma władzy nad swoim ciałem, tylko jej mąż; podobnie mąż nie ma władzy nad własnym ciałem, tylko jego żona.
###### **1Kor 7,5**
 Nie odmawiajcie sobie, chyba że na określony czas, za obopólną zgodą, i to tylko po to, aby mieć więcej czasu na modlitwę; ale potem zejdźcie się znowu. W przeciwnym razie przez wasz brak wstrzemięźliwości możecie ulec pokusie Przeciwnika.
###### **1Kor 7,6**
 Daję wam to jako radę, a nie nakaz.
###### **1Kor 7,7**
 Bo wolałbym, żeby każdy był tak jak ja; ale każdy ma swój dar od Boga, jeden taki, drugi taki.
###### **1Kor 7,8**
 Co do osób samotnych i wdów, to powiem, że dobrze jest, jeśli pozostaną wolne tak jak ja;
###### **1Kor 7,9**
 ale jeśli nie potrafią nad sobą zapanować, to powinni zawrzeć małżeństwo; bo lepiej zawrzeć małżeństwo, niż pałać pożądaniem.
###### **1Kor 7,10**
 Dla tych, którzy są w małżeństwie, mam nakaz, a nie pochodzi on ode mnie, lecz od Pana: niech kobieta nie odchodzi od męża.
###### **1Kor 7,11**
 Ale jeśli odejdzie, ma pozostać wolna albo pojednać się z mężem. Również mąż niech nie opuszcza żony.
###### **1Kor 7,12**
 Pozostałym powiadam - ja, nie Pan: jeśli jakiś brat ma żonę, która nie jest wierząca, i chce ona dalej z nim żyć, to nie powinien jej opuszczać.
###### **1Kor 7,13**
 Również jeśli jakaś kobieta ma niewierzącego męża, który chce dalej z nią żyć, to niech go nie opuszcza.
###### **1Kor 7,14**
 Bo niewierzący mąż został przez żonę zabezpieczony dla Pana, a niewierząca żona została przez brata zabezpieczona dla Boga - w przeciwnym razie wasze dzieci byłyby "nieczyste", tak jednak są zabezpieczone dla Boga.
###### **1Kor 7,15**
 Jeśli jednak niewierzący małżonek odchodzi, to niech odejdzie. W takich okolicznościach brat czy siostra nie są zniewoleni - Bóg powołał nas do życia w pokoju.
###### **1Kor 7,16**
 Bo skąd wiesz, żono, że zbawisz męża? I skąd wiesz, mężu, że zbawisz żonę?
###### **1Kor 7,17**
 Niech tylko każdy żyje tak, jak Pan mu przypisał, i niech żyje w takim stanie, w jakim był, gdy go Bóg powołał. Tej zasady nauczam we wszystkich zgromadzeniach.
###### **1Kor 7,18**
 Ktoś był już obrzezany, gdy został powołany? Niech nie próbuje usuwać znaków obrzezania. Ktoś był nieobrzezany, gdy go powołano? Nie powinien się poddawać b'rit-mili.
###### **1Kor 7,19**
 Obrzezanie nic nie znaczy i nieobrzezanie nic nie znaczy; znaczenie ma natomiast przestrzeganie Bożych przykazań.
###### **1Kor 7,20**
 Każdy człowiek powinien pozostać w stanie, w jakim był, gdy został powołany.
###### **1Kor 7,21**
 Byłeś niewolnikiem, gdy zostałeś powołany? Nie zaprzątaj tym sobie głowy; choć jeśli możesz odzyskać wolność, skorzystaj z okazji.
###### **1Kor 7,22**
 Bo człowiek, który był niewolnikiem, gdy został powołany, jest wyzwoleńcem Pana; podobnie ten, kto był wolny, gdy został powołany, jest niewolnikiem Mesjasza.
###### **1Kor 7,23**
 Zostaliście kupieni za pewną cenę, nie stańcie się więc niewolnikami innych ludzi.
###### **1Kor 7,24**
 Bracia, niech każdy pozostanie z Bogiem w takim stanie, w jakim został powołany.
###### **1Kor 7,25**
 A teraz sprawa ludzi w stanie wolnym: nie mam nakazu od Pana, wyrażam jednak zdanie jako ten, który przez miłosierdzie Boże godny jest zaufania.
###### **1Kor 7,26**
 Sądzę, że w czasach ucisku takich jak obecne dobrze jest człowiekowi pozostać takim, jak jest.
###### **1Kor 7,27**
 Znaczy to, że jeśli mężczyzna ma żonę, nie powinien starać się od niej uwolnić; a jeśli jest wolny, nie powinien szukać żony.
###### **1Kor 7,28**
 Lecz jeśli się żenisz, nie grzeszysz, i jeśli dziewczyna wychodzi za mąż, nie grzeszy. Tyle tylko, że ci, którzy wstępują w związki małżeńskie, doświadczą zwykłych problemów życia małżeńskiego, a wolałbym ich wam oszczędzić.
###### **1Kor 7,29**
 Chcę powiedzieć, bracia, że czasu nie zostało wiele: odtąd mężczyzna posiadający żonę powinien żyć tak, jakby jej nie miał -
###### **1Kor 7,30**
 a ci, którzy są smutni, powinni żyć tak, jakby smutni nie byli, ci, którzy się cieszą, tak jakby się nie cieszyli,
###### **1Kor 7,31**
 ci zaś, którzy zajmują się sprawami tego świata, tak jakby się im nie oddawali - bo obecny porządek tego świata nie potrwa już długo.
###### **1Kor 7,32**
 A chciałbym, żebyście byli wolni od trosk. Mężczyznę wolnego zajmują sprawy Pana,
###### **1Kor 7,33**
 jak się podobać Panu; ale mężczyznę żonatego zajmują sprawy tego świata, jak się podobać żonie;
###### **1Kor 7,34**
 i czuje się rozdarty. Podobnie kobietę, która nie jest już zamężna albo jest dziewczyną, która nigdy nie miała męża, zajmują sprawy Pana, jak być świętą fizycznie i duchowo; natomiast kobietę zamężną zajmują sprawy tego świata, jak się podobać mężowi.
###### **1Kor 7,35**
 Mówię wam to dla waszego pożytku, a nie żeby wam narzucać ograniczenia. Zależy mi na tym, abyście żyli, jak należy, i służyli Panu z całym poświęceniem.
###### **1Kor 7,36**
 A jeśli ktoś uważa, że postępuje niegodnie, traktując w ten sposób swoją narzeczoną, i jeśli jest silne pożądanie, tak że powinno dojść do małżeństwa, to niech robi, co chce -nie grzeszy, niech się pobiorą.
###### **1Kor 7,37**
 Jeśli jednak mężczyzna podjął mocne postanowienie, nie pod przymusem, ale całkowicie panując nad swą wolą, żeby utrzymać swą narzeczoną w dziewictwie, to zrobi dobrze.
###### **1Kor 7,38**
 Toteż człowiek, który poślubi swą narzeczoną, postąpi dobrze, a człowiek, który nie poślubi, zrobi lepiej.
###### **1Kor 7,39**
 Żona jest przywiązana do męża tak długo, jak długo on żyje, jeśli jednak mąż umrze, jest wolna i może wyjść, za kogo chce, pod warunkiem, że wierzy on w Pana.
###### **1Kor 7,40**
 Ale moim zdaniem szczęśliwsza będzie, jeśli pozostanie niezamężna, a mówiąc to, przypuszczam, że mam Ducha Bożego.
# 1Kor 7 TRO
###### **1Kor 7,10**
 **τοις** *tois* (Tym) [[G3588]] WTT-DPM **δε** *de* zaś [[G1161]] [[CONJ]] **γεγαμηκοσιν** *gegamēkosin* którzy są zaślubieni [[G1060]] WTV-RAP-DPM **παραγγελλω** *parangellō* nakazuję [[G3853]] WTV-PAI-1S **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εγω** *egō* ja [[G1473]] WTP-1NS **αλλ** *all* ale [[G235]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **γυναικα** *gynaika* żona – kobieta [[G1135]] WTN-ASF **απο** *apo* od [[G575]] [[PREP]] **ανδρος** *andros* męża [[G435]] [[N-GSM]] **μη** *mē* nie [[G3361]] [[PRT-N]] **χωρισθηναι** *chōristhēnai* zostać oddzielona – zostać oddalona [[G5563]] WTV-APN-M
###### **1Kor 7,11**
 **εαν** *ean* jeśli [[G1437]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **χωρισθη** *chōristhē* została oddzielona – została oddalona [[G5563]] [[V-API-3S]]-M **μενετω** *menetō* niech pozostaje – niech trwa [[G3306]] WTV-PAM-3S **αγαμος** *agamos* niezamężna [[G22]] [[N-NSF]] **η** *ē* lub [[G2228]] WTPRT **τω** *tō* (z) [[G3588]] WTT-DSM **ανδρι** *andri* mężem [[G435]] WTN-DSM **καταλλαγητω** *katallagētō* niech zostanie pojednana – niech zostanie pogodzona [[G2644]] WTV-2APM-3S **και** *kai* i [[G2532]] [[CONJ]] **ανδρα** *andra* mąż [[G435]] [[N-ASM]] **γυναικα** *gynaika* żonę – kobietę [[G1135]] WTN-ASF **μη** *mē* nie [[G3361]] [[PRT-N]] **αφιεναι** *afienai* oddalać – opuszczać [[G863]] WTV-PAN
###### **1Kor 7,12**
 **τοις** *tois* [[G3588]] WTT-DPM **δε** *de* zaś [[G1161]] [[CONJ]] **λοιποις** *loipois* pozostałym [[G3062]] WTA-DPM **εγω** *egō* ja [[G1473]] WTP-1NS **λεγω** *legō* mówię [[G3004]] WTV-PAI-1S **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **ει** *ei* jeśli [[G1487]] WTCOND **τις** *tis* jakiś [[G5100]] WTX-NSM **αδελφος** *adelfos* brat [[G80]] [[N-NSM]] **γυναικα** *gynaika* żonę – kobietę [[G1135]] WTN-ASF **εχει** *echei* ma [[G2192]] WTV-PAI-3S **απιστον** *apiston* niewierzącą [[G571]] WTA-ASF **και** *kai* i [[G2532]] [[CONJ]] **αυτη** *autē* ta [[G846]] WTP-NSF **συνευδοκει** *syneudokei* zgadza się [[G4909]] WTV-PAI-3S **οικειν** *oikein* mieszkać [[G3611]] WTV-PAN **μετ** *met* z [[G3326]] [[PREP]] **αυτου** *autou* nim [[G846]] [[P-GSM]] **μη** *mē* nie [[G3361]] [[PRT-N]] **αφιετω** *afietō* niech oddala – niech opuszcza [[G863]] WTV-PAM-3S **αυτην** *autēn* jej [[G846]] [[P-ASF]]
###### **1Kor 7,13**
 **και** *kai* i [[G2532]] [[CONJ]] **γυνη** *gynē* żona – kobieta [[G1135]] [[N-NSF]] **ητις** *hētis* która [[G3748]] WTR-NSF **εχει** *echei* ma [[G2192]] WTV-PAI-3S **ανδρα** *andra* męża [[G435]] [[N-ASM]] **απιστον** *apiston* niewierzącego [[G571]] WTA-ASM **και** *kai* i [[G2532]] [[CONJ]] **αυτος** *autos* ten [[G846]] WTP-NSM **συνευδοκει** *syneudokei* zgadza się [[G4909]] WTV-PAI-3S **οικειν** *oikein* mieszkać [[G3611]] WTV-PAN **μετ** *met* z [[G3326]] [[PREP]] **αυτης** *autēs* nią [[G846]] [[P-GSF]] **μη** *mē* nie [[G3361]] [[PRT-N]] **αφιετω** *afietō* niech oddala – niech opuszcza [[G863]] WTV-PAM-3S **αυτον** *auton* go [[G846]] WTP-ASM
###### **1Kor 7,1**
 **περι** *peri* O [[G4012]] [[PREP]] **δε** *de* zaś [[G1161]] [[CONJ]] **ων** *hōn* których [[G3739]] WTR-GPN **εγραψατε** *egrapsate* napisaliście [[G1125]] WTV-AAI-2P **μοι** *moi* mi [[G3427]] WTP-1DS **καλον** *kalon* dobre – piękne [[G2570]] WTA-NSN **ανθρωπω** *anthrōpō* człowiekowi [[G444]] WTN-DSM **γυναικος** *gynaikos* kobiety [[G1135]] [[N-GSF]] **μη** *mē* nie [[G3361]] [[PRT-N]] **απτεσθαι** *haptesthai* dotykać [[G680]] WTV-PMN
###### **1Kor 7,2**
 **δια** *dia* Przez [[G1223]] [[PREP]] **δε** *de* zaś [[G1161]] [[CONJ]] **τας** *tas* [[G3588]] WTT-APF **πορνειας** *porneias* nierządy – wszeteczeństwa [[G4202]] WTN-APF **εκαστος** *hekastos* każdy [[G1538]] [[A-NSM]] **την** *tēn* [[G3588]] WTT-ASF **εαυτου** *heautou* swoją [[G1438]] WTF-3GSM **γυναικα** *gynaika* żonę – kobietę [[G1135]] WTN-ASF **εχετω** *echetō* niech ma [[G2192]] WTV-PAM-3S **και** *kai* i [[G2532]] [[CONJ]] **εκαστη** *hekastē* każda [[G1538]] WTA-NSF **τον** *ton* [[G3588]] [[T-ASM]] **ιδιον** *idion* swojego [[G2398]] WTA-ASM **ανδρα** *andra* męża [[G435]] [[N-ASM]] **εχετω** *echetō* niech ma [[G2192]] WTV-PAM-3S
###### **1Kor 7,3**
 **τη** *tē* [[G3588]] WTT-DSF **γυναικι** *gynaiki* Żonie – Kobiecie [[G1135]] [[N-DSF]] **ο** *ho* [[G3588]] [[T-NSM]] **ανηρ** *anēr* mąż [[G435]] [[N-NSM]] **την** *tēn* [[G3588]] WTT-ASF **οφειλομενην** *ofeilomenēn* który jest zobowiązany – który jest winnym [[G3784]] WTV-PPP-ASF **ευνοιαν** *eunoian* z dobrej woli – z życzliwością [[G2133]] WTN-ASF **αποδιδοτω** *apodidotō* niech oddaje [[G591]] WTV-PAM-3S **ομοιως** *homoiōs* podobnie [[G3668]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **γυνη** *gynē* żona – kobieta [[G1135]] [[N-NSF]] **τω** *tō* [[G3588]] WTT-DSM **ανδρι** *andri* mężowi [[G435]] WTN-DSM
###### **1Kor 7,4**
 **η** *hē* [[G3588]] [[T-NSF]] **γυνη** *gynē* Żona – Kobieta [[G1135]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSN **ιδιου** *idiou* własnym [[G2398]] [[A-GSN]] **σωματος** *sōmatos* ciałem [[G4983]] [[N-GSN]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εξουσιαζει** *eksousiazei* włada [[G1850]] WTV-PAI-3S **αλλ** *all* ale [[G235]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **ανηρ** *anēr* mąż [[G435]] [[N-NSM]] **ομοιως** *homoiōs* podobnie [[G3668]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **ανηρ** *anēr* mąż [[G435]] [[N-NSM]] **του** *tou* [[G3588]] WTT-GSN **ιδιου** *idiou* własnym [[G2398]] [[A-GSN]] **σωματος** *sōmatos* ciałem [[G4983]] [[N-GSN]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εξουσιαζει** *eksousiazei* włada [[G1850]] WTV-PAI-3S **αλλ** *all* ale [[G235]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **γυνη** *gynē* żona – kobieta [[G1135]] [[N-NSF]]
###### **1Kor 7,5**
 **μη** *mē* Nie [[G3361]] [[PRT-N]] **αποστερειτε** *apostereite* pozbawiajcie się – wstrzymujcie się [[G650]] WTV-PAM-2P **αλληλους** *allēlous* wzajemnie [[G240]] WTC-APM **ει** *ei* jeśli [[G1487]] WTCOND **μη** *mē* nie [[G3361]] [[PRT-N]] **τι** *ti* kto- [[G5100]] WTX-NSN **αν** *an* kolwiek [[G302]] WTPRT **εκ** *ek* z [[G1537]] [[PREP]] **συμφωνου** *symfōnou* obopólnej zgody – uzgodnienia [[G4859]] [[A-GSN]] **προς** *pros* do [[G4314]] [[PREP]] **καιρον** *kairon* pory [[G2540]] [[N-ASM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **σχολαζητε** *scholazēte* mielibyście czas [[G4980]] WTV-PAS-2P **τη** *tē* [[G3588]] WTT-DSF **νηστεια** *nēsteia* postu [[G3521]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **τη** *tē* [[G3588]] WTT-DSF **προσευχη** *proseuchē* modlitwy [[G4335]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **παλιν** *palin* znów [[G3825]] [[ADV]] **επι** *epi* przy [[G1909]] [[PREP]] **το** *to* (tym) [[G3588]] WTT-ASN **αυτο** *auto* samym [[G846]] WTP-ASN **συνερχησθε** *synerchēsthe* schodzilibyście się [[G4905]] WTV-PNS-2P **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **πειραζη** *peirazē* próbowałby – doświadczałby [[G3985]] WTV-PAS-3S **υμας** *hymas* was [[G5209]] WTP-2AP **ο** *ho* [[G3588]] [[T-NSM]] **σατανας** *satanas* szatan – [przeciwnik] [[G4567]] [[N-NSM]] **δια** *dia* przez [[G1223]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **ακρασιαν** *akrasian* niepowściągliwość – nieopanowanie [[G192]] WTN-ASF **υμων** *hymōn* waszą [[G5216]] WTP-2GP
###### **1Kor 7,6**
 **τουτο** *touto* To [[G5124]] WTD-ASN **δε** *de* zaś [[G1161]] [[CONJ]] **λεγω** *legō* mówię [[G3004]] WTV-PAI-1S **κατα** *kata* według [[G2596]] [[PREP]] **συγγνωμην** *syngnōmēn* przyzwolenia [[G4774]] WTN-ASF **ου** *ou* nie [[G3756]] [[PRT-N]] **κατ** *kat* według [[G2596]] [[PREP]] **επιταγην** *epitagēn* nakazu – rozkazu [[G2003]] WTN-ASF
###### **1Kor 7,7**
 **θελω** *thelō* Chcę [[G2309]] WTV-PAI-1S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **παντας** *pantas* wszyscy [[G3956]] WTA-APM **ανθρωπους** *anthrōpous* ludzie [[G444]] [[N-APM]] **ειναι** *einai* być [[G1511]] WTV-PXN **ως** *hōs* jak [[G5613]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **εμαυτον** *emauton* ja [[G1683]] WTF-1ASM **αλλ** *all* ale [[G235]] [[CONJ]] **εκαστος** *hekastos* każdy [[G1538]] [[A-NSM]] **ιδιον** *idion* własny [[G2398]] WTA-ASN **χαρισμα** *charisma* dar łaski [[G5486]] WTN-ASN **εχει** *echei* ma [[G2192]] WTV-PAI-3S **εκ** *ek* z [[G1537]] [[PREP]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ος** *hos* ten [[G3739]] WTR-NSM **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **ουτως** *houtōs* tak [[G3779]] [[ADV]] **ος** *hos* ten [[G3739]] WTR-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **ουτως** *houtōs* tak [[G3779]] [[ADV]]
###### **1Kor 7,8**
 **λεγω** *legō* Mówię [[G3004]] WTV-PAI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **τοις** *tois* [[G3588]] WTT-DPM **αγαμοις** *agamois* nieżonatym [[G22]] WTN-DPM **και** *kai* i [[G2532]] [[CONJ]] **ταις** *tais* [[G3588]] WTT-DPF **χηραις** *chērais* wdowom [[G5503]] WTN-DPF **καλον** *kalon* dobry – piękny [[G2570]] WTA-NSN **αυτοις** *autois* (dla) nich [[G846]] WTP-DPM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **εαν** *ean* jeśli [[G1437]] WTCOND **μεινωσιν** *meinōsin* pozostaliby – trwaliby [[G3306]] WTV-AAS-3P **ως** *hōs* jak [[G5613]] [[ADV]] **καγω** *kagō* i ja [[G2504]] WTP-1NS-C
###### **1Kor 7,9**
 **ει** *ei* jeśli [[G1487]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εγκρατευονται** *egkrateuontai* powściągają się – wytrzymają [[G1467]] WTV-PNI-3P **γαμησατωσαν** *gamēsatōsan* niech się zaślubią [[G1060]] WTV-AAM-3P **κρεισσον** *kreisson* lepiej [[G2908]] WTA-NSN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **γαμησαι** *gamēsai* zaślubić się [[G1060]] [[V-AAN]] **η** *ē* niż [[G2228]] WTPRT **πυρουσθαι** *pyrousthai* być rozpalonym – być rozżarzonym [[G4448]] WTV-PPN
###### **1Kor 7,14**
 **ηγιασται** *hēgiastai* Jest uświęcony – Jest poświęcony [[G37]] WTV-RPI-3S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **ανηρ** *anēr* mąż [[G435]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **απιστος** *apistos* niewierzący [[G571]] [[A-NSM]] **εν** *en* przez [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **γυναικι** *gynaiki* żonę – kobietę [[G1135]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **ηγιασται** *hēgiastai* jest uświęcona – jest poświęcona [[G37]] WTV-RPI-3S **η** *hē* [[G3588]] [[T-NSF]] **γυνη** *gynē* żona [[G1135]] [[N-NSF]] **η** *hē* [[G3588]] [[T-NSF]] **απιστος** *apistos* niewierząca [[G571]] WTA-NSF **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **ανδρι** *andri* mężu [[G435]] WTN-DSM **επει** *epei* skoro – jako, że [[G1893]] [[CONJ]] **αρα** *ara* zatem [[G686]] WTPRT **τα** *ta* [[G3588]] WTT-NPN **τεκνα** *tekna* dzieci [[G5043]] WTN-NPN **υμων** *hymōn* wasze [[G5216]] WTP-2GP **ακαθαρτα** *akatharta* nieczyste [[G169]] WTA-NPN **εστιν** *estin* jest (są) [[G2076]] WTV-PXI-3S **νυν** *nyn* teraz [[G3568]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **αγια** *hagia* święte [[G40]] WTA-NPN **εστιν** *estin* jest (są) [[G2076]] WTV-PXI-3S
###### **1Kor 7,15**
 **ει** *ei* jeśli [[G1487]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **απιστος** *apistos* niewierzący [[G571]] [[A-NSM]] **χωριζεται** *chōrizetai* oddziela się – odchodzi [[G5563]] WTV-PMI-3S **χωριζεσθω** *chōrizesthō* niech jest oddzielony – niech jest oddalony [[G5563]] WTV-PPM-3S **ου** *ou* nie [[G3756]] [[PRT-N]] **δεδουλωται** *dedoulōtai* jest poddany niewoli [[G1402]] WTV-RPI-3S **ο** *ho* [[G3588]] [[T-NSM]] **αδελφος** *adelfos* brat [[G80]] [[N-NSM]] **η** *ē* lub [[G2228]] WTPRT **η** *hē* [[G3588]] [[T-NSF]] **αδελφη** *adelfē* siostra [[G79]] [[N-NSF]] **εν** *en* w [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPN **τοιουτοις** *toioutois* takich (przypadkach) [[G5108]] WTD-DPN **εν** *en* w [[G1722]] [[PREP]] **δε** *de* zaś [[G1161]] [[CONJ]] **ειρηνη** *eirēnē* pokoju [[G1515]] [[N-DSF]] **κεκληκεν** *keklēken* wezwał – powołał [[G2564]] WTV-RAI-3S **ημας** *hēmas* nas [[G2248]] WTP-1AP **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]]
###### **1Kor 7,16**
 **τι** *ti* Co [[G5101]] WTI-ASN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **οιδας** *oidas* wiesz [[G1492]] WTV-RAI-2S **γυναι** *gynai* żono – kobieto [[G1135]] WTN-VSF **ει** *ei* czy [[G1487]] WTCOND **τον** *ton* [[G3588]] [[T-ASM]] **ανδρα** *andra* męża [[G435]] [[N-ASM]] **σωσεις** *sōseis* zbawisz – uratujesz [[G4982]] WTV-FAI-2S **η** *ē* lub [[G2228]] WTPRT **τι** *ti* co [[G5101]] WTI-ASN **οιδας** *oidas* wiesz [[G1492]] WTV-RAI-2S **ανερ** *aner* mężu [[G435]] WTN-VSM **ει** *ei* czy [[G1487]] WTCOND **την** *tēn* [[G3588]] WTT-ASF **γυναικα** *gynaika* żonę – kobietę [[G1135]] WTN-ASF **σωσεις** *sōseis* zbawisz – uratujesz [[G4982]] WTV-FAI-2S
###### **1Kor 7,17**
 **ει** *ei* Jeśli [[G1487]] WTCOND **μη** *mē* nie [[G3361]] [[PRT-N]] **εκαστω** *hekastō* każdemu [[G1538]] WTA-DSM **ως** *hōs* jak [[G5613]] [[ADV]] **εμερισεν** *emerisen* przydzielił [[G3307]] [[V-AAI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **εκαστον** *hekaston* każdego [[G1538]] WTA-ASM **ως** *hōs* jak [[G5613]] [[ADV]] **κεκληκεν** *keklēken* wezwał – powołał [[G2564]] WTV-RAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **ουτως** *houtōs* tak [[G3779]] [[ADV]] **περιπατειτω** *peripateitō* niech postępuje – niech chodzi [[G4043]] WTV-PAM-3S **και** *kai* i [[G2532]] [[CONJ]] **ουτως** *houtōs* tak [[G3779]] [[ADV]] **εν** *en* w [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **εκκλησιαις** *ekklēsiais* zgromadzeniach – (społecznościach) wywołanych [[G1577]] WTN-DPF **πασαις** *pasais* wszystkich [[G3956]] WTA-DPF **διατασσομαι** *diatassomai* zarządzam – rozporządzam [[G1299]] WTV-PMI-1S
###### **1Kor 7,18**
 **περιτετμημενος** *peritetmēmenos* Który jest obrzezany [[G4059]] WTV-RPP-NSM **τις** *tis* ktoś [[G5100]] WTX-NSM **εκληθη** *eklēthē* został wezwany [[G2564]] [[V-API-3S]] **μη** *mē* nie [[G3361]] [[PRT-N]] **επισπασθω** *epispasthō* niech staje się nieobrzezany – niech naciąga sobie [[G1986]] WTV-PNM-3S **εν** *en* w [[G1722]] [[PREP]] **ακροβυστια** *akrobystia* nieobrzezaniu [[G203]] [[N-DSF]] **τις** *tis* ktoś [[G5100]] WTX-NSM **εκληθη** *eklēthē* został wezwany [[G2564]] [[V-API-3S]] **μη** *mē* nie [[G3361]] [[PRT-N]] **περιτεμνεσθω** *peritemnesthō* niech jest obrzezywany [[G4059]] WTV-PPM-3S
###### **1Kor 7,19**
 **η** *hē* [[G3588]] [[T-NSF]] **περιτομη** *peritomē* Obrzezanie [[G4061]] [[N-NSF]] **ουδεν** *ouden* niczym [[G3762]] WTA-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **ακροβυστια** *akrobystia* nieobrzezanie [[G203]] [[N-NSF]] **ουδεν** *ouden* niczym [[G3762]] WTA-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **αλλα** *alla* ale [[G235]] [[CONJ]] **τηρησις** *tērēsis* przestrzeganie – strzeżenie [[G5084]] [[N-NSF]] **εντολων** *entolōn* przykazań [[G1785]] WTN-GPF **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **1Kor 7,20**
 **εκαστος** *hekastos* Każdy [[G1538]] [[A-NSM]] **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **κλησει** *klēsei* powołaniu [[G2821]] [[N-DSF]] **η** *hē* którym [[G3739]] WTR-DSF **εκληθη** *eklēthē* został wezwany [[G2564]] [[V-API-3S]] **εν** *en* w [[G1722]] [[PREP]] **ταυτη** *tautē* tym [[G3778]] WTD-DSF **μενετω** *menetō* niech pozostaje – niech trwa [[G3306]] WTV-PAM-3S
###### **1Kor 7,21**
 **δουλος** *doulos* Niewolnik – Sługa [[G1401]] [[N-NSM]] **εκληθης** *eklēthēs* zostałeś wezwany [[G2564]] WTV-API-2S **μη** *mē* nie [[G3361]] [[PRT-N]] **σοι** *soi* ciebie [[G4671]] WTP-2DS **μελετω** *meletō* niech martwi [[G3199]] WTV-PAM-3S **αλλ** *all* ale [[G235]] [[CONJ]] **ει** *ei* jeśli [[G1487]] WTCOND **και** *kai* i [[G2532]] [[CONJ]] **δυνασαι** *dynasai* możesz [[G1410]] WTV-PNI-2S **ελευθερος** *eleutheros* wolny [[G1658]] [[A-NSM]] **γενεσθαι** *genesthai* stać się [[G1096]] WTV-2ADN **μαλλον** *mallon* raczej [[G3123]] [[ADV]] **χρησαι** *chrēsai* korzystaj [[G5530]] WTV-ADM-2S
###### **1Kor 7,22**
 **ο** *ho* [[G3588]] [[T-NSM]] **γαρ** *gar* Bowiem [[G1063]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **κληθεις** *klētheis* który został wezwany – który został nazwany [[G2564]] WTV-APP-NSM **δουλος** *doulos* niewolnik – sługa [[G1401]] [[N-NSM]] **απελευθερος** *apeleutheros* wyzwoleniec [[G558]] [[N-NSM]] **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ομοιως** *homoiōs* podobnie [[G3668]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **ελευθερος** *eleutheros* wolny [[G1658]] [[A-NSM]] **κληθεις** *klētheis* który został nazwany [[G2564]] WTV-APP-NSM **δουλος** *doulos* niewolnik – sługa [[G1401]] [[N-NSM]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **1Kor 7,23**
 **τιμης** *timēs* Drogo – (Za cenę) szacunku [[G5092]] [[N-GSF]] **ηγορασθητε** *ēgorasthēte* zostaliście wykupieni [[G59]] WTV-API-2P **μη** *mē* nie [[G3361]] [[PRT-N]] **γινεσθε** *ginesthe* stawajcie się [[G1096]] WTV-PNM-2P **δουλοι** *douloi* niewolnicy – słudzy [[G1401]] WTN-NPM **ανθρωπων** *anthrōpōn* ludzi [[G444]] WTN-GPM
###### **1Kor 7,24**
 **εκαστος** *hekastos* Każdy [[G1538]] [[A-NSM]] **εν** *en* w [[G1722]] [[PREP]] **ω** *hō* czym [[G3739]] WTR-DSN **εκληθη** *eklēthē* został wezwany [[G2564]] [[V-API-3S]] **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **εν** *en* w [[G1722]] [[PREP]] **τουτω** *toutō* tym [[G5129]] WTD-DSN **μενετω** *menetō* niech pozostaje – niech trwa [[G3306]] WTV-PAM-3S **παρα** *para* u – przy [[G3844]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Boga [[G2316]] WTN-DSM
###### **1Kor 7,25**
 **περι** *peri* O [[G4012]] [[PREP]] **δε** *de* zaś [[G1161]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPF **παρθενων** *parthenōn* dziewicach [[G3933]] WTN-GPF **επιταγην** *epitagēn* nakazu – rozkazu [[G2003]] WTN-ASF **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εχω** *echō* mam [[G2192]] WTV-PAI-1S **γνωμην** *gnōmēn* mniemanie – opinię [[G1106]] WTN-ASF **δε** *de* zaś [[G1161]] [[CONJ]] **διδωμι** *didōmi* daję [[G1325]] WTV-PAI-1S **ως** *hōs* jak [[G5613]] [[ADV]] **ηλεημενος** *ēleēmenos* dostępujący litości – dostępujący zmiłowania [[G1653]] WTV-RPP-NSM **υπο** *hypo* od [[G5259]] [[PREP]] **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **πιστος** *pistos* godny wiary – wierny [[G4103]] [[A-NSM]] **ειναι** *einai* być [[G1511]] WTV-PXN
###### **1Kor 7,26**
 **νομιζω** *nomizō* Wnioskuję – Sądzę [[G3543]] WTV-PAI-1S **ουν** *oun* więc [[G3767]] [[CONJ]] **τουτο** *touto* to [[G5124]] WTD-ASN **καλον** *kalon* dobre – piękne [[G2570]] WTA-ASN **υπαρχειν** *hyparchein* być [[G5225]] WTV-PAN **δια** *dia* przez [[G1223]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **ενεστωσαν** *enestōsan* nastającą [[G1764]] WTV-RAP-ASF **αναγκην** *anagkēn* konieczność – przymus [[G318]] WTN-ASF **οτι** *hoti* że [[G3754]] [[CONJ]] **καλον** *kalon* dobre – piękne [[G2570]] WTA-NSN **ανθρωπω** *anthrōpō* człowiekowi [[G444]] WTN-DSM **το** *to* [[G3588]] WTT-NSN **ουτως** *houtōs* tak [[G3779]] [[ADV]] **ειναι** *einai* być [[G1511]] WTV-PXN
###### **1Kor 7,27**
 **δεδεσαι** *dedesai* Jesteś związany [[G1210]] WTV-RPI-2S **γυναικι** *gynaiki* żoną – kobietą [[G1135]] [[N-DSF]] **μη** *mē* nie [[G3361]] [[PRT-N]] **ζητει** *zētei* szukaj [[G2212]] WTV-PAM-2S **λυσιν** *lysin* uwolnienia – rozłączenia [[G3080]] WTN-ASF **λελυσαι** *lelysai* jesteś rozwiązany – jesteś uwolniony [[G3089]] WTV-RPI-2S **απο** *apo* od [[G575]] [[PREP]] **γυναικος** *gynaikos* żony – kobiety [[G1135]] [[N-GSF]] **μη** *mē* nie [[G3361]] [[PRT-N]] **ζητει** *zētei* szukaj [[G2212]] WTV-PAM-2S **γυναικα** *gynaika* żony – kobiety [[G1135]] WTN-ASF
###### **1Kor 7,28**
 **εαν** *ean* jeśli [[G1437]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **γημης** *gēmēs* zaślubiłbyś się [[G1060]] WTV-AAS-2S **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **ημαρτες** *hēmartes* zgrzeszyłeś [[G264]] WTV-2AAI-2S **και** *kai* i [[G2532]] [[CONJ]] **εαν** *ean* jeśli [[G1437]] WTCOND **γημη** *gēmē* zaślubiłaby się [[G1060]] WTV-AAS-3S **η** *hē* [[G3588]] [[T-NSF]] **παρθενος** *parthenos* dziewica [[G3933]] [[N-NSF]] **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **ημαρτεν** *hēmarten* zgrzeszyła [[G264]] WTV-2AAI-3S **θλιψιν** *thlipsin* ucisk – utrapienie [[G2347]] WTN-ASF **δε** *de* zaś [[G1161]] [[CONJ]] **τη** *tē* [[G3588]] WTT-DSF **σαρκι** *sarki* ciała [[G4561]] [[N-DSF]] **εξουσιν** *eksousin* będą mieć [[G2192]] WTV-FAI-3P **οι** *hoi* [[G3588]] WTT-NPM **τοιουτοι** *toioutoi* tacy [[G5108]] WTD-NPM **εγω** *egō* ja [[G1473]] WTP-1NS **δε** *de* zaś [[G1161]] [[CONJ]] **υμων** *hymōn* was [[G5216]] WTP-2GP **φειδομαι** *feidomai* oszczędzam [[G5339]] WTV-PNI-1S
###### **1Kor 7,29**
 **τουτο** *touto* To [[G5124]] WTD-ASN **δε** *de* zaś [[G1161]] [[CONJ]] **φημι** *fēmi* mówię [[G5346]] WTV-PXI-1S **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **οτι** *hoti* że [[G3754]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **καιρος** *kairos* pora [[G2540]] [[N-NSM]] **συνεσταλμενος** *synestalmenos* która jest skrócona [[G4958]] WTV-RPP-NSM **το** *to* [[G3588]] WTT-NSN **λοιπον** *loipon* w końcu [[G3063]] WTA-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ινα** *hina* aby [[G2443]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **εχοντες** *echontes* mający [[G2192]] WTV-PAP-NPM **γυναικας** *gynaikas* żony – kobiety [[G1135]] WTN-APF **ως** *hōs* jak [[G5613]] [[ADV]] **μη** *mē* nie [[G3361]] [[PRT-N]] **εχοντες** *echontes* mający [[G2192]] WTV-PAP-NPM **ωσιν** *ōsin* byliby [[G5600]] WTV-PXS-3P
###### **1Kor 7,30**
 **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **κλαιοντες** *klaiontes* płaczący [[G2799]] WTV-PAP-NPM **ως** *hōs* jak [[G5613]] [[ADV]] **μη** *mē* nie [[G3361]] [[PRT-N]] **κλαιοντες** *klaiontes* płaczący [[G2799]] WTV-PAP-NPM **και** *kai* a [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **χαιροντες** *chairontes* radujący się – cieszący się [[G5463]] WTV-PAP-NPM **ως** *hōs* jak [[G5613]] [[ADV]] **μη** *mē* nie [[G3361]] [[PRT-N]] **χαιροντες** *chairontes* radujący się – cieszący się [[G5463]] WTV-PAP-NPM **και** *kai* a [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **αγοραζοντες** *agorazontes* kupujący [[G59]] WTV-PAP-NPM **ως** *hōs* jak [[G5613]] [[ADV]] **μη** *mē* nie [[G3361]] [[PRT-N]] **κατεχοντες** *katechontes* nabywający [[G2722]] WTV-PAP-NPM
###### **1Kor 7,31**
 **και** *kai* a [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **χρωμενοι** *chrōmenoi* korzystający – używający [[G5530]] WTV-PNP-NPM **τω** *tō* [[G3588]] WTT-DSM **κοσμω** *kosmō* świata [[G2889]] WTN-DSM **τουτω** *toutō* tego [[G5129]] WTD-DSM **ως** *hōs* jak [[G5613]] [[ADV]] **μη** *mē* nie [[G3361]] [[PRT-N]] **καταχρωμενοι** *katachrōmenoi* wykorzystujący – używający [[G2710]] WTV-PNP-NPM **παραγει** *paragei* przemija [[G3855]] WTV-PAI-3S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **σχημα** *schēma* postać – kształt [[G4976]] WTN-NSN **του** *tou* [[G3588]] WTT-GSM **κοσμου** *kosmou* świata [[G2889]] [[N-GSM]] **τουτου** *toutou* tego [[G5127]] WTD-GSM
###### **1Kor 7,32**
 **θελω** *thelō* Chcę [[G2309]] WTV-PAI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **υμας** *hymas* wam [[G5209]] WTP-2AP **αμεριμνους** *amerimnous* wolnymi od trosk – wolnymi od kłopotów [[G275]] WTA-APM **ειναι** *einai* być [[G1511]] WTV-PXN **ο** *ho* [[G3588]] [[T-NSM]] **αγαμος** *agamos* nieżonaty [[G22]] [[N-NSM]] **μεριμνα** *merimna* martwi się – troszczy się [[G3309]] WTV-PAI-3S **τα** *ta* (o) [[G3588]] WTT-APN **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **πως** *pōs* jak [[G4459]] [[ADV]]-I **αρεσει** *aresei* przypodoba się [[G700]] WTV-FAI-3S **τω** *tō* [[G3588]] WTT-DSM **κυριω** *kyriō* Panu [[G2962]] WTN-DSM
###### **1Kor 7,33**
 **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **γαμησας** *gamēsas* który zaślubił się [[G1060]] WTV-AAP-NSM **μεριμνα** *merimna* martwi się – troszczy się [[G3309]] WTV-PAI-3S **τα** *ta* (o) [[G3588]] WTT-APN **του** *tou* [[G3588]] WTT-GSM **κοσμου** *kosmou* świata [[G2889]] [[N-GSM]] **πως** *pōs* jak [[G4459]] [[ADV]]-I **αρεσει** *aresei* przypodoba się [[G700]] WTV-FAI-3S **τη** *tē* [[G3588]] WTT-DSF **γυναικι** *gynaiki* żonie – kobiecie [[G1135]] [[N-DSF]]
###### **1Kor 7,34**
 **μεμερισται** *memeristai* jest podzielona – jest rozczłonkowana [[G3307]] WTV-RPI-3S **η** *hē* [[G3588]] [[T-NSF]] **γυνη** *gynē* kobieta [[G1135]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **παρθενος** *parthenos* dziewica [[G3933]] [[N-NSF]] **η** *hē* [[G3588]] [[T-NSF]] **αγαμος** *agamos* niezamężna [[G22]] [[N-NSF]] **μεριμνα** *merimna* martwi się – troszczy się [[G3309]] WTV-PAI-3S **τα** *ta* (o) [[G3588]] WTT-APN **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **η** *ē* byłaby [[G5600]] WTV-PXS-3S **αγια** *hagia* święta [[G40]] WTA-NSF **και** *kai* i [[G2532]] [[CONJ]] **σωματι** *sōmati* ciałem [[G4983]] WTN-DSN **και** *kai* i [[G2532]] [[CONJ]] **πνευματι** *pneumati* duchem [[G4151]] WTN-DSN **η** *hē* [[G3588]] [[T-NSF]] **δε** *de* zaś [[G1161]] [[CONJ]] **γαμησασα** *gamēsasa* która zaślubiła się [[G1060]] WTV-AAP-NSF **μεριμνα** *merimna* martwi się – troszczy się [[G3309]] WTV-PAI-3S **τα** *ta* (o) [[G3588]] WTT-APN **του** *tou* [[G3588]] WTT-GSM **κοσμου** *kosmou* świata [[G2889]] [[N-GSM]] **πως** *pōs* jak [[G4459]] [[ADV]]-I **αρεσει** *aresei* przypodoba się [[G700]] WTV-FAI-3S **τω** *tō* [[G3588]] WTT-DSM **ανδρι** *andri* mężowi [[G435]] WTN-DSM
###### **1Kor 7,35**
 **τουτο** *touto* To [[G5124]] WTD-ASN **δε** *de* zaś [[G1161]] [[CONJ]] **προς** *pros* do [[G4314]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **υμων** *hymōn* waszych [[G5216]] WTP-2GP **αυτων** *autōn* własnych [[G846]] WTP-GPM **συμφερον** *symferon* będącej korzyścią – będącej pożytkiem [[G4851]] WTV-PAP-ASN **λεγω** *legō* mówię [[G3004]] WTV-PAI-1S **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **ινα** *hina* aby [[G2443]] [[CONJ]] **βροχον** *brochon* pętlę [[G1029]] [[N-ASM]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **επιβαλω** *epibalō* narzucałbym [[G1911]] WTV-2AAS-1S **αλλα** *alla* ale [[G235]] [[CONJ]] **προς** *pros* do [[G4314]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **ευσχημον** *euschēmon* dostojności – szanowności [[G2158]] WTA-ASN **και** *kai* i [[G2532]] [[CONJ]] **ευπροσεδρον** *euprosedron* wytrwałości [[G2145]] WTA-ASN **τω** *tō* [[G3588]] WTT-DSM **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **απερισπαστως** *aperispastōs* nierozerwalnie [[G563]] [[ADV]]
###### **1Kor 7,36**
 **ει** *ei* jeśli [[G1487]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **τις** *tis* ktoś [[G5100]] WTX-NSM **ασχημονειν** *aschēmonein* być niestosownym – być nieprzyzwoitym [[G807]] WTV-PAN **επι** *epi* do [[G1909]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **παρθενον** *parthenon* dziewicy [[G3933]] WTN-ASF **αυτου** *autou* jego [[G846]] [[P-GSM]] **νομιζει** *nomizei* wnioskuje – sądzi [[G3543]] WTV-PAI-3S **εαν** *ean* jeśli [[G1437]] WTCOND **η** *ē* byłby [[G5600]] WTV-PXS-3S **υπερακμος** *hyperakmos* przekroczyć lata młodości [[G5230]] [[A-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ουτως** *houtōs* tak [[G3779]] [[ADV]] **οφειλει** *ofeilei* powinien [[G3784]] WTV-PAI-3S **γινεσθαι** *ginesthai* stawać się [[G1096]] WTV-PNN **ο** *ho* co [[G3739]] WTR-ASN **θελει** *thelei* chce [[G2309]] WTV-PAI-3S **ποιειτω** *poieitō* niech czyni [[G4160]] WTV-PAM-3S **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **αμαρτανει** *hamartanei* grzeszy [[G264]] WTV-PAI-3S **γαμειτωσαν** *gameitōsan* niech zaślubiają się [[G1060]] WTV-PAM-3P
###### **1Kor 7,37**
 **ος** *hos* Który [[G3739]] WTR-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **εστηκεν** *hestēken* postanowił – stanął [[G2476]] WTV-IAI-3S **εδραιος** *hedraios* mocno – niezłomnie [[G1476]] [[A-NSM]] **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **καρδια** *kardia* sercu [[G2588]] [[N-DSF]] **μη** *mē* nie [[G3361]] [[PRT-N]] **εχων** *echōn* mając [[G2192]] [[V-PAP-NSM]] **αναγκην** *anagkēn* przymusu – konieczności [[G318]] WTN-ASF **εξουσιαν** *eksousian* władzę [[G1849]] WTN-ASF **δε** *de* zaś [[G1161]] [[CONJ]] **εχει** *echei* ma [[G2192]] WTV-PAI-3S **περι** *peri* nad [[G4012]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **ιδιου** *idiou* własną [[G2398]] [[A-GSN]] **θεληματος** *thelēmatos* wolą [[G2307]] [[N-GSN]] **και** *kai* i [[G2532]] [[CONJ]] **τουτο** *touto* to [[G5124]] WTD-ASN **κεκρικεν** *kekriken* osądził [[G2919]] WTV-RAI-3S **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **καρδια** *kardia* sercu [[G2588]] [[N-DSF]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **του** *tou* [[G3588]] WTT-GSM **τηρειν** *tērein* zachowywać – strzec [[G5083]] WTV-PAN **την** *tēn* [[G3588]] WTT-ASF **εαυτου** *heautou* swoją [[G1438]] WTF-3GSM **παρθενον** *parthenon* dziewicę [[G3933]] WTN-ASF **καλως** *kalōs* dobrze – pięknie [[G2573]] [[ADV]] **ποιει** *poiei* czyni [[G4160]] WTV-PAI-3S
###### **1Kor 7,38**
 **ωστε** *hōste* Tak, że [[G5620]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **εκγαμιζων** *ekgamizōn* zaślubiający [[G1547]] [[V-PAP-NSM]] **καλως** *kalōs* dobrze – pięknie [[G2573]] [[ADV]] **ποιει** *poiei* czyni [[G4160]] WTV-PAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **εκγαμιζων** *ekgamizōn* zaślubiający [[G1547]] [[V-PAP-NSM]] **κρεισσον** *kreisson* lepiej [[G2908]] WTA-ASN **ποιει** *poiei* czyni [[G4160]] WTV-PAI-3S
###### **1Kor 7,39**
 **γυνη** *gynē* Żona – Kobieta [[G1135]] [[N-NSF]] **δεδεται** *dedetai* jest związana [[G1210]] WTV-RPI-3S **νομω** *nomō* prawem [[G3551]] WTN-DSM **εφ** *ef* do [[G1909]] [[PREP]] **οσον** *hoson* jakiego [[G3745]] WTK-ASM **χρονον** *chronon* czasu [[G5550]] [[N-ASM]] **ζη** *zē* żyje [[G2198]] WTV-PAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **ανηρ** *anēr* mąż [[G435]] [[N-NSM]] **αυτης** *autēs* jej [[G846]] [[P-GSF]] **εαν** *ean* jeśli [[G1437]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **κοιμηθη** *koimēthē* zostałby uśpiony [[G2837]] WTV-APS-3S **ο** *ho* [[G3588]] [[T-NSM]] **ανηρ** *anēr* mąż [[G435]] [[N-NSM]] **αυτης** *autēs* jej [[G846]] [[P-GSF]] **ελευθερα** *eleuthera* wolna [[G1658]] WTA-NSF **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ω** *hō* któremu [[G3739]] WTR-DSM **θελει** *thelei* chce [[G2309]] WTV-PAI-3S **γαμηθηναι** *gamēthēnai* zostać zaślubioną [[G1060]] WTV-APN **μονον** *monon* jedynie – tylko [[G3440]] [[ADV]] **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM
###### **1Kor 7,40**
 **μακαριωτερα** *makariōtera* Szczęśliwsza – Bardziej błogosławiona [[G3107]] WTA-NSF-C **δε** *de* zaś [[G1161]] [[CONJ]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **εαν** *ean* jeśli [[G1437]] WTCOND **ουτως** *houtōs* tak [[G3779]] [[ADV]] **μεινη** *meinē* pozostałaby – wytrwałaby [[G3306]] WTV-AAS-3S **κατα** *kata* według [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **εμην** *emēn* mojego [[G1699]] WTS-1ASF **γνωμην** *gnōmēn* mniemania – opinii [[G1106]] WTN-ASF **δοκω** *dokō* uważam [[G1380]] WTV-PAI-1S-C **δε** *de* zaś [[G1161]] [[CONJ]] **καγω** *kagō* i ja [[G2504]] WTP-1NS-C **πνευμα** *pneuma* Ducha [[G4151]] WTN-ASN **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εχειν** *echein* mieć [[G2192]] WTV-PAN
