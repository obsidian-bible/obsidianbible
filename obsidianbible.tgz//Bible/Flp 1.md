# Flp 1 BT5
###### **Flp 1,1**
 Paweł i Tymoteusz, słudzy Chrystusa Jezusa, do wszystkich świętych w Chrystusie Jezusie, którzy są w Filippi, wraz z biskupami i diakonami.
###### **Flp 1,2**
 Łaska wam i pokój od Boga, Ojca naszego, i Pana, Jezusa Chrystusa!
###### **Flp 1,3**
 Dziękuję Bogu mojemu, ilekroć was wspominam –
###### **Flp 1,4**
 zawsze, w każdej modlitwie, zanosząc ją z radością za was wszystkich –
###### **Flp 1,5**
 z powodu waszego udziału w [szerzeniu] Ewangelii od pierwszego dnia aż do chwili obecnej.
###### **Flp 1,6**
 Mam właśnie ufność, że Ten, który zapoczątkował w was dobre dzieło, dokończy go do dnia Chrystusa Jezusa.
###### **Flp 1,7**
 Słusznie przecież mogę tak o was myśleć, bo noszę was wszystkich w sercu jako tych, którzy mają udział w mojej łasce: zarówno w moich kajdanach, jak i w obronie Ewangelii uzasadnionej dowodami.
###### **Flp 1,8**
 Albowiem Bóg jest mi świadkiem, jak gorąco tęsknię za wami wszystkimi [ożywiony] miłością Chrystusa Jezusa.
###### **Flp 1,9**
 A modlę się o to, by miłość wasza doskonaliła się coraz bardziej i bardziej w głębszym poznaniu i wszelkim wyczuciu
###### **Flp 1,10**
 dla oceny tego, co lepsze, abyście byli czyści i bez zarzutu na dzień Chrystusa,
###### **Flp 1,11**
 napełnieni plonem sprawiedliwości, który [przynosimy] przez Jezusa Chrystusa, na chwałę i cześć Boga.
###### **Flp 1,12**
 Bracia, chcę, abyście wiedzieli, że moje sprawy przyniosły raczej korzyść Ewangelii,
###### **Flp 1,13**
 tak iż kajdany moje stały się głośne w Chrystusie w całym pretorium i u wszystkich innych.
###### **Flp 1,14**
 I tak więcej braci, ośmielonych w Panu moimi kajdanami, bardziej się odważa głosić bez lęku słowo Boże.
###### **Flp 1,15**
 Niektórzy wprawdzie z zawiści i przekory, inni zaś z dobrej woli głoszą Chrystusa.
###### **Flp 1,16**
 Ci ostatni [głoszą] z miłości, świadomi tego, że jestem przeznaczony do obrony Ewangelii.
###### **Flp 1,17**
 Tamci zaś, powodowani niewłaściwym współzawodnictwem, rozgłaszają Chrystusa nieszczerze, sądząc, że przez to dodadzą ucisku moim kajdanom.
###### **Flp 1,18**
 Ale cóż to znaczy? Jedynie to, że czy to obłudnie, czy naprawdę, na wszelki sposób głosi się Chrystusa. A z tego ja się cieszę i będę się cieszył.
###### **Flp 1,19**
 Wiem bowiem, że mi to wyjdzie na zbawienie dzięki waszej modlitwie i pomocy, udzielanej przez Ducha Jezusa Chrystusa,
###### **Flp 1,20**
 zgodnie z gorącym oczekiwaniem i nadzieją moją, że w niczym nie doznam zawodu. Lecz jak zawsze, tak i teraz, z całą swobodą i jawnością Chrystus będzie uwielbiony w moim ciele: czy to przez życie, czy przez śmierć.
###### **Flp 1,21**
 Dla mnie bowiem żyć – to Chrystus, a umrzeć – to zysk.
###### **Flp 1,22**
 Jeśli zaś żyć w ciele – to dla mnie owocna praca, cóż mam wybrać? Nie umiem powiedzieć.
###### **Flp 1,23**
 Z dwóch stron doznaję nalegania: pragnę odejść, a być z Chrystusem, bo to o wiele lepsze;
###### **Flp 1,24**
 pozostawać zaś w ciele – to bardziej konieczne ze względu na was.
###### **Flp 1,25**
 A ufny w to, wiem, że pozostanę, i to pozostanę nadal dla was wszystkich, dla waszego postępu i radości w wierze,
###### **Flp 1,26**
 aby rosła wasza duma w Chrystusie Jezusie przez moją ponowną obecność u was.
###### **Flp 1,27**
 Tylko sprawujcie się w sposób godny Ewangelii Chrystusowej, abym ja – czy to gdy przybędę i ujrzę was, czy też będąc z daleka – mógł usłyszeć o was, że trwacie mocno w jednym duchu, jednym sercem walcząc wspólnie o wiarę w Ewangelię,
###### **Flp 1,28**
 i w niczym nie dajecie się zastraszyć przeciwnikom. To właśnie jest dla nich zapowiedzią zagłady, dla was zaś zbawienia, i to przez Boga.
###### **Flp 1,29**
 Wam bowiem z łaski dane jest dla Chrystusa: nie tylko w Niego wierzyć, ale i dla Niego cierpieć,
###### **Flp 1,30**
 skoro toczycie taką samą walkę, jaką u mnie widzieliście i jaką teraz prowadzę.
# Flp 1 PAU
###### **Flp 1,1**
 Paweł i Tymoteusz, słudzy Chrystusa Jezusa, do wszystkich świętych w Chrystusie Jezusie, którzy są w Filippi, wraz z biskupami i diakonami:
###### **Flp 1,2**
 łaska wam i pokój od Boga, naszego Ojca, i od Pana Jezusa Chrystusa.
###### **Flp 1,3**
 Dziękuję mojemu Bogu zawsze, gdy was wspominam.
###### **Flp 1,4**
 W każdej mojej modlitwie dziękuję Mu zawsze z radością
###### **Flp 1,5**
 za to, że pomagacie szerzyć Ewangelię od pierwszego dnia aż do obecnej chwili.
###### **Flp 1,6**
 Jestem bowiem przekonany, że Ten, który rozpoczął w was dobre dzieło, ukończy je do dnia Chrystusa Jezusa.
###### **Flp 1,7**
 Mam prawo tak myśleć o was wszystkich, gdyż noszę was w swoim sercu i wy wszyscy macie udział w tej samej łasce, której ja dostępuję zarówno wtedy, gdy jestem w kajdanach, jak też gdy bronię Ewangelii i ją umacniam.
###### **Flp 1,8**
 Bóg mi świadkiem, jak bardzo zależy mi na was wszystkich w Chrystusie Jezusie.
###### **Flp 1,9**
 Dlatego modlę się, aby wasza miłość coraz bardziej wzrastała w poznaniu i wszelkim zrozumieniu,
###### **Flp 1,10**
 abyście umieli rozeznać to, co słuszne, i abyście dzięki temu pozostali czyści i nienaganni do dnia Chrystusa,
###### **Flp 1,11**
 przynosząc owoc sprawiedliwości przez Jezusa Chrystusa, na cześć i chwałę Bożą.
###### **Flp 1,12**
 Chcę bracia, abyście wiedzieli, że przeciwności, które mnie spotkały, spowodowały jeszcze większe rozszerzenie się Ewangelii.
###### **Flp 1,13**
 Otóż jest już jawne w całym pretorium i u wszystkich innych, że dla Chrystusa noszę kajdany.
###### **Flp 1,14**
 Dzięki temu coraz więcej braci w Panu, ośmielonych moimi kajdanami, z niezwykłą odwagą i bez lęku głosi słowo.
###### **Flp 1,15**
 Niektórzy, co prawda, robią to z zazdrości i przekory, inni jednak głoszą Chrystusa szczerym sercem.
###### **Flp 1,16**
 Ci ostatni czynią to z miłości, wiedząc, że moim zadaniem jest obrona Ewangelii,
###### **Flp 1,17**
 tamci zaś głoszą Chrystusa dla własnej chwały i nieszczerze, chcąc powiększyć jeszcze ucisk moich kajdan.
###### **Flp 1,18**
 I co z tego wynika? To tylko, że na wszelki sposób, na pokaz, czy też naprawdę głosi się Chrystusa. To mnie raduje i będzie radowało.
###### **Flp 1,19**
 Wiem bowiem, że wszystko to przyczyni się do mojego zbawienia dzięki waszej modlitwie oraz pomocy Ducha Jezusa Chrystusa.
###### **Flp 1,20**
 Tego oczekuję i mam nadzieję, że w niczym nie doznam wstydu, ale że w sposób zupełnie jawny, jak zawsze tak i teraz, Chrystus będzie uwielbiony w moim ciele: czy to przez życie, czy przez śmierć.
###### **Flp 1,21**
 Dla mnie bowiem życie to Chrystus, a śmierć to zysk.
###### **Flp 1,22**
 Lecz jeśli życie w ciele oznacza dla mnie owocną pracę, nie wiem, co mam wybrać.
###### **Flp 1,23**
 Dręczy mnie podwójne pragnienie: chcę odejść, aby być z Chrystusem, co byłoby o wiele lepsze,
###### **Flp 1,24**
 lecz dla was jest bardziej konieczne, abym pozostał w ciele.
###### **Flp 1,25**
 Będąc o tym przekonany, wiem, że pozostanę z wami wszystkimi, abyście czynili postępy i radowali się w wierze,
###### **Flp 1,26**
 abyście przeze mnie chlubili się w Chrystusie Jezusie, gdy znowu do was przybędę.
###### **Flp 1,27**
 Tylko postępujcie w sposób godny Ewangelii Chrystusa, abym ja - gdy przybędę i ujrzę was czy też będąc daleko - usłyszał o was, że trwacie mocno w jednym duchu. Walczcie jednomyślnie o wiarę w Ewangelię
###### **Flp 1,28**
 i w niczym nie dajcie się zastraszyć przeciwnikom. Takie właśnie postępowanie jest dla nich zapowiedzią zguby, dla was zaś - zbawienia, a znak ten pochodzi od Boga.
###### **Flp 1,29**
 Dostąpiliście bowiem łaski ze względu na Chrystusa, aby nie tylko w Niego wierzyć, lecz także dla Niego cierpieć.
###### **Flp 1,30**
 Tak oto toczycie tę samą walkę, w której widzieliście mnie i którą ja sam także toczę.
# Flp 1 BP
###### **Flp 1,1**
 Paweł i Tymoteusz, słudzy Chrystusa Jezusa, zamieszkałych w Filippi, wraz z biskupami i diakonami.
###### **Flp 1,2**
 Łaska wam i pokój od Boga, Ojca naszego, i od Pana Jezusa Chrystusa.
###### **Flp 1,3**
 Ilekroć was wspominam, dziękuję Bogu mojemu
###### **Flp 1,4**
 za was wszystkich w każdej z radością odmawianej modlitwie,
###### **Flp 1,5**
 za wasz udział w szerzeniu ewangelii od pierwszego dnia aż do chwili obecnej.
###### **Flp 1,6**
 Stąd żywię nadzieję, że ten, który zapoczątkował w was dobre dzieło, doprowadzi je do końca na dzień Chrystusa Jezusa.
###### **Flp 1,7**
 Słusznie mogę tak o was wszystkich myśleć, ponieważ kocham was za to, że uczestniczycie w udzielonej mi łasce, jaką jest dźwiganie kajdan, obrona i umacnianie ewangelii.
###### **Flp 1,8**
 Bóg mi świadkiem, że miłość Chrystusa Jezusa wyzwala we mnie serdeczne uczucia dla was wszystkich.
###### **Flp 1,9**
 Przeto modlę się, aby miłość wasza z każdym dniem wzrastała
###### **Flp 1,10**
 dla głębszego poznania i oceny tego, co lepsze. A wtedy w dniu Chrystusa Jezusa czystość wasza zajaśnieje jak słońce, będziecie bez skazy,
###### **Flp 1,11**
 obfitujący w owoc sprawiedliwości [nabyty] dzięki Jezusowi Chrystusowi na chwałę i cześć Boga.
###### **Flp 1,12**
 Bracia, chciałbym, abyście wiedzieli, że to, co mnie spotkało, przyczyniło się raczej do rozszerzenia ewangelii.
###### **Flp 1,13**
 Wieść bowiem o moim uwięzieniu dla Chrystusa rozeszła się po całym pretorium i wśród wszystkich innych ludzi.
###### **Flp 1,14**
 Dlatego wielu z braci, ośmielonych moimi kajdanami dla Pana, ze wzmożoną odwagą głosi słowo Boże.
###### **Flp 1,15**
 Niektórzy wprawdzie powodowani zazdrością i chęcią rywalizacji,
###### **Flp 1,16**
 pozostali jednak z dobrej woli zwiastują Chrystusa. [Czynią to] i z miłości, bo wiedzą, że jestem powołany do obrony ewangelii.
###### **Flp 1,17**
 Tamci natomiast przepowiadają Chrystusa nieszczerze. Kierowani niezdrową ambicją sądzą, że w ten sposób jeszcze bardziej dokuczą mi w więzieniu.
###### **Flp 1,18**
 Ale cóż z tego? Byleby tylko, obłudnie czy szczerze, we wszelki sposób głoszono Chrystusa. Z tego się raduję. I będę się radował.
###### **Flp 1,19**
 Wiem bowiem, że to dzięki waszej modlitwie błagalnej i pomocy Ducha Jezusa Chrystusa przyczyni się do mojego zbawienia.
###### **Flp 1,20**
 Za tym tęsknię i mam nadzieję, że w niczym nie doznam zawodu, ale jak dotąd tak i teraz Chrystus będzie jawnie uwielbiony w moim ciele czy to przez życie, czy przez śmierć.
###### **Flp 1,21**
 Dla mnie bowiem życiem jest Chrystus, a śmierć zyskiem.
###### **Flp 1,22**
 Jeśli jednak życie umożliwiłoby mi owocną pracę, nie wiedziałbym, co wybrać.
###### **Flp 1,23**
 Nęci mnie jedno i drugie. Pragnę rozstać się z życiem i być z Chrystusem, co byłoby lepsze,
###### **Flp 1,24**
 chociaż pozostanie przy życiu byłoby ze względu na was bardziej pożyteczne.
###### **Flp 1,25**
 Stąd jestem przekonany, że będę żył nadal i pozostanę wśród wszystkich dla waszego dalszego rozwoju i radości z wiary.
###### **Flp 1,26**
 Tak, kiedy znów do was przybędę, będziecie we mnie mieli powód do chluby w Chrystusie Jezusie.
###### **Flp 1,27**
 Tylko postępujcie w sposób godny ewangelii Chrystusa, bym mógł, bądź to, gdy do was przybędę - zobaczyć, bądź to, gdy pozostanę z daleka - usłyszeć, że jesteście jednej myśli i wspólnymi siłami walczycie o wiarę w ewangelię,
###### **Flp 1,28**
 nie pozwalając się przeciwnikom w niczym zastraszyć. To jest właśnie dla nich zapowiedzią zatracenia, a dla was znakiem zbawienia [danym] przez Boga.
###### **Flp 1,29**
 Wam bowiem została udzielona łaska, że możecie nie tylko wierzyć w Chrystusa, ale i dla Niego cierpieć.
###### **Flp 1,30**
 Toczycie bowiem tę samą [co ja] walkę. Dawniej patrzyliście na nią, a teraz o niej słyszycie.
# Flp 1 BR
###### **Flp 1,1**
 Paweł i Tymoteusz, słudzy Chrystusa Jezusa, do całego ludu Bożego, który zjednoczony z Jezusem Chrystusem, żyje w Filippi wraz z biskupami i diakonami.
###### **Flp 1,2**
 Niech was obdarzy łaską i pokojem Bóg, Ojciec nasz, i Pan Jezus Chrystus.
###### **Flp 1,3**
 Ilekroć was wspominam, dziękuję Bogu mojemu
###### **Flp 1,4**
 za was w każdej modlitwie. Czynię to zawsze, z wielką radością mówiąc Bogu o was wszystkich,
###### **Flp 1,5**
 a zwłaszcza o tym, jak przyczynialiście się do szerzenia Ewangelii od pierwszego dnia aż do chwili obecnej.
###### **Flp 1,6**
 Jestem też przekonany, że Ten, który rozpoczął w was dobre dzieło, dokończy go do dnia Chrystusa Jezusa.
###### **Flp 1,7**
 Nie ma w tym nic dziwnego, że tak właśnie o was myślę. Wszystkich was przecież noszę w swoim sercu, bo wy wszyscy macie swój udział w łasce mojego apostołowania: zarówno teraz, gdy znajduję się w więzieniu, jak i wtedy, kiedy swobodnie za pomocą [odpowiednich] dowodów broniłem Ewangelii.
###### **Flp 1,8**
 Sam Bóg jest mi świadkiem, jak bardzo tęsknię za wami wszystkimi, ożywiony miłością Jezusa Chrystusa.
###### **Flp 1,9**
 Modlę się zaś o to, aby miłość wasza była coraz większa, żeby jej towarzyszyła prawdziwa mądrość i zrozumienie;
###### **Flp 1,10**
 byście mogli dostrzegać to, co lepsze; abyście byli czyści i bez zarzutu w dzień przyjścia Chrystusa;
###### **Flp 1,11**
 byście obfitowali w uczynki sprawiedliwości nabytej przez Jezusa Chrystusa ku chwale i czci Boga.
###### **Flp 1,12**
 Bracia, chciałbym, żebyście wiedzieli, że to, co teraz znoszę, wychodzi raczej na korzyść Ewangelii.
###### **Flp 1,13**
 W całym bowiem pałacu królewskim i wśród wszystkich innych stało się wiadome, że jestem więziony dla Chrystusa.
###### **Flp 1,14**
 I tak wiedząc, że jestem w więzieniu, większość braci tym silniej zaufała Panu i z większą odwagą poczęli głosić słowo Boże.
###### **Flp 1,15**
 To prawda, że niektórzy głoszą Chrystusa przez zwykłą zawiść [do mnie] i przekorę, inni - powodowani dobrą wolą -
###### **Flp 1,16**
 z miłości, ponieważ wiedzą, że sam Bóg zlecił mi zadanie występowania w obronie Ewangelii.
###### **Flp 1,17**
 Natomiast ci pierwsi, próbując współzawodniczyć z nami w sposób fałszywy, głoszą Chrystusa nieszczerze, sądząc że przyczynią się przez to do zwiększenia moich cierpień w więzieniu.
###### **Flp 1,18**
 Wszystko to jednak nie ma znaczenia. Mniejsza o to, czy obłudnie, czy szczerze głoszą Chrystusa. Ważne jest to, że głosi się Chrystusa, a to jest i będzie dla mnie zawsze źródłem radości.
###### **Flp 1,19**
 Jestem bowiem przekonany, że to wszystko posłuży ku mojemu zbawieniu, zwłaszcza dzięki waszej modlitwie i pomocy, jakiej mi udziela Jezus Chrystus przez Ducha (Świętego).
###### **Flp 1,20**
 Dlatego też, zgodnie z moim oczekiwaniem, nie spotka mnie, jak ufam, żaden zawód. Będę więc usiłował zawsze, podobnie jak teraz, z całą odwagą i jawnie moim postępowaniem uwielbiać Chrystusa: czy to ciesząc się pełnią życia, czy to idąc na śmierć.
###### **Flp 1,21**
 Dla mnie bowiem życie - to Chrystus, a śmierć - to po prostu zysk.
###### **Flp 1,22**
 Lecz jeśli pozostawanie przy życiu w tym ciele daje mi sposobność do owocnej pracy, to sam nie wiem, co mam wybrać.
###### **Flp 1,23**
 Odczuwam podwójne pragnienie: z jednej strony chciałbym odejść, bo być z Chrystusem to przecież wielkie szczęście,
###### **Flp 1,24**
 z drugiej strony jednak pragnąłbym pozostawać nadal przy życiu, gdyż byłoby to pożyteczne dla was.
###### **Flp 1,25**
 Będąc przekonany o tych korzyściach dla was, wiem już, że pozostanę z wami wszystkimi, by służyć wam pomocą w waszym zdobywaniu dalszej doskonałości i by radować się w wierze.
###### **Flp 1,26**
 Tak więc gdy znajdę się ponownie wśród was, będziecie [chyba] dumni - pośrednio przeze mnie - z waszego życia w Jezusie Chrystusie.
###### **Flp 1,27**
 Pamiętajcie tylko, żebyście postępowali w sposób godny Ewangelii Chrystusowej. Wówczas ja - czy to gdy przybędę do was, żeby was zobaczyć, czy to znajdując się z dala od was - z pewnością będę mógł usłyszeć o was, że trwacie mocno w tych samych pragnieniach i że wszyscy razem stajecie w obronie wiary, którą daje Ewangelia.
###### **Flp 1,28**
 W niczym nie dajcie się przestraszyć waszym przeciwnikom. Wasza odwaga będzie dla nich zapowiedzią ich zagłady, a dla was - źródłem przeświadczenia, że jesteście na drodze do zbawienia, które otrzymacie od Boga.
###### **Flp 1,29**
 Otrzymaliście bowiem łaskę posługiwania Chrystusowi nie tylko przez wiarę w Niego, lecz także przez znoszenie dla Niego ucisków,
###### **Flp 1,30**
 jeśli rzeczywiście uczestniczycie w zmaganiach moich, o których już zresztą słyszeliście przedtem i które, jak wiecie, obecnie prowadzę.
# Flp 1 WUJ
###### **Flp 1,1**
 Paweł i Tymotheusz słudzy Jezusa Chrystusa: wszystkim świętym w Chrystusie Jezusie, którzy są w Philippiech z Biskupy i Diakonami.
###### **Flp 1,2**
 Łaska wam i pokój od Boga Ojca naszego, i Pana Jezusa Chrystusa.
###### **Flp 1,3**
 Dziękuję Bogu memu w każdem przypominaniu was
###### **Flp 1,4**
 Zawżdy we wszelkich prośbach moich za wszystkich was, modlitwą z weselem,
###### **Flp 1,5**
 Za społeczność waszę w Ewanieljej Chrystusowej od pierwszego dnia aż dotąd:
###### **Flp 1,6**
 Mając ufność o tym samym, iż który począł w was dobrą sprawę, wykona aż do dnia Chrystusa Jezusa.
###### **Flp 1,7**
 Jakoż jest słuszna, abych ja to rozumiał o was wszystkich, dla tego, iż was mam w sercu i w więzieniu mojem, i w obronie, i w utwierdzaniu Ewanieljej, że wy wszyscy towarzysze jesteście wesela mego.
###### **Flp 1,8**
 Abowiem świadkiem mi jest Bóg, jako pragnę was wszystkich we wnętrznościach Jezusa Chrystusa.
###### **Flp 1,9**
 I o to proszę, aby miłość wasza więcej a więcej obfitowała w umiejętności i we wszelakiem zrozumieniu:
###### **Flp 1,10**
 Abyście doświadczali co jest pożyteczniejszego, żebyście byli szczeremi i bez obrażenia na dzień Chrystusów.
###### **Flp 1,11**
 Napełnieni owocu sprawiedliwości przez Jezusa Chrystusa, ku sławie i chwale Bożej.
###### **Flp 1,12**
 A chcę bracia, abyście wiedzieli, iż to co się zemną dzieje, więcej się obróciło ku pomnożeniu Ewanieljej.
###### **Flp 1,13**
 Tak iż też okowy moje wiadome są w Chrystusie po wszystkim pałacu, i u wszystkich inszych.
###### **Flp 1,14**
 I więcej z braciej w Panie dufając okowam moim, obficiej śmieli bez bojaźni słowo Boże opowiadać.
###### **Flp 1,15**
 I dla zazdrości i sporu: a niektórzy też z dobrej woli Chrystusa opowiadają.
###### **Flp 1,16**
 Inni z miłości: wiedząc, iżem jest postanowion ku obronie Ewanieljej.
###### **Flp 1,17**
 A drudzy z sporu Chrystusa opowiadają nie szczerze: mniemając, iż przydawają ucisku okowam moim.
###### **Flp 1,18**
 Bo cóż? By jeno wszelkim sposobem, bądź z okazjej, bądź poprawdzie Chrystus był opowiadan, i w tem się weselę, ale i weselić się będę.
###### **Flp 1,19**
 Bo wiem, iż mi to wynidzie ku zbawieniu, za waszą modlitwą i dodawaniem Ducha Jezusa Chrystusa,
###### **Flp 1,20**
 Według oczekawania i nadzieje mojej, iż się w niwczem nie zawstydzę, ale z wszelakiem bezpieczeństwem jako zawsze i teraz wielce będzie wsławion Chrystus w ciele mojem, choć przez żywot, choć przez śmierć.
###### **Flp 1,21**
 Abowiem mnie żyć jest Chrystus, a umrzeć zysk.
###### **Flp 1,22**
 A jeśliż żywym być w ciele, ten mi jest owoc pracej, i nie wiem cobym obrać miał.
###### **Flp 1,23**
 Jestem ściśnion ze dwojga: pragnienie mając, rozwiązanym być, i być z Chrystusem: barzo daleko lepiej.
###### **Flp 1,24**
 Ale zostać w ciele, potrzebna dla was.
###### **Flp 1,25**
 A o tem ufność mając, wiem, iż zostanę i zetrwam wszystkim wam, ku waszemu pomnożeniu i weselu wiary:
###### **Flp 1,26**
 Aby obfitowało przechwalanie wasze w Chrystusie Jezusie we mnie, przez moje przybycie zaś do was.
###### **Flp 1,27**
 Tylko się sprawujcie godnie Ewanieljej Chrystusowej: abym chociaż gdy przybędę i oglądam was, chociaż w niebytności słyszał o was, iż stoicie w jednym duchu, jednomyślni wespół pracując około wiary Ewanieljej.
###### **Flp 1,28**
 A niwczem nie bądźcie ustraszeni od przeciwników, co onym jest przyczyną zginienia, a wam zbawienia, i to od Boga:
###### **Flp 1,29**
 Iż wam darowano, jest dla Chrystusa, nietylko abyście weń wierzyli, ale iżbyście też dla niego cierpili:
###### **Flp 1,30**
 Toż potykanie mając, jakieście i widzieli we mnie, i terazeście o mnie słyszeli.
# Flp 1 STERN
###### **Flp 1,1**
 Sza'ul i Tymoteusz, niewolnicy Mesjasza Jeszui, do całego ludu Bożego zjednoczonego z Mesjaszem Jeszuą, a mieszkającego w Filippi, wraz z przywódcami zgromadzenia i szammaszim:
###### **Flp 1,2**
 łaska wam i szalom od Boga, naszego Ojca, i Pana Jeszui Mesjasza.
###### **Flp 1,3**
 Dziękuję mojemu Bogu za każdym razem, gdy o was myślę.
###### **Flp 1,4**
 Ilekroć modlę się za was wszystkich, zawsze modlę się z radością,
###### **Flp 1,5**
 bo mieliście udział w rozgłaszaniu Dobrej Nowiny od pierwszego dnia aż do dziś.
###### **Flp 1,6**
 A tego jestem pewien: że Ten, który rozpoczął wśród was dobre dzieło, będzie dawał mu wzrost, aż stanie się ono doskonałe w Dniu Mesjasza Jeszui.
###### **Flp 1,7**
 Słusznie w ten sposób o was wszystkich myślę, bo mam was na sercu, bowiem czy jestem w kajdanach, czy bronię Dobrej Nowiny i ugruntowuję ją, wy wszyscy macie ze mną udział w tej zaszczytnej pracy.
###### **Flp 1,8**
 Bóg może zaświadczyć, jak tęsknię za wami wszystkimi głębokim uczuciem Mesjasza Jeszui.
###### **Flp 1,9**
 A o to się modlę: aby miłość wasza coraz bardziej obfitowała w pełnię poznania i głębię rozeznania,
###### **Flp 1,10**
 abyście byli w stanie ocenić, co jest najlepsze, i mogli w ten sposób okazać się czyści i bez zmazy w Dniu Mesjasza,
###### **Flp 1,11**
 obfitujący w owoc sprawiedliwości, który przychodzi przez Jeszuę Mesjasza - na chwałę i cześć Bogu.
###### **Flp 1,12**
 A chcę, bracia, abyście wiedzieli, że to, co mnie spotkało, przyczyniło się do szerzenia Dobrej Nowiny.
###### **Flp 1,13**
 Stało się jasne dla całego pałacu i dla wszystkich innych, że to ze względu na Mesjasza jestem w kajdanach.
###### **Flp 1,14**
 Ponadto mój pobyt w więzieniu dodał otuchy większości braci w Panu, tak że stali się znacznie śmielsi w nieustraszonym głoszeniu słowa Bożego.
###### **Flp 1,15**
 To prawda, że niektórzy rozgłaszają Mesjasza z zazdrości i chęci współzawodnictwa, inni jednak robią to w dobrej wierze.
###### **Flp 1,16**
 Ci postępują w miłości, świadomi, że jestem, gdzie jestem, za obronę Dobrej Nowiny,
###### **Flp 1,17**
 tamci zaś zwiastują Mesjasza z samolubnych ambicji, z nieczystych pobudek, licząc, że mogą mi w więzieniu narobić kłopotów.
###### **Flp 1,18**
 Lecz cóż z tego? Liczy się to jedynie, że na wszelakie sposoby, już to uczciwe, już to nieszczere, Mesjasz jest głoszony, i z tego się raduję. Owszem, i dalej będę się radował,
###### **Flp 1,19**
 bo wiem, że to przyczyni się do mojego uwolnienia, dzięki waszym modlitwom i pokrzepieniu, jakiego mi udziela Duch Jeszui Mesjasza.
###### **Flp 1,20**
 Wszystko to jest zgodne z moim najszczerszym oczekiwaniem i nadzieją, że nie będę musiał się wstydzić, lecz że teraz jak zawsze Mesjasz zostanie uwielbiony w moim ciele: albo żywym, albo martwym.
###### **Flp 1,21**
 Bo dla mnie życie to Mesjasz, a śmierć to zysk.
###### **Flp 1,22**
 Jeśli jednak żyjąc dalej w ciele, mogę wykonywać owocne dzieło, to nie wiem, co wybrać.
###### **Flp 1,23**
 Staję przed dylematem: pragnę odejść, aby być z Mesjaszem - to daleko lepsze -
###### **Flp 1,24**
 ale ze względu na was potrzebniejsze jest zostać jeszcze w ciele.
###### **Flp 1,25**
 Tak, jestem tego pewien; wiem zatem, że zostanę dalej z wami, aby pomóc wam wzrastać w wierze i radować się w niej.
###### **Flp 1,26**
 A wtedy przez to, że ponownie będę wśród was, jeszcze ważniejszy będziecie mieli powód, aby szczycić się Mesjaszem Jeszuą.
###### **Flp 1,27**
 Tylko prowadźcie swoje życie w sposób godny Dobrej Nowiny o Mesjaszu, tak abyście - czy to gdy przybędę i ujrzę was, czy to gdy usłyszę o was z daleka - trwali niewzruszenie, zjednoczeni w duchu, walcząc jednomyślnie o wiarę Dobrej Nowiny,
###### **Flp 1,28**
 nie lękając się niczego, co robią przeciwnicy. Będzie to dla nich sygnałem, że zmierzają do zguby, wy zaś do wyzwolenia. A to pochodzi od Boga,
###### **Flp 1,29**
 bo ze względu na Mesjasza zostało wam dane nie tylko pokładać w Nim ufność, ale i cierpieć dla Niego,
###### **Flp 1,30**
 toczyć te same boje, jakie kiedyś widzieliście, że ja toczyłem, a teraz słyszycie, że toczę je nadal.
# Flp 1 TRO
###### **Flp 1,1**
 **παυλος** *paulos* Paweł – [mały] [[G3972]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **τιμοθεος** *timotheos* Tymoteusz – [czczący Boga] [[G5095]] [[N-NSM]] **δουλοι** *douloi* niewolnicy – słudzy [[G1401]] WTN-NPM **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **πασιν** *pasin* wszystkim [[G3956]] WTA-DPM **τοις** *tois* [[G3588]] WTT-DPM **αγιοις** *hagiois* świętym [[G40]] WTA-DPM **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM **τοις** *tois* [[G3588]] WTT-DPM **ουσιν** *ousin* będącym [[G5607]] WTV-PXP-DPM **εν** *en* w [[G1722]] [[PREP]] **φιλιπποις** *filippois* Filippi – [miłujący konie] [[G5375]] WTN-DPM **συν** *syn* razem z [[G4862]] [[PREP]] **επισκοποις** *episkopois* doglądającymi – dozorującymi [[G1985]] WTN-DPM **και** *kai* i [[G2532]] [[CONJ]] **διακονοις** *diakonois* sługami [[G1249]] WTN-DPM
###### **Flp 1,2**
 **χαρις** *charis* łaska [[G5485]] [[N-NSF]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **και** *kai* i [[G2532]] [[CONJ]] **ειρηνη** *eirēnē* pokój [[G1515]] [[N-NSF]] **απο** *apo* od [[G575]] [[PREP]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **πατρος** *patros* Ojca [[G3962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **και** *kai* i [[G2532]] [[CONJ]] **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **Flp 1,3**
 **ευχαριστω** *eucharistō* Dziękuję [[G2168]] WTV-PAI-1S **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **μου** *mou* mojemu [[G3450]] WTP-1GS **επι** *epi* przy [[G1909]] [[PREP]] **παση** *pasē* każdym [[G3956]] WTA-DSF **τη** *tē* [[G3588]] WTT-DSF **μνεια** *mneia* wspomnieniu [[G3417]] [[N-DSF]] **υμων** *hymōn* was [[G5216]] WTP-2GP
###### **Flp 1,4**
 **παντοτε** *pantote* zawsze – każdej chwili [[G3842]] [[ADV]] **εν** *en* w [[G1722]] [[PREP]] **παση** *pasē* każdej [[G3956]] WTA-DSF **δεησει** *deēsei* prośbie [[G1162]] [[N-DSF]] **μου** *mou* mojej [[G3450]] WTP-1GS **υπερ** *hyper* za [[G5228]] [[PREP]] **παντων** *pantōn* wszystkich [[G3956]] WTA-GPM **υμων** *hymōn* was [[G5216]] WTP-2GP **μετα** *meta* z [[G3326]] [[PREP]] **χαρας** *charas* radością [[G5479]] [[N-GSF]] **την** *tēn* [[G3588]] WTT-ASF **δεησιν** *deēsin* prośbę [[G1162]] WTN-ASF **ποιουμενος** *poioumenos* czyniąc [[G4160]] WTV-PMP-NSM
###### **Flp 1,5**
 **επι** *epi* Z powodu [[G1909]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **κοινωνια** *koinōnia* wspólnoty [[G2842]] [[N-DSF]] **υμων** *hymōn* waszej [[G5216]] WTP-2GP **εις** *eis* względem [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **ευαγγελιον** *euangelion* dobrej nowiny [[G2098]] WTN-ASN **απο** *apo* od [[G575]] [[PREP]] **πρωτης** *prōtēs* pierwszego [[G4413]] WTA-GSF **ημερας** *hēmeras* dnia [[G2250]] [[N-GSF]] **αχρι** *achri* aż do [[G891]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **νυν** *nyn* teraz [[G3568]] [[ADV]]
###### **Flp 1,6**
 **πεποιθως** *pepoithōs* będąc przekonany – pokładając ufność [[G3982]] WTV-2RAP-NSM **αυτο** *auto* samym [[G846]] WTP-ASN **τουτο** *touto* tym [[G5124]] WTD-ASN **οτι** *hoti* że [[G3754]] [[CONJ]] **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **εναρξαμενος** *enarksamenos* który rozpoczął [[G1728]] WTV-ADP-NSM **εν** *en* w [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **εργον** *ergon* dzieło [[G2041]] WTN-ASN **αγαθον** *agathon* dobre [[G18]] WTA-ASN **επιτελεσει** *epitelesei* będzie wypełniał [[G2005]] WTV-FAI-3S **αχρις** *achris* aż do [[G891]] [[PREP]] **ημερας** *hēmeras* dnia [[G2250]] [[N-GSF]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **Flp 1,7**
 **καθως** *kathōs* Tak, jak [[G2531]] [[ADV]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **δικαιον** *dikaion* sprawiedliwe [[G1342]] WTA-NSN **εμοι** *emoi* (dla) mnie [[G1698]] WTP-1DS **τουτο** *touto* to [[G5124]] WTD-ASN **φρονειν** *fronein* myśleć – rozumieć [[G5426]] WTV-PAN **υπερ** *hyper* o [[G5228]] [[PREP]] **παντων** *pantōn* wszystkich [[G3956]] WTA-GPM **υμων** *hymōn* was [[G5216]] WTP-2GP **δια** *dia* z powodu [[G1223]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **εχειν** *echein* mieć [[G2192]] WTV-PAN **με** *me* mi [[G3165]] WTP-1AS **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **καρδια** *kardia* sercu [[G2588]] [[N-DSF]] **υμας** *hymas* was [[G5209]] WTP-2AP **εν** *en* w [[G1722]] [[PREP]] **τε** *te* zarówno [[G5037]] WTPRT **τοις** *tois* (w) [[G3588]] WTT-DPM **δεσμοις** *desmois* więzach [[G1199]] WTN-DPM **μου** *mou* moich [[G3450]] WTP-1GS **και** *kai* i [[G2532]] [[CONJ]] **τη** *tē* [[G3588]] WTT-DSF **απολογια** *apologia* obronie [[G627]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **βεβαιωσει** *bebaiōsei* utwierdzeniu – umocnieniu [[G951]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSN **ευαγγελιου** *euangeliou* dobrej nowiny [[G2098]] [[N-GSN]] **συγκοινωνους** *sygkoinōnous* współuczestnikami [[G4791]] WTA-APM **μου** *mou* mojej [[G3450]] WTP-1GS **της** *tēs* [[G3588]] [[T-GSF]] **χαριτος** *charitos* łaski [[G5485]] [[N-GSF]] **παντας** *pantas* wszystkich [[G3956]] WTA-APM **υμας** *hymas* was [[G5209]] WTP-2AP **οντας** *ontas* będącymi [[G5607]] WTV-PXP-APM
###### **Flp 1,8**
 **μαρτυς** *martys* Świadek [[G3144]] [[N-NSM]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **μου** *mou* moim [[G3450]] WTP-1GS **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ως** *hōs* jak [[G5613]] [[ADV]] **επιποθω** *epipothō* tęsknię – pragnę [[G1971]] WTV-PAI-1S **παντας** *pantas* wszystkich [[G3956]] WTA-APM **υμας** *hymas* was [[G5209]] WTP-2AP **εν** *en* we [[G1722]] [[PREP]] **σπλαγχνοις** *splagchnois* wnętrznościach – głębokich uczuciach [[G4698]] WTN-DPN **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **Flp 1,9**
 **και** *kai* I [[G2532]] [[CONJ]] **τουτο** *touto* (o) to [[G5124]] WTD-ASN **προσευχομαι** *proseuchomai* modlę się [[G4336]] WTV-PNI-1S **ινα** *hina* aby [[G2443]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **αγαπη** *agapē* miłość [[G26]] [[N-NSF]] **υμων** *hymōn* wasza [[G5216]] WTP-2GP **ετι** *eti* jeszcze [[G2089]] [[ADV]] **μαλλον** *mallon* bardziej [[G3123]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **μαλλον** *mallon* bardziej [[G3123]] [[ADV]] **περισσευη** *perisseuē* obfitowałaby [[G4052]] WTV-PAS-3S **εν** *en* w [[G1722]] [[PREP]] **επιγνωσει** *epignōsei* poznaniu [[G1922]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **παση** *pasē* wszelkim [[G3956]] WTA-DSF **αισθησει** *aisthēsei* postrzeganiu – spostrzeżeniu [[G144]] [[N-DSF]]
###### **Flp 1,10**
 **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **δοκιμαζειν** *dokimazein* rozpoznawać – badać [[G1381]] WTV-PAN **υμας** *hymas* wam [[G5209]] WTP-2AP **τα** *ta* (te) [[G3588]] WTT-APN **διαφεροντα** *diaferonta* przewyższające – różniące się [[G1308]] WTV-PAP-APN **ινα** *hina* aby [[G2443]] [[CONJ]] **ητε** *ēte* bylibyście [[G5600]] WTV-PXS-2P **ειλικρινεις** *eilikrineis* szczerzy – nieskażeni [[G1506]] WTA-NPM **και** *kai* i [[G2532]] [[CONJ]] **απροσκοποι** *aproskopoi* nie powodujący potknięcia się – nie powodujący obrazy [[G677]] WTA-NPM **εις** *eis* do [[G1519]] [[PREP]] **ημεραν** *hēmeran* dnia [[G2250]] WTN-ASF **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **Flp 1,11**
 **πεπληρωμενοι** *peplērōmenoi* którzy są wypełnieni [[G4137]] WTV-RPP-NPM **καρπων** *karpōn* owocami [[G2590]] WTN-GPM **δικαιοσυνης** *dikaiosynēs* sprawiedliwości [[G1343]] [[N-GSF]] **των** *tōn* [[G3588]] WTT-GPM **δια** *dia* przez [[G1223]] [[PREP]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **εις** *eis* ku [[G1519]] [[PREP]] **δοξαν** *doksan* chwale [[G1391]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **επαινον** *epainon* pochwale [[G1868]] [[N-ASM]] **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **Flp 1,12**
 **γινωσκειν** *ginōskein* (By) znać [[G1097]] WTV-PAN **δε** *de* zaś [[G1161]] [[CONJ]] **υμας** *hymas* (przez) was [[G5209]] WTP-2AP **βουλομαι** *boulomai* chcę [[G1014]] WTV-PNI-1S **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **οτι** *hoti* że [[G3754]] [[CONJ]] **τα** *ta* (te) [[G3588]] WTT-NPN **κατ** *kat* przeciwko [[G2596]] [[PREP]] **εμε** *eme* mnie [[G1691]] WTP-1AS **μαλλον** *mallon* bardziej [[G3123]] [[ADV]] **εις** *eis* ku [[G1519]] [[PREP]] **προκοπην** *prokopēn* postępowi [[G4297]] WTN-ASF **του** *tou* [[G3588]] WTT-GSN **ευαγγελιου** *euangeliou* dobrej nowiny [[G2098]] [[N-GSN]] **εληλυθεν** *elēlythen* przyszło [[G2064]] WTV-2RAI-3S
###### **Flp 1,13**
 **ωστε** *hōste* tak, że [[G5620]] [[CONJ]] **τους** *tous* [[G3588]] WTT-APM **δεσμους** *desmous* więzy [[G1199]] [[N-APM]] **μου** *mou* moje [[G3450]] WTP-1GS **φανερους** *fanerous* widoczne – jawne [[G5318]] WTA-APM **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **γενεσθαι** *genesthai* stać się [[G1096]] WTV-2ADN **εν** *en* w [[G1722]] [[PREP]] **ολω** *holō* całym [[G3650]] WTA-DSN **τω** *tō* [[G3588]] WTT-DSN **πραιτωριω** *praitōriō* pretorium – siedzibie namiestnika [[G4232]] WTN-DSN **και** *kai* i [[G2532]] [[CONJ]] **τοις** *tois* [[G3588]] WTT-DPM **λοιποις** *loipois* pozostałym [[G3062]] WTA-DPM **πασιν** *pasin* wszystkim [[G3956]] WTA-DPM
###### **Flp 1,14**
 **και** *kai* i [[G2532]] [[CONJ]] **τους** *tous* [[G3588]] WTT-APM **πλειονας** *pleionas* coraz liczniejsi [[G4119]] WTA-APM-C **των** *tōn* (z) [[G3588]] WTT-GPM **αδελφων** *adelfōn* braci [[G80]] WTN-GPM **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **πεποιθοτας** *pepoithotas* będąc przekonani – pokładając ufność [[G3982]] WTV-2RAP-APM **τοις** *tois* [[G3588]] WTT-DPM **δεσμοις** *desmois* więzami [[G1199]] WTN-DPM **μου** *mou* moimi [[G3450]] WTP-1GS **περισσοτερως** *perissoterōs* bardziej – jeszcze obficiej [[G4056]] [[ADV]] **τολμαν** *tolman* ośmielać się – odważać się [[G5111]] WTV-PAN **αφοβως** *afobōs* bez obaw – bez bojaźni [[G870]] [[ADV]] **τον** *ton* [[G3588]] [[T-ASM]] **λογον** *logon* Słowo [[G3056]] [[N-ASM]] **λαλειν** *lalein* mówić [[G2980]] WTV-PAN
###### **Flp 1,15**
 **τινες** *tines* Niektórzy [[G5100]] WTX-NPM **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **δια** *dia* z powodu [[G1223]] [[PREP]] **φθονον** *fthonon* zawiści – zazdrości [[G5355]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **εριν** *erin* kłótni – sporu [[G2054]] WTN-ASF **τινες** *tines* niektórzy [[G5100]] WTX-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **δι** *di* z powodu [[G1223]] [[PREP]] **ευδοκιαν** *eudokian* upodobania [[G2107]] WTN-ASF **τον** *ton* [[G3588]] [[T-ASM]] **χριστον** *christon* Pomazańca [[G5547]] [[N-ASM]] **κηρυσσουσιν** *kēryssousin* głoszą [[G2784]] WTV-PAI-3P
###### **Flp 1,16**
 **οι** *hoi* (ci) [[G3588]] WTT-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **εξ** *eks* z [[G1537]] [[PREP]] **αγαπης** *agapēs* miłości [[G26]] [[N-GSF]] **ειδοτες** *eidotes* wiedząc [[G1492]] WTV-RAP-NPM **οτι** *hoti* że [[G3754]] [[CONJ]] **εις** *eis* do [[G1519]] [[PREP]] **απολογιαν** *apologian* obrony [[G627]] WTN-ASF **του** *tou* [[G3588]] WTT-GSN **ευαγγελιου** *euangeliou* dobrej nowiny [[G2098]] [[N-GSN]] **κειμαι** *keimai* jestem umieszczony – jestem położony [[G2749]] WTV-PNI-1S
###### **Flp 1,17**
 **οι** *hoi* (ci) [[G3588]] WTT-NPM **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **εξ** *eks* z [[G1537]] [[PREP]] **εριθειας** *eritheias* niesnasek – podjudzania [[G2052]] [[N-GSF]] **τον** *ton* [[G3588]] [[T-ASM]] **χριστον** *christon* Pomazańca [[G5547]] [[N-ASM]] **καταγγελλουσιν** *katangellousin* zwiastują – głoszą [[G2605]] WTV-PAI-3P **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **αγνως** *hagnōs* szczerze – w czysty sposób [[G55]] [[ADV]] **οιομενοι** *oiomenoi* sądząc – myśląc [[G3633]] WTV-PNP-NPM **θλιψιν** *thlipsin* ucisk – utrapienie [[G2347]] WTN-ASF **επιφερειν** *epiferein* nosić [[G2018]] WTV-PAN **τοις** *tois* [[G3588]] WTT-DPM **δεσμοις** *desmois* więzów [[G1199]] WTN-DPM **μου** *mou* moich [[G3450]] WTP-1GS
###### **Flp 1,18**
 **τι** *ti* co [[G5101]] WTI-NSN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **πλην** *plēn* mimo, że [[G4133]] [[ADV]] **παντι** *panti* każdym [[G3956]] WTA-DSM **τροπω** *tropō* sposobem [[G5158]] WTN-DSM **ειτε** *eite* czy to [[G1535]] [[CONJ]] **προφασει** *profasei* pretekstem – pozorem [[G4392]] [[N-DSF]] **ειτε** *eite* czy to [[G1535]] [[CONJ]] **αληθεια** *alētheia* prawdą [[G225]] [[N-DSF]] **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **καταγγελλεται** *katangelletai* jest zwiastowany – jest głoszony [[G2605]] WTV-PPI-3S **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **τουτω** *toutō* tym [[G5129]] WTD-DSN **χαιρω** *chairō* raduję się – cieszę się [[G5463]] WTV-PAI-1S **αλλα** *alla* ale [[G235]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **χαρησομαι** *charēsomai* będę się radował – będę się cieszył [[G5463]] WTV-2FOI-1S
###### **Flp 1,19**
 **οιδα** *oida* wiem [[G1492]] WTV-RAI-1S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **οτι** *hoti* że [[G3754]] [[CONJ]] **τουτο** *touto* to [[G5124]] WTD-NSN **μοι** *moi* mi [[G3427]] WTP-1DS **αποβησεται** *apobēsetai* wyjdzie [[G576]] WTV-FDI-3S **εις** *eis* ku [[G1519]] [[PREP]] **σωτηριαν** *sōtērian* zbawieniu – wyzwoleniu [[G4991]] WTN-ASF **δια** *dia* przez [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **υμων** *hymōn* waszą [[G5216]] WTP-2GP **δεησεως** *deēseōs* prośbę [[G1162]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **επιχορηγιας** *epichorēgias* zaopatrzenie – wsparcie [[G2024]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSN **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **Flp 1,20**
 **κατα** *kata* według [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **αποκαραδοκιαν** *apokaradokian* oczekiwania – wyczekiwania [[G603]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **ελπιδα** *elpida* nadziei [[G1680]] WTN-ASF **μου** *mou* mojej [[G3450]] WTP-1GS **οτι** *hoti* że [[G3754]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **ουδενι** *oudeni* niczym [[G3762]] WTA-DSN **αισχυνθησομαι** *aischynthēsomai* zostanę zawstydzony [[G153]] WTV-FPI-1S **αλλ** *all* ale [[G235]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **παση** *pasē* całej [[G3956]] WTA-DSF **παρρησια** *parrēsia* otwartości – śmiałości [[G3954]] [[N-DSF]] **ως** *hōs* jak [[G5613]] [[ADV]] **παντοτε** *pantote* zawsze – każdej chwili [[G3842]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **νυν** *nyn* teraz [[G3568]] [[ADV]] **μεγαλυνθησεται** *megalynthēsetai* zostanie wywyższony [[G3170]] WTV-FPI-3S **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **σωματι** *sōmati* ciele [[G4983]] WTN-DSN **μου** *mou* moim [[G3450]] WTP-1GS **ειτε** *eite* czy to [[G1535]] [[CONJ]] **δια** *dia* przez [[G1223]] [[PREP]] **ζωης** *zōēs* życie [[G2222]] [[N-GSF]] **ειτε** *eite* czy to [[G1535]] [[CONJ]] **δια** *dia* przez [[G1223]] [[PREP]] **θανατου** *thanatou* śmierć [[G2288]] [[N-GSM]]
###### **Flp 1,21**
 **εμοι** *emoi* (Dla) mnie [[G1698]] WTP-1DS **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **ζην** *zēn* żyć [[G2198]] WTV-PAN **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **και** *kai* a [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **αποθανειν** *apothanein* umrzeć [[G599]] [[V-2AAN]] **κερδος** *kerdos* zysk [[G2771]] WTN-NSN
###### **Flp 1,22**
 **ει** *ei* Jeśli [[G1487]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **ζην** *zēn* żyć [[G2198]] WTV-PAN **εν** *en* w [[G1722]] [[PREP]] **σαρκι** *sarki* ciele [[G4561]] [[N-DSF]] **τουτο** *touto* to [[G5124]] WTD-NSN **μοι** *moi* (dla) mnie [[G3427]] WTP-1DS **καρπος** *karpos* owoc [[G2590]] [[N-NSM]] **εργου** *ergou* pracy [[G2041]] [[N-GSN]] **και** *kai* i [[G2532]] [[CONJ]] **τι** *ti* co [[G5101]] WTI-ASN **αιρησομαι** *hairēsomai* wybiorę [[G138]] WTV-FMI-1S **ου** *ou* nie [[G3756]] [[PRT-N]] **γνωριζω** *gnōrizō* wiem [[G1107]] WTV-PAI-1S
###### **Flp 1,23**
 **συνεχομαι** *synechomai* Jestem pociągany – Jestem obejmowany [[G4912]] WTV-PPI-1S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εκ** *ek* z [[G1537]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **δυο** *dyo* dwóch [[G1417]] WTA-NUI **την** *tēn* [[G3588]] WTT-ASF **επιθυμιαν** *epithymian* pragnienie – pożądanie [[G1939]] WTN-ASF **εχων** *echōn* mając [[G2192]] [[V-PAP-NSM]] **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **αναλυσαι** *analysai* odejść [[G360]] [[V-AAN]] **και** *kai* i [[G2532]] [[CONJ]] **συν** *syn* razem z [[G4862]] [[PREP]] **χριστω** *christō* Pomazańcem [[G5547]] WTN-DSM **ειναι** *einai* być [[G1511]] WTV-PXN **πολλω** *pollō* wielce [[G4183]] WTA-DSN **μαλλον** *mallon* bardziej [[G3123]] [[ADV]] **κρεισσον** *kreisson* lepsze [[G2908]] WTA-NSN
###### **Flp 1,24**
 **το** *to* [[G3588]] WTT-NSN **δε** *de* zaś [[G1161]] [[CONJ]] **επιμενειν** *epimenein* pozostawać [[G1961]] WTV-PAN **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **σαρκι** *sarki* ciele [[G4561]] [[N-DSF]] **αναγκαιοτερον** *anagkaioteron* konieczniejsze – niezbędniejsze [[G316]] WTA-NSN-C **δι** *di* z powodu [[G1223]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP
###### **Flp 1,25**
 **και** *kai* I [[G2532]] [[CONJ]] **τουτο** *touto* to [[G5124]] WTD-ASN **πεποιθως** *pepoithōs* będąc przekonany – pokładając ufność [[G3982]] WTV-2RAP-NSM **οιδα** *oida* wiem [[G1492]] WTV-RAI-1S **οτι** *hoti* że [[G3754]] [[CONJ]] **μενω** *menō* pozostanę [[G3306]] WTV-FAI-1S **και** *kai* i [[G2532]] [[CONJ]] **συμπαραμενω** *symparamenō* będę trwać razem przy [[G4839]] WTV-FAI-1S **πασιν** *pasin* wszystkich [[G3956]] WTA-DPM **υμιν** *hymin* was [[G5213]] WTP-2DP **εις** *eis* ku [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **υμων** *hymōn* waszemu [[G5216]] WTP-2GP **προκοπην** *prokopēn* postępowi [[G4297]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **χαραν** *charan* radości [[G5479]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]]
###### **Flp 1,26**
 **ινα** *hina* aby [[G2443]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **καυχημα** *kauchēma* chluba [[G2745]] WTN-NSN **υμων** *hymōn* wasza [[G5216]] WTP-2GP **περισσευη** *perisseuē* obfitowałaby [[G4052]] WTV-PAS-3S **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM **εν** *en* we [[G1722]] [[PREP]] **εμοι** *emoi* mnie [[G1698]] WTP-1DS **δια** *dia* z powodu [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **εμης** *emēs* mojego [[G1699]] WTS-1GSF **παρουσιας** *parousias* przyjścia [[G3952]] [[N-GSF]] **παλιν** *palin* znowu [[G3825]] [[ADV]] **προς** *pros* do [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP
###### **Flp 1,27**
 **μονον** *monon* jedynie – tylko [[G3440]] [[ADV]] **αξιως** *aksiōs* godnie [[G516]] [[ADV]] **του** *tou* [[G3588]] WTT-GSN **ευαγγελιου** *euangeliou* dobrą nowinę [[G2098]] [[N-GSN]] **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **πολιτευεσθε** *politeuesthe* żyjcie jak obywatele [[G4176]] WTV-PNM-2P **ινα** *hina* aby [[G2443]] [[CONJ]] **ειτε** *eite* czy to [[G1535]] [[CONJ]] **ελθων** *elthōn* przyszedłszy [[G2064]] WTV-2AAP-NSM **και** *kai* i [[G2532]] [[CONJ]] **ιδων** *idōn* zobaczywszy [[G1492]] WTV-2AAP-NSM **υμας** *hymas* was [[G5209]] WTP-2AP **ειτε** *eite* czy to [[G1535]] [[CONJ]] **απων** *apōn* będąc nieobecnym [[G548]] [[V-PXP-NSM]] **ακουσω** *akousō* słyszałbym [[G191]] WTV-AAS-1S **τα** *ta* [[G3588]] WTT-APN **περι** *peri* o [[G4012]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **οτι** *hoti* że [[G3754]] [[CONJ]] **στηκετε** *stēkete* stoicie – trwacie [[G4739]] WTV-PAI-2P **εν** *en* w [[G1722]] [[PREP]] **ενι** *heni* jednym [[G1520]] WTA-DSN **πνευματι** *pneumati* duchu [[G4151]] WTN-DSN **μια** *mia* jedną [[G1520]] WTA-DSF **ψυχη** *psychē* duszą – życiem [[G5590]] [[N-DSF]] **συναθλουντες** *synathlountes* walcząc razem [[G4866]] WTV-PAP-NPM **τη** *tē* (dla) [[G3588]] WTT-DSF **πιστει** *pistei* wiary [[G4102]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSN **ευαγγελιου** *euangeliou* dobrej nowiny [[G2098]] [[N-GSN]]
###### **Flp 1,28**
 **και** *kai* i [[G2532]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **πτυρομενοι** *ptyromenoi* dając się zastraszyć [[G4426]] WTV-PPP-NPM **εν** *en* w [[G1722]] [[PREP]] **μηδενι** *mēdeni* niczym [[G3367]] WTA-DSN **υπο** *hypo* przez [[G5259]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **αντικειμενων** *antikeimenōn* będących przeciwnymi [[G480]] WTV-PNP-GPM **ητις** *hētis* co [[G3748]] WTR-NSF **αυτοις** *autois* (dla) nich [[G846]] WTP-DPM **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ενδειξις** *endeiksis* wykazanie – dowód [[G1732]] [[N-NSF]] **απωλειας** *apōleias* zguby – zatracenia [[G684]] [[N-GSF]] **υμιν** *hymin* waszej [[G5213]] WTP-2DP **δε** *de* zaś [[G1161]] [[CONJ]] **σωτηριας** *sōtērias* zbawienia – wyzwolenia [[G4991]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **τουτο** *touto* to [[G5124]] WTD-NSN **απο** *apo* od [[G575]] [[PREP]] **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **Flp 1,29**
 **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **εχαρισθη** *echaristhē* zostało darowane [[G5483]] [[V-API-3S]] **το** *to* (to) [[G3588]] WTT-ASN **υπερ** *hyper* za [[G5228]] [[PREP]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **ου** *ou* nie [[G3756]] [[PRT-N]] **μονον** *monon* jedynie – tylko [[G3440]] [[ADV]] **το** *to* [[G3588]] WTT-ASN **εις** *eis* w [[G1519]] [[PREP]] **αυτον** *auton* Niego [[G846]] WTP-ASM **πιστευειν** *pisteuein* wierzyć [[G4100]] WTV-PAN **αλλα** *alla* ale [[G235]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-ASN **υπερ** *hyper* za [[G5228]] [[PREP]] **αυτου** *autou* Niego [[G846]] [[P-GSM]] **πασχειν** *paschein* cierpieć [[G3958]] WTV-PAN
###### **Flp 1,30**
 **τον** *ton* (ten) [[G3588]] [[T-ASM]] **αυτον** *auton* sam [[G846]] WTP-ASM **αγωνα** *agōna* bój – walkę [[G73]] [[N-ASM]] **εχοντες** *echontes* mając [[G2192]] WTV-PAP-NPM **οιον** *hoion* jaki [[G3634]] WTK-ASM **ειδετε** *eidete* zobaczyliście [[G1492]] WTV-2AAI-2P **εν** *en* we [[G1722]] [[PREP]] **εμοι** *emoi* mnie [[G1698]] WTP-1DS **και** *kai* i [[G2532]] [[CONJ]] **νυν** *nyn* teraz [[G3568]] [[ADV]] **ακουετε** *akouete* słyszycie [[G191]] WTV-PAI-2P **εν** *en* we [[G1722]] [[PREP]] **εμοι** *emoi* mnie [[G1698]] WTP-1DS
