# 1Krl 8 BT5
###### **1Krl 8,1**
 Wtedy też Salomon zwołał starszyznę Izraela, wszystkich naczelników pokoleń, przywódców rodów Izraelitów, aby zgromadzili się przy królu Salomonie w Jerozolimie na przeniesienie Arki Przymierza Pańskiego z Miasta Dawidowego, czyli z Syjonu.
###### **1Krl 8,2**
 Zebrali się więc u króla Salomona wszyscy Izraelici w miesiącu Etanim, na Święto [Namiotów] przypadające w siódmym miesiącu.
###### **1Krl 8,3**
 Kiedy przyszła cała starszyzna Izraela, kapłani wzięli arkę
###### **1Krl 8,4**
 i przenieśli Arkę Pańską, Namiot Spotkania i wszystkie święte sprzęty, jakie były w namiocie. Przenieśli je kapłani oraz lewici.
###### **1Krl 8,5**
 A król Salomon i cała społeczność Izraela, zgromadzona przy nim, przed arką składali wraz z nim na ofiarę owce i woły, których nie rachowano i nie obliczano z powodu wielkiej ich liczby.
###### **1Krl 8,6**
 Następnie kapłani wprowadzili Arkę Przymierza Pańskiego na jej miejsce do sanktuarium świątyni, do Miejsca Najświętszego, pod skrzydła cherubów,
###### **1Krl 8,7**
 gdyż cheruby miały tak rozpostarte skrzydła nad miejscem arki, że okrywały arkę i jej drążki z wierzchu.
###### **1Krl 8,8**
 Drążki te były tak długie, że ich końce widoczne były z Miejsca Świętego przed sanktuarium, z zewnątrz jednak nie były widoczne. Pozostają one tam do dnia dzisiejszego.
###### **1Krl 8,9**
 W arce nie było nic, oprócz dwóch kamiennych tablic, które Mojżesz tam złożył pod Horebem, < tablic Przymierza >, gdy Pan zawarł przymierze z Izraelitami w czasie ich wyjścia z ziemi egipskiej.
###### **1Krl 8,10**
 A kiedy kapłani wyszli z Miejsca Świętego, obłok wypełnił dom Pański.
###### **1Krl 8,11**
 Kapłani nie mogli pozostać i pełnić swej służby z powodu tego obłoku, bo chwała Pańska napełniła dom Pański.
###### **1Krl 8,12**
 Wtedy przemówił Salomon: «***Pan powiedział, że będzie mieszkać w czarnej chmurze.***
###### **1Krl 8,13**
 ***Już zbudowałem Ci dom na mieszkanie, miejsce przebywania Twego na wieki***».
###### **1Krl 8,14**
 Potem król się odwrócił i pobłogosławił całe zgromadzenie Izraela. Całe zaś zgromadzenie Izraela stało.
###### **1Krl 8,15**
 Potem rzekł: «***Błogosławiony Pan, Bóg Izraela, który to, co zapowiedział swymi ustami memu ojcu, Dawidowi, też własnoręcznie wypełnił, mówiąc:***
###### **1Krl 8,16**
 ***Od tego dnia, w którym wyprowadziłem mój lud, Izraela, z Egiptu, nie wybrałem ze wszystkich pokoleń izraelskich miasta celem wybudowania [w nim] świątyni, by imię moje w niej przebywało. Ale wybrałem sobie <Jerozolimę, aby tam było moje imię, i obrałem > Dawida, aby był nad moim ludem, Izraelem.***
###### **1Krl 8,17**
 ***Dawid zaś, mój ojciec, powziął zamiar zbudowania domu dla imienia Pana, Boga Izraela.***
###### **1Krl 8,18**
 ***Wówczas Pan rzekł memu ojcu, Dawidowi: Dobrze postąpiłeś, że powziąłeś zamiar zbudowania domu dla mego imienia, bo wypłynęło to z twego serca.***
###### **1Krl 8,19**
 ***Jednak nie ty będziesz budować tę świątynię, ale twój rodzony syn. On zbuduje dom dla mego imienia.***
###### **1Krl 8,20**
 ***Pan wypełnił właśnie to, co obiecał, bo nastałem po moim ojcu, Dawidzie, i zasiadłem na tronie izraelskim, jak zapowiedział Pan, oraz zbudowałem dom dla imienia Pana, Boga Izraela.***
###### **1Krl 8,21**
 ***A w nim urządziłem miejsce dla arki, w której jest przymierze Pana zawarte z naszymi przodkami, gdy ich wyprowadził z ziemi egipskiej***».
###### **1Krl 8,22**
 Następnie Salomon stanął przed ołtarzem Pańskim wobec całego zgromadzenia izraelskiego i wyciągnąwszy ręce do nieba, rzekł:
###### **1Krl 8,23**
 «***O Panie, Boże Izraela! Nie ma takiego Boga jak Ty, ani w górze na niebie, ani w dole na ziemi, tak dochowującego przymierza i łaski względem Twoich sług, którzy czczą Cię z całego serca,***
###### **1Krl 8,24**
 ***bo dotrzymałeś słowa Twemu słudze, Dawidowi, memu ojcu, w tym, coś mu przyrzekł i powiedział swymi ustami, a co dziś wypełniłeś własnoręcznie.***
###### **1Krl 8,25**
 ***Więc i teraz, o Panie, Boże Izraela, dotrzymaj słowa danego Twemu słudze, memu ojcu, Dawidowi, jak mu przyrzekłeś, mówiąc: Nie będzie ci odjęty sprzed mego oblicza mąż zasiadający na tronie Izraela, jeśli tylko twoi synowie strzec będą swej drogi, postępując wobec Mnie tak, jak ty wobec Mnie postępowałeś.***
###### **1Krl 8,26**
 ***Więc i teraz niech się sprawdzi, proszę Cię, < Panie >, Boże Izraela, Twoje słowo, które dałeś Twemu słudze, ojcu memu, Dawidowi.***
###### **1Krl 8,27**
 ***Czy jednak naprawdę zamieszka Bóg na ziemi? Przecież niebo i niebiosa najwyższe nie mogą Cię objąć, a tym mniej ta świątynia, którą zbudowałem.***
###### **1Krl 8,28**
 ***Zważ więc na modlitwę Twego sługi i jego błaganie, o Panie, Boże mój, i wysłuchaj tego wołania i tej modlitwy, którą dziś Twój sługa zanosi przed Ciebie.***
###### **1Krl 8,29**
 ***Niech w nocy i w dzień Twoje oczy będą otwarte na tę świątynię, na miejsce, o którym powiedziałeś: Tam będzie moje imię – tak, aby wysłuchać modlitwę, którą zanosi Twój sługa na tym miejscu.***
###### **1Krl 8,30**
 ***Dlatego wysłuchaj błaganie sługi Twego i Twojego ludu, Izraela, ilekroć modlić się będzie na tym miejscu. Ty zaś wysłuchaj w miejscu Twego przebywania – w niebie. Nie tylko wysłuchaj, ale też i przebacz!***
###### **1Krl 8,31**
 ***Kiedy ktoś zgrzeszy przeciw swemu bliźniemu, później zaś wezwie go do przysięgi, a on przyjdzie do przysięgi wobec Twego ołtarza w tej świątyni,***
###### **1Krl 8,32**
 ***wtedy Ty wysłuchaj w niebiosach i racz działać: rozsądź między Twoimi sługami, złego skazując na karę, aby na jego głowę spadła [odpowiedzialność za] jego postępowanie, a sprawiedliwego uznając niewinnym za jego uczciwość.***
###### **1Krl 8,33**
 ***Kiedy Twój lud spotka klęska od nieprzyjaciela za to, że zgrzeszył przeciw Tobie, a oni się nawrócą do Ciebie i będą wzywać Twego imienia, modlić się do Ciebie i błagać w tej świątyni,***
###### **1Krl 8,34**
 ***wtedy Ty wysłuchaj w niebiosach i przebacz grzech Twego ludu, Izraela, i przyprowadź ich z powrotem do kraju, który dałeś ich przodkom.***
###### **1Krl 8,35**
 ***Kiedy niebo zostanie zamknięte i nie będzie deszczu, dlatego że zgrzeszyli przeciw Tobie, ale potem będą się modlić na tym miejscu i sławić Twe imię oraz odwrócą się od swoich grzechów, bo ich upokorzyłeś,***
###### **1Krl 8,36**
 ***wtedy Ty wysłuchaj w niebiosach i przebacz grzech Twoich sług i Twego ludu, Izraela. Ty wskażesz im dobrą drogę, którą iść mają, i ześlesz deszcz na Twoją ziemię, którą dałeś Twemu ludowi jako dziedzictwo.***
###### **1Krl 8,37**
 ***Gdy w kraju będzie głód lub zaraza, gdy będą: spiekota, śnieć, szarańcza lub liszki, gdy wróg jego natrze na jedną z jego bram, jakakolwiek by była klęska lub jakakolwiek choroba –***
###### **1Krl 8,38**
 ***wszelką modlitwę, każde błaganie poszczególnego człowieka czy też całego Twego ludu, Izraela, skoro przejęty klęską wyciągnie ręce ku tej świątyni,***
###### **1Krl 8,39**
 ***Ty usłysz w niebie, miejscu Twego przebywania. Racz przebaczyć i działać. Oddaj każdemu według jego postępowania, bo Ty znasz jego serce, bo jedynie Ty znasz serce każdego człowieka.***
###### **1Krl 8,40**
 ***Niech zachowują bojaźń wobec Ciebie po wszystkie dni swego życia na powierzchni ziemi, którą dałeś naszym przodkom.***
###### **1Krl 8,41**
 ***Również i cudzoziemca, który nie jest z Twego ludu, Izraela, a jednak przyjdzie z dalekiego kraju przez wzgląd na Twe imię –***
###### **1Krl 8,42**
 ***bo będzie słychać o Twoim wielkim imieniu i o Twej mocnej ręce, i wyciągniętym ramieniu – gdy przyjdzie i będzie się modlić w tej świątyni,***
###### **1Krl 8,43**
 ***Ty w niebie, miejscu Twego przebywania, wysłuchaj i uczyń to wszystko, o co ten cudzoziemiec będzie do Ciebie wołać. Niech wszystkie narody ziemi poznają Twe imię, by przejąć się bojaźnią wobec Ciebie za przykładem Twego ludu, Izraela. Niech też wiedzą, że Twoje imię zostało wezwane nad tą świątynią, którą zbudowałem.***
###### **1Krl 8,44**
 ***Kiedy Twój lud wyruszy do walki z nieprzyjacielem swoim w drogę, którą go poślesz, i będzie się modlić do Ciebie, [zwracając się] ku wybranemu przez Ciebie miastu i domowi, który zbudowałem dla Twego imienia,***
###### **1Krl 8,45**
 ***wówczas wysłuchaj w niebie ich modlitwę oraz błaganie i wymierz im sprawiedliwość.***
###### **1Krl 8,46**
 ***Jeśliby grzeszyli przeciw Tobie – bo nie ma człowieka, który by nie grzeszył – a Ty za to będziesz na nich zagniewany i dlatego oddasz ich w moc wroga, wskutek czego zaborcy uprowadzą ich do ziemi nieprzyjaciół, dalekiej czy bliskiej,***
###### **1Krl 8,47**
 ***oni zaś w kraju, do którego zostaną uprowadzeni, będą żałować, nawrócą się w kraju zaborców i będą Cię błagać o litość, wołając: Zgrzeszyliśmy, zbłądziliśmy, bezbożnie postąpiliśmy;***
###### **1Krl 8,48**
 ***jeśli więc nawrócą się do Ciebie z całego serca, z całej duszy w kraju ich wrogów, którzy ich uprowadzili, i będą się modlić do Ciebie, zwracając się ku krajowi, który dałeś ich przodkom, i ku miastu, które wybrałeś, i ku domowi, który zbudowałem dla Twego imienia,***
###### **1Krl 8,49**
 ***to wtedy racz wysłuchać w niebie, miejscu Twego przebywania, ich modlitwę oraz błagania i wymierz im sprawiedliwość.***
###### **1Krl 8,50**
 ***Przebacz łaskawie ludowi Twojemu to, w czym zgrzeszył przeciw Tobie, oraz wszystkie jego występki, przez które odstąpił od Ciebie, i skłoń ich zaborców do miłosierdzia, aby zmiłowali się [nad nimi].***
###### **1Krl 8,51**
 ***Wszak Twoim ludem i Twoim dziedzictwem są ci, których wyprowadziłeś z Egiptu, ze środka tego pieca do wytopu żelaza.***
###### **1Krl 8,52**
 ***Niech Twoje oczy będą otwarte na błaganie Twego sługi i błaganie Twego ludu, Izraela, byś ich wysłuchał, ilekroć będą wołać do Ciebie.***
###### **1Krl 8,53**
 ***Wszak Ty wybrałeś sobie ich ze wszystkich ludów świata na dziedzictwo, jak powiedziałeś, o Panie Boże, przez Twego sługę, Mojżesza, kiedy wyprowadziłeś naszych przodków z Egiptu***».
###### **1Krl 8,54**
 Potem, kiedy Salomon skończył zanosić do Pana te wszystkie modły i błagania, podniósł się sprzed ołtarza Pańskiego, z miejsca, gdzie klęczał i ręce wyciągał do nieba,
###### **1Krl 8,55**
 i stanąwszy, błogosławił całe zgromadzenie izraelskie, wołając donośnym głosem:
###### **1Krl 8,56**
 «***Niech będzie błogosławiony Pan, który dał pokój swemu ludowi, Izraelowi, zgodnie z tym wszystkim, co zapowiedział; za to, że nie uchybił ani jednemu wypowiedzianemu słowu z wszelkiej obietnicy pomyślności, danej przez swego sługę, Mojżesza.***
###### **1Krl 8,57**
 ***Niech będzie z nami Pan, nasz Bóg, jak był z naszymi przodkami! Niech nas nie opuszcza i nie odrzuca nas,***
###### **1Krl 8,58**
 ***ale nakłoni do siebie nasze serca, abyśmy chodzili Jego drogami, przestrzegając Jego poleceń, praw i nakazów, do których zobowiązał naszych przodków.***
###### **1Krl 8,59**
 ***Niech te moje słowa, w których błagałem Pana o zmiłowanie, docierają do Pana, Boga naszego, czy to w dzień, czy to w nocy, aby wymierzał sprawiedliwość swemu słudze i swemu ludowi, Izraelowi, według potrzeby każdego dnia.***
###### **1Krl 8,60**
 ***Niech wszystkie ludy świata dowiedzą się, że jedynie Pan jest Bogiem, a innego nie ma.***
###### **1Krl 8,61**
 ***Niech więc serce wasze będzie szczere wobec Pana, Boga naszego, abyście postępowali według Jego praw i przestrzegali Jego nakazów, jak to jest w dniu dzisiejszym***».
###### **1Krl 8,62**
 Następnie król, a z nim cały Izrael składali ofiary przed Panem.
###### **1Krl 8,63**
 Wtedy Salomon złożył ofiarę biesiadną, w której ofiarował ku czci Pana dwadzieścia dwa tysiące wołów i sto dwadzieścia tysięcy owiec. Tym samym król i wszyscy Izraelici poświęcili dom Panu.
###### **1Krl 8,64**
 Tegoż dnia król poświęcił środkową część dziedzińca przed domem Pańskim, bo dokonał tam ofiary całopalnej, ofiary pokarmowej i z tłuszczu ofiar biesiadnych, gdyż ołtarz z brązu, który był przed Panem, okazał się za mały, by pomieścić ofiary całopalne oraz ofiary pokarmowe i z tłuszczu ofiar biesiadnych.
###### **1Krl 8,65**
 Wtedy Salomon, a z nim wielkie zgromadzenie całego Izraela od Wejścia do Chamat aż do Potoku Egipskiego, obchodził uroczyste święto przed Panem, Bogiem naszym, przez siedem < i siedem dni, to jest czternaście dni >.
###### **1Krl 8,66**
 Dnia zaś ósmego odprawił lud, który błogosławiąc królowi, rozszedł się do swoich namiotów radosny i z wdzięcznym sercem za te wszystkie dobrodziejstwa, które Pan wyświadczył swemu słudze, Dawidowi, oraz swemu ludowi, Izraelowi.
# 1Krl 8 PAU
###### **1Krl 8,1**
 Wtedy Salomon wezwał do Jerozolimy starszych Izraela, wszystkich przywódców plemion i głowy rodzin izraelskich, aby razem z królem Salomonem uczestniczyli w przeniesieniu Arki Przymierza PANA z Miasta Dawida, to jest z Syjonu.
###### **1Krl 8,2**
 W miesiącu Etanim, w siódmym miesiącu roku, zgromadzili się wszyscy Izraelici u króla Salomona, aby razem z nim obchodzić święto.
###### **1Krl 8,3**
 Kiedy przybyli wszyscy starsi Izraela, kapłani wzięli arkę
###### **1Krl 8,4**
 i razem z lewitami przenieśli zarówno arkę PANA, jak i Namiot Spotkania oraz wszystkie święte przedmioty, znajdujące się w Namiocie.
###### **1Krl 8,5**
 Król Salomon wraz z całą wspólnotą Izraela, zgromadzoną wokół niego przed arką, składał w ofierze owce i woły, których w ogóle nie liczono z powodu ogromnej ich liczby.
###### **1Krl 8,6**
 Następnie kapłani wnieśli Arkę Przymierza PANA na przygotowane dla niej miejsce w najbardziej wewnętrznej części domu, to jest w miejscu najświętszym, pod skrzydła cherubów.
###### **1Krl 8,7**
 Cheruby bowiem miały skrzydła rozpostarte nad miejscem, gdzie postawiono arkę, tak iż okrywały z góry arkę i drążki do jej przenoszenia.
###### **1Krl 8,8**
 Same drążki były tak długie, że można było zobaczyć ich końce z miejsca świętego tuż przed miejscem najświętszym, ale z zewnątrz nie były widoczne. Są tam one aż do dnia dzisiejszego.
###### **1Krl 8,9**
 W arce nie było nic, prócz dwóch tablic kamiennych, które Mojżesz włożył do niej na Horebie, gdzie PAN zawarł z Izraelitami przymierze po ich wyjściu z ziemi egipskiej.
###### **1Krl 8,10**
 Skoro tylko kapłani wyszli z miejsca świętego, obłok wypełnił dom PANA.
###### **1Krl 8,11**
 Kapłani nie mogli więc dalej spełniać swojej posługi, gdyż chwała PANA napełniła dom PANA.
###### **1Krl 8,12**
 Wtedy Salomon przemówił: „PANIE, powiedziałeś, że będziesz mieszkał w ciemnym obłoku.
###### **1Krl 8,13**
 Oto wzniosłem dla Ciebie wspaniały dom, miejsce, gdzie możesz zamieszkać na zawsze”.
###### **1Krl 8,14**
 Całe zgromadzenie Izraela stało w oczekiwaniu, gdy król zwrócił się w ich kierunku z uroczystym błogosławieństwem:
###### **1Krl 8,15**
 „Błogosławiony PAN, Bóg Izraela, który wypełnił to, co przyrzekł mojemu ojcu, Dawidowi, mówiąc:
###### **1Krl 8,16**
 «Od dnia, w którym wyprowadziłem mój lud, Izraela, z Egiptu, nie wybrałem sobie żadnego miasta spośród wszystkich plemion Izraela, aby wybudować w nim dom dla mojego imienia. Wybrałem dopiero Dawida, aby postawić go nad moim ludem Izraelem».
###### **1Krl 8,17**
 To właśnie w sercu mojego ojca, Dawida, zrodziła się myśl, aby wybudować dom dla imienia PANA, Boga Izraela.
###### **1Krl 8,18**
 Lecz PAN mu powiedział: «Postanowienie, które zrodziło się w twoim sercu, aby wybudować dom ku czci mojego imienia, jest dobre.
###### **1Krl 8,19**
 Nie ty go jednak zbudujesz, ale twój syn, który się tobie urodzi. On zbuduje dom dla mojego imienia».
###### **1Krl 8,20**
 PAN spełnił więc swoją obietnicę: oto stałem się następcą mojego ojca, Dawida, zasiadając na tronie Izraela, jak PAN zapowiedział, i wybudowałem dom dla imienia PANA, Boga Izraela.
###### **1Krl 8,21**
 Urządziłem w nim również miejsce dla arki. W niej znajduje się Przymierze PANA, które zawarł z naszymi przodkami, gdy wyprowadził ich z ziemi egipskiej”.
###### **1Krl 8,22**
 Salomon stanął przed ołtarzem PANA na czele całego zgromadzenia Izraela i wzniósł ręce ku niebu,
###### **1Krl 8,23**
 mówiąc: „O PANIE, Boże Izraela, nie ma boga równego Tobie ani u góry w niebie, ani w dole na ziemi. Ty jesteś wierny przymierzu i okazujesz dobroć swoim sługom, którzy służą Ci z całego serca.
###### **1Krl 8,24**
 Dotrzymałeś słowa twemu słudze Dawidowi, memu ojcu, i dzisiaj wypełniłeś swoje przyrzeczenie.
###### **1Krl 8,25**
 PANIE, Boże Izraela, dotrzymaj teraz obietnicy, którą dałeś twojemu słudze, a mojemu ojcu, Dawidowi, mówiąc: «Jeśli twoi potomkowie będą usilnie starali się służyć Mi, tak jak ty Mi służysz, nie zabraknie ci następcy, który będzie stał przed moim obliczem i zasiadał na tronie izraelskim».
###### **1Krl 8,26**
 Boże Izraela, niech teraz Twoje słowo, które dałeś Twemu słudze, mojemu ojcu, Dawidowi, okaże się niezawodne.
###### **1Krl 8,27**
 Czy jednak naprawdę Bóg zamieszka na ziemi? Przecież niebo nieogarnione nie może Ciebie objąć, a cóż dopiero ten dom, który zbudowałem.
###### **1Krl 8,28**
 Usłysz moją modlitwę i błaganie, o PANIE, mój Boże, wysłuchaj wołania i modlitwy, które Twój sługa zanosi dzisiaj do Ciebie.
###### **1Krl 8,29**
 Niech Twoje oczy będą zwrócone w nocy i w dzień ku temu domowi. Przyrzekłeś bowiem: «W tym miejscu będzie obecne moje imię». Wysłuchaj więc modlitwy, którą Twój sługa wznosi w tym miejscu.
###### **1Krl 8,30**
 Wysłuchaj błagania Twojego sługi i Twego ludu, Izraela. Ilekroć będą modlić się w tym miejscu, Ty wysłuchaj ich w miejscu, gdzie przebywasz - w niebie. A kiedy wysłuchasz, przebacz.
###### **1Krl 8,31**
 Jeśli ktoś zgrzeszy przeciw swojemu bliźniemu i zostanie zobowiązany do złożenia przysięgi ze złorzeczeniem wobec Twego ołtarza w tym domu,
###### **1Krl 8,32**
 Ty usłysz w niebie, działaj i osądź swoje sługi. Winnemu wymierz karę, niech poniesie skutki swojego postępowania, niewinnego zaś uwolnij od zarzutów, stwierdzając jego niewinność.
###### **1Krl 8,33**
 Jeśli Twój lud, Izrael, po klęsce zadanej mu przez wroga za to, że zgrzeszył przeciwko Tobie, powróci do Ciebie, odda cześć Twojemu imieniu, będzie modlił się i zanosił prośby do Ciebie w tym domu,
###### **1Krl 8,34**
 Ty wysłuchaj z nieba i przebacz grzech Twojego ludu, Izraela. Pozwól im wrócić do kraju, który dałeś ich przodkom.
###### **1Krl 8,35**
 Kiedy niebo będzie zamknięte i nie będzie deszczu, ponieważ zgrzeszyli przeciwko Tobie, potem jednak będą modlić się do Ciebie w tym miejscu, oddadzą cześć Twojemu imieniu i odwrócą się od swojego grzechu, bo dotkniesz ich nieszczęściem,
###### **1Krl 8,36**
 Ty wysłuchaj z nieba i przebacz grzech Twoich sług i Twego ludu, Izraela. Wskażesz im właściwą drogę postępowania i ześlesz deszcz na ziemię, którą dałeś Twojemu ludowi na własność.
###### **1Krl 8,37**
 Kiedy kraj zostanie dotknięty głodem lub zarazą, suszą albo rdzą zbożową, plagą szarańczy lub robactwa, kiedy z którejkolwiek strony uderzy na niego nieprzyjaciel albo porazi go jakieś nieszczęście lub choroba,
###### **1Krl 8,38**
 wszystkie modlitwy i błagania zanoszone przez każdego z osobna i przez cały Twój lud izraelski, który przejęty nieszczęściem i karą wyciągać będzie ręce ku temu domowi,
###### **1Krl 8,39**
 Ty usłysz w niebie, w miejscu Twojego przebywania. Przebacz, działaj, uczyń każdemu według jego postępowania, znasz bowiem jego serce. Tylko Ty przenikasz serce człowieka.
###### **1Krl 8,40**
 Wtedy przez cały czas swojego pobytu na ziemi, którą dałeś naszym przodkom, będą żyli w bojaźni przed Tobą.
###### **1Krl 8,41**
 Również cudzoziemca, który nie należy do Twojego ludu, Izraela, a który przybędzie z dalekiego kraju ze względu na Twoje imię -
###### **1Krl 8,42**
 gdyż wielu usłyszy o Twoim wielkim imieniu, a także o Twojej mocnej ręce i wzniesionym ramieniu - gdy więc przyjdzie, aby się modlić w tym domu,
###### **1Krl 8,43**
 Ty usłysz w niebie, w miejscu Twojego przebywania. Spełnij to, o co ten cudzoziemiec będzie Cię prosił. Niech wszystkie ludy ziemi poznają Twoje imię i niech postępują w bojaźni przed Tobą na wzór Twego ludu, Izraela. Niech się dowiedzą, że ten dom, który zbudowałem, nosi Twoje imię.
###### **1Krl 8,44**
 Jeśli Twój lud, zgodnie z Twoim wskazaniem, wyruszy, aby walczyć z nieprzyjaciółmi, i w drodze będzie modlił się do PANA, zwracając się ku miastu, które wybrałeś, i ku domowi, który zbudowałem dla Twego imienia,
###### **1Krl 8,45**
 wtedy wysłuchaj z nieba jego modlitwę i błaganie i bądź obrońcą jego sprawy.
###### **1Krl 8,46**
 Jeśli zgrzeszą przeciwko Tobie, gdyż nikt nie jest wolny od grzechu, a Ty rozgniewasz się na nich i wydasz ich w ręce nieprzyjaciół, którzy wezmą ich w niewolę i przesiedlą do swojej ziemi, dalekiej lub bliskiej,
###### **1Krl 8,47**
 oni zaś okażą szczerą skruchę w ziemi, do której zostali uprowadzeni, i będą Cię błagać o zmiłowanie w ziemi swoich zaborców, wyznając: «Zgrzeszyliśmy, zawiniliśmy, popełniliśmy nieprawość»,
###### **1Krl 8,48**
 jeśli więc nawrócą się do Ciebie całym swoim sercem i całą swoją duszą w ziemi, do której zostali uprowadzeni przez swoich wrogów, i będą się modlić do Ciebie, zwracając się ku ziemi, którą dałeś ich przodkom, ku miastu, które wybrałeś, i ku domowi, który wybudowałem ku czci Twojego imienia,
###### **1Krl 8,49**
 wtedy wysłuchaj z nieba, z miejsca Twego przebywania ich modlitwę i błaganie i okaż im sprawiedliwość.
###### **1Krl 8,50**
 Przebacz swojemu ludowi, który zgrzeszył przeciwko Tobie, odpuść wszystkie jego wykroczenia i porusz serca ich zaborców, aby okazali im miłosierdzie.
###### **1Krl 8,51**
 Gdyż oni właśnie są Twoim ludem i dziedzictwem, które wyprowadziłeś z Egiptu, z wnętrza pieca do wytapiania żelaza.
###### **1Krl 8,52**
 Wejrzyj łaskawie na błaganie Twojego sługi i Twojego ludu, Izraela, i wysłuchaj ich, ilekroć wołać będą do Ciebie.
###### **1Krl 8,53**
 Panie, Boże, Ty sam przecież wybrałeś ich sobie na własność spośród wszystkich ludów ziemi zgodnie z tym, co obiecałeś przez Mojżesza, Twego sługę, gdy wyprowadziłeś naszych przodków z Egiptu”.
###### **1Krl 8,54**
 Kiedy Salomon zakończył wszystkie te modlitwy i błagania, wznoszone do PANA, podniósł się z klęczek przed ołtarzem PANA, gdzie wyciągał ręce ku niebu,
###### **1Krl 8,55**
 i w uroczystym tonie zaczął błogosławić całe zgromadzenie Izraela:
###### **1Krl 8,56**
 „Błogosławiony niech będzie PAN, który obdarzył swój lud, Izraela, miejscem odpoczynku, wypełniając swoją obietnicę. Nie zawiodło żadne z dobrych słów, które PAN powiedział przez Mojżesza, swojego sługę.
###### **1Krl 8,57**
 Niech PAN, Bóg nasz, będzie z nami, jak był z naszymi przodkami. Niech nas nie opuszcza i nie odrzuca.
###### **1Krl 8,58**
 Niech wzbudzi w nas miłość do siebie, abyśmy szli drogą wskazaną przez Niego, przestrzegając Jego przykazań, praw i wyroków, do których zobowiązał naszych przodków.
###### **1Krl 8,59**
 Niech prośby zanoszone w moim błaganiu znajdą przychylność u PANA, Boga naszego we dnie i w nocy. Niech PAN będzie obrońcą spraw swojego sługi i ludu swojego, Izraela, w potrzebach każdego dnia,
###### **1Krl 8,60**
 aby wszystkie ludy ziemi poznały, że tylko Pan jest Bogiem, a żaden inny nie istnieje.
###### **1Krl 8,61**
 Niech więc wasze serca będą całkowicie oddane PANU, Bogu naszemu, tak jak dzisiaj, abyście postępowali według Jego poleceń i zachowywali Jego przykazania”.
###### **1Krl 8,62**
 Następnie król wraz z całym Izraelem składali ofiary PANU.
###### **1Krl 8,63**
 Salomon złożył więc dla PANA dwadzieścia dwa tysiące wołów i sto dwadzieścia tysięcy owiec na ofiarę wspólnotową. Tak król i wszyscy Izraelici dokonali poświęcenia domu PANA.
###### **1Krl 8,64**
 W tym samym dniu król poświęcił także środkową część dziedzińca przed domem PANA, gdyż tam właśnie złożono ofiary całopalne, ofiary pokarmowe i tłuszcz ofiar wspólnotowych, ponieważ ołtarz z brązu, stojący przed PANEM, okazał się za mały, aby pomieścić ofiary całopalne, ofiary pokarmowe oraz tłuszcz ofiar wspólnotowych.
###### **1Krl 8,65**
 Tak więc Salomon wraz z całym Izraelem, tworzącym wielkie zgromadzenie pielgrzymów przybyłych z całego kraju od Lebo-Chamat aż do Potoku Egipskiego, obchodził przez siedem dni uroczyste święto przed PANEM, Bogiem naszym.
###### **1Krl 8,66**
 Ósmego dnia rozesłał lud, który błogosławił króla. Wszyscy wracali do swoich domów szczęśliwi i pełni wdzięczności za wszelkie dobro, które PAN okazał swojemu słudze, Dawidowi, i swojemu ludowi, Izraelowi.
# 1Krl 8 BP
###### **1Krl 8,1**
 Wówczas zgromadził Salomon starszyznę Izraela, wszystkich naczelników pokoleń i książąt rodowych synów Izraela przy sobie, w Jerozolimie, aby przenieść Arkę Przymierza z Miasta Dawidowego, którym jest Syjon.
###### **1Krl 8,2**
 Zebrali się więc u króla Salomona wszyscy mężowie izraelscy w miesiącu Etanim - był to miesiąc siódmy - w uroczyste święto.
###### **1Krl 8,3**
 [Gdy] przybyła cała starszyzna Izraela, kapłani wzięli Arkę
###### **1Krl 8,4**
 i przenieśli Arkę Jahwe i Namiot Spotkania oraz wszystkie naczynia święte, które znajdowały się w Namiocie. Przenieśli je kapłani i lewici.
###### **1Krl 8,5**
 Król Salomon i cała wspólnota Izraela zebrana wokół niego [stanęła razem] z nim przed Arką, składając na ofiarę owce i woły w tak wielkiej liczbie, że nie dało się ich ani policzyć, ani spisać.
###### **1Krl 8,6**
 Kapłani wnieśli Arkę Przymierza Jahwe na jej miejsce do Debir Świątyni, do miejsca Świętego Świętych pod skrzydła cherubów.
###### **1Krl 8,7**
 Albowiem cheruby rozpościerały skrzydła nad miejscem Arki i osłaniały od góry Arkę i jej drążki.
###### **1Krl 8,8**
 Drążki byty takie długie, że ich końce można było widzieć z miejsca Świętego przed miejscem Najświętszym, ale nie były widoczne na zewnątrz [miejsca Najświętszego]. I są tam aż do tego dnia.
###### **1Krl 8,9**
 W Arce nie było nic z wyjątkiem dwu tablic kamiennych, które złożył tam Mojżesz na Chorebie, gdy Jahwe zawarł [Przymierze] z synami Izraela po ich wyjściu z ziemi egipskiej.
###### **1Krl 8,10**
 I stało się, gdy kapłani wyszli z miejsca Świętego, że obłok napełnił Świątynię Jahwe.
###### **1Krl 8,11**
 I nie mogli kapłani spełniać [swych] obrzędów z powodu obłoku, bo Chwała Jahwe napełniła Świątynię Pańską.
###### **1Krl 8,12**
 Wtedy przemówił Salomon: Powiedział Jahwe, że mieszka w chmurze
###### **1Krl 8,13**
 Rzeczywiście więc zbudowałem dom królewski dla Ciebie, miejsce Twego mieszkania na wieki.
###### **1Krl 8,14**
 Potem król się odwrócił, błogosławił całemu zgromadzeniu Izraela, a całe zgromadzenie Izraela stało,
###### **1Krl 8,15**
 i przemówił: Niech będzie błogosławiony Jahwe, Bóg Izraela, który ustami swymi tak powiedział Dawidowi, ojcu mojemu, i ręką swą [tego] dopełnił:
###### **1Krl 8,16**
 "Od dnia, w którym wyprowadziłem lud mój izraelski z Egiptu, nie wybrałem sobie żadnego miasta spośród wszystkich pokoleń izraelskich, aby tam zbudowano Świątynię, w której przebywałoby Imię moje, ale wybrałem sobie Dawida, aby stanął na czele mojego ludu izraelskiego".
###### **1Krl 8,17**
 Ojciec mój, Dawid, powziął myśl, aby zbudować Świątynię dla Imienia Jahwe, Boga Izraela.
###### **1Krl 8,18**
 Ale Jahwe rzekł do Dawida, ojca mego: "Skoro powziąłeś zamiar zbudowania Świątyni Imieniu mojemu, dobrze się stało, że taka myśl powstała w sercu twoim.
###### **1Krl 8,19**
 Nie ty wszakże będziesz budował Świątynię, ale syn twój, ten, który wyjdzie z biódr twoich, on zbuduje Świątynię Imieniu mojemu".
###### **1Krl 8,20**
 Dotrzymał więc Jahwe swego słowa, które wypowiedział. Zostałem następcą Dawida, mojego ojca, i zasiadłem na tronie izraelskim, jak to zapowiedział Jahwe, i zbudowałem Świątynię dla Imienia Jahwe, Boga Izraela.
###### **1Krl 8,21**
 Przygotowałem tam miejsce dla Arki, bo tam się znajduje Przymierze Jahwe, które zawarł z ojcami naszymi, gdy wyprowadził ich z ziemi egipskiej.
###### **1Krl 8,22**
 Salomon stanął przed ołtarzem Jahwe wobec całego zgromadzenia Izraela, wzniósł dłonie swe ku niebu
###### **1Krl 8,23**
 i modlił się: Jahwe, Boże Izraela, w górze na niebie i w dole na ziemi nie ma takiego jak Ty Boga, który przestrzega Przymierza i łaskawości względem sług swoich, całym swym sercem idących za Tobą,
###### **1Krl 8,24**
 który dotrzymałeś Twojemu słudze Dawidowi, mojemu ojcu, tego, co mu przyrzekłeś. Wypowiedziałeś [obietnicę] ustami Twymi i wypełniłeś [ją] rękoma Twoimi właśnie dzisiaj.
###### **1Krl 8,25**
 Teraz zatem, Jahwe, Boże Izraela, wypełnij względem sługi Twego Dawida, mojego ojca, to, co mu przyrzekłeś mówiąc: "Nie zabraknie ci wobec mnie potomka zasiadającego na tronie izraelskim, jeśli tylko synowie twoi będą strzec dróg swoich, postępując wobec mnie tak, jak ty wobec mnie postępowałeś."
###### **1Krl 8,26**
 Boże Izraela, niech się więc teraz spełnią Twoje słowa, które wyrzekłeś do sługi Twojego Dawida, ojca mojego.
###### **1Krl 8,27**
 Czy rzeczywiście Bóg zamieszka na ziemi? Oto niebo i niebiosa niebios nie mogą Cię ogarnąć, a cóż dopiero ta [oto] Świątynia, którą zbudowałem.
###### **1Krl 8,28**
 Wejrzyj na modlitwę Twojego sługi i na jego prośbę, Jahwe, Boże mój. Wysłuchaj błagania i modlitwy, którą sługa Twój zanosi dzisiaj przed Twoje oblicze.
###### **1Krl 8,29**
 Niech oczy Twoje we dnie i w nocy spoglądają na tę Świątynię, na miejsce, o którym mówiłeś: "Tam będzie Imię moje". Wysłuchaj modlitwy, którą na tym [właśnie] miejscu zanosi Twój sługa.
###### **1Krl 8,30**
 Wysłuchaj błagania sługi Twego i ludu Twojego izraelskiego. Gdy będą się modlić na tym miejscu, Ty wysłuchaj z miejsca, gdzie przebywasz - z nieba. Wysłuchaj i udziel przebaczenia.
###### **1Krl 8,31**
 Gdy ktoś zawini przeciw bliźniemu swemu, a ten zobowiąże go do przysięgi złorzeczącej, aby przysiągł, [że jest niewinny], i on przyjdzie [złożyć tę] przysięgę złorzeczącą przed Twoim ołtarzem w tej Świątyni,
###### **1Krl 8,32**
 Ty wysłuchaj w niebie, racz działać i osądź sługi Twoje. Złemu wymierz karę, składając jego postępowanie na jego głowę, a uznaj niewinnym sprawiedliwego, płacąc mu według jego uczciwości.
###### **1Krl 8,33**
 Gdy nieprzyjaciel zada klęskę Twojemu ludowi izraelskiemu za to, że zgrzeszyli przeciw Tobie, i nawrócą się do Ciebie, będą wysławiać Twoje Imię, będą się modlić i będą Cię błagać w tej Świątyni,
###### **1Krl 8,34**
 Ty wysłuchaj w niebie, przebacz grzech Twego ludu izraelskiego i przyprowadź ich znów do ziemi, którą dałeś ich ojcom.
###### **1Krl 8,35**
 Gdy zamknie się niebo i nie będzie deszczu, bo zgrzeszyli przeciw Tobie, ale będą się modlić na tym miejscu, będą wysławiać Twoje Imię i odwrócą się od grzechów swoich, dlatego bo ich upokorzyłeś.
###### **1Krl 8,36**
 Ty wysłuchaj w niebie i przebacz grzech sług Twoich i Twojego ludu izraelskiego, ukaż im dobrą drogę, po której winni kroczyć, i spuść deszcz na Twój kraj, który dałeś Twojemu ludowi w dziedzictwo.
###### **1Krl 8,37**
 Gdy kraj nawiedzi głód i zaraza, gdy pojawi się rdza i śnieć [zbożowa], szarańcza i skrzydlate szkodniki, gdy zdarzy się, że jego nieprzyjaciel oblegnie któreś z jego miast, [gdy spadnie] jakakolwiek plaga lub choroba,
###### **1Krl 8,38**
 wszelką modlitwę, każde błaganie, jakie zaniesie bądź poszczególny człowiek, bądź cały lud twój izraelski, ktokolwiek przejęty udręką serca swojego wzniesie swe dłonie ku tej Świątyni,
###### **1Krl 8,39**
 Ty wysłuchaj w niebie, z miejsca, gdzie przebywasz, przebacz, spełnij [prośbę] i każdemu oddaj według wszystkich jego uczynków, bo Ty znasz jego serce, albowiem Ty jedynie znasz serce każdego z synów człowieczych,
###### **1Krl 8,40**
 aby po wszystkie dni bali się Ciebie ci, co żyją na ziemi, którą dałeś ojcom naszym.
###### **1Krl 8,41**
 Także i obcokrajowca, tego, który nie należy do Twego ludu izraelskiego, [gdy] przybędzie z dalekiej krainy przez wzgląd na Twe Imię -
###### **1Krl 8,42**
 bo [ludzie] słyszą o Twoim wielkim Imieniu, o mocnej Twojej ręce, o Twym wyciągniętym ramieniu - [skoro więc] przyjdzie i będzie się modlił w tej Świątyni,
###### **1Krl 8,43**
 Ty wysłuchaj w niebie, z miejsca Twego przebywania, zechciej wypełnić wszystko, o co Cię będzie prosił [ów] cudzoziemiec, aby wszystkie ludy ziemi poznały Twe Imię, aby się bały Ciebie tak, jak Twój lud izraelski, i aby wiedziały, że Imię Twoje jest nadane tej Świątyni, którą zbudowałem.
###### **1Krl 8,44**
 Kiedy lud Twój wyruszy na wojnę przeciw swojemu wrogowi drogą, którą ich poślesz, i będą się modlić do Jahwe [zwróceni] w kierunku Miasta, które sobie obrałeś, i Świątyni, którą zbudowałem Imieniu Twojemu,
###### **1Krl 8,45**
 wysłuchaj w niebie ich modlitwy i ich błagania i oddaj im sprawiedliwość.
###### **1Krl 8,46**
 Gdy [synowie Izraela] zgrzeszą przeciw Tobie - bo nie ma człowieka, który by nie zgrzeszył - i rozgniewawszy się na nich wydasz ich nieprzyjacielowi, ich zwycięzcy zaś uprowadzą ich [w niewolę] do ziemi nieprzyjacielskiej, dalekiej lub bliskiej,
###### **1Krl 8,47**
 i jeśli w kraju, dokąd ich uprowadzono, opamiętają się, nawrócą i w kraju swych ciemięzców będą Cię błagać, wołając: "Zgrzeszyliśmy, postępowaliśmy przewrotnie, zawiniliśmy",
###### **1Krl 8,48**
 i nawrócą się do Ciebie całym swym sercem, całą duszą swoją w ziemi swych nieprzyjaciół, dokąd ich uprowadzono, i będą się modlić do Ciebie [zwróceni] w stronę swego kraju, który dałeś ich ojcom, w stronę Miasta, które obrałeś, i Świątyni, którą zbudowałem Imieniu Twojemu,
###### **1Krl 8,49**
 wtedy wysłuchaj w niebie, z miejsca Twojego przebywania, ich modlitwy i ich błagania i oddaj im sprawiedliwość.
###### **1Krl 8,50**
 Przebacz ludowi Twojemu, który zgrzeszył [przeciw] Tobie, wszystkie ich przewinienia, którymi Cię obrazili, i spraw, by znaleźli miłosierdzie w oczach swych ciemięzców, [aby] byli im litościwi,
###### **1Krl 8,51**
 bo są Twoim ludem i Twoim dziedzictwem. To są ci, których wywiodłeś z Egiptu, spośród pieca, [w którym wytapia się] żelazo.
###### **1Krl 8,52**
 Oby Twoje oczy były otwarte na błaganie sługi Twojego i na błaganie Twojego ludu izraelskiego, abyś ich wysłuchał we wszystkim, o co będą wołać do Ciebie.
###### **1Krl 8,53**
 Ty bowiem wybrałeś ich sobie na dziedzictwo ze wszystkich ludów ziemi, jak to powiedziałeś za pośrednictwem Mojżesza, Twojego sługi, gdy wywiodłeś naszych ojców z Egiptu, Panie mój, Jahwe.
###### **1Krl 8,54**
 Gdy Salomon skończył zanosić do Jahwe całą tę modlitwę i to błaganie, powstał z miejsca, gdzie klęczał przed ołtarzem Jahwe z rękami wzniesionymi ku niebu.
###### **1Krl 8,55**
 Stanął i błogosławił całe zgromadzenie Izraela, mówiąc doniosłym głosem:
###### **1Krl 8,56**
 Niech będzie błogosławiony Jahwe, który zapewnił pokój swojemu ludowi izraelskiemu zgodnie z tym wszystkim, co powiedział, i nie uronił jednego słowa z całej swojej wspaniałej obietnicy, którą ogłosił za pośrednictwem Mojżesza, swojego sługi.
###### **1Krl 8,57**
 Niech Jahwe, Bóg nasz, będzie z nami, jak był z naszymi ojcami. Niech nas nie opuszcza i niech nas nie odrzuca.
###### **1Krl 8,58**
 Niech nakłoni ku sobie serca nasze, abyśmy postępowali wszystkimi Jego drogami oraz zachowywali Jego nakazy, Jego przepisy i Jego zarządzenia, które polecił ojcom naszym.
###### **1Krl 8,59**
 Niech te moje słowa, którymi wyraziłem moje błaganie przed obliczem Jahwe, we dnie i w nocy będą w pobliżu Jahwe, Boga naszego, aby oddał sprawiedliwość swojemu słudze i sprawiedliwość swojemu ludowi izraelskiemu według potrzeby na każdy dzień,
###### **1Krl 8,60**
 ażeby wszystkie ludy ziemi poznały, że Jahwe jest Bogiem i nie ma innego [poza] Nim.
###### **1Krl 8,61**
 Niech serca wasze będą szczerze oddane Jahwe, Bogu naszemu, idąc za Jego przepisami i strzegąc Jego nakazów tak, jak dzisiaj.
###### **1Krl 8,62**
 Król Salomon a z nim cały Izrael złożyli krwawą ofiarę przed Jahwe.
###### **1Krl 8,63**
 Salomon zabił [na] ofiarę dziękczynną, którą złożył dla Jahwe, dwadzieścia dwa tysiące wołów i sto dwadzieścia tysięcy owiec. [W ten sposób] król i wszyscy synowie Izraela poświęcili Świątynię Jahwe.
###### **1Krl 8,64**
 W tym dniu król poświęcił wnętrze dziedzińca, który znajdował się przed Świątynią Jahwe, ponieważ złożył tam całopalenie, ofiarę z pokarmów i tłuszcz ofiary dziękczynnej, albowiem ołtarz z brązu, który znajdował się przed [Świątynią] Jahwe, okazał się za mały, aby pomieścić całopalenie, pokarmy i tłuszcz ofiary dziękczynnej.
###### **1Krl 8,65**
 W tym czasie Salomon obchodził uroczyste święto. Wraz z nim cały Izrael, wielkie zgromadzenie [ludzi przybyłych z kraju] od wejścia do Chamat aż do Potoku Egipskiego, [obchodzili je] przed obliczem Jahwe, Boga naszego, przez siedem dni.
###### **1Krl 8,66**
 W ósmym dniu odprawił lud. Błogosławili więc króla i rozeszli się do swych namiotów radośni, w dobrym nastroju z powodu wszystkiego dobra, którym Jahwe obdarzył Dawida, swojego sługę, i Izraela, swój lud.
# 1Krl 8 BR
###### **1Krl 8,1**
 Potem zwołał Salomon do siebie, do Jerozolimy, starszych Izraela, przywódców wszystkich rodów izraelskich, żeby przenieść Arkę Przymierza Bożego z Miasta Dawidowego, to jest z Syjonu, [do świątyni Jahwe].
###### **1Krl 8,2**
 Zgromadzili się tedy wszyscy Izraelici wokół Salomona w miesiącu Etanim, który jest siódmym miesiącem roku, na obchody święta.
###### **1Krl 8,3**
 Kiedy już przybyli wszyscy starsi Izraela, kapłani wynieśli arkę.
###### **1Krl 8,4**
 Wzięto samą arkę Bożą, Namiot Spotkania oraz wszystkie święte przedmioty, które znajdowały się w namiocie. Nieśli to wszystko kapłani oraz lewici.
###### **1Krl 8,5**
 Król Salomon i wszyscy zgromadzeni przy nim Izraelici stanęli przed arką. Złożono ofiarę z tak wielu owiec i wołów, że nie sposób byłoby ich ani zliczyć, ani ocenić pod względem wartości.
###### **1Krl 8,6**
 Kapłani zanieśli arkę Bożą do świątyni Jahwe, do Świętego Świętych, i ustawili ją pod skrzydłami cherubów.
###### **1Krl 8,7**
 Cheruby miały bowiem rozpostarte skrzydła nad miejscem przeznaczonym dla arki. Swoimi skrzydłami okrywały cheruby całą arkę i drążki do jej przenoszenia.
###### **1Krl 8,8**
 Drążki owe były tak długie, że ich końce widziało się z Miejsca Świętego, stojąc naprzeciw Świętego Świętych, ale nie widziało się ich z zewnątrz. Są one tam do dnia dzisiejszego.
###### **1Krl 8,9**
 W arce nie było nic poza dwiema tablicami kamiennymi, które Mojżesz w niej złożył na górze Horeb, kiedy to Jahwe zawarł przymierze z synami Izraela podczas ich wyjścia z Egiptu.
###### **1Krl 8,10**
 Kiedy kapłani wychodzili z Miejsca Świętego, obłok wypełnił całą świątynię Jahwe.
###### **1Krl 8,11**
 Z powodu tego obłoku kapłani nie mogli zostać wewnątrz, żeby pełnić swoją służbę. Chwała Boża wypełniała bowiem całą świątynię Jahwe.
###### **1Krl 8,12**
 Wtedy powiedział Salomon: Jahwe chce pozostać w mrokach obłoku.
###### **1Krl 8,13**
 Zbudowałem Ci dom, miejsce Twojego zamieszkania, abyś mógł tam pozostawać na wieki.
###### **1Krl 8,14**
 Potem król odwrócił się i pobłogosławił całe zgromadzenie Izraela. Wszyscy zebrani stali.
###### **1Krl 8,15**
 A król mówił: Niech będzie błogosławiony Jahwe, Bóg Izraela, który przemówił do ojca mojego, Dawida, i swą ręką sprawił, że wypełniły się te oto słowa:
###### **1Krl 8,16**
 Od czasu wyprowadzenia z Egiptu mojego ludu izraelskiego nie wybrałem sobie w żadnym pokoleniu izraelskim żadnego miasta i nie żądałem, by Mi tam zbudowano dom, w którym mógłbym zamieszkać, ale powołałem Dawida na króla mojego ludu izraelskiego.
###### **1Krl 8,17**
 Dawid, mój ojciec, postanowił zbudować dom dla imienia Jahwe, Boga Izraela.
###### **1Krl 8,18**
 Lecz Jahwe powiedział do mojego ojca, Dawida: To bardzo dobrze, żeś postanowił zbudować dom dla mojego imienia.
###### **1Krl 8,19**
 Ale to nie tobie dane będzie zbudować ów dom. To twój syn, ten, który wyjdzie z twego łona, zbuduje dom dla mojego imienia.
###### **1Krl 8,20**
 Jahwe dotrzymał słowa, które wypowiedział. To rzeczywiście ja przyszedłem na miejsce ojca mojego, Dawida, to ja zasiadłem na tronie Izraela, jak przepowiedział Jahwe, ja wreszcie zbudowałem świątynię dla imienia Jahwe, Boga Izraela.
###### **1Krl 8,21**
 Wydzieliłem w niej specjalne miejsce dla arki, znaku przymierza Jahwe, przymierza, które On zawarł z naszymi praojcami, kiedy ich wyprowadzał z ziemi egipskiej.
###### **1Krl 8,22**
 Potem, zająwszy miejsce przed ołtarzem Jahwe, Salomon zwrócił się twarzą do całego zgromadzenia Izraela, wzniósł ręce ku górze i powiedział:
###### **1Krl 8,23**
 O Jahwe, Boże Izraela, Tobie równego nie ma ani na wysokościach niebieskich, ani tu na ziemi. Nikt tak jak Ty nie przestrzega miłosiernego przymierza, które zawarłeś z Twoimi sługami, jeśli tylko z całego serca trwają przy Tobie.
###### **1Krl 8,24**
 Jakże okazałeś się wierny wobec tego wszystkiego, co powiedziałeś słudze Twojemu, a mojemu ojcu, Dawidowi! Własnymi rękami, jak to można było zobaczyć za dni naszych, uczyniłeś to wszystko, co zapowiedziałeś swymi ustami.
###### **1Krl 8,25**
 Teraz, o Jahwe, Boże Izraela, racz wypełnić, ze względu na sługę Twojego, a mojego ojca, Dawida, to, co zechciałeś mu przyrzec, mówiąc: Nie zabraknie ci nigdy potomka, który będzie zasiadał na tronie Izraela, byleby tylko synowie twoi chodzili prostymi drogami i trzymali się blisko Mnie.
###### **1Krl 8,26**
 Niech więc wypełnią się teraz słowa, wypowiedziane przez Ciebie do sługi Twojego, a mojego Ojca, Dawida!
###### **1Krl 8,27**
 Ale czy to prawda, że Bóg mieszka na ziemi? Przecież Ciebie nie są w stanie objąć niebiosa i niebiosa niebios, a cóż dopiero ta świątynia, którą ja zbudowałem?
###### **1Krl 8,28**
 A Ty, Jahwe, Boże mój, racz wysłuchać modłów i próśb, jakie Twój sługa zanosi do ciebie. Usłysz ten krzyk, pełen radości, i nie odrzucaj prośby, którą sługa Twój zanosi dziś do Ciebie [Boga].
###### **1Krl 8,29**
 We dnie i w nocy patrzysz na tę świątynię, na to miejsce, o którym sam przecież powiedziałeś, że tam będzie przebywać Twoje imię i że tam będziesz wysłuchiwał próśb zanoszonych do Ciebie przez Twojego sługę.
###### **1Krl 8,30**
 Nie odrzucaj tedy modłów Twojego sługi i próśb całego ludu izraelskiego, kiedy będzie zwracał się do Ciebie na tym miejscu. Racz ich wysłuchiwać z miejsca Twego przebywania, z wyżyn niebieskich; wysłuchaj ich i przebacz im ich winy.
###### **1Krl 8,31**
 Jeżeli ktoś zgrzeszy przeciw swemu bratu, a potem zostanie nakłoniony do złożenia przysięgi, i jeżeli się zjawi przed Twoim ołtarzem w tej świątyni,
###### **1Krl 8,32**
 to racz go wysłuchać z niebios i nie ociągaj się z działaniem: rozsądzaj sprawy Twoich sług i zsyłaj zasłużone kary na winnych; niech owoce ich działania spadają na ich głowy; uniewinniaj zaś niewinnych i postępuj z nimi zgodnie z ich niewinnością.
###### **1Krl 8,33**
 Kiedy zdarzy się, że synowie Twojego ludu izraelskiego poniosą klęskę, którą zadadzą im ich wrogowie, dlatego że sprzeniewierzali się Tobie, to jeśli nawrócą się ku Tobie, oddadzą chwałę Twojemu imieniu, jeśli zaczną zanosić do Ciebie w tej świątyni prośby i błagania -
###### **1Krl 8,34**
 racz ich wysłuchać z wysokości niebieskich, przebacz winy Twojemu ludowi izraelskiemu i pozwól mu wrócić do kraju, który raczyłeś kiedyś przekazać jego ojcom.
###### **1Krl 8,35**
 Kiedy niebo się zamknie i nie będzie deszczu, dlatego że dopuścili się wykroczeń przeciw Tobie, to jeśli zwrócą się znów ku Tobie, jeśli zaczną się modlić na tym miejscu i oddawać chwałę Twojemu imieniu, jeśli porzucą swoje grzechy wskutek Twojego karania -
###### **1Krl 8,36**
 racz ich wysłuchać z wyżyn niebieskich, przebacz im, Twoim sługom i Twojemu ludowi izraelskiemu, grzechy i zechciej im wskazywać drogę, którą powinni kroczyć. Niech też w końcu spadnie deszcz na ziemię, którą raczyłeś dać Twojemu ludowi jako dziedzictwo.
###### **1Krl 8,37**
 Kiedy kraj nawiedzi klęska głodu, gdy spadnie nań jakaś zaraza, gdy jego zbiory będzie niszczył ogień, śnieć, szarańcza lub chasil; gdy wróg nagle zacznie nękać mieszkańców całego kraju, od bram jego poczynając, gdy zdarzy się jakaś jeszcze inna klęska lub choroba -
###### **1Krl 8,38**
 [racz wysłuchać] modlitw i błagań, jakie poszczególni ludzie albo cały lud izraelski zaczną zanosić do Ciebie; gdy wszyscy, z potrzeby serca, zaczną wyciągać ręce w stronę tej świątyni,
###### **1Krl 8,39**
 wtedy racz ich wysłuchać z wyżyn niebieskich, z miejsca Twojego zamieszkania, i przebacz im ich winy; zechciej - Ty, który znasz serce każdego, Ty, który jedyny znasz tajniki wszystkich serc ludzkich - odpłacić każdemu według dróg, którymi kroczył,
###### **1Krl 8,40**
 tak iżby trwali w bojaźni Twojej do końca swojego życia na tej ziemi, którą raczyłeś dać naszym ojcom.
###### **1Krl 8,41**
 Kiedy jakiś cudzoziemiec, czyli człowiek, który nie należy do ludu Twojego izraelskiego, pociągnięty Twoim imieniem, przyjdzie tu z dalekiego kraju -
###### **1Krl 8,42**
 bo będą się rozchodzić dokoła wieści o Twoim wielkim imieniu, o Twojej silnej ręce i wyciągniętym ramieniu - kiedy więc ów cudzoziemiec przyjdzie, aby modlić się w tej świątyni -
###### **1Krl 8,43**
 racz go wysłuchać z wysokości niebieskich, z miejsca Twojego zamieszkania, zechciej uczynić to, o co będzie Cię prosił cudzoziemiec, żeby wszystkie narody ziemi poznały Twoje imię i żyły w Twojej bojaźni, tak jak Twój lud izraelski; niech wiedzą, że Twoje imię zostało wezwane nad tą świątynią, którą zbudowałem.
###### **1Krl 8,44**
 Kiedy lud Twój wyruszy na wojnę ze swymi wrogami, chodząc przy tym wskazanymi przez Ciebie drogami, gdy zacznie się modlić do Jahwe, kierując swój wzrok w stronę miasta, w którym sobie upodobałeś, i ku świątyni, którą zbudowałem dla Twojego imienia -
###### **1Krl 8,45**
 racz wysłuchać jego modlitw i błagań i postąp z nim sprawiedliwie.
###### **1Krl 8,46**
 Kiedy zgrzeszą przeciwko Tobie - a przecież wiadomo, że nie ma człowieka, który by nie grzeszył - Ty zaś, rozgniewawszy się na nich, wydasz ich w ręce ich wroga, który jako zwycięzca pojmie ich w niewolę i uprowadzi do kraju bądź bardzo odległego, bądź nieco bliższego,
###### **1Krl 8,47**
 i tak znajdą się na ziemi swojego zwycięzcy, to jeśli się nawrócą i zaczną do Ciebie zanosić błagania, pozostając na ziemi swych wrogów; jeśli będą wyznawać swoje grzechy i niegodziwości oraz zbrodnie, których się dopuścili;
###### **1Krl 8,48**
 jeśli nawrócą się do Ciebie z całego serca i z całej swojej duszy, pozostając na ziemi wrogów, którzy ich tam przywiedli jako wziętych do niewoli; jeśli zaczną się do Ciebie modlić, zwracając swoje oczy w stronę tej ziemi, którą raczyłeś dać ich ojcom, i w stronę miasta, w którym sobie upodobałeś, oraz w stronę świątyni, którą ja zbudowałem dla Twojego imienia -
###### **1Krl 8,49**
 racz wysłuchać z wyżyn niebieskich, z miejsca Twojego zamieszkania, ich modlitw i błagań i postąp z nimi sprawiedliwie;
###### **1Krl 8,50**
 przebacz Twojemu ludowi przewinienia i grzechy, których się dopuścił przeciwko Tobie; spraw, żeby ich wrogowie okazali im współczucie i litość.
###### **1Krl 8,51**
 Są oni przecież ludźmi Twojego dziedzictwa, potomkami tych, których kiedyś wyprowadziłeś z Egiptu, z samego środka owego pieca do topienia żelaza.
###### **1Krl 8,52**
 Niech się otworzą Twoje oczy na błagania Twojego sługi i modły całego ludu izraelskiego, racz im uczynić wszystko, o co Cię będą prosić.
###### **1Krl 8,53**
 Przecież Ty sam oddzieliłeś ich od innych ludów ziemi i wybrałeś dla siebie, aby byli Twoim dziedzictwem, tak jak to ogłosiłeś przez Mojżesza, kiedy wyprowadzałeś ojców naszych z Egiptu, o Panie nasz, Jahwe.
###### **1Krl 8,54**
 Salomon skończył prosić i błagać w ten sposób Jahwe, a potem podniósł się sprzed ołtarza Jahwe, z miejsca, na którym klęczał z rękami wyciągniętymi ku niebu.
###### **1Krl 8,55**
 Powstawszy pobłogosławił całe zgromadzenie Izraela, mówiąc głośno:
###### **1Krl 8,56**
 Niech będzie błogosławiony Jahwe za to, że dał odpocznienie swojemu ludowi izraelskiemu, dokładnie tak, jak to zapowiedział. Z tego, co przekazał przez usta sługi swego Mojżesza, ani jedno słowo nie pozostało nie spełnione.
###### **1Krl 8,57**
 Jahwe, nasz Bóg, niech będzie z nami, tak jak był z praojcami naszymi. Niech nas nie opuszcza i nigdy nie odrzuca,
###### **1Krl 8,58**
 lecz niech sprawia, żeby nasze serca lgnęły do Niego, byśmy zawsze chodzili Jego drogami i przestrzegali Jego przykazań, praw i pouczeń, które pozostawił ojcom naszym.
###### **1Krl 8,59**
 Niech wypowiedziane przeze mnie tu, przed obliczem Jahwe, modlitwy błagalne będą blisko Jahwe, Boga naszego, w nocy i za dnia, tak by mógł On, według potrzeby dnia każdego, czynić dobro tak swemu słudze, jak i całemu ludowi izraelskiemu.
###### **1Krl 8,60**
 Wtedy będą widziały wszystkie ludy ziemi, że Jahwe jest Bogiem i że nie ma innego Boga.
###### **1Krl 8,61**
 Całym waszym sercem przylgnijcie do Jahwe, Boga naszego, by postępować według Jego praw i zachowywać Jego nakazy, tak jak to dziś wszyscy czynimy.
###### **1Krl 8,62**
 Potem król wraz z całym Izraelem złożył ofiary na cześć Jahwe.
###### **1Krl 8,63**
 Na ofiarę pojednania dla Jahwe zabił Salomon dwadzieścia dwa tysiące wołów i sto dwadzieścia tysięcy owiec. W ten sposób król i wszyscy synowie Izraela dokonali poświęcenia świątyni Jahwe.
###### **1Krl 8,64**
 Tego samego dnia poświęcił król również środkową część dziedzińca znajdującego się przed świątynią Jahwe. Złożył tam bowiem ofiary całopalenia, ofiary z pokarmów i tłuszczu ofiar pojednania, gdyż ołtarz brązowy, który był przed Jahwe [wewnątrz świątyni], okazał się za mały, by móc pomieścić wszystkie całopalenia, ofiary pojednania tudzież ofiary z pokarmów i tłuszczu ofiar pojednania.
###### **1Krl 8,65**
 Przez siedem dni i przez następne siedem dni, czyli w sumie przez czternaście dni, obchodził Salomon wobec Jahwe, naszego Boga, uroczystość [poświęcenia świątyni]. Uczestniczył w tym cały Izrael, mnóstwo ludzi, którzy przybyli z całego kraju - od Wejścia do Chamat aż do Potoku Egipskiego.
###### **1Krl 8,66**
 Ósmego dnia [Salomon] rozesłał lud. Wracając z sercem przepełnionym radością do swoich domów, wszyscy błogosławili króla za to, że Jahwe był taki dobry dla swego sługi Dawida i dla Izraela, swojego ludu.
# 1Krl 8 WUJ
###### **1Krl 8,1**
 Zebrali się tedy wszyscy starszy Izraelscy z Książęty pokoleni i przełożeni domów synów Izraelskich do Króla Salomona w Jeruzalem: aby przenieśli skrzynię przymierza Pańskiego z miasta Dawidowego, to jest z Sionu.
###### **1Krl 8,2**
 I zszedł się do króla Salomona wszystek Izrael w miesiącu Ethanim w uroczysty dzień, ten jest miesiąc siódmy.
###### **1Krl 8,3**
 I przyszli wszyscy starszy z Izraela, i wzięli skrzynię kapłani.
###### **1Krl 8,4**
 I nieśli skrzynię Pańską, i przybytek przymierza, i wszystkie naczynia świątnice, które były w przybytku: i nieśli je kapłani i Lewitowie.
###### **1Krl 8,5**
 A król Salomon, i wszystko mnóstwo Izraelskie, które się było zeszło do niego, szło z nim przed skrzynią, i ofiarowali owce i woły bez szacunku i liczby.
###### **1Krl 8,6**
 I wnieśli kapłani skrzynię przymierza Pańskiego na miejsce jej do wyrocmice kościelnej, do świętego świętych pod skrzydła Cherubini.
###### **1Krl 8,7**
 Bo Cherubowie rozciągali skrzydła nad miejscem skrzynie, i okrywali skrzynię, i drążki jej zwierzchu.
###### **1Krl 8,8**
 A gdyż wychadzały drążki, i ukazowały się końce ich z świątnice przed wyrocznicą, nie okazowały się więcej zewnątrz, które też tam były aż do dnia dzisiejszego.
###### **1Krl 8,9**
 A w skrzyni nie było nic inszego, jedno dwie tablicy kamienne, które był do niej włożył Mojżesz na Horeb, gdy Pan uczynił przymierze z synmi Izraelowemi, gdy wychodzili z ziemie Egiptskiej.
###### **1Krl 8,10**
 I stało się, gdy wyszli kapłani z świątnice, obłok napełnił dom Pański.
###### **1Krl 8,11**
 I nie mogli kapłani stać i służyć dla obłoku: bo była chwała Pańska napełniła dom Pański.
###### **1Krl 8,12**
 Tedy rzekł Salomon: Pan rzekł, że miał mieszkać we mgle.
###### **1Krl 8,13**
 Budując zbudowałem dom na mieszkanie tobie, mocną stolicę twoję na wieki.
###### **1Krl 8,14**
 I obrócił król oblicze swe, i błogosławił wszystkiemu zgromadzeniu Izraelskiemu: bo wszystko zgromadzenie Izraelskie stało.
###### **1Krl 8,15**
 I rzekł Salomon: Błogosławiony Pan Bóg Izraelów, który mówił usty swemi do Dawida ojca mego, i w rękach jego wypełnił, rzekąc:
###### **1Krl 8,16**
 Ode dnia, któregom wywiódł lud mój Izraelski z Egiptu, nie obrałem miasta ze wszech pokoleni Izraelskich, żeby był zbudowany dom i było tam imię moję: alem obrał Dawida, aby był nad ludem moini Izraelskim.
###### **1Krl 8,17**
 I chciał Dawid ociec mój budować dom imieniowi Pana Boga Izraelowego.
###### **1Krl 8,18**
 I rzekł Pan do Dawida ojca mego: Żeś myślił w sercu swojem budować dom imieniowi memu, dobrześ uczynił, to samo w sercu rozbierając.
###### **1Krl 8,19**
 Wszakże jednak, ty mi domu nie zbudujesz, ale syn twój, który wynidzie z nerek twoich, ten zbuduje dom imieniowi memu.
###### **1Krl 8,20**
 I potwierdził Pan mowę swoję, którą mówił: i stanąłem miasto Dawida ojca mego, i usiadłem na stolicy Izraelskiej, jako Pan powiedział: i zbudowałem dom, imieniowi Pana Boga Izraelowego,
###### **1Krl 8,21**
 I postanowiłem tam miejsce skrzyni, w której jest przymierze Pańskie, które postanowił z ojcy naszymi, gdy wyszli z ziemie Egiptskiej.
###### **1Krl 8,22**
 I stanął Salomon przed ołtarzem Pańskim przed oczyma zgromadzenia Izraelskiego, i wyciągnął ręce swe ku niebu.
###### **1Krl 8,23**
 I rzekł: Panie Boże Izraelów, niemasz podobnego tobie Boga na niebie wzgórę, i na ziemi nisko: który chowasz umowę i miłosierdzie sługom swym, którzy chodzili przed tobą we wszystkiein sercu swojem.
###### **1Krl 8,24**
 Któryś strzegł słudze twemu Dawidowi ojcu memu, coś mu powiedział: ustyś mówił, a rękomaś wykonał, jako ten dzień świadczy.
###### **1Krl 8,25**
 Teraz tedy Panie Boże Izraelów, zachowaj słudze twemu Dawidowi ojcu memu, coś mu powiedział mówiąc: Nie będzie odjęty z ciebie mąż przedemną, któryby siedział na stolicy Izraelskiej: wszakże tak, jeśli będą strzedz synowie twoi drogi swej, żeby chodzili przedemną jakoś ty chodził przed oblicznością moją.
###### **1Krl 8,26**
 A teraz Panie Boże Izraelów niech się utwierdzą słowa twoje, któreś mówił słudze twemu Dawidowi ojcu niemu.
###### **1Krl 8,27**
 A więc mniemać mamy, że prawdziwie Bóg mieszka na ziemi? bo jeśli niebo i nieba niebów ciebie ogarnąć nie mogą, jakoż daleko więcej ten dom, którym zbudował?
###### **1Krl 8,28**
 Ale wejrzy na modlitwę sługi twego, i na prośby jego Panie Boże mój: usłysz chwałę i modlitwę, którą sługa twój modli się dziś przed tobą:
###### **1Krl 8,29**
 Aby były oczy twe otworzone nad tym domem we dnie i w nocy: nad domem, o którymeś mówił: Będzie tam imię moje: abyś wysłuchał modlitwę, którą się modli do ciebie sługa twój na tem miejscu.
###### **1Krl 8,30**
 Abyś wysłuchał prośbę sługi twego i ludu twego Izraelskiego, aczkolwiek prosić będą na tem miejscu, a wysłuchasz na miejscu mieszkania twego na niebie, a wysłuchawszy będziesz miłościw.
###### **1Krl 8,31**
 Jeśli człowiek zgrzeszy przeciw bliźniemu swemu, a będzie miał jaką przysięgę, którąby był obwiązany: a przyjdzie dla przysięgi przed ołtarz twój do domu twego:
###### **1Krl 8,32**
 Ty wysłuchasz na niebie a uczynisz i rozsądzisz sługi twoje, potępiając niepobożnego, i oddając drogę jego na głowę jego: a usprawiedliwiając sprawiedliwego, i oddając mu według sprawiedliwości jego.
###### **1Krl 8,33**
 Jeśliby uciekł lud twój Izraelski przed nieprzyjacielmi swemi (boć będzie grzeszył przeciw tobie) a czyniąc pokutę i wyznawając imieniowi twemu, przyjdą i modlić się będą, i odpraszać cię w tym domu:
###### **1Krl 8,34**
 Wysłuchaj na niebie, a odpuść grzech ludu twego Izraelskiego, a przywróć je do ziemie, którąś dał ojcom ich.
###### **1Krl 8,35**
 Jeśli będzie zamknione niebo, a nie będzie dżdżu dla grzechów ich: a modląc się na tem miejscu pokutę czynić będą imieniowi twemu, a nawrócą się od grzechów swoich dla utrapienia swego:
###### **1Krl 8,36**
 Wysłuchaj ich na niebie, a odpuść grzechy sług twoich i ludu twego Izraelskiego: a ukaż im drogę dobrą, którąby chodzili, a daj deszcz na ziemię twoje, którąś dał ludowi twemu w osiadłość.
###### **1Krl 8,37**
 Jeśli się zaweźmie głód w ziemi, abo mór, abo skażone powietrze, abo susza, abo szarańcza, abo rdza, i utrapi go nieprzyjaciel jego oblegszy bramy jego, wszelaka plaga, wszelka choroba.
###### **1Krl 8,38**
 Wszelkie przeklęctwo i złorzeczenstwo, któreby przypadło na wszelkiego człowieka z ludu twego Izraelskiego: jeśliby kto poznał ranę serca swego, a rozciągnął ręce swe w tym domu.
###### **1Krl 8,39**
 Ty wysłuchasz w niebie na miejscu mieszkania twego, a zlitujesz się, i uczynisz, że dasz każdemu według wszystkich dróg jego, jako ujrzysz serce jego, (Bo ty sam znasz serce wszystkich synów człowieczych).
###### **1Krl 8,40**
 Aby się ciebie bali po wszystkie dni, których żywią na ziemi, którąś dał ojcom naszym,
###### **1Krl 8,41**
 Nadto i cudzoziemiec, który nie jest z ludu twego Izraelskiego, gdy przyjdzie z dalekiej ziemie dla imienia twego (bo usłyszą imię twoje wielkie i rękę twoją mocną i ramię twoje wyciągnione wszędy),
###### **1Krl 8,42**
 Gdy tedy przyjdzie, a będzie się modlił na tem miejscu.
###### **1Krl 8,43**
 Ty wysłuchasz na niebie, na utwierdzeniu mieszkania twego, i uczynisz wszystko o co cię cudzoziemiec będzie wzywał: aby się nauczyli wszyscy narodowie ziemscy bać się imienia twego, jako twój lud Izraelski, ażeby doznali, że wzywane jest imię twoje nad tym domem, którym zbudował.
###### **1Krl 8,44**
 Jeśli wynidzie lud twój na wojnę przeciw nieprzyjaciołom swym, drogą dokądkolwiek je poślesz: a będą się modlić przeciw drodze miasta, któreś obrał i ku domowi, którym zbudował imieniowi twemu:
###### **1Krl 8,45**
 I wysłuchasz na niebie modlitwy ich i prośby ich, uczynisz sąd ich.
###### **1Krl 8,46**
 A jeśli zgrzeszą przeciw tobie, (bo niemasz człowieka, któryby nie grzeszył) i rozgniewawszy się podasz je nieprzyjaciołom ich, i będą zabrani w niewolą do ziemie nieprzyjacielskiej, daleko abo blisko:
###### **1Krl 8,47**
 A będą czynić pokutę w sercu swem na miejscu niewoli, a nawróciwszy się, prosiliby cię w niewolej swej, mówiąc: Zgrzeszyliśmy, źleśmy uczynili, niezbożnieśmy się sprawowali:
###### **1Krl 8,48**
 A nawróciliby się do ciebie ze wszystkiego serca swego, i ze wszystkiej dusze swej, w ziemi nieprzyjaciół swoich, do której więźniami zabrani są: a modliliby się tobie ku drodze ziemi swojej, którąś dał ojcom ich, i miasta, któreś obrał, i kościoła, którym zbudował imieniowi twemu.
###### **1Krl 8,49**
 Wysłuchasz na niebie na utwierdzeniu stolice twej modlitwy ich, i prośby ich, a uczynisz sąd ich:
###### **1Krl 8,50**
 I miłościw będziesz ludowi twemu, który zgrzeszył przeciw tobie i wszystkim nieprawościom ich, którymi wystąpili przeciw tobie: i dasz miłosierdzie przed temi, którzy je w niewoli trzymają, ze się zmiłują nad nimi.
###### **1Krl 8,51**
 Bo lud twój jest i dziedzictwo twoje, którycheś wywiódł z ziemie Egiptskiej, z pośrodku pieca żelaznego.
###### **1Krl 8,52**
 Aby były oczy twoje otwarte na prośbę sługi twego, i ludu twego Izraelskiego, i abyś je wysłuchał we wszystkieni, o co cię wzywać będą.
###### **1Krl 8,53**
 Boś je ty odłączył sobie za dziedzictwo ze wszech narodów ziemskich, jakoś mówił przez Mojżesza sługę twego, kiedyś wywiódł ojce nasze z Egiptu, Panie Boże.
###### **1Krl 8,54**
 I stało się, gdy dokonał Salomon, modląc się Panu, wszystkiej modlitwy i prośby tej, wstał od ołtarza Pańskiego: bo był na obie kolenie poklęknął, a ręce rozciągnął ku niebu.
###### **1Krl 8,55**
 Stanął tedy i błogosławił wszystkiemu zgromadzeniu Izraelskiemu głosem wielkim, mówiąc:
###### **1Krl 8,56**
 Błogosławiony Pan, który dał odpoczynienie ludowi swemu Izraelskiemu, według wszystkiego co powiedział: nie upadło ani jedno słowo ze wszystkiego dobra, które mówił przez Mojżesza sługę swego.
###### **1Krl 8,57**
 Niechże Pan Bóg nasz będzie z nami, jako był z ojcy naszymi, nie opuszczając nas ani odrzucając.
###### **1Krl 8,58**
 Ale niech nakłoni serca nasze, ku sobie, żebyśmy chodzili we wszystkich drogach jego, a strzegli przykazań jego, i Ceremonje jego i sądów, którekolwiek przykazał ojcom naszym.
###### **1Krl 8,59**
 A te mowy moje, któremim się modlił przed Panem, przybliżą się do Pana Boga naszego we dnie i w nocy, żeby czynił sąd słudze swemu, i ludowi swemu Izraelskiemu na każdy dzień.
###### **1Krl 8,60**
 Aby wiedzieli wszyscy narodowie ziemscy, że Pan sam jest Bóg, a niemasz dalej oprócz niego.
###### **1Krl 8,61**
 Serce też nasze niech będzie doskonałe z Panem Bogiem naszym, abyśmy chodzili w wyrokach jego, a strzegli przykazań jego, jako i dnia dzisiejszego.
###### **1Krl 8,62**
 Król tedy i wszystek Izrael z nim, ofiarowali ofiary przed Panem.
###### **1Krl 8,63**
 I nabił Salomon ofiar zapokojnych, które ofiarował Panu, wołów dwadzieścia i dwa tysiąca, a owiec sto i dwadzieścia tysięcy: i poświęcili kościół Pański król i synowie Izraelowi.
###### **1Krl 8,64**
 Onegoż dnia poświęcił król środek sieni, która była przed domem Pańskim: bo tam ofiarował całopalenie i ofiarę, i tłustość zapokojnycli: bo ołtarz miedziany, który był przed Panem, był mniejszy, i nie mogły się na nim zmieścić całopalenia i ofiara i tłustość zapokojnych.
###### **1Krl 8,65**
 Uczynił tedy Salomon na on czas święto znamienite, i wszystek Izrael z nim, zgromadzenie wielkie od weścia Emat aż do Rzeki Egiptskiej, przed Pnnem Bogiem naszym, przez siedm dni, i przez siedm dni, to jest, przez czternaście dni.
###### **1Krl 8,66**
 A ósmego dnia, rozpuścił lud: którzy błogosławiąc królowi, poszli do przybytków swoich, weseląc się, i z ochotnem sercem dla wszystkiego dobra, które uczynił Pan Dawidowi słudze swemu i Izraelowi ludowi swemu.
