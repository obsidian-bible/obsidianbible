# Dn 7 BT5
###### **Dn 7,1**
 W pierwszym roku [panowania] króla babilońskiego, Baltazara, miał Daniel sen i zaniepokoiły go widziadła [powstałe w] jego głowie na jego łożu. Następnie spisał on ten sen.
###### **Dn 7,2**
 Daniel więc opowiedział: «***Ujrzałem w swoich wizjach nocnych. Oto cztery wichry z nieba wzburzyły wielkie morze.***
###### **Dn 7,3**
 ***Cztery ogromne bestie wyszły z morza, a jedna różniła się od drugiej.***
###### **Dn 7,4**
 ***Pierwsza podobna była do lwa i miała skrzydła orle. Patrzyłem, a oto wyrwano jej skrzydła, ją zaś samą uniesiono w górę i postawiono jak człowieka na dwu nogach, dając jej ludzkie serce.***
###### **Dn 7,5**
 ***I oto druga bestia, zupełnie inna, podobna do niedźwiedzia, z jednej strony podparta, a trzy żebra miała w paszczy między zębami. Mówiono do niej: Podnieś się! Pożeraj wiele mięsa!***
###### **Dn 7,6**
 ***Potem patrzyłem, a oto inna [bestia] podobna do pantery, mająca na grzbiecie cztery ptasie skrzydła. Bestia ta miała cztery głowy; jej to powierzono władzę.***
###### **Dn 7,7**
 ***Dalej ujrzałem w moich nocnych wizjach: Oto czwarta bestia, okropna i przerażająca, o nadzwyczajnej sile. Miała wielkie zęby z żelaza < i miedziane pazury >; pożerała i kruszyła, depcąc nogami to, co pozostawało. Różniła się od wszystkich poprzednich bestii i miała dziesięć rogów.***
###### **Dn 7,8**
 ***Gdy przypatrywałem się rogom, oto inny mały róg wyrósł między nimi i trzy spośród pierwszych rogów zostały przed nim wyrwane. Miał on oczy podobne do ludzkich oczu i usta, które mówiły wielkie rzeczy.***
###### **Dn 7,9**
 ***Patrzyłem, aż postawiono trony, a Przedwieczny zajął miejsce. Szata Jego była biała jak śnieg, a włosy na Jego głowie jakby z czystej wełny. Tron Jego był z ognistych płomieni, jego koła z płonącego ognia.***
###### **Dn 7,10**
 ***Strumień ognia się rozlewałi wypływał od Niego. Tysiąc tysięcy służyło Mu, a dziesięć tysięcy razy dziesięć tysięcystało przed Nim.Sąd zasiadłi otwarto księgi.***
###### **Dn 7,11**
 ***Z powodu hałasu wielkich słów, jakie wypowiadał róg, patrzyłem, aż oto zabito bestię; ciało jej uległo zniszczeniu i wydano je na spalenie.***
###### **Dn 7,12**
 ***Także innym bestiom odebrano władzę, ale ustalono okres trwania ich życia do czasu oznaczonego.***
###### **Dn 7,13**
 ***Patrzyłem w nocnych widzeniach:a oto na obłokach nieba przybywajakby Syn Człowieczy.Podchodzi do Przedwiecznegoi wprowadzają Go przed Niego.***
###### **Dn 7,14**
 ***Powierzono Mu panowanie, chwałę i władzę królewską, a służyły Mu wszystkie narody, ludy i języki. Panowanie Jego jest wiecznym panowaniem, które nie przeminie, a Jego królestwo nie ulegnie zagładzie.***
###### **Dn 7,15**
 ***Ja, Daniel, popadłem z tego powodu w niepokój ducha, a widzenia [powstałe] w mojej głowie przeraziły mnie.***
###### **Dn 7,16**
 ***Przybliżyłem się do jednego ze stojących i zapytałem o właściwe znaczenie tego wszystkiego. On zaś odpowiedział i wyjaśnił znaczenie rzeczy.***
###### **Dn 7,17**
 ***Te wielkie bestie w liczbie czterech – to czterej królowie, którzy powstaną z ziemi.***
###### **Dn 7,18**
 ***Królestwo jednak otrzymają święci Najwyższego, i będą posiadać królestwo na zawsze i na wieki wieków.***
###### **Dn 7,19**
 ***Potem chciałem się upewnić co do czwartej bestii, odmiennej od pozostałych i nader strasznej, która miała zęby z żelaza i miedziane pazury, a pożerała, kruszyła i deptała nogami resztę;***
###### **Dn 7,20**
 ***oraz co do dziesięciu rogów na jej głowie, i co do innego, przed którym, gdy wyrósł, upadły trzy tamte. Róg ten miał oczy i usta, wypowiadające wielkie rzeczy, i wydawał się większy od swoich towarzyszy.***
###### **Dn 7,21**
 ***Patrzyłem, a róg ten rozpoczął wojnę ze świętymi, i zwyciężał ich,***
###### **Dn 7,22**
 ***aż przybył Przedwieczny i sąd zasiadł, a władzę dano świętym Najwyższego, i aż nadszedł czas, by święci otrzymali królestwo.***
###### **Dn 7,23**
 ***Powiedział tak:Czwarta bestia –to czwarte królestwo, które będzie na ziemi, różne od wszystkich królestw; pochłonie ono całą ziemię, podepce ją i na proch zetrze.***
###### **Dn 7,24**
 ***Dziesięć zaś rogów – z tego królestwa powstanie dziesięciu królów, po nich zaś inny powstanie, różny od poprzednich, i obali trzech królów.***
###### **Dn 7,25**
 ***Będzie wypowiadał słowa przeciw Najwyższemui gnębił świętych Najwyższego, postanowi zmienićczasy i Prawo, a [święci] będą wydani w jego ręceaż do czasu, czasów i połowy czasu.***
###### **Dn 7,26**
 ***Wtedy odbędzie się sąd i odbiorą mu władzę, by go zniszczyć i zniweczyć doszczętnie.***
###### **Dn 7,27**
 ***A panowanie i władzę, i wielkość królestwpod całym niebemotrzyma lud święty Najwyższego. Królestwo Jego będzie wiecznym królestwem; będą Mu służyły wszystkie mocei będą Mu uległe.***
###### **Dn 7,28**
 ***Dotąd opis zdarzenia. Moje myśli bardzo przeraziły mnie, Daniela; zmieniłem się na twarzy, lecz zachowałem wydarzenie w sercu.***
# Dn 7 PAU
###### **Dn 7,1**
 W pierwszym roku Baltazara, króla Babilonu, Daniel miał sen. To, co widział na swoim łożu, opisał własnymi słowami. Daniel powiedział:
###### **Dn 7,2**
 „Miałem takie widzenie w nocy. Oto wiatry z czterech stron świata wzburzyły ogromne morze.
###### **Dn 7,3**
 I cztery bestie ogromne wychodziły z morza, a każda była inna.
###### **Dn 7,4**
 Pierwsza - podobna była do lwa i miała skrzydła orła. Widziałem, jak wyrwane zostały jej skrzydła, a ona podniosła się z ziemi i stanęła na dwóch nogach jak człowiek. I dano jej ludzki rozum.
###### **Dn 7,5**
 Potem zjawiła się bestia inna, druga - podobna do niedźwiedzia. Była podparta z jednej strony, a w paszczy, między zębami, miała trzy żebra. I powiedziano jej: «Wstań! Pożeraj wiele mięsa!».
###### **Dn 7,6**
 Potem zobaczyłem inną bestię - podobną do pantery. Na jej grzbiecie były cztery ptasie skrzydła i miała cztery głowy. I dano jej władzę.
###### **Dn 7,7**
 Potem w widzeniu nocnym zobaczyłem: Oto bestia czwarta - straszna, przerażająca, nadzwyczaj silna. Miała potężne zęby z żelaza, pożerała i miażdżyła, a to, co jeszcze pozostało, deptała nogami. Była ona inna od wszystkich poprzednich bestii. Miała dziesięć rogów.
###### **Dn 7,8**
 Kiedy przypatrywałem się tym rogom, zaczął wyrastać spomiędzy nich inny róg, mały, a trzy spośród wcześniejszych rogów zostały przed nim wyrwane. Na tym rogu były ludzkie oczy i usta, które wypowiadały straszne rzeczy.
###### **Dn 7,9**
 Patrzyłem, jak postawiono trony i usiadł Przedwieczny. Jego szaty były białe jak śnieg, włosy na Jego głowie jak czysta wełna. Jego tron był z ognistych płomieni, a koła u tronu - to ogień płonący.
###### **Dn 7,10**
 Ognista rzeka wypływała i wydobywała się sprzed Niego. Tysiąc tysięcy służyło Mu i nieprzeliczone rzesze stały przed Nim. Zasiadł sąd i otwarto księgi.
###### **Dn 7,11**
 Patrzyłem, jak z powodu strasznych słów, które wypowiadał róg, zabito bestię, a jej ciało powalono i wrzucono do ognia, aby spłonęło.
###### **Dn 7,12**
 Pozostałym bestiom odebrano władzę, ale zachowały życie aż do wyznaczonego czasu.
###### **Dn 7,13**
 Patrzyłem i widziałem w widzeniu nocnym: Oto z obłokami nieba przybywa jakby Syn Człowieczy, przychodzi do Przedwiecznego i prowadzą Go przed Niego.
###### **Dn 7,14**
 I dano Mu panowanie, chwałę i królowanie: będą Mu służyły wszystkie ludy, narody i języki. Jego panowanie będzie wiecznym panowaniem, które nie przeminie, a Jego królowanie - królowaniem, które nie ulegnie zagładzie.
###### **Dn 7,15**
 Dlatego ja, Daniel, wystraszyłem się i przeraziło mnie to, co widziałem.
###### **Dn 7,16**
 Zwróciłem się do jednego ze stojących i zapytałem o to wszystko. On wyjaśnił mi te sprawy i ujawnił ich znaczenie:
###### **Dn 7,17**
 «Te cztery wielkie bestie oznaczają czterech królów, którzy powstaną na ziemi.
###### **Dn 7,18**
 Lecz to królestwo otrzymają święci Najwyższego. Będą je posiadać na zawsze i po wszystkie wieki».
###### **Dn 7,19**
 Wtedy chciałem poznać prawdę o czwartej bestii, która była inna od wszystkich zwierząt przed nią, nadzwyczaj straszna, miała zęby z żelaza i pazury z miedzi, pożerała, miażdżyła, a to, co jeszcze zostało, deptała nogami.
###### **Dn 7,20**
 I o dziesięciu rogach na jej głowie, i o innym rogu, który wyszedł spośród nich, a przed nim upadły trzy z jej rogów. Róg ten miał oczy i usta mówiące straszne rzeczy i wyglądał na większy od innych.
###### **Dn 7,21**
 Patrzyłem i zobaczyłem, że róg wypowiedział wojnę świętym i pokonał ich.
###### **Dn 7,22**
 Wtedy przybył Przedwieczny i odbył się sąd ze względu na świętych Najwyższego. Nadszedł wyznaczony czas i to królestwo otrzymali święci.
###### **Dn 7,23**
 I mówił dalej: «Bestia czwarta - królestwo czwarte nastanie na ziemi, inne od wszystkich królestw - pożre całą ziemię, podepcze ją i zmiażdży.
###### **Dn 7,24**
 Dziesięć rogów - z tego królestwa powstanie dziesięciu królów, a po nich nastanie inny, różny od poprzednich, i poniży trzech królów.
###### **Dn 7,25**
 Będzie bluźnił przeciw Najwyższemu i będzie prześladował świętych Najwyższego. Będzie usiłował zmienić dni świąt i Prawo. Zostaną wydani w jego ręce do czasu, czasów i połowy czasu.
###### **Dn 7,26**
 Zasiądzie sąd i odbierze mu władzę. Zostanie on zniszczony i zatracony zupełnie.
###### **Dn 7,27**
 Jego królowanie i władzę oraz wszystkie królestwa pod całym niebem otrzyma lud świętych Najwyższego. Królowanie Najwyższego jest wieczne. Wszystkie potęgi będą Go czciły i będą Mu posłuszne.
###### **Dn 7,28**
 Tu kończy się opowiadanie. Ja, Daniel, zląkłem się swoich myśli, zmienił się wyraz mojej twarzy, lecz zachowałem sprawę w moim sercu”.
# Dn 7 BP
###### **Dn 7,1**
 W pierwszym roku Belszazara, króla Babilonu, Daniel miał sen i widzenia [w] swej głowie, [gdy leżał] na łożu. Potem spisał sen i podał istotę rzeczy.
###### **Dn 7,2**
 Daniel przemówił: Widziałem w widzeniu nocnym: Oto cztery wiatry niebieskie wzburzyły wielkie morze.
###### **Dn 7,3**
 Cztery wielkie zwierzęta wyszły z morza, różniące się jedno od drugiego.
###### **Dn 7,4**
 Pierwsze było jak lew i miało skrzydła orle. Patrzyłem [na nie w] widzeniu aż do chwili, gdy wyrwano mu skrzydła. Zostało podniesione z ziemi, postawione na nogach jak człowiek i dano mu serce ludzkie.
###### **Dn 7,5**
 Oto inne, drugie zwierzę, podobne do niedźwiedzia, było postawione na jednym boku. Trzy żebra miało w swej paszczy między zębami i tak mu powiedziano: Wstań i pożeraj dużo mięsa.
###### **Dn 7,6**
 Potem widziałem: Oto inne [zwierzę], jak pantera. Miało cztery skrzydła ptasie na swoim grzbiecie. Zwierzę miało cztery głowy i dano mu panowanie.
###### **Dn 7,7**
 Potem widziałem w widzeniach nocnych: Oto czwarte zwierzę, straszne, okropne, bardzo silne, zęby miało żelazne, ogromne, żarło, miażdżyło, resztę deptało swoimi nogami. Różniło się ono od wszystkich zwierząt, które były przed nim. Miało dziesięć rogów.
###### **Dn 7,8**
 Uważnie przyglądałem się rogom. Oto inny mały róg wyszedł spośród nich. Trzy z poprzednich rogów zostały wyrwane przed nim. Oto oczy, niby oczy ludzkie, były na tym rogu oraz usta głoszące wielkie rzeczy.
###### **Dn 7,9**
 Patrzyłem, aż wzniesiono trony, Starowieczny zasiadł. Jego szata była biała jak śnieg, a włosy Jego głowy jak czysta wełna. Jego tron - płomienie ognia, koła zaś Jego [tronu] - płonący ogień.
###### **Dn 7,10**
 Strumień ognia wypływał i tryskał przed Nim. Tysiąc tysięcy służyło Mu, a dziesięć tysięcy dziesiątków tysięcy stało przed Nim. Sąd zasiadł. Otworzono księgi.
###### **Dn 7,11**
 Patrzyłem wtedy z powodu głosu słów wielkich, jakie wypowiadał róg - patrzyłem aż do chwili, gdy zostało zabite zwierzę a jego ciało rozproszone i wydane na spalenie w ogniu.
###### **Dn 7,12**
 Reszcie zwierząt odebrano władzę i dano im przedłużenie życia aż do czasu i godziny.
###### **Dn 7,13**
 Widziałem w widzeniach nocnych: Oto z obłokami niebieskimi przybył jakby Syn Człowieczy, przyszedł aż do Starowiecznego i przyprowadzono Go przed Niego.
###### **Dn 7,14**
 I przekazana Mu została władza, majestat i królowanie. Wszystkie ludy, narody i języki służyły Mu. Jego władza jest wiecznym panowaniem, które nie przeminie, Jego zaś królestwo nie zniszczeje.
###### **Dn 7,15**
 Ja, Daniel, zatrwożyłem się w duchu z powodu tego, widzenia zaś mojej głowy przeraziły mnie.
###### **Dn 7,16**
 Zbliżyłem się do jednego ze stojących i poprosiłem go, [aby mi wyjawił] prawdę o tym wszystkim. Powiedział mi i oznajmił mi znaczenie [tych rzeczy]:
###### **Dn 7,17**
 Te wielkie zwierzęta - owe cztery - to czterej królowie, którzy powstaną z ziemi.
###### **Dn 7,18**
 Ale królestwo otrzymają święci Najwyższego, posiądą królestwo na zawsze, aż na wieki wieków.
###### **Dn 7,19**
 Wtedy chciałem wiedzieć prawdę o czwartym zwierzęciu, które różniło się od nich wszystkich, bardzo groźnym, o żelaznych zębach, pazurach z brązu, które pożerało i miażdżyło, a resztę deptało nogami;
###### **Dn 7,20**
 o dziesięciu rogach, które miało na swej głowie, i o innym, który powstał, a przed nim upadły trzy, oraz o owym rogu, który miał oczy i usta mówiące wielkie rzeczy, z wyglądu zaś był większy od swych przyjaciół.
###### **Dn 7,21**
 Widziałem, że róg ten prowadził wojnę ze świętymi i przemógł ich.
###### **Dn 7,22**
 Aż przybył Starowieczny i oddał sprawiedliwość świętym Najwyższego. Nadszedł czas i królestwo wzięli w posiadanie święci.
###### **Dn 7,23**
 Tak powiedział: - Czwarte zwierzę [oznacza] czwarte królestwo, [które] będzie na ziemi, odmienne od wszystkich królestw. Pożre całą ziemię, podepcze ją i zmiażdży.
###### **Dn 7,24**
 Dziesięć rogów oznacza dziesięciu królów, którzy powstaną z tego królestwa. Po nich powstanie inny, będzie on różny od poprzednich i poskromi trzech królów.
###### **Dn 7,25**
 Będzie mówił słowa przeciw Najwyższemu, będzie gnębił świętych Najwyższego, będzie chciał zmienić czasy i prawo, w jego ręce zostaną wydani aż do czasu i czasów, i połowy czasu.
###### **Dn 7,26**
 Ale sąd zasiądzie. Zostanie [mu] odebrana jego władza, aby została zniszczona i zatracona aż do końca.
###### **Dn 7,27**
 Królestwo i władza oraz wielkość królestw pod całym niebem będzie przekazana ludowi świętych Najwyższego. Jego królestwo będzie królestwem wiecznym. Jemu będą służyć i [Jego] słuchać wszystkie zwierzchności.
###### **Dn 7,28**
 Tu jest koniec rzeczy. Ja, Daniel, byłem bardzo przerażony moimi myślami. Zmienił się mój kolor [twarzy]. Rzecz zachowałem w moim sercu.
# Dn 7 BR
###### **Dn 7,21**
 I widziałem, jak ten róg walczył ze świętymi i jak odnosił nad nimi zwycięstwo.
###### **Dn 7,22**
 Aż pojawił się Przedwieczny i przeprowadzono sąd, przyznając rację świętym Najwyższego. A potem nadszedł czas i święci posiedli królestwo.
###### **Dn 7,28**
 Tak oto kończy się opis. Ja, Daniel, czułem się bardzo przygnębiony na duchu. Zmieniłem się na twarzy i długo nosiłem to wszystko w swoim sercu.
###### **Dn 7,23**
 I tak powiedział: Czwarta bestia - to będzie czwarte królestwo ziemskie, niepodobne do wszystkich innych królestw. Pochłonie ono całą ziemię, rzuci wszystko pod swoje nogi i zmiażdży.
###### **Dn 7,24**
 A oto znaczenie dziesięciu rogów: Z królestwa owego wyjdzie z czasem dziesięciu władców, a po nich pojawi się jeszcze jeden, całkiem inny niż wszyscy pozostali. On to pokona trzech spośród reszty władców.
###### **Dn 7,25**
 Będzie też bluźnił Najwyższemu i uciskał świętych Najwyższego. Będzie również usiłował zmienić czasy i Prawo, a święci zostaną wydani w jego ręce na czas, wiele czasów i pół czasu.
###### **Dn 7,26**
 A potem przyjdzie na niego sąd i zostanie pozbawiony władzy, będzie pokonany i starty z ziemi.
###### **Dn 7,27**
 Królestwo zaś i panowanie, i wszystko, co wielkie w tych królestwach pod słońcem, zostanie przekazane ludowi świętych Najwyższego. I na wieki trwać będzie Jego panowanie, a wszystkie królestwa służyć Mu będą, słuchając Jego rozkazów.
###### **Dn 7,1**
 W pierwszym roku panowania króla babilońskiego Baltazara, Daniel, znajdując się w swoim łożu, miał we śnie widzenie, które przedstawił na piśmie. Oto początek tego opisu:
###### **Dn 7,2**
 Miałem - mówi Daniel - takie widzenie w nocy: Cztery wichry spadające z nieba wzburzyły wielkie morze,
###### **Dn 7,3**
 z którego wyszły cztery ogromne bestie, każda z nich inna.
###### **Dn 7,4**
 Pierwsza była podobna do lwa, ale miała skrzydła jakby orła. Gdy się jej przypatrywałem, wyrwano jej skrzydła, a ona sama została uniesiona z ziemi i stanęła na [tylnych] nogach, tak że wyglądała jak człowiek. I otrzymała ludzkie serce.
###### **Dn 7,5**
 A oto druga bestia, wcale niepodobna do pierwszej. Wyglądała raczej jak niedźwiedź; była podparta z jednej strony, a w paszczy między zębami, miała trzy żebra. [Słyszałem, jak] do niej mówiono: Podnieś się i pożeraj dużo mięsa.
###### **Dn 7,6**
 Patrząc dalej zobaczyłem jeszcze jedną bestię, podobną do pantery, z czterema skrzydłami ptaka na grzbiecie. Miała także cztery głowy i widać było, że odznaczała się wielką siłą.
###### **Dn 7,7**
 Patrzyłem dalej i oto zobaczyłem w widzeniu nocnym czwartą bestię, była straszna, przerażająca i ogromnie silna. Miała wielkie zęby z żelaza. Żarła i pochłaniała wszystko, a co pozostawało, miażdżyła nogami. Wcale nie była podobna do trzech pierwszych bestii i miała dziesięć rogów.
###### **Dn 7,8**
 Kiedy patrzyłem właśnie na te rogi, zauważyłem, że spomiędzy nich wyrasta mały róg. Pierwsze trzy rogi przed nim zostały wyrwane, na tym zaś, który wyrastał, były oczy podobne do oczu ludzkich oraz usta, które wypowiadały rzeczy bardzo ważne.
###### **Dn 7,9**
 Patrząc dalej, zobaczyłem jak ustawiano trony i jak [na jednym z nich] zasiadł Przedwieczny. Jego szaty były białe jak śnieg, włosy zaś na Jego głowie - jakby z wełny najczystszej. Tron Jego był cały z ognistych płomieni i poruszał się na kołach, które także płonęły ogniem.
###### **Dn 7,10**
 Płynęła też cała rzeka ognista, wydobywająca się spod Niego. Tysiące tysięcy służyło Mu, dziesiątki zaś tysięcy innych stało przed Nim. Odbywał się sąd i już zostały otwarte księgi.
###### **Dn 7,11**
 Jeszcze miałem w uszach potężne odgłosy tego, co mówił róg, i oto na moich oczach bestia została zabita. Jej ciało wkrótce uległo zniszczeniu, zostało wrzucone do ognia.
###### **Dn 7,12**
 Pozostałym bestiom też odebrano władzę, ale życie przedłużono im jeszcze do czasu dokładnie określonego.
###### **Dn 7,13**
 I dalej przypatrywałem się temu, co mi się w nocy ukazywało: I oto zobaczyłem, jak zstępowała na obłokach z nieba postać jakby Syna Człowieczego. Zbliżył się on do Przedwiecznego i podprowadzono Go tuż przed Niego.
###### **Dn 7,14**
 I Jemu przekazał [Przedwieczny] władzę, chwałę i całe królestwo oraz wszystkie ludy, narody i języki. Swoją władzę będzie sprawował na wieki i nikt Mu jej nie odbierze, a Jego królestwo nie ulegnie zagładzie.
###### **Dn 7,15**
 Ja, Daniel, poczułem, że umysł mój ogarnia całkowite przygnębienie. Bardzo mnie bowiem zaniepokoiły widzenia senne.
###### **Dn 7,16**
 Podszedłem więc do jednego ze stojących tam mężów i poprosiłem, żeby mi wyjawił całą prawdę o tym wszystkim. On zaś, odpowiadając, tak mi wyjaśnił znaczenie tych rzeczy:
###### **Dn 7,17**
 Te cztery wielkie bestie - to czterej królowie, którzy pojawią się na ziemi.
###### **Dn 7,18**
 Królestwo jednak zostanie przekazane świętym Najwyższego. Otrzymają oni to królestwo na zawsze po wszystkie czasy.
###### **Dn 7,19**
 Potem chciałem się dowiedzieć, co oznacza czwarta bestia, różna od wszystkich pozostałych i przerażająca, o zębach z żelaza i szponach z brązu, bestia, która żarła i pochłaniała wszystko, miażdżąc nogami resztę.
###### **Dn 7,20**
 [Chciałem też wiedzieć], co oznacza dziesięć rogów na jej głowie oraz ten róg, który dopiero wyrastał, podczas gdy trzy pierwsze odpadły, a on sam miał oczy oraz usta, wypowiadające rzeczy wielkie, i wydawał się być znacznie większy niż pozostałe rogi.
# Dn 7 WUJ
###### **Dn 7,1**
 Roku pierwszego Balthazara króla Babilońskiego, Daniel widział sen: a widzenie głowy jego na łożu jego, i opisując sen krótką mową zamknął: a krótko dotykając, rzekł:
###### **Dn 7,2**
 Widziałem w widzeniu mojem w nocy, ano cztery wiatry niebieskie potykały się na morzu wielkiem:
###### **Dn 7,3**
 A cztery bestye wielkie występowały z morza różne od siebie.
###### **Dn 7,4**
 Pierwsza jako lwica, a miała skrzydła orle: patrzyłem aż wyrwane są skrzydła jej: i zdjęta jest z ziemie, a na nogi stanęła jako człowiek, i dano jej serce człowiecze.
###### **Dn 7,5**
 A oto bestya druga podobna niedźwiedziowi stanęła na stronie: a trzy rzędy były w gębie jej i między zębami jej: i tak jej mówiono: Wstań, jedz mięsa barzo wiele.
###### **Dn 7,6**
 Potymem patrzał a ono druga jako Ryś, a miała skrzydła jako ptak cztery na sobie, a cztery głowy były u bestyi, a władzą jej dano.
###### **Dn 7,7**
 Potem patrzałem w widzeniu nocnem, ano bestya czwarta straszna i dziwna, a barzo mocna: zęby żelazne miała wielkie, jedząc i krusząc, a ostatek nogami swemi depcąc: a była różna od innych bestyj, którem przed nią widział, i miała dziesięć rogów.
###### **Dn 7,8**
 Przypatrowałem się rogom, a oto róg inszy mały wyrósł z pośrodku ich: a trzy z rogów pierwszych wyłomione są od oblicza jego: a oto oczy, jako oczy człowiecze, były w owym rogu, i usta mówiące zbytnie wielkie rzeczy.
###### **Dn 7,9**
 Przypatrowałem się aż postanowiono stołki, a starowieczny usiadł: Szata jego biała jako śnieg, a włosy głowy jego jako wełna czysta: stolica jego płomienie ogniste: koła jej ogień rozpalony.
###### **Dn 7,10**
 Rzeka ognista a bystra wychodziła od oblicza jego: tysiąc tysięcy służyło mu, a po dziesięć tysięcy kroć sto tysięcy stało przy nim: zasiadł sąd, i księgi otworzono.
###### **Dn 7,11**
 Patrzyłem dla głosu mów wielkich, które on róg mówił: i widziałem, że była zabita bestya, i zginęło ciało jej, i dano je na spalenie ogniem:
###### **Dn 7,12**
 Inszych też bestyj władzą odjęto, i zamierzono im czasy żywota aż do czasu i czasu.
###### **Dn 7,13**
 Patrzyłem tedy w widzeniu nocnem, a oto z obłoki niebieskiemi jako syn człowieczy przychodził, i aż do staro wiecznego przyszedł: i stawili go przed oblicze jego.
###### **Dn 7,14**
 I dał mu władzą, i cześć, i królestwo: i wszyscy narodowie pokolenia i języki służyć mu będą: władza jego władza wieczna, która nie będzie odjęta: a królestwo jego, które się nie skazi.
###### **Dn 7,15**
 Zląkł się duch mój, ja Daniel byłem przestraszony temi rzeczami, a widzenia głowy mojej strwożyły mię.
###### **Dn 7,16**
 Przystąpiłem do jednego z stojących, i pytałem się u niego prawdy o tem wszystkiem: który mi powiedział wykład mów.
###### **Dn 7,17**
 I nauczył mię: Te cztery bestye wielkie, są cztery królestwa, które powstaną z ziemie.
###### **Dn 7,18**
 A przyjmą królestwo świętego Boga nawyższego, i odzierżą królestwo aż na wieki, i na wiek wieków.
###### **Dn 7,19**
 Potem chciałem się pilnie wywiedzieć o bestyi czwartej, która była barzo różna od wszystkich, i nazbyt straszna: zęby i paznokcie jej żelazne, jadła i kruszyła, a ostatek nogami swemi deptała.
###### **Dn 7,20**
 I o dziesiąci rogach, które miała na głowie: i o drugim, który był urósł, przed którym upadły trzy rogi: i o onym rogu, który miał oczy i usta mówiące wielkie rzeczy, a był więtszy nad inne.
###### **Dn 7,21**
 Patrzyłem ano on róg walczył przeciw świętym, i przemagał je,
###### **Dn 7,22**
 Aż przyszedł starowieczny, i dał sąd świętym wysokiego, i czas przyszedł, i święci odzierżeli królestwo.
###### **Dn 7,23**
 I tak rzekł: Bestya czwarta, królestwo czwarte będzie na ziemi, które będzie więtsze niż wszystkie królestwa, i pożre wszystkę ziemię, i podepcze i zetrze ją.
###### **Dn 7,24**
 A dziesięć rogów tego królestwa, dziesięć królów będzie: a drugi powstanie po nich, a on będzie mocniejszy nad pierwsze, i trzech królów zniży.
###### **Dn 7,25**
 A będzie mówił mowy przeciw wysokiego, i święte nawyższego skruszy: i będzie się mu zdało, że może odmienić czasy i prawa, a będą podani w ręce jego aż do czasu, i czasów, i pół czasu.
###### **Dn 7,26**
 I zasiądzie sąd, aby była od jęta moc, i był zstart, i zginął aż do końca.
###### **Dn 7,27**
 A królestwo, i władzą, i wielkość królestwa, która jest pod wszystkiem niebem, żeby dano ludowi świętych Nawyższego: którego królestwo, królestwo wieczne jest, a wszyscy królowie będą mu służyć, i słuchać go.
###### **Dn 7,28**
 Póty koniec słowa. Ja Daniel wielcem się myślami niemi trwożył, i oblicze moje zmieniło się na mnie: a słowo zachowałem w sercu mojem.
