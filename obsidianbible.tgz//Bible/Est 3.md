# Est 3 BT5
###### **Est 3,1**
 Po tych wydarzeniach król Aswerus uczynił wielkim Hamana, syna Hammedaty, Agagitę, wywyższył go i umieścił jego tron ponad wszystkimi książętami, którzy przy nim byli.
###### **Est 3,2**
 Wszyscy słudzy króla, którzy stali w bramie, klękali i oddawali pokłon Hamanowi, ponieważ taki rozkaz wydał król co do jego osoby. A Mardocheusz nie klękał i nie oddawał pokłonu.
###### **Est 3,3**
 Wtedy stojący w bramie słudzy królewscy powiedzieli Mardocheuszowi: «***Dlaczego przestępujesz polecenie króla?***»
###### **Est 3,4**
 Mówili do niego tak codziennie, ale on ich nie słuchał. Powiedzieli więc Hamanowi, aby się przekonać, czy trwałe będą postanowienia Mardocheusza, ponieważ wyznał im, że jest Żydem.
###### **Est 3,5**
 A Haman zauważył, że Mardocheusz nie klęka ani nie oddaje pokłonu; napełnił się więc Haman gniewem.
###### **Est 3,6**
 Uważał jednak za niegodne podnieść rękę na samego tylko Mardocheusza, ponieważ powiedziano mu o narodzie Mardocheusza. Szukał więc Haman sposobności, aby w całym królestwie Aswerusa wytępić wszystkich Żydów, naród Mardocheusza.
###### **Est 3,7**
 Od pierwszego miesiąca, to jest miesiąca Nisan, w dwunastym roku [panowania] króla Aswerusa rzucano Pur, to jest los, w obecności Hamana na każdy dzień i na każdy miesiąc aż do dwunastego miesiąca Adar.
###### **Est 3,8**
 Potem rzekł Haman do króla Aswerusa: «***Jest pewien naród rozproszony i odłączony od narodów we wszystkich państwach królestwa twego, a prawa jego są inne niż każdego innego narodu. Praw króla oni nie wykonują i w interesie króla leży, aby ich nie zostawić w spokoju.***
###### **Est 3,9**
 ***Jeśli król uzna to za słuszne, niech wyda dekret, aby ich wytracić, a ja wpłacę na ręce urzędników dziesięć tysięcy talentów srebra, aby je przelano do skarbca królewskiego***».
###### **Est 3,10**
 Na to król zdjął sygnet z ręki swojej i dał go Hamanowi, synowi Hammedaty, Agagicie, wrogowi Żydów.
###### **Est 3,11**
 I powiedział król do Hamana: «***Niech będzie ci dane srebro i ten lud, abyś uczynił z nim to, co wydaje się słuszne w twoich oczach***».
###### **Est 3,12**
 Zawołano pisarzy królewskich w miesiącu pierwszym dnia trzynastego i napisano wszystko, co rozkazał Haman, do satrapów króla i do namiestników, którzy stali na czele wszystkich państw, oraz do książąt poszczególnych narodów; napisano do każdego państwa jego pismem i do poszczególnych narodów w ich języku w imieniu króla Aswerusa i opieczętowano sygnetem królewskim.
###### **Est 3,13**
 Potem wysłano listy przez gońców do wszystkich państw króla, aby wygubić i wybić, i wytracić wszystkich Żydów od chłopca do starca, dzieci i kobiety, w tym samym trzynastym dniu dwunastego miesiąca, to jest miesiąca Adar, a majątek ich skonfiskować.
###### **Est 3,14**
 Odpis pisma został dostarczony wszystkim państwom jako ustawa i ogłoszono wszystkim narodom, aby były gotowe na ten dzień.
###### **Est 3,15**
 Gońcy pobiegli przynaglani rozkazem królewskim, a dekret ogłoszono na zamku w Suzie. Król i Haman siedzieli i pili, miasto zaś Suza było bezradne.
###### **Est 3,13a**
 Odpis dekretu brzmi następująco: «***Wielki król Artakserkses pisze do książąt i rządców stu dwudziestu siedmiu państw, od Indii aż po Etiopię:***
###### **Est 3,13b**
***Gdy zapanowałem nad licznymi narodami i gdy podbiłem cały świat, nie nadużywając swojej władzy, lecz z łaskawością i łagodnością stale sprawując rządy, chciałem zawsze bez zakłóceń normować życie podwładnych, zapewnić królestwu spokój i bezpieczeństwo aż po jego krańce i przywrócić wszystkim ludom upragniony pokój.***
###### **Est 3,13c**
  ***Gdy pytałem moich doradców, jak by to można dokładnie przeprowadzić, Haman, który wyróżniał się przy nas mądrością i niezmiernie przychylnym usposobieniem oraz odznaczał się niezachwianą wiernością, zajmując drugie miejsce w królestwie,***
###### **Est 3,13d**
***wskazał nam, że wmieszał się pomiędzy inne szczepy całego świata pewien naród wrogo [do pozostałych] usposobiony, który przez swoje prawa sprzeciwia się wszystkim narodom i stale lekceważy zarządzenia królów, tak iż stanowi przeszkodę w rządach nienagannie sprawowanych przez nas nad całością.***
###### **Est 3,13e**
***Przekonawszy się, że jedynie ten naród pozostaje ze wszystkimi w stałej niezgodzie, że trzyma się osobno na skutek swych praw, że stale nieżyczliwy jest dla naszych zarządzeń, spełniając najgorsze czyny, tak iż państwo nigdy nie będzie mogło dojść do wewnętrznego pokoju,***
###### **Est 3,13f**
***rozkazaliśmy, aby osoby wymienione w pismach Hamana, który jest przełożonym nad sprawami państwa i drugim ojcem naszym – aby wszyscy ci wraz z żonami i dziećmi wyginęli doszczętnie od miecza przeciwników, bez żadnej litości i oszczędzania, czternastego dnia dwunastego miesiąca Adar, roku bieżącego.***
###### **Est 3,13g**
***I aby od dawna nieżyczliwie usposobieni w jednym dniu przemocą zesłani zostali do Hadesu i w ten sposób na przyszłość zapewnili nam zawsze bezpieczne i niczym nie zamącone sprawowanie rządów w państwie***».
# Est 3 PAU
###### **Est 3,1**
 Po tych wydarzeniach król Artakserkses wyróżnił szczególnie Hamana Pyszałka, syna Hammedaty, dając mu pierwsze miejsce w gronie swoich przyjaciół.
###### **Est 3,2**
 Wszyscy pełniący służbę na dziedzińcu oddawali mu pokłon, bo król tak nakazał. Tylko Mardocheusz nie oddawał mu pokłonu.
###### **Est 3,3**
 Dlatego obecni na dziedzińcu królewskim pytali go: „Mardocheuszu, dlaczego naruszasz nakaz króla?”.
###### **Est 3,4**
 Rozmawiali z nim każdego dnia, ale ich nie słuchał. Wreszcie donieśli Hamanowi, że Mardocheusz nie zachowuje poleceń króla, a Mardocheusz przyznał się im, że jest Żydem z pochodzenia.
###### **Est 3,5**
 Gdy Haman dowiedział się, że Mardocheusz nie oddaje mu pokłonu, uniósł się wielkim gniewem
###### **Est 3,6**
 i postanowił wytracić wszystkich Żydów żyjących w królestwie Artakserksesa.
###### **Est 3,7**
 W dwunastym roku panowania Artakserksesa powziął to postanowienie i rzucił losy, by wybrać dzień spośród wszystkich dni i miesiąc spośród miesięcy, kiedy to jednego dnia zostanie zgładzony naród Mardocheusza. A los wskazał na czternasty dzień miesiąca Adar.
###### **Est 3,8**
 Wówczas Haman odbył rozmowę z królem Artakserksesem i tak powiedział: „Jest pewien naród, rozproszony wśród narodów całego twego królestwa. Jego prawa różnią się od praw pozostałych narodów i lekceważą oni prawa królewskie. Dlatego nie służy to królowi, że żyją oni w spokoju.
###### **Est 3,9**
 Jeśli więc król uzna to za słuszne, niech zdecyduje o ich zagładzie, a ja przekażę dziesięć tysięcy talentów srebra do skarbca królewskiego”.
###### **Est 3,10**
 Król zdjął pierścień i przekazał go Hamanowi, aby opieczętował nim dekret przeciwko Żydom.
###### **Est 3,11**
 Potem rzekł do Hamana: „Pieniądze zatrzymaj, a z tym narodem postąpię zgodnie z twoją wolą”.
###### **Est 3,12**
 W trzynastym dniu pierwszego miesiąca wezwano pisarzy królewskich, którzy w imieniu króla Artakserksesa napisali, co rozkazał Haman, do dowódców i do namiestników wszystkich okręgów od Indii aż do Etiopii, do stu dwudziestu siedmiu okręgów i do książąt poszczególnych narodów, do każdego w ich własnym języku.
###### **Est 3,13**
 Następnie rozesłano kurierów po całym królestwie Artakserksesa, by w dwunastym miesiącu, a był to miesiąc Adar, jednego dnia zgładzić naród żydowski, a jego mienie zagrabić. (a) Oto odpis dekretu: „Tak pisze wielki król Artakserkses do namiestników w stu dwudziestu siedmiu okręgach, od Indii aż do Etiopii, i do podległych im książąt: (c) Zapytałem więc moich doradców, jak można osiągnąć ten cel, a wtedy Haman, wyróżniający się u nas roztropnością i stałością, a także wypróbowaną wiernością, zajmujący drugie miejsce w królestwie, (d) uświadomił nam, że wśród wszystkich plemion na ziemi żyje pewien lud, zmieszany z innymi, który kierując się swoimi prawami, sprzeciwia się każdemu narodowi, a wydawane przez króla rozporządzenia stale lekceważy. Nie służy to rządom, które my sprawujemy w sposób nienaganny. (e) Przekonaliśmy się, że naród ten jako jedyny odnosi się wrogo do każdego człowieka, izoluje się z racji swoich praw i nie włącza się w nasze sprawy. Nieprzychylnie do nich nastawiony dopuszcza się najokropniejszych rzeczy i dlatego w królestwie nie może zapanować spokój. (f) Rozkazaliśmy więc, aby w czternastym dniu dwunastego miesiąca tego właśnie roku, to jest miesiąca Adar, bezlitośnie i nie kierując się żadnymi względami, doszczętnie wyniszczyć mieczem wszystkich wymienionych w dekrecie wielkorządcy Hamana, który jest naszym drugim ojcem. Zgładzić ich trzeba wraz z ich kobietami i dziećmi, (g) aby ci, którzy niegdyś byli i teraz są wrogo usposobieni, tego samego dnia przemocą zstąpili do krainy umarłych. Dzięki temu będziemy w przyszłości zarządzać naszymi sprawami bezpiecznie i w spokoju”.
###### **Est 3,14**
 Odpisy dekretu zostały obwieszczone w każdym okręgu, a wszystkim narodom nakazano, aby się przygotowały na ten dzień.
###### **Est 3,15**
 Ogłoszono to również w Suzie. Król i Haman pili bez umiaru, a miasto było niespokojne.
# Est 3 BP
###### **Est 3,1**
 Po tych wydarzeniach król Achaszwerosz wywyższył Hamana, syna Hammedaty, Agagitę, a wyróżniając go, wyniósł do godności wyższej niż wszystkich innych książąt, którzy byli w jego otoczeniu.
###### **Est 3,2**
 Wszyscy dworzanie, pełniący służbę przy bramie Królewskiej, zginali kolana i bili pokłony przed Hamanem, bo tak rozkazał król; lecz Mardocheusz nie zginał kolan ani nie bił pokłonów.
###### **Est 3,3**
 Słudzy królewscy, czuwający u bramy Królewskiej, mówili do Mardocheusza: Dlaczego przekraczasz rozkaz królewski?
###### **Est 3,4**
 A codziennie mu to powtarzali, on zaś ich nie słuchał. Donieśli więc o tym Hamanowi, aby się przekonać, czy Mardocheusz wytrwa w swym postanowieniu, ponieważ im wyjawił, że jest Żydem.
###### **Est 3,5**
 A gdy Haman stwierdził, że Mardocheusz ani nie zgina kolan, ani nie bije przed nim pokłonów, wpadł w wielki gniew.
###### **Est 3,6**
 Uznał jednak, że zbyt małą rzeczą byłoby podnieść rękę na samego tylko Mardocheusza, ponieważ doniesiono mu, z jakiego narodu Mardocheusz pochodzi. Przemyśliwał więc nad tym, jak razem z Mardocheuszem wytracić wszystkich Żydów osiadłych w całym królestwie Achaszwerosza.
###### **Est 3,7**
 Pierwszego tedy miesiąca - a był to miesiąc Nizan - roku dwunastego panowania Achaszwerosza rozpoczęto rzucać w obecności Hamana pur, to jest los, dzień po dniu i z miesiąca na miesiąc, aż los padł na trzynasty dzień dwunastego miesiąca, to jest na miesiąc Adar.
###### **Est 3,8**
 Wówczas rzekł Haman do króla Achaszwerosza: Wśród ludów wszystkich prowincji twojego królestwa żyje pewien lud [rozproszony] w odosobnieniu od innych narodów. Prawa jego są zupełnie inne niż u wszystkich ludów, praw zaś królewskich nie przestrzega. Nie jest to zgodne z interesami króla, by żył sobie spokojnie.
###### **Est 3,9**
 Jeżeli król uzna to za słuszne, niech zostanie wydany rozkaz na piśmie, aby ich wytracono. [W zamian za to] jestem gotów odważyć dziesięć tysięcy talentów srebra na ręce urzędników królewskich, aby je odprowadzili do skarbca królewskiego.
###### **Est 3,10**
 Na to ściągnął król ze swojej ręki pierścień i dał go Hamanowi, synowi Hammedaty, Agagicie, prześladowcy Żydów,
###### **Est 3,11**
 i rzekł do niego: Srebro? Pozostawiam ci srebro i lud - uczyń z nim, cokolwiek uznasz za słuszne.
###### **Est 3,12**
 Wezwano więc pisarzy królewskich na dzień trzynasty miesiąca pierwszego i zgodnie ze wszystkimi poleceniami Hamana wystosowano rozkaz do satrapów królewskich i zarządców poszczególnych prowincji i do książąt każdego z ludów pismem używanym przez poszczególne prowincje i w języku, którym posługiwały się poszczególne ludy. Rozkaz ten napisano w imieniu króla Achaszwerosza i przypieczętowano pierścieniem królewskim.
###### **Est 3,13**
 Następnie rozesłano pisma za pośrednictwem gońców do wszystkich prowincji królewskich [nakazując], aby zgładzono i wymordowano, i wytracono wszystkich Żydów, od młodzieńca aż do starca, dzieci i niewiasty, jednego i tego samego dnia to jest trzynastego miesiąca dwunastego - był to miesiąc Adar - i aby mienie ich zabrano jako łup. Według LXX: B3.13a-13g 13a Tekst pisma jest następujący: "Wielki król Artakserkses pisze do książąt stu dwudziestu siedmiu prowincji, [rozciągających się] od Indii aż do Etiopii, i do podległych im zarządców, co następuje: 13b Ponieważ otrzymałem władzę nad licznymi narodami i panowanie nad całym światem, postanowiłem - nie nadużywając potęgi mej władzy, ale kierując się zawsze w mych rządach łagodnością i dobrocią - umożliwić moim poddanym pod każdym względem niezakłócone życie, a zapewniwszy całemu państwu pokój i pomyślność aż po najdalsze granice, użyczyć wszystkim ludziom upragnionego pokoju. 13c Gdym się pytał doradców, w jaki sposób można by ten cel urzeczywistnić, Aman, który wyróżnia się u nas mądrością, a także odznacza się wypróbowaną wiernością, i który zajmuje drugie po mnie miejsce na dworze królewskim, 13d wyjawił nam, że pośród wszystkich plemion świata żyje zmieszany z nimi pewien nieprzyjazny innym lud, z powodu swych praw wrogi wszystkim innym narodom, który z reguły odnosi się ze wzgardą do rozporządzeń królów, tak że mimo nienagannie sprawowanych przez nas rządów nie możemy zapewnić państwu ładu. 13e Ponieważ przekonaliśmy się, że jedynie ten naród pozostaje w niezgodzie z całym rodzajem ludzkim, że żyje w odosobnieniu na skutek stosowania dziwacznych zwyczajów, że jest wrogo usposobiony do naszych spraw, że dopuszcza się najgorszych czynów, tak że w państwie nigdy nie będzie można zaprowadzić wewnętrznego spokoju, 13f nakazaliśmy, aby wszystkich wymienionych w listach Amana - na którym ciąży odpowiedzialność za sprawy państwa i który jest naszym drugim ojcem - wraz z żonami i z dziećmi doszczętnie zniszczyć przez ich przeciwników bez żadnej litości i bez pobłażania dnia czternastego dwunastego miesiąca, to jest miesiąca Adar bieżącego roku, 13g ażeby ci, tak niegdyś jak i obecnie wrogo [do wszystkich] usposobieni, siłą zostali wtrąceni do królestwa umarłych jednego i tego samego dnia i [tak] abyśmy w przyszłości mogli w spokoju i bez przeszkód kierować sprawami królestwa".
###### **Est 3,14**
 Treść tego dekretu, który miał być ogłoszony w każdej prowincji jako prawo, skierowana była do wszystkich narodów, aby były gotowe na oznaczony dzień.
###### **Est 3,15**
 Gońcy śpiesznie ruszyli w drogę, gnani rozkazem królewskim. Dekret ten ogłoszono także w stolicy Suzie. A gdy król i Haman siedzieli ucztując, na miasto Suza padło przerażenie.
# Est 3 BR
###### **Est 3,1**
 Po tym wszystkim wyróżnił król Aswerus w sposób szczególny Agagitę Hamana, syna Hammedaty, przyznając mu najwyższą rangę wśród otaczających go książąt.
###### **Est 3,2**
 Wszyscy słudzy królewscy pełniący straż przy bramie pałacowej klękali przed Hamanem i oddawali mu niskie pokłony. Kazał im król w ten sposób czcić Hamana. Tylko Mardocheusz nie kłaniał się przed nim i nie oddawał mu czci.
###### **Est 3,3**
 Powiedzieli tedy do Mardocheusza słudzy trzymający straż przy bramie pałacowej: Dlaczego nie przestrzegasz zarządzenia króla?
###### **Est 3,4**
 I stawiali mu to pytanie każdego dnia, ale on wcale ich nie słuchał. W końcu powiedzieli o tym samemu Hamanowi; chcieli się bowiem przekonać, czy wyjaśnienie Mardocheusza, że jest Żydem, zostanie uznane za wystarczające.
###### **Est 3,5**
 A Haman bardzo się rozgniewał, kiedy sam zobaczył, że Mardocheusz nie kłania się przed nim i nie oddaje mu czci.
###### **Est 3,6**
 Nie uważał jednak, że był to powód dostateczny, by podnosić rękę na Mardocheusza, postanowił Haman wyniszczyć wszystkich Żydów w całym królestwie Aswerusa, wygnać cały naród Mardocheusza.
###### **Est 3,7**
 Pierwszego miesiąca, to jest miesiąca Nisan, w dwunastym roku panowania króla Aswerusa, w obecności Hamana, rzucono pur to znaczy losy, żeby określić dzień i miesiąc [rozpoczęcia zagłady Żydów]. I padł los na dzień trzynasty dwunastego miesiąca Adar.
###### **Est 3,8**
 Potem rzekł Haman do króla Aswerusa: Jest pewien naród, który przeniknął do wszystkich prowincji twojego królestwa, ale żyje w sposób inny niż wszystkie pozostałe ludy. Jego prawa są odmienne od praw wszystkich innych narodów, a prawom królewskim się nie podporządkowuje. Nie jest dobrze, że król zezwala im na to wszystko.
###### **Est 3,9**
 Jeśli król uzna za słuszne, niech raczy wydać dekret na piśmie, aby ich wszystkich zgładzono. Wówczas ja sam przekażę skarbnikom dziesięć talentów srebra, przeznaczonych do skarbców królewskich.
###### **Est 3,10**
 Wtedy zdjął król ze swego palca pierścień z pieczęcią i wręczył go Agagicie Hamanowi, synowi Hammedaty, wrogowi Żydów.
###### **Est 3,11**
 Powiedział przy tym do Hamana: Zatrzymaj sobie swoje srebro, a z tym ludem zrób co ci się podoba.
###### **Est 3,12**
 Trzynastego dnia pierwszego miesiąca zostali wezwani pisarze królewscy. Skierowano do satrapów królewskich, do zarządców poszczególnych prowincji i do książąt poszczególnych narodów, spisane własnym pismem każdego z nich oraz we własnym języku każdego, nakazując wykonanie tego wszystkiego, czego domagał się Haman. Dekret został wydany w imieniu króla Aswerusa i opieczętowany pierścieniem z pieczęcią króla.
###### **Est 3,13**
 Przez specjalnych gońców rozesłano do wszystkich to pismo z takim oto poleceniem: Tego samego dnia, mianowicie dnia trzynastego dwunastego miesiąca, czyli miesiąca Adar, wszystkich Żydów, młodych i starych, a także dzieci i kobiety należy wymordować i zabrać całe ich mienie. (a) A oto odpis tego zarządzenia: Wielki król Aswerus - do zarządców stu dwudziestu siedmiu prowincji, poczynając od Indii aż po Etiopię, i do wszystkich podległych mu władców. (b) Sprawując władzę nad wielu narodami i krajami całego świata, postanowiłem nie kierować się wygórowaną żądzą władzy, lecz towarzyszącą mi zawsze troską o to, aby być dla wszystkich łaskawym i dobrym. Pragnąłem zapewnić moim podwładnym życie pod każdym względem spokojne, a całemu państwu - rozwój aż do jego granic. Chciałem przywrócić wszystkim ludziom upragniony pokój. (c) Kiedy zapytałem moich doradców, jak to można osiągnąć, wystąpił Haman, który wyróżniał się u nas mądrością, niezmiennie szlachetną życzliwością oraz niezachwianą wiernością, a w państwie zajmował drugie co do ważności miejsce. (d) On to radził zwrócić uwagę na to, że pomiędzy wszystkie narody świata przeniknął jeden bardzo podstępny lud, który ze względu na swoje prawa jest nieprzyjaźnie usposobiony do wszystkich pozostałych narodów. Lud ten lekceważy ciągle zarządzenia naszego króla, co utrudnia kierowanie całym państwem, choć jak dotąd rządy są sprawowane nienagannie. (e) Doszliśmy też jednomyślnie do przekonania, że lud ten jako jedyny jest nastawiony wrogo do wszystkich bez wyjątku; że trzyma się dziwnych i całkiem obcych nam zwyczajów; że działa na szkodę naszego państwa i dopuszcza się najgorszych wykroczeń i że wskutek tego nigdy nie będzie w państwie prawdziwego porządku i ładu. (f) Dlatego wydaliśmy taki oto rozkaz: Wszyscy ci, których Haman, kierujący sprawami państwa, nasz drogi ojciec, opisał dokładniej w swoim liście, wszyscy ci, razem ze swymi kobietami i dziećmi, bez żadnych ułaskawień i miłosierdzia, winni zginąć od miecza swych przeciwników czternastego miesiąca Adar tego roku. (g) W ten sposób zginą jednego dnia nagłą śmiercią i odejdą do świata zmarłych wszyscy owi ludzie od niepamiętnych czasów tak wrogo nastawieni do innych. Dopiero wtedy kraj nasz będzie mógł liczyć na trwały i niezmącony pokój w przyszłości.
###### **Est 3,14**
 Do każdej prowincji zostało posłane takie pismo, a jego treść ogłoszono jako prawo, tak aby wszystkie narody były przygotowane na ten dzień.
###### **Est 3,15**
 Gońcy rozjechali się na wszystkie strony, przynaglani oddzielnym rozkazem do pośpiechu. Kiedy zaś dekret królewski ogłaszano na zamku w Suzie, król i Haman siedzieli razem i pili. Całe miasto Suza było bardzo poruszone.
# Est 3 WUJ
###### **Est 3,1**
 Potem król Asswerus wywyższył Amana syna Amathy, który był z rodu Agag: i wystawił stolicę jego nade wszystkie książęta które miał.
###### **Est 3,2**
 I wszyscy słudzy królewscy, którzy we drzwiach pałacu byli, klękali i kłaniali się Amanowi, bo im tak był Pan rozkazał. Sam Mardocheusz nie klękał, ani mu się kłaniał.
###### **Est 3,3**
 Któremu rzekli słudzy królewscy, którzy przede drzwiami pałacu siadali: Przecz mimo insze nie zachowujesz przykazania królewskiego?
###### **Est 3,4**
 A gdy to często mawiali, a on słuchać nie chciał, powiedzieli Amanowi, chcąc wiedzieć, będzieli trwał w przedsięwzięciu: bo im był powiedział, że był żydem.
###### **Est 3,5**
 Co gdy usłyszał Aman, i samą rzeczą doznał, że Mardocheusz nie klękał przed nim, ani mu się kłaniał, rozgniewał się barzo.
###### **Est 3,6**
 I za nic sobie nie miał na jednego Mardocheusza puścić ręce swe, bo był usłyszał, że był narodu żydowskiego, i raczej chciał wytracić wszystek naród żydów, którzy byli w królestwie Asswerusowem.
###### **Est 3,7**
 Miesiąca pierwszego (który zowią Nisan) roku dwunastego królestwa Asswerusowego, rzucono los w banię, który po Hebrejsku zowią Phur, przed Amanem, któregoby dnia, i którego miesiąca naród Żydowski miał być wygubiony, i wyszedł księżyc dwunasty, który zowią Adar.
###### **Est 3,8**
 I rzekł Aman królowi Asswerusowi: Jest lud po wszystkich krainach królestwa twego rozproszony, i sam od siebie różny, nowych praw i ceremonij używający, nadto i królewskim rozkazaniem gardzący. A wiesz barzo dobrze że nie jest pożyteczno królestwu twojemu, aby się miał rozpuszczać przez swą wolą.
###### **Est 3,9**
 Jeślić się podoba wydaj wyrok, aby zginął, a dziesięć tysięcy talentów odważę podskarbim skarbu twego.
###### **Est 3,10**
 Zdjął tedy król sygnet, którego używał, z ręki swej, i dał go Amanowi synowi Amadathy z narodu Agag, nieprzyjacielowi Żydowskiemu,
###### **Est 3,11**
 I rzekł do niego: Srebro, które mi obiecujesz, niech twoje będzie, z ludem czyń coć się podoba.
###### **Est 3,12**
 I przyzwano pisarzów królewskich, pierwszego miesiąca Nisan, trzynastego dnia tegoż miesiąca: i napisano jest jako był rozkazał Aman, do wszystkich książąt królewskich, i sędziów krain, i rozmaitych narodów, aby każdy naród czytać mógł, i słyszeć mógł, według różności języków, imieniem króla Asswerusa: a listy zapieczętowane sygnetem jego,
###### **Est 3,13**
 Rozesłano przez posły królewskie do wszystkich ziem, aby pobito i wygładzono wszystkie Żydy, od dziecięcia aż do starca, dziatki i niewiasty jednego dnia, to jest trzynastego, miesiąca dwunastego, który zowią Adar, a majętność ich, aby rozszarpali.
###### **Est 3,14**
 A summa listów ta była, aby wszystkie krainy wiedziały, a nagotowały się na dzień przerzeczony.
###### **Est 3,15**
 Spieszyli się posłowie, których było posłano, aby rozkazanie królewskie wypełnili. I natychmiast w Susan przybito wyrok, gdy król i Aman biesiadowali, a wszyscy Żydowie, którzy byli w mieście płakali.
