# 1Mch 2 BT5
###### **1Mch 2,1**
 W tym czasie wystąpił Matatiasz, syn Jana, syna Symeona, kapłan z pokolenia Joariba z Jerozolimy, który mieszkał w Modin.
###### **1Mch 2,2**
 Miał on pięciu synów: Jana zwanego Gaddi,
###### **1Mch 2,3**
 Szymona zwanego Tassi;
###### **1Mch 2,4**
 Judę zwanego Machabeusz;
###### **1Mch 2,5**
 Eleazara zwanego Auaran i Jonatana zwanego Apfus.
###### **1Mch 2,6**
 Kiedy zobaczył on świętokradztwa, które się działy wśród ludu w Judzie i w Jerozolimie,
###### **1Mch 2,7**
 powiedział:«***Biada mi! Dlaczego się urodziłem? Czy po to, żeby oglądać upadek mego narodui  upadek Świętego Miasta i przebywać tam, podczas gdy zostało ono wydane w ręce nieprzyjaciół, a świątynia w ręce cudzoziemców?***
###### **1Mch 2,8**
 ***Świątynia jego stała się podobna do człowieka bez czci,***
###### **1Mch 2,9**
 ***a wspaniałe jej naczynia zabrano do niewoli. Małe jego dzieci mordowano na ulicach, młodzieńców – mieczem wroga.***
###### **1Mch 2,10**
 ***Jakiż naród nie przywłaszczał sobie jego praw królewskich i siłą nie zabierał z niego łupów!***
###### **1Mch 2,11**
 ***Wszystkie jego ozdoby zrabowano; niegdyś wolne – stało się niewolnikiem.***
###### **1Mch 2,12**
 ***I oto wniwecz obrócona jest świętość nasza, piękność nasza i chwała nasza, a poganie je zbezcześcili.***
###### **1Mch 2,13**
 ***Po cóż więc nam jeszcze żyć?***»
###### **1Mch 2,14**
 Matatiasz i jego synowie rozdarli swoje szaty, przyoblekli się w wory i gorzko płakali.
###### **1Mch 2,15**
 Wtedy do miasta Modin przybyli królewscy wysłańcy, którzy zmuszali do odstępstwa przez uczestnictwo w składaniu ofiary.
###### **1Mch 2,16**
 Wielu spomiędzy Izraelitów przyszło do nich. A Matatiasz i jego synowie zebrali się razem.
###### **1Mch 2,17**
 Wtedy królewscy wysłańcy zwrócili się do Matatiasza ze słowami: «***Ty jesteś zwierzchnikiem, sławnym i wielkim w tym mieście, a podtrzymują cię synowie i krewni.***
###### **1Mch 2,18**
 ***Teraz więc ty pierwszy przystąp i wykonaj zarządzenie króla, tak jak wykonały wszystkie narody, mieszkańcy Judy i ci, którzy pozostali w Jeruzalem, a ty i twoi synowie będziecie należeli do królewskich przyjaciół, ty i synowie twoi będziecie zaszczyceni darami w srebrze i złocie oraz innymi podarunkami***».
###### **1Mch 2,19**
 Na to jednak Matatiasz odpowiedział donośnym głosem: «***Jeżeli nawet wszystkie narody, które należą do państwa podległego królowi, słuchają go, odstąpiwszy od kultu swych ojców, i zgodziły się na jego nakazy,***
###### **1Mch 2,20**
 ***to jednak ja, moi synowie i moi krewni będziemy postępowali zgodnie z przymierzem, które zawarli nasi ojcowie.***
###### **1Mch 2,21**
 ***Niech nas [Bóg] broni od przekroczenia Prawa i jego nakazów!***
###### **1Mch 2,22**
 ***Słów króla nie będziemy słuchali i od kultu naszego nie odstąpimy ani w prawo, ani w lewo***».
###### **1Mch 2,23**
 Zaledwie skończył mówić te słowa, pewien Żyd przystąpił na oczach wszystkich do ołtarza w Modin, ażeby złożyć ofiarę, zgodnie z zarządzeniem króla.
###### **1Mch 2,24**
 Gdy zobaczył to Matatiasz, zapłonął gorliwością i zadrżały mu nerki, i zawrzał gniewem, który był słuszny. Pobiegł więc i zabił tamtego obok ołtarza.
###### **1Mch 2,25**
 Przy tej sposobności zabił także urzędnika królewskiego, który zmuszał do składania ofiar, ołtarz zaś rozwalił.
###### **1Mch 2,26**
 Zapałał gorliwością o Prawo, jak to uczynił Pinchas z Zambrim, synem Salu.
###### **1Mch 2,27**
 Wtedy też Matatiasz zaczął w mieście wołać donośnym głosem: «***Niech idzie za mną każdy, kto płonie gorliwością o Prawo i obstaje za przymierzem***».
###### **1Mch 2,28**
 Potem zaś on sam i jego synowie uciekli w góry, pozostawiając w mieście wszystko, co posiadali.
###### **1Mch 2,29**
 Wtedy wielu spośród ludzi, którzy szukali tego, co sprawiedliwe i słuszne, udało się na pustynię, aby tam przebywać
###### **1Mch 2,30**
 razem ze swoimi dziećmi, żonami i bydłem, bo zwaliły się na nich nieszczęścia.
###### **1Mch 2,31**
 Urzędnikom zaś królewskim i wojsku, które było w Jeruzalem, mieście Dawidowym, doniesiono, że ludzie, którzy wzgardzili królewskim rozkazem, poszli na pustynię do kryjówek.
###### **1Mch 2,32**
 Wielu więc udało się za nimi w pościg, a kiedy ich napotkali, rozłożyli się obozem naprzeciwko nich. Potem rozpoczęli z nimi walkę w dzień szabatu.
###### **1Mch 2,33**
 Mówili do nich: «***Dość już! Wyjdźcie i uczyńcie to, co głosi królewski rozkaz, a będziecie żyli***».
###### **1Mch 2,34**
 Oni odpowiedzieli: «***Nie wyjdziemy, nie będziemy robili tego, co głosi królewski rozkaz, i nie znieważymy szabatu***».
###### **1Mch 2,35**
 Zaraz więc [tamci] zaczęli walczyć przeciwko nim.
###### **1Mch 2,36**
 Oni jednak ani im nie odpowiedzieli, ani kamieniami w nich nie rzucali, ani nawet nie zatarasowali kryjówek.
###### **1Mch 2,37**
 Mówili oni: «***Umrzyjmy wszyscy z czystym sumieniem! Niebo i ziemia są naszymi świadkami, że wy niesprawiedliwie nas mordujecie***».
###### **1Mch 2,38**
 Natarli [tamci] na nich w walce, w szabat, tak że poginęli oni, a także ich żony, dzieci – blisko tysiąc ludzi – oraz ich bydło.
###### **1Mch 2,39**
 Kiedy Matatiasz i jego przyjaciele dowiedzieli się o tym, bardzo ich opłakiwali,
###### **1Mch 2,40**
 a jeden do drugiego mówił: «***Jeżeli wszyscy będziemy tak postępowali jak nasi bracia i [w szabat] nie będziemy walczyć z poganami o nasze życie i nasze ustawy, to teraz bardzo szybko zgładzą nas z ziemi***».
###### **1Mch 2,41**
 Tego więc dnia postanowili: «***Jeśliby jakikolwiek człowiek w dzień szabatu wyszedł walczyć przeciwko nam, my będziemy z nim walczyli, żebyśmy nie zginęli wszyscy, tak jak zginęli nasi bracia w kryjówkach***».
###### **1Mch 2,42**
 Wtedy przyłączyło się do nich zgromadzenie asydejczyków; spośród Izraela mocni i odważni, z których każdy dobrowolnie stanął w obronie Prawa.
###### **1Mch 2,43**
 Wszyscy również, którzy uciekali od nieszczęść, dołączyli do nich i wzmocnili ich.
###### **1Mch 2,44**
 W ten sposób utworzyli oni wojsko i w gniewie uderzyli na grzeszników, a w swej zapalczywości – na ludzi wiarołomnych; reszta zaś szukała ratunku w ucieczce do pogan.
###### **1Mch 2,45**
 Matatiasz i jego przyjaciele krążyli i rozbijali ołtarze,
###### **1Mch 2,46**
 a nieobrzezane dzieci, ile tylko ich znaleźli w granicach Izraela, obrzezywali przemocą.
###### **1Mch 2,47**
 Prześladowali synów pychy, a szczęście sprzyjało ich postępowaniu.
###### **1Mch 2,48**
 Tak więc bronili Prawa przed potęgą pogan i króla oraz nie pozwolili górować grzesznikowi.
###### **1Mch 2,49**
 Kiedy zbliżył się dzień śmierci Matatiasza, powiedział do swoich synów: «***Teraz pycha jest górą, [nastał] czas karania, czas zniszczenia i straszliwego gniewu.***
###### **1Mch 2,50**
 ***Teraz więc, dzieci, wykażcie gorliwość o Prawo, a nawet życie swoje oddajcie za przymierze zawarte z waszymi przodkami.***
###### **1Mch 2,51**
 ***Pamiętajcie, jak postępowali przodkowie, co czynili w swoich pokoleniach, i zdobywajcie dla siebie wielką chwałę i wieczyste imię.***
###### **1Mch 2,52**
 ***Czyż nie w czasie próby Abraham okazał się wierny?I zostało mu to poczytane za sprawiedliwość.***
###### **1Mch 2,53**
 ***Józef w czasie największych trudności zachował przykazanie, i został panem Egiptu.***
###### **1Mch 2,54**
 ***Nasz praojciec, Pinchas, za swoją wielką gorliwość otrzymał obietnicę kapłaństwa na wieki.***
###### **1Mch 2,55**
 ***Jozue za wypełnienie [Bożego] nakazu został sędzią Izraela.***
###### **1Mch 2,56**
 ***Kaleb za to, że dał świadectwo wobec zgromadzenia, otrzymał ziemię w dziedzictwo.***
###### **1Mch 2,57**
 ***Dawid za swoje oddanie odziedziczył na wieki tron królewski.***
###### **1Mch 2,58**
 ***Eliasz w nagrodę za swoją wielką gorliwość o Prawo został zabrany do nieba.***
###### **1Mch 2,59**
 ***Chananiasz, Azariasz i Miszael dzięki wierze zostali wyratowani z ognia.***
###### **1Mch 2,60**
 ***Daniel dzięki swej niewinności z paszczy lwów został ocalony.***
###### **1Mch 2,61**
 ***Tak zauważcie, że z pokolenia na pokolenie nie doznawali zawodu ci wszyscy, którzy Mu ufają.***
###### **1Mch 2,62**
 ***Nie obawiajcie się zatem słów grzesznika,bo jego chwała [obróci się] w gnój i robactwo;***
###### **1Mch 2,63**
 ***dziś się wywyższa, a jutro już go się nie znajdzie, bo powrócił do swego prochu i przepadły jego zamysły.***
###### **1Mch 2,64**
 ***Dzieci! Mężnie poczynajcie sobie i umacniajcie się w [przestrzeganiu] Prawa, przez nie bowiem dostąpicie chwały.***
###### **1Mch 2,65**
 ***Oto wasz brat, Szymon. Wiem, że jest on człowiekiem rozważnym. Jemu będziecie posłuszni po wszystkie dni, bo on będzie dla was ojcem,***
###### **1Mch 2,66**
 ***a Juda Machabeusz, który od młodości odznacza się odwagą, będzie dowódcą waszego wojska i poprowadzi wojnę z ludami.***
###### **1Mch 2,67**
 ***Wy więc ściągnijcie do siebie tych wszystkich, którzy przestrzegają Prawa, i w imieniu swego ludu wykonajcie pomstę!***
###### **1Mch 2,68**
 ***Odwetem odpłaćcie poganom, a trzymajcie się przepisów Prawa!***»
###### **1Mch 2,69**
 Potem udzielił im błogosławieństwa i został przyłączony do swoich przodków.
###### **1Mch 2,70**
 Zmarł w roku sto czterdziestym szóstym i został pochowany w grobach przodków w Modin. Cały Izrael opłakiwał go z bardzo wielkim żalem.
# 1Mch 2 PAU
###### **1Mch 2,1**
 W owych dniach wystąpił Matatiasz, syn Jana, syna Szymona, kapłan spośród potomków Joariba z Jerozolimy, który osiedlił się w Modin.
###### **1Mch 2,2**
 Miał on pięciu synów: Jana, zwanego Gaddi,
###### **1Mch 2,3**
 Szymona, zwanego Tassi,
###### **1Mch 2,4**
 Judę, zwanego Machabeusz,
###### **1Mch 2,5**
 Eleazara, zwanego Auaran, i Jonatana, zwanego Apfus.
###### **1Mch 2,6**
 Widząc świętokradztwo dokonywane w Judzie i w Jerozolimie,
###### **1Mch 2,7**
 powiedział: „Biada mi! Czy po to zostałem zrodzony, aby patrzeć na ucisk mojego ludu i na ucisk świętego miasta? Siedzieć bezczynnie, gdy wydane jest w ręce nieprzyjaciół, a świątynia - w ręce obcych?
###### **1Mch 2,8**
 Jego mieszkanie jest jak człowiek czci pozbawiony.
###### **1Mch 2,9**
 Wspaniałe naczynia zostały zrabowane. Na placach wymordowano jego dzieci. Jego młodzieńcy padli od wrogiego miecza.
###### **1Mch 2,10**
 Czy jest naród, który nie zawładnął jego królestwem i nie zagarnął jego łupów?
###### **1Mch 2,11**
 Wszystkie jego ozdoby zostały zagrabione. Zamiast być wolne, stało się niewolnikiem.
###### **1Mch 2,12**
 A oto nasza świątynia, nasza piękność i chwała, została spustoszona i zbezczeszczona przez obce narody.
###### **1Mch 2,13**
 Po co więc jeszcze żyjemy?”.
###### **1Mch 2,14**
 Matatiasz i jego synowie rozdarli szaty, nałożyli wory pokutne i bardzo płakali.
###### **1Mch 2,15**
 Do miasta Modin przybyli wysłannicy królewscy, aby przymuszać do odstępstwa przez składanie ofiar.
###### **1Mch 2,16**
 Zgromadziło się wokół nich wielu Izraelitów. Przyszedł także Matatiasz wraz ze swoimi synami.
###### **1Mch 2,17**
 Wtedy wysłannicy królewscy zwrócili się do Matatiasza w słowach: „Jesteś w tym mieście przywódcą wielkim i sławnym. Wspierają cię twoi synowie i bracia.
###### **1Mch 2,18**
 Podejdź więc pierwszy i wypełnij zarządzenie króla, jak to uczyniły wszystkie obce narody, mieszkańcy Judy i ci, co pozostali w Jerozolimie. Wtedy ciebie i twoich synów spotka zaszczyt, że będziecie przyjaciółmi króla i wszyscy zostaniecie obsypani srebrem, złotem i wieloma darami”.
###### **1Mch 2,19**
 Matatiasz odpowiedział donośnym głosem: „Nawet jeśli wszystkie obce narody, które podlegają królowi i są mu posłuszne, odstępują od wiary swoich przodków i zgadzają się z jego nakazami,
###### **1Mch 2,20**
 to ja, moi synowie i moi bracia będziemy postępować zgodnie z przymierzem naszych ojców.
###### **1Mch 2,21**
 Niech nas Bóg ustrzeże od tego, abyśmy porzucili Prawo i przykazania.
###### **1Mch 2,22**
 Nie będziemy słuchać nakazów króla i w niczym nie odstąpimy od naszej wiary”.
###### **1Mch 2,23**
 Kiedy skończył mówić te słowa, właśnie wystąpił pewien Żyd, aby w obecności wszystkich złożyć ofiarę na ołtarzu w Modin, zgodnie z zarządzeniem króla.
###### **1Mch 2,24**
 Na ten widok Matatiasz zapłonął gorliwością, a poruszony do głębi i wiedziony słusznym gniewem podbiegł i zabił go przy ołtarzu.
###### **1Mch 2,25**
 Zabił też wtedy królewskiego wysłannika, który zmuszał do składania ofiar, a ołtarz zburzył.
###### **1Mch 2,26**
 Zapłonął gorliwością o Prawo i uczynił podobnie jak Pinchas synowi Saloma, Zambriemu.
###### **1Mch 2,27**
 Następnie Matatiasz nawoływał po mieście donośnym głosem: „Każdy, kto płonie gorliwością o Prawo i zachowuje przymierze, niech idzie za mną”.
###### **1Mch 2,28**
 Uciekł on wraz z synami w góry, pozostawiając w mieście całe swoje mienie.
###### **1Mch 2,29**
 Wówczas wielu szukających tego, co sprawiedliwe i słuszne, zbiegło na pustynię, aby tam zamieszkać
###### **1Mch 2,30**
 razem ze swoimi synami, żonami i swoimi stadami, ponieważ zaciążyły nad nimi nieszczęścia.
###### **1Mch 2,31**
 Wysłannikom królewskim i wojsku, przebywającemu w Jerozolimie, mieście Dawida, doniesiono, że ludzie, którzy odrzucili nakazy króla, ukryli się w jaskiniach na pustyni.
###### **1Mch 2,32**
 Wówczas wielu rzuciło się za nimi w pogoń. Dopędzili ich, zajęli pozycje naprzeciwko i w dzień szabatu stanęli do walki z nimi.
###### **1Mch 2,33**
 Powiedzieli do nich: „Dosyć tego! Wyjdźcie i wypełnijcie nakaz króla, a będziecie żyli!”.
###### **1Mch 2,34**
 Tamci odpowiedzieli: „Nie wyjdziemy! Nie spełnimy nakazu króla i nie zbezcześcimy dnia szabatu”.
###### **1Mch 2,35**
 Wtedy zaczęli z nimi walczyć.
###### **1Mch 2,36**
 Tamci jednak nie odpowiedzieli im, nie rzucili w nich kamieniem ani nie zabarykadowali jaskiń.
###### **1Mch 2,37**
 Mówili tylko: „Wolimy zginąć z czystym sumieniem. Niebo i ziemia są naszymi świadkami, że mordujecie nas niesprawiedliwie”.
###### **1Mch 2,38**
 Prześladowcy jednak podjęli z nimi walkę w szabat i zabili ich, ich żony i dzieci - około tysiąc ludzi, a także stada.
###### **1Mch 2,39**
 Kiedy Matatiasz i jego przyjaciele dowiedzieli się o tym, bardzo zasmucili się z ich powodu.
###### **1Mch 2,40**
 Mówili między sobą: „Jeśli wszyscy tak postąpimy, jak uczynili nasi bracia, i nie będziemy walczyć przeciwko obcym narodom o nasze życie i nasze prawa, wówczas szybko zgładzą nas z ziemi!”.
###### **1Mch 2,41**
 Postanowili więc tego dnia: „Jeśli ktokolwiek stanie do walki przeciwko nam w dzień szabatu, będziemy z nim walczyli i nie zginiemy, jak nasi bracia w jaskiniach”.
###### **1Mch 2,42**
 Wówczas dołączyła do nich grupa asydejczyków - dzielnych Izraelitów, z których każdy bez reszty oddany był Prawu.
###### **1Mch 2,43**
 Przyłączyli się do nich także wszyscy uciekający przed prześladowaniami i wzmocnili ich szeregi.
###### **1Mch 2,44**
 Tak oto utworzyli wojsko i w swoim oburzeniu uderzyli na grzeszników, w swym gniewie - na ludzi nieprawych. Wszyscy inni ratowali się ucieczką do obcych narodów, aby ocaleć.
###### **1Mch 2,45**
 Matatiasz zaś i jego przyjaciele krążyli po kraju i burzyli ołtarze.
###### **1Mch 2,46**
 Nieobrzezane dzieci, które znaleźli w granicach Izraela, obrzezywali siłą.
###### **1Mch 2,47**
 Ścigali zuchwalców i przyczynili się do pomyślnego wykonania podjętego dzieła.
###### **1Mch 2,48**
 Wyrwali Prawo z rąk pogan i królów i nie pozwolili panować grzesznikowi.
###### **1Mch 2,49**
 Kiedy zbliżał się dzień śmierci Matatiasza, powiedział do swoich synów: „Oto teraz wzmogła się pycha i kara, czas zagłady i straszliwego gniewu.
###### **1Mch 2,50**
 Teraz więc, synowie, brońcie gorliwie Prawa i oddajcie swoje życie za przymierze waszych ojców.
###### **1Mch 2,51**
 Wspomnijcie czyny przodków, których dokonali za swojego życia, a zyskacie wielką chwałę i nieśmiertelne imię.
###### **1Mch 2,52**
 Czy Abraham nie okazał się wierny w czasie próby i czy nie dlatego został uznany za sprawiedliwego?
###### **1Mch 2,53**
 Prześladowany Józef zachował przykazania i został panem Egiptu.
###### **1Mch 2,54**
 Ojciec nasz Pinchas za niegasnącą gorliwość otrzymał obietnicę wiecznego kapłaństwa.
###### **1Mch 2,55**
 Jozue za wypełnienie nakazu stał się sędzią w Izraelu.
###### **1Mch 2,56**
 Kaleb za złożenie świadectwa na zgromadzeniu otrzymał w dziedzictwo ziemię.
###### **1Mch 2,57**
 Dawid za swoje miłosierdzie na wieki odziedziczył tron królewski.
###### **1Mch 2,58**
 Eliasz za niegasnącą gorliwość o Prawo został uniesiony do nieba.
###### **1Mch 2,59**
 Chananiasz, Azariasz i Miszael, ponieważ wierzyli, zostali ocaleni z płomienia.
###### **1Mch 2,60**
 Daniel za swoją prostotę został wyrwany z paszczy lwów.
###### **1Mch 2,61**
 Zauważcie więc, że z pokolenia na pokolenie ci się nie zawiodą, którzy pokładają w Nim nadzieję.
###### **1Mch 2,62**
 Nie bójcie się gróźb grzesznika, bo jego chwała zamieni się w gnój i w robactwo.
###### **1Mch 2,63**
 Dzisiaj się wywyższa, a już jutro go nie będzie, gdyż zamieni się w proch i znikną jego plany.
###### **1Mch 2,64**
 Synowie, bądźcie mężni i trzymajcie się mocno Prawa, ponieważ dzięki niemu doznacie chwały.
###### **1Mch 2,65**
 Oto wasz brat Szymon. Wiem, że jest człowiekiem mądrym. Jego zawsze słuchajcie, on będzie waszym ojcem.
###### **1Mch 2,66**
 Juda Machabeusz, od młodości znany ze swojej siły, będzie wodzem waszego wojska w walce z poganami.
###### **1Mch 2,67**
 A wy, przyłączcie do siebie wszystkich wypełniających Prawo i pomścijcie wasz lud.
###### **1Mch 2,68**
 Odpłaćcie poganom za zło i przylgnijcie do nakazu Prawa”.
###### **1Mch 2,69**
 Potem pobłogosławił ich i został przyłączony do swoich przodków.
###### **1Mch 2,70**
 Umarł w sto czterdziestym szóstym roku i został pochowany w grobach swoich przodków w Modin. Cały Izrael bardzo go opłakiwał.
# 1Mch 2 BP
###### **1Mch 2,21**
 Niech nas [Bóg] uchroni od przekroczenia Prawa i przepisów.
###### **1Mch 2,22**
 Nie usłuchamy rozkazów królewskich i ani w prawo, ani w lewo nie odstąpimy od naszej religii.
###### **1Mch 2,37**
 Mówili tylko: Zgińmy wszyscy nieskalani, niebo i ziemia są nam świadkami, że mordujecie nas niesprawiedliwie.
###### **1Mch 2,38**
 Rzucili się na nich w dzień szabatu i zginęli [Żydzi] wraz z żonami, dziećmi i bydłem - (razem) około tysiąca ludzi.
###### **1Mch 2,39**
 Wiadomość o tym napełniła Mattatiasza i jego przyjaciół głębokim smutkiem.
###### **1Mch 2,23**
 Zaledwie skończył mówić, wystąpił pewien Judejczyk, aby na oczach wszystkich spełnić rozkaz króla i złożyć ofiarę na ołtarzu w Modin.
###### **1Mch 2,24**
 Na widok ten wzburzył się do głębi Mattatiasz, poruszyły się jego nerki, uniesiony słusznym gniewem podbiegł i zabił go przy ołtarzu.
###### **1Mch 2,25**
 Zabił także królewskiego urzędnika, który zmuszał do składania ofiar, i zburzył ołtarz.
###### **1Mch 2,26**
 Okazał wielką gorliwość w obronie Prawa i postąpił podobnie jak Finees z Zambrim, synem Saloma.
###### **1Mch 2,27**
 I rozgłaszał Mattatiasz po mieście potężnym głosem: Każdy, kto kocha Prawo i zachowuje Przymierze, niech idzie za mną!
###### **1Mch 2,28**
 Zaraz też uszedł w góry on sam i jego synowie, pozostawiając w mieście cały swój dobytek.
###### **1Mch 2,29**
 Uszło wtedy na pustynię wielu takich, którzy pragnęli sprawiedliwości i Prawa, i przybywali tam
###### **1Mch 2,30**
 wraz z synami, żonami i bydłem, ponieważ dotknęło ich nieszczęście.
###### **1Mch 2,31**
 I doniesiono urzędnikom królewskim i wojskom stojącym w Jerozolimie, mieście Dawida, że ludzie, którzy naruszyli rozkaz króla, ukryli się w grotach pustynnych.
###### **1Mch 2,32**
 Liczny oddział wyruszył za nimi w pościg i gdy się do nich zbliżyli, rozbili naprzeciwko obóz, zamierzając wszcząć z nimi walkę w dzień szabatu.
###### **1Mch 2,33**
 I rzekli im: Dość już tego! Wychodźcie, wykonajcie rozkaz królewski, a ocalicie swe życie.
###### **1Mch 2,34**
 Odpowiedzieli: Nie wyjdziemy, nie wypełnimy rozkazu króla i nie znieważymy szabatu.
###### **1Mch 2,35**
 Wtedy uderzyli na nich.
###### **1Mch 2,36**
 Oni jednak nie podjęli walki, nie rzucali kamieni ani nie zatarasowali grot.
###### **1Mch 2,1**
 W tym czasie wystąpił Mattatiasz, syn Jana, który był synem Symeona, kapłana z pokolenia Joariba, i pochodził z Jerozolimy, a osiedlił się w Modin.
###### **1Mch 2,2**
 Miał pięciu synów: Jana z przydomkiem Gaddi,
###### **1Mch 2,3**
 Szymona, zwanego Tassi,
###### **1Mch 2,4**
 Judę, zwanego Machabeusz,
###### **1Mch 2,5**
 Eleazara, zwanego Auaran, i Jonatana z przydomkiem Apfus.
###### **1Mch 2,6**
 Widząc bezbożność panoszącą się w ziemi judzkiej i w Jerozolimie,
###### **1Mch 2,7**
 powiedział: Biada mi! Po cóż przyszedłem na świat? Czy aby oglądać upadek mego ludu i zagładę świętego miasta? Aby patrzeć bezczynnie, jak wydano je w ręce nieprzyjaciół, a Świątynię w niewolę obcych?
###### **1Mch 2,8**
 Przybytek jego stał się podobny do człowieka bez czci,
###### **1Mch 2,9**
 naczynia stanowiące jego chwałę stały się łupem, dzieci mordowano na ulicach, młodzieńcy [ginęli] od nieprzyjacielskiego miecza.
###### **1Mch 2,10**
 Jakiż to naród nie zawładnął jego królestwem i nie zagarnął jego łupów?
###### **1Mch 2,11**
 Odebrano mu całą świetność, z wolnego stało się niewolnikiem.
###### **1Mch 2,12**
 Oto nasza świętość pełna piękna i chwały została zniszczona i zhańbiona przez pogan.
###### **1Mch 2,13**
 Po co więc jeszcze żyjemy?
###### **1Mch 2,14**
 Mattatiasz i jego synowie rozdarli swe szaty, a przywdziawszy wory lamentowali bardzo.
###### **1Mch 2,15**
 Przybyli wtedy do Modin wysłańcy królewscy, aby przymuszać [ludność] przez składanie ofiary do odstępstwa.
###### **1Mch 2,16**
 Zgromadziło się wokół nich wielu Izraelitów. Przybył także Mattatiasz z synami.
###### **1Mch 2,17**
 Wówczas wysłańcy króla zwrócili się do niego ze słowami: Masz duże znaczenie i jesteś bardzo poważany w mieście. Silne oparcie masz w synach i krewnych.
###### **1Mch 2,18**
 Przystąp więc pierwszy i wykonaj rozkaz królewski, jak uczyniły to wszystkie narody i [nawet] mężowie z Judei oraz ci, którzy pozostali w Jerozolimie. Wówczas wraz z synami należał będziesz do przyjaciół króla, którzy obdarzyli was srebrem, złotem i wielu innymi darami.
###### **1Mch 2,19**
 Odpowiadając im oświadczył Mattatiasz donośnym głosem: Jeśli nawet wszystkie narody, nad którymi rozciąga się władza króla, usłuchały go i odstępując od wiary ojców podporządkowały się jego nakazom,
###### **1Mch 2,20**
 to ja, moi synowie i krewni pozostaniemy wierni Przymierzu naszych ojców.
###### **1Mch 2,40**
 Poczęli mówić między sobą: Jeżeli wszyscy postąpimy tak, jak uczynili nasi bracia, i nie będziemy walczyć z poganami o nasze życie i prawa, to sprawią oni, że wkrótce znikniemy z powierzchni ziemi.
###### **1Mch 2,41**
 Dlatego owego dnia powzięli postanowienie: Jeżeli ktokolwiek napadnie na nas w dzień szabatu, staniemy z nim do walki, abyśmy nie zginęli wszyscy, tak jak poginęli nasi bracia w jaskiniach.
###### **1Mch 2,42**
 Wówczas przyłączyła się do nich grupa asydejczyków - dzielni Izraelici, wszyscy całym sercem przywiązani do Prawa.
###### **1Mch 2,43**
 Powiększyli i wzmocnili ich szeregi i ci, którzy uszli przed prześladowaniem.
###### **1Mch 2,44**
 Utworzyli w ten sposób wojsko. Pełni gniewu bili grzeszników i w uniesieniu gromili bezbożnych. Pozostali ratowali się ucieczką do pogan.
###### **1Mch 2,45**
 Mattatiasz wraz z przyjaciółmi obchodził [cały kraj], burzył ołtarze
###### **1Mch 2,46**
 oraz przemocą obrzezywał znalezione na terenach izraelskich nie obrzezane dzieci.
###### **1Mch 2,47**
 Prześladowali zuchwalców, a szczęście sprzyjało ich poczynaniom.
###### **1Mch 2,48**
 Wy stąpili w obronie Prawa przeciw poganom i królowi i nie dopuścili do triumfu grzeszników.
###### **1Mch 2,49**
 Kiedy zbliżał się dzień śmierci Mattatiasza, tak przemówił do swoich synów: Nadszedł teraz czas pychy i kary, nastał czas zniszczenia i straszliwego gniewu.
###### **1Mch 2,50**
 Teraz więc, synowie, gorliwie przestrzegajcie Prawa i życie swe poświęćcie w obronie Przymierza naszych ojców.
###### **1Mch 2,51**
 Pamiętajcie o czynach przodków, jakich oni dokonali w życiu, a osiągniecie wielką chwałę i nieśmiertelne imię.
###### **1Mch 2,52**
 Czyż Abraham nie okazał się wiernym w chwili pokusy? I zostało mu to policzone jako sprawiedliwość.
###### **1Mch 2,53**
 Józef w czasie największych nieszczęść zachował przykazania i został panem Egiptu.
###### **1Mch 2,54**
 Nasz ojciec Finees za płomienną gorliwość otrzymał zapewnienie wiecznego kapłaństwa.
###### **1Mch 2,55**
 Jozue został sędzią Izraela, ponieważ wypełniał polecenia.
###### **1Mch 2,56**
 Kaleb dał świadectwo przed zgromadzonym ludem i otrzymał ziemię w dziedzictwie.
###### **1Mch 2,57**
 Dawid dla swej pobożności odziedziczył tron królewski na wieki.
###### **1Mch 2,58**
 Eliasz za gorliwą służbę Prawu wzięty został do nieba.
###### **1Mch 2,59**
 Wiara ocaliła z płomieni Ananiasza, Azariasza i Misaela.
###### **1Mch 2,60**
 Niewinność Daniela wyrwała go z paszczy lwów.
###### **1Mch 2,61**
 Możecie tak przejść myślą z pokolenia w pokolenie, a przekonacie się, że nie zawiedli się ci, którzy pokładają w Nim nadzieję.
###### **1Mch 2,62**
 Dlatego nie lękajcie się gróźb grzesznego człowieka, gdyż sława jego obróci się w gnój i robactwo.
###### **1Mch 2,63**
 Dziś się wywyższa, a jutro nikt go nie ujrzy: zamienił się w proch, a zamysły jego wniwecz się obróciły.
###### **1Mch 2,64**
 Dzieci, bądźcie mężni i niezłomnie trwajcie przy Prawie! Ono bowiem przyniesie wam sławę.
###### **1Mch 2,65**
 Oto brat wasz Szymon. Wiem, że jest mężem roztropnym. Jego zawsze słuchajcie, on będzie waszym ojcem.
###### **1Mch 2,66**
 Juda Machabeusz, od młodości wyróżniający się siłą, będzie waszym wodzem w wojnie przeciw poganom.
###### **1Mch 2,67**
 Wy zaś zgromadźcie wokół siebie wszystkich, którzy wypełniają Prawo, i pomścijcie swój lud.
###### **1Mch 2,68**
 Odpłaćcie za wszystko poganom i trzymajcie się ściśle przepisów Prawa.
###### **1Mch 2,69**
 Potem pobłogosławił ich i odszedł do ojców swoich.
###### **1Mch 2,70**
 Zmarł w roku sto czterdziestym szóstym i pochowano go w rodzinnym grobowcu w Modin. Cały Izrael bardzo go opłakiwał.
# 1Mch 2 BR
###### **1Mch 2,1**
 Wtedy pojawił się pewien kapłan imieniem Matatiasz, z pokolenia Joariba. Ojciec Matatiasza, Jan, był synem syna Jana. Sam Matatiasz pochodził z Jerozolimy, ale z czasem osiedlił się w Medii.
###### **1Mch 2,2**
 Miał on pięciu synów: Jana, którego nazywano także Gaddi,
###### **1Mch 2,3**
 Szymona, noszącego przydomek Tassi,
###### **1Mch 2,4**
 Judę, znanego pod przydomkiem Machabeusz,
###### **1Mch 2,5**
 Eleazara, zwanego również Auaran, i Jonatana, o przydomku Apfus.
###### **1Mch 2,6**
 Widząc te wszystkie bezbożności, których dopuszczono się w Judzie i w Jerozolimie, Matatiasz powiedział:
###### **1Mch 2,7**
 Ach, po cóż ja na świat przyszedłem? By patrzeć, jak wyniszcza się mój naród i bezcześci się święte miasto? Bezradnie muszę patrzeć, jak przemocą zajmuje je nieprzyjaciel i jak wszystkie święte miejsca dostają się w obce ręce.
###### **1Mch 2,8**
 Świątynia wygląda jak człowiek pozbawiony czci wielkiej,
###### **1Mch 2,9**
 zabrano z niej wszystkie kosztowności. Na miejscach publicznych zabijano dzieci mego narodu, jego młodzieńcy padali pod mieczami wrogów.
###### **1Mch 2,10**
 Czy jest naród, który by nie otrzymał choć kawałka jego ziemi lub nie uczestniczył w grabieniu jego sumienia?
###### **1Mch 2,11**
 Odebrano temu narodowi całe jego piękno, a jego wolni synowie stali się niewolnikami.
###### **1Mch 2,12**
 Popatrzcie na naszą świątynię! Pustynią stało się to, co było naszym pięknem i naszą chwałą. Wszystko zbezczeszczone przez obce narody.
###### **1Mch 2,13**
 Po cóż my jeszcze żyjemy?
###### **1Mch 2,14**
 I rozdzierali Matatiasz i jego synowie swoje szaty, założyli wory pokutne i pogrążyli się w głębokim smutku.
###### **1Mch 2,15**
 Po jakimś czasie przybyli do miasta Modin wysłannicy królewscy, żeby jego mieszkańców nakłonić do składania ofiar i zmusić ich, na mocy rozkazu królewskiego, do odwrócenia się od ich Boga.
###### **1Mch 2,16**
 Spotkało się z nimi wtedy wielu Izraelitów. Musiał się im pokazać także Matatiasz razem ze swymi synami.
###### **1Mch 2,17**
 Wtedy wysłannicy królewscy tak powiedzieli do Matatiasza: Posiadasz w tym mieście władzę, cieszysz się powszechnym uznaniem, wpływami i poparciem twoich synów oraz krewnych.
###### **1Mch 2,18**
 Wystąp tedy jako pierwszy i uczyń to, czego domaga się król w swoim rozkazie. Tak postąpiły przecież już inne ludy, jak również wszyscy mężowie w Judzie oraz ci, co pozostali w Jerozolimie. Jeśli tak uczynisz, znajdziesz się - razem z twoimi synami - wśród przyjaciół króla i zarówno ty, jak i twoi synowie zostaniecie obsypani srebrem, złotem, oraz licznymi podarkami.
###### **1Mch 2,19**
 Lecz Matatiasz odpowiedział donośnym głosem: Choćby nawet wszystkie narody będące pod władzą króla poddały się jego rozkazom i porzuciły wiarę swoich ojców, i postanowiły wypełnić dokładnie polecenia króla,
###### **1Mch 2,20**
 to ja, moi synowie i wszyscy moi krewni pozostaniemy wierni przymierzu naszych ojców.
###### **1Mch 2,21**
 Niech niebiosa bronią nas przed zapomnieniem o prawie i jego nakazach!
###### **1Mch 2,22**
 Nie poddamy się rozkazom króla i nie odejdziemy ani na lewo, ani na prawo od naszej wiary.
###### **1Mch 2,23**
 Zaledwie skończył to mówić, wystąpił - na oczach wszystkich - pewien Judejczyk, żeby zgodnie z rozkazem króla złożyć ofiarę na ołtarzu.
###### **1Mch 2,24**
 Kiedy zobaczył to Matatiasz, zapłonął świętym oburzeniem. Aż zatrząsł się ze słusznego gniewu. Rzucił się naprzód i położył tamtego trupem przed samym ołtarzem.
###### **1Mch 2,25**
 Potem zabił także wysłannika królewskiego, który nakłaniał do składania ofiar, i rozwalił cały ołtarz.
###### **1Mch 2,26**
 Zapłonął tak wielką gorliwością o prawo, że czynił to, co kiedyś uczynił Finees Zambriemu, synowi Saloma.
###### **1Mch 2,27**
 Potem biegł Matatiasz przez całe miasto i wołał głośno: Wszyscy, którym leży na sercu prawo i przymierze, niech idą ze mną!
###### **1Mch 2,28**
 Wreszcie uciekł razem ze swymi synami w góry, pozostawiając w mieście cały swój dobytek.
###### **1Mch 2,29**
 Wtedy wielu spośród tych, którzy szukali prawa i sprawiedliwości, zbiegło na pustynię i tam żyło.
###### **1Mch 2,30**
 Zabrali oni ze sobą dzieci i żony, i cały dobytek, gdyż dalsze ich przebywanie w domach okazało się nie do zniesienia.
###### **1Mch 2,31**
 Wkrótce jednak doniesiono ludziom króla oraz załodze obwarowanej w Mieście Dawidowym w Jerozolimie, że ludzie, którzy nie poddali się zarządzeniom króla, uciekli na pustynię i zamieszkali w grotach skalnych.
###### **1Mch 2,32**
 Wysłano przeto za nimi silny oddział wojska, który dotarłszy do kryjówek Żydów, rozbił w ich pobliżu obóz, szykując się do uderzenia. A w dniu tym właśnie przypadał szabat.
###### **1Mch 2,33**
 Wołali tedy wojownicy królewscy: Jeszcze macie czas! Wyjdźcie i uczyńcie, co nakazuje król, a wtedy ocalicie wasze życie.
###### **1Mch 2,34**
 Lecz Żydzi odpowiedzieli: Nie wyjdziemy i nie wykonamy rozkazu króla. Nie zbezcześcimy szabatu.
###### **1Mch 2,35**
 Wówczas wojownicy królewscy przystąpili do ataku.
###### **1Mch 2,36**
 Żydzi nie stawiali najmniejszego oporu: nie rzucili ani jednego kamienia i nie tarasowali wejść do jaskiń skalnych.
###### **1Mch 2,37**
 Powtarzali tylko jedno: Wolimy raczej wszyscy umrzeć niż obciążyć nasze sumienia. Niebo i ziemia są świadkami, że prześladujecie nas wbrew wszelkiemu prawu.
###### **1Mch 2,38**
 Właśnie w szabat uderzyli na nich wojownicy królewscy. Poległo wtedy około tysiąca Żydów, razem z żonami i dziećmi. Zniszczono także cały ich dobytek.
###### **1Mch 2,39**
 Gdy wieść o tym dotarła do Matatiasza i jego zwolenników, wszyscy zaczęli opłakiwać pomordowanych.
###### **1Mch 2,40**
 Mówili przy tym jeden do drugiego: Jeżeli wszyscy będziemy się zachowywali tak jak nasi bracia i nie podejmiemy walki z obcymi narodami, stając w obronie naszego życia i prawa, to wkrótce znikniemy z ziemi.
###### **1Mch 2,41**
 I jeszcze tego samego dnia postanowili, że jeśli ktoś zaatakuje ich w szabat, to oni będą walczyli, żeby nie zginąć tak jak ich bracia w jaskiniach skalnych.
###### **1Mch 2,42**
 Dołączyła się do nich wtedy także wspólnota hasydyjczyków, do której należeli bardzo dzielni Izraelici, wszyscy oddani całkowicie prawu.
###### **1Mch 2,43**
 Ponadto wszyscy ci, którzy się dotąd ukrywali, przybyli do nich, wzmacniając ich szeregi.
###### **1Mch 2,44**
 W ten sposób powstał dobrze uzbrojony oddział. I uderzyli w swoim gniewie na grzeszników, zadali ciosy gwałcicielom prawa. Ci, co ocaleli, musieli szukać schronienia u narodów sąsiednich, żeby ujść z życiem.
###### **1Mch 2,45**
 Matatiasz i jego zwolennicy przemierzali cały kraj i burzyli ołtarze.
###### **1Mch 2,46**
 Wszystkie dzieci nie obrzezane żyjące na ziemi izraelskiej poddawali natychmiast obrzezaniu.
###### **1Mch 2,47**
 I nękali grzeszników, i wiodło się im we wszystkim, co zaczęli.
###### **1Mch 2,48**
 I uwolnili prawo spod przemocy ludów, a grzesznikom żadnej nie zostawili władzy.
###### **1Mch 2,49**
 Kiedy nadeszły ostatnie dni życia Matatiasza, powiedział tak do swoich synów: Przyszły na nas dni panowania, pysznych, dni kary, dni zagłady i strasznego gniewu.
###### **1Mch 2,50**
 I was niech napełni, synowie, gorliwość o prawo, życia nie żałujcie za przymierze ojców.
###### **1Mch 2,51**
 Pamiętajcie o dziełach dokonanych przez ojców, a chwałą się okryjecie i wasze imię przetrwa wieki.
###### **1Mch 2,52**
 Czyż nie okazał się wiernym Abraham czasu próby i czy mu tego za sprawiedliwość nie poczytano?
###### **1Mch 2,53**
 Józef strzegł przykazań kiedy był w ucisku, i został za to panem całego Egiptu.
###### **1Mch 2,54**
 Nasz praojciec Finees, pełen troski o sprawę Bożą, otrzymał obietnicę kapłaństwa na wieki.
###### **1Mch 2,55**
 Za wypełnienie Bożego nakazu Jozue stał się sędzią Izraela.
###### **1Mch 2,56**
 Kaleb jako świadek prawdę wyznał przed ludem i dostał za to cząstkę w dziedzictwie kraju.
###### **1Mch 2,57**
 A Dawid w nagrodę za wierność tron królewski otrzymał na wieki.
###### **1Mch 2,58**
 Eliasz walczył z zapałem o prawo i został wzięty w nagrodę do nieba.
###### **1Mch 2,59**
 Chananiasz, Azariasz i Miszael uwierzyli i nie tknęły ich płomienie ognia.
###### **1Mch 2,60**
 Daniel, ponieważ był niewinny, uszedł nawet paszczy lwów.
###### **1Mch 2,61**
 Pomyślcie o naszych minionych dziejach:
###### **1Mch 2,62**
 Nie bójcie się tego, co mówi zły człowiek, bo jego wspaniałość - to gnój i robactwo
###### **1Mch 2,63**
 Dziś jeszcze wynosi się pod niebiosy, lecz już jutro zniknie bez śladu, w proch się znowu zamieni i nic zeń nie zostanie.
###### **1Mch 2,64**
 Dzielnie i odważnie walczcie, moi synowie, o prawo, gdyż prawo przyniesie wam nieśmiertelność i sławę.
###### **1Mch 2,65**
 Oto wasz brat Szymon. Wiem, że jest to mądry człowiek. On niech będzie waszym ojcem.
###### **1Mch 2,66**
 Juda zaś, Machabeusz, który od najwcześniejszej młodości był dzielnym wojownikiem, niech stanie na czele waszych oddziałów i niech pokieruje walką w obronie całego narodu.
###### **1Mch 2,67**
 Zgromadźcie wokół siebie tych wszystkich, którzy przestrzegają prawa, i pomścijcie cały naród.
###### **1Mch 2,68**
 Odpłaćcie za wszystko poganom, trzymając się jednak dokładnie tego, co nakazuje prawo.
###### **1Mch 2,69**
 Potem udzieliwszy im błogosławieństwa, odszedł do swoich przodków.
###### **1Mch 2,70**
 Umarł w roku sto czterdziestym szóstym i został pochowany w Modin, w grobach swoich przodków. Cały zaś Izrael opłakiwał go z wielkim żalem
# 1Mch 2 WUJ
