# Ag 1 BT5
###### **Ag 1,1**
 W drugim roku [rządów] króla Dariusza, w pierwszym dniu szóstego miesiąca, Pan skierował te słowa przez proroka Aggeusza do Zorobabela, syna Szealtiela, namiestnika Judy, i do arcykapłana Jozuego, syna Josadaka:
###### **Ag 1,2**
 «***Tak mówi Pan Zastępów: Ten lud powiada: Jeszcze nie nadszedł czas, aby odbudowywać dom Pański.***
###### **Ag 1,3**
 ***Wówczas Pan skierował te słowa przez proroka Aggeusza:***
###### **Ag 1,4**
 ***Czy to jest czas stosowny dla was, byście spoczywali w domach wyłożonych płytami, podczas gdy ten dom leży w gruzach?***
###### **Ag 1,5**
 ***A teraz tak mówi Pan Zastępów: Zastanówcie się dobrze nad swoim postępowaniem!***
###### **Ag 1,6**
 ***Siejecie wiele, lecz plon macie lichy; przyjmujecie pokarm, lecz nie macie go do syta; pijecie, lecz nie gasicie pragnienia; okrywacie się, lecz się nie rozgrzewacie; ten, kto pracuje dla zarobku, pracuje dla dziurawego mieszka.***
###### **Ag 1,7**
 ***Tak mówi Pan Zastępów: Zastanówcie się dobrze nad swoim postępowaniem.***
###### **Ag 1,8**
 ***Wyjdźcie w góry i sprowadźcie drewno, a budujcie ten dom, bym sobie w nim upodobał i doznał czci – mówi Pan.***
###### **Ag 1,9**
 ***Spodziewaliście się wiele, a urodziło się mało. Kiedy zaś znieśliście to do domu, Ja to rozproszyłem. Dlaczego tak się dzieje? – wyrocznia Pana Zastępów: Z powodu mego domu, który leży w gruzach, podczas gdy każdy z was pilnie się troszczy o swój własny dom.***
###### **Ag 1,10**
 ***Dlatego niebiosa nad wami zatrzymały rosę, a ziemia nie dała urodzaju.***
###### **Ag 1,11**
 ***Ja bowiem sprowadziłem suszę na ziemię i na góry, na pszenicę, na winne krzewy i na oliwki – na wszystko, cokolwiek może wydać gleba, na ludzi i na bydło, i na wszelką pracę rąk***».
###### **Ag 1,12**
 Zorobabel, syn Szealtiela, i arcykapłan Jozue, syn Josadaka, a także cała Reszta ludu usłyszeli wówczas głos Pana, Boga swego, i słowa proroka Aggeusza – jako że wysłał go ich Pan, Bóg – a lęk przed Panem ogarnął lud.
###### **Ag 1,13**
 Aggeusz zaś, wysłannik Pański, pełniąc to poselstwo Pańskie, przemówił do ludu tymi słowami: «***Ja jestem z wami! – wyrocznia Pana***».
###### **Ag 1,14**
 Pobudził więc Pan ducha Zorobabela, syna Szealtiela, namiestnika Judy, i ducha arcykapłana Jozuego, syna Josadaka, a także ducha całej Reszty ludu; przyszli więc i wzięli się do pracy przy domu swego Boga, Pana Zastępów,
###### **Ag 1,15**
 dnia dwudziestego czwartego, miesiąca szóstego, w drugim roku [rządów] króla Dariusza.
# Ag 1 PAU
###### **Ag 1,1**
 W drugim roku panowania króla Dariusza, w pierwszym dniu szóstego miesiąca, PAN tak przemówił przez proroka Aggeusza do Zorobabela, syna Szealtiela, namiestnika Judy, i do najwyższego kapłana Jozuego, syna Josadaka:
###### **Ag 1,2**
 „Tak mówi PAN Zastępów: Lud ten mówi: «Jeszcze nie nadszedł czas na odbudowę domu PANA».
###### **Ag 1,3**
 Wtedy PAN tak przemówił przez proroka Aggeusza:
###### **Ag 1,4**
 A czy dla was nadszedł już czas, żebyście mieszkali w przyozdobionych domach, podczas gdy dom PANA leży w gruzach?
###### **Ag 1,5**
 Teraz tak mówi PAN Zastępów: Rozważcie, jak się wam powodzi!
###### **Ag 1,6**
 Siejecie wiele, lecz zbieracie mało, jecie, lecz nie zaspokajacie głodu, pijecie, lecz nie gasicie pragnienia, ubieracie się, lecz nie odczuwacie ciepła, a kto pracuje dla zarobku, pracuje dla dziurawej kieszeni.
###### **Ag 1,7**
 Tak mówi PAN Zastępów: Rozważcie, jak się wam powodzi!
###### **Ag 1,8**
 Idźcie w góry, sprowadźcie drewno, budujcie ten dom, a upodobam go sobie i w nim doznam czci - mówi PAN.
###### **Ag 1,9**
 Liczyliście na wiele, lecz macie mało. A kiedy przynieśliście to do swojego domu, Ja i to rozproszyłem. Dlaczego? - wyrocznia PANA Zastępów. Ponieważ mój dom leży w gruzach, podczas gdy każdy z was gorliwie troszczy się o własny dom.
###### **Ag 1,10**
 Dlatego niebo wstrzymało deszcz nad wami, a ziemia nie wydała swojego plonu.
###### **Ag 1,11**
 Sprowadziłem też suszę na ziemię, na góry, na zboże, na winne krzewy i drzewa oliwek, na wszystko, co wydaje ziemia, na ludzi i na zwierzęta, i na wszelką pracę rąk waszych”.
###### **Ag 1,12**
 Wtedy Zorobabel, syn Szealtiela, i najwyższy kapłan Jozue, syn Josadaka, oraz cała reszta ludu wysłuchali głosu PANA, swojego Boga, w słowach proroka Aggeusza, którego PAN posłał do nich. A lud odczuł bojaźń przed PANEM.
###### **Ag 1,13**
 Aggeusz, wysłannik PANA, ogłosił ludowi przesłanie otrzymane od PANA: „Ja jestem z wami - wyrocznia PANA”.
###### **Ag 1,14**
 Wtedy PAN pobudził ducha namiestnika Judy Zorobabela, syna Szealtiela, ducha najwyższego kapłana Jozuego, syna Josadaka, i ducha całej reszty ludu, tak że przyszli i podjęli pracę przy budowie domu PANA Zastępów, swojego Boga,
###### **Ag 1,15**
 dwudziestego czwartego dnia, miesiąca szóstego, w drugim roku panowania króla Dariusza.
# Ag 1 BP
###### **Ag 1,15**
 dnia dwudziestego czwartego, miesiąca szóstego.
###### **Ag 1,1**
 W drugim roku [panowania] króla Dariusza, dnia pierwszego, miesiąca szóstego, przemówił Jahwe przez proroka Aggeusza do Zorobabela, syna Salatiela, zarządcy Judei, oraz do arcykapłana Jozuego, syna Jocedeka:
###### **Ag 1,2**
 Tak mówi Jahwe Zastępów: Lud ten powiada: "Teraz nie nadszedł jeszcze czas na odbudowę Domu Jahwe".
###### **Ag 1,3**
 (Przez proroka Aggeusza zostało więc przekazane następujące słowo Jahwe:)
###### **Ag 1,4**
 A dla was czy nadszedł już czas, by mieszkać w domach pokrytych obiciami, podczas gdy ten Dom leży w gruzach?
###### **Ag 1,5**
 Otóż tak mówi Jahwe Zastępów: Zważcie, jak wam się wiedzie!
###### **Ag 1,6**
 Zasialiście wiele, a zebraliście mało; macie wprawdzie co jeść, ale nie starczy tego, by się nasycić; macie co pić, ale za mało, by ugasić pragnienie; macie się czym przyodziać, ale nie na tyle, żeby się ogrzać; a kto pracuje dla zarobku, pracuje dla worka bez dna.
###### **Ag 1,7**
 a Tak mówi Jahwe Zastępów: 7b Zważcie, jak wam się wiedzie!
###### **Ag 1,8**
 Udajcie się w góry, sprowadźcie drzewo i budujcie Świątynię, abym w niej miał upodobanie i był w niej czczony - mówi Jahwe.
###### **Ag 1,9**
 Liczyliście na obfitość, a było tego mało; przynieśliście to do domu, a Ja to rozproszyłem. Dlaczegóż to? - mówi Jahwe Zastępów. Dlatego, że Dom mój leży w gruzach, podczas gdy każdy z was zabiega pilnie o swój własny dom.
###### **Ag 1,10**
 Przeto poskąpiło wam niebo deszczu, a ziemia nie wydała plonu.
###### **Ag 1,11**
 Sprowadziłem suszę na pola i na góry, na zboże, na winne szczepy i na oliwki, na wszystko, co ziemia wydaje, na ludzi i na zwierzęta, i na wszystkie dzieła rąk.
###### **Ag 1,12**
 Zorobabel, syn Salatiela, i arcykapłan Jozue, syn Jocedeka, oraz cała ocalała część narodu usłuchali tedy głosu Jahwe, Boga swego, i słów proroka Aggeusza, ponieważ to Jahwe go posłał, ich Bóg; i lud począł się lękać Jahwe.
###### **Ag 1,13**
 Aggeusz zaś, wysłaniec Jahwe, rzekł do ludu z polecenia Jahwe: "Ja jestem z wami - tak mówi Jahwe".
###### **Ag 1,14**
 Pobudził więc Jahwe ducha Zorobabela, syna Salatiela, zarządcy Judei, i ducha arcykapłana Jozuego, syna Jocedeka, i ducha całej pozostałej części narodu, tak że przyszli i rozpoczęli prace przy Domu Jahwe, Boga swego,
# Ag 1 BR
###### **Ag 1,1**
 W drugim roku panowania króla Dariusza, pierwszego dnia szóstego miesiąca, Pan przemówił przez proroka swojego, Aggeusza, do namiestnika Judy, Zorobabela, syna Szealtiela, oraz do arcykapłana Jozuego, syna Josadaka.
###### **Ag 1,2**
 Tak powiedział Pan Zastępów: Naród ten mówi, że jeszcze nie nadszedł czas odbudowy domu Pańskiego.
###### **Ag 1,3**
 Dlatego Pan powiedział przez swojego proroka, Aggeusza:
###### **Ag 1,4**
 Czy to wypada, żebyście mieszkali spokojnie w domach waszych, bogato przyozdobionych, podczas kiedy dom Pański jeszcze leży w gruzach?
###### **Ag 1,5**
 Zastanówcie się zatem teraz - mówi Pan Zastępów - jak się wam wiedzie!
###### **Ag 1,6**
 Siejecie dużo, a zbieracie bardzo niewiele, jecie, ale ciągle jesteście głodni, pijecie, ale nie możecie ugasić swego pragnienia. Przyodziewacie się, ale ciągle odczuwacie zimno, a ci, którzy pracują, żeby coś zarobić, to, co mają, wkładają jakby do dziurawego mieszka.
###### **Ag 1,7**
 I dalej tak mówi Pan Zastępów: Pomyślcie więc, jak się wam żyje!
###### **Ag 1,8**
 Udajcie się tedy w góry, sprowadźcie stamtąd drzewo i zabierzcie się do odbudowy świątyni. Znajdziecie przez to u Mnie uznanie i cześć mi przez to okażecie - mówi Pan.
###### **Ag 1,9**
 Spodziewaliście się tak wiele, a spełniło się waszych nadziei niewiele, a gdy już te nieliczne dobra zgromadziliście w domach, Ja rozproszyłem wszystko. Dlaczego tak się dzieje? - pyta Pan Zastępów. - Dlatego, że mój dom ciągle leży w gruzach, podczas gdy każdy z was krząta się dokoła tylko własnego domu.
###### **Ag 1,10**
 Z tego to powodu niebiosa wstrzymały rosę nad wami, a ziemia przestała wydawać plony.
###### **Ag 1,11**
 Suszę sprowadziłem na pola uprawne i na góry, na zboża, na winnice i oliwki; na wszystko, co przynosi ziemia; na ludzi i na bydło, i na wszystkie dzieła rąk waszych.
###### **Ag 1,12**
 Zorobabel, syn Szealtiela, oraz arcykapłan Jozue, syn Josadaka, i wszyscy, którzy ocaleli z ludu, słuchali głosu swego Boga, a także słów proroka Aggeusza, którego posłał do nich Pan i Bóg. I drżał cały lud z bojaźni przed Panem.
###### **Ag 1,13**
 Aggeusz zaś, wysłannik Pański, przekazał ludowi takie polecenia Pana: Ja jestem z wami - mówi Pan.
###### **Ag 1,14**
 Wtedy pobudził Pan ducha Zorobabela, syna Szealtiela, oraz ducha arcykapłana Jozuego, syna Josadaka, i wreszcie ducha tych wszystkich, którzy z całego ludu zostali przy życiu. Wszyscy oni zgłosili się, aby stanąć do pracy przy domu swego Boga, Pan Zastępów.
###### **Ag 1,15**
 Stało się to dwudziestego czwartego dnia szóstego miesiąca, w drugim roku panowania króla Dariusza.
# Ag 1 WUJ
###### **Ag 1,1**
 Roku wtórego Daryusza króla, miesiąca szóstego, pierwszego dnia miesiąca, stało się słowo Pańskie w ręce Aggeusza proroka do Zorobabela syna Salathiel, książęcia Judzkiego, i do Jezusa, syna Josedek kapłana wielkiego, mówiąc:
###### **Ag 1,2**
 To mówi Pan zastępów, rzekąc: Lud ten mówi, jeszcze czas nie przyszedł budowania domu Pańskiego.
###### **Ag 1,3**
 I stało się słowo w ręce Aggeusza proroka, mówiąc:
###### **Ag 1,4**
 Izali wam jest czas mieszkać w domiech z ozdobnemi słupami, a dom ten pusty?
###### **Ag 1,5**
 A teraz to mówi Pan zastępów: Połóżcie serca wasze na drogi wasze.
###### **Ag 1,6**
 Sialiście wiele, a zwieźliście mało, jedliście, a nie najedliście się: piliście, a nie napiliście się: okryliście się, a nie zagrzaliście się: a kto zyski zbierał, kładł je w dziurawy mieszek.
###### **Ag 1,7**
 To mówi Pan zastępów: Połóżcie serca wasze na drogi wasze.
###### **Ag 1,8**
 Wstąpcie na górę, nawoźcie drzewa, i zbudujcie dom, a będzie mi przyjemny, i rozsławię się, mówi Pan.
###### **Ag 1,9**
 Patrzyliście na więcej, a oto stało się mniej, i wnieśliście do domu, i rozdmuchnąłem je: Dla której przyczyny, mówi Pan zastępów? Iż dom mój jest pusty, a wy się spieszycie każdy do domu swego.
###### **Ag 1,10**
 Dla tego nad wami zakazano niebiosom, aby nie dawały rosy, i zakazano ziemi, aby nie dawała urodzaju swego:
###### **Ag 1,11**
 I przyzwałem suchości na ziemię, i na góry, i na pszenicę, i na wino, i na oliwę, i cokolwiek rodzi ziemia, i na ludzie, i na bydło, i na wszystkę pracę ręczną.
###### **Ag 1,12**
 I usłyszał Zorobabel syn Salathiel, i Jezus syn Josedeków kapłan wielki, i wszystek ostatek ludu głos Pana Boga swego, i słowa Aggeusza proroka, jako posłał go Pan ich do nich, i bał się lud oblicza Pańskiego.
###### **Ag 1,13**
 I rzekł Aggeusz poseł Pański, z posłów Pańskich do ludu, mówiąc: Ja jestem z wami, mówi Pan.
###### **Ag 1,14**
 I wzbudził Pan ducha Zorobabel syna Salathiel, książęcia Judzkiego, i ducha Jezusa syna Josedek kapłana wielkiego, i ducha innych ze wszego ludu: i weszli, i czynili dzieło w domu Pana zastępów Boga swego.
###### **Ag 1,15**
 Dwudziestego i czwartego dnia miesiąca, w szóstym miesiącu, wtórego roku Daryusza króla.
