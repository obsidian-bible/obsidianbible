# 1Mch 4 BT5
###### **1Mch 4,1**
 Gorgiasz wziął z sobą pięć tysięcy piechoty i tysiąc wyborowej jazdy i nocą wojsko wyruszyło z obozu,
###### **1Mch 4,2**
 ażeby niespodzianie napaść na obóz Żydów i zadać im klęskę. Przewodnikami jego byli żołnierze z zamku.
###### **1Mch 4,3**
 Juda jednak dowiedział się o tym i sam ruszył z wojownikami, aby uderzyć na siły królewskie, które pozostały w obozie pod Emaus,
###### **1Mch 4,4**
 jeszcze w tym czasie, kiedy część wojska była z dala od obozu.
###### **1Mch 4,5**
 Gorgiasz w nocy przybył do obozu Judy. Nikogo jednak nie zastał. Szukał więc ich w górach, gdyż mówił sobie: «***Oni uciekają przed nami***».
###### **1Mch 4,6**
 Z nastaniem dnia Juda ukazał się na równinie wraz z trzema tysiącami żołnierzy. Poza pancerzami i mieczami nie mieli żadnej broni, jaką by mieć pragnęli.
###### **1Mch 4,7**
 Zobaczyli zaś, jak wojsko pogan było mocne i opancerzone oraz otoczone jazdą, a sami [żołnierze] byli wyćwiczeni w walce.
###### **1Mch 4,8**
 Wtedy Juda odezwał się do tych ludzi, którzy z nim byli: «***Nie obawiajcie się ich wielkiej liczby! Nie bójcie się ich natarcia!***
###### **1Mch 4,9**
 ***Przypomnijcie sobie, jak to w Morzu Czerwonym ocaleli nasi przodkowie, gdy ścigał ich faraon razem z wojskiem.***
###### **1Mch 4,10**
 ***Teraz więc wołajmy do Nieba, może ma w nas upodobanie, wspomni na przymierze zawarte z przodkami i zgniecie dzisiaj to wojsko przed nami,***
###### **1Mch 4,11**
 ***aby wszystkie narody przekonały się, że istnieje Ten, który wybawia i ocala Izraela***».
###### **1Mch 4,12**
 Poganie podnieśli oczy i zobaczyli, że oni idą przeciwko nim.
###### **1Mch 4,13**
 Wyszli więc z obozu do walki. Ci, którzy byli obok Judy, zagrali na trąbach.
###### **1Mch 4,14**
 Tak rozpoczęto bitwę. Poganie zostali pobici i uciekli na równinę,
###### **1Mch 4,15**
 a którzy uciekali ostatni, wszyscy padli pod mieczem. Ścigano ich aż do Gezer, do Równiny Idumejskiej, do Azotu i do Jamnii. Zginęło z nich blisko trzy tysiące żołnierzy.
###### **1Mch 4,16**
 Potem Juda i wojsko powrócili z pościgu za nimi,
###### **1Mch 4,17**
 Juda zaś powiedział do ludzi: «***Na łupy się nie łakomcie! Walka bowiem jest jeszcze przed nami.***
###### **1Mch 4,18**
 ***Gorgiasz i jego wojsko jest blisko nas, na górze. Stańcie więc teraz przeciwko naszym wrogom, pobijcie ich, a wtedy z całą swobodą będziecie mogli zabrać łupy***».
###### **1Mch 4,19**
 Jeszcze Juda tych [słów] nie dokończył, gdy ukazał się jakiś oddział, który schodził z góry.
###### **1Mch 4,20**
 Zobaczył on, że [swoi] pouciekali, a [tamci] podpalają obóz. Dym bowiem, który się unosił, jasno ukazywał to, co się stało.
###### **1Mch 4,21**
 Ci, którzy to zobaczyli, bardzo się przelękli. Kiedy zaś zobaczyli na równinie także wojsko Judy gotowe do boju,
###### **1Mch 4,22**
 wszyscy uciekli do kraju filistyńskiego.
###### **1Mch 4,23**
 Wtedy Juda wrócił, aby zabrać łupy z obozu. Zabrali wiele złota i srebra, a także purpury fioletowej i czerwonej, i wiele innego bogactwa.
###### **1Mch 4,24**
 Wracając zaś, śpiewali pieśni i dziękowali Niebu, że jest dobre i że na wieki Jego łaska.
###### **1Mch 4,25**
 Tego bowiem dnia dokonało się prawdziwe wybawienie Izraela.
###### **1Mch 4,26**
 Ci z pogan, którzy zdołali się uratować, udali się do Lizjasza i donieśli mu o wszystkim, co się stało.
###### **1Mch 4,27**
 On zaś, dowiedziawszy się o tym, zatrwożył się i upadł na duchu, bo z Izraelem nie tak się stało, jak on sobie życzył, i nie tak wyszło, jak mu król rozkazał.
###### **1Mch 4,28**
 W następnym więc roku zgromadził sześćdziesiąt tysięcy wyborowej piechoty i pięć tysięcy konnicy, aby ich pobić.
###### **1Mch 4,29**
 Przybyli do Idumei i w Bet-Sur rozłożyli się obozem. Juda z dziesięciu tysiącami żołnierzy wyruszył im naprzeciw.
###### **1Mch 4,30**
 Kiedy zobaczył ogromne wojsko, modlił się słowami: «***Błogosławiony jesteś, Wybawicielu Izraela, który natarcie mocarza złamałeś ręką swego sługi, Dawida, i który obóz filistyński wydałeś w ręce Jonatana, syna Saula, i tego, który broń za nim nosił.***
###### **1Mch 4,31**
 ***Tak samo wydaj ten obóz w ręce ludu Twego izraelskiego. Niech będą pohańbieni razem ze swym wojskiem i ze swą konnicą.***
###### **1Mch 4,32**
 ***Ześlij na nich strach, zniszcz ich odwagę i męstwo, niech drżą z obawy przed swoją klęską.***
###### **1Mch 4,33**
 ***Powal ich na ziemię mieczem tych, którzy Cię miłują, i niechaj Cię pieśniami sławią wszyscy, co znają Twoje imię***».
###### **1Mch 4,34**
 Rzucili się jedni na drugich. Z wojska Lizjasza padło blisko pięć tysięcy żołnierzy, i to padło w walce wręcz.
###### **1Mch 4,35**
 Kiedy Lizjasz spostrzegł odwrót swoich szyków i odwagę żołnierzy Judy, jak gotowi byli albo żyć, albo mężnie zginąć, wycofał się do Antiochii i najmował żołnierzy, aby znów znaleźć się w Judei z większą liczbą [wojska].
###### **1Mch 4,36**
 Juda i jego bracia powiedzieli: «***Oto nasi wrogowie zostali starci na proch. Chodźmy oczyścić świątynię i na nowo poświęcić***».
###### **1Mch 4,37**
 Zebrało się więc całe wojsko i poszli na górę Syjon.
###### **1Mch 4,38**
 Tam zobaczyli, że świątynia jest spustoszona, ołtarz zbezczeszczony, bramy spalone, na dziedzińcach krzaki rozrośnięte jakby w lesie albo na jakiejś górze, a pomieszczenia dla kapłanów zamienione w ruinę.
###### **1Mch 4,39**
 Rozdarli więc swoje szaty, podnieśli ogromny płacz, głowy posypali popiołem
###### **1Mch 4,40**
 i upadli twarzą na ziemię. Potem zaś zaczęli grać na trąbach sygnałowych i wołali do Nieba.
###### **1Mch 4,41**
 Wtedy Juda rozkazał ludziom, aby walczyli z tymi, co przebywali na zamku, aż świątynia zostanie oczyszczona.
###### **1Mch 4,42**
 Wybrał kapłanów bez skazy i wiernych Prawu.
###### **1Mch 4,43**
 Oczyścili oni świątynię i wynieśli splugawione kamienie na nieczyste miejsce.
###### **1Mch 4,44**
 Potem naradzali się, co zrobić z ołtarzem całopalenia, który został zbezczeszczony.
###### **1Mch 4,45**
 Przyszła im jednak dobra myśl, żeby go rozwalić, aby nie było dla nich hańbą to, że poganie go zbezcześcili. Rozwalili więc ołtarz,
###### **1Mch 4,46**
 a kamienie złożyli na odpowiednim miejscu na górze świątynnej, na tak długo, aż się ukaże prorok i nimi rozporządzi.
###### **1Mch 4,47**
 Potem, zgodnie z nakazami Prawa, wzięli nie ociosanych kamieni i na wzór poprzedniego wybudowali nowy ołtarz.
###### **1Mch 4,48**
 Naprawili też świątynię i poświęcili wnętrze przybytku i dziedzińce.
###### **1Mch 4,49**
 Wykonali także nowe święte naczynia, a do przybytku wnieśli świecznik, ołtarz kadzenia i stół.
###### **1Mch 4,50**
 Na ołtarzu palili kadzidło, zapalili świece na świeczniku, i jaśniały one w przybytku.
###### **1Mch 4,51**
 Na stole położyli chleby, zawiesili zasłony. Tak do końca doprowadzili wszystko, czego się podjęli.
###### **1Mch 4,52**
 Dwudziestego piątego dnia dziewiątego miesiąca, to jest miesiąca Kislew, sto czterdziestego ósmego roku wstali wcześnie rano
###### **1Mch 4,53**
 i zgodnie z Prawem złożyli ofiarę na nowym ołtarzu całopalenia, który wybudowali.
###### **1Mch 4,54**
 Dokładnie w tym samym czasie i tego samego dnia, którego poganie go zbezcześcili, został on na nowo poświęcony przy śpiewie pieśni i grze na cytrach, harfach i cymbałach.
###### **1Mch 4,55**
 Cały lud upadł na twarz, oddał pokłon i aż pod niebo wysławiał Tego, który im poszczęścił.
###### **1Mch 4,56**
 W osiem dni dokonali poświęcenia ołtarza, a przy tym z radością złożyli całopalenia, ofiarę biesiadną i ofiarę uwielbienia.
###### **1Mch 4,57**
 Fasadę świątyni ozdobili wieńcami i małymi tarczami, odbudowali bramy i pomieszczenia dla kapłanów i pozakładali do nich drzwi,
###### **1Mch 4,58**
 a wśród ludu nastała bardzo wielka radość z tego powodu, że skończyła się hańba, którą sprowadzili poganie.
###### **1Mch 4,59**
 Juda zaś, jego bracia i całe zgromadzenie Izraela postanowili, że uroczystość poświęcenia ołtarza będą z weselem i radością obchodzili rokrocznie przez osiem dni, począwszy od dnia dwudziestego piątego miesiąca Kislew.
###### **1Mch 4,60**
 W tym też czasie wokoło góry Syjon wybudowali wysoki mur i mocne wieże jako obronę przeciw poganom, aby nie przyszli i nie podeptali ich, jak to już poprzednio zrobili.
###### **1Mch 4,61**
 [Juda] zostawił też tam wojsko, które miało jej strzec. Obwarował także Bet-Sur, aby jej strzegło, a lud miał warownię od strony Idumei.
# 1Mch 4 PAU
###### **1Mch 4,1**
 Gorgiasz wziął pięć tysięcy piechoty i tysiąc wyborowych jeźdźców i wyprowadził ich nocą,
###### **1Mch 4,2**
 aby z zaskoczenia uderzyć na wojsko Żydów i zadać mu klęskę. Mieszkańcy twierdzy byli jego przewodnikami.
###### **1Mch 4,3**
 Juda dowiedział się o tym i wyruszył ze swoimi ludźmi, aby uderzyć na wojsko króla, obozujące w Emaus,
###### **1Mch 4,4**
 dopóki tamte oddziały były jeszcze poza obozem.
###### **1Mch 4,5**
 Gorgiasz przybył nocą do obozu Judy i nie zastał nikogo. Szukał więc ich w górach, gdyż pomyślał sobie: „Oni uciekają przed nami”.
###### **1Mch 4,6**
 Gdy tylko nastał dzień, Juda pojawił się na równinie z trzema tysiącami ludzi, którzy nie mieli takich zbroi ani mieczy, jakby tego pragnęli.
###### **1Mch 4,7**
 Zobaczyli zaś, że obóz wojsk obcych narodów był potężny i umocniony. Otaczała go jazda, a wszyscy byli wyćwiczeni w walce.
###### **1Mch 4,8**
 Juda powiedział do swoich ludzi: „Nie bójcie się ich liczby ani nie lękajcie się ich wyglądu.
###### **1Mch 4,9**
 Wspomnijcie, jak nasi ojcowie zostali ocaleni w Morzu Czerwonym, gdy ścigał ich faraon ze swoim wojskiem.
###### **1Mch 4,10**
 A teraz wołajmy do Nieba, może okaże nam przychylność, wspomni na przymierze ojców i zniszczy dziś to wojsko, które jest przed nami.
###### **1Mch 4,11**
 Niech wszystkie narody poznają, że istnieje Ten, który wykupuje i ocala Izraela”.
###### **1Mch 4,12**
 Gdy cudzoziemcy podnieśli swoje oczy, zobaczyli ich nadchodzących z naprzeciwka
###### **1Mch 4,13**
 i wyszli z obozu do bitwy. Ludzie Judy zadęli w trąby.
###### **1Mch 4,14**
 Rozpoczęła się bitwa. Poganie zostali pobici i uciekli na równinę.
###### **1Mch 4,15**
 Wszyscy zaś, którzy nie zdążyli uciec, padli od miecza. Ścigali ich aż do Gezer, do równin Idumei, Azotu i Jamnii. Zginęło ich trzy tysiące ludzi.
###### **1Mch 4,16**
 Kiedy Juda powrócił ze swoim wojskiem z pościgu,
###### **1Mch 4,17**
 powiedział do ludu: „Nie pożądajcie łupów, ponieważ czeka nas jeszcze bitwa.
###### **1Mch 4,18**
 Gorgiasz i jego wojsko są niedaleko na górze. Stawcie czoła nieprzyjaciołom i pokonajcie ich. Potem bez przeszkód bierzcie łupy”.
###### **1Mch 4,19**
 Juda nie skończył jeszcze mówić, gdy pojawił się jakiś oddział schodzący z góry.
###### **1Mch 4,20**
 Zobaczyli oni, że ich wojsko zostało zmuszone do ucieczki, a obóz się palił. Dym, który widzieli, wskazywał na to, co się wydarzyło.
###### **1Mch 4,21**
 Na ten widok bardzo się przerazili. Gdy jeszcze ujrzeli na równinie wojsko Judy gotowe do bitwy,
###### **1Mch 4,22**
 wszyscy uciekli do kraju Filistynów.
###### **1Mch 4,23**
 Juda zawrócił, aby złupić obóz. Zabrali wiele srebra i złota, czerwonej i fioletowej purpury i wiele innych bogactw.
###### **1Mch 4,24**
 Wracając, śpiewali hymny i wysławiali Niebo, że jest dobre i że na wieki trwa Jego miłosierdzie.
###### **1Mch 4,25**
 W tym dniu dokonało się wielkie ocalenie Izraela.
###### **1Mch 4,26**
 Cudzoziemcy, którzy ocaleli, przyszli do Lizjasza i opowiedzieli mu o wszystkim, co się wydarzyło.
###### **1Mch 4,27**
 Gdy to usłyszał, zasmucił się i zatrwożył, ponieważ wyprawa przeciwko Izraelowi nie przebiegła po jego myśli i nie wypełnił rozkazu króla.
###### **1Mch 4,28**
 Aby więc ich pobić, w następnym roku zgromadził sześćdziesiąt tysięcy doborowej piechoty i pięć tysięcy jazdy.
###### **1Mch 4,29**
 Przybyli do Idumei i rozbili obóz w Bet-Sur. Juda wyszedł im naprzeciw z dziesięcioma tysiącami ludzi.
###### **1Mch 4,30**
 Gdy zobaczył ten potężny obóz, modlił się, mówiąc: „Błogosławiony jesteś, Zbawicielu Izraela, który odparłeś atak mocarza ręką swego sługi Dawida i oddałeś wojsko cudzoziemców w ręce syna Saula, Jonatana, i giermka noszącego jego broń.
###### **1Mch 4,31**
 Podobnie wydaj to wojsko w ręce ludu twego, Izraela. Niech wstydem okryją się z powodu swego wojska i jazdy.
###### **1Mch 4,32**
 Napełnij ich strachem i odbierz im odwagę, choć są pewni swej siły. Niech przerazi ich widmo zguby.
###### **1Mch 4,33**
 Niech miłujący Ciebie pokonają ich mieczem. Niech hymny Twych wyznawców wychwalają Ciebie”.
###### **1Mch 4,34**
 Uderzyli jedni na drugich. Z wojska Lizjasza padło w walce wręcz około pięć tysięcy ludzi.
###### **1Mch 4,35**
 Lizjasz, widząc ucieczkę swojego wojska oraz rosnącą odwagę żołnierzy Judy i ich gotowość do mężnej walki na śmierć i życie, powrócił do Antiochii. Tam zwerbował liczne wojska najemne i zamierzał ponownie zjawić się w Judei.
###### **1Mch 4,36**
 Juda i jego bracia powiedzieli: „Oto nasi wrogowie zostali pokonani. Chodźmy oczyścić i na nowo poświęcić świątynię”.
###### **1Mch 4,37**
 Zebrało się całe wojsko i weszli na górę Syjon.
###### **1Mch 4,38**
 Zobaczyli spustoszoną świątynię, zbezczeszczony ołtarz, spalone bramy, zrujnowane komnaty oraz krzaki rosnące na dziedzińcach jak w lesie albo na górach.
###### **1Mch 4,39**
 Rozdarli swoje szaty, głośno płakali i posypali głowy popiołem.
###### **1Mch 4,40**
 Upadli twarzą na ziemię i na sygnał trąb wołali do Nieba.
###### **1Mch 4,41**
 Wówczas Juda rozkazał ludziom, aby walczyli z tymi, którzy przebywali w twierdzy, dopóki świątynia nie zostanie oczyszczona.
###### **1Mch 4,42**
 Wybrali nieskazitelnych i wiernych Prawu kapłanów i
###### **1Mch 4,43**
 oczyścili świątynię. Wynieśli zbezczeszczone kamienie na miejsce nieczyste.
###### **1Mch 4,44**
 Potem naradzali się, co powinni zrobić ze sprofanowanym ołtarzem całopaleń.
###### **1Mch 4,45**
 Zrodziła się wśród nich dobra myśl, aby go zburzyć, bo zbezczeszczony przez pogan był dla nich znakiem hańby. Zburzyli więc ołtarz,
###### **1Mch 4,46**
 a kamienie złożyli w odpowiednim miejscu na górze Domu Pańskiego, aż przyjdzie prorok, aby o nich zdecydować.
###### **1Mch 4,47**
 Następnie zgodnie z Prawem wzięli nieociosane kamienie i wznieśli nowy ołtarz, na wzór poprzedniego.
###### **1Mch 4,48**
 Odbudowali świątynię oraz wnętrze domu Pańskiego i poświęcili dziedzińce.
###### **1Mch 4,49**
 Sporządzili nowe sprzęty święte, wnieśli do świętego mieszkania świecznik, ołtarz kadzielny i stół chlebów poświęconych.
###### **1Mch 4,50**
 Złożyli na ołtarzu ofiarę kadzielną i zapalili lampy, które były na świeczniku, rozświetlając mieszkanie.
###### **1Mch 4,51**
 Położyli chleby na stole chlebów poświęconych i zawiesili zasłonę. W ten sposób ukończyli podjęte dzieło.
###### **1Mch 4,52**
 Dwudziestego piątego dnia dziewiątego miesiąca, to jest miesiąca Kislew, sto czterdziestego ósmego roku wstali wcześnie rano.
###### **1Mch 4,53**
 Zgodnie z Prawem złożyli ofiarę na nowym ołtarzu całopaleń, który wybudowali.
###### **1Mch 4,54**
 Został on ponownie poświęcony pośród śpiewów hymnów, dźwięków cytr, harf i cymbałów dokładnie o tej porze i tego dnia, w którym był sprofanowany przez pogan.
###### **1Mch 4,55**
 Cały lud upadł na twarz, złożył pokłon i wychwalał pod niebiosa Tego, który dał im powodzenie.
###### **1Mch 4,56**
 Przez osiem dni obchodzili ponowne poświęcenie ołtarza. Z radością złożyli całopalenia, składali ofiary wspólnotowe i uwielbienia.
###### **1Mch 4,57**
 Przyozdobili fasadę mieszkania złotymi wieńcami i pierścieniami, odnowili wejścia, komnaty i wstawili drzwi.
###### **1Mch 4,58**
 Zapanowała niezwykła radość wśród ludu, bo usunięto hańbę sprowadzoną przez pogan.
###### **1Mch 4,59**
 Juda, jego bracia i całe zgromadzenie Izraela postanowili, aby we właściwym czasie, to jest co roku przez osiem dni, od dwudziestego piątego dnia miesiąca Kislew, obchodzić z radością i weselem uroczystość ponownego poświęcenia ołtarza.
###### **1Mch 4,60**
 Wtedy zbudowali też dokoła góry Syjon wysoki mur i potężne wieże, ażeby poganie już więcej nie przyszli jej podeptać, jak to uczynili poprzednio.
###### **1Mch 4,61**
 Dla jej obrony umieścili tam wojsko. Umocnili także Bet-Sur, aby lud miał warownię od strony Idumei.
# 1Mch 4 BP
###### **1Mch 4,1**
 Gorgiasz wziął z sobą pięć tysięcy piechoty oraz tysiąc najlepszych jeźdźców i wyruszył nocą z obozu,
###### **1Mch 4,2**
 aby znienacka uderzyć na obóz Żydów i zadać im klęskę. Ludzie z załogi zamkowej byli jego przewodnikami.
###### **1Mch 4,3**
 Na wieść o tym Juda wyruszył wraz ze swymi wojownikami, aby pobić siły królewskie znajdujące się w Emmaus,
###### **1Mch 4,4**
 dopóki jeszcze tamta część wojska była rozproszona.
###### **1Mch 4,5**
 Gorgiasz przybył w nocy do obozu Judy i nikogo nie znalazł. Szukał ich więc w górach sądząc, że uciekają przed nim.
###### **1Mch 4,6**
 O świcie ukazał się na równinie Juda z trzema tysiącami ludzi. Oprócz pancerzy i mieczy nie mieli innej broni, jaka im była potrzebna.
###### **1Mch 4,7**
 Ujrzeli silny i obwarowany obóz pogan, a wokół niego jazdę złożoną z doświadczonych w walkach żołnierzy.
###### **1Mch 4,8**
 Wówczas przemówił Juda do ludzi, którzy przy nim byli: "Nie bójcie się, że jest ich tak wielu ani nie lękajcie się ich natarcia.
###### **1Mch 4,9**
 Przypomnijcie sobie, jak ocaleni zostali w Morzu Czerwonym nasi ojcowie, gdy ścigał ich faraon na czele wojska.
###### **1Mch 4,10**
 Wołajmy do nieba, może będzie dla nas łaskawe i pamiętając o Przymierzu naszych ojców jeszcze dziś zetrze stojące przed nami wojsko,
###### **1Mch 4,11**
 aby wszystkie narody poznały, że istnieje Ten, który wybawia i ocala Izraela".
###### **1Mch 4,12**
 Poganie podnieśli oczy i ujrzeli ich idących naprzeciw.
###### **1Mch 4,13**
 Wtedy wyszli z obozu do walki. Wojownicy otaczający Judę zadęli w trąby.
###### **1Mch 4,14**
 Rozgorzała bitwa. Poganie zostali pobici i uciekli na równinę.
###### **1Mch 4,15**
 Ci, którzy wycofywali się na końcu, polegli wszyscy od miecza. I ścigali ich aż do Gezer, do równiny idumejskiej, do Azotu i Jamnii. Zginęło spośród nich blisko trzy tysiące ludzi.
###### **1Mch 4,16**
 Juda powróciwszy ze swym wojskiem z pościgu
###### **1Mch 4,17**
 rzekł do ludu: "Nie bądźcie chciwi łupów, gdyż czeka nas jeszcze walka.
###### **1Mch 4,18**
 Gorgiasz stoi z wojskiem na pobliskim wzgórzu. Stawcie im czoła i pokonajcie ich, a wtedy spokojnie będziecie mogli zabrać łupy".
###### **1Mch 4,19**
 Jeszcze Juda nie skończył mówić, a już ukazał się schodzący ze wzgórza oddział żołnierzy.
###### **1Mch 4,20**
 Dostrzegli oni, że wojsko uciekło, a obóz jest spalony, gdyż o tym, co się stało, mówił idący w górę słup dymu.
###### **1Mch 4,21**
 Widząc to przerazili się, zwłaszcza że zobaczyli na równinie gotowe do walki wojsko Judy.
###### **1Mch 4,22**
 Uciekli więc wszyscy do kraju Filistynów.
###### **1Mch 4,23**
 Juda zaś zawrócił, aby złupić obóz. Zebrał wiele złota, srebra, tkanin z purpury jasnej i ciemnej i mnóstwo innych cennych rzeczy.
###### **1Mch 4,24**
 Wracając śpiewali pieśni pochwalne i wielbili niebiosa za dobroć i wieczne miłosierdzie.
###### **1Mch 4,25**
 Doznał bowiem Izrael w owym dniu wielkiej łaski wybawienia.
###### **1Mch 4,26**
 Ci spośród pogan, którzy zdołali się uratować, udali się do Lizjasza i donieśli mu o wszystkim, co się wydarzyło.
###### **1Mch 4,27**
 Usłyszawszy to, przeraził się i upadł na duchu, gdyż losy Izraela potoczyły się nie tak, jak sobie tego życzył, i nie zdołał wypełnić polecenia króla.
###### **1Mch 4,28**
 Dlatego w następnym roku powołał pod broń sześćdziesiąt tysięcy wyborowej piechoty i pięć tysięcy konnicy, aby ich pokonać.
###### **1Mch 4,29**
 Gdy przybyli do Idumei i rozbili obóz w Betsur, wyruszył przeciwko nim Juda z dziesięcioma tysiącami ludzi.
###### **1Mch 4,30**
 Ujrzawszy ogromne wojsko modlił się tymi słowy: "Błogosławiony jesteś, Zbawco Izraela, który ręką sługi Twego Dawida złamałeś natarcie olbrzyma i wydałeś obóz cudzoziemców w ręce Jonatana, syna Saula, i jego giermka.
###### **1Mch 4,31**
 Tak też wydaj ten obóz w ręce Twego ludu izraelskiego. Niech pohańbieni będą wraz ze swym wojskiem i konnicą.
###### **1Mch 4,32**
 Ześlij na nich strach, odbierz im odwagę i męstwo, niech się przerażą własną klęską.
###### **1Mch 4,33**
 Powal ich mieczem tych, którzy Cię miłują, a wszyscy znający Twe Imię sławić Cię będą w pieśniach".
###### **1Mch 4,34**
 Starli się w boju. W walce z nimi wojsko Lizjasza straciło blisko pięć tysięcy ludzi.
###### **1Mch 4,35**
 Widząc więc Lizjasz klęskę swych oddziałów i odwagę żołnierzy Judy, gotowych żyć albo mężnie umrzeć, wycofał się do Antiochii i werbował najemnych żołnierzy, aby znów pojawić się w Judei z jeszcze większą siłą.
###### **1Mch 4,36**
 Wówczas rzekł Juda i jego bracia: "Patrzcie, oto starci zostali wasi wrogowie. Ruszajmy zatem oczyścić Świątynię i poświęcić ją na nowo".
###### **1Mch 4,37**
 Zebrało się całe wojsko i udali się na górę Syjon.
###### **1Mch 4,38**
 Ujrzeli spustoszony Przybytek, zbezczeszczony ołtarz, spalone bramy, dziedzińce zarośnięte krzewami niczym las lub jakaś góra, siedziby kapłanów zniszczone.
###### **1Mch 4,39**
 Rozdarli więc swoje szaty i wybuchnęli głośnym płaczem. [Głowy] posypywali popiołem
###### **1Mch 4,40**
 i padali twarzami na ziemię. Potem na sygnał trąb [zaczęli] wołać do nieba.
###### **1Mch 4,41**
 Juda rozkazał mężom walczyć z załogą zamku do chwili oczyszczenia Przybytku.
###### **1Mch 4,42**
 Następnie wybrał nienagannych i wiernych Prawu kapłanów.
###### **1Mch 4,43**
 Oczyścili oni Świątynię i usunęli splugawione kamienie na miejsce nieczyste.
###### **1Mch 4,44**
 Naradzali się też, co mają zrobić ze zbezczeszczonym ołtarzem całopalenia.
###### **1Mch 4,45**
 Przyszła im myśl szczęśliwa, aby go zburzyć, ponieważ zbezczeszczony przez pogan byłby dla nich piętnem hańby. Rozebrali ołtarz,
###### **1Mch 4,46**
 a kamienie złożyli w oznaczonym miejscu na świątynnej górze, aż pojawi się Prorok i orzeknie, co z nimi zrobić.
###### **1Mch 4,47**
 Potem zgodnie z nakazem Prawa wzięli nie ciosane kamienie i na wzór dawnego ołtarza zbudowali nowy.
###### **1Mch 4,48**
 Odbudowali też Świątynię i jej wnętrze oraz poświęcili dziedzińce.
###### **1Mch 4,49**
 Sporządzili nowe naczynia święte i wnieśli do Przybytku świecznik, ołtarz kadzenia i stół.
###### **1Mch 4,50**
 Następnie spalili na ołtarzu kadzidło i zapalili światła na świeczniku, które oświetliły Przybytek.
###### **1Mch 4,51**
 Złożyli na stole chleby i zawiesili zasłonę. W ten sposób ukończyli całe podjęte dzieło.
###### **1Mch 4,52**
 [Dnia] dwudziestego piątego dziewiątego miesiąca - był to miesiąc Kasleu - roku sto czterdziestego ósmego wstali o świcie
###### **1Mch 4,53**
 i, jak nakazuje Prawo, złożyli ofiarę na nowo zbudowanym ołtarzu całopalenia.
###### **1Mch 4,54**
 O tej samej porze i tego samego dnia, w którym został zbezczeszczony przez pogan, poświęcono go na nowo pośród śpiewów pochwalnych, przy dźwiękach cytr, harf i cymbałów.
###### **1Mch 4,55**
 Padł tedy wszystek lud na twarz czcząc i wysławiając pod niebiosa Tego, który był sprawcą ich szczęścia.
###### **1Mch 4,56**
 Przez osiem dni obchodzili uroczystość poświęcenia ołtarza i radośnie składali całopalne ofiary - ofiary za ocalenie i ofiary dziękczynne.
###### **1Mch 4,57**
 Fronton Świątyni ozdobili złotymi wieńcami i małymi tarczami; wznieśli nowe bramy i mieszkania kapłanów, zaopatrując je w drzwi.
###### **1Mch 4,58**
 I lud bardzo się cieszył, gdyż zmazano hańbę sprowadzoną przez pogan.
###### **1Mch 4,59**
 Juda zaś, jego bracia i zgromadzenie całego ludu izraelskiego postanowili obchodzić corocznie z radością i weselem uroczystość poświęcenia ołtarza przez osiem dni, poczynając od dwudziestego piątego dnia miesiąca Kasleu.
###### **1Mch 4,60**
 W tym samym czasie otoczyli górę Syjon wysokimi murami i warownymi wieżami, aby nie dopuścić do powtórnego zniszczenia jej przez pogan.
###### **1Mch 4,61**
 [Juda] zostawił tam oddział wojska, aby jej strzegł. W tym samym celu umocnił Betsur. Dzięki temu lud miał obronne miejsce od strony Idumei.
# 1Mch 4 BR
###### **1Mch 4,1**
 Tymczasem Gorgiasz wziął ze sobą część wojska, liczącą pięć tysięcy pieszych wojowników i tysiąc wyborowych jeźdźców, i wyruszył z nią w środku nocy.
###### **1Mch 4,2**
 Chciał on zaskoczyć oddziały izraelskie i niespodziewanie je zaatakować. Ludzie z twierdzy wskazywali mu drogę.
###### **1Mch 4,3**
 Ale Juda dowiedział się o tym i sam wyruszył ze swoimi wojownikami aby uderzyć na oddziały królewskie pozostałe w obozie koło Emmaus,
###### **1Mch 4,4**
 dopóki były one oddzielone od reszty wojska.
###### **1Mch 4,5**
 Była jeszcze noc, kiedy Gorgiasz dotarł do obozu żydowskiego, ale nie znalazł tam już nikogo. Postanowił tedy szukać w górach, bo był przekonany, że tam się przed nim schronili.
###### **1Mch 4,6**
 Z nastaniem dnia oczom jego ukazał się na równinie Juda z trzema tysiącami swoich wojowników. Nie byli oni jednak tak wyposażeni i uzbrojeni, jak by sobie tego życzyli.
###### **1Mch 4,7**
 Kiedy Izraelici zobaczyli obóz wojenny obcych ludów - silny, mocno zbudowany, otoczony dokoła konnicą - i wojowników bardzo doświadczonych w boju,
###### **1Mch 4,8**
 Juda powiedział do swoich ludzi: Nie bójcie się, że jest ich tak wielu, nie lękajcie się ich oręża!
###### **1Mch 4,9**
 Przypomnijcie sobie, jak nasi ojcowie zostali przeprowadzeni przez Morze Czerwone, gdy ścigał ich faraon z całym swoim wojskiem.
###### **1Mch 4,10**
 Wezwijcie niebiosa na pomoc. Może wspomną na przymierze zawarte z ojcami naszymi i zechcą dziś na naszych oczach porazić śmiertelnie to wojsko.
###### **1Mch 4,11**
 Wtedy dowiedzą się wszystkie narody, że jest ktoś, kto uwalnia i ratuje Izraela.
###### **1Mch 4,12**
 Kiedy obcy wojownicy spojrzeli przed siebie i zobaczyli, że nadciągają Żydzi,
###### **1Mch 4,13**
 wyszli ze swego obozu i ustawili się do walki. Wtedy też zadęli w rogi wojenne ludzie Judy.
###### **1Mch 4,14**
 I starły się oba wojska. I zostały pokonane oddziały obcych ludów i zaczęły uciekać w stronę równiny.
###### **1Mch 4,15**
 Ci, którzy nie zdołali umknąć, zginęli pod ciosami mieczy. Żydzi ścigali ich aż do Gezer, do równiny idumejskiej, do Azotu i Jamni, zabijając po drodze prawie trzy tysiące z nich.
###### **1Mch 4,16**
 Gdy Juda i jego ludzie zaprzestali pościgu i wrócili do siebie,
###### **1Mch 4,17**
 Juda odezwał się do nich w te słowa: Porzućcie na razie myśli o łupach, gdyż czeka nas jeszcze jedna walka.
###### **1Mch 4,18**
 W górach, bardzo blisko nas, stoi ze swymi oddziałami Gorgiasz. Przygotujcie się tedy do walki z waszymi wrogami i rozgromcie ich. Potem dopiero będziecie mogli z całym spokojem brać wasze łupy.
###### **1Mch 4,19**
 Kiedy Juda jeszcze to mówił, pojawiły się wrogie oddziały schodzące z gór.
###### **1Mch 4,20**
 Wrogowie owi, zobaczywszy, że ich ludzie zostali pokonani, a Żydzi podpalili obóz - o czym świadczy wysoko wznoszący się dym - przerazili się bardzo.
###### **1Mch 4,21**
 Kiedy ponadto zobaczyli, że oddziały Judy stoją na równinie gotowe do boju,
###### **1Mch 4,22**
 wszyscy uciekli, szukając schronienia na ziemi filistyńskiej.
###### **1Mch 4,23**
 Teraz dopiero zabrał się Juda do przetrząsania całego obozu. Znaleziono wiele złota i srebra, wiele [tkaniny] purpurowej fioletowej i czerwonej oraz wiele innych kosztowności.
###### **1Mch 4,24**
 Wracając do siebie wychwalali i wielbili niebiosa tymi słowami: Dobry jest [Pan] i na wieki miłosierdzie Jego.
###### **1Mch 4,25**
 Tego dnia bowiem został Izrael cudownie ocalony.
###### **1Mch 4,26**
 Ci z obcych ludów, którzy zdołali się uratować, przyszli do Lizjasza i opowiedzieli o wszystkim, co się stało.
###### **1Mch 4,27**
 Na wieść o tym ogarnęło go wielkie przygnębienie i niepokój. Wyprawa przeciw Izraelowi nie przebiegała bowiem tak, jak on tego pragnął, i rozkaz króla nie został wykonany.
###### **1Mch 4,28**
 Dlatego tez na następny rok przygotował sześćdziesiąt tysięcy wyborowych wojowników pieszych oraz pięć tysięcy jeźdźców na wyprawę i postanowił po raz drugi wyruszyć przeciw Żydom.
###### **1Mch 4,29**
 Skierowali się do Idumei i rozbili swoje namioty koło Bet-Sur. Naprzeciw nim wyruszył Juda z dziesięcioma tysiącami swoich wojowników.
###### **1Mch 4,30**
 Zobaczywszy rozległe obozowisko oddziałów nieprzyjacielskich, Juda tak zaczął się modlić: Bądź błogosławiony, Wybawco Izraela! Ty, poprzez Twojego sługę Dawida, pokonałeś kiedyś strasznego olbrzyma. Ty również wydałeś kiedyś w ręce Jonatana, syna Saula, i jego giermka cały obóz wojenny Filistynów.
###### **1Mch 4,31**
 Racz teraz wydać w ręce ludu izraelskiego to wojsko! Niech słuszne pohańbienie spadnie na nich wszystkich, na pieszych i jeźdźców.
###### **1Mch 4,32**
 Napełnij ich przerażeniem, pozbaw ich tej butnej zarozumiałości. Niech zadrżą na myśl o swojej klęsce.
###### **1Mch 4,33**
 Niech wyginą od mieczów tych, którzy Cię kochają. A wtedy wszyscy, którzy znają Twoje imię, będą wyśpiewywać Twoją chwałę.
###### **1Mch 4,34**
 Gdy starły się z sobą oba wojska, poległo około pięciu tysięcy wojowników Lizjasza.
###### **1Mch 4,35**
 Wtedy Lizjasz widząc, jak wielkie straty poniosło jego wojsko i z jak wielką odwagą wojownicy Judy walczyli na śmierć i życie, powrócił do Antiochii, aby zebrać nowych najemników i z większą siłą jeszcze raz wyruszyć na Judeę.
###### **1Mch 4,36**
 Tymczasem Juda i jego bracia mówili sobie: Tak więc nasi wrogowie zostali całkowicie pokonani. Udajmy się teraz do Jerozolimy, aby oczyścić świątynię i na nowo ją poświęcić.
###### **1Mch 4,37**
 Zebrało się tedy całe wojsko i wszyscy udali się na górę Syjon.
###### **1Mch 4,38**
 A tam zobaczyli przybytek Pański całkowicie spustoszony. Zbezczeszczony był ołtarz całopalenia, bramy popalone, w przedsionkach - pełno dzikiej roślinności, jak w jakimś lesie albo górach, a wszystkie budowle wokół zburzone.
###### **1Mch 4,39**
 Zaczęli tedy rozdzierać szaty, lamentować głośno, krzyczeć i posypywać sobie głowy popiołem.
###### **1Mch 4,40**
 I rzucali się twarzą na ziemię, a potem dęli w trąby na alarm i niebiosa wzywali na pomoc.
###### **1Mch 4,41**
 A Juda wydał rozkaz, żeby atakowano załogę twierdzy dopóty, dopóki świątynia nie zostanie oczyszczona.
###### **1Mch 4,42**
 Potem wybrał nienagannych i najwierniejszych prawu kapłanów,
###### **1Mch 4,43**
 którzy mieli dokonać oczyszczenia świątyni i poznosić na miejsce, gdzie wyrzuca się nieczystości, wszystkie zbrukane kamienie.
###### **1Mch 4,44**
 Następnie odbyli naradę w sprawie zbezczeszczonego ołtarza całopalenia.
###### **1Mch 4,45**
 Doszli do wniosku, że należy go całkowicie zburzyć, bo jako zbezczeszczony przez obcych przynosiłby im hańbę. Dlatego zburzyli ołtarz,
###### **1Mch 4,46**
 a kamienie z niego złożyli na wyznaczonym miejscu na zboczu góry świątynnej, gdzie miały pozostać do czasu pojawienia się proroka, który rozstrzygnie, co należy z nimi zrobić.
###### **1Mch 4,47**
 Potem wzięli, zgodnie z prawem, nieociosane kamienie i zbudowali nowy ołtarz, który wyglądał zupełnie tak samo jak dawny.
###### **1Mch 4,48**
 Odbudowali również Święte Świętych oraz całe wnętrze świątyni i oczyścili przedsionki.
###### **1Mch 4,49**
 Wykonali nowe święte naczynia i ustawili na nowo w świątyni świeczniki, ołtarz kadzenia i stół na chleby pokładne.
###### **1Mch 4,50**
 Wreszcie położyli na stole chleby pokładne i zawiesili zasłonę.
###### **1Mch 4,51**
 I w ten sposób zakończyli wszystkie prace, które rozpoczęli.
###### **1Mch 4,52**
 Dwudziestego piątego dnia dziewiątego miesiąca, to jest miesiąca Kislew, w roku sto czterdziestym ósmym wstali wczesnym rankiem
###### **1Mch 4,53**
 i złożyli na nowym ołtarzu całopaleń ofiarę zgodną z przepisami prawa.
###### **1Mch 4,54**
 W tym samym czasie, i w tym samym dniu, w którym ołtarz ten został kiedyś zbezczeszczony przez obcych, dokonano teraz jego poświęcenia na nowo wśród śpiewów, przy dźwiękach cytr, harf i cymbałów.
###### **1Mch 4,55**
 Cały lud upadł na twarz, modlił się i wychwalał niebiosa za to, że spotkało go takie nieszczęście.
###### **1Mch 4,56**
 Przez osiem dni obchodzili uroczyście poświęcenie ołtarza, składając w radości ofiary całopalenia, a także pojednania i uwielbienia.
###### **1Mch 4,57**
 Przednią ścianę świątyni ozdobili wieńcami i małymi tarczami ze złota. Odnowili bramy i wszystkie budynki pomocnicze, do których powstawiali drzwi.
###### **1Mch 4,58**
 Cały lud cieszył się bardzo, bo oto została usunięta hańba, którą ściągnęły na nie obce narody.
###### **1Mch 4,59**
 Juda, razem ze swymi braćmi i całym zgromadzeniem Izraela powziął postanowienie, że co roku o tym samym czasie będzie się uroczyście obchodzić dni poświęcenia ołtarza. Uroczystości miały się rozpoczynać dwudziestego piątego dnia miesiąca Kislew i winny trwać przez osiem dni.
###### **1Mch 4,60**
 Wkrótce potem całą górę Syjon otoczono wysokim murem z wieżami obronnymi, żeby nikt z obcych nie mógł się przedostać na ten teren i go nie zbezcześcił, jak to już raz się zdarzyło.
###### **1Mch 4,61**
 Ustanowił też Juda specjalne straże, żeby strzegły góry. Polecił także umocnić Bet-Sur i osadził tam załogę, żeby zabezpieczyć górę od strony Idumei.
# 1Mch 4 WUJ
