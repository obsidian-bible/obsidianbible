# Est 5 BT5
##### tekst hebrajski
###### **Est 5,1**
  Trzeciego dnia Estera ubrała się po królewsku i weszła na wewnętrzny dziedziniec domu królewskiego, naprzeciw pokojów króla. Król siedział wtedy na królewskim tronie w sali królewskiej naprzeciw bramy wejściowej pałacu.
###### **Est 5,2**
 A gdy król zobaczył królową Esterę stojącą na dziedzińcu, znalazła ona łaskę w jego oczach i wyciągnął król do Estery złote berło, które miał w ręce, i przybliżyła się Estera, i dotknęła końca berła.
##### tekst grecki
###### **Est 5,1**
 Trzeciego dnia, gdy skończyła się modlić, zdjęła szaty pokutne i przyodziała się we wspaniałości swoje.
###### **Est 5,1a**
 A gdy już wyglądała pięknie, wezwawszy Boga, który widzi wszystko i ocala, wzięła ze sobą dwie służebnice. Na jednej z nich opierała się, jakby omdlewając z rozkoszy, a druga szła za nią, podtrzymując jej tren.
###### **Est 5,1b**
 Ona zaś zapłonęła wdziękiem swej piękności, a oblicze jej rozjaśniło się jakby było pełne miłości, lecz serce miała ściśnięte strachem.
###### **Est 5,1c**
 Przeszedłszy przez wszystkie drzwi, stanęła przed królem. A on siedział na tronie swego królestwa, strojny we wszystkie swoje wspaniałe szaty, cały w złocie i drogich kamieniach, a wzbudzał wielki postrach.
###### **Est 5,1d**
 I podniósł majestatyczne swe oblicze, i spojrzał w największym gniewie. A królowa zachwiała się, zmieniła się na twarzy, zbladła i przechyliła się na głowę służebnicy, która ją wyprzedzała.
###### **Est 5,1e**
 I przemienił Bóg usposobienie króla na łaskawe, tak że zaniepokojony zeskoczył ze swego tronu i wziął ją w ramiona, aż doszła do przytomności. I pocieszał ją łagodnymi słowami, mówiąc:
###### **Est 5,1f**
 «***Co ci się stało, Estero? Jam brat twój, bądź dobrej myśli! Nie umrzesz, ponieważ nasze zarządzenie jest ogólne, przybliż się!***»
###### **Est 5,2**
 I wyciągnął złote berło, i położył je na jej szyi, pocałował ją i rzekł: «***Mów do mnie!***»
###### **Est 5,2a**
  I rzekła do niego: «***Ujrzałam cię, panie, jak anioła Bożego, i poruszyło się serce moje z obawy przed twoim majestatem, ponieważ jesteś godny podziwu, panie, a oblicze twoje jest pełne wdzięku***».
###### **Est 5,2b**
  A gdy to mówiła, padła zemdlona. Król zaś zaniepokoił się, a cała jego służba dodawała jej odwagi.
###### **Est 5,3**
 I król rzekł do niej: «***Czego chcesz, królowo Estero, i jaka jest prośba twoja? – choćby to była połowa królestwa, będzie ci dane***».
###### **Est 5,4**
 Na to Estera odpowiedziała: «***Jeśli król uzna to za słuszne, to niech przyjdą dzisiaj król i Haman na ucztę, którą przygotowałam dla niego***».
###### **Est 5,5**
 Król rzekł: «***Zawołajcie Hamana, by szybko spełnił wolę Estery***». Tak przyszli król i Haman na ucztę, którą przygotowała Estera.
###### **Est 5,6**
 I odezwał się król do Estery po napiciu się wina: «***Jakie jest twoje życzenie, a będzie ci spełnione, i jaka twoja prośba? Choćby to była połowa królestwa, stanie się***».
###### **Est 5,7**
 Na to odpowiedziała Estera, mówiąc: «***Oto życzenie moje i moja prośba:***
###### **Est 5,8**
 ***Jeśli król darzy mnie życzliwością i jeśli król uzna za słuszne spełnić moje życzenie oraz uczynić zadość mojej prośbie, to niech król przyjdzie z Hamanem [jeszcze jutro] na ucztę, którą przygotowałam dla nich, a jutro uczynię zgodnie ze słowem króla***».
###### **Est 5,9**
 I wyszedł Haman w dniu tym wesoły i dobrej myśli. Ale gdy Haman ujrzał Mardocheusza w Bramie Królewskiej, a on ani nie wstał, ani się nie poruszył przed nim, ogarnął Hamana gniew na Mardocheusza.
###### **Est 5,10**
 Mimo to Haman opanował się i poszedł do domu. Potem posłał po przyjaciół i po swoją żonę, Zeresz.
###### **Est 5,11**
 I wyliczył im Haman wspaniałości swych bogactw i mnóstwo swoich dzieci i to, jak wielkim uczynił go król i jak wyniósł go nad książąt i sługi królewskie.
###### **Est 5,12**
 I mówił Haman: «***Nawet królowa Estera nikogo poza mną nie zaprosiła na ucztę z królem, którą przygotowała, a także na jutro mam zaproszenie do niej razem z królem.***
###### **Est 5,13**
 ***Lecz wszystko to jest dla mnie niczym, jak długo patrzę na Mardocheusza, Żyda siedzącego w Bramie***».
###### **Est 5,14**
 Na to odpowiedziała mu jego żona, Zeresz, i wszyscy jego przyjaciele: «***Niech postawią drzewo wysokie na pięćdziesiąt łokci, a rano powiedz królowi, by powieszono na nim Mardocheusza, i idź wesół na ucztę z królem!***» Spodobała się ta rada Hamanowi i rozkazał postawić drzewo.
# Est 5 PAU
###### **Est 5,1**
 Trzeciego dnia, gdy Estera skończyła się modlić, zdjęła strój pokutny i włożyła wspaniałe szaty. (a) Potem, pełna blasku swego majestatu, polecając się opiece Boga i Wybawcy, wzięła z sobą dwie służące. Na jednej wsparła się wzorem wytwornych kobiet, druga zaś szła z tyłu, niosąc jej welon. (b) Szła promienna, niezwykle piękna, z obliczem pogodnym i przyjaznym, choć jej serce drżało ze strachu. (c) Przeszła przez drzwi pałacu i stanęła przed królem. Siedział on na królewskim tronie, a jego strój cały był pokryty złotem i ozdobiony szlachetnymi kamieniami. Jego majestatyczny wygląd budził lęk. (d) Pełen dostojeństwa, spojrzał gniewnie i wówczas królowa zasłabła i osunęła się na idącą obok niej służącą, a twarz królowej bardzo zbladła. (e) Wtedy Bóg odmienił usposobienie króla. Zaniepokojony wstał z tronu i przytrzymał ją w swych ramionach, zanim nie przyszła do siebie. Potem pocieszał ją i przemawiał do niej łagodnie, mówiąc: (f) „Estero, co się stało? Jestem twoim bratem, odwagi! Nie umrzesz, gdyż nasze zarządzenie jest bardzo ogólne. Podejdź!”.
###### **Est 5,2**
 Podniósł złote berło i dotknął nim jej szyi. Następnie ucałował ją i powiedział: „Przemów do mnie!”. A ona powiedziała: „Ujrzałam w tobie jakby anioła Bożego i moje serce zatrwożyło się przed twym majestatem, gdyż jesteś wspaniały, panie, jednak twoje oblicze pełne jest dobroci”. Jeszcze nie skończyła mówić, gdy znów osunęła się z powodu osłabienia. Wtedy król bardzo się zaniepokoił, a wszyscy jego słudzy pocieszali Esterę.
###### **Est 5,3**
 Król zapytał: „Estero, czego pragniesz? O co prosisz? Jeśli zechcesz, dam ci nawet połowę mego królestwa!”.
###### **Est 5,4**
 Wtedy Estera odpowiedziała: „Jeśli król uzna to za słuszne, niech przyjdzie na przyjęcie, które dzisiaj przygotuję. Niech przyjdzie on sam i Haman”.
###### **Est 5,5**
 Król rozkazał: „Przywołajcie szybko Hamana, byśmy mogli spełnić życzenie Estery i obydwaj udać się na przyjęcie, o którym Estera mówiła”.
###### **Est 5,6**
 Kiedy pili już wino, król rzekł do Estery: „Królowo Estero, jakie jest twoje życzenie? Dam ci wszystko, czego pragniesz!”.
###### **Est 5,7**
 Ona odpowiedziała: „Oto moja prośba i moje życzenie.
###### **Est 5,8**
 Jeśli znalazłam łaskę w oczach króla, niech król przybędzie również jutro, a z nim Haman, na przyjęcie, które dla was przygotuję, gdyż jutro postąpię podobnie!”.
###### **Est 5,9**
 Haman wyszedł od króla bardzo ucieszony, ale kiedy na dziedzińcu zobaczył Żyda Mardocheusza, wpadł w gniew.
###### **Est 5,10**
 Gdy przyszedł do domu, przywołał przyjaciół i swoją żonę Zosarę.
###### **Est 5,11**
 Opowiedział im o bogactwach i czci, jaką otoczył go król, i jak uczynił go pierwszym ministrem, powierzając mu zarządzanie królestwem.
###### **Est 5,12**
 Następnie Haman dodał: „Królowa i król nie zaprosili na przyjęcie nikogo oprócz mnie i także na jutrzejsze przyjęcie zostałem zaproszony.
###### **Est 5,13**
 Jednak nie zadowala mnie to wszystko, dopóki na dziedzińcu widzę Żyda Mardocheusza”.
###### **Est 5,14**
 Na to żona Zosara i jego przyjaciele powiedzieli: „Niech postawią szubienicę wysoką na pięćdziesiąt łokci, a ty skoro świt porozmawiaj z królem i niech powieszą na niej Mardocheusza. Dopiero wtedy idź z królem na przyjęcie i wesel się!”. Rada ta spodobała się Hamanowi i postawiono szubienicę.
# Est 5 BP
###### **Est 5,1**
 Według TM: 5.1-4 Dnia trzeciego Estera przywdziała szaty królewskie i stanęła w wewnętrznym dziedzińcu pałacu królewskiego, [w miejscu] naprzeciw komnat królewskich. Król siedział na tronie w sali królewskiej naprzeciw podwoi prowadzących do pałacu. Według LXX: D 5.l-2b 1 Trzeciego dnia. gdy ukończyła swe modły, zdjęła z siebie strój pokutny i przywdziała szaty wspaniałe. 1a W pełni blasku swego majestatu i wezwawszy [na pomoc] Boga, Wszechwiedzącego i Wybawcę, wzięła ze sobą dwie służebne. O jedną się wspierała, jak gdyby bliska była omdlenia, druga zaś postępowała za nią, podtrzymując jej szatę. 1b Promieniała cała kwitnącą pięknością, lecz choć oblicze jej było pełne wesela, sercem targała bojaźń. 1c Tak przeszła przez wszystkie podwoje i stanęła przed królem. On zaś siedział na swym królewskim tronie w całym majestacie wspaniałych szat, otoczony blaskiem złota i drogich kamieni, tak że bojaźń roztaczał wokół siebie. 1d Podniósł oblicze jaśniejące majestatem i spojrzał na nią z wielkim gniewem. [Na ten widok] królowa zachwiała się, zbladła i omdlała osunęła się na ramię służebnej, która szła przed nią. 1e Bóg jednak złagodził usposobienie króla, tak że tknięty obawą zszedł ze swego tronu i trzymał ją w ramionach do czasu, aż odzyskała przytomność. Następnie przemówił do niej łaskawie tymi słowy: Co ci jest, Estero? Jestem przecież bratem twoim! Miej ufność! Rozkaz nasz dotyczy jedynie pospólstwa. Podejdź bliżej!
###### **Est 5,2**
 A skoro tylko król dostrzegł królową Esterę stojącą na dziedzińcu, znalazła łaskę w jego oczach, tak że wyciągnął król do Estery złote berło, które trzymał w ręku. Estera zbliżyła się i dotknęła końca berła. 2 A podniósłszy złote berło i położywszy je na jej szyi, ucałował ją i rzekł: Przemów do mnie! 2a Powiedziała mu: Ujrzałam w tobie, panie, jakby anioła Bożego i serce moje zadrżało we mnie porażone twym majestatem. Podziwu godzien jesteś, o panie, a oblicze twoje jest pełne łaskawości. 2b Gdy tak mówiła, usunęła się znowu bliska omdlenia. Król był wzruszony, a wszyscy jego dworzanie starali się natchnąć ją otuchą.
###### **Est 5,3**
 Król rzekł do niej: Cóż za sprawę masz, królowo Estero? Czego żądasz? Choćbyś prosiła o połowę królestwa, będzie ci dane!
###### **Est 5,4**
 Estera odrzekała: Jeżeli spodoba się to królowi, niech król wraz z Hamanem zechce przyjść dziś na ucztę, którą przygotowałam na jego cześć.
###### **Est 5,5**
 Król odpowiedział: Przywołajcie śpiesznie Hamana, by spełnić życzenie Estery. Kiedy król i Haman przybyli na ucztę, którą przygotowała Estera,
###### **Est 5,6**
 rzekł król do Estery pijąc wino: Jakakolwiek jest twoja prośba, zostanie spełniona! Czegokolwiek byś sobie życzyła, choćby chodziło nawet o połowę królestwa, stanie się!
###### **Est 5,7**
 Estera odpowiedziała tymi słowy: Moja prośba i życzenie?
###### **Est 5,8**
 Jeśli znalazłam łaskę w oczach króla i jeżeli spodoba się królowi spełnić moją prośbę i zadośćuczynić mojemu życzeniu, niech król wraz z Hamanem przyjdzie jeszcze jutro na ucztę, którą dla nich przygotuję. Jutro zastosuję się do rozkazu królewskiego.
###### **Est 5,9**
 Haman wyszedł dnia tego w wesołym i pogodnym usposobieniu. Gdy jednak spostrzegł u bramy Królewskiej Mardocheusza, który ani nie powstał, ani się nie poruszył ze swego miejsca, rozgniewał się bardzo na niego.
###### **Est 5,10**
 Opanował się jednak i wrócił do domu. Polecił przyjść do siebie swoim przyjaciołom i żonie swojej Zeresz.
###### **Est 5,11**
 Opowiadał im Haman o wspaniałości swego bogactwa, o wielkiej liczbie swoich synów oraz o tym wszystkim, do jak wielkiego dostojeństwa wyniósł go król i jak go wyróżnił spośród książąt i dworzan królewskich.
###### **Est 5,12**
 Haman mówił: Mnie jednego tylko wraz z królem zaprosiła królowa Estera na ucztę, którą wyprawia. Także i na dzień jutrzejszy zostałem przez nią proszony razem z królem.
###### **Est 5,13**
 Ale wszystko to nie ma dla mnie znaczenia, dopóki widzę Żyda Mardocheusza, siedzącego u bramy Królewskiej.
###### **Est 5,14**
 Rzekła do niego jego żona Zeresz i wraz z nią wszyscy przyjaciele: Każ wznieść szubienicę wielką na pięćdziesiąt łokci, a jutro z rana poproś króla, by powieszono na niej Mardocheusza. Potem możesz już wesół iść na ucztę z królem. Spodobała się Hamanowi ta rada i rozkazał ustawić szubienicę.
# Est 5 BR
###### **Est 5,1**
 Trzeciego dnia ubrała się Estera w swoje szaty królewskie i poszła na wewnętrzny dziedziniec pałacowy, znajdujący się tuż przed domem króla. Król siedział na tronie na wprost wejścia w swoim królewskim domu. (a) Odzyskawszy w ten sposób swoje olśniewające piękno, zaczęła modlić się do wszystko widzącego Boga i Wybawcy. Potem wzięła ze sobą dwie służebnice. Na jednej z nich wsparła się, jak to zwykły czynić lubieżne kobiety, a druga szła za nią podtrzymując jej powiewną szatę. (b) Sama ona wprost promieniowała blaskiem swojej piękności; twarz jej wyrażała radość i jakby upojenie miłosne, ale jej serce było pełne strachu. (c) Przeszła wszystkie drzwi i w końcu stanęła przed królem, który siedział na swoim tronie, ubrany we wspaniałe szaty, wysadzane złotem i drogimi kamieniami. Spojrzenie miał bardzo surowe. (d) Kiedy w dzikim zagniewaniu, czerwony na twarzy, spojrzał na królową, ta pobladła, zachwiała się i upadła omdlała, wspierając się na ramionach służącej, która szła przed nią. (e) Wtedy dopiero zmiękczył Bóg nieco serce króla. Zaniepokojony zszedł szybko ze swego tronu, chwycił ją w ramionach i podtrzymywał, dopóki nie doszła do siebie. Potem zaczął przemawiać do niej życzliwie takimi oto słowami: (f) Co ci jest, Estero? Przecież ja jestem twoim bratem. Bądź spokojna! Ty nie musisz umierać. Nasz rozkaz dotyczy innych. Chodź tutaj!
###### **Est 5,2**
 Kiedy król zobaczył królową Esterę stojącą na dziedzińcu, okazał jej całą życzliwość. Wyciągnął ku niej swoje złote berło, które trzymał w ręku. Estera podeszła i dotknęła końca berła. (a) Powiedziała zatem do niego: Patrzyłam na ciebie, panie mój, jak na anioła Bożego, a moje serce drżało z przerażenia na widok twojego majestatu. Jesteś bowiem wspaniały, panie mój, a twoje oblicze jest pełne dobroci. (b) Kiedy tak jeszcze do niego mówiła, ponownie zachwiała się mdlejąc. Król poczuł się tym bardzo zaniepokojony, a ją całe otoczenie starało się podnosić na duchu.
###### **Est 5,3**
 Wtedy powiedział do niej król: Czego sobie życzysz, królowo Estero? Jakie są twoje pragnienia? Gdybyś zażądała nawet połowy mojego królestwa, twojej prośbie stanie się zadość.
###### **Est 5,4**
 Rzekła na to Estera: Jeśli król jest tak łaskaw, to niech raczy przyjść dziś razem z Hamanem na ucztę, którą przygotowała.
###### **Est 5,5**
 Powiedział tedy król: Zawołajcie mi tu zaraz Hamana, żeby można było uczynić zadość prośbie Estery. Król i Haman przybyli na ucztę wydaną przez Esterę.
###### **Est 5,6**
 Gdy potem siedzieli razem przy winie, powiedział król do Estery: Jeśli masz jeszcze jakieś życzenie, to zostanie ono spełnione natychmiast. Czego pragnęłabyś jeszcze? Będzie ci dana nawet połowa całego królestwa, jeśli tylko tego zażądasz.
###### **Est 5,7**
 Wtedy odpowiedziała Estera: Oto moja prośba i moje największe pragnienie:
###### **Est 5,8**
 Jeśli znalazłam łaskę u króla, jeśli w swojej dobroci gotów byłby spełnić moje życzenie, to niech raczy król także jutro przyjść z Jamanem na ucztę, którą przygotowałam. Jutro odpowiem królowi na jego pytanie.
###### **Est 5,9**
 Wracał Haman tego dnia do domu uradowany i pełen najlepszych myśli. Ale kiedy przy bramie pałacu królewskiego zobaczył Mardocheusza, który nie podniósł się i nie złożył mu pokłonu, bardzo się na niego rozgniewał.
###### **Est 5,10**
 Nie dał jednak tego po sobie poznać, lecz wróciwszy do domu, kazał natychmiast przywołać do siebie przyjaciół i swoją żonę Zeresz.
###### **Est 5,11**
 I zaczął im opowiadać o swoich ogromnych bogactwach, o licznych synach, o wielkiej władzy przekazanej mu przez króla i o tym, jak go król ustanowił przełożonym wielu innych książąt i sług królewskich.
###### **Est 5,12**
 Na koniec powiedział Haman: Także królowa Estera na ucztę, którą urządziła, zaprosiła tylko króla i mnie. Również na jutro zostałem do niej zaproszony razem z królem.
###### **Est 5,13**
 Ale moje szczęście będzie niepełne tak długo, jak długo będę patrzył na Żyda Mardocheusza, siedzącego przed wejściem do pałacu.
###### **Est 5,14**
 Wtedy jego żona Zeresz oraz zebrani przyjaciele powiedzieli: Możesz przecież rozkazać ustawić szubienicę wysoką na pięćdziesiąt łokci, a jutro wczesnym rankiem powiesz królowi, żeby na niej powieszono Mardocheusza. Potem, czując ulgę w sercu, pójdziesz razem z królem na ucztę. Spodobała się ta rada Hamanowi. I rozkazał zbudować szubienicę.
# Est 5 WUJ
###### **Est 5,1**
 A trzeciego dnia oblokła się Esther w ubiór królewski, i stanęła w sieni domu królewskiego, która była we wnątrz przeciw pokojowi królewskiemu: a on siedział na stolicy swej w sali sądowej w pałacu przeciwko drzwiam domu.
###### **Est 5,2**
 I gdy ujrzał Esther królową stojącą, spodobała się oczam jego, i wyciągnął ku niej laskę złotą, którą trzymał w ręce. A ona przystąpiwszy pocałowała koniec laski jego.
###### **Est 5,3**
 I rzekł do niej król: Czego chcesz Esther królowa? co za prośba twoja? byś też i o połowicę królestwa prosiła, będzieć dano.
###### **Est 5,4**
 A ona odpowiedziała: Jeśli się królowi podoba, proszę, żebyś dziś przyszedł do mnie, i Aman z tobą, na ucztę, którąm nagotowała.
###### **Est 5,5**
 I wnet król rzekł: Wzówcie co rychlej Amana, aby dosyć uczynił wolej Esther. Przyszli tedy król i Aman na ucztę, którą im królowa była zgotowała.
###### **Est 5,6**
 I rzekł król do niej, napiwszy się dostatkiem wina: Czego żądasz, abyć dano? a o co prosisz? byś też o pół królestwa mego prosiła, uprosisz.
###### **Est 5,7**
 Któremu Esther odpowiedziała: żądanie moje i prośba ta jest:
###### **Est 5,8**
 Jeślim nalazła łaskę przed obliczem królewskiem, a jeśli się królowi podoba, żeby mi dał o co żądam, i prośbę moję wypełnił: niech przyjdzie król i Aman na ucztę, którąm im zgotowała, a jutro otworzę królowi wolą moję.
###### **Est 5,9**
 A tak wyszedł Aman onego dnia wesoły i ochotny. A gdy ujrzał Mardocheusza siedzącego przede drzwiami pałacu, iż nie tylko nie wstał ku niemu, ale ani się ruszył z miejsca siedzenia swego, rozjadł się okrutnie:
###### **Est 5,10**
 I nie pokazując gniewu, wróciwszy się do domu swego, wezwał do siebie przyjaciół swych, i Zares żonę swoję:
###### **Est 5,11**
 I przełożył im wielkość bogactw swoich, i gromadę synów, i z jak wielką chwałą wywyższył go król nad wszystkie książęta i sługi swoje.
###### **Est 5,12**
 A potem rzekł: królowa też Esther żadnego innego nie wezwała na ucztę z królem, jedno mnie: u której też jutro z królem obiadować mam.
###### **Est 5,13**
 A choć to wszystko mam, zda mi się jakobych nic nie miał, póki będę patrzył na Mardocheusza Żyda siedzącego przede drzwiami królewskimi.
###### **Est 5,14**
 I odpowiedzieli mu Zares żona jego i inni przyjaciele: Każ nagotować wysokie drzewa mające wzwyż pięćdziesiąt łokci, a rano mów królowi, aby na nim Mardocheusz był obieszon, i tak pójdziesz z królem na ucztę wesoły. Spodobała mu się rada, i kazał nagotować wysok szubienicę.
