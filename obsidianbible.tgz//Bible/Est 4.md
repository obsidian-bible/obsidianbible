# Est 4 BT5
###### **Est 4,1**
 Skoro Mardocheusz dowiedział się o wszystkim, co czyniono, rozdarł szaty i okrył się worem, i [posypał głowę] popiołem, wyszedł na środek miasta i lamentował głośno i gorzko.
###### **Est 4,2**
 I przyszedł aż pod Bramę Królewską, ponieważ nie wolno było wejść do samej Bramy Królewskiej przyodzianemu w wór pokutny.
###### **Est 4,3**
 A w każdym państwie, wszędzie, dokąd dekret króla i prawo jego dotarły, powstał wielki smutek wśród Żydów i posty, i płacz, i lament. Wór pokutny i popiół stanowiły posłanie dla wielu.
###### **Est 4,4**
 I przyszły służące Estery i jej eunuchowie, i opowiedzieli jej o tym. Wtedy królowa zlękła się bardzo i posłała szaty, aby ubrać Mardocheusza i zdjąć wór z niego, ale on nie przyjął.
###### **Est 4,5**
 Wówczas Estera zawołała Hataka, który spośród eunuchów królewskich usługiwał jej osobiście, i posłała go do Mardocheusza, aby się dowiedzieć, co to [znaczy] i dlaczego [tak czyni].
###### **Est 4,6**
 I poszedł Hatak do Mardocheusza na rynek miasta, który był przed Bramą Królewską.
###### **Est 4,7**
 Mardocheusz opowiedział mu wszystko, co się zdarzyło, i dokładnie powiadomił go o sumie srebra, którą Haman przyrzekł wpłacić do skarbca królewskiego za Żydów, skoro tylko będzie mógł ich wytracić.
###### **Est 4,8**
 A odpis dokumentu prawnego, który wydano w Suzie, aby ich wytracić, dał mu do pokazania Esterze, celem powiadomienia jej i polecenia, aby poszła do króla i błagała go o łaskę oraz prosiła przed nim za ludem swoim.
###### **Est 4,9**
 A Hatak odszedł i przekazał Esterze słowa Mardocheusza.
###### **Est 4,10**
 Estera odpowiedziała Hatakowi, polecając mu iść do Mardocheusza:
###### **Est 4,11**
 «***Wszyscy słudzy króla i ludność państw królewskich wiedzą, że jedno jest dla nich prawo, dla każdego mężczyzny i każdej kobiety, którzy udają się do króla na dziedziniec wewnętrzny, a którzy nie otrzymali wezwania: mają być zabici, chyba że król wyciągnie nad nimi złote berło, to wtedy pozostaną przy życiu. A mnie nie zawołano, abym poszła do króla, już od trzydziestu dni***».
###### **Est 4,12**
 I przekazano Mardocheuszowi słowa Estery.
###### **Est 4,13**
 Wtedy Mardocheusz rzekł, aby odpowiedzieli Esterze: «***Nie myśl sobie w sercu, że uratujesz się w domu króla, jedyna ze wszystkich Żydów,***
###### **Est 4,14**
 ***bo jeśli ty zachowasz milczenie w tym czasie, uwolnienie i ratunek dla Żydów przyjdzie z innego miejsca, a ty i dom ojca twojego zginiecie. A kto wie, czy nie ze względu na tę właśnie chwilę dostąpiłaś godności królowej?***»
###### **Est 4,15**
 A Estera rzekła, aby odpowiedziano Mardocheuszowi:
###### **Est 4,16**
 «***Idź, zgromadź wszystkich Żydów, którzy znajdują się w Suzie. Pośćcie za mnie, nie jedząc i nie pijąc przez trzy dni, ani w nocy, ani w dzień. Ja też i dziewczęta moje będziemy pościły podobnie. Potem pójdę do króla, choć to niezgodne z prawem, a jeśli zginę, to zginę***».
###### **Est 4,17**
 I poszedł Mardocheusz i uczynił stosownie do tego wszystkiego, co mu poleciła Estera.
###### **Est 4,17a**
 Błagał Pana, wspominając wszystkie dzieła Pańskie, i mówił:
###### **Est 4,17b**
 «***Panie, Panie, Królu, Wszechmogący, ponieważ w Twojej mocy jest wszystko i nie ma takiego, który by Ci się sprzeciwił, gdy chcesz ocalić Izraela,***
###### **Est 4,17c**
 ***ponieważ Ty uczyniłeś niebo i ziemię, i wszystko, co na niej pod niebem godne jest podziwu, Ty jesteś Panem wszystkiego i nie ma nikogo, kto by się sprzeciwił Tobie, Panu.***
###### **Est 4,17d**
 ***Ty znasz wszystko, Ty wiesz, iż – jeśli nie oddawałem pokłonu pysznemu Hamanowi – nie czyniłem tego ani z pychy, ani z zuchwałości, ani z żądzy sławy. Byłem nawet gotów ślady stóp jego całować dla ocalenia Izraela.***
###### **Est 4,17e**
 ***Lecz czyniłem tak, aby nie stawiać wyżej czci człowieka nad cześć Boga i aby nikomu nie oddawać pokłonu, oprócz Ciebie, Panie mój, i nie uczyniłem tego z pychy.***
###### **Est 4,17f**
  ***A teraz, Panie Boże, Królu, Boże Abrahama, ocal Twój lud, bo czyhają na naszą zgubę i mają zamiar zniszczyć nas, Twoje od początku dziedzictwo.***
###### **Est 4,17g**
  ***Nie gardź Twoim dziedzictwem, które wykupiłeś dla siebie z Egiptu.***
###### **Est 4,17h**
  ***Wysłuchaj prośby mojej i okaż miłosierdzie nad dziedzicznym Twym działem, obróć smutek nasz w radość, abyśmy żyli i imię Twoje, Panie, wielbili, i nie zamykaj ust chwalących Ciebie!***»
###### **Est 4,17i**
  I cały Izrael wołał ze wszystkich sił swoich, bo śmierć stała im przed oczami.
###### **Est 4,17k**
   (k) Także królowa Estera zwróciła się do Pana, przejęta niebezpieczeństwem śmierci. Zdjęła swe okazałe szaty, przywdziała suknie smutku i żałoby i zamiast wspaniałymi wonnościami pokryła swoją głowę popiołem i śmieciami, i ciało swoje poniżyła bardzo, a radosne ozdoby zastąpiła rozpuszczonymi włosami.
###### **Est 4,17l**
   (l) I błagała Pana, Boga Izraela, mówiąc: «***Panie mój, Królu nasz, Ty jesteś jedyny, wspomóż mnie samotną, nie mającą poza Tobą wspomożyciela, bo niebezpieczeństwo jest niejako w mojej ręce.***
###### **Est 4,17m**
   ***Słyszałam od młodości mojej w pokoleniu moim ojczystym, że Ty, Panie, wybrałeś Izraela spośród wszystkich narodów i ojców naszych ze wszystkich ich przodków na wieczyste dziedzictwo i uczyniłeś im wszystko, co zapowiedziałeś.***
###### **Est 4,17n**
   ***A teraz zgrzeszyliśmy wobec Ciebie i wydałeś nas w ręce naszych wrogów za to, że czciliśmy ich bóstwa. Sprawiedliwy jesteś, Panie!***
###### **Est 4,17o**
   ***A oni nie zadowolili się goryczą naszej niewoli i włożyli swoje ręce w ręce swoich bożków, aby odmienić obietnice ust Twoich i aby zniszczyć Twoje dziedzictwo, zamknąć usta tych, którzy Cię wielbią, i zgasić sławę Twego domu i ołtarza Twego,***
###### **Est 4,17p**
   ***a otworzyć usta pogan, [by chwaliły] przymioty bezwartościowych bałwanów i podziwiały nieustannie doczesnego króla.***
###### **Est 4,17q**
   ***Nie oddawaj, Panie, berła Twego tym, którzy nie istnieją, i niech się nie naigrawają z naszego upadku, lecz zwróć postanowienie ich przeciwko nim; tego zaś, który zaczął z nami walkę, przykładnie ukarz!***
###### **Est 4,17r**
   ***Wspomnij, Panie, daj się rozpoznać w chwili naszego udręczenia i dodaj mi odwagi, Królu bogów i Władco nad wszystkimi władcami.***
###### **Est 4,17s**
   ***Włóż stosowną mowę w moje usta przed obliczem lwa i zwróć jego serce ku nienawiści do wroga naszego, aby zginął on sam i ci, którzy są z nim jednej myśli.***
###### **Est 4,17t**
   ***Wybaw nas ręką Twoją i wspomóż mnie opuszczoną i nie mającą nikogo poza Tobą, Panie.***
###### **Est 4,17u**
   ***Ty wiesz wszystko, wiesz, że nienawidzę chwały bezbożnych i brzydzę się łożem nieobrzezanych i każdym obcym.***
###### **Est 4,17w**
   ***Ty znasz moją niedolę i to, że brzydzę się znakiem mojego wywyższenia, który noszę na głowie w dniach publicznych wystąpień. Brzydzę się nim jak łachmanem krwawiących co miesiąc kobiet i nie noszę go w dniach mego odpoczynku.***
###### **Est 4,17x**
   ***Także ze stołu Hamana nie jadła służebnica Twoja i nie ceniła sobie wysoko uczty króla ani też nie piła wina płynnych ofiar.***
###### **Est 4,17y**
   ***I nie radowała się służebnica Twoja od dnia zabrania jej aż dotąd, jak tylko w Tobie, Panie, Boże Abrahama.***
###### **Est 4,17z**
   ***O Boże władający wszystkimi, wysłuchaj głosu pozbawionych nadziei i wyratuj nas z ręki niegodziwych, mnie zaś uwolnij od mego lęku***».
# Est 4 PAU
###### **Est 4,1**
 Kiedy Mardocheusz dowiedział się o wszystkim, rozdarł swoje szaty, włożył wór pokutny i posypał się popiołem, a potem szedł główną ulicą miasta, wołając głośno: „Zabija się naród niewinny!”.
###### **Est 4,2**
 Doszedł tak do Bramy Królewskiej. Tam się zatrzymał, gdyż okrytemu w wór pokutny i popiół nie było wolno wejść na dziedziniec.
###### **Est 4,3**
 Tymczasem we wszystkich okręgach, w których ogłoszono dekret, wybuchnął wśród Żydów krzyk, płacz i wielki lament. Dla wielu z nich wór pokutny i popiół stały się posłaniem.
###### **Est 4,4**
 Służące i eunuchowie królowej przystąpili do niej i opowiedzieli jej o wszystkim. A ona zlękła się, gdy usłyszała, co się stało. Posłała Mardocheuszowi szaty, aby się w nie ubrał, a zdjął wór pokutny. On jednak nie ustąpił.
###### **Est 4,5**
 Wtedy Estera przywołała eunucha Achratajosa, który jej służył, i posłała go po dokładne wiadomości od Mardocheusza.
###### **Est 4,6**
 [I poszedł Hatak do Mardocheusza na rynek miasta, który był przed Bramą Królewską.]
###### **Est 4,7**
 Mardocheusz opowiedział mu o zdarzeniu i obietnicy, jaką Haman złożył królowi, o sumie dziesięciu tysięcy talentów za zagładę Żydów.
###### **Est 4,8**
 Dał mu też ogłoszony w Suzie odpis dekretu, dotyczący zagłady, aby pokazał go Esterze. Przekazał także polecenie dla niej: „Pójdziesz do króla i będziesz go prosić i błagać za ludem, wspominając twe obecne upokorzenie, jako że zostałaś wychowana przeze mnie. Ponieważ Haman, najważniejszy po królu, mówił przeciwko nam i zgotował naszą zgubę, dlatego ty najpierw wezwij PANA, a potem pomów o nas z królem i wybaw nas od śmierci!”.
###### **Est 4,9**
 Achratajos wrócił i przekazał Esterze wszystkie te słowa.
###### **Est 4,10**
 Na to rzekła ona do Achratajosa: „Idź do Mardocheusza i powiedz:
###### **Est 4,11**
 «Wszystkie ludy królestwa wiedzą, że nikt, czy to mężczyzna, czy kobieta, kto bez wezwania pójdzie do króla na dziedziniec wewnętrzny, nie będzie ocalony, chyba że król wyciągnie swoje złote berło i tak go ocali. Ale ja od trzydziestu dni nie jestem wzywana, aby iść do króla»”.
###### **Est 4,12**
 Achratajos przekazał Mardocheuszowi wszystkie te słowa.
###### **Est 4,13**
 A Mardocheusz rzekł do Achratajosa: „Idź i powiedz jej: «Estero, nie myśl, że w całym królestwie jedynie ty zostaniesz ocalona spośród wszystkich Żydów.
###### **Est 4,14**
 Bo jeśli nawet ty będziesz milczała w takiej chwili, to pomoc i ratunek nadejdą dla Żydów skądinąd, ale ty i dom twego ojca zginiecie. Kto wie, czy właśnie ze względu na tę chwilę nie zostałaś królową?»”.
###### **Est 4,15**
 Estera odesłała do Mardocheusza posłańca z takim poleceniem:
###### **Est 4,16**
 „Idź i zbierz Żydów mieszkających w Suzie. Pośćcie za mnie, nie jedzcie i nie pijcie przez trzy dni, dniem i nocą. Także ja i moje służące powstrzymamy się od pokarmów, a potem wbrew prawu udam się do króla, nawet jeśli będzie to przyczyną mojej zguby”.
###### **Est 4,17**
 Mardocheusz odszedł i zrobił, jak mu poleciła Estera. (a) A wspominając wszystkie dzieła Pańskie, modlił się do PANA: (b) „PANIE, PANIE! Królu, który panujesz nad wszystkim! W Twojej mocy jest wszystko i nie ma nikogo, kto mógłby sprzeciwić się Tobie, jeśli zechcesz ocalić Izraela, (c) ponieważ to Ty stworzyłeś niebo i ziemię, i wszystko, co pod niebem godne jest podziwu. Ty jesteś Panem wszystkiego i nie ma nikogo, kto mógłby przeciwstawić się Tobie, PANU! (d) Ty wiesz wszystko! Ty wiesz, PANIE, że nie z powodu zuchwalstwa, pychy czy próżności nie złożyłem hołdu dumnemu Hamanowi, gdyż dla ocalenia Izraela gotów byłbym ucałować ślady jego stóp. (e) Uczyniłem tak, by nie przedkładać chwały ludzkiej nad chwałę Bożą. Nie złożę hołdu nikomu poza Tobą, moim PANEM! I nie czynię tego z powodu pychy! (f) A teraz PANIE, Boże, Królu, Boże Abrahama, oszczędź Twój lud! Oto zmierzają do naszej zguby i pragną zgładzić dziedzictwo, które od początku było Twoje. (g) Nie gardź Twą cząstką, którą wykupiłeś dla siebie z Egiptu. (h) Wysłuchaj moją prośbę i okaż zmiłowanie Twojemu dziedzictwu! Przemień nasz smutek w wesele, abyśmy żyli i wielbili Twe imię, PANIE! I nie pozwól, aby umilkły usta wielbiących Ciebie!”. (i) Podobnie wszyscy Izraelici wołali z mocą, bo śmierć stała im przed oczyma. (k) Podobnie królowa Estera, będąc w niebezpieczeństwie śmierci, uciekła się pod opiekę PANA. Zdjęła swój dostojny strój i ubrała się w szaty smutku i żałoby. Zamiast wybornymi wonnościami posypała swoją głowę popiołem i śmieciami. Bardzo umartwiła swoje ciało, a wszystkie miejsca na ozdoby, których noszenie było jej radością, zakryła splotami swych włosów. I prosiła PANA, Boga Izraela: (l) „PANIE mój! Ty jesteś jedynym królem naszym! Przyjdź z pomocą mnie samotnej i niemającej prócz Ciebie żadnego obrońcy! Oto grozi mi niebezpieczeństwo! (m) W rodzinie mego ojca słyszałam od mojej młodości, że Ty, o PANIE, wybrałeś Izraela spośród wszystkich narodów i naszych ojców spośród wszystkich ich przodków na wieczne dziedzictwo. I postąpiłeś z nimi, jak zapowiedziałeś. (n) Ale teraz zgrzeszyliśmy przeciwko Tobie i wydałeś nas w ręce naszych wrogów, bo czciliśmy ich bogów. PANIE, jesteś sprawiedliwy! (o) Jednak nie zadowolili się goryczą naszej niewoli, ale ręce swoje włożyli w ręce bożków swoich, by odmienić postanowienia ust Twoich, wytracić Twoje dziedzictwo, zamknąć usta proszących Ciebie i zgasić chwałę Twego domu i Twego ołtarza, (p) a otworzyć usta pogan, by czcili nicość i na wieki podziwiali cielesnego króla. (q) Dlatego, PANIE, nie wydawaj swego berła czemuś, co nie istnieje! Niech nie drwią z naszego upadku, ale odwróć ich zamiar przeciwko nim! A los tego, który pierwszy powstał przeciwko nam, niech będzie przykładem! (r) Wspomnij na nas, PANIE!  Daj się poznać w chwili naszego ucisku! A mnie, Królu bogów i Władco wszystkich panujących, dodaj odwagi! (s) Włóż w moje usta właściwe słowa w obecności lwa i odmień jego serce, by znienawidził walczącego z nami i położył kres jemu i myślącym tak jak on. (t) Wybaw nas Twoją mocą i pomóż mnie samotnej, niemającej nikogo prócz Ciebie, PANIE! (u) Posiadasz wszelką wiedzę, więc wiesz, że znienawidziłam chwałę nieprawych, brzydzę się łożem nieobrzezanych i każdym obcym. (w) Ty wiesz o moim udręczeniu, że brzydzę się znakiem mego wywyższenia, który w dniach mych publicznych wystąpień noszę na głowie. Brzydzę się nim jak szmatą krwawiącej kobiety i nie noszę go w dniach mego odpoczynku. (x) Twoja służebnica nie jadała ze stołu Hamana i nie cieszyła się z uczt królewskich, i nie piła wina z płynnych ofiar. (y) Twoja służebnica nie radowała się niczym od dnia swego przeobrażenia aż do chwili obecnej, jedynie Tobą, PANIE, Boże Abrahama. (z) Boże! Potężny nade wszystko! Wysłuchaj wołania pozbawionych nadziei i wybaw nas z rąk niegodziwców, a mnie uwolnij od lęku!”.
# Est 4 BP
###### **Est 4,1**
 Kiedy Mardocheusz dowiedział się o wszystkim, co zaszło, rozdarł szaty swoje, a przywdziawszy wór pokutny i posypawszy [głowę] popiołem, wybiegł na miasto, lamentując głośno i gorzko.
###### **Est 4,2**
 Tak doszedł aż do bramy Królewskiej; nie wolno było bowiem przekraczać bramy Królewskiej w szatach pokutnych.
###### **Est 4,3**
 A we wszystkich prowincjach, do których nadszedł dekret i rozkaz królewski, zapanowała wielka żałoba wśród Żydów, połączona z postem, płaczem i lamentem, dla wielu zaś z nich wór i popiół służyły za posłanie.
###### **Est 4,4**
 Gdy tedy przyszły służące Estery i eunuchowie donieśli jej o tym, królowa bardzo się przeraziła i posłała szaty Mardocheuszowi, aby się w nie przyodział, a zdjął wór pokutny. On jednak nie przyjął ich.
###### **Est 4,5**
 Przywołała więc Estera Hataka, jednego z eunuchów królewskich, przydzielonego jej do posługi, i wysłała go do Mardocheusza, aby się dowiedział, co to ma znaczyć i dlaczego to się stało.
###### **Est 4,6**
 Hatak wyszedł do Mardocheusza na plac miejski, znajdujący się przed bramą Królewską.
###### **Est 4,7**
 Mardocheusz opowiedział mu o wszystkim, co mu się przydarzyło, zwłaszcza o owej sumie srebra, którą Haman obiecał odważyć do skarbca królewskiego w zamian za wytracenie Żydów.
###### **Est 4,8**
 Nadto wręczył mu odpis dekretu o ich zagładzie, ogłoszonego w Suzie, aby pokazał go Esterze oraz by powiadamiając ją o wszystkim przekazał jego życzenie, żeby się udała do króla, błagając go o łaskę i wstawiając się przed nim za swoim ludem.
###### **Est 4,9**
 Hatak wrócił i powtórzył Esterze to, co powiedział Mardocheusz.
###### **Est 4,10**
 Estera rozkazała Hatakowi przekazać [jeszcze raz] następujące słowa Mardocheuszowi:
###### **Est 4,11**
 Wszyscy dworzanie królewscy i mieszkańcy prowincji królewskich wiedzą, że każdy - zarówno mężczyzna, jak i kobieta - kto wejdzie do króla na dziedziniec wewnętrzny nie będąc wezwany, podlega tylko jednemu prawu - karze śmierci - z wyjątkiem tego, nad którym król wyciągnie złote berło: ten będzie ocalony. Ja zaś od dni trzydziestu nie otrzymałam wezwania, by się udać do króla.
###### **Est 4,12**
 Kiedy Mardocheuszowi powtórzono słowa Estery,
###### **Est 4,13**
 polecił dać jej taką odpowiedź: Nie sądź, że ty jedna tylko ocalejesz spośród wszystkich Żydów dlatego, że mieszkasz w pałacu królewskim.
###### **Est 4,14**
 Stanie się inaczej. Jeśli w takiej chwili ty będziesz milczała, ratunek i ocalenie przyjdzie dla Żydów z innej strony, ty sama natomiast zginiesz wraz z domem ojca twego. Któż wie, czy to właśnie nie ze względu na tę chwilę dostąpiłaś godności królewskiej?
###### **Est 4,15**
 [Na te słowa] poleciła Estera oznajmić Mardocheuszowi:
###### **Est 4,16**
 Idź, zgromadź wszystkich Żydów, którzy przebywają w Suzie; niech poszczą w mojej intencji, nie jedząc nic ani nie pijąc przez trzy dni i trzy noce. Ja także i służebnice moje będziemy pościć w ten sam sposób: udam się do króla wbrew prawu i jeżeli mam zginąć, zginę.
###### **Est 4,17**
 Odszedł więc Mardocheusz i zarządził wszystko tak, jak mu to poleciła Estera. Według LXX: C 4.17a-17z Modlitwa Mardocheusza 17a Wspominając wszystkie dzieła Pana, modlił się on do Niego tymi słowy: 17b "Panie, Panie, Królu, który nad wszystkim panujesz, ponieważ wszystko jest w Twojej mocy i nie ma nikogo, kto by mógł się Tobie sprzeciwić, gdy zechcesz wybawić Izraela. 17c Tyś przecież uczynił niebiosa i ziemię, i te zadziwiające rzeczy, [jakie istnieją] pod niebem! Ty jesteś Panem wszystkiego i nie ma nikogo, kto by się mógł oprzeć Tobie - Panu. 17d Ty znasz wszystko! Ty wiesz, Panie, że to nie pycha, nie zarozumiałość, nie próżność powodowały mną, że nie chciałem padać na twarz przed pysznym Amanem. Chętnie ucałowałbym ślad stóp jego dla wybawienia Izraela; 17e nie uczyniłem tego dlatego jedynie, by wyższej czci nie okazywać człowiekowi niż Bogu; nie będę się kłaniał przed nikim, tylko przed Tobą, Panem moim. To nie pycha mną powoduje. 17f Teraz zaś, Panie, Boże, Królu, Boże Abrahama, oszczędź swój lud, gdyż oni dążą do naszej zguby i zmierzają do tego, by unicestwić to, co od początku Twoim było dziedzictwem. 17g Nie gardź Twym działem, któryś wykupił dla siebie z Egiptu. 17h Wysłuchaj mego błagania, okaż łaskawość swemu dziedzictwu i zamień żałobę naszą w wesele, abyśmy żyli i sławili Imię Twoje, o Panie! Nie zamykaj ust tym, którzy Cię wielbią!" 17i Także wszystek lud izraelski wołał z całej mocy [do Pana], bo śmierć miał przed oczyma. 17k Również królowa Estera, czując się zagrożona śmiertelnym niebezpieczeństwem, szukała ratunku u Pana. Zdjęła swe wspaniałe szaty i przywdziała odzienie odpowiadające [godzinie] smutku i żałoby; zamiast kosztownych wonności posypała głowę swą popiołem i nieczystościami. Umartwiała mocno swe ciało; a te wszystkie jego części, które niegdyś z taką radością zdobiła, zakryła roztarganymi włosami. Modliła się do Boga Izraela tymi słowy: 17l "Panie mój, Królu nasz, Ty jedynie Nim jesteś. Wspomóż mnie opuszczoną, która prócz Ciebie nie ma innego wspomożyciela, gdyż zagrażające mi niebezpieczeństwo jest tuż przy mnie. 17m Od najwcześniejszych lat mojej młodości słyszałam w pokoleniu mojej ojczyzny, żeś Ty, o Panie, wybrał Izraela na wieczne dziedzictwo spośród wszystkich narodów i ojców naszych, spośród wszystkich ich przodków i dopełniłeś wszystkich swych obietnic. 17n Lecz oto zgrzeszyliśmy przed Tobą i wydałeś nas w ręce nieprzyjaciół naszych za to, że oddawaliśmy cześć ich bogom. Sprawiedliwy jesteś, o Panie! 17o Oto teraz nie zadowalają się gorzkością naszej niewoli, lecz ręce swoje włożyli w ręce swych bożków, aby ustawę ust Twoich uchylić, zniszczyć Twoje dziedzictwo, zamknąć usta tych, którzy Cię wysławiają, i zgasić wspaniałość Twego Domu i Twego ołtarza, 17p by [w zamian za to] otworzyć usta pogan do wychwalania nicości i sprawić, by sławiono śmiertelnego króla na wieki. 17q Nie przekazuj, o Panie, berła swego tym, którzy są nicością, aby nie szydzono z naszego upadku! Spraw, by ich zamysły spadły na nich samych, i ukarz tego, który powstał przeciwko nam! 17r Wspomnij [na to], o Panie, objaw się na czas naszej udręki i dodaj mi odwagi, Królu bogów i Władco nad wszystkimi panującymi! 17s włóż mi w usta stosowne słowa w obecności lwa i zwróć jego serce ku nienawiści tego, który nas prześladuje, aby zguba dosięgła jego i tych, którzy podzielają jego uczucia. 17t Lecz wybaw nas swą ręką i wspomóż mnie opuszczoną, która nie ma nikogo prócz Ciebie, o Panie! 17u Ty znasz wszystko, wiesz, że nienawidzę wspaniałości ludzi nieprawych i gardzę łożem nie obrzezanych, i brzydzę się tym wszystkim, co obce. 17w Ty znasz moją niedolę i to, że się brzydzę godłem mojego wyniesienia, które spoczywa na mojej głowie w dniach, kiedy muszę się ukazywać. Brzydzę się nim jak szmatą miesięcznej słabości i nie noszę go nigdy w dniach mego odpoczywania. 17x Służebnica Twoja nie jadała nigdy przy stole Amana ani nie miała upodobania w ucztach królewskich i nie pijała wina ofiarnego. 17y Służebnica twoja od dnia odmiany swego losu aż po dzień dzisiejszy nie zaznała innej radości prócz Ciebie, o Panie, Boże Abrahama. 17z O Boże, który nad wszystkimi panujesz, wysłuchaj wołania tych, którzy pozbawieni są innej nadziei, wybaw nas z ręki niegodziwych i wybaw mnie od mej udręki!"
# Est 4 BR
###### **Est 4,1**
 Kiedy dowiedział się o tym wszystkim Mardocheusz, rozdarł swoje szaty, okrył się worem i [posypał] popiołem, chodził po mieście i głośno lamentował.
###### **Est 4,2**
 I tak przyszedł aż do bramy pałacu królewskiego. Nikomu jednak nie wolno było przekraczać bramy pałacu w stroju pokutnym.
###### **Est 4,3**
 We wszystkich prowincjach po ukazaniu się dekretu królewskiego ogarnęło Żydów wielkie przygnębienie. Wszyscy pościli, płakali i biadali, a wielu spało w worach pokutnych i w popiele.
###### **Est 4,4**
 Kiedy służebnice Estery i eunuchowie przyszli i opowiedzieli jej o wszystkim, przerażenie ogarnęło królową. Natychmiast posłała Mardocheuszowi [odświętne] szaty, żeby mógł się w nie ubrać zdjąwszy z siebie wór pokutny. Ale on nie chciał przyjąć owych szat.
###### **Est 4,5**
 Wtedy Estera wezwała do siebie Hataka, którego przydzielił jej król do specjalnych posług. Posłała go do Mardocheusza, żeby się dowiedział co zaszło, że zachowuje się on tak dziwnie.
###### **Est 4,6**
 I przyszedł Hatak do Mardocheusza, który znajdował się na placu przed bramą pałacową.
###### **Est 4,7**
 Opowiedział mu Mardocheusz o wszystkim, co zaszło. Wspomniał także o tym, ile to srebra zobowiązał się Haman przekazać do skarbca królewskiego, skoro tylko zostaną wymordowani wszyscy Żydzi.
###### **Est 4,8**
 Wręczył mu także odpis ogłoszonego w Suzie dekretu skazującego Żydów na zagładę. Dekret ten miał Hatak pokazać Esterze. Miał jej też opowiedzieć wszystko, prosząc ją, aby udała się do króla i błagała go na wszelkie sposoby o łaskę dla swego ludu.
###### **Est 4,9**
 Wrócił Hatak i powtórzył Esterze wszystko, co usłyszał od Mardocheusza.
###### **Est 4,10**
 Posłała tedy Estera po raz drugi Hataka do Mardocheusza i kazała mu powiedzieć:
###### **Est 4,11**
 Wszyscy słudzy króla oraz mieszkańcy prowincji królewskich wiedzą, że każdego, zarówno spośród mężczyzn, jak i kobiet, kto by próbował bez specjalnego wezwania dostać się do króla, na wewnętrzny dziedziniec, dotyczy to samo prawo: każdy ma być zabity, chyba że król wyciągnie nad nim złote berło - wtedy ocaleje. A mnie nie wzywano do króla już od trzydziestu dni.
###### **Est 4,12**
 Powtórzył więc Hatak Mardocheuszowi to, co powiedziała Estera.
###### **Est 4,13**
 A Mardocheusz kazał odpowiedzieć Esterze tak: Nie myśl sobie, że skoro żyjesz już w pałacu królewskim, to tylko ty jedna będziesz mogła ocaleć.
###### **Est 4,14**
 Jeżeli ty nie przemówisz teraz, to skądinąd przyjdzie dla Żydów pomoc i ocalenie. Ale wtedy zginiesz ty sama i cały dom twojego ojca zostanie zgładzony. Kto wie, czy nie po to, [żeby ratować Żydów] akurat w tym czasie, zostałaś wyniesiona do godności królewskiej?
###### **Est 4,15**
 Wtedy Estera przesłała taką odpowiedź Mardocheuszowi:
###### **Est 4,16**
 Pójdź i zbierz razem wszystkich Żydów, którzy żyją w Suzie. Zacznijcie pościć w mojej intencji. Przez trzy dni i trzy noce nie jedzcie nic ani nie pijcie. Ja i moje służebnice będziemy pościły tak samo. A potem udam się do króla, mimo że prawo wyraźnie tego zabrania. Jeśli przyjdzie mi zginąć, to zginę.
###### **Est 4,17**
 Poszedł tedy Mardocheusz i uczynił wszystko dokładnie tak, jak mu poleciła Estera. (a) Mardocheusz wspominał wszystkie wielkie dzieła Pana i modlił się do Niego mówiąc: (b) Panie, Panie, Królu i Władco wszechrzeczy! Ty jesteś w stanie unicestwić wszystko. Jeżeli tylko zechcesz uratować Izrael, nikt Ci w tym nie przeszkodzi. (c) Ty przecież stworzyłeś niebo i ziemię, i wszystko, co podziwiamy pod niebem. Jesteś panem wszystkiego i nikt nie odważy się wystąpić przeciwko Tobie, o Panie. (d) Ty znasz wszystko. Ty wiesz, o Panie, że nie zgiąłem kolan przed wyniosłym Hamanem ani z pychy, ani z próżności, ani z żądzy sławy. Ale nadal byłbym gotów całować nawet ślady jego stóp, gdyby się to przyczyniło do ocalenia Izraela. (e) Postępowałem zaś tak dlatego, że nie chciałem okazywać człowiekowi czci większej niż Bogu. Będę oddawał pokłony tylko mojemu Bogu i nikomu więcej, a postępując tak wcale nie hołduję próżności. (f) Teraz więc, Panie mój i Boże, Królu i Boże Abrahama, zechciej wziąć w obronę twój lud. Patrzą bowiem na nas dokoła z nienawiścią i szukają zagłady tych, którzy są od początku Twoim dziedzictwem. (g) Nie gardź Twoim dziedzictwem, które wykupiłeś z Egiptu. (h) Wysłuchaj mojego błagania, ulituj się nad Twoim dziedzictwem i przemień nasz smutek w radość, abyśmy mogli żyć i wielbić Twoje imię, o Panie. Nie dopuszczaj do tego, by zamilkły usta tych, którzy Cię chwalą. (i) Cały Izrael wołał ze wszystkich sił do Pana, bo śmierć stała już przed ich oczyma. (k) Strach przed śmiercią ogarnął także królową Esterę, która również zaczęła szukać ratunku u Pana. Zdjęła z siebie swoje kosztowne suknie i przyodziała się w szaty z dni ucisku i żałoby. Nie używała już więcej drogich wonności, tylko popiołem i pyłem z ziemi posypywała swoją głowę. Przestała się troszczyć zupełnie o swoje ciało, a jej włosy nie były już pięknie ułożone, lecz spadały bezładnie na ramiona. I modliła się do Pana, Boga Izraela, mówiąc: (l) O Panie, nasz jedyny Królu! Wspomóż mnie! jestem bowiem sama i nie mam nikogo, kto by mi pomógł, a niebezpieczeństwo jest już blisko. (m) Słyszałam, że od dzieciństwa z całą moją rodziną należałam do pokolenia, które Ty, Panie, wybrałeś jako Izrael spośród innych narodów, a naszych przodków uważałeś za swoje odwieczne dziedzictwo i czyniłeś im zawsze to, co obiecałeś. (n) Jednakże dopuściliśmy się wykroczeń przeciwko Tobie i dlatego wydałeś nas w ręce naszych wrogów, których bóstwom składaliśmy hołdy. I słusznie postąpiłeś, o Panie. (o) Ale teraz wrogom naszym nie wystarcza już to, że nas okrutnie uciskają. Poprzysięgli oni swoim bogom, że zniweczą Twoje obietnice, unicestwią Twoje dziedzictwo, zamkną raz na zawsze usta tych, którzy Cię uwielbiają, i wygaszą światła twojej świątyni oraz ogień na Twoim ołtarzu. (p) Pragną oni natomiast, ażeby poganie otworzyli swoje usta i chwalili swoich bożków, oddając cześć po wszystkie czasy śmiertelnemu królowi. (q) Nie oddawaj, o Panie, Twojego berła nic nie znaczącym bożkom! Niech nie naigrawają się wyniośle z naszych upadków! Spraw, żeby ich złe zamiary obróciły się przeciw nim samym, z tym zaś, który wszystko to przeciw nam uknuł, postąp tak, by posłużył innym za ostrzeżenie. (r) Wspomnij na nas, o Panie! Ukaż się nam za dni naszego ucisku i dodaj mi odwagi, Królu bogów i Władco wszystkich mocy! (s) Włóż w moje usta odpowiednie słowa, kiedy będę przechodzić koło lwa, i spraw, żeby począł się srożyć ze wszystkich sił na naszego wroga, doprowadzając ostatecznie do zagłady jego samego i wszystkich, co tak jak on czują. (t) Nas zaś uratuj Twoją własną prawicą. Pomóż mi, bo jestem sama i oprócz Ciebie nie mam nikogo, kto by mi pomógł, o Panie! (u) Ty wiesz wszystko! Ty wiesz również, że nienawidzę tej próżności bezbożnej i że czuję odrazę do łoża męża nieobrzezanego i do wszystkiego, co obce. (v) Ty znasz moją niedolę i wiesz, ze nie znoszę tych oznak mojej godności i że tylko pod przymusem zakładam na głowę diadem, kiedy mam się ukazywać publicznie. (w) Brzydzę się tym wszystkim jak szmatą w dniach mojego krwawienia i nie zakładam go, kiedy zażywam odpoczynku. (x) Służebnica twoja nigdy również nie zasiadała do stołu razem z Hamanem ani nie miała upodobania w królewskich ucztach, ani nie piła wina składanego na ofiarę. (y) Dla twojej służebnicy od dnia, w którym się tu znalazła, powodem radości byłeś tylko Ty, o Panie, Boże Abrahama. (z) O Boże, który zarządzasz wszystkim, racz wysłuchać błagania wątpiących [już w ocalenie] i uwolnij nas z rąk złoczyńców! Uwolnij mnie od wszelkiego lęku!
# Est 4 WUJ
###### **Est 4,1**
 Co gdy usłyszał Mardocheusz rozdarł szaty swe, i oblókł się w wór, posypawszy głowę popiołem: i na ulicy w pośród miasta krzyczał Wielkim głosem, okazując gorzkość serca swego,
###### **Est 4,2**
 I z tym krzykiem aż do drzwi pałacu idąc. Bo się nie godziło obleczonemu w wór wniść na dwór królewski.
###### **Est 4,3**
 Po wszystkich też krainach, miasteczkach i miejscach, do których okrutny wyrok królewski był przyszedł, była niezmierna żałość u Żydów, post, krzyk, i płacz, i wiele ich miasto pościeli woru i popiołu używało.
###### **Est 4,4**
 I weszły panny służebne Esther i rzezańcy, i oznajmili jej. Co usłyszawszy zlękła się: i posłała szatę, aby go, zdjąwszy wór, ubrali: którą przyjąć nie chciał.
###### **Est 4,5**
 I zawoławszy Athach rzezańca, którego jej był król dał za służebnika, rozkazała mu, aby szedł do Mardocheusza, a dowiedział się od niego przeczby to czynił.
###### **Est 4,6**
 I wyszedszy Athach, szedł do Mardecheusza stojącego na ulicy miejskiej, przede drzwiami pałacu.
###### **Est 4,7**
 Który mu powiedział wszystko co się działo, jako Aman obiecał, że miał wnieść srebro do skarbów królewskich za żydów wytracenie.
###### **Est 4,8**
 I kopiją też wyroku, który był przybit w Susan dał mu, aby królowej ukazał, i napominał ją, aby weszła do króla, i prosiła go za ludem swoim.
###### **Est 4,9**
 Wróciwszy się Athach, powiedział Esther wszystko, co był Mardocheusz rzekł.
###### **Est 4,10**
 Która mu odpowiedziała, i kazała, żeby powiedział Mardocheuszowi.
###### **Est 4,11**
 Wszyscy służebnicy królewscy, i wszystkie krainy, które pod mocą jego są, wiedzą, iż jeśliby, chocia mężczyzna, choć białagłowa, nie będąc wezwani do sieni wewnętrznej królewskiej wszedł, bez żadnej odwłoki ma być zabit, chybaby król laskę złotą kniemu ściągnął na znak łaski, tożby tak mógł żyw zostać. Jakoż tedy ja mam wniść do króla któram już trzydzieści dni nie jest wezwana do niego?
###### **Est 4,12**
 Co gdy usłyszał Mardocheusz,
###### **Est 4,13**
 Zasię wskazał do Esther mówiąc: Nie mnimaj, abyś tylko duszę twoję wyzwoliła mimo wszystkie Żydy, iżeś jest w domu królewskim:
###### **Est 4,14**
 Bo jeśli teraz milczeć będziesz, innym sposobem będą wybawieni żydzi: a ty, i dom ojca twego zginiecie. A kto wie, jeśliś nie dla tego dostąpiła królestwa, abyś na taki czas zgotowana była?
###### **Est 4,15**
 Znowu Esther do Mardocheusza te słowa wskazała:
###### **Est 4,16**
 Idź, a zbierz wszystkie Żydy, które w Susan najdziesz, a módlcie się za mną. Nie jedzcie ani pijcie przez trzy dni i przez trzy nocy: a ja takież będę się pościć z służebnicami swemi, a tedy wnidę do króla, czyniąc przeciw prawu, nie będąc wezwana, i wydając się na śmierć i niebezpieczność.
###### **Est 4,17**
 Szedł tedy Mardocheusz, i uczynił wszystko co mu była Esther rozkazała.
