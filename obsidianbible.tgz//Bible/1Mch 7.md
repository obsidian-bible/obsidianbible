# 1Mch 7 BT5
###### **1Mch 7,1**
 W roku sto pięćdziesiątym pierwszym Demetriusz, syn Seleukosa, wyruszył z Rzymu z niewielką liczbą wojska. Wylądował w nadmorskim mieście i jako król zaczął tam panować.
###### **1Mch 7,2**
 Gdy wszedł do królewskiego pałacu swoich przodków, wojska pochwyciły Antiocha i Lizjasza, aby ich przyprowadzić do niego.
###### **1Mch 7,3**
 Kiedy doniesiono mu o tym, powiedział: «***Nie pokazujcie mi ich twarzy!***»
###### **1Mch 7,4**
 Wojsko więc zamordowało ich, a Demetriusz zasiadł na tronie swego królestwa.
###### **1Mch 7,5**
 Wtedy wszyscy wiarołomni i bezbożni spomiędzy Izraela przybyli do niego, a przywódcą ich był Alkimos, który chciał osiągnąć godność arcykapłana.
###### **1Mch 7,6**
 Tak oskarżyli oni naród przed królem: «***Juda razem ze swoimi braćmi wytracił wszystkich twoich przyjaciół, a nas wypędził z ojczystego kraju.***
###### **1Mch 7,7**
 ***Poślij więc teraz swojego zaufanego męża, niech on idzie i niech zobaczy krzywdę, jaką wyrządził nam i królewskiemu krajowi, i niech ukarze ich razem z tymi wszystkimi, którzy im pomagają***».
###### **1Mch 7,8**
 Król wybrał Bakchidesa, jednego z królewskich przyjaciół, który władzę swą wykonywał za Rzeką, a będąc wpływowym człowiekiem w królestwie, wierny był królowi.
###### **1Mch 7,9**
 Jego to wysłał razem z bezbożnym Alkimosem, któremu przyznał godność kapłańską, i nakazał pomstę na synach Izraela.
###### **1Mch 7,10**
 Wyruszywszy, przybyli wraz z licznym wojskiem do ziemi judzkiej. Stamtąd wysłał poselstwo do Judy i do jego braci, podstępnie używając słów pokojowych.
###### **1Mch 7,11**
 Oni jednak nie uwierzyli ich słowom. Widzieli bowiem, że przybyli z licznym wojskiem.
###### **1Mch 7,12**
 U Alkimosa i Bakchidesa zebrało się zgromadzenie uczonych w Piśmie, aby naradzić się nad tym, co jest słuszne.
###### **1Mch 7,13**
 Spomiędzy synów Izraela asydejczycy pierwsi starali się o to, żeby z nimi zawrzeć pokój.
###### **1Mch 7,14**
 Mówili bowiem: «***Razem z wojskiem przyszedł przecież arcykapłan z rodu Aarona. On nam nie zrobi żadnej krzywdy***».
###### **1Mch 7,15**
 Rozmawiał on z nimi pokojowo i przysiągł im, zapewniając: «***Ani wam, ani też przyjaciołom waszym nie uczynimy nic złego***».
###### **1Mch 7,16**
 Uwierzyli mu więc, a on rozkazał pochwycić spomiędzy nich sześćdziesięciu ludzi i zamordować ich w ciągu jednego dnia, zgodnie ze słowami Pisma:
###### **1Mch 7,17**
 Ciała Twych świętych [porzucili],a krew ich rozlali dokoła Jeruzalem, i nie było nikogo, kto by ich pochował.
###### **1Mch 7,18**
 Bojaźń zaś i drżenie padły na cały lud, gdyż mówiono: «***Nie ma w nich prawdy ani sprawiedliwości. Złamali bowiem umowę i przysięgę, którą złożyli***».
###### **1Mch 7,19**
 Wtedy Bakchides odstąpił od Jerozolimy i rozłożył się obozem koło Bet-Zait. Tam kazał pochwycić wielu tych ludzi, którzy sami uciekli od niego, i niektórych spomiędzy ludu zamordował [i wrzucił] do wielkiej cysterny.
###### **1Mch 7,20**
 Potem Bakchides oddał Alkimosowi władzę nad krajem i pozostawił mu wojsko do pomocy, sam zaś powrócił do króla.
###### **1Mch 7,21**
 Alkimos starał się objąć władzę arcykapłańską,
###### **1Mch 7,22**
 do niego zaś zeszli się wszyscy, którzy ciemiężyli swój własny naród, bo zawładnęli judzką krainą i przyczynili się do wielkiej klęski Izraela.
###### **1Mch 7,23**
 Gdy Juda zobaczył całe zło, którego dopuścił się Alkimos i jego zwolennicy, w większym stopniu aniżeli poganie,
###### **1Mch 7,24**
 obszedł dokoła wszystkie ziemie Judei i wywarł pomstę na odstępcach, tak że nie mogli oni poruszać się po kraju.
###### **1Mch 7,25**
 Gdy Alkimos przekonał się, że Juda razem ze swoimi zwolennikami znów ma wiele sił, i kiedy spostrzegł, że nie będzie się mógł mu przeciwstawić, wrócił do króla i oskarżył ich o złe zamiary.
###### **1Mch 7,26**
 Wtedy król wysłał Nikanora, jednego z najznaczniejszych swoich dowódców, który nienawidził Izraela i wrogo do niego się odnosił. Wydał mu też rozkaz, aby wytępił naród.
###### **1Mch 7,27**
 Nikanor zaś z licznym wojskiem przybył do Jerozolimy, a do Judy i jego braci wysłał poselstwo, podstępnie mówiąc do nich pokojowymi słowami:
###### **1Mch 7,28**
 «***Niech między mną a wami nie będzie żadnej wojny. Z nielicznym oddziałem przybędę, aby w pokoju zobaczyć was osobiście***».
###### **1Mch 7,29**
 Przybył więc do Judy i wzajemnie po przyjacielsku się pozdrowili, ale nieprzyjaciele byli w pogotowiu, aby Judę porwać.
###### **1Mch 7,30**
 Wtedy Juda dowiedział się, że przybył do niego zdradliwie. Przeląkł się go i nie chciał więcej się z nim widzieć.
###### **1Mch 7,31**
 Nikanor zaś domyślił się, że jego zamiar został odkryty. Wystąpił więc do walki przeciwko Judzie koło Chafarsalama.
###### **1Mch 7,32**
 Spośród wojska Nikanora padło blisko pięciuset żołnierzy, a reszta uciekła do Miasta Dawidowego.
###### **1Mch 7,33**
 Po tych wypadkach Nikanor udał się na górę Syjon. Ze świątyni spomiędzy kapłanów i spomiędzy starszych ludu wyszli niektórzy, aby pokojowo go powitać i pokazać mu całopalenie składane za króla.
###### **1Mch 7,34**
 On jednak wyszydził i wyśmiał ich, i znieważył. Przemówił też zarozumiale,
###### **1Mch 7,35**
 a nawet pełen gniewu przysiągł: «***Jeżeli w tej chwili Juda razem ze swoim wojskiem nie zostanie wydany w moje ręce, spalę tę świątynię, gdy szczęśliwie powrócę***». I wyszedł z wielkim gniewem.
###### **1Mch 7,36**
 Wtedy kapłani powrócili, stanęli przed ołtarzem i przed przybytkiem, zaczęli płakać i modlić się:
###### **1Mch 7,37**
 «***Ty sam wybrałeś tę świątynię, aby była poświęcona Twojemu imieniu, aby była dla Twego ludu domem modlitwy i błagania.***
###### **1Mch 7,38**
 ***Dokonaj pomsty na tym człowieku i na jego wojsku. Niech zginą od miecza! Pamiętaj o ich bluźnierstwach i nie pozwól im nadal trwać!***»
###### **1Mch 7,39**
 Nikanor odszedł z Jeruzalem i rozłożył się obozem w Bet-Choron. Tam przyłączyło się do niego wojsko z Syrii.
###### **1Mch 7,40**
 Juda zaś rozłożył się obozem w Adasa razem z trzema tysiącami żołnierzy i modlił się słowami:
###### **1Mch 7,41**
 «***Gdy bluźnili posłowie króla, wtedy anioł Twój stanął i zabił spomiędzy nich sto osiemdziesiąt pięć tysięcy.***
###### **1Mch 7,42**
 ***Tak samo zetrzyj na proch to wojsko dzisiaj przed nami! Niech poznają ci, którzy pozostaną, jak strasznie zbluźnił on przeciwko Twojej świątyni; osądź go tak, jak jego złość na to zasługuje***».
###### **1Mch 7,43**
 W trzynastym dniu miesiąca Adar wojska spotkały się w walce i wojsko Nikanora zostało rozbite. On sam pierwszy padł w bitwie.
###### **1Mch 7,44**
 A gdy jego wojsko zobaczyło, że Nikanor zginął, porzuciwszy broń, uciekło.
###### **1Mch 7,45**
 Ścigali więc ich na dzień drogi od Adasa aż blisko Gezer. Wtedy w ślad za nimi grały trąby sygnałowe.
###### **1Mch 7,46**
 I ze wszystkich dokoła wiosek Judei wyszli mieszkańcy i osaczyli ich. Tamci obrócili się przeciwko nim, ale wszyscy padli od miecza i nie pozostał z nich ani jeden.
###### **1Mch 7,47**
 Zabrano łupy i to, co tamci zrabowali, a głowę Nikanora i jego prawą rękę, którą tak hardo wyciągnął, obcięli, zanieśli do Jerozolimy i wystawili na widok publiczny.
###### **1Mch 7,48**
 Lud zaś bardzo się uradował i dzień ten obchodził jako dzień wielkiej radości.
###### **1Mch 7,49**
 Postanowiono też, żeby rokrocznie ten dzień obchodzić uroczyście dnia trzynastego Adar.
###### **1Mch 7,50**
 Na krótki czas pokój zapanował w ziemi judzkiej.
# 1Mch 7 PAU
###### **1Mch 7,1**
 W roku sto pięćdziesiątym pierwszym Demetriusz, syn Seleukosa, wyruszył z Rzymu z niewielką liczbą ludzi. Przybył do nadmorskiego miasta i obwołał się królem.
###### **1Mch 7,2**
 Kiedy wszedł do królewskiego pałacu swoich przodków, żołnierze pochwycili Antiocha i Lizjasza i chcieli przyprowadzić ich do niego.
###### **1Mch 7,3**
 Gdy o tym usłyszał, powiedział: „Nie chcę ich widzieć”.
###### **1Mch 7,4**
 Żołnierze więc zabili ich, a Demetriusz objął władzę królewską.
###### **1Mch 7,5**
 Przybyli do niego wszyscy ludzie nieprawi i bezbożni z Izraela. Przywiódł ich Alkimos, który chciał sprawować urząd najwyższego kapłana.
###### **1Mch 7,6**
 Oskarżyli lud wobec króla, mówiąc: „Juda i jego bracia wytracili wszystkich twoich przyjaciół, a nas wypędzili z naszej ziemi.
###### **1Mch 7,7**
 Poślij więc teraz zaufanego człowieka, aby poszedł i zobaczył całe zniszczenie, które oni wyrządzili nam i królewskiej krainie. Niech wymierzy karę im i wszystkim, którzy ich wspierali”.
###### **1Mch 7,8**
 Król wybrał Bakchidesa, jednego z królewskich przyjaciół. Zarządzał on Transeufrateą, był bardzo wpływowy w królestwie i wierny królowi.
###### **1Mch 7,9**
 Król posłał go wraz z bezbożnym Alkimosem, którego ustanowił najwyższym kapłanem, i kazał mu ukarać Izraelitów.
###### **1Mch 7,10**
 Wyruszyli więc z licznym wojskiem do ziemi Judy. Wysłali posłów do Judy i jego braci, podstępnie proponując zawarcie pokoju.
###### **1Mch 7,11**
 Oni jednak nie uwierzyli ich słowom, bo widzieli, że przyszli z licznym wojskiem.
###### **1Mch 7,12**
 U Alkimosa i Bakchidesa zebrała się grupa nauczycieli Pisma, aby szukać sprawiedliwego rozwiązania.
###### **1Mch 7,13**
 Asydejczycy jako pierwsi spośród Izraelitów zabiegali o zawarcie z nimi pokoju.
###### **1Mch 7,14**
 Mówili bowiem: „Razem z wojskami przybył przecież kapłan z rodu Aarona. On nas nie skrzywdzi”.
###### **1Mch 7,15**
 A on mówił do nich o pokoju i zapewniał ich: „Nie chcemy wyrządzić zła ani wam, ani waszym przyjaciołom”.
###### **1Mch 7,16**
 I uwierzyli mu. Lecz on kazał pojmać sześćdziesięciu z nich i zamordować ich jednego dnia, tak jak zostało napisane:
###### **1Mch 7,17**
 Ciała Twoich wiernych porzucili i krew ich rozlali wokół Jeruzalem, i nie miał kto ich pogrzebać.
###### **1Mch 7,18**
 Wówczas strach i przerażenie ogarnęło cały lud. Mówiono: „Nie ma w nich prawdy ani sprawiedliwości, bo złamali umowę i przysięgę, którą złożyli”.
###### **1Mch 7,19**
 Bakchides odszedł z Jeruzalem i rozłożył obóz w Bet-Zait. Kazał pojmać, zabić i wrzucić do wielkiego zbiornika na wodę wielu z tych, którzy wcześniej przyłączyli się do niego, a także niektórych z ludu.
###### **1Mch 7,20**
 Bakchides przekazał Alkimosowi władzę nad krajem i zostawił mu do pomocy wojsko. Sam zaś wrócił do króla.
###### **1Mch 7,21**
 Alkimos walczył o urząd najwyższego kapłana.
###### **1Mch 7,22**
 Przy nim zgromadzili się wszyscy, którzy siali zamęt wśród ludu. Opanowali oni ziemię Judy i sprowadzili nieszczęście na Izraela.
###### **1Mch 7,23**
 Kiedy Juda zobaczył, że Alkimos i jego ludzie wyrządzają Izraelitom więcej zła niż obce narody,
###### **1Mch 7,24**
 obszedł wszystkie regiony Judei i dokonał pomsty na odstępcach, uniemożliwiając im poruszanie się po kraju.
###### **1Mch 7,25**
 Wtedy Alkimos zrozumiał, że Juda i jego towarzysze są silniejsi od niego, i przekonał się, że nie jest w stanie im się przeciwstawić. Wrócił więc do króla i oskarżał ich o złe rzeczy.
###### **1Mch 7,26**
 Wtedy król wysłał Nikanora, jednego ze swych najsłynniejszych dowódców, który nienawidził Izraela i był jego wrogiem, i nakazał mu wyniszczyć lud.
###### **1Mch 7,27**
 Nikanor przybył do Jeruzalem z licznym wojskiem i wysłał do Judy i jego braci podstępną propozycję zawarcia pokoju:
###### **1Mch 7,28**
 „Nie walczmy przeciwko sobie. Przybędę w pokoju z niewielkim oddziałem, aby spotkać się z wami”.
###### **1Mch 7,29**
 Przybył więc do Judy i wymienił z nim pokojowe pozdrowienie. Tymczasem wrogowie byli gotowi porwać Judę.
###### **1Mch 7,30**
 Juda jednak dowiedział się o podstępie Nikanora, przestraszył się i nie chciał się ponownie z nim spotkać.
###### **1Mch 7,31**
 Wtedy Nikanor zrozumiał, że jego zamiar został odkryty i wyruszył do bitwy przeciwko Judzie w pobliżu Chafarsalama.
###### **1Mch 7,32**
 Nikanor stracił około pięciuset ludzi, a pozostali uciekli do Miasta Dawida.
###### **1Mch 7,33**
 Po tych wydarzeniach Nikanor wszedł na górę Syjon. Niektórzy kapłani wyszli ze świątyni i wraz ze starszymi ludu pozdrowili go pokojowo i pokazali mu całopalenie składane za króla.
###### **1Mch 7,34**
 On jednak wyszydził ich, wyśmiał, znieważył i obrzucił obelgami.
###### **1Mch 7,35**
 Potem przysiągł ze złością: „Jeśli Juda i jego wojsko nie zostaną natychmiast wydani w moje ręce, to gdy wrócę szczęśliwie, spalę tę świątynię”. I odszedł bardzo zagniewany.
###### **1Mch 7,36**
 Wtedy kapłani wrócili, stanęli naprzeciwko ołtarza i świętego mieszkania i modlili się, płacząc:
###### **1Mch 7,37**
 „Ty wybrałeś ten dom, aby wzywano w nim Twego imienia, aby dla Twojego ludu był on domem modlitwy i błagania.
###### **1Mch 7,38**
 Dokonaj pomsty na tym człowieku i jego wojsku. Niech zginą od miecza. Pamiętaj o ich bluźnierstwach i nie daj im wytchnienia”.
###### **1Mch 7,39**
 Nikanor opuścił Jeruzalem i rozbił obóz w Bet-Choron. Tam dołączyło do niego wojsko z Syrii.
###### **1Mch 7,40**
 A Juda z trzema tysiącami ludzi rozbił obóz w Adasie. Potem Juda modlił się słowami:
###### **1Mch 7,41**
 „Gdy posłowie królewscy bluźnili, pojawił się Twój anioł i pobił sto osiemdziesiąt pięć tysięcy spośród nich.
###### **1Mch 7,42**
 Podobnie i dzisiaj zetrzyj to wojsko przed nami! Niech ci, którzy pozostaną, przekonają się, że Nikanor złorzeczył Twojej świątyni. Osądź go stosownie do jego przestępstwa”.
###### **1Mch 7,43**
 Trzynastego dnia miesiąca Adar wojska stoczyły bitwę. Wojsko Nikanora zostało rozbite. On pierwszy zginął w walce.
###### **1Mch 7,44**
 Kiedy jego żołnierze zobaczyli, że Nikanor poległ, porzucili broń i uciekli.
###### **1Mch 7,45**
 Ścigano ich na odległość jednego dnia drogi: od Adasy aż do wejścia do Gezer. Dawano sygnały na trąbach,
###### **1Mch 7,46**
 a z wszystkich okolicznych wiosek Judei wychodzili ludzie, aby ich osaczyć. Tamci zwrócili się przeciwko nim, lecz wszyscy padli od miecza, żaden z nich nie pozostał przy życiu.
###### **1Mch 7,47**
 Zabrano łupy i to, co tamci zrabowali. Nikanorowi odcięto głowę i prawą rękę, którą zuchwale wyciągał. Zabrano je i wystawiono w pobliżu Jeruzalem.
###### **1Mch 7,48**
 Lud bardzo się cieszył i obchodzono ten dzień jako dzień wielkiej radości.
###### **1Mch 7,49**
 I postanowiono świętować każdego roku trzynasty dzień miesiąca Adar.
###### **1Mch 7,50**
 Na krótki czas zapanował w ziemi Judy pokój.
# 1Mch 7 BP
###### **1Mch 7,1**
 W roku sto pięćdziesiątym pierwszym Demetriusz, syn Seleukosa, wyruszył z Rzymu z niewielkim zastępem mężów. Wylądował w nadmorskim mieście i ogłosił się królem.
###### **1Mch 7,2**
 Pewnego razu, gdy wszedł do królewskiego pałacu swych ojców, wojsko pochwyciło Antiocha i Lizjasza, aby ich przyprowadzić przed jego oblicze.
###### **1Mch 7,3**
 Na wieść o tym rzekł: "Nie chcę ich widzieć."
###### **1Mch 7,4**
 Zostali więc zamordowani przez żołnierzy, a Demetriusz zasiadł na tronie królewskim.
###### **1Mch 7,5**
 Wówczas przybyli do niego nie szanujący Prawa i bezbożni Izraelici. Przyprowadził ich Alkimos, który chciał zostać arcykapłanem.
###### **1Mch 7,6**
 Oskarżyli oni lud przed królem mówiąc: "Juda i jego bracia pomordowali wszystkich twoich przyjaciół, a nas wygnali z własnej ojczyzny.
###### **1Mch 7,7**
 Wyślij przeto zaufanego człowieka, niech idzie i przekona się naocznie o całym zniszczeniu, jakiego dokonał w stosunku do nas i ziemi królewskiej oraz niech ich ukarze, a także tych wszystkich, którzy mu pomagali."
###### **1Mch 7,8**
 Spośród swych przyjaciół wybrał król Bakchidesa, który sprawował władzę w kraju położonym za Rzeką, człowieka mającego znaczne wpływy w królestwie i oddanego królowi.
###### **1Mch 7,9**
 Wysłał go razem z bezbożnym Alkimosem, któremu powierzył godność arcykapłana, i nakazał mu wywrzeć zemstę na synach Izraela.
###### **1Mch 7,10**
 Wyruszyli w drogę z wielkim wojskiem i przybyli do ziemi judzkiej. Knując podstęp wysłali posłów do Judy i jego braci z propozycją zawarcia pokoju.
###### **1Mch 7,11**
 Ale oni nie dali się uwieść ich słowom - wiedzieli bowiem, z jakim licznym wojskiem przybyli.
###### **1Mch 7,12**
 Do Alkimosa i Bakchidesa udała się grupa uczonych w Piśmie, aby znaleźć słuszne wyjście.
###### **1Mch 7,13**
 Spośród Izraelitów asydejczycy pierwsi starali się zawrzeć pokój.
###### **1Mch 7,14**
 Mówili bowiem: "Kapłan z rodu Aarona przybył wraz z wielkim wojskiem. On nie uczyni nam krzywdy."
###### **1Mch 7,15**
 Rozmawiał z nimi przyjaźnie i przysięgał, że nie wyrządzą krzywdy ani im, ani ich przyjaciołom.
###### **1Mch 7,16**
 A gdy mu zaufali, rozkazał w jednym dniu pochwycić sześćdziesięciu mężów spośród nich i wymordować, aby się wypełniły słowa Pisma:
###### **1Mch 7,17**
 Skrwawione ciała Twych świętych porzucili wokół Jerozolimy; i nie było nikogo, kto by ich pochował.
###### **1Mch 7,18**
 Bojaźń i strach padły na cały naród. Mówiono bowiem: "Nie ma w nich prawdy ani sprawiedliwości: nie dotrzymali umowy i złamali złożoną przysięgę."
###### **1Mch 7,19**
 Bakchides odstąpił od Jerozolimy i rozłożył się obozem pod Betzet. Wysłani przez niego ludzie pochwycili wielu spośród tych, którzy przeszli na jego stronę, i niektórych z ludu. Kazał ich zabić i wrzucić do wielkiej studni.
###### **1Mch 7,20**
 Potem oddał kraj Alkimosowi pozostawiając mu wojsko do pomocy, sam natomiast wrócił do króla.
###### **1Mch 7,21**
 Alkimos usilnie zabiegał o arcykapłaństwo.
###### **1Mch 7,22**
 Skupili się wokół niego wszyscy ciemięzcy swego ludu. Opanowali oni ziemię judzką i byli sprawcami wielu nieszczęść w Izraelu.
###### **1Mch 7,23**
 Gdy Juda zobaczył, że krzywdy wyrządzone synom Izraela przez Alkimosa i jego popleczników są większe niż te, których dopuścili się poganie,
###### **1Mch 7,24**
 wyprawił się na graniczne okolice Judei i mścił się na odstępcach tak, że nie mogli napadać na krainę judzką.
###### **1Mch 7,25**
 Alkimos widząc, że Juda i jego towarzysze rosną w siłę, zrozumiał, że nie zdoła stawić im czoła. Zwrócił się więc do króla i oskarżał ich o wiele zbrodni.
###### **1Mch 7,26**
 Wówczas wysłał króla Nikanora, jednego ze swych najznakomitszych wodzów, śmiertelnego wroga Izraela, z rozkazem wymordowania ludu.
###### **1Mch 7,27**
 Przybywszy z licznym wojskiem do Jerozolimy wysłał Nikanor [poselstwo] do Judy i jego braci, przekazując im pozornie pokojowe, a w gruncie rzeczy podstępne propozycje:
###### **1Mch 7,28**
 "Nie chcę, aby doszło między nami do wojny. Przybędę z niewielkim oddziałem i spotkamy się jak przyjaciele."
###### **1Mch 7,29**
 Zjawił się więc u Judy i wymienił z nim przyjacielskie pozdrowienie. Równocześnie jego żołnierze gotowi byli porwać Judę.
###### **1Mch 7,30**
 Gdy jednak Juda dowiedział się, że przybycie [Nikanora] było podstępem, przeląkł się i nie chciał się już z nim spotkać.
###### **1Mch 7,31**
 Skoro Nikanor spostrzegł, że jego podstęp wyszedł na jaw, wyruszył przeciwko Judzie do walki i [spotkał się z nim] pod Chafarsalema.
###### **1Mch 7,32**
 Nikanor stracił około pięciuset ludzi, a reszta uciekła do Miasta Dawidowego.
###### **1Mch 7,33**
 Po tych wydarzeniach wstąpił Nikanor na górę Syjon. Niektórzy spośród kapłanów i starszych ludu wyszli ze Świątyni, aby go przyjaźnie powitać i pokazać mu całopalną ofiarę, którą mieli złożyć za króla.
###### **1Mch 7,34**
 On jednak szyderczo wyśmiał ich w zuchwałym przemówieniu i znieważył.
###### **1Mch 7,35**
 Poprzysiągł w gniewie, że jeżeli Juda wraz z wojskiem natychmiast nie będzie wydany w jego ręce, on - skoro tylko szczęśliwie powróci - spali Świątynię. Odszedł uniesiony wielkim gniewem.
###### **1Mch 7,36**
 Kapłani wrócili i stanąwszy przed ołtarzem i Przybytkiem modlili się z płaczem:
###### **1Mch 7,37**
 "Ty sam wybrałeś ten Przybytek, aby był poświęcony Twemu Imieniu i aby stał się dla Twego ludu Domem modlitwy błagalnej.
###### **1Mch 7,38**
 Wywrzyj zemstę na tym człowieku i jego wojsku, niech zginą od miecza. Pamiętaj o ich bluźnierstwach, nie dopuść, aby się ostali".
###### **1Mch 7,39**
 Nikanor zaś wyruszył do Jerozolimy i rozbił obóz w Betoron, gdzie połączyło się z nim wojsko syryjskie.
###### **1Mch 7,40**
 Juda na czele trzech tysięcy żołnierzy rozłożył się obozem w Adasa. I modlił się tymi słowami:
###### **1Mch 7,41**
 "Gdy posłowie królewscy bluźnili, zstąpił Twój anioł i wytracił spośród nich sto osiemdziesiąt pięć tysięcy ludzi.
###### **1Mch 7,42**
 Podobnie też i Ty zniszcz dzisiaj na naszych oczach to wojsko, aby ci, którzy pozostaną przy życiu, poznali, jak strasznie bluźnił przeciwko Twej Świątyni. I osądź go tak, jak na to zasługuje jego złość".
###### **1Mch 7,43**
 Trzynastego dnia miesiąca Adar wojska starły się w bitwie. Armia Nikanora poniosła klęskę, on sam pierwszy padł w boju.
###### **1Mch 7,44**
 Żołnierze widząc jego śmierć rzucili broń i uciekli.
###### **1Mch 7,45**
 [Żydzi] ścigali ich przez jeden dzień od Adasa aż do Gezer, trąbiąc głośno za nimi.
###### **1Mch 7,46**
 Na znak ten wyszli ludzie ze wszystkich okolicznych wsi Judei i osaczyli uciekających, którzy próbowali się bronić, lecz wszyscy padli od miecza i nikt nie uszedł z życiem.
###### **1Mch 7,47**
 Zebrali łupy i to, co wróg zrabował. Głowę zaś i prawą rękę Nikanora, którą tak hardo potrząsał, odcięli i wzięli z sobą, aby powiesić [przy wejściu] do Jerozolimy.
###### **1Mch 7,48**
 Lud bardzo się cieszył i dzień ten obchodził jako dzień wielkiej radości.
###### **1Mch 7,49**
 Postanowiono też, aby święcić go corocznie trzynastego Adar.
###### **1Mch 7,50**
 W ziemi judzkiej nastał krótki czas spokoju.
# 1Mch 7 BR
###### **1Mch 7,1**
 W roku sto pięćdziesiątym pierwszym Demetriusz, syn Seleukosa, uciekł z Rzymu z niewielką liczbą wojowników, dotarł do pewnego nadmorskiego miasta i obwołał się tam królem.
###### **1Mch 7,2**
 Kiedy wszedł do pałacu królewskiego swego ojca, jego wojsko pochwyciło Antiocha i Lizjasza, żeby ich oddać w jego ręce.
###### **1Mch 7,3**
 Kiedy Demetriuszowi o tym doniesiono, powiedział, że nie chce oglądać ich twarzy.
###### **1Mch 7,4**
 Zgładzono ich tedy obydwu, a Demetriusz objął władzę nad całym państwem.
###### **1Mch 7,5**
 Przybywali do niego z całego Izraela różni wykolejeńcy i przestępcy, a dowodził nimi niejaki Alkimos, który zapragnął być arcykapłanem.
###### **1Mch 7,6**
 Zaczęli oni podburzać króla, rzucając na lud oskarżenia: To Juda i jego bracia wymordowali wszystkich twoich przyjaciół, a nas wypędzili z naszej własnej ojczyzny.
###### **1Mch 7,7**
 Przyślij jakiegoś człowieka, któremu ufasz. Niech przyjdzie i zobaczy zło, którego się dopuścili wobec nas i całego kraju, pozostającego pod władzą króla. I niech wymierzy słuszną karę im oraz tym, którzy ich wspierają.
###### **1Mch 7,8**
 I wyznaczył król Bakchidesa, jednego ze swoich przyjaciół. Miał on pod swoją władzą ziemie położone z drugiej strony Rzeki, cieszył się wielkim poważaniem w całym państwie i był zawsze wierny królowi.
###### **1Mch 7,9**
 Do pomocy dał mu bezbożnika Alkimosa, którego uczynił arcykapłanem, i polecił im dokonać zemsty na Izraelitach.
###### **1Mch 7,10**
 Wyruszyli oni z wielkim wojskiem w drogę i przybyli do Judei. Posłali swoich ludzi do Judy i jego braci, donosząc im obłudnie, że pragną zawrzeć z nimi pokój.
###### **1Mch 7,11**
 Ale tamci nie uwierzyli, bo wiedzieli, że nadciągnęło ku nim mnóstwo wojska.
###### **1Mch 7,12**
 Wtedy u Alkimosa i Bakchidesa zebrała się grupa uczonych w Piśmie, żeby znaleźć jakieś rozwiązanie.
###### **1Mch 7,13**
 Spośród Izraelitów zaś hasydyjczycy jako pierwsi dążyli do tego, żeby zawrzeć z nimi pokój.
###### **1Mch 7,14**
 Zaczęto sobie mówić: Z wojskiem przyszedł kapłan z rodu Aarona. Taki nie może przecież uczynić nam nic złego.
###### **1Mch 7,15**
 Sam Alkimos okazywał im też wiele życzliwości, a nawet poprzysiągł, że ani ich, ani ich przyjaciół nie spotka żadne zło.
###### **1Mch 7,16**
 I uwierzyli mu. On zaś jeszcze tego samego dnia kazał sześćdziesięciu spośród nich pochwycić i zgładzić, zgodnie z tym, co jest napisane:
###### **1Mch 7,17**
 Ciała twoich świętych rozrzucone wokół Jeruzalem, przelano ich krew niewinną i nie było, kto by ich pogrzebał.
###### **1Mch 7,18**
 Wtedy dopiero cały lud zaczął drżeć przed nimi z bojaźni. Mówiono bowiem: Ani wierność słowu, ani prawo nie znajdują u nich żadnego poszanowania. Złamali umowę mimo przysięgi, którą ją potwierdzili.
###### **1Mch 7,19**
 Bakchides odstąpił od Jerozolimy i ruszył na Bet-Zait, gdzie rozbił swoje namioty. Tam też wielu spośród tych, którzy próbowali odłączyć się od niego, a także niektórych z ludu kazał pochwycić i [po zamordowaniu] wrzucić do wielkiej cysterny.
###### **1Mch 7,20**
 Potem przekazał cały kraj Alkimosowi, przydzieliwszy mu dla osłony część oddziałów wojskowych, a sam wrócił do króla.
###### **1Mch 7,21**
 Tymczasem Alkimos zabiegał o urząd arcykapłana.
###### **1Mch 7,22**
 Wszyscy wichrzyciele spośród ludu gromadzili się wokół niego. Przejęli władzę nad całą Judeą i sprowadzili na Izrael wiele nieszczęścia.
###### **1Mch 7,23**
 Kiedy Juda zobaczył, ile zła wyrządzili Izraelitom Alkimos i jego poplecznicy, gorsi od wszystkich cudzoziemców,
###### **1Mch 7,24**
 wyruszył w drogę, przemierzył całą Judeę i poskromił tych złoczyńców, tak że nie mogli już poruszać się swobodnie po całym kraju.
###### **1Mch 7,25**
 Alkimos, spostrzegłszy, że Juda razem ze swymi ludźmi, rozporządza znaczną siłą i że wobec tego on nie będzie mógł im sprostać, znów zwrócił się do króla, oskarżając ich o wszystko, co najgorsze.
###### **1Mch 7,26**
 Wtedy wysłał król jednego ze swych najbardziej wypróbowanych dowódców, Nikanora, nieprzejednanego wroga Izraelitów, i rozkazał mu wyniszczyć cały naród.
###### **1Mch 7,27**
 Przybył tedy Nikanor z ogromnym wojskiem do Jerozolimy. On też posłał swoich ludzi do Judy i jego braci, prosząc podstępnie o zawarcie z nimi pokoju. Kazał im powiedzieć:
###### **1Mch 7,28**
 Ja nie chcę z wami żadnej wojny. Wezmę ze sobą tylko kilku ludzi, spotkam się z wami, by szczerze porozmawiać o pokoju.
###### **1Mch 7,29**
 Później sam nawet przyszedł do Judy i pozdrowili się nawzajem po przyjacielsku. Tymczasem jego ludzie byli gotowi w każdej chwili rzucić się na Judę.
###### **1Mch 7,30**
 Ale Juda się dowiedział, że Nikanor przychodzi w złych zamiarach, i nie chciał już więcej się z nim spotykać.
###### **1Mch 7,31**
 Nikanor również zauważył, że jego plany zostały odkryte. Wyruszył więc przeciw Judzie i stoczył z nim bitwę koło Chafarsalama.
###### **1Mch 7,32**
 Spośród wojowników Nikonora padło wtedy około pięciuset ludzi, reszta zaś schroniła się do Miasta Dawidowego.
###### **1Mch 7,33**
 Po tym wszystkim wszedł Nikanor na górę Syjon. Ze świątyni wyszli mu naprzeciw kapłani i starsi ludu, aby go pozdrowić z całą życzliwością i pokazać mu ofiarę całopalenia, która miała być złożona za króla.
###### **1Mch 7,34**
 Ale on wyszydził ich, obrzucił obelgami i splugawił. Przechwalał się też
###### **1Mch 7,35**
 i odgrażał, a nawet przysiągł w gniewie, że jeśli Juda razem ze swoim wojskiem nie zostanie natychmiast wydany w jego ręce, to gdy tylko on, Nikanor, szczęśliwie tu powróci, spali świątynię i zionąc nienawiścią odszedł.
###### **1Mch 7,36**
 Wtedy kapłani weszli znów do środka, stanęli przed ołtarzem i przybytkiem i płacząc zaczęli mówić:
###### **1Mch 7,37**
 Wybrałeś sobie ten przybytek, żeby w nim było wzywane Twoje święte imię. Miał on być dla Twojego ludu domem modlitwy i błagania.
###### **1Mch 7,38**
 Zechciej się zemścić na tym człowieku i jego wojsku. Niech zginą od miecza. Pomnij na zniewagi, których od nich doznałeś, i nie pozwól im dłużej cieszyć się życiem.
###### **1Mch 7,39**
 Nikanor zaś opuścił Jerozolimę i rozbił swoje namioty w Bet-Choron, gdzie przyłączyła się do niego część oddziałów wojskowych, które były w Syrii.
###### **1Mch 7,40**
 Tymczasem Juda, z trzema tysiącami ludzi stanął obozem w Adasa i modlił się, mówiąc:
###### **1Mch 7,41**
 Kiedyś, gdy wysłannicy króla Aszszura Cię znieważyli, pojawił się Twój anioł i zgładził spośród nich sto osiemdziesiąt pięć tysięcy.
###### **1Mch 7,42**
 Racz dziś porazić na naszych oczach w podobny sposób to wojsko, ażeby ci z nich, którzy ocaleją, mogli się dowiedzieć, jak strasznego bluźnierstwa przeciwko Twemu świętemu przybytkowi dopuścił się Nikanor. Osądź go tak, jak na to zasługuje jego przestępstwo.
###### **1Mch 7,43**
 Trzynastego dnia miesiąca Adar doszło do starcia obydwu wojsk i wojownicy Nikanora ponieśli dotkliwą klęskę. Jako pierwszy poległ w walce sam Nikanor.
###### **1Mch 7,44**
 Kiedy jego wojownicy zobaczyli, że ich dowódca zginął, rzucili broń i ratowali się ucieczką.
###### **1Mch 7,45**
 Przez cały dzień ścigali ich Żydzi od Adasa aż do Gezer, bez przerwy dmąc w trąby.
###### **1Mch 7,46**
 Z okolicznych miejscowości Judei wybiegali na ten znak ludzie i okrążali ze wszystkich stron uciekających. Próbowali oni stawiać opór atakującym, ale ostatecznie wycięto ich co do jednego; ani jeden nie został przy życiu.
###### **1Mch 7,47**
 Żydzi zabrali całe ich uzbrojenie i bardzo bogate łupy. Nikanorowi odcięto głowę oraz prawą rękę - tę właśnie, którą tak zuchwale podnosił - zawieziono je do Jerozolimy i powieszono na miejscu publicznym.
###### **1Mch 7,48**
 Cały lud radował się bardzo, a dzień ten obchodzono jako wielkie święto.
###### **1Mch 7,49**
 Postanowiono też na przyszłość co roku obchodzić uroczyście trzynastego dnia miesiąca Adar.
###### **1Mch 7,50**
 Przez jakiś czas panował potem w Judei spokój.
# 1Mch 7 WUJ
