# 1Mch 8 BT5
###### **1Mch 8,1**
 Juda dowiedział się o sławie, jaką cieszą się Rzymianie: że są mocni i odważni, że okazują życzliwość wszystkim, którzy się do nich przyłączają, a nawet przyjaźń zawierają z tymi wszystkimi, którzy udają się do nich, a są mocni i odważni.
###### **1Mch 8,2**
 Opowiadano mu o ich wojnach i mężnych czynach dokonywanych wśród Galatów, jak ich zwyciężyli i zmusili do płacenia daniny;
###### **1Mch 8,3**
 tak samo o tym wszystkim, czego dokonali w kraju hiszpańskim, by zawładnąć tamtejszymi kopalniami srebra i złota;
###### **1Mch 8,4**
 jak każdym krajem, choćby to był kraj najbardziej od nich odległy, zawładnęli dzięki swojej roztropności i cierpliwości; jak pokonali królów, którzy z końca świata przeciw nim wyruszyli, jak zadali im wielką klęskę, i jak inni rokrocznie płacą im daninę.
###### **1Mch 8,5**
 Tak samo królów kittejskich, Filipa i Perseusza, razem z tymi, którzy przeciwko nim wzniecili powstanie, w czasie wojny rozbili i siłą poddali swej władzy.
###### **1Mch 8,6**
 Nawet Antioch Wielki, król Azji, który wyszedł na wojnę przeciwko nim, mając sto dwadzieścia słoni, konnicę, rydwany i bardzo wiele wojska, został przez nich pokonany.
###### **1Mch 8,7**
 Pochwycili go jednak żywcem i wyznaczyli jemu oraz jego następcom zapłacenie sobie wielkiej daniny, danie zakładników i odstąpienie krain,
###### **1Mch 8,8**
 mianowicie: Indii, Medii, Lidii < i > części najpiękniejszych ich posiadłości. Oni zaś odebrali je od niego i oddali królowi Eumenesowi.
###### **1Mch 8,9**
 [Opowiadano] też, jak mieszkańcy Hellady zamierzali wyruszyć, aby ich wytępić.
###### **1Mch 8,10**
 Oni jednak, dowiedziawszy się o tym, wysłali do nich jednego wodza, który walczył z nimi, tak że padło spośród nich wielu zabitych, żony ich i dzieci zostały wzięte do niewoli, złupili ich, a ziemię ich sobie przywłaszczyli, zburzyli ich warownie, a ich samych aż do tego dnia trzymają w niewoli.
###### **1Mch 8,11**
 Pozostałe zaś królestwa i wyspy, które kiedykolwiek im się przeciwstawiły, zniszczyli i poddali sobie w niewolę; z przyjaciółmi zaś swoimi i z tymi, którzy na nich polegają, zachowali przyjaźń.
###### **1Mch 8,12**
 Nad pobliskimi i nad odległymi królami rozciągnęli władzę. Lęk przed nimi ogarniał więc wszystkich, którzy słyszeli o ich imieniu.
###### **1Mch 8,13**
 Którym zechcą pomóc w osiągnięciu władzy królewskiej, ci ją sprawują; a których chcą, zrzucają z tronu. I wzrośli do ogromnej potęgi.
###### **1Mch 8,14**
 Przy tym wszystkim zaś ani jeden z nich nie włożył sobie diademu na głowę i nikt nie okrył się purpurą, by się nią chełpić.
###### **1Mch 8,15**
 Raczej ustanowili sobie radę. Codziennie zbiera się ich trzystu dwudziestu i zawsze radzą nad ludem, jak by najlepiej zachować w nim ład.
###### **1Mch 8,16**
 Rokrocznie jednemu człowiekowi powierzają rządy nad nimi i nad całym ich krajem, a wszyscy temu jednemu są posłuszni i nie ma pomiędzy nimi zazdrości ani nienawiści.
###### **1Mch 8,17**
 Juda więc wybrał Eupolemosa, syna Jana, syna Akkosa, oraz Jazona, syna Eleazara, i wysłał ich do Rzymu celem zawarcia przyjaźni i przymierza,
###### **1Mch 8,18**
 aby zdjęto z nich jarzmo. Widać bowiem było, że królestwo greckie usiłuje wziąć Izraela w niewolę.
###### **1Mch 8,19**
 Udali się więc do Rzymu, a droga była bardzo daleka, weszli do senatu i tak się odezwali:
###### **1Mch 8,20**
 «***Juda, zwany Machabeuszem, jego bracia i lud żydowski wysłali nas do was, abyśmy z wami zawarli przymierze i pokój, aby zapisano nas jako waszych sprzymierzeńców i przyjaciół***».
###### **1Mch 8,21**
 Przemówienie im się podobało.
###### **1Mch 8,22**
 To zaś jest odpis listu, który został napisany na tablicach z brązu i posłany do Jeruzalem, aby tam był u nich jako akt upamiętniający pokój i przymierze:
###### **1Mch 8,23**
 «***Niech Rzymianom i narodowi żydowskiemu zawsze dobrze się wiedzie na morzu i na lądzie, a miecz wroga niech będzie od nich z daleka!***
###### **1Mch 8,24**
 ***Jeżeliby jednak najpierw zagrażała wojna Rzymowi albo któremukolwiek jego sprzymierzeńcowi na całym obszarze ich władania,***
###### **1Mch 8,25**
 ***wtedy naród żydowski, zależnie od tego, jak okoliczności będą mu wskazywały, z całym poświęceniem będzie w walce pomagał.***
###### **1Mch 8,26**
 ***Walczącym zaś wrogom, według postanowienia Rzymu, nie będzie dostarczał zboża, broni, pieniędzy ani okrętów. Postanowień swych będą przestrzegali bez żadnego wynagrodzenia.***
###### **1Mch 8,27**
 ***Tak samo jeżeli narodowi żydowskiemu najpierw wypadnie wojować, Rzymianie, zależnie od tego, jak okoliczności będą im wskazywały, chętnie w walce im dopomogą.***
###### **1Mch 8,28**
 ***Walczącym zaś wrogom – według postanowienia Rzymu – nie będą dostarczane: zboże, broń, pieniądze ani okręty. Postanowień tych będą przestrzegali bez żadnego podstępu.***
###### **1Mch 8,29**
 ***Na podstawie tych postanowień Rzymianie zawarli układy z ludem żydowskim.***
###### **1Mch 8,30**
 ***Jeżeliby zaś jedni i drudzy chcieli coś dodać do tych postanowień albo coś z nich skreślić, będą mogli to uczynić wedle swej woli; dodatek albo skreślenie będą ważne.***
###### **1Mch 8,31**
 ***Co zaś się tyczy krzywd wyrządzonych im przez króla Demetriusza, to napisaliśmy do niego te słowa: Dlaczego naszych przyjaciół i sprzymierzeńców, Żydów, obciążyłeś swoim jarzmem?***
###### **1Mch 8,32**
 ***Jeżeli jeszcze będą skarżyli się na ciebie, wtedy ujmiemy się za ich prawami i będziemy z tobą wojować na morzu i na lądzie***».
# 1Mch 8 PAU
###### **1Mch 8,1**
 Juda usłyszał o sławie Rzymian, o tym, że są bardzo potężni i okazują przychylność wszystkim, którzy przyłączają się do nich; że zawierają przyjaźń z tymi, którzy o nią proszą, i że są bardzo potężni.
###### **1Mch 8,2**
 Opowiadano mu o ich wojnach i mężnych czynach, których dokonali wśród Galatów: że ich podbili i zmusili do płacenia daniny.
###### **1Mch 8,3**
 A także o ich czynach w krainie Hiszpanii, gdzie opanowali kopalnie srebra i złota.
###### **1Mch 8,4**
 O tym, jak każde to miejsce zdobyli dzięki swej roztropności i wytrwałości, choć znajdowało się ono bardzo daleko od nich. Królów, którzy wyruszyli przeciwko nim z krańca ziemi, pokonali, zadając im wielką klęskę. Pozostali zaś płacą im każdego roku daninę.
###### **1Mch 8,5**
 Zmiażdżyli w walce i podporządkowali sobie Filipa i Perseusza, króla Kittyjczyków, oraz innych, którzy przeciwko nim występowali.
###### **1Mch 8,6**
 Również Antioch, wielki król Azji, wyruszył przeciwko nim do walki, a chociaż miał sto dwadzieścia słoni, jeźdźców, rydwany bojowe i bardzo liczne wojsko, został przez nich pokonany.
###### **1Mch 8,7**
 Pojmali go żywego i postanowili, że on i jego następcy będą płacić wielką daninę i dostarczać zakładników, a ponadto, że zrzeknie się
###### **1Mch 8,8**
 krain Indii, Medii i Lidii oraz części swoich najpiękniejszych ziem, przekazując je królowi Eumenesowi.
###### **1Mch 8,9**
 Mieszkańcy Hellady postanowili wyruszyć, aby ich wytępić,
###### **1Mch 8,10**
 ale kiedy tamci dowiedzieli się o tym, wysłali przeciwko nim tylko jednego dowódcę. Walczył on z nimi i padło spośród nich wielu zabitych. Rzymianie wzięli do niewoli ich żony i dzieci, ograbili ich, zajęli ziemię i zniszczyli ich twierdze. Podporządkowali ich sobie aż do dnia dzisiejszego.
###### **1Mch 8,11**
 Pozostałe królestwa i wyspy, jeśli tylko próbowały się im przeciwstawić, niszczyli i ujarzmiali. Ze swoimi przyjaciółmi natomiast i z tymi, którzy im zaufali, zachowywali przyjaźń.
###### **1Mch 8,12**
 Opanowali królestwa leżące blisko i daleko. Na dźwięk ich imienia wszystkich przejmowała trwoga.
###### **1Mch 8,13**
 Komu chcieli pomóc w zdobyciu władzy królewskiej, ten stawał się królem. Tych zaś, których chcieli usunąć, usuwali. W taki sposób stali się bardzo potężni.
###### **1Mch 8,14**
 Pomimo tego wszystkiego żaden z nich nie wywyższał się, nakładając sobie koronę czy ubierając się w purpurę.
###### **1Mch 8,15**
 Ustanowili sobie senat złożony z trzystu dwudziestu senatorów, którzy codziennie obradowali o wszystkim, co dotyczyło ogółu, dla zapewnienia porządku.
###### **1Mch 8,16**
 Każdego roku jednemu człowiekowi powierzają z zaufaniem władzę nad sobą i nad całym swym krajem. Temu jednemu wszyscy są posłuszni. Nie ma wśród nich zazdrości ani zawiści.
###### **1Mch 8,17**
 Juda wybrał Eupolemosa, syna Jana, syna Akkosa, oraz Jazona, syna Eleazara, i posłał ich, aby zawarli przyjaźń i sojusz z Rzymianami,
###### **1Mch 8,18**
 aby oni zdjęli z Izraela jarzmo, ponieważ wiadomo było, że królestwo Hellenów usiłuje trzymać go w niewoli.
###### **1Mch 8,19**
 Udali się więc w bardzo daleką drogę do Rzymu. Weszli do senatu i zabrali głos, mówiąc:
###### **1Mch 8,20**
 „Juda Machabeusz, jego bracia i ogół Żydów przysłali nas, aby zawrzeć z wami sojusz i pokój, abyście zaliczyli nas do waszych sojuszników i przyjaciół”.
###### **1Mch 8,21**
 Przemówienie to spodobało się im.
###### **1Mch 8,22**
 A oto odpis listu, który wyryli na tablicach z brązu i posłali do Jerozolimy, aby przypominał im o pokoju i sojuszu:
###### **1Mch 8,23**
 „Niech Rzymianom i narodowi żydowskiemu na wieki powodzi się na morzu i na lądzie! Niech miecz i nieprzyjaciel będą od nich daleko!
###### **1Mch 8,24**
 Gdyby najpierw wszczęto wojnę przeciwko Rzymowi albo przeciwko któremuś z jego sojuszników na całym obszarze ich panowania,
###### **1Mch 8,25**
 wtedy naród żydowski całym sercem przyłączy się do walki, zgodnie z potrzebą chwili.
###### **1Mch 8,26**
 Według woli Rzymu nie będą dostarczać jego przeciwnikom żywności, broni, pieniędzy ani okrętów. Będą przestrzegać swoich zobowiązań, nie żądając niczego w zamian.
###### **1Mch 8,27**
 Podobnie też, jeśli najpierw wszczęta zostanie wojna przeciwko narodowi żydowskiemu, Rzymianie ochoczo przyłączą się do walki, zgodnie z potrzebą chwili.
###### **1Mch 8,28**
 Według woli Rzymu nie będą dostarczać wrogom żywności, broni, pieniędzy ani okrętów. Będą przestrzegać tych zobowiązań bez podstępu.
###### **1Mch 8,29**
 Takie są warunki sojuszu, który Rzymianie zawarli z narodem żydowskim.
###### **1Mch 8,30**
 Jeśli zaś obie strony chciałyby dodać lub ująć coś z tej umowy, mogą to zrobić według swojej woli. Cokolwiek dodadzą albo usuną, będzie zobowiązujące.
###### **1Mch 8,31**
 W sprawie niegodziwości popełnionych przez króla Demetriusza napisaliśmy do niego: «Dlaczego nałożyłeś tak ciężkie jarzmo na Żydów, naszych przyjaciół i sojuszników?
###### **1Mch 8,32**
 Jeśli jeszcze raz poskarżą się na ciebie, będziemy bronili ich praw, walcząc z tobą na morzu i na lądzie»”.
# 1Mch 8 BP
###### **1Mch 8,1**
 Do Judy doszły wieści o sławie Rzymian, mianowicie że stanowią wielką potęgę i życzliwi są tym wszystkim, którzy wchodzą z nimi w przymierze, a ogromna siła pozwala im nawet zawierać przyjaźń z tymi, którzy o nią proszą.
###### **1Mch 8,2**
 Opowiadano mu również o znakomitych czynach wojennych, jakich dokonali [walcząc] z Galatami, których ujarzmili i zmusili do płacenia daniny,
###### **1Mch 8,3**
 a także o wszystkim, czego dokonali w Hiszpanii, aby zawładnąć tamtejszymi kopalniami srebra i złota,
###### **1Mch 8,4**
 jak dzięki mądrości i wytrwałości opanowali nawet najbardziej odległe ziemie, jak pokonali i zadali ogromną klęskę królom, którzy nadciągnęli przeciw nim z krańców świata, jak wreszcie pozostałych zmusili do corocznego płacenia daniny.
###### **1Mch 8,5**
 Zwyciężyli też w wojnie i podporządkowali sobie Filipa i Perseusza, królów kittyjskich, wraz z tymi, którzy przeciwko nim [Rzymianom] powstali.
###### **1Mch 8,6**
 Pokonali także Antiocha Wielkiego, króla Azji, który wyruszył przeciwko nim na wojnę mając sto dwadzieścia słoni, jazdę, wozy bojowe i potężne wojsko.
###### **1Mch 8,7**
 Pojmali go żywego i kazali jemu i jego następcom składać wielkie daniny oraz dostarczyć zakładników. Wymusili też zgodę na odstąpienie części jego królestwa:
###### **1Mch 8,8**
 a więc Indii, Medii i Lyddy - najpiękniejszych krain - po czym ofiarowali je królowi Eumenesowi.
###### **1Mch 8,9**
 [Słyszał też], że mieszkańcy Hellady postanowili wyruszyć przeciw nim, by ich zniszczyć.
###### **1Mch 8,10**
 Oni zaś [Rzymianie] dowiedziawszy się o tym wysłali przeciwko nim jednego wodza i walczyli z nimi tak, że poległo wielu z nich. Żony ich i dzieci uprowadzili w niewolę, dobra zrabowali, ziemie zajęli, twierdze zburzyli; i aż po dzień dzisiejszy żyją oni w niewoli.
###### **1Mch 8,11**
 Wszystkie inne królestwa i wyspy, które próbowały stawiać im opór, zniszczyli i podbili w niewolę; z przyjaciółmi zaś i z tymi, którzy im zaufali, utrzymują przyjazne stosunki.
###### **1Mch 8,12**
 W ten sposób rozszerzyli swe panowanie zarówno na bliskie, jak i na dalekie królestwa. Na samo wspomnienie ich imienia ogarnia wszystkich strach.
###### **1Mch 8,13**
 Ci, którym chcą pomóc i pozostawić ich przy władzy - panują, niewygodnych usuwają, do tak wielkiej bowiem doszli potęgi.
###### **1Mch 8,14**
 Mimo wszystko żaden z nich nie wkłada diademu i nie okrywa się purpurą, aby się w niej pysznić.
###### **1Mch 8,15**
 Stworzyli sobie radę, której trzystu dwudziestu członków zbiera się codziennie, aby obradować nad wszystkim, co leży w interesie ludu.
###### **1Mch 8,16**
 Corocznie władzę nad sobą i panowanie nad całym krajem powierzają jednemu człowiekowi. Temu jednemu wszyscy są posłuszni, nie ma między nimi zawiści ani niechęci.
###### **1Mch 8,17**
 Wybrał więc Juda Eupolemosa, syna Jana, którego ojcem był Akkos, oraz Jazona, syna Eleazara, aby ich wysłać do Rzymu. Celem było zawarcie przyjaźni i przymierza,
###### **1Mch 8,18**
 aby [Rzymianie] zdjęli z nich jarzmo. Widać było, że królestwo helleńskie chce narzucić Izraelowi całkowitą niewolę.
###### **1Mch 8,19**
 Wyruszyli więc w bardzo daleką podróż do Rzymu. Wszedłszy do senatu przemówili w te słowa:
###### **1Mch 8,20**
 "Juda, zwany Machabeuszem, jego bracia i cały lud żydowski przysłali nas tutaj, aby zawrzeć z wami przymierze i pokój. [Pragniemy], abyście nas zaliczyli między waszych sprzymierzeńców i przyjaciół".
###### **1Mch 8,21**
 Słowa te spodobały się im [Rzymianom].
###### **1Mch 8,22**
 Oto jest odpis listu, który został wyryty na spiżowych tablicach i wysłany do Jerozolimy, aby był tam świadectwem zawarcia pokoju i sojuszu:
###### **1Mch 8,23**
 "Niech pomyślność towarzyszy na wieki Rzymianom i ludowi izraelskiemu na lądzie i na morzu. Niech omija ich miecz nieprzyjacielski.
###### **1Mch 8,24**
 Gdyby jednak Rzymowi najpierw lub któremuś z jego sprzymierzeńców na całym obszarze podległym ich władzy groziła wojna,
###### **1Mch 8,25**
 wówczas naród żydowski całym sercem stanie u ich boku do walki, jak tego będą wymagały od niego okoliczności.
###### **1Mch 8,26**
 Zgodnie z wolą Rzymu nie da ani nie dostarczy walczącym wrogom zboża, broni, pieniędzy ani okrętów. Zobowiązań swych dochowają zupełnie bezinteresownie.
###### **1Mch 8,27**
 Podobnie i Rzymianie będą z ochotą wspólnie z nimi walczyć - jak tego wymagać będą okoliczności - jeżeli naród żydowski pierwszy zmuszony będzie prowadzić wojnę.
###### **1Mch 8,28**
 Przeciwnicy - zgodnie z przyrzeczeniem Rzymu - nie otrzymają zboża, broni, pieniędzy ani okrętów. Warunków tych przestrzegać będą [Rzymianie] bez żadnego podstępu.
###### **1Mch 8,29**
 Na mocy tych oto postanowień zawierają Rzymianie układ z ludem żydowskim.
###### **1Mch 8,30**
 Gdyby zaś do tych postanowień jedna ze stron chciała jeszcze coś dodać lub usunąć, może to uczynić według swej woli; zarówno dodatki jak i skreślenia będą ważne.
###### **1Mch 8,31**
 Co do krzywd wyrządzonych im przez króla Demetriusza napisaliśmy [my Rzymianie] do niego, co następuje: "Dlaczego na Żydów, naszych przyjaciół i sprzymierzeńców, nałożyłeś tak ciężkie jarzmo?
###### **1Mch 8,32**
 Jeżeli jeszcze raz złożą na ciebie skargę, staniemy w obronie ich praw i wydamy ci wojnę na lądzie i na morzu"".
# 1Mch 8 BR
###### **1Mch 8,1**
 Potem dotarła do Judy sława, jaką cieszyli się Rzymianie: że byli doświadczeni w prowadzeniu wojen, że byli bardzo życzliwi dla tych, którzy stawali po ich stronie, i chętni do zawierania przyjaźni z tymi, którzy ich o to prosili, a nade wszystko, że byli bardzo dzielnymi wojownikami.
###### **1Mch 8,2**
 Opowiadano mu również o ich wyprawach wojennych przeciwko Galatom, których podbili i zmusili do płacenia daniny,
###### **1Mch 8,3**
 a także o tym, czego dokonali w Hiszpanii: jak zawładnęli tamtejszymi kopalniami srebra i złota
###### **1Mch 8,4**
 i dzięki swojej mądrości i wytrwałości wzięli w posiadanie cały kraj, mimo że znajdował się tak daleko od nich. Królów zaś, którzy z krańców świata przeciwko nim wyruszali, oni pokonywali, zadając wszystkim dotkliwe straty. Inni musieli im płacić roczne daniny.
###### **1Mch 8,5**
 Filipa i Perseusza, królów Kittim, a także wszystkich innych, którzy przeciwko nim występowali, zwyciężyli w walce i poddali pod swoją władzę.
###### **1Mch 8,6**
 Kiedy Antioch Wielki, król Azji ze stu dwudziestu słoniami bojowymi, konnicą i rydwanami oraz mnóstwem pieszych wojowników wyruszył przeciwko nim na wojnę, doznał straszliwej klęski.
###### **1Mch 8,7**
 Jego samego pochwycili żywcem i na niego oraz na jego następców nałożyli wysoką daninę. Poza tym musiał on przekazać im pewną liczbę zakładników i odstąpić część swojego państwa.
###### **1Mch 8,8**
 Tak więc zabrali mu wówczas prowincję Indii, Medię, Lidię, czyli najbogatsze obszary jego królestwa, które przekazali zresztą królowi Eumenesowi.
###### **1Mch 8,9**
 Po jakimś czasie mieszkańcy Hellady postanowili wyruszyć na wojnę przeciwko Rzymianom, żeby ich zniszczyć.
###### **1Mch 8,10**
 Wtedy Rzymianie, dowiedziawszy się o tych zamiarach, wysłali przeciwko nim tylko jednego dowódcę wojskowego, aby poprowadził z nimi wojnę. Wielu Greków odniosło w tej wojnie rany, wielu też poległo. Rzymianie uprowadzili ich kobiety i dzieci do niewoli, a całe ich mienie zagrabili. Zrównali też z ziemią ich twierdze, a cały kraj poddali pod swoje panowanie. I tak jest aż do dnia dzisiejszego.
###### **1Mch 8,11**
 Wszystkie inne królestwa oraz wyspy, które przeciwko nim występowały, zwyciężali i poddawali pod swoją władzę.
###### **1Mch 8,12**
 Natomiast ze swoimi przyjaciółmi oraz z tymi, którzy im ufali, trwali w serdecznej przyjaźni. Władcy zarówno krajów pobliskich, jak i dalekich znaleźli się pod ich panowaniem i wszyscy drżeli ze strachu na samo ich imię.
###### **1Mch 8,13**
 Komu chcą pomóc w dojściu do władzy, ten niebawem zostaje królem, kogo zaś chcą utrącić, ten rychło musi odejść. W ten sposób rosła coraz bardziej ich potęga.
###### **1Mch 8,14**
 Mimo to żaden z nich nie wkłada sobie korony na głowę i nie przyodziewa się w purpurę po to tylko, żeby wywyższać się ponad innych.
###### **1Mch 8,15**
 Uznali za słuszne raczej ustanowić sobie radę, składającą się z trzystu dwudziestu mężów, którzy codziennie radzą nad tym, jak najlepiej rządzić całym ludem.
###### **1Mch 8,16**
 Jednemu spośród siebie z całym zaufaniem powierzają na jeden rok siebie samych i władzę nad całym krajem. Wszyscy słuchają tego jednego i nie ma między nimi żadnych zawiści ani zazdrości.
###### **1Mch 8,17**
 Wybrał Juda Eupolemosa, syna Jana, syna Akkosa, oraz Jazona, syna Eleazara, i posłał ich do Rzymu, żeby prosili jego mieszkańców o zawarcie z nimi układu pokojowego.
###### **1Mch 8,18**
 W ten sposób uwolnić całą Judeę od jarzma [greckiego]. Rzymianie sami bowiem widzieli już, jak królowie greccy usiłują trzymać w niewoli naród izraelski.
###### **1Mch 8,19**
 Odbywszy tedy bardzo długą podróż wysłannicy owi przybyli do Rzymu, stanęli przed senatem i powiedzieli:
###### **1Mch 8,20**
 Zostaliśmy przysłani do was przez Judę zwanego Machabeuszem, przez jego braci i cały naród żydowski. Chcemy zawrzeć z wami przymierze pokoju. Zależy nam na tym, byście uważali nas za swoich sprzymierzeńców i przyjaciół.
###### **1Mch 8,21**
 Senatowi spodobały się te słowa.
###### **1Mch 8,22**
 A oto odpis listu, który [Rzymianie] przesłali na tablicach brązowych do Jerozolimy, żeby pamięć o zawarciu przymierza pokoju była zawsze żywa:
###### **1Mch 8,23**
 Rzymianom i narodowi żydowskiemu zawsze niech wiedzie się dobrze na morzu i na lądzie. Miecz wrogów niech zawsze będzie od nich jak najdalej.
###### **1Mch 8,24**
 Gdyby Rzymowi albo któremuś z jego sprzymierzeńców na ziemiach mu podległych zagrażała wojna,
###### **1Mch 8,25**
 to naród żydowski, w miarę potrzeby, będzie gotów natychmiast stanąć do walki i udzielić pomocy.
###### **1Mch 8,26**
 Napastnikom nie będzie dostarczać żywności, broni, pieniędzy i okrętów, skoro tylko Rzym tego zażąda. Zobowiązania te Żydzi będą wypełniali bez żadnego wynagrodzenia.
###### **1Mch 8,27**
 Gdyby zaś narodowi żydowskiemu zagrażała jakaś wojna, wtedy Rzymianie, według potrzeby, przystąpią do walki [i będą wspomagać Żydów].
###### **1Mch 8,28**
 Sprzymierzeńcom napastników - o ile Rzym uzna to za słuszne - również nie będzie się dostarczać ani żywności, ani broni, ani pieniędzy, ani okrętów. Wszystkie te zobowiązania będą wypełnione bez jakiegokolwiek podstępu.
###### **1Mch 8,29**
 Taka jest treść układu zawartego przez Rzymian z narodem żydowskim.
###### **1Mch 8,30**
 Obie strony, gdyby uznały za słuszne do tego układu coś dodać lub coś z niego skreślić, mogą to uczynić według własnego uznania. Uzupełnienia albo skreślenia będą uznane za ważne.
###### **1Mch 8,31**
 Natomiast do króla Demetriusza o bezprawiu, jakiego dopuszczał się wobec Żydów [my, Rzymianie] napisaliśmy tak: Dlaczego tak ciężkie brzemię nałożyłeś na Żydów, naszych przyjaciół i sprzymierzeńców?
###### **1Mch 8,32**
 Jeżeli raz jeszcze będą się na ciebie uskarżać, pośpieszymy im z pomocą i broniąc ich praw, będziemy walczyć z tobą na morzu i na lądzie.
# 1Mch 8 WUJ
