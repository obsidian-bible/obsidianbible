# Ab 1 BT5
###### **Ab 1,1**
 Widzenie Abdiasza. Tak mówi Pan Bóg do Edomu. Wieść niezawodną usłyszeliśmy od Pana, a zwiastuna wysłano do narodów: Powstańcie! Stańcie przeciw niemu do bitwy!
###### **Ab 1,2**
 «***Oto pomniejszyłem cię wśród narodów, bardzo jesteś wzgardzony.
###### **Ab 1,3**
 A pycha twego serca zwiodła ciebie, który mieszkasz w rozpadlinach skalnych, który na wysokościach założyłeś swoją siedzibę, który mówisz w swym sercu: Któż mnie strąci na ziemię?
###### **Ab 1,4**
 Choćbyś wzniósł się jak orzeł i choćbyś nawet między gwiazdami założył swoje gniazdo, stamtąd Ja strącę ciebie – wyrocznia Pana***».
###### **Ab 1,5**
 «***Jeśli wtargną do ciebie złodzieje albo rabusie nocni, jakże zachowasz spokój! Czy nie okradną cię doszczętnie? Jeśli przyjdą do ciebie zbieracze winogron, to czy zostawią cokolwiek?
###### **Ab 1,6**
  Jakże przeszukali Ezawa, splądrowali jego schowki!
###### **Ab 1,7**
 Przepędzili cię aż do granicy. Wszyscy twoi sprzymierzeńcy cię zwiedli. Oszukali cię twoi przyjaciele. Twoi stołownicy zastawili na ciebie sieć. Brak w tym rozsądku***».
###### **Ab 1,8**
 «***Czyż nie stanie się w owym dniu – wyrocznia Pana – że wytracę mądrych z Edomu i rozsądek z góry Ezawa?
###### **Ab 1,9**
 I zadrżą, Temanie, twoi mocarze, bo w czasie rzezi zginą wszyscy z góry Ezawa. Z powodu zbrodni,
###### **Ab 1,10**
 z powodu gwałtu wobec brata twego, Jakuba, okryje cię hańba, zostaniesz zniszczony na wieki.
###### **Ab 1,11**
 W dniu, w którym stanąłeś przeciwko niemu, w dniu, w którym obcy brali w niewolę jego wojsko, a cudzoziemcy wkroczyli w jego bramy i rzucali los o Jeruzalem, również ty byłeś jakby jednym z nich.
###### **Ab 1,12**
 Przestań się cieszyć widokiem brata twego w dniu jego nieszczęścia! Przestań się śmiać z synów Judy w dniu ich zagłady! Przestań wygłaszać mowy w dniu ucisku!
###### **Ab 1,13**
 Przestań wchodzić w bramy ludu mego w dniu jego klęski! Przestań się cieszyć, zwłaszcza ty, widokiem jego nieszczęścia w dniu jego klęski! I nie wyciągaj ręki po jego bogactwa w dniu jego klęski!
###### **Ab 1,14**
 Przestań stawać na rozdrożu, by zabijać jego uciekinierów! I nie wydawaj jego ocalonych w dniu ucisku!***»
###### **Ab 1,15**
 «***Albowiem nadchodzi dzień Pański na wszystkie narody. Tak jak ty uczyniłeś, uczynią tobie: Czyny twoje spadną na twoją głowę***».
###### **Ab 1,16**
 «***Albowiem jak wy piliście na mojej świętej górze, tak wszystkie narody pić będą nieustannie; będą pić na umór i staną się, jakby ich nie było.
###### **Ab 1,17**
 Lecz schronienie będzie na górze Syjon i będzie ona święta, a dom Jakuba posiądzie swoje dziedzictwo.
###### **Ab 1,18**
 Dom Jakuba będzie ogniem, dom Józefa – płomieniem, a dom Ezawa – słomą; zapalą i pochłoną go i nic nie pozostanie z domu Ezawa, tak bowiem postanowił Pan***».
###### **Ab 1,19**
 «***I posiądą Negeb, to jest górę Ezawa, oraz Szefelę, to jest kraj Filistynów. I posiądą ziemię Efraima, to jest ziemię Samarii, a Beniamin [posiądzie] Gilead.
###### **Ab 1,20**
 Wygnańcy zaś z Chalach, synowie Izra-ela, odziedziczą ziemię Kanaan aż do Sarepty, a wygnańcy z Jerozolimy, którzy przebywają w Sefarad, posiądą miasta Negebu.
###### **Ab 1,21**
 I pójdą zwycięzcy na górę Syjon, aby sądzić górę Ezawa. I do Pana będzie należeć królowanie!***»
# Ab 1 PAU
###### **Ab 1,1**
 Widzenie Abdiasza. Usłyszałem wieść od Pana, posłaniec został posłany do narodów. Tak powiedział Pan Bóg w sprawie Edomu: „Powstańcie! Wyruszmy na wojnę przeciw niemu!”.
###### **Ab 1,2**
 Oto uczyniłem cię małym wśród narodów i bardzo wzgardzonym.
###### **Ab 1,3**
 Zwiodła cię pycha twojego serca: uczyniłeś sobie mieszkanie w załomach skalnych, założyłeś swoją siedzibę na wysokości, i mówisz sobie: „Kto mnie strąci na ziemię?”.
###### **Ab 1,4**
 Choć wzbiłbyś się jak orzeł i założył swoje gniazdo wśród gwiazd, strącę cię stamtąd - wyrocznia PANA.
###### **Ab 1,5**
 Kiedy nocą przyjdą do ciebie złodzieje i rabusie, jakże bardzo zostaniesz ograbiony! Czyż nie zabiorą wszystkiego, co zechcą? I kiedy zrywający winogrona przyjdą do ciebie, czy pozostawią nawet jedno grono?
###### **Ab 1,6**
 Jakże dokładnie przeszukają Ezawa i przetrząsną jego tajemne skarbce!
###### **Ab 1,7**
 Aż do granicy ścigać cię będą. Wszyscy twoi sprzymierzeńcy cię zdradzą, a twoi przyjaciele cię oszukają. Ci, którzy twój chleb jedzą, zastawią sidła na ciebie. Brak mu roztropności!
###### **Ab 1,8**
 W owym dniu wygubię mędrców z Edomu i uczonych z góry Ezawa - wyrocznia PANA.
###### **Ab 1,9**
 Przerażą się twoi wojownicy, Temanie, i wycięci zostaną mieszkańcy góry Ezawa z powodu zbrodni narodów.
###### **Ab 1,10**
 Z powodu przemocy wobec brata twojego, Jakuba, okryjesz się hańbą i przepadniesz na wieki.
###### **Ab 1,11**
 Bo byłeś obecny, gdy wrogowie kradli jego bogactwa, a cudzoziemcy wkraczali w jego bramy i o Jerozolimę rzucali losy. Także ty brałeś w tym udział.
###### **Ab 1,12**
 Nie ciesz się, widząc brata w dniu jego nieszczęścia i nie wyśmiewaj się z Judejczyków w dniu ich zagłady! Nie mów zuchwale w dniu ich niedoli!
###### **Ab 1,13**
 Nie przekraczaj bramy mojego ludu w dzień jego klęski! Nie ciesz się widokiem jego nieszczęścia! W dzień jego klęski nie wyciągaj rąk po jego bogactwa!
###### **Ab 1,14**
 Nie stawaj na skrzyżowaniach dróg, aby zabijać jego uchodźców ani nie wydawaj ocalałych w dniu niedoli!
###### **Ab 1,15**
 Bo zbliża się Dzień PANA przeciwko wszystkim narodom. Jak ty postępowałeś, tak postąpią z tobą: za swoje czyny otrzymasz odpłatę.
###### **Ab 1,16**
 Jak wy piliście na mojej świętej górze, tak pić będą wszystkie narody bez końca: pić będą bez wytchnienia i znikną, jak gdyby ich nigdy nie było.
###### **Ab 1,17**
 Lecz na górze Syjon, która jest święta, będzie ocalenie. Dom Jakuba zawładnie dziedzictwem tych, którzy go wydziedziczyli.
###### **Ab 1,18**
 Dom Jakuba będzie jak ogień, a dom Józefa - jak płomień, dom zaś Ezawa - jak słoma: spalą ją i zniszczą. Nikt się nie uratuje z domu Ezawa, ponieważ PAN tak powiedział.
###### **Ab 1,19**
 Mieszkańcy Negebu zajmą górę Ezawa, mieszkańcy Szefeli - kraj Filistynów, i posiądą ziemie Efraima i ziemie Samarii, a Beniamin zajmie Gilead.
###### **Ab 1,20**
 Wygnańcy izraelscy, jak wojsko, wezmą w posiadanie Kanaan aż do Sarepty, wygnańcy zaś z Jerozolimy, którzy przebywają w Sefara, posiądą miasta Negebu.
###### **Ab 1,21**
 I wkroczą ocaleni na górę Syjon, aby panować nad górą Ezawa. I tak nastanie królestwo PANA!
# Ab 1 BP
###### **Ab 1,1**
 Widzenie Abdiasza. Usłyszałem wieść od Jahwe, a między narody wyprawiono posłańca: "Powstańcie, podnieśmy się do walki przeciw niemu;" 1a Tak mówi Jahwe-Pan do Edomu: -
###### **Ab 1,2**
 Oto uczynię cię małym wśród narodów i będziesz w największej pogardzie!
###### **Ab 1,3**
 Zwodzi cię pycha twego serca: mieszkasz w grotach skalnych, na wysokościach wznosisz swe mieszkanie i mówisz sobie: "Któż zdoła mnie ściągnąć na ziemię?"
###### **Ab 1,4**
 Choćbyś się wzniósł wysoko jak orzeł i między gwiazdami założył swe gniazdo, strącę cię stamtąd - mówi Pan.
###### **Ab 1,5**
 Jeśli w nocy wkradną się do ciebie złodzieje lub zbóje, czyż nie ukradną tyle, ile im trzeba? Jeśli napadną na ciebie ludzie z winnicy, czyż nie zostawią choćby reszty winnych gron? 5c Jakże wielkie zniszczenie cię czeka!
###### **Ab 1,6**
 Jak przeszukają Ezawa, jak przetrząsną kryjówki jego [kraju]!
###### **Ab 1,7**
 Aż do granicy cię odpędzą wszyscy twoi sprzymierzeńcy; zdradzą cię i zawładną tobą twoi przyjaciele; ci, co jedli z tobą, zastawią na ciebie sidła. (Brak mu rozwagi).
###### **Ab 1,8**
 Zaprawdę, w owym dniu - mówi Jahwe - sprawię, że znikną mędrcy z Edomu i rozsądek z gór Ezawa.
###### **Ab 1,9**
 Twoi bohaterzy, Temanie, tak się przelękną, że w górach Ezawa wszyscy zostaną wycięci w pień.
###### **Ab 1,10**
 Za morderstwa, za krzywdy, wyrządzone twemu bratu Jakubowi, okryje cię hańba i zostaniesz zgładzony na zawsze.
###### **Ab 1,11**
 W dniu, w którym byłeś przy tym, gdy obcy prowadzili jego wojsko do niewoli, a barbarzyńcy wdarli się do jego bram i o Jeruzalem rzucali los - ty byłeś także jakby jednym z nich.
###### **Ab 1,12**
 Nie spoglądaj szyderczo na brata swego w dniu jego niedoli! Nie tryumfuj nad synami Judy w dniu ich zagłady! Nie mów słów zuchwałych w dniu utrapienia!
###### **Ab 1,13**
 Nie wkraczaj w bramy mego ludu w dniu jego klęski! Nie patrzże i ty z uciechą na jego nieszczęście w dniu jego klęski! Nie wyciągaj ręki po jego mienie w dniu jego klęski!
###### **Ab 1,14**
 Nie stawaj na rozstajach dróg, żeby zabijać jego zbiegów! Nie wydawaj tych, którzy umknęli w dniu utrapienia!
###### **Ab 1,15**
 Bo bliski jest dzień Jahwe dla wszystkich narodów. Jak postąpiłeś ty, tak stanie się i tobie, postępki twoje spadną na twą własną głowę.
###### **Ab 1,16**
 Jak piliście na mojej górze świętej, tak będą piły wszystkie narody dokoła; napiją się i będą się słaniały, i znikną, jak gdyby ich nigdy nie było.
###### **Ab 1,17**
 Ale na górze Syjon będzie ocalenie - wszak ona jest miejscem świętym - i Dom Jakuba odzyska swe dziedzictwo.
###### **Ab 1,18**
 Dom Jakuba będzie wtedy ogniem, Dom Józefa - płomieniem, lecz Dom Ezawa - słomą. Podpalą go i zniszczą! Nikt się nie ocali z Domu Ezawa, bo Jahwe tak powiedział.
###### **Ab 1,19**
 Zajmą wtedy krainę południową - góry Ezawa, i kraj nizinny - Filisteę, zajmą obszary Efraima i obszary Samarii, ziemie Beniamina i Gilead.
###### **Ab 1,20**
 Izraelici, którzy są na wygnaniu w Chalach, zajmą Kanaan aż po Sareptę, a wygnańcy z Jerozolimy przebywający w Sefarad zajmą miasta południowe.
###### **Ab 1,21**
 Wybawieni wstąpią wtedy na górę Syjon, by sprawować sąd nad górską krainą Ezawa. Królowanie zaś należeć będzie do Jahwe.
# Ab 1 BR
###### **Ab 1,1**
 (a) Widzenie Abdiasza (b) Kiedy do narodów został posłany mąż wołający: Wszyscy na wojnę z Edomem!, wtedy taką wieść usłyszeliśmy od Pana: Oto, co mówi Bóg i Pan do Edomu:
###### **Ab 1,2**
 Popatrz, uczyniłem cię najmniejszym wśród narodów i wszyscy będą tobą pomiatać.
###### **Ab 1,3**
 Lecz sprowadziła cię na manowce twa niemądra pycha. I musisz mieszkać teraz w rozpadlinach skalnych, gniazda sobie zakładasz na wysokich górach i pytasz dumnie: A któż mnie stąd strącić zdoła?
###### **Ab 1,4**
 Ale choćbyś się wzbił wysoko jak orzeł i pomiędzy gwiazdami gniazdko sobie uwił, to Ja też strącę cię stamtąd - wyrocznia Pana.
###### **Ab 1,5**
 Gdy nocą napadną cię złodzieje lub bandyci, to czeka cię niechybna zguba. Czy nie ograbią cię, z czego tylko zechcą? A gdy robotnicy czasu winnicy pojawią się u ciebie, to czy zostawią cokolwiek na winnych krzewach?
###### **Ab 1,6**
 Jakże dokładnie przeszukują Ezawa, jak przetrząsać będą wszystkie jego kryjówki?
###### **Ab 1,7**
 I popędzą cię aż do granicy wszyscy twoi sprzymierzeńcy; okrutnie cię zdradzą, oszukają wszyscy przyjaciele twoi. Kiedyś żywili się twoim chlebem, teraz po kryjomu sidła na cię stawiają.
###### **Ab 1,8**
 Zaprawdę, w dniu owym - wyrocznia Pana - wygubię wszystkich mędrców w Edomie i wszystkich uczonych z gór Ezawa.
###### **Ab 1,9**
 A twoich bohaterów, Temanie, przerażenie napełni, bo będą zgładzeni wszyscy mieszkańcy gór Ezawa z powodu swych zbrodni.
###### **Ab 1,10**
 A z powodu zbrodni na twym bracie Jakubie i ty również okryjesz się hańbą, i będziesz zgubiony na zawsze.
###### **Ab 1,11**
 Gdy wrogowie do niewoli jego wojska brali, gdy zaczęli zajmować bramy do miast jego, o samą zaś Jerozolimę rzucili losy - ty patrzyłeś na to obojętnie i byłeś jakby jednym spośród nich.
###### **Ab 1,12**
 Nie ciesz się w ukryciu, gdy przyjdzie dzień twego brata i kiedy spadnie na niego nieszczęście! Nie wyśmiewaj się także z biednych synów Judy, gdy przyjdzie na nich dzień zguby. Nie otwieraj twoich ust tak szeroko, gdy dzień ucisku nadejdzie.
###### **Ab 1,13**
 Nie wciskaj się do bramy mego ludu, gdy przyjdzie nań dzień jego klęski! Nie ciesz się ukradkiem z nieszczęścia jego! Nie wyciągaj ręki po jego dobra, gdy przyjdzie nań dzień jego klęski.
###### **Ab 1,14**
 Nie zaczajaj się na dróg skrzyżowaniach, aby napadać na uciekających. Zbiegłych nie wydawaj w ręce wroga, gdy przyjdzie dzień ucisku.
###### **Ab 1,15**
 Bliski jest bowiem dzień Pański dla narodów wszystkich i tobie uczynią to samo, co ty innym czyniłeś, do ciebie wrócą twoje własne czyny.
###### **Ab 1,16**
 Jak wyście kiedyś pili na mojej świętej górze, tak muszą teraz pić ciągle pozostałe narody. Pić będą i sączyć do ostatniej kropli i tak żyć będą, jakby ich wcale nie było.
###### **Ab 1,17**
 Lecz ocalenie pojawi się na górze Syjon i święta będzie owa góra, dom zaś Jakuba zawładnie tymi, którzy go kiedyś zdobyli.
###### **Ab 1,18**
 Wtedy stanie się dom Jakuba ogniem, a dom Józefa będzie jednym płomieniem. Dom zaś Ezawa będzie słomą, którą ogień ogarnie i strawi doszczętnie. I nikt nie ocaleje z domu Ezawa, bo tak Pan powiedział.
###### **Ab 1,19**
 Wezmą w posiadanie Negeb i góry Ezawa oraz Szefelę i kraj Filistynów. Zawładną ziemią Efraima, wejdą do Samarii, do Beniamina części i do Gileadu.
###### **Ab 1,20**
 A wygnańcy z Chalaoch, synowie Izraela, zajmą kraj Kanaanitów aż po samą Sareptę. Wypędzeni zaś z Jerozolimy, w Sefaradzie żyjący, zajmą wszystkie miejscowości Negebu.
###### **Ab 1,21**
 I ciągnąć będą oswobodzeni na sam szczyt góry Syjon, by rozpocząć sąd nad górą Ezawa. A Pan jako władca obejmie swe rządy!
# Ab 1 WUJ
###### **Ab 1,1**
 Widzenie Abdiaszowe. To mówi Pan Bóg do Edom: Słuch słyszeliśmy od Pana, i posła do narodów posłał: Wstańcie, a powstańmy nań ku bitwie.
###### **Ab 1,2**
 Oto maluczkim dałem cię między narody: wzgardzonyś ty jest barzo.
###### **Ab 1,3**
 Pycha serca twego wyniosła cię, mieszkającego w rozpadlinach skał, podwyższającego stolicę twoję: który mówisz w sercu swojem: kto mię ściągnie na ziemię?
###### **Ab 1,4**
 Choćbyś się wywyższył jako orzeł, i choćbyś między gwiazdami położył gniazdo twoje, ztamtąd zaciągnę cię, mówi Pan.
###### **Ab 1,5**
 Gdyby złodzieje weszli do ciebie, gdyby zbójcę w nocy, jakobyś zamilczał? azaby nie nakradli sobie dosyć? gdyby winiarze weszli do ciebie, azaby przynajmniej grona nie zostawili tobie?
###### **Ab 1,6**
 Jako wyszperowali Esau, wyśladowali tajemne miejsca jego?
###### **Ab 1,7**
 Aż do granice wypuścili cię: wszyscy mężowie przymierza twego naśmiali się z ciebie, przemogli przeciw tobie mężowie pokoju twego: którzy jadają z tobą, zastawią zasadzki pod tobą: niemasz rozumu w nim.
###### **Ab 1,8**
 Izali nie onego dnia, mówi Pan, wytracę mędrce z Idumei, i roztropność z góry Esau?
###### **Ab 1,9**
 I będą się bać mężni twoi od południa, aby zginął mąż z góry Esau.
###### **Ab 1,10**
 Dla zabicia, i dla nieprawości przeciw bratu twemu Jakóbowi, okryje cię wstyd, i zginiesz na wieki.
###### **Ab 1,11**
 W dzień, kiedyś stał przeciw niemu, gdy imali cudzy wojsko jego, a obcy wchodzili bramami jego, a o Jeruzalem miotali los: ty też byłeś jako jeden z nich.
###### **Ab 1,12**
 A nie wzgardzisz w dzień brata twego, w dzień pielgrzymowania jego: i nie będziesz się weselił nad syny Judzkimi w dzień zatracenia ich: i nie będziesz wielmożył ust twoich w dzień ucisku.
###### **Ab 1,13**
 Ani wnidziesz w bramę ludu mego, w dzień upadku ich: ani z góry patrzyć będziesz i ty na złe ich, w dzień pustoszenia ich: i nie puszczą cię na wojsko jego w dzień pustoszenia jego.
###### **Ab 1,14**
 Ani będziesz stał na rozstaniach, abyś zabijał tych co uciekali, ani zawrzesz pozostałych jego w dzień ucisku.
###### **Ab 1,15**
 Bo blizko jest dzień Pański nad wszystkie narody: jakoś uczynił, stanieć się: zapłatę twoję obróci na głowę twoję.
###### **Ab 1,16**
 Bo jakoście pili na górze świętej mojej, pić będą narodowie ustawicznie: a pić będą, i połkną, i będą jakoby niebyli.
###### **Ab 1,17**
 A na górze Sion będzie zbawienie i będzie święty: i posiędzie dom Jakobów te, którzy ji byli posiedli.
###### **Ab 1,18**
 I będzie dom Jakobów ogniem, a dom Józefów płomieniem, a dom Esau słomą: i zapalą się na nie, i pożrą je: a nie będzie szczątku domu Esau, bo Pan mówił.
###### **Ab 1,19**
 A odziedziczą ci, którzy są na południe górę Esau, i którzy na polach Filistyńskich: i posiędą krainę Ephraim, i krainę Samaryi, i Benjamin posiędzie Galaad.
###### **Ab 1,20**
 A przeprowadzenie wojska tego synów Izraelskich, wszystkie miejsca Chananejczyków aż do Sarepty: a przeprowadzenie Jeruzalem które jest w Bosphorze, posięże miasto południowe.
###### **Ab 1,21**
 I wstąpią zbawicielowie na górę Sion, sądzić górę Esau: a będzie Panu królestwo.1
