# 1Kor 5 BT5
###### **1Kor 5,1**
 Słyszy się powszechnie o rozpuście między wami, i to o takiej rozpuście, jaka < się nie zdarza > nawet wśród pogan; mianowicie, że ktoś żyje z żoną swego ojca.
###### **1Kor 5,2**
 A wy unieśliście się pychą, zamiast z ubolewaniem żądać, by usunięto spośród was tego, który się dopuścił wspomnianego czynu.
###### **1Kor 5,3**
 Ja zaś, nieobecny wprawdzie ciałem, ale obecny duchem, już potępiłem, tak jakbym był wśród was, sprawcę owego przestępstwa.
###### **1Kor 5,4**
 Przeto wy, zebrawszy się razem w imię Pana naszego, Jezusa, w łączności z duchem moim i z mocą Pana naszego, Jezusa,
###### **1Kor 5,5**
 wydajcie takiego szatanowi na zatracenie ciała, lecz ku ratunkowi jego ducha w dzień Pana < Jezusa >.
###### **1Kor 5,6**
 Wcale nie macie się czym szczycić! Czyż nie wiecie, że odrobina kwasu całe ciasto zakwasza?
###### **1Kor 5,7**
 Wyrzućcie więc stary kwas, abyście się stali nowym ciastem, bo przecież przaśni jesteście. Chrystus bowiem został złożony w ofierze jako nasza Pascha.
###### **1Kor 5,8**
 Tak przeto odprawiajmy święto nasze, nie przy użyciu starego kwasu złości i przewrotności, lecz na przaśnym chlebie czystości i prawdy.
###### **1Kor 5,9**
 Napisałem wam w liście, żebyście nie obcowali z rozpustnikami.
###### **1Kor 5,10**
 Nie chodzi o rozpustników tego świata w ogóle ani o ludzi chciwych albo zdzierców lub bałwochwalców; musielibyście bowiem całkowicie opuścić ten świat.
###### **1Kor 5,11**
 Dlatego pisałem wam wówczas, byście nie przestawali z takim, który nazywając się bratem, w rzeczywistości jest rozpustnikiem, chciwcem, bałwochwalcą, oszczercą, pijakiem lub zdziercą. Z takim nawet nie siadajcie wspólnie do posiłku.
###### **1Kor 5,12**
 Jakże bowiem mogę sądzić tych, którzy są na zewnątrz? Czyż i wy nie macie sądzić tych, którzy są wewnątrz?
###### **1Kor 5,13**
 Tych, którzy są na zewnątrz, będzie sądził Bóg. Usuńcie złego spośród was samych.
# 1Kor 5 PAU
###### **1Kor 5,1**
 Słyszy się powszechnie o nierządzie wśród was, i to takim nierządzie, jakiego nie spotyka się nawet wśród pogan: że ktoś współżyje z żoną swego ojca.
###### **1Kor 5,2**
 A wy zadufani w sobie, nawet nie poczuwacie się do tego, by usunąć spośród was tego, który dopuścił się takiego czynu.
###### **1Kor 5,3**
 Ja tymczasem, wprawdzie nieobecny fizycznie, ale obecny duchem, osądziłem tego, który to uczynił, tak jakbym był obecny -
###### **1Kor 5,4**
 w imię Pana naszego Jezusa. Wy również zgromadzeni razem i w duchowej łączności ze mną, z mocą Pana naszego Jezusa
###### **1Kor 5,5**
 wydajcie takiego szatanowi - na zatracenie ciała, ale dla ocalenia jego ducha w dniu Pana.
###### **1Kor 5,6**
 Nie macie powodu do chluby! Czy nie wiecie, że odrobina zakwasu zakwasza całe ciasto?
###### **1Kor 5,7**
 Usuńcie stary zakwas, by stać się nowym ciastem, gdyż jesteście ciastem niezakwaszonym. Chrystus przecież został złożony w ofierze jako nasza Pascha.
###### **1Kor 5,8**
 Nie świętujmy więc, używając starego zakwasu, a także zakwasu złości i przewrotności, ale w niezakwaszonej czystości i prawdzie.
###### **1Kor 5,9**
 Napisałem wam w liście, abyście nie zadawali się z rozpustnikami.
###### **1Kor 5,10**
 Nie miałem na myśli w ogóle rozpustników tego świata, chciwych, zdzierców czy też bałwochwalców, bo wtedy musielibyście porzucić ten świat.
###### **1Kor 5,11**
 Teraz jednak napisałem wam, abyście nie zadawali się z takim, który nazywa siebie bratem, a jest rozpustnikiem lub chciwcem albo bałwochwalcą, oszczercą, pijakiem czy zdziercą. Z takim nawet nie zasiadajcie do wspólnego stołu.
###### **1Kor 5,12**
 Ja nie zamierzam sądzić tych spoza wspólnoty. Wy sądźcie tylko tych, którzy do was należą.
###### **1Kor 5,13**
 Tych spoza wspólnoty osądzi Bóg. Usuńcie złego spośród was samych.
# 1Kor 5 BP
###### **1Kor 5,1**
 Ogólnie słyszy się o rozpuście wśród was i to takiej, jakiej się nie spotyka nawet u pogan. Doszło do tego, że ktoś żyje z żoną swego ojca.
###### **1Kor 5,2**
 Wy zaś macie jeszcze odwagę unosić się pychą, zamiast raczej okryć się wstydem i domagać się, aby usunięto spośród was tego, który dopuścił się takiego czynu.
###### **1Kor 5,3**
 Ja - znajdując się wprawdzie daleko od was, ale obecny wśród was duchowo - wydałem już wyrok na sprawcę tego występku, tak jakbym znajdował się wśród was.
###### **1Kor 5,4**
 W imię Pana naszego Jezusa: na waszym zgromadzeniu, złączeni duchowo ze mną i z mocą Pana naszego Jezusa,
###### **1Kor 5,5**
 wydajcie tego człowieka szatanowi na zatracenie ciała, aby duch dostąpił zbawienia w dniu Pana.
###### **1Kor 5,6**
 To nie dobrze, że się przechwalacie.
###### **1Kor 5,7**
 Wyrzućcie więc stary kwas, abyście mogli się stać "nowym ciastem", ponieważ jesteście wolni od kwasu. Chrystus bowiem został złożony w ofierze jako nasza Pascha.
###### **1Kor 5,8**
 Obchodźmy zatem święta wielkanocne bez starego kwasu, bez kwasu, który jest symbolem przewrotności, a z niekwaszonymi chlebami symbolizującymi czystość i prawdę.
###### **1Kor 5,9**
 Napisałem wam w liście, abyście nie przebywali w towarzystwie rozpustników.
###### **1Kor 5,10**
 Nie miałem jednak na myśli rozpustników tego świata w ogóle ani chciwców, ani też rabusiów czy bałwochwalców, ponieważ w tym wypadku musielibyście opuścić ten świat.
###### **1Kor 5,11**
 Napisałem wam, abyście nie przebywali w towarzystwie takiego, który nazywa siebie "bratem", a w rzeczywistości jest rozpustnikiem lub chciwcem, bałwochwalcą czy oszczercą, potwarcą lub pijakiem. Z takim człowiekiem nie należy wspólnie spożywać posiłków.
###### **1Kor 5,12**
 Czy do mnie należy wydawanie sądu o tych, którzy znajdują się poza wspólnotą? Natomiast czy wy nie możecie sądzić tych, którzy należą do wspólnoty?
###### **1Kor 5,13**
 Tych, którzy znajdują się poza wspólnotą, będzie sądził Bóg. "Usuńcie przewrotnego spośród was".
# 1Kor 5 BR
###### **1Kor 5,1**
 Słyszy się powszechnie o rozpuście między wami, i to o takiej rozpuście, jaka się nie zdarza nawet wśród pogan; mianowicie, że ktoś żyje z żoną swego ojca.
###### **1Kor 5,2**
 A wy unieśliście się pychą, zamiast z ubolewaniem żądać, by usunięto spośród was tego, który się dopuścił wspomnianego czynu!
###### **1Kor 5,3**
 Ja zaś, nieobecny wprawdzie ciałem, ale obecny duchem, już potępiłem, tak jakbym był wśród was, sprawcę owego przestępstwa.
###### **1Kor 5,4**
 Przeto wy, zebrawszy się razem w imię Pana naszego Jezusa, w łączności z duchem moim i z mocą Pana naszego Jezusa,
###### **1Kor 5,5**
 wydajcie takiego szatanowi na zatracenie ciała, lecz ku ratunkowi jego ducha w dzień Pana [Jezusa].
###### **1Kor 5,6**
 Wcale nie macie się czym szczycić! Czyż nie wiecie, że odrobina kwasu całe ciasto zakwasza?
###### **1Kor 5,7**
 Wyrzućcie więc stary kwas, abyście się stali nowym ciastem, bo przecież przaśni jesteście. Chrystus bowiem został złożony w ofierze jako nasza Pascha.
###### **1Kor 5,8**
 Tak przeto odprawiajmy święto nasze nie przy użyciu starego kwasu złości i przewrotności, lecz na przaśnym chlebie czystości i prawdy.
###### **1Kor 5,9**
 Napisałem wam w liście, żebyście nie obcowali z rozpustnikami.
###### **1Kor 5,10**
 Nie chodzi o rozpustników tego świata w ogóle ani o ludzi chciwych albo zdzierców lub bałwochwalców; musielibyście bowiem całkowicie opuścić ten świat.
###### **1Kor 5,11**
 Pisałem wam wówczas, byście nie przestawali z takim, który nazywając się bratem, w rzeczywistości jest rozpustnikiem, chciwcem, bałwochwalcą, oszczercą, pijakiem lub zdziercą. Z takim nawet nie siadajcie wspólnie do posiłku.
###### **1Kor 5,12**
 Jakże bowiem mogę sądzić tych, którzy są na zewnątrz? Czyż i wy nie sądzicie tych, którzy są wewnątrz?
###### **1Kor 5,13**
 Tych, którzy są na zewnątrz, będzie sądził Bóg. Usuńcie złego spośród was samych.
# 1Kor 5 WUJ
###### **1Kor 5,1**
 Koniecznie słychać między wami porubstwo, a takie porubstwo, jakiego ani między Pogany, tak, iż któryś ma ojca swego żonę.
###### **1Kor 5,2**
 A wyście się, nadęli: a nie raczejeście żałości mieli, aby był zniesion z pośrodku was, który tego uczynku się dopuścił.
###### **1Kor 5,3**
 Ja iście nieprzytomny ciałem, ale duchem przytomny, jużem jako przytomny osądził, tego, który tak uczynił,
###### **1Kor 5,4**
 Gdy się w imię Pana naszego Jezu Chrysta zgromadzicie i z duchem moim: z mocą Pana naszego Jezusa,
###### **1Kor 5,5**
 Podać takiego szatanowi na zatracenie ciała: aby duch był zachowan w dzień Pana naszego Jezusa Chrystusa.
###### **1Kor 5,6**
 Nie dobra jest chluba wasza. Nie wiecie, iż trocha kwasu wszystko ciasto zakwasza?
###### **1Kor 5,7**
 Wyczyśćcież stary kwas, abyście byli nowem zaczynieniem, jako przaśni jesteście. Abowiem paschanasza, ofiarowany jest Chrystus.
###### **1Kor 5,8**
 A tak używajmy nie w starym kwasie, ani w kwasie złości i przewrotności: ale w przaśnikach szczerości i prawdy.
###### **1Kor 5,9**
 Pisałem wam w liście, abyście się nie mieszali z porubnikami.
###### **1Kor 5,10**
 Niezgoła z porubnikami świata tego, abo z łakomymi, abo z drapieżnymi, abo z służącymi bałwanom: Bo inaczej, musielibyście z tego świata wyniść.
###### **1Kor 5,11**
 Lecz teraz pisałem wam, abyście się nie mieszali: jeśli ten, który się bratem mianuje, jest porubnikiem, abo łakomym, abo służącym bałwanom, abo złorzeczącym, abo pijanicą, abo drapieżcą, żebyście z takowym ani jedli.
###### **1Kor 5,12**
 Bo co mnie należy o tych, ktorzy nie są u nas sądzić? Aza o tych, którzy u nas są wy nie sądzicie?
###### **1Kor 5,13**
 Bo tych, którzy nie u nas są, Bóg sądzić będzie. Wyrzućcie złego z pośrodka was.
# 1Kor 5 STERN
###### **1Kor 5,1**
 Mówi się wręcz, że jest wśród was grzech rozwiązłości, i to takiej rozwiązłości, jaką potępiają nawet poganie - że mężczyzna żyje ze swą macochą!
###### **1Kor 5,2**
 A wy się pysznicie? Czy nie powinniście raczej odczuwać smutku, zdolnego skłonić was do usunięcia spośród siebie człowieka, który to popełnił?
###### **1Kor 5,3**
 Bo co do mnie, choć jestem nieobecny fizycznie, to jestem z wami duchowo; i już osądziłem człowieka, który to popełnił, tak jakbym tam był.
###### **1Kor 5,4**
 W imieniu Pana Jeszui, kiedy się zgromadzicie i ja będę duchowo obecny, a moc naszego Pana Jeszui będzie wśród nas,
###### **1Kor 5,5**
 wydajcie takiego Przeciwnikowi, na zniszczenie jego starej natury, tak aby jego duch był ocalony w Dniu Pana.
###### **1Kor 5,6**
 Wasze przechwałki to nic dobrego. Nie znacie przysłowia: "Do zakwaszenia całej partii ciasta wystarczy odrobina chamecu"?
###### **1Kor 5,7**
 Pozbądźcie się starego chamecu, abyście byli nowym ciastem, bo naprawdę jesteście przaśni. Nasz bowiem baranek pesachowy, Mesjasz, został złożony na ofiarę.
###### **1Kor 5,8**
 Świętujmy więc seder nie resztkami chamecu, chamecu niegodziwości i zła, ale macą czystości i prawdy.
###### **1Kor 5,9**
 We wcześniejszym liście napisałem wam, abyście nie przestawali z ludźmi oddającymi się rozwiązłości.
###### **1Kor 5,10**
 Nie miałem na myśli ludzi rozwiązłych spoza waszej wspólnoty ani chciwych, złodziei czy bałwochwalców - bo wtedy w ogóle musielibyście opuścić ten świat!
###### **1Kor 5,11**
 Nie, napisałem wam to, żebyście nie przestawali z nikim, kto choć rzekomo jest bratem, to oddaje się rozwiązłości, jest chciwy, czci bałwany, rzuca obelgi, upija się albo kradnie. Z takim kimś nie powinniście nawet zasiadać do stołu!
###### **1Kor 5,12**
 Bo czemu miałbym się zajmować osądzaniem ludzi z zewnątrz? Czy to nie tych, którzy należą do wspólnoty, powinniście osądzać?
###### **1Kor 5,13**
 Tych na zewnątrz osądzi Bóg. Wy tylko wypędźcie złoczyńcę spośród siebie.
# 1Kor 5 TRO
###### **1Kor 5,1**
 **ολως** *holōs* Całkowicie [[G3654]] [[ADV]] **ακουεται** *akouetai* jest słyszany [[G191]] WTV-PPI-3S **εν** *en* wśród [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **πορνεια** *porneia* nierząd – wszeteczeństwo [[G4202]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **τοιαυτη** *toiautē* taki [[G5108]] WTD-NSF **πορνεια** *porneia* nierząd – wszeteczeństwo [[G4202]] [[N-NSF]] **ητις** *hētis* który [[G3748]] WTR-NSF **ουδε** *oude* ani [[G3761]] [[ADV]] **εν** *en* wśród [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPN **εθνεσιν** *ethnesin* narodów – pogan [[G1484]] WTN-DPN **ονομαζεται** *onomazetai* jest wymieniany – jest nazywana [[G3687]] WTV-PPI-3S **ωστε** *hōste* że [[G5620]] [[CONJ]] **γυναικα** *gynaika* żonę – kobietę [[G1135]] WTN-ASF **τινα** *tina* ktoś [[G5100]] WTX-ASF **του** *tou* [[G3588]] WTT-GSM **πατρος** *patros* ojca [[G3962]] [[N-GSM]] **εχειν** *echein* mieć [[G2192]] WTV-PAN
###### **1Kor 5,2**
 **και** *kai* A [[G2532]] [[CONJ]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **πεφυσιωμενοι** *pefysiōmenoi* którzy są nadętymi [[G5448]] WTV-RPP-NPM **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **και** *kai* i [[G2532]] [[CONJ]] **ουχι** *ouchi* wcale [[G3780]] WTPRT-I **μαλλον** *mallon* bardziej [[G3123]] [[ADV]] **επενθησατε** *epenthēsate* zasmuciliście się – zaczęliście boleć [[G3996]] WTV-AAI-2P **ινα** *hina* aby [[G2443]] [[CONJ]] **εξαρθη** *eksarthē* zostałby usunięty [[G1808]] WTV-APS-3S **εκ** *ek* z [[G1537]] [[PREP]] **μεσου** *mesou* pośród [[G3319]] [[A-GSN]] **υμων** *hymōn* was [[G5216]] WTP-2GP **ο** *ho* (ten) [[G3588]] [[T-NSM]] **το** *to* [[G3588]] WTT-ASN **εργον** *ergon* czynu [[G2041]] WTN-ASN **τουτο** *touto* tego [[G5124]] WTD-ASN **ποιησας** *poiēsas* który uczynił [[G4160]] WTV-AAP-NSM
###### **1Kor 5,3**
 **εγω** *egō* Ja [[G1473]] WTP-1NS **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ως** *hōs* jak [[G5613]] [[ADV]] **απων** *apōn* będąc nieobecny [[G548]] [[V-PXP-NSM]] **τω** *tō* [[G3588]] WTT-DSN **σωματι** *sōmati* ciałem [[G4983]] WTN-DSN **παρων** *parōn* będąc obecny [[G3918]] [[V-PXP-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **τω** *tō* [[G3588]] WTT-DSN **πνευματι** *pneumati* duchem [[G4151]] WTN-DSN **ηδη** *ēdē* już [[G2235]] [[ADV]] **κεκρικα** *kekrika* osądziłem [[G2919]] WTV-RAI-1S **ως** *hōs* jak [[G5613]] [[ADV]] **παρων** *parōn* będąc obecny [[G3918]] [[V-PXP-NSM]] **τον** *ton* [[G3588]] [[T-ASM]] **ουτως** *houtōs* tak [[G3779]] [[ADV]] **τουτο** *touto* tego [[G5124]] WTD-ASN **κατεργασαμενον** *katergasamenon* który był sprawcą [[G2716]] WTV-ADP-ASM
###### **1Kor 5,4**
 **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **ονοματι** *onomati* imieniu [[G3686]] WTN-DSN **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **συναχθεντων** *synachthentōn* zostawszy zebranymi – zostawszy zgromadzonymi [[G4863]] WTV-APP-GPM **υμων** *hymōn* wy [[G5216]] WTP-2GP **και** *kai* i [[G2532]] [[CONJ]] **του** *tou* [[G3588]] WTT-GSN **εμου** *emou* mój [[G1700]] WTP-1GS **πνευματος** *pneumatos* duch [[G4151]] [[N-GSN]] **συν** *syn* z [[G4862]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **δυναμει** *dynamei* mocą [[G1411]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **1Kor 5,5**
 **παραδουναι** *paradounai* wydać [[G3860]] [[V-2AAN]] **τον** *ton* [[G3588]] [[T-ASM]] **τοιουτον** *toiouton* takiego [[G5108]] WTD-ASM **τω** *tō* [[G3588]] WTT-DSM **σατανα** *satana* szatanowi – [przeciwnik] [[G4567]] WTN-DSM **εις** *eis* ku [[G1519]] [[PREP]] **ολεθρον** *olethron* zagładzie – ruinie [[G3639]] [[N-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **σαρκος** *sarkos* ciała [[G4561]] [[N-GSF]] **ινα** *hina* aby [[G2443]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **πνευμα** *pneuma* duch [[G4151]] WTN-NSN **σωθη** *sōthē* zostałby zbawiony – zostałby uratowany [[G4982]] WTV-APS-3S **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **ημερα** *hēmera* dzień [[G2250]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]]
###### **1Kor 5,6**
 **ου** *ou* Nie [[G3756]] [[PRT-N]] **καλον** *kalon* dobra – piękna [[G2570]] WTA-NSN **το** *to* [[G3588]] WTT-NSN **καυχημα** *kauchēma* chluba [[G2745]] WTN-NSN **υμων** *hymōn* wasza [[G5216]] WTP-2GP **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **οιδατε** *oidate* wiecie [[G1492]] WTV-RAI-2P **οτι** *hoti* że [[G3754]] [[CONJ]] **μικρα** *mikra* mały [[G3398]] WTA-NSF **ζυμη** *zymē* kwas – zaczyn [[G2219]] [[N-NSF]] **ολον** *holon* całe [[G3650]] WTA-ASN **το** *to* [[G3588]] WTT-ASN **φυραμα** *fyrama* ciasto [[G5445]] WTN-ASN **ζυμοι** *zymoi* zakwasza – zaczynia [[G2220]] WTV-PAI-3S
###### **1Kor 5,7**
 **εκκαθαρατε** *ekkatharate* Oczyśćcie [[G1571]] WTV-AAM-2P **ουν** *oun* więc [[G3767]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **παλαιαν** *palaian* stary [[G3820]] WTA-ASF **ζυμην** *zymēn* zakwas – zaczyn [[G2219]] WTN-ASF **ινα** *hina* aby [[G2443]] [[CONJ]] **ητε** *ēte* bylibyście [[G5600]] WTV-PXS-2P **νεον** *neon* nowe – młode [[G3501]] WTA-NSN **φυραμα** *fyrama* ciasto [[G5445]] WTN-NSN **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **αζυμοι** *azymoi* przaśni – niekwaszeni [[G106]] WTA-NPM **και** *kai* i [[G2532]] [[CONJ]] **γαρ** *gar* bo [[G1063]] [[CONJ]] **το** *to* (jako) [[G3588]] WTT-NSN **πασχα** *pascha* Pascha – [przejście] [[G3957]] WTARAM **ημων** *hēmōn* nasza [[G2257]] WTP-1GP **υπερ** *hyper* za [[G5228]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP **εθυθη** *ethythē* został złożony w ofierze – został zabity na ofiarę [[G2380]] [[V-API-3S]] **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]]
###### **1Kor 5,8**
 **ωστε** *hōste* tak, że [[G5620]] [[CONJ]] **εορταζωμεν** *heortazōmen* świętowalibyśmy – obchodzilibyśmy święto [[G1858]] WTV-PAS-1P **μη** *mē* nie [[G3361]] [[PRT-N]] **εν** *en* w [[G1722]] [[PREP]] **ζυμη** *zymē* zakwasie – zaczynie [[G2219]] [[N-DSF]] **παλαια** *palaia* starym [[G3820]] WTA-DSF **μηδε** *mēde* ani [[G3366]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **ζυμη** *zymē* zakwasie – zaczynie [[G2219]] [[N-DSF]] **κακιας** *kakias* złości – niegodziwości [[G2549]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **πονηριας** *ponērias* niegodziwości [[G4189]] [[N-GSF]] **αλλ** *all* ale [[G235]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **αζυμοις** *azymois* przaśnikach – niekwaszonych [[G106]] WTA-DPN **ειλικρινειας** *eilikrineias* szczerości – nieskażoności [[G1505]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **αληθειας** *alētheias* prawdy [[G225]] [[N-GSF]]
###### **1Kor 5,9**
 **εγραψα** *egrapsa* Napisałem [[G1125]] WTV-AAI-1S **υμιν** *hymin* wam [[G5213]] WTP-2DP **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* (tym) [[G3588]] WTT-DSF **επιστολη** *epistolē* liście [[G1992]] [[N-DSF]] **μη** *mē* nie [[G3361]] [[PRT-N]] **συναναμιγνυσθαι** *synanamignysthai* mieszać się z [[G4874]] WTV-PMN **πορνοις** *pornois* rozpustnikami – wszetecznikami [[G4205]] WTN-DPM
###### **1Kor 5,10**
 **και** *kai* A [[G2532]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **παντως** *pantōs* wcale [[G3843]] [[ADV]] **τοις** *tois* (z) [[G3588]] WTT-DPM **πορνοις** *pornois* rozpustnikami – wszetecznikami [[G4205]] WTN-DPM **του** *tou* [[G3588]] WTT-GSM **κοσμου** *kosmou* świata [[G2889]] [[N-GSM]] **τουτου** *toutou* tego [[G5127]] WTD-GSM **η** *ē* lub [[G2228]] WTPRT **τοις** *tois* (z) [[G3588]] WTT-DPM **πλεονεκταις** *pleonektais* chciwcami – zachłannymi [[G4123]] WTN-DPM **η** *hē* lub [[G2228]] WTPRT **αρπαξιν** *harpaksin* zdziercami – drapieżnymi [[G727]] WTA-DPM **η** *ē* lub [[G2228]] WTPRT **ειδωλολατραις** *eidōlolatrais* bałwochwalcami [[G1496]] WTN-DPM **επει** *epei* skoro – jako, że [[G1893]] [[CONJ]] **οφειλετε** *ofeilete* jesteście zobowiązani [[G3784]] WTV-PAI-2P **αρα** *ara* zatem [[G686]] WTPRT **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* (tego) [[G3588]] WTT-GSM **κοσμου** *kosmou* świata [[G2889]] [[N-GSM]] **εξελθειν** *ekselthein* wyjść [[G1831]] [[V-2AAN]]
###### **1Kor 5,11**
 **νυνι** *nyni* Teraz [[G3570]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **εγραψα** *egrapsa* napisałem [[G1125]] WTV-AAI-1S **υμιν** *hymin* wam [[G5213]] WTP-2DP **μη** *mē* aby nie [[G3361]] [[PRT-N]] **συναναμιγνυσθαι** *synanamignysthai* mieszać się [[G4874]] WTV-PMN **εαν** *ean* jeśli [[G1437]] WTCOND **τις** *tis* ktoś [[G5100]] WTX-NSM **αδελφος** *adelfos* brat [[G80]] [[N-NSM]] **ονομαζομενος** *onomazomenos* który jest nazywany [[G3687]] [[V-PPP-NSM]] **η** *ē* lub [[G2228]] WTPRT **πορνος** *pornos* rozpustnik – wszetecznik [[G4205]] [[N-NSM]] **η** *ē* lub [[G2228]] WTPRT **πλεονεκτης** *pleonektēs* chciwiec – zachłanny [[G4123]] [[N-NSM]] **η** *ē* lub [[G2228]] WTPRT **ειδωλολατρης** *eidōlolatrēs* bałwochwalca [[G1496]] [[N-NSM]] **η** *ē* lub [[G2228]] WTPRT **λοιδορος** *loidoros* oszczerca – znieważający [[G3060]] [[A-NSM]] **η** *ē* lub [[G2228]] WTPRT **μεθυσος** *methysos* pijak [[G3183]] [[N-NSM]] **η** *ē* lub [[G2228]] WTPRT **αρπαξ** *harpaks* zdzierca – drapieżca [[G727]] [[A-NSM]] **τω** *tō* (z) [[G3588]] WTT-DSM **τοιουτω** *toioutō* takimi [[G5108]] WTD-DSM **μηδε** *mēde* i nie [[G3366]] [[CONJ]] **συνεσθιειν** *synesthiein* jeść razem [[G4906]] WTV-PAN
###### **1Kor 5,12**
 **τι** *ti* Co [[G5101]] WTI-NSN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **μοι** *moi* mi [[G3427]] WTP-1DS **και** *kai* i [[G2532]] [[CONJ]] **τους** *tous* (tych) [[G3588]] WTT-APM **εξω** *eksō* z zewnątrz [[G1854]] [[ADV]] **κρινειν** *krinein* sądzić [[G2919]] WTV-PAN **ουχι** *ouchi* czyż nie [[G3780]] WTPRT-I **τους** *tous* (tych) [[G3588]] WTT-APM **εσω** *esō* wewnątrz [[G2080]] [[ADV]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **κρινετε** *krinete* sądzicie [[G2919]] WTV-PAI-2P
###### **1Kor 5,13**
 **τους** *tous* (Tych) [[G3588]] WTT-APM **δε** *de* zaś [[G1161]] [[CONJ]] **εξω** *eksō* z zewnątrz [[G1854]] [[ADV]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **κρινει** *krinei* osądzi [[G2919]] WTV-FAI-3S **και** *kai* i [[G2532]] [[CONJ]] **εξαρειτε** *eksareite* usuniecie – pozbędziecie się [[G1808]] WTV-FAI-2P **τον** *ton* (tego) [[G3588]] [[T-ASM]] **πονηρον** *ponēron* niegodziwego – złego [[G4190]] WTA-ASM **εξ** *eks* z [[G1537]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **αυτων** *autōn* samych [[G846]] WTP-GPM
