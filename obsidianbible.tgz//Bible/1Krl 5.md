# 1Krl 5 BT5
###### **1Krl 5,1**
 Salomon panował od Rzeki do kraju Filistynów i do granicy Egiptu nad wszystkimi królestwami. Składały one daninę i były poddane Salomonowi przez całe jego życie.
###### **1Krl 5,2**
 Codzienną dostawę żywności dla Salomona stanowiło: trzydzieści kor najczystszej mąki i sześćdziesiąt kor zwykłej mąki,
###### **1Krl 5,3**
 dziesięć tucznych wołów i dziesięć wołów pastwiskowych oraz sto owiec, nie licząc jeleni, gazeli, danieli i tucznego ptactwa.
###### **1Krl 5,4**
 Panował on też w całym Zarzeczu od Tifsach do Gazy i nad wszystkimi królami Zarzecza, i zażywał pokoju ze wszystkich stron dokoła.
###### **1Krl 5,5**
 Dlatego też przez wszystkie dni Salomona Juda i Izrael mieszkali bezpiecznie, każdy pod swoją winoroślą i pod swoim figowcem, od Dan do Beer-Szeby.
###### **1Krl 5,6**
 Salomon miał też cztery tysiące stajni dla koni do swoich powozów i dwanaście tysięcy wierzchowców.
###### **1Krl 5,7**
 Rządcy ci zaopatrywali króla Salomona i wszystkich zaproszonych do stołu królewskiego; każdy w swoim miesiącu, tak iż niczego nie brakowało.
###### **1Krl 5,8**
 Również jęczmień i słomę dla koni [pociągowych] i rumaków sprowadzano na to miejsce, które każdemu było wyznaczone.
###### **1Krl 5,9**
 Bóg dał Salomonowi mądrość i rozsądek nadzwyczajny oraz rozum nieogarniony jak piasek na brzegu morza.
###### **1Krl 5,10**
 Toteż mądrość Salomona przewyższała mądrość wszystkich ludzi Wschodu i mądrość Egipcjan.
###### **1Krl 5,11**
 Górował on mądrością nad wszystkimi ludźmi, nawet nad Etanem Ezrachitą i Hemanem, jak też Kalkolem i Dardą, synami Machola. A imię jego stało się sławne wśród wszystkich okolicznych narodów.
###### **1Krl 5,12**
 Wypowiedział bowiem trzy tysiące przysłów, a pieśni jego było tysiąc pięć.
###### **1Krl 5,13**
 Rozprawiał też o drzewach: od cedrów na Libanie aż do hizopu rosnącego na murze. Mówił także o zwierzętach czworonożnych, o ptactwie, o tym, co pełza po ziemi, i o rybach.
###### **1Krl 5,14**
 Przychodzili więc ze wszystkich narodów i spośród wszystkich królów ci, którzy dowiedzieli się o mądrości Salomona, aby przysłuchiwać się jego mądrości.
###### **1Krl 5,15**
 Hiram, król Tyru, posłał do Salomona swoje sługi, bo dowiedział się, że namaszczono go na króla w miejsce jego ojca, a Hiram był stale w przyjaźni z Dawidem.
###### **1Krl 5,16**
 Wtedy Salomon przesłał Hiramowi takie słowa:
###### **1Krl 5,17**
 «***Wiesz, że Dawid, mój ojciec, nie mógł zbudować świątyni imieniu Pana, Boga swego, z powodu wojen, jakimi go dokoła otoczyli [wrogowie], dopóki Pan nie położył ich pod jego stopy.***
###### **1Krl 5,18**
 ***A teraz Pan, Bóg mój, obdarzył mnie zewsząd pokojem. Nie ma przeciwnika ani też złego wydarzenia.***
###### **1Krl 5,19**
 ***Wobec tego zamierzam budować świątynię imieniu Pana, Boga mego, stosownie do tego, co Pan rzekł Dawidowi, memu ojcu: Twój syn, którego ci dam jako następcę na twoim tronie, on właśnie będzie budował świątynię dla mego imienia.***
###### **1Krl 5,20**
 ***Teraz więc każ naścinać mi cedrów z Libanu. A moi słudzy niech będą razem z twoimi sługami. Dam ci zapłatę dla twoich sług, jakiej tylko zażądasz, bo wiesz, że nie mamy ludzi tak umiejących ciąć drzewa jak Sydończycy***».
###### **1Krl 5,21**
 Gdy Hiram usłyszał słowa Salomona, ucieszył się bardzo i rzekł: «***Niech będzie dziś błogosławiony Pan, który Dawidowi dał mądrego syna, [by władał] tym wielkim ludem***».
###### **1Krl 5,22**
 Następnie Hiram przesłał Salomonowi te słowa: «***Wysłuchałem tego, co mi przesłałeś. Ja spełnię wszystkie twoje życzenia co do drewna cedrowego i co do drewna cyprysowego.***
###### **1Krl 5,23**
 ***Słudzy moi sprowadzają je z Libanu do morza, a ja zestawię je na morzu w tratwy i przeciągnę je na to miejsce, które mi wskażesz. Tam każę je rozłączyć, a ty je weźmiesz i spełnisz moje życzenie, aby mój dwór zaopatrzyć w żywność***».
###### **1Krl 5,24**
 Tak Hiram dostarczał Salomonowi drewna cedrowego i drewna cyprysowego, ile tylko ten potrzebował.
###### **1Krl 5,25**
 Salomon zaś dawał Hiramowi na wyżywienie jego dworu dwadzieścia tysięcy kor pszenicy i dwadzieścia tysięcy bat tłoczonej oliwy. Co roku Salomon dawał to Hiramowi.
###### **1Krl 5,26**
 Pan bowiem obdarzył Salomona mądrością, tak jak mu przyrzekł. Utrwaliła się zatem przyjaźń między Hiramem a Salomonem, gdyż zawarli ze sobą przymierze.
###### **1Krl 5,27**
 Król Salomon wziął robotników pracujących przymusowo z całego Izraela. Było takich robotników trzydzieści tysięcy.
###### **1Krl 5,28**
 Wysyłał ich do Libanu co miesiąc po dziesięć tysięcy na zmianę: miesiąc byli w Libanie, a dwa miesiące w domu. Nadzorcą robotników pracujących przymusowo był Adoniram.
###### **1Krl 5,29**
 Salomon miał też siedemdziesiąt tysięcy tragarzy i osiemdziesiąt tysięcy kamieniarzy.
###### **1Krl 5,30**
 Ponadto Salomon miał, prócz wyższych urzędników zarządzających pracami, trzy tysiące trzystu nadzorujących lud wykonujący pracę.
###### **1Krl 5,31**
 Król polecił im, aby kazali wydobywać wielkie kamienie, wyborowe i ciosane, na założenie fundamentów budowli.
###### **1Krl 5,32**
 Murarze więc Salomona i murarze Hirama wraz z Giblitami ciosali i przygotowywali drewno i kamienie na budowę świątyni.
# 1Krl 5 PAU
###### **1Krl 5,1**
 Salomon był władcą nad wszystkimi królestwami od Eufratuaż do kraju Filistynów, sięgając granic Egiptu. Płaciły one daninę i były poddane Salomonowi przez całe jego życie.
###### **1Krl 5,2**
 Dostawa żywności dla króla na jeden dzień wynosiła: trzydzieści kor najlepszej mąki i sześćdziesiąt kor zwykłej mąki,
###### **1Krl 5,3**
 dziesięć utuczonych wołów oraz dwadzieścia wołów z pastwiska, a także sto owiec, nie licząc jeleni, gazeli, saren oraz utuczonego ptactwa.
###### **1Krl 5,4**
 Był on bowiem władcą nad całym obszarem na zachód od Eufratu, od Tifsach do Gazy, ciesząc się pokojem ze wszystkich stron dokoła.
###### **1Krl 5,5**
 Przez cały okres panowania Salomona Juda i Izrael mieszkali bezpiecznie, każdy pod swoją winoroślą i drzewem figowym, od Dan do Beer-Szeby.
###### **1Krl 5,6**
 Salomon miał też czterdzieści tysięcy koni do rydwanów w swoich stajniach oraz dwanaście tysięcy koni dla jeźdźców.
###### **1Krl 5,7**
 Zarządcy prowincji, kolejno każdy w swoim miesiącu, zaopatrywali w żywność króla Salomona i wszystkich zaproszonych do królewskiego stołu, tak że niczego nie brakowało.
###### **1Krl 5,8**
 Sprowadzali oni także jęczmień i słomę dla koni wierzchowych i pociągowych na miejsce, które każdemu było wyznaczone.
###### **1Krl 5,9**
 Bóg obdarzył Salomona mądrością, głębokim zrozumieniem spraw i rozumem nieogarnionym jak piaszczysty brzeg morski.
###### **1Krl 5,10**
 Mądrość Salomona była większa od mądrości wszystkich ludzi Wschodu i całej mądrości Egiptu.
###### **1Krl 5,11**
 Górował mądrością nad wszystkimi ludźmi, zarówno nad Etanem Ezrachitą i Hemanem, jak i nad Kalkolem i Dardą, synami Machola. Stał się sławny wśród wszystkich okolicznych narodów.
###### **1Krl 5,12**
 Ułożył trzy tysiące przysłów oraz tysiąc pięć pieśni.
###### **1Krl 5,13**
 Wypowiadał się na temat drzew, poczynając od cedru z Libanu, aż do hizopu rosnącego na murze. Dzielił się także wiedzą dotyczącą zwierząt i ptaków, płazów i ryb.
###### **1Krl 5,14**
 Ludzie, którzy dowiedzieli się o mądrości Salomona, przychodzili ze wszystkich narodów i wszystkich królestw, aby go słuchać.
###### **1Krl 5,15**
 Kiedy Hiram, król Tyru, usłyszał, że namaszczono Salomona na króla w miejsce jego ojca Dawida, wysłał do niego poselstwo. Był on bowiem przez całe życie przyjacielem Dawida.
###### **1Krl 5,16**
 Wtedy Salomon przekazał Hiramowi następującą wiadomość:
###### **1Krl 5,17**
 „Wiesz, że mój ojciec, Dawid, nie mógł zbudować domu dla imienia PANA, swojego Boga, z powodu wojen, które toczył ze swymi wrogami, dopóki PAN nie rzucił mu ich pod nogi.
###### **1Krl 5,18**
 Teraz jednak PAN, mój Bóg, obdarzył mnie powszechnym pokojem. Nie ma żadnego przeciwnika, nie spodziewamy się też żadnego ataku.
###### **1Krl 5,19**
 Zamierzam zatem zbudować dom dla imienia PANA, mojego Boga, zgodnie z obietnicą, którą PAN dał memu ojcu Dawidowi: «Twój syn, którego posadzę na twoim tronie jako następcę, zbuduje dom dla Mojego imienia».
###### **1Krl 5,20**
 Każ ściąć dla mnie cedry z Libanu. Moi ludzie będą pracować z twoimi. Zapłacę twoim ludziom tyle, ile wyznaczysz. Sam wiesz bowiem, że nie mamy tak zręcznych drwali jak Sydończycy”.
###### **1Krl 5,21**
 Hiram bardzo się ucieszył z odpowiedzi Salomona: „Niech będzie dziś błogosławiony PAN, który dał Dawidowi mądrego syna i ustanowił go królem nad tym wielkim ludem”.
###### **1Krl 5,22**
 Potem przekazał Salomonowi tę wiadomość: „W odpowiedzi na twoją prośbę o drzewa cedrowe i cyprysowe, spełnię wszystkie twe życzenia.
###### **1Krl 5,23**
 Moi ludzie sprowadzą je z Libanu nad morze, ja zaś każę powiązać je w tratwy i przeprawić przez morze do miejsca, które mi wskażesz. Tam je rozładują, a ty je stamtąd zabierzesz. Ty ze swojej strony spełnisz moje życzenie i dostarczysz żywność na mój dwór”.
###### **1Krl 5,24**
 Tak więc Hiram dostarczał Salomonowi drewna cedrowego i cyprysowego na każde jego życzenie.
###### **1Krl 5,25**
 Natomiast Salomon dostarczał Hiramowi na wyżywienie jego dworu dwadzieścia tysięcy miar pszenicy oraz dwadzieścia miar czystej oliwy. Co roku Salomon dostarczał Hiramowi taką ilość żywności.
###### **1Krl 5,26**
 Zgodnie ze swą obietnicą Pan obdarzył Salomona mądrością. Panował więc pokój między Hiramem i Salomonem, utrwalony przymierzem.
###### **1Krl 5,27**
 Król Salomon wyznaczył do publicznych robót trzydzieści tysięcy robotników z całego Izraela.
###### **1Krl 5,28**
 Co miesiąc wysyłał ich do Libanu po dziesięć tysięcy na każdej zmianie, tak że miesiąc przebywali w Libanie, a dwa miesiące w domu. Całością publicznych robót kierował Adoniram.
###### **1Krl 5,29**
 Salomon miał również siedemdziesiąt tysięcy robotników do przewozu materiałów oraz osiemdziesiąt tysięcy pracujących w kamieniołomach,
###### **1Krl 5,30**
 nie licząc trzech tysięcy trzystu kierowników robót, którzy nadzorowali pracujących.
###### **1Krl 5,31**
 Król polecił wycinać wielkie bloki z twardej skały, aby ułożyć z nich fundamenty budowli.
###### **1Krl 5,32**
 Budowniczowie Salomona i Hirama oraz Giblici ciosali bloki skalne i przygotowywali drewno i kamienie na budowę domu.
# 1Krl 5 BP
###### **1Krl 5,1**
 Salomon był władcą wszystkich królestw od Rzeki [poprzez] ziemię Filistynów aż po granice Egiptu. Płaciły [one] daninę i były poddane Salomonowi przez całe jego życie.
###### **1Krl 5,2**
 Dzienne utrzymanie dworu Salomona wynosiło trzydzieści kor mąki najprzedniejszej i sześćdziesiąt kor mąki razowej;
###### **1Krl 5,3**
 dziesięć [sztuk] bydła karmnego, dwadzieścia [sztuk] bydła z pastwisk i sto owiec, nie licząc jeleni, gazeli, antylop i tuczonego drobiu.
###### **1Krl 5,4**
 Panował on bowiem nad całą [krainą] za Rzeką od Tifsach aż do Gazy, nad wszystkimi królami za Rzeką i miał pokój ze wszech stron dookoła.
###### **1Krl 5,5**
 Przez wszystkie lata Salomona Juda i Izrael pędzili życie w bezpieczeństwie, każdy pod swoim winnym krzewem i pod swym drzewem figowym od Dan aż po Beerszebę.
###### **1Krl 5,6**
 Salomon miał cztery tysiące stanowisk dla koni do swoich rydwanów i dwanaście tysięcy wierzchowców.
###### **1Krl 5,7**
 Owi prefekci, każdy w swoim miesiącu, starali się o utrzymanie króla Salomona i wszystkich jego stołowników. Troszczyli się [oni o to], aby nie brakowało niczego.
###### **1Krl 5,8**
 Jęczmień oraz sieczkę dla koni i zwierząt pociągowych dostawiali na miejsce tam, gdzie się [król] znajdował, każdy według swojej powinności.
###### **1Krl 5,9**
 Bóg dał Salomonowi mądrość i bardzo wielki rozum oraz tak rozległy umysł jak piasek na morskim wybrzeżu.
###### **1Krl 5,10**
 Mądrość Salomona przerastała mądrość wszystkich synów Wschodu i całą mądrość egipską.
###### **1Krl 5,11**
 Mędrszy był niż wszyscy ludzie, niż Etan Ezrachita, niż Heman, Kalkol i Darda, synowie Machola. Imię jego znały wszystkie ludy dookoła.
###### **1Krl 5,12**
 Powiedzał trzy tysiące przysłów, a jego pieśni było tysiąc pięć.
###### **1Krl 5,13**
 Rozprawiał o drzewach [począwszy] od cedru libańskiego aż po hizop, który się krzewi na murze. Mówił o zwierzętach, o ptakach, o płazach i rybach.
###### **1Krl 5,14**
 Przybywano ze wszystkich narodów, aby słuchać mądrości Salomona, [nawet] od wszystkich królów ziemi, którzy słyszeli o jego mądrości.
###### **1Krl 5,15**
 Chiram, król Tyru, posłał swoich dworzan do Salomona, ponieważ usłyszał, że namaszczono go na króla po jego ojcu. Chiram bowiem był przez wszystkie lata przyjacielem Dawida.
###### **1Krl 5,16**
 Salomon zwrócił się do Chirama, prosząc:
###### **1Krl 5,17**
 Ty wiesz, że Dawid, mój ojciec, nie mógł zbudować Świątyni dla Imienia Jahwe, swego Boga, z powodu wojny, jaką toczyli z nim [wrogowie] dookoła, aż [do chwili, gdy] Jahwe dał ich pod jego stopy.
###### **1Krl 5,18**
 Obecnie Jahwe, mój Bóg, zesłał mi zewsząd pokój; nie ma nieprzyjaciela i nie ma przeciwności.
###### **1Krl 5,19**
 Oto więc ja postanowiłem budować Świątynię Imieniu Jahwe, mojemu Bogu, zgodnie z tym co powiedział Jahwe do Dawida, mojego ojca: Syn twój, którego osadzę po tobie na twym tronie, on zbuduje Świątynię dla Imienia mojego.
###### **1Krl 5,20**
 Teraz zatem rozkaż, aby ścięto dla mnie [pewną ilość] cedrów libańskich. Moi słudzy będą [pracować] z twoimi poddanymi. Dam ci zapłatę za [pracę] twoich poddanych w tej wysokości, jaką sam ustalisz, bo ty wiesz, że nie ma u nas nikogo, kto by umiał ścinać drzewo tak, jak Sydończycy.
###### **1Krl 5,21**
 Gdy Chiram usłyszał prośbę Salomona bardzo się uradował i rzekł: Niech będzie dzisiaj błogosławiony Jahwe, który dał Dawidowi mądrego syna, [panującego] nad tym wielkim narodem.
###### **1Krl 5,22**
 I posłał Chiram do Salomona mówiąc: Przyjąłem do wiadomości to, co mi przekazałeś. Ja [ze swej strony] spełnię wszystkie twoje życzenia co do drzewa cedrowego i drzewa cyprysowego.
###### **1Krl 5,23**
 Moi poddani sprowadzą [je] z Libanu ku morzu, a ja złożę je tam w tratwy i morzem [spławię] aż do miejsca, które mi wyznaczysz. Tam [tratwy] rozbiorę, a ty [drzewo] sobie zabierzesz. Ty [znów ze swej strony] spełnisz moje życzenie, dostarczając żywności mojemu domowi.
###### **1Krl 5,24**
 [Tak więc] Chiram dostarczał Salomonowi drzewo cedrowe i drzewo cyprysowe, wszystko według jego życzenia.
###### **1Krl 5,25**
 Salomon zaś dawał Chiramowi dwadzieścia tysięcy kor pszenicy na utrzymanie jego domu i dwadzieścia kor czystej oliwy. Tyle płacił Salomon Chiramowi rokrocznie.
###### **1Krl 5,26**
 Jahwe dał mądrość Salomonowi, tak jak mu obiecał. Między Chiramem a Salomonem panował pokój. Obydwaj zawarli z sobą przymierze.
###### **1Krl 5,27**
 Król Salomon zażądał pracy przymusowej od całego Izraela. Praca przymusowa objęła trzydzieści tysięcy mężów.
###### **1Krl 5,28**
 Co miesiąc na zmianę posyłał dziesięć tysięcy ludzi do Libanu. Przez miesiąc byli [oni zatrudnieni] w Libanie, a dwa miesiące przebywali w swoim domu. Adoniram był kierownikiem pracy przymusowej.
###### **1Krl 5,29**
 Salomon miał [także] siedemdziesiąt tysięcy ludzi do dźwigania ciężarów i osiemdziesiąt tysięcy kamieniarzy w górach,
###### **1Krl 5,30**
 nie licząc trzech tysięcy trzystu przełożonych nad robotami, [mianowanych przez] prefektów Salomona, którzy kierowali ludem zatrudnionym przy pracy.
###### **1Krl 5,31**
 Król wydał polecenie, i łupano olbrzymie głazy, pełnowartościowe bloki, aby położyć [fundament] Świątyni na ciosanych kamieniach.
###### **1Krl 5,32**
 Majstrzy Salomona i majstrzy Chirama oraz Gebalczycy cięli i przygotowywali drzewo oraz kamienie do budowy Świątyni.
# 1Krl 5 BR
###### **1Krl 5,1**
 Salomon zaś miał władzę nad wszystkimi królestwami, od Rzeki aż do kraju Filistynów i po granice z Egiptem. [Wszyscy władcy tych królestw] przynosili Salomonowi różne dary i byli mu poddani przez wszystkie dni jego życia.
###### **1Krl 5,2**
 Na utrzymanie Salomona zużywano każdego dnia trzydzieści kor najczystszej mąki i sześćdziesiąt kor mąki zwykłej,
###### **1Krl 5,3**
 dziesięć wołów tuczonych, dwadzieścia wołów branych prosto z pastwiska, sto baranów, nie licząc jeleni, kozic, danieli i specjalnie tuczonego ptactwa.
###### **1Krl 5,4**
 Władza Salomona rozciągała się na całą krainę poza Rzeką, od Tifsach aż do Gazy; podlegali mu wszyscy władcy z obszarów po drugiej stronie Rzeki, a on ze wszystkimi swoimi poddanymi dokoła żył w pokoju.
###### **1Krl 5,5**
 Mieszkańcy Judy oraz Izraela żyli bezpiecznie, każdy w cieniu własnych winorośli i drzew figowych, od Dan aż do Beer-Szeby. I tak było aż do ostatnich dni Salomona.
###### **1Krl 5,6**
 Salomon miał cztery tysiące stajni dla koni, które zaprzęgano do rydwanów, oraz dwanaście tysięcy koni wierzchowych.
###### **1Krl 5,7**
 Nadzorcy królewscy troszczyli się, każdy przez jeden miesiąc, o pożywienie dla króla Salomona oraz dla wszystkich, którzy byli dopuszczani do jego stołu. Pilnowali, żeby niczego nie brakowało.
###### **1Krl 5,8**
 Sprowadzali także jęczmień i słomę dla koni, zarówno tych pociągowych, jak i wierzchowców, i dostarczali tam, gdzie znajdowały się konie, według ilości, którą każdemu z nich wcześnie wyznaczano.
###### **1Krl 5,9**
 Bóg dał Salomonowi mądrość, bystrość umysłu i wiedzę tak rozległą jak zasoby piasku nad brzegiem morza.
###### **1Krl 5,10**
 Swoją mądrością przewyższał Salomon wszystkich synów Wschodu oraz mędrców egipskich.
###### **1Krl 5,11**
 Nikt z ludzi nie dorównywał mu mądrością: ani Etan Ezrachita, ani Heman, ani Kalkol i Darda, synowie Machola. Rosła też jego sława wśród wszystkich narodów dokoła.
###### **1Krl 5,12**
 Wygłosił Salomon trzy tysiące przysłów i ułożył tysiąc pięć pieśni.
###### **1Krl 5,13**
 Pisał rozprawy o roślinach, zaczynając od cedrów libańskich, a kończąc na hizopie, który pnie się po murach. Wypowiadał się też na temat czworonogów i ptaków, na temat płazów i ryb.
###### **1Krl 5,14**
 Wszystkie ludy przychodziły, by podziwiać mądrość Salomona. Wszyscy królowie świata słyszeli, jak mówiono o jego mądrości.
###### **1Krl 5,15**
 Hiram, król Tyru, wysłał swoje sługi do Salomona, gdyż dowiedział się, że został on namaszczony na króla po śmierci swego ojca. Hiram był bowiem zawsze przyjacielem Dawida.
###### **1Krl 5,16**
 Ze swej strony Salomon kazał powiedzieć Hiramowi:
###### **1Krl 5,17**
 Wiesz zapewne, że mój ojciec, Dawid, nie mógł zbudować świątyni dla imienia Jahwe, swojego Boga, gdyż był przez nieprzyjaciół nękany ciągłymi wojnami, które się zakończyły, kiedy Jahwe rzucił pod jego nogi wszystkich wrogów.
###### **1Krl 5,18**
 Teraz Jahwe, mój Bóg, darzy mnie ze wszystkich stron pokojem; nie mam żadnych przeciwników, żadnych spraw spornych.
###### **1Krl 5,19**
 Dlatego chciałbym teraz zacząć budować przybytek dla imienia Jahwe, mojego Boga, zgodnie z tym, co Jahwe, Bóg mój, powiedział do mojego ojca, Dawida: Przybytek dla mojego imienia zbuduje Mi twój syn, którego wprowadzę na twój tron po tobie.
###### **1Krl 5,20**
 Wydaj zatem teraz polecenie, żeby naścinano dla mnie cedrów na Libanie. Moi słudzy będą pracować z twoimi sługami, a ja tym ostatnim zapłacę za ich pracę, ile tylko zażądasz. Wiesz bowiem sam, że wśród nas nie ma nikogo, kto by się znał na ścinaniu drzew tak dobrze jak Sydończycy.
###### **1Krl 5,21**
 Hiram, usłyszawszy to, co powiedział Salomon, bardzo się ucieszył i rzekł: Niech będzie błogosławiony Jahwe, który dał Dawidowi tak mądrego syna, żeby panował nad tym wielkim narodem.
###### **1Krl 5,22**
 Ponadto kazał Hiram donieść Salomonowi: Czynię zadość twojej prośbie. Przyślę ci drewna, ile sobie życzysz, zarówno cedrowego, jak i cyprysowego.
###### **1Krl 5,23**
 Moi słudzy dostarczą je z Libanu nad brzeg morza, skąd każę ci je przesłać okrętami na miejsce, które wskażesz. Stamtąd po rozładunku będziesz mógł je zabrać, dokąd zechcesz. Za to ty zechciej spełnić moją prośbę i zaopatrzyć mój dom w żywność.
###### **1Krl 5,24**
 I dawał Hiram Salomonowi drewna cedrowego i cyprysowego tyle, ile chciał.
###### **1Krl 5,25**
 W zamian za to Salomon dawał Hiramowi co roku dwadzieścia tysięcy kor pszenicy oraz dwadzieścia kor tłoczonej oliwy.
###### **1Krl 5,26**
 A Jahwe darzył Salomona mądrością, tak jak mu to przyrzekł. Pokój panował też między Hiramem a Salomonem, gdyż zawarli oni ze sobą przymierze.
###### **1Krl 5,27**
 Zebrał też Salomon z całego Izraela wszystkich mężczyzn, zatrudnionych przy ciężkich robotach. Było takich robotników razem około trzydziestu tysięcy.
###### **1Krl 5,28**
 Wysyłał ich do Libanu, po dziesięć tysięcy co miesiąc, na zmianę: przebywali jeden miesiąc w Libanie i dwa miesiące u siebie w domu. Pieczę nad tymi robotnikami miał Adoniram.
###### **1Krl 5,29**
 Ponadto miał Salomon siedemdziesiąt tysięcy tragarzy do przenoszenia materiałów, a także osiemdziesiąt tysięcy kamieniarzy, którzy wydobywali w górach kamień [do budowy].
###### **1Krl 5,30**
 Prócz tego było trzy tysiące trzystu nadzorców, którzy z polecenia Salomona pilnowali przebiegu robót. Kierowali oni również ludźmi zatrudnionymi przy różnych pracach.
###### **1Krl 5,31**
 Polecił król wydobywać wielkie, najbardziej odpowiednie bloki kamienne i z kamieni specjalnie ociosanych układać fundamenty świątyni.
###### **1Krl 5,32**
 Budowniczowie Salomona i Hirama, wspomagani przez Giblitów, ciosali i przygotowywali drewno i kamienie potrzebne do budowy świątyni.
# 1Krl 5 WUJ
###### **1Krl 5,1**
 Posłał też Hiram król Tyru sługi swe do Salomona: bo słyszał, że go pomazano na królestwo miasto ojca jego: abo wiem Hiram był przyjacielem Dawidowi przez wszystek czas,
###### **1Krl 5,2**
 I posłał Salomon do Hiram, mówiąc:
###### **1Krl 5,3**
 Ty wiesz wolą Dawida ojca mego: a iż nie mógł budować domu imieniowi Pana Boga swego, przed walkami nalegającemi, w około, aż je dał Pan pod stopy nóg jego.
###### **1Krl 5,4**
 Lecz teraz dał mi Pan Bóg mój odpoczynienie zewsząd: i niemasz przeciwnika, ani zabiegu złego.
###### **1Krl 5,5**
 Przetoż myślę zbudować kościół imieniowi Pana Boga mego, jako mówił Pan Dawidowi ojcu memu, rzekąc: Syn twój, którego dam miasto siebie na stolicę twoję, ten zbuduje dom imieniowi memu.
###### **1Krl 5,6**
 A tak przykaż, że mi nawycinają słudzy twoi Cedru z Libanu, a słudzy moi niechaj będą z sługami twymi, a zapłatę sług twoich dam tobie którąkolwiek żądać będziesz: bo wiesz jako niemasz między ludem moim męża, któryby umiał drzewo wyrębować jako Sydończycy.
###### **1Krl 5,7**
 Gdy tedy usłyszał Hiram słowa Salomonowe, uradował się barzo, i rzekł: Błogosławiony Pan Bóg dzisia, który dał Dawidowi syna barzo mądrego nad ludem tym wielkim.
###### **1Krl 5,8**
 I posłał Hiram do Salomona, mówiąc: Słyszałem o cośkolwiek wskazał do mnie: ja uczynię wszystkę wolą twoję około drzewa Cedrowego, i Jodłowego.
###### **1Krl 5,9**
 Słudzy moi złożą je z Libanu do morza, a ja złożę je w tratfy na morzu, aż na miejsce, o którem mi dasz znać, i przypławię je tam, a ty je pobierzesz: i dodasz mi potrzeb, aby była dana żywność domowi memu.
###### **1Krl 5,10**
 A tak Hiram dodawał Salomonowi drzewa Cedrowego, i drzewa Jodłowego, według wszystkiej woli jego,
###### **1Krl 5,11**
 A Salomon dawał Hiram dwadzieścia tysięcy korcy pszenice na żywność domowi jego, i dwadzieścia korcy oliwy naczystszej: to dawał Salomon Hiram na każdy rok.
###### **1Krl 5,12**
 Dał też Pan mądrość Salomonowi, jako mu rzekł: i był pokój między Hiram i Salomonem, i uczynili obadwa przymierze,
###### **1Krl 5,13**
 I obrał Król Salomon robotniki ze wszego Izraeli, i było na trzydzieści tysięcy mężów.
###### **1Krl 5,14**
 I posyłał je na Liban, dziesięć tysięcy na każdy miesiąc na przemiany, tak że przez dwa miesiąca byli w domiech swoich: a nad tem nakazaniem przełożonym był Adoniram.
###### **1Krl 5,15**
 Miał też Salomon siedmdziesiąt tysięcy tych, co nosili brzemiona, a ośmdziesiąt tysięcy tych, którzy w górze łamali kamienie:
###### **1Krl 5,16**
 Oprócz przełożonych, którzy byli nad każdą robotą liczbą trzech tysięcy i trzechset, którzy rozkazowali ludzomm i tym co robili.
###### **1Krl 5,17**
 I przykazał król, żeby brali kamienie wielkie, kamienie kosztowne na fundament kościelny, i kwadrowali je:
###### **1Krl 5,18**
 Które ciosali murarze Salomonowi, i murarze Hiram, a Gibliowie nagotowali drzewa i kamienie na budowanie domu.
