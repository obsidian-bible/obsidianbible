# Ap 3 BT5
###### **Ap 3,1**
***Aniołowi Kościoła w Sardes napisz: To mówi Ten, co ma siedem Duchów Boga i siedem gwiazd: Znam twoje czyny: masz imię, [które mówi], że żyjesz, a jesteś umarły.***
###### **Ap 3,2**
***Stań się czujnym i umocnij resztę, która miała umrzeć, bo nie znalazłem twych czynów doskonałymi wobec mego Boga.***
###### **Ap 3,3**
***Pamiętaj więc, jak wziąłeś i usłyszałeś,[tak] strzeż tego i nawróć się! Jeśli więc czuwać nie będziesz, przyjdę jak złodziej, i nie poznasz, o której godzinie przyjdę do ciebie.***
###### **Ap 3,4**
***Lecz w Sardes masz kilka osób, co swoich szat nie splamiły; będą chodzić ze mną w bieli, bo godne są tego.***
###### **Ap 3,5**
***Tak szaty białe przywdzieje zwycięzca, i z księgi życia imienia jego nie wymażę. I wyznam imię jego przed moim Ojcem i Jego aniołami.***
###### **Ap 3,6**
***Kto ma uszy, niechaj posłyszy, co mówi Duch do Kościołów.***
###### **Ap 3,7**
***Aniołowi Kościoła w Filadelfii napisz: To mówi Święty, Prawdomówny, Ten, co ma klucz Dawida, Ten, co otwiera, a nikt nie zamknie, i Ten, co zamyka, a nikt nie otwiera.***
###### **Ap 3,8**
***Znam twoje czyny. Oto postawiłem jako dar przed tobą drzwi otwarte, których nikt nie może zamknąć, bo ty, chociaż moc masz znikomą, zachowałeś moje słowoi nie zaparłeś się mego imienia.***
###### **Ap 3,9**
***Oto Ja ci daję [ludzi] z synagogi szatana, spośród tych, którzy mówią o sobie, że są Żydami – a nie są nimi, lecz kłamią. Oto sprawię, iż przyjdą i padną na twarz do twych stóp, a poznają, że Ja cię umiłowałem.***
###### **Ap 3,10**
***Skoro zachowałeś naukę o mojej cierpliwości, i Ja cię zachowam od próby, która ma nadejść na cały obszar zamieszkany, by wypróbować mieszkańców ziemi.***
###### **Ap 3,11**
***Przyjdę niebawem: Trzymaj, co masz, by nikt twego wieńca nie zabrał!***
###### **Ap 3,12**
***Zwycięzcę uczynię filarem w świątyni Boga mojego, i już nie wyjdzie na zewnątrz. A na nim imię Boga mojego napiszęi imię miasta Boga mojego, Nowego Jeruzalem, co z nieba zstępuje od mego Boga, i moje nowe imię.***
###### **Ap 3,13**
***Kto ma uszy, niechaj posłyszy, co mówi Duch do Kościołów.***
###### **Ap 3,14**
***Aniołowi Kościoła w Laodycei napisz: To mówi Amen, Świadek wierny i prawdomówny, Początek stworzenia Bożego:***
###### **Ap 3,15**
***Znam twoje czyny, że ani zimny, ani gorący nie jesteś. Obyś był zimny albo gorący!***
###### **Ap 3,16**
***A tak, skoro jesteś letnii ani gorący, ani zimny, chcę cię wyrzucić z mych ust.***
###### **Ap 3,17**
***Ty bowiem mówisz: "Jestem bogaty" i "wzbogaciłem się", i "niczego mi nie potrzeba", a nie wiesz, że to ty jesteś nieszczęsny i godzien litości, i biedny, i ślepy, i nagi.***
###### **Ap 3,18**
***Radzę ci nabyć u mniezłota w ogniu oczyszczonego, abyś się wzbogacił, i białe szaty, abyś się przyodział, i by nie ujawniła się haniebna twa nagość, oraz balsamu do namaszczenia twych oczu, byś widział.***
###### **Ap 3,19**
***Ja wszystkich, których kocham, karcę i ćwiczę. Bądź więc gorliwy i nawróć się!***
###### **Ap 3,20**
***Oto stoję u drzwi i kołaczę:jeśli ktoś posłyszy mój głos i drzwi otworzy, wejdę do niego i będę z nim wieczerzał, a on ze Mną.***
###### **Ap 3,21**
***Zwycięzcy dam zasiąść ze Mną na moim tronie, jak i Ja zwyciężyłem i zasiadłem z mym Ojcem na Jego tronie.***
###### **Ap 3,22**
***Kto ma uszy, niechaj posłyszy, co mówi Duch do Kościołów***».
# Ap 3 PAU
###### **Ap 3,1**
 Aniołowi Kościoła w Sardach napisz: To mówi Ten, który ma siedem Duchów Boga i siedem gwiazd: Znam twoje czyny. Masz imię, które mówi, że żyjesz, lecz jesteś martwy.
###### **Ap 3,2**
 Bądź czujny! Umocnij też innych, którzy są bliscy śmierci. Nie uznałem bowiem twoich czynów za doskonałe przed moim Bogiem.
###### **Ap 3,3**
 Przypomnij więc sobie, co otrzymałeś i usłyszałeś. Przestrzegaj tego i zmień swoje postępowanie! Jeśli nie będziesz czuwał, przyjdę jak złodziej. Nawet nie będziesz wiedział, o której godzinie do ciebie przyjdę.
###### **Ap 3,4**
 Jest jednak w Sardach kilka osób, które nie splamiły swoich szat i będą chodziły ze mną w bieli, bo są tego godne.
###### **Ap 3,5**
 Także zwycięzca będzie nosił białe szaty i nie wymażę jego imienia z księgi życia. Imię jego wyznam przed moim Ojcem i przed Jego aniołami.
###### **Ap 3,6**
 Kto ma uszy, niech słucha, co Duch mówi do Kościołów.
###### **Ap 3,7**
 Aniołowi Kościoła w Filadelfii napisz: To mówi Święty, Prawdziwy, który ma klucz Dawida, który otwiera, a nikt nie może zamknąć i który zamyka, a nikt nie może otworzyć.
###### **Ap 3,8**
 Znam twoje czyny. Oto zostawiłem ci otwarte drzwi, których nikt nie może zamknąć, bo mimo słabych sił strzegłeś mojego słowa i nie wyparłeś się mojego imienia.
###### **Ap 3,9**
 Oto wydam ci tych z synagogi szatana, którzy nazywają siebie Żydami, lecz kłamią, bo nimi nie są. Oto sprawię, że przyjdą i upadną do twoich stóp, i poznają, że Ja ciebie umiłowałem.
###### **Ap 3,10**
 Ponieważ wytrwale strzegłeś mojego słowa, Ja też będę cię strzegł w godzinie próby, która dosięgnie całą ludzkość i wypróbuje mieszkańców ziemi.
###### **Ap 3,11**
 Przyjdę wkrótce. Trzymaj mocno to, co posiadasz, aby nikt ci nie zabrał twego wieńca.
###### **Ap 3,12**
 Zwycięzcę uczynię filarem w świątyni mojego Boga i już nie wyjdzie na zewnątrz. Wypiszę też na nim imię mego Boga i imię miasta mego Boga, nowego Jeruzalem zstępującego z nieba od mego Boga, oraz moje nowe imię.
###### **Ap 3,13**
 Kto ma uszy, niech słucha, co Duch mówi do Kościołów.
###### **Ap 3,14**
 Aniołowi Kościoła w Laodycei napisz: To mówi Amen, wierny i prawdziwy świadek, początek Bożego stworzenia.
###### **Ap 3,15**
 Znam twoje czyny: nie jesteś ani zimny, ani gorący. Obyś był zimny albo gorący!
###### **Ap 3,16**
 Skoro jednak jesteś letni, a nie zimny ani gorący, wypluję cię z moich ust.
###### **Ap 3,17**
 Mówisz: «Jestem bogaty, wzbogaciłem się, niczego nie potrzebuję!». Nie wiesz jednak, że jesteś nędzny, godny pożałowania, biedny, ślepy i nagi.
###### **Ap 3,18**
 Radzę ci, kup u Mnie złota oczyszczonego w ogniu, aby się wzbogacić, i białe szaty, aby się ubrać i nie musieć się wstydzić swojej nagości, oraz balsam do namaszczenia twych oczu, aby przejrzeć.
###### **Ap 3,19**
 Ja tych, których kocham, upominam i karcę. Bądź więc gorliwy i popraw się!
###### **Ap 3,20**
 Oto stoję przed drzwiami i pukam. Jeśli ktoś usłyszy mój głos i otworzy Mi drzwi, wejdę do niego i spożyjemy wieczerzę: Ja z nim, a on ze Mną.
###### **Ap 3,21**
 Zwycięzcy pozwolę zasiąść ze Mną na tronie, gdyż i Ja po zwycięstwie zasiadłem na tronie z moim Ojcem.
###### **Ap 3,22**
 Kto ma uszy, niech słucha, co Duch mówi do Kościołów”.
# Ap 3 BP
###### **Ap 3,1**
 Aniołowi Kościoła w Sardach napisz: To mówi ten, co ma siedem Duchów Boga i siedem gwiazd: Znam twoje czyny - masz imię [które mówi], że żyjesz, a jesteś umarły.
###### **Ap 3,2**
 Stań się czujny i umocnij resztę, która miała umrzeć, bo nie uznałem twoich uczynków za doskonałe wobec Boga mojego.
###### **Ap 3,3**
 Pamiętaj więc, jak wziąłeś i usłyszałeś, strzeż się tego i nawróć się! Jeśli więc czuwać nie będziesz, przyjdę jak złodziej, i nie będziesz wiedział, o której godzinie przyjdę do ciebie.
###### **Ap 3,4**
 Lecz w Sardach masz kilka osób, które swoich szat nie splamiły i będą chodzić za mną w bieli, bo godni są.
###### **Ap 3,5**
 Tak szaty białe przywdzieje zwycięzca i z księgi życia imienia jego nie wymażę. I wyznam imię jego przed moim Ojcem i Jego aniołami.
###### **Ap 3,6**
 Kto ma uszy, nich usłyszy, co mówi Duch do Kościołów.
###### **Ap 3,7**
 Aniołowi Kościoła w Filadelfii napisz: To mówi Święty, Prawdomówny, który ma klucz Dawida, ten, co otwiera, a nikt nie może zamknąć, i co zamyka, a nikt nie może otworzyć:
###### **Ap 3,8**
 Znam twoje czyny. Oto postawiłem jako dar przed tobą drzwi otwarte, których nikt nie może zamknąć, bo ty, chociaż moc masz znikomą, zachowałeś moje słowo i nie wyparłeś się mego imienia.
###### **Ap 3,9**
 Oto Ja ci daję [ludzi] z synagogi szatana, spośród tych, którzy mówią o sobie, że są Żydami - a nie są nimi, lecz kłamią. Oto sprawię, że przyjdą i padną na twarz u twoich stóp, a poznają, że Ja umiłowałem ciebie.
###### **Ap 3,10**
 Skoro bowiem zachowałeś nakaz mojej wytrwałości i Ja ciebie zachowam od godziny próby, która ma przyjść na cały obszar zamieszkany, by wypróbować tych, co mieszkają na ziemi.
###### **Ap 3,11**
 Przyjdę niebawem: Trzymaj, co masz, by nikt nie odebrał ci wieńca!
###### **Ap 3,12**
 Zwycięzcę uczynię filarem w świątyni Boga mojego i już nie wyjdzie na zewnątrz. I napiszę na nim imię Boga mojego i imię miasta Boga mojego, Nowego Jeruzalem, co z nieba zstępuje od mego Boga, i moje nowe imię,
###### **Ap 3,13**
 Kto ma uszy, niech usłyszy, co mówi Duch do Kościołów.
###### **Ap 3,14**
 Aniołowi kościoła w Laodycei napisz: To mówi Amen. Świadek wierny i prawdomówny, Początek stworzenia Bożego:
###### **Ap 3,15**
 Znam twoje czyny, że nie jesteś zimny ani gorący. Obyś był zimny albo gorący!
###### **Ap 3,16**
 A tak, skoro jesteś letni i ani gorący, ani zimny, mam cię wyrzucić z moich ust.
###### **Ap 3,17**
 Ty bowiem mówisz: "jestem bogaty" i "wzbogaciłem się", i "niczego mi nie potrzeba", a nie wiesz, że to ty jesteś nieszczęsny i godzien litości, i biedny, i ślepy, i nagi.
###### **Ap 3,18**
 Radzę ci kupić u mnie złota w ogniu oczyszczonego, abyś się wzbogacił, i białe szaty, abyś się odział, i aby nie widziano twojej haniebnej nagości, i balsamu do namaszczenia twoich oczu, abyś przejrzał.
###### **Ap 3,19**
 Ja wszystkich, których kocham, karcę i wychowuję. Bądź więc gorliwy i nawróć się.
###### **Ap 3,20**
 Oto stoję u drzwi i kołaczę: jeśli kto usłyszy mój głos i drzwi otworzy, wejdę do niego i będę z nim wieczerzał, a on ze mną.
###### **Ap 3,21**
 Zwycięzcy dam zasiąść ze sobą na moim tronie, jak i Ja zwyciężyłem i zasiadłem z mym Ojcem na Jego tronie.
###### **Ap 3,22**
 Kto ma uszy, niech usłyszy, co mówi Duch do Kościołów.
# Ap 3 BR
###### **Ap 3,1**
 Aniołowi Kościoła w Sardach napisz tak: To mówi Ten, który ma siedem Duchów Boga i siedem gwiazd. Wiem o twoich poczynaniach. Co prawda mówi się o tobie, że żyjesz; ale ty jesteś umarły.
###### **Ap 3,2**
 Ocknij się i umacniaj tych nielicznych, którzy jeszcze przetrwali, lecz grozi im niebezpieczeństwo. Widzę bowiem, że twoje postępowanie nie zasługuje na pochwałę w oczach Boga.
###### **Ap 3,3**
 Przypomnij sobie tedy naukę, którą [sam] otrzymałeś i o której słyszałeś. Strzeż jej, nawróć się [ku dobremu]. A jeśli nie będziesz czuwał, przyjdę [niespodziewanie] jak złodziej i wcale nie będziesz wiedział, o której godzinie do ciebie przyjdę.
###### **Ap 3,4**
 Lecz jest u ciebie w Sardach kilka osób, które nie zbrukały [grzechem] szaty swojej duszy. One to będą chodzić za Mną w swej bieli, gdyż są tego godne.
###### **Ap 3,5**
 Takie też białe szaty przywdzieją ci, którzy przetrwają [wszystko] zwycięsko. Ich imion nie wymażę z księgi życia, a przyznam się do nich przed moim Ojcem i przed Jego aniołami.
###### **Ap 3,6**
 Kto ma uszy do słuchania, niech słucha, co mówi Duch do Kościołów.
###### **Ap 3,7**
 Aniołowi Kościoła w Filadelfii napisz tak: To mówi Święty, Prawdomówny, Ten, który ma klucz Dawida; gdy On otwiera, to nikt nie zamknie, a gdy zamknie, nikt nie otworzy.
###### **Ap 3,8**
 Znane mi są twoje uczynki. Oto zostawiłem przed tobą drzwi otwarte i [dzięki tobie] nikt nie może ich zamknąć, bo choć nie posiadasz wielkiej władzy, to jednak zachowałeś moje słowo i nie zaparłeś się mojego imienia.
###### **Ap 3,9**
 Przekazuję ci ludzi ze społeczności szatańskiej, tych, którzy podają się za Żydów, a w rzeczywistości nie są Żydami, lecz zwykłymi kłamcami. Otóż sprawię to, że przyjdą do ciebie, padną ci do nóg i przekonają się, że Ja cię umiłowałem.
###### **Ap 3,10**
 Ponieważ usłuchałeś Mnie i wytrwałeś wiernie przy moich przykazaniach, przeto i Ja zachowam cię w godzinę próby, która przyjdzie na całą ziemię, by wypróbować wszystkich jej mieszkańców.
###### **Ap 3,11**
 Przyjdę już niebawem. Pilnuj tego, co masz, by nikt nie zabrał ci twego wieńca.
###### **Ap 3,12**
 Kto przejdzie zwycięsko przez wszystkie próby, tego uczynię kolumną w świątyni Boga mojego i już nie wyjdzie na zewnątrz. I wypiszę na niej imię Boga mojego oraz nazwę miasta Boga mojego, nowego Jeruzalem, które zstępuje z nieba od Boga mojego i moje własne nowe imię.
###### **Ap 3,13**
 Kto ma uszy do słuchania, niech słucha, co mówi Duch do Kościołów.
###### **Ap 3,14**
 Aniołowi Kościoła w Laodycei napisz tak: To mówi Amen, świadek wierny i prawdomówny, Ten, który jest Początkiem stworzenia Bożego.
###### **Ap 3,15**
 Znam twoje dzieła; wiem, żeś ani zimny, ani gorący. Obyś wreszcie był albo zimny, albo gorący!
###### **Ap 3,16**
 Ponieważ jednak jesteś letni, a nie zimny ani gorący, muszę cię wyrzucić z ust moich.
###### **Ap 3,17**
 Chlubisz się tym, że jesteś bogaty, że nadal się wzbogacasz, że nie brak ci niczego, a nigdy nie pomyślaleś o tym, że w rzeczywistości jesteś nieszczęśliwy, godny politowania, biedny, ślepy i nagi.
###### **Ap 3,18**
 Radziłbym ci kupić sobie u Mnie złota oczyszczonego w ogniu, byś mógł stać się naprawdę bogatym; radzę ci nabyć sobie białe szaty, byś mógł okryć nimi hańbę swojej nagości; kup sobie również balsamu do namaszczenia twoich oczu, abyś mógł widzieć.
###### **Ap 3,19**
 Upominam i karcę tych wszystkich, których kocham. Bądź tedy gorliwy i opamiętaj się!
###### **Ap 3,20**
 Oto stoję u drzwi i stukam. Jeżeli kto zechce usłyszeć mój głos i otworzy drzwi, wejdę do niego i spożyję wieczerzę, Ja z nim, a on ze Mną.
###### **Ap 3,21**
 Temu, kto zwycięży wszystko, pozwolę zasiąść na moim tronie, tak jak Ja, odniósłszy zwycięstwo, zasiadłem razem z mym Ojcem na Jego tronie.
###### **Ap 3,22**
 Kto ma uszy do słuchania, niech słucha, co mówi Duch do Kościołów.
# Ap 3 WUJ
###### **Ap 3,1**
 Aniołowi kościoła Sardyjskiego, napisz: To mówi, który ma siedm Duchów Bożych, i siedm gwiazd: Znam uczynki twoje, iż masz imię, że żywiesz, aleś jest umarły.
###### **Ap 3,2**
 Bądź czujny, a utwierdzaj inne co umrzeć miało. Abowiem nie najduję uczynków twoich zupełnych przed Bogiem moim.
###### **Ap 3,3**
 Pamiętaj tedy jakoś wziął i słyszał, a chowaj, i pokutę czyń. Jesliż tedy czuć nie będziesz, przydę do ciebie jako złodziej, a nie poznasz, której godziny przydę do ciebie.
###### **Ap 3,4**
 Ale masz mało imion w Sardziech, którzy niepokalali szat swoich: i chodzić będą zemną w bieli, iż godni są.
###### **Ap 3,5**
 Kto zwycięży, tak będzie obleczon w szaty białe, i nie wymażę imienia jego z ksiąg żywota, i wyznam imię jego przed Ojcem moim, i przed anioły jego.
###### **Ap 3,6**
 Kto ma ucho, niech słucha, co Duch kościołom mówi.
###### **Ap 3,7**
 A aniołowi kościoła Philadelphskiego napisz: To mówi Święty i Prawdziwy, który ma klucz Dawidów: który otwiera, a żaden nie zawiera: zawiera, a żaden nie otwiera.
###### **Ap 3,8**
 Wiem uczynki twoje. Otom dał przed tobą drzwi otworzone, których żaden nie może zamknąć: iż masz małą moc, i zachowałeś słowo moje, i nie zaprzałeś się imienia mojego.
###### **Ap 3,9**
 Oto dam zbóżnice szatańskiej, co się powiadają być Żydami, a nie są, ale kłamają. Oto uczynię im, iżby przyszli, i pokłonili się przed nogami twemi: i poznają, iżem ja ciebie umiłował.
###### **Ap 3,10**
 Iżeś zachował słowo cierpliwości mojej: a ja ciebie zachowam od godziny pokuszenia, która przyść ma na wszystek świat kusić mieszkające na ziemi.
###### **Ap 3,11**
 Oto idę rychło: trzymaj co masz, aby żaden nie wziął korony twojej.
###### **Ap 3,12**
 Kto zwycięży, uczynię go słupem w kościele Boga mego: a więcej z niego nie wynidzie: i napiszę na nim imię Boga mego, i imię miasta Boga mego nowego Jeruzalem, które zstępuje z nieba od Boga mego, i imię moje nowe.
###### **Ap 3,13**
 Kto ma ucho, niechaj słucha co Duch mówi kościołom.
###### **Ap 3,14**
 A aniołowi kościoła Laodyckiego napisz. To mówi Amen, świadek wierny i prawdziwy, który jest początkiem stworzenia Bożego.
###### **Ap 3,15**
 Znam sprawy twoje, iżeś nie jest ani zimy, ani gorący: bodajbyś był zimny, abo gorący.
###### **Ap 3,16**
 Ale iżeś letny, a ani zimny ani gorący: pocznę cię wyrzucać z ust moich.
###### **Ap 3,17**
 Iż mówisz: Żem jest bogaty i zbogacony, a niczego nie potrzebuję: a nie wiesz, iżeś ty nędzny, i mizerny, i ubogi, i ślepy, i nagi.
###### **Ap 3,18**
 Radzęć, abyś sobie kupił u mnie złota w ogniu doświadczonego, żebyś się zbogacił: i szaty białe oblókł, aby się nie okazowała sromota nagości twojej: a namaż maścią na oczy twoje, abyś widział.
###### **Ap 3,19**
 Ja, które miłuję, strofuję i karzę. Bądź tedy żarliwym, a pokutuj.
###### **Ap 3,20**
 Oto stoję u drzwi i kołące: jeśliby kto usłyszał głos mój, i otworzył mi drzwi, wnijdę do niego, i będę z nim wieczerzał, a on zemną.
###### **Ap 3,21**
 Kto zwycięży, dam mu siedzieć z sobą na stolicy mojej: jakom ja też zwyciężył, i usiadłem z Ojcem moim na stolicy jego.
###### **Ap 3,22**
 Kto ma ucho, niechaj słucha co Duch kościołom mówi.
# Ap 3 STERN
###### **Ap 3,1**
 Aniołowi wspólnoty mesjanicznej w Sardis napisz: "Oto wiadomość od Tego, który ma siedmiorakiego Ducha Bożego i siedem gwiazd: 'Znam twoje poczynania - jesteś znany z tego, że żyjesz, ale w rzeczywistości jesteś martwy!
###### **Ap 3,2**
 Obudź się i umocnij to, co pozostało, zanim i to umrze! Bo przekonałem się, że twoje poczynania nie są doskonałe w oczach mojego Boga.
###### **Ap 3,3**
 Pamiętaj więc, co otrzymałeś i usłyszałeś, i zachowuj to, i odwróć się od swojego grzechu! Bo jeśli się nie obudzisz, przyjdę jak złodziej, a nie znasz chwili, w której przyjdę do ciebie.
###### **Ap 3,4**
 Mimo to masz w Sardis nieco ludzi, którzy nie pobrudzili swoich szat, i oni będą chodzić ze mną, odziani w biel, bo są godni.
###### **Ap 3,5**
 Ten, kto zwycięży, będzie tak jak oni odziany w białe szaty i nie wymażę jego imienia z Księgi Życia, a nawet uznam go imiennie przed moim Ojcem i przed Jego aniołami.
###### **Ap 3,6**
 Ci, którzy mają uszy, niech usłyszą, co mówi Duch do wspólnot mesjanicznych'".
###### **Ap 3,7**
 Aniołowi wspólnoty mesjanicznej w Filadelfii napisz: "Oto wiadomość od Ha-Kadosz, Wiernego, Tego, który ma klucz Dawida, który jeśli coś otworzy, nikt inny tego nie zamknie, a jeśli coś zamknie, nikt inny tego nie otworzy:
###### **Ap 3,8**
 'Znam twoje poczynania. Wiedz, że postawiłem przed tobą otwarte drzwi i nikt nie może ich zamknąć. Wiem, że mocy masz niewiele, ale zachowałeś moje posłanie i nie zaparłeś się mnie.
###### **Ap 3,9**
 Oto dam ci niektórych z synagogi Przeciwnika, tych, którzy nazywają siebie Żydami, ale nimi nie są - przeciwnie, kłamią - otóż sprawię, że przyjdą i padną u twoich stóp, i poznają, że ja cię ukochałem.
###### **Ap 3,10**
 Ponieważ zachowałeś moje orędzie o wytrwaniu, ja zachowam ciebie od czasu próby nadchodzącego na cały świat, aby wypróbować mieszkańców ziemi.
###### **Ap 3,11**
 Nadchodzę wkrótce, trzymaj się tego, co masz, tak aby nikt nie odebrał ci korony.
###### **Ap 3,12**
 Tego, kto zwycięży, uczynię filarem w Świątyni mojego Boga i nigdy jej nie opuści. Wypiszę też na nim imię mojego Boga i nazwę miasta mojego Boga, nowego Jeruszalaim, zstępującego z nieba od mojego Boga, i moje własne nowe imię.
###### **Ap 3,13**
 Ci, którzy mają uszy, niech usłyszą, co mówi Duch do wspólnot mesjanicznych'".
###### **Ap 3,14**
 Aniołowi wspólnoty mesjanicznej w Laodycei napisz: "Oto wiadomość od Amen, świadka wiernego i prawdziwego, Władcy stworzenia Bożego:
###### **Ap 3,15**
 'Znam twoje poczynania: nie jesteś ani zimny, ani gorący. Jaka szkoda, że nie jesteś ani taki, ani taki!
###### **Ap 3,16**
 Ale ponieważ jesteś letni, ani zimny, ani gorący, wypluję cię z Mych ust!
###### **Ap 3,17**
 Bo ciągle powtarzasz: "Jestem bogaty, wzbogaciłem się, niczego nie potrzebuję!"". Nie wiesz, że to ty jesteś nieszczęsny, pożałowania godny, biedny, ślepy i goły!
###### **Ap 3,18**
 Radzę ci, żebyś kupił u mnie złota oczyszczonego w ogniu, abyś był bogaty, i białe odzienie, abyś był ubrany i nie musiał wstydzić się swej nagości, i maści do oczu, abyś przetarł swoje oczy i przejrzał.
###### **Ap 3,19**
 Co do mnie zaś, karcę i utrzymuję w karności każdego, kogo kocham, dołóż więc starań i odwróć się od swych grzechów.
###### **Ap 3,20**
 Oto stoję u drzwi i pukam. Jeśli ktoś usłyszy mój głos i otworzy drzwi, wejdę do niego i zasiądę z nim do stołu, a on zasiądzie do stołu ze mną.
###### **Ap 3,21**
 Temu, kto zwycięży, pozwolę zasiąść ze mną na moim tronie, tak jak i ja zwyciężyłem i zasiadłem z moim Ojcem na Jego tronie.
###### **Ap 3,22**
 Ci, którzy mają uszy, niech usłyszą, co mówi Duch do wspólnot mesjanicznych'"".
# Ap 3 TRO
###### **Ap 3,1**
 **και** *kai* A [[G2532]] [[CONJ]] **τω** *tō* [[G3588]] WTT-DSM **αγγελω** *angelō* zwiastunowi [[G32]] WTN-DSM **της** *tēs* [[G3588]] [[T-GSF]] **εν** *en* w [[G1722]] [[PREP]] **σαρδεσιν** *sardesin* Sardes [[G4554]] WTN-DPF **εκκλησιας** *ekklēsias* zgromadzenia – (społeczności) wywołanych [[G1577]] [[N-GSF]] **γραψον** *grapson* napisz [[G1125]] WTV-AAM-2S **ταδε** *tade* to [[G3592]] WTD-APN **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **εχων** *echōn* mający [[G2192]] [[V-PAP-NSM]] **τα** *ta* [[G3588]] WTT-APN **επτα** *hepta* siedem [[G2033]] WTA-NUI **πνευματα** *pneumata* duchów [[G4151]] WTN-APN **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **τους** *tous* [[G3588]] WTT-APM **επτα** *hepta* siedem [[G2033]] WTA-NUI **αστερας** *asteras* gwiazd [[G792]] [[N-APM]] **οιδα** *oida* znam [[G1492]] WTV-RAI-1S **σου** *sou* twoje [[G4675]] WTP-2GS **τα** *ta* [[G3588]] WTT-APN **εργα** *erga* czyny – dzieła [[G2041]] WTN-APN **οτι** *hoti* że [[G3754]] [[CONJ]] **το** *to* [[G3588]] WTT-ASN **ονομα** *onoma* imię [[G3686]] WTN-ASN **εχεις** *echeis* masz [[G2192]] WTV-PAI-2S **οτι** *hoti* że [[G3754]] [[CONJ]] **ζης** *zēs* żyjesz [[G2198]] WTV-PAI-2S **και** *kai* a [[G2532]] [[CONJ]] **νεκρος** *nekros* martwy [[G3498]] [[A-NSM]] **ει** *ei* jesteś [[G1488]] WTV-PXI-2S
###### **Ap 3,2**
 **γινου** *ginou* Stawaj się [[G1096]] WTV-PNM-2S **γρηγορων** *grēgorōn* czuwający [[G1127]] [[V-PAP-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **στηριξον** *stērikson* utwierdź – postaw mocno [[G4741]] WTV-AAM-2S **τα** *ta* [[G3588]] WTT-APN **λοιπα** *loipa* pozostałe [[G3062]] WTA-APN **α** *ha* które [[G3739]] WTR-APN **μελλει** *mellei* mają [[G3195]] WTV-PAI-3S **αποθανειν** *apothanein* umrzeć [[G599]] [[V-2AAN]] **ου** *ou* nie [[G3756]] [[PRT-N]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ευρηκα** *heurēka* znalazłem [[G2147]] WTV-RAI-1S **σου** *sou* twoich [[G4675]] WTP-2GS **τα** *ta* [[G3588]] WTT-APN **εργα** *erga* czynów – dzieł [[G2041]] WTN-APN **πεπληρωμενα** *peplērōmena* które są dopełnione – które są wypełnione [[G4137]] WTV-RPP-APN **ενωπιον** *enōpion* przed – wobec oblicza [[G1799]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Bogiem [[G2316]] [[N-GSM]]
###### **Ap 3,3**
 **μνημονευε** *mnēmoneue* Pamiętaj – Przypominaj sobie [[G3421]] WTV-PAM-2S **ουν** *oun* więc [[G3767]] [[CONJ]] **πως** *pōs* jak [[G4459]] [[ADV]] **ειληφας** *eilēfas* wziąłeś [[G2983]] WTV-RAI-2S **και** *kai* i [[G2532]] [[CONJ]] **ηκουσας** *ēkousas* usłyszałeś [[G191]] WTV-AAI-2S **και** *kai* i [[G2532]] [[CONJ]] **τηρει** *tērei* zachowuj – strzeż [[G5083]] WTV-PAM-2S **και** *kai* i [[G2532]] [[CONJ]] **μετανοησον** *metanoēson* opamiętaj się – zmień myślenie [[G3340]] WTV-AAM-2S **εαν** *ean* jeśli [[G1437]] WTCOND **ουν** *oun* więc [[G3767]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **γρηγορησης** *grēgorēsēs* czuwałbyś [[G1127]] WTV-AAS-2S **ηξω** *hēksō* przyjdę [[G2240]] WTV-FAI-1S **επι** *epi* na [[G1909]] [[PREP]] **σε** *se* ciebie [[G4571]] WTP-2AS **ως** *hōs* jak [[G5613]] [[ADV]] **κλεπτης** *kleptēs* złodziej – kradnący [[G2812]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **μη** *mē* [[G3361]] [[PRT-N]] **γνως** *gnōs* wiedziałbyś – poznałbyś [[G1097]] WTV-2AAS-2S **ποιαν** *poian* jakiej [[G4169]] WTI-ASF **ωραν** *hōran* godziny [[G5610]] WTN-ASF **ηξω** *hēksō* przyjdę [[G2240]] WTV-FAI-1S **επι** *epi* na [[G1909]] [[PREP]] **σε** *se* ciebie [[G4571]] WTP-2AS
###### **Ap 3,4**
 **εχεις** *echeis* Masz [[G2192]] WTV-PAI-2S **ολιγα** *oliga* trochę [[G3641]] WTA-APN **ονοματα** *onomata* imion [[G3686]] WTN-APN **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **σαρδεσιν** *sardesin* Sardes [[G4554]] WTN-DPF **α** *ha* które [[G3739]] WTR-APN **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εμολυναν** *emolynan* splamiły [[G3435]] WTV-AAI-3P **τα** *ta* [[G3588]] WTT-APN **ιματια** *himatia* szat – płaszczy [[G2440]] WTN-APN **αυτων** *autōn* ich [[G846]] WTP-GPN **και** *kai* i [[G2532]] [[CONJ]] **περιπατησουσιν** *peripatēsousin* będą chodzić [[G4043]] WTV-FAI-3P **μετ** *met* ze [[G3326]] [[PREP]] **εμου** *emou* Mną [[G1700]] WTP-1GS **εν** *en* w [[G1722]] [[PREP]] **λευκοις** *leukois* białych [[G3022]] WTA-DPN **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **αξιοι** *aksioi* godni [[G514]] WTA-NPM **εισιν** *eisin* są [[G1526]] WTV-PXI-3P
###### **Ap 3,5**
 **ο** *ho* [[G3588]] [[T-NSM]] **νικων** *nikōn* Zwyciężający [[G3528]] [[V-PAP-NSM]] **ουτος** *houtos* ten [[G3778]] WTD-NSM **περιβαλειται** *peribaleitai* okryje się – odzieje się [[G4016]] WTV-FMI-3S **εν** *en* w [[G1722]] [[PREP]] **ιματιοις** *himatiois* szaty – płaszcze [[G2440]] WTN-DPN **λευκοις** *leukois* białe [[G3022]] WTA-DPN **και** *kai* i [[G2532]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **μη** *mē* [[G3361]] [[PRT-N]] **εξαλειψω** *eksaleipsō* wymażę – zetrę [[G1813]] WTV-FAI-1S **το** *to* [[G3588]] WTT-ASN **ονομα** *onoma* imienia [[G3686]] WTN-ASN **αυτου** *autou* jego [[G846]] [[P-GSM]] **εκ** *ek* ze [[G1537]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **βιβλου** *biblou* zwoju – księgi [[G976]] [[N-GSF]] **της** *tēs* [[G3588]] [[T-GSF]] **ζωης** *zōēs* życia [[G2222]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **εξομολογησομαι** *eksomologēsomai* wyznam [[G1843]] WTV-FMI-1S **το** *to* [[G3588]] WTT-ASN **ονομα** *onoma* imię [[G3686]] WTN-ASN **αυτου** *autou* jego [[G846]] [[P-GSM]] **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **πατρος** *patros* Ojcem [[G3962]] [[N-GSM]] **μου** *mou* moim [[G3450]] WTP-1GS **και** *kai* i [[G2532]] [[CONJ]] **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **των** *tōn* [[G3588]] WTT-GPM **αγγελων** *angelōn* zwiastunami [[G32]] WTN-GPM **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Ap 3,6**
 **ο** *ho* [[G3588]] [[T-NSM]] **εχων** *echōn* Mający [[G2192]] [[V-PAP-NSM]] **ους** *ous* ucho [[G3775]] WTN-ASN **ακουσατω** *akousatō* niech usłyszy [[G191]] WTV-AAM-3S **τι** *ti* co [[G5101]] WTI-ASN **το** *to* [[G3588]] WTT-NSN **πνευμα** *pneuma* Duch [[G4151]] WTN-NSN **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **ταις** *tais* [[G3588]] WTT-DPF **εκκλησιαις** *ekklēsiais* zgromadzeniom – (społecznościom) wywołanych [[G1577]] WTN-DPF
###### **Ap 3,7**
 **και** *kai* A [[G2532]] [[CONJ]] **τω** *tō* [[G3588]] WTT-DSM **αγγελω** *angelō* zwiastunowi [[G32]] WTN-DSM **της** *tēs* [[G3588]] [[T-GSF]] **εν** *en* w [[G1722]] [[PREP]] **φιλαδελφεια** *filadelfeia* Filadelfii – [kochać braci] [[G5359]] [[N-DSF]] **εκκλησιας** *ekklēsias* zgromadzenia – (społeczności) wywołanych [[G1577]] [[N-GSF]] **γραψον** *grapson* napisz [[G1125]] WTV-AAM-2S **ταδε** *tade* to [[G3592]] WTD-APN **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **αγιος** *hagios* Święty [[G40]] [[A-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **αληθινος** *alēthinos* Prawdziwy [[G228]] [[A-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **εχων** *echōn* mający [[G2192]] [[V-PAP-NSM]] **την** *tēn* [[G3588]] WTT-ASF **κλειδα** *kleida* klucz [[G2807]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **δαβιδ** *dabid* Dawida – [umiłowany] [[G1138]] [[N-PRI]] **ο** *ho* [[G3588]] [[T-NSM]] **ανοιγων** *anoigōn* otwierający [[G455]] [[V-PAP-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ουδεις** *oudeis* nikt [[G3762]] [[A-NSM]] **κλειει** *kleiei* zamyka [[G2808]] WTV-PAI-3S **και** *kai* a [[G2532]] [[CONJ]] **κλειει** *kleiei* zamyka [[G2808]] WTV-PAI-3S **και** *kai* i [[G2532]] [[CONJ]] **ουδεις** *oudeis* nikt [[G3762]] [[A-NSM]] **ανοιγει** *anoigei* otwiera [[G455]] WTV-PAI-3S
###### **Ap 3,8**
 **οιδα** *oida* Znam [[G1492]] WTV-RAI-1S **σου** *sou* twoje [[G4675]] WTP-2GS **τα** *ta* [[G3588]] WTT-APN **εργα** *erga* czyny – dzieła [[G2041]] WTN-APN **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **δεδωκα** *dedōka* dałem [[G1325]] WTV-RAI-1S **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **σου** *sou* tobą [[G4675]] WTP-2GS **θυραν** *thyran* drzwi [[G2374]] WTN-ASF **ανεωγμενην** *aneōgmenēn* które jest otworzone (które są otworzone) [[G455]] WTV-RPP-ASF **και** *kai* i [[G2532]] [[CONJ]] **ουδεις** *oudeis* nikt [[G3762]] [[A-NSM]] **δυναται** *dynatai* może [[G1410]] WTV-PNI-3S **κλεισαι** *kleisai* zamknąć [[G2808]] [[V-AAN]] **αυτην** *autēn* je [[G846]] [[P-ASF]] **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **μικραν** *mikran* małą [[G3398]] WTA-ASF **εχεις** *echeis* masz [[G2192]] WTV-PAI-2S **δυναμιν** *dynamin* moc [[G1411]] WTN-ASF **και** *kai* a [[G2532]] [[CONJ]] **ετηρησας** *etērēsas* zachowałeś – strzegłeś [[G5083]] WTV-AAI-2S **μου** *mou* moje [[G3450]] WTP-1GS **τον** *ton* [[G3588]] [[T-ASM]] **λογον** *logon* Słowo [[G3056]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ηρνησω** *ērnēsō* wyparłeś się – odrzuciłeś [[G720]] WTV-ADI-2S **το** *to* [[G3588]] WTT-ASN **ονομα** *onoma* imienia [[G3686]] WTN-ASN **μου** *mou* mojego [[G3450]] WTP-1GS
###### **Ap 3,9**
 **ιδου** *idou* Oto [[G2400]] WTV-2AAM-2S **διδωμι** *didōmi* daję [[G1325]] WTV-PAI-1S **εκ** *ek* ze [[G1537]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **συναγωγης** *synagōgēs* zgromadzenia – synagogi [[G4864]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **σατανα** *satana* szatana – [przeciwnik] [[G4567]] [[N-GSM]] **των** *tōn* (z) [[G3588]] WTT-GPM **λεγοντων** *legontōn* mówiących [[G3004]] WTV-PAP-GPM **εαυτους** *heautous* sobie samym [[G1438]] WTF-3APM **ιουδαιους** *ioudaious* Judejczykami – [wielbić] [[G2453]] WTA-APM **ειναι** *einai* być [[G1511]] WTV-PXN **και** *kai* a [[G2532]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **αλλα** *alla* ale [[G235]] [[CONJ]] **ψευδονται** *pseudontai* kłamią [[G5574]] WTV-PEI-3P **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **ποιησω** *poiēsō* uczynię [[G4160]] WTV-FAI-1S **αυτους** *autous* ich [[G846]] [[P-APM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **ηξωσιν** *ēksōsin* przyszliby [[G2240]] WTV-AAS-3P **και** *kai* i [[G2532]] [[CONJ]] **προσκυνησωσιν** *proskynēsōsin* oddaliby cześć – pokłoniliby się [[G4352]] WTV-AAS-3P **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **των** *tōn* [[G3588]] WTT-GPM **ποδων** *podōn* stopami [[G4228]] WTN-GPM **σου** *sou* twoimi [[G4675]] WTP-2GS **και** *kai* i [[G2532]] [[CONJ]] **γνωσιν** *gnōsin* poznaliby [[G1097]] WTV-2AAS-3P **οτι** *hoti* że [[G3754]] [[CONJ]] **εγω** *egō* Ja [[G1473]] WTP-1NS **ηγαπησα** *ēgapēsa* umiłowałem [[G25]] WTV-AAI-1S **σε** *se* cię [[G4571]] WTP-2AS
###### **Ap 3,10**
 **οτι** *hoti* Gdyż [[G3754]] [[CONJ]] **ετηρησας** *etērēsas* zachowałeś – strzegłeś [[G5083]] WTV-AAI-2S **τον** *ton* [[G3588]] [[T-ASM]] **λογον** *logon* Słowo [[G3056]] [[N-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **υπομονης** *hypomonēs* wytrwałości [[G5281]] [[N-GSF]] **μου** *mou* mojej [[G3450]] WTP-1GS **καγω** *kagō* i Ja [[G2504]] WTP-1NS-C **σε** *se* ciebie [[G4571]] WTP-2AS **τηρησω** *tērēsō* zachowam – ustrzegę [[G5083]] WTV-FAI-1S **εκ** *ek* od [[G1537]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **ωρας** *hōras* godziny [[G5610]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **πειρασμου** *peirasmou* próby – doświadczenia [[G3986]] [[N-GSM]] **της** *tēs* [[G3588]] [[T-GSF]] **μελλουσης** *mellousēs* mającej [[G3195]] WTV-PAP-GSF **ερχεσθαι** *erchesthai* przyjść [[G2064]] WTV-PNN **επι** *epi* na [[G1909]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **οικουμενης** *oikoumenēs* świat zamieszkały [[G3625]] [[N-GSF]] **ολης** *holēs* cały [[G3650]] WTA-GSF **πειρασαι** *peirasai* doświadczyć – wypróbować [[G3985]] [[V-AAN]] **τους** *tous* [[G3588]] WTT-APM **κατοικουντας** *katoikountas* zamieszkujących [[G2730]] WTV-PAP-APM **επι** *epi* na [[G1909]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]]
###### **Ap 3,11**
 **ιδου** *idou* Oto [[G2400]] WTV-2AAM-2S **ερχομαι** *erchomai* przychodzę [[G2064]] WTV-PNI-1S **ταχυ** *tachy* szybko – spiesznie [[G5035]] [[ADV]] **κρατει** *kratei* trzymaj [[G2902]] WTV-PAM-2S **ο** *ho* co [[G3739]] WTR-ASN **εχεις** *echeis* masz [[G2192]] WTV-PAI-2S **ινα** *hina* aby [[G2443]] [[CONJ]] **μηδεις** *mēdeis* nikt [[G3367]] [[A-NSM]] **λαβη** *labē* odebrałby – wziąłby [[G2983]] WTV-2AAS-3S **τον** *ton* [[G3588]] [[T-ASM]] **στεφανον** *stefanon* wieńca – korony [[G4735]] [[N-ASM]] **σου** *sou* twojego [[G4675]] WTP-2GS
###### **Ap 3,12**
 **ο** *ho* [[G3588]] [[T-NSM]] **νικων** *nikōn* Zwyciężający [[G3528]] [[V-PAP-NSM]] **ποιησω** *poiēsō* uczynię [[G4160]] WTV-FAI-1S **αυτον** *auton* go [[G846]] WTP-ASM **στυλον** *stylon* filarem – kolumną [[G4769]] [[N-ASM]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **ναω** *naō* świątyni – przybytku [[G3485]] WTN-DSM **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **μου** *mou* mojego [[G3450]] WTP-1GS **και** *kai* i [[G2532]] [[CONJ]] **εξω** *eksō* na zewnątrz – poza [[G1854]] [[ADV]] **ου** *ou* nie [[G3756]] [[PRT-N]] **μη** *mē* [[G3361]] [[PRT-N]] **εξελθη** *ekselthē* wyszedłby [[G1831]] WTV-2AAS-3S **ετι** *eti* jeszcze [[G2089]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **γραψω** *grapsō* napiszę [[G1125]] WTV-FAI-1S **επ** *ep* na [[G1909]] [[PREP]] **αυτον** *auton* nim [[G846]] WTP-ASM **το** *to* [[G3588]] WTT-ASN **ονομα** *onoma* imię [[G3686]] WTN-ASN **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **μου** *mou* mojego [[G3450]] WTP-1GS **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-ASN **ονομα** *onoma* imię [[G3686]] WTN-ASN **της** *tēs* [[G3588]] [[T-GSF]] **πολεως** *poleōs* miasta [[G4172]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **μου** *mou* mojego [[G3450]] WTP-1GS **της** *tēs* [[G3588]] [[T-GSF]] **καινης** *kainēs* nowego [[G2537]] WTA-GSF **ιερουσαλημ** *ierousalēm* Jeruzalem – [dziedzictwo pokoju] [[G2419]] [[N-PRI]] **η** *hē* (które) [[G3588]] [[T-NSF]] **καταβαινει** *katabainei* schodzi – zstępuje [[G2597]] WTV-PAI-3S **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **ουρανου** *ouranou* nieba [[G3772]] [[N-GSM]] **απο** *apo* od [[G575]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **μου** *mou* mojego [[G3450]] WTP-1GS **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-ASN **ονομα** *onoma* imię [[G3686]] WTN-ASN **μου** *mou* moje [[G3450]] WTP-1GS **το** *to* [[G3588]] WTT-ASN **καινον** *kainon* nowe [[G2537]] WTA-ASN
###### **Ap 3,13**
 **ο** *ho* [[G3588]] [[T-NSM]] **εχων** *echōn* Mający [[G2192]] [[V-PAP-NSM]] **ους** *ous* ucho [[G3775]] WTN-ASN **ακουσατω** *akousatō* niech usłyszy [[G191]] WTV-AAM-3S **τι** *ti* co [[G5101]] WTI-ASN **το** *to* [[G3588]] WTT-NSN **πνευμα** *pneuma* Duch [[G4151]] WTN-NSN **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **ταις** *tais* [[G3588]] WTT-DPF **εκκλησιαις** *ekklēsiais* zgromadzeniom – (społecznościom) wywołanych [[G1577]] WTN-DPF
###### **Ap 3,14**
 **και** *kai* A [[G2532]] [[CONJ]] **τω** *tō* [[G3588]] WTT-DSM **αγγελω** *angelō* zwiastunowi [[G32]] WTN-DSM **της** *tēs* [[G3588]] [[T-GSF]] **εκκλησιας** *ekklēsias* zgromadzenia – (społeczności) wywołanych [[G1577]] [[N-GSF]] **λαοδικεων** *laodikeōn* laodejczyków – [prawo ludu] [[G2994]] WTN-GPM **γραψον** *grapson* napisz [[G1125]] WTV-AAM-2S **ταδε** *tade* to [[G3592]] WTD-APN **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **αμην** *amēn* amen – [zaprawdę] [[G281]] WTHEB **ο** *ho* [[G3588]] [[T-NSM]] **μαρτυς** *martys* świadek [[G3144]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **πιστος** *pistos* wierny [[G4103]] [[A-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **αληθινος** *alēthinos* prawdziwy [[G228]] [[A-NSM]] **η** *hē* [[G3588]] [[T-NSF]] **αρχη** *archē* początek [[G746]] [[N-NSF]] **της** *tēs* [[G3588]] [[T-GSF]] **κτισεως** *ktiseōs* stworzenia [[G2937]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **Ap 3,15**
 **οιδα** *oida* Znam [[G1492]] WTV-RAI-1S **σου** *sou* twoje [[G4675]] WTP-2GS **τα** *ta* [[G3588]] WTT-APN **εργα** *erga* czyny – dzieła [[G2041]] WTN-APN **οτι** *hoti* że [[G3754]] [[CONJ]] **ουτε** *oute* ani [[G3777]] [[CONJ]] **ψυχρος** *psychros* zimny [[G5593]] [[A-NSM]] **ει** *ei* jesteś [[G1488]] WTV-PXI-2S **ουτε** *oute* ani [[G3777]] [[CONJ]] **ζεστος** *zestos* gorący – wrzący [[G2200]] [[A-NSM]] **οφελον** *ofelon* obyś! – życzę ci! [[G3785]] WTINJ **ψυχρος** *psychros* zimny [[G5593]] [[A-NSM]] **ειης** *eiēs* oby jesteś [[G1498]] WTV-PXO-2S **η** *ē* lub [[G2228]] WTPRT **ζεστος** *zestos* gorący – wrzący [[G2200]] [[A-NSM]]
###### **Ap 3,16**
 **ουτως** *houtōs* Tak [[G3779]] [[ADV]] **οτι** *hoti* że [[G3754]] [[CONJ]] **χλιαρος** *chliaros* letni [[G5513]] [[A-NSM]] **ει** *ei* jesteś [[G1488]] WTV-PXI-2S **και** *kai* i [[G2532]] [[CONJ]] **ουτε** *oute* ani [[G3777]] [[CONJ]] **ψυχρος** *psychros* zimny [[G5593]] [[A-NSM]] **ουτε** *oute* ani [[G3777]] [[CONJ]] **ζεστος** *zestos* gorący – wrzący [[G2200]] [[A-NSM]] **μελλω** *mellō* zamierzam [[G3195]] WTV-PAI-1S **σε** *se* cię [[G4571]] WTP-2AS **εμεσαι** *emesai* zwymiotować – wyrzygać [[G1692]] [[V-AAN]] **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **στοματος** *stomatos* ust [[G4750]] [[N-GSN]] **μου** *mou* moich [[G3450]] WTP-1GS
###### **Ap 3,17**
 **οτι** *hoti* Gdyż [[G3754]] [[CONJ]] **λεγεις** *legeis* mówisz [[G3004]] WTV-PAI-2S **οτι** *hoti* że [[G3754]] [[CONJ]] **πλουσιος** *plousios* bogaty [[G4145]] [[A-NSM]] **ειμι** *eimi* jestem [[G1510]] WTV-PXI-1S **και** *kai* i [[G2532]] [[CONJ]] **πεπλουτηκα** *peploutēka* wzbogaciłem się [[G4147]] WTV-RAI-1S **και** *kai* i [[G2532]] [[CONJ]] **ουδενος** *oudenos* niczego [[G3762]] [[A-GSN]] **χρειαν** *chreian* potrzebę [[G5532]] WTN-ASF **εχω** *echō* mam [[G2192]] WTV-PAI-1S **και** *kai* a [[G2532]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **οιδας** *oidas* wiesz [[G1492]] WTV-RAI-2S **οτι** *hoti* że [[G3754]] [[CONJ]] **συ** *sy* ty [[G4771]] WTP-2NS **ει** *ei* jesteś [[G1488]] WTV-PXI-2S **ο** *ho* [[G3588]] [[T-NSM]] **ταλαιπωρος** *talaipōros* nędzny [[G5005]] [[A-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ελεεινος** *eleeinos* pożałowania godny – godny litości [[G1652]] [[A-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **πτωχος** *ptōchos* ubogi [[G4434]] [[A-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **τυφλος** *tyflos* niewidomy – ślepy [[G5185]] [[A-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **γυμνος** *gymnos* nagi [[G1131]] [[A-NSM]]
###### **Ap 3,18**
 **συμβουλευω** *symbouleuō* Radzę [[G4823]] WTV-PAI-1S **σοι** *soi* ci [[G4671]] WTP-2DS **αγορασαι** *agorasai* kupić [[G59]] [[V-AAN]] **παρ** *par* ode [[G3844]] [[PREP]] **εμου** *emou* Mnie [[G1700]] WTP-1GS **χρυσιον** *chrysion* złoto [[G5553]] WTN-ASN **πεπυρωμενον** *pepyrōmenon* które jest wypalone – które jest rozżarzone [[G4448]] WTV-RPP-ASN **εκ** *ek* z [[G1537]] [[PREP]] **πυρος** *pyros* ognia [[G4442]] [[N-GSN]] **ινα** *hina* aby [[G2443]] [[CONJ]] **πλουτησης** *ploutēsēs* wzbogaciłbyś się [[G4147]] WTV-AAS-2S **και** *kai* i [[G2532]] [[CONJ]] **ιματια** *himatia* szaty – płaszcze [[G2440]] WTN-APN **λευκα** *leuka* białe [[G3022]] WTA-APN **ινα** *hina* aby [[G2443]] [[CONJ]] **περιβαλη** *peribalē* okryłbyś się – odziałbyś się [[G4016]] WTV-2AMS-2S **και** *kai* i [[G2532]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **φανερωθη** *fanerōthē* zostałby objawiony – zostałby uczyniony widocznym [[G5319]] WTV-APS-3S **η** *hē* [[G3588]] [[T-NSF]] **αισχυνη** *aischynē* wstyd – hańba [[G152]] [[N-NSF]] **της** *tēs* [[G3588]] [[T-GSF]] **γυμνοτητος** *gymnotētos* nagości [[G1132]] [[N-GSF]] **σου** *sou* twojej [[G4675]] WTP-2GS **και** *kai* i [[G2532]] [[CONJ]] **κολλουριον** *kollourion* maścią do oczu [[G2854]] WTN-ASN **εγχρισον** *egchrison* posmaruj – wetrzyj [[G1472]] WTV-AAM-2S **τους** *tous* [[G3588]] WTT-APM **οφθαλμους** *ofthalmous* oczy [[G3788]] [[N-APM]] **σου** *sou* twoje [[G4675]] WTP-2GS **ινα** *hina* aby [[G2443]] [[CONJ]] **βλεπης** *blepēs* widziałbyś [[G991]] WTV-PAS-2S
###### **Ap 3,19**
 **εγω** *egō* Ja [[G1473]] WTP-1NS **οσους** *hosous* ilu [[G3745]] WTK-APM **εαν** *ean* jeśli [[G1437]] WTCOND **φιλω** *filō* okazywałbym czułość – miłowałbym [[G5368]] WTV-PAS-1S **ελεγχω** *elegchō* upominam – zawstydzam [[G1651]] WTV-PAI-1S **και** *kai* i [[G2532]] [[CONJ]] **παιδευω** *paideuō* koryguję – dyscyplinuję [[G3811]] WTV-PAI-1S **ζηλωσον** *zēlōson* staraj się usilnie – bądź gorliwy [[G2206]] WTV-AAM-2S **ουν** *oun* więc [[G3767]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **μετανοησον** *metanoēson* opamiętaj się – zmień myślenie [[G3340]] WTV-AAM-2S
###### **Ap 3,20**
 **ιδου** *idou* Oto [[G2400]] WTV-2AAM-2S **εστηκα** *hestēka* stanąłem [[G2476]] WTV-RAI-1S **επι** *epi* przy [[G1909]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **θυραν** *thyran* drzwiach [[G2374]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **κρουω** *krouō* pukam [[G2925]] WTV-PAI-1S **εαν** *ean* jeśli [[G1437]] WTCOND **τις** *tis* ktoś [[G5100]] WTX-NSM **ακουση** *akousē* usłyszałby [[G191]] WTV-AAS-3S **της** *tēs* [[G3588]] [[T-GSF]] **φωνης** *fōnēs* głos [[G5456]] [[N-GSF]] **μου** *mou* mój [[G3450]] WTP-1GS **και** *kai* i [[G2532]] [[CONJ]] **ανοιξη** *anoiksē* otworzyłby [[G455]] WTV-AAS-3S **την** *tēn* [[G3588]] WTT-ASF **θυραν** *thyran* drzwi [[G2374]] WTN-ASF **εισελευσομαι** *eiseleusomai* wejdę [[G1525]] WTV-FDI-1S **προς** *pros* do [[G4314]] [[PREP]] **αυτον** *auton* niego [[G846]] WTP-ASM **και** *kai* i [[G2532]] [[CONJ]] **δειπνησω** *deipnēsō* spożyję wieczerzę [[G1172]] WTV-FAI-1S **μετ** *met* z [[G3326]] [[PREP]] **αυτου** *autou* nim [[G846]] [[P-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **αυτος** *autos* on [[G846]] WTP-NSM **μετ** *met* ze [[G3326]] [[PREP]] **εμου** *emou* Mną [[G1700]] WTP-1GS
###### **Ap 3,21**
 **ο** *ho* [[G3588]] [[T-NSM]] **νικων** *nikōn* Zwyciężający [[G3528]] [[V-PAP-NSM]] **δωσω** *dōsō* dam [[G1325]] WTV-FAI-1S **αυτω** *autō* mu [[G846]] WTP-DSM **καθισαι** *kathisai* usiąść [[G2523]] [[V-AAN]] **μετ** *met* ze [[G3326]] [[PREP]] **εμου** *emou* Mną [[G1700]] WTP-1GS **εν** *en* na [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **θρονω** *thronō* tronie [[G2362]] WTN-DSM **μου** *mou* moim [[G3450]] WTP-1GS **ως** *hōs* jak [[G5613]] [[ADV]] **καγω** *kagō* i Ja [[G2504]] WTP-1NS-C **ενικησα** *enikēsa* zwyciężyłem [[G3528]] WTV-AAI-1S **και** *kai* i [[G2532]] [[CONJ]] **εκαθισα** *ekathisa* usiadłem [[G2523]] WTV-AAI-1S **μετα** *meta* z [[G3326]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **πατρος** *patros* Ojcem [[G3962]] [[N-GSM]] **μου** *mou* moim [[G3450]] WTP-1GS **εν** *en* na [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **θρονω** *thronō* tronie [[G2362]] WTN-DSM **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Ap 3,22**
 **ο** *ho* [[G3588]] [[T-NSM]] **εχων** *echōn* Mający [[G2192]] [[V-PAP-NSM]] **ους** *ous* ucho [[G3775]] WTN-ASN **ακουσατω** *akousatō* niech usłyszy [[G191]] WTV-AAM-3S **τι** *ti* co [[G5101]] WTI-ASN **το** *to* [[G3588]] WTT-NSN **πνευμα** *pneuma* Duch [[G4151]] WTN-NSN **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **ταις** *tais* [[G3588]] WTT-DPF **εκκλησιαις** *ekklēsiais* zgromadzeniom – (społecznościom) wywołanych [[G1577]] WTN-DPF
