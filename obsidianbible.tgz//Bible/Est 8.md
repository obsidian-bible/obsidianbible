# Est 8 BT5
###### **Est 8,1**
 Tego dnia król Aswerus podarował królowej Esterze dom Hamana, wroga Żydów, Mardocheusz zaś dostał się przed oblicze króla, ponieważ Estera opowiedziała, kim on był dla niej.
###### **Est 8,2**
 Wtedy król zdjął swój sygnet, który odebrał Hamanowi, i dał go Mardocheuszowi. Estera zaś ustanowiła Mardocheusza zarządcą domu Hamana.
###### **Est 8,3**
 I znowu Estera przemówiła do króla, i padła mu do nóg, i płakała, i błagała go o łaskę, aby zniweczył przewrotność Hamana, Agagity, i jego zamiar skierowany przeciwko Żydom.
###### **Est 8,4**
 A król wyciągnął do Estery złote berło; wówczas Estera podniosła się i stanęła przed królem,
###### **Est 8,5**
 i rzekła: «***Jeśli król uzna to za słuszne, jeśli darzy mnie życzliwością i jeśli królowi to odpowiada, a ja jestem miła w jego oczach, niech zostanie zapisane odwołanie listów, dzieła Hamana, syna Hammedaty, który napisał, aby wytracić Żydów mieszkających we wszystkich państwach króla.***
###### **Est 8,6**
 ***Bo jakże mogłabym patrzeć na zło, które spadnie na lud mój, i jak mogłabym patrzeć na zgubę mojego narodu?***»
###### **Est 8,7**
 Wtedy król Aswerus rzekł do królowej Estery i do Żyda Mardocheusza: «***Oto dałem Esterze dom Hamana, a jego powiesili na drzewie, ponieważ podniósł rękę na Żydów.***
###### **Est 8,8**
 ***Wy zaś, jeśli to będzie dobre w oczach waszych, napiszcie w sprawie Żydów, w imieniu króla, i zapieczętujcie sygnetem, ponieważ pismo króla, napisane w imieniu króla i zapieczętowane sygnetem króla, jest nieodwołalne***».
###### **Est 8,9**
 Przywołano pisarzy królewskich w tym czasie, w trzecim miesiącu, to jest miesiącu Siwan, w dniu dwudziestym trzecim, i napisano zgodnie z tym wszystkim, co rozkazał Mardocheusz, do Żydów i do satrapów, do namiestników i książąt państw, od Indii aż po Etiopię, to jest do stu dwudziestu siedmiu państw, do każdego państwa jego pismem i do każdego ludu w jego języku oraz do Żydów ich pismem i w ich języku.
###### **Est 8,10**
 Napisano w imieniu króla Aswerusa pisma, zapieczętowano sygnetem króla i posłano przez gońców jadących na koniach, na wierzchowcach królewskich, na źrebcach klaczy ze stadniny królewskiej.
###### **Est 8,11**
 [W pismach] król pozwolił Żydom mieszkającym w poszczególnych miastach zgromadzić się i stanąć w obronie swego życia, aby mogli wytracić, wymordować i wygubić wszystkich zbrojnych swoich wrogów wśród ludów i państw, wraz z ich niemowlętami i kobietami, a także zabrać ich majątek
###### **Est 8,12**
 w jednym dniu, we wszystkich państwach króla Aswerusa, trzynastego dnia dwunastego miesiąca, to jest miesiąca Adar.
###### **Est 8,12**
 w jednym dniu, we wszystkich państwach króla Aswerusa, trzynastego dnia dwunastego miesiąca, to jest miesiąca Adar.
###### **Est 8,12a**
 Odpis tego listu, dotyczącego powyższych wypadków, brzmi następująco:
###### **Est 8,12b**
 «***Wielki król Artakserkses przesyła pozdrowienia stu dwudziestu siedmiu państwom od Indii aż do Etiopii, przełożonym krain i tym, którzy z nami są jednej myśli.***
###### **Est 8,12c**
 ***Wielu z tych, którzy przez nadzwyczajną łaskawość dobroczyńców zostało podniesionych do niezwykłej godności, zapragnęło jeszcze czegoś większego. Usiłują nie tylko źle czynić naszym poddanym, na których szczęście nie mogą patrzeć, lecz przeciw swoim własnym dobroczyńcom knują zdradę.***
###### **Est 8,12d**
 ***Nie tylko usuwają wdzięczność spomiędzy ludzi, lecz także rozzuchwaleni pochwałami tych, co nie znają dobra, mniemają, że ujdą karzącej sprawiedliwości wszystkowiedzącego Boga.***
###### **Est 8,12e**
 ***Często też namowa przyjaciół, którym powierzono zarząd spraw, czyniąc tych, którzy sprawują władzę, odpowiedzialnymi za niewinną krew, wikła ich w niepowetowane klęski.***
###### **Est 8,12f**
 ***W ten sposób kłamliwym rozumowaniem nikczemności oszukują szczerą życzliwość panujących.***
###### **Est 8,12g**
 ***I możecie zauważyć - niekoniecznie w starożytnych kronikach, któreśmy ogłosili - lecz o wiele więcej patrząc na to, co jest przed stopami, ile zła dzieje się z powodu zepsucia ludzi niegodnie rządzących.***
###### **Est 8,12h**
 ***Na przyszłość trzeba zwrócić uwagę na to, a w ten sposób sprawimy, że będzie królestwo nie zamącone, pełne pokoju dla wszystkich ludzi,***
##### **Est 8,12i**
 ***a przy dokonywaniu zmian, narzucających się z oczywistością, rozsądzimy zawsze kierując się większą łagodnością.***
##### **Est 8,12k**
 ***Tak to Haman, syn Hammedaty, < Macedończyk >, co prawda obcy krwi perskiej i bardzo daleki od naszej dobroci, znalazł u nas gościnę i spotkał się do tego stopnia z życzliwością,***
###### **Est 8,12l**
 ***którą mamy dla całego ludu, że nazywali go ojcem naszym i oddawali mu wszyscy pokłon, bo osiągnął drugie miejsce przy tronie królewskim.***
###### **Est 8,12m**
 ***Jednak nie ujarzmił żądzy wielkości, ale przemyśliwał nad tym, jak by nas pozbawić panowania i życia.***
###### **Est 8,12n**
 ***Naszego zaś wybawcę i stałego dobroczyńcę, Mardocheusza, oraz Esterę, wspólniczkę bez skazy we władzy królewskiej, a także cały ich lud starał się doprowadzić do zguby podstępnymi, dobrze przemyślanymi sposobami.***
###### **Est 8,12o**
 ***W ten sposób zamierzał on, zaskoczywszy nas w osamotnieniu, przenieść panowanie z Persów na Macedończyków.***
###### **Est 8,12p**
 ***My jednak stwierdzamy, że Żydzi wydani na zagładę przez tego po trzykroć zbrodniczego człowieka nie są złoczyńcami, lecz rządzą się najbardziej sprawiedliwymi prawami,***
###### **Est 8,12q**
 ***i że są synami najwyższego, żywego Boga, który dobrze kierując zarówno nami, jak też i naszymi przodkami, królestwo nasze najlepiej utwierdza.***
###### **Est 8,12r**
 ***Dobrze więc zrobicie, jeśli nie będziecie zważać na listy nadesłane przez Hamana, syna Hammedaty, który za to, że się tego dopuścił, zawisł na drzewie u bram Suzy, z całym swym domem, albowiem wszechwładny Bóg bezzwłocznie wymierzył mu wyrok sprawiedliwy.***
###### **Est 8,12s**
 ***A odpis tego listu wystawcie wszędzie na widok publiczny, pozwalając Żydom jawnie posługiwać się ich własnymi prawami. Dopomóżcie im, aby tych, którzy ich napadną w chwili ucisku, trzynastego dnia dwunastego miesiąca, Adar, mogli odeprzeć w tym samym dniu.***
###### **Est 8,12t**
 ***Ten bowiem dzień wszechwładny Bóg, zamiast na zagładę ludu wybranego, przeznaczył na jego wesele.***
###### **Est 8,12u**
 ***Przeto i wy w liczbie świąt waszych imiennie określonych obchodźcie ów pamiętny dzień z wszelkimi biesiadami, aby on i teraz, i potem był dla nas i dla życzliwych Persów [pamiątką] wybawienia, a dla spiskujących przeciw nam przypomnieniem zguby.***
###### **Est 8,12x**
 ***Każde zaś miasto czy okręg, bez wyjątku, które by tego nie spełniło, będzie wydane w gniewie na pastwę włóczni i ognia i będzie uważane nie tylko za niedostępne dla ludzi, lecz także za najbardziej wrogie dla zwierząt i ptaków***».
###### **Est 8,13**
 Odpis pisma został ogłoszony we wszystkich państwach z mocą prawa, aby wiadome było wszystkim ludom, że Żydzi będą gotowi na ten dzień do pomsty nad nieprzyjaciółmi.
###### **Est 8,14**
 Gońcy konni, gońcy królewscy, pędzili śpiesznie, przynaglani rozkazem króla, a dekret króla został ogłoszony na zamku w Suzie.
###### **Est 8,15**
 Mardocheusz zaś wyszedł od króla w szacie królewskiej z fioletowej purpury i białego lnu, w wielkiej złotej koronie, w płaszczu z bisioru i szkarłatu, a miasto Suza cieszyło się i weseliło.
###### **Est 8,16**
 Dla Żydów nastało światło i wesele, i radość, i sława.
###### **Est 8,17**
 We wszystkich bez wyjątku państwach i w każdym mieście, dokądkolwiek dotarły słowo króla i jego dekret, nastały dla Żydów radość i wesele, uczty i dzień zabawy. Wielu spośród ludności kraju przechodziło na judaizm, ponieważ padł na nich strach przed Żydami.
# Est 8 PAU
###### **Est 8,1**
 Tego dnia król Artakserkses obdarował Esterę wszystkim, co należało do oszczercy Hamana. Również Mardocheusz został wezwany przez króla, ponieważ Estera wyznała, że jest jej krewnym.
###### **Est 8,2**
 Król wziął pierścień, który odebrał Hamanowi, i dał go Mardocheuszowi, a Estera ustanowiła Mardocheusza zarządcą całego majątku Hamana.
###### **Est 8,3**
 Potem znowu przystąpiła do króla, upadła mu do nóg i prosiła, aby zapobiegł złu, jakie Haman postanowił wyrządzić Żydom.
###### **Est 8,4**
 Król wyciągnął w stronę Estery złote berło, więc Estera podniosła się i stanęła przed królem.
###### **Est 8,5**
 Powiedziała: „Jeśli uznasz to za słuszne i jeśli jesteś mi życzliwy, niech zostanie odwołany dekret wysłany przez Hamana, w którym napisał o zagładzie Żydów mieszkających w twoim królestwie.
###### **Est 8,6**
 Jak mogłabym patrzeć na nieszczęście mojego ludu? Jak mogłabym sama zostać ocalona od zagłady, jaka czeka mój naród?”.
###### **Est 8,7**
 Król rzekł do Estery: „Całe mienie Hamana oddałem tobie i okazałem ci wdzięczność, a jego powiesiłem na szubienicy, ponieważ wystąpił przeciwko Żydom. Czegóż jeszcze żądasz?
###### **Est 8,8**
 To wy w moim imieniu napiszcie, co uznacie za słuszne i opieczętujcie moim pierścieniem, ponieważ tego, co z rozkazu króla zostało napisane i opieczętowane jego pierścieniem, nie można już odwołać”.
###### **Est 8,9**
 Wezwano pisarzy, a było to w tym samym roku, dwudziestego trzeciego dnia pierwszego miesiąca, którym był miesiąc Nisan. I napisano do Żydów o tym, co zostało nakazane urzędnikom oraz książętom poszczególnych prowincji od Indii aż do Etiopii, stu dwudziestu siedmiu prowincjom stosownie do okręgów, a każdemu okręgowi w jego własnym języku.
###### **Est 8,10**
 Pisma zostały napisane w imieniu króla, opieczętowane jego pierścieniem i wysłane poprzez kurierów.
###### **Est 8,11**
 Król zezwalał Żydom w każdym mieście żyć według ich praw, a także przyjść sobie z pomocą i postąpić z nieprzyjaciółmi i wrogami tak, jak zechcą,
###### **Est 8,12**
 w całym królestwie Artakserksesa, ale tylko w tym dniu, to jest w dniu trzynastym dwunastego miesiąca, którym był miesiąc Adar. (a) Oto odpis dekretu, jaki został napisany: (b) „Wielki król Artakserkses do prowincji, do namiestników stu dwudziestu siedmiu prowincji, od Indii aż do Etiopii oraz do wszystkich, którzy są nam wierni. Pozdrowienia! (c) Wielu z tych, którzy dzięki nadzwyczajnej szlachetności swych dobroczyńców cieszyło się wielkim poważaniem, zapragnęło jeszcze czegoś więcej i nie tylko zamierzają skrzywdzić naszych poddanych, ale nie wiedząc, co począć z nadmiarem okazywanej im dobroci, spiskują przeciw własnym dobroczyńcom. (d) Nie tylko chcą wymazać wdzięczność spośród ludzi, ale ponadto, rozzuchwaleni pochwałami tych, co nie znają dobra, myślą, że ominie ich sąd wszystko widzącego Boga, który nie znosi zła. (e) Niejednokrotnie już wielu z tych, którym powierzono władzę, uległo podszeptom przyjaciół kierujących sprawami państwowymi i w ten sposób stali się odpowiedzialni za niewinnie przelaną krew. Za to spadło na nich straszliwe nieszczęście. (h) Biorąc to pod uwagę, zamierzamy na przyszłość zapewnić wszystkim obywatelom królestwo bezpieczne i spokojne, (i) a wszystkie sprawy wymagające zmian, jeśli o takich usłyszymy, będziemy rozstrzygać po rzetelnym zbadaniu. (k) Macedończyk Haman, syn Hammedaty, tak naprawdę obcy w narodzie perskim i bardzo daleki od naszej dobroci, został naszym gościem. (l) Doświadczył życzliwości, jaką mamy dla każdego narodu, i to tak wielkiej, że publicznie ogłosiliśmy go naszym ojcem, a czczony przez wszystkich, był drugim przy tronie króla. (m) Ale uległ swojej pysze i chciał pozbawić nas władzy i życia. (n) Wyrafinowanymi, dobrze obmyślanymi intrygami dążył do zguby Mardocheusza, naszego wybawcy i sprawdzonego dobroczyńcy, a także Estery, która w sposób nieposzlakowany piastuje godność królewską, oraz całego ich narodu. (p) My jednak stwierdziliśmy, że Żydzi, skazani przez tego łotra na zagładę, nie czynią nic złego, ale kierują się najbardziej sprawiedliwymi prawami. (q) A są oni synami najwyższego, największego, żyjącego Boga, który prowadzi nas jak niegdyś naszych przodków oraz utrzymuje królestwo w doskonałym ładzie. (t) Ten bowiem dzień Bóg potężny ustanowił dniem radości, a nie zagłady narodu wybranego. (u) Zatem wy, wśród innych znanych wam świąt, obchodźcie jak najradośniej i ten wyznaczony dzień, aby dla nas i dla życzliwie usposobionych Persów był pamiątką ocalenia, zarówno teraz, jak i później, a dla spiskujących przeciwko nam był wspomnieniem zagłady. (x) Każde miasto czy okręg bez wyjątku, które się do tego nie zastosują, bez litości będą spustoszone włócznią i ogniem i nie tylko staną się niedostępne dla ludzi, ale po wszystkie czasy będą bardzo nieprzyjazne dla zwierząt i ptactwa”.
###### **Est 8,13**
 Odpisy zostały wywieszone w miejscach publicznych w całym królestwie, aby wszyscy wiedzieli, że Żydzi są przygotowani w ten dzień do walki ze swymi przeciwnikami.
###### **Est 8,14**
 Gońcy na koniach wyruszyli spiesznie, by spełnić polecenia króla. Rozporządzenie zostało ogłoszone również w Suzie.
###### **Est 8,15**
 Wtedy Mardocheusz wyszedł obleczony w szatę królewską, na głowie miał złotą koronę oraz diadem z bisioru i purpury, a mieszkańcy Suzy widzieli to i się cieszyli.
###### **Est 8,16**
 Dla Żydów nastały dni światłości i wesela.
###### **Est 8,17**
 W miastach i w okręgach, gdziekolwiek wywieszono rozporządzenie króla albo jego obwieszczenie, Żydzi cieszyli się i radowali, ucztowali i weselili się, a wielu pogan dało się obrzezać i z obawy przed Żydami przyjęło religię żydowską.
# Est 8 BP
###### **Est 8,1**
 Tego samego dnia król Achaszwerosz ofiarował królowej Esterze pałac Hamana, prześladowcy Żydów. Mardocheusz zaś został dopuszczony przed oblicze króla, ponieważ Estera wyjawiła mu, kim był on dla niej.
###### **Est 8,2**
 I zdjął król swój pierścień, który kazał odebrać Hamanowi, i podarował go Mardocheuszowi, a Estera ustanowiła go zarządcą pałacu Hamana.
###### **Est 8,3**
 Estera zaś ponownie zabrała głos przed królem. Upadłszy mu do nóg poprosiła go z płaczem, by nakazał całkowicie zniweczyć [skutki] złości Hamana, Agagity, [to jest] niecne zamierzenia zwrócone przeciwko Żydom.
###### **Est 8,4**
 Król wyciągnął ku Esterze złote berło. Powstała więc i stojąc przed królem
###### **Est 8,5**
 mówiła: Jeżeli taka jest wola króla, jeżeli naprawdę znalazłam u niego łaskę, jeżeli ta rzecz wydaje mu się słuszna, a ja jestem mu miła, niech wyda polecenie na piśmie, by wycofano dekret [zrodzony w umyśle] Hamana, syna Hammedaty, Agagity, w którym jest napisane, by wytracono Żydów, mieszkających we wszystkich prowincjach królewskich.
###### **Est 8,6**
 Bo jakżeż mogłabym patrzeć na nieszczęście, które dotknie mój lud, i jakżeż mogłabym oglądać zgubę mojego narodu?
###### **Est 8,7**
 Rzekł król Achaszwerosz do królowej Estery i do Żyda Mardocheusza: Oto podarowałem Esterze pałac Hamana, on sam zaś zawisł na szubienicy za to, że podniósł rękę swą przeciwko Żydom.
###### **Est 8,8**
 Teraz zaś napiszcie sami w sprawie Żydów w imieniu króla to, co uznacie za wskazane, a następnie opieczętujcie [pismo] pierścieniem królewkim. To bowiem, co raz zostało napisane w imieniu króla i przypieczętowane pierścieniem królewskim, nie może być odwołane.
###### **Est 8,9**
 Natychmiast więc, to jest dnia dwudziestego trzeciego, miesiąca trzeciego - to jest w miesiącu Sziwan - zwołano pisarzy królewskich i wystosowano pismo zgodnie z poleceniem Mardocheusza do Żydów i do satrapów, do zarządców i książąt prowincji, rozciągających się od Indii aż do Etiopii, to jest do stu dwudziestu siedmiu prowincji, do poszczególnych prowincji ich pismem i do poszczególnych ludów ich językiem, i do Żydów ich pismem i ich językiem.
###### **Est 8,10**
 Po wystosowaniu pisma w imieniu króla Achaszwerosza i opieczętowaniu go pierścieniem królewskim rozesłał je [Mardocheusz] przez konnych gońców, jeżdżących na wierzchowcach państwowych pochodzących ze stadnin królewskich.
###### **Est 8,11**
 [W piśmie tym] zezwalano Żydom, mieszkającym w poszczególnych miastach, gromadzić się i stawać w obronie swego życia, a także zabijać, wytracać i wyniszczać wszystkich swoich wrogów, występujących zbrojnie wśród ludów i prowincji wraz z ich niemowlętami i kobietami, a także zabierać ich majętność jako łup.
###### **Est 8,12**
 [Miało się to stać] jednego i tego samego dnia we wszystkich prowincjach króla Achaszwerosza, mianowicie trzynastego, miesiąca dwunastego, który jest miesiącem Adar. Według LXX: E 8.12a-12x 12a A oto odpis tego pisma: 12b "Wielki król Artakserkses do stu dwudziestu siedmiu wielkorządców, [urzędujących w prowincjach] od Indii aż do Etiopii, naczelników okręgów i do tych, którym leżą na sercu nasze sprawy, [śle] pozdrowienie! 12c Wielu z tych, którzy dzięki niezwykłej łaskawości swoich dobroczyńców zostali obsypani zaszczytami, uległo pysze. Nie tylko wykorzystują je na szkodę naszych poddanych, nie umiejąc ścierpieć ich pomyślności, ale ponadto knują zdradę przeciw swoim dobroczyńcom. 12d Nie poprzestają na tym, że wykorzeniają wdzięczność spośród ludzi, lecz także rozzuchwaleni pochwałami ludzi bez doświadczenia, mniemają, że ujdą nienawidzącej zła sprawiedliwości wszystkowiedzącego Boga. 12e Często też wielu z tych, których obdarzono władzą, za namową swych przyjaciół, zajmujących się sprawami państwowymi, stawało się odpowiedzialnymi za krew niewinnie przelaną, co pociągnęło szkody nie do naprawienia. 12f Tak to fałszywa rada, kierowana podłością, wprowadziła w błąd prawe zamierzenia panujących. 12g Wystarczy otworzyć oczy, by zrozumieć - i to nie tylko na podstawie dawnych opowiadań, które zostały nam przekazane, ale nawet przez zwykłe przyjrzenie się temu, co znajduje się tuż pod stopami - ile niesprawiedliwości dokonuje się na skutek nikczemności tych, którzy niegodnie sprawują władzę. 12h Odtąd więc wszystkie nasze wysiłki będą skierowane ku temu, by dla dobra wszystkich ludzi zapewnić państwu niezmącony pokój. 12i Dlatego przy podejmowaniu niezbędnych zmian postanawiamy, że wszystkie sprawy osądzać będziemy zawsze w sposób pełen łaskawości. 12k I tak Aman, syn Amadaty, Macedończyk, który na domiar wszystkiego nie jest Persem z pochodzenia, a przez to samo bardzo daleki od naszej dobroci, znalazł u nas gościnne przyjęcie 12l i doznał od nas tak wielkiej życzliwości, jaką usiłujemy mieć względem każdego narodu, że został nazwany ojcem naszym; wszyscy oddawali mu cześć na klęczkach, gdyż zajmował drugie miejsce na tronie królewskim. 12m Nie zadowalając się tak niezwykłym wyniesieniem, zdążał wyraźnie ku temu, aby nas pozbawić władzy i życia. 12n Naszego zaś wybawiciela i wypróbowanego dobroczyńcę Mardocheusza oraz Esterę, nieposzlakowanej czci towarzyszkę naszej godności królewskiej, usiłował wraz z całym ich narodem doprowadzić do zguby przez liczne swoje przemyślne a kręte knowania. 12o W ten sposób zamierzał zaskoczyć nas osamotnionych, państwo zaś Persów wydać w ręce Macedończyków. 12p Przekonujemy się jednak, że skazani na zagładę przez największego ze zbrodniarzy Żydzi nie są bynajmniej żadnymi przestępcami, ale że, owszem, żyją według najsprawiedliwszych praw 12q i są synami najwyższego, największego i wiecznie żyjącego Boga, któremu my i nasi przodkowie zawdzięczają kwitnący stan naszego królestwa. 12r Postąpicie zatem słusznie, jeśli uznacie za niebyłe listy wysłane przez Amana, syna Amadaty, zważywszy na to, że sprawca tych zbrodni zawisł na szubienicy u bram Suzy wraz z całym swym domem, gdyż Bóg, Pan wszechświata, bezzwłocznie wykonał nad nim zasłużony wyrok. 12s Rozgłoście wszędzie odpis niniejszego dekretu, zezwólcie Żydom na całkowitą swobodę życia według ich własnych praw. Pomagajcie im, by mogli się obronić przed tymi, którzy powstaną przeciwko nim w chwili ucisku, to jest trzynastego dnia, miesiąca dwunastego, czyli miesiąca Adar, jednego i tego samego dnia. 12t Wszechmoc Boga bowiem przemieniła dzień zagłady w dzień wesela dla swego Narodu Wybranego. 12u Wy zaś pośród waszych uroczystych świąt obchodźcie jak najradośniej ten szczególnie wielki dzień, aby i teraz, i w przyszłości stał się on dla nas i dla przyjaźnie usposobionych Persów znakiem wybawienia, dla tych zaś, którzy przeciwko wam występowali, wspomnieniem zagłady. 12x Każde miasto i każdy okręg bez wyjątku, który nie zastosuje się do tego rozkazu, zostanie bezlitośnie zniszczony mieczem i ogniem, tak by po wszystkie czasy stał się niemożliwy do zamieszkania nie tylko dla ludzi, lecz także zgubny dla dzikich zwierząt i ptaków".
###### **Est 8,13**
 Według TM: 8.13-10.2 Treść tego pisma miano ogłosić publicznie jako obowiązującą ustawę we wszystkich prowincjach i podać do wiadomości wszystkim ludom, że Żydzi będą gotowi na oznaczony dzień do wzięcia pomsty na swych wrogach.
###### **Est 8,14**
 Gońcy, dosiadłszy chyżych koni, wyruszyli natychmiast w drogę, gnani rozkazem królewskim. Dekret ogłoszono także w twierdzy Suza.
###### **Est 8,15**
 Mardocheusz wyszedł od króla odziany w niebieskie i białe szaty królewskie, z wielkim złotym diademem oraz w płaszczu z bisioru i purpury na ramieniu, a miasto Suza weseliło się i radowało.
###### **Est 8,16**
 Żydom przypadły w udziale szczęście i wesele, radość i chwała.
###### **Est 8,17**
 Także i w każdej prowincji, i w każdym mieście, dokąd tylko dotarł rozkaz królewski i dekret, panowały wśród Żydów radość i wesele, biesiady i uczty. A wielu spośród pogańskich plemion kraju przechodziło na judaizm, gdyż zaciążył nad nimi strach przed Żydami.
# Est 8 BR
###### **Est 8,1**
 Jeszcze tego samego dnia przekazał król Aswerus w darze królowej Esterze dom nieprzyjaciela Żydów Hamana, a Mardocheuszowi umożliwiono dostęp do króla. Estera powiedziała bowiem królowi, jak blisko Mardocheusz był z nią związany.
###### **Est 8,2**
 Król zdjął z własnego palca pierścień z pieczęcią, który kazał odebrać Hamanowi, i przekazał ów pierścień Mardocheuszowi, a Estera ustanowiła Mardocheusza zarządcą domu Hamana.
###### **Est 8,3**
 Potem jeszcze raz miała Estera rozmowę z królem. Płacząc upadła mu do stóp i błagała go, żeby nie dopuszczał do nieszczęścia, jakie zamierzał sprowadzić na Żydów Agagita Haman.
###### **Est 8,4**
 Król wyciągnął swoje złote berło w stronę Estery, która podniosła się, podeszła do króla
###### **Est 8,5**
 i powiedziała: Jeżeli król uzna to za słuszne, jeżeli znalazłam u niego łaskę, jeżeli to, co mówię, wyda mu się prawne, jeżeli jest dla mnie tak dobry, to niech raczy ogłosić na piśmie rozkaz, żeby odwołano wszystkie zalecenia, które wydał syn Hammedaty, Agagita Haman, zamierzający wyniszczyć Żydów we wszystkich prowincjach królewskich.
###### **Est 8,6**
 Bo jak ja będę patrzeć na nieszczęścia mające spotkać mój lud, jak będę mogła przypatrywać się zagładzie mojego narodu?
###### **Est 8,7**
 Powiedział wtedy król Aswerus do królowej Estery i do Żyda Mardocheusza: Już przekazałem Esterze dom Hamana, którego powieszono na szubienicy, ponieważ odważył się podnieść rękę na Żydów.
###### **Est 8,8**
 Wy sami zaś wydajecie teraz w imieniu króla dekret tak pomyślny dla Żydów, jak uznacie to za słuszne. Opieczętujecie go pierścieniem z pieczęcią królewską. Pismo sporządzono w imieniu króla i opatrzono pieczęcią królewską. Pismo sporządzone w imieniu króla i opatrzone pieczęcią królewską nie może już być odwołane przez niego.
###### **Est 8,9**
 Wezwano tedy pisarzy królewskich, a było to dwudziestego trzeciego dnia trzeciego miesiąca, to jest miesiąca Siwan. Zgodnie z tym, co rozkazał Mardocheusz, sporządzono na piśmie dekret, który został doręczony Żydom, satrapom, zarządcom i księżom stu dwudziestu siedmiu prowincji, od Indii aż po Etiopię. Dekret skierowany do każdej prowincji był sporządzony jej pismem i w jej języku.
###### **Est 8,10**
 Pismo wydano w imieniu króla Aswerusa, opieczętowano je pierścieniem z pieczęcią królewską i rozesłano przez specjalnych gońców na koniach, które pochodziły ze stadnin królewskich.
###### **Est 8,11**
 Na mocy tego dekretu zezwalał król Żydom mieszkającym w różnych miastach połączyć się razem i występować w obronie własnego życia. Wolno im było zaatakować każdy wrogi im lud w każdej prowincji, razem z ich kobietami i dziećmi. Mogli ich nękać, mordować i całkowicie zgładzić, zabierając całe ich mienie.
###### **Est 8,12**
 Miało się to dokonywać równocześnie we wszystkich prowincjach króla Aswerusa, tego samego dnia, to jest trzynastego dnia dwunastego miesiąca, czyli miesiąca Adar. (a) A oto odpis dekretu: (b) Wielki król Aswerus przesyła pozdrowienia zarządcom stu dwudziestu siedmiu prowincji od Indii aż po Etiopię oraz tym wszystkim, którzy są z nami zaprzyjaźnieni. (c) Wielu z tych, którzy dostąpili wysokiego zaszczytu dzięki łaskawości swoich dobroczyńców, wyrażało mimo to niezadowolenie. Usiłowali oni nie tylko krzywdzić naszych najbliższych poddanych, lecz także, nie mogąc znieść już ich dobrobytu, układają zgubne plany unicestwienia swych dobroczyńców. (d) Nie tylko nie chcą, żeby ludzie kierowali się między sobą jakimikolwiek uczuciami wdzięczności, lecz także, rozzuchwaleni słowami swoich pochlebców, którzy nie chcą słyszeć o tym, co dobre, są przeświadczeni, że uda im się uniknąć sprawiedliwego sądu wszystkowiedzącego Boga, który nienawidzi zła. (e) Bardzo często na tych, co sprawują władzę, zły wpływ wywierają ich przyjaciele, którzy, sami zamieszani w różne nadużycia państwowe, czynią rządzących współwinnymi śmierci wielu niewinnych i ściągają na nich w ten sposób ogromne nieszczęścia. (f) I tak, nawet wyraźna życzliwość panujących jest unicestwiona ich złą wolą i zgubnymi radami. (g) Jest to widoczne wyraźnie już w najstarszych przekazach, ale jeszcze wyraźniej można się o tym przekonać przypatrując się dokładnie temu, co dzieje się na naszych oczach. Zepsucie ludzi niegodnie sprawujących władzę doprowadziło do wielkich nieprawości. (h) Musimy się starać, aby zmienić taki stan rzeczy, i zrobić wszystko, aby w przyszłości wszyscy ludzie w naszym państwie, przez nikogo nie nękani, żyli w prawdziwym pokoju. (i) Będziemy badali bardzo dokładnie wszystkie dochodzące do nas wieści, zanim zdecydujemy się na wydanie jakiegoś wyroku. (k) A oto, jak się rzecz miała z Macedończykiem Hamana, synem Hammedaty: Choć początkowo nie miał on nic wspólnego z narodami perskimi i nie korzystał z naszej dobroci, to jednak okazaliśmy mu naszą gościnność. (l) Także i on doświadczył miłości, którą kierujemy się wobec wszystkich narodów. Doszło aż do tego, że mówiono do niego 'nasz ojcze'. Co do odbieranej czci zajmował drugie miejsce po królu. (m) Mimo to nie potrafił zaspokoić swojej żądzy chwały, ale przemyśliwał nad tym, jakby nas pozbawić i władzy, i życia. (n) Usiłował podstępnie sprowadzić zagładę na Mardocheusza, naszego wybawcę i dobroczyńcę, a także na Esterę, cieszącą się w sposób nienaganny udziałem w naszej królewskiej godności, i na cały jej lud. (o) I tak chciał nas pozbawić wszelkich przyjaciół, a dla siebie zagarnąć całą władzę nad wszystkimi Persami i Macedończykami. (p) Ale my już wiemy teraz, że owi Żydzi, których ten zbrodniarz zamierzał zgładzić, nie są przestępcami lecz żyją jak inni obywatele, zgodnie z nakazami prawa. (q) Są oni wyznawcami najwyższego, największego i żywego Boga, który całemu państwu już od czasu najdawniejszych przodków zapewnia porządek i trwałość. (r) I dlatego nie postępujcie zgodnie z rozporządzeniem zawartym w piśmie jakie przysłał syn Hammedaty, Haman. Został on bowiem razem z całą swoją rodziną powieszony przed bramą do miasta Suzy. Tak oto Bóg wszechmocny rychło wymierzył mu dobrze zasłużoną karę. (s) Zechciejcie natomiast porozwieszać wszędzie na widocznych miejscach odpis niniejszego dekretu, który zezwala Żydom żyć spokojnie, zgodnie z ich prawem. Udzielcie im swojej pomocy w tym dniu, na który została wyznaczona ich zagłada, i występujcie przeciwko tym, którzy zaczną ich atakować. Dzień ten - to trzynasty dwunastego miesiąca, czyli miesiąca Adar. (t) Wszechmocny Bóg zaś zamienił ten dzień zamierzonej zagłady wybranego narodu na dzień jego wielkiej radości. (u) Tak więc i wy, oprócz waszych wielkich uroczystości dorocznych, z radością powinniście obchodzić także i to dodatkowe święto, żeby odtąd przynosiło szczęście nam i wszystkim wiernym nam Persom. Dla tych zaś, co na nas czyhają, niech będzie to dzień ostrzeżenia przed czekającą ich zgubą. (x) Wszystkie miasta i wszystkie prowincje, które nie będą przestrzegały tego zarządzenia, zostaną spustoszone beż żadnego miłosierdzia ogniem i mieczem. Nie stanie na ich miejscu już nigdy więcej nie tylko żadna ludzka stopa, lecz stronić od niego będzie także dzika zwierzyna i ptactwo.
###### **Est 8,13**
 W każdej prowincji został ogłoszony jako prawo obowiązujące wszystkich ludzi odpis królewskiego dekretu. Żydzi mieli się przygotować do dokonania w tym dniu zemsty na swych wrogach.
###### **Est 8,14**
 Gońcy na koniach ze stadnin królewskich wyruszyli tedy, przynaglani rozkazem królewskim do pośpiechu. W Suzie również ogłoszono dekret króla.
###### **Est 8,15**
 Mardocheusz zaś, wychodząc od króla, był przybrany w szatę królewską z purpury fioletowej i białego lnu, na głowie miał wielką złotą koronę i na sobie płaszcz z kosztownej tkaniny lnianej przetykanej czerwoną purpurą. W całym mieście Suza panowało wesele i radość.
###### **Est 8,16**
 Żydzi byli bardzo szczęśliwi, wykrzykiwali z radości i nie bali się niczego.
###### **Est 8,17**
 W każdej prowincji, w każdym mieście, wszędzie tam, gdzie ogłoszono dekret królewski i nakaz jego wykonania, Żydzi wznosili radosne okrzyki, jedli i pili i czuli się bardzo szczęśliwi. Wśród wszystkich narodów państwa perskiego wielu przechodziło na wiarę narodu żydowskiego. Strach przed Żydami ogarniał bowiem wszystkich.
# Est 8 WUJ
###### **Est 8,1**
 Dnia onego dał król Asswerus Esther królowej dom Amana nieprzyjaciela żydowskiego, i Mardocheusz wszedł przed oblicze królewskie: bo mu była przyznała Esther, że jej był stryjem.
###### **Est 8,2**
 I wziął król pierścień, który był kazał wziąć od Amana, i dał Mardocheuszowi. A Esther postanowiła Mardocheusza nad domem swoim.
###### **Est 8,3**
 I na tem nie przestając, upadła do nóg królewskich, i płakała, i mówiąc do niego prosiła, aby złość Amana Agagitczyka i wymysły jego niecnotliwe, które był wymyślił przeciw Żydom, rozkazał wniwecz obrócić.
###### **Est 8,4**
 A on według zwyczaju ściągnął ręką sceptrum złote, którem się łaski znak pokazował, a ona wstawszy stanęła przed nim,
###### **Est 8,5**
 I rzekła: Jeśli się podoba królowi, a jeślim nalazła łaskę przed oczyma jego, a prośba moja nie zda mu się przeciwna, proszę, aby nowemi listy stare listy Amana zdrajcę i nieprzyjaciela Żydów, w których rozkazał je wytracić we wszystkich ziemiach królewskich, kasowane były.
###### **Est 8,6**
 Bo jakoż będę mogła znosić zabijanie i mordowanie narodu mojego?
###### **Est 8,7**
 I odpowiedział król Asswerus Estherze królowej i Mardocheuszowi Żydowi: Dom Amanów dałem Esther, a samego kazałem zawiesić na szubienicy, iż śmiał rękę ściągnąć na Żydy.
###### **Est 8,8**
 A tak napiszcie Żydom, jako się wam podoba, imieniem królewskiem, zapieczętowawszy listy sygnetem moim. Bo ten był obyczaj, iż listom które imieniem królewskim posyłano, a sygnetem jego zapieczętowano, żaden się nie śmiał sprzeciwić.
###### **Est 8,9**
 I zawoławszy pisarzów i podpisków królewskich (a był czas miesiąca trzeciego, który zowią Syban) dwudziestego i trzeciego dnia jego napisano listy, jako był chciał Mardocheusz, do Żydów i do książąt, i do Oekonomów, i Sędziów, którzy byli przełożeni we stu i dwudziestu, i siedmi ziemiach od Indyiej aż do Aethyoptej: krainie i krainie, narodowi i narodowi wedle języków i pisem ich: i Żydom jako czytać mogli i słuchać.
###### **Est 8,10**
 A te listy, które posyłano imieniem królewskiem, sygnetem jego zapieczętowane są i rozesłane przez prędkie posły: którzyby po wszystkich ziemiach biegając one pierwsze listy nowemi poselstwy uprzedzili:
###### **Est 8,11**
 Którym król rozkazał, aby szli do żydów w każdem mieście, i kazali się im zgromadzić, aby się zastawili za dusze swe, a wszystkie swe nieprzyjacioły, z żonami, z dziećmi, i ze wszystkiemi domy pobili i wygładzili, i korzyści ich pobrali.
###### **Est 8,12**
 I naznaczon jest po wszystkich ziemiach jeden dzień pomsty, to jest, trzynasty miesiąca dwunastego Adar.
###### **Est 8,13**
 A summa listu ta była, aby we wszystkich ziemiach i narodach, które były pod państwem Asswerusa króla, wiadomo było, iż żydowie byli gotowi mścić się nad nieprzyjacioły swemi.
###### **Est 8,14**
 I bieżeli podwodnicy prędcy poselstwa nosząc, a wyrok królewski rozbito w Susan.
###### **Est 8,15**
 A Mardocheusz, wychodząc z pałacu i od oczu królewskich, świecił się w szatach królewskich, to jest w Hiacyntowych, i w białych: nosząc na głowie koronę złotą, i odziany płaszczem jedwabnym i szarłotowym. I wszystko miasto weseliło się i radowało.
###### **Est 8,16**
 A Żydom nowa światłość zdała się wschodzić, wesele, cześć, i tańce.
###### **Est 8,17**
 I wszystkich narodów, miast i krain, gdziekolwiek mandaty królewskie przychodziły, dziwne radości, biesiady, i uczty, i święto: tak, iż mnodzy inszego narodu i sekty, na wiarę i ceremonie przystawali: Bo był na wszystkie przypadł wielki strach imienia żydowskiego.
