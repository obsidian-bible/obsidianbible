# Ezd 5 BT5
###### **Ezd 5,1**
 Wtedy Aggeusz i Zachariasz, syn Iddo, prorocy, ogłosili Żydom w Judzie i w Jerozolimie proroctwo w imieniu Boga Izraela, który nad nimi czuwał.
###### **Ezd 5,2**
 Zatem Zorobabel, syn Szealtiela, i Jozue, syn Josadaka, zabrali się do budowy domu Bożego w Jerozolimie, a z nimi byli prorocy Boga, którzy ich zachęcali.
###### **Ezd 5,3**
 Wówczas przyszli do nich Tattenaj, namiestnik Transeufratei, i Sztarboznaj oraz ich towarzysze i tak im powiedzieli: «***Kto wam kazał dom ten budować i to oszalowanie wykończyć?***»
###### **Ezd 5,4**
 Następnie tak ich pytali: «***Jak się nazywają ludzie, którzy wznoszą tę budowlę?***»
###### **Ezd 5,5**
 Ale oko Boga ich czuwało nad starszyzną żydowską, tak że ich tamci od budowania nie powstrzymali, aż doszło doniesienie do Dariusza i doręczono im dokument w tej sprawie.
###### **Ezd 5,6**
 Odpis listu, który Tattenaj, namiestnik Transeufratei, i Sztarboznaj oraz towarzysze jego, Persowie w Transeufratei, posłali do króla Dariusza.
###### **Ezd 5,7**
 Posłali do niego doniesienie, w którym tak było napisane:«***Królowi Dariuszowi – pełnego szczęścia!***
###### **Ezd 5,8**
 ***Niech król przyjmie do wiadomości, że udaliśmy się do domu Boga wielkiego w krainie judzkiej. Jest on odbudowywany z kamienia ciosowego i drewnem okłada się ściany. Ta robota jest starannie wykonywana i posuwa się naprzód.***
###### **Ezd 5,9**
 ***Wtedy zapytaliśmy owych starszych, mówiąc do nich tak: Kto wam kazał dom ten budować i to oszalowanie wykończyć?***
###### **Ezd 5,10**
 ***Również pytaliśmy ich o ich imiona, by cię powiadomić. Toteż podajemy imiona mężów stojących na ich czele.***
###### **Ezd 5,11**
 ***I odpowiedzieli nam w sposób następujący: My jesteśmy sługami Boga nieba i ziemi i odbudowujemy dom, który – niegdyś wzniesiony – stał przez wiele lat, a wielki król izraelski zbudował go i wykończył.***
###### **Ezd 5,12**
 ***Ponieważ jednak przodkowie nasi rozgniewali Boga niebios, wydał ich Chaldejczykowi Nabuchodonozorowi, królowi babilońskiemu. On zburzył ten dom, a lud uprowadził do Babilonu.***
###### **Ezd 5,13**
 ***Ale w pierwszym roku [panowania] Cyrusa, króla babilońskiego, kazał ten król odbudować ten dom Boży.***
###### **Ezd 5,14**
 ***Również co do złotych i srebrnych sprzętów domu Bożego, które Nabuchodonozor zabrał ze świątyni w Jerozolimie i przeniósł do świątyni w Babilonie, to król Cyrus wydobył je ze świątyni w Babilonie i wręczył pewnemu mężowi, imieniem Szeszbassar, którego ustanowił namiestnikiem***
###### **Ezd 5,15**
 ***i któremu rzekł: Weź te sprzęty; idź złożyć je w świątyni w Jerozolimie, a dom Boży ma być odbudowany na dawnym miejscu.***
###### **Ezd 5,16**
 ***Zatem ów Szeszbassar przyszedł i położył fundamenty domu Bożego w Jerozolimie. Odtąd aż do dziś buduje się go, lecz jeszcze nie jest on ukończony.***
###### **Ezd 5,17**
 ***A teraz: Jeśli się królowi podoba, niech przeprowadzą poszukiwania w skarbcach królewskich, tamże w Babilonie: czy rzeczywiście został przez króla Cyrusa wydany rozkaz odbudowy tego domu Bożego w Jerozolimie, a rozstrzygnięcie królewskie w tej sprawie niech nam przyślą***».
# Ezd 5 PAU
###### **Ezd 5,1**
 Wtedy właśnie wystąpili prorocy Aggeusz i Zachariasz, syn Iddo, i ogłosili Żydom w Jerozolimie i w Judei proroctwo w imieniu Boga Izraela, który czuwał nad nimi.
###### **Ezd 5,2**
 Wówczas Zorobabel, syn Szealtiela, i Jozue, syn Josadaka, podjęli na nowo pracę przy budowie domu Bożego w Jerozolimie, zachęcani przez proroków Boga, którzy im towarzyszyli.
###### **Ezd 5,3**
 Ale zaraz przybyli do nich Tattenaj, namiestnik prowincji Transeufratei, Szetar-Boznaj i inni urzędnicy z zapytaniem: „Kto wam pozwolił budować ten dom i wykładać jego ściany drewnem?”.
###### **Ezd 5,4**
 Pytali ich także: „Jak nazywają się budowniczy wznoszący tę budowlę?”.
###### **Ezd 5,5**
 Ale opatrzność Boża czuwała nad starszyzną żydowską tak, że mogli nadal pracować. Tamci jednak wysłali doniesienia do Dariusza i otrzymali w tej sprawie jego odpowiedź.
###### **Ezd 5,6**
 Oto odpis listu, który Tattenaj, namiestnik prowincji Transeufrateia, i Szetar-Boznaj oraz urzędnicy prowincji perskich za Eufratem wysłali do króla Dariusza.
###### **Ezd 5,7**
 W swoim doniesieniu tak napisali: „Królowi Dariuszowi - wszelkiej pomyślności!
###### **Ezd 5,8**
 Niech będzie królowi wiadomo, że udaliśmy się do prowincji judzkiej, do domu potężnego Boga. Dom ten jest odbudowywany z kamienia ciosanego, a ściany wykładane są drewnem. Prace są wykonywane gorliwie i sprawnie postępują naprzód.
###### **Ezd 5,9**
 Spotkaliśmy ich starszyznę i zadaliśmy im pytanie: Kto pozwolił wam budować ten dom i wykładać jego ściany drewnem?
###### **Ezd 5,10**
 Pytaliśmy ich także o ich imiona, by cię o nich poinformować i przesłać listę mężczyzn, którzy im przewodzą.
###### **Ezd 5,11**
 Na to oni odpowiedzieli: «My jesteśmy sługami Boga nieba i ziemi i odbudowujemy dom, który stał tu przez wiele lat od zamierzchłych czasów, a wybudował go i wykończył wielki król Izraela.
###### **Ezd 5,12**
 Ponieważ przodkowie nasi rozgniewali Boga niebios, On wydał ich w ręce króla Babilonu, chaldejczyka Nabuchodonozora, który zburzył ten dom, a lud uprowadził do Babilonu.
###### **Ezd 5,13**
 Lecz Cyrus, król Babilonii, w pierwszym roku swojego panowania wydał polecenie, by odbudować ten dom Boży.
###### **Ezd 5,14**
 Co więcej: wszystkie złote i srebrne naczynia z domu Bożego, które Nabuchodonozor zabrał ze świątyni w Jerozolimie i umieścił w świątyni w Babilonie, król Cyrus kazał wziąć ze świątyni w Babilonie i przekazać niejakiemu Szeszbassarowi, którego mianował namiestnikiem.
###### **Ezd 5,15**
 Król dał mu następujące polecenie: 'Oto naczynia! Weź i zanieś je osobiście do świątyni w Jerozolimie. Dom Boga niech będzie odbudowany na swoim dawnym miejscu'.
###### **Ezd 5,16**
 Wówczas ów Szeszbassar przybył i położył fundamenty domu Bożego w Jerozolimie. Od tego czasu trwa budowa aż do dzisiaj i nie jest jeszcze dokończona».
###### **Ezd 5,17**
 A zatem: Jeżeli król uzna to za właściwe, niech poszukają w archiwach królewskich w Babilonie, czy rzeczywiście istnieje dokument króla Cyrusa zezwalający na odbudowę tego domu Bożego w Jerozolimie, i niech decyzja w tej sprawie zostanie nam przesłana”.
# Ezd 5 BP
###### **Ezd 5,1**
 Wówczas prorocy Aggeusz i Zachariasz, syn Iddy, pełnili urząd prorocki wśród Judejczyków w Judei i w Jeruzalem w Imię Boga Izraela, który czuwał nad nimi.
###### **Ezd 5,2**
 Wtedy wystąpili Zorobabel, syn Szealtiela, i Jozue, syn Jocadaka, i rozpoczęli budować Świątynię Boga w Jeruzalem, a Prorocy Boga byli z nimi i umacniali ich.
###### **Ezd 5,3**
 W owym czasie przybyli do nich Tattenaj, zarządca [kraju] za Eufratem, oraz Szetar-Boznaj ze swymi towarzyszami i spytali ich: Kto wam pozwolił budować tę Świątynię i wznosić te mury?
###### **Ezd 5,4**
 Następnie pytali ich o imiona mężów, którzy prowadzą tę budowę.
###### **Ezd 5,5**
 Oko Boga czuwało jednak nad starszyzną Judejczyków, tak że nie nakazano im przerwania robót, dopóki do Dariusza nie dojdzie sprawozdanie i dopóki nie zostanie im doręczona odpowiedź w tej sprawie.
###### **Ezd 5,6**
 Odpis listu, który wysłali do króla Dariusza: Tattenaj, zarządca kraju za Eufratem, Szetar-Boznaj i jego towarzysze, niżsi urzędnicy kraju za Eufratem.
###### **Ezd 5,7**
 Posłali do niego sprawozdanie, w którym pisali: "Królowi Dariuszowi wszelkiej pomyślności!
###### **Ezd 5,8**
 Podajemy królowi do wiadomości, że udaliśmy się do krainy judzkiej i do Domu wielkiego Boga. Wznosi się go z bloków kamiennych, a ściany jego wykłada się drzewem. Roboty są prowadzone z całą starannością i rosną w ich rękach.
###### **Ezd 5,9**
 Pytaliśmy tedy starszyznę, tak mówiąc do nich: "Kto wam pozwolił odbudowywać tę Świątynię i wykańczać te mury?"
###### **Ezd 5,10**
 Pytaliśmy także o ich imiona, abyś je poznał i byśmy mogli przedstawić ci na piśmie imiona mężów, stojących na ich czele.
###### **Ezd 5,11**
 Oni zaś dali nam taką odpowiedź: "Jesteśmy sługami Boga nieba i ziemi i odbudujemy Świątynię, którą przed wielu laty wzniesiono, a którą zbudował i wykończył wielki król Izraela.
###### **Ezd 5,12**
 Lecz gdy ojcowie nasi rozgniewali Boga niebios, wydał On ich w ręce Nebukadnezara, króla Babilonu, Chaldejczyka, który zburzył tę Świątynię i uprowadził lud do niewoli w Babilonie.
###### **Ezd 5,13**
 Jednak w pierwszym roku swego panowania Cyrus, król Babilonu, dał polecenie, aby Świątynię Boga odbudowano.
###### **Ezd 5,14**
 Również złote i srebrne sprzęty z Domu Bożego, które Nebukadnezar zabrał ze Świątyni w Jeruzalem i zawiózł do świątyni w Babilonie, polecił król Cyrus zabrać ze świątyni w Babilonie. Zostały one przekazane mężowi imieniem Szeszbaccar, którego ustanowił namiestnikiem.
###### **Ezd 5,15**
 Rozkazał mu: Weź te sprzęty, idź i złóż je w Świątyni w Jeruzalem! A Świątynię Boga należy odbudować na tym samym miejscu.
###### **Ezd 5,16**
 Następnie przybył tenże Szeszbaccar i położył fundamenty pod Świątynię Boga w Jeruzalem. Od tego czasu aż do chwili obecnej buduje się ją, ale jej jeszcze nie ukończono.
###### **Ezd 5,17**
 Jeżeli taka jest więc wola króla, niech szukają w skarbcach królewskich, znajdujących się tam w Babilonie [i niech zbadają], czy rzeczywiście został wydany przez króla Cyrusa rozkaz, by odbudować tę Świątynię Boga w Jeruzalem, i niech nam król przekaże swoją wolę w tej sprawie".
# Ezd 5 BR
###### **Ezd 5,1**
 Prorocy Aggeusz i Zachariasz, syn Iddo, zaczęli wtedy przemawiać w imieniu Boga Izraela do Żydów, którzy mieszkali na ziemi judzkiej i w Jerozolimie.
###### **Ezd 5,2**
 Powstali tedy Zorobabel, syn Szealtiela, i Jozue, syn Josadaka, i rozpoczęli na nowo budowę świątyni Jahwe w Jerozolimie. Przyłączyli się też do nich inni prorocy Pańscy, którzy podnosili ich na duchu.
###### **Ezd 5,3**
 Wtedy przyszli do nich Tattenaj, zarządca krainy położonej za Rzeką, oraz Sztarboznaj ze swoimi współpracownikami i tak zaczęli do nich mówić:
###### **Ezd 5,4**
 Kto pozwolił wam budować tę świątynię i wznosić mury [obronne]? Jak nazywają się ludzie prowadzący budowę?
###### **Ezd 5,5**
 Ale oko Boga starszych żydowskich czuwało nad nimi. Nie zdołano przerwać prac, które trwały aż do czasu przesłania Dariuszowi specjalnego listu w tej sprawie.
###### **Ezd 5,6**
 Oto treść listu, który posłali do króla Dariusza Tattenaj, zarządca krainy położonej za Rzeką, oraz Sztarboznaj ze swymi współpracownikami, pozostałymi urzędnikami w krainie położonej za Rzeką.
###### **Ezd 5,7**
 Posłali listy-sprawozdanie, w którym pisali: Królowi Dariuszowi - wszelkiego dobra.
###### **Ezd 5,8**
 Pragniemy powiadomić cię, o królu, że byliśmy w ziemi judzkiej i oglądaliśmy świątynię wielkiego Boga. Budują tę świątynię z ogromnych bloków kamiennych, a na murach już układają [belkowania z] drewna. Prace posuwają się szybko i są wykonywane przez nich z wielką starannością.
###### **Ezd 5,9**
 Zwróciliśmy się do starszych z zapytaniem: Kto pozwolił wam budować tę świątynię i wznosić mury [obronne]?
###### **Ezd 5,10**
 Zażądaliśmy także ujawnienia imion ludzi [prowadzących budowę], byśmy mogli ci je przekazać. Podajemy ci zatem imiona ludzi stojących na czele.
###### **Ezd 5,11**
 A oto, co oni nam odpowiedzieli: Jesteśmy sługami Boga niebios i ziemi. Odbudowujemy świątynię, która została wzniesiona na tym miejscu przed wielu laty i wykończona ostatecznie przez wielkiego króla izraelskiego.
###### **Ezd 5,12**
 Potem, ponieważ ojcowie nasi stali się powodem zagniewania Boga Zastępów niebieskich, wydał ich Bóg w ręce króla babilońskiego Nabuchodonozora, Chaldejczyka, który zburzył tę świątynię, a cały lud uprowadził do Babilonu.
###### **Ezd 5,13**
 Jednakże Cyrus, król babiloński, już w pierwszym roku swego panowania kazał odbudować tę świątynię Pańską.
###### **Ezd 5,14**
 Co więcej, król Cyrus kazał zwrócić wszystkie naczynia złote i srebrne, które król Nabuchodonozor zabrał kiedyś ze świątyni w Babilonie. Wszystko zostało zwrócone na ręce Szeszbassara, ówczesnego zarządcy.
###### **Ezd 5,15**
 Powiedział wtedy [Cyrus]: Weź te naczynia, niech wrócą do świątyni Jerozolimskiej. Sama zaś świątynia Pańska niech zostanie odbudowana na dawnym miejscu.
###### **Ezd 5,16**
 Wróciwszy tedy Szeszbassar położył fundamenty pod świątynię Pańską w Jerozolimie. Od tamtego czasu trwa odbudowa świątyni i prace nie zostały jeszcze ukończone.
###### **Ezd 5,17**
 Gdybyś to uznał za słuszne, o królu, wydaj polecenie, żeby przeszukano skarbce w pałacu królewskim w Babilonie, a być może znajdą dekret króla Cyrusa zezwalający na budowę tej świątyni Pańskiej w Jerozolimie. I niech nam potem prześlą wolę twoją, o królu, w tej sprawie.
# Ezd 5 WUJ
###### **Ezd 5,1**
 A Aggeus Prorok, i Zacharyasz syn Addo prorokowali prorokując do Żydów, którzy w Żydostwie w Jeruzalem, w imię Boga Izraelskiego.
###### **Ezd 5,2**
 Tedy powstali Zorobabel syn Salathiel, i Jozue syn Josedek, i poczęli budować kościół Boży w Jeruzalem, a z nimi prorocy Boży pomagający im.
###### **Ezd 5,3**
 W ten czas przyszedł do nich Thathanaj, który był książęciem za rzeką, i Stharbuzanaj, i radzce ich: i tak im mówili: Kto wam radził, żebyście ten dom budowało mury jego naprawowali?
###### **Ezd 5,4**
 Na cośmy im odpowiedzieli, co za imiona były ludzi, którzy byli przyczyną onego budowania.
###### **Ezd 5,5**
 A oko Boga ich było nad starszymi żydowskimi, i zahamować ich nie mogli, i zdało się, aby rzecz do Daryusza była odniesiona, a na ten czas, aby dosyć uczynili, przeciw onemu oskarżeniu.
###### **Ezd 5,6**
 Kopia listu, który posłał Thathanaj książę krainy za rzeką, i Stharbuzanaj, i radzce jego Arphasachczycy, którzy byli za rzeką, do Daryusza króla.
###### **Ezd 5,7**
 Mowa, którą mu byli posłali, tak była napisana: Daryuszowi królowi pokój wszelaki.
###### **Ezd 5,8**
 Niech będzie wiadomo królowi, żeśmy jeździli do żydowskiej krainy, do domu Boga wielkiego, który z kamienia nieciosanego budują, i drzewo w ściany kładą: a tę robotę pilno wywodzą, i roście w ręku ich.
###### **Ezd 5,9**
 A tak pytaliśmy starszych onych, i takeśmy im rzekli: Kto wam dał moc, abyście ten dom budowali, i mury te naprawowali?
###### **Ezd 5,10**
 Ale i imion ich pytaliśmy od nich, abyśmyć oznajmili: i wypisaliśmy imiona tych mężów, którzy są między nimi przedniejszy.
###### **Ezd 5,11**
 A oni nam odpowiedzieli temi słowy: My jesteśmy słudzy Boga nieba i ziemie, i budujemy kościół, który był zbudowany przed tą wielą lat, i który był król Izraelski wielki zbudował i wywiódł.
###### **Ezd 5,12**
 A gdy ojcowie naszy wzruszyli ku gniewu Boga niebieskiego, dał je w ręce Nabuchodonozora króla Babilońskiego Chaldejczyka, dom też ten zburzył, i lud jego przeniósł do Babilonu.
###### **Ezd 5,13**
 A pierwszego roku Cyrusa króla Babilońskiego, Cyrus król dał wyrok, aby ten dom Boży zbudowano.
###### **Ezd 5,14**
 Bo i naczynia kościoła Bożego złote i srebrne, które był Nabuchodonozor wybrał z kościoła, który był w Jeruzalem, i zaniósł je był do zboru Babilońskiego: wyniósł król Cyrus ze sboru Babilońskiego, i dano je niejakiemu Sassabasarowi, którego też książęciem postanowił.
###### **Ezd 5,15**
 I rzekł mu: Weźmi te naczynia, a idź, a połóż je w kościele, który jest w Jeruzalem, a dom Boży niech będzie zbudowany na miejscu swojem.
###### **Ezd 5,16**
 Na ten czas tedy on Sassabasar przyszedł i założył fundamenty Kościoła Bożego w Jeruzalem, i od onego czasu aż dotąd buduje się, a jeszcze nie jest skończony.
###### **Ezd 5,17**
 Teraz tedy, jeśli się zda rzecz dobra królowi, niech szukają w Bibliotece królewskiej, która jest w Babilonie, jeśli król Cyrus rozkazał budować dom Boży w Jeruzalem, a wolą królewską w tej rzeczy niechaj do nas pośle.
