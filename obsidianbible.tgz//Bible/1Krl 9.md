# 1Krl 9 BT5
###### **1Krl 9,1**
 Kiedy Salomon ukończył budowę świątyni Pańskiej i pałacu królewskiego oraz wszystkiego, co z upodobaniem chciał wykonać,
###### **1Krl 9,2**
 Pan ukazał się Salomonowi po raz drugi, odkąd dał mu się widzieć w Gibeonie.
###### **1Krl 9,3**
 Pan tak przemówił do niego: «***Wysłuchałem twoją modlitwę i twoje błaganie, które zanosiłeś przede Mną. Uświęciłem tę świątynię, którą zbudowałeś dla umieszczenia w niej na wieki mego imienia. Po wszystkie dni będą na nią zwrócone moje oczy i moje serce.***
###### **1Krl 9,4**
 ***Ty zaś, jeżeli będziesz postępował wobec Mnie, jak postępował twój ojciec, Dawid, w szczerości serca i uczciwości wypełniając wszystko, do czego cię zobowiązałem, jeżeli będziesz strzegł moich praw i nakazów,***
###### **1Krl 9,5**
 ***to na wieki utrwalę tron twego królowania nad Izraelem, jak przyrzekłem niegdyś twemu ojcu, Dawidowi, mówiąc: Nie będzie ci odjęty mąż zasiadający na tronie Izraela.***
###### **1Krl 9,6**
 ***Ale jeżeli zupełnie odwrócicie się ode Mnie wy i wasi synowie i nie będziecie przestrzegali moich poleceń i praw, które wam dałem, oraz zechcecie pójść i służyć cudzym bogom i będziecie im oddawać pokłon,***
###### **1Krl 9,7**
 ***to wytępię Izraela z powierzchni ziemi, którą im dałem, a świątynię, którą poświęciłem memu imieniu, odtrącę od mego oblicza. Izrael zaś będzie przedmiotem przypowieści i pośmiewiska u wszystkich narodów,***
###### **1Krl 9,8**
 ***a świątynia ta będzie ruiną. Każdy przechodzący koło niej będzie zgrozą przejęty i zagwiżdże szyderczo. Gdy będą pytać: Dlaczego Pan tak uczynił temu krajowi i tej świątyni?***
###### **1Krl 9,9**
 ***odpowiedzą: Dlatego że opuścili Pana, Boga swego, który wyprowadził ich przodków z ziemi egipskiej, a upodobali sobie bogów cudzych oraz im oddawali pokłon i służyli; dlatego Pan sprowadził na nich całe to nieszczęście***».
###### **1Krl 9,10**
 Po upływie dwudziestu lat, w ciągu których Salomon zbudował obydwa gmachy, to jest świątynię Pańską i pałac królewski,
###### **1Krl 9,11**
 a Hiram, król Tyru, dostarczał Salomonowi drewna cedrowego i drewna cyprysowego, i złota, stosownie do wszelkiego jego zapotrzebowania, król Salomon dał Hiramowi za to dwadzieścia miast w ziemi galilejskiej.
###### **1Krl 9,12**
 Kiedy Hiram wyjechał z Tyru, aby obejrzeć miasta, które mu dał Salomon, te mu się nie spodobały.
###### **1Krl 9,13**
 Powiedział więc: «***Cóż to są za miasta, te, które mi dałeś, mój bracie?***» Dlatego nazwał je Ziemią Kabul po dziś dzień.
###### **1Krl 9,14**
 Jednak Hiram dostarczył królowi sto dwadzieścia talentów złota.
###### **1Krl 9,15**
 Tak przedstawiała się sprawa robot przymusowych, które król Salomon podjął celem budowy świątyni Pańskiej, swego pałacu Millo, murów jerozolimskich, Chasor, Megiddo i Gezer.
###### **1Krl 9,16**
 Faraon, król egipski, nadciągnął i zdobywszy Gezer, spalił je, a Kananejczyków zamieszkujących to miasto wytępił. Później dał je w posagu swej córce, żonie Salomona.
###### **1Krl 9,17**
 Salomon zaś odbudował Gezer i dolne Bet-Choron,
###### **1Krl 9,18**
 a także Baalat i Tamar na pustyni, w kraju;
###### **1Krl 9,19**
 ponadto wszystkie miasta-spichlerze, które należały do Salomona, miasta dla rydwanów i miasta dla konnicy oraz wszystko, co spodobało się Salomonowi wybudować w Jerozolimie, na Libanie i w każdym kraju będącym pod jego władzą.
###### **1Krl 9,20**
 Całą ludność pozostałą z Amorytów, Chittytów, Peryzzytów, Chiwwitów oraz Jebusytów, która nie była izraelska,
###### **1Krl 9,21**
 stanowiąc potomstwo pozostałe w kraju po tych, których Izraelici nie zdołali poddać klątwie, Salomon wziął do robot przymusowych, po dziś dzień.
###### **1Krl 9,22**
 Z Izraelitów zaś nikogo nie skazał na niewolę, gdyż byli oni wojownikami i jego podwładnymi, jak również wodzami przybocznymi, dowódcami jego rydwanów oraz konnicy.
###### **1Krl 9,23**
 Salomon miał pięciuset pięćdziesięciu wyższych urzędników zarządzających pracami. Oni to nadzorowali lud wykonujący pracę.
###### **1Krl 9,24**
 Skoro tylko córka faraona wyprowadziła się z Miasta Dawidowego do własnego domu, który wzniósł dla niej, Salomon zbudował Millo.
###### **1Krl 9,25**
 Trzy razy w roku Salomon składał ofiary całopalne i ofiary biesiadne na ołtarzu, który zbudował Panu, oraz składał przed Panem < ofiary kadzielne >, odkąd wykończył świątynię.
###### **1Krl 9,26**
 Król Salomon zbudował flotę w Esjon-Geber koło Elat nad brzegiem Morza Czerwonego, w kraju Edomu.
###### **1Krl 9,27**
 Hiram zaś posyłał do tej floty swoje sługi, żeglarzy znających morze, [aby byli] razem ze sługami Salomona.
###### **1Krl 9,28**
 Po pewnym czasie wyruszyli do Ofiru i wzięli stamtąd czterysta dwadzieścia talentów złota, i przywieźli królowi Salomonowi.
# 1Krl 9 PAU
###### **1Krl 9,1**
 Kiedy Salomon ukończył budowę domu PANA i pałacu królewskiego oraz wykonał wszystko, co zamierzał,
###### **1Krl 9,2**
 po raz drugi ukazał mu się PAN, podobnie jak wtedy, gdy objawił mu się w Gabaonie.
###### **1Krl 9,3**
 PAN mu powiedział: „Usłyszałem twoją modlitwę i błaganie, które zanosiłeś do Mnie. Ten dom zatem, który zbudowałeś, uświęciłem, aby odtąd moje imię zawsze w nim przebywało. Moje oczy i serce ciągle będą w nim obecne.
###### **1Krl 9,4**
 Jeśli więc ty będziesz Mi służył z pełnym oddaniem, jak twój ojciec, Dawid, i wypełnisz wszystko, do czego cię zobowiązałem; jeśli będziesz przestrzegał moich praw i nakazów,
###### **1Krl 9,5**
 wówczas Ja utrwalę na wieki twoją władzę królewską nad Izraelem, tak jak obiecałem twemu ojcu, Dawidowi: «Nie zabraknie ci następcy na tronie Izraela».
###### **1Krl 9,6**
 Jeśli jednak wy lub wasze dzieci odwrócicie się ode Mnie i nie będziecie przestrzegać moich przykazań i praw, do których was zobowiązałem, a pójdziecie służyć i oddawać cześć innym bogom,
###### **1Krl 9,7**
 wtedy wytępię Izraela i usunę ich z ziemi, którą im dałem, a dom, który uświęciłem moim imieniem, odrzucę od siebie. Izrael zaś stanie się przestrogą, a nawet pośmiewiskiem dla wszystkich ludów.
###### **1Krl 9,8**
 Ten dom legnie w gruzach. Każdy, kto będzie przechodził, na jego widok wpadnie w osłupienie, zagwiżdże i zapyta: «Dlaczego PAN postąpił tak z tym krajem i z tym domem?».
###### **1Krl 9,9**
 Odpowiedzą mu: «Ponieważ opuścili PANA, swojego Boga, który wyprowadził ich przodków z ziemi egipskiej, i związali się z innymi bogami, służąc im i oddając cześć, dlatego też PAN sprowadził na nich całe to nieszczęście»”.
###### **1Krl 9,10**
 Po upływie dwudziestu lat, które Salomon poświęcił na budowę obu budynków: domu PANA i pałacu królewskiego,
###### **1Krl 9,11**
 oddał Hiramowi, królowi Tyru, dwadzieścia miast na terenie Galilei. Hiram bowiem dostarczył Salomonowi każdą potrzebną ilość drewna cedrowego i cyprysowego oraz złota.
###### **1Krl 9,12**
 Hiram więc wyruszył z Tyru, aby obejrzeć miasta, które dał mu Salomon, ale mu się nie spodobały.
###### **1Krl 9,13**
 Wtedy zapytał: „Cóż to za miasta mi dałeś, mój bracie?”. Dlatego też nadał im nazwę Ziemia Kabul, którą noszą aż do dnia dzisiejszego.
###### **1Krl 9,14**
 Hiram posłał królowi sto dwadzieścia talentów złota.
###### **1Krl 9,15**
 Król Salomon zarządził roboty przymusowe, żeby wybudować dom PANA, swój pałac, Millo, mury obronne Jerozolimy, Chasor, Megiddo i Gezer.
###### **1Krl 9,16**
 Gezer zostało najpierw zdobyte przez faraona, króla Egiptu, który atakując je, spalił doszczętnie, a zamieszkujących w nim Kananejczyków wymordował. Dał je później jako posag ślubny swojej córce, żonie Salomona.
###### **1Krl 9,17**
 Salomon zaś je odbudował. Wzniósł także Dolne Bet-Choron,
###### **1Krl 9,18**
 Baalat i Tamar na pustyni,
###### **1Krl 9,19**
 jak również wszystkie miasta, w których znajdowały się magazyny żywności. Ponadto zbudował garnizony, w których rozmieszczono rydwany i konie. Zrealizował swoje plany budowlane w Jerozolimie, w Libanie oraz na całym obszarze podległym jego panowaniu.
###### **1Krl 9,20**
 Wszystkich ocalałych Amorytów, Chetytów, Peryzzytów, Chiwwitów oraz Jebusytów, nienależących do Izraela -
###### **1Krl 9,21**
 potomków tych, których Izraelici nie zdołali wyniszczyć - Salomon zmusił do robót publicznych. Tak jest po dziś dzień.
###### **1Krl 9,22**
 Nikogo z Izraelitów Salomon nie zmuszał do robót publicznych. Byli oni żołnierzami, urzędnikami, wodzami, oficerami oraz dowódcami rydwanów i jeźdźców.
###### **1Krl 9,23**
 Było również pięciuset pięćdziesięciu nadzorców robót, którzy sprawowali władzę nad ludem i nadzorowali prace zlecone przez Salomona.
###### **1Krl 9,24**
 Dla swojej żony, córki faraona, zbudował osobny pałac i tam ją przeniósł z Miasta Dawida. Wtedy wybudował również Millo.
###### **1Krl 9,25**
 Trzy razy w roku Salomon składał ofiary całopalne i ofiary wspólnotowe na ołtarzu, który zbudował dla PANA, oraz spalał w ofierze kadzidło przed PANEM. Tak ukończył budowę Jego domu.
###### **1Krl 9,26**
 Król Salomon zbudował również flotę w Esjon-Geber, które znajduje się w ziemi Edomu, w Elat nad brzegiem Morza Czerwonego.
###### **1Krl 9,27**
 Hiram posłał swoich ludzi, doświadczonych żeglarzy, aby razem z poddanymi Salomona służyli na statkach jego floty.
###### **1Krl 9,28**
 Oni to popłynęli do Ofiru, gdzie załadowali czterysta dwadzieścia talentów złota i przywieźli je do króla Salomona.
# 1Krl 9 BP
###### **1Krl 9,1**
 Gdy Salomon ukończył budowę Świątyni Jahwe i pałacu królewskiego oraz wszystko, co według swych zamierzeń pragnął wykonać,
###### **1Krl 9,2**
 Jahwe ukazał się Salomonowi po raz drugi, podobnie jak mu się objawił w Gibeon.
###### **1Krl 9,3**
 I rzekł mu Jahwe: Wysłuchałem twoją modlitwę i twoje błaganie, które zaniosłeś przed moje oblicze. Poświęciłem tę Świątynię, którą zbudowałeś, aby Imię moje pozostało tam na wieki. Oczy moje i serce moje będą tam po wszystkie dni.
###### **1Krl 9,4**
 Jeśli ty zaś będziesz postępował wobec mnie tak, jak postępował Dawid, twój ojciec, w czystości serca i prawości, wypełniając dokładnie wszystko, co ci nakazałem, i będziesz strzegł mojego Prawa i moich zarządzeń,
###### **1Krl 9,5**
 [wówczas] utwierdzę na wieki tron twojego królestwa nad Izraelem, jak [to] obiecałem Dawidowi, twojemu ojcu, mówiąc: Nie zabraknie ci potomka na tronie Izraela.
###### **1Krl 9,6**
 Jeśli jednak wy i synowie wasi naprawdę się odwrócicie ode mnie i nie będziecie strzec moich nakazów i moich przykazań, które wam dałem, lecz pójdziecie i będziecie służyć bogom obcym i będziecie się im kłaniać,
###### **1Krl 9,7**
 wytracę Izraela z ziemi, którą mu dałem, a Świątynię, którą poświęciłem Imieniu mojemu, odrzucę sprzed oblicza mego. Izrael stanie się przedmiotem przysłowia i pośmiewiskiem u wszystkich narodów,
###### **1Krl 9,8**
 a ta Świątynia będzie rumowiskiem. Każdy, kto obok niej przejdzie, zdumieje się i zagwiżdże. I będą pytać: Dlaczego Jahwe tak postąpił z tą ziemią i z tą Świątynią?
###### **1Krl 9,9**
 Odpowiedzą: Ponieważ opuścili Jahwe, swojego Boga, który wywiódł ich ojców z ziemi egipskiej, i poszli za obcymi bóstwami, kłamali się im i służyli im, dlatego Jahwe przywiódł na nich całe to nieszczęście.
###### **1Krl 9,10**
 Pod koniec dwudziestu lat, gdy Salomon wzniósł obie budowle: Świątynię Jahwe i pałac królewski,
###### **1Krl 9,11**
 a Chiram, król Tyru, dostarczył Salomonowi tyle drzewa cedrowego, drzewa cyprysowego i złota, ile potrzebował, wówczas król Salomon dał Chiramowi dwadzieścia miast w ziemi galilejskiej.
###### **1Krl 9,12**
 Chiram wyruszył z Tyru, aby obejrzeć miasta, które dał mu Salomon. Nie spodobały mu się [jednak]
###### **1Krl 9,13**
 i powiedział: Cóż to za miasta dałeś mi, mój bracie? I nazwał je krainą Kabul. [Nazwa ta utrzymała się] aż do tego dnia.
###### **1Krl 9,14**
 I Chiram postał królowi sto dwadzieścia talentów złota.
###### **1Krl 9,15**
 Tak przedstawia się sprawa robót przymusowych, które król Salomon nałożył, aby zbudować Świątynię Jahwe, swój pałac, Millo, mury Jerozolimy oraz [odbudować] Chacor, Megiddo, Gezer -
###### **1Krl 9,16**
 faraon, król egipski, najechał i zdobył Gezer. [Miasto] ogniem spalił, a Kananejczyków, mieszkańców miasta, wymordował, i dał je w posagu swej córce, żonie Salomona.
###### **1Krl 9,17**
 Salomon odbudował Gezer - Bet Choron Niższe,
###### **1Krl 9,18**
 Baalat, Tamar na pustyni w ziemi [judzkiej],
###### **1Krl 9,19**
 [zbudował] wszystkie miasta zaopatrzenia, które należały do Salomona, miejsca [postoju] rydwanów, miejsca stadnin oraz to, co zamierzał Salomon wybudować w Jerozolimie, w Libanie i na całym obszarze swego panowania.
###### **1Krl 9,20**
 Wszystkie ludy, które ocalały spośród Amorytów, Chittytów, Peryzzytów, Chiwwitów i Jebuzytów - ponieważ one nie pochodziły z synów izraelskich
###### **1Krl 9,21**
 i były potomkami tych, które pozostały w kraju, bo synowie Izraela nie mogli ich wytracić - Salomon obciążył pracą przymusową, [co trwa] aż do tego dnia.
###### **1Krl 9,22**
 Na synów Izraela Salomon nie nakładał pracy służebnej, ponieważ oni byli żołnierzami, jego dworzanami, dostojnikami, gwardzistami, dowódcami jego rydwanów i jego jazdy.
###### **1Krl 9,23**
 [Liczba] owych przełożonych nad robotami [mianowanych przez] prefektów, którzy kierowali ludem zatrudnionym przy pracy dla Salomona, [wynosiła] pięćset pięćdziesiąt.
###### **1Krl 9,24**
 Gdy tylko córka faraona przeprowadziła się z Miasta Dawidowego do swego pałacu, który jej [Salomon] wystawił, zaraz przystąpił [on] do budowy Millo.
###### **1Krl 9,25**
 Salomon składał trzy razy w roku całopalenia i ofiary dziękczynne na ołtarzu, który wzniósł dla Jahwe, zapalał ofiarę ogniem przed Jahwe, dopełniając [tego przeznaczenia, dla którego zbudował] Świątynię.
###### **1Krl 9,26**
 Król Salomon zbudował okręty w Ecjon-Geber, które [leży w sąsiedztwie] Elot, nad brzegiem Morza Sitowia, w krainie Edomu.
###### **1Krl 9,27**
 Chiram przysłał dla tych okrętów swoich poddanych, żeglarzy, znających morze, [aby pływali razem] z poddanymi Salomona.
###### **1Krl 9,28**
 Udali się [oni] do Ofiru, zabrali stamtąd czterysta dwadzieścia talentów złota i przywieźli królowi Salomonowi.
# 1Krl 9 BR
###### **1Krl 9,1**
 Kiedy Salomon ukończył budowę świątyni dla Jahwe, pałacu królewskiego oraz tego wszystkiego, co budował z własnego upodobania, o czym od dawna marzył,
###### **1Krl 9,2**
 Jahwe objawił mu się po raz drugi, tak jak kiedyś uczynił to w Gibeonie,
###### **1Krl 9,3**
 i powiedział do niego: Wysłuchałem próśb i błagań, jakie zanosiłeś do Mnie. Uświęciłem tę świątynię, którą zbudowałeś po to, by było tam zawsze moje imię. Na nią też będą skierowane po wszystkie czasy moje oczy i moje serce.
###### **1Krl 9,4**
 A ciebie, jeśli będziesz chodził moimi drogami - tak jak to czynił twój ojciec, Dawid - w prostocie twojego serca, jeśli będziesz wprowadzał w życiu wszystko, co ci nakazałem, jeśli będziesz przestrzegał moich praw i nakazów -
###### **1Krl 9,5**
 Ja umocnię na wieki na tronie w Izraelu, tak jak to przyobiecałem twojemu ojcu, Dawidowi, mówiąc: Nie zabraknie ci nigdy potomka, który będzie zasiadał na tronie izraelskim.
###### **1Krl 9,6**
 Lecz jeśli odwrócicie się ode Mnie wy i wasi synowie i przestaniecie zachowywać moje nakazy i prawa, które wam dałem, jeśli pójdziecie służyć i kłaniać się innym bogom -
###### **1Krl 9,7**
 to Ja usunę Izraela z ziemi, którą mu dałem, a dom, który poświęciłem dla mojego imienia, zniknie sprzed mojego oblicza, Izrael zaś stanie się przedmiotem wzgardy i pośmiewiskiem dla wszystkich narodów.
###### **1Krl 9,8**
 Ta świątynia legnie w gruzach i każdy, kto będzie koło niej przechodził, zgrozą przejęty zapyta złośliwie: Dlaczego Jahwe postąpił w taki sposób z tym krajem i z tą świątynią?
###### **1Krl 9,9**
 Odpowiedź będzie tylko jedna: Dlatego że odeszli od Jahwe, swojego Boga, który wyprowadził ich ojców z ziemi egipskiej; [dlatego że] kłaniali się i służyli innym bogom. Oto, dlaczego zesłał Jahwe na nich te wszystkie nieszczęścia.
###### **1Krl 9,10**
 Pod koniec dwudziestoletniego okresu, w którym Salomon wzniósł dwie budowle: świątynię dla Jahwe i pałac królewski,
###### **1Krl 9,11**
 Hiram zaś dostarczył Salomonowi potrzebne do budowy drewno cedrowe i cyprysowe oraz tyle, ile [Salomon] chciał, złota, król Salomon w zamian za to wszystko dał Hiramowi dwadzieścia miast galilejskich.
###### **1Krl 9,12**
 Wyruszył tedy Hiram z Tyru, żeby obejrzeć miasta przekazane mu przez Salomona. Ale nie był z nich zadowolony.
###### **1Krl 9,13**
 Powiedział więc: A cóż to są za miasta, które mi dałeś, bracie mój? I nazywają się one aż po dzień dzisiejszy Ziemią Kabul.
###### **1Krl 9,14**
 Hiram wysłał Salomonowi w sumie sto dwadzieścia talentów złota.
###### **1Krl 9,15**
 A z robotnikami zatrudnionymi przy pracach przymusowych było tak: Zgromadził ich Salomon, żeby budowali świątynię dla Jahwe i pałac królewski dla niego samego. Oni też mieli zbudować Millo, mury jerozolimskie, Chasor, Megiddo i Gezer.
###### **1Krl 9,16**
 Kiedyś jeden z królów egipskich, faraon, wyruszył ze swym wojskiem na Gezer. Spalił miasto, wybił wszystkich Kananejczyków, którzy tam mieszkali, po czym dał to miasto w posagu swojej córce, którą Salomon wziął sobie za żonę.
###### **1Krl 9,17**
 Salomon odbudował Gezer, dolne Bet-Choron,
###### **1Krl 9,18**
 a także Baalat i Tamar w okolicach pustynnych,
###### **1Krl 9,19**
 ponadto wszystkie miasta, które służyły Salomonowi za miasta-magazyny: w jednych z nich były przechowywane wszystkie rydwany, w innych była zgromadzona konnica. Wreszcie zbudował Salomon to, co uważał za słuszne, w Jerozolimie, w Libanie i w całym kraju, który pozostawał pod jego władzą.
###### **1Krl 9,20**
 Wszystkich ocalałych Amorytów, Chetytów, Peryzzytów, Chiwwitów oraz Jebuzytów, czyli tych, którzy nie należeli do synów Izraela
###### **1Krl 9,21**
 i byli potomkami tych, co zostali na ziemi Izraela, a synowie Izraela nie zdołali ich wyniszczyć przez rzucanie na nich klątwy, zatrudnił Salomon przy robotach przymusowych, które wykonują po dzień dzisiejszy.
###### **1Krl 9,22**
 Natomiast nie pozwalał Salomon zatrudniać przy robotach przymusowych żadnego z synów Izraela; oni byli wojownikami, jego podwładnymi, przywódcami, urzędnikami, powożącymi jego rydwanami, dowódcami konnicy.
###### **1Krl 9,23**
 Miał Salomon pięciuset pięćdziesięciu nadzorców robót [budowlanych], którzy kierowali ludźmi wykonującymi różne prace.
###### **1Krl 9,24**
 Córka faraona przeprowadziła się z Miasta Dawidowego do pałacu, który specjalnie dla niej zbudował Salomon. Było to w czasie, kiedy Salomon Budował Millo.
###### **1Krl 9,25**
 Każdego roku Salomon składał trzy razy ofiary całopalenia tudzież ofiary pojednania na ołtarzu, który zbudował dla Jahwe; tam spalał również wonności przed Jahwe. Tak dokończył Salomon wznoszenia swoich budowli.
###### **1Krl 9,26**
 Zbudował też Salomon własną flotę w Esjon-Geber, koło Elat, nad brzegiem Morza Czerwonego, w krainie Edom.
###### **1Krl 9,27**
 Do ludzi Salomona Hiram wysłał na swoich okrętach własnych żeglarzy, dobrze obeznanych z morzem.
###### **1Krl 9,28**
 [Razem] udali się oni do Ofir, skąd wzięli czterysta dwadzieścia talentów złota i przywieźli je Salomonowi.
# 1Krl 9 WUJ
###### **1Krl 9,1**
 I stało się, gdy dokończył Salomon budowania domu Pańskiego, i domu królewskiego, i wszystkiego co żądał i chciał uczynić.
###### **1Krl 9,2**
 Ukazał mu się Pan powtóre, jako mu się był ukazał w Gabaon.
###### **1Krl 9,3**
 I rzekł Pan do niego: Wysłuchałem modlitwę twoję i prośbę twoję, którąś się modlił przedemną: poświęciłem dom ten, któryś zbudował, abym tam położył imię moje na wieki, i będą tam oczy moje i serce moje po wszystkie dni.
###### **1Krl 9,4**
 Ty też, jeśli będziesz chodził przedemną, jako twój ociec chodził, w prostości serca i w prawości: i uczynisz wszystko com ci przykazał, i zachowasz prawa moję i sądy moje.
###### **1Krl 9,5**
 Postawię stolicę królestwa twego nad Izraelem na wieki, jakom mówił Dawidowi ojcu twemu, mówiąc: Nie będzie odjęty mąż z rodzaju twego z stolice Izraelskiej.
###### **1Krl 9,6**
 Ale jeśli odwróceniem odwrócicie się wy i synowie waszy, nie naśladując mię, ani strzegąc przykazań moich i Ceremonij moich, którem wam podał. Ale pójdziecie i służyć będziecie bogom cudzym, i kłaniać się im:
###### **1Krl 9,7**
 Zniosę Izraela z ziemie, którąm im dał: i kościół którym poświęcił imieniowi memu, odrzucę od oblicza mego, i będzie Izrael na przypowieść i baśń wszystkim narodom.
###### **1Krl 9,8**
 A ten dom będzie na przykład: każdy, który pójdzie przezeń, zdumieje się, i zaświszcze, i rzecze: Przecz tak uczynił Pan ziemi tej i domowi temu?
###### **1Krl 9,9**
 I odpowiedzą: iż opuścili Pana Boga swego, który wywiódł ojce ich z ziemie Egiptskiej i poszli za Bogi cudzymi, i kłaniali się im, i służyli im: przeto Pan im nie przywiódł to wszystko złe.
###### **1Krl 9,10**
 A gdy się skończyło dwadzieścia lat po tem jako, był Salomon zbudował dwa domy, to jest, dom Pański i dom Królewski;
###### **1Krl 9,11**
 (A Hiram Król Tyrski dodawał Salomonowi drzewa Cedrowego i Jodłowego i złota wedle wszystkiego co potrzebował) tedy dał Salomon Hiram dwadzieścia miast w ziemi Galilejskiej.
###### **1Krl 9,12**
 I wyjachał Hiram z Tyru, aby oglądał miasta, które mu dał Salomon i niepodobały mu się.
###### **1Krl 9,13**
 I rzekł, a więc to są miasta, któreś mi dał bracie? i przezwał je ziemią Chabul, aż do dnia tego.
###### **1Krl 9,14**
 Posłał też Hiram do króla Salomona sto i dwadzieścia talentów złota,
###### **1Krl 9,15**
 Tać jest suma nakładów, którą dał król Salomon na budowanie domu Pańskiego i domu swego, i Mella, i muru Jerozolimskiego, i Heser i Mageddo i Gazer,
###### **1Krl 9,16**
 Pharaon król Egiptski wyciągnął i wziął Gazer spalił ji ogniem: i Chananejczyka, który mieszkał w mieście wymordował, i dał ji za posag córce swej żenie Salomonowej.
###### **1Krl 9,17**
 A tak zbudował Salomon Gazer i Bethoron niższy.
###### **1Krl 9,18**
 I Baalath, i Palmire w ziemie pustyniej.
###### **1Krl 9,19**
 I wszystkie miasteczka, które do niego należały, a nie miały murów, obmurował, i miasta wozów, i miasto jezdnych, i co mu się kolwiek podobało, żeby budował w Jeruzalem i na Libanie, i we wszystkiej ziemi władzej swej.
###### **1Krl 9,20**
 Wszystek lud, który był pozostał i z Amorrhejczyków i Hethejczyków i Pherezejczyków i Hewejczyków i z Jebuzejczyków, którzy nie są z synów Izraelowych.
###### **1Krl 9,21**
 Tych syny, którzy byli pozostali w ziemi, to jest, których synowie Izraelowi nie mogli wyniszczyć, uczynił Salomon, hołdownikami aż po dzisiejszy dzień.
###### **1Krl 9,22**
 Lecz z synów Izraelowych, nie postanowił Salomon żadnego niewolnikiem, ale byli mężami walecznymi i sługami jego, i książęty, i hetmany, i przełożonymi nad wozami i nad końmi.
###### **1Krl 9,23**
 A było przełożonych nad wszystkiemi robotami Salomonowemi, Panów pięć set pięćdziesiąt, którzy mieli lud pod sobą i postanowionym robotam rozkazował.
###### **1Krl 9,24**
 A córka Pharaonowa przeniosła się z miasta Dawidowego do domu swego, który jej Salomon był zbudował: tedy zbudował Mello.
###### **1Krl 9,25**
 Ofiarował też Salomon trzykroć na każdy rok całopalenia i zapokojne ofiary na ołtarzu, który był zbudował Panu, i palił wonności przed Panem i dokonany jest kościół.
###### **1Krl 9,26**
 Nabudował też Salomon okrętów w Asiongabar, który jest blisko Ailath na brzegu morza Czerwonego, w ziemi Idumejskiej.
###### **1Krl 9,27**
 I posłał Hiram w onych okręciech sługi swe męże żeglarskie i morza świadome z sługami Salomonowymi.
###### **1Krl 9,28**
 Którzy gdy przypłynęli do Ophir, nabrawszy tam złota cztery sta i dwadzieścia talentów, przywieźli do króla Salomona.
