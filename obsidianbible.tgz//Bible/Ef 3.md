# Ef 3 BT5
###### **Ef 3,1**
 Dlatego ja, Paweł, więzień Chrystusa Jezusa dla was, pogan...
###### **Ef 3,2**
 bo przecież słyszeliście o udzieleniu przez Boga łaski danej mi dla was,
###### **Ef 3,3**
 że mianowicie przez objawienie oznajmiona mi została ta tajemnica, jaką pokrótce przedtem opisałem.
###### **Ef 3,4**
 Dlatego, czytając [te słowa], możecie się przekonać o moim zrozumieniu tajemnicy Chrystusa.
###### **Ef 3,5**
 Nie była ona oznajmiona synom ludzkim w poprzednich pokoleniach, tak jak teraz została objawiona przez Ducha świętym Jego apostołom i prorokom,
###### **Ef 3,6**
 to znaczy, że poganie już są współdziedzicami i współczłonkami Ciała, i współuczestnikami obietnicy w Chrystusie Jezusie przez Ewangelię.
###### **Ef 3,7**
 Jej sługą stałem się z daru łaski Boga udzielonej mi przez działanie Jego potęgi.
###### **Ef 3,8**
 Mnie, zgoła najmniejszemu ze wszystkich świętych, została dana ta łaska: ogłosić poganom jako Dobrą Nowinę niezgłębione bogactwo Chrystusa
###### **Ef 3,9**
 i wydobyć na światło, czym jest wykonanie tajemniczego planu, ukrytego przed wiekami w Bogu, Stwórcy wszechrzeczy.
###### **Ef 3,10**
 Przez to teraz wieloraka w przejawach mądrość Boga poprzez Kościół stanie się jawna Zwierzchnościom i Władzom na wyżynach niebieskich –
###### **Ef 3,11**
 zgodnie z planem wieków, jaki powziął [Bóg] w Chrystusie Jezusie, Panu naszym.
###### **Ef 3,12**
 W Nim mamy śmiały przystęp [do Ojca] z ufnością, przez wiarę w Niego.
###### **Ef 3,13**
 Dlatego proszę, abyście się nie zniechęcali prześladowaniami, jakie znoszę dla was, bo to jest właśnie waszą chwałą.
###### **Ef 3,14**
 Dlatego zginam kolana moje przed Ojcem,
###### **Ef 3,15**
 od którego bierze nazwę wszelki ród na niebie i na ziemi,
###### **Ef 3,16**
 aby według bogactwa swej chwały sprawił w was przez Ducha swego, by potężnie wzmocnił się wewnętrzny człowiek.
###### **Ef 3,17**
 Niech Chrystus zamieszka przez wiarę w waszych sercach; abyście w miłości zakorzenieni i ugruntowani,
###### **Ef 3,18**
 wraz ze wszystkimi świętymi zdołali ogarnąć duchem, czym jest Szerokość, Długość, Wysokość i Głębokość,
###### **Ef 3,19**
 i poznać miłość Chrystusa, przewyższającą wszelką wiedzę, abyście zostali napełnieni całą Pełnią Boga.
###### **Ef 3,20**
 Temu zaś, który mocą działającą w nas może uczynić nieskończenie więcej niż to, o co my prosimy czy rozumiemy,
###### **Ef 3,21**
 Jemu chwała w Kościele i w Chrystusie Jezusie po wszystkie pokolenia wieku wieków! Amen.
# Ef 3 PAU
###### **Ef 3,1**
 Dlatego ja, Paweł, więzień Chrystusa Jezusa dla was, pogan….
###### **Ef 3,2**
 Na pewno słyszeliście o udzielonej mi łasce Bożej dotyczącej was.
###### **Ef 3,3**
 Została mi objawiona tajemnica, o której wcześniej pokrótce wam pisałem.
###### **Ef 3,4**
 Czytając to, możecie przekonać się o moim zrozumieniu tajemnicy Chrystusa.
###### **Ef 3,5**
 Poprzednim pokoleniom nie było dane poznać ją tak, jak teraz została objawiona Jego świętym apostołom i prorokom przez Ducha:
###### **Ef 3,6**
 poganie współdziedziczą i są włączeni w Ciało oraz współuczestniczą w obietnicy Chrystusa Jezusa przez Ewangelię!
###### **Ef 3,7**
 Ja stałem się jej sługą zgodnie z darem łaski Boga, udzielonej mi przez działanie Jego mocy.
###### **Ef 3,8**
 To mnie, najmniejszemu ze wszystkich świętych, została dana ta łaska, aby poganom ogłosić Ewangelię o niepojętym bogactwie Chrystusa
###### **Ef 3,9**
 i ujawnić wszystkim, na czym polega spełnianie się tajemnicy ukrytej od wieków w Bogu, który wszystko stworzył.
###### **Ef 3,10**
 I oto teraz zwierzchności i władze na wyżynach niebieskich poznają przez Kościół wieloraką mądrość Bożą,
###### **Ef 3,11**
 zgodnie z odwiecznym planem, który wypełnił się w Chrystusie Jezusie, naszym Panu.
###### **Ef 3,12**
 W Nim mamy otwartą drogę i dostęp do Ojca, pełni ufności dzięki wierze w Niego.
###### **Ef 3,13**
 Błagam was, abyście nie zniechęcali się z powodu moich utrapień, które znoszę za was. One są waszą chwałą!
###### **Ef 3,14**
 Dlatego upadam na kolana przed Ojcem,
###### **Ef 3,15**
 od którego bierze nazwę wszelki ród w niebie i na ziemi.
###### **Ef 3,16**
 Niech On, według bogactwa swojego majestatu, obdarzy was przez swojego Ducha siłą umacniającą wewnętrznego człowieka.
###### **Ef 3,17**
 Niech Chrystus przez wiarę zamieszka w waszych sercach, abyście zakorzenieni i ugruntowani w miłości
###### **Ef 3,18**
 mogli wraz ze wszystkimi świętymi pojąć, czym jest szerokość i długość, wysokość i głębokość.
###### **Ef 3,19**
 Obyście poznali miłość Chrystusa, która przewyższa wiedzę, i zostali napełnieni całą pełnią Boga.
###### **Ef 3,20**
 Temu zaś, który działającą w nas mocą może uczynić znacznie więcej niż to, o co prosimy czy pojmujemy,
###### **Ef 3,21**
 Jemu chwała w Kościele i w Chrystusie Jezusie przez wszystkie pokolenia na wieki wieków. Amen.
# Ef 3 BP
###### **Ef 3,1**
 Toteż ja, Paweł, więzień Chrystusa [Jezusa], jestem wśród was, pogan.
###### **Ef 3,2**
 I słyszeliście o łasce powołania, udzielonej mi ze względu na was przez Boga:
###### **Ef 3,3**
 przez objawienie została mi odsłonięta tajemnica, którą krótko opisałem powyżej.
###### **Ef 3,4**
 Kiedy więc to czytacie, możecie się dowiedzieć, ile wiem o tajemnicy Chrystusa.
###### **Ef 3,5**
 Nie była ona ujawniona ludziom w minionych czasach, teraz zaś została objawiona przez Ducha Świętego apostołom i prorokom,
###### **Ef 3,6**
 to znaczy że poganie są współdziedzicami i współczłonkami Ciała i współuczestnikami obietnicy w Chrystusie Jezusie przez ewangelię.
###### **Ef 3,7**
 A ja, Paweł, stałem się sługą tej ewangelii dzięki darowi łaski Bożej, udzielonej mi przez Jego skuteczne działanie.
###### **Ef 3,8**
 Ta łaska została dana mnie, najmniejszemu ze wszystkich świętych: mam zwiastować poganom niewyczerpane bogactwo Chrystusa,
###### **Ef 3,9**
 wyjawić [wszystkim], na czym polega tajemnica planu [zbawienia], ukryta od wieków w Bogu, Stwórcy wszechrzeczy.
###### **Ef 3,10**
 Teraz za pośrednictwem Kościoła zwierzchności i władze w przestworzach mają poznać wieloraką mądrość Boga,
###### **Ef 3,11**
 zgodnie z odwiecznym [Jego] postanowieniem, które urzeczywistnił w Chrystusie Jezusie, naszym Panu.
###### **Ef 3,12**
 W Nim i dzięki wierze w Niego możemy śmiało i z ufnością dojść (do Ojca).
###### **Ef 3,13**
 Dlatego proszę was, abyście się nie załamywali z powodu prześladowań, które za was znoszę. To wasza chluba.
###### **Ef 3,14**
 Przeto zginam kolana przed Ojcem,
###### **Ef 3,15**
 od którego wywodzi swoją nazwę wszelki ród w niebie i na ziemi,
###### **Ef 3,16**
 żeby pozwolił wam według bogactwa swej chwały, przez Ducha swojego, umocnić w sobie wewnętrznego człowieka,
###### **Ef 3,17**
 aby Chrystus zamieszkał w waszych sercach przez wiarę, zakorzeniając i ugruntowując w [was] miłość.
###### **Ef 3,18**
 Wtedy będziecie mogli wraz ze wszystkimi świętymi zgłębić [swoim] umysłem Szerokość i Długość, Wysokość i Głębokość
###### **Ef 3,19**
 oraz poznać miłość Chrystusa, która przewyższa wszelką wiedzę, i osiągnąć całą pełnię [darów] Bożych.
###### **Ef 3,20**
 Temu, który działającą w nas mocą może uczynić daleko więcej niż to, o co prosimy lub co pojmujemy,
###### **Ef 3,21**
 chwała w Kościele i w Chrystusie Jezusie przez wszystkie pokolenia, na wieki wieków. Amen.
# Ef 3 BR
###### **Ef 3,1**
 Dlatego, ja, Paweł, więzień Chrystusa Jezusa z powodu was, pogan...
###### **Ef 3,2**
 Słyszeliście z pewnością o zadaniach, jakie Bóg w swej dobroci zlecił mi dla waszego dobra.
###### **Ef 3,3**
 W [specjalnym] objawieniu ukazał mi tajemnicę swoich planów, które przed chwilą opisałem pokrótce.
###### **Ef 3,4**
 Czytając to, co napisałem, możecie się przekonać, że rozumiem, na czym polega tajemnica Chrystusa.
###### **Ef 3,5**
 Poprzednim pokoleniom ludzi tajemnica ta nie była objawiona tak, jak została ukazana przez Ducha świętym wyznawcom [Chrystusa], apostołom i prorokom.
###### **Ef 3,6**
 A oto treść tej tajemnicy: dzięki Ewangelii poganie mają także udział razem z Żydami w dobrach, które Bóg przeznaczył na dziedzictwo dla swojego ludu; są już członkami tego samego ciała i wreszcie do nich również odnoszą się obietnice, które Bóg zostawił nam w Jezusie Chrystusie.
###### **Ef 3,7**
 Stałem się więc sługą Dobrej Nowiny dzięki okazanej mi łaskawości Bożej i na skutek działania Jego mocy.
###### **Ef 3,8**
 Jestem najmniejszym wśród tych, którzy tworzą lud Boży, a jednak mnie Bóg obdarzył łaską głoszenia poganom Dobrej Nowiny o bezmiarze wszelkich dóbr w Chrystusie.
###### **Ef 3,9**
 Wskutek tego głoszenia mieli też zrozumieć poganie, czym winno być urzeczywistnienie tajemnicy planów Bożych, zakrytych przed wiekami w Bogu, Stwórcy wszechrzeczy.
###### **Ef 3,10**
 Tym samym Zwierzchności i Władze na wyżynach niebieskich już teraz poprzez Kościół poznają mądrość Bożą w jej wielorakich przejawach,
###### **Ef 3,11**
 zgodnie z Jego odwieczną wolą, którą urzeczywistnił w Chrystusie Jezusie, Panu naszym.
###### **Ef 3,12**
 W zjednoczeniu z Nim i dzięki wierze w Niego z całą śmiałością możemy pójść do Ojca.
###### **Ef 3,13**
 Dlatego proszę was, żebyście nie upadali na duchu z powodu ucisków, jakie znoszę dla was; będą one źródłem jeszcze większej chwały waszej.
###### **Ef 3,14**
 Dlatego też upadam na kolana przed Ojcem,
###### **Ef 3,15**
 od którego bierze prawdziwą nazwę wszelki ród na niebie i na ziemi,
###### **Ef 3,16**
 prosząc Go, aby, według swej ogromnej chwały, umacniał w was za sprawą swego Ducha waszego wewnętrznego człowieka;
###### **Ef 3,17**
 aby Chrystus zamieszkał przez wiarę w waszych sercach przepełnionych i umocnionych miłością;
###### **Ef 3,18**
 abyście razem z wszystkimi wiernymi mogli zrozumieć, jaka jest Szerokość, Długość, Wysokość i Głębia [miłości Chrystusa];
###### **Ef 3,19**
 abyście mogli dojść do przekonania, że miłość Chrystusa przewyższa wszelkie poznanie; abyście obfitowali w całą Pełnię Bożą.
###### **Ef 3,20**
 Temu zaś, który może mocą w nas działającą uczynić nieskończenie więcej niż to, o co Go prosimy lub o czym nawet możemy pomyśleć,
###### **Ef 3,21**
 Jemu, w Kościele i w Chrystusie Jezusie, niech będzie chwała po wszystkie pokolenia i wieki wieków! Amen.
# Ef 3 WUJ
###### **Ef 3,1**
 Dla tego, ja Paweł więzień Chrystusa Jezusa za was Pogany:
###### **Ef 3,2**
 Jeśliście jedno słyszeli o szafowaniu łaski Bożej, która mi jest do was dana,
###### **Ef 3,3**
 Przez objawienie oznajmiona mi jest tajemnica, jakom przedtem pisał na krótce:
###### **Ef 3,4**
 Jako czytając możecie zrozumieć wyrozumienie moje w tajemnicy Chrystusowej:
###### **Ef 3,5**
 Która inszych wieków nie była poznana od synów ludzkich, jako teraz objawiona jest świętym Apostołom jego i Prorokom w Duchu.
###### **Ef 3,6**
 Iż Pogani są spółdziedzicy, i spółcielni, i spółuczestnicy obietnice jego w Chrystusie Jezusie przez Ewanielią:
###### **Ef 3,7**
 Którejem się stał sługą wedle daru łaski Bożej, która mi jest dana wedle skuteczności mocy jego.
###### **Ef 3,8**
 Mnie namniejszemu ze wszystkich świętych, dana jest łaska ta, abym między Pogany przepowiadał niedościgłe bogactwa Chrystusowe:
###### **Ef 3,9**
 A iżbym objaśnił wszystkim, który jest szafunek tajemnice zakrytej od wieków w Bogu, który wszystko stworzył:
###### **Ef 3,10**
 Aby wiadoma była księstwam i zwierzchnościam na niebiosach przez kościół rozliczna mądrość Boża:
###### **Ef 3,11**
 Wedle przeznaczenia wieków, które uczynił w Chrystusie Jezusie Panie naszym.
###### **Ef 3,12**
 W którym mamy bezpieczność i przystęp z ufaniem, przez wiarę jego.
###### **Ef 3,13**
 Przetoż proszę, abyście nie ustawali w uciskach moich za was, która jest chwała wasza.
###### **Ef 3,14**
 Dla tego klękam na kolana moje ku Ojcu Pana naszego Jezusa Chrystusa,
###### **Ef 3,15**
 Z którego wszelkie ojcostwo na niebie i na ziemi jest nazywane,
###### **Ef 3,16**
 Aby wam dał wedle bogactw chwały swej, żebyście byli mocą utwierdzeni, przez Ducha jego we wnętrznego człowieka.
###### **Ef 3,17**
 Aby mieszkał Chrystus przez wiarę w sercach waszych, w miłości wkorzenieni i ugruntowani,
###### **Ef 3,18**
 Żebyście mogli pojąć ze wszystkiemi świętemi, która jest szerokość, i długość, i wysokość, i głębokość,
###### **Ef 3,19**
 I poznać przewyższającą naukę miłość Chrystusową, abyście byli napełnieni wszelakiej zupełności Bożej.
###### **Ef 3,20**
 A temu, który mocen jest wszystko daleko obficiej uczynić, niż prosimy abo rozumiemy, wedle mocy, która w nas skutecznie robi:
###### **Ef 3,21**
 Jemu chwała w kościele, i w Chrystusie Jezusie na wszystkie rodzaje wieku wieków, Amen.
# Ef 3 STERN
###### **Ef 3,1**
 Właśnie wskutek tego ja, Sza'ul, jestem więźniem Mesjasza Jeszui ze względu na was, nie-Żydów.
###### **Ef 3,2**
 Przypuszczam, że słyszeliście o pracy, jaką Bóg w swej łasce dał mi do wykonania z pożytkiem dla was,
###### **Ef 3,3**
 i że to przez objawienie został mi wyjawiony ten ukryty plan. Już wcześniej o tym pokrótce napisałem,
###### **Ef 3,4**
 a jeśli czytaliście, co napisałem, będziecie wiedzieli, jak rozumiem ów ukryty plan dotyczący Mesjasza.
###### **Ef 3,5**
 W minionych pokoleniach nie był on wyjawiony ludziom w taki sposób, jak teraz Duch objawia go swym wysłannikom i prorokom -
###### **Ef 3,6**
 że w jedności z Mesjaszem i za sprawą Dobrej Nowiny nie-Żydzi mieli się stać wraz z Żydami współdziedzicami, jednym ciałem i współuczestnikami tego, co obiecał Bóg.
###### **Ef 3,7**
 Dzięki darowi Bożej łaski, którego udzielił mi On przez działanie swej mocy, stałem się sługą tej Dobrej Nowiny.
###### **Ef 3,8**
 mnie, najniepozorniejszemu spośród całego świętego ludu Bożego, dano zaszczyt oznajmienia nie-Żydom Dobrej Nowiny o nieogarnionych bogactwach Mesjasza
###### **Ef 3,9**
 i sprawienia, aby każdy mógł ujrzeć urzeczywistnienie tego tajemnego planu. Plan ów, przez wieki trzymany w ukryciu przez Boga, Stwórcę wszystkiego,
###### **Ef 3,10**
 polega na tym, aby władcy i zwierzchności w niebie poznali poprzez istnienie Wspólnoty Mesjanicznej wielopłaszczyznowość Bożej mądrości.
###### **Ef 3,11**
 Zgadza się to z odwiecznym zamysłem Bożym, wypełnionym w Mesjaszu Jeszui, naszym Panu.
###### **Ef 3,12**
 W jedności z Nim, przez Jego wierność, śmiało i ufnie zbliżamy się do Boga.
###### **Ef 3,13**
 Proszę was więc, abyście się nie zniechęcali uciskami, jakich doznaję ze względu na was - to wszystko dla waszej chwały.
###### **Ef 3,14**
 Dlatego padam na kolana przed Ojcem,
###### **Ef 3,15**
 od którego każde ojcostwo w niebie i na ziemi bierze swoje imię.
###### **Ef 3,16**
 Modlę się, aby czerpiąc z bogactwa swej chwały, wyposażył was On w wewnętrzną siłę przez swego Ducha,
###### **Ef 3,17**
 ażeby Mesjasz żył w waszych sercach przez waszą ufność. Modlę się również, ażebyście byli zakorzenieni i ugruntowani w miłości,
###### **Ef 3,18**
 abyście wraz z całym ludem Bożym otrzymali siłę, by pojąć szerokość, długość, wysokość i głębokość miłości Mesjasza -
###### **Ef 3,19**
 tak jest, abyście ją znali, mimo że wykracza ona poza wszelkie poznanie, abyście byli napełnieni całą pełnią Boga.
###### **Ef 3,20**
 A Temu, który swoją mocą działającą w nas jest w stanie uczynić znacznie więcej niż cokolwiek, o co moglibyśmy prosić i co moglibyśmy sobie wyobrażać,
###### **Ef 3,21**
 Jemu niech będzie chwała we Wspólnocie Mesjanicznej i w Mesjaszu Jeszui z pokolenia w pokolenie na wieki. Amen.
# Ef 3 TRO
###### **Ef 3,1**
 **τουτου** *toutou* Tego [[G5127]] WTD-GSN **χαριν** *charin* z powodu [[G5484]] [[ADV]] **εγω** *egō* ja [[G1473]] WTP-1NS **παυλος** *paulos* Paweł – [mały] [[G3972]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **δεσμιος** *desmios* więzień [[G1198]] [[N-NSM]] **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **υπερ** *hyper* za [[G5228]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **των** *tōn* [[G3588]] WTT-GPN **εθνων** *ethnōn* pogan – narody [[G1484]] WTN-GPN
###### **Ef 3,2**
 **ειγε** *eige* jeśli rzeczywiście – jeśli oczywiście [[G1489]] WTCOND **ηκουσατε** *ēkousate* usłyszeliście [[G191]] WTV-AAI-2P **την** *tēn* (o) [[G3588]] WTT-ASF **οικονομιαν** *oikonomian* zarządzaniu sprawami domowymi [[G3622]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **χαριτος** *charitos* łaski [[G5485]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **της** *tēs* [[G3588]] [[T-GSF]] **δοθεισης** *dotheisēs* która została dana [[G1325]] [[V-APP-GSF]] **μοι** *moi* mi [[G3427]] WTP-1DS **εις** *eis* w [[G1519]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP
###### **Ef 3,3**
 **οτι** *hoti* że [[G3754]] [[CONJ]] **κατα** *kata* według [[G2596]] [[PREP]] **αποκαλυψιν** *apokalypsin* objawienia [[G602]] WTN-ASF **εγνωρισεν** *egnōrisen* oznajmił – dał poznać [[G1107]] [[V-AAI-3S]] **μοι** *moi* mi [[G3427]] WTP-1DS **το** *to* [[G3588]] WTT-ASN **μυστηριον** *mystērion* tajemnicę [[G3466]] WTN-ASN **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **προεγραψα** *proegrapsa* wcześniej napisałem [[G4270]] WTV-AAI-1S **εν** *en* w [[G1722]] [[PREP]] **ολιγω** *oligō* małym – krótkim [[G3641]] WTA-DSM
###### **Ef 3,4**
 **προς** *pros* ku – dzięki [[G4314]] [[PREP]] **ο** *ho* czemu [[G3739]] WTR-ASN **δυνασθε** *dynasthe* możecie [[G1410]] WTV-PNI-2P **αναγινωσκοντες** *anaginōskontes* czytając [[G314]] WTV-PAP-NPM **νοησαι** *noēsai* rozumieć – zauważyć [[G3539]] [[V-AAN]] **την** *tēn* [[G3588]] WTT-ASF **συνεσιν** *synesin* zrozumienie [[G4907]] WTN-ASF **μου** *mou* moje [[G3450]] WTP-1GS **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **μυστηριω** *mystēriō* tajemnicy [[G3466]] WTN-DSN **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **Ef 3,5**
 **ο** *ho* która [[G3739]] WTR-NSN **εν** *en* w [[G1722]] [[PREP]] **ετεραις** *heterais* innych [[G2087]] WTA-DPF **γενεαις** *geneais* pokoleniach [[G1074]] WTN-DPF **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εγνωρισθη** *egnōristhē* została oznajmiona – została dana do poznania [[G1107]] [[V-API-3S]] **τοις** *tois* [[G3588]] WTT-DPM **υιοις** *hyiois* synom [[G5207]] WTN-DPM **των** *tōn* [[G3588]] WTT-GPM **ανθρωπων** *anthrōpōn* ludzkim [[G444]] WTN-GPM **ως** *hōs* jak [[G5613]] [[ADV]] **νυν** *nyn* teraz [[G3568]] [[ADV]] **απεκαλυφθη** *apekalyfthē* została objawiona [[G601]] [[V-API-3S]] **τοις** *tois* [[G3588]] WTT-DPM **αγιοις** *hagiois* świętym [[G40]] WTA-DPM **αποστολοις** *apostolois* wysłannikom [[G652]] WTN-DPM **αυτου** *autou* Jego [[G846]] [[P-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **προφηταις** *profētais* prorokom [[G4396]] WTN-DPM **εν** *en* w [[G1722]] [[PREP]] **πνευματι** *pneumati* Duchu [[G4151]] WTN-DSN
###### **Ef 3,6**
 **ειναι** *einai* (że) być [[G1511]] WTV-PXN **τα** *ta* [[G3588]] WTT-APN **εθνη** *ethnē* poganie – narody [[G1484]] WTN-APN **συγκληρονομα** *sygklēronoma* współdziedzicami [[G4789]] WTA-APN **και** *kai* i [[G2532]] [[CONJ]] **συσσωμα** *syssōma* stanowiącymi jedno ciało [[G4954]] WTA-APN **και** *kai* i [[G2532]] [[CONJ]] **συμμετοχα** *symmetocha* wspólnikami – współuczestniczącymi [[G4830]] WTA-APN **της** *tēs* (w) [[G3588]] [[T-GSF]] **επαγγελιας** *epangelias* obietnicy [[G1860]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **δια** *dia* przez [[G1223]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **ευαγγελιου** *euangeliou* dobrą nowinę [[G2098]] [[N-GSN]]
###### **Ef 3,7**
 **ου** *hou* której [[G3739]] WTR-GSN **εγενομην** *egenomēn* stałem się [[G1096]] WTV-2ADI-1S **διακονος** *diakonos* sługa [[G1249]] [[N-NSM]] **κατα** *kata* według [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **δωρεαν** *dōrean* daru – darowizny [[G1431]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **χαριτος** *charitos* łaski [[G5485]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **την** *tēn* [[G3588]] WTT-ASF **δοθεισαν** *dotheisan* która została dana [[G1325]] WTV-APP-ASF **μοι** *moi* mi [[G3427]] WTP-1DS **κατα** *kata* według [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **ενεργειαν** *energeian* działania [[G1753]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **δυναμεως** *dynameōs* mocy [[G1411]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Ef 3,8**
 **εμοι** *emoi* Mnie [[G1698]] WTP-1DS **τω** *tō* [[G3588]] WTT-DSM **ελαχιστοτερω** *elachistoterō* mniejszemu [[G1647]] WTA-DSM-C **παντων** *pantōn* (od) wszystkich [[G3956]] WTA-GPM **των** *tōn* [[G3588]] WTT-GPM **αγιων** *hagiōn* świętych [[G40]] WTA-GPM **εδοθη** *edothē* została dana [[G1325]] [[V-API-3S]] **η** *hē* [[G3588]] [[T-NSF]] **χαρις** *charis* łaska [[G5485]] [[N-NSF]] **αυτη** *hautē* ta [[G3778]] WTD-NSF **εν** *en* między [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPN **εθνεσιν** *ethnesin* poganami – narodami [[G1484]] WTN-DPN **ευαγγελισασθαι** *euangelisasthai* ogłosić dobrą nowinę [[G2097]] WTV-AMN **τον** *ton* [[G3588]] [[T-ASM]] **ανεξιχνιαστον** *aneksichniaston* niezgłębione – niemożliwe do wytropienia [[G421]] WTA-ASM **πλουτον** *plouton* bogactwo [[G4149]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **Ef 3,9**
 **και** *kai* i [[G2532]] [[CONJ]] **φωτισαι** *fōtisai* oświetlić [[G5461]] [[V-AAN]] **παντας** *pantas* wszystkich [[G3956]] WTA-APM **τις** *tis* jaka [[G5101]] WTI-NSM **η** *hē* [[G3588]] [[T-NSF]] **κοινωνια** *koinōnia* wspólnota [[G2842]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSN **μυστηριου** *mystēriou* tajemnicy [[G3466]] [[N-GSN]] **του** *tou* [[G3588]] WTT-GSN **αποκεκρυμμενου** *apokekrymmenou* która jest ukryta – która jest zakryta [[G613]] WTV-RPP-GSN **απο** *apo* od [[G575]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **αιωνων** *aiōnōn* wieków [[G165]] WTN-GPM **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **τω** *tō* (Tym) [[G3588]] WTT-DSM **τα** *ta* [[G3588]] WTT-APN **παντα** *panta* wszystkie [[G3956]] WTA-APN **κτισαντι** *ktisanti* który stworzył [[G2936]] WTV-AAP-DSM **δια** *dia* przez [[G1223]] [[PREP]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **Ef 3,10**
 **ινα** *hina* aby [[G2443]] [[CONJ]] **γνωρισθη** *gnōristhē* zostałaby oznajmiona – zostałaby dana do poznania [[G1107]] WTV-APS-3S **νυν** *nyn* teraz [[G3568]] [[ADV]] **ταις** *tais* [[G3588]] WTT-DPF **αρχαις** *archais* zwierzchnościom – władcom [[G746]] WTN-DPF **και** *kai* i [[G2532]] [[CONJ]] **ταις** *tais* [[G3588]] WTT-DPF **εξουσιαις** *eksousiais* władzom [[G1849]] WTN-DPF **εν** *en* w [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPN **επουρανιοις** *epouraniois* niebiosach [[G2032]] WTA-DPN **δια** *dia* przez [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **εκκλησιας** *ekklēsias* zgromadzenie – (społeczność) wywołanych [[G1577]] [[N-GSF]] **η** *hē* [[G3588]] [[T-NSF]] **πολυποικιλος** *polypoikilos* różnorodna – wielce rozmaita [[G4182]] [[A-NSM]] **σοφια** *sofia* mądrość [[G4678]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **Ef 3,11**
 **κατα** *kata* według [[G2596]] [[PREP]] **προθεσιν** *prothesin* postanowienia przed [[G4286]] WTN-ASF **των** *tōn* [[G3588]] WTT-GPM **αιωνων** *aiōnōn* wiekami [[G165]] WTN-GPM **ην** *hēn* które [[G3739]] WTR-ASF **εποιησεν** *epoiēsen* uczynił – wykonał [[G4160]] [[V-AAI-3S]] **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM **τω** *tō* [[G3588]] WTT-DSM **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **ημων** *hēmōn* naszym [[G2257]] WTP-1GP
###### **Ef 3,12**
 **εν** *en* w [[G1722]] [[PREP]] **ω** *hō* którym [[G3739]] WTR-DSM **εχομεν** *echomen* mamy [[G2192]] WTV-PAI-1P **την** *tēn* [[G3588]] WTT-ASF **παρρησιαν** *parrēsian* śmiałość [[G3954]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **προσαγωγην** *prosagōgēn* dostęp – zbliżenie się [[G4318]] WTN-ASF **εν** *en* w [[G1722]] [[PREP]] **πεποιθησει** *pepoithēsei* przekonaniu – przeświadczeniu [[G4006]] [[N-DSF]] **δια** *dia* przez [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **πιστεως** *pisteōs* wiarę [[G4102]] [[N-GSF]] **αυτου** *autou* Jego – (w) Niego [[G846]] [[P-GSM]]
###### **Ef 3,13**
 **διο** *dio* Dlatego [[G1352]] [[CONJ]] **αιτουμαι** *aitoumai* proszę [[G154]] WTV-PMI-1S **μη** *mē* aby nie [[G3361]] [[PRT-N]] **εκκακειν** *ekkakein* zniechęcać się – słabnąć [[G1573]] WTV-PAN **εν** *en* w [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **θλιψεσιν** *thlipsesin* uciskach – utrapieniach [[G2347]] WTN-DPF **μου** *mou* moich [[G3450]] WTP-1GS **υπερ** *hyper* za [[G5228]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **ητις** *hētis* co [[G3748]] WTR-NSF **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **δοξα** *doksa* chwała [[G1391]] [[N-NSF]] **υμων** *hymōn* wasza [[G5216]] WTP-2GP
###### **Ef 3,14**
 **τουτου** *toutou* Tego [[G5127]] WTD-GSN **χαριν** *charin* z powodów [[G5484]] [[ADV]] **καμπτω** *kamptō* zginam [[G2578]] WTV-PAI-1S **τα** *ta* [[G3588]] WTT-APN **γονατα** *gonata* kolana [[G1119]] WTN-APN **μου** *mou* moje [[G3450]] WTP-1GS **προς** *pros* przed – względem [[G4314]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **πατερα** *patera* Ojcem [[G3962]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **Ef 3,15**
 **εξ** *eks* od [[G1537]] [[PREP]] **ου** *hou* którego [[G3739]] WTR-GSM **πασα** *pasa* cała [[G3956]] WTA-NSF **πατρια** *patria* rodzina – ojcostwo [[G3965]] [[N-NSF]] **εν** *en* w [[G1722]] [[PREP]] **ουρανοις** *ouranois* niebiosach [[G3772]] WTN-DPM **και** *kai* i [[G2532]] [[CONJ]] **επι** *epi* na [[G1909]] [[PREP]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]] **ονομαζεται** *onomazetai* jest nazywana [[G3687]] WTV-PPI-3S
###### **Ef 3,16**
 **ινα** *hina* aby [[G2443]] [[CONJ]] **δωη** *dōē* dałby [[G1325]] WTV-2AAS-3S **υμιν** *hymin* wam [[G5213]] WTP-2DP **κατα** *kata* według [[G2596]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **πλουτον** *plouton* bogactwa [[G4149]] [[N-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **δοξης** *doksēs* chwały [[G1391]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **δυναμει** *dynamei* mocą [[G1411]] [[N-DSF]] **κραταιωθηναι** *krataiōthēnai* zostać wzmocnionymi [[G2901]] WTV-APN **δια** *dia* przez [[G1223]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **εις** *eis* w [[G1519]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **εσω** *esō* wewnętrznym [[G2080]] [[ADV]] **ανθρωπον** *anthrōpon* człowieku [[G444]] [[N-ASM]]
###### **Ef 3,17**
 **κατοικησαι** *katoikēsai* (by) zamieszkać [[G2730]] [[V-AAN]] **τον** *ton* [[G3588]] [[T-ASM]] **χριστον** *christon* Pomazaniec [[G5547]] [[N-ASM]] **δια** *dia* przez [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **πιστεως** *pisteōs* wiarę [[G4102]] [[N-GSF]] **εν** *en* w [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **καρδιαις** *kardiais* sercach [[G2588]] WTN-DPF **υμων** *hymōn* waszych [[G5216]] WTP-2GP
###### **Ef 3,18**
 **εν** *en* w [[G1722]] [[PREP]] **αγαπη** *agapē* miłości [[G26]] [[N-DSF]] **ερριζωμενοι** *errizōmenoi* którzy zostali zakorzenieni [[G4492]] WTV-RPP-NPM **και** *kai* i [[G2532]] [[CONJ]] **τεθεμελιωμενοι** *tethemeliōmenoi* którzy są ugruntowani – którzy mają położony fundament [[G2311]] WTV-RPP-NPM **ινα** *hina* aby [[G2443]] [[CONJ]] **εξισχυσητε** *eksischysēte* nabralibyście siłę [[G1840]] WTV-AAS-2P **καταλαβεσθαι** *katalabesthai* (by) uchwycić [[G2638]] WTV-2AMN **συν** *syn* razem z [[G4862]] [[PREP]] **πασιν** *pasin* wszystkimi [[G3956]] WTA-DPM **τοις** *tois* [[G3588]] WTT-DPM **αγιοις** *hagiois* świętymi [[G40]] WTA-DPM **τι** *ti* jaka [[G5101]] WTI-NSN **το** *to* [[G3588]] WTT-NSN **πλατος** *platos* szerokość [[G4114]] WTN-NSN **και** *kai* i [[G2532]] [[CONJ]] **μηκος** *mēkos* długość [[G3372]] WTN-NSN **και** *kai* i [[G2532]] [[CONJ]] **βαθος** *bathos* głębokość [[G899]] WTN-NSN **και** *kai* i [[G2532]] [[CONJ]] **υψος** *hypsos* wysokość [[G5311]] WTN-NSN
###### **Ef 3,19**
 **γνωναι** *gnōnai* (by) poznać [[G1097]] [[V-2AAN]] **τε** *te* zarówno [[G5037]] WTPRT **την** *tēn* (tę) [[G3588]] WTT-ASF **υπερβαλλουσαν** *hyperballousan* przewyższającą [[G5235]] WTV-PAP-ASF **της** *tēs* [[G3588]] [[T-GSF]] **γνωσεως** *gnōseōs* poznanie – wiedzę [[G1108]] [[N-GSF]] **αγαπην** *agapēn* miłość [[G26]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **πληρωθητε** *plērōthēte* zostalibyście wypełnieni [[G4137]] WTV-APS-2P **εις** *eis* w [[G1519]] [[PREP]] **παν** *pan* całej [[G3956]] WTA-ASN **το** *to* [[G3588]] WTT-ASN **πληρωμα** *plērōma* pełni [[G4138]] WTN-ASN **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **Ef 3,20**
 **τω** *tō* (Temu) [[G3588]] WTT-DSM **δε** *de* zaś [[G1161]] [[CONJ]] **δυναμενω** *dynamenō* mogącemu [[G1410]] WTV-PNP-DSM **υπερ** *hyper* ponad [[G5228]] [[PREP]] **παντα** *panta* wszystkie [[G3956]] WTA-APN **ποιησαι** *poiēsai* uczynić [[G4160]] [[V-AAN]] **υπερ** *hyper* ponad [[G5228]] [[PREP]] **εκπερισσου** *ekperissou* wszelką miarę [[G4057]] [[ADV]] **ων** *hōn* które [[G3739]] WTR-GPN **αιτουμεθα** *aitoumetha* prosimy [[G154]] WTV-PMI-1P **η** *ē* lub [[G2228]] WTPRT **νοουμεν** *nooumen* rozumiemy – rozważamy [[G3539]] WTV-PAI-1P **κατα** *kata* według [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **δυναμιν** *dynamin* mocy [[G1411]] WTN-ASF **την** *tēn* [[G3588]] WTT-ASF **ενεργουμενην** *energoumenēn* działającej [[G1754]] WTV-PMP-ASF **εν** *en* w [[G1722]] [[PREP]] **ημιν** *hēmin* nas [[G2254]] WTP-1DP
###### **Ef 3,21**
 **αυτω** *autō* Jemu [[G846]] WTP-DSM **η** *hē* [[G3588]] [[T-NSF]] **δοξα** *doksa* chwała [[G1391]] [[N-NSF]] **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **εκκλησια** *ekklēsia* zgromadzeniu – (społeczności) wywołanych [[G1577]] [[N-DSF]] **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM **εις** *eis* we [[G1519]] [[PREP]] **πασας** *pasas* wszystkich [[G3956]] WTA-APF **τας** *tas* [[G3588]] WTT-APF **γενεας** *geneas* pokoleniach [[G1074]] WTN-APF **του** *tou* [[G3588]] WTT-GSM **αιωνος** *aiōnos* wieku [[G165]] [[N-GSM]] **των** *tōn* [[G3588]] WTT-GPM **αιωνων** *aiōnōn* wieków [[G165]] WTN-GPM **αμην** *amēn* amen – [zaprawdę] [[G281]] WTHEB
