# Dn 8 BT5
###### **Dn 8,1**
 W trzecim roku panowania króla Baltazara miałem widzenie, ja, Daniel, po tym, co ujrzałem poprzednio.
###### **Dn 8,2**
 Gdy patrzyłem podczas widzenia, zobaczyłem siebie w Suzie, w warowni, która leży w kraju Elam. Patrzyłem w widzeniu i znalazłem się nad rzeką Ulaj.
###### **Dn 8,3**
 Podniosłem oczy i spojrzałem, a oto jeden baran stał nad rzeką; miał on dwa rogi, obydwa wysokie, jeden wyższy niż drugi, a wyższy wyrósł później.
###### **Dn 8,4**
 Ujrzałem barana bodącego [rogami] ku zachodowi, północy i południu. Żadne ze zwierząt nie mogło mu sprostać ani nikt nie mógł uwolnić się z jego mocy. On zaś czynił, co chciał, i stawał się wielki.
###### **Dn 8,5**
 A ja patrzyłem uważnie i oto od zachodu szedł kozioł po całej powierzchni ziemi, nie dotykając jej. Kozioł ten miał okazały róg między oczami.
###### **Dn 8,6**
 Podszedł on do barana o dwóch rogach, którego widziałem, stojąc nad rzeką, i rzucił się na niego z całą złością.
###### **Dn 8,7**
 Zobaczyłem, jak on, przybliżywszy się do barana, rozzłościł się na niego, i uderzył barana, i złamał oba jego rogi. Baran nie miał siły, by mu stawić czoło. On więc powalił go na ziemię i podeptał nogami, a nie było nikogo, kto by wyrwał barana z jego mocy.
###### **Dn 8,8**
 Kozioł urósł niezmiernie, ale gdy był w pełni sił, wielki róg uległ złamaniu, a na jego miejscu wyrosły cztery inne – ku czterem stronom świata.
###### **Dn 8,9**
 Z jednego z nich wyrósł inny, mały róg, i wzrastał nadmiernie ku południowi, ku wschodowi i ku wspaniałemu krajowi.
###### **Dn 8,10**
 Wzniósł się on aż do wojska niebieskiego i strącił na ziemię część wojska oraz gwiazd, i podeptał je.
###### **Dn 8,11**
 Wielkością dosięgał on niemal Władcy wojska, odjął Mu wieczną ofiarę i zniszczył doszczętnie miejsce Jego przybytku
###### **Dn 8,12**
 i jego wojsko. Jako codzienną ofiarę składał występek i prawdę rzucił na ziemię; działał zaś skutecznie.
###### **Dn 8,13**
 I usłyszałem, że jeden ze Świętych mówił, a drugi Święty zapytał tego, który mówił: Jak długo [potrwa] widzenie: wieczna ofiara, zgubna nieprawość, przybytek i podeptane wojsko?
###### **Dn 8,14**
 On zaś powiedział do niego: Jeszcze przez dwa tysiące trzysta wieczorów i poranków, następnie świątynia odzyska swoje prawa.
###### **Dn 8,15**
 Gdy ja, Daniel, oglądałem widzenie i roztrzą-sałem jego znaczenie, oto stanął przede mną ktoś o wyglądzie mężczyzny,
###### **Dn 8,16**
 i usłyszałem głos ludzki nad [rzeką] Ulaj, który wołał tymi słowami: Gabrielu, wyjaśnij mu widzenie!
###### **Dn 8,17**
 Podszedł więc on do miejsca, gdzie stałem, a gdy przybył, przeraziłem się i padłem na twarz. I powiedział do mnie: Wiedz, synu człowieczy, że widzenie odnosi się do czasów ostatecznych.
###### **Dn 8,18**
 Gdy on ze mną rozmawiał, padłem oszołomiony twarzą ku ziemi; wtedy dotknął mnie, postawił mnie na nogi
###### **Dn 8,19**
 i powiedział: Oto oznajmię ci, co ma nastąpić przy końcu gniewu, bo widzenie dotyczy końca czasów.
###### **Dn 8,20**
 Baran, którego widziałeś z dwoma rogami, [oznacza] królów Medów irsów.
###### **Dn 8,21**
 Kozioł zaś – króla Jawanu, a wielki róg między jego oczami – pierwszego króla.
###### **Dn 8,22**
 Róg zaś, który uległ złamaniu, i cztery rogi, co wyrosły na jego miejsce, to cztery królestwa, które powstaną z jego narodu, będą jednak pozbawione jego mocy.
###### **Dn 8,23**
 A przy końcu ich panowania, gdy występni dopełnią swej miary, powstanie król o okrutnym obliczu, zdolny rozumieć rzeczy tajemne.
###### **Dn 8,24**
 Jego moc będzie potężna, ale nie dzięki własnej sile.Będzie podejmował rzeczy dziwnei dozna powodzenia w swych poczynaniach; obróci wniwecz potężnychi naród świętych.
###### **Dn 8,25**
 Przy jego przebiegłości...nawet knowanie będzie skutecznew jego ręku. Stanie się on wyniosły w sercui niespodziewanie zgotuje zagładę wielu. Powstanie przeciw Najwyższemu Przywódcy, lecz bez udziału ręki ludzkiej zostanie skruszony.
###### **Dn 8,26**
 Widzenie zaś o wieczorach i rankach, jakie opowiedziano tobie, jest prawdziwe. Ty jednak widzenie okryj milczeniem, bo dotyczy ono dni odległych.
###### **Dn 8,27**
 Wtedy mnie, Daniela, ogarnęła niemoc i chorowałem przez [wiele] dni. Następnie wstałem i załatwiałem sprawy królewskie; byłem jednak poruszony widzeniem, gdyż nie mogłem go zrozumieć.
# Dn 8 PAU
###### **Dn 8,1**
 W trzecim roku panowania króla Baltazara ja, Daniel, miałem następne widzenie po tym, co ujrzałem poprzednio.
###### **Dn 8,2**
 Zobaczyłem w widzeniu, że jestem w Suzie, w twierdzy położonej w prowincji Elam. Zobaczyłem, że jestem nad kanałem Ulaj.
###### **Dn 8,3**
 Podniosłem oczy i zobaczyłem, jak nad potokiem stanął baran. Miał dwa rogi - oba długie, jeden dłuższy od drugiego, a ten dłuższy wyrósł później.
###### **Dn 8,4**
 Zobaczyłem, jak baran bodzie na zachód, na północ i na południe. Żadne ze zwierząt nie mogłoby się z nim zmierzyć i nikomu nie udałoby się uwolnić z jego mocy. Robił, co chciał, i był coraz silniejszy.
###### **Dn 8,5**
 Patrzyłem uważnie, a oto kozioł przeszedł od zachodu całą ziemię, nie dotykając jej. Miał wielki róg między oczami.
###### **Dn 8,6**
 Podszedł do barana z rogami, którego widziałem stojącego nad potokiem, i uderzył na niego z całej siły.
###### **Dn 8,7**
 Widziałem, jak zbliżył się do barana, rozjuszył się i uderzył w barana, połamał oba jego rogi, a baran nie miał siły, aby mu się przeciwstawić. Kozioł rzucił go na ziemię, zdeptał i nie było nikogo, kto by wyrwał barana z mocy kozła.
###### **Dn 8,8**
 Kozioł bardzo wyrósł, a gdy stał się potężny, jego wielki róg się złamał. Na jego miejscu wyrosły cztery okazałe rogi, wymierzone przeciw czterem duchom nieba.
###### **Dn 8,9**
 Z jednego z nich wyrósł inny, mały róg, który bardzo wzrastał ku południu, ku wschodowi i ku wspaniałemu miejscu.
###### **Dn 8,10**
 Wielkością swoją sięgał wojska nieba, strącił na ziemię część tego wojska i część gwiazd i zdeptał je.
###### **Dn 8,11**
 Dosięgnął też Wodza wojska nieba, odebrał Mu codzienną ofiarę i zniszczył Jego świątynię.
###### **Dn 8,12**
 Na miejsce ofiary wprowadził swój występek. Prawda została przez niego zdeptana, a on robił, co mu się podobało.
###### **Dn 8,13**
 Usłyszałem, jak jeden święty mówił, a inny święty zapytał mówiącego: „Jak długo będą trwać sprawy dotyczące tej wizji: zniesienie codziennej ofiary, przerażająca bezbożność oraz deptanie świątyni i jej służby?”.
###### **Dn 8,14**
 Odpowiedział mu: „Aż do dwóch tysięcy trzystu wieczorów i poranków. Potem świątynia zostanie oczyszczona”.
###### **Dn 8,15**
 Gdy ja, Daniel, miałem to widzenie i rozważałem, co ono oznacza, stanął przede mną ktoś podobny do człowieka.
###### **Dn 8,16**
 I usłyszałem głos człowieka, który wołał nad kanałem Ulaj: „Gabrielu, objaśnij mu widzenie!”.
###### **Dn 8,17**
 Przyszedł na miejsce, gdzie stałem. A gdy nadszedł, zląkłem się i upadłem na twarz. Powiedział do mnie: „Zważ, synu człowieczy, że to widzenie dotyczy kresu lat”.
###### **Dn 8,18**
 Gdy on mówił do mnie, ja omdlały leżałem na ziemi. Dotknął mnie i postawił na nogi.
###### **Dn 8,19**
 Powiedział: „Chcę, żebyś wiedział, co stanie się po upływie lat gniewu, bo bliski jest kres czasów.
###### **Dn 8,20**
 Dwurogi Baran, którego widziałeś - to królowie Medów i Persów.
###### **Dn 8,21**
 Kozioł - to król Jawanu; róg wielki między jego oczami - to król pierwszy.
###### **Dn 8,22**
 Został on złamany. Cztery rogi, które wyrosły na jego miejscu - to cztery królestwa, które powstaną z jego narodu, ale nie będą miały takiej mocy jak on.
###### **Dn 8,23**
 Pod koniec ich panowania występni dopełnią miary swych grzechów i powstanie król zuchwały, przebiegły i podstępny.
###### **Dn 8,24**
 Potężna będzie jego moc, ale nie dzięki jego sile. Dokona on ogromnego zniszczenia. Uda mu się to i tak uczyni. Będzie niszczył możnych i lud świętych.
###### **Dn 8,25**
 Z powodu jego przebiegłości jego oszustwa odniosą skutki. Będzie wyniosły w swoim sercu i niespodziewanie zniszczy wielu. Powstanie przeciw Najwyższemu z książąt, ale bez udziału ręki człowieka zostanie złamany.
###### **Dn 8,26**
 Widzenie wieczora i poranka, które miałeś, jest prawdziwe. Lecz zachowaj je w tajemnicy, bo jeszcze wiele czasu upłynie”.
###### **Dn 8,27**
 Ja, Daniel, zasłabłem i chorowałem przez długi czas. Potem wstałem i pełniłem służbę u króla, jak przedtem. Byłem jednak poruszony tym widzeniem i nie rozumiałem go.
# Dn 8 BP
###### **Dn 8,1**
 W trzecim roku panowania króla Belszazara ja, Daniel, miałem widzenie, po tym, które mi się ukazało poprzednio.
###### **Dn 8,2**
 Zobaczyłem w widzeniu i ujrzałem, że byłem w Suzie na zamku, który znajduje się w prowincji Elamu. Spostrzegłem w widzeniu, że znajdowałem się nad brzegiem [rzeki] Ulaj.
###### **Dn 8,3**
 Podniosłem swe oczy i zobaczyłem: Oto jeden baran stał nad brzegiem. Miał dwa rogi. Rogi [te] były wysokie, jeden był wyższy od drugiego, a później wyższy się podniósł.
###### **Dn 8,4**
 Widziałem, jak baran bódł w stronę zachodu, w stronę północy i w stronę południa. Żadne zwierzę nie mogło stać przed nim i nie było, kto by mógł wyrwać z jego mocy. Czynił, co chciał, i rósł w potęgę.
###### **Dn 8,5**
 Gdy ja się zastanawiałem, oto przyszedł kozioł z zachodu nad całą ziemię, ale nie dotykał ziemi. Kozioł ten miał okazały róg między swymi oczami.
###### **Dn 8,6**
 Przyszedł aż do barana, który miał dwa rogi, a którego widziałem stojącego nad brzegiem. Podbiegł ku niemu w poczuciu swej siły
###### **Dn 8,7**
 i zobaczyłem, [jak] dopadł barana, pastwił się nad nim, powalił barana, połamał oba jego rogi, a baran nie miał siły, aby mu się oprzeć. I rzucił go na ziemię, stratował, i nie miał baran [nikogo], kto by go wyrwał z jego mocy.
###### **Dn 8,8**
 Kozioł rósł w potęgę coraz bardziej, a gdy stał się silny, został złamany wielki róg. Na jego miejsce powstały cztery okazałe [rogi] na cztery wiatry nieba.
###### **Dn 8,9**
 Z jednego z nich wyszedł jeden mały róg i rósł bardzo w kierunku południa, w kierunku wschodu i w kierunku ozdoby [ziemi].
###### **Dn 8,10**
 Rósł aż ku wojsku niebieskiemu. I rzucił na ziemię część wojska i część gwiazd, i podeptał je.
###### **Dn 8,11**
 Urósł aż do Wodza wojska i zabrał Mu nieustanną [ofiarę], a miejsce Jego sanktuarium zostało porzucone.
###### **Dn 8,12**
 Wojsko zostało wydane wraz z nieustanną [ofiarą] z powodu nieprawości. [Róg] rzucił na ziemię prawdę. Działał i rozwijał się pomyślnie.
###### **Dn 8,13**
 I słyszałem jednego świętego mówiącego, a drugi święty postawił pytanie mówiącemu: Jak długo będzie trwać widzenie dotyczące nieustannej ofiary, nieprawość niszcząca, sanktuarium wydane [na zniewagę] i wojsko zdeptane?
###### **Dn 8,14**
 I rzekł do niego: Aż [minie] dwa tysiące trzysta wieczorów [i] poranków. [Wówczas] sanktuarium zostanie przyprowadzone do porządku.
###### **Dn 8,15**
 I stało się, gdy ja, Daniel, oglądałem widzenie i pragnąłem je zrozumieć, oto stanął przede mną [ktoś, kto miał] wygląd człowieka.
###### **Dn 8,16**
 I słyszałem głos ludzki między [brzegami] Ulaj, który wołał: Gabrielu! Wyjaśnij mu widzenie.
###### **Dn 8,17**
 Przyszedł na miejsce, gdzie stałem. A gdy on przystąpił, przeraziłem się i upadłem na twarz. Wtedy rzekł do mnie: Zrozum, synu człowieczy, że widzenie odnosi się do końca czasu.
###### **Dn 8,18**
 Gdy przemawiał do mnie, straciłem przytomność [i leżałem] twarzą ku ziemi. Dotknął mnie, postawił mnie na [miejscu, gdzie] stałem,
###### **Dn 8,19**
 i rzekł: Oto sprawię, że będziesz wiedział, co się stanie, gdy skończy się gniew, gdyż dotyczy to końca czasu.
###### **Dn 8,20**
 Baran o dwu rogach, którego widziałeś, oznacza królów Medów i Persów.
###### **Dn 8,21**
 Kozioł porośnięty sierścią to król Jawanu; wielki róg, który jest między jego oczami, to jest pierwszy król.
###### **Dn 8,22**
 On został złamany. Cztery zaś [rogi, które] powstały na jego miejsce, to cztery królestwa. Z narodu powstaną, ale nie będą miały jego potęgi.
###### **Dn 8,23**
 pod koniec ich panowania, gdy grzesznicy dopełnią miary przewrotności, powstanie król o srogim obliczu, który zna podstęp.
###### **Dn 8,24**
 Jego moc będzie wielka, ale nie przez jego [własną] siłę. Dokona niewiarygodnych zniszczeń. Będzie się mu powodziło [w tym, co] będzie niszczył. Zniszczy możnych i naród świętych.
###### **Dn 8,25**
 Przez swoją przebiegłość sprawi, że oszustwo będzie mu przynosić owoce. Będzie się wynosił w swym sercu i zniszczy wielu żyjących spokojnie. Przeciwstawi się Księciu Książąt, lecz bez udziału [ludzkiej] ręki zostanie złamany.
###### **Dn 8,26**
 Widzenie wieczora i poranka, o którym była mowa, jest prawdą. Ty zaś trzymaj w tajemnicy widzenie, gdyż dotyczy dni dalekich.
###### **Dn 8,27**
 Ja, Daniel, osłabłem i byłem chory [przez wiele] dni. Potem wstałem i załatwiałem sprawy królewskie, ale byłem przerażony widzeniem i nie rozumiałem go.
# Dn 8 BR
###### **Dn 8,1**
 W trzecim roku panowania króla Baltazara, ja, Daniel, miałem znów widzenie po tym, co już poprzednio widziałem.
###### **Dn 8,2**
 W czasie tego widzenia zobaczyłem, że jestem w Suzie, w warowni znajdującej się w prowincji Elamu. Przypatrując się temu widzeniu, ujrzałem siebie nad rzeką Ulaj.
###### **Dn 8,3**
 Kiedy podniosłem oczy, żeby się rozejrzeć dokładnie, zobaczyłem barana stojącego nad rzeką: miał dwa rogi, dość długie, ale jeden był wyższy od drugiego i ten wyższy wyrósł [co było widać] później.
###### **Dn 8,4**
 I widziałem, jak baran bódł swymi rogami w stronę zachodu, ku północy i ku południu. Nie mogło mu się oprzeć żadne zwierzę i nic nie zdołało się przed nim uratować. Robił, co chciał, i stawał się coraz silniejszy.
###### **Dn 8,5**
 Potem zauważyłem, jak od zachodu zbliżał się kozioł. Przemierzył on całą ziemię [prawie] jej nie dotykając. Spomiędzy oczu wyrastał mu wspaniały róg.
###### **Dn 8,6**
 Zbliżył się do barana mającego dwa rogi, stojącego nad brzegiem rzeki. I ruszył na niego ze wszystkich swoich sił.
###### **Dn 8,7**
 Widziałem, jak dopadł barana i starł się z nim. Uderzając barana z całej siły połamał mu obydwa rogi, a baran nie potrafił go powstrzymać. Powalił barana na ziemię i miażdżył nogami. I nikt się nie znalazł, kto mógłby uratować barana.
###### **Dn 8,8**
 Kozioł zaś stawał się coraz silniejszy, a gdy był już w pełni swojej mocy, wyłamał się jego róg i na jego miejscu wyrosły cztery wspaniałe rogi, skierowane w cztery strony świata.
###### **Dn 8,9**
 Z jednego z nich, najmniejszego, wyrósł z czasem róg, który wzrastał bardzo w kierunku południowym, wschodnim oraz w stronę wspaniałego kraju [Palestyny].
###### **Dn 8,10**
 I urósł aż do wojska niebieskiego, strącił na ziemię całe legiony oraz gwiazdy i podeptał je.
###### **Dn 8,11**
 Wystąpił nawet przeciwko Przywódcy legionów, zniósł składanie wiecznotrwałej ofiary i zburzył aż do fundamentów Jego przybytek,
###### **Dn 8,12**
 wytracił Jego wojsko, na miejsce ofiar wprowadził swoje niegodziwości, a prawdę zmieszał z ziemią. I co tylko zamierzył, zawsze doprowadzał to do końca.
###### **Dn 8,13**
 I słyszałem, jak jeden święty zaczął przemawiać. Tymczasem inny święty rzekł do przemawiającego: Jak długo jeszcze potrwa to widzenie: wiecznotrwała ofiara, spustoszenie powodowane niegodziwością, przybytek i wojsko podeptane nogami?
###### **Dn 8,14**
 A tamten odpowiedział: Jeszcze dwa tysiące trzysta wieczorów i poranków i przybytek zostanie odzyskany.
###### **Dn 8,15**
 Przypatrując się tym obrazom, ja, Daniel, myślałem, jakie może być ich znaczenie. I wtedy stanął przede mną ktoś o wyglądzie człowieka.
###### **Dn 8,16**
 I usłyszałem, głos ludzki nadchodzący od [rzeki] Ulaj: Gabrielu, wytłumacz mu, co znaczy to widzenie.
###### **Dn 8,17**
 A kiedy zbliżył się do miejsca, na którym ja byłem, ogarnęło mnie tak wielkie przerażenie, że upadłem na twarz. A on powiedział do mnie: Zapamiętaj, synu człowieczy, ze widzenie to odnosi się do końca czasów.
###### **Dn 8,18**
 Kiedy on do mnie mówił, ja omdlały leżałem na ziemi. I dotknął mnie i postawił na nogi.
###### **Dn 8,19**
 Wtedy mi powiedział: Chcę ci objawić, co się wydarzy przy końcu [czasu] gniewu, to, co jest przewidziane na koniec.
###### **Dn 8,20**
 Baran o dwu rogach, którego widziałeś - to władcy Medów i Persów.
###### **Dn 8,21**
 Kozioł - to król Jawanu, a wielki róg wyrastający spomiędzy oczu kozła - to pierwszy król.
###### **Dn 8,22**
 Róg wyłamany oraz cztery rogi, które wyrosły na jego miejscu - to cztery królestwa, które zostały utworzone z tego narodu, ale nigdy nie będą miały takiego znaczenia.
###### **Dn 8,23**
 Kiedy zaś nadejdzie kres ich panowania i dopełni się miara ich grzechów, powstanie król o dumnym obliczu, umiejący przenikać wszelkie tajemnice.
###### **Dn 8,24**
 I będzie rosła coraz bardziej jego siła, ale nie w skutek jego własnych możliwości. Będzie się podejmował dzieł przedziwnych i będą mu się one udawały. Pokona on wszystkich potężnych i wygubi cały naród świętych.
###### **Dn 8,25**
 Będąc bardzo przebiegłym, własnym knowaniem dopuści się zdrady. Będzie się wynosił w swoim sercu i niespodziewanie na wielu sprowadzi zagładę. Wystąpi przeciw Księciu Książąt, ale bez udziału ręki człowieka zostanie złamany.
###### **Dn 8,26**
 Taka jest prawda o widzeniu wieczorów i poranków, które miałeś. Lecz nie mów nikomu o tym widzeniu, bo jeszcze wiele czasu upłynie, nim się to wszystko stanie.
###### **Dn 8,27**
 Usłyszawszy to ja, Daniel, popadłem w omdlenie i byłem chory przez wiele dni. Potem wstałem, żeby pełnić nadal moją służbę u króla. Nic też nie mówiłem o całym widzeniu, gdyż nie rozumiałem jego znaczenia.
# Dn 8 WUJ
###### **Dn 8,1**
 Roku trzeciego królestwa Balthazara króla, ukazało mi się widzenie.
###### **Dn 8,2**
 Ja Daniel potem com był widział na początku, widziałem w widzeniu mojem, gdym był na Susis zamku, który jest w krainie Elam: a widziałem w widzeniu, żem był nad bramą Ulai.
###### **Dn 8,3**
 I podniosłem oczy moje, a ujrzałem: ano baran jeden stał nad błotem, mający rogi wysokie, a jeden wyższy niż drugi, a podrastający.
###### **Dn 8,4**
 Potem widziałem barana rogami rzucającego na zachód, i na północy, i na południe, a wszystkie bestye nie mogły się mu sprzeciwić, ani się wyzwolić z ręki jego: i czynił według woli swej, i stał się wielkim.
###### **Dn 8,5**
 A jam uważał: alić oto kozieł kóz przychodził od zachodu na wszystkę ziemię, a nie dotykał się ziemie: a kozieł miał róg znaczny między oczyma swemi.
###### **Dn 8,6**
 I przyszedł aż do barana onego rogatego, któregom widział stojącego przed bramą, i skoczył do niego w popędliwości siły swej.
###### **Dn 8,7**
 A gdy się przybliżył blizko barana, rozjadł się nań, i uderzył barana: i zdruzgotał dwa rogi jego, a nie mógł się mu baran sprzeciwić: i obaliwszy go na ziemię, zdeptał: a żaden nie mógł wybawić barana z ręki jego.
###### **Dn 8,8**
 A kozieł kóz stał się barzo wielkim: a gdy urósł złamał się róg, wielki, i wyrosły pod nim cztery rogi na cztery wiatry niebieskie.
###### **Dn 8,9**
 A z jednego z nich wyszedł róg jeden mały, i stał się wielkim na południe, i na wschód, i na moc.
###### **Dn 8,10**
 I rozwielmożył się aż do siły niebieskiej: i zrzucił z siły, i z gwiazd, i podeptał je.
###### **Dn 8,11**
 I aż do książęcia siły rozwielmożył się, i odjął od niego ofiarę ustawiczną, i zrzucił miejsce świątynie jego.
###### **Dn 8,12**
 I dano mu moc przeciw ustawicznej ofierze dla grzechów: i porzucona będzie prawda na ziemi, i będzie czynił a zdarzy mu się.
###### **Dn 8,13**
 I słyszałem jednego z świętych mówiącego: i rzekł jeden z świętych drugiemu nie wiem, któremu mówiącemu: Dokądże widzenie, i ustawiczna ofiara, i grzech spustoszenia, które się stało: a świątynia i siła będzie podeptana?
###### **Dn 8,14**
 I rzekł mu: Aż do wieczora i do poranku dni dwa tysiące trzysta, a będzie oczyszczona świątynia.
###### **Dn 8,15**
 I stało się, gdym ja Daniel widział widzenie, i wywiadowałem się wyrozumienia: oto stanęła przed oczyma memi jako osoba męża.
###### **Dn 8,16**
 I słyszałem głos męża między Ulai: i wołał, a rzekł: Gabryelu uczyń, że zrozumie ten widzenie:
###### **Dn 8,17**
 I przyszedł, i stanął podle gdziem ja stał: a gdy przyszedł, zlękłszy się padłem na oblicze moje, i rzekł do mnie: Rozumiej synu człowieczy, bo czasu końca wypełni się widzenie.
###### **Dn 8,18**
 A gdy mówił do mnie, padłem twarzą na ziemię: i dotknął się mnie, i postawił mię na nogach moich,
###### **Dn 8,19**
 I rzekł mi: Ja pokażę tobie co będzie na końcu przeklęctwa: bo czas ma koniec swój.
###### **Dn 8,20**
 Baran, któregoś widział mającego rogi, jest król Medzki i Perski.
###### **Dn 8,21**
 A kozioł kóz jest Grecki, a róg wielki, który był między oczyma jego, ten jest król pierwszy.
###### **Dn 8,22**
 A iż po złamaniu jego urosły cztery miasto niego: czterzy królowie z narodu jego powstaną: ale nie w mocy jego.
###### **Dn 8,23**
 A po królestwie ich, gdy urostą nieprawości, powstanie król nie wstydliwej twarzy, a rozumiejący gadki.
###### **Dn 8,24**
 I zmocni się siła jego, ale nie swemi siłami: a więcej niż kto wierzyć może wszystko zburzy, i zdarzy się mu, i czynić będzie, i pobije mocarze i lud świętych.
###### **Dn 8,25**
 Według wolej swej, i zdarzy się zdrada w ręce jego: a serce swe uwielbi, a w dostatku wszech rzeczy pozabija wielu: i przeciw książęciu książąt powstanie, a bez ręki skruszon będzie.
###### **Dn 8,26**
 A widzenie wieczorne i rane które powiedziano, prawdziwe jest: przeto ty zapieczętuj widzenie: bo po wielu dni będzie.
###### **Dn 8,27**
 A ja Daniel zemdlałem, i chorzałem przez dni: a gdym wstał odprawowałem sprawy królewskie, i zdumiałem się nad widzeniem: a nie było, ktoby wyłożył.
