# 1Tes 5 BT5
###### **1Tes 5,1**
 Nie potrzeba wam, bracia, pisać o czasach i chwilach,
###### **1Tes 5,2**
 sami bowiem dokładnie wiecie, że dzień Pański przyjdzie tak jak złodziej w nocy.
###### **1Tes 5,3**
 Kiedy bowiem będą mówić: «***Pokój i bezpieczeństwo***» – tak niespodzianie przyjdzie na nich zagłada, jak bóle na brzemienną, i nie umkną.
###### **1Tes 5,4**
 Ale wy, bracia, nie jesteście w ciemnościach, aby ów dzień miał was zaskoczyć jak złodziej.
###### **1Tes 5,5**
 Wszyscy wy bowiem jesteście synami światłości i synami dnia. Nie jesteśmy synami nocy ani ciemności.
###### **1Tes 5,6**
 Nie śpijmy przeto jak inni, ale czuwajmy i bądźmy trzeźwi.
###### **1Tes 5,7**
 Ci, którzy śpią, w nocy śpią, a którzy się upijają, w nocy są pijani.
###### **1Tes 5,8**
 My zaś, którzy do dnia należymy, bądźmy trzeźwi, przyodziani w pancerz wiary i miłości oraz w hełm nadziei zbawienia.
###### **1Tes 5,9**
 Ponieważ nie przeznaczył nas Bóg [na to, abyśmy zasłużyli] na gniew, ale na osiągnięcie zbawienia przez Pana naszego, Jezusa Chrystusa,
###### **1Tes 5,10**
 który za nas umarł, abyśmy – żywi czy umarli – razem z Nim żyli.
###### **1Tes 5,11**
 Dlatego zachęcajcie się wzajemnie i budujcie jedni drugich, jak to zresztą czynicie.
###### **1Tes 5,12**
 Prosimy was, bracia, abyście uznawali [władzę] tych, którzy wśród was pracują, którzy przewodzą wam i w Panu was napominają.
###### **1Tes 5,13**
 Ze względu na ich pracę otaczajcie ich szczególną miłością. Między sobą zachowujcie pokój.
###### **1Tes 5,14**
 Prosimy was, bracia, upominajcie niekarnych, pocieszajcie małodusznych, przygarniajcie słabych, a dla wszystkich bądźcie cierpliwi.
###### **1Tes 5,15**
 Baczcie, aby nikt nie odpłacał złem za zło, lecz zawsze usiłujcie czynić dobrze sobie nawzajem i wszystkim.
###### **1Tes 5,16**
 Zawsze się radujcie,
###### **1Tes 5,17**
 nieustannie się módlcie.
###### **1Tes 5,18**
 W każdym położeniu dziękujcie, taka jest bowiem wola Boża w Jezusie Chrystusie względem was.
###### **1Tes 5,19**
  Ducha nie gaście,
###### **1Tes 5,20**
 proroctwa nie lekceważcie.
###### **1Tes 5,21**
 Wszystko badajcie, a co szlachetne – zachowujcie.
###### **1Tes 5,22**
 Unikajcie wszelkiego rodzaju zła.
###### **1Tes 5,23**
 Sam zaś Bóg pokoju niech uświęca was całych, aby nietknięty duch wasz, dusza i ciało bez zarzutu zachowały się na przyjście Pana naszego, Jezusa Chrystusa.
###### **1Tes 5,24**
 Wierny jest Ten, który was wzywa: On też tego dokona.
###### **1Tes 5,25**
 Bracia, módlcie się także i za nas.
###### **1Tes 5,26**
 Pozdrówcie wszystkich braci pocałunkiem świętym.
###### **1Tes 5,27**
 Zaklinam was na Pana, aby list ten został odczytany wszystkim braciom.
###### **1Tes 5,28**
 Łaska Pana naszego, Jezusa Chrystusa, [niech będzie] z wami!
# 1Tes 5 PAU
###### **1Tes 5,1**
 Bracia, nie potrzeba wam pisać o dniach i godzinach,
###### **1Tes 5,2**
 gdyż sami doskonale wiecie, że Dzień Pana przyjdzie jak złodziej w nocy.
###### **1Tes 5,3**
 Kiedy powiedzą: „Pokój i bezpieczeństwo”, wtedy dosięgnie ich zagłada, tak nagle jak bóle kobietę przed porodem, i na pewno się nie uratują.
###### **1Tes 5,4**
 Wy natomiast, bracia, nie żyjecie w ciemności, aby ów dzień miał was zaskoczyć jak złodziej.
###### **1Tes 5,5**
 Wy wszyscy przecież jesteście dziećmi światła i dziećmi dnia, a nie nocy i ciemności.
###### **1Tes 5,6**
 Nie śpijmy więc jak inni, ale czuwajmy i bądźmy trzeźwi.
###### **1Tes 5,7**
 Ci, którzy śpią, śpią w nocy, a którzy się upijają, pijani są w nocy.
###### **1Tes 5,8**
 My natomiast, którzy należymy do dnia, bądźmy trzeźwi. Załóżmy pancerz - wiarę i miłość oraz hełm - nadzieję zbawienia.
###### **1Tes 5,9**
 Bóg przecież nie wydał nas na gniew, lecz zechciał, abyśmy osiągnęli zbawienie przez naszego Pana, Jezusa Chrystusa.
###### **1Tes 5,10**
 On umarł za nas, abyśmy - czy czuwamy, czy śpimy - razem z Nim żyli.
###### **1Tes 5,11**
 Dlatego pokrzepiajcie się wzajemnie i umacniajcie jeden drugiego, jak to zresztą czynicie.
###### **1Tes 5,12**
 Prosimy was, bracia: Szanujcie tych, którzy wśród was się trudzą, kierują wami w imię Pana i napominają was.
###### **1Tes 5,13**
 Ze względu na ich pracę darzcie ich szczególną miłością. Zachowujcie pokój między sobą.
###### **1Tes 5,14**
 Zachęcamy was, bracia: Pouczajcie nieposłusznych, podnoście na duchu bojaźliwych, troszczcie się o słabych, bądźcie wyrozumiali dla każdego.
###### **1Tes 5,15**
 Uważajcie, aby nikt nikomu nie odpłacał złem za zło, ale zawsze starajcie się czynić dobro sobie nawzajem i wszystkim ludziom.
###### **1Tes 5,16**
 Zawsze się radujcie!
###### **1Tes 5,17**
 Módlcie się nieustannie!
###### **1Tes 5,18**
 W każdej sytuacji dziękujcie! To jest bowiem wolą Boga względem was w Chrystusie Jezusie.
###### **1Tes 5,19**
 Nie gaście Ducha!
###### **1Tes 5,20**
 Nie lekceważcie proroctw!
###### **1Tes 5,21**
 Wszystko badajcie! Trzymajcie się tego, co dobre,
###### **1Tes 5,22**
 a unikajcie wszystkiego, co złe!
###### **1Tes 5,23**
 Sam Bóg pokoju niech was w pełni uświęci. Niech was całych - to jest ducha, duszę i ciało - zachowa bez skazy na przyjście naszego Pana Jezusa Chrystusa.
###### **1Tes 5,24**
 Wierny jest ten, który was powołuje i On tego dokona.
###### **1Tes 5,25**
 Bracia, módlcie się za nas.
###### **1Tes 5,26**
 Pozdrówcie wszystkich braci świętym pocałunkiem.
###### **1Tes 5,27**
 Błagam was na Pana, aby ten list został odczytany wszystkim braciom!
###### **1Tes 5,28**
 Łaska naszego Pana Jezusa Chrystusa z wami!
# 1Tes 5 BP
###### **1Tes 5,1**
 Nie trzeba też, bracia, żebym wam podał dokładnie dzień i godzinę.
###### **1Tes 5,2**
 Sami nazbyt dobrze wiecie o tym, że dzień Pański nadejdzie tak jak złodziej w nocy.
###### **1Tes 5,3**
 Kiedy więc mówić będą: "Pokój i bezpieczeństwo", nagle spadnie na nich zagłada, jak bóle na rodzącą, i nie ujdą.
###### **1Tes 5,4**
 Lecz wy, bracia, nie przebywacie w ciemnościach, aby ten dzień miał was zaskoczyć jak złodziej.
###### **1Tes 5,5**
 Wy wszyscy bowiem jesteście synami dnia i światłości. Nie należymy więc ani do nocy, ani do ciemności.
###### **1Tes 5,6**
 Przeto nie śpijmy jak inni, ale czuwajmy i bądźmy trzeźwi.
###### **1Tes 5,7**
 bo ci, którzy śpią, śpią nocą, ci zaś, którzy się upijają, są w nocy pijani.
###### **1Tes 5,8**
 Lecz my należymy do dnia, przywdziejmy więc pancerz wiary i miłości, włóżmy hełm zbawiennej nadziei i bądźmy trzeźwi.
###### **1Tes 5,9**
 Bóg nie chce naszej zagłady, lecz zbawienia w Panu naszym Jezusie Chrystusie,
###### **1Tes 5,10**
 który za nas umarł, abyśmy, czy żywi, czy umarli, razem z Nim żyli.
###### **1Tes 5,11**
 Dlatego zachęcajcie się wzajemnie i budujcie jedni drugich dobrym przykładem, jak to zresztą czynicie.
###### **1Tes 5,12**
 Prosimy was, bracia, poważajcie swoich przełożonych, którzy się trudzą i napominają was w Panu.
###### **1Tes 5,13**
 Otaczajcie ich szczególną miłością ze względu na ich pracę. Żyjcie ze sobą w pokoju.
###### **1Tes 5,14**
 Zachęcamy was, bracia, upominajcie niekarnych, pocieszajcie małodusznych, słabych podtrzymujcie na duchu, a dla wszystkich bądźcie cierpliwi.
###### **1Tes 5,15**
 Czuwajcie nad tym, aby jeden drugiemu złem za zło nie odpłacał, lecz zawsze dobro wyświadczajcie sobie nawzajem, jak i wszystkim ludziom.
###### **1Tes 5,16**
 Zawsze miejcie radość w sercu,
###### **1Tes 5,17**
 nieustannie się módlcie.
###### **1Tes 5,18**
 Dziękujcie Bogu za wszystko, bo taka jest wola Boża, przekazana nam przez Jezusa Chrystusa.
###### **1Tes 5,19**
 Ducha nie gaście,
###### **1Tes 5,20**
 daru proroctwa nie lekceważcie.
###### **1Tes 5,21**
 Sprawdzajcie wszystko, a zachowujcie to, co szlachetne.
###### **1Tes 5,22**
 Unikajcie wszystkiego, co złe.
###### **1Tes 5,23**
 A sam Bóg pokoju niech was w pełni uświęca. Niech wasz duch i dusza, i ciało bez najmniejszej skazy zostaną zachowane aż do powtórnego przyjścia Pana naszego Jezusa Chrystusa.
###### **1Tes 5,24**
 Ten, który was wzywa, dochowuje wierności i dokona tego.
###### **1Tes 5,25**
 Bracia, módlcie się także za nas.
###### **1Tes 5,26**
 Pozdrówcie wszystkich braci świętym pocałunkiem.
###### **1Tes 5,27**
 Zaklinam was na Pana, niech list ten będzie odczytany wszystkim braciom.
###### **1Tes 5,28**
 Łaska Pana naszego Jezusa Chrystusa niech będzie z wami.
# 1Tes 5 BR
###### **1Tes 5,1**
 Nie muszę wam, bracia, pisać o dniu lub o godzinie.
###### **1Tes 5,2**
 Sami bowiem wiecie dobrze, że dzień Pański przyjdzie jak złodziej nocą.
###### **1Tes 5,3**
 Gdy ludzie będą mówić, że panuje pokój i całkowite bezpieczeństwo, to wtedy właśnie spadnie na nich niespodziewana zagłada, tak jak [nagle] przychodzą bóle na niewiastę brzemienną. Nie zdołają już ujść przed nimi.
###### **1Tes 5,4**
 Ale wy, bracia, nie żyjecie przecież w ciemnościach, by ów dzień miał was zaskoczyć jak złodziej.
###### **1Tes 5,5**
 Wszyscy bowiem jesteście dziećmi światłości i dnia. Nie pozostajemy pod władzą nocy ani ciemności.
###### **1Tes 5,6**
 Tak więc nie powinniśmy trwać w uśpieniu jak wielu innych; musimy być czujni i trzeźwi.
###### **1Tes 5,7**
 Kto śpi, śpi zazwyczaj w nocy, a kto się upija, czyni to również w nocy.
###### **1Tes 5,8**
 My zaś, ponieważ jesteśmy dziećmi dnia, musimy być trzeźwi; powinniśmy przywdziać na siebie pancerz wiary i miłości, założyć na głowę hełm nadziei przyszłego zbawienia.
###### **1Tes 5,9**
 Nie przeznaczył nas przecież Bóg na przedmiot swego zagniewania, lecz do osiągnięcia zbawienia przez Pana naszego Jezusa Chrystusa,
###### **1Tes 5,10**
 który za nas umarł po to, abyśmy czy to jako żywi, czy jako umarli zawsze razem z Nim żyli.
###### **1Tes 5,11**
 Dlatego podnoście się wzajemnie na duchu i budujcie jedni drugich, tak jak to zresztą już czynicie.
###### **1Tes 5,12**
 Prosimy was, bracia, abyście szanowali tych, którzy trudzą się dla was, którzy wam przewodzą i którzy was upominają w imię Pana.
###### **1Tes 5,13**
 Ze względu na ich pracę okazujcie im szczególną miłość. Między sobą zachowujcie spokój.
###### **1Tes 5,14**
 Prosimy was też, bracia, abyście zachęcali do pracy opieszałych, dodawali otuchy małodusznym, otaczali opieką słabych, a dla wszystkich byli cierpliwi.
###### **1Tes 5,15**
 Pamiętajcie, żeby nikt nie odpłacał złem za złe starajcie się zawsze świadczyć dobro, nie tylko sobie nawzajem, lecz także wszystkim ludziom.
###### **1Tes 5,16**
 Bądźcie zawsze radośni,
###### **1Tes 5,17**
 módlcie się nieustannie
###### **1Tes 5,18**
 i za wszystko dziękujcie [Bogu], gdyż taka jest Jego wola względem was, którzy stanowicie jedno z Jezusem Chrystusem.
###### **1Tes 5,19**
 Nie utrudniajcie działania Duchowi [Świętemu],
###### **1Tes 5,20**
 nie lekceważcie sobie daru prorokowania.
###### **1Tes 5,21**
 Wszystko [dokładnie] badajcie, zatrzymując to, co dobre,
###### **1Tes 5,22**
 a unikajcie tego, co ma choć-by tylko pozór zła.
###### **1Tes 5,23**
 A Bóg, Dawca pokoju, niech ześle na was pełnię świętości, tak aby całe wasze jestestwo z duchem, duszą i ciałem było bez zarzutu, gdy przyjdzie Pan nasz Jezus Chrystus.
###### **1Tes 5,24**
 Ten, który was powołał [do świętości], wierny jest; doprowadzi więc swoje dzieło do końca.
###### **1Tes 5,25**
 Bracia, módlcie się także i za nas.
###### **1Tes 5,26**
 Pozdrówcie wszystkich braci pocałunkiem świętego pokoju.
###### **1Tes 5,27**
 Proszę was bardzo, w imię samego Pana, aby list ten był odczytany wszystkim braciom.
###### **1Tes 5,28**
 Łaska Pana naszego Jezusa Chrystusa niech będzie z wami.
# 1Tes 5 WUJ
###### **1Tes 5,1**
 A o czasiech i o chwilach bracia, nie potrzebujecie abyśmy wam pisali.
###### **1Tes 5,2**
 Abowiem sami dostatecznie wiecie, iż dzień Pański, jako złodziej w nocy tak przydzie.
###### **1Tes 5,3**
 Bo gdy rzeką, Pokój i bezpieczeństwo: tedy nagle zginienie przydzie na nie, jako ból w żywocie mającej: a nie wybiegają się.
###### **1Tes 5,4**
 A wy bracia, nie jesteście w ciemności: aby on dzień was miał jako złodziej zastać.
###### **1Tes 5,5**
 Abowiem wszyscy wy, jesteście synowie światłości, i synowie dnia: nie jesteśmy nocy ani ciemności.
###### **1Tes 5,6**
 A tak nie śpimy jako i inszy, ale czujmy i bądźmy trzeźwymi.
###### **1Tes 5,7**
 Abowiem którzy śpią, w nocy śpią: a którzy są pijani, w nocy są pijani.
###### **1Tes 5,8**
 A my, którzy jesteśmy dniowi, bądźmy trzeźwi, oblekszy pancerz wiary i miłości, a przyłbicę nadzieje zbawienia.
###### **1Tes 5,9**
 Gdyż Bóg nie postawił nas ku gniewu, ale ku nabyciu zbawienia przez Pana naszego Jezusa Chrystusa.
###### **1Tes 5,10**
 Który umarł za nas: abyśmy, chociaż czujemy, chociaż śpimy, społu z nim żyli.
###### **1Tes 5,11**
 Dla tego cieszcie się społecznie, i budujcie jeden drugiego, jako i czynicie.
###### **1Tes 5,12**
 A prosiemy was bracia, abyście znali te, którzy pracują między wami, i którzy są przełożonymi waszymi w Panu, i napominają was:
###### **1Tes 5,13**
 Iżbyście je barziej miłowali dla ich prace: pokój miejcie z nimi.
###### **1Tes 5,14**
 A prosiemy was bracia, karzcie niespokojne, cieszcie małego serca, i przyjmujecie niemocne, cierpliwymi bądźcie ku wszystkim.
###### **1Tes 5,15**
 Patrzcie, aby kto złem za złe komu nie oddawał: ale zawżdy co dobrego jest naśladujcie, jeden przeciw drugiemu, i przeciw wszystkim.
###### **1Tes 5,16**
 Zawsze się weselcie.
###### **1Tes 5,17**
 Bez przestanku się módlcie.
###### **1Tes 5,18**
 We wszystkiem dziękujcie: abowiem ta jest wola Boża w Chrystusie Jezusie ku wam wszystkim.
###### **1Tes 5,19**
 Ducha nie gaście.
###### **1Tes 5,20**
 Proroctw nie lekceważcie.
###### **1Tes 5,21**
 A wszystkiego doświadczajcie: co dobre jest dzierzcie.
###### **1Tes 5,22**
 Od wszelakiego podobieństwa złego się powściągajcie.
###### **1Tes 5,23**
 A sam Bóg pokoju niech was we wszystkiem poświęci: aby cały duch wasz, i dusza i ciało bez skargi na przyście Pana naszego Jezusa Chrystusa było zachowane.
###### **1Tes 5,24**
 Wierny jest który was wezwał, który też uczyni.
###### **1Tes 5,25**
 Bracia módlcie się za nas.
###### **1Tes 5,26**
 Pozdrówcie bracią wszystkę w pocałowaniu świętem.
###### **1Tes 5,27**
 Poprzysięgam was przez Pana, aby ten list przeczytan był wszystkiej świętej braciej.
###### **1Tes 5,28**
 Łaska Pana naszego Jezusa Chrystusa z wami, Amen.1
# 1Tes 5 STERN
###### **1Tes 5,1**
 Nie trzeba wam jednak, bracia, nic pisać o czasach i datach, kiedy się to wydarzy,
###### **1Tes 5,2**
 bo sami dobrze wiecie, że Dzień Pana nadejdzie jak złodziej w nocy.
###### **1Tes 5,3**
 Kiedy ludzie będą mówić: "Jest tak spokojnie i bezpiecznie", wtedy spadnie nagle na nich zagłada, jak bóle porodowe przychodzą na ciężarną kobietę, i w żaden sposób nie umkną.
###### **1Tes 5,4**
 Lecz wy, bracia, nie jesteście w ciemności, aby was ten Dzień miał zaskoczyć jak złodziej,
###### **1Tes 5,5**
 bo wszyscy jesteście ludźmi, którzy należą do światłości, należą do dnia. Nie należymy do nocy ani do ciemności,
###### **1Tes 5,6**
 nie śpijmy więc jak pozostali, przeciwnie, pozostańmy czujni i trzeźwi.
###### **1Tes 5,7**
 Ludzie, którzy śpią, śpią w nocy, a którzy się upijają, w nocy się upijają.
###### **1Tes 5,8**
 Ponieważ jednak my należymy do dnia, pozostańmy trzeźwi, przywdziewając ufność i miłość jako pancerz, a nadzieję ocalenia jako hełm.
###### **1Tes 5,9**
 Bo nie jest zamiarem Boga, abyśmy doświadczyli Jego gniewu, lecz abyśmy doznali wyzwolenia przez naszego Pana Jeszuę Mesjasza,
###### **1Tes 5,10**
 który umarł za nas, abyśmy - czy żywi, czy martwi - żyli razem z Nim.
###### **1Tes 5,11**
 Dlatego pokrzepiajcie się nawzajem i budujcie jeden drugiego, tak jak to czynicie.
###### **1Tes 5,12**
 Prosimy was, bracia, abyście szanowali tych, którzy się trudzą wśród was, którzy prowadzą was w Panu i napominają, aby pomóc wam się zmieniać.
###### **1Tes 5,13**
 Traktujcie ich z najwyższym szacunkiem i kochajcie przez wzgląd na pracę, jaką wykonują. Żyjcie w pokoju między sobą,
###### **1Tes 5,14**
 ale nalegamy, bracia, abyście napominali leniwych, z myślą o tym, żeby dopomóc im w zmianie, abyście dodawali otuchy strachliwym, pomagali słabym, a każdemu okazywali cierpliwość.
###### **1Tes 5,15**
 Uważajcie, żeby nikt nie odpłacał złem za zło, przeciwnie, zawsze starajcie się czynić dobrze sobie nawzajem i w ogóle wszystkim.
###### **1Tes 5,16**
 Zawsze bądźcie radośni.
###### **1Tes 5,17**
 Módlcie się regularnie.
###### **1Tes 5,18**
 We wszystkim składajcie dzięki, bo tego właśnie oczekuje Bóg od was, tych, którzy są zjednoczeni z Mesjaszem Jeszuą.
###### **1Tes 5,19**
 Nie gaście Ducha,
###### **1Tes 5,20**
 nie gardźcie natchnionym orędziem.
###### **1Tes 5,21**
 Tylko wszystko sprawdzajcie - trzymajcie się tego, co dobre,
###### **1Tes 5,22**
 ale unikajcie zła we wszelkiej postaci.
###### **1Tes 5,23**
 Niech Bóg szalomu uczyni was w pełni świętymi - niech cały wasz duch, dusza i ciało zachowają się bez zarzutu na przyjście naszego Pana Jeszui Mesjasza.
###### **1Tes 5,24**
 Wierny jest Ten, który was wzywa, i uczyni to.
###### **1Tes 5,25**
 Bracia, módlcie się zawsze za nas.
###### **1Tes 5,26**
 Pozdrówcie wszystkich braci świętym pocałunkiem.
###### **1Tes 5,27**
 Polecam wam w Panu, aby list ten odczytano wszystkim braciom.
###### **1Tes 5,28**
 Łaska naszego Pana Jeszui Mesjasza niech będzie z wami.1
# 1Tes 5 TRO
###### **1Tes 5,1**
 **περι** *peri* O [[G4012]] [[PREP]] **δε** *de* zaś [[G1161]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPM **χρονων** *chronōn* czasach [[G5550]] WTN-GPM **και** *kai* i [[G2532]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPM **καιρων** *kairōn* porach [[G2540]] WTN-GPM **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **ου** *ou* nie [[G3756]] [[PRT-N]] **χρειαν** *chreian* potrzebę [[G5532]] WTN-ASF **εχετε** *echete* macie [[G2192]] WTV-PAI-2P **υμιν** *hymin* wam [[G5213]] WTP-2DP **γραφεσθαι** *grafesthai* być napisane [[G1125]] WTV-PPN
###### **1Tes 5,2**
 **αυτοι** *autoi* Sami [[G846]] WTP-NPM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ακριβως** *akribōs* uważnie – dokładnie [[G199]] [[ADV]] **οιδατε** *oidate* wiecie [[G1492]] WTV-RAI-2P **οτι** *hoti* że [[G3754]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **ημερα** *hēmera* dzień [[G2250]] [[N-NSF]] **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ως** *hōs* jak [[G5613]] [[ADV]] **κλεπτης** *kleptēs* złodziej – kradnący [[G2812]] [[N-NSM]] **εν** *en* w [[G1722]] [[PREP]] **νυκτι** *nykti* nocy [[G3571]] [[N-DSF]] **ουτως** *houtōs* tak [[G3779]] [[ADV]] **ερχεται** *erchetai* przychodzi [[G2064]] WTV-PNI-3S
###### **1Tes 5,3**
 **οταν** *hotan* Gdy [[G3752]] [[CONJ]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **λεγωσιν** *legōsin* mówiliby [[G3004]] WTV-PAS-3P **ειρηνη** *eirēnē* pokój [[G1515]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **ασφαλεια** *asfaleia* bezpieczeństwo – niezawodność [[G803]] [[N-NSF]] **τοτε** *tote* wtedy [[G5119]] [[ADV]] **αιφνιδιος** *aifnidios* nagła – niespodziewana [[G160]] [[A-NSM]] **αυτοις** *autois* (na) nich [[G846]] WTP-DPM **εφισταται** *efistatai* nadciąga – staje obok [[G2186]] WTV-PMI-3S **ολεθρος** *olethros* zagłada – ruina [[G3639]] [[N-NSM]] **ωσπερ** *hōsper* tak, jak [[G5618]] [[ADV]] **η** *hē* [[G3588]] [[T-NSF]] **ωδιν** *ōdin* ból porodowy [[G5604]] [[N-NSF]] **τη** *tē* [[G3588]] WTT-DSF **εν** *en* w [[G1722]] [[PREP]] **γαστρι** *gastri* łonie [[G1064]] [[N-DSF]] **εχουση** *echousē* mającą [[G2192]] WTV-PAP-DSF **και** *kai* i [[G2532]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **μη** *mē* [[G3361]] [[PRT-N]] **εκφυγωσιν** *ekfygōsin* wymknęliby się – uciekliby [[G1628]] WTV-2AAS-3P
###### **1Tes 5,4**
 **υμεις** *hymeis* Wy [[G5210]] WTP-2NP **δε** *de* zaś [[G1161]] [[CONJ]] **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **εν** *en* w [[G1722]] [[PREP]] **σκοτει** *skotei* ciemności [[G4655]] WTN-DSN **ινα** *hina* aby [[G2443]] [[CONJ]] **η** *hē* (ten) [[G3588]] [[T-NSF]] **ημερα** *hēmera* dzień [[G2250]] [[N-NSF]] **υμας** *hymas* was [[G5209]] WTP-2AP **ως** *hōs* jak [[G5613]] [[ADV]] **κλεπτης** *kleptēs* złodziej – kradnący [[G2812]] [[N-NSM]] **καταλαβη** *katalabē* pochwyciłby – złapałby [[G2638]] WTV-2AAS-3S
###### **1Tes 5,5**
 **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **υμεις** *hymeis* wy [[G5210]] WTP-2NP **υιοι** *hyioi* synowie [[G5207]] WTN-NPM **φωτος** *fōtos* światła [[G5457]] [[N-GSN]] **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **και** *kai* i [[G2532]] [[CONJ]] **υιοι** *hyioi* synowie [[G5207]] WTN-NPM **ημερας** *hēmeras* dnia [[G2250]] [[N-GSF]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εσμεν** *esmen* jesteśmy [[G2070]] WTV-PXI-1P **νυκτος** *nyktos* nocy [[G3571]] [[N-GSF]] **ουδε** *oude* ani [[G3761]] [[ADV]] **σκοτους** *skotous* ciemności [[G4655]] [[N-GSN]]
###### **1Tes 5,6**
 **αρα** *ara* Zatem [[G686]] WTPRT **ουν** *oun* więc [[G3767]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **καθευδωμεν** *katheudōmen* spalibyśmy [[G2518]] WTV-PAS-1P **ως** *hōs* jak [[G5613]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **λοιποι** *loipoi* pozostali [[G3062]] WTA-NPM **αλλα** *alla* ale [[G235]] [[CONJ]] **γρηγορωμεν** *grēgorōmen* czuwalibyśmy [[G1127]] WTV-PAS-1P **και** *kai* i [[G2532]] [[CONJ]] **νηφωμεν** *nēfōmen* bylibyśmy trzeźwi [[G3525]] WTV-PAS-1P
###### **1Tes 5,7**
 **οι** *hoi* [[G3588]] WTT-NPM **γαρ** *gar* Bowiem [[G1063]] [[CONJ]] **καθευδοντες** *katheudontes* śpiący [[G2518]] WTV-PAP-NPM **νυκτος** *nyktos* nocą [[G3571]] [[N-GSF]] **καθευδουσιν** *katheudousin* śpią [[G2518]] WTV-PAI-3P **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **μεθυσκομενοι** *methyskomenoi* którzy są upici [[G3182]] WTV-PPP-NPM **νυκτος** *nyktos* nocą [[G3571]] [[N-GSF]] **μεθυουσιν** *methyousin* są pijani [[G3184]] WTV-PAI-3P
###### **1Tes 5,8**
 **ημεις** *hēmeis* My [[G2249]] WTP-1NP **δε** *de* zaś [[G1161]] [[CONJ]] **ημερας** *hēmeras* dnia [[G2250]] [[N-GSF]] **οντες** *ontes* będąc [[G5607]] WTV-PXP-NPM **νηφωμεν** *nēfōmen* bylibyśmy trzeźwi [[G3525]] WTV-PAS-1P **ενδυσαμενοι** *endysamenoi* przyoblekłszy się w – wdziawszy na siebie [[G1746]] WTV-AMP-NPM **θωρακα** *thōraka* pancerz [[G2382]] [[N-ASM]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **αγαπης** *agapēs* miłości [[G26]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **περικεφαλαιαν** *perikefalaian* hełm [[G4030]] WTN-ASF **ελπιδα** *elpida* nadziei [[G1680]] WTN-ASF **σωτηριας** *sōtērias* zbawienia – wyzwolenia [[G4991]] [[N-GSF]]
###### **1Tes 5,9**
 **οτι** *hoti* Gdyż [[G3754]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εθετο** *etheto* umieścił – położył [[G5087]] WTV-2AMI-3S **ημας** *hēmas* nas [[G2248]] WTP-1AP **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **εις** *eis* ku – do [[G1519]] [[PREP]] **οργην** *orgēn* gniewowi [[G3709]] WTN-ASF **αλλ** *all* ale [[G235]] [[CONJ]] **εις** *eis* ku – do [[G1519]] [[PREP]] **περιποιησιν** *peripoiēsin* pozyskaniu dla siebie – nabyciu dla siebie [[G4047]] WTN-ASF **σωτηριας** *sōtērias* zbawienia – wyzwolenia [[G4991]] [[N-GSF]] **δια** *dia* przez [[G1223]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezus – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **1Tes 5,10**
 **του** *tou* [[G3588]] WTT-GSM **αποθανοντος** *apothanontos* który umarł [[G599]] WTV-2AAP-GSM **υπερ** *hyper* za [[G5228]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP **ινα** *hina* aby [[G2443]] [[CONJ]] **ειτε** *eite* czy to [[G1535]] [[CONJ]] **γρηγορωμεν** *grēgorōmen* czuwalibyśmy [[G1127]] WTV-PAS-1P **ειτε** *eite* czy to [[G1535]] [[CONJ]] **καθευδωμεν** *katheudōmen* spalibyśmy [[G2518]] WTV-PAS-1P **αμα** *hama* równocześnie [[G260]] [[ADV]] **συν** *syn* z [[G4862]] [[PREP]] **αυτω** *autō* Nim [[G846]] WTP-DSM **ζησωμεν** *zēsōmen* żylibyśmy [[G2198]] WTV-AAS-1P
###### **1Tes 5,11**
 **διο** *dio* Dlatego [[G1352]] [[CONJ]] **παρακαλειτε** *parakaleite* zachęcajcie [[G3870]] WTV-PAM-2P **αλληλους** *allēlous* jedni drugich [[G240]] WTC-APM **και** *kai* i [[G2532]] [[CONJ]] **οικοδομειτε** *oikodomeite* budujcie [[G3618]] WTV-PAM-2P **εις** *heis* jeden [[G1520]] [[A-NSM]] **τον** *ton* [[G3588]] [[T-ASM]] **ενα** *hena* jednego [[G1520]] WTA-ASM **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **ποιειτε** *poieite* czynicie [[G4160]] WTV-PAI-2P
###### **1Tes 5,12**
 **ερωτωμεν** *erōtōmen* Prosimy [[G2065]] WTV-PAI-1P **δε** *de* zaś [[G1161]] [[CONJ]] **υμας** *hymas* was [[G5209]] WTP-2AP **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **ειδεναι** *eidenai* (by) wiedzieć [[G1492]] WTV-RAN **τους** *tous* (o) [[G3588]] WTT-APM **κοπιωντας** *kopiōntas* trudzących się [[G2872]] WTV-PAP-APM **εν** *en* wśród [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **και** *kai* i [[G2532]] [[CONJ]] **προισταμενους** *proistamenous* stojących na czele [[G4291]] WTV-PMP-APM **υμων** *hymōn* was [[G5216]] WTP-2GP **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **νουθετουντας** *nouthetountas* napominając – kładąc do rozumu [[G3560]] WTV-PAP-APM **υμας** *hymas* was [[G5209]] WTP-2AP
###### **1Tes 5,13**
 **και** *kai* i [[G2532]] [[CONJ]] **ηγεισθαι** *hēgeisthai* (by) uznawać [[G2233]] WTV-PNN **αυτους** *autous* ich [[G846]] [[P-APM]] **υπερ** *hyper* ponad – naj- [[G5228]] [[PREP]] **εκπερισσου** *ekperissou* wszelką miarę – bardziej [[G4057]] [[ADV]] **εν** *en* w [[G1722]] [[PREP]] **αγαπη** *agapē* miłości [[G26]] [[N-DSF]] **δια** *dia* z powodu [[G1223]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **εργον** *ergon* pracy – dzieła [[G2041]] WTN-ASN **αυτων** *autōn* ich [[G846]] WTP-GPM **ειρηνευετε** *eirēneuete* zachowujcie pokój [[G1514]] WTV-PAM-2P **εν** *en* wśród [[G1722]] [[PREP]] **εαυτοις** *heautois* siebie samych [[G1438]] WTF-3DPM
###### **1Tes 5,14**
 **παρακαλουμεν** *parakaloumen* Zachęcamy [[G3870]] WTV-PAI-1P **δε** *de* zaś [[G1161]] [[CONJ]] **υμας** *hymas* was [[G5209]] WTP-2AP **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **νουθετειτε** *noutheteite* napominajcie – kładźcie do rozumu [[G3560]] WTV-PAM-2P **τους** *tous* [[G3588]] WTT-APM **ατακτους** *ataktous* niekarnych – nie trzymających szyku [[G813]] WTA-APM **παραμυθεισθε** *paramytheisthe* pocieszajcie [[G3888]] WTV-PNM-2P **τους** *tous* [[G3588]] WTT-APM **ολιγοψυχους** *oligopsychous* małodusznych – trwożliwych [[G3642]] WTA-APM **αντεχεσθε** *antechesthe* podtrzymujcie [[G472]] WTV-PNM-2P **των** *tōn* [[G3588]] WTT-GPM **ασθενων** *asthenōn* słabych – bezsilnych [[G772]] WTA-GPM **μακροθυμειτε** *makrothymeite* bądźcie cierpliwi – bądźcie wyrozumiali [[G3114]] WTV-PAM-2P **προς** *pros* względem [[G4314]] [[PREP]] **παντας** *pantas* wszystkich [[G3956]] WTA-APM
###### **1Tes 5,15**
 **ορατε** *horate* Patrzcie – Uważajcie [[G3708]] WTV-PAM-2P **μη** *mē* aby nie [[G3361]] [[PRT-N]] **τις** *tis* ktoś [[G5100]] WTX-NSM **κακον** *kakon* zła [[G2556]] WTA-ASN **αντι** *anti* za [[G473]] [[PREP]] **κακου** *kakou* zło [[G2556]] [[A-GSN]] **τινι** *tini* komuś [[G5100]] WTX-DSM **αποδω** *apodō* oddałby [[G591]] WTV-2AAS-3S **αλλα** *alla* ale [[G235]] [[CONJ]] **παντοτε** *pantote* zawsze – w każdej chwili [[G3842]] [[ADV]] **το** *to* [[G3588]] WTT-ASN **αγαθον** *agathon* dobro [[G18]] WTA-ASN **διωκετε** *diōkete* ścigajcie – zabiegajcie o [[G1377]] WTV-PAM-2P **και** *kai* i [[G2532]] [[CONJ]] **εις** *eis* względem [[G1519]] [[PREP]] **αλληλους** *allēlous* jedni drugich [[G240]] WTC-APM **και** *kai* i [[G2532]] [[CONJ]] **εις** *eis* względem [[G1519]] [[PREP]] **παντας** *pantas* wszystkich [[G3956]] WTA-APM
###### **1Tes 5,16**
 **παντοτε** *pantote* Zawsze – W każdej chwili [[G3842]] [[ADV]] **χαιρετε** *chairete* radujcie się – cieszcie się [[G5463]] WTV-PAM-2P
###### **1Tes 5,17**
 **αδιαλειπτως** *adialeiptōs* nieustannie [[G89]] [[ADV]] **προσευχεσθε** *proseuchesthe* módlcie się [[G4336]] WTV-PNM-2P
###### **1Tes 5,18**
 **εν** *en* We [[G1722]] [[PREP]] **παντι** *panti* wszystkim [[G3956]] WTA-DSN **ευχαριστειτε** *eucharisteite* dziękujcie [[G2168]] WTV-PAM-2P **τουτο** *touto* to [[G5124]] WTD-NSN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **θελημα** *thelēma* wola [[G2307]] WTN-NSN **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM **εις** *eis* względem [[G1519]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP
###### **1Tes 5,19**
 **το** *to* [[G3588]] WTT-ASN **πνευμα** *pneuma* Ducha [[G4151]] WTN-ASN **μη** *mē* nie [[G3361]] [[PRT-N]] **σβεννυτε** *sbennyte* gaście [[G4570]] WTV-PAM-2P
###### **1Tes 5,20**
 **προφητειας** *profēteias* Prorokowań [[G4394]] WTN-APF **μη** *mē* nie [[G3361]] [[PRT-N]] **εξουθενειτε** *eksoutheneite* lekceważcie – miej za nic [[G1848]] WTV-PAM-2P
###### **1Tes 5,21**
 **παντα** *panta* Wszystkie [[G3956]] WTA-APN **δοκιμαζετε** *dokimazete* badajcie – próbujcie [[G1381]] WTV-PAM-2P **το** *to* (co) [[G3588]] WTT-ASN **καλον** *kalon* dobre – piękne [[G2570]] WTA-ASN **κατεχετε** *katechete* trzymajcie [[G2722]] WTV-PAM-2P
###### **1Tes 5,22**
 **απο** *apo* od [[G575]] [[PREP]] **παντος** *pantos* każdej [[G3956]] [[A-GSN]] **ειδους** *eidous* postaci – formy [[G1491]] [[N-GSN]] **πονηρου** *ponērou* niegodziwego – złego [[G4190]] [[A-GSN]] **απεχεσθε** *apechesthe* wstrzymujcie się [[G567]] WTV-PMM-2P
###### **1Tes 5,23**
 **αυτος** *autos* Sam [[G846]] WTP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **της** *tēs* [[G3588]] [[T-GSF]] **ειρηνης** *eirēnēs* pokoju [[G1515]] [[N-GSF]] **αγιασαι** *hagiasai* oby uczynił świętymi – oby poświęcił [[G37]] WTV-AAO-3S **υμας** *hymas* was [[G5209]] WTP-2AP **ολοτελεις** *holoteleis* całkowicie [[G3651]] WTA-APM **και** *kai* i [[G2532]] [[CONJ]] **ολοκληρον** *holoklēron* w pełni wyposażonym [[G3648]] WTA-NSN **υμων** *hymōn* wasz [[G5216]] WTP-2GP **το** *to* [[G3588]] WTT-NSN **πνευμα** *pneuma* duch [[G4151]] WTN-NSN **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **ψυχη** *psychē* dusza [[G5590]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **σωμα** *sōma* ciało [[G4983]] WTN-NSN **αμεμπτως** *amemptōs* nienagannie [[G274]] [[ADV]] **εν** *en* podczas [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **παρουσια** *parousia* przyjścia [[G3952]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **τηρηθειη** *tērētheiē* oby zostały zachowane – oby zostały ustrzeżone [[G5083]] WTV-APO-3S
###### **1Tes 5,24**
 **πιστος** *pistos* Wierny [[G4103]] [[A-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **καλων** *kalōn* wzywający [[G2564]] [[V-PAP-NSM]] **υμας** *hymas* was [[G5209]] WTP-2AP **ος** *hos* który [[G3739]] WTR-NSM **και** *kai* i [[G2532]] [[CONJ]] **ποιησει** *poiēsei* uczyni [[G4160]] WTV-FAI-3S
###### **1Tes 5,25**
 **αδελφοι** *adelfoi* Bracia [[G80]] WTN-VPM **προσευχεσθε** *proseuchesthe* módlcie się [[G4336]] WTV-PNM-2P **περι** *peri* za [[G4012]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP
###### **1Tes 5,26**
 **ασπασασθε** *aspasasthe* Pozdrówcie [[G782]] WTV-ADM-2P **τους** *tous* [[G3588]] WTT-APM **αδελφους** *adelfous* braci [[G80]] [[N-APM]] **παντας** *pantas* wszystkich [[G3956]] WTA-APM **εν** *en* przez [[G1722]] [[PREP]] **φιληματι** *filēmati* pocałunek [[G5370]] WTN-DSN **αγιω** *hagiō* święty [[G40]] WTA-DSN
###### **1Tes 5,27**
 **ορκιζω** *horkizō* Zaklinam – Poprzysięgam [[G3726]] WTV-PAI-1S **υμας** *hymas* was [[G5209]] WTP-2AP **τον** *ton* (na) [[G3588]] [[T-ASM]] **κυριον** *kyrion* Pana [[G2962]] [[N-ASM]] **αναγνωσθηναι** *anagnōsthēnai* (by) zostać odczytany [[G314]] WTV-APN **την** *tēn* (ten) [[G3588]] WTT-ASF **επιστολην** *epistolēn* list [[G1992]] WTN-ASF **πασιν** *pasin* wszystkim [[G3956]] WTA-DPM **τοις** *tois* [[G3588]] WTT-DPM **αγιοις** *hagiois* świętym [[G40]] WTA-DPM **αδελφοις** *adelfois* braciom [[G80]] WTN-DPM
###### **1Tes 5,28**
 **η** *hē* [[G3588]] [[T-NSF]] **χαρις** *charis* Łaska [[G5485]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **μεθ** *meth* z [[G3326]] [[PREP]] **υμων** *hymōn* wami [[G5216]] WTP-2GP **αμην** *amēn* amen – [zaprawdę] [[G281]] WTHEB **προς** *pros* do [[G4314]] [[PREP]] **θεσσαλονικεις** *thessalonikeis* Tesaloniczan [[G2331]] [[N-APM]] **πρωτη** *prōtē* najpierw [[G4413]] WTA-NSF **εγραφη** *egrafē* zostało napisane [[G1125]] WTV-2API-3S **απο** *apo* z [[G575]] [[PREP]] **αθηνων** *athēnōn* Aten [[G116]] WTN-GPF
