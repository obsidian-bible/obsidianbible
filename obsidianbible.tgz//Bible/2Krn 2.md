# 2Krn 2 BT5
###### **2Krn 2,1**
 Odliczył potem Salomon siedemdziesiąt tysięcy mężczyzn do dźwigania i osiemdziesiąt tysięcy do wydobywania kamienia w górach, a nadzorców nad nimi – trzy tysiące sześciuset.
###### **2Krn 2,2**
 Następnie przesłał Salomon do Hurama, króla Tyru, takie słowa: «***Uczyń, jak uczyniłeś mojemu ojcu, Dawidowi, przysyłając mu drewno cedrowe, by wybudować mu dom na mieszkanie.***
###### **2Krn 2,3**
 ***Oto ja buduję dom dla imienia Pana, Boga mego, aby Mu go poświęcić, aby palić przed Nim wonne kadzidło, składać nieustannie chleby i ofiary całopalne rankiem i wieczorem, w szabaty i w dni nowiu księżyca, w święta Pana, Boga naszego, i to na wieki w Izraelu.***
###### **2Krn 2,4**
 ***Dom ten, który ja buduję, będzie wielki, albowiem nasz Bóg większy jest od wszystkich bogów.***
###### **2Krn 2,5**
 ***Któż zdoła wybudować Mu dom, skoro niebiosa i najwyższe niebiosa nie mogą Go ogarnąć? Kimże ja jestem, aby wybudować Mu dom, choćby tylko po to, by palić przed Nim kadzidło?***
###### **2Krn 2,6**
 ***Przyślij mi teraz mądrego człowieka, aby umiał wyrabiać przedmioty ze złota i srebra, z brązu i żelaza, z purpury, karmazynu i fioletowej purpury, aby umiał rzeźbić i współpracować z artystami, którzy są ze mną w Judzie i w Jerozolimie, których przygotował mój ojciec, Dawid.***
###### **2Krn 2,7**
 ***Nadeślij mi też drewna cedrowego, cyprysowego i sandałowego z Libanu, wiem bowiem, że słudzy twoi umieją wycinać drzewa Libanu. Oto moi słudzy będą razem z twoimi sługami,***
###### **2Krn 2,8**
 ***aby przygotować mi drewno w wielkiej ilości, albowiem dom, który ja buduję, będzie wielki i budzący podziw.***
###### **2Krn 2,9**
 ***A oto daję na wyżywienie dla drwali, twoich sług ścinających drzewa, dwadzieścia tysięcy kor wymłóconej pszenicy, dwadzieścia tysięcy kor jęczmienia, dwadzieścia tysięcy bat wina i dwadzieścia tysięcy bat oliwy***».
###### **2Krn 2,10**
 Na to odpowiedział na piśmie król Tyru, Huram, i wysłał je do Salomona: «***Ponieważ Pan umiłował swój lud, ustanowił ciebie nad nim królem***».
###### **2Krn 2,11**
 Następnie mówił Huram: «***Błogosławiony Pan, Bóg Izraela, który uczynił niebiosa i ziemię, który dał królowi Dawidowi syna mądrego, roztropnego i rozumnego, tak iż będzie budował dom dla Pana, a dla siebie pałac królewski.***
###### **2Krn 2,12**
 ***Posyłam ci obecnie mądrego, roztropnego człowieka, Hurama-Abi,***
###### **2Krn 2,13**
 ***syna pewnej kobiety spośród Danitek i z ojca Tyryjczyka. Umie on wyrabiać przedmioty ze złota i ze srebra, z brązu i z żelaza, z kamieni, z drewna, z czerwonej i z fioletowej purpury, z bisioru i karmazynu; [będzie on] wykonywał wszelkie rzeźby i obmyślał każdy projekt, jaki będzie mu dany, razem z twymi artystami i z artystami mego pana, a twego ojca, Dawida.***
###### **2Krn 2,14**
 ***Teraz więc niech przyśle mój pan swoim sługom pszenicę i jęczmień, oliwę i wino, o których mówił.***
###### **2Krn 2,15**
 ***My zaś będziemy wycinać drzewa z Libanu stosownie do twej potrzeby i sprowadzimy je morzem na tratwach do Jafy, ty zaś każesz je dostarczyć do Jerozolimy***».
###### **2Krn 2,16**
 Policzył więc Salomon wszystkich mężczyzn obcoplemieńców, zamieszkałych w ziemi Izraela, według spisu jego ojca, Dawida. Znalazło się ich sto pięćdziesiąt trzy tysiące sześciuset.
###### **2Krn 2,17**
 Siedemdziesiąt tysięcy z nich przeznaczył do dźwigania, osiemdziesiąt tysięcy do wydobywania kamienia w górach, a trzy tysiące sześciuset na nadzorców, aby dopilnowali pracy ludu.
# 2Krn 2 PAU
###### **2Krn 2,1**
 Siedemdziesiąt tysięcy robotników skierował Salomon do przewozu materiałów, a osiemdziesiąt tysięcy do prac w kamieniołomach. Wyznaczył nad nimi trzy tysiące sześciuset nadzorców.
###### **2Krn 2,2**
 Następnie Salomon zwrócił się z prośbą do króla Tyru, Hirama: „Przychyliłeś się do prośby mego ojca Dawida i wysłałeś mu drewno cedrowe, kiedy budował swój pałac, aby w nim zamieszkać.
###### **2Krn 2,3**
 Ja postanowiłem zbudować dom dla imienia PANA, mego Boga. Jemu będzie poświęcony, aby przed Jego obliczem palić wonne kadzidło, aby regularnie układać chleby poświęcone, aby rano i wieczorem składać ofiary całopalne, a także w szabaty, w dni nowiu księżyca, w święta PANA, naszego Boga. Taki jest wieczysty obowiązek Izraela.
###### **2Krn 2,4**
 Zamierzam zbudować wielki dom, ponieważ nasz Bóg jest największy ze wszystkich bogów.
###### **2Krn 2,5**
 Kto może zbudować Mu dom, jeśli niebo i niebo najwyższe nie mogą Go pomieścić? Kimże ja jestem, abym mógł zbudować Mu dom i palić przed Nim kadzidło?
###### **2Krn 2,6**
 Przyślij mi więc człowieka doświadczonego w obróbce złota, srebra, brązu i żelaza, znawcę purpury, karmazynu, fioletowej purpury i sztuki rzeźbiarskiej. Niech pracuje z moimi rzemieślnikami z Judy i z Jerozolimy, których wyznaczył mój ojciec Dawid.
###### **2Krn 2,7**
 Dostarcz mi również z Libanu drewna cedrowego, cyprysowego i sandałowego. Wiem bowiem, że twoi słudzy potrafią wycinać drzewa Libanu. Moi robotnicy będą pracować razem z twoimi,
###### **2Krn 2,8**
 aby przygotować wielką ilość drewna. Bo dom, który buduję, ma być wielki i wspaniały.
###### **2Krn 2,9**
 Na wyżywienie dla drwali, twoich poddanych, którzy będą wycinać drzewa, przeznaczam dwadzieścia tysięcy kor pszenicy, dwadzieścia tysięcy kor jęczmienia, dwadzieścia tysięcy bat wina i dwadzieścia tysięcy bat oliwy”.
###### **2Krn 2,10**
 Król Tyru, Hiram, wysłał Salomonowi list z następującą odpowiedzią: „Ponieważ PAN kocha swój lud, ciebie ustanowił nad nim królem”.
###### **2Krn 2,11**
 Dalej Hiram napisał: „Niech będzie błogosławiony PAN, Bóg Izraela, który stworzył niebo i ziemię. On króla Dawida obdarzył synem mądrym, roztropnym i rozumnym, który podejmuje się budowy domu dla PANA i pałacu królewskiego.
###### **2Krn 2,12**
 Posyłam ci Hirama-Abiego, człowieka mądrego i rozumnego.
###### **2Krn 2,13**
 Jego matka pochodzi z plemienia Dana, a jego ojciec z Tyru. Potrafi on wykonywać przedmioty ze złota, srebra, brązu i żelaza, ma doświadczenie w obróbce kamienia i drewna, zna się na czerwonej i fioletowej purpurze, na bisiorze i karmazynie. Umie rzeźbić i potrafi wykonać każdy projekt razem z twoimi rzemieślnikami oraz rzemieślnikami mojego pana Dawida, twojego ojca.
###### **2Krn 2,14**
 Niech więc mój pan przyśle swym sługom pszenicę i jęczmień, oliwę i wino, które obiecał.
###### **2Krn 2,15**
 My wytniemy w Libanie potrzebną ci ilość drzew i sprowadzimy je tratwami drogą morską do Jafy. Ty zaś zajmij się ich transportem do Jerozolimy”.
###### **2Krn 2,16**
 Salomon zgromadził wszystkich cudzoziemców mieszkających w ziemi Izraela, których zgodnie ze spisem ludności dokonanym przez jego ojca Dawida było sto pięćdziesiąt trzy tysiące sześciuset.
###### **2Krn 2,17**
 Siedemdziesiąt tysięcy spośród nich Salomon skierował do przewozu materiałów, a osiemdziesiąt tysięcy do prac w kamieniołomach. Wyznaczył nad nimi trzy tysiące sześciuset nadzorców, aby doglądali pracy ludu.
# 2Krn 2 BP
###### **2Krn 2,1**
 Salomon wyznaczył 70 000 mężczyzn do noszenia [ciężarów] i 80 000 mężczyzn do łamania [kamienia] w górach, a nad nimi 3600 [dozorców].
###### **2Krn 2,2**
 Posłał też Salomon do Chirama, króla Tyru, z prośbą: Postąp ze mną tak, jak postąpiłeś z ojcem moim Dawidem, gdyś mu przysłał drzewo cedrowe, aby mógł wybudować sobie dom na mieszkanie.
###### **2Krn 2,3**
 Oto ja wznoszę Dom dla Imienia Jahwe, Boga mojego, aby Mu go poświęcić na palenie przed Nim wonnych ofiar z kadzidła, dla nieustannej [ofiary] z chlebów składanych [Bogu], dla całopalenia porannego i wieczornego, w szabaty, podczas nowiu księżyca i w uroczyste święta Jahwe, Boga naszego, co jest nakazem dla Izraela na wieki.
###### **2Krn 2,4**
 A Dom, który mam budować, będzie wielki, albowiem Bóg nasz jest wyższy ponad wszystkich bogów.
###### **2Krn 2,5**
 Któż jednak zdoła wznieść Dom dla Niego, skoro niebiosa nawet i najwyższe sfery ogarnąć Go nie mogą? Kimże jestem ja, bym Dom budował dla Niego albo bym [godny] był Mu składać ofiarę z kadzidła?
###### **2Krn 2,6**
 Teraz więc przyślij mi człowieka sprawnego, który umiałby wykonywać przedmioty ze złota, srebra, spiżu, żelaza, z purpury jasnej i purpury ciemnej i który by umiał rzeźbić, [by pracował] wraz z innymi rzemieślnikami, którzy są przy mnie w Judzie i w Jeruzalem, przygotowani jeszcze przez ojca mego Dawida.
###### **2Krn 2,7**
 Przyślij mi również z Libanu drzewa cedrowego, cyprysowego i sandałowego. Wiem bowiem, że twoi słudzy umieją ścinać drzewo na Libanie. Moi słudzy będą [współpracowali] z twoimi sługami,
###### **2Krn 2,8**
 aby mi przygotowali jak najwięcej drzewa, albowiem Dom, który buduję, ma być wielki i wspaniały.
###### **2Krn 2,9**
 Na wyżywienie dla robotników, sług twoich, którzy będą ścinać drzewo, przeznaczam 12 000 kor wymłóconej pszenicy, 20 000 kor jęczmienia, 20 000 bat wina i podobnież 20 000 bat oliwy.
###### **2Krn 2,10**
 Odpowiedział na to król Chiram w piśmie, które wysłał do Salomona: Dlatego że umiłował Jahwe swój lud, ustanowił cię nad nim królem. -
###### **2Krn 2,11**
 I mówił dalej Chiram: - Błogosławiony niech będzie Jahwe, Bóg Izraela, który uczynił niebiosa i ziemię i dał królowi Dawidowi syna mądrego, roztropnego i rozumnego, który buduje Dom dla Jahwe i pałac królewski dla siebie.
###### **2Krn 2,12**
 Posyłam ci tedy Chirama-Abi, męża mądrego i biegłego,
###### **2Krn 2,13**
 syna kobiety z pokolenia Dana i ojca Tyryjczyka. Zna się na robotach w złocie, srebrze, spiżu, żelazie, kamieniu, drzewie, a także [na wyrobach] z jasnej i ciemnej purpury, bisioru i karmazynu. Potrafi on również wykonywać wszelkie rzeźby i zrealizować każde zamierzenie wespół z rzemieślnikami twymi i rzemieślnikami pana mego, a twego ojca - Dawida.
###### **2Krn 2,14**
 Pszenicę zaś, jęczmień, oliwę i wino, które pan mój przyobiecał, niech przyśle sługom swoim.
###### **2Krn 2,15**
 My naścinamy drzewa w Libanie, ile ci tylko potrzeba, i sprowadzimy je morzem tratwami do Jaffy, a ty przewieziesz je do Jeruzalem.
###### **2Krn 2,16**
 Policzył jeszcze Salomon wszystkich mężczyzn będących przychodniami w ziemi izraelskiej po tym spisie, którego dokonał ojciec jego Dawid; było ich 153 600.
###### **2Krn 2,17**
 Wybrał z nich następnie 70000 do dźwigania [ciężarów], 80000 do łamania [kamieni] w górach oraz 3600 dozorców nad robotami ludu.
# 2Krn 2 BR
###### **2Krn 2,1**
 Wyznaczył Salomon siedemdziesiąt tysięcy robotników, którzy mieli być zatrudnieni przy noszeniu materiałów, osiemdziesiąt tysięcy kamieniarzy miało pracować w górach, a trzy tysiące sześciuset zostało wyznaczonych do czuwania nad przebiegiem robót.
###### **2Krn 2,2**
 Posłał Salomon swoich ludzi z następującą prośbą do króla Tyru Hurama: Zechciej i mnie wyświadczyć dobrodziejstwo jakie kiedyś wyświadczyłeś mojemu ojcu, Dawidowi, wysyłając mu drewno cedrowe na dom, który sobie zamierzał zbudować.
###### **2Krn 2,3**
 Przystępuję bowiem do budowy świątyni dla imienia Jahwe, mojego Boga. Jemu pragnę ją poświęcić, by były tam palone przed Jego obliczem wonne kadzidła i składane chleby pokładne, ofiary całopalenia każdego dnia rano i wieczorem, we wszystkie szabaty i nowie księżyca oraz w święta Jahwe, naszego Boga - wszystko zgodnie z tym, co nakazał On Izraelowi czynić po wszystkie czasy.
###### **2Krn 2,4**
 Świątynia, którą zamierzam zbudować, musi być wielka, bo nasz Bóg większy jest od wszystkich bogów.
###### **2Krn 2,5**
 Któż jednak jest w stanie zbudować dom dla Tego, którego nie mogą objąć niebiosa i niebiosa niebios? Kimże ja jestem, że mam zbudować dla Niego świątynię albo palić przed Nim wonne kadzidła?
###### **2Krn 2,6**
 Przyślij mi tedy, proszę, zdolnego rzemieślnika, który potrafi wyrabiać różne przedmioty ze złota i ze srebra, z brązu i żelaza, z purpury czerwonej, z karmazynu oraz z purpury fioletowej; takiego, który by się znał na sztuce rzeźbienia i potrafił współpracować z rzemieślnikami, jacy są u mnie, w Judei i w Jerozolimie, i zostali już do tych prac przygotowani przez mojego ojca, Dawida.
###### **2Krn 2,7**
 Przyślij mi także z Libanu drewna cedrowego, cyprysowego i sandałowego, wiem bowiem, że twoi słudzy potrafią ścinać drzewa w Libanie. Moi słudzy będą pracować razem z twoimi sługami.
###### **2Krn 2,8**
 W ten sposób przygotują mi dostatecznie dużo drewna, gdyż świątynia, którą zamierzam zbudować, musi być wielka i wspaniała.
###### **2Krn 2,9**
 Dla twoich sług, drwali, zatrudnionych przy ścinaniu drzew, przeznaczam na pożywienie dwadzieścia tysięcy kor pszenicy, dwadzieścia tysięcy kor jęczmienia, dwadzieścia tysięcy bat wina i dwadzieścia tysięcy bat oliwy.
###### **2Krn 2,10**
 Huram, król Tyru, przekazał Salomonowi listem taką oto odpowiedź: Ponieważ Jahwe miłuje swój lud, ustanowił cię królem nad nim.
###### **2Krn 2,11**
 I dalej pisał Huram: Błogosławiony niech będzie Jahwe, Bóg Izraela, który stworzył niebo i ziemię, że dał królowi Dawidowi syna mądrego, roztropnego i bardzo pojętnego i zlecił mu budowę świątyni Jahwe oraz pałacu królewskiego.
###### **2Krn 2,12**
 Posyłam ci więc człowieka bardzo zdolnego i mądrego, Huram-Abiego.
###### **2Krn 2,13**
 Jego matka pochodził z córek Dana, ojciec zaś był Tyryjczykiem. Umie on sporządzać różne przedmioty ze złota i srebra, z brązu i z żelaza, z kamieni i z drewna, z purpury czerwonej i fioletowej, z karmazynu i z bisioru. potrafi także wykonywać rzeźby i rysować wszelkie plany, o jakie tylko się go poprosi. (Będzie mógł) współdziałać z twoimi rzemieślnikami oraz z ludźmi doświadczonymi mojego pana, a twojego ojca, Dawida.
###### **2Krn 2,14**
 Racz tedy tylko, panie mój, wysłać swoim sługom pszenicę, jęczmień, oliwę i wino w obiecanych ilościach.
###### **2Krn 2,15**
 My zaś zabierzemy się do ścinania drzew na Libanie. Ścięte drzewa prześlemy na tratwach drogą morską aż do Jafy, skąd ty już dostarczysz je do Jerozolimy.
###### **2Krn 2,16**
 W tym czasie Salomon przeprowadził spis wszystkich żyjących w Izraelu cudzoziemców według wykazu, który kiedyś sporządził jego ojciec, Dawid. Okazało się, że wszystkich było sto pięćdziesiąt trzy tysiące sześciuset.
###### **2Krn 2,17**
 Spośród nich siedemdziesiąt tysięcy przeznaczył do noszenia materiałów (budowlanych), osiemdziesiąt tysięcy - do wydobywania kamieni w górach oraz trzy tysiące sześciuset do nadzorowania wszelkich robót.
# 2Krn 2 WUJ
###### **2Krn 2,1**
 I umyślił Salomon budować dom imieniowi Pańskiemu, a sobie pałac.
###### **2Krn 2,2**
 I naliczył siedmdziesiąt tysięcy mężów co na ramionach nosili, a ośmdziesiąt tysięcy tych co kamienie w górach łamali, i przystawów ich trzy tysiące sześć set.
###### **2Krn 2,3**
 Posłał też do Hirama króla Tyrskiego, mówiąc: Jakoś czynił z Dawidem ojcem moim, i posłałeś mu drzewo, cedrowe, aby zbudował sobie dom, w którym i mieszkał.
###### **2Krn 2,4**
 Tak też uczyń ze mną, abym zbudował dom imieniowi Pana Boga mego, abych ji poświęcił na zapalenie przed nim i kadzenie wonnych rzeczy, i na wykładanie ustawiczne chleba, i na ofiary całopalone rano i w wieczór, w Soboty też i na nowie miesiąców, i w święta uroczyste Pana Boga naszego na wieki, które są przykazane Izraelowi.
###### **2Krn 2,5**
 Bo dom, który chcę budować, wielki jest: abowiem wielki jest Bóg nasz nade wszystkie Bogi.
###### **2Krn 2,6**
 Któż tedy będzie mógł przemódz, żeby mu dom godny zbudował? jeśliż go niebo, i niebiosa nad niebiosy ogarnąć nie mogą: cóżem ja jest, żebych mu mógł dom zbudować? ale tylko na to, aby przed nim było palone kadzenie.
###### **2Krn 2,7**
 A tak poszli mi człowieka umiejętnego, któryby umiał robić złotem i ze srebrem, miedzią, i z żelazem, szarłatem, karmazynem, i hiacynthem, i któryby umiał ryć rzezania, z temi rzemieślniki, które mam przy sobie w Żydowskiej ziemi i w Jeruzalem, które Dawid ociec mój nagotował.
###### **2Krn 2,8**
 Ale i drzewa cedrowego pośli mi, i jałowcowego i sosnowego z Libanu: bo wiem, iż słudzy twoi umieją wyrębować drzewa z Libanu, a słudzy moi będą z sługami twemi,
###### **2Krn 2,9**
 Aby mi co nawięcej drzewa wygotowali. Bo dom, który chcę budować barzo wielki jest, i sławny.
###### **2Krn 2,10**
 Nadto robotnikom, którzy będą drzewo wycinać, sługom twoim, dam na strawę dwadzieścia tysięcy korcy pszenice, i korcy jęczmienia tyleż, i dwadzieścia tysięcy wiader wina, dwadzieścia też tysięcy miar oliwy.
###### **2Krn 2,11**
 I rzekł Hiram król Tyrski przez list, który posłał do Salomona: Iż Pan lud swój umiłował, przeto uczynił, abyś ty nad nim królował.
###### **2Krn 2,12**
 I przydał, mówiąc: Błogosławiony Pan Bóg Izraelski, który stworzył niebo i ziemię, który dał Dawidowi syna mądrego i umiejętnego, i zmyślnego, i roztropnego, aby zbudował dom Panu i sobie pałac.
###### **2Krn 2,13**
 Posłałem ci tedy męża roztropnego i dobrze umiejętnego, Hirama ojca mego,
###### **2Krn 2,14**
 Syna niewiasty z córek Dan, którego ociec był Tyryjczyk, który umie robić złotem, srebrem, miedzią i żelazem, i marmurem, i drzewem, szarłatem też i hiacynthem i bisiorem, i karmazynem: i który umie rzezać wszelakie rzezanie, i wynaleść mądrze cokolwiek w robocie jest potrzebnego, z rzemieślniki twemi, i z rzemieślniki pana mego Dawida ojca twego.
###### **2Krn 2,15**
 Pszenicę tedy i jęczmień, i oliwę, i wino, któreś obiecał panie mój, pośli sługom twoim.
###### **2Krn 2,16**
 A my nacieszemy drzewa z Libanu ileć go będzie potrzeba, i spuściemy je traftami po morzu do Joppe: a twoja będzie zwieźć je do Jeruzalem.
###### **2Krn 2,17**
 Obliczył tedy Salomon wszystkie męże nowo nawrócone, którzy byli w ziemi Izraelskiej, po policzeniu, które policzył Dawid ociec jego, i nalazło się ich sto pięćdziesiąt tysięcy, i trzy tysiące sześć set.
###### **2Krn 2,18**
 I uczynił z nich siedmdziesiąt tysięcy, którzyby na ramionach brzemiona nosili, a ośmdziesiąt tysięcy, którzyby kamienie w górach łamali: a trzy tysiące i sześć set przy stawów robót ludu.
