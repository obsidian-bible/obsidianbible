# Ap 6 BT5
###### **Ap 6,1**
 I ujrzałem:gdy Baranek otworzył pierwszą z siedmiu pieczęci, usłyszałem pierwszą z czterech Istot żyjących, gdy mówiłajakby głosem gromu:«***Przyjdź!***»
###### **Ap 6,2**
 I ujrzałem:oto biały koń, a siedzący na nim miał łuk. I dano mu wieniec, i wyruszył jako zwycięzca, by [jeszcze] zwyciężać.
###### **Ap 6,3**
 A gdy otworzył pieczęć drugą, usłyszałem drugą Istotę żyjącą, gdy mówiła:«***Przyjdź!***»
###### **Ap 6,4**
 I wyszedł inny koń – barwy ognia, a siedzącemu na nim dano odebrać ziemi pokój, by się wzajemnie ludzie zabijali – i dano mu wielki miecz.
###### **Ap 6,5**
 A gdy otworzył pieczęć trzecią, usłyszałem trzecią Istotę żyjącą, gdy mówiła:«***Przyjdź!***»I ujrzałem:a oto czarny koń, a siedzący na nim miał w ręce wagę.
###### **Ap 6,6**
 I usłyszałem jakby głos pośrodku czterech Istot żyjących, gdy mówił:«***Kwarta pszenicy za denarai trzy kwarty jęczmienia za denara, a nie krzywdź oliwy i wina!***»
###### **Ap 6,7**
 A gdy otworzył pieczęć czwartą, usłyszałem głos czwartej Istoty żyjącej, gdy mówiła:«***Przyjdź!***»
###### **Ap 6,8**
 I ujrzałem: oto koń trupio blady, a imię siedzącego na nim Śmierć, i Otchłań mu towarzyszyła. I dano im władzę nad czwartą częścią ziemi, by zabijali mieczem i głodem, i morem, i przez dzikie zwierzęta.
###### **Ap 6,9**
 A gdy otworzył pieczęć piątą, ujrzałem pod ołtarzem dusze zabitych dla Słowa Bożego i dla świadectwa, jakie mieli.
###### **Ap 6,10**
 I głosem donośnym tak zawołały:«***Jak długo jeszcze, Władco święty i prawdziwy, nie będziesz sądził i wymierzał za krew naszą kary tym, co mieszkają na ziemi?***»
###### **Ap 6,11**
 I dano każdemu z nich białą szatę, i powiedziano im, by jeszcze krótki czas spokojnie zaczekali, aż się dopełni liczba ich współsług i braci, którzy, jak i oni, mają być zabici.
###### **Ap 6,12**
  I ujrzałem: gdy otworzył pieczęć szóstą, nastąpiło wielkie trzęsienie ziemii słońce stało się czarne jak włosienny wór, a cały księżyc stał się jak krew.
###### **Ap 6,13**
 I gwiazdy spadły z nieba na ziemię, podobnie jak figowiec wstrząsany silnym wiatrem zrzuca na ziemię niedojrzałe owoce.
###### **Ap 6,14**
 Niebo zostało usunięte jak księga, którą się zwija, a wszelka góra i wyspa z miejsc swych poruszone.
###### **Ap 6,15**
 A królowie ziemscy, wielmoże i wodzowie, bogacze i możni, i każdy niewolnik oraz wolnyukryli się w jaskiniach i górskich skałach.
###### **Ap 6,16**
 I mówią do gór i do skał:«***Spadnijcie na nasi zakryjcie nas przed obliczem Zasiadającego na troniei przed gniewem Baranka,***
###### **Ap 6,17**
 ***bo nadszedł Wielki Dzień Jego gniewu, a któż zdoła się ostać?***»
# Ap 6 PAU
###### **Ap 6,1**
 Zobaczyłem, że Baranek otworzył jedną z siedmiu pieczęci i usłyszałem jedną z czterech istot żywych mówiącą głosem podobnym do huku gromu: „Przyjdź!”.
###### **Ap 6,2**
 I oto ujrzałem białego konia, a na nim jeźdźca trzymającego łuk. Gdy dano mu wieniec, wyruszył zwycięski, by dalej zwyciężać.
###### **Ap 6,3**
 Gdy Baranek otworzył drugą pieczęć, usłyszałem drugą istotę żywą, która powiedziała: „Przyjdź!”.
###### **Ap 6,4**
 I wyszedł drugi koń - gniady. Jego jeźdźcowi pozwolono odebrać ziemi pokój, żeby ludzie się wzajemnie pozabijali. Dano mu więc wielki miecz.
###### **Ap 6,5**
 Gdy Baranek otworzył trzecią pieczęć, usłyszałem trzecią istotę żywą, która powiedziała: „Przyjdź!”. I oto ujrzałem czarnego konia, a na nim jeźdźca trzymającego w ręku wagę.
###### **Ap 6,6**
 Usłyszałem też jakby głos pośród czterech istot żywych, który mówił: „Kwarta pszenicy za denara i trzy kwarty jęczmienia za denara, ale nie niszcz oliwy ani wina”.
###### **Ap 6,7**
 Gdy otworzył czwartą pieczęć, usłyszałem głos czwartej istoty żywej, która powiedziała: „Przyjdź!”.
###### **Ap 6,8**
 I oto ujrzałem zielonego konia, a na nim jeźdźca. Miał na imię Śmierć i towarzyszyła mu Kraina Umarłych. Dano im władzę nad czwartą częścią ziemi, aby zabijali mieczem, głodem, zarazą i przez dzikie zwierzęta.
###### **Ap 6,9**
 Gdy otworzył piątą pieczęć, ujrzałem pod ołtarzem dusze zabitych z powodu słowa Bożego i danego świadectwa.
###### **Ap 6,10**
 Zawołali oni potężnym głosem: „Jak długo, święty i prawdziwy Władco, będziesz zwlekał z sądem i pomstą naszej krwi wśród mieszkańców ziemi?”.
###### **Ap 6,11**
 A każdemu z nich dano białą szatę i powiedziano im, aby jeszcze przez krótki czas odpoczęli, aż dopełni się liczba ich towarzyszy i braci, którzy tak jak oni mają być zabici.
###### **Ap 6,12**
 Gdy otworzył szóstą pieczęć, zobaczyłem, że nastąpiło wielkie trzęsienie ziemi. Słońce stało się czarne jak wór pokutny, a cały księżyc stał się jak krew.
###### **Ap 6,13**
 Gwiazdy nieba spadały na ziemię, jak spadają niedojrzałe figi z figowca wstrząsanego gwałtownym wichrem.
###### **Ap 6,14**
 Niebo zostało usunięte, zwinięte jak zwój, a każda góra i wyspa zostały przesunięte ze swego miejsca.
###### **Ap 6,15**
 Królowie ziemi, możnowładcy, dowódcy wojska, bogacze i zamożni, wszyscy niewolnicy i wolni ukryli się w jaskiniach i grotach górskich
###### **Ap 6,16**
 i prosili góry i skały: „Spadnijcie na nas i zasłońcie nas przed obliczem Siedzącego na tronie i przed gniewem Baranka,
###### **Ap 6,17**
 bo nadszedł wielki dzień Ich gniewu, i kto zdoła przetrwać?”.
# Ap 6 BP
###### **Ap 6,1**
 I ujrzałem: Gdy Baranek otworzył pierwszą z siedmiu pieczęci, usłyszałem pierwsze z czterech Zwierząt mówiące jakby hukiem gromu: "Przyjdź!"
###### **Ap 6,2**
 I ujrzałem: Oto biały koń, a siedzący na nim miał łuk. Dano mu wieniec, a on, zwycięzca, wyruszył, by dalej zwyciężać.
###### **Ap 6,3**
 A gdy otworzył drugą pieczęć, usłyszałem drugie Zwierzę mówiące: "Przyjdź!"
###### **Ap 6,4**
 I wyszedł inny koń - koloru płomienia, a siedzącemu na nim pozwolono odebrać ziemi pokój, tak iż ludzie wzajemnie się zabijali. I dano mu wielki miecz.
###### **Ap 6,5**
 A gdy otworzył trzecią pieczęć, usłyszałem trzecie Zwierzę mówiące: "Przyjdź!" I ujrzałem: A oto czarny koń, a siedzący na nim miał w ręce wagę.
###### **Ap 6,6**
 I usłyszałem jakby głos w pośrodku czterech Zwierząt, mówiący: "Miara pszenicy za denara i trzy miary jęczmienia za denara, a nie niszcz oliwy i wina!"
###### **Ap 6,7**
 A gdy otworzył czwartą pieczęć, usłyszałem głos czwartego Zwierzęcia mówiącego: "Przyjdź!"
###### **Ap 6,8**
 I ujrzałem: Oto koń trupio blady, a imię siedzącego na nim Śmierć, i Otchłań mu towarzyszyła. I dano im władzę nad czwartą częścią ziemi, aby miecz i głód, i mór, i dzikie zwierzęta zabijały ludzi.
###### **Ap 6,9**
 A gdy otworzył piątą pieczęć, ujrzałem pod ołtarzem dusze zabitych dla Słowa Bożego i dla świadectwa, jakie mieli.
###### **Ap 6,10**
 I głosem donośnym tak zawołały: "Władco święty i prawdziwy! Jak długo jeszcze będziesz zwlekał z wyrokiem i karą za naszą krew na tych, co mieszkają na ziemi?"
###### **Ap 6,11**
 I dano każdemu z nich białą szatę, i powiedziano im, by jeszcze przez krótki czas odpoczęli, aż dopełni się liczba ich współsług oraz braci, którzy, jak i oni, mają być zabici.
###### **Ap 6,12**
 Potem ujrzałem: Gdy otworzył szóstą pieczęć, nastąpiło wielkie trzęsienie ziemi i słońce stało się czarne jak włosiany wór, a cały księżyc stał się jak krew.
###### **Ap 6,13**
 I gwiazdy spadły z nieba na ziemię, tak jak drzewo figowe wstrząsane silnym wiatrem zrzuca na ziemię swe niedojrzałe owoce.
###### **Ap 6,14**
 Niebo zostało usunięte jak księga, która się zwija, a każda góra i każda wyspa zostały ruszone ze swoich miejsc.
###### **Ap 6,15**
 A królowie ziemscy, wielmoże i wodzowie, bogacze i możni, i każdy niewolnik, i wolny, ukryli się w jaskiniach i w skalistych górach.
###### **Ap 6,16**
 I mówią do gór i do skał: "Padnijcie na nas i ukryjcie nas przed obliczem Zasiadającego na tronie i przed gniewem Baranka,
###### **Ap 6,17**
 bo nadszedł Wielki Dzień Jego gniewu, a któż zdoła się ostać?"
# Ap 6 BR
###### **Ap 6,1**
 Potem zobaczyłem, jak Bara- nek otwierał pierwszą spośród siedmiu pieczęci, i usłyszałem, jak pierwsze z czterech Zwierząt odezwało się jakby głosem gromu: Przyjdź!
###### **Ap 6,2**
 I ujrzałem białego konia, a na nim jeźdźca z łukiem. Wręczono jeźdźcowi wieniec, a on wyruszył jako zwycięzca, aby odnosić dalsze triumfy.
###### **Ap 6,3**
 Kiedy zaś [Baranek] otworzył drugą pieczęć, usłyszałem, jak drugie Zwierzę zawołało: Przyjdź!
###### **Ap 6,4**
 Wtedy ukazał się inny koń: Był barwy ognistej, a znajdujący się na nim jeździec otrzymał władzę pozbawienia ziemi pokoju i doprowadzenia do tego, żeby ludzie poczęli zabijać jedni drugich. I dano mu wielki miecz.
###### **Ap 6,5**
 Gdy [Baranek] otworzył trzecią pieczęć, usłyszałem, jak trzecie Zwierzę zawołało: Przyjdź! Wtedy zobaczyłem czarnego konia, a jeździec, który był na nim, miał w ręce wagę.
###### **Ap 6,6**
 Z pośrodka zaś czworga Zwierząt jakby głos donośny wołał: Miara pszenicy za denara, trzy miary jęczmienia za denara. A nie wyrządzaj żadnej krzywdy oliwie i winu!
###### **Ap 6,7**
 A gdy otworzył czwartą pieczęć, usłyszałem, jak czwarte Zwierzę wołało: Przyjdź!
###### **Ap 6,8**
 Zobaczyłem też konia maści trupioszarej, a jeździec siedzący na nim nazywał się, Śmierć. A jeźdźcowi towarzyszyła cała kraina zmarłych. Dano im władzę nad czwartą częścią ziemi oraz możność zabijania mieczem, głodem, zarazą morową i przez dzikie zwierzęta, które są na ziemi.
###### **Ap 6,9**
 Gdy otworzył pieczęć piątą, zobaczyłem pod ołtarzem dusze umęczonych dla słowa Bożego i dla świadectwa, jakie złożyli.
###### **Ap 6,10**
 Od dusz owych zaś dochodziło wołanie: Jak długo jeszcze, Wszechmocny, Święty i Prawdziwy, będziesz zwłóczył z osądzeniem tych, którzy mieszkają na ziemi, i z wymierzeniem im słusznej kary za krew naszą?
###### **Ap 6,11**
 I dano im wszystkim białe szaty, i kazano jeszcze przez jakiś czas odpoczywać, dokładnie tak długo, aż dopełni się liczba ich współsług i braci, którzy, podobnie jak oni, mieli być również zabici.
###### **Ap 6,12**
 A kiedy patrzyłem, gdy otwierał szóstą pieczęć, nastąpiło wielkie trzęsienie ziemi; słońce stało się czarne niczym wór z włosia, a księżyc - cały czerwony jak krew.
###### **Ap 6,13**
 Gwiazdy spadały na ziemię, podobnie jak niedojrzałe jeszcze owoce spadają z drzewa figowego potrząsanego silnym wiatrem.
###### **Ap 6,14**
 Niebo zawarło się jak księga, którą zamknięto, a wszystkie góry i wyspy zostały poruszone ze swego miejsca.
###### **Ap 6,15**
 A królowie ziemscy i wielcy tego świata oraz jego przywódcy, bogacze i możni, i wszyscy niewolni i wolni poukrywali się w jaskiniach i rozpadlinach górskich,
###### **Ap 6,16**
 wołając do gór i do skal: Upadnijcie na nas i zakryjcie nas przed obliczem Siedzącego na tronie, i ratujcie nas od gniewu Baranka!
###### **Ap 6,17**
 Nadszedł bowiem Wielki Dzień Jego gniewu. Któż tedy może się ostać?
# Ap 6 WUJ
###### **Ap 6,1**
 I widziałem, iż otworzył baranek jednę z siedmi pieczęci: i słyszałem jedno ze czterech zwierząt mówiące, jakoby głos gromu: Chodź, a patrzaj.
###### **Ap 6,2**
 I widziałem, a oto koń biały, a który na nim siedział, miał łuk: i dano mu koronę, i wyszedł, zwyciężając aby zwyciężył.
###### **Ap 6,3**
 A gdy otworzył wtóra pieczęć, słyszałem wtóre zwierzę mówiące: Chodź a patrzaj.
###### **Ap 6,4**
 I wyszedł drugi koń rydzy: a który na nim siedział, dano mu jest, aby odjął pokój z ziemie, a iżby jedni drugie zabijali, i dano mu miecz wielki.
###### **Ap 6,5**
 A gdy otworzył trzecią pieczęć, słyszałem trzecie zwierzę, mówiące: Chodź, a patrzaj. A oto koń wrony: a który na nim siedział, miał szalę w ręce swojej.
###### **Ap 6,6**
 I słyszałem jakoby głos w pośrodku czworga zwierząt mówiących: Miarka pszenice za grosz, a trzy miarki jęczmienia za grosz, a nie szkodź oliwy i wina.
###### **Ap 6,7**
 A gdy otworzył czwartą pieczęć, słyszałem głos czwartego zwierzęcia mówiącego: Chodź a patrzaj.
###### **Ap 6,8**
 A oto koń blady: a który siedział na nim, imię jemu Śmierć, a piekło szło za nim, i dana mu jest moc nad czterzmi częściami ziemi, zabijać mieczem, głodem, i śmiercią, i przez bestye ziemskie.
###### **Ap 6,9**
 A gdy otworzył piątą pieczęć, widziałem pod ołtarzem dusze pobitych dla słowa Bożego, i dla świadectwa, które miały.
###### **Ap 6,10**
 I wołały głosem wielkim, mówiąc: Dokądże Panie (święty, i prawdziwy) nie sądzisz i nie mścisz się krwie naszej nad tymi, co mieszkają na ziemi?
###### **Ap 6,11**
 I dano im po szacie białej: i powiedziano im, aby jeszcze odpoczęły mały czas, ażby się wypełnili spółsłudzy ich, i bracia ich, którzy mają być pobici jako i oni.
###### **Ap 6,12**
 I widziałem, gdy otworzył szóstą pieczęć: a oto się stało wielkie trzęsienie ziemie, i słońce się stało czarne jako wór włosiany: i księżyc wszystek stał się jako krew:
###### **Ap 6,13**
 A gwiazdy z nieba upadły na ziemię, jako drzewo figowe zrzuca niedojrzałe figi swoje, gdy od wiatru wielkiego bywa zatrzęsione:
###### **Ap 6,14**
 A niebo odstąpiło jako księgi zwinione: a wszelka góra, i wyspy z swoich miejsc poruszone są:
###### **Ap 6,15**
 A królowie ziemie i książęta, i tysiącznicy, i bogaci, i mocarze, i każdy niewolnik, i wolny pokryli się w jamy i w skały gór.
###### **Ap 6,16**
 I rzekli góram i skałam: Upadnicie na nas, i nakrycie nas od oblicza siedzącego na stolicy, i od gniewu barankowego:
###### **Ap 6,17**
 Bo przyszedł dzień wielki gniewu ich: a któż się ostać będzie mógł?
# Ap 6 STERN
###### **Ap 6,1**
 Potem patrzyłem, jak Baranek łamie pierwszą z siedmiu pieczęci, i usłyszałem, jak jedna z czterech żywych istot mówi grzmiącym głosem: "Idź!".
###### **Ap 6,2**
 Spojrzałem, a przede mną był biały koń. Jeździec miał łuk, i dano mu koronę, i odjechał jako zdobywca, aby zdobywać.
###### **Ap 6,3**
 Kiedy złamał drugą pieczęć, usłyszałem, jak druga żywa istota mówi: "Idź!".
###### **Ap 6,4**
 Wyszedł inny koń, czerwony, a jeźdźcowi dano moc, aby zabrał pokój z ziemi i sprawił, by ludzie zabijali się nawzajem. Dano mu wielki miecz.
###### **Ap 6,5**
 Kiedy złamał trzecią pieczęć, usłyszałem, jak trzecia żywa istota mówi: "Idź!". I spojrzałem, i był przede mną czarny koń, a jeździec trzymał w dłoni wagę.
###### **Ap 6,6**
 I usłyszałem coś, co brzmiało jak głos wychodzący spomiędzy czterech żywych istot, jak mówi: "Kwarta pszenicy za dzienny zarobek! Trzy kwarty jęczmienia za tyle samo! Ale nie wtrącaj się do oliwy ani wina!"
###### **Ap 6,7**
 Kiedy złamał czwartą pieczęć, usłyszałem głos czwartej żywej istoty, jak mówi: "Idź!".
###### **Ap 6,8**
 Spojrzałem, a przede mną był blady, trupi koń. Jeździec nosił imię Śmierć, a za nim szedł Sz'ol. Dano im władzę zabicia jednej czwartej świata wojną, głodem, zarazami i przez dzikie zwierzęta ziemi.
###### **Ap 6,9**
 Kiedy Baranek złamał piątą pieczęć, ujrzałem pod ołtarzem dusze tych, których zgładzono za głoszenie Słowa Bożego, czyli za składanie świadectwa.
###### **Ap 6,10**
 Wołali donośnym głosem: "Najwyższy Władco, Ha-Kadosz, Prawdziwy, jak długo jeszcze nie będziesz sądził mieszkańców ziemi i mścił naszej krwi?".
###### **Ap 6,11**
 Każdemu z nich dano białą szatę i kazano poczekać jeszcze trochę, aż dopełni się liczba ich współsług spośród ich braci, którzy mieli być zabici tak samo jak oni.
###### **Ap 6,12**
 I patrzyłem, jak łamał szóstą pieczęć, i było wielkie trzęsienie ziemi, słońce stało się czarne jak wór pokutny, a księżyc w pełni stał się czerwony jak krew.
###### **Ap 6,13**
 Gwiazdy spadły z nieba, tak jak drzewo figowe zrzuca figi, gdy potrząśnie nim silny wiatr.
###### **Ap 6,14**
 Niebo uciekło jak zwijany zwój, a każda góra i wyspa ruszyły się ze swego miejsca.
###### **Ap 6,15**
 Wtedy królowie ziemi, władcy, generałowie, bogaci i potężni - tak jest, każdy, czy niewolnik, czy wolny - skryli się w jaskiniach i wśród skał w górach
###### **Ap 6,16**
 i mówili do gór i skał: "Spadnijcie na nas i ukryjcie nas przed obliczem Zasiadającego na tronie i przed furią Baranka!
###### **Ap 6,17**
 Bo Wielki Dzień Ich furii nadszedł i kto się ostanie?".
# Ap 6 TRO
###### **Ap 6,1**
 **και** *kai* I [[G2532]] [[CONJ]] **ειδον** *eidon* zobaczyłem [[G1492]] WTV-2AAI-1S **οτε** *hote* gdy [[G3753]] [[ADV]] **ηνοιξεν** *ēnoiksen* otworzył [[G455]] [[V-AAI-3S]] **το** *to* [[G3588]] WTT-NSN **αρνιον** *arnion* baranek [[G721]] WTN-NSN **μιαν** *mian* jedną [[G1520]] WTA-ASF **εκ** *ek* z [[G1537]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPF **σφραγιδων** *sfragidōn* pieczęci [[G4973]] WTN-GPF **και** *kai* i [[G2532]] [[CONJ]] **ηκουσα** *ēkousa* usłyszałem [[G191]] WTV-AAI-1S **ενος** *henos* jedną [[G1520]] [[A-GSN]] **εκ** *ek* z [[G1537]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **τεσσαρων** *tessarōn* czterech [[G5064]] WTA-GPN **ζωων** *zōōn* istot żywych [[G2226]] WTN-GPN **λεγοντος** *legontos* mówiącą [[G3004]] WTV-PAP-GSN **ως** *hōs* jak [[G5613]] [[ADV]] **φωνης** *fōnēs* głosem [[G5456]] [[N-GSF]] **βροντης** *brontēs* grzmotu [[G1027]] [[N-GSF]] **ερχου** *erchou* chodź [[G2064]] WTV-PNI-2S **και** *kai* i [[G2532]] [[CONJ]] **βλεπε** *blepe* patrz [[G991]] WTV-PAM-2S
###### **Ap 6,2**
 **και** *kai* I [[G2532]] [[CONJ]] **ειδον** *eidon* zobaczyłem [[G1492]] WTV-2AAI-1S **και** *kai* i [[G2532]] [[CONJ]] **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **ιππος** *hippos* koń [[G2462]] [[N-NSM]] **λευκος** *leukos* biały [[G3022]] [[A-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **καθημενος** *kathēmenos* siedzący [[G2521]] WTV-PNP-NSM **επ** *ep* na [[G1909]] [[PREP]] **αυτω** *autō* nim [[G846]] WTP-DSM **εχων** *echōn* mający [[G2192]] [[V-PAP-NSM]] **τοξον** *tokson* łuk [[G5115]] WTN-ASN **και** *kai* i [[G2532]] [[CONJ]] **εδοθη** *edothē* został dany [[G1325]] [[V-API-3S]] **αυτω** *autō* mu [[G846]] WTP-DSM **στεφανος** *stefanos* wieniec – korona [[G4735]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **εξηλθεν** *eksēlthen* wyszedł [[G1831]] WTV-2AAI-3S **νικων** *nikōn* zwyciężając [[G3528]] [[V-PAP-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ινα** *hina* aby [[G2443]] [[CONJ]] **νικηση** *nikēsē* zwyciężyłby [[G3528]] WTV-AAS-3S
###### **Ap 6,3**
 **και** *kai* I [[G2532]] [[CONJ]] **οτε** *hote* gdy [[G3753]] [[ADV]] **ηνοιξεν** *ēnoiksen* otworzył [[G455]] [[V-AAI-3S]] **την** *tēn* [[G3588]] WTT-ASF **δευτεραν** *deuteran* drugą [[G1208]] WTA-ASF **σφραγιδα** *sfragida* pieczęć [[G4973]] WTN-ASF **ηκουσα** *ēkousa* usłyszałem [[G191]] WTV-AAI-1S **του** *tou* [[G3588]] WTT-GSN **δευτερου** *deuterou* drugą [[G1208]] [[A-GSN]] **ζωου** *zōou* istotę żywą [[G2226]] [[N-GSN]] **λεγοντος** *legontos* mówiącą [[G3004]] WTV-PAP-GSN **ερχου** *erchou* chodź [[G2064]] WTV-PNI-2S **και** *kai* i [[G2532]] [[CONJ]] **βλεπε** *blepe* patrz [[G991]] WTV-PAM-2S
###### **Ap 6,4**
 **και** *kai* I [[G2532]] [[CONJ]] **εξηλθεν** *eksēlthen* wyszedł [[G1831]] WTV-2AAI-3S **αλλος** *allos* inny [[G243]] [[A-NSM]] **ιππος** *hippos* koń [[G2462]] [[N-NSM]] **πυρρος** *pyrros* ognistej czerwieni [[G4450]] [[A-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **τω** *tō* [[G3588]] WTT-DSM **καθημενω** *kathēmenō* siedzącemu [[G2521]] WTV-PNP-DSM **επ** *ep* na [[G1909]] [[PREP]] **αυτω** *autō* nim [[G846]] WTP-DSM **εδοθη** *edothē* zostało dane [[G1325]] [[V-API-3S]] **αυτω** *autō* mu [[G846]] WTP-DSM **λαβειν** *labein* wziąć [[G2983]] [[V-2AAN]] **την** *tēn* [[G3588]] WTT-ASF **ειρηνην** *eirēnēn* pokój [[G1515]] WTN-ASF **απο** *apo* z [[G575]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **ινα** *hina* aby [[G2443]] [[CONJ]] **αλληλους** *allēlous* jedni drugich [[G240]] WTC-APM **σφαξωσιν** *sfaksōsin* zabijaliby brutalnie – mordowaliby [[G4969]] WTV-AAS-3P **και** *kai* i [[G2532]] [[CONJ]] **εδοθη** *edothē* został dany [[G1325]] [[V-API-3S]] **αυτω** *autō* mu [[G846]] WTP-DSM **μαχαιρα** *machaira* miecz [[G3162]] [[N-NSF]] **μεγαλη** *megalē* wielki [[G3173]] WTA-NSF
###### **Ap 6,5**
 **και** *kai* I [[G2532]] [[CONJ]] **οτε** *hote* gdy [[G3753]] [[ADV]] **ηνοιξεν** *ēnoiksen* otworzył [[G455]] [[V-AAI-3S]] **την** *tēn* [[G3588]] WTT-ASF **τριτην** *tritēn* trzecią [[G5154]] WTA-ASF **σφραγιδα** *sfragida* pieczęć [[G4973]] WTN-ASF **ηκουσα** *ēkousa* usłyszałem [[G191]] WTV-AAI-1S **του** *tou* [[G3588]] WTT-GSN **τριτου** *tritou* trzecią [[G5154]] [[A-GSN]] **ζωου** *zōou* istotę żywą [[G2226]] [[N-GSN]] **λεγοντος** *legontos* mówiącą [[G3004]] WTV-PAP-GSN **ερχου** *erchou* chodź [[G2064]] WTV-PNI-2S **και** *kai* i [[G2532]] [[CONJ]] **βλεπε** *blepe* patrz [[G991]] WTV-PAM-2S **και** *kai* i [[G2532]] [[CONJ]] **ειδον** *eidon* zobaczyłem [[G1492]] WTV-2AAI-1S **και** *kai* i [[G2532]] [[CONJ]] **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **ιππος** *hippos* koń [[G2462]] [[N-NSM]] **μελας** *melas* czarny [[G3189]] [[A-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **καθημενος** *kathēmenos* siedzący [[G2521]] WTV-PNP-NSM **επ** *ep* na [[G1909]] [[PREP]] **αυτω** *autō* nim [[G846]] WTP-DSM **εχων** *echōn* mający [[G2192]] [[V-PAP-NSM]] **ζυγον** *zygon* wagę – jarzmo [[G2218]] [[N-ASM]] **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **χειρι** *cheiri* ręce [[G5495]] [[N-DSF]] **αυτου** *autou* jego [[G846]] [[P-GSM]]
###### **Ap 6,6**
 **και** *kai* I [[G2532]] [[CONJ]] **ηκουσα** *ēkousa* usłyszałem [[G191]] WTV-AAI-1S **φωνην** *fōnēn* głos [[G5456]] WTN-ASF **εν** *en* na [[G1722]] [[PREP]] **μεσω** *mesō* środku [[G3319]] WTA-DSN **των** *tōn* [[G3588]] WTT-GPN **τεσσαρων** *tessarōn* czterech [[G5064]] WTA-GPN **ζωων** *zōōn* istot żywych [[G2226]] WTN-GPN **λεγουσαν** *legousan* mówiący [[G3004]] WTV-PAP-ASF **χοινιξ** *choiniks* kwarta – choinks [[G5518]] [[N-NSM]] **σιτου** *sitou* pszenicy – zboża [[G4621]] [[N-GSM]] **δηναριου** *dēnariou* denara [[G1220]] [[N-GSN]] **και** *kai* i [[G2532]] [[CONJ]] **τρεις** *treis* trzy [[G5140]] WTA-NPM **χοινικες** *choinikes* kwarty – choniksy [[G5518]] WTN-NPM **κριθης** *krithēs* jęczmienia [[G2915]] [[N-GSF]] **δηναριου** *dēnariou* denara [[G1220]] [[N-GSN]] **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-ASN **ελαιον** *elaion* oliwie [[G1637]] WTN-ASN **και** *kai* i [[G2532]] [[CONJ]] **τον** *ton* [[G3588]] [[T-ASM]] **οινον** *oinon* winu [[G3631]] [[N-ASM]] **μη** *mē* nie [[G3361]] [[PRT-N]] **αδικησης** *adikēsēs* czyniłbyś niesprawiedliwości – krzywdziłbyś [[G91]] WTV-AAS-2S
###### **Ap 6,7**
 **και** *kai* I [[G2532]] [[CONJ]] **οτε** *hote* gdy [[G3753]] [[ADV]] **ηνοιξεν** *ēnoiksen* otworzył [[G455]] [[V-AAI-3S]] **την** *tēn* [[G3588]] WTT-ASF **σφραγιδα** *sfragida* pieczęć [[G4973]] WTN-ASF **την** *tēn* [[G3588]] WTT-ASF **τεταρτην** *tetartēn* czwartą [[G5067]] WTA-ASF **ηκουσα** *ēkousa* usłyszałem [[G191]] WTV-AAI-1S **φωνην** *fōnēn* głos [[G5456]] WTN-ASF **του** *tou* [[G3588]] WTT-GSN **τεταρτου** *tetartou* czwartej [[G5067]] [[A-GSN]] **ζωου** *zōou* istoty żywej [[G2226]] [[N-GSN]] **λεγουσαν** *legousan* mówiącej [[G3004]] WTV-PAP-ASF **ερχου** *erchou* chodź [[G2064]] WTV-PNI-2S **και** *kai* i [[G2532]] [[CONJ]] **βλεπε** *blepe* patrz [[G991]] WTV-PAM-2S
###### **Ap 6,8**
 **και** *kai* I [[G2532]] [[CONJ]] **ειδον** *eidon* zobaczyłem [[G1492]] WTV-2AAI-1S **και** *kai* i [[G2532]] [[CONJ]] **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **ιππος** *hippos* koń [[G2462]] [[N-NSM]] **χλωρος** *chlōros* zielony [[G5515]] [[A-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **καθημενος** *kathēmenos* siedzący [[G2521]] WTV-PNP-NSM **επανω** *epanō* na [[G1883]] [[ADV]] **αυτου** *autou* nim [[G846]] [[P-GSM]] **ονομα** *onoma* imię [[G3686]] WTN-NSN **αυτω** *autō* jego [[G846]] WTP-DSM **ο** *ho* [[G3588]] [[T-NSM]] **θανατος** *thanatos* śmierć [[G2288]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **αδης** *hadēs* piekło – Hades [[G86]] [[N-NSM]] **ακολουθει** *akolouthei* podąża – towarzyszy [[G190]] WTV-PAI-3S **μετ** *met* z [[G3326]] [[PREP]] **αυτου** *autou* nim [[G846]] [[P-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **εδοθη** *edothē* została dana [[G1325]] [[V-API-3S]] **αυτοις** *autois* im [[G846]] WTP-DPM **εξουσια** *eksousia* władza [[G1849]] [[N-NSF]] **αποκτειναι** *apokteinai* (by) zabić [[G615]] [[V-AAN]] **επι** *epi* nad [[G1909]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **τεταρτον** *tetarton* czwartą [[G5067]] WTA-ASN **της** *tēs* (częścią) [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]] **εν** *en* w [[G1722]] [[PREP]] **ρομφαια** *romfaia* mieczu [[G4501]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **λιμω** *limō* głodzie [[G3042]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **θανατω** *thanatō* śmierci [[G2288]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **υπο** *hypo* przez [[G5259]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **θηριων** *thēriōn* zwierzęta [[G2342]] WTN-GPN **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]]
###### **Ap 6,9**
 **και** *kai* I [[G2532]] [[CONJ]] **οτε** *hote* gdy [[G3753]] [[ADV]] **ηνοιξεν** *ēnoiksen* otworzył [[G455]] [[V-AAI-3S]] **την** *tēn* [[G3588]] WTT-ASF **πεμπτην** *pemptēn* piątą [[G3991]] WTA-ASF **σφραγιδα** *sfragida* pieczęć [[G4973]] WTN-ASF **ειδον** *eidon* zobaczyłem [[G1492]] WTV-2AAI-1S **υποκατω** *hypokatō* pod [[G5270]] [[ADV]] **του** *tou* [[G3588]] WTT-GSN **θυσιαστηριου** *thysiastēriou* ołtarzem [[G2379]] [[N-GSN]] **τας** *tas* [[G3588]] WTT-APF **ψυχας** *psychas* dusze [[G5590]] WTN-APF **των** *tōn* (tych) [[G3588]] WTT-GPM **εσφαγμενων** *esfagmenōn* którzy są brutalnie zabite – którzy są zamordowane [[G4969]] WTV-RPP-GPM **δια** *dia* z powodu [[G1223]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **λογον** *logon* Słowa [[G3056]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **δια** *dia* z powodu [[G1223]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **μαρτυριαν** *martyrian* świadectwa [[G3141]] WTN-ASF **ην** *hēn* które [[G3739]] WTR-ASF **ειχον** *eichon* mieli [[G2192]] WTV-IAI-3P
###### **Ap 6,10**
 **και** *kai* i [[G2532]] [[CONJ]] **εκραζον** *ekrazon* krzyczeli – wołali [[G2896]] WTV-IAI-3P **φωνη** *fōnē* głosem [[G5456]] [[N-DSF]] **μεγαλη** *megalē* wielkim [[G3173]] WTA-DSF **λεγοντες** *legontes* mówiąc [[G3004]] WTV-PAP-NPM **εως** *heōs* aż do [[G2193]] [[CONJ]] **ποτε** *pote* kiedy [[G4219]] WTPRT-I **ο** *ho* [[G3588]] [[T-NSM]] **δεσποτης** *despotēs* Władco [[G1203]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **αγιος** *hagios* Święty [[G40]] [[A-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **αληθινος** *alēthinos* Prawdziwy [[G228]] [[A-NSM]] **ου** *ou* nie [[G3756]] [[PRT-N]] **κρινεις** *krineis* sądzisz [[G2919]] WTV-PAI-2S **και** *kai* i [[G2532]] [[CONJ]] **εκδικεις** *ekdikeis* wymierzasz sprawiedliwość [[G1556]] WTV-PAI-2S **το** *to* [[G3588]] WTT-ASN **αιμα** *haima* krwi [[G129]] WTN-ASN **ημων** *hēmōn* naszej [[G2257]] WTP-1GP **απο** *apo* od [[G575]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **κατοικουντων** *katoikountōn* zamieszkujących [[G2730]] WTV-PAP-GPM **επι** *epi* na [[G1909]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]]
###### **Ap 6,11**
 **και** *kai* I [[G2532]] [[CONJ]] **εδοθησαν** *edothēsan* zostały dane [[G1325]] WTV-API-3P **εκαστοις** *ekastois* każdemu [[G1538]] WTA-DPM **στολαι** *stolai* długie szaty [[G4749]] [[N-NPF]] **λευκαι** *leukai* białe [[G3022]] [[A-NPF]] **και** *kai* i [[G2532]] [[CONJ]] **ερρεθη** *errethē* zostało powiedziane [[G4483]] [[V-API-3S]] **αυτοις** *autois* im [[G846]] WTP-DPM **ινα** *hina* aby [[G2443]] [[CONJ]] **αναπαυσωνται** *anapausōntai* odpoczęliby [[G373]] WTV-AMS-3P **ετι** *eti* jeszcze [[G2089]] [[ADV]] **χρονον** *chronon* czas [[G5550]] [[N-ASM]] **μικρον** *mikron* krótki – mały [[G3398]] WTA-ASM **εως** *heōs* aż do [[G2193]] [[CONJ]] **ου** *hou* kiedy [[G3739]] WTR-GSM **πληρωσονται** *plērōsontai* wypełni się [[G4137]] WTV-FDI-3P **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **συνδουλοι** *syndouloi* współniewolnicy – współsłudzy [[G4889]] WTN-NPM **αυτων** *autōn* ich [[G846]] WTP-GPM **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **αδελφοι** *adelfoi* bracia [[G80]] WTN-NPM **αυτων** *autōn* ich [[G846]] WTP-GPM **οι** *hoi* [[G3588]] WTT-NPM **μελλοντες** *mellontes* zamierzający [[G3195]] WTV-PAP-NPM **αποκτεινεσθαι** *apokteinesthai* być zabitymi [[G615]] WTV-PPN **ως** *hōs* jak [[G5613]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **αυτοι** *autoi* oni [[G846]] WTP-NPM
###### **Ap 6,12**
 **και** *kai* I [[G2532]] [[CONJ]] **ειδον** *eidon* zobaczyłem [[G1492]] WTV-2AAI-1S **οτε** *hote* gdy [[G3753]] [[ADV]] **ηνοιξεν** *ēnoiksen* otworzył [[G455]] [[V-AAI-3S]] **την** *tēn* [[G3588]] WTT-ASF **σφραγιδα** *sfragida* pieczęć [[G4973]] WTN-ASF **την** *tēn* [[G3588]] WTT-ASF **εκτην** *hektēn* szóstą [[G1623]] WTA-ASF **και** *kai* i [[G2532]] [[CONJ]] **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **σεισμος** *seismos* trzęsienie ziemi [[G4578]] [[N-NSM]] **μεγας** *megas* wielkie [[G3173]] [[A-NSM]] **εγενετο** *egeneto* stało się [[G1096]] WTV-2ADI-3S **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **ηλιος** *hēlios* słońce [[G2246]] [[N-NSM]] **εγενετο** *egeneto* stało się [[G1096]] WTV-2ADI-3S **μελας** *melas* czarne [[G3189]] [[A-NSM]] **ως** *hōs* jak [[G5613]] [[ADV]] **σακκος** *sakkos* wór [[G4526]] [[N-NSM]] **τριχινος** *trichinos* z włosów [[G5155]] [[A-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **σεληνη** *selēnē* księżyc [[G4582]] [[N-NSF]] **εγενετο** *egeneto* stał się [[G1096]] WTV-2ADI-3S **ως** *hōs* jak [[G5613]] [[ADV]] **αιμα** *haima* krew [[G129]] WTN-ASN
###### **Ap 6,13**
 **και** *kai* I [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **αστερες** *asteres* gwiazdy [[G792]] WTN-NPM **του** *tou* [[G3588]] WTT-GSM **ουρανου** *ouranou* nieba [[G3772]] [[N-GSM]] **επεσαν** *epesan* upadły [[G4098]] WTV-2AAI-3P **εις** *eis* na [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **γην** *gēn* ziemię [[G1093]] WTN-ASF **ως** *hōs* jak [[G5613]] [[ADV]] **συκη** *sykē* figowiec [[G4808]] [[N-NSF]] **βαλλει** *ballei* rzuca [[G906]] WTV-PAI-3S **τους** *tous* [[G3588]] WTT-APM **ολυνθους** *olynthous* niedojrzałe figi [[G3653]] [[N-APM]] **αυτης** *autēs* jego [[G846]] [[P-GSF]] **υπο** *hypo* przez [[G5259]] [[PREP]] **μεγαλου** *megalou* wielki [[G3173]] WTA-GSM **ανεμου** *anemou* wiatr [[G417]] [[N-GSM]] **σειομενη** *seiomenē* który jest poruszany – który jest wstrząsany [[G4579]] WTV-PPP-NSF
###### **Ap 6,14**
 **και** *kai* i [[G2532]] [[CONJ]] **ουρανος** *ouranos* niebo [[G3772]] [[N-NSM]] **απεχωρισθη** *apechōristhē* zostało rozdzielone – zostało oddzielone [[G673]] [[V-API-3S]] **ως** *hōs* jak [[G5613]] [[ADV]] **βιβλιον** *biblion* zwój [[G975]] WTN-NSN **ειλισσομενον** *eilissomenon* który jest zwijany – który jest rolowany [[G1507]] WTV-PPP-NSN **και** *kai* i [[G2532]] [[CONJ]] **παν** *pan* wszelka [[G3956]] WTA-NSN **ορος** *oros* góra [[G3735]] WTN-NSN **και** *kai* i [[G2532]] [[CONJ]] **νησος** *nēsos* wyspa [[G3520]] [[N-NSF]] **εκ** *ek* z [[G1537]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **τοπων** *topōn* miejsc [[G5117]] WTN-GPM **αυτων** *autōn* ich [[G846]] WTP-GPM **εκινηθησαν** *ekinēthēsan* zostały poruszone [[G2795]] WTV-API-3P
###### **Ap 6,15**
 **και** *kai* I [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **βασιλεις** *basileis* królowie [[G935]] WTN-NPM **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **μεγιστανες** *megistanes* dostojnicy [[G3175]] WTN-NPM **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **πλουσιοι** *plousioi* bogaci [[G4145]] WTA-NPM **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **χιλιαρχοι** *chiliarchoi* trybuni – dowódcy [[G5506]] WTN-NPM **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **δυνατοι** *dynatoi* potężni – możni [[G1415]] WTA-NPM **και** *kai* i [[G2532]] [[CONJ]] **πας** *pas* każdy [[G3956]] [[A-NSM]] **δουλος** *doulos* niewolnik – sługa [[G1401]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **πας** *pas* każdy [[G3956]] [[A-NSM]] **ελευθερος** *eleutheros* wolny [[G1658]] [[A-NSM]] **εκρυψαν** *ekrypsan* ukryli [[G2928]] WTV-AAI-3P **εαυτους** *heautous* siebie samych [[G1438]] WTF-3APM **εις** *eis* w [[G1519]] [[PREP]] **τα** *ta* [[G3588]] WTT-APN **σπηλαια** *spēlaia* jaskiniach [[G4693]] WTN-APN **και** *kai* i [[G2532]] [[CONJ]] **εις** *eis* w [[G1519]] [[PREP]] **τας** *tas* [[G3588]] WTN-APF **πετρας** *petras* skałach [[G4073]] WTN-APF **των** *tōn* [[G3588]] WTT-GPN **ορεων** *oreōn* gór [[G3735]] WTN-GPN
###### **Ap 6,16**
 **και** *kai* i [[G2532]] [[CONJ]] **λεγουσιν** *legousin* mówią [[G3004]] WTV-PAI-3P **τοις** *tois* [[G3588]] WTT-DPN **ορεσιν** *oresin* górom [[G3735]] WTN-DPN **και** *kai* i [[G2532]] [[CONJ]] **ταις** *tais* [[G3588]] WTT-DPF **πετραις** *petrais* skałom [[G4073]] WTN-DPF **πεσετε** *pesete* padnijcie [[G4098]] WTV-2AAM-2P **εφ** *ef* na [[G1909]] [[PREP]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **και** *kai* i [[G2532]] [[CONJ]] **κρυψατε** *krypsate* ukryjcie [[G2928]] WTV-AAM-2P **ημας** *hēmas* nas [[G2248]] WTP-1AP **απο** *apo* od [[G575]] [[PREP]] **προσωπου** *prosōpou* oblicza – twarzy [[G4383]] [[N-GSN]] **του** *tou* [[G3588]] WTT-GSM **καθημενου** *kathēmenou* siedzącego [[G2521]] WTV-PNP-GSM **επι** *epi* na [[G1909]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronie [[G2362]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **απο** *apo* od [[G575]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **οργης** *orgēs* gniewu [[G3709]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSN **αρνιου** *arniou* baranka [[G721]] [[N-GSN]]
###### **Ap 6,17**
 **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **ηλθεν** *ēlthen* przyszedł [[G2064]] WTV-2AAI-3S **η** *hē* [[G3588]] [[T-NSF]] **ημερα** *hēmera* dzień [[G2250]] [[N-NSF]] **η** *hē* [[G3588]] [[T-NSF]] **μεγαλη** *megalē* wielki [[G3173]] WTA-NSF **της** *tēs* [[G3588]] [[T-GSF]] **οργης** *orgēs* gniewu [[G3709]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **τις** *tis* kto [[G5101]] WTI-NSM **δυναται** *dynatai* może [[G1410]] WTV-PNI-3S **σταθηναι** *stathēnai* zostać ostałym [[G2476]] WTV-APN
