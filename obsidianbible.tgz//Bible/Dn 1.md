# Dn 1 BT5
###### **Dn 1,1**
 W trzecim roku panowania króla judzkiego, Jojakima, przybył król babiloński, Nabuchodonozor, pod Jerozolimę i oblegał ją.
###### **Dn 1,2**
 Pan wydał w jego ręce króla judzkiego, Jojakima, oraz część naczyń domu Bożego, które zabrał do ziemi Szinear, do domu swego boga, umieszczając naczynia w skarbcu swego boga.
###### **Dn 1,3**
  Król polecił następnie Aszfenazowi, przełożonemu swoich dworzan, sprowadzić spośród Izraelitów z rodu królewskiego oraz z możnowładców
###### **Dn 1,4**
 młodzieńców bez jakiejkolwiek skazy, o pięknym wyglądzie, obeznanych z wszelką mądrością, posiadających wiedzę i obdarzonych rozumem, zdatnych do służby w królewskim pałacu. Zamierzał ich nauczyć pisma i mowy chaldejskiej.
###### **Dn 1,5**
 Król przydzielił im codzienną porcję potraw królewskich i wina, które pijał. Mieli być wychowywani przez trzy lata, by po ich upływie rozpocząć służbę przy królu.
###### **Dn 1,6**
 Spośród synów judzkich byli wśród nich: Daniel, Chananiasz, Miszael i Azariasz.
###### **Dn 1,7**
 Nadzorca służby dworskiej nadał im imiona: Danielowi – Belteszassar, Chananiaszowi – Szadrak, Miszaelowi – Meszak, Azariaszowi zaś Abed-Nego.
###### **Dn 1,8**
 Daniel powziął postanowienie, by się nie kalać potrawami królewskimi ani winem, które [król] pijał. Poprosił więc nadzorcę służby dworskiej, by nie musiał się kalać.
###### **Dn 1,9**
 Bóg zaś obdarzył Daniela przychylnością i miłosierdziem nadzorcy służby dworskiej.
###### **Dn 1,10**
 Nadzorca służby dworskiej powiedział do Daniela: «***Obawiam się, by mój pan, król, który przydzielił wam pożywienie i napoje, nie ujrzał, że wasze twarze są chudsze niż [twarze] młodzieńców w waszym wieku i byście nie narazili mojej głowy na niebezpieczeństwo u króla***».
###### **Dn 1,11**
 Daniel zaś powiedział do strażnika, którego ustanowił nadzorca służby dworskiej nad Danielem, Chananiaszem, Miszaelem i Azariaszem:
###### **Dn 1,12**
 «***Poddaj sługi twoje dziesięciodniowej próbie: niech nam dają jarzyny do jedzenia i wodę do picia.***
###### **Dn 1,13**
 ***Wtedy zobaczysz, jak my wyglądamy, a jak wyglądają młodzieńcy jedzący potrawy królewskie, i postąpisz ze swoimi sługami według tego, co zobaczysz***».
###### **Dn 1,14**
 Przystał na to żądanie i poddał ich dziesięciodniowej próbie.
###### **Dn 1,15**
 A po upływie dziesięciu dni wygląd ich był lepszy i zdrowszy niż innych młodzieńców, którzy spożywali potrawy królewskie.
###### **Dn 1,16**
 Strażnik zabierał więc ich potrawy i wino do picia, a podawał im jarzyny.
###### **Dn 1,17**
 Bóg zaś dał tym czterem młodzieńcom wiedzę i umiejętność wszelkiego pisma oraz mądrość. Daniel miał dar rozeznawania wszelkich widzeń i snów.
###### **Dn 1,18**
 Gdy minął okres ustalony przez króla, by ich przedstawić, nadzorca służby dworskiej wprowadził ich przed Nabuchodonozora.
###### **Dn 1,19**
 Król rozmawiał z nimi, i nie można było znaleźć pośród nich wszystkich nikogo równego Danielowi, Chananiaszowi, Miszaelowi i Azariaszowi. Zaczęli więc sprawować służbę przy królu.
###### **Dn 1,20**
 We wszystkich wymagających mądrości i roztropności sprawach, jakie przedkładał im król, okazywali się dziesięciokrotnie lepsi niż wszyscy tłumaczący sny i wróżbici w całym jego królestwie.
###### **Dn 1,21**
 Przebywał tam Daniel aż do pierwszego roku [panowania] Cyrusa.
# Dn 1 PAU
###### **Dn 1,1**
 W trzecim roku panowania Jojakima, króla Judy, Nabuchodonozor, król Babilonu, najechał na Jerozolimę i oblegał ją.
###### **Dn 1,2**
 Pan wydał w jego ręce Jojakima, króla Judy, oraz część naczyń domu Bożego. Nabuchodonozor zabrał je do ziemi Szinear, do domu swojego boga, i umieścił je w skarbcu swojego boga.
###### **Dn 1,3**
 Król rozkazał Aszfenazowi, przełożonemu dworzan, sprowadzić spośród Izraelitów - z rodu królewskiego oraz z możnowładców -
###### **Dn 1,4**
 młodzieńców bez skazy, przystojnych, uzdolnionych, obdarzonych wiedzą, roztropnych, pojętnych, zdolnych do pełnienia służby w pałacu królewskim oraz do poznania pisma i języka chaldejskiego.
###### **Dn 1,5**
 Król wyznaczył im codzienną porcję jedzenia i wina ze stołu królewskiego i polecił ich kształcić. Po trzech latach mieli oni stanąć przed królem.
###### **Dn 1,6**
 Spośród mieszkańców Judy był tam: Daniel, Chananiasz, Miszael i Azariasz.
###### **Dn 1,7**
 Przełożony dworzan zmienił im imiona. Danielowi dał imię Belteszassar, Chananiaszowi - Szadrak, Miszaelowi - Meszak, Azariaszowi - Abednego.
###### **Dn 1,8**
 Daniel powziął mocne postanowienie, aby nie kalać się pokarmem, który jadał król, ani winem, które on pił. Poprosił więc przełożonego dworzan, aby nie musiał tego spożywać.
###### **Dn 1,9**
 Bóg zjednał Danielowi łaskę i miłość przełożonego dworzan.
###### **Dn 1,10**
 Przełożony dworzan powiedział do Daniela: „Boję się, że mój pan, król, który postanowił, co macie jeść i pić, zapyta, dlaczego wyglądacie mizerniej niż wasi rówieśnicy. W ten sposób ściągniecie karę na moją głowę”.
###### **Dn 1,11**
 Daniel odpowiedział strażnikowi, którego przełożony dworzan wyznaczył dla Daniela, Chananiasza, Miszaela i Azariasza:
###### **Dn 1,12**
 „Poddaj swoje sługi dziesięciodniowej próbie. Niech dają nam do jedzenia tylko jarzyny, a do picia - wodę.
###### **Dn 1,13**
 Potem przyjrzysz się nam i młodzieńcom, którzy jedli potrawy królewskie, i postąpisz ze swymi sługami według tego, co zobaczysz”.
###### **Dn 1,14**
 I tak się stało. Strażnik poddał ich dziesięciodniowej próbie.
###### **Dn 1,15**
 Po upływie dziesięciu dni okazało się, że wyglądają oni lepiej niż młodzieńcy, którzy jedli potrawy królewskie.
###### **Dn 1,16**
 Strażnik zabierał im więc potrawy i wino królewskie, a przynosił jarzyny.
###### **Dn 1,17**
 A Bóg obdarzył tych czterech młodzieńców wiedzą, rozumieniem wszelkiego pisma i mądrością. Daniel umiał też wyjaśniać widzenia i sny.
###### **Dn 1,18**
 Kiedy upłynął czas wyznaczony przez króla, przełożony dworzan zaprowadził młodzieńców przed Nabuchodonozora.
###### **Dn 1,19**
 Król rozmawiał z nimi, a nie znalazł się wśród nich nikt taki, jak Daniel, Chananiasz, Miszael i Azariasz. Dlatego oni właśnie rozpoczęli służbę przy królu.
###### **Dn 1,20**
 Król zasięgał ich rady we wszystkich sprawach wymagających rozwagi i mądrości. Widział, że mądrością dziesięciokrotnie przewyższają oni wszystkich wróżbitów i magów w całym jego królestwie.
###### **Dn 1,21**
 Daniel był tam do pierwszego roku panowania króla Cyrusa.
# Dn 1 BP
###### **Dn 1,1**
 W trzecim roku panowania Jojakima, króla Judy, Nebukadnezar, król Babilonu, przybył do Jerozolimy i obległ ją.
###### **Dn 1,2**
 Pan dał w jego rękę Jojakima, króla Judy, oraz część naczyń Domu Bożego. Odesłał je do krainy Szinear [...]. Naczynia umieścił w skarbcu swojego boga.
###### **Dn 1,3**
 Król polecił Aszpenazowi, przełożonemu swoich dworzan, przyprowadzić [niektórych] spośród synów Izraela z rodu królewskiego i [pochodzenia] książęcego
###### **Dn 1,4**
 młodzieńców, w których by nie było żadnej skazy, o pięknym wyglądzie, biegłych we wszelkiej mądrości, posiadających wiedzę, bystrego rozumu, którzy nadawaliby się do służby w pałacu królewskim - aby ich nauczyć pisma i języka Chaldejczyków.
###### **Dn 1,5**
 Król wyznaczył im na każdy dzień część strawy królewskiej i wina, które sam pił. Mieli być wychowywani przez trzy lata, a po ich upływie mieli służyć królowi.
###### **Dn 1,6**
 z synów Judy byli między nimi: Daniel, Chananiasz, Miszael i Azariasz.
###### **Dn 1,7**
 Przełożony dworzan nadał im imiona: Daniela nazwał Belteszaccarem, Chananiasza Szadrakiem, Miszaela Meszakiem i Azariasza Abed Nego.
###### **Dn 1,8**
 Daniel postanowił w sercu swoim, że się nie splami pokarmem króla i winem, które on pił. Prosił więc przełożonego dworzan, aby się nie musiał plamić.
###### **Dn 1,9**
 Bóg sprawił, że Daniel znalazł życzliwość i zrozumienie u przełożonego dworzan.
###### **Dn 1,10**
 Przełożony dworzan rzekł do Daniela: Boję się pana mojego, króla, który wyznaczył wam pokarm i napój; gdy zobaczy wasze twarze mizerniejsze niż [innych] młodzieńców w waszym wieku, narazicie moją głowę u króla.
###### **Dn 1,11**
 Daniel powiedział dozorcy, któremu przełożony dworzan zlecił [pieczę] nad Danielem, Chananiaszem, Miszaelem i Azariaszem:
###### **Dn 1,12**
 Poddaj próbie, proszę, sługi twoje przez dziesięć dni. Niech nam dają jarzyny do jedzenia i wodę do picia.
###### **Dn 1,13**
 Zobaczysz, jak wyglądamy my, a jak młodzieńcy, którzy jedzą pokarm królewski, i według tego, jak zauważysz, postąp z twoimi sługami.
###### **Dn 1,14**
 Posłuchał ich w tej sprawie i poddał ich próbie przez dziesięć dni.
###### **Dn 1,15**
 Po upływie dziesięciu dni ich wygląd okazał się lepszy i ciało lepiej odżywione niż wszystkich młodzieńców, którzy jedli pokarm królewski.
###### **Dn 1,16**
 Toteż zabrał dozorca ich potrawy oraz wino, które oni mieli pić, i dawał im jarzyny.
###### **Dn 1,17**
 Owym czterem młodzieńcom dał Bóg wiedzę, biegłość w każdym piśmie i mądrość. Daniel miał [nadto] dar rozumienia wszelkich widzeń i snów.
###### **Dn 1,18**
 A gdy upłynęły dni, po których król polecił, aby ich przyprowadzono, przełożony dworzan stawił ich przed oblicze Nebukadnezara.
###### **Dn 1,19**
 Król rozmawiał z nimi. I nie znalazł się pośród nich wszystkich [nikt taki], jak Daniel, Chananiasz, Miszael i Azariasz. Służyli więc królowi.
###### **Dn 1,20**
 W każdej sprawie [wymagającej] mądrości i rozumu, w której król ich się radził, widział, że oni są dziesięciokrotnie bieglejsi od wszystkich magów i czarodziejów, którzy byli w całym jego królestwie.
###### **Dn 1,21**
 I pozostał Daniel [na dworze] aż do pierwszego roku [panowania] króla Cyrusa.
# Dn 1 BR
###### **Dn 1,1**
 W trzecim roku panowania Jojakima, króla judzkiego, Nabuchodonozor, król Babilonii, dotarł do Jerozolimy i rozpoczął oblężenie miasta.
###### **Dn 1,2**
 Pan wydał w jego ręce Jojakima, króla judzkiego. Zabrał też [Nabuchodonozor] wiele świętych przedmiotów ze Świątyni, które wywiózł do ziemi Szinear [do domu swego boga] i złożył je w skarbcu swego boga.
###### **Dn 1,3**
 Aszfenazowi, przełożonemu swoich dworzan, król kazał wybrać spośród Izraelitów pewną liczbę chłopców z królewskich rodów.
###### **Dn 1,4**
 Mieli to być młodzieńcy zdrowi, o szczególnie pięknym wyglądzie, uzdolnieni wszechstronnie, mający i dużą wiedzę i wrodzoną roztropność, nadający się do pełnienia służby na dworze królewskim. Aszfenaz miał ich nauczyć pisma i języka chaldejskiego.
###### **Dn 1,5**
 Król przydzielił im codzienną część potraw oraz wino z własnego stołu. Po trzech latach wychowania mieli rozpocząć służbę przy królu.
###### **Dn 1,6**
 Wśród owych młodzieńców było czterech z pokolenia Judy: Daniel, Chananiasz, Miszael, i Azariasz.
###### **Dn 1,7**
 Przełożony służby dworskiej nadał im nowe imiona: Danielowi dał imię Belteszassar, Chananiaszowi - Szadrak, Miszaelowi - Meszak i Azariaszowi - Abed-Nego.
###### **Dn 1,8**
 Daniel w trosce o to, by się nie skalać jedzeniem i winem ze stołu królewskiego, prosił przełożonego służby dworskiej, żeby nie musiał korzystać [ze stołu królewskiego].
###### **Dn 1,9**
 I sprawił Bóg, że znalazł Daniel życzliwość i miłosierdzie w oczach przełożonego służby dworskiej.
###### **Dn 1,10**
 Powiedział jednak przełożony służby dworskiej do Daniela: Boję się mojego pana i króla. On sam bowiem przydzielił wam takie jedzenie i wino. Jeżeli teraz zobaczy, że wyglądacie gorzej niż inni chłopcy w waszym wieku, to ja będę musiał za to odpowiedzieć przed królem.
###### **Dn 1,11**
 Powiedział tedy Daniel do przełożonego służby dworskiej, sprawującego władzę nad Danielem, Chananieszem, Miszaelem i Azariaszem:
###### **Dn 1,12**
 Proszę cię bardzo, weź twoje sługi na dziesięciodniową próbę. Niech podają nam przez ten czas tylko jarzyny do jedzenia i wodę do picia.
###### **Dn 1,13**
 Potem porównasz nasz wygląd z wyglądem młodzieńców odżywiających się daniami królewskimi. Wtedy będziesz mógł zrobić z nami, co zechcesz.
###### **Dn 1,14**
 I zgodził się na to, o co go prosili.
###### **Dn 1,15**
 Otóż, okazało się po dziesięciu dniach, że wyglądali oni lepiej i byli zdrowsi niż wszyscy ci młodzieńcy, którzy jedli ze stołu królewskiego.
###### **Dn 1,16**
 Od tego czasu opiekun ich nie przysyłał im już więcej ani królewskich potraw, ani wina, lecz dawał im do jedzenia tylko jarzyny.
###### **Dn 1,17**
 A owych czterech młodzieńców obdarzał Bóg szczególną mądrością i postępami w czytaniu i pisaniu. Prócz tego Daniel miał dar objaśniania widzeń i snów.
###### **Dn 1,18**
 Kiedy nadszedł czas wyznaczony przez króla na spotkanie u niego, przełożony służby dworskiej przedstawił ich Nabuchodonozorowi.
###### **Dn 1,19**
 Pozostając z nimi jakiś czas król widział, że Daniel, Chananiasz, Miszael i Azariasz nie mają sobie równych wśród pozostałych młodzieńców. Zaczęli więc pełnić służbę u Nabuchodonozora.
###### **Dn 1,20**
 W sprawach wymagających mądrości i szczególnego rozeznania przewyższali oni - według króla - po dziesięciokroć wszystkich czarnoksiężników i wróżbitów, jacy istnieli w całym królestwie.
###### **Dn 1,21**
 I pozostawał tam Daniel aż do pierwszego roku panowania Cyrusa.
# Dn 1 WUJ
###### **Dn 1,1**
 Roku trzeciego królestwa Joakima króla Judzkiego, przyszedł Nabuchodonozor król Babiloński do Jeruzalem, i obiegł je.
###### **Dn 1,2**
 I dał Pan w ręce jego Joakima króla Judzkiego, i część naczynia domu Bożego, i zawiózł je do ziemie Sannaar, do domu Boga swego, i wniósł naczynie do domu skarbu Boga swego.
###### **Dn 1,3**
 I rzekł król Asphenezowi przełożonemu trzebieńców, aby wwiód z synów Izraelowych, a z nasienia królewskiego i Pańskiego,
###### **Dn 1,4**
 Pacholęta, w którychby nie było żadnej zmazy, pięknych urodą, i wyćwiczone we wszelakiej mądrości, ostrożne w umiejętności, i uczone w nauce, a którzyby mogli stać w pałacu królewskim, aby ich uczył pisma i języka Chaldejskiego.
###### **Dn 1,5**
 I postanowił im król obrok na każdy dzień z potraw swoich, i z wina, z którego sam pił, aby wychowani przez trzy lata, potem stali przed obliczem królewskiem.
###### **Dn 1,6**
 Byli tedy między nimi z synów Judzkich, Daniel, Ananiasz, Misael, i Azaryasz.
###### **Dn 1,7**
 I dał im przełożony trzebieńców imiona: Danielowi Balthassar: Ananiaszowi Sydrach: Misaelowi Misach: a Azaryaszowi Abdenago.
###### **Dn 1,8**
 Lecz Daniel postanowił w sercu swojem, żeby się nie mazał z stołu królewskiego, ani winem picia jego: i prosił przełożonego rzezańców, żeby się nie zmazał.
###### **Dn 1,9**
 I dał Bóg Danielowi łaskę i miłosierdzie przed obliczem przełożonego rzezańców.
###### **Dn 1,10**
 I rzekł przełożony rzezańców do Daniela: Boję się ja Pana mego króla, który wam postanowił jadło i picie: który jeśli ujrzy twarzy wasze chudsze niż innych młodzieńców rówienników waszych, potępicie głowę moję królowi.
###### **Dn 1,11**
 I rzekł Daniel do Malasara, którego był postanowił przełożony rzezańców nad Danielem, Ananiaszem, Misaelem, i Azaryaszem.
###### **Dn 1,12**
 Doświadcz nas proszę cię sług twoich przez dziesięć dni, a niech nam dawają jarzyny ku jedzeniu, a wodę ku piciu:
###### **Dn 1,13**
 A przypatruj się twarzom naszym, i twarzom pacholąt, które jedzą potrawy królewskie: a jako ujrzysz uczynisz z sługami twemi.
###### **Dn 1,14**
 Który usłyszawszy mowę takową, doświadczał ich przez dziesięć dni.
###### **Dn 1,15**
 A po dziesiąci dni pokazały się twarzy ich lepsze i cielistsze niźli wszech pacholąt, które jadły potrawy królewskie.
###### **Dn 1,16**
 Tedy Malasar brał potrawy i wino napoju ich: a dawał im jarzyn.
###### **Dn 1,17**
 A tym pacholętom dał Bóg umiejętność, i naukę we wszelakich księgach i w mądrości: a Danielowi dał wyrozumienie wszelakiego widzenia i snów.
###### **Dn 1,18**
 A tak, gdy się wypełniły dni, po których był król rzekł, aby je wprowadzono, przywiódł je przełożony rzezańców przed oczy Nabuchodonozora.
###### **Dn 1,19**
 A gdy z nimi król rozmawia, nie naleźli się tacy ze wszystkich, jako Daniel, Ananiasz, Misael, i Azaryasz: i stawali przed królem.
###### **Dn 1,20**
 A wszelkie słowo w mądrości i w rozumie, którego pytał się król u nich, nalazł w nich dziesięciorako nad wszystkie wieszczki i czarnoksiężniki, którzy byli we wszystkiem królestwie jego.
###### **Dn 1,21**
 I był Daniel aż do pierwszego roku Cyrusa króla.
