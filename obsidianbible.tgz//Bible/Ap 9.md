# Ap 9 BT5
###### **Ap 9,1**
 Piąty anioł zatrąbił:i ujrzałem gwiazdę, która z nieba spadła na ziemię, i dano jej klucz od studni Czeluści.
###### **Ap 9,2**
 I otworzyła studnię Czeluści, a dym się uniósł ze studni jak dym z wielkiego pieca, i od dymu studni zaćmiło się słońce i powietrze.
###### **Ap 9,3**
 A z dymu wyszła szarańcza na ziemię, i dano jej moc, jaką mają ziemskie skorpiony.
###### **Ap 9,4**
 I powiedziano jej, by nie czyniła szkody trawie na ziemi ani żadnej zieleni, ani żadnemu drzewu, lecz tylko ludziom, którzy nie mają pieczęci Boga na czołach.
###### **Ap 9,5**
 I dano jej nakaz, by ich nie zabijała, lecz aby pięć miesięcy cierpieli katusze. A katusze przez nią zadane są jak zadane przez skorpiona, kiedy ukłuje człowieka.
###### **Ap 9,6**
 I w owe dni ludzie szukać będą śmierci, ale jej nie znajdą, i będą chcieli umrzeć, ale śmierć od nich ucieknie.
###### **Ap 9,7**
 A wygląd szarańczy: podobne do koni uszykowanych do boju, na głowach ich jakby wieńce podobne do złotych, oblicza ich jakby oblicza ludzi,
###### **Ap 9,8**
 i miały włosy jakby włosy kobiet, a zęby ich były jakby zęby lwów,
###### **Ap 9,9**
 i miały przody tułowi jakby pancerze żelazne, a łoskot ich skrzydeł jak łoskot wielokonnych wozów, pędzących do boju.
###### **Ap 9,10**
 I mają ogony podobne do skorpionowych oraz żądła; a w ich ogonach jest ich moc szkodzenia ludziom przez pięć miesięcy.
###### **Ap 9,11**
 Mają nad sobą króla – anioła Czeluści; imię jego po hebrajsku Abaddon,a w greckim języku ma imię Apollyon.
###### **Ap 9,12**
 Minęło pierwsze "biada": oto jeszcze dwa "biada" nadchodzą po nim.
###### **Ap 9,13**
 Szósty anioł zatrąbił: i usłyszałem jeden głos od czterech rogów złotego ołtarza,który jest przed Bogiem,
###### **Ap 9,14**
 mówiący do szóstego anioła, który miał trąbę: «***Uwolnij czterech aniołówzwiązanych nad wielką rzeką Eufrat!***»
###### **Ap 9,15**
 I zostali uwolnieni czterej aniołowie, gotowi na [określoną] godzinę, dzień, miesiąc i rok, by pozabijać trzecią część ludzi.
###### **Ap 9,16**
 A liczba wojsk – konnicy: dwie miriady miriad – posłyszałem ich liczbę.
###### **Ap 9,17**
 I tak ujrzałem w widzeniu konie i tych, co na nich siedzieli, mających pancerze barwy ognia, hiacyntu i siarki. A głowy koni jak głowy lwów, a z pysków ich wychodzi ogień, dym i siarka.
###### **Ap 9,18**
 Przez te trzy plagi została zabita trzecia część ludzi, od ognia, dymu i siarki, wychodzących z ich pysków.
###### **Ap 9,19**
 Moc bowiem koni jest w ich pyskachi w ich ogonach, bo ich ogony – podobne do wężów:mają głowy i nimi czynią szkodę.
###### **Ap 9,20**
  A pozostali ludzie, nie zabici przez te plagi, nie odwrócili się od dzieł swoich rąk, tak by nie wielbić [już] demonówani bożków złotych, srebrnych, spiżowych, kamiennych, drewnianych, które nie mogą ni widzieć, ni słyszeć, ni chodzić.
###### **Ap 9,21**
 Ani się nie odwrócili od swoich zabójstw, swych czarów, swego nierządu i swych kradzieży.
# Ap 9 PAU
###### **Ap 9,1**
 Zatrąbił piąty anioł. Ujrzałem gwiazdę, która spadała z nieba na ziemię. Dano jej klucz do studni otchłani.
###### **Ap 9,2**
 I otworzyła studnię otchłani, a ze studni, jak z wielkiego pieca uniósł się dym. Słońce i powietrze pociemniały od dymu ze studni.
###### **Ap 9,3**
 Z dymu zaś wyszła na ziemię szarańcza, której dano taką moc, jaką mają na ziemi skorpiony.
###### **Ap 9,4**
 Powiedziano jej, aby nie niszczyła ani ziemskiej trawy, ani jakiejkolwiek rośliny czy drzewa, lecz tylko ludzi, którzy nie mają na czole pieczęci Boga.
###### **Ap 9,5**
 Nakazano jej, aby ich nie zabijała, lecz by dręczyła ich przez pięć miesięcy takim bólem, jaki wywołuje ukąszenie skorpiona.
###### **Ap 9,6**
 W owych dniach ludzie będą szukać śmierci i nie znajdą jej. Będą chcieli umrzeć, a śmierć ucieknie od nich.
###### **Ap 9,7**
 A szarańcza podobna była do koni gotowych do walki. Na ich głowach - jakby wieńce podobne do złota, a ich pyski - jak ludzkie twarze.
###### **Ap 9,8**
 Ich grzywy były jak włosy kobiet, a ich zęby jak zęby lwa.
###### **Ap 9,9**
 Ich torsy były jak żelazne pancerze, a łopot ich skrzydeł - jak turkot wielokonnych wozów pędzących do boju.
###### **Ap 9,10**
 Miały ogony - takie jak u skorpionów - oraz żądła. Właśnie w ogonach tkwiła ich moc niszczenia ludzi przez pięć miesięcy.
###### **Ap 9,11**
 Miały nad sobą króla - anioła otchłani. Jego hebrajskie imię Abaddon po grecku brzmi Niszczyciel.
###### **Ap 9,12**
 Pierwsze „biada” odeszło. Oto po nim nadchodzą jeszcze dwa „biada”.
###### **Ap 9,13**
 Zatrąbił szósty anioł. Z czterech rogów złotego ołtarza, który stał przed Bogiem, usłyszałem głos
###### **Ap 9,14**
 mówiący do szóstego anioła trzymającego trąbę: „Uwolnij czterech aniołów spętanych nad wielką rzeką Eufrat”.
###### **Ap 9,15**
 I czterej aniołowie, którzy byli przygotowani na godzinę, dzień, miesiąc i rok, zostali uwolnieni, aby zabić jedną trzecią ludzi.
###### **Ap 9,16**
 Liczba wojska konnego wynosiła dwie miriady miriad. Ich liczbę usłyszałem.
###### **Ap 9,17**
 Tak więc zobaczyłem w widzeniu konie, a na nich jeźdźców, którzy mieli pancerze koloru ognia, hiacyntu i siarki. Łby koni podobne były do łbów lwów, a z ich pysków wydobywał się ogień, dym i siarka.
###### **Ap 9,18**
 Z powodu tych trzech plag: ognia, dymu i siarki, które wydobywały się z ich pysków, zginęła jedna trzecia ludzi.
###### **Ap 9,19**
 A moc koni była w ich pyskach i w ogonach, gdyż ogony te były jak węże mające głowy, aby nimi kąsać.
###### **Ap 9,20**
 Pozostali ludzie, którzy nie zginęli od tych plag, nie odwrócili się od dzieł swoich rąk. Nie przestali oddawać pokłonu demonom oraz złotym, srebrnym, miedzianym, kamiennym i drewnianym bożkom, co nie potrafią ani widzieć, ani słyszeć, ani chodzić.
###### **Ap 9,21**
 Nie odwrócili się także od swych morderstw ani od czarów, ani od nierządu, ani od kradzieży.
# Ap 9 BP
###### **Ap 9,1**
 Piąty anioł zatrąbił: i ujrzałem gwiazdę, która spadła z nieba na ziemię, i dano jej klucz od studni Przepaści.
###### **Ap 9,2**
 Otworzyła studnię Przepaści, a dym się uniósł ze studni jak dym z wielkiego pieca, i od dymu studni zaćmiło się słońce i powietrze.
###### **Ap 9,3**
 A z dymu wyszła na ziemię szarańcza, której dano moc, jaką mają ziemskie skorpiony.
###### **Ap 9,4**
 I powiedziano jej, by nie szkodziła trawie na ziemi ani żadnej innej zieleni, ani żadnemu drzewu, lecz tylko ludziom, którzy nie mają pieczęci Boga na czołach.
###### **Ap 9,5**
 Nakazano jej też, by ich nie zabijała, ale miała przez pięć miesięcy zadawać im katusze. A katusze przez nią zadane są jak katusze zadane przez skorpiona, kiedy ukąsi człowieka.
###### **Ap 9,6**
 W owe dni ludzie szukać będą śmierci, ale jej nie znajdą, i będą chcieli umrzeć, ale śmierć od nich ucieknie.
###### **Ap 9,7**
 A szarańcza tak wyglądała: podobna [była] do koni w szyku bojowym, na ich głowach jakby wieńce podobne do złotych, oblicza ich były jakby twarze ludzkie,
###### **Ap 9,8**
 i miały włosy jakby włosy kobiece, a zęby ich były jak zęby lwów.
###### **Ap 9,9**
 Przody tułowi jakby pancerze żelazne, a łoskot ich skrzydeł jak łoskot wielokonnych wozów pędzących do boju.
###### **Ap 9,10**
 I mają ogony podobne do skorpionowych oraz żądła, a swymi ogonami mogą szkodzić ludziom przez pięć miesięcy.
###### **Ap 9,11**
 Mają nad sobą króla - anioła Przepaści. Imię jego po hebrajsku brzmi ABADDON, a w greckim języku ma imię APOLLYON.
###### **Ap 9,12**
 Minęło pierwsze "biada", oto jeszcze dwa inne "biada" nadchodzą potem.
###### **Ap 9,13**
 Szósty anioł zatrąbił: i usłyszałem jeden głos od czterech rogów złotego ołtarza, który jest przed Bogiem,
###### **Ap 9,14**
 mówiący do szóstego anioła, który ma trąbę: "Uwolnił czterech aniołów związanych nad wielką rzeką Eufratem!"
###### **Ap 9,15**
 I zostali uwolnieni czterej aniołowie, gotowi na godzinę, dzień, miesiąc i rok, aby zabić trzecią część ludzi.
###### **Ap 9,16**
 A liczba wojsk konnicy: dwie miriady miriad - posłyszałem ich liczbę.
###### **Ap 9,17**
 I ujrzałem w widzeniu konie i siedzących na nich [jeźdźców] w pancerzach barwy ognia, hiacyntu i siarki. A głowy koni jak głowy lwów, a z pysków ich wychodzi ogień, dym i siarka.
###### **Ap 9,18**
 Trzecia część ludzi zginęła od tych trzech plag: od ognia, dymu i siarki wychodzących z ich pysków.
###### **Ap 9,19**
 Bo siła koni jest w ich pyskach i w ogonach, bo ich ogony - podobne do węży: mają głowy i szkodzą nimi.
###### **Ap 9,20**
 Pozostali zaś ludzie - nie zabici przez te plagi - nie zerwali z dziełami swoich rąk, nie zaprzestali [też] wielbić demonów ani bożków złotych, srebrnych, spiżowych, kamiennych, drewnianych, które nie mogą widzieć ani słyszeć, ani chodzić.
###### **Ap 9,21**
 Ani nie zerwali z zabójstwami, czarami, nierządem i kradzieżą.
# Ap 9 BR
###### **Ap 9,1**
 Kiedy zatrąbił piąty anioł, ujrzałem gwiazdę, która spadła z nieba na ziemię, i której dano klucz od zejścia prowadzącego ku przepaści.
###### **Ap 9,2**
 A gdy otworzyła zejście do przepaści, z wewnątrz, jakby z wielkiego pieca, wydobył się dym, od którego zaćmiło się słońce i powietrze.
###### **Ap 9,3**
 A z dymu wyszła na ziemię szarańcza, której dano moc [szkodzenia], jaką mają skorpiony.
###### **Ap 9,4**
 Szarańcza owa otrzymała nakaz niewyrządzania żadnej szkody trawie rosnącej na ziemi lub jakiejkolwiek zieleni albo drzewu. Miała atakować tylko ludzi nie posiadających pieczęci Boga na czołach.
###### **Ap 9,5**
 Zakazano jej zabijać tych ludzi, lecz mieli oni przez pięć miesięcy cierpieć udręczenie. Ból zaś, który zadawała, przypominał cierpienie, jakie znosi człowiek ukąszony przez skorpiona.
###### **Ap 9,6**
 Ludzie sami poczną wtedy szukać śmierci, lecz nigdzie jej nie znajdą; będą chcieli umrzeć, lecz śmierć będzie od nich stronić.
###### **Ap 9,7**
 Z wyglądu szarańcza owa podobna była do koni ustawionych w bojowym szyku: na głowach ich widniały jakby wieńce ze złota, oblicza przypominały twarze ludzi,
###### **Ap 9,8**
 a ich włosy były jakby włosy kobiet, zęby zaś - jakby zęby lwów.
###### **Ap 9,9**
 Ich tułowie od przodu były podobne do żelaznych pancerzy, szum zaś poruszanych skrzydeł przypominał odgłosy wozów wielokonnych, pędzących do boju.
###### **Ap 9,10**
 Miały ogony takie jak u skorpionów i żądła. Właśnie za pomocą owych ogonów mogły wyrządzać ludziom szkody przez pięć miesięcy.
###### **Ap 9,11**
 Ich wodzem jest anioł przepaści, który nazywa się po hebrajsku Abaddon, a po grecku Apollyon.
###### **Ap 9,12**
 Tak oto minęło pierwsze Biada. Następują po nim dwa inne Biada.
###### **Ap 9,13**
 A gdy zatrąbił szósty anioł, usłyszałem głos pochodzący od czterech rogów złotego ołtarza, stojącego przed Bogiem.
###### **Ap 9,14**
 Głos ten był skierowany do szóstego anioła z trąbą i brzmiał: Uwolnij czterech aniołów, związanych nad wielką rzeką Eufratem!
###### **Ap 9,15**
 I zostali uwolnieni czterej aniołowie, przygotowani już na godzinę, dzień, miesiąc i rok, by zgładzić trzecią część ludzi.
###### **Ap 9,16**
 Usłyszałem także liczbę wojowników konnych: było ich dwie miriady miriad.
###### **Ap 9,17**
 Zobaczyłem też w kolejnym widzeniu konie i jeźdźców, którzy na nich siedzieli: mieli na sobie zbroje koloru ognia, hiacyntu i siarki. Głowy końskie zaś przypominały wyglądem głowy lwów. Z pysków ich buchał ogień, dym i siarka.
###### **Ap 9,18**
 Wskutek tych trzech plag, od ognia, dymu i siarki wychodzących z ich pysków, padła trzecia część ludzi.
###### **Ap 9,19**
 Moc bowiem [śmiercionośna] owych koni znajduje się w ich pyskach i ogonach; ogony przypominają wyglądem węże: są zakończone głowami i nimi szkodzą.
###### **Ap 9,20**
 Lecz pozostali ludzie, nie wyniszczeni tymi plagami, nie porzucili dzieł rąk swoich; nie przestali wielbić demonów, bożków ze złota, ze srebra, ze spiżu, z kamienia i z drewna, idolów, które nie mogą ani widzieć, ani słyszeć, ani chodzić.
###### **Ap 9,21**
 Nie przestali dopuszczać się zabójstw, czarów, nierządu i kradzieży.
# Ap 9 WUJ
###### **Ap 9,1**
 I zatrąbił piąty anioł, i widziałem gwiazdę, że spadła z nieba na ziemię, a dano jej klucz studnie przepaści.
###### **Ap 9,2**
 I otworzyła studnią przepaści: i wstąpił dym studnie, jako dym pieca wielkiego: i zaćmiło się słońce i powietrze od dymu studniej.
###### **Ap 9,3**
 I wyszły z dymu studniej szarańcze na ziemię: i dano im moc, jako mają moc niedźwiadkowie ziemscy:
###### **Ap 9,4**
 A rozkazano im, żeby nie psowały trawy ziemie, ani wszelkiej zieloności, ani wszelkiego co zielono: jedno tylko ludzie, którzy nie mają pieczęci Bożej na czołach swoich.
###### **Ap 9,5**
 A dano im, aby ich nie zabijali: ale aby byli męczeni pięć miesięcy: a męczenie ich, jako męczenie niedźwiadkowe, gdy człowieka ukąsi.
###### **Ap 9,6**
 A w one dni szukać będą ludzie śmierci, a nie najdą jej: i będą żądać umrzeć, a uciecze śmierć od nich.
###### **Ap 9,7**
 A podobieństwa szarańczej, podobne koniom gotowym na wojnę: a na głowach ich jakoby, korony podobne złotu: a twarzy ich jako twarzy człowiecze;
###### **Ap 9,8**
 I miały włosy jako włosy niewieście: a zęby ich, jako zęby lwów były.
###### **Ap 9,9**
 A miały pancerze jako pancerze żelazne: a głos skrzydeł ich jako głos wozów wielu koni bieżących na wojnę.
###### **Ap 9,10**
 I miały ogony podobne niedźwiadkom, a żądła były w ich ogoniech: a ich moc szkodzić ludziom przez pięć miesięcy.
###### **Ap 9,11**
 A miały nad sobą króla anioła przepaści, któremu imię po Żydowsku Abaddon, a po Grecku Apollion, a po Łacinie imię mając Exterminans.
###### **Ap 9,12**
 Biada jedna przeszła, a oto idą jeszcze dwie biedy potem.
###### **Ap 9,13**
 I szósty anioł zatrąbił: i słyszałem głos jeden ze czterech rogów ołtarza złotego, które jest przed oczyma Bożemi,
###### **Ap 9,14**
 Mówiący szóstemu aniołowi, który miał trąbę: Rozwiąż czterech aniołów, którzy są uwiązani w wielkiej rzece Euphrates.
###### **Ap 9,15**
 I rozwiązani są czterzej aniołowie, którzy byli gotowi na godzinę, na dzień, i na miesiąc, i na rok: aby pobili trzecią część ludzi.
###### **Ap 9,16**
 A liczba konnego wojska po dwakroć sto tysięcy milionów. A słyszałem liczbę ich.
###### **Ap 9,17**
 I takżem widział konie w widzeniu: a którzy na nich, mieli pancerze ogniste, i Hyacyntowe, i siarczane. A głowy koni były jako głowy lwie: a z gęby ich wychodzi ogień, i dym, i siarka.
###### **Ap 9,18**
 A od tych trzech plag pobita jest trzecia część ludzi, od ognia, i od dymu, i od siarki, które wychodziły z gąb ich.
###### **Ap 9,19**
 Abowiem władza koni jest w gębach ich, i w ogonach ich. Bo ogony ich, wężom podobne, mając głowy: a temiż szkodzą.
###### **Ap 9,20**
 A inni ludzie, którzy nie są pobici temi plagami, ani pokutowali za uczynki rąk swych, aby się nie kłaniali czartom i bałwanom złotym, i srebrnym, i miedzianym, i kamiennym, i drzewianym, którzy ani widzieć mogą, ani słyszeć, ani chodzić,
###### **Ap 9,21**
 I nie pokutowali za mężobójstwa swoje, ani za czary swoje, ani za porubstwa swe, ani za złodziejstwa swoje.
# Ap 9 STERN
###### **Ap 9,1**
 Piąty anioł zadął w swój szofar, i ujrzałem gwiazdę, która spadła z nieba na ziemię, i dano jej klucz do szybu prowadzącego do Otchłani.
###### **Ap 9,2**
 Otworzyła szyb Otchłani, i z szybu wyszedł dym, niby dym z ogromnego pieca. Słońce pociemniało i niebo także od dymu z szybu.
###### **Ap 9,3**
 Wtedy z dymu wyszła na ziemię szarańcza i dano jej moc jak moc skorpionów na ziemi.
###### **Ap 9,4**
 Polecono jej nie wyrządzać szkody trawie na ziemi, żadnej zielonej roślinie ani drzewu, a tylko ludziom, którzy nie mają na czołach pieczęci Boga.
###### **Ap 9,5**
 Szarańczy nie pozwolono zabijać ich, a tylko zadawać im ból przez pięć miesięcy, a ból przez nią zadawany był jak ból po ukąszeniu skorpiona.
###### **Ap 9,6**
 W tych dniach ludzie będą szukać śmierci, ale jej nie znajdą, będą pragnęli umrzeć, ale śmierć będzie ich unikać.
###### **Ap 9,7**
 A szarańcze te wyglądały jak konie przyszykowane do bitwy. Na głowach miały coś o wyglądzie złotych koron, a twarze ich były jak twarze ludzkie.
###### **Ap 9,8**
 Miały włosy jak włosy kobiet, a ich zęby były jak zęby lwów.
###### **Ap 9,9**
 Ich tułowia jak żelazny pancerz, a dźwięk ich skrzydeł przypominał zgiełk wielu koni i rydwanów pędzących do bitwy.
###### **Ap 9,10**
 Miały ogony jak ogony skorpionów, z żądłami, a w tych ogonach była ich moc, aby wyrządzać krzywdę ludziom przez pięć miesięcy.
###### **Ap 9,11**
 Miały nad sobą jako króla anioła Otchłani, którego imię brzmi po hebrajsku Abaddon, a w naszym języku - Niszczyciel.
###### **Ap 9,12**
 Pierwsze biada minęło, ale nadchodzą jeszcze dwa biada.
###### **Ap 9,13**
 Szósty anioł zadął w swój szofar, i usłyszałem głos od czterech rogów złotego ołtarza przed Bogiem
###### **Ap 9,14**
 mówiący do szóstego anioła, tego z szofarem: "Wypuść czterech aniołów, którzy są związani nad wielką rzeką Eufratem!".
###### **Ap 9,15**
 I zostali wypuszczeni. Tych czterech aniołów było trzymanych w gotowości na tę właśnie chwilę, na ten dzień i ten miesiąc, i rok, aby zabić jedną trzecią ludzkości,
###### **Ap 9,16**
 a liczba jazdy wynosiła dwieście milionów! -usłyszałem tę liczbę.
###### **Ap 9,17**
 Oto, jak wyglądały konie w wizji: jeźdźcy mieli pancerze ognistoczerwone, niebieskie jak irysy i żółte jak siarka. Łby koni były jak głowy lwów, a z paszcz ich wychodził ogień, dym i siarka.
###### **Ap 9,18**
 Te trzy plagi zabiły jedną trzecią ludzkości - ów ogień, dym i siarka wydobywające się z pysków koni.
###### **Ap 9,19**
 Bo moc tych koni była w ich pyskach, a także w ich ogonach, bo ogony ich były podobne do węży z głowami, i mogły nimi ranić.
###### **Ap 9,20**
 Reszta ludzkości, ci, którzy nie zginęli od tych plag, nawet wtedy nie odwróciła się od tego, co uczyniła własnymi rękami - nie przestali czcić demonów i bożków ze złota, srebra, brązu, kamienia i drewna, którzy nie widzą ani nie słyszą, ani nie chodzą.
###### **Ap 9,21**
 Nie odwrócili się też od swych morderstw, nadużywania narkotyków w związku z okultyzmem, rozwiązłości i kradzieży.
# Ap 9 TRO
###### **Ap 9,1**
 **και** *kai* I [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **πεμπτος** *pemptos* piąty [[G3991]] [[A-NSM]] **αγγελος** *angelos* zwiastun [[G32]] [[N-NSM]] **εσαλπισεν** *esalpisen* zatrąbił [[G4537]] [[V-AAI-3S]] **και** *kai* i [[G2532]] [[CONJ]] **ειδον** *eidon* zobaczyłem [[G1492]] WTV-2AAI-1S **αστερα** *astera* gwiazdę [[G792]] [[N-ASM]] **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **ουρανου** *ouranou* nieba [[G3772]] [[N-GSM]] **πεπτωκοτα** *peptōkota* spadającą [[G4098]] WTV-RAP-ASM **εις** *eis* na [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **γην** *gēn* ziemię [[G1093]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **εδοθη** *edothē* został dany [[G1325]] [[V-API-3S]] **αυτω** *autō* mu [[G846]] WTP-DSM **η** *hē* [[G3588]] [[T-NSF]] **κλεις** *kleis* klucz [[G2807]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSN **φρεατος** *freatos* studni [[G5421]] [[N-GSN]] **της** *tēs* [[G3588]] [[T-GSF]] **αβυσσου** *abyssou* otchłani – abyssu [[G12]] [[N-GSF]]
###### **Ap 9,2**
 **και** *kai* I [[G2532]] [[CONJ]] **ηνοιξεν** *ēnoiksen* otworzył [[G455]] [[V-AAI-3S]] **το** *to* [[G3588]] WTT-ASN **φρεαρ** *frear* studnię [[G5421]] WTN-ASN **της** *tēs* [[G3588]] [[T-GSF]] **αβυσσου** *abyssou* otchłani – abyssu [[G12]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **ανεβη** *anebē* wstąpił – wszedł [[G305]] WTV-2AAI-3S **καπνος** *kapnos* dym [[G2586]] [[N-NSM]] **εκ** *ek* ze [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **φρεατος** *freatos* studni [[G5421]] [[N-GSN]] **ως** *hōs* jak [[G5613]] [[ADV]] **καπνος** *kapnos* dym [[G2586]] [[N-NSM]] **καμινου** *kaminou* pieca [[G2575]] [[N-GSF]] **μεγαλης** *megalēs* wielkiego [[G3173]] WTA-GSF **και** *kai* i [[G2532]] [[CONJ]] **εσκοτισθη** *eskotisthē* zostało zaćmione – zostało pogrążone w ciemności [[G4654]] [[V-API-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **ηλιος** *hēlios* słońce [[G2246]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **αηρ** *aēr* powietrze [[G109]] [[N-NSM]] **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **καπνου** *kapnou* dymu [[G2586]] [[N-GSM]] **του** *tou* [[G3588]] WTT-GSN **φρεατος** *freatos* studni [[G5421]] [[N-GSN]]
###### **Ap 9,3**
 **και** *kai* I [[G2532]] [[CONJ]] **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **καπνου** *kapnou* dymu [[G2586]] [[N-GSM]] **εξηλθον** *eksēlthon* wyszły [[G1831]] WTV-2AAI-3P **ακριδες** *akrides* szarańcze [[G200]] [[N-NPF]] **εις** *eis* do [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **γην** *gēn* ziemię [[G1093]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **εδοθη** *edothē* została dana [[G1325]] [[V-API-3S]] **αυταις** *autais* im [[G846]] WTP-DPF **εξουσια** *eksousia* władza [[G1849]] [[N-NSF]] **ως** *hōs* jak [[G5613]] [[ADV]] **εχουσιν** *echousin* mają [[G2192]] WTV-PAI-3P **εξουσιαν** *eksousian* władzę [[G1849]] WTN-ASF **οι** *hoi* [[G3588]] WTT-NPM **σκορπιοι** *skorpioi* skorpiony [[G4651]] WTN-NPM **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]]
###### **Ap 9,4**
 **και** *kai* I [[G2532]] [[CONJ]] **ερρεθη** *errethē* zostało powiedziane [[G4483]] [[V-API-3S]] **αυταις** *autais* im [[G846]] WTP-DPF **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **αδικησωσιν** *adikēsōsin* czyniłyby niesprawiedliwości – krzywdziłyby [[G91]] WTV-AAS-3P **τον** *ton* [[G3588]] [[T-ASM]] **χορτον** *chorton* trawie [[G5528]] [[N-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]] **ουδε** *oude* ani [[G3761]] [[ADV]] **παν** *pan* wszelkiego [[G3956]] WTA-ASN **χλωρον** *chlōron* zielonego [[G5515]] WTA-ASN **ουδε** *oude* ani [[G3761]] [[ADV]] **παν** *pan* wszelkiemu [[G3956]] WTA-ASN **δενδρον** *dendron* drzewu [[G1186]] WTN-ASN **ει** *ei* jeśli [[G1487]] WTCOND **μη** *mē* nie [[G3361]] [[PRT-N]] **τους** *tous* [[G3588]] WTT-APM **ανθρωπους** *anthrōpous* ludziom [[G444]] [[N-APM]] **μονους** *monous* samych [[G3441]] WTA-APM **οιτινες** *hoitines* którzy [[G3748]] WTR-NPM **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εχουσιν** *echousin* mają [[G2192]] WTV-PAI-3P **την** *tēn* [[G3588]] WTT-ASF **σφραγιδα** *sfragida* pieczęci [[G4973]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **επι** *epi* na [[G1909]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **μετωπων** *metōpōn* czołach [[G3359]] WTN-GPN **αυτων** *autōn* ich [[G846]] WTP-GPM
###### **Ap 9,5**
 **και** *kai* I [[G2532]] [[CONJ]] **εδοθη** *edothē* zostało dane [[G1325]] [[V-API-3S]] **αυταις** *autais* im [[G846]] WTP-DPF **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **αποκτεινωσιν** *apokteinōsin* zabiliby [[G615]] WTV-PAS-3P **αυτους** *autous* ich [[G846]] [[P-APM]] **αλλ** *all* ale [[G235]] [[CONJ]] **ινα** *hina* aby [[G2443]] [[CONJ]] **βασανισθωσιν** *basanisthōsin* zostaliby dręczeni [[G928]] WTV-APS-3P **μηνας** *mēnas* miesięcy [[G3376]] [[N-APM]] **πεντε** *pente* pięć [[G4002]] WTA-NUI **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **βασανισμος** *basanismos* męczarnia – tortura [[G929]] [[N-NSM]] **αυτων** *autōn* ich [[G846]] WTP-GPF **ως** *hōs* jak [[G5613]] [[ADV]] **βασανισμος** *basanismos* męczarnia – tortura [[G929]] [[N-NSM]] **σκορπιου** *skorpiou* (od) skorpiona [[G4651]] [[N-GSM]] **οταν** *hotan* kiedy [[G3752]] [[CONJ]] **παιση** *paisē* raziłby – uderzyłby [[G3817]] WTV-AAS-3S **ανθρωπον** *anthrōpon* człowieka [[G444]] [[N-ASM]]
###### **Ap 9,6**
 **και** *kai* I [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **ημεραις** *hēmerais* dniach [[G2250]] WTN-DPF **εκειναις** *ekeinais* tych [[G1565]] WTD-DPF **ζητησουσιν** *zētēsousin* będą szukać [[G2212]] WTV-FAI-3P **οι** *hoi* [[G3588]] WTT-NPM **ανθρωποι** *anthrōpoi* ludzie [[G444]] WTN-NPM **τον** *ton* [[G3588]] [[T-ASM]] **θανατον** *thanaton* śmierci [[G2288]] [[N-ASM]] **και** *kai* a [[G2532]] [[CONJ]] **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **ευρησουσιν** *heurēsousin* znajdą [[G2147]] WTV-FAI-3P **αυτον** *auton* jej [[G846]] WTP-ASM **και** *kai* i [[G2532]] [[CONJ]] **επιθυμησουσιν** *epithymēsousin* będą pragnąć [[G1937]] WTV-FAI-3P **αποθανειν** *apothanein* umrzeć [[G599]] [[V-2AAN]] **και** *kai* a [[G2532]] [[CONJ]] **φευξεται** *feuksetai* ucieknie [[G5343]] WTV-FDI-3S **ο** *ho* [[G3588]] [[T-NSM]] **θανατος** *thanatos* śmierć [[G2288]] [[N-NSM]] **απ** *ap* od [[G575]] [[PREP]] **αυτων** *autōn* nich [[G846]] WTP-GPM
###### **Ap 9,7**
 **και** *kai* A [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-NPN **ομοιωματα** *homoiōmata* podobne formy – podobieństwo [[G3667]] WTN-NPN **των** *tōn* [[G3588]] WTT-GPF **ακριδων** *akridōn* szarańczy [[G200]] WTN-GPF **ομοια** *homoia* podobne [[G3664]] WTA-NPN **ιπποις** *hippois* koniom [[G2462]] WTN-DPM **ητοιμασμενοις** *hētoimasmenois* które są przygotowane [[G2090]] WTV-RPP-DPM **εις** *eis* do [[G1519]] [[PREP]] **πολεμον** *polemon* wojny – bitwy [[G4171]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **επι** *epi* na [[G1909]] [[PREP]] **τας** *tas* [[G3588]] WTT-APF **κεφαλας** *kefalas* głowach [[G2776]] WTN-APF **αυτων** *autōn* ich [[G846]] WTP-GPF **ως** *hōs* jak [[G5613]] [[ADV]] **στεφανοι** *stefanoi* wieńce – korony [[G4735]] WTN-NPM **ομοιοι** *homoioi* podobne [[G3664]] WTA-NPM **χρυσω** *chrysō* złotu [[G5557]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-NPN **προσωπα** *prosōpa* oblicza – twarze [[G4383]] WTN-NPN **αυτων** *autōn* ich [[G846]] WTP-GPF **ως** *hōs* jak [[G5613]] [[ADV]] **προσωπα** *prosōpa* oblicza – twarze [[G4383]] WTN-NPN **ανθρωπων** *anthrōpōn* ludzi [[G444]] WTN-GPM
###### **Ap 9,8**
 **και** *kai* I [[G2532]] [[CONJ]] **ειχον** *eichon* miały [[G2192]] WTV-IAI-3P **τριχας** *trichas* włosy [[G2359]] WTN-APF **ως** *hōs* jak [[G5613]] [[ADV]] **τριχας** *trichas* włosy [[G2359]] WTN-APF **γυναικων** *gynaikōn* kobiet [[G1135]] WTN-GPF **και** *kai* a [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **οδοντες** *odontes* zęby [[G3599]] WTN-NPM **αυτων** *autōn* ich [[G846]] WTP-GPF **ως** *hōs* jak [[G5613]] [[ADV]] **λεοντων** *leontōn* lwów [[G3023]] WTN-GPM **ησαν** *ēsan* były [[G2258]] WTV-IXI-3P
###### **Ap 9,9**
 **και** *kai* I [[G2532]] [[CONJ]] **ειχον** *eichon* miały [[G2192]] WTV-IAI-3P **θωρακας** *thōrakas* pancerze [[G2382]] [[N-APM]] **ως** *hōs* jak [[G5613]] [[ADV]] **θωρακας** *thōrakas* pancerze [[G2382]] [[N-APM]] **σιδηρους** *sidērous* żelazne [[G4603]] WTA-APM **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **φωνη** *fōnē* głos [[G5456]] [[N-NSF]] **των** *tōn* [[G3588]] WTT-GPF **πτερυγων** *pterygōn* skrzydeł [[G4420]] WTN-GPF **αυτων** *autōn* ich [[G846]] WTP-GPF **ως** *hōs* jak [[G5613]] [[ADV]] **φωνη** *fōnē* głos [[G5456]] [[N-NSF]] **αρματων** *harmatōn* rydwanów – wozów [[G716]] WTN-GPN **ιππων** *hippōn* koni [[G2462]] WTN-GPM **πολλων** *pollōn* licznych – wielu [[G4183]] WTA-GPM **τρεχοντων** *trechontōn* biegających [[G5143]] WTV-PAP-GPM **εις** *eis* na [[G1519]] [[PREP]] **πολεμον** *polemon* wojnę – bitwę [[G4171]] [[N-ASM]]
###### **Ap 9,10**
 **και** *kai* I [[G2532]] [[CONJ]] **εχουσιν** *echousin* mają [[G2192]] WTV-PAI-3P **ουρας** *ouras* ogony [[G3769]] WTN-APF **ομοιας** *homoias* podobne [[G3664]] WTA-APF **σκορπιοις** *skorpiois* skorpionom [[G4651]] WTN-DPM **και** *kai* i [[G2532]] [[CONJ]] **κεντρα** *kentra* żądła [[G2759]] WTN-APN **ην** *ēn* było (były) [[G2258]] [[V-IXI-3S]] **εν** *en* w [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **ουραις** *ourais* ogonach [[G3769]] WTN-DPF **αυτων** *autōn* ich [[G846]] WTP-GPF **και** *kai* a [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **εξουσια** *eksousia* władza [[G1849]] [[N-NSF]] **αυτων** *autōn* ich [[G846]] WTP-GPF **αδικησαι** *adikēsai* uczynić niesprawiedliwość – skrzywdzić [[G91]] [[V-AAN]] **τους** *tous* [[G3588]] WTT-APM **ανθρωπους** *anthrōpous* ludziom [[G444]] [[N-APM]] **μηνας** *mēnas* miesięcy [[G3376]] [[N-APM]] **πεντε** *pente* pięć [[G4002]] WTA-NUI
###### **Ap 9,11**
 **και** *kai* i [[G2532]] [[CONJ]] **εχουσιν** *echousin* mają [[G2192]] WTV-PAI-3P **επ** *ep* nad [[G1909]] [[PREP]] **αυτων** *autōn* nimi [[G846]] WTP-GPF **βασιλεα** *basilea* króla [[G935]] [[N-ASM]] **τον** *ton* [[G3588]] [[T-ASM]] **αγγελον** *angelon* zwiastuna [[G32]] [[N-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **αβυσσου** *abyssou* otchłani – abyssu [[G12]] [[N-GSF]] **ονομα** *onoma* imię [[G3686]] WTN-NSN **αυτω** *autō* mu [[G846]] WTP-DSM **εβραιστι** *hebraisti* (po) hebrajsku [[G1447]] [[ADV]] **αβαδδων** *abaddōn* Abaddon – [niszczyciel] [[G3]] [[N-PRI]] **και** *kai* a [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **ελληνικη** *hellēnikē* greckim [[G1673]] WTA-DSF **ονομα** *onoma* imię [[G3686]] WTN-NSN **εχει** *echei* ma [[G2192]] WTV-PAI-3S **απολλυων** *apollyōn* Apollon – Niszczyciel [[G623]] [[N-NSM]]
###### **Ap 9,12**
 **η** *hē* [[G3588]] [[T-NSF]] **ουαι** *ouai* Biada [[G3759]] WTN-OI **η** *hē* [[G3588]] [[T-NSF]] **μια** *mia* jedno [[G1520]] WTA-NSF **απηλθεν** *apēlthen* odeszło [[G565]] WTV-2AAI-3S **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **ερχονται** *erchontai* przychodzą [[G2064]] WTV-PNI-3P **ετι** *eti* jeszcze [[G2089]] [[ADV]] **δυο** *dyo* dwa [[G1417]] WTA-NUI **ουαι** *ouai* biada [[G3759]] WTN-OI **μετα** *meta* po [[G3326]] [[PREP]] **ταυτα** *tauta* tych [[G5023]] WTD-APN
###### **Ap 9,13**
 **και** *kai* I [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **εκτος** *hektos* szósty [[G1623]] [[A-NSM]] **αγγελος** *angelos* zwiastun [[G32]] [[N-NSM]] **εσαλπισεν** *esalpisen* zatrąbił [[G4537]] [[V-AAI-3S]] **και** *kai* i [[G2532]] [[CONJ]] **ηκουσα** *ēkousa* usłyszałem [[G191]] WTV-AAI-1S **φωνην** *fōnēn* głos [[G5456]] WTN-ASF **μιαν** *mian* jeden [[G1520]] WTA-ASF **εκ** *ek* z [[G1537]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **τεσσαρων** *tessarōn* czterech [[G5064]] WTA-GPN **κερατων** *keratōn* rogów [[G2768]] WTN-GPN **του** *tou* [[G3588]] WTT-GSN **θυσιαστηριου** *thysiastēriou* ołtarza [[G2379]] [[N-GSN]] **του** *tou* [[G3588]] WTT-GSN **χρυσου** *chrysou* złotego [[G5552]] [[A-GSN]] **του** *tou* [[G3588]] WTT-GSN **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Bogiem [[G2316]] [[N-GSM]]
###### **Ap 9,14**
 **λεγουσαν** *legousan* mówiący [[G3004]] WTV-PAP-ASF **τω** *tō* [[G3588]] WTT-DSM **εκτω** *hektō* szóstemu [[G1623]] WTA-DSM **αγγελω** *angelō* zwiastunowi [[G32]] WTN-DSM **ος** *hos* który [[G3739]] WTR-NSM **ειχε** *eiche* miał [[G2192]] WTV-IAI-3S **την** *tēn* [[G3588]] WTT-ASF **σαλπιγγα** *salpinga* trąbę [[G4536]] WTN-ASF **λυσον** *lyson* rozwiąż [[G3089]] WTV-AAM-2S **τους** *tous* [[G3588]] WTT-APM **τεσσαρας** *tessaras* czterech [[G5064]] WTA-APM **αγγελους** *angelous* zwiastunów [[G32]] [[N-APM]] **τους** *tous* [[G3588]] WTT-APM **δεδεμενους** *dedemenous* którzy są związani [[G1210]] WTV-RPP-APM **επι** *epi* nad [[G1909]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **ποταμω** *potamō* rzeką [[G4215]] WTN-DSM **τω** *tō* [[G3588]] WTT-DSM **μεγαλω** *megalō* wielką [[G3173]] WTA-DSM **ευφρατη** *eufratē* Eufratem [[G2166]] WTN-DSM
###### **Ap 9,15**
 **και** *kai* I [[G2532]] [[CONJ]] **ελυθησαν** *elythēsan* zostali rozwiązani [[G3089]] WTV-API-3P **οι** *hoi* [[G3588]] WTT-NPM **τεσσαρες** *tessares* czterej [[G5064]] WTA-NPM **αγγελοι** *angeloi* zwiastunowie [[G32]] WTN-NPM **οι** *hoi* [[G3588]] WTT-NPM **ητοιμασμενοι** *hētoimasmenoi* którzy są przygotowani [[G2090]] WTV-RPP-NPM **εις** *eis* na [[G1519]] [[PREP]] **την** *tēn* (tę) [[G3588]] WTT-ASF **ωραν** *hōran* godzinę [[G5610]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **ημεραν** *hēmeran* dzień [[G2250]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **μηνα** *mēna* miesiąc [[G3376]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **ενιαυτον** *eniauton* rok [[G1763]] [[N-ASM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **αποκτεινωσιν** *apokteinōsin* zabiliby [[G615]] WTV-PAS-3P **το** *to* [[G3588]] WTT-ASN **τριτον** *triton* trzecią [[G5154]] WTA-ASN **των** *tōn* (część) [[G3588]] WTT-GPM **ανθρωπων** *anthrōpōn* ludzi [[G444]] WTN-GPM
###### **Ap 9,16**
 **και** *kai* A [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **αριθμος** *arithmos* liczba [[G706]] [[N-NSM]] **στρατευματων** *strateumatōn* wojsk [[G4753]] WTN-GPN **του** *tou* [[G3588]] WTT-GSN **ιππικου** *hippikou* konnicy – jeźdźców [[G2461]] [[A-GSN]] **δυο** *dyo* dwie [[G1417]] WTA-NUI **μυριαδες** *myriades* dziesiątki tysięcy – miriady [[G3461]] WTA-NPM **μυριαδων** *myriadōn* dziesiątków tysięcy – miriad [[G3461]] WTA-GPM **και** *kai* i [[G2532]] [[CONJ]] **ηκουσα** *ēkousa* usłyszałem [[G191]] WTV-AAI-1S **τον** *ton* [[G3588]] [[T-ASM]] **αριθμον** *arithmon* liczbę [[G706]] [[N-ASM]] **αυτων** *autōn* ich [[G846]] WTP-GPN
###### **Ap 9,17**
 **και** *kai* I [[G2532]] [[CONJ]] **ουτως** *houtōs* tak [[G3779]] [[ADV]] **ειδον** *eidon* zobaczyłem [[G1492]] WTV-2AAI-1S **τους** *tous* [[G3588]] WTT-APM **ιππους** *hippous* konie [[G2462]] [[N-APM]] **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **ορασει** *horasei* widzeniu – wizji [[G3706]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **τους** *tous* [[G3588]] WTT-APM **καθημενους** *kathēmenous* siedzących [[G2521]] WTV-PNP-APM **επ** *ep* na [[G1909]] [[PREP]] **αυτων** *autōn* nich [[G846]] WTP-GPM **εχοντας** *echontas* mających [[G2192]] WTV-PAP-APM **θωρακας** *thōrakas* pancerze [[G2382]] [[N-APM]] **πυρινους** *pyrinous* ognistych czerwieni [[G4447]] WTA-APM **και** *kai* i [[G2532]] [[CONJ]] **υακινθινους** *hyakinthinous* hiacyntowe [[G5191]] WTA-APM **και** *kai* i [[G2532]] [[CONJ]] **θειωδεις** *theiōdeis* siarkawe [[G2306]] WTA-APM **και** *kai* i [[G2532]] [[CONJ]] **αι** *hai* [[G3588]] [[T-NPF]] **κεφαλαι** *kefalai* głowy [[G2776]] [[N-NPF]] **των** *tōn* [[G3588]] WTT-GPM **ιππων** *hippōn* koni [[G2462]] WTN-GPM **ως** *hōs* jak [[G5613]] [[ADV]] **κεφαλαι** *kefalai* głowy [[G2776]] [[N-NPF]] **λεοντων** *leontōn* lwów [[G3023]] WTN-GPM **και** *kai* i [[G2532]] [[CONJ]] **εκ** *ek* z [[G1537]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **στοματων** *stomatōn* ust [[G4750]] WTN-GPN **αυτων** *autōn* ich [[G846]] WTP-GPM **εκπορευεται** *ekporeuetai* wychodzi [[G1607]] WTV-PNI-3S **πυρ** *pyr* ogień [[G4442]] WTN-NSN **και** *kai* i [[G2532]] [[CONJ]] **καπνος** *kapnos* dym [[G2586]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **θειον** *theion* siarka [[G2303]] WTN-NSN
###### **Ap 9,18**
 **υπο** *hypo* Przez [[G5259]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **τριων** *triōn* trzech [[G5140]] WTA-GPM **τουτων** *toutōn* tych [[G5130]] WTD-GPM **απεκτανθησαν** *apektanthēsan* zostali zabici [[G615]] WTV-API-3P **το** *to* [[G3588]] WTT-NSN **τριτον** *triton* trzecia [[G5154]] WTA-NSN **των** *tōn* (część) [[G3588]] WTT-GPM **ανθρωπων** *anthrōpōn* ludzi [[G444]] WTN-GPM **εκ** *ek* od [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **πυρος** *pyros* ognia [[G4442]] [[N-GSN]] **και** *kai* i [[G2532]] [[CONJ]] **εκ** *ek* od [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **καπνου** *kapnou* dymu [[G2586]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **εκ** *ek* od [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **θειου** *theiou* siarki [[G2303]] [[N-GSN]] **του** *tou* [[G3588]] WTT-GSN **εκπορευομενου** *ekporeuomenou* wychodzącej [[G1607]] WTV-PNP-GSN **εκ** *ek* z [[G1537]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **στοματων** *stomatōn* ust [[G4750]] WTN-GPN **αυτων** *autōn* ich [[G846]] WTP-GPM
###### **Ap 9,19**
 **η** *hē* [[G3588]] [[T-NSF]] **γαρ** *gar* Bowiem [[G1063]] [[CONJ]] **εξουσια** *eksousia* władza [[G1849]] [[N-NSF]] **αυτων** *autōn* ich [[G846]] WTP-GPM **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **στοματι** *stomati* ustach [[G4750]] WTN-DSN **αυτων** *autōn* ich [[G846]] WTP-GPM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **ουραις** *ourais* ogonach [[G3769]] WTN-DPF **αυτων** *autōn* ich [[G846]] WTP-GPM **αι** *hai* [[G3588]] [[T-NPF]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ουραι** *ourai* ogony [[G3769]] [[N-NPF]] **αυτων** *autōn* ich [[G846]] WTP-GPM **ομοιαι** *homoiai* podobne [[G3664]] [[A-NPF]] **οφεσιν** *ofesin* wężom [[G3789]] WTN-DPM **εχουσαι** *echousai* mające [[G2192]] WTV-PAP-NPF **κεφαλας** *kefalas* głowy [[G2776]] WTN-APF **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **αυταις** *autais* nich [[G846]] WTP-DPF **αδικουσιν** *adikousin* czynią niesprawiedliwość – krzywdzą [[G91]] WTV-PAI-3P
###### **Ap 9,20**
 **και** *kai* A [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **λοιποι** *loipoi* pozostali [[G3062]] WTA-NPM **των** *tōn* (z) [[G3588]] WTT-GPM **ανθρωπων** *anthrōpōn* ludzi [[G444]] WTN-GPM **οι** *hoi* którzy [[G3739]] WTR-NPM **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **απεκτανθησαν** *apektanthēsan* zostali zabici [[G615]] WTV-API-3P **εν** *en* w [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **πληγαις** *plēgais* ciosach – razach [[G4127]] WTN-DPF **ταυταις** *tautais* tych [[G3778]] WTD-DPF **ου** *hou* nie [[G3756]] [[PRT-N]] **μετενοησαν** *metenoēsan* opamiętali się – zmienili myślenie [[G3340]] WTV-AAI-3P **εκ** *ek* od [[G1537]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **εργων** *ergōn* dzieł – uczynków [[G2041]] WTN-GPN **των** *tōn* [[G3588]] WTT-GPF **χειρων** *cheirōn* rąk [[G5495]] WTN-GPF **αυτων** *autōn* ich [[G846]] WTP-GPM **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **προσκυνησωσιν** *proskynēsōsin* oddaliby cześć – pokłoniliby się [[G4352]] WTV-AAS-3P **τα** *ta* [[G3588]] WTT-APN **δαιμονια** *daimonia* demonom [[G1140]] WTN-APN **και** *kai* i [[G2532]] [[CONJ]] **ειδωλα** *eidōla* bożkom – fałszywym bogom [[G1497]] WTN-APN **τα** *ta* [[G3588]] WTT-APN **χρυσα** *chrysa* złotym [[G5552]] WTA-APN **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **αργυρα** *argyra* srebrnym [[G693]] WTA-APN **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **χαλκα** *chalka* brązowym – mosiężnym [[G5470]] WTA-APN **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **λιθινα** *lithina* kamiennym [[G3035]] WTA-APN **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **ξυλινα** *ksylina* drewnianym [[G3585]] WTA-APN **α** *ha* które [[G3739]] WTR-APN **ουτε** *oute* ani [[G3777]] [[CONJ]] **βλεπειν** *blepein* widzieć [[G991]] WTV-PAN **δυναται** *dynatai* może (mogą) [[G1410]] WTV-PNI-3S **ουτε** *oute* ani [[G3777]] [[CONJ]] **ακουειν** *akouein* słuchać [[G191]] WTV-PAN **ουτε** *oute* ani [[G3777]] [[CONJ]] **περιπατειν** *peripatein* chodzić [[G4043]] WTV-PAN
###### **Ap 9,21**
 **και** *kai* I [[G2532]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **μετενοησαν** *metenoēsan* opamiętali się – zmienili myślenie [[G3340]] WTV-AAI-3P **εκ** *ek* od [[G1537]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **φονων** *fonōn* morderstw [[G5408]] WTN-GPM **αυτων** *autōn* ich [[G846]] WTP-GPM **ουτε** *oute* ani [[G3777]] [[CONJ]] **εκ** *ek* od [[G1537]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPF **φαρμακειων** *farmakeiōn* czarów – guseł [[G5331]] WTN-GPF **αυτων** *autōn* ich [[G846]] WTP-GPM **ουτε** *oute* ani [[G3777]] [[CONJ]] **εκ** *ek* od [[G1537]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **πορνειας** *porneias* nierządu – wszeteczeństwa [[G4202]] [[N-GSF]] **αυτων** *autōn* ich [[G846]] WTP-GPM **ουτε** *oute* ani [[G3777]] [[CONJ]] **εκ** *ek* od [[G1537]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **κλεμματων** *klemmatōn* kradzieży [[G2809]] WTN-GPN **αυτων** *autōn* ich [[G846]] WTP-GPM
