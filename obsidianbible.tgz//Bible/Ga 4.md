# Ga 4 BT5
###### **Ga 4,1**
 A to mówię: Jak długo dziedzic jest nieletni, niczym się nie różni od niewolnika, chociaż jest właścicielem wszystkiego.
###### **Ga 4,2**
 Aż do czasu określonego przez ojca podlega on opiekunom i rządcom.
###### **Ga 4,3**
 My również, dopóki byliśmy nieletni, pozostawaliśmy w niewoli "żywiołów tego świata".
###### **Ga 4,4**
  Gdy jednak nadeszła pełnia czasu, zesłał Bóg Syna swego, zrodzonego z Niewiasty, zrodzonego pod Prawem,
###### **Ga 4,5**
 aby wykupił tych, którzy podlegali Prawu, byśmy mogli otrzymać przybrane synostwo.
###### **Ga 4,6**
 Na dowód tego, że jesteście synami, Bóg zesłał do serc naszych Ducha Syna swego, który woła: «***Abba, Ojcze!***»
###### **Ga 4,7**
 A zatem nie jesteś już niewolnikiem, lecz synem. Jeżeli zaś synem, to i dziedzicem z woli Bożej.
###### **Ga 4,8**
 Wprawdzie ongiś, nie znając Boga, służyliście bogom, którzy w rzeczywistości nie istnieją.
###### **Ga 4,9**
 Teraz jednak, gdyście Boga poznali i, co więcej, Bóg was poznał, jakże możecie powracać do tych bezsilnych i nędznych żywiołów, pod których niewolę znowu chcecie się poddać?
###### **Ga 4,10**
 Zachowujecie dni, święta nowiu i lata!
###### **Ga 4,11**
 Obawiam się o was, czy się dla was nie trudziłem na próżno.
###### **Ga 4,12**
 Bracia, proszę was, stańcie się takimi jak ja, bo ja stałem się takim jak wy. Nie skrzywdziliście mnie w niczym.
###### **Ga 4,13**
 Wiecie przecież, jak pierwszy raz głosiłem wam Ewangelię, zatrzymany chorobą,
###### **Ga 4,14**
 i jak mimo próby, na jaką moje niedomaganie cielesne was wystawiło, nie wzgardziliście mną ani nie odtrąciliście, ale mnie przyjęliście jak anioła Bożego, jak samego Chrystusa Jezusa.
###### **Ga 4,15**
 Gdzież się więc podziało to, co nazywaliście waszym szczęściem? Bo mogę wydać wam świadectwo: gdyby to było możliwe, bylibyście sobie oczy wydarli i dali je mnie.
###### **Ga 4,16**
 Czy dlatego stałem się waszym wrogiem, że mówiłem wam prawdę?
###### **Ga 4,17**
 Zabiegają o was nie z czystych pobudek, lecz chcą was odłączyć [ode mnie], abyście o nich zabiegali.
###### **Ga 4,18**
 Dobrze jest doznawać oznak przywiązania z czystych pobudek zawsze, a nie tylko wtedy, gdy jestem między wami.
###### **Ga 4,19**
 Dzieci moje, oto ponownie w bólach was rodzę, aż Chrystus w was się ukształtuje.
###### **Ga 4,20**
 Jakże chciałbym być w tej chwili u was i odpowiednio zmienić swój głos, bo nie wiem, co z wami począć.
###### **Ga 4,21**
 Powiedzcie mi [wy], którzy chcecie żyć pod Prawem, czy Prawa tego nie rozumiecie?
###### **Ga 4,22**
 Przecież napisane jest, że Abraham miał dwóch synów, jednego z niewolnicy, a drugiego z wolnej.
###### **Ga 4,23**
 Lecz ten z niewolnicy urodził się tylko według ciała, ten zaś z wolnej – na skutek obietnicy.
###### **Ga 4,24**
 Wydarzenia te mają jeszcze sens alegoryczny: niewiasty te wyobrażają dwa przymierza; jedno, zawarte pod górą Synaj, rodzi ku niewoli, a wyobraża je Hagar:
###### **Ga 4,25**
 Synaj jest to góra w Arabii, a odpowiednikiem jej jest obecne Jeruzalem. Ono bowiem wraz ze swoimi dziećmi trwa w niewoli.
###### **Ga 4,26**
 Natomiast górne Jeruzalem cieszy się wolnością i ono jest naszą matką.
###### **Ga 4,27**
 Wszak napisane jest: Wesel się, niepłodna, która nie rodziłaś, wykrzykuj z radości, która nie znałaś bólów rodzenia, bo więcej dzieci ma samotna niż ta, która żyje z mężem.
###### **Ga 4,28**
 Właśnie wy, bracia, jesteście jak Izaak dziećmi obietnicy.
###### **Ga 4,29**
 Ale jak wówczas ten, który się urodził tylko według ciała, prześladował tego, który się urodził według ducha, tak dzieje się i teraz.
###### **Ga 4,30**
 Co jednak mówi Pismo? Wypędź niewolnicę i jej syna, bo nie będzie dziedziczyć syn niewolnicy razem z synem wolnej.
###### **Ga 4,31**
 Tak to, bracia, nie jesteśmy dziećmi niewolnicy, ale wolnej.
# Ga 4 PAU
###### **Ga 4,1**
 Otóż i to wam powiem: Jak długo dziedzic jest dzieckiem, nie różni się od niewolnika, choć jest panem wszystkiego;
###### **Ga 4,2**
 do czasu wyznaczonego przez ojca poddany jest opiekunom i zarządcom.
###### **Ga 4,3**
 Podobnie i my. Kiedy byliśmy dziećmi, byliśmy poddani żywiołom świata.
###### **Ga 4,4**
 Gdy jednak wypełnił się czas, Bóg wysłał swego Syna zrodzonego z kobiety, narodzonego w czasach Prawa,
###### **Ga 4,5**
 aby uwolnić tych, którzy podlegali Prawu, abyśmy się stali przybranymi dziećmi.
###### **Ga 4,6**
 A ponieważ jesteście synami, Bóg wysłał do naszych serc Ducha swego Syna, który woła: „Abba, Ojcze!”.
###### **Ga 4,7**
 Tak więc nie jesteś już niewolnikiem, lecz synem, a jeśli synem, to i dziedzicem z woli Boga.
###### **Ga 4,8**
 Wtedy jednak, kiedy nie znaliście Boga, służyliście bóstwom, które w rzeczywistości nie istnieją.
###### **Ga 4,9**
 Ale teraz, kiedy poznaliście Boga, albo raczej, kiedy przez Boga zostaliście rozpoznania, jak możecie zwracać się znów ku bezsilnym i marnym żywiołom, pragnąc na nowo im służyć?
###### **Ga 4,10**
 Zwracacie uwagę na dni, miesiące, pory roku i lata.
###### **Ga 4,11**
 Obawiam się, czy nie na próżno trudziłem się dla was.
###### **Ga 4,12**
 Proszę was, bracia, stańcie się tacy, jak ja, ponieważ ja stałem się taki, jak wy. W niczym mnie nie skrzywdziliście.
###### **Ga 4,13**
 Pamiętacie przecież, że za pierwszym razem głosiłem wam Ewangelię, gdy byłem chory.
###### **Ga 4,14**
 W próbie, na jaką wystawiła was moja choroba, nie okazaliście mi wzgardy ani odrazy, ale przyjęliście mnie jak anioła Bożego, jak Chrystusa Jezusa.
###### **Ga 4,15**
 Gdzie się podziała wasza radość? Zaświadczam, że gdyby to tylko było możliwe, wyłupilibyście sobie oczy, aby dać je mnie.
###### **Ga 4,16**
 Czy mówiąc wam prawdę, stałem się waszym wrogiem?
###### **Ga 4,17**
 Tamci troszczą się o was nieszczerze, bo chcą was oderwać ode mnie, abyście związali się z nimi.
###### **Ga 4,18**
 Otóż byłoby dobrze, gdybyście doznawali prawdziwej troski zawsze, a nie tylko wtedy, kiedy jestem z wami.
###### **Ga 4,19**
 Moje dzieci, ponownie w bólach was rodzę, aż Chrystus ukształtuje się w was.
###### **Ga 4,20**
 Chciałbym być teraz wśród was i odpowiednio przemówić, bo już nie wiem, jak z wami postąpić.
###### **Ga 4,21**
 Powiedzcie mi, wy, którzy chcecie pozostawać pod władzą Prawa: Czy nie czytacie Prawa?
###### **Ga 4,22**
 Napisane jest przecież, że Abraham miał dwóch synów: jednego z niewolnicy, a drugiego z wolnej.
###### **Ga 4,23**
 Ten z niewolnicy urodził się według ciała, a ten z wolnej - według obietnicy.
###### **Ga 4,24**
 Jest w tym głębszy sens. Kobiety wyobrażają dwa przymierza. Hagar oznacza przymierze z góry Synaj, które rodzi do niewoli.
###### **Ga 4,25**
 Ta właśnie Hagar to góra Synaj w Arabii. Symbolizuje ona obecną Jerozolimę, która wraz ze swymi dziećmi znajduje się w niewoli.
###### **Ga 4,26**
 Jerozolima, która jest na wysokości, jest natomiast wolna i ona jest naszą matką.
###### **Ga 4,27**
 Napisano bowiem: Ciesz się, niepłodna, która nie rodziłaś, wykrzykuj i wołaj, która nie zaznałaś bólów rodzenia! Bo liczniejsze są dzieci opuszczonej niż tej, która ma męża.
###### **Ga 4,28**
 A wy, bracia, jesteście dziećmi obietnicy, tak jak Izaak.
###### **Ga 4,29**
 Ale tak jak wtedy, ten, który urodził się według ciała, prześladował urodzonego według ducha, tak jest i teraz.
###### **Ga 4,30**
 I co mówi Pismo? Wypędź niewolnicę i jej syna, bo nie będzie dziedziczyć syn niewolnicy razem z synem wolnej.
###### **Ga 4,31**
 Otóż, bracia, nie jesteśmy dziećmi niewolnicy, ale wolnej.
# Ga 4 BP
###### **Ga 4,1**
 A powiadam, że dopóki spadkobierca jest małoletni, w niczym nie różni się od niewolnika. Choć jest panem wszystkiego,
###### **Ga 4,2**
 to jednak poddany jest nadzorcom i zarządcom aż do dnia ustalonego przez ojca.
###### **Ga 4,3**
 Tak jest i z nami. Będąc małoletnimi, byliśmy oddani w niewolę spraw świata.
###### **Ga 4,4**
 Gdy zaś wypełnił się czas, Bóg zesłał swego Syna, który urodził się z kobiety, urodził się pod panowaniem Prawa,
###### **Ga 4,5**
 aby uwolnić tych, którzy byli pod panowaniem Prawa, abyśmy otrzymali przybrane synostwo.
###### **Ga 4,6**
 Aby zaś udowodnić, że jesteście synami, Bóg zesłał do naszych serc Ducha Syna swego, który woła: Abba, Ojcze!
###### **Ga 4,7**
 Nie jesteś już niewolnikiem, lecz synem. A jeśli jesteś synem, to i spadkobiercą - z łaski Boga.
###### **Ga 4,8**
 Kiedyś wprawdzie, gdy nie znaliście Boga, byliście niewolnikami tego wszystkiego, co w rzeczywistości nie jest Bogiem.
###### **Ga 4,9**
 Teraz zaś, gdy poznaliście Boga - a jeszcze bardziej Bóg was poznał - jakżeż możecie znów powracać do słabych i nędznych spraw? Czyż ponownie chcecie być w ich niewoli?
###### **Ga 4,10**
 Dokładnie przestrzegacie dni, miesięcy, pór roku i lat.
###### **Ga 4,11**
 Lękam się, że na próżno trudziłem się dla was.
###### **Ga 4,12**
 Proszę was, bracia, stańcie się tacy jak ja, ponieważ ja stałem się taki jak wy. Nie wyrządziliście mi w niczym krzywdy.
###### **Ga 4,13**
 Wiecie natomiast, że gdy po raz pierwszy głosiłem wam ewangelię, trapiła mnie choroba,
###### **Ga 4,14**
 natomiast wy nie tylko nie wzgardziliście mną i nie odepchnęliście mnie, choć moje ciało mogło dawać do tego powód, lecz przyjęliście mnie jak wysłańca Boga, jak samego Chrystusa Jezusa.
###### **Ga 4,15**
 Gdzież więc wasz tytuł do szczęścia? Mogę bowiem wam oświadczyć, że - gdyby to było możliwe - wyjęlibyście sobie oczy i dalibyście je mnie.
###### **Ga 4,16**
 Czyż więc, mówiąc wam prawdę, stałem się waszym wrogiem?
###### **Ga 4,17**
 Sprzyjają wam nieszczerze, bo chcą was oddzielić, abyście wy im sprzyjali.
###### **Ga 4,18**
 Przyjemnie mi jest, gdy zawsze szczerą darzycie mnie życzliwością, a nie tylko wtedy, gdy jestem wśród was obecny.
###### **Ga 4,19**
 Dzieci moje najmilsze! Znów rodzę was w boleściach, aż ukształtuje się w was Chrystus.
###### **Ga 4,20**
 Chciałbym już teraz być wśród was i odpowiednio do was przemówić, gdyż nawiedzają mnie wątpliwości w waszej sprawie.
###### **Ga 4,21**
 Powiedzcie mi, wy, którzy chcecie być pod panowaniem Prawa! Czy nie słyszycie, co mówi Prawo?
###### **Ga 4,22**
 Napisano przecież, że Abraham miał dwóch synów: jeden był zrodzony z niewolnicy, a drugi z wolnej.
###### **Ga 4,23**
 Syn z niewolnicy był zrodzony zwyczajnie, według praw ciała, a syn z wolnej - dzięki obietnicy.
###### **Ga 4,24**
 Ma to znaczenie przenośne. Kobiety te bowiem oznaczają dwa przymierza: jedno zawarte na górze Synaj - rodzące niewolę - wyobraża je Hagar.
###### **Ga 4,25**
 Symbolizuje ona górę Synaj, która znajduje się w Arabii. Obecnie zaś Hagar wyobraża Jeruzalem, ponieważ jest ono w niewoli ze swoimi dziećmi.
###### **Ga 4,26**
 Jeruzalem zaś górne cieszy się wolnością. Ono to właśnie jest naszą matką.
###### **Ga 4,27**
 Napisano bowiem: "Ciesz się, niepłodna, która nie rodziłaś, wykrzykuj z radości ty, która nie doznałaś bólów rodzenia, gdyż więcej dzieci mieć będzie kobieta opuszczona, niż ta, która jest zamężna".
###### **Ga 4,28**
 Właśnie wy, bracia, jesteście - jak Izaak - dziećmi obietnicy.
###### **Ga 4,29**
 Lecz jak niegdyś syn zrodzony zwyczajnie, według praw ciała, prześladował syna zrodzonego według praw ducha, tak jest i teraz.
###### **Ga 4,30**
 Ale co mówi Pismo? "Wypędź niewolnicę i jej syna, gdyż syn niewolnicy nigdy nie będzie spadkobiercą razem z synem" wolnej.
###### **Ga 4,31**
 Dlatego, bracia, nie jesteśmy dziećmi niewolnicy, lecz wolnej.
# Ga 4 BR
###### **Ga 4,1**
 Pragnę wam przypomnieć jeszcze i to, że dopóki ten, który ma coś odziedziczyć, jest jeszcze dzieckiem, nie różni się od niewolnika, chociaż jest już właścicielem wszystkiego.
###### **Ga 4,2**
 Pozostaje jednak, aż do czasu ustanowionego przez ojca, pod władzą tych, którzy się nim opiekują i zarządzają jego majątkiem.
###### **Ga 4,3**
 I my również, jak długo byliśmy dziećmi, pozostawaliśmy w więzach żywiołów tego świata.
###### **Ga 4,4**
 Lecz kiedy nadeszła [z dawna określona] pełnia czasu, posłał Bóg Syna swego - który narodził się z niewiasty i był poddany przepisom Prawa [żydowskiego] -
###### **Ga 4,5**
 po to, aby uwolnił tych wszystkich, którzy podlegali Prawu, i abyśmy mogli stać się w ten sposób przybranymi dziećmi Boga.
###### **Ga 4,6**
 A na dowód tego, żeście dziećmi Boga, sprawił Bóg, że w naszych sercach zamieszkał Duch Jego Syna, Duch, który woła: Abba, to znaczy: Ojcze!
###### **Ga 4,7**
 Tak więc nie jesteśmy już niewolnikami, lecz synami, a jeżeli jesteśmy synami - to dziedziczymy również dobra, które Bóg zechciał dla nas przeznaczyć.
###### **Ga 4,8**
 To prawda, że kiedyś nie znając Boga, służyliście bogom, których w rzeczywistości wcale nie ma.
###### **Ga 4,9**
 Ale teraz, kiedy już znacie Boga - lub raczej : kiedy Bóg już poznał was - to jakże możecie znów powracać do tych bezsilnych i nędznych żywiołów, żeby na nowo popaść w ich niewolę?
###### **Ga 4,10**
 Przywiązujecie tak wielką wagę do niektórych dni, miesięcy, pewnych pór roku lub całych lat.
###### **Ga 4,11**
 Obawiam się, czy aby nie na próżno trudziłem się dla was.
###### **Ga 4,12**
 Bracia, proszę was, bądźcie tacy jak ja, bo ja stałem się taki jak wy. Nie wyrządziliście mi żadnej krzywdy.
###### **Ga 4,13**
 Pamiętacie przecież, jak po raz pierwszy zjawiłem się wśród was, by głosić Dobrą Nowinę. Byłem wtedy chory.
###### **Ga 4,14**
 Ale wy, mimo próby, na jaką byliście narażeni wskutek niedomagań mojego ciała, nie wzgardziliście mną ani nie odrzuciliście mnie, lecz przeciwnie, przyjęliście mnie jak anioła Bożego albo jak samego Jezusa Chrystusa.
###### **Ga 4,15**
 Byliście przecież tacy szczęśliwi! Gdzież się podziało to wasze szczęście? Byliście przecież gotowi - mówię to z całą świadomością - wyłupić sobie, jeśliby to było możliwe, własne oczy i oddać je mnie.
###### **Ga 4,16**
 Czyż obecnie stałem się waszym wrogiem przez to, że mówię wam prawdę?
###### **Ga 4,17**
 Ludzie, którzy próbują przeciągnąć was na swoją stronę, nie czynią tego z czystych pobudek. Pragną wprowadzić rozdźwięk między mną a wami po to, żebyście poszli za nimi.
###### **Ga 4,18**
 Otóż byłoby dobrze, gdybym mógł odczuwać wasze szlachetne przywiązanie do mnie zawsze, a nie tylko, gdy wśród was przebywam.
###### **Ga 4,19**
 Dzieci moje! Oto ponownie rodzę was w bólach tak, byście w końcu ukazali kształty Chrystusa.
###### **Ga 4,20**
 O, jak bardzo chciałbym być teraz wsród was i przemawiać do was całkiem innym głosem! Jestem naprawdę zaniepokojony o was.
###### **Ga 4,21**
 Powiedzcie mi, wy, którzy chcecie znów poddać się Prawu: czy wy nie rozumiecie tego, co mówi Prawo?
###### **Ga 4,22**
 Otóż Prawo mówi [między innymi], że Abraham miał dwu synów: jednego matką była niewolnica, drugiego - kobieta wolna.
###### **Ga 4,23**
 Ten, którego matką była niewolnica, przyszedł na świat w sposób cielesny, ten zaś, którego matką była kobieta wolna, narodził się na mocy obietnicy [Bożej].
###### **Ga 4,24**
 Historia tych narodzin posiada również głębszy sens: Dwie kobiety-matki wyobrażają dwa przymierza. Jedno z nich - przedstawia je Hagar - zostało zawarte na górze Synaj i ono daje początek pokoleniu rodzącemu się do niewolnictwa.
###### **Ga 4,25**
 Synaj - to góra w Arabii; jej odpowiednikiem jest dzisiejsza Jerozolima, pozostająca razem ze swymi dziećmi w niewoli.
###### **Ga 4,26**
 Natomiast Jerozolima niebieska jest wolna i to ją właśnie mamy za naszą matkę.
###### **Ga 4,27**
 Napisane jest bowiem: Raduj się; niewiasto niepłodna, któraś nigdy nie miała potomstwa; wołaj ze szczęścia ty, któraś nigdy nie zaznała bólów rodzenia. Bo niezamężna więcej będzie mieć dzieci niż ta, która posiada małżonka.
###### **Ga 4,28**
 Otóż to wy, bracia, jesteście zrodzeni wskutek obietnicy, zupełnie tak jak Izaak.
###### **Ga 4,29**
 I podobnie jak kiedyś ten, który przyszedł na świat w sposób cielesny, prześladował tego, który się urodził według Ducha Bożego, tak też i teraz.
###### **Ga 4,30**
 Lecz oto, co mówi Pismo: Wyrzuć niewolnicę i jej syna, bo dziecko niewolnicy nie może mieć udziału w dobrach ojcowskich razem z synem wolnej.
###### **Ga 4,31**
 Pamiętajcie więc, bracia: nie jesteśmy dziećmi niewolnicy, ale wolnej !
# Ga 4 WUJ
###### **Ga 4,1**
 A mówię, jako długo dziedzic jest dziecięciem, nic nie jest różny od sługi, będąc panem wszystkiego:
###### **Ga 4,2**
 Ale jest pod opiekuny i sprawcami aż do zamierzonego czasu od ojca:
###### **Ga 4,3**
 Także i my, gdyśmy byli dziećmi, byliśmy pod elementy świata.
###### **Ga 4,4**
 Lecz gdy przyszło wypełnienie czasu, zesłał Bóg syna swego uczynionego z niewiasty, uczynionego pod zakonem:
###### **Ga 4,5**
 Aby te, którzy pod zakonem byli, wykupił, żebyśmy przysposobienia synowskiego dostali.
###### **Ga 4,6**
 A iż jesteście synowie: zesłał Bóg ducha syna swego w serca wasze wołającego Abba, Ojcze.
###### **Ga 4,7**
 A tak już nie jest niewolnikiem, ale synem: a jeśli synem: tedyć i dziedzicem przez Boga.
###### **Ga 4,8**
 Aleć na on czas, nie znając Boga, służyliście tym, którzy z przyrodzenia nie są Bogowie.
###### **Ga 4,9**
 A teraz poznawszy Boga, i owszem poznani będąc od Boga: jakoż się zaś nawracacie ku elementom mdłym i niedostatecznym, którym zasię z nowu służyć chcecie?
###### **Ga 4,10**
 Pilnujecie dni, i miesięcy, i czasów, i roków.
###### **Ga 4,11**
 Boję się o was, bym snadź darmo nie pracował około was.
###### **Ga 4,12**
 Bądźcież jako ja, gdyżem i ja jako wy: Bracia, proszę was, w niwczemeście mię nie obrazili.
###### **Ga 4,13**
 A wiecie, iżem już dawno przez krewkość ciała przepowiadał was Ewanielią:
###### **Ga 4,14**
 A pokusy waszej w ciele mojem nie lekceście ważyli, aniście odrzucili: aleście mię przyjęli jako Anioła Bożego, jako Chrystusa Jezusa.
###### **Ga 4,15**
 Gdzież tedy jest błogosławieństwo wasze? Abowiem świadectwo wam daję, iż, by była rzecz można, oczy wasze wyłupilibyście byli, i dalibyście mi byli.
###### **Ga 4,16**
 Więcem się wam stał nieprzyjacielem, prawdę wam mówiąc?
###### **Ga 4,17**
 Miłują was nie dobrze, ale was chcą wypchnąć, abyście ich naśladowali.
###### **Ga 4,18**
 A dobrego naśladujcie zawżdy w dobrym: a nie tylko, gdym jest obecny u was.
###### **Ga 4,19**
 Dziatki moje, które zaś bolejąc rodzę, ażby był Chrystus w was wykształtowan.
###### **Ga 4,20**
 A chciałbym teraz być u was, i odmienić głos mój: przeto iż wątpię o was.
###### **Ga 4,21**
 Powiedzcie mi, którzy pod zakonem chcecie być, zakonuście nie czytali?
###### **Ga 4,22**
 Abowiem napisano jest, iż Abraham miał dwu synów: jednego z niewolnice, a drugiego z wolnej.
###### **Ga 4,23**
 Lecz który z niewolnice, według ciała się narodził: a który z wolnej, przez obietnicę.
###### **Ga 4,24**
 Co przez Allegorią powiedziano jest. Abowiem te są dwa testamenty. Jeden na górze Sinai, rodzący w niewolą: która jest Agar.
###### **Ga 4,25**
 Abowiem Sina jest góra w Arabiej: przyrównywa się do tego, które teraz jest Jeruzalem, i w niewolej jest z synami swymi.
###### **Ga 4,26**
 A ono, które wzgórę jest Jeruzalem, wolne jest: które jest matka nasza.
###### **Ga 4,27**
 Abowiem napisano jest: Wesel się niepłodna, która nie rodzisz: zakrzykni a zawołaj, która rodząc nie pracujesz: bo wiele synów opuszczonej, więcej niż tej, która ma męża.
###### **Ga 4,28**
 A my bracia, według Izaaka jesteśmy synami obietnice.
###### **Ga 4,29**
 Ale jako na on czas ten, który się był narodził wedle ciała, prześladował tego, który wedle ducha: tak i teraz.
###### **Ga 4,30**
 Ale co mówi pismo? Wyrzuć niewolnicę i syna jej: abowiem nie będzie dziedzicem syn niewolnice z synem wolnej:
###### **Ga 4,31**
 A tak bracia, nie jesteśmy synami niewolnice, ale wolnej: którą wolnością nas Chrystus wolne uczynił.
# Ga 4 STERN
###### **Ga 4,1**
 Chodzi mi o to, że póki dziedzic jest niepełnoletni, nie różni się od niewolnika, mimo że jest prawowitym właścicielem majątku,
###### **Ga 4,2**
 lecz jest poddany strażnikom i opiekunom aż do czasu wyznaczonego przez ojca.
###### **Ga 4,3**
 Tak jest i z nami - kiedy byliśmy "dziećmi", byliśmy niewolnikami duchów żywiołów wszechświata,
###### **Ga 4,4**
 ale gdy nastał wyznaczony czas, Bóg posłał swego Syna. Narodził się On z kobiety, narodził się w kulturze, gdzie legalistyczne wypaczenie Tory było normą,
###### **Ga 4,5**
 aby odkupić poddanych temu legalizmowi i w ten sposób sprawić, żebyśmy mogli się stać synami Bożymi.
###### **Ga 4,6**
 A skoro jesteście synami, Bóg posłał do waszych serc Ducha swego Syna, Ducha, który woła: "Abba!" (czyli "Drogi Ojcze!").
###### **Ga 4,7**
 Za sprawą więc Boga nie jesteś już niewolnikiem, ale synem, a jeśli jesteś synem, to i dziedzicem.
###### **Ga 4,8**
 W przeszłości, gdy nie znaliście Boga, jako niewolnicy służyliście istotom, które w rzeczywistości są nie-bogami.
###### **Ga 4,9**
 Lecz teraz naprawdę znacie Boga i - więcej jeszcze - Bóg was zna. Jak to więc możliwe, że zwracacie się z powrotem do tych słabych i nędznych duchów żywiołów? Chcecie ponownie oddać się im w niewolę?
###### **Ga 4,10**
 Przestrzegacie szczególnych dni, miesięcy, pór i lat!
###### **Ga 4,11**
 Obawiam się o was, czy moja praca wśród was nie poszła na marne!
###### **Ga 4,12**
 Błagam was, bracia, postawcie się w moim położeniu - bo bądź co bądź ja postawiłem się w waszym. Nie chodzi o to, że mnie jakoś skrzywdziliście -
###### **Ga 4,13**
 wiecie, że na początku głosiłem wam Dobrą Nowinę dlatego, że chorowałem,
###### **Ga 4,14**
 i mimo że ze względu na moje fizyczne samopoczucie mogliście traktować mnie z pogardą, nie okazaliście mi w najmniejszym stopniu lekceważenia czy odrazy. Nie, przyjęliście mnie tak, jak gdybym był aniołem Bożym, jak gdybym był samym Mesjaszem Jeszuą!
###### **Ga 4,15**
 Cóż się więc stało z tą radością, którą odczuwaliście? Bo mogę o was zaświadczyć, że gdyby to było możliwe, oczy byście sobie wyłupili i mnie je oddali.
###### **Ga 4,16**
 Stałem się wam wrogiem, bo mówię wam prawdę?
###### **Ga 4,17**
 Owszem, ci nauczyciele wykazują gorliwość o was, ale ich pobudki nie są dobre. Chcą was od nas oddzielić, abyście zaczęli gorliwie zabiegać o nich.
###### **Ga 4,18**
 Dobrze jest być gorliwym, zawsze jednak pod warunkiem, że chodzi o dobrą sprawę. Bo rzeczywiście, czy jestem z wami, czy też nie,
###### **Ga 4,19**
 drogie dzieci, cierpię bóle, rodząc was ponownie - i tak już będzie, aż się Mesjasz w was ukształtuje.
###### **Ga 4,20**
 Żałuję, że nie mogę teraz być wśród was i zmienić tonu głosu. Nie wiem, co z wami począć.
###### **Ga 4,21**
 Powiedzcie mi, wy, którzy chcecie poddać się systemowi zrodzonemu z wypaczenia Tory w legalizm - czy nie słyszycie, co mówi Tora właśnie?
###### **Ga 4,22**
 Mówi, że Awraham miał dwóch synów, jednego z niewolnicy i jednego z kobiety wolnej.
###### **Ga 4,23**
 Ten z niewolnicy narodził się według ograniczonych możliwości ludzkich, lecz ten z kobiety wolnej narodził się za sprawą działającej cuda mocy Boga, który wypełnił swą obietnicę.
###### **Ga 4,24**
 Ułóżmy z tych rzeczy midrasz: dwie kobiety to dwa przymierza. Jedno jest z góry Synaj i rodzi dzieci do niewolnictwa - to Hagar.
###### **Ga 4,25**
 Hagar to góra Synaj w Arabii, odpowiada ona obecnemu Jeruszalaim, bo służy jako niewolnica wraz ze swoimi dziećmi.
###### **Ga 4,26**
 Lecz Jeruszalaim na górze jest wolne i ono jest naszą matką;
###### **Ga 4,27**
 Tanach bowiem mówi: "Raduj się, niepłodna, która nie rodzisz dzieci! Wybuchnij radością i zakrzyknij, która nie jesteś w połogu! Bo małżonka porzucona więcej będzie mieć dzieci niż ta, z którą mąż pozostał!".
###### **Ga 4,28**
 Wy, bracia, jak Jic'chak, jesteście dziećmi, o których mowa w obietnicy Bożej.
###### **Ga 4,29**
 Lecz jak ten, który narodził się w ramach ograniczonych możliwości ludzkich, prześladował tego, który narodził się z nadprzyrodzonej mocy Ducha, tak jest i teraz.
###### **Ga 4,30**
 Mimo to - co mówi Tanach?. "Pozbądź się niewolnicy i jej syna, bo syn niewolnicy w żadnym razie nie będzie dziedziczył razem z synem kobiety wolnej!".
###### **Ga 4,31**
 A zatem, bracia, jesteśmy dziećmi nie niewolnicy, ale kobiety wolnej.
# Ga 4 TRO
###### **Ga 4,1**
 **λεγω** *legō* Mówię [[G3004]] WTV-PAI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **εφ** *ef* do [[G1909]] [[PREP]] **οσον** *hoson* jakiego – ile [[G3745]] WTK-ASM **χρονον** *chronon* czasu [[G5550]] [[N-ASM]] **ο** *ho* [[G3588]] [[T-NSM]] **κληρονομος** *klēronomos* dziedzic [[G2818]] [[N-NSM]] **νηπιος** *nēpios* niemowlę [[G3516]] [[A-NSM]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ουδεν** *ouden* nic [[G3762]] WTA-ASN **διαφερει** *diaferei* przewyższa – różni się [[G1308]] WTV-PAI-3S **δουλου** *doulou* niewolnika – sługę [[G1401]] [[N-GSM]] **κυριος** *kyrios* pan [[G2962]] [[N-NSM]] **παντων** *pantōn* wszystkich [[G3956]] WTA-GPM **ων** *ōn* będąc [[G5607]] [[V-PXP-NSM]]
###### **Ga 4,2**
 **αλλα** *alla* Ale [[G235]] [[CONJ]] **υπο** *hypo* pod [[G5259]] [[PREP]] **επιτροπους** *epitropous* dozorcami – zarządcami [[G2012]] [[N-APM]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **και** *kai* i [[G2532]] [[CONJ]] **οικονομους** *oikonomous* zarządcami [[G3623]] [[N-APM]] **αχρι** *achri* aż do [[G891]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **προθεσμιας** *prothesmias* ustalonego czasu – zamierzenia [[G4287]] [[N-GSF]] **του** *tou* (przez) [[G3588]] WTT-GSM **πατρος** *patros* ojca [[G3962]] [[N-GSM]]
###### **Ga 4,3**
 **ουτως** *houtōs* Tak [[G3779]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **ημεις** *hēmeis* my [[G2249]] WTP-1NP **οτε** *hote* gdy [[G3753]] [[ADV]] **ημεν** *ēmen* byliśmy [[G1510]] WTV-IXI-1P **νηπιοι** *nēpioi* niemowlęta [[G3516]] WTA-NPM **υπο** *hypo* pod [[G5259]] [[PREP]] **τα** *ta* [[G3588]] WTT-APN **στοιχεια** *stoicheia* elementami [[G4747]] WTN-APN **του** *tou* [[G3588]] WTT-GSM **κοσμου** *kosmou* świata [[G2889]] [[N-GSM]] **ημεν** *ēmen* byliśmy [[G1510]] WTV-IXI-1P **δεδουλωμενοι** *dedoulōmenoi* którzy są uczynieni niewolnikami – którzy są zniewoleni [[G1402]] WTV-RPP-NPM
###### **Ga 4,4**
 **οτε** *hote* Gdy [[G3753]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **ηλθεν** *ēlthen* przyszło [[G2064]] WTV-2AAI-3S **το** *to* [[G3588]] WTT-NSN **πληρωμα** *plērōma* wypełnienie [[G4138]] WTN-NSN **του** *tou* [[G3588]] WTT-GSM **χρονου** *chronou* czasu [[G5550]] [[N-GSM]] **εξαπεστειλεν** *eksapesteilen* posłał [[G1821]] [[V-AAI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **τον** *ton* [[G3588]] [[T-ASM]] **υιον** *hyion* Syna [[G5207]] [[N-ASM]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **γενομενον** *genomenon* który stał się [[G1096]] WTV-2ADP-ASM **εκ** *ek* z [[G1537]] [[PREP]] **γυναικος** *gynaikos* kobiety [[G1135]] [[N-GSF]] **γενομενον** *genomenon* który stał się [[G1096]] WTV-2ADP-ASM **υπο** *hypo* pod [[G5259]] [[PREP]] **νομον** *nomon* Prawem [[G3551]] [[N-ASM]]
###### **Ga 4,5**
 **ινα** *hina* aby [[G2443]] [[CONJ]] **τους** *tous* (tych) [[G3588]] WTT-APM **υπο** *hypo* pod [[G5259]] [[PREP]] **νομον** *nomon* Prawem [[G3551]] [[N-ASM]] **εξαγοραση** *eksagorasē* wykupiłby – odkupiłby [[G1805]] WTV-AAS-3S **ινα** *hina* aby [[G2443]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **υιοθεσιαν** *hyiothesian* usynowienia [[G5206]] WTN-ASF **απολαβωμεν** *apolabōmen* dostąpilibyśmy – odebralibyśmy [[G618]] WTV-2AAS-1P
###### **Ga 4,6**
 **οτι** *hoti* Że [[G3754]] [[CONJ]] **δε** *de* zaś [[G1161]] [[CONJ]] **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **υιοι** *hyioi* synowie [[G5207]] WTN-NPM **εξαπεστειλεν** *eksapesteilen* posłał [[G1821]] [[V-AAI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **το** *to* [[G3588]] WTT-ASN **πνευμα** *pneuma* Ducha [[G4151]] WTN-ASN **του** *tou* [[G3588]] WTT-GSM **υιου** *hyiou* Syna [[G5207]] [[N-GSM]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **εις** *eis* do [[G1519]] [[PREP]] **τας** *tas* [[G3588]] WTT-APF **καρδιας** *kardias* serc [[G2588]] WTN-APF **υμων** *hymōn* waszych [[G5216]] WTP-2GP **κραζον** *krazon* wołającego [[G2896]] WTV-PAP-ASN **αββα** *abba* Abba – [tata] [[G5]] [[N-PRI]] **ο** *ho* [[G3588]] [[T-NSM]] **πατηρ** *patēr* Ojcze [[G3962]] [[N-NSM]]
###### **Ga 4,7**
 **ωστε** *hōste* Tak, że [[G5620]] [[CONJ]] **ουκετι** *ouketi* już nie [[G3765]] [[ADV]] **ει** *ei* jesteś [[G1488]] WTV-PXI-2S **δουλος** *doulos* niewolnik – sługa [[G1401]] [[N-NSM]] **αλλ** *all* ale [[G235]] [[CONJ]] **υιος** *hyios* syn [[G5207]] [[N-NSM]] **ει** *ei* jeśli [[G1487]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **υιος** *hyios* syn [[G5207]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **κληρονομος** *klēronomos* dziedzic [[G2818]] [[N-NSM]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **δια** *dia* przez [[G1223]] [[PREP]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **Ga 4,8**
 **αλλα** *alla* Ale [[G235]] [[CONJ]] **τοτε** *tote* wtedy [[G5119]] [[ADV]] **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ειδοτες** *eidotes* znając [[G1492]] WTV-RAP-NPM **θεον** *theon* Boga [[G2316]] [[N-ASM]] **εδουλευσατε** *edouleusate* staliście się niewolnikami – staliście się sługami [[G1398]] WTV-AAI-2P **τοις** *tois* [[G3588]] WTT-DPM **μη** *mē* nie [[G3361]] [[PRT-N]] **φυσει** *fysei* naturą [[G5449]] [[N-DSF]] **ουσιν** *ousin* będących [[G5607]] WTV-PXP-DPM **θεοις** *theois* bogami [[G2316]] WTN-DPM
###### **Ga 4,9**
 **νυν** *nyn* Teraz [[G3568]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **γνοντες** *gnontes* poznawszy [[G1097]] WTV-2AAP-NPM **θεον** *theon* Boga [[G2316]] [[N-ASM]] **μαλλον** *mallon* raczej – bardziej [[G3123]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **γνωσθεντες** *gnōsthentes* którzy zostaliście poznani [[G1097]] WTV-APP-NPM **υπο** *hypo* przez [[G5259]] [[PREP]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **πως** *pōs* jak [[G4459]] [[ADV]]-I **επιστρεφετε** *epistrefete* odwracacie się – zawracacie [[G1994]] WTV-PAI-2P **παλιν** *palin* znowu [[G3825]] [[ADV]] **επι** *epi* do [[G1909]] [[PREP]] **τα** *ta* [[G3588]] WTT-APN **ασθενη** *asthenē* słabych – bezsilnych [[G772]] WTA-APN **και** *kai* i [[G2532]] [[CONJ]] **πτωχα** *ptōcha* ubogich [[G4434]] WTA-APN **στοιχεια** *stoicheia* elementów [[G4747]] WTN-APN **οις** *hois* którym [[G3739]] WTR-DPN **παλιν** *palin* znowu [[G3825]] [[ADV]] **ανωθεν** *anōthen* na nowo – od początku [[G509]] [[ADV]] **δουλευειν** *douleuein* być niewolnikami – służyć [[G1398]] WTV-PAN **θελετε** *thelete* chcecie [[G2309]] WTV-PAI-2P
###### **Ga 4,10**
 **ημερας** *hēmeras* Dni [[G2250]] WTN-APF **παρατηρεισθε** *paratēreisthe* pilnujecie [[G3906]] WTV-PMI-2P **και** *kai* i [[G2532]] [[CONJ]] **μηνας** *mēnas* miesięcy [[G3376]] [[N-APM]] **και** *kai* i [[G2532]] [[CONJ]] **καιρους** *kairous* pór [[G2540]] [[N-APM]] **και** *kai* i [[G2532]] [[CONJ]] **ενιαυτους** *eniautous* lat [[G1763]] [[N-APM]]
###### **Ga 4,11**
 **φοβουμαι** *foboumai* Obawiam się – Boję się [[G5399]] WTV-PNI-1S **υμας** *hymas* (o) was [[G5209]] WTP-2AP **μηπως** *mēpōs* aby czasem nie – aby nie jakoś [[G3381]] [[CONJ]] **εικη** *eikē* na próżno – bez powodu [[G1500]] [[ADV]] **κεκοπιακα** *kekopiaka* trudziłem się [[G2872]] WTV-RAI-1S **εις** *eis* nad – względem [[G1519]] [[PREP]] **υμας** *hymas* wami [[G5209]] WTP-2AP
###### **Ga 4,12**
 **γινεσθε** *ginesthe* Stawajcie się [[G1096]] WTV-PNM-2P **ως** *hōs* jak [[G5613]] [[ADV]] **εγω** *egō* ja [[G1473]] WTP-1NS **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **καγω** *kagō* i ja [[G2504]] WTP-1NS-C **ως** *hōs* jak [[G5613]] [[ADV]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **δεομαι** *deomai* proszę [[G1189]] WTV-PNI-1S **υμων** *hymōn* was [[G5216]] WTP-2GP **ουδεν** *ouden* nic [[G3762]] WTA-ASN **με** *me* mnie [[G3165]] WTP-1AS **ηδικησατε** *ēdikēsate* uczyniliście niesprawiedliwości – skrzywdziliście [[G91]] WTV-AAI-2P
###### **Ga 4,13**
 **οιδατε** *oidate* wiecie [[G1492]] WTV-RAI-2P **δε** *de* zaś [[G1161]] [[CONJ]] **οτι** *hoti* że [[G3754]] [[CONJ]] **δι** *di* przez [[G1223]] [[PREP]] **ασθενειαν** *astheneian* słabość – bezsiłę [[G769]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **σαρκος** *sarkos* ciała [[G4561]] [[N-GSF]] **ευηγγελισαμην** *euēngelisamēn* ogłosiłem dobrą nowinę [[G2097]] WTV-AMI-1S **υμιν** *hymin* wam [[G5213]] WTP-2DP **το** *to* [[G3588]] WTT-ASN **προτερον** *proteron* wcześniej [[G4386]] WTA-ASN
###### **Ga 4,14**
 **και** *kai* i [[G2532]] [[CONJ]] **τον** *ton* [[G3588]] [[T-ASM]] **πειρασμον** *peirasmon* próbą – doświadczeniu [[G3986]] [[N-ASM]] **μου** *mou* moją [[G3450]] WTP-1GS **τον** *ton* [[G3588]] [[T-ASM]] **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **σαρκι** *sarki* ciele [[G4561]] [[N-DSF]] **μου** *mou* moim [[G3450]] WTP-1GS **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εξουθενησατε** *eksouthenēsate* wzgardziliście – mieliście za nic [[G1848]] WTV-AAI-2P **ουδε** *oude* ani [[G3761]] [[ADV]] **εξεπτυσατε** *ekseptysate* wypluliście [[G1609]] WTV-AAI-2P **αλλ** *all* ale [[G235]] [[CONJ]] **ως** *hōs* jak [[G5613]] [[ADV]] **αγγελον** *angelon* zwiastuna [[G32]] [[N-ASM]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εδεξασθε** *edeksasthe* przyjęliście [[G1209]] WTV-ADI-2P **με** *me* mnie [[G3165]] WTP-1AS **ως** *hōs* jak [[G5613]] [[ADV]] **χριστον** *christon* Pomazańca [[G5547]] [[N-ASM]] **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]]
###### **Ga 4,15**
 **τις** *tis* Kto [[G5101]] WTI-NSM **ουν** *oun* więc [[G3767]] [[CONJ]] **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **μακαρισμος** *makarismos* szczęście – uszczęśliwienie [[G3108]] [[N-NSM]] **υμων** *hymōn* wasze [[G5216]] WTP-2GP **μαρτυρω** *martyrō* świadczę [[G3140]] WTV-PAI-1S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **οτι** *hoti* że [[G3754]] [[CONJ]] **ει** *ei* jeśli [[G1487]] WTCOND **δυνατον** *dynaton* możliwe [[G1415]] WTA-NSN **τους** *tous* [[G3588]] WTT-APM **οφθαλμους** *ofthalmous* oczy [[G3788]] [[N-APM]] **υμων** *hymōn* wasze [[G5216]] WTP-2GP **εξορυξαντες** *eksoryksantes* wyłupiwszy [[G1846]] WTV-AAP-NPM **αν** *an* (kiedy)kolwiek [[G302]] WTPRT **εδωκατε** *edōkate* daliście [[G1325]] WTV-AAI-2P **μοι** *moi* mi [[G3427]] WTP-1DS
###### **Ga 4,16**
 **ωστε** *hōste* Tak, że [[G5620]] [[CONJ]] **εχθρος** *echthros* wróg – nieprzyjaciel [[G2190]] [[A-NSM]] **υμων** *hymōn* wasz [[G5216]] WTP-2GP **γεγονα** *gegona* stałem się [[G1096]] WTV-2RAI-1S **αληθευων** *alētheuōn* mówiąc prawdę [[G226]] [[V-PAP-NSM]] **υμιν** *hymin* wam [[G5213]] WTP-2DP
###### **Ga 4,17**
 **ζηλουσιν** *zēlousin* Współzawodniczą – Zabiegają [[G2206]] WTV-PAI-3P **υμας** *hymas* (o) was [[G5209]] WTP-2AP **ου** *ou* nie [[G3756]] [[PRT-N]] **καλως** *kalōs* dobrze – pięknie [[G2573]] [[ADV]] **αλλα** *alla* ale [[G235]] [[CONJ]] **εκκλεισαι** *ekkleisai* odłączyć – wykluczyć [[G1576]] [[V-AAN]] **υμας** *hymas* was [[G5209]] WTP-2AP **θελουσιν** *thelousin* chcą [[G2309]] WTV-PAI-3P **ινα** *hina* aby [[G2443]] [[CONJ]] **αυτους** *autous* (o) nich [[G846]] [[P-APM]] **ζηλουτε** *zēloute* współzawodniczylibyście – zabiegalibyście [[G2206]] WTV-PAS-2P
###### **Ga 4,18**
 **καλον** *kalon* Dobre – Piękne [[G2570]] WTA-NSN **δε** *de* zaś [[G1161]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **ζηλουσθαι** *zēlousthai* być współzawodniczącym – być zabiegającym [[G2206]] WTV-PPN **εν** *en* w [[G1722]] [[PREP]] **καλω** *kalō* dobrym – pięknym [[G2570]] WTA-DSN **παντοτε** *pantote* zawsze – każdej chwili [[G3842]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **μονον** *monon* jedynie – tylko [[G3440]] [[ADV]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **παρειναι** *pareinai* być obecnym [[G3918]] WTV-PXN **με** *me* ja [[G3165]] WTP-1AS **προς** *pros* wśród – przy [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP
###### **Ga 4,19**
 **τεκνια** *teknia* Dzieciaczki – Małe dzieci [[G5040]] WTN-VPN **μου** *mou* moje [[G3450]] WTP-1GS **ους** *hous* których [[G3739]] WTR-APM **παλιν** *palin* znowu [[G3825]] [[ADV]] **ωδινω** *ōdinō* rodzę w bólach – rodzę w cierpieniach [[G5605]] WTV-PAI-1S **αχρις** *achris* aż do [[G891]] [[PREP]] **ου** *hou* kiedy [[G3739]] WTR-GSM **μορφωθη** *morfōthē* zostałby ukształtowany [[G3445]] WTV-APS-3S **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **εν** *en* w [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP
###### **Ga 4,20**
 **ηθελον** *ēthelon* chciałem [[G2309]] WTV-IAI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **παρειναι** *pareinai* być obecnym [[G3918]] WTV-PXN **προς** *pros* przy [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **αρτι** *arti* teraz [[G737]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **αλλαξαι** *allaksai* zmienić – przemienić [[G236]] [[V-AAN]] **την** *tēn* [[G3588]] WTT-ASF **φωνην** *fōnēn* głos [[G5456]] WTN-ASF **μου** *mou* mój [[G3450]] WTP-1GS **οτι** *hoti* że [[G3754]] [[CONJ]] **απορουμαι** *aporoumai* jestem zakłopotany – jestem w niepewności [[G639]] WTV-PMI-1S **εν** *en* (co) do [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP
###### **Ga 4,21**
 **λεγετε** *legete* Mówcie [[G3004]] WTV-PAM-2P **μοι** *moi* mi [[G3427]] WTP-1DS **οι** *hoi* [[G3588]] WTT-NPM **υπο** *hypo* pod [[G5259]] [[PREP]] **νομον** *nomon* Prawem [[G3551]] [[N-ASM]] **θελοντες** *thelontes* chcąc [[G2309]] WTV-PAP-NPM **ειναι** *einai* być [[G1511]] WTV-PXN **τον** *ton* [[G3588]] [[T-ASM]] **νομον** *nomon* Prawa [[G3551]] [[N-ASM]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ακουετε** *akouete* słyszycie [[G191]] WTV-PAI-2P
###### **Ga 4,22**
 **γεγραπται** *gegraptai* Jest napisane [[G1125]] WTV-RPI-3S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **οτι** *hoti* że [[G3754]] [[CONJ]] **αβρααμ** *abraam* Abraham – [ojciec wielu narodów] [[G11]] [[N-PRI]] **δυο** *dyo* dwóch [[G1417]] WTA-NUI **υιους** *hyious* synów [[G5207]] [[N-APM]] **εσχεν** *eschen* miał [[G2192]] WTV-2AAI-3S **ενα** *hena* jednego [[G1520]] WTA-ASM **εκ** *ek* ze [[G1537]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **παιδισκης** *paidiskēs* służącej – służki [[G3814]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **ενα** *hena* jednego [[G1520]] WTA-ASM **εκ** *ek* z [[G1537]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **ελευθερας** *eleutheras* wolnej [[G1658]] WTA-GSF
###### **Ga 4,23**
 **αλλ** *all* Ale [[G235]] [[CONJ]] **ο** *ho* (ten) [[G3588]] [[T-NSM]] **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **εκ** *ek* ze [[G1537]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **παιδισκης** *paidiskēs* służącej – służki [[G3814]] [[N-GSF]] **κατα** *kata* według [[G2596]] [[PREP]] **σαρκα** *sarka* ciała [[G4561]] WTN-ASF **γεγεννηται** *gegennētai* jest zrodzony [[G1080]] WTV-RPI-3S **ο** *ho* (ten) [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **εκ** *ek* z [[G1537]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **ελευθερας** *eleutheras* wolnej [[G1658]] WTA-GSF **δια** *dia* przez [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **επαγγελιας** *epangelias* obietnicę [[G1860]] [[N-GSF]]
###### **Ga 4,24**
 **ατινα** *hatina* Które [[G3748]] WTR-NPN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **αλληγορουμενα** *allēgoroumena* będące mówionym alegorycznie – mające znaczenie przenośne [[G238]] WTV-PPP-NPN **αυται** *hautai* te [[G3778]] WTD-NPF **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **αι** *hai* [[G3588]] [[T-NPF]] **δυο** *dyo* dwoma [[G1417]] WTA-NUI **διαθηκαι** *diathēkai* przymierzami [[G1242]] [[N-NPF]] **μια** *mia* jedno [[G1520]] WTA-NSF **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **απο** *apo* z [[G575]] [[PREP]] **ορους** *orous* góry [[G3735]] [[N-GSN]] **σινα** *sina* Synaj [[G4614]] [[N-PRI]] **εις** *eis* w [[G1519]] [[PREP]] **δουλειαν** *douleian* niewolę [[G1397]] WTN-ASF **γεννωσα** *gennōsa* rodzącą [[G1080]] [[V-PAP-NSF]] **ητις** *hētis* która [[G3748]] WTR-NSF **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **αγαρ** *hagar* Hagar [[G28]] [[N-PRI]]
###### **Ga 4,25**
 **το** *to* [[G3588]] WTT-NSN **γαρ** *gar* Bowiem [[G1063]] [[CONJ]] **αγαρ** *hagar* Hagar [[G28]] [[N-PRI]] **σινα** *sina* Synaj [[G4614]] [[N-PRI]] **ορος** *oros* góra [[G3735]] WTN-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **αραβια** *arabia* Arabii – [płaskowyż pustynny] [[G688]] [[N-DSF]] **συστοιχει** *systoichei* odpowiada – stoi w tym szeregu z [[G4960]] WTV-PAI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **τη** *tē* (temu) [[G3588]] WTT-DSF **νυν** *nyn* teraz [[G3568]] [[ADV]] **ιερουσαλημ** *ierousalēm* Jeruzalem – [dziedzictwo pokoju] [[G2419]] [[N-PRI]] **δουλευει** *douleuei* jest niewolnikiem – jest sługą [[G1398]] WTV-PAI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **μετα** *meta* z [[G3326]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **τεκνων** *teknōn* dziećmi [[G5043]] WTN-GPN **αυτης** *autēs* jej [[G846]] [[P-GSF]]
###### **Ga 4,26**
 **η** *hē* [[G3588]] [[T-NSF]] **δε** *de* zaś [[G1161]] [[CONJ]] **ανω** *anō* w górze [[G507]] [[ADV]] **ιερουσαλημ** *ierousalēm* Jeruzalem – [dziedzictwo pokoju] [[G2419]] [[N-PRI]] **ελευθερα** *eleuthera* wolne [[G1658]] WTA-NSF **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ητις** *hētis* które [[G3748]] WTR-NSF **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **μητηρ** *mētēr* matka [[G3384]] [[N-NSF]] **παντων** *pantōn* wszystkich [[G3956]] WTA-GPM **ημων** *hēmōn* nas [[G2257]] WTP-1GP
###### **Ga 4,27**
 **γεγραπται** *gegraptai* Jest napisane [[G1125]] WTV-RPI-3S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ευφρανθητι** *eufranthēti* zostań rozweselona – zostań ucieszona [[G2165]] WTV-APM-2S **στειρα** *steira* bezpłodna [[G4723]] WTN-VSF **η** *hē* (ta) [[G3588]] [[T-NSF]] **ου** *ou* nie [[G3756]] [[PRT-N]] **τικτουσα** *tiktousa* rodząca [[G5088]] [[V-PAP-NSF]] **ρηξον** *rēkson* wybuchnij [[G4486]] WTV-AAM-2S **και** *kai* i [[G2532]] [[CONJ]] **βοησον** *boēson* zawołaj [[G994]] WTV-AAM-2S **η** *hē* (ta) [[G3588]] [[T-NSF]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ωδινουσα** *ōdinousa* rodząca w bólach [[G5605]] [[V-PAP-NSF]] **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **πολλα** *polla* liczne – wiele [[G4183]] WTA-NPN **τα** *ta* [[G3588]] WTT-NPN **τεκνα** *tekna* dzieci [[G5043]] WTN-NPN **της** *tēs* (tej) [[G3588]] [[T-GSF]] **ερημου** *erēmou* porzuconej – samotnej [[G2048]] WTA-GSF **μαλλον** *mallon* bardziej [[G3123]] [[ADV]] **η** *ē* niż [[G2228]] WTPRT **της** *tēs* [[G3588]] [[T-GSF]] **εχουσης** *echousēs* mającej [[G2192]] WTV-PAP-GSF **τον** *ton* [[G3588]] [[T-ASM]] **ανδρα** *andra* męża [[G435]] [[N-ASM]]
###### **Ga 4,28**
 **ημεις** *hēmeis* My [[G2249]] WTP-1NP **δε** *de* zaś [[G1161]] [[CONJ]] **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **κατα** *kata* według – na wzór [[G2596]] [[PREP]] **ισαακ** *isaak* Izaaka – [śmiać się] [[G2464]] [[N-PRI]] **επαγγελιας** *epangelias* obietnicy [[G1860]] [[N-GSF]] **τεκνα** *tekna* dzieci [[G5043]] WTN-NPN **εσμεν** *esmen* jesteśmy [[G2070]] WTV-PXI-1P
###### **Ga 4,29**
 **αλλ** *all* Ale [[G235]] [[CONJ]] **ωσπερ** *hōsper* tak, jak [[G5618]] [[ADV]] **τοτε** *tote* wtedy [[G5119]] [[ADV]] **ο** *ho* (ten) [[G3588]] [[T-NSM]] **κατα** *kata* według [[G2596]] [[PREP]] **σαρκα** *sarka* ciała [[G4561]] WTN-ASF **γεννηθεις** *gennētheis* który został zrodzony [[G1080]] WTV-APP-NSM **εδιωκεν** *ediōken* prześladował – nastawał [[G1377]] WTV-IAI-3S **τον** *ton* (tego) [[G3588]] [[T-ASM]] **κατα** *kata* według [[G2596]] [[PREP]] **πνευμα** *pneuma* Ducha [[G4151]] WTN-ASN **ουτως** *houtōs* tak [[G3779]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **νυν** *nyn* teraz [[G3568]] [[ADV]]
###### **Ga 4,30**
 **αλλα** *alla* Ale [[G235]] [[CONJ]] **τι** *ti* co [[G5101]] WTI-ASN **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **η** *hē* [[G3588]] [[T-NSF]] **γραφη** *grafē* Pismo [[G1124]] [[N-NSF]] **εκβαλε** *ekbale* wyrzuć [[G1544]] WTV-2AAM-2S **την** *tēn* [[G3588]] WTT-ASF **παιδισκην** *paidiskēn* służącą – służkę [[G3814]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **τον** *ton* [[G3588]] [[T-ASM]] **υιον** *hyion* syna [[G5207]] [[N-ASM]] **αυτης** *autēs* jej [[G846]] [[P-GSF]] **ου** *ou* nie [[G3756]] [[PRT-N]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **μη** *mē* [[G3361]] [[PRT-N]] **κληρονομηση** *klēronomēsē* mógłby dziedziczyć – mógłby dostać w udziale [[G2816]] WTV-AAS-3S **ο** *ho* [[G3588]] [[T-NSM]] **υιος** *hyios* syn [[G5207]] [[N-NSM]] **της** *tēs* [[G3588]] [[T-GSF]] **παιδισκης** *paidiskēs* służącej – służki [[G3814]] [[N-GSF]] **μετα** *meta* z [[G3326]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **υιου** *hyiou* synem [[G5207]] [[N-GSM]] **της** *tēs* [[G3588]] [[T-GSF]] **ελευθερας** *eleutheras* wolnej [[G1658]] WTA-GSF
###### **Ga 4,31**
 **αρα** *ara* Zatem [[G686]] WTPRT **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εσμεν** *esmen* jesteśmy [[G2070]] WTV-PXI-1P **παιδισκης** *paidiskēs* służącej – służki [[G3814]] [[N-GSF]] **τεκνα** *tekna* dzieci [[G5043]] WTN-NPN **αλλα** *alla* ale [[G235]] [[CONJ]] **της** *tēs* [[G3588]] [[T-GSF]] **ελευθερας** *eleutheras* wolnej [[G1658]] WTA-GSF
