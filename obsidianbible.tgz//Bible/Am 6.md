# Am 6 BT5
###### **Am 6,1**
 Biada beztroskim na Syjoniei dufnym na górze Samarii, książętom pierwszego z narodów, których słucha dom Izraela.
###### **Am 6,2**
 Idźcie do Kalne i zobaczcie, potem idźcie stamtąd do Chamat-Rabbai zajdźcie do Gat filistyńskiego.Czyż od tych królestw jesteście silniejsialbo posiadłości wasze większe niż u nich?
###### **Am 6,3**
 [W mniemaniu swoim] oddalacie dzień niedoli, a [rzeczywiście] przybliżacie panowanie gwałtu.
###### **Am 6,4**
 Leżą na łożach z kości słonioweji wylegują się na dywanach; jedzą oni jagnięta z trzodyi cielęta ze środka obory.
###### **Am 6,5**
 Improwizują na strunach harfyi jak Dawid wynajdują instrumenty muzyczne.
###### **Am 6,6**
 Piją czaszami winoi najlepszym olejkiem się namaszczają, a nic się nie martwią upadkiem domu Józefa.
###### **Am 6,7**
 Dlatego teraz ich poprowadzę na czele wygnańców, i zniknie krzykliwe grono hulaków.
###### **Am 6,8**
 Poprzysiągł Pan Bóg na swoje życie – wyrocznia Pana, Boga Zastępów: Brzydzę się pychą Jakuba i nienawidzę jego pałaców, wydam więc [wrogom] miasto i to, co się w nim znajduje.
###### **Am 6,9**
 I gdyby pozostało dziesięciu mężów w jednym domu –i ci umrą;
###### **Am 6,10**
 a krewny, który z domu wyniesie ich zwłoki, zapyta tego, który pozostał w domu:«***Czy jest jeszcze ktoś z tobą?***»Odpowie: «***Nie ma***», i doda:«***Milcz!***» Nie ma nikogo, aby wzywać imienia Pana.
###### **Am 6,11**
 Oto Pan rozkazał, i obrócony będzie wielki dom w ruinę, a mały dom w rozsypkę.
###### **Am 6,12**
 Czy konie pędzą po skałachalbo czy tam się orze wołami, że zamieniacie sprawiedliwość na truciznę, a owoc prawości – na cykutę?
###### **Am 6,13**
 Cieszycie się z Lo-Debari mówicie: «***Czyż nie naszą siłą zdobyliśmy sobie Karnaim?***»
###### **Am 6,14**
 Lecz oto Ja wzbudzę przeciwko wam, domu Izraela,– wyrocznia Pana, Boga Zastępów –naród, który was uciemiężyod Wejścia do Chamat aż do potoku Araby.
# Am 6 PAU
###### **Am 6,1**
 Biada beztroskim na Syjonie i pewnym siebie na górze Samarii; przywódcom pierwszego z narodów, których słucha dom Izraela.
###### **Am 6,2**
 Idźcie do Kalne i zobaczcie, a potem pójdźcie do wielkiego Chamati zejdźcie do Gat Filistynów. Czy jesteście lepsi od tych królestw albo większe są wasze kraje?
###### **Am 6,3**
 Chcecie oddalić dzień klęski, a przybliżacie panowanie przemocy.
###### **Am 6,4**
 Leżą na łożach z kości słoniowej i wylegują się na posłaniach, jedzą jagnięta z trzody i cielęta z zagrody wybrane.
###### **Am 6,5**
 Fałszywie śpiewają przy dźwiękach harfy, wymyślają sobie instrumenty muzyczne, jak Dawid.
###### **Am 6,6**
 Piją wino z wielkich kielichów, najlepszymi olejkami się namaszczają i nie martwią się wcale upadkiem domu Józefa.
###### **Am 6,7**
 Dlatego pójdą na czele wygnańców i skończy się ich swawola.
###### **Am 6,8**
 PAN BÓG przysiągł na swoje życie. Wyrocznia PANA, Boga Zastępów: Brzydzę się pychą Jakuba i nienawidzę jego pałaców! Wrogom wydam więc miasto i wszystko, co w nim się znajduje.
###### **Am 6,9**
 Choćby tylko dziesięciu ludzi pozostało w jednym domu, nawet oni umrą.
###### **Am 6,10**
 Ich kości wyniesie krewny i ten, co przygotowuje stos. Zapyta pozostającego w domu: „Czy jest jeszcze ktoś z tobą?”. On odpowie: „Nie ma” i doda: „Milcz!”. Nie będzie się już wspominać imienia Pana.
###### **Am 6,11**
 Oto Pan rozkazał większy dom obrócić w ruinę, a mniejszy - w gruzy.
###### **Am 6,12**
 Czy konie pędzą po skałach albo czy można wołami orać morze? Bo zamieniacie sprawiedliwość w truciznę, a owoc prawości w gorycz.
###### **Am 6,13**
 Cieszycie się z Lo-Debar. Mówicie: „Czyż nie naszą siłą zdobyliśmy Karnaim?”.
###### **Am 6,14**
 Wyrocznia PANA, Boga Zastępów - Oto Ja skieruję przeciwko wam, domu Izraela, naród, który będzie was ciemiężył od Lebo-Chamat aż do potoku Araby.
# Am 6 BP
###### **Am 6,1**
 Biada tym, którzy żyją beztrosko na Syjonie, i tym, którzy bezpiecznie się czują na górze Samarii, dostojnikom najznamienitszego narodu, do których przychodzi Dom Izraela.
###### **Am 6,2**
 Udajcie się do Kalne i rozejrzyjcie się, stamtąd idźcie do wielkiego Chamat, potem zaś wstąpcie do Get filistyńskiego! Czy może więcej znaczycie niż te królestwa albo czy obszar wasz jest większy niż ich obszary?
###### **Am 6,3**
 Mniemacie, że zdołacie odroczyć dzień nieszczęścia, a przyspieszacie panowanie przemocy.
###### **Am 6,4**
 Sypiają na łożach zdobionych kością słoniową i wylegują się na posłaniach; zjadają baranki z trzody i cielęta z zagrody,
###### **Am 6,5**
 śpiewają hałaśliwie przy dźwiękach harfy i obmyślają instrumenty muzyczne podobnie jak Dawid;
###### **Am 6,6**
 c ale zagładą Józefa się nie przejmują.
###### **Am 6,7**
 Dlatego wkrótce pójdą na wygnanie na czele wygnańców i skończą się hulanki próżniaków - tak mówi Jahwe, Bóg Zastępów.
###### **Am 6,8**
 Poprzysiągł Jahwe na samego siebie: - Brzydzę się pychą Jakuba, nienawidzę jego pałaców; w ręce [wroga] wydam miasto i wszystko, co się w nim znajduje.
###### **Am 6,9**
 Wówczas jeśli w jakimś domu zostanie jeszcze dziesięciu ludzi, i oni będą musieli umrzeć.
###### **Am 6,10**
 Niewielu tylko z tych, którzy ujdą cało, pozostanie, by wynieść z domu zwłoki. A gdy spytają kogoś znajdującego się w głębi domu: "Jest jeszcze ktoś przy tobie?" - ten odpowie: "Nie ma" i doda: "Cicho!", by nie zostało wspomniane [przypadkiem] Imię Jahwe.
###### **Am 6,11**
 Bo zaprawdę teraz Jahwe rządzi! Pod Jego uderzeniem wielkie domy padają w gruzy, małe zaś rozsypują się w pył.
###### **Am 6,12**
 Czy konie mogą biegać po skałach albo czy można orać wołami morze? Wy jednak zmieniacie prawo w truciznę, a owoc sprawiedliwości w piołun.
###### **Am 6,13**
 radują się z powodu Lo-Debar i powiadają: "Czyż nie zdobyliśmy Karnajim własnymi siłami?" -
###### **Am 6,14**
 Oto Ja - mówi Jahwe, Bóg Zastępów - wzbudzę przeciwko wam, o Domu Izraela, naród, który was będzie gnębił od drogi do Chamat aż po potok Araba.
# Am 6 BR
###### **Am 6,1**
 Biada tym, co tak beztrosko żyją na Syjonie i co są tak pewni siebie na górach Samarii. Biada księżętom pierwszego spośród wszystkich narodów, (biada tym, u których zbiera się cały Izrael).
###### **Am 6,2**
 Idźcie w stronę kalne i rozejrzyjcie się dobrze, potem udajcie się do Chamat - miasta wielkiego, wstąpcie później do Gat, które leży w ziemi filistyńskiej! Czy jesteście silniejsi od tamtejszych ? Czy kraj wasz jest większy niźli ich królestwa?
###### **Am 6,3**
 Wy, co tak usiłujecie oddalić dzień nieszczęścia, w rzeczywistości tylko przybliżacie dzień gwałtu.
###### **Am 6,4**
 Wylegujecie się na łożach ze słoniowej kości, rozkładacie się wygodnie na swoich dywanach. Spożywają jagnięta ze stada i cielęta z samego środka obory.
###### **Am 6,5**
 Melodie zawodzicie na każdy głos harfy i chcecie jak Dawid nowe pieśni układać.
###### **Am 6,6**
 Wino pijecie ogromnymi czarami, ciała sobie namaszczacie najdroższym olejkiem i wcale nie myślicie o tym, że dom Józefa chyli się ku zgubie.
###### **Am 6,7**
 Dlatego musicie iść teraz na wygnanie, wszyscy uprowadzeni będziecie. Skończyły się już dla hulaków zabawy!
###### **Am 6,8**
 Bóg zaś i Pan nasz poprzysiągł na siebie - oto wyrocznia Pana i Boga Zastępów: Brzydzę się wyniosłością Jakuba, nienawidzę jego pałaców, zgubę zgotuję miastu i wszystkiemu, co w nim pozostało.
###### **Am 6,9**
 A jeśli po tym wszystkim jeszcze choć dziesięciu mężów znajdzie się gdzieś w jednym domu, wszyscy oni także umrzeć będą musieli.
###### **Am 6,10**
 Tylko bardzo nieliczni zdołają się uratować, ażeby wynieść kości już umarłych z domu. Kiedy zaś zapytają siedzącego w kącie, czy jest ktoś jeszcze w domu, to on odpowie: Nie, i doda: Mów cicho i nie wypowiadaj imienia Bożego!
###### **Am 6,11**
 Pan bowiem rozkazał, i w gruzach lec musi dom wielki, a mały rozsypie się na drobne części.
###### **Am 6,12**
 Czyż konie biegają po skałach lub czy ktoś orkę uprawia wołami na morzu? A wyście prawo w truciznę zmienili, owoce sprawiedliwości - w bardzo gorzki piołun.
###### **Am 6,13**
 Cieszycie się po zdobyciu Lo- Debar mówiąc: Przecież własnymi siłami wzięliśmy Karnaim.
###### **Am 6,14**
 Ale ześlę na was, domu Izraela, lud, który was zacznie nękać od wejścia do Chamat aż do Araby potoku - oto wyrocznia Pana i Boga Zastępów.
# Am 6 WUJ
###### **Am 6,1**
 Biada, którzyście bogaci na Sionie, a ufacie w górze Samaryjskiej: co celniejszy, głowy ludów, chodzący z pompą do domu Izraelskiego.
###### **Am 6,2**
 Zajdźcie do Chalane, a obaczcie, a z onąd idźcie do Emath wielkiego, i znidźcie do Geth Palestyńskiego, i do co lepszych królestw tych, jeśli szersza jest granica ich niż granica wasza.
###### **Am 6,3**
 Którzyście odłączeni na dzień zły: a przybliżacie się do stolice nieprawości.
###### **Am 6,4**
 Którzy sypiacie na łożach słoniowych, a rozpustujecie na pościelach waszych: którzy jadacie baranka z trzody, i cielce z pośrodku stada.
###### **Am 6,5**
 Którzy śpiewacie przy dźwięku arfy: mniemali, że mieli jako Dawid naczynia śpiewania.
###### **Am 6,6**
 Którzy piją czasami wino, a przedniejszym się olejkiem namazują, a nic się nie użalili skruszenia Józefowego.
###### **Am 6,7**
 Przeto teraz wyprowadzą się na przodku prowadzących się: a będzie odjęte spiknienie rozpustnych.
###### **Am 6,8**
 Przysiągł Pan Bóg na duszę swoję, mówi Pan Bóg zastępów: Brzydzę się ja pychą Jakóbową, a domów jego nienawidzę, i wydam miasto z obywatelmi jego.
###### **Am 6,9**
 A jeśli się zostanie dziesięć mężów w domu jednym, i ci pomrą.
###### **Am 6,10**
 I weźmie go blizki jego, i spali go, aby wyniósł kości z domu: i rzecze temu, który jest wewnątrz domu. Jestli jeszcze u ciebie? (11) A on odpowie: Już koniec. I rzecze mu: Milcz, a nie wspominaj imienia Pańskiego.
###### **Am 6,11**
 Bo oto Pan rozkaże, i skarżę dom więtszy obaleniem, a dom mniejszy porysowaniem.
###### **Am 6,12**
 Izali biegać mogą konie po skałach, abo mogą orać bawołami: żeście przemienili sąd w gorzkość a owoc sprawiedliwości w piołun?
###### **Am 6,13**
 Którzy się radujecie w niczem: którzy mówicie: Izali nie mocą naszą wzięliśmy sobie rogi?
###### **Am 6,14**
 Bo oto wzbudzę na was domie Izraelów, mówi Pan Bóg zastępów, naród: i skruszy was od weszcia do Emath, aż do potoku paszcze.
