# Ez 8 BT5
###### **Ez 8,1**
 Kiedy roku szóstego, piątego dnia szóstego miesiąca, przebywałem w moim domu, a starsi Judy siedzieli przede mną, spoczęła tam na mnie ręka Pana Boga.
###### **Ez 8,2**
 Patrzyłem, a oto była tam istota podobna do postaci człowieka; w dół od tego, co wyglądało na jego biodra, był ogień, i w górę od tego, co wyglądało na biodra, było coś, co przypominało połysk stopu złota ze srebrem.
###### **Ez 8,3**
 Wyciągnął coś w rodzaju ręki i uchwycił mnie za włosy na głowie, a duch podniósł mnie w górę między ziemię a niebo i w Boskich widzeniach zaprowadził do Jerozolimy, do przedsionka bramy wewnętrznej, położonej po stronie północnej, tam gdzie znajdował się bożek zazdrości, < pobudzający do zazdrośc i>.
###### **Ez 8,4**
 Oto tam była chwała Boga Izraela, taka sama, jaką widziałem na równinie.
###### **Ez 8,5**
 I rzekł do mnie: «***Synu człowieczy, podnieś teraz oczy ku północy***». I podniosłem oczy w kierunku północnym, a oto na północ od bramy ołtarza znajdował się u wejścia ów bożek zazdrości.
###### **Ez 8,6**
 I rzekł [Pan] do mnie: «***Synu człowieczy, czy widzisz, co oni czynią? – Okropne obrzydliwości, którym się tu oddają pokolenia izraelskie, aby Mnie zmusić do oddalenia się z mojej świątyni. Ale gdy się lepiej przypatrzysz, zobaczysz jeszcze większe obrzydliwości***».
###### **Ez 8,7**
 Zaprowadził mnie potem do wejścia na dziedziniec, i popatrzyłem, a oto był tam otwór w murze.
###### **Ez 8,8**
 On rzekł do mnie: «***Synu człowieczy, przebij ten mur!***» I przebiłem mur, a oto było tam przejście.
###### **Ez 8,9**
 A On rzekł do mnie: «***Wejdź i przyjrzyj się tym ohydnym czynom, którym się oni tu oddają***».
###### **Ez 8,10**
 Wszedłem i patrzyłem, a oto były tam wszelkiego rodzaju postacie tego, co pełza po ziemi, i bydląt, ohydnych istot, i wszystkie bożki domu Izraela, wyrysowane wszędzie na ścianie dokoła.
###### **Ez 8,11**
 Siedemdziesięciu mężów spośród starszyzny izraelskiej stało przed nimi – a wśród nich stał Jaazaniasz, syn Szafana – w ręku każdego była kadzielnica, a woń unosiła się z obłoków kadzidła.
###### **Ez 8,12**
 I rzekł [Pan] do mnie: «***Czy widzisz, synu człowieczy, czemu się oddaje w ukryciu każdy ze starszyzny domu Izraela w tajemnej komnacie? Mówią oni bowiem: Pan nas nie widzi. Pan opuścił ten kraj***».
###### **Ez 8,13**
 I rzekł do mnie: «***Zobaczysz jeszcze gorsze obrzydliwości popełniane przez nich***».
###### **Ez 8,14**
 Następnie zaprowadził mnie do przedsionka bramy świątyni Pańskiej, mieszczącej się po stronie północnej, a oto siedziały tam kobiety i opłakiwały Tammuza.
###### **Ez 8,15**
 I rzekł do mnie: «***Czy widzisz, synu człowieczy? Zobaczysz jeszcze większe obrzydliwości od tych***».
###### **Ez 8,16**
 Zaprowadził mnie także na wewnętrzny dziedziniec świątyni Pańskiej i oto u wejścia do świątyni Pańskiej, pomiędzy przedsionkiem a ołtarzem, znajdowało się około dwudziestu pięciu mężów, obróconych tyłem do świątyni Pańskiej, z twarzami skierowanymi ku wschodowi. Zwróceni na wschód oddawali pokłon słońcu.
###### **Ez 8,17**
 I rzekł do mnie: «***Czy widzisz to, synu człowieczy? Czyż nie dosyć domowi Judy dokonywania tych obrzydliwości, które tu popełniają? Napełniają kraj ten przemocą i stale Mnie obrażają. I oto wciąż podnoszą gałązkę do nosa.
###### **Ez 8,18**
 Również i Ja będę postępował z nimi z zapalczywością; oko moje nie okaże litości, i nie będę oszczędzał. A będą wołać do moich uszu do-nośnym głosem, lecz Ja ich nie wysłucham***».
# Ez 8 PAU
###### **Ez 8,1**
 W szóstym roku, w piątym dniu szóstego miesiąca, siedziałem w moim domu, a starsi Judy siedzieli przede mną. Nagle dotknęła mnie ręka PANA BOGA.
###### **Ez 8,2**
 I wtedy zobaczyłem coś podobnego do ognia. Poniżej tego, co wyglądało jak biodra, był ogień, to zaś, co było powyżej bioder, przypominało jasność, jakby blask pozłacanego srebra.
###### **Ez 8,3**
 Wyciągnął coś podobnego do ręki i uchwycił mnie za włosy na głowie. Duch podniósł mnie między ziemię i niebo i wprowadził w widzeniach Bożych do Jerozolimy, do wejścia do bramy wewnętrznej, zwróconej ku północy, gdzie znajdował się tron figury bożka zazdrości, wywołującego oburzenie.
###### **Ez 8,4**
 A była tam chwała Boga Izraela, podobna do tej, którą widziałem na równinie.
###### **Ez 8,5**
 Rzekł On do mnie: „Synu człowieczy, zwróć, proszę, oczy w kierunku północnym”. Zwróciłem więc oczy w kierunku północnym. I zobaczyłem, że na północ od bramy był ołtarz, u wejścia zaś stała figura bożka zazdrości.
###### **Ez 8,6**
 Wtedy Bóg mi powiedział: „Synu człowieczy, czy widzisz co oni robią? Te wielkie obrzydliwości, których lud izraelski tutaj się dopuszcza, żeby Mnie oddalić od mojej świątyni. Ale zobaczysz jeszcze większe obrzydliwości”.
###### **Ez 8,7**
 I wprowadził mnie do wejścia na dziedziniec, gdzie zobaczyłem otwór w ścianie.
###### **Ez 8,8**
 Bóg rzekł do mnie: „Synu człowieczy, przebij, proszę, tę ścianę”. Przebiłem ścianę, a oto było tam jakieś wejście.
###### **Ez 8,9**
 Potem mi powiedział: „Wejdź i zobacz najgorsze obrzydliwości, jakich oni się tu dopuszczają”.
###### **Ez 8,10**
 Gdy wszedłem, zobaczyłem wyryte na ścianach dookoła wszelkie wyobrażenia płazów, wstrętnych bydląt i wszystkich bożków ludu izraelskiego.
###### **Ez 8,11**
 A siedemdziesięciu mężczyzn spośród starszych Izraela - był pośród nich syn Szafana, Jaazaniasz - stało przed nimi. Każdy trzymał w ręku kadzielnicę, z której unosiła się woń dymu kadzielnego.
###### **Ez 8,12**
 I rzekł do mnie: „Czy widzisz, synu człowieczy, co czynią w ciemności starsi ludu izraelskiego, każdy w swoim pomieszczeniu przed pogańskimi wizerunkami? Mówią bowiem: PAN nas nie widzi. PAN opuścił kraj”.
###### **Ez 8,13**
 I dodał: „Zobaczysz jeszcze większe obrzydliwości, jakich się dopuszczają”.
###### **Ez 8,14**
 Następnie wprowadził mnie do wejścia do bramy domu PANA, która była po stronie północnej. Siedziały tam kobiety opłakujące Tammuza.
###### **Ez 8,15**
 I rzekł do mnie: „Czy widzisz, synu człowieczy? Zobaczysz jednak jeszcze większe obrzydliwości”.
###### **Ez 8,16**
 Potem wprowadził mnie na wewnętrzny dziedziniec domu PANA. Przy wejściu do świątyni PANA, między przedsionkiem a ołtarzem, stało około dwudziestu pięciu mężczyzn, każdy tyłem do świątyni PANA. Twarzami swymi zwróceni ku wschodowi, kłaniali się głęboko w kierunku wschodu słońca.
###### **Ez 8,17**
 Bóg zapytał mnie: „Czy widzisz, synu człowieczy? Czyż mało domowi Judy, że czyni obrzydliwości, które się tu dzieją? Napełnili bowiem kraj przemocą i żeby Mnie znowu obrażać, przykładają gałązkę do nosa.
###### **Ez 8,18**
 Ja także będę działał w oburzeniu. Nie spojrzę ze współczuciem i nie przebaczę. Będą głośno wołać do Mnie, ale nie będę ich słuchał”.
# Ez 8 BP
###### **Ez 8,1**
 Stało się to w szóstym roku, szóstego [miesiąca] w piątym [dniu] miesiąca; [gdy] siedziałem u siebie w domu, a starsi Judy siedzieli przede mną, dotknęła mnie tam ręka Pana, Jahwe.
###### **Ez 8,2**
 Spojrzałem: oto [ukazało się] coś podobnego do widoku ognia. Od podobieństwa jego bioder ku dołowi - ogień, zaś od jego bioder wzwyż jakby podobieństwo jasności, jak gdyby blask pozłacanego srebra.
###### **Ez 8,3**
 Wyciągnął [coś na] kształt ręki i uchwycił mię za kędziory mej głowy. Duch uniósł mię między ziemię a niebo i przeniósł mię w widzeniu Bożym do Jerozolimy, do wejścia bramy wewnętrznej, zwróconej ku północy, tam gdzie był ustawiony bożek zazdrości, pobudzający do zazdrości [z żarliwości].
###### **Ez 8,4**
 A oto tam znajdowała się Chwała Boga Izraela, podobna do tej, którą widziałem na równinie.
###### **Ez 8,5**
 Powiedział mi: Synu człowieczy, wznieś swoje oczy w kierunku północy. Zwróciłem oczy w kierunku północnym, a oto z północnej strony bramy ołtarza u wejścia [znajdował się] ów bożek zazdrości.
###### **Ez 8,6**
 I rzekł do mnie: Synu człowieczy, czy widzisz, co one robią? Te wielkie obrzydliwości, jakie Dom Izraela tu czyni, abym się oddalił z mego sanktuarium. Zobaczysz jednak jeszcze większe obrzydliwości.
###### **Ez 8,7**
 I zaprowadził mię do wejścia na dziedziniec. Spojrzałem: oto jakiś otwór był w ścianie.
###### **Ez 8,8**
 Polecił mi: Przebij ścianę, synu człowieczy. Przebiłem ścianę, a oto [ukazało się] jakieś wejście.
###### **Ez 8,9**
 Rzekł do mnie: Wejdź i zobacz te niecne obrzydliwości, które oni tu czynią.
###### **Ez 8,10**
 Wszedłem i zobaczyłem: oto wszędzie dookoła na ścianie były wyryte wszelkiego [rodzaju] wyobrażenia płazów, wstrętnych bydląt i wszystkich bożków Domu Izraela.
###### **Ez 8,11**
 Siedemdziesięciu mężów ze starszyzny Domu Izraela - Jaazaniasz, syn Szafana, był wśród nich - stało przed nimi, każdy z kadzielnicą w swym ręku, z której unosiła się woń dymu kadzielnego.
###### **Ez 8,12**
 I spytał się: Cóż widziałeś, synu człowieczy, co czynią w ciemności starsi Domu Izraela, każdy w celi z obrazem swego bożka? Mówią bowiem: Jahwe nas nie widzi. Jahwe opuścił kraj.
###### **Ez 8,13**
 Powiedział mi: Zobaczysz znów jeszcze większe obrzydliwości, które oni popełniają.
###### **Ez 8,14**
 I zaprowadził mię do wejścia w bramę Domu Jahwe, która znajdowała się po stronie północnej. A tam oto siedziały kobiet opłakujące Tammuza.
###### **Ez 8,15**
 Zapytał mię wtedy: Widziałeś, synu człowieczy? A zobaczysz znów jeszcze większe od tych obrzydliwości.
###### **Ez 8,16**
 Wprowadził mię na wewnętrzny dziedziniec Świątyni Jahwe. Oto wejście do miejsca Świętego Jahwe. Między przedsionkiem a ołtarzem stało około dwudziestu pięciu mężów. Każdy był odwrócony plecami do miejsca Świętego Jahwe, a twarze mieli zwrócone ku wschodowi. Padali oni na twarz przed słońcem w kierunku wschodu.
###### **Ez 8,17**
 Zapytał mię tedy: Widziałeś, synu człowieczy? Czyż to zbyt mało dla Domu Judy, iż popełnia obrzydliwości, które tu czynią? Napełnili bowiem kraj gwałtem, a [teraz] znowu mnie obrażają. Oto przykładają oni gałązkę do swych nosów.
###### **Ez 8,18**
 [Przeto] Ja także będę działał w gniewie. Moje oko nie wejrzy z litością i nie zmiłuje się. Głosem wielkim będą wołać do mych uszu, ale ich nie wysłucham.
# Ez 8 BR
###### **Ez 8,1**
 W piątym dniu szóstego miesiąca, roku szóstego byłem w moim domu. Byli też ze mną starsi Judy. I nagle spoczęła na mnie ręka Pańska.
###### **Ez 8,2**
 I zobaczyłem przed sobą jakby postać ludzką. Spod tego, co wyglądało jak biodro, wydostawał się ogień, powyżej zaś owych bioder świeciło coś jak najszlachetniejsze złoto.
###### **Ez 8,3**
 Postać ta wyciągnęła coś na kształt ręki, która uchwyciła mnie za włosy. Duch uniósł mnie w górę, tak że znalazłem się między ziemią a niebem i przeniósł mnie, w boskim, widzeniu, do Jerozolimy, [i postanowił] koło wejścia do wnętrza bramy Północnej, gdzie stoi posąg bożka zazdrości budzący zazdrość.
###### **Ez 8,4**
 Tam to zobaczyłem Chwałę Boga Izraela, taką samą, jak ta którą widziałem na równinie.
###### **Ez 8,5**
 Powiedział do mnie: Synu człowieczy, popatrz w stronę północną! Zwróciłem więc mój wzrok ku północy i zobaczyłem, nieco na północ od wejścia, ołtarz z posągiem, bożka zazdrości.
###### **Ez 8,6**
 Wtedy On powiedział do mnie: Synu człowieczy, czy widzisz, co się tu dzieje? Są to obrzydliwości, których dopuszcza się tu cały Dom Izraela, żeby Mnie odsunąć od mojego przybytku. Ale ty zobaczysz jeszcze większe obrzydliwości.
###### **Ez 8,7**
 Potem zawiódł mnie przed wejście na dziedziniec. Zobaczyłem tam dużą wyrwę w murze.
###### **Ez 8,8**
 Wtedy On powiedział do mnie: Synu człowieczy, przebij ten mur! Kiedy mur przebiłem, ujrzałem wejście.
###### **Ez 8,9**
 I powiedział do mnie: Wejdź i przypatrz się wszystkim obrzydliwościom, które się tam dzieją.
###### **Ez 8,10**
 Wszedłem więc tam i zobaczyłem mnóstwo podobizn odrażających małych i dużych zwierząt, a także wszystkie bóstwa Domu Izraela na wszystkich ścianach dokoła.
###### **Ez 8,11**
 Siedemdziesięciu spośród starszych domu Izraela - wśród nich Jaazaniasz, syn Szafana - stało na samym przedzie. Każdy z nich trzymał w ręku kadzielnicę, a w górę unosiły się obłoki wonnego dymu.
###### **Ez 8,12**
 A On powiedział do mnie: Synu człowieczy, czy widzisz, co czynią ci starsi Domu Izraela w ciemnościach, każdy w innej komnacie swego bóstwa? Pocieszają się przy tym myśląc, że Pan opuścił cały kraj.
###### **Ez 8,13**
 Potem powiedział do mnie: Przekonasz się, że czynią oni jeszcze większe obrzydliwości.
###### **Ez 8,14**
 I przywiódł mnie do bramy Północnej Domu Pańskiego, gdzie siedziały kobiety, opłakujące [odejście] boga Tammuza.
###### **Ez 8,15**
 Powiedział wtedy do mnie: Widziałeś, synu człowieczy? Zobaczysz jeszcze większe obrzydliwości.
###### **Ez 8,16**
 Potem zaprowadził mnie na dziedziniec wewnętrzny Domu Pańskiego. Przy wejściu do Świątyni Pańskiej, między przedsionkiem a ołtarzem, stało około dwudziestu pięciu mężów, zwróconych plecami do Świątyni Pańskiej, a twarzą - ku wschodowi. I tak, zwróceni ku wschodowi, modlili się do słońca.
###### **Ez 8,17**
 Powiedział mi tedy: Widziałeś, synu człowieczy? Czy Domowi Judy nie wystarczyły te obrzydliwości, których się tu dopuszczono? Czy muszą nadal cały kraj wypełniać swoimi obrzydliwościami? Czy muszą Mnie nadal tak obrażać, podnosząc gałązkę do nosa?
###### **Ez 8,18**
 Dlatego i Ja okażę im całe moje zagniewanie. Nic nie będzie w stanie skłonić mych oczu do litości i nikogo nie będę oszczędzał. I choćby głośno krzyczeli do mych uszu, nie będę ich słuchał.
# Ez 8 WUJ
###### **Ez 8,1**
 I stało się roku szóstego, w szóstym miesiącu dnia piątego, jam siedział w domu moim, a starszy Judzcy siedzieli przedemną: I padła tam na mię ręka Pana Boga.
###### **Ez 8,2**
 I ujrzałem, ano podobieństwo jako widzenie ognia, od widzenia biódr jego, i niżej ogień, a od biódr jego i wyżej jako widzenie jasności, jako pozór mosiądzu.
###### **Ez 8,3**
 I spuszczone podobieństwo ręki uchwyciło mię za kędzierze głowy mojej: i podniósł mię duch między ziemię, a niebo, i przywiódł mię do Jeruzalem w widzeniu Bożem podle bramy wnętrznej patrzącej ku północy, gdzie był postawion bałwan rzewliwości ku pobudzeniu zawiści.
###### **Ez 8,4**
 A oto tam chwała Boga Izraelowego, według widzenia, którem widział na polu.
###### **Ez 8,5**
 I rzekł do mnie: Synu człowieczy, podnieś oczy twe na drogę północną: i podniosłem oczy moje na drogę północną, a oto z północy bramy ołtarzowej bałwan rzewliwości w samem weszciu.
###### **Ez 8,6**
 I rzekł do mnie: Synu człowieczy, mnimaszli, że widzisz ty co ci czynią, obrzydłości wielkie, które tu działa dom Izraelski, abych daleko odstąpił od świątnice mojej? a jeszcze obróciwszy się ujrzysz obrzydliwości więtsze.
###### **Ez 8,7**
 I wwiódł mię do drzwi sieni: i ujrzałem ano dziura jedna w ścienie.
###### **Ez 8,8**
 I rzekł do mnie: Synu człowieczy przekopaj ścianę. A gdym przekopał ścianę, ukazały się drzwi jedne.
###### **Ez 8,9**
 I rzekł do mnie: Wnidź, a obacz obrzydłości barzo złe, które tu ci działają.
###### **Ez 8,10**
 I wszedłszy ujrzałem ano wszelkie podobieństwo płazów i zwierzów obrzydliwość, i wszelakie bałwany domu Izraelskiego wymalowane były na ścienie w około wszędy.
###### **Ez 8,11**
 A siedmdziesiąt mężów z starszych domu Izraelowego, i Jezoniasz syn Saphan stał na pośrodku onych stojących przed malowaniem, a każdy miał kadzielnicę w ręku swoich: a kurzawa obłoczna z kadzidła wstępowała.
###### **Ez 8,12**
 I rzekł do mnie: Iście widzisz synu człowieczy, co starszy domu Izraelowego dziełają w ciemności, każdy w skrytości komory swej? bo mówią: Nie widzi nas Pan: opuścił Pan ziemię.
###### **Ez 8,13**
 I rzekł do mnie: Jeszcze się obróciwszy ujrzysz obrzydliwości więtsze, które ci działają.
###### **Ez 8,14**
 I wiódł mię przez drzwi bramy domu Pańskiego, które patrzyły ku północy: a oto tam niewiasty siedziały płacząc Adonida.
###### **Ez 8,15**
 I rzekł do mnie: Iście widziałeś synu człowieczy? Jeszcze obróciwszy się ujrzysz obrzydliwości większe niźli te.
###### **Ez 8,16**
 I wwiódł mię do sieni domu Pańskiego wnętrznej: a oto u drzwi domu Pańskiego między przysionkiem a ołtarzem, jakmiarz dwadzieścia i pięć mężów tyły mające ku kościołowie Pańskiemu, a twarzy na wschód: a kłaniali się na wschód słońca.
###### **Ez 8,17**
 I rzekł do mnie: Iście widziałeś synu człowieczy: izali to lekka jest domowi Judzkiemu czynić obrzydłości te, które tu czynią? bo napełniwszy ziemię nieprawości, obrócili się ku drażnieniu mnie: a oto przykładają gałązkę do nosa swego.
###### **Ez 8,18**
 Przetoż i ja będę czynił w zapale żywości: nie sfolguje oko moje, ani się zmiłuje: a gdy będą wołać do uszu moich głosem wielkim, nie wysłucham ich.
