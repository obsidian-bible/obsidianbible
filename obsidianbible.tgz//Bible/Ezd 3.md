# Ezd 3 BT5
###### **Ezd 3,1**
  Gdy nadszedł siódmy miesiąc – a Izraelici mieszkali już w miastach swoich – wtedy zgromadził się cały lud, jak jeden mąż, w Jerozolimie.
###### **Ezd 3,2**
 A Jozue, syn Josadaka, i bracia jego, kapłani, oraz Zorobabel, syn Szealtiela, i bracia jego przystąpili do zbudowania ołtarza Boga izraelskiego, aby na nim złożyć całopalenia, jak napisano w Prawie Mojżesza, męża Bożego.
###### **Ezd 3,3**
 I na dawnym fundamencie wznieśli ołtarz, podczas gdy niebezpieczeństwo groziło im ze strony narodów pogranicznych, i złożyli na nim całopalenia dla Pana, całopalenia poranne i wieczorne.
###### **Ezd 3,4**
 Potem obchodzili Święto Namiotów według przepisów i składali ofiary codziennie w liczbie wyznaczonej, zgodnie z wymaganą każdego dnia należnością.
###### **Ezd 3,5**
 Następnie – oprócz całopalenia nieustającego – składali ofiary w szabaty, w dni nowiu i we wszystkie święte uroczystości Pańskie oraz zawsze, gdy ktoś dał dobrowolną ofiarę dla Pana.
###### **Ezd 3,6**
 Od pierwszego dnia miesiąca siódmego zaczęli składać całopalenia Panu – ale fundamenty świątyni Pańskiej nie były jeszcze położone.
###### **Ezd 3,7**
 Dali więc pieniędzy kamieniarzom i cieślom oraz żywności, napoju i oliwy Sydończykom i Tyryjczykom, by sprowadzili drewno cedrowe z Libanu morzem do Jafy na mocy pozwolenia udzielonego im przez Cyrusa, króla perskiego.
###### **Ezd 3,8**
 A w drugim roku od przybycia ich do domu Bożego w Jerozolimie, w drugim miesiącu, Zorobabel, syn Szealtiela, i Jozue, syn Josadaka, i szereg ich braci: kapłanów i lewitów oraz wszyscy, którzy wrócili z niewoli do Jerozolimy, zabrali się do dzieła i powołali lewitów od dwudziestego roku [życia] wzwyż do pilnowania pracy około domu Pańskiego.
###### **Ezd 3,9**
 A Jozue oraz synowie i bracia jego: Kadmiel, Binnuj i Hodawiasz, przystąpili wspólnie do kierowania lewitami wykonującymi pracę około domu Bożego: synami Chenadada, ich synami i braćmi.
###### **Ezd 3,10**
 A gdy budowniczowie położyli fundamenty świątyni Pańskiej, wtedy wystąpili kapłani w szatach uroczystych, z trąbami, i lewici, synowie Asafa, z cymbałami, by zgodnie z rozporządzeniem Dawida, króla izraelskiego, chwalić Pana;
###### **Ezd 3,11**
 i zaśpiewali, chwaląc Pana i dziękując Mu: Dobry On; na wieki trwa Jego łaska dla Izraela. A cały lud podniósł na chwałę Pana krzyk głośny, z powodu położenia fundamentów domu Pańskiego.
###### **Ezd 3,12**
 Wielu zaś starców spośród kapłanów, lewitów i naczelników rodów, którzy dawniej widzieli dom pierwszy, przy kładzeniu fundamentów tego domu, na ich oczach płakało głośno; wielu natomiast z radości wybuchało głośnym krzykiem.
###### **Ezd 3,13**
 I nie można było odróżnić głośnego krzyku radości od głośnego płaczu ludu, albowiem lud ten podniósł wrzawę tak wielką, że głos ten było słychać z daleka.
# Ezd 3 PAU
###### **Ezd 3,1**
 Gdy Izraelici mieszkali już w swoich miastach, z nadejściem siódmego miesiąca cały lud bez wyjątku zgromadził się w Jerozolimie.
###### **Ezd 3,2**
 Wówczas Jozue, syn Josadaka, wraz ze swymi braćmi kapłanami oraz Zorobabel, syn Szealtiela, wraz ze swymi braćmi wybudowali ołtarz dla Boga Izraela, by składać na nim ofiary całopalne zgodnie z przepisami Prawa danego przez Mojżesza, męża Bożego.
###### **Ezd 3,3**
 Wznieśli ołtarz na dawnych fundamentach, mimo wrogości sąsiednich ludów, i złożyli na nim ofiary całopalne dla PANA, ofiary poranne i wieczorne.
###### **Ezd 3,4**
 Potem obchodzili zgodnie z przepisami Święto Namiotów. Składali każdego dnia ofiary całopalne według ustalonej liczby i przepisów Prawa wyznaczającego odpowiednią ofiarę na każdy dzień.
###### **Ezd 3,5**
 Składali więc ofiary całopalne, nieustanne, sobotnie, ofiary w dni nowiu i we wszystkie uroczyste święta PANA, oraz ofiary dobrowolne i przynoszone indywidualnie dla PANA.
###### **Ezd 3,6**
 Ofiary całopalne zaczęto składać od pierwszego dnia siódmego miesiąca, ale fundamenty świątyni PANA nie były jeszcze położone.
###### **Ezd 3,7**
 Zatrudnili więc za opłatą kamieniarzy i cieśli i zaopatrzyli w żywność, napój i oliwę Sydończykówi Syryjczyków, żeby przywozili drewno cedrowe z Libanu drogą morską do Jafy, zgodnie z zezwoleniem udzielonym im przez Cyrusa, króla perskiego.
###### **Ezd 3,8**
 Zorobabel, syn Szealtiela, i Jozue, syn Josadaka, wraz z resztą ich braci kapłanów i lewitów, i ze wszystkimi repatriantami, którzy zamieszkali w Jerozolimie, rozpoczęli pracę w drugim miesiącu drugiego roku od ich przybycia do domu Bożego w Jerozolimie. Najpierw wyznaczyli lewitów od dwudziestego roku wzwyż do pracy przy budowie domu PANA.
###### **Ezd 3,9**
 Następnie Jozue, jego synowie i bracia, Kadmiel wraz ze swymi synami i synowie Hodawiasza zgłosili się razem do kierowania przebiegiem prac wokół domu Bożego. Podobnie i synowie Chenadada wraz z ich synami i braćmi, lewitami.
###### **Ezd 3,10**
 Gdy budowniczowie położyli fundamenty świątyni PANA, wystąpili kapłani w szatach uroczystych, z trąbami, i lewici, potomkowie Asafa, z cymbałami, aby śpiewać PANU pieśni pochwalne zgodnie z postanowieniami Dawida, króla Izraela.
###### **Ezd 3,11**
 Śpiewali pieśni uwielbienia i wysławiali PANA, bo jest dobry, bo Jego łaska trwa na wieki nad Izraelem. Zgromadzony zaś lud odpowiadał okrzykami wielkiej radości, wielbiąc PANA za to, że położono fundamenty domu PANA.
###### **Ezd 3,12**
 Wielu spośród podeszłych wiekiem kapłanów i lewitów oraz przywódców rodów, którzy pamiętali jeszcze tamten pierwszy dom, głośno płakało na widok położonych fundamentów tego domu, podczas gdy inni radowali się i wznosili entuzjastyczne okrzyki.
###### **Ezd 3,13**
 Nie można było odróżnić okrzyków radości od szlochu płaczących, tak wielka była wrzawa, której odgłosy dało się słyszeć z daleka.
# Ezd 3 BP
###### **Ezd 3,1**
 Kiedy nadszedł siódmy miesiąc, a Izraelici znajdowali się już w swoich miastach, zgromadził się lud jak jeden mąż w Jeruzalem.
###### **Ezd 3,2**
 Wówczas wystąpili Jozue, syn Jocadaka, ze swoimi braćmi kapłanami, oraz Zorobabel, syn Szealtiela, ze swoimi braćmi i poczęli budować ołtarz Boga Izraela, aby na nim składać ofiarę całopalną, jak jest napisane w Prawie Mojżesza, męża Bożego.
###### **Ezd 3,3**
 Zbudowali ołtarz na jego dawnych fundamentach, chociaż odczuwali lęk przed ludnością tego kraju. I składali na nim ofiarę całopalną dla Jahwe, ofiarę całopalną rano i wieczorem.
###### **Ezd 3,4**
 Obchodzili Święto Namiotów zgodnie z przepisem i składali co dzień tyle ofiar całopalnych, ile zostało ustalonych na każdy dzień.
###### **Ezd 3,5**
 Następnie składali ofiarę całopalną codzienną, a także ofiarę w [Święto] Nowiu i na wszystkie uroczyste święta Jahwe; prócz tego także [ofiarę] z wszystkich dobrowolnych darów, jakie każdy składał dla Jahwe.
###### **Ezd 3,6**
 Pierwszego dnia siódmego miesiąca zaczęli składać ofiary całopalne dla Jahwe, chociaż fundament pod Przybytek Jahwe nie został jeszcze położony.
###### **Ezd 3,7**
 Dawano kamieniarzom i cieślom pieniądze oraz [dostarczano] mieszkańcom Sydonu i Tyru żywność i napoje, jak również oliwę, aby [w zamian za to] przewozili morzem drzewo cedrowe z Libanu do Jaffy - zgodnie z zezwoleniem Cyrusa, króla Persji.
###### **Ezd 3,8**
 W drugim roku po ich przybyciu do Świątyni Boga w Jeruzalem, w drugim miesiącu, Zorobabel, syn Szealtiela, i Jozue, syn Jocadaka, i pozostali ich bracia, kapłani i lewici i wszyscy, którzy przybyli z wygnania do Jeruzalem, rozpoczęli [przygotowania do budowy]. Ustanowili oni lewitów od dwudziestego roku życia wzwyż do kierowania robotami przy budowie Świątyni Jahwe.
###### **Ezd 3,9**
 Jozue, jego synowie i bracia, jak również Kadmiel i jego synowie, potomkowie Hodawji, stanęli jak jeden mąż gotowi czuwać nad robotnikami przy [budowie] Świątyni Boga, podobnie jak potomkowie Chenadady ze swoimi synami i braćmi.
###### **Ezd 3,10**
 Kiedy budowniczowie położyli fundamenty pod Świątynię Jahwe, zarządzono, by kapłani wystąpili w uroczystych szatach z trąbami, lewici, potomkowie Asafa, z cymbałami, ażeby sławić Jahwe zgodnie z przepisami Dawida, króla Izraela.
###### **Ezd 3,11**
 Śpiewali oni na cześć i chwałę Jahwe: "gdyż dobry On jest, gdyż łaska Jego trwa na wieki nad Izraelem". Cały lud wydawał głośne okrzyki wielbiąc Jahwe z powodu położenia fundamentów pod Świątynię Jahwe.
###### **Ezd 3,12**
 Wielu zaś kapłanów, lewitów i przywódców rodów, którzy byli starzy i oglądali jeszcze pierwszą Świątynię, płakało w głos, gdy na ich oczach kładziono pod nią fundamenty, podczas gdy wielu innych krzyczało rozgłośnie, w uniesieniu i radości.
###### **Ezd 3,13**
 I tak niepodobna było odróżnić okrzyków wesela i radości od głośnego płaczu ludu; lud bowiem wydawał tak głośne okrzyki, że krzyk ten słychać było z daleka.
# Ezd 3 BR
###### **Ezd 3,1**
 Gdy nadszedł siódmy miesiąc i synowie Izraela osiedli na nowo w swoich miastach, cały lud, jak jeden mąż, zebrał się w Jerozolimie.
###### **Ezd 3,2**
 Jozue, syn Josadaka, razem ze swymi braćmi, kapłanami, i Zorobabel, syn Szealtiela, i jego bracia zabrali się do pracy i zbudowali ołtarz dla Boga Izraela, by móc składać ofiary całopalenia, zgodnie z tym, co jest napisane w prawie męża Bożego Mojżesza.
###### **Ezd 3,3**
 Ustawili ołtarz na jego dawnym fundamencie, chociaż bali się jeszcze mieszkańców sąsiednich krain, i złożyli tam ofiary całopalne na cześć Jahwe, całopalenia poranne i wieczorne.
###### **Ezd 3,4**
 Obchodzili też zgodnie z przepisami święto Namiotów i składali codziennie ofiary całopalenia w liczbie wyznaczonej na każdy dzień przez prawo.
###### **Ezd 3,5**
 Potem zaczęli składać całopalenie nieustanne, ofiary całopalenia z okazji nowiu księżycowego oraz we wszystkie święta Pańskie, a także wszystkie te ofiary dobrowolne, o których złożenie na cześć Jahwe ktokolwiek prosił.
###### **Ezd 3,6**
 Od pierwszego dnia siódmego miesiąca składali już ofiary całopalenia na cześć Jahwe, ale nowe fundamenty świątyni ciągle jeszcze nie były położone.
###### **Ezd 3,7**
 Przekazano zatem pieniądze kamieniarzom i cieślom, przesłano także odpowiednią ilość żywności, napojów i oliwy mieszkańcom Sydonu i Tyru, żeby za to drogą morską przysłali do Jafy drewno cedrowe z Libanu, zgodnie z pozwoleniem uzyskanym od Cyrusa, króla Persów.
###### **Ezd 3,8**
 W drugim roku od swego przybycia do świątyni Bożej w Jerozolimie, w drugim miesiącu Zorobabel, syn Szealtiela, i Jozue, syn Josadaka, oraz wielu spośród ich braci, kapłanów i lewitów, i wszyscy ci, którzy wrócili z wygnania i osiedli w Jerozolimie, przystąpili do pracy. Najpierw wybrali spośród lewitów tych, którzy już mieli co najmniej dwadzieścia lat, i starszych, powierzając im pieczę nad budową świątyni Jahwe.
###### **Ezd 3,9**
 Jozue i jego synowie oraz bracia, a także Kadmiel i jego synowie, potomkowie Hodawiasza, sami zgłosili swoją gotowość nadzorowania tych, którzy mieli pracować przy budowie świątyni Pańskiej. To samo uczynili synowie Chenadada oraz ich synowie i bracia, także lewici.
###### **Ezd 3,10**
 Kiedy robotnicy położyli już fundamenty pod świątynię Jahwe, wtedy przyszli kapłani, ubrani w swoje szaty, z trąbami w rękach, a także lewici, synowie Asafa, z cymbałami, żeby zgodnie z poleceniem Dawida, króla izraelskiego, śpiewać pieśni uwielbienia na cześć Jahwe.
###### **Ezd 3,11**
 Zaczęli tedy wielbić Jahwe i śpiewać na Jego cześć: Dobry jest i na wieki miłosierdzie Jego. Cały lud wykrzykiwał przy tym radośnie, dziękując Jahwe za to, że zdołano położyć fundamenty świątyni Jahwe.
###### **Ezd 3,12**
 Bardzo wielu kapłanów i lewitów oraz starszych przywódców rodów, tych, którzy jeszcze pamiętali pierwszą świątynię, płakało, gdy w ich obecności kładziono nowe fundamenty. Bardzo wielu krzyczało z radości i uniesienia.
###### **Ezd 3,13**
 Nie można było w końcu odróżnić okrzyków radości od zawodzenia płaczących. Wszystko zlewało się w głos tak potężny, że słychać go było z daleka.
# Ezd 3 WUJ
###### **Ezd 3,1**
 I już był przyszedł miesiąc siódmy, a synowie Izraelowi byli w mieściech swoich: zgromadził się tedy wszystek lud jako mąż jeden do Jeruzalem.
###### **Ezd 3,2**
 I powstał Jozue syn Josedek, i bracia jego kapłani, i Zorobabel syn Salathiel, i bracia jego, i zbudowali ołtarz Bogu Izraelowemu, aby na nim ofiarowali całopalenia, jako napisano w zakonie Mojżesza męża Bożego.
###### **Ezd 3,3**
 A ołtarz Boży postawili na podstawkach jego, gdy ich narodowie okolicznych ziem odstraszali, i ofiarowali na nim całopalenie Panu po ranu i w wieczór.
###### **Ezd 3,4**
 I uczynili święto Kuczek, jako napisano jest, i całopalenie na każdy dzień porządnie według przykazania, robotę dnia w dzień jej.
###### **Ezd 3,5**
 A potem całopalenie ustawiczne, tak w pierwsze dni miesiąca, jako i we wszystkie uroczyste święta Pańskie, które były poświęcone, i we wszystkich, w których z chęci był ofiarowany dar Panu.
###### **Ezd 3,6**
 Od pierwszego dnia miesiąca siódmego poczęli ofiarować całopalenie Panu: a kościół Boży jeszcze nie był założony.
###### **Ezd 3,7**
 I dali pieniądze kamiennikom i murarzom: strawę też i picie i oliwę Sydończykom i Tyryjczykom, aby prowadzili drzewo Cedrowe z Libanu do morza Joppe wedle tego, jako im był Cyrus król Perski przykazał.
###### **Ezd 3,8**
 A roku wtórego przyścia ich do kościoła Bożego do Jeruzalem, miesiąca wtórego, zaczęli Zorobabel syn Salathiel i Jozue syn Josedek i inni z braciej ich kapłani i Lewitowie, i wszyscy, którzyby przyszli z pojmania do Jeruzalem, i postanowili Lewity od dwudziestu lat i wyżej, aby przynaglali robocie Pańskiej.
###### **Ezd 3,9**
 I stanął Jozue, i synowie jego, i bracia jego Cedmihel, i synowie jego, i synowie Juda, jakon: aż jeden, aby przypilnowali tych którzy robili w kościele Bożym: synowie Henadad, i synowie ich, i ich bracia Lewitowie.
###### **Ezd 3,10**
 Gdy tedy założyli murarze Kościół Pański, stanęli kapłani w ubiorze swoim, z trąbami: a Lewitowie synowie Asaph z cymbałami, aby chwalili Boga przez ręce Dawida króla Izraelskiego.
###### **Ezd 3,11**
 I śpiewali pieśni i wyznawanie Panu: Iż dobry, iż na wieki miłosierdzie jego nad Izraelem. Wszystek też lud krzyczał krzykiem wielkim, chwaląc Pana z tego, iż był założon kościół Pański.
###### **Ezd 3,12**
 Mnodzy też z kapłanów i z Lewitów, i przedniejszy ojców, i starcowie, którzy widzieli kościół pierwszy gdy był założony, i ten kościół przed oczyma swemi, płakali głosem wielkim: a mnodzy krzycząc w radości, głos podnosili.
###### **Ezd 3,13**
 I nie mógł żaden poznać głosu krzyczenia weselących się i głosu płaczu ludu: abowiem lud społecznie krzyczał głosem wielkim, i głos daleko było słyszeć.
