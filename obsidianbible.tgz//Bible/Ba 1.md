# Ba 1 BT5
###### **Ba 1,1**
 Oto słowa księgi, którą w Babilonie napisał Baruch, syn Neriasza, syna Machsejasza, syna Sedecjasza, syna Asadiasza, syna Chilkiasza,
###### **Ba 1,2**
 w piątym roku, siódmego dnia miesiąca od czasu, jak Chaldejczycy zajęli Jerozolimę i zniszczyli ją ogniem.
###### **Ba 1,3**
 Słowa tej księgi czytał Baruch wobec Jechoniasza, syna Jojakima, króla judzkiego, wobec całego ludu przychodzącego na to czytanie,
###### **Ba 1,4**
 wobec możnych, synów królewskich, starszyzny, wobec całego ludu, od najmniejszego aż do największego, wobec wszystkich mieszkających w Babilonie nad rzeką Sud.
###### **Ba 1,5**
 A oni płakali, pościli i modlili się przed Panem.
###### **Ba 1,6**
 Nazbierali też srebra, ile kto mógł dać,
###### **Ba 1,7**
 posłali je do Jerozolimy, do kapłana Jojakima, syna Chilkiasza, syna Szalluma, i do <innych> kapłanów, do całego ludu i do znajdujących się z nim w Jerozolimie.
###### **Ba 1,8**
 Wówczas też Baruch otrzymał [z powrotem] dnia dziesiątego miesiąca Siwan zabrane niegdyś ze świątyni naczynia domu Pańskiego, aby je zawieźć do ziemi judzkiej, srebrne naczynia, które sprawił Sedecjasz, syn Jozjasza, król judzki,
###### **Ba 1,9**
 [zabrane] potem, gdy uprowadził Nabuchodonozor, król babiloński, Jechoniasza, zwierzchników, rzemieślników, możnych wraz z ludem pospolitym z Jerozolimy i zaprowadził ich do Babilonu.
###### **Ba 1,10**
 Rzekli: Posyłamy wam srebro, kupcie za nie, [czego potrzeba] na całopalenie, ofiarę zadośćuczynienia i kadzenia, uczyńcie też mannę i ofiarujcie na ołtarzu Pana, Boga naszego.
###### **Ba 1,11**
 Módlcie się o zdrowie Nabuchodonozora, króla babilońskiego, i o zdrowie Baltazara, syna jego, aby były ich dni na ziemi jak dni nieba.
###### **Ba 1,12**
 Niech nam Pan da męstwo, niech oświeci nasze oczy, byśmy mogli żyć pod osłoną Nabuchodonozora, króla babilońskiego, i pod osłoną Baltazara, jego syna; byśmy im służyli przez wiele dni i znaleźli u nich łaskę.
###### **Ba 1,13**
 Módlcie się też i za nas do Pana, Boga naszego, ponieważ zgrzeszyliśmy przeciw Niemu, a zapalczywość i gniew Jego do obecnej chwili nie odwróciły się od nas.
###### **Ba 1,14**
 Przyjmijcie tę księgę, którą wam przesyłamy, aby była odczytywana w dniu święta i w dniach zebrań.
###### **Ba 1,15**
 Mówić będziecie: Panu, Bogu naszemu, [należna jest] sprawiedliwość, nam zaś rumieniec wstydu na twarzy, jak to jest obecnie, oraz każdemu człowiekowi na ziemi judzkiej i mieszkańcom Jeruzalem,
###### **Ba 1,16**
 królom, zwierzchnikom, kapłanom, prorokom i przodkom naszym,
###### **Ba 1,17**
 ponieważ zgrzeszyliśmy przed Panem,
###### **Ba 1,18**
 nie wierzyliśmy Jemu, nie byliśmy posłuszni głosowi Pana, Boga naszego, by pójść za przykazaniami, które nam dał.
###### **Ba 1,19**
 Od czasu, kiedy Pan wyprowadził przodków naszych z ziemi egipskiej, aż do dnia dzisiejszego byliśmy niewierni wobec Pana, Boga naszego, byliśmy tak niedbali, iż nie słuchaliśmy Jego głosu.
###### **Ba 1,20**
 Przylgnęły przeto do nas nieszczęścia i przekleństwo, jakimi Pan zagroził przez Mojżesza, sługę swego, w dniu, w którym wyprowadził przodków naszych z Egiptu, aby nam dać ziemię opływającą w mleko i miód, jak to jest i obecnie.
###### **Ba 1,21**
 Nie byliśmy posłuszni głosowi Pana, Boga naszego, [przekazanemu] we wszystkich mowach proroków, których posłał do nas.
###### **Ba 1,22**
 Każdy chodził według zamysłów swego złego serca, służyliśmy bowiem cudzym bogom i czyniliśmy, co jest złe w oczach Pana, Boga naszego.
# Ba 1 PAU
###### **Ba 1,1**
 Oto słowa księgi, którą w Babilonie napisał Baruch, syn Neriasza, syna Machsejasza, syna Sedecjasza, syna Asadiasza, syna Chilkiasza.
###### **Ba 1,2**
 Było to w piątym roku, siódmego dnia miesiąca od czasu, kiedy Chaldejczycy zdobyli i spalili Jeruzalem.
###### **Ba 1,3**
 Słowa tej księgi odczytał Baruch w obecności króla judzkiego Jechoniasza, syna Jojakima, oraz wobec całego ludu, który zgromadził się wokół księgi.
###### **Ba 1,4**
 Tak więc słuchali go możni, dworzanie, starszyzna i cały lud, od najmniejszego do największego, wszyscy mieszkający w Babilonie nad rzeką Sud.
###### **Ba 1,5**
 A potem płakali, pościli i modlili się do PANA.
###### **Ba 1,6**
 Następnie zebrano srebro, ile tylko każdy mógł dać,
###### **Ba 1,7**
 i posłano je do Jeruzalem, do kapłana Jojakima, syna Chilkiasza, syna Szaloma oraz do innych kapłanów i do całego ludu będącego z Jojakimem w Jeruzalem.
###### **Ba 1,8**
 Dziesiątego dnia miesiąca Siwan Baruch odebrał naczynia domu Pańskiego, zrabowane niegdyś ze świątyni. Miał je zwrócić do kraju Judy. Były to te srebrne naczynia, które kazał zrobić Sedecjasz, syn Jozjasza, król Judy.
###### **Ba 1,9**
 Zabrał je Nabuchodonozor, król babiloński, gdy przesiedlił z Jeruzalem do Babilonu króla Jechoniasza z książętami, a wraz z nimi wziął w niewolę możnych i lud tej ziemi.
###### **Ba 1,10**
 Zebrane srebro przekazano do Jeruzalem z takimi oto słowami: „Posyłamy wam srebro. Kupcie za nie wszystko, czego potrzeba na ofiarę całopalną, przebłagalną i kadzielną, abyście mogli złożyć ofiary na ołtarzu PANA, BOGA naszego.
###### **Ba 1,11**
 Módlcie się też o pomyślność króla babilońskiego Nabuchodonozora oraz jego syna Baltazara, aby ich życie trwało tak długo, jak trwa niebo nad ziemią.
###### **Ba 1,12**
 Wówczas PAN udzieli nam pomyślności i właściwego rozeznania, byśmy mogli żyć pod opieką króla babilońskiego Nabuchodonozora i jego syna Baltazara i byśmy im służyli przez długie lata, ciesząc się ich życzliwością.
###### **Ba 1,13**
 Módlcie się też do PANA, BOGA naszego, za nas, bo zgrzeszyliśmy przeciwko Niemu i aż dotąd Jego gniew nie przestaje płonąć nad nami.
###### **Ba 1,14**
 Zapoznajcie się dobrze z księgą, którą wam przesyłamy. Niech będzie czytana publicznie w domu Pańskim w dniach waszych świątecznych zgromadzeń.
###### **Ba 1,15**
 I powiecie: „PANU, Bogu naszemu, należy się sprawiedliwość, nam zaś wstyd, jak to jest obecnie! Wstyd ludziom Judy i mieszkańcom Jeruzalem,
###### **Ba 1,16**
 wszystkim naszym królom i książętom, naszym kapłanom i prorokom oraz naszym przodkom!
###### **Ba 1,17**
 Bo zgrzeszyliśmy przeciw PANU.
###### **Ba 1,18**
 Nie byliśmy Mu ulegli i nie słuchaliśmy głosu PANA, BOGA naszego, i nie postępowaliśmy według przykazań, które nam przekazał.
###### **Ba 1,19**
 Nie słuchaliśmy głosu PANA, BOGA naszego, nie byliśmy Mu posłuszni od dnia, kiedy PAN wyprowadził naszych przodków z Egiptu. I tacy pozostaliśmy do dnia dzisiejszego.
###### **Ba 1,20**
 Dlatego przylgnęły do nas nieszczęścia i przekleństwo, którymi zagroził nam PAN przez sługę swego Mojżesza, kiedy wyprowadził naszych przodków z ziemi egipskiej, aby dać nam ziemię, opływającą w mleko i miód, jak to jest do dnia dzisiejszego.
###### **Ba 1,21**
 Nie słuchaliśmy nie tylko głosu PANA, BOGA naszego, ale i żadnego z proroków, których On posyłał do nas.
###### **Ba 1,22**
 Każdy postępował według złych zamysłów swego serca, tak iż służyliśmy obcym bogom i robiliśmy to, co nie podobało się PANU, naszemu Bogu.
# Ba 1 BP
###### **Ba 1,1**
 Oto słowa Księgi, które w Babilonie spisał Baruch, syn Nerii, syna Maasai, syna Sedeki, syna Asadji, syna Chelkii,
###### **Ba 1,2**
 w piątym roku, siódmego dnia miesiąca od czasu, kiedy Chaldejczycy zdobyli Jeruzalem i spalili je.
###### **Ba 1,3**
 Baruch czytał słowa tej Księgi w obecności króla Jechoniasza, syna Jojakima, króla judzkiego, w obecności wszystkiego ludu, który gromadził się, aby [słuchać słów] tej Księgi,
###### **Ba 1,4**
 i w obecności możnych i synów królewskich, a także w obecności starszyzny i całego ludu od najmłodszego aż do najstarszego, w obecności wygnańców osiedlonych w Babilonie nad rzeką Sud.
###### **Ba 1,5**
 A oni płakali, pościli i modlili się przed Panem.
###### **Ba 1,6**
 Zebrali też pieniądze [każdy] według swoich możliwości.
###### **Ba 1,7**
 Przesłali je następnie do Jeruzalem na ręce kapłana Jojakima, syna Chelkii, syna Salluma, oraz na ręce [innych] kapłanów i wszystkiego ludu, który znajdował się z nim w Jeruzalem.
###### **Ba 1,8**
 [Działo się to w owym czasie, kiedy Baruch] otrzymał także z powrotem dnia dziesiątego [miesiąca] Siwan naczynia Domu Pańskiego, które zrabowano ze Świątyni, aby je zabrać do Ziemi Judzkiej, te srebrne naczynia, które polecił sporządzić Sedecjasz, syn Jozjasza, król judzki,
###### **Ba 1,9**
 po tym, jak Nabuchodonozor, król babiloński, uprowadził z Jeruzalem Jechoniasza i przełożonych, jeńcowi możnych i lud ziemi i przywiódł ich do Babilonii.
###### **Ba 1,10**
 Przekazali [im] wyjaśnienie: Oto wysyłamy wam pieniądze. Kupcie za nie ofiary całopalne i przebłagalne, a także kadzidło. Przygotujcie też ofiary z pokarmów i ofiarujcie je na ołtarzu Pana, naszego Boga.
###### **Ba 1,11**
 Zanoście modły za życie Nabuchodonozora, króla Babilonii, i za życie Baltazara, jego syna, aby dni ich na ziemi były jako dni niebios.
###### **Ba 1,12**
 Oby Pan obdarzył nas męstwem i oświecił nasze oczy, abyśmy pod opieką Nabuchodonozora, króla babilońskiego, i w cieniu jego syna Baltazara żyli [spokojnie] i służyli im przez długie dni i byśmy u nich mogli znaleźć łaskę!
###### **Ba 1,13**
 Módlcie się także za nas do Pana, Boga naszego! Zgrzeszyliśmy bowiem przed Panem, naszym Bogiem, a zapalczywość Pana i Jego gniew nie odwrócił się jeszcze od nas aż do dnia dzisiejszego.
###### **Ba 1,14**
 Przyjmijcie tę Księgę, którą wam przysyłamy, aby była odczytywana w Domu Pańskim w dniu święta i w [inne] dni wyznaczone.
###### **Ba 1,15**
 Będziecie mówić:
###### **Ba 1,16**
 naszym królom i zwierzchnikom, naszym kapłanom i prorokom, a także naszym ojcom,
###### **Ba 1,17**
 bośmy zgrzeszyli przeciwko Panu;
###### **Ba 1,18**
 byliśmy nieposłuszni wobec Niego, nie słuchaliśmy głosu Pana, Boga naszego, abyśmy postępowali według Jego przykazań, które nam podał.
###### **Ba 1,19**
 Począwszy od dnia, kiedy Pan wyprowadził naszych ojców z ziemi egipskiej, aż do dnia dzisiejszego byliśmy oporni wobec Pana, Boga naszego, i uciekaliśmy od słuchania Jego głosu.
###### **Ba 1,20**
 Dlatego przywarło do nas zło i przekleństwo, jakie Pan [nam] zapowiedział przez swego sługę Mojżesza, w on dzień, w który wyprowadził naszych ojców z ziemi egipskiej, aby nam dać ziemię płynącą mlekiem i miodem, jak to jest jeszcze i dziś.
###### **Ba 1,21**
 Nie słuchaliśmy jednak głosu Pana, Boga naszego [wołającego do nas] każdym słowem Proroków, których do nas posyłał,
###### **Ba 1,22**
 ale każdy postępował według skłonności swego złego serca, służąc cudzym bogom, czyniąc zło przed oczyma Pana, Boga naszego.
# Ba 1 BR
###### **Ba 1,1**
 Oto księga, którą napisał w Babilonie Baruch, syn Neriasza, syna Machsejasza, syna Sedecjasza, syna Asadiasza, syna Chilkiasza.
###### **Ba 1,2**
 Było to w piątym roku, siódmego dnia piątego miesiąca, od czasu, kiedy to Chaldejczycy zdobyli i podpalili Jerozolimę.
###### **Ba 1,3**
 Słowa zapisane w tej księdze odczytał Baruch przed królem judzkim Jechoniaszem, synem Jojakima, i wobec całego ludu, który specjalnie został zwołany, aby słuchać [słowa Bożego].
###### **Ba 1,4**
 Słuchali go więc urzędnicy królewscy oraz książęta, starsi, a także cały lud - od najmniejszych aż do największych - wszyscy mieszkańcy Babilonu osiedleni nad rzeką Sud.
###### **Ba 1,5**
 Poczęto wtedy płakać, pościć i żalić się przed Panem.
###### **Ba 1,6**
 Potem zebrano pieniądze - każdy dawał tyle, ile tylko mógł -
###### **Ba 1,7**
 posłano je do Jerozolimy, na ręce kapłana Jojakima, syna Chilkiasza, syna Szaloma, oraz na ręce innych kapłanów, dla całego ludu, który się jeszcze znajdował w Jerozolimie.
###### **Ba 1,8**
 Baruch sam otrzymał dziesiątego dnia miesiąca Siwan różne święte naczynia, które zostały kiedyś zabrane ze Świątyni. Miały one być teraz odesłane z powrotem mieszkańcom Judy. Były tam wszystkie te srebrne naczynia, które król judzki Sedecjasz, syn Jozjasza, kazał wykonać wtedy,
###### **Ba 1,9**
 kiedy król babiloński Nabuchodonozor pojmał w Jerozolimie Jechoniasza i uprowadził go do Babilonu razem z urzędnikami, rzemieślnikami, nadzorcami i pozostałymi mieszkańcami kraju.
###### **Ba 1,10**
 Ci, co złożyli swoje ofiary, prosili, żeby powiedzieć: Posyłamy wam pieniądze na całopalenie, na ofiary przebłagalne i na kadzidła oraz na ofiary z pokarmów. Złóżcie wszystko na ołtarzu naszego Pana i Boga
###### **Ba 1,11**
 i pomódlcie się o pomyślność dla króla babilońskiego, Nabuchodonozora, oraz za jego syna Baltazara. [Proście Boga], aby liczba ich dni była tak wielka, jak dni niebios nad ziemią.
###### **Ba 1,12**
 Nas zaś niech wspiera Pan swoją siłą i niech dodaje blasku oczom naszym, byśmy mogli żyć pod opieką króla babilońskiego, Nabuchodonozora, i jego syna, Baltazara; byśmy im przez długie lata służyli, ciesząc się zawsze ich łaskawością.
###### **Ba 1,13**
 Módlcie się także za nas do Pana i Boga naszego, bo zgrzeszyliśmy przeciwko Panu i Bogu naszemu, a zapalczywość Jego gniewu nie odwróciła się od nas do dnia dzisiejszego.
###### **Ba 1,14**
 Odczytajcie również słowa zawarte w księdze, którą wam posyłamy, abyście potem sami w każde święto i w dniach waszych zgromadzeń mogli się modlić w Świątyni Pańskiej.
###### **Ba 1,15**
 Modlić się zaś będziecie tak: Panu i Bogu naszemu sprawiedliwość[oddajmy], wstyd zaś niech pokryje oblicza nam wszystkim, mieszkańcom Judy i Jerozolimy,
###### **Ba 1,16**
 naszym królom i urzędnikom, naszym kapłanom i prorokom oraz ojcom naszym.
###### **Ba 1,17**
 Zgrzeszyliśmy bowiem przeciwko Panu naszemu;
###### **Ba 1,18**
 bo nie byliśmy Mu posłuszni. Nie słuchaliśmy głosu naszego Pana i Boga i nie wypełnialiśmy nakazów, które Pan nam dawał.
###### **Ba 1,19**
 Od dnia, w którym Pan wyprowadził naszych ojców z Egiptu, aż do dnia dzisiejszego byliśmy nieposłuszni Panu i Bogu naszemu. Wkrótce przestaliśmy w ogóle słuchać głosu Jego.
###### **Ba 1,20**
 Spadły za to na nas nieszczęścia i przekleństwo, którym zagroził nam Pan przez sługę swego, Mojżesza, kiedy nas wyprowadzał z ziemi egipskiej, żeby nam dać w posiadanie krainę mlekiem i miodem płynącą, jak to jest do dnia dzisiejszego.
###### **Ba 1,21**
 Nie słuchaliśmy głosu ani naszego Pana i Boga, ani wszystkich nawoływań proroków, którzy byli posyłani do nas.
###### **Ba 1,22**
 Każdy z nas szedł za upodobaniami swego przewrotnego serca. Służyliśmy obcym bogom i czyniliśmy to, co nie podobało się naszemu Bogu.
# Ba 1 WUJ
