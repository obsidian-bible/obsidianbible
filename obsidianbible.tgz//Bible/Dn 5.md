# Dn 5 BT5
###### **Dn 5,1**
 Król Baltazar urządził dla swych możnowładców w liczbie tysiąca wielką ucztę i pił wino wobec tysiąca [osób].
###### **Dn 5,2**
 Gdy zasmakował w winie, rozkazał Baltazar przynieść srebrne i złote naczynia, które jego ojciec, Nabuchodonozor, zabrał ze świątyni w Jerozolimie, aby mogli z nich pić król oraz jego możnowładcy, jego żony i nałożnice.
###### **Dn 5,3**
 Przyniesiono więc złote i srebrne naczynia zabrane ze świątyni w Jerozolimie; pili z nich król, jego możnowładcy, jego żony i jego nałożnice.
###### **Dn 5,4**
 Pijąc wino, wychwalali bożków złotych i srebrnych, miedzianych i żelaznych, drewnianych i kamiennych.
###### **Dn 5,5**
 W tej chwili ukazały się palce ręki ludzkiej i pisały za świecznikiem na wapnie ściany królewskiego pałacu. Król zaś widział piszącą rękę.
###### **Dn 5,6**
 Twarz króla zmieniła się, myśli jego napełniły się przerażeniem, jego stawy biodrowe uległy rozluźnieniu, a kolana jego uderzały jedno o drugie.
###### **Dn 5,7**
 Zakrzyknął król, by wprowadzono wróżbitów, Chaldejczyków i astrologów. Zwrócił się król do mędrców babilońskich i rzekł: «***Każdy, kto przeczyta to pismo i wyjaśni mi je, ma być odziany w purpurę i złoty łańcuch na szyję i ma panować w moim kraju jako trzeci***».
###### **Dn 5,8**
 Przystąpili więc wszyscy mędrcy królewscy, ale nie mogli odczytać pisma ani podać wyjaśnienia królowi.
###### **Dn 5,9**
 Wtedy Baltazar przeraził się bardzo i zmienił się na twarzy, a jego możnowładców ogarnęło zmieszanie.
###### **Dn 5,10**
 Królowa, na słowa króla i możnowładców, weszła do sali biesiadnej. Odezwała się królowa i rzekła: «***Królu, żyj wiecznie! Nie lękaj się swoich myśli i nie mień się na twarzy!
###### **Dn 5,11**
 Jest w twoim królestwie mąż, który ma w sobie ducha świętych bogów; w czasach twego ojca znaleziono w nim światło rozumu i mądrość podobną do mądrości bogów. Ojciec twój, król Nabuchodonozor, ustanowił go zwierzchnikiem tłumaczących sny, wróżbitów, Chaldejczyków i astrologów,
###### **Dn 5,12**
 ponieważ stwierdzono u Daniela, któremu król nadał imię Belteszassar, nadzwyczajnego ducha, wiedzę i rozwagę, umiejętność tłumaczenia snów, wyjaśniania rzeczy zagadkowych i rozwiązywania zawiłych. Każ więc zawołać Daniela, a on ci wskaże znaczenie***».
###### **Dn 5,13**
 Wtedy przyprowadzono Daniela przed króla. Król odezwał się do Daniela: «***Czy to ty jesteś Daniel, jeden z uprowadzonych z Judy, których sprowadził <z Judy > król, mój ojciec?
###### **Dn 5,14**
 Słyszałem o tobie, że posiadasz boskiego ducha i że stwierdzono u ciebie światło, rozwagę i nadzwyczajną mądrość.
###### **Dn 5,15**
 Przyprowadzono do mnie mędrców i wróżbitów, by odczytali to pismo i podali jego znaczenie. Oni jednak nie potrafili podać znaczenia sprawy.
###### **Dn 5,16**
 Słyszałem zaś o tobie, że umiesz dawać wyjaśnienia i rozwiązywać zawiłości. Jeśli więc potrafisz odczytać pismo i wyjaśnić jego znaczenie, zostaniesz odziany w purpurę i złoty łańcuch na szyję i będziesz panował jako trzeci w królestwie***».
###### **Dn 5,17**
 Wtedy odezwał się Daniel i rzekł wobec króla: «***Dary swoje zatrzymaj, a podarunki daj innym! Jednakże odczytam królowi pismo i wyjaśnię jego znaczenie.
###### **Dn 5,18**
 Królu, Najwyższy Bóg dał twemu ojcu, Nabuchodonozorowi, królestwo, wielkość, chwałę i majestat.
###### **Dn 5,19**
 Z powodu udzielonej mu wielkości wszystkie ludy, narody i języki odczuwały lęk i drżały przed nim. Zabijał, kogo chciał, i pozostawiał przy życiu, kogo chciał; kogo chciał, wywyższał, a kogo chciał, poniżał.
###### **Dn 5,20**
 Gdy jednak jego serce uniosło się [pychą], a jego duch stał się zatwardziały w hardości, złożono go z królewskiego tronu i odebrano mu chwałę.
###### **Dn 5,21**
 Wypędzono go spośród ludzi, jego serce upodobniło się do serca zwierząt, i przebywał z onagrami. Żywiono go jak woły trawą, jego ciało zaś obmywała rosa z nieba, aż uznał, że Najwyższy Bóg panuje nad królestwem ludzi i że kogo chce, ustanawia nad nimi.
###### **Dn 5,22**
 Ty zaś, jego syn, Baltazar, nie uniżyłeś swego serca, mimo że wiedziałeś o tym wszystkim,
###### **Dn 5,23**
 lecz uniosłeś się przeciw Panu nieba. Przyniesiono do ciebie naczynia z Jego domu, ty zaś, twoi możnowładcy, twoje żony i twoje nałożnice piliście z nich wino. Wychwalałeś bogów srebrnych i złotych, miedzianych, żelaznych, drewnianych i kamiennych, którzy nie widzą, nie słyszą i nie rozumieją. Bogu zaś, w którego mocy jest twój oddech i wszystkie twoje drogi, czci nie oddałeś.
###### **Dn 5,24**
 Dlatego posłał On tę rękę, która nakreśliła to pismo.
###### **Dn 5,25**
 A oto nakreślone pismo: Mene, mene, tekel ufarsin.
###### **Dn 5,26**
 Takie zaś jest znaczenie wyrazów: Mene – Bóg obliczył twoje panowanie i ustalił jego kres.
###### **Dn 5,27**
 Tekel – zważono cię na wadze i okazałeś się zbyt lekki.
###### **Dn 5,28**
 res – twoje królestwo uległo podziałowi, oddano je Medom irsom***».
###### **Dn 5,29**
 Wtedy na rozkaz Baltazara odziano Daniela w purpurę, nałożono mu na szyję złoty łańcuch i ogłoszono, że ma rządzić jako trzeci w państwie.
###### **Dn 5,30**
 Tej samej nocy król chaldejski, Baltazar, został zabity.
# Dn 5 PAU
###### **Dn 5,1**
 Król Baltazar wydał wielką ucztę dla tysiąca swoich dostojników i w ich obecności pił wino.
###### **Dn 5,2**
 Gdy Baltazar napił się wina, kazał przynieść złote i srebrne naczynia, które jego ojciec, Nabuchodonozor, wziął ze świątyni w Jerozolimie, żeby mógł z nich pić król, jego dostojnicy, jego żony i nałożnice.
###### **Dn 5,3**
 Przyniesiono więc złote naczynia zabrane ze świątyni, która jest domem Boga w Jerozolimie. I pił z nich król, jego dostojnicy, jego żony i nałożnice.
###### **Dn 5,4**
 Pili wino i chwalili bogów ze złota, srebra, z miedzi, z drewna i kamienia.
###### **Dn 5,5**
 W tej samej chwili ukazały się palce ludzkiej ręki i pisały na wapiennej ścianie pałacu królewskiego naprzeciw świecznika. Gdy król zobaczył piszącą rękę,
###### **Dn 5,6**
 zmienił się wyraz jego twarzy. Zląkł się bardzo, zaczął drżeć na całym ciele i poczuł się słabo.
###### **Dn 5,7**
 Król kazał więc strażnikowi przyprowadzić magów, chaldejczyków i astrologów. Następnie powiedział do mędrców babilońskich: „Każdy, kto odczyta ten napis i powie, jakie jest jego znaczenie, zostanie odziany w purpurę, otrzyma złoty łańcuch na szyję i będzie w moim królestwie panował jako trzeci”.
###### **Dn 5,8**
 Przybyli więc wszyscy mędrcy króla, ale nie potrafili odczytać tego napisu ani powiedzieć królowi, jakie jest jego znaczenie.
###### **Dn 5,9**
 Wtedy król Baltazar bardzo się przestraszył i zmienił się wyraz jego twarzy. Także dostojnicy bardzo się zmieszali.
###### **Dn 5,10**
 Wołanie króla i jego dostojników dotarło do uszu królowej. Przyszła do sali biesiadnej i powiedziała: „O, królu, obyś żył wiecznie! Niech cię nie trwożą twoje myśli i niech twoja twarz nie blednie.
###### **Dn 5,11**
 Jest w twoim królestwie człowiek, w którym mieszka duch świętych bogów. Już za dni twojego ojca znajdowano u niego światło, rozsądek i mądrość - także mądrość bogów. Król Nabuchodonozor, twój ojciec, ustanowił go przełożonym mędrców, chaldejczyków i astrologów.
###### **Dn 5,12**
 Skoro więc Daniel, któremu król nadał imię Belteszassar, ma w sobie nadzwyczajnego ducha, rozum i rozsądek, zdolność wyjaśniania snów i tajemnic oraz rozwiązywania zawiłych spraw, wezwij go i teraz, aby powiedział, co to oznacza”.
###### **Dn 5,13**
 Gdy wprowadzono Daniela do króla, król powiedział do niego: „Ty jesteś Daniel, jeden z wygnańców judzkich, których król, mój ojciec, przyprowadził z Judy.
###### **Dn 5,14**
 Słyszałem o tobie, że masz ducha bogów i że masz światło, rozsądek i nadzwyczajną mądrość.
###### **Dn 5,15**
 Sprowadzono przed moje oblicze mędrców i magów, aby odczytali ten napis i powiedzieli mi, co on oznacza, ale nie potrafili tego zrobić.
###### **Dn 5,16**
 Słyszałem zaś o tobie, że umiesz wyjaśniać rzeczy trudne i rozwiązywać zawiłe sprawy. Jeśli więc potrafisz, odczytaj napis i powiedz, co on oznacza, a zostaniesz odziany w purpurę, otrzymasz złoty łańcuch i będziesz w moim królestwie panował jako trzeci”.
###### **Dn 5,17**
 Daniel odpowiedział królowi: „Dary swoje zatrzymaj, a prezenty rozdaj innym. Lecz odczytam królowi ten napis i powiem, co on oznacza.
###### **Dn 5,18**
 O królu! Najwyższy Bóg dał to królestwo, wielkość, przepych i majestat twojemu ojcu, Nabuchodonozorowi.
###### **Dn 5,19**
 Bóg dał mu także wielkość, która wszystkie ludy, narody i języki napełniła lękiem i bojaźnią, gdyż zabijał, kogo chciał, i pozostawiał przy życiu, kogo chciał. Kogo chciał, wywyższał, i kogo chciał, poniżał.
###### **Dn 5,20**
 Gdy jego serce stało się wyniosłe, a jego duch zuchwały, został strącony z królewskiego tronu i odebrano mu jego przepych.
###### **Dn 5,21**
 Wypędzono go spomiędzy ludzi, rozumem przypominał zwierzę i mieszkał z dzikimi osłami. Żywił się trawą jak bydło, a rosa z nieba była mu ochłodą, aż poznał, że królestwami ludzkimi rządzi Najwyższy i On je przekazuje, komu chce.
###### **Dn 5,22**
 Ty, Baltazarze, nie ukorzyłeś swojego serca, chociaż jako jego syn wiedziałeś o tym wszystkim.
###### **Dn 5,23**
 Wywyższyłeś się ponad Pana nieba i kazałeś przynieść przed swoje oblicze naczynia z Jego domu. Piłeś z nich wino ty sam, twoi dostojnicy, twoje żony i nałożnice. Chwaliłeś bogów ze srebra, złota, z miedzi, żelaza, z drewna i kamienia, którzy są ślepi, nie słyszą i nie wiedzą. A Boga, w którego ręku jest twoje tchnienie i każdy twój krok, nie wysławiałeś.
###### **Dn 5,24**
 Dlatego On posłał tę rękę, która wykonała ten napis.
###### **Dn 5,25**
 Oto jego treść: Mene mene tekel uparsin.
###### **Dn 5,26**
 A słowa te znaczą: mene - Bóg określił twoje królowanie i jego koniec;
###### **Dn 5,27**
 tekel - zważono cię na wadze i okazałeś się bez wartości;
###### **Dn 5,28**
 peres - twoje królestwo zostało podzielone i oddane Medom i Persom”.
###### **Dn 5,29**
 Wtedy Baltazar kazał ubrać Daniela w purpurę, włożyć mu złoty łańcuch na szyję i ogłosić, że w tym królestwie będzie panował jako trzeci.
###### **Dn 5,30**
 Jeszcze tej nocy król chaldejski, Baltazar, został zabity.
# Dn 5 BP
###### **Dn 5,1**
 Król Belszazar wydał wielką ucztę dla tysiąca swoich książąt i wobec [tego] tysiąca [osób] pił wino.
###### **Dn 5,2**
 Gdy miano podać wino, Belszazar polecił przynieść naczynia złote i srebrne, które Nebukadnezar, jego ojciec, zabrał ze Świątyni w Jerozolimie, aby pili z nich król, jego książęta, jego żony i jego nałożnice.
###### **Dn 5,3**
 Przyniesiono tedy naczynia złote, które zabrano ze Świątyni, z Domu Bożego w Jerozolimie, i pili z nich król, jego książęta, jego żony i jego nałożnice.
###### **Dn 5,4**
 pili wino i chwalili bogów [wykonanych] ze złota, srebra, brązu, żelaza, drzewa i kamienia.
###### **Dn 5,5**
 W tej samej chwili ukazały się palce ludzkiej ręki i pisały na wapnie ściany komnaty królewskiej naprzeciw świecznika. Król widział dłoń ręki, która pisała.
###### **Dn 5,6**
 Wówczas zmienił się kolor twarzy króla, jego myśli przeraziły go, mięśnie jego bioder osłabły, a jego kolana poczęły uderzać jedno o drugie.
###### **Dn 5,7**
 I zawołał król głośno, aby przyprowadzono wróżbiarzy, Chaldejczyków i astrologów. Król odezwał się i rzekł mędrcom babilońskim: Którykolwiek mąż odczyta to pismo i oznajmi mi jego znaczenie, będzie się mógł ubrać w purpurę, włożyć łańcuch złoty na szyję i będzie rządził w królestwie jako trzeci.
###### **Dn 5,8**
 Przybyli zatem wszyscy mędrcy królewscy, ale nie potrafili pisma odczytać i oznajmić królowi jego znaczenia.
###### **Dn 5,9**
 Wtedy król Belszazar bardzo się przeraził. Zmienił się kolor jego twarzy, jego zaś książęta zmieszali się.
###### **Dn 5,10**
 Z powodu słów króla i jego książąt królowa udała się na miejsce biesiady. Królowa przemówiła i rzekła: Królu, żyj na wieki! Niech cię nie trwożą twe myśli i niech się nie zmienia kolor twojej twarzy.
###### **Dn 5,11**
 Jest w twoim królestwie mąż, w którym jest duch świętych bogów. W dniach twojego ojca znalazły się w nim światło, rozum i mądrość podobna do mądrości bogów. Król Nebukadnezar, ojciec twój, ustanowił go przełożonym magów, wróżbitów, Chaldejczyków i astrologów. Ojciec twój, król,
###### **Dn 5,12**
 [uczynił to], ponieważ znajdowały się w nim - w Danielu, któremu król nadał imię Belteszaccar - nadzwyczajny duch, wiedza, rozum, wyjaśnianie snów, odkrywanie tajemnic i rozwiązywanie trudnych spraw. Niech więc teraz zostanie wezwany Daniel, a da wyjaśnienie.
###### **Dn 5,13**
 Wówczas Daniel został wprowadzony przed króla. Król przemówił i rzekł do Daniela: Ty jesteś Daniel spośród uprowadzonych z [pokolenia] Judy, których mój ojciec sprowadził z Judei.
###### **Dn 5,14**
 Słyszałem o tobie, że duch bogów jest w tobie. Światło, rozum i niezwykła mądrość znajdują się w tobie.
###### **Dn 5,15**
 Właśnie wprowadzeni zostali przede mnie mędrcy i wróżbici, aby to pismo odczytali i oznajmili mi jego znaczenie, ale nie potrafią dać wyjaśnienia [tej] rzeczy.
###### **Dn 5,16**
 Ja słyszę o tobie, że jesteś w stanie dawać wyjaśnienia i rozwiązywać trudne sprawy. Toteż jeśli potrafisz pismo [to] odczytać i oznajmić mi jego znaczenie, będziesz mógł ubrać się w purpurę, włożyć złoty łańcuch na szyję i [jako] trzeci będziesz rządził w królestwie.
###### **Dn 5,17**
 Wówczas Daniel odpowiadając rzekł w obecności króla: Dary twoje niech pozostaną przy tobie, a twoje podarki daj innemu, ale pismo odczytam królowi i oznajmię mu znaczenie.
###### **Dn 5,18**
 O ty, królu! Bóg Najwyższy dał Nebukadnezarowi, twojemu ojcu, królestwo, wielkość, sławę i majestat.
###### **Dn 5,19**
 Z powodu wielkości, jaką go obdarzył, drżały przed nim i bały się [go] wszystkie narody, ludy i języki. Kogo chciał, zabijał, a kogo chciał, zostawiał przy życiu. Kogo chciał, wywyższał, a kogo chciał, poniżał.
###### **Dn 5,20**
 Gdy jego serce wyniosło się i duch jego stał się hardy aż do pychy, został złożony z tronu swojego królestwa i pozbawiono go sławy.
###### **Dn 5,21**
 Został usunięty spośród ludzi, jego serce stało się podobne do zwierząt, mieszkał z dzikimi osłami, karmiono go trawą jak woły i rosą zwilżało się jego ciało, aż poznał, że Bóg Najwyższy sprawuje władzę nad królestwem ludzi i ustanawia nad nim, kogo chce.
###### **Dn 5,22**
 Ty zaś, Belszazarze, jego synu, nie upokorzyłeś swego serca, chociaż wiedziałeś o tym wszystkim.
###### **Dn 5,23**
 Przeciw Panu niebios się podniosłeś. Naczynia Jego Domu przyniesiono przed ciebie i pili z nich wino ty, twoi książęta, twoje żony i twe nałożnice. Sławiłeś bogów [zrobionych] ze srebra, złota, brązu, żelaza, drzewa i kamienia, które nie widzą, nie słyszą i nie poznają. Natomiast nie uczciłeś Boga, w którego ręku jest twoje tchnienie i do którego należą wszystkie twoje drogi.
###### **Dn 5,24**
 Przeto przez Niego została posłana dłoń ręki i pismo to jest napisane.
###### **Dn 5,25**
 Tak brzmi pismo, które jest napisane: mene, mene, tekel, ufarsin.
###### **Dn 5,26**
 Takie jest znaczenie słowa: mene - policzył Bóg twoje królestwo i położył mu kres,
###### **Dn 5,27**
 tekel - jesteś zważony na wadze, jesteś znaleziony jako brakujący;
###### **Dn 5,28**
 peres - królestwo twoje zostało podzielone i dane jest Medom i Persom.
###### **Dn 5,29**
 Wtedy Belszazar nakazał oblec Daniela w purpurę; nałożono złoty łańcuch na jego szyję i ogłoszono o nim, że będzie sprawował władzę jako trzeci w królestwie.
###### **Dn 5,30**
 Tej nocy zamordowano Belszazara, króla Chaldejczyków,
# Dn 5 BR
###### **Dn 5,1**
 Król Baltazar urządził wielką ucztę dla swoich możnowładców. Zaproszonych było około tysiąca osób. Wobec tysiąca owych ludzi król pił wino.
###### **Dn 5,2**
 Zasmakowawszy już wina, rozkazał Baltazar wnieść naczynia złote i srebrne, zabrane kiedyś przez jego ojca Nabuchodonozora ze Świątyni jerozolimskiej, żeby pili z nich wszyscy: król, jego możnowładcy, ich żony i nałożnice.
###### **Dn 5,3**
 Wniesiono więc naczynia złote i srebrne, zrabowane ze Świątyni Bożej w Jerozolimie, i pił z nich król, pili jego możnowładcy, ich żony i nałożnice.
###### **Dn 5,4**
 Pijąc wino, wychwalali swoich bożków ze złota, srebra, brązu, żelaza, drewna i kamienia.
###### **Dn 5,5**
 I nagle ukazały się palce, które zaczęły pisać na wapnie ściany pałacu królewskiego, z tyłu, za świecznikiem.
###### **Dn 5,6**
 Król widząc piszącą rękę, zmienił się na twarzy i bardzo się zaniepokoił, poczuł słabość w biodrach, a kolana wyraźnie mu drżały.
###### **Dn 5,7**
 I rozkazał król, żeby natychmiast wprowadzono wróżbitów, Chaldejczyków i tłumaczy snów. Powiedział król do mędrców babilońskich: Tego, kto zdoła odczytać napis i powie mi, co on znaczy, każę przyodziać w purpurę, zawiesić mu na szyi złoty łańcuch i wyznaczę mu trzecie miejsce w moim królestwie.
###### **Dn 5,8**
 I zbiegli się wszyscy mędrcy królewscy, ale żaden nie mógł odczytać napisu ani powiedzieć, co ten napis znaczy.
###### **Dn 5,9**
 Przeraził się więc bardzo król Baltazar, zmienił się wygląd jego twarzy, a wszyscy jego możnowładcy byli pełni niepokoju.
###### **Dn 5,10**
 I oto królowa przynaglona słowami króla i możnowładców weszła do komnaty, w której odbywała się uczta. Wszedłszy, królowa powiedziała: Żyj wiecznie, królu! Przestań się trwożyć twoimi myślami i niech spokój nie opuszcza twego oblicza.
###### **Dn 5,11**
 Jest w twoim królestwie człowiek, mający ducha świętych bogów. Jeszcze za czasów twojego ojca odkryto w nim szczególne światło umysłu, rozsądek i mądrość równą mądrości bogów. Ojciec twój, król Nabuchodonozor, uczynił go przełożonym wszystkich wróżbitów, Chaldejczyków, tłumaczy snów i mędrców.
###### **Dn 5,12**
 Ponieważ właśnie w owym Danielu, którego król nazwał również Belteszassarem, znaleziono szczególne światło ducha, wiedzę, mądrość oraz umiejętność tłumaczenia snów, odgadywania zagadek i rozwiązywania różnych problemów, poślij więc po Daniela, a on powie ci, co znaczy napis.
###### **Dn 5,13**
 Stawiono więc Daniela przed królem, który zapytał: Czy ty jesteś Danielem, jednym spośród uprowadzonych z Judy i przywiedzionych tu przez króla, mojego ojca?
###### **Dn 5,14**
 Słyszałem, że przebywa w tobie duch świętych bogów i że odznaczasz się szczególnym światłem umysłu, rozsądkiem i niezwykłą mądrością.
###### **Dn 5,15**
 Sprowadzono mi tu mędrców i wróżbitów, żeby odczytali ten napis i powiedzieli, co on znaczy, ale nie potrafią tego uczynić.
###### **Dn 5,16**
 Otóż usłyszałem, że ty potrafisz tłumaczyć różne rzeczy i rozwiązywać trudne problemy. Jeżeli więc odczytasz mi ten napis i powiesz, co on znaczy, zostaniesz przyodziany w purpurę, każę ci zawiesić na szyi złoty łańcuch i wyznaczę ci trzecie miejsce w całym królestwie.
###### **Dn 5,17**
 Wtedy zabrał głos Daniel i przemówił w te słowa: Zatrzymaj dla siebie twoje dary, innym przekaż twoje upominki. A ja i tak odczytam królowi ten napis i powiem, co on oznacza.
###### **Dn 5,18**
 Ojcu twojemu, Nabuchodonozorowi, o królu, przekazał Najwyższy panowanie, wielkość, chwałę i majestat.
###### **Dn 5,19**
 Jego wielkość lękiem napełniała wszystkie ludy, narody i języki, gdyż zabijał on, kogo chciał i kogo chciał, pozostawiał przy życiu, również kogo chciał, wywyższał, a kogo chciał, poniżał.
###### **Dn 5,20**
 Z czasem jednak uniósł się tak wielką pychą, a jego serce popadło w taką zatwardziałość i zuchwałość, że został strącony z tronu, na którym zasiadał w swoim królestwie, i pozbawiony wszelkiej chwały.
###### **Dn 5,21**
 Wygnano go spośród ludzi, a jego serce upodobniło go do nierozumnych zwierząt. Przebywał pomiędzy dzikimi osłami, żywił się trawą tak, jak bydło, a pragnienie gasił rosą spadającą z nieba, aż wreszcie zrozumiał, że Najwyższy sprawuje władzę nad wszelkim ludzkim królestwem, które przekazuje komu chce, wedle swego upodobania.
###### **Dn 5,22**
 Ale ty, Baltazarze, jego synu, ty także nie uniżyłeś się w twoim sercu, choć wszystko to już wcześniej wiedziałeś.
###### **Dn 5,23**
 Występowałeś przeciwko Panu Niebios, kazałeś przynieść naczynia z Jego Świątyni, z których piliście wino, ty sam, twoi możnowładcy, twoje nałożnice. Wysławialiście przy tym waszych bożków ze złota, srebra, brązu i żelaza, z drewna i z kamienia, bożków, które ani nie widzą, ani nie słyszą, ani niczego nie rozumieją, a nie oddałeś chwały Bogu, w którego rękach jest każde twoje tchnienie i wszystkie drogi twojego życia.
###### **Dn 5,24**
 To On skierował tu ową rękę, która pozostawiła ten napis.
###### **Dn 5,25**
 Oto treść napisu mene, mene, tekel, ufarsin.
###### **Dn 5,26**
 Napisane zaś słowa znaczą: Mene - Bóg zmierzył już twoje królowanie i wyznaczył jego dni.
###### **Dn 5,27**
 Tekel - zostałeś już zważony na wadze i wiele ci nie dostaje;
###### **Dn 5,28**
 Ufarsin - twoje królestwo zostało podzielone: część otrzymali Medowie, a część Persowie.
###### **Dn 5,29**
 Rozkazał tedy Baltazar przyodziać Daniela w purpurę, włożyć mu na szyję łańcuch ze złota i ogłosić wszystkim, że będzie on odtąd zajmował trzecie miejsce w państwie.
###### **Dn 5,30**
 I jeszcze tej samej nocy król Baltazar został zamordowany.
# Dn 5 WUJ
###### **Dn 5,1**
 Balthazar król uczynił ucztę wielką na tysiąc przednich panów swych, a każdy z nich pił podług swego wieku.
###### **Dn 5,2**
 Rozkazał tedy już pijany, aby przyniesiono naczynie złote i srebrne, które był zabrał Nabuchodonozor ociec jego z kościoła, który był w Jeruzalem, żeby pili z nich król, i panowie przedni jego, i żony jego, i nałożnice.
###### **Dn 5,3**
 Tedy przyniesiono naczynia złote i srebrne, które był zebrał z kościoła, który był w Jeruzalem, i pili nimi król i przedni panowie jego, żony i nałożnice jego.
###### **Dn 5,4**
 Pili wino, i chwalili bogi swe złote i srebrne, miedziane, żelazne, i drewniane, i kamienne.
###### **Dn 5,5**
 Tejże godziny ukazały się palce jako ręki człowieczej piszącej przeciw lichtarzowi na ścienie sali królewskiej: a król patrzał na członki ręki piszącej.
###### **Dn 5,6**
 Tedy twarz królewska zmieniła się, a myśli jego trwożyły go, a spojenia nerek jego słabiały, a kolana jego jedno o drugie się tłukły.
###### **Dn 5,7**
 A tak zawołał król mocno, aby przywiedziono czarnoksiężniki, Chaldejczyki, i praktykarze. A mówiąc król rzekł do mędrców Babilońskich: którykolwiek to pismo wyczyta, a wykład jego mi oznajmi: w szarłat ubran będzie, a łańcuch złoty będzie miał na szyjej, a trzecim w królestwie moim będzie.
###### **Dn 5,8**
 Tedy wszedłszy wszyscy mędrcy królewscy, nie mogli ani pisma wyczytać, ani wykładu królowi pokazać.
###### **Dn 5,9**
 Z czego król Balthazar barzo się zafrasował, i zmieniła się twarz jego: lecz i panowie przedni jego trwożyli się.
###### **Dn 5,10**
 A królowa dla rzeczy, która się przydała królowi i przednim panom jego, weszła do domu uczty, a przemówiwszy rzekła: Królu żyj na wieki: niech cię nie trwożą myśli twoje, i niech się nie mieni twarz twoja.
###### **Dn 5,11**
 Jest mąż w królestwie twoim, który ducha bogów świętych ma w sobie: a za dni ojca twego umiejętność i mądrość nalazły się w nim: bo i król Nabuchodonozor ociec twój uczynił go przedniejszym nad czarnoksiężnikami, czarownikami, Chaldejczykami, i praktykarzami, ociec mówię, twój królu.
###### **Dn 5,12**
 Iż duch więtszy, i roztropność, i rozum, i wykład snów, i objawienie tajemnic, i rozwiązanie zawiązałych rzeczy nalazły się w nim, to jest, w Danielu, któremu król dał imię Balthazar. Teraz tedy niech przyzową Daniela, a powie wykład,
###### **Dn 5,13**
 Wprowadzony tedy jest Daniel przed króla. Do którego przemowę uczyniwszy król rzekł: Tyś jest Daniel z synów pojmania Judzkiego, którego przywiódł ociec mój król z Żydowskiej ziemie?
###### **Dn 5,14**
 Słyszałem o tobie, że masz ducha bogów: a iż nauka, i wyrozumienie, i mądrość, więtsze nalazły się w tobie.
###### **Dn 5,15**
 A teraz weszli przed mię mądrzy czarnoksiężnicy, aby to pismo czytali, i wykład jego, aby mi ukazali: i nie mogli wykładu mowy tej wypowiedzieć.
###### **Dn 5,16**
 A jam słyszał o tobie, że możesz wykładać trudne rzeczy i zawiazałe rozwiązać: a tak jeśli możesz pismo wyczytać, i wykład mi jego oznajmić, w szarłat ubran będziesz, i złoty łańcuch będziesz miał na szyjej, i trzecim w królestwie moim książęciem zostaniesz.
###### **Dn 5,17**
 Na co odpowiadając Daniel, rzekł przed królem: Dary twoje tobie niech będą, a upominki domu twego innemu daj: wszakże pismo przeczytam tobie królu, i wykład jego pokażę tobie.
###### **Dn 5,18**
 O królu, Bóg nawyższy dał Nabuchodonozorowi ojcu twemu królestwo, i wielmożność, sławę, i cześć.
###### **Dn 5,19**
 A dla wielmożności, którą mu był dał, wszyscy narodowie, pokolenia, i języki drżały, i bały się go: które chciał, zabijał: a które chciał ubijał: które też chciał wywyższał: a które chciał zniżał.
###### **Dn 5,20**
 Lecz gdy się podniosło serce jego, i duch jego zatwardział na pychę, złożon jest z stolice królestwa swego, i odjęta jest sława jego:
###### **Dn 5,21**
 I wygnan był od synów ludzkich, ale i serce jego między zwierzęty położono było, i z osły leśnemi było mieszkanie jego: trawę też jadł jako wół, i rosą niebieską ciało jego zmoczone było, aż poznał, że Nawyższy ma moc w królestwie ludzkiem, a kogokolwiek zechce postanowi na niem.
###### **Dn 5,22**
 Ty też Balthazarze synu jego, nie uniżyłeś serca twego, gdyżeś to wszystko wiedział:
###### **Dn 5,23**
 Aleś się podniósł przeciw Panu niebieskiemu: i naczynie domu jego przyniesiono przed cię: a ty, i Panowie twoi, i żony twoje, i nałożnice twoje, piliście wino z nich: a ktemu bogi srebrne, i złote, miedziane, żelazne, kamienne, i drewniane, którzy nie widzą, ani słyszą, ani czują, chwaliłeś: a Boga który ma tchnienie twe w ręce swej, i wszystkie drogi twoje, nie uczciłeś.
###### **Dn 5,24**
 Przeto od niego posłań jest członek ręki, która to pisała, co jest wyrażono.
###### **Dn 5,25**
 A toć jest pismo, które jest rozłożone: MANE, THECEL, PHARES.
###### **Dn 5,26**
 A ten jest wykład mówi. MANE: przeliczył Bóg królestwo twoje, i dokonał go.
###### **Dn 5,27**
 THECEL: Zważonyś na wadze, i znalezionyś mniej mającym.
###### **Dn 5,28**
 PHARES: Rozdzielone jest królestwo twoje, i dano je Medom i Persom.
###### **Dn 5,29**
 Tedy z rozkazania królewskiego obleczony jest Daniel w szarłat i włożono łańcuch złoty na szyję jego: I obwołano o nim, że miał władzę trzeci w królestwie jego.
###### **Dn 5,30**
 Tejże nocy zabit jest Balthazar król Chaldejski.
###### **Dn 5,31**
 A Daryus Medczyk nastąpił na królestwo, gdy mu było sześćdziesiąt lat i dwie.
