# Ba 5 BT5
###### **Ba 5,1**
 Odłóż, Jeruzalem, szatę smutku i utrapienia swego, a przywdziej wspaniałe szaty chwały, dane ci na zawsze przez Pana.
###### **Ba 5,2**
 Przyoblecz się w płaszcz sprawiedliwości pochodzącej od Boga, włóż na głowę swą koronę chwały Przedwiecznego!
###### **Ba 5,3**
 Albowiem Bóg chce pokazać wspaniałość twojąwszystkiemu, co jest pod niebem.
###### **Ba 5,4**
 Imię twe u Boga na wieki będzie nazwane:Pokój sprawiedliwości i chwała pobożności.
###### **Ba 5,5**
 Podnieś się, Jeruzalem!Stań na miejscu wysokim, spojrzyj na wschód, zobacz twe dzieci, zgromadzone na słowo Świętegood wschodu słońca aż do zachodu, rozradowane, że Bóg o nich pamiętał.
###### **Ba 5,6**
 Wyszli od ciebie pieszo, pędzeni przez wrogów, a Bóg przyprowadzi ich niesionych z chwałą, jakby na tronie królewskim.
###### **Ba 5,7**
 Albowiem postanowił Bóg zniżyćkażdą górę wysoką, pagórki odwieczne, doły zasypać do zrównania z ziemią, aby bezpiecznie mógł kroczyć Izrael w chwale Pana.
###### **Ba 5,8**
 Na rozkaz Panalasy i drzewa pachnąceocieniać będą Izraela.
###### **Ba 5,9**
 Z radością bowiem poprowadzi Bóg Izraelado światła swej chwałyz właściwą sobie sprawiedliwością i miłosierdziem. Odpis listu wysłanego przez Jeremiasza do tych, którzy jako niewolnicy mieli być uprowadzeni przez króla babilońskiego do Babilonu, by im oznajmić, co mu Bóg polecił.
# Ba 5 PAU
###### **Ba 5,1**
 Jeruzalem! Zrzuć szatę smutku i upokorzenia, a włóż uroczystą szatę chwały, którą Bóg dał ci na wieki.
###### **Ba 5,2**
 Okryj się płaszczem sprawiedliwości podarowanej ci przez Boga, włóż na głowę koronę chwały Przedwiecznego!
###### **Ba 5,3**
 Gdyż Bóg chce ukazać całą twą wspaniałość wszystkiemu, co jest pod niebem.
###### **Ba 5,4**
 Bóg cię nazwie na wieki imieniem: „Pokój dla sprawiedliwych, chwała dla bogobojnych”.
###### **Ba 5,5**
 Wstań, Jeruzalem! Stań na miejscu wysokim i popatrz na wschód, zobacz twe dzieci zgromadzone od wschodu do zachodu. Radują się słowem Świętego, że Bóg o nich pamięta.
###### **Ba 5,6**
 Wyszły od ciebie pieszo, popędzane przez wrogów, a teraz Bóg pozwala im wrócić tryumfalnie, niesionym jak tron królewski.
###### **Ba 5,7**
 Bóg postanowił zniżyć każdą wysoką górę i odwieczne pagórki, zasypać doliny do równego poziomu, aby Izrael mógł iść bezpiecznie w chwale Boga.
###### **Ba 5,8**
 Nawet lasy i drzewa pachnące na rozkaz Boga ocieniły Izraela,
###### **Ba 5,9**
 gdyż sam Bóg z radością poprowadzi Izraela do swego chwalebnego światła, ze sprawiedliwością i miłosierdziem, które pochodzą od Niego.
# Ba 5 BP
###### **Ba 5,1**
 Złóż, Jeruzalem, szaty żałoby i udręki, a przyoblecz się na zawsze we wspaniałość chwały od Boga.
###### **Ba 5,2**
 Przywdziej płaszcz sprawiedliwości [pochodzącej] od Boga, a na swą głowę włóż diadem chwały Odwiecznego.
###### **Ba 5,3**
 Bóg bowiem ukaże twą świetność całemu okręgowi ziemi, [który jest] pod niebem.
###### **Ba 5,4**
 Bo takim imieniem będziesz nazwane przez Boga na wieki: "Pokój sprawiedliwości" i "Chwała pobożności".
###### **Ba 5,5**
 Powstań, o Jeruzalem, stań na miejscu wyniosłym i zwróć swe spojrzenie ku Wschodowi; zobacz swe dzieci, zgromadzone od zachodu aż do wschodu słońca mocą słowa Świętego, radujące się, że Bóg wspomniał na nie.
###### **Ba 5,6**
 Opuścili cię pieszo uprowadzeni przez nieprzyjaciół, Bóg jednak przyprowadza ich ku tobie niesionych z chwałą niby na tronie królewskim.
###### **Ba 5,7**
 Bóg rozkazał zniżyć wszelką górę wyniosłą i pagórki odwieczne, a doliny napełnić, by się zrównały, żeby Izrael mógł kroczyć bezpieczny w chwale Boga.
###### **Ba 5,8**
 Nawet lasy i wszelkie drzewa pachnące na rozkaz Boga osłonią Izrael swym cieniem.
###### **Ba 5,9**
 Tak, Bóg sam z radością poprowadzi Izraela do światła swej chwały, z właściwym Mu miłosierdziem i sprawiedliwością.
# Ba 5 BR
###### **Ba 5,1**
 Zdejm z siebie, Jerozolimo, szaty twego smutku i przygnębienia i przyodziej się we wspaniałe odzienie chwały, dane ci na zawsze przez Boga.
###### **Ba 5,2**
 Włóż na siebie płaszcz sprawiedliwości Bożej. Na skronie włóż koronę chwały Przedwiecznego!
###### **Ba 5,3**
 Bo oto Bóg chce twój blask na całym okręgu ziemi ukazać wszystkiemu, co jest pod niebem.
###### **Ba 5,4**
 Bóg dał ci na zawsze imię: Pokój w sprawiedliwości i Chwała w bojaźni Bożej.
###### **Ba 5,5**
 Powstań, Jerozolimo, i wejdź na górę! Spojrzyj na wschód i popatrz na twoje dzieci. Od zachodu aż do wschodu słońca zgromadziło ich słowo Świętego. I cieszą się, że Bóg o nich nie zapomniał.
###### **Ba 5,6**
 Odeszli od Ciebie daleko, pieszo, pędzeni przez wrogów. A Bóg sprowadził ich znowu do ciebie, niosąc ich jakby na królewskim tronie.
###### **Ba 5,7**
 Bóg bowiem rozkazał: Niech się zachwieją wszystkie góry wysokie i odwieczne szczyty! Niziny niech się zamienią w równą krainę, tak aby Izrael spokojnie mógł kroczyć w Bożej chwale.
###### **Ba 5,8**
 Na Boże polecenie lasy i wszelkie drzewa pachnące niech dostarczają Izraelowi cienia.
###### **Ba 5,9**
 I prowadził Bóg Izraela z wielką radością i w blasku swojej chwały, od Niego zaś szły miłosierdzie i sprawiedliwość. Odpis listu, wysłanego przez Jeremiasza do tych, którzy jako niewolnicy mieli być uprowadzeni przez króla babilońskiego do Babilonu. Przekazywał im [w tym liście] przeznaczone dla nich polecenia Boże.
# Ba 5 WUJ
