# 1Krn 2 BT5
###### **1Krn 2,1**
 Oto synowie Izraela: Ruben, Symeon, Lewi, Juda, Issachar, Zabulon,
###### **1Krn 2,2**
 Dan, Józef, Beniamin, Neftali, Gad i Aser.
###### **1Krn 2,3**
 Synowie Judy: Er, Onan i Szela. Ci trzej urodzili się mu z Bat-Szuy, Kananejki. Lecz Er, pierworodny Judy, okazał się złym w oczach Pana i spotkała go śmierć.
###### **1Krn 2,4**
 Także synowa jego, Tamar, urodziła mu Peresa i Zeracha. Wszystkich synów Judy było pięciu.
###### **1Krn 2,5**
 Synowie Peresa: Chesron i Chamul.
###### **1Krn 2,6**
 Synowie Zeracha: Zimri, Etan, Heman, Kalkol i Darda, wszystkich ich pięciu.
###### **1Krn 2,7**
 Synowie Karmiego: Akar, który zatrwożył Izraela z powodu kradzieży rzeczy obłożonych klątwą.
###### **1Krn 2,8**
 Syn Etana: Azariasz.
###### **1Krn 2,9**
 Synowie Chesrona, którzy mu się urodzili: Jerachmeel, Ram i Kelubaj.
###### **1Krn 2,10**
 Ram był ojcem Amminadaba. Amminadab zaś – Nachszona, naczelnika potomków Judy.
###### **1Krn 2,11**
 Nachszon był ojcem Szalmy, a Szalma – Booza.
###### **1Krn 2,12**
 Booz był ojcem Obeda, a Obed – Jessego.
###### **1Krn 2,13**
 Jesse był ojcem: pierworodnego Eliaba, drugiego Abinadaba, trzeciego Szimei,
###### **1Krn 2,14**
 czwartego Netaneela, piątego Raddaja,
###### **1Krn 2,15**
 szóstego Osema, siódmego Dawida.
###### **1Krn 2,16**
 A siostrami ich były: Seruja i Abigail. Synowie Serui: Abiszaj, Joab i Asahel, trzej;
###### **1Krn 2,17**
 Abigail zaś urodziła Amasę; ojcem Amasy był Jeter, Izmaelita.
###### **1Krn 2,18**
 Kaleb, syn Chesrona, miał Jeriota ze swoją żoną, Azubą. Oto [jeszcze] jej synowie: Jeszer, Szobab i Ardon.
###### **1Krn 2,19**
 A gdy umarła Azuba, Kaleb wziął sobie za żonę Efratę, która mu urodziła Chura.
###### **1Krn 2,20**
 Chur zaś był ojcem Uriego, a Uri – Besaleela.
###### **1Krn 2,21**
 Potem zbliżył się Chesron do córki Makira, ojca Gileada, wziął ją za żonę, gdy miał sześćdziesiąt lat, a urodziła mu Seguba.
###### **1Krn 2,22**
 Segub był ojcem Jaira, który miał dwadzieścia trzy miasta w ziemi Gilead.
###### **1Krn 2,23**
 Geszur i Aram zabrali Osiedla Jaira i Kenat z przynależnymi sześćdziesięcioma miejscowościami; wszyscy oni byli synami Makira, ojca Gileada.
###### **1Krn 2,24**
 Po śmierci Chesrona w Kaleb-Efrata, żona Chesrona, Abijja, urodziła mu Aszchura, ojca Tekoa.
###### **1Krn 2,25**
 Synami Jerachmeela, pierworodnego Chesrona, byli: Ram – pierworodny, Buna, Oren, Osem i Achiasz.
###### **1Krn 2,26**
 Miał też Jerachmeel inną żonę, imieniem Atara; ta była matką Onama.
###### **1Krn 2,27**
 Synowie Rama, pierworodnego Jerachmeela: Maas, Jamin i Eker.
###### **1Krn 2,28**
 Synami Onama byli: Szammaj i Jada. Synami Szammaja: Nadab i Abiszur.
###### **1Krn 2,29**
 Żona Abiszura, która miała na imię Abihajil, urodziła mu Achbana i Molida.
###### **1Krn 2,30**
 Synami Nadaba: Seled i Appaim. Seled umarł bezdzietny.
###### **1Krn 2,31**
 Synem Appaima: Jiszi. Synem Jisziego: Szeszan. Synem Szeszana: Achlaj.
###### **1Krn 2,32**
 Synami Jady, brata Szammaja: Jeter i Jonatan. Jeter umarł bezdzietny.
###### **1Krn 2,33**
 Synami Jonatana: Pelet i Zara. Ci byli synami Jerachmeela.
###### **1Krn 2,34**
 Szeszan nie miał synów, tylko córki, ale miał sługę Egipcjanina imieniem Jarcha.
###### **1Krn 2,35**
 Dał przeto Szeszan słudze swemu, Jarsze, córkę swą za żonę i urodziła mu Attaja.
###### **1Krn 2,36**
 Attaj zaś był ojcem Natana, a Natan – Zabada.
###### **1Krn 2,37**
 Zabad był ojcem Eflala, a Eflal – Obeda.
###### **1Krn 2,38**
 Obed był ojcem Jehu, a Jehu – Azariasza.
###### **1Krn 2,39**
 Azariasz był ojcem Chelesa, a Cheles – Eleasy.
###### **1Krn 2,40**
 Eleasa był ojcem Sismaja, a Sismaj – Szalluma.
###### **1Krn 2,41**
 Szallum był ojcem Jekamiasza, a Jekamiasz – Eliszamy.
###### **1Krn 2,42**
 Synowie Kaleba, brata Jerachmeela: Mesza, jego pierworodny, który był ojcem Zifa i Mareszy, < ojca > Chebrona.
###### **1Krn 2,43**
 Synowie Chebrona: Korach, Tappuach, Rekem i Szema.
###### **1Krn 2,44**
 Szema był ojcem Rachama, ojca Jorkeama, a Rekem był ojcem Szammaja.
###### **1Krn 2,45**
 Synem Szammaja był Maon, a Maon był ojcem Bet-Sura.
###### **1Krn 2,46**
 Efa, drugorzędna żona Kaleba, urodziła Charana, Mosę i Gazeza. Charan był ojcem Gazeza.
###### **1Krn 2,47**
 Synowie Jahdaja: Regem, Jotam, Geszan, Pelet, Efa i Szaaf.
###### **1Krn 2,48**
 Drugorzędna żona Kaleba, Maaka, urodziła Szebera i Tirchanę.
###### **1Krn 2,49**
 Urodziła ona także Szaafa, ojca Madmanny, oraz Szewę, ojca Makbeny i ojca Gibea. Corką Kaleba była Aksa.
###### **1Krn 2,50**
 Ci byli synami Kaleba. Synami Chura, pierworodnego Efraty: Szobal, ojciec Kiriat-Jearim,
###### **1Krn 2,51**
 Salma, ojciec Bet-Lechem, Charef, ojciec Bet-Gader.
###### **1Krn 2,52**
 Szobal, ojciec Kiriat-Jearim, miał synów: Haroego, połowę Manachtytów
###### **1Krn 2,53**
 oraz rody Kiriat-Jearim, Jitrytów, Putytów, Szumatytów i Miszraitów; od nich wyszli Soreatyci i Esztaulici.
###### **1Krn 2,54**
 Synowie Salmy: Bet-Lechem, Netofatyci, Atrot Bet-Joab, połowa Manachtytów, Soreici,
###### **1Krn 2,55**
 rody pisarzy mieszkających w Jabbes, Tireatyci, Szimeatyci, Sukatyci. Ci są zatem Kenitami pochodzącymi od Chammata, ojca domu Rekaba.
# 1Krn 2 PAU
###### **1Krn 2,1**
 Oto synowie Izraela: Ruben, Symeon, Lewi i Juda, Issachar i Zabulon,
###### **1Krn 2,2**
 Dan, Józef i Beniamin, Neftali, Gad i Aser.
###### **1Krn 2,3**
 Oto trzej synowie Judy: Er, Onan i Szela, których urodziła mu Bat-Szua, Kananejka. Er, pierworodny Judy, okazał się zły i dlatego Pan ukarał go śmiercią.
###### **1Krn 2,4**
 Tamar, synowa Judy, urodziła mu Peresa i Zeracha. Razem Juda miał pięciu synów.
###### **1Krn 2,5**
 Synami Peresa byli Chesron i Chamul.
###### **1Krn 2,6**
 Pięciu synów Zeracha to: Zimri, Etan, Heman, Kalkol i Dara.
###### **1Krn 2,7**
 Syn Karmiego Akar sprowadził nieszczęście na Izraela, ponieważ dopuścił się kradzieży przedmiotów obłożonych klątwą.
###### **1Krn 2,8**
 Synem Etana był Azariasz.
###### **1Krn 2,9**
 Synowie Chesrona, którzy zostali przez niego spłodzeni: Jerachmeel, Ram, Kelubaj.
###### **1Krn 2,10**
 Ram był ojcem Amminadaba, Amminadab - Nachszona, który był przywódcą Judejczyków.
###### **1Krn 2,11**
 Nachszon był ojcem Szalmy, a Szalma - Booza.
###### **1Krn 2,12**
 Booz był ojcem Obeda, Obed był ojcem Jessego.
###### **1Krn 2,13**
 Pierworodnym synem Jessego był Eliab, po nim Jessemu urodzili się: Abinadab - jako drugi, Szimei - jako trzeci,
###### **1Krn 2,14**
 Netaneel - jako czwarty, Raddaj - jako piąty,
###### **1Krn 2,15**
 Osem - jako szósty i jako siódmy - Dawid.
###### **1Krn 2,16**
 Córkami Jessego były Seruja i Abigail. Seruja miała trzech synów: Abiszaja, Joaba i Asahela.
###### **1Krn 2,17**
 Abigail zaś urodziła Amasę; ojcem Amasy był Jeter, Izmaelita.
###### **1Krn 2,18**
 Kaleb, syn Chesrona, miał z żoną Azubą Jeriotę, której synami byli: Jeszer, Szobab i Ardon.
###### **1Krn 2,19**
 Gdy Azuba zmarła, Kaleb ożenił się z Efratą, która urodziła mu Chura.
###### **1Krn 2,20**
 Chur był ojcem Uriego, a Uri - Besaleela.
###### **1Krn 2,21**
 Gdy Chesron miał sześćdziesiąt lat, poszedł do córki Makira, ojca Gileada i wziął ją za żonę, a ona urodziła mu syna imieniem Segub.
###### **1Krn 2,22**
 Segub był ojcem Jaira, do którego należały dwadzieścia trzy miasta na terytorium Gileadu.
###### **1Krn 2,23**
 Geszur i Aram odebrali im osiedla Jaira i Kenat wraz z przynależnymi do nich sześćdziesięcioma miejscowościami. Wszystkie one należały do potomków Makira, ojca Gileada.
###### **1Krn 2,24**
 Po śmierci Chesrona w Kaleb Efrata, jego żona Abijja urodziła Chesronowi Aszchura, ojca Tekoa.
###### **1Krn 2,25**
 Potomkowie Jerachmeela, pierworodnego Chesrona: Ram był pierworodnym, po nim urodzili się: Buna, Oren, Osem i Achiasz.
###### **1Krn 2,26**
 Jerachmeel miał również drugą żonę, o imieniu Atara. Była ona matką Onama.
###### **1Krn 2,27**
 Ram, pierworodny Jerachmeela, miał trzech synów: Maasa, Jamina i Ekera.
###### **1Krn 2,28**
 Onam miał synów Szammaja i Jada. Synami Szammaja byli Nadab i Abiszur.
###### **1Krn 2,29**
 Żona Abiszura miała na imię Abihajil i urodziła mu Achbana i Molida.
###### **1Krn 2,30**
 Synami Nadaba byli Seled, który zmarł bezpotomnie, i Appaim.
###### **1Krn 2,31**
 Synem Appaima był Jeszi, a Jesziego - Szeszan. Synem Szeszana był Achlaj.
###### **1Krn 2,32**
 Jada, brat Szammaja, miał dwóch synów: Jetera, który umarł bezdzietnie, i Jonatana.
###### **1Krn 2,33**
 Synami Jonatana byli Pelet i Zaza. To są potomkowie Jerachmeela.
###### **1Krn 2,34**
 Szeszan nie miał synów, tylko córki. Miał on sługę, Egipcjanina, o imieniu Jarcha.
###### **1Krn 2,35**
 Jemu to, swemu słudze Jarsze, dał Szeszan za żonę jedną ze swych córek, która urodziła mu Attaja.
###### **1Krn 2,36**
 Attaj był ojcem Natana, a Natan - Zabada.
###### **1Krn 2,37**
 Zabad był ojcem Eflala, a Eflal - Obeda.
###### **1Krn 2,38**
 Obed był ojcem Jehu, a Jehu - Azariasza.
###### **1Krn 2,39**
 Azariasz był ojcem Chelesa, Cheles - Eleasy.
###### **1Krn 2,40**
 Eleasa był ojcem Sismaja, a Sismaj - Szalluma.
###### **1Krn 2,41**
 Szallum był ojcem Jekamiasza, a Jekamiasz - Eliszamy.
###### **1Krn 2,42**
 Potomkowie Kaleba, brata Jerachmeela: pierworodnym Kaleba był Mesza, ojciec Zify i Mareszy, ojca Chebrona.
###### **1Krn 2,43**
 Synami Chebrona byli: Korach, Tappuach, Rekem i Szema.
###### **1Krn 2,44**
 Szema był ojcem Rachama, ojca Jorkeama, Rekem zaś ojcem Szammaja.
###### **1Krn 2,45**
 Synem Szammaja był Maon, a synem Maona Bet-Sura.
###### **1Krn 2,46**
 Efa, drugorzędna żona Kaleba, urodziła mu Charana, Mosę i Gazeza. Charan był ojcem Gazeza.
###### **1Krn 2,47**
 Synami Jahdaja byli: Regem, Jotam, Geszan, Pelet, Efa i Szaaf.
###### **1Krn 2,48**
 Maaka, drugorzędna żona Kaleba, urodziła mu Szebera i Tirchanę.
###### **1Krn 2,49**
 Urodziła ona także Szaafę, ojca Madmanny, Szewę, ojca Makbeny i Gibea. Córką Kaleba była Aksa.
###### **1Krn 2,50**
 Wszyscy oni są potomkami Kaleba. Chur, pierworodny Efraty, miał trzech synów: Szobala, założyciela Kiriat-Jearim,
###### **1Krn 2,51**
 Salmę, założyciela Betlejem, i Charefa, założyciela Bet-Gader.
###### **1Krn 2,52**
 Szobal, założyciel Kiriat-Jearim, miał trzech synów: Reajasza, Chasriego i Manachata.
###### **1Krn 2,53**
 Od niego wywodzą się również rody zamieszkujące Kiriat-Jearim, rody: Jetrytów, Putytów, Szumatytów i Miszraitów. Od nich też wywodzą się Soreatyci i Esztaulici.
###### **1Krn 2,54**
 Potomkami Salmy są: Betlejemici, Netofatyci, Atrot-Bet-Joab, połowa Manachtytów, Soreici, a
###### **1Krn 2,55**
 także rody pisarzy mieszkających w Jabbes: Tireatyci, Szimeatyci i Sukatyci. Są oni Kenitami wywodzącymi się od Chammata, założyciela domu Rekaba.
# 1Krn 2 BP
###### **1Krn 2,1**
 A oto synowie Izraela: Ruben, Symeon. Lewi, Juda, Issachar, Zebulon,
###### **1Krn 2,2**
 Dan, Józef, Beniamin, Neftali, Gad i Aszer.
###### **1Krn 2,3**
 Synami Judy byli: Er, Onan i Szela. Tych trzech urodziła mu córka Szuy, Kananejka. Er jednak, pierworodny Judy, okazał się winnym wobec Jahwe, który sprawił, że umarł.
###### **1Krn 2,4**
 Synowa jego Tamar urodziła mu Pereca i Zeracha. Wszystkich zatem synów Judy było pięciu.
###### **1Krn 2,5**
 Synami Pereca byli: Checron i Chamul;
###### **1Krn 2,6**
 synami zaś Zeracha: Zimri, Etan, Heman, Kalkol i Dara - razem pięciu.
###### **1Krn 2,7**
 Synem Zimnego był Karmi, a synem Karmiego Akar, który sprowadził nieszczęście na Izraela z powodu przestępstwa [popełnionego] przeciw rzeczom obłożonym klątwą.
###### **1Krn 2,8**
 Synem Etana był Azarja.
###### **1Krn 2,9**
 Checronowi zaś urodzili się synowie: Jerachmeel, Ram i Kaleb.
###### **1Krn 2,10**
 Ram był ojcem Amminadaba, Amminadab był zaś ojcem Nachszona, który był księciem nad potomkami Judy.
###### **1Krn 2,11**
 Nachszon był ojcem Salmy, a Salma ojcem Booza.
###### **1Krn 2,12**
 Booz był ojcem Obeda, Obed zaś był ojcem Jiszaja.
###### **1Krn 2,13**
 Jiszaj był ojcem Eliaba, swego pierworodnego. Drugim [synem] był Abinadab, trzecim Szima,
###### **1Krn 2,14**
 czwartym Netanel, piątym Raddaj,
###### **1Krn 2,15**
 szóstym Ocem, a siódmym Dawid.
###### **1Krn 2,16**
 Siostrami ich były Ceruja i Abigail. Ceruja miała trzech synów: Abszaja, Joaba i Asaela.
###### **1Krn 2,17**
 Abigail urodziła Amasę; ojcem Amasy był Jeter, Ismaelita.
###### **1Krn 2,18**
 Kalebowi, synowi Checrona, urodziła jego żona Azuba [córka] Jerriota tych oto synów: Jeszera, Szobaba i Ardona.
###### **1Krn 2,19**
 Po śmierci Azuby pojął Kaleb za żonę Efratę, która urodziła mu Chura.
###### **1Krn 2,20**
 Chur był ojcem Uriego, Uri znów ojcem Bacalela.
###### **1Krn 2,21**
 Potem przyszedł Checron do córki Makira, ojca Gileada, i wziął ją za żonę mając już sześćdziesiąt lat; urodziła mu ona Seguba.
###### **1Krn 2,22**
 Segub był ojcem Jaira, który posiadał dwadzieścia trzy miasta w ziemi Gilead.
###### **1Krn 2,23**
 Geszur jednak i Aram zajęli osiedla Jaira oraz Kenat i należące do niego miejscowości: razem sześćdziesiąt osad. Ci wszyscy byli synami Makira, ojca Gileada.
###### **1Krn 2,24**
 Po śmierci Checrona Kaleb pojął za żonę Efratę, która poprzednio była żoną jego ojca Checrona, i ona to urodziła mu Aszchura, który był ojcem Tekoi.
###### **1Krn 2,25**
 Synami Jerachmeela, pierworodnego Checrona, byli: pierworodny Ram, następnie Buna, Oren, Ocem i Achijja.
###### **1Krn 2,26**
 Miał też Jerachmeel drugą żonę imieniem Atara, która była matką Onama.
###### **1Krn 2,27**
 Synami Rama, pierworodnego Jerachmeela, byli: Maac, Jamin i Eker.
###### **1Krn 2,28**
 Synami Onama byli: Szammaj i Jada. Synami zaś Szammaj a: Nadab i Abiszur.
###### **1Krn 2,29**
 Żona Abiszura, imieniem Abihail, urodziła mu Achbana i Molida.
###### **1Krn 2,30**
 Synami Nadaba byli: Seled i Appaim. Seled umarł bezdzietnie.
###### **1Krn 2,31**
 Synem Appaima był Jiszi. Synem Jisziego był Szeszan, a synem Szeszana: Achlaj.
###### **1Krn 2,32**
 Synami Jady, brata Szammaj a, byli: Jeter i Jonatan. Jeter umarł bezdzietnie.
###### **1Krn 2,33**
 Synami Jonatana byli: Pelet i Zaza. Ci oto są potomkowie Jerachmeela.
###### **1Krn 2,34**
 Szeszan nie miał synów, lecz tylko córki. Miał jednak Szeszan niewolnika egipskiego imieniem Jarcha.
###### **1Krn 2,35**
 Dał więc Szeszan niewolnikowi Jarsze córkę swą za żonę, a ona urodziła mu Attaja.
###### **1Krn 2,36**
 Attaj znów był ojcem Natana, a Natan był ojcem Zabada.
###### **1Krn 2,37**
 Zabad był ojcem Eflala, a Eflal był ojcem Obeda.
###### **1Krn 2,38**
 Obed był ojcem Jehu, a Jehu był ojcem Azarji.
###### **1Krn 2,39**
 Azarja był ojcem Cheleca, a Chelec był ojcem Elasy.
###### **1Krn 2,40**
 Elasa był ojcem Sismaja, a Sismaj był ojcem Szalluma.
###### **1Krn 2,41**
 Szallum był ojcem Jekamii, a Jekamia był ojcem Eliszamy.
###### **1Krn 2,42**
 Potomkami Kaleba, brata Jerachmeela, byli: jego syn pierworodny Mesza, ojciec Zifa, którego synem był Maresza, ojciec Chebrona.
###### **1Krn 2,43**
 Synami Chebrona byli: Korach, Tappuach, Rekem i Szema.
###### **1Krn 2,44**
 Od Szemy pochodził Racham, ojciec Jorkoama, a Rekem był ojcem Szammaj a.
###### **1Krn 2,45**
 Synem Szammaj a był Maon, ojciec Betcura.
###### **1Krn 2,46**
 Efa, drugorzędna żona Kaleba, urodziła Charana, Mocę i Gazeza. Charan był ojcem Jahdaja.
###### **1Krn 2,47**
 Synami Jahdaja byli: Regem, Jotam, Geszan, Pelet, Efa i Szaaf.
###### **1Krn 2,48**
 Drugorzędna żona Kaleba, Maaka, urodziła Szebera i Tirchanę.
###### **1Krn 2,49**
 Urodziła również Szaafa, ojca Madmanny, i Szewę, ojca Makbeny i Gibei. A córką Kaleba była Aksa.
###### **1Krn 2,50**
 Ci są potomkami Kaleba. Synami Chura, pierworodnego z [żony] Erraty, byli: Szobal, ojciec Kirjat-Jearima,
###### **1Krn 2,51**
 Salma, ojciec Bet-Lechema, i Charef, ojciec Bet-Gadera.
###### **1Krn 2,52**
 Szobal, ojciec Kirjat-Jearima, miał [nadto] synów: Reaję, połowę [rodu] Manachtytów
###### **1Krn 2,53**
 oraz rody Kirjat-Jearim: Itrytów, Putytów, Szumatytów i Miszraitów. Od nich pochodzą: Coreatyci i Esztaulici.
###### **1Krn 2,54**
 Synami Salmy byli: Bet-Lechem, Netofatyci, Atrot, Bet-Joab, połowa Manachtytów, Coreici,
###### **1Krn 2,55**
 rody Sof rytów, mieszkańcy Jabbec, Tiratyci, Szimatyci, Sukatyci; ci są Kenitami pochodzącymi od Chammata, który był ojcem Bet-Rekaba.
# 1Krn 2 BR
###### **1Krn 2,1**
 A oto synowie Izraela: Ruben, Symeon, Lewi, Juda, Issachar, Zabulon,
###### **1Krn 2,2**
 Dan, Józef, Beniamin, Neftali, Gad i Aser.
###### **1Krn 2,3**
 Synami Judy byli: Er, Onan i Szela. Matką ich była Kananejka, Bat-Szua. Na Era, pierworodnego Judy, zesłał jednak Jahwe śmierć, ponieważ czynił on to, co złe w oczach Jahwe.
###### **1Krn 2,4**
 Synowa Judy, Tamar, urodziła Peresa i Zeracha. Tak więc pięciu było wszystkich synów Judy.
###### **1Krn 2,5**
 Synami Peresa byli Chesron i Chamul,
###### **1Krn 2,6**
 synami Zeracha zaś Zimri, Etan, Heman, Kalkol i Dara. Było więc pięciu synów Zeracha.
###### **1Krn 2,7**
 Synem Karmiego był Akar, który sprowadził wiele utrapień na cały Izrael, ponieważ przywłaszczył sobie rzeczy, które były obłożone klątwą.
###### **1Krn 2,8**
 Etan miał syna Azariasza,
###### **1Krn 2,9**
 a synami Chesrona byli: Jerachmeel, Ram i Kelubaj.
###### **1Krn 2,10**
 Ram był ojcem Amminadaba, Amminadab zaś Nachszona, naczelnika potomków Judy.
###### **1Krn 2,11**
 Nachszon był ojcem Szalmy, a Szalma - Booza.
###### **1Krn 2,12**
 Booz był ojcem Obeda, a Obed ojcem Jessego.
###### **1Krn 2,13**
 Jesse miał siedmiu synów. Pierwszym, czyli pierworodnym, był Eliab, drugim Abinadab, trzecim Szimea,
###### **1Krn 2,14**
 czwartym Netaneel, piątym Raddaj,
###### **1Krn 2,15**
 szóstym Osem, a siódmym Dawid.
###### **1Krn 2,16**
 Ich siostrami były Seruja i Abigail. Seruja miała trzech synów: Abiszaja, Joaba i Asahela.
###### **1Krn 2,17**
 Abigail była matką Amasy, ojcem Amasy zaś był Jeter, Izmaelita.
###### **1Krn 2,18**
 Kaleb, syn Chesrona, pojął za żonę Azubę, która urodziła mu syna Jeriota. A oto pozostali jej synowie: Jeszer, Szobab i Ardon.
###### **1Krn 2,19**
 Po śmierci Azuby Kaleb wziął sobie za żonę Efratę, która urodziła mu syna Chura.
###### **1Krn 2,20**
 Chur był ojcem Uriego, Uri zaś ojcem Besaleela.
###### **1Krn 2,21**
 Potem zbliżył się Chesron do córki Makira, który był ojcem Gileada, i wziął ją sobie za żonę. Miał już wtedy sześćdziesiąt lat, ale jeszcze urodziła mu syna Seguba.
###### **1Krn 2,22**
 Segub był ojcem Jaira, do którego należały dwadzieścia trzy miasta w ziemi Gilead.
###### **1Krn 2,23**
 Aramejczykom i Geszurytom zabrał Osiedla Jaira oraz Kenat, z podlegającymi mu sześćdziesięcioma miejscowościami. Wszystko to należało kiedyś do potomków Machira, ojca Gileada.
###### **1Krn 2,24**
 Kiedy już Chesron zmarł, do Efrata przybył Kaleb, którego żona Abijja urodziła syna. Miał on na imię Aszchur i był ojcem Tekoa.
###### **1Krn 2,25**
 A oto synowie pierworodnego Chesrona, Jerachmeela: Ram jako pierworodny, Buna, Oren, Osem i Achiasz.
###### **1Krn 2,26**
 Jerachmeel miał też żonę imieniem Atara i ona to właśnie stała się matką Onama.
###### **1Krn 2,27**
 Synami Rama, pierworodnego Jerachmeela, byli: Maas, Jamin i Eker,
###### **1Krn 2,28**
 synami Onama zaś - Szammaj i Jada. Szammaj był ojcem Nadaba i Abiszura.
###### **1Krn 2,29**
 Abichajil, żona Abiszura, była matką Achbana i Molida.
###### **1Krn 2,30**
 Nadab był ojcem Seleda i Appaima, Seled zaś umarł bezdzietnie.
###### **1Krn 2,31**
 Appaim był ojcem Jisziego, a Jiszi ojcem Szeszana, Szeszan zaś ojcem Achlaja.
###### **1Krn 2,32**
 Jada, brat Szammaja, był ojcem Jetera oraz Jonatana. Jeter zaś umarł bezdzietnie.
###### **1Krn 2,33**
 Jonatan był ojcem Peleta i Zary. Wszyscy ci byli potomkami Jerachmeela.
###### **1Krn 2,34**
 Szeszan nie miał synów, tylko same córki. Miał też sługę Egipcjanina imieniem Jarcha.
###### **1Krn 2,35**
 Dał przeto owemu słudze, Jarsze, jedną ze swych córek za żonę i ta urodziła mu syna Attaja.
###### **1Krn 2,36**
 Attaj był ojcem Natana, a Natan ojcem Zabada.
###### **1Krn 2,37**
 Zabad był ojcem Eflala, a Eflal ojcem Obeda.
###### **1Krn 2,38**
 Obed był ojcem Jehu, a Jehu ojcem Azariasza.
###### **1Krn 2,39**
 Azariasz był ojcem Chelesa, a Cheles ojcem Eleasy.
###### **1Krn 2,40**
 Eleasa był ojcem Sismaja, a Sismaj ojcem Szalluma.
###### **1Krn 2,41**
 Szallum był ojcem Jekamiasza, a Jekamiasz ojcem Eliszamy.
###### **1Krn 2,42**
 Synami Kaleba, brata Jerachmeela, byli: Mesza jako pierworodny, późniejszy ojciec Zifa, oraz Maresza, ojciec Chebrona.
###### **1Krn 2,43**
 Synami zaś Chebrona byli: Korach, Tappuach, Rekem i Szema.
###### **1Krn 2,44**
 Szema był ojcem Rachama, ojca Jorkeama, a Rekem był ojcem Szammaja.
###### **1Krn 2,45**
 Szammaj był ojcem Maona, a Maon ojcem Bet-Sura.
###### **1Krn 2,46**
 Efa, nałożnica Kaleba, była matką Charana, Mosy i Gazera, Charan zaś był ojcem Jahdaja.
###### **1Krn 2,47**
 A oto synowie Jahdaja: Regem, Jotam, Geszan, Pelet, Efa i Szaaf.
###### **1Krn 2,48**
 Nałożnica Kaleba, Maaka, była matką Szebera i Tirchany,
###### **1Krn 2,49**
 a także Szaafa, ojca Madmanny, Szewy, ojca Makbeny i Gibei. Córką Kaleba była Aksa.
###### **1Krn 2,50**
 Takie było potomstwo Kaleba. Synami zaś Chura, pierworodnego Efraty, byli: Szobal, ojciec Kiriat-Jearim,
###### **1Krn 2,51**
 Salma, ojciec Bet-Lechem, Charef, ojciec Bet-Gader.
###### **1Krn 2,52**
 Synami Szobala, ojca Kiriat-Jearim, byli: Reajasz, Chasri, Manachat.
###### **1Krn 2,53**
 Od Szobala wywodziły się także rody Kiriat-Jearim: Jitryci, Putyci, Szumatyci i Miszraici, z których wyłonili się też potem Soreatyci i Esztaulici.
###### **1Krn 2,54**
 Potomkami Salmy byli: Bet-Lechem, Netofatyci, Atrot Bet-Joab, połowa rodu Manachtytów, Soreici.
###### **1Krn 2,55**
 Rody pisarzy mieszkających w Jabbes oraz Tireatyci, Szimeatyci i Sukatyci są Kenitami, którzy pochodzą z Chammat od ojca domu Rekaba.
# 1Krn 2 WUJ
###### **1Krn 2,1**
 A synowie Izraelowi: Ruben, Simeon, Lewi, Juda, Issachar, i Zabulon.
###### **1Krn 2,2**
 Dan, Józef, Benjamin, Nephtali, Gad i Aser:
###### **1Krn 2,3**
 Synowie Judowi: Her, Onan, i Sela, ci trzej urodzili się mu z córki Sue Chananitki. A był Her pierworodny Judy zły przed Panem. I zabił go.
###### **1Krn 2,4**
 Lecz Thamar niewiastka jego urodziła mu Phares i Zara. A tak wszystkich synów Juda pięć.
###### **1Krn 2,5**
 A synowie Phares Hesron i Hamul.
###### **1Krn 2,6**
 Synowie też Zary Zambry i Ethan i Eman, i Chalchal też, i Dara, pospołu pięć.
###### **1Krn 2,7**
 Synowie Charmi: Achar, który strwożył Izraela, i zgrzeszył kradzieżą rzeczy przeklętych.
###### **1Krn 2,8**
 Synowie Ethan: Azaryasz.
###### **1Krn 2,9**
 A synowie Hesron, którzy się mu urodzili: Jerameel, i Ram, i Kalubi.
###### **1Krn 2,10**
 Ale Ram zrodził Aminadab. A Aminadab zrodził Nahasson książę synów Juda.
###### **1Krn 2,11**
 A Nahasson też zrodził Salma, z którego poszedł Booz.
###### **1Krn 2,12**
 Booz lepak zrodził Obed, który też zrodził Izai.
###### **1Krn 2,13**
 A Izai zrodził pierworodnego Eliaba, wtórego Aminadaba, trzeciego Simaa,
###### **1Krn 2,14**
 Czwartego Nathanaela, piątego Raddaja,
###### **1Krn 2,15**
 Szóstego Asoma, siódmego Dawida.
###### **1Krn 2,16**
 Którego siostry były Sarwia i Abigail. Synowie Sarwijej: Abisai, Joab, i Asael, trzej.
###### **1Krn 2,17**
 Abigail zaś urodziła Amasę, którego ojciec był Jether Ismaelczyk.
###### **1Krn 2,18**
 A Kaleb syn Hesron wziął żonę imieniem Azuba, z której zrodził Jeryothę: a synowie jej byli, Jaser i Sobab i Ardon.
###### **1Krn 2,19**
 A gdy umarła Azuba, pojął Kaleb żonę Ephratę: która mu urodziła Hur.
###### **1Krn 2,20**
 Hur lepak zrodził Uri: a Uri zrodził Bezeleela.
###### **1Krn 2,21**
 Potem wszedł Hesron do córki Machira ojca Galaad i pojął ją, gdy mu było sześćdziesiąt lat: która mu urodziła Seguba.
###### **1Krn 2,22**
 Ale i Segub zrodził Jaira, a osiadł dwadzieścia i trzy miasta w ziemi Galaad.
###### **1Krn 2,23**
 I wziął Gessur i Aran miasteczka Jair, i Kanath, i wsi jego sześćdziesiąt miast, wszyscy ci synowie Machira ojca Galaad.
###### **1Krn 2,24**
 A gdy umarł Hesron, wszedł Kaleb do Ephrathy. Miał też Hesron żonę Abią, która mu urodziła Ashura ojca Thekui:
###### **1Krn 2,25**
 A narodzili się synowie Jerameela pierworodnego Hesron: Ram pierworodny jego, i Buna i Aram, i Asom, i Achia.
###### **1Krn 2,26**
 Pojął też drugą żonę Jeramael, imieniem Atarę, która była matka Onam.
###### **1Krn 2,27**
 Ale i synowie Ram pierworodnego Jerameel, byli Moos, Jamin, i Achar.
###### **1Krn 2,28**
 A Onam miał syny, Semei i Jada. A synowie Semei: Nadab, i Abisur.
###### **1Krn 2,29**
 A imię żony Abisur, Abihail, która mu urodziła Ahobbana, i Molida.
###### **1Krn 2,30**
 A synowie Nadabowi byli: Saled, i Apphaim. Lecz Saled umarł bez dziatek.
###### **1Krn 2,31**
 A syn Apphaimów, Jesy: który Jesy zrodził Sesan. A Sesan zrodził Obolai.
###### **1Krn 2,32**
 A synowie Jady brata Semei: Jether, i Jonathan. Lecz i Jether umarł bez synów.
###### **1Krn 2,33**
 A Jonathan zrodził Phaleth i Żiza. Cić byli synowie Jerameel.
###### **1Krn 2,34**
 A Sesan nie miał synów ale córki, a służebnika Egiptyanina imieniem Jeraa.
###### **1Krn 2,35**
 I dał mu córkę swą za żonę, która mu urodziła Etheja.
###### **1Krn 2,36**
 A Ethej zrodził Nathana, Nathan zrodził Zabada.
###### **1Krn 2,37**
 Zabad też zrodził Ophlala, a Ophlal zrodził Obeda,
###### **1Krn 2,38**
 Obed zrodził Jehua, Jehu zrodził Azaryasza,
###### **1Krn 2,39**
 Azaryasz zrodził Hellesa, a Helles zrodził Elasa,
###### **1Krn 2,40**
 Elasa zrodził Sisamoj, Sisamoj zrodził Sellum,
###### **1Krn 2,41**
 Sellum zrodził Ikamią, Ikamia zrodził Elisama,
###### **1Krn 2,42**
 A synowie Kaleb brata Jerameela, Mesa pierworodny jego, ten jest ociec Ziph: i synowie Maresa ojca Hebron.
###### **1Krn 2,43**
 A synowie Hebron: Kore, i Thaphua, i Recem, i Samma.
###### **1Krn 2,44**
 A Samma zrodził Rahama ojca Jerkaam, a Recem zrodził Samai.
###### **1Krn 2,45**
 Syn Samai, Maon: a Maon ociec Bethsur.
###### **1Krn 2,46**
 A Epha nałożnica Kaleb urodziła Haram, i Mosa, i Gezez. A Haran zrodził Gezez.
###### **1Krn 2,47**
 A synowie Jahaddai, Regom, i Joathan, i Gesan, i Phalet, i Epha, i Saaph.
###### **1Krn 2,48**
 Nałożnica Kalebowa Maacha, urodziła Saber, i Tharana.
###### **1Krn 2,49**
 A Saaph ociec Madmena, zrodził Suę ojca Machbena, i ojca Gabaa. A córka Kalebowa była Achsa.
###### **1Krn 2,50**
 Ci byli synowie Kaleb syna Hur pierworodnego Ephrata, Sobal ociec Kariathiarim.
###### **1Krn 2,51**
 Salma ociec Bethlehem, Hariph ociec Bethgader.
###### **1Krn 2,52**
 A byli synowie Sobala ojca Kariathiarim, który doglądał połowicę odpoczynków.
###### **1Krn 2,53**
 A z rodu Kariathiarim, Jetrejowie, i Aphuthejowie, i Semathejowie, i Maserejowie. Z tych wyszli Saraitowie, i Esthaolitowie.
###### **1Krn 2,54**
 Synowie Salmy: Bethlehem, i Netophaty, Korony domu Joabowego, a połowica odpoczynku Sarai.
###### **1Krn 2,55**
 Rodziny też pisarzów mieszkających w Jabes, Śpiewający, i Brzmiący, i w namieciech mieszkający. Ci są Cineowie, którzy poszli od Ciepła ojca domu Rechab.
