# Dz 6 BT5
###### **Dz 6,1**
 Wówczas, gdy liczba uczniów wzrastała, zaczęli helleniści szemrać przeciwko Hebrajczykom, że przy codziennym rozdawaniu jałmużny zaniedbywano ich wdowy.
###### **Dz 6,2**
 «***Nie jest rzeczą słuszną, abyśmy zaniedbali słowo Boże, a obsługiwali stoły***» – powiedziało Dwunastu, zwoławszy wszystkich uczniów.
###### **Dz 6,3**
 «***Upatrzcie zatem, bracia, siedmiu mężów spośród siebie, cieszących się dobrą sławą, pełnych Ducha i mądrości. Im zlecimy to zadanie.***
###### **Dz 6,4**
 ***My zaś oddamy się wyłącznie modlitwie i posłudze słowa***».
###### **Dz 6,5**
 Spodobały się te słowa wszystkim zebranym i wybrali Szczepana, męża pełnego wiary i Ducha Świętego, oraz Filipa, Prochora, Nikanora, Tymona, Parmenasa i Mikołaja, prozelitę z Antiochii.
###### **Dz 6,6**
 Przedstawili ich Apostołom, którzy, modląc się, położyli na nich ręce.
###### **Dz 6,7**
 A słowo Boże szerzyło się, wzrastała też bardzo liczba uczniów w Jerozolimie, a nawet bardzo wielu kapłanów przyjmowało wiarę.
###### **Dz 6,8**
 Szczepan, pełen łaski i mocy, działał cuda i znaki wielkie wśród ludu.
###### **Dz 6,9**
 Niektórzy zaś z synagogi zwanej [synagogą] Wyzwoleńców oraz Cyrenejczyków i Aleksandryjczyków, i tych, którzy pochodzili z Cylicji i z Azji, przystąpili do rozprawy ze Szczepanem.
###### **Dz 6,10**
 Nie mogli jednak sprostać mądrości i Duchowi, z którego [natchnienia] przemawiał.
###### **Dz 6,11**
 Podstawili więc ludzi, którzy zeznali: «***Słyszeliśmy, jak on wypowiadał bluźnierstwa przeciwko Mojżeszowi i Bogu***».
###### **Dz 6,12**
 W ten sposób podburzyli lud, starszych i uczonych w Piśmie. Przybiegli, porwali go i zaprowadzili przed Sanhedryn.
###### **Dz 6,13**
 Tam postawili fałszywych świadków, którzy zeznali: «***Ten człowiek nie przestaje mówić przeciwko temu świętemu miejscu i przeciwko Prawu.***
###### **Dz 6,14**
 ***Bo słyszeliśmy, jak mówił, że Jezus Nazarejczyk zburzy to miejsce i pozmienia zwyczaje, które nam Mojżesz przekazał***».
###### **Dz 6,15**
 A wszyscy, którzy zasiadali w Sanhedrynie, przyglądali się mu uważnie i zobaczyli twarz jego, podobną do oblicza anioła.
# Dz 6 PAU
###### **Dz 6,1**
 Był to czas, gdy powiększała się liczba uczniów. Helleniści zaczęli narzekać na Hebrajczyków. Twierdzili, że ich wdowy są niesprawiedliwie traktowane podczas codziennej posługi.
###### **Dz 6,2**
 Wtedy Dwunastu zwołało zgromadzenie wszystkich uczniów i powiedziało: „Nie jest słuszne, abyśmy zaniedbywali głoszenie słowa Bożego, a zajmowali się obsługiwaniem stołów.
###### **Dz 6,3**
 Wybierzcie więc, bracia, siedmiu mężczyzn, cieszących się dobrą opinią, pełnych Ducha Świętego i mądrości! Im zlecimy to zadanie.
###### **Dz 6,4**
 My zaś poświęcimy się wyłącznie modlitwie i służbie słowa”.
###### **Dz 6,5**
 Wszyscy się z tym zgodzili. Wybrano Szczepana, człowieka pełnego wiary i Ducha Świętego, oraz Filipa, Prochora, Nikanora, Tymona, Parmenasa, a także Mikołaja, prozelitę z Antiochii.
###### **Dz 6,6**
 Zaprowadzono ich do apostołów, którzy modląc się, nałożyli na nich ręce.
###### **Dz 6,7**
 A słowo Boże rozszerzało się coraz bardziej. Zwiększała się też bardzo liczba uczniów w Jeruzalem. Uwierzyło nawet wielu kapłanów.
###### **Dz 6,8**
 Szczepan, napełniony łaską i mocą, czynił cuda i wielkie znaki wśród ludzi.
###### **Dz 6,9**
 Niektórzy wystąpili przeciwko niemu. Pochodzili oni z synagogi wyzwoleńców, Cyrenejczyków, Aleksandryjczyków oraz z Cylicji i Azji. Dyskutowali oni ze Szczepanem.
###### **Dz 6,10**
 Nie byli jednak w stanie sprostać mądrości i Duchowi, pod wpływem którego przemawiał.
###### **Dz 6,11**
 Wtedy podstawili ludzi, którzy zeznali: „Słyszeliśmy, jak on wypowiadał bluźniercze słowa przeciwko Mojżeszowi i Bogu”.
###### **Dz 6,12**
 W ten sposób podburzyli lud, starszych oraz nauczycieli Pisma. Zebrali się, pojmali go i zaprowadzili przed Wysoką Radę.
###### **Dz 6,13**
 Tam również podstawili fałszywych świadków, którzy zeznali: „Człowiek ten ciągle występuje przeciwko świątyni i Prawu.
###### **Dz 6,14**
 Słyszeliśmy, jak mówił: «Jezus Nazarejczyk zniszczy to miejsce i zmieni zwyczaje, które przekazał nam Mojżesz»”.
###### **Dz 6,15**
 A wszyscy, którzy znajdowali się w sali posiedzeń, widzieli, że ma twarz jakby oblicze anioła.
# Dz 6 BP
###### **Dz 6,1**
 W tym czasie, gdy wzrastała liczba uczniów, helleniści zaczęli szemrać przeciwko Hebrajczykom, że wspierając codziennie ubogich zaniedbywali ich wdowy.
###### **Dz 6,2**
 W związku z tym Dwunastu zwołało wszystkich uczniów i oświadczyło: "Niesłuszne jest, byśmy zostawili głoszenie słowa Bożego na rzecz obsługiwania stołów.
###### **Dz 6,3**
 Rozejrzyjcie się więc, bracia, by wybrać spośród was siedmiu mężczyzn, cieszących się dobrą opinią, pełnych ducha i mądrości, którym zlecimy to zadanie.
###### **Dz 6,4**
 My zaś oddawać się będziemy nieustannie modlitwie i posłudze słowa".
###### **Dz 6,5**
 Słowa te spodobały się całej gminie. Wybrano Szczepana, człowieka pełnego wiary i Ducha Świętego, Filipa, Prochora, Nikanora, Tymona, Parmenasa i Mikołaja, prozelitę z Antiochii.
###### **Dz 6,6**
 Zaprowadzono ich do apostołów, którzy w czasie modlitwy włożyli na nich ręce.
###### **Dz 6,7**
 A słowo Boże rozszerzyło się i zwiększała się coraz bardziej liczba uczniów w Jerozolimie. Nawet wielu przysłuchujących się kapłanów przyjęło wiarę.
###### **Dz 6,8**
 Szczepan, pełen łaski i mocy, dokonywał wśród ludu wiele zdumiewających znaków.
###### **Dz 6,9**
 Wtedy podjęli z nim dyskusję niektórzy ludzie, należący do synagogi Wyzwoleńców, Cyrenejczyków i Aleksandryjczyków, mieszkańcy Cylicji i Azji.
###### **Dz 6,10**
 Nie mogąc jednak dorównać mądrości i Duchowi, pod wpływem którego przemawiał,
###### **Dz 6,11**
 podstawili ludzi, aby zeznali: "Słyszeliśmy, jak rzucał bluźnierstwa przeciwko Mojżeszowi i Bogu".
###### **Dz 6,12**
 Podburzyli lud, kapłanów i nauczycieli Pisma, podeszli do niego, schwytali i zaprowadzili przed sanhedryn,
###### **Dz 6,13**
 a potem postawili fałszywych świadków, którzy oświadczyli: "Człowiek ten nie przestaje bluźnić przeciwko miejscu świętemu i Prawu.
###### **Dz 6,14**
 Słyszeliśmy bowiem, jak mówił, że Jezus z Nazaretu, zburzy to miejsce i zmieni zwyczaje, które dał nam Mojżesz".
###### **Dz 6,15**
 Wszyscy zasiadający w sanhedrynie wpatrywali się w niego i widzieli, że twarz jego podobna jest do oblicza anioła.
# Dz 6 BR
###### **Dz 6,1**
 A kiedy liczba uczniów wzrastała coraz bardziej, helleniści poczęli oskarżać Hebrajczyków o to, że przy codziennym rozdzielaniu jałmużny krzywdzą ich wdowy.
###### **Dz 6,2**
 I wtedy to na zebraniu Dwunastu i wszystkich uczniów stwierdzono, co następuje: Nie wypada, żebyśmy zaniedbywali głoszenia słowa Bożego, poświęcając swój czas na posługiwanie przy stołach.
###### **Dz 6,3**
 Wybierzcie tedy, bracia, spośród siebie siedmiu mężów o nienagannej sławie, pełnych Ducha Bożego i mądrości, i im zlećcie to zadanie.
###### **Dz 6,4**
 A my oddamy się wtedy wyłącznie modlitwie i głoszeniu słowa.
###### **Dz 6,5**
 Trafiło to do przekonania wszystkim zgromadzonym. Wybrali więc Szczepana, męża pełnego wiary i Ducha Świętego, Filipa, Prochora, Nikanora, Tymona, Parmenasa i Mikołaja, prozelitę z Antiochii.
###### **Dz 6,6**
 Przedstawiono ich apostołom, a ci, modląc się, włożyli na nich ręce.
###### **Dz 6,7**
 A słowo Boże rozchodziło się coraz bardziej, wzrastała też liczba uczniów w Jerozolimie. Nawracało się nawet wielu kapłanów.
###### **Dz 6,8**
 Szczepan zaś, pełen łaski i mocy [Bożej], działał cuda i znaki wielkie wśród ludu.
###### **Dz 6,9**
 Wtedy niektórzy z synagogi Libertynów, Cyrenejczyków i Aleksandryjczyków, i tych, którzy pochodzili z Cylicji i z Azji, postanowili rozprawić się ze Szczepanem.
###### **Dz 6,10**
 Nie mogli jednak przeciwstawić się skutecznie mądrości i Duchowi, z którego natchnienia przemawiał.
###### **Dz 6,11**
 Przekupili więc ludzi, którzy oświadczyli: Słyszeliśmy, jak ten bluźnił przeciwko Mojżeszowi i Bogu.
###### **Dz 6,12**
 W ten sposób zdołali podburzyć lud, starszyznę i uczonych w Piśmie. Przybiegli tedy, porwali go i zaprowadzili przed Sanhedryn.
###### **Dz 6,13**
 Tam zaś znów podstawili fałszywych świadków, którzy zeznali: Ten człowiek ciągle występuje przeciwko temu świętemu miejscu i przeciwko Prawu.
###### **Dz 6,14**
 Słyszeliśmy bowiem, jak mówił, że Jezus z Nazaretu zburzy to miejsce i poznosi obyczaje, które nam przekazał sam Mojżesz.
###### **Dz 6,15**
 A wszyscy członkowie Sanhedrynu przypatrywali się z uwagą jego twarzy, przypominającej wyglądem oblicze anioła.
# Dz 6 WUJ
###### **Dz 6,1**
 A we dni one gdy rosła liczba uczniów, stało się szemranie Greków przeciw Żydom, iż w posługowaniu powszedniem, bywały pogardzone wdowy ich.
###### **Dz 6,2**
 A dwanaście zezwawszy gromadę uczniów, rzekł: Nie jest słuszna, żebyśmy my opuścili słowo Boże, a stołom służyli.
###### **Dz 6,3**
 Upatrzcież tedy, Bracia, z was siedmi mężów dobre świadectwo mających, pełnych Ducha świętego, i mądrości, którebyśmy przełożyli nad tą sprawą.
###### **Dz 6,4**
 A my modlitwy i usługowania słowa pilnować będziemy.
###### **Dz 6,5**
 I podobała się mowa przed wszystką gromadą. I obrali Szczepana męża pełnego wiary i Ducha ś. i Filipa, i Prochora, i Nikanora, i Tymona, i Parmena, i Mikołaja nowożydowina Antiocheńczyka.
###### **Dz 6,6**
 Te postawili przed oczyma Apostołów, a modliwszy się włożyli na nie ręce.
###### **Dz 6,7**
 A słowo Pańskie rosło, i mnożył się poczet uczniów barzo w Jeruzalem: wielkie też mnóstwo kapłanów posłuszne było wierze.
###### **Dz 6,8**
 A Szczepan pełen łaski i mocy czynił cuda i znaki wielkie między ludem.
###### **Dz 6,9**
 I powstali niektórzy z bóżnice, którą zowią Libertynów i Cerenejczyków, i Aleksandryanów, i tych, którzy byli z Cylicjej i z Azjej, gadając się z Szczepanem.
###### **Dz 6,10**
 I nie mogli się sprzeciwić mądrości i Duchowi, który mówił.
###### **Dz 6,11**
 Tedy naprawili męże, którzyby mówili, że go słyszeli mówiącego słowa bluźnierskie przeciw Mojżeszowi i Bogu.
###### **Dz 6,12**
 A tak wzruszyli lud i starsze i Doktory: a zbieżawszy się porwali go, i przywiedli do rady:
###### **Dz 6,13**
 I postawili fałszywe świadki, którzy mówili: Ten człowiek nie przestawa mówić słów przeciw miejscu świętemu, i zakonowi.
###### **Dz 6,14**
 Abowiemeśmy go słyszeli, mówiącego: Iż Jezus Nazareński ten zburzy to miejsce, i odmieni podania które nam podał Mojżesz.
###### **Dz 6,15**
 A patrząc nań pilnie wszyscy, którzy siedzieli w radzie, widzieli oblicze jego jako oblicze anielskie.
# Dz 6 STERN
###### **Dz 6,1**
 Mniej więcej w tym czasie, gdy liczba talmidim rosła, greckojęzyczni Żydzi zaczęli się uskarżać na tych, którzy mówili po hebrajsku, że podczas codziennego rozdziału dóbr pomija się ich wdowy.
###### **Dz 6,2**
 Dwunastu zwołało więc ogólne zebranie talmidim i powiedzieli: "Nie jest właściwe, abyśmy zaniedbywali Słowo Boże, ażeby podawać do stołów.
###### **Dz 6,3**
 Bracia, wybierzcie spomiędzy siebie siedmiu ludzi, o których wiadomo, że są pełni Ducha i mądrości. Wyznaczymy ich, aby odpowiadali za tę ważną sprawę,
###### **Dz 6,4**
 my sami jednak poświęcimy się całkowicie modlitwie i służbie Słowu".
###### **Dz 6,5**
 To, co powiedzieli, spodobało się wszystkim zebranym. Wybrali Szczepana, męża pełnego wiary i Ruach Ha-Kodesz, Filipa, Prochorosa, Nikanora, Tymona, Parmenasa i Mikołaja, prozelitę z Antiochii.
###### **Dz 6,6**
 Przedstawili ich wysłannikom, który modlili się i nałożyli na nich ręce.
###### **Dz 6,7**
 Słowo Boże szerzyło się więc dalej. Liczba talmidim w Jeruszalaim rosła gwałtownie i wielka rzesza kohanim stawała się posłuszna wierze.
###### **Dz 6,8**
 A Szczepan, pełen łaski i mocy, dokonywał wielkich cudów i znaków wśród ludu.
###### **Dz 6,9**
 Lecz zrodził się sprzeciw wśród członków Synagogi Wyzwoleńców (jak ją nazywano), złożonej z Cyrenejczyków, Aleksandryjczyków i ludzi z Cylicji i prowincji Azja. Spierali się ze Szczepanem,
###### **Dz 6,10**
 ale nie mogli sprostać jego mądrości ani Duchowi, w którym przemawiał.
###### **Dz 6,11**
 Potajemnie namówili więc jakichś ludzi, aby przysięgli: "Słyszeliśmy, jak bluźnił przeciwko Moszemu i przeciwko Bogu".
###### **Dz 6,12**
 Podburzyli lud, a także starszych i nauczycieli Tory, i przyszli, i pojmali go, i zaprowadzili przed Sanhedrin.
###### **Dz 6,13**
 - - -
###### **Dz 6,14**
 Tam podstawili fałszywych świadków, którzy powiedzieli: "Ten człowiek nigdy nie przestaje występować przeciwko temu miejscu świętemu i przeciwko Torze, bo słyszeliśmy, jak mówi, że Jeszua z Naceret zniszczy to miejsce i zmieni zwyczaje, jakie przekazał nam Mosze".
###### **Dz 6,15**
 Wszyscy w Sanhedrinie wpatrywali się w Szczepana i widzieli, że twarz jego wygląda jak twarz anioła.
# Dz 6 TRO
###### **Dz 6,1**
 **εν** *en* W [[G1722]] [[PREP]] **δε** *de* zaś [[G1161]] [[CONJ]] **ταις** *tais* [[G3588]] WTT-DPF **ημεραις** *hēmerais* dniach [[G2250]] WTN-DPF **ταυταις** *tautais* tych [[G3778]] WTD-DPF **πληθυνοντων** *plēthynontōn* gdy mnożą się [[G4129]] WTV-PAP-GPM **των** *tōn* [[G3588]] WTT-GPM **μαθητων** *mathētōn* uczniowie [[G3101]] WTN-GPM **εγενετο** *egeneto* stało się [[G1096]] WTV-2ADI-3S **γογγυσμος** *gongysmos* szemranie [[G1112]] [[N-NSM]] **των** *tōn* [[G3588]] WTT-GPM **ελληνιστων** *hellēnistōn* Greków – Hellenistów [[G1675]] WTN-GPM **προς** *pros* na [[G4314]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **εβραιους** *hebraious* Hebrajczyków – [poza obszar] [[G1445]] WTA-APM **οτι** *hoti* że [[G3754]] [[CONJ]] **παρεθεωρουντο** *paretheōrounto* są przeoczane – są zaniedbywane [[G3865]] WTV-IPI-3P **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **διακονια** *diakonia* posłudze – służbie [[G1248]] [[N-DSF]] **τη** *tē* [[G3588]] WTT-DSF **καθημερινη** *kathēmerinē* codziennej [[G2522]] WTA-DSF **αι** *hai* [[G3588]] [[T-NPF]] **χηραι** *chērai* wdowy [[G5503]] [[N-NPF]] **αυτων** *autōn* ich [[G846]] WTP-GPM
###### **Dz 6,2**
 **προσκαλεσαμενοι** *proskalesamenoi* Przywoławszy – Wezwawszy [[G4341]] WTV-ADP-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **δωδεκα** *dōdeka* dwunastu [[G1427]] WTA-NUI **το** *to* [[G3588]] WTT-ASN **πληθος** *plēthos* mnóstwo – mnogość [[G4128]] WTN-ASN **των** *tōn* [[G3588]] WTT-GPM **μαθητων** *mathētōn* uczniów [[G3101]] WTN-GPM **ειπον** *eipon* powiedzieli [[G2036]] WTV-2AAI-3P **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **αρεστον** *areston* podobające się – przyjemne [[G701]] WTA-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ημας** *hēmas* nam [[G2248]] WTP-1AP **καταλειψαντας** *kataleipsantas* pozostawiwszy – opuściwszy [[G2641]] WTV-AAP-APM **τον** *ton* [[G3588]] [[T-ASM]] **λογον** *logon* Słowo [[G3056]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **διακονειν** *diakonein* służyć [[G1247]] WTV-PAN **τραπεζαις** *trapezais* stołom [[G5132]] WTN-DPF
###### **Dz 6,3**
 **επισκεψασθε** *episkepsasthe* Przyjrzyjcie się [[G1980]] WTV-ADM-2P **ουν** *oun* więc [[G3767]] [[CONJ]] **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **ανδρας** *andras* mężom [[G435]] [[N-APM]] **εξ** *eks* z [[G1537]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **μαρτυρουμενους** *martyroumenous* którzy są poświadczeni [[G3140]] WTV-PPP-APM **επτα** *hepta* siedmiu [[G2033]] WTA-NUI **πληρεις** *plēreis* pełnych [[G4134]] WTA-APM **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **αγιου** *hagiou* Świętego [[G40]] [[A-GSN]] **και** *kai* i [[G2532]] [[CONJ]] **σοφιας** *sofias* mądrości [[G4678]] [[N-GSF]] **ους** *hous* których [[G3739]] WTR-APM **καταστησομεν** *katastēsomen* ustanowimy [[G2525]] WTV-FAI-1P **επι** *epi* do [[G1909]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **χρειας** *chreias* potrzeby [[G5532]] [[N-GSF]] **ταυτης** *tautēs* tej [[G3778]] WTD-GSF
###### **Dz 6,4**
 **ημεις** *hēmeis* My [[G2249]] WTP-1NP **δε** *de* zaś [[G1161]] [[CONJ]] **τη** *tē* [[G3588]] WTT-DSF **προσευχη** *proseuchē* modlitwie [[G4335]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **τη** *tē* [[G3588]] WTT-DSF **διακονια** *diakonia* posłudze – służbie [[G1248]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSM **λογου** *logou* Słowa [[G3056]] [[N-GSM]] **προσκαρτερησομεν** *proskarterēsomen* będziemy trwającymi niezłomnie [[G4342]] WTV-FAI-1P
###### **Dz 6,5**
 **και** *kai* I [[G2532]] [[CONJ]] **ηρεσεν** *ēresen* spodobało się [[G700]] [[V-AAI-3S]] **ο** *ho* (to) [[G3588]] [[T-NSM]] **λογος** *logos* słowo [[G3056]] [[N-NSM]] **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **παντος** *pantos* całym [[G3956]] [[A-GSN]] **του** *tou* [[G3588]] WTT-GSN **πληθους** *plēthous* mnóstwem – mnogością [[G4128]] [[N-GSN]] **και** *kai* i [[G2532]] [[CONJ]] **εξελεξαντο** *ekseleksanto* wybrali [[G1586]] WTV-AMI-3P **στεφανον** *stefanon* Szczepana – [wieniec] [[G4736]] [[N-ASM]] **ανδρα** *andra* męża [[G435]] [[N-ASM]] **πληρη** *plērē* pełnego [[G4134]] WTA-ASM **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **αγιου** *hagiou* Świętego [[G40]] [[A-GSN]] **και** *kai* i [[G2532]] [[CONJ]] **φιλιππον** *filippon* Filipa – [miłujący konie] [[G5376]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **προχορον** *prochoron* Prochora – [przed tańcem] [[G4402]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **νικανορα** *nikanora* Nikanora – [człowiek zwycięstwa] [[G3527]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **τιμωνα** *timōna* Tymona – [cena] [[G5096]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **παρμεναν** *parmenan* Parmena – [stały] [[G3937]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **νικολαον** *nikolaon* Mikołaja – [zwycięzca ludu] [[G3532]] [[N-ASM]] **προσηλυτον** *prosēlyton* prozelitę [[G4339]] [[N-ASM]] **αντιοχεα** *antiochea* Antiocheńczyka [[G491]] [[N-ASM]]
###### **Dz 6,6**
 **ους** *hous* których [[G3739]] WTR-APM **εστησαν** *hestēsan* postawili [[G2476]] WTV-2AAI-3P **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **των** *tōn* [[G3588]] WTT-GPM **αποστολων** *apostolōn* wysłannikami [[G652]] WTN-GPM **και** *kai* i [[G2532]] [[CONJ]] **προσευξαμενοι** *proseuksamenoi* pomodliwszy się [[G4336]] WTV-ADP-NPM **επεθηκαν** *epethēkan* położyli na [[G2007]] WTV-AAI-3P **αυτοις** *autois* nich [[G846]] WTP-DPM **τας** *tas* [[G3588]] WTT-APF **χειρας** *cheiras* ręce [[G5495]] WTN-APF
###### **Dz 6,7**
 **και** *kai* I [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **λογος** *logos* Słowo [[G3056]] [[N-NSM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ηυξανεν** *ēuksanen* wzrastało [[G837]] WTV-IAI-3S **και** *kai* i [[G2532]] [[CONJ]] **επληθυνετο** *eplēthyneto* była pomnażana [[G4129]] WTV-IPI-3S **ο** *ho* [[G3588]] [[T-NSM]] **αριθμος** *arithmos* liczba [[G706]] [[N-NSM]] **των** *tōn* [[G3588]] WTT-GPM **μαθητων** *mathētōn* uczniów [[G3101]] WTN-GPM **εν** *en* w [[G1722]] [[PREP]] **ιερουσαλημ** *ierousalēm* Jeruzalem – [dziedzictwo pokoju] [[G2419]] [[N-PRI]] **σφοδρα** *sfodra* bardzo [[G4970]] [[ADV]] **πολυς** *polys* wielki [[G4183]] [[A-NSM]] **τε** *te* zarówno – także [[G5037]] WTPRT **οχλος** *ochlos* tłum [[G3793]] [[N-NSM]] **των** *tōn* [[G3588]] WTT-GPM **ιερεων** *hiereōn* kapłanów [[G2409]] WTN-GPM **υπηκουον** *hypēkouon* byli posłuszni (był posłuszny) [[G5219]] WTV-IAI-3P **τη** *tē* [[G3588]] WTT-DSF **πιστει** *pistei* wierze [[G4102]] [[N-DSF]]
###### **Dz 6,8**
 **στεφανος** *stefanos* Szczepan – [wieniec] [[G4736]] [[N-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **πληρης** *plērēs* pełen [[G4134]] [[A-NSM]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **δυναμεως** *dynameōs* mocy [[G1411]] [[N-GSF]] **εποιει** *epoiei* czynił [[G4160]] WTV-IAI-3S **τερατα** *terata* cuda [[G5059]] WTN-APN **και** *kai* i [[G2532]] [[CONJ]] **σημεια** *sēmeia* znaki [[G4592]] WTN-APN **μεγαλα** *megala* wielkie [[G3173]] WTA-APN **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **λαω** *laō* ludzie [[G2992]] WTN-DSM
###### **Dz 6,9**
 **ανεστησαν** *anestēsan* Powstali – Podnieśli się [[G450]] WTV-AAI-3P **δε** *de* zaś [[G1161]] [[CONJ]] **τινες** *tines* niektórzy [[G5100]] WTX-NPM **των** *tōn* [[G3588]] WTT-GPM **εκ** *ek* ze [[G1537]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **συναγωγης** *synagōgēs* zgromadzenia – synagogi [[G4864]] [[N-GSF]] **της** *tēs* [[G3588]] [[T-GSF]] **λεγομενης** *legomenēs* która jest nazywana [[G3004]] WTV-PPP-GSF **λιβερτινων** *libertinōn* Libertynów – Wyzwoleńców [[G3032]] WTN-GPM **και** *kai* i [[G2532]] [[CONJ]] **κυρηναιων** *kyrēnaiōn* Cyrenejczyków [[G2956]] WTN-GPM **και** *kai* i [[G2532]] [[CONJ]] **αλεξανδρεων** *aleksandreōn* Aleksandryjczyków [[G221]] WTN-GPM **και** *kai* i [[G2532]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPM **απο** *apo* z [[G575]] [[PREP]] **κιλικιας** *kilikias* Cylicji [[G2791]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **ασιας** *asias* Azji [[G773]] [[N-GSF]] **συζητουντες** *syzētountes* dociekając razem ze – dyskutując ze [[G4802]] WTV-PAP-NPM **τω** *tō* [[G3588]] WTT-DSM **στεφανω** *stefanō* Szczepanem – [wieniec] [[G4736]] WTN-DSM
###### **Dz 6,10**
 **και** *kai* i [[G2532]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ισχυον** *ischyon* mieli siłę [[G2480]] WTV-IAI-3P **αντιστηναι** *antistēnai* przeciwstawić się – stanąć przeciw [[G436]] [[V-2AAN]] **τη** *tē* [[G3588]] WTT-DSF **σοφια** *sofia* mądrości [[G4678]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **τω** *tō* [[G3588]] WTT-DSN **πνευματι** *pneumati* Duchowi [[G4151]] WTN-DSN **ω** *hō* któremu [[G3739]] WTR-DSN **ελαλει** *elalei* mówił [[G2980]] WTV-IAI-3S
###### **Dz 6,11**
 **τοτε** *tote* Wtedy [[G5119]] [[ADV]] **υπεβαλον** *hypebalon* podstawili – podrzucili [[G5260]] WTV-2AAI-3P **ανδρας** *andras* mężów [[G435]] [[N-APM]] **λεγοντας** *legontas* mówiących [[G3004]] WTV-PAP-APM **οτι** *hoti* że [[G3754]] [[CONJ]] **ακηκοαμεν** *akēkoamen* słyszeliśmy [[G191]] WTV-2RAI-1P-ATT **αυτου** *autou* go [[G846]] [[P-GSM]] **λαλουντος** *lalountos* mówiącego [[G2980]] WTV-PAP-GSM **ρηματα** *rēmata* wypowiedzi [[G4487]] WTN-APN **βλασφημα** *blasfēma* bluźniercze – krzywdząco mówiące [[G989]] WTA-APN **εις** *eis* na [[G1519]] [[PREP]] **μωσην** *mōsēn* Mojżesza – [wyciągnąć] [[G3475]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **τον** *ton* [[G3588]] [[T-ASM]] **θεον** *theon* Boga [[G2316]] [[N-ASM]]
###### **Dz 6,12**
 **συνεκινησαν** *synekinēsan* Poruszyli się razem – Podburzyli się razem [[G4787]] WTV-AAI-3P **τε** *te* zarówno – także [[G5037]] WTPRT **τον** *ton* [[G3588]] [[T-ASM]] **λαον** *laon* lud [[G2992]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **τους** *tous* [[G3588]] WTT-APM **πρεσβυτερους** *presbyterous* starsi [[G4245]] WTA-APM **και** *kai* i [[G2532]] [[CONJ]] **τους** *tous* [[G3588]] WTT-APM **γραμματεις** *grammateis* znawcy Pisma – uczeni w Piśmie [[G1122]] [[N-APM]] **και** *kai* i [[G2532]] [[CONJ]] **επισταντες** *epistantes* przystanąwszy – stanąwszy obok [[G2186]] WTV-2AAP-NPM **συνηρπασαν** *synērpasan* wspólnie porwali [[G4884]] WTV-AAI-3P **αυτον** *auton* go [[G846]] WTP-ASM **και** *kai* i [[G2532]] [[CONJ]] **ηγαγον** *ēgagon* przyprowadzili [[G71]] WTV-2AAI-3P **εις** *eis* do [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **συνεδριον** *synedrion* sanhedrynu – rady [[G4892]] WTN-ASN
###### **Dz 6,13**
 **εστησαν** *hestēsan* Postawili [[G2476]] WTV-2AAI-3P **τε** *te* zarówno – także [[G5037]] WTPRT **μαρτυρας** *martyras* świadków [[G3144]] [[N-APM]] **ψευδεις** *pseudeis* fałszywych – kłamliwych [[G5571]] WTA-APM **λεγοντας** *legontas* mówiących [[G3004]] WTV-PAP-APM **ο** *ho* [[G3588]] [[T-NSM]] **ανθρωπος** *anthrōpos* człowiek [[G444]] [[N-NSM]] **ουτος** *houtos* ten [[G3778]] WTD-NSM **ου** *ou* nie [[G3756]] [[PRT-N]] **παυεται** *pauetai* przestaje – zaprzestaje [[G3973]] WTV-PMI-3S **ρηματα** *rēmata* wypowiedzi [[G4487]] WTN-APN **βλασφημα** *blasfēma* bluźniercze – krzywdząco mówiące [[G989]] WTA-APN **λαλων** *lalōn* mówiąc [[G2980]] [[V-PAP-NSM]] **κατα** *kata* przeciw [[G2596]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **τοπου** *topou* miejscu [[G5117]] [[N-GSM]] **του** *tou* [[G3588]] WTT-GSM **αγιου** *hagiou* świętemu [[G40]] WTA-GSM **τουτου** *toutou* temu [[G5127]] WTD-GSM **και** *kai* i [[G2532]] [[CONJ]] **του** *tou* [[G3588]] WTT-GSM **νομου** *nomou* Prawu [[G3551]] [[N-GSM]]
###### **Dz 6,14**
 **ακηκοαμεν** *akēkoamen* Słyszeliśmy [[G191]] WTV-2RAI-1P-ATT **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **αυτου** *autou* go [[G846]] [[P-GSM]] **λεγοντος** *legontos* mówiącego [[G3004]] WTV-PAP-GSM **οτι** *hoti* że [[G3754]] [[CONJ]] **ιησους** *iēsous* Jezus – [JHWH jest zbawieniem] [[G2424]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **ναζωραιος** *nazōraios* Nazarejczyk [[G3480]] [[N-NSM]] **ουτος** *houtos* Ten [[G3778]] WTD-NSM **καταλυσει** *katalysei* obali [[G2647]] WTV-FAI-3S **τον** *ton* [[G3588]] [[T-ASM]] **τοπον** *topon* miejsce [[G5117]] [[N-ASM]] **τουτον** *touton* to [[G5126]] WTD-ASM **και** *kai* i [[G2532]] [[CONJ]] **αλλαξει** *allaksei* zmieni – przemieni [[G236]] WTV-FAI-3S **τα** *ta* [[G3588]] WTT-APN **εθη** *ethē* zwyczaje [[G1485]] WTN-APN **α** *ha* które [[G3739]] WTR-APN **παρεδωκεν** *paredōken* przekazał [[G3860]] [[V-AAI-3S]] **ημιν** *hēmin* nam [[G2254]] WTP-1DP **μωυσης** *mōusēs* Mojżesz – [wyciągnąć] [[G3475]] [[N-NSM]]
###### **Dz 6,15**
 **και** *kai* i [[G2532]] [[CONJ]] **ατενισαντες** *atenisantes* spojrzawszy wprost – skierowawszy wprost wzrok [[G816]] WTV-AAP-NPM **εις** *eis* w [[G1519]] [[PREP]] **αυτον** *auton* niego [[G846]] WTP-ASM **απαντες** *hapantes* wszyscy [[G537]] WTA-NPM **οι** *hoi* [[G3588]] WTT-NPM **καθεζομενοι** *kathezomenoi* siedzący [[G2516]] WTV-PNP-NPM **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **συνεδριω** *synedriō* sanhedrynie – radzie [[G4892]] WTN-DSN **ειδον** *eidon* zobaczyli [[G1492]] WTV-2AAI-3P **το** *to* [[G3588]] WTT-ASN **προσωπον** *prosōpon* oblicze – twarz [[G4383]] WTN-ASN **αυτου** *autou* jego [[G846]] [[P-GSM]] **ωσει** *hōsei* jakby [[G5616]] [[ADV]] **προσωπον** *prosōpon* oblicze – twarz [[G4383]] WTN-ASN **αγγελου** *angelou* zwiastuna [[G32]] [[N-GSM]]
