# Ez 4 BT5
###### **Ez 4,1**
 ***A ty, synu człowieczy, weź sobie tabliczkę glinianą, połóż ją przed sobą i narysuj na niej miasto Jerozolimę.***
###### **Ez 4,2**
 ***Następnie przedstaw jego oblężenie, zbuduj naprzeciw niego szaniec, usyp naprzeciw niego wał, uszykuj przeciwko niemu obóz i ustaw przeciwko niemu tarany dokoła.***
###### **Ez 4,3**
 ***Potem weź sobie patelnię żelazną i uczyń z niej jakby mur żelazny pomiędzy sobą a miastem, i skieruj wzrok swój na nie, tak jakby było oblężone i jakbyś ty je oblegał. To będzie znakiem dla domu Izraela.***
###### **Ez 4,4**
 ***Połóż się na lewym boku, a Ja złożę winę Izraelitów na ciebie. Przez tyle dni będziesz znosił ich winę, przez ile będziesz na nim leżał.***
###### **Ez 4,5**
 ***Podaję ci lata trwania ich winy w liczbie dni: przez trzysta dziewięćdziesiąt dni będziesz znosił winę pokoleń izraelskich.***
###### **Ez 4,6**
 ***A kiedy je wypełnisz, położysz się znów na prawym boku i będziesz znosił przewinienia pokolenia Judy przez czterdzieści dni. Liczę ci jeden dzień za każdy poszczególny rok.***
###### **Ez 4,7**
 ***Następnie ku oblężonej Jerozolimie skierujesz wzrok i obnażone ramię, a będziesz prorokował przeciwko niej.***
###### **Ez 4,8**
 ***Oto nakładam na ciebie powrozy, i tak długo nie obrócisz się z jednego boku na drugi, aż dni twojego ucisku nie zostaną wypełnione.***
###### **Ez 4,9**
 ***Weź sobie pszenicy i jęczmienia, bobu i soczewicy, prosa i orkiszu: włóż je do tego samego naczynia i przygotuj sobie z tego chleb. Będziesz go spożywał przez tyle dni, przez ile będziesz leżał na boku – przez trzysta dziewięćdziesiąt dni.***
###### **Ez 4,10**
 ***Waga tego pokarmu, który będziesz spożywał, wyniesie dwadzieścia syklów na dzień. Raz na dobę będziesz go spożywał.***
###### **Ez 4,11**
 ***Także wodę oszczędnie pić będziesz: wypijesz raz na dobę jedną szóstą hinu.***
###### **Ez 4,12**
 ***Będziesz go spożywał jak podpłomyk jęczmienny; upieczesz go w ich oczach na nawozie ludzkim***».
###### **Ez 4,13**
 I dodał Pan: «***Tak będą spożywać Izraelici swój pokarm nieczysty między poganami, wśród których ich rozproszę***».
###### **Ez 4,14**
 Na to rzekłem: «***Ach, Panie Boże, oto dusza moja nigdy się nie splamiła. Od dzieciństwa aż do tej pory nie spożywałem ani padliny, ani tego, co zostało rozszarpane; żadne mięso nieczyste nie weszło do moich ust***».
###### **Ez 4,15**
 A On rzekł do mnie: «***Patrz, zezwalam ci, byś upiekł sobie pokarm na nawozie krowim zamiast na ludzkim***».
###### **Ez 4,16**
 Następnie rzekł do mnie: «***Synu człowieczy, oto złamię podporę chleba w Jerozolimie, tak że pełni zgryzoty będą jedli chleb ściśle odważony i ze strachem będą pili wodę ściśle odmierzoną,***
###### **Ez 4,17**
 ***aby cierpiąc niedostatek chleba i wody, jeden po drugim mdleli i niszczeli w swych grzechach.***
# Ez 4 PAU
###### **Ez 4,1**
 „Synu człowieczy, weź glinianą tabliczkę, połóż ją przed sobą i wyrysuj na niej miasto Jeruzalem.
###### **Ez 4,2**
 Przedstaw jego oblężenie: zbuduj dokoła niego szaniec, usyp wał i rozstaw obozy. Postaw wokół niego tarany.
###### **Ez 4,3**
 Potem weź żelazną płytę, połóż ją jak żelazny mur między tobą a miastem i patrz na nie. Będzie ono jakby oblężone, tak jakbyś to ty je oblegał. To jest znak dla ludu izraelskiego.
###### **Ez 4,4**
 Potem połóż się na lewym boku i złóż na nim winę ludu izraelskiego. Ile dni będziesz tak leżał, tyle będziesz ponosił karę, na którą oni zasłużyli.
###### **Ez 4,5**
 Ja decyduję, jak długo będziesz ponosił karę za ich winy. Będziesz ponosił karę za winy ludu izraelskiego przez trzysta dziewięćdziesiąt dni.
###### **Ez 4,6**
 Gdy skończy się ten czas, położysz się z powrotem na prawym boku i będziesz ponosił karę za winy ludu judzkiego przez czterdzieści dni. Wyznaczam ci po jednym dniu za każdy rok.
###### **Ez 4,7**
 Swoją twarz i odsłonięte ramię zwrócisz na oblężoną Jerozolimę i będziesz prorokował przeciw niej.
###### **Ez 4,8**
 A oto Ja nakładam na ciebie pęta i nie obrócisz się z boku na bok, aż skończą się dni twojego ucisku”.
###### **Ez 4,9**
 „Weź sobie pszenicy, jęczmienia, bobu, soczewicy, prosa i orkiszu, następnie włóż to wszystko do jednego naczynia i zrób z tego chleb. Przez wszystkie trzysta dziewięćdziesiąt dni, gdy będziesz leżał na boku, masz się żywić tym chlebem.
###### **Ez 4,10**
 Twój dzienny posiłek będzie ważył dwadzieścia syklów i będziesz go jadł dzień po dniu.
###### **Ez 4,11**
 Również wodę będziesz pił w określonej ilości: dzień po dniu będziesz pił szóstą część hinu.
###### **Ez 4,12**
 Będziesz jadł podpłomyk jęczmienny, który w ich obecności upieczesz na ludzkich odchodach”.
###### **Ez 4,13**
 I powiedział PAN: „Tak Izraelici będą jedli swój chleb nieczysty wśród narodów, do których ich ześlę”.
###### **Ez 4,14**
 Odpowiedziałem: Ach, PANIE mój, BOŻE, przecież moje usta nigdy się nie skalały niczym nieczystym. Od młodości aż do tej pory nie jadłem ani padliny, ani rozszarpanego zwierzęcia, nie miałem też w ustach nieczystego mięsa.
###### **Ez 4,15**
 Powiedział do mnie: „Patrz, daję ci nawóz bydlęcy zamiast odchodów ludzkich. Na nim upieczesz swój chleb”.
###### **Ez 4,16**
 I dodał: „Synu człowieczy, oto Ja zmniejszam zapas chleba w Jerozolimie. Będą z lękiem jedli odważone porcje i w przygnębieniu pili odmierzoną wodę.
###### **Ez 4,17**
 Będą łaknąć chleba i wody, będą drżeć jeden przed drugim i marnieć z powodu swojej nieprawości”.
# Ez 4 BP
###### **Ez 4,1**
 Ty, synu człowieczy, weź tabliczkę glinianą, połóż ją przed sobą i wyryj na niej miasto Jeruzalem.
###### **Ez 4,2**
 przedstaw jego oblężenie. Zbuduj przeciw niemu maszyny oblężnicze, usyp szaniec, wytycz obozy i ustaw wokoło tarany.
###### **Ez 4,3**
 potem ty weź blachę żelazną, połóż ją [niby] mur żelazny między sobą a miastem i zwróć swoją twarz na nie. [Ono] będzie oblężone, a ty będziesz je oblegał. To jest znak dla Domu Izraela.
###### **Ez 4,4**
 Połóż się [też] na swym lewym boku i złóż na nim winę Domu Izraela. Przez tyle dni będziesz dźwigał ich winę, ile będziesz na nim leżał.
###### **Ez 4,5**
 Ja wyznaczam ci lata, [które odpowiadają] ich winie. Masz dźwigać winę Domu Izraela w liczbie trzystu dziewięćdziesięciu dni.
###### **Ez 4,6**
 A gdy tego dokonasz, położysz się powtórnie na swym prawym boku i będziesz dźwigał winę Domu Judy przez czterdzieści dni. Za każdy rok wyznaczam ci jeden dzień.
###### **Ez 4,7**
 Zwrócisz swą twarz i swe obnażone ramię na oblężoną Jerozolimę i będziesz prorokował przeciw niej.
###### **Ez 4,8**
 Oto nakładam na ciebie pęta, abyś się nie mógł obrócić z boku na bok, aż dopełnisz dni twego skrępowania.
###### **Ez 4,9**
 Ty weź też sobie pszenicy, jęczmienia, bobu, soczewicy, prosa i orkiszu, włóż je do jednego naczynia i zrób z nich chleb. Będziesz go jadł przez tyle dni, ile będziesz leżał na swym boku, [tj. przez] trzysta dziewięćdziesiąt dni.
###### **Ez 4,10**
 Twój pokarm, który będziesz spożywał, będzie ważył dwadzieścia syklów na dzień. Będziesz go spożywał w oznaczonym czasie.
###### **Ez 4,11**
 Wodę będziesz pił w określonej ilości, tj. szóstą część hinu w oznaczonym czasie.
###### **Ez 4,12**
 Będziesz jadł podpłomyk jęczmienny, a będziesz go piekł na ich oczach, [paląc] wyschniętym nawozem ludzkim.
###### **Ez 4,13**
 I rzekł Jahwe: Tak synowie Izraela będą spożywali swój chleb nieczysty pośród ludów tam, dokąd ich ześlę.
###### **Ez 4,14**
 Odezwałem się wówczas: Ach, Panie mój, Jahwe, oto dusza moja nigdy się nie splamiła. Od młodości mojej aż do tego czasu nie jadłem padliny ani mięsa [bydlęcia] rozszarpanego [przez dzikie zwierzę], a mięso nieczyste nie dotknęło ust moich.
###### **Ez 4,15**
 Powiedział mi wtedy: Patrz, pozwalam ci [używać] nawozu zwierzęcego zamiast nawozu ludzkiego. Na nim więc będziesz piekł swój chleb.
###### **Ez 4,16**
 [Potem] rzekł do mnie: Synu człowieczy, oto Ja łamię laskę chleba w Jerozolimie. Będą jedli chleb w ilości odważonej i w trwodze oraz będą pili wodę w ilości odmierzonej i z drżeniem,
###### **Ez 4,17**
 aby im brakowało chleba i wody, [żeby] się niszczyli wzajemnie i ginęli w swej nieprawości.
# Ez 4 BR
###### **Ez 4,1**
 Synu człowieczy, weź jedną tabliczkę glinianą, połóż ją przed sobą i wyrysuj na niej granice miasta Jerozolimy.
###### **Ez 4,2**
 Spróbuj następnie przedstawić oblężenie miasta: wyrysuj dokoła wały oblężnicze, ustaw zapory, załóż obóz wojskowy, zbuduj ze wszystkich stron tarany!
###### **Ez 4,3**
 Potem weź żelazną patelnię i umieść ją - jakby mur żelazny - pomiędzy tobą a miastem. Następnie zwróć swoją twarz w stronę miasta - i oto już zaczyna się oblężenie miasta. To ty sam prowadzisz oblężenie. Znak ten ma posłużyć za ostrzeżenie dla Domu Izraela.
###### **Ez 4,4**
 Potem położysz się na lewym boku, a Ja złożę na tobie winy całego Izraela. Jak długo będziesz leżał na tym boku, tak długo będziesz dźwigał ich winy.
###### **Ez 4,5**
 Oznajmiam ci, że ile lat trwały występki Domu Izraela, tyle dni będziesz dźwigał na sobie ich winy. Otóż będzie to trwało trzysta dziewięćdziesiąt dni.
###### **Ez 4,6**
 A kiedy już skończy się ten czas, położysz się na drugim, to jest na prawym, boku i będziesz dźwigał na sobie winy Domu Judy przez czterdzieści dni. Będę cię liczył za każdy rok jeden dzień.
###### **Ez 4,7**
 Potem skierujesz twarz wyraźnie w stronę obleganej Jerozolimy i, wyciągnąwszy rękę w kierunku miasta, będziesz prorokował.
###### **Ez 4,8**
 Ja zaś skrępuję cię teraz powrozami, tak żebyś nie mógł sam przewrócić się z jednego boku na drugi, jak długo będzie trwało oblężenie [miasta].
###### **Ez 4,9**
 Weź sobie trochę pszenicy, jęczmienia, fasoli, soczewicy, prosa i orkiszu. Zmiel wszystko razem w jednym naczyniu i upiecz sobie chleb. Jak długo będziesz leżał na boku, to znaczy przez owych trzysta dziewięćdziesiąt dni, będziesz się żywił tylko tym chlebem.
###### **Ez 4,10**
 Chleb niech będzie na każdy dzień dokładnie odważany, po dwadzieścia syklów na dzień. Co pewien czas będziesz się pożywiał tym chlebem.
###### **Ez 4,11**
 Dokładnie też niech będzie wymierzana woda przeznaczona do picia: po jednej szóstej hinu na dzień. Napijesz się z tego od czasu do czasu.
###### **Ez 4,12**
 Chleb będziesz sobie piekł i spożywał tak jak podpłomyki jęczmienne. Będziesz je piekł, w obecności wszystkich, na nawozie ludzkim.
###### **Ez 4,13**
 Pan powiedział mi także: Izraelici będą także zmuszeni jeść chleb nieczysty wśród narodów, między którymi ich rozproszę.
###### **Ez 4,14**
 Lecz ja odpowiedziałem na to: Ach, Panie mój i Boże, nigdy jeszcze nie popadłem w żadną nieczystość! Od czasu najwcześniejszej młodości nigdy jeszcze nie jadłem padliny ani mięsa z rozszarpanego zwierzęcia. Jeszcze nigdy żadne nieczyste mięso nie znalazło się w moich ustach.
###### **Ez 4,15**
 Wtedy on powiedział do mnie: Dobrze, zgadzam się, żebyś sobie piekł chleb na nawozie nie ludzkim, lecz wołowym.
###### **Ez 4,16**
 A potem tak mi jeszcze powiedział: Synu człowieczy, postanowiłem uszczuplić zapas chleba dla Jerozolimy. Będą musieli bardzo starannie odważać sobie porcje chleba i spożywać go w niepewności. Także wodę będą musieli dokładnie odmierzać i pić ją w zalęknieniu.
###### **Ez 4,17**
 Będzie im bowiem brakować chleba i wody. Nie mając ani jednego, ani drugiego, zaczną słabnąć i ginąć w swoich grzechach.
# Ez 4 WUJ
###### **Ez 4,1**
 A ty synu człowieczy weźmi sobie cegłę, a położysz ją przed sobą: i wyrysujesz na niej miasto Jeruzalem.
###### **Ez 4,2**
 I sporządzisz przeciw niemu oblężenie, a zbudujesz baszty, i usypiesz wał, i położysz przeciwko jemu obozy, i postawisz tarany w koło.
###### **Ez 4,3**
 A ty weźmi sobie panew żelazną, i postawisz ją miasto muru żelaznego między tobą a między miastem: a umocnisz twarz twoję przeciw niemu, i będzie oblężone, i obtoczysz je: znak jest domowi Izraelowemu.
###### **Ez 4,4**
 A ty będziesz spał na bok twój lewy, i włożysz nieprawości domu Izraelowego nań, wedle liczby dniów, których spać będziesz na nim, i przyjmiesz nieprawości ich.
###### **Ez 4,5**
 A ja dałem tobie lata nieprawości ich, wedle liczby dni, trzysta i dziewięćdziesiąt dni: i poniesiesz nieprawość domu Izraelowego.
###### **Ez 4,6**
 A dokonawszy tego, będziesz spał na bok twój prawy powtóre, i weźmiesz nieprawość domu Judzkiego czterdzieści dni: dzień za rok, dzień mówię za rok dałem tobie.
###### **Ez 4,7**
 A do oblężenia Jeruzalem obrócisz twarz twoję, a ramię twoje będzie wyciągnione: i będziesz prorokował przeciw jemu.
###### **Ez 4,8**
 Otom cię obtoczył powrozami: i nie obrócisz się z boku twego na drugi bok, aż wypełnisz dni oblężenia twego.
###### **Ez 4,9**
 A ty nabierz sobie pszenice, i jęczmienia, i bobu, i soczewice, i jagieł, i wyki, i włożysz je w naczynie jedno, i naczynisz sobie chleba według liczby dni, przez które będziesz spał na boku twoim: przez trzysta i dziewięćdziesiąt dni będziesz ji jadł.
###### **Ez 4,10**
 A strawa twoja, którą jeść będziesz, będzie ważyć dwadzieścia syklów na dzień: od czasu aż do czasu jeść to będziesz.
###### **Ez 4,11**
 I wody w miarę napijać się będziesz, szóstą część Hinu: od czasu aż do czasu pić to będziesz,
###### **Ez 4,12**
 A jako podpłomyk jęczmienny jeść ji będziesz: a łajnem, które wychodzi z człowieka nakryjesz ji przed ich oczyma.
###### **Ez 4,13**
 I rzekł Pan: Tak będą jeść synowie Izraelowi chleb swój nieczysty między narody, do których je wyrzucę.
###### **Ez 4,14**
 I rzekłem: A, a, a, Panie Boże, oto dusza moja nie jest splugawioną, a ścierwu i utarganego od zwierzów nie jadłem z dzieciństwa mego aż dotąd, ani wchodziło do ust moich żadne mięso nieczyste.
###### **Ez 4,15**
 I rzekł do mnie: Otóż dałem ci gnój wołowy miasto gnoju człowieczego: że uczynisz chleb twój w nim.
###### **Ez 4,16**
 I rzekł do mnie: Synu człowieczy: Oto ja złamię laskę chleba w Jeruzalem: i będą jeść chleb pod wagą, i w frasunku: a wodę pod miara, i w ucisku pić będą:
###### **Ez 4,17**
 Żeby, gdy nie stanie chleba i wody, upadł każdy na brata swego: i popchnęli w nieprawościach swoich.
