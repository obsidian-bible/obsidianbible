# Ezd 4 BT5
###### **Ezd 4,1**
 Gdy wrogowie Judy i Beniamina usłyszeli, że wygnańcy budują świątynię dla Pana, Boga Izraela,
###### **Ezd 4,2**
 przystąpili do Zorobabela, < do Jozuego > oraz przedstawicieli rodów i rzekli do nich: «***Chcemy budować z wami, albowiem czcimy Boga waszego jak wy i Jemu składamy ofiary od czasów Asarhaddona, króla asyryjskiego, który nas tu sprowadził***».
###### **Ezd 4,3**
 Lecz Zorobabel, Jozue i pozostali naczelnicy rodów izraelskich im odpowiedzieli: «***Nie wolno wam razem z nami budować domu dla Boga naszego, ale my sami budować będziemy dla Pana, Boga Izraela, jak nam rozkazał Cyrus, król perski***».
###### **Ezd 4,4**
 I oto ludność miejscowa tłumiła zapał Judejczyków i odstraszała ich od budowy,
###### **Ezd 4,5**
 by zaś udaremnić ich zamiar, przekupywano przeciwko nim radców przez cały czas panowania Cyrusa, króla perskiego, aż do panowania Dariusza, króla perskiego.
###### **Ezd 4,6**
 Za panowania Kserksesa, na początku jego rządów, napisano oskarżenie przeciwko mieszkańcom Judy i Jerozolimy.
###### **Ezd 4,7**
 A za czasów Artakserksesa Biszelam, Mitredat, Tabeel i pozostali towarzysze jego wystosowali pismo do Artakserksesa, króla perskiego; litery tego dokumentu były napisane po aramejsku i ułożony był on po aramejsku.
###### **Ezd 4,8**
  Komendant Rechum i pisarz Szimszaj napisali do króla Artakserksesa przeciw Jerozolimie list tej treści:
###### **Ezd 4,9**
 «***Komendant Rechum, pisarz Szimszaj i pozostali ich towarzysze: sędziowie, posłowie, pisarze, Persowie, ludzie z Erek, z Babilonu, z Suzy – to jest Elamici –***
###### **Ezd 4,10**
 ***i reszta narodów, które uprowadził wielki i dostojny Asnappar i osiedlił je w miastach Samarii i w reszcie krain transeufratejskich, a teraz***».
###### **Ezd 4,11**
 Oto odpis listu, który oni posłali do niego: «***Do króla Artakserksesa – słudzy twoi, mężowie z Transeufratei. A teraz:***
###### **Ezd 4,12**
 ***Niech król przyjmie do wiadomości, że Żydzi, którzy od ciebie wyszli i przybyli do nas, do Jerozolimy, odbudowują to buntownicze i niegodziwe miasto, naprawili mury i fundamenty domów są położone.***
###### **Ezd 4,13**
 ***Otóż: Niech król przyjmie do wiadomości, że jeżeli to miasto będzie odbudowane, a mury jego naprawione, to oni podatku, daniny ani cła nie uiszczą i to w końcu królom przyniesie szkodę.***
###### **Ezd 4,14**
 ***Otóż: Ponieważ sól pałacu – to nasza sól i nie przystoi nam patrzeć na ograbianie króla, dlatego posyłamy królowi tę wiadomość.***
###### **Ezd 4,15**
 ***Niech poszukają w kronikach twoich przodków, a znajdziesz to i przekonasz się, że to miasto jest miastem buntowniczym, które przynosi królom i prowincjom szkodę, a rozruchy wznieca się w nim od dawien dawna, dlatego zburzone zostało to miasto.***
###### **Ezd 4,16**
 ***Powiadamiamy króla, że jeśli to miasto będzie odbudowane, a mury jego będą naprawione, wtedy w Transeufratei nic nie będzie twojego***».
###### **Ezd 4,17**
 Król przysłał takie rozstrzygnięcie: «***Komendantowi Rechumowi, pisarzowi Szimszajowi i pozostałym ich towarzyszom, którzy mieszkają w Samarii i w pozostałych krainach transeufratejskich, pozdrowienie***». A teraz:
###### **Ezd 4,18**
 «***Dokument, który nam przysłaliście, został przede mną w przekładzie odczytany.***
###### **Ezd 4,19**
 ***Przeze mnie został wydany rozkaz, by szukano. I znaleziono, że to miasto od dawien dawna powstaje przeciwko królom oraz że wzniecane są w nim bunt i rozruchy.***
###### **Ezd 4,20**
 ***A królowie potężni panowali nad Jerozolimą i rządzili całą Transeufrateą, i odstawiano im podatek, daninę i cło.***
###### **Ezd 4,21**
 ***Zatem wydajcie zarządzenie, by powstrzymać tych ludzi: to miasto nie ma być odbudowane, dopóki taki rozkaz nie będzie wydany przeze mnie.***
###### **Ezd 4,22**
 ***A strzeżcie się, by nie dopuścić się w tym zaniedbania, żeby nie wzrosła strata na szkodę królów***».
###### **Ezd 4,23**
 Wtedy, skoro odpis dokumentu króla Artakserksesa został przeczytany przed komendantem Rechumem, pisarzem Szimszajem i ich towarzyszami, poszli oni pośpiesznie do Żydów w Jerozolimie, by pod groźbą użycia siły zakazać im dalszej pracy.
###### **Ezd 4,24**
 Już kiedyś stanęła praca nad domem Bożym w Jerozolimie i przerwano ją aż do drugiego roku panowania Dariusza, króla perskiego.
# Ezd 4 PAU
###### **Ezd 4,1**
 Gdy nieprzyjaciele Judy i Beniamina usłyszeli, że repatrianci budują świątynię dla PANA Boga Izraela,
###### **Ezd 4,2**
 przybyli do Zorobabela i do przywódców rodów z następującą propozycją: „Pragniemy budować z wami i tak jak wy czcić waszego Boga. I my bowiem składamy Mu ofiary od czasu, gdy nas tu przesiedlił Asarhaddon, król Asyrii”.
###### **Ezd 4,3**
 Lecz Zorobabel, Jozue i pozostali przywódcy rodów izraelskich odpowiedzieli: „Nie możecie budować wspólnie z nami domu dla Boga naszego, gdyż król perski Cyrus nakazał, żebyśmy sami budowali dla PANA Boga Izraela”.
###### **Ezd 4,4**
 Wówczas miejscowa ludność zaczęła zniechęcać Judejczyków i przeszkadzać im w budowie.
###### **Ezd 4,5**
 Przekupywali królewskich doradców, aby udaremnić ich zamiar. Tak było przez cały czas panowania Cyrusa, króla perskiego, aż do objęcia władzy przez Dariusza, jego następcę.
###### **Ezd 4,6**
 Gdy zaś królem został Kserkses, zaraz na początku jego rządów napisali skargę na mieszkańców Judei i Jerozolimy.
###### **Ezd 4,7**
 Następnie za czasów Artakserksesa, Biszelam, Mitredat i Tabeel wraz z pozostałymi sprzymierzeńcami wysłali skargę do króla perskiego przetłumaczoną i napisaną po aramejsku.
###### **Ezd 4,8**
 Namiestnik Rechum i pisarz Szymszaj napisali do króla Artakserksesa przeciwko Jerozolimie list następującej treści:
###### **Ezd 4,9**
 „Namiestnik Rechum, pisarz Szimszaj i pozostali urzędnicy, sędziowie, zarządcy, pisarze, mieszkańcy z Erek, z Babilonu i z Suzy, to jest Elamici,
###### **Ezd 4,10**
 oraz pozostałe grupy narodowościowe, które wielki i dostojny Asnappar przesiedlił do miast Samarii i na tereny Transeufratei”. Oto
###### **Ezd 4,11**
 odpis listu, który oni wysłali do niego: „Do króla Artakserksesa twoi słudzy, mieszkańcy prowincji Transeufratei. A zatem:
###### **Ezd 4,12**
 Niech królowi będzie wiadomo, że Judejczycy, którzy wyruszyli od ciebie i przybyli do nas, do Jerozolimy, odbudowują to niegodziwe i buntownicze miasto. Rozpoczęli już naprawę murów i położyli fundamenty pod budowle.
###### **Ezd 4,13**
 Zatem: Niech król przyjmie do wiadomości, że jeżeli to miasto zostanie odbudowane i mury jego naprawione, to nie będą oni płacić ani podatku, ani daniny, ani cła, co w końcu będzie ze szkodą dla władców.
###### **Ezd 4,14**
 I dalej: Ponieważ dwór królewski jest naszym dobroczyńcą, nie możemy być obojętni na ograbianie króla. Wysyłamy zatem królowi tę wiadomość.
###### **Ezd 4,15**
 Niech przeszukają kroniki twoich poprzedników, a znajdziesz w nich potwierdzenie, że to miasto jest miastem buntowniczym, które przynosiło szkody królom i prowincjom i które od niepamiętnych czasów się buntowało. Z tej właśnie przyczyny to miasto zostało zburzone!
###### **Ezd 4,16**
 Podajemy więc królowi do wiadomości, że jeśli to miasto zostanie odbudowane i jego mury będą naprawione, z prowincji Transeufratei nie będziesz czerpał dochodów!”.
###### **Ezd 4,17**
 Król przysłał taką odpowiedź: „Namiestnikowi Rechumowi, pisarzowi Szimszajowi, pozostałym urzędnikom mieszkającym w Samarii oraz wszystkim w prowincjach Transeufratei, po zdrowie nie! A zatem:
###### **Ezd 4,18**
 List, który mi przysłaliście, został w mojej obecności w całości odczytany.
###### **Ezd 4,19**
 Wydałem więc rozkaz, aby szukano w kronikach. Znaleziono rzeczywiście, że to miasto buntowało się od zamierzchłych czasów przeciwko królom i powstawały w nim rozruchy i bunty.
###### **Ezd 4,20**
 Potężni władcy panowali nad Jerozolimą i rozciągali swą władzę na wszystkie tereny Transeufratei, z których płacono im daniny, podatki i cła.
###### **Ezd 4,21**
 Wydaję więc zarządzenie, by powstrzymać tych ludzi: nie wolno im odbudowywać miasta, dopóki nie otrzymają na to zezwolenia ode mnie!
###### **Ezd 4,22**
 Czuwajcie, aby nie dopuścić się zaniedbania i nie spowodować większej straty na niekorzyść królów”.
###### **Ezd 4,23**
 Skoro tylko odpis listu króla Artakserksesa został odczytany w obecności Rechuma, pisarza Szimszaja i urzędników, udali się oni pospiesznie do Żydów w Jerozolimie i pod groźbą użycia przemocy wstrzymali budowę.
###### **Ezd 4,24**
 W podobny sposób już kiedyś została wstrzymana praca przy budowie domu Bożego w Jerozolimie i przerwa trwała aż do drugiego roku panowania Dariusza, króla perskiego.
# Ezd 4 BP
###### **Ezd 4,1**
 Kiedy wrogowie Judy i Beniamina usłyszeli, że przybysze z wygnania budują Świątynię dla Jahwe, Boga Izraela,
###### **Ezd 4,2**
 zwrócili się do Zorobabela i przywódców rodów i oświadczyli im: Będziemy budować wspólnie z wami, ponieważ podobnie jak wy szukamy Boga waszego i składamy Mu ofiary od dni Assarhaddona, króla asyryjskiego, który nas tu osiedlił.
###### **Ezd 4,3**
 Ale Zorobabel, Jozue i reszta przywódców rodów izraelskich odpowiedzieli im: Nie godzi się, abyśmy wspólnie z wami budowali Świątynię dla naszego Boga. My sami wzniesiemy Świątynię dla Jahwe, Boga Izraela, jak to nam polecił Cyrus, król Persji.
###### **Ezd 4,4**
 Dlatego lud tego kraju począł zniechęcać Judejczyków, utrudniając im budowę.
###### **Ezd 4,5**
 Przekupywano przeciwko nim doradców [królewskich], aby przeszkodzić ich przedsięwzięciu. Ten stan trwał przez całe panowanie Cyrusa, króla Persji, aż do panowania Dariusza, króla Persji.
###### **Ezd 4,6**
 Za panowania Kserksesa, a mianowicie na początku jego panowania, napisali oni skargę przeciwko mieszkańcom Judy i Jeruzalem.
###### **Ezd 4,7**
 Za dni Artakserksesa Biszlam, Mitredat, Tabeel i reszta jego towarzyszy wysłali pismo do Artakserksesa, króla Persji. List był pisany literami aramejskimi i w języku aramejskim.
###### **Ezd 4,8**
 Zarządca Rechum i pisarz Szimszaj skierowali do króla Artakserksesa list przeciwko Jeruzalem następującej treści: "
###### **Ezd 4,9**
 Zarządca Rechum, pisarz Szimszaj i wszyscy ich towarzysze, sędziowie, niżsi urzędnicy, dozorcy i zarządcy, [ludzie] z Erek, Babel, Suza, to jest Elamici,
###### **Ezd 4,10**
 i reszta ludów, które wielki i sławny Asnappar przeprowadził i osiedlił w miastach Samarii i w pozostałych krajach za Eufratem". A oto
###### **Ezd 4,11**
 odpis listu, który do niego wysłali: "Do króla Artakserksesa, twoi słudzy, mieszkańcy kraju za Eufratem! A teraz:
###### **Ezd 4,12**
 Król winien się dowiedzieć, że Judejczycy, którzy wyszli spod twojej bezpośredniej władzy i przybyli do nas, do Jeruzalem, odbudowują to buntownicze i przewrotne miasto, naprawiają jego mury i kładą już pod nie fundamenty.
###### **Ezd 4,13**
 Królowi podaje się zatem do wiadomości, że jeżeli to miasto zostanie odbudowane, a jego mury wzniesione, nie zechcą oni już uiszczać danin, podatków i cła i w końcu wyniknie stąd szkoda dla króla.
###### **Ezd 4,14**
 Ponieważ pożywamy sól z pałacu, nie przystoi nam patrzeć na zniewagę wyrządzaną królowi, zawiadamiamy go więc o tym.
###### **Ezd 4,15**
 Niech kto zbada Kroniki ojców twoich. Znajdziesz w nich i stwierdzisz, że miasto to jest miastem buntowniczym, które królom i prowincjom przyniosło szkodę, i że od dawien dawna wzniecano w nim bunty. Z tego też powodu zostało ono zburzone.
###### **Ezd 4,16**
 Dlatego donosimy królowi: Jeśli miasto to zostanie odbudowane i mury jego wzniesione, nie będziesz już miał żadnego wpływu w kraju za Eufratem".
###### **Ezd 4,17**
 Król wysłał [następującą] odpowiedź: "Zarządcy Rechumowi, pisarzowi Szimszajowi i wszystkim towarzyszom, którzy mieszkają w Samarii i w pozostałych [krajach] za Eufratem, pozdrowienie! A teraz:
###### **Ezd 4,18**
 List, który skierowaliście do nas, został mi najdokładniej odczytany.
###### **Ezd 4,19**
 Na mój rozkaz poczyniono poszukiwania i stwierdzono, że miasto to od dawien dawna powstawało przeciwko królom i że zdarzały się w nim powstania i bunty.
###### **Ezd 4,20**
 Potężni królowie panowali [niegdyś] nad Jeruzalem i byli władcami nad wszystkimi krajami za Eufratem. Płacono im daniny, podatki i cło.
###### **Ezd 4,21**
 Wobec tego wydajcie rozkaz, aby powstrzymano tych mężów od robót: miasto nie będzie odbudowane, dopóki ja nie wydam innego rozporządzenia.
###### **Ezd 4,22**
 Pilnujcież, abyście w tej sprawie nie okazali żadnego zaniedbania, ażeby królom nie przysporzono jeszcze większych szkód".
###### **Ezd 4,23**
 Natychmiast, skoro tylko odpis listu króla Artakserksesa został odczytany Rechumowi i pisarzowi Szimszajowi oraz ich towarzyszom, udali się oni spiesznie do Judejczyków do Jeruzalem i siłą i gwałtem przymusili do przerwania prac.
###### **Ezd 4,24**
 Tak więc prace przy Świątyni Boga w Jeruzalem zostały wstrzymane i nie prowadzono ich aż do drugiego roku panowania Dariusza, króla Persji.
# Ezd 4 BR
###### **Ezd 4,1**
 Kiedy nieprzyjaciele Judy i Beniamina dowiedzieli się, że byli wygnańcy budują już świątynię dla Jahwe, Boga Izraela,
###### **Ezd 4,2**
 przyszli do Zorobabela oraz do przywódców poszczególnych rodów i powiedzieli im tak: Pozwólcie nam budować razem z wami. My przecież tak jak wy czcimy waszego Boga i na Jego cześć składamy ofiary od czasów Asarhaddona, króla asyryjskiego, który nas tu sprowadził.
###### **Ezd 4,3**
 Lecz Zorobabel, Jozue i przywódcy rodów izraelskich odpowiedzieli im: Nie godzi się, żebyśmy razem budowali świątynię dla naszego Boga. Będziemy ją budowali sami dla Jahwe, Boga Izraela, tak jak nam to nakazał król perski, Cyrus.
###### **Ezd 4,4**
 Wtedy owi tubylcy zaczęli odradzać mieszkańcom Judy budowę i odbierali im chęć do pracy.
###### **Ezd 4,5**
 Przekupywali pieniędzmi specjalnych doradców, którzy mieli ich odciągać od pracy. Czynili tak przez cały czas panowania króla perskiego, Cyrusa, aż na tron wstąpił Dariusz, kolejny król Persów.
###### **Ezd 4,6**
 Za czasów panowania króla Kserksesa, zaraz na początku jego rządów, wpłynął do niego list z różnymi skargami na mieszkańców Judy i Jerozolimy.
###### **Ezd 4,7**
 Za panowania Artakserksesa, króla Persów, list do niego napisali Biszelam, Mitredat, Tabeel i pozostali ich towarzysze. List był napisany w języku aramajskim i pismem aramajskim.
###### **Ezd 4,8**
 Zarządca zaś Rechum i pisarz Szimszaj napisali do Artakserksesa taki list w sprawie Jerozolimy:
###### **Ezd 4,9**
 Zarządca Rechum i pisarz Szimszaj oraz pozostali ich współpracownicy spośród sędziów, posłów, pisarzy oraz innych urzędników, ludzie z Erek, z Babilonu i z Suzy, czyli Elamici,
###### **Ezd 4,10**
 tudzież pozostałe ludy, które dostojny Asnappar sprowadził i osiedlił w miastach Samarii i w innych okolicach po drugiej stronie Rzeki.
###### **Ezd 4,11**
 A oto odpis listu, który wysłali: Do króla Artakserksesa - jego słudzy, mieszkający po drugiej stronie Rzeki.
###### **Ezd 4,12**
 Niech ci będzie wiadomo, o królu, że Żydzi, których wysłałeś od siebie do nas, przybyli do Jerozolimy. Już odbudowują to miasto zbuntowane i przewrotne, wznoszą dokoła mury [obronne] i umacniają fundamenty.
###### **Ezd 4,13**
 Musisz przeto liczyć się z tym, o królu, że jeśli to miasto zostanie odbudowane, jeśli znów staną wokół niego mury, przestaną oni uiszczać wszelkie podatki i daniny i nie będą płacić cła. Wszystko to przyniesie wielkie straty królom.
###### **Ezd 4,14**
 Otóż, ponieważ sól pałacu królewskiego to także nasza sól i ponieważ nie możemy dopuścić do tego, żeby lekceważono naszego króla, pozwalamy sobie powiadomić o tym wszystkim króla.
###### **Ezd 4,15**
 Wydaj polecenie, żeby zbadano kroniki twoich przodków, a przekonasz się, że to miasto zawsze się buntowało, przyprawiając o wielkie straty królów i całe prowincje. Buntowało się od najdawniejszych czasów i dlatego zostało w końcu zburzone.
###### **Ezd 4,16**
 Chcemy cię więc ostrzec, o królu, że jeśli to miasto zostanie odbudowane, jeśli wokół niego na nowo zostaną wzniesione mury, to tym samym nic już nie będziesz posiadał po drugiej stronie Rzeki.
###### **Ezd 4,17**
 Zarządcy Rechumowi, pisarzowi Szimszajowi i wszystkim ich współpracownikom, pozostającym w Samarii oraz w innych okolicach po drugiej stronie Rzeki, król przysłał taką oto odpowiedź:
###### **Ezd 4,18**
 Pozdrowienia. List, któryście wysłali, został mi odczytany bardzo dokładnie.
###### **Ezd 4,19**
 Wydałem odpowiednie zarządzenie i już przebadano kroniki, z których wynika, że od czasów najdawniejszych miasto to buntowało się przeciwko swoim królom, wdając się w różne spiski i wszczynając rozruchy.
###### **Ezd 4,20**
 Rządzili kiedyś w Jerozolimie potężni królowie, obejmujący swoją władzą całą krainę poza Rzeką. Do nich wpływały stamtąd podatki, daniny i cło.
###### **Ezd 4,21**
 Dlatego wydajcie zarządzenie, żeby ci ludzie przerwali prace przy budowie. Miasto nie może być odbudowywane, dopóki nie wydam na to mojego zezwolenia.
###### **Ezd 4,22**
 Z całą dokładnością wypełnijcie moje polecenie, żeby nie doszło do większego zła i strat dla królewskiego skarbca.
###### **Ezd 4,23**
 Gdy tylko odpis listu króla Artakserksesa został odczytany w obecności Rechuma, pisarza Szimszaja oraz ich współpracowników, udali się oni z pośpiechem do Jerozolimy i pracujących tam Żydów siłą zmusili do przerwania budowy.
###### **Ezd 4,24**
 I tak zostało zatrzymane dzieło budowy domu Bożego w Jerozolimie. Przerwa w pracy trwała aż do drugiego roku panowania Dariusza, króla Persów.
# Ezd 4 WUJ
###### **Ezd 4,1**
 I usłyszeli nieprzyjaciele Judy i Benjamin, iż synowie pojmania budowali kościół Panu Bogu Izraelowemu:
###### **Ezd 4,2**
 I przystąpiwszy do Zorobabela i do przedniejszych ojców, rzekli im: Niech budujemy z wami, bo tak jako i wy szukamy Boga waszego: otośmy ofiarowali ofiary, odedni Asor Haddan króla Assur, który nas tu zaprowadził.
###### **Ezd 4,3**
 I rzekł im Zorobabel i Josue, i inszy przedniejszy ojcowie Izraelscy: Nie możecie wy z nami budować domu Bogu naszemu, ale my tylko sami zbudujemy Panu Bogu naszemu, jako nam rozkazał Cyrus król Perski,
###### **Ezd 4,4**
 Stało się tedy, że lud ziemie przeszkadzał rękam ludu Judzkiego, i przekażał im w budowaniu.
###### **Ezd 4,5**
 I najęli przeciwko nim rajcę, aby rozproszyli radę ich po wszystkie dni Cyrusa króla Perskiego, i aż do królestwa Daryusza króla Perskiego.
###### **Ezd 4,6**
 A za królestwa Assuera, na początku królestwa jego, napisali skargę na obywatele Judzkie i Jerozolimskie.
###### **Ezd 4,7**
 I za dni Artaxerxa pisał Beselam Mithridat, i Tabeel, i inni, którzy w radzie ich byli, do Artaxerxa króla Perskiego, a list skargi napisany był po Syryjsku, i czytano ji językiem Syryjskim.
###### **Ezd 4,8**
 Reum Beelteem, i Samsaj pisarz napisali list jeden o Jeruzalem, do Artaxerxa króla takowy.
###### **Ezd 4,9**
 Reum Beelteem, i Samsaj pisarz, i inne rady ich, Dynejczycy, Apharsathachowie, Terphalczycy, Apharsejczycy, Erchuejczycy, Babilończycy, Susanechowie, Diewiowie i Elamitowie,
###### **Ezd 4,10**
 I inni z narodów, które przeniósł Asenaphar wielki i sławny, i kazał im mieszkać w mieściech Samaryjskich, i w innych zarzecznych krainach w pokoju:
###### **Ezd 4,11**
 (Ten jest wypis listu, który posłali do niego) Artaxerxowi królowi, słudzy twoi, mężowie, którzy za rzeką, zdrowia życzą.
###### **Ezd 4,12**
 Niech będzie wiadomo królowi, iż Żydowie, którzy wyszli od ciebie do nas, przyszli do Jeruzalem miasta odpornego, i złego, które budują wywodząc mury jego i ściany oprawując.
###### **Ezd 4,13**
 Teraz tedy niech będzie wiadomo królowi, iż jeśli ono miasto będzie zbudowane, a mury jego naprawione będą: podatku, i cła, i dochodów rocznych nie dadzą, i aż do królów ta szkoda przydzie.
###### **Ezd 4,14**
 A my pamiętając na sól, którąśmy na pałacu królewskim jadali, a iż patrząc na królewskie urazy, za rzecz niesłuszną mamy, przetośmy posłali i oznajmili królowi,
###### **Ezd 4,15**
 Abyś poszukał w księgach historyj ojców twoich, a najdziesz napisano w kronikach, i dowiesz się, iż ono miasto, miasto odporne jest, a królom i ziemiam szkodliwe, i wojny powstają w niem od dawnych dni: przeco i miasto same zburzone jest:
###### **Ezd 4,16**
 Opowiadamy my królowi, iż jeśli ono miasto będzie zbudowane, a mury jego będą naprawione, dzierżawy za rzeką mieć nie będziesz.
###### **Ezd 4,17**
 Słowo posłał król do Reum Beelteem, i Samsaj pisarza, i do innych, którzy w radzie ich byli obywatelów Samariej, i innym za rzeką, życząc zdrowia i pokoju.
###### **Ezd 4,18**
 Skarga, którąście posłali do nas, jawnie jest czytana przedemną.
###### **Ezd 4,19**
 I rozkazałem i szukano, i naleziono, że to miasto zdawna królom się przeciwia, i rozruchy i walki w niem powstawają.
###### **Ezd 4,20**
 Bo i królowie mocni byli w Jeruzalem, którzy i panowali nad wszelką krainą, która jest za rzeką: dań też, cła i dochody bierali.
###### **Ezd 4,21**
 Przetoż teraz słuchajcie wyroku: Brońcie tamtym mężom, aby tamto miasto nie było budowane, aż jeśliby podobno odemnie rozkazano było.
###### **Ezd 4,22**
 Patrzcie, abyście tego niedbale nie czynili, i złe przeciw królom polekku nie rosło.
###### **Ezd 4,23**
 A tak kopia wyroku Artaxerxa króla czytana jest przed Reumem Beelteem, i Samsaj pisarzem i radą ich: i jachali wskok do Jeruzalem do Żydów, i zabronili im ramieniem i mocą.
###### **Ezd 4,24**
 Zaniechana jest tedy robota domu Pańskiego w Jeruzalem, i nie budowano aż do roku wtórego królestwa Daryusza króla Perskiego.
