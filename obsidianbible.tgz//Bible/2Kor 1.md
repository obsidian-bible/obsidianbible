# 2Kor 1 BT5
###### **2Kor 1,1**
 Paweł, z woli Bożej apostoł Chrystusa Jezusa, i Tymoteusz, brat, do Kościoła Bożego, który jest w Koryncie, ze wszystkimi świętymi, jacy są w całej Achai.
###### **2Kor 1,2**
 Łaska wam i pokój od Boga, Ojca naszego, i Pana Jezusa Chrystusa!
###### **2Kor 1,3**
 Błogosławiony Bóg i Ojciec Pana naszego, Jezusa Chrystusa, Ojciec miłosierdzia i Bóg wszelkiej pociechy,
###### **2Kor 1,4**
 Ten, który nas pociesza w każdym naszym ucisku, byśmy sami mogli pocieszać tych, co są w jakimkolwiek ucisku, tą pociechą, której doznajemy od Boga.
###### **2Kor 1,5**
 Jak bowiem obfitują w nas cierpienia Chrystusa, tak też wielkiej doznajemy przez Chrystusa pociechy.
###### **2Kor 1,6**
 Ale gdy znosimy udręki – to dla pociechy i zbawienia waszego; a gdy pocieszani jesteśmy – to dla waszej pociechy, sprawiającej, że z wytrwałością znosicie te same cierpienia, których i my doznajemy.
###### **2Kor 1,7**
 A nadzieja nasza co do was jest silna, bo wiemy, że jak cierpień jesteście współuczestnikami, tak i pociechy.
###### **2Kor 1,8**
 Nie chciałbym bowiem, bracia, byście nie wiedzieli o ucisku doznanym przez nas w Azji; jak do ostateczności i ponad siły byliśmy doświadczani, tak iż zwątpiliśmy, czy uda się nam ujść z życiem.
###### **2Kor 1,9**
 Lecz właśnie w samych sobie znaleźliśmy wyrok śmierci: aby nie ufać sobie samemu, lecz Bogu, który wskrzesza umarłych.
###### **2Kor 1,10**
 On to ocalił nas tylekroć od śmierci i [nadal] będzie ocalał. Tak, mamy nadzieję, że nadal będzie nas ratował
###### **2Kor 1,11**
 przy współudziale waszych za nas modlitw, aby w ten sposób wielu dzięki składało za dar dla wielu w nas złożony.
###### **2Kor 1,12**
 Chlubą bowiem jest dla nas świadectwo naszego sumienia, bo w prostocie serca i szczerości wobec Boga, a nie według mądrości doczesnej, lecz według łaski Bożej postępowaliśmy na tym świecie, szczególnie względem was.
###### **2Kor 1,13**
 Nie piszemy wam bowiem czegoś innego niż to, co czytaliście i co zrozumieliście. Mam nadzieję, że i do końca będziecie nas rozumieć tak,
###### **2Kor 1,14**
 jak już po części zostaliśmy przez was zrozumiani: mianowicie, że w dzień Pana naszego Jezusa ja będę waszą chlubą, tak jak i wy moją.
###### **2Kor 1,15**
 W tym przeświadczeniu postanowiłem już wcześniej do was przybyć – byście dostąpili powtórnej łaski –
###### **2Kor 1,16**
 następnie udać się od was do Macedonii i z Macedonii znów przyjść do was po to, byście mnie wyprawili w podróż do Judei.
###### **2Kor 1,17**
 Czyż więc poczynałem sobie lekkomyślnie, wszystko to zamierzając? Albo układając to, czy postanawiałem według ciała w ten sposób, iżby "tak, tak" było u mnie [równocześnie] "nie, nie"?
###### **2Kor 1,18**
 Bóg mi świadkiem, że w tym, co do was mówię, nie ma równocześnie "tak" i "nie".
###### **2Kor 1,19**
 Syn Boży, Chrystus Jezus, Ten, którego głosiłem wam ja i Sylwan, i Tymoteusz, nie był "tak" i "nie", lecz dokonało się w Nim "tak".
###### **2Kor 1,20**
 Albowiem ile tylko obietnic Bożych, wszystkie w Nim są "tak". Dlatego też przez Niego wypowiada się nasze "Amen" Bogu na chwałę.
###### **2Kor 1,21**
 Tym zaś, który umacnia nas wespół z wami w Chrystusie i który nas namaścił, jest Bóg.
###### **2Kor 1,22**
 On też wycisnął na nas pieczęć i zostawił zadatek Ducha w sercach naszych.
###### **2Kor 1,23**
 A ja wzywam Boga na świadka mojej duszy, iż tylko dlatego, aby was oszczędzić, nie przybyłem do Koryntu.
###### **2Kor 1,24**
 Nie żeby okazać nasze władztwo nad wiarą waszą, bo przecież jesteśmy współtwórcami radości waszej; wiarą bowiem stoicie.
# 2Kor 1 PAU
###### **2Kor 1,1**
 Paweł, z woli Boga apostoł Chrystusa Jezusa, i brat Tymoteusz do Kościoła Bożego w Koryncie, z wszystkimi świętymi, którzy są w całej Achai:
###### **2Kor 1,2**
 łaska wam i pokój od Boga, naszego Ojca, i od Pana Jezusa Chrystusa.
###### **2Kor 1,3**
 Niech będzie błogosławiony Bóg, Ojciec naszego Pana Jezusa Chrystusa, Ojciec miłosierdzia i Bóg wszelkiego pocieszenia.
###### **2Kor 1,4**
 On pociesza nas we wszystkich naszych utrapieniach, abyśmy potrafili pocieszać tych, którzy znajdują się w jakimkolwiek utrapieniu, pocieszeniem, którym sami jesteśmy pocieszani przez Boga.
###### **2Kor 1,5**
 Bo jak obfitują w nas cierpienia Chrystusa, tak dzięki Chrystusowi również nasze pocieszenie jest obfite.
###### **2Kor 1,6**
 Gdy jesteśmy dręczeni - to dla waszego pocieszenia i zbawienia. Gdy jesteśmy pocieszani - to także dla waszego pocieszenia, abyście mogli wytrwale znosić te same cierpienia, których i my doświadczamy.
###### **2Kor 1,7**
 Nasza nadzieja co do was jest mocna, bo wiemy, że jesteście uczestnikami cierpień, ale też i pocieszenia.
###### **2Kor 1,8**
 Bracia! Chcemy, abyście wiedzieli o utrapieniu, które dotknęło nas w Azji. Zostaliśmy doświadczeni ponad miarę i ponad siły, tak że wątpiliśmy, czy uda nam się ujść z życiem.
###### **2Kor 1,9**
 Po to jednak odczuliśmy grozę śmierci, aby nie polegać na sobie, lecz na Bogu, który wskrzesza umarłych.
###### **2Kor 1,10**
 On nas wybawił od grozy śmierci i będzie wybawiał. Pokładamy nadzieję w Nim, że nadal będzie wybawiał,
###### **2Kor 1,11**
 aby wielu ludzi mogło dziękować za nas, za charyzmat, który został nam dany. Przyczyniacie się do tego także wy, kiedy modlicie się za nas.
###### **2Kor 1,12**
 Nasze sumienie daje nam chlubne świadectwo, że na tym świecie, a szczególnie względem was, postępowaliśmy w prostocie i szczerości, które są od Boga, i nie kierowaliśmy się mądrością świata, lecz łaską Bożą.
###### **2Kor 1,13**
 Nie piszemy wam bowiem niczego innego poza tym, co czytacie i co przyjmujecie. Mam też nadzieję, że w pełni zrozumiecie to,
###### **2Kor 1,14**
 co już częściowo zrozumieliście, a mianowicie, że w Dniu Pana naszego Jezusa będziemy waszą chlubą, podobnie jak wy naszą.
###### **2Kor 1,15**
 Z takim nastawieniem już wcześniej zamierzałem przybyć do was, aby dwa razy wyświadczyć wam zaszczyt:
###### **2Kor 1,16**
 raz odwiedzając was w drodze do Macedonii i drugi raz wracając z Macedonii do was, aby następnie wyruszyć do Judei.
###### **2Kor 1,17**
 Czy postępowałem lekkomyślnie, kiedy powziąłem takie postanowienie? Czy to, co postanowiłem, było pragnieniem tylko ludzkim, a we mnie było jednocześnie „tak” i „nie”?
###### **2Kor 1,18**
 Bóg mi świadkiem, że nasze słowa do was nie znaczą „tak” i „nie”.
###### **2Kor 1,19**
 Syn Boży, Jezus Chrystus, którego głosiliśmy wam ja, Sylwan i Tymoteusz, nie był „tak” i „nie”. W Nim było tylko „tak”.
###### **2Kor 1,20**
 Wszystkie obietnice Boga w Nim stały się „tak”. Dlatego przez Niego wypowiadamy na chwałę Boga nasze „Amen”.
###### **2Kor 1,21**
 Bóg umacnia nas razem z wami dla Chrystusa, który nas namaścił.
###### **2Kor 1,22**
 On nas opieczętował i dał naszym sercom Ducha jako poręczyciela.
###### **2Kor 1,23**
 Wzywam Boga na świadka mojego życia, że tylko dlatego nie przybyłem do Koryntu, aby wam oszczędzić przykrości.
###### **2Kor 1,24**
 Nie jesteśmy panami waszej wiary, lecz współtwórcami waszej radości. Wy zaś zachowujecie stałość dzięki wierze!
# 2Kor 1 BP
###### **2Kor 1,1**
 Paweł, z woli Bożej apostoł Jezusa Chrystusa, i brat Tymoteusz do zgromadzenia ludu Bożego w Koryncie oraz do wszystkich świętych w całej Achai.
###### **2Kor 1,2**
 Łaska wam i pokój od Boga, Ojca naszego, i Pana Jezusa Chrystusa.
###### **2Kor 1,3**
 Niech będzie błogosławiony Bóg i Ojciec Pana naszego Jezusa Chrystusa. Ojciec miłosierdzia i Bóg wszelkiej pociechy.
###### **2Kor 1,4**
 Ten, który nas pociesza w każdym utrapieniu naszym, abyśmy wzmocnieni pociechą doznaną od Boga, mogli pocieszać tych, którzy znaleźli się w jakimkolwiek utrapieniu.
###### **2Kor 1,5**
 Podobnie jak przeogromny jest nasz udział w męce Chrystusa, tak samo przeogromna jest nasza pociecha dzięki Chrystusowi.
###### **2Kor 1,6**
 I utrapienia znosimy za waszą pociechę i zbawienie, i pociech doznajemy za waszą pociechę. A sprawia ona, że w cierpliwości znosicie męki, których i my doznajemy.
###### **2Kor 1,7**
 A nasza nadzieja co do was jest utwierdzona. I wiemy, że jak udziałem waszym jest męka, tak samo będzie pociecha.
###### **2Kor 1,8**
 Otóż nie chciałbym, bracia, abyście nie wiedzieli o naszym utrapieniu, jakiego doznaliśmy w Azji. Byliśmy przygnębieni ponad wszelką miarę i ponad siły, tak że zwątpiliśmy już w ocalenie życia.
###### **2Kor 1,9**
 Wprost przeciwnie, osobiście byliśmy przekonani nawet o wyroku śmierci. Nie należy bowiem polegać na sobie samym, lecz na Bogu, który wskrzesza umarłych.
###### **2Kor 1,10**
 On wybawił nas z tak wielkich niebezpieczeństw śmierci i znowu wybawi. Mocno ufamy Jemu, że jeszcze wybawi,
###### **2Kor 1,11**
 przy współudziale waszej usilnej modlitwy za nas. W ten sposób z wielu ust popłynie dziękczynienie za nas, za dar udzielony nam dzięki modlitwom wielu.
###### **2Kor 1,12**
 Naszą chlubą jest świadectwo naszego sumienia o tym, że kierowaliśmy się w świecie, a tym bardziej wobec was prostotą i szczerością otrzymaną od Boga. Nie kierowaliśmy się mądrością naturalną, lecz łaską Bożą.
###### **2Kor 1,13**
 Nie piszemy wam o niczym innym, jak tylko o tym, co czytacie i co rozumiecie, a mam nadzieję, że do końca życia będziecie to rozumieć.
###### **2Kor 1,14**
 Zresztą częściowo już nas zrozumieliście, a mianowicie to, że w dniu przyjścia Pana Jezusa będziemy się chlubić wami, a wy nami.
###### **2Kor 1,15**
 Z tą ufnością postanowiłem już wcześniej do was przybyć, abyście po raz drugi dostąpili łaski.
###### **2Kor 1,16**
 Od was zamierzałem wyruszyć do Macedonii i z Macedonii znowu przybyć do was, abyście wyprawili mnie do Judei.
###### **2Kor 1,17**
 Czy mając taki zamiar postąpiłem lekkomyślnie? Albo czy powziąwszy takie postanowienie kierowałem się czysto ludzkimi względami? Czy u mnie "tak, tak" znaczy równocześnie "nie, nie"?
###### **2Kor 1,18**
 Przysięgam na wierność Boga, że słowo, które do was kieruję, nie zawiera jednocześnie "tak" i "nie".
###### **2Kor 1,19**
 Syn Boży, Jezus Chrystus, którego głosiliśmy wam - to znaczy ja, Sylwan i Tymoteusz - nie był równocześnie "tak" i "nie". W Nim było tylko "tak",
###### **2Kor 1,20**
 ponieważ ile tylko było obietnic Bożych, wszystkie w Nim się wypełniły. Dlatego przez Niego wypowiadamy "Amen" na chwałę Bogu.
###### **2Kor 1,21**
 Bóg zaś jest tym, który nas i was utwierdził w Chrystusie, namaścił nas
###### **2Kor 1,22**
 oraz opieczętował i dał naszym sercom Ducha jako zadatek.
###### **2Kor 1,23**
 Wzywam Boga na świadka i zaklinam się przed Nim na moje życie, że tylko dlatego nie przybyłem jeszcze do Koryntu, aby was oszczędzić.
###### **2Kor 1,24**
 Nie jesteśmy panami waszej wiary, lecz współtwórcami waszej radości, bo przy wierze mocno stoicie.
# 2Kor 1 BR
###### **2Kor 1,1**
 Paweł, z woli Bożej apostoł Chrystusa Jezusa, i Tymoteusz, brat, do Kościoła Bożego, który jest w Koryncie, ze wszystkimi świętymi, jacy są w całej Achai.
###### **2Kor 1,2**
 Łaska wam i pokój od Boga, Ojca naszego, i Pana Jezusa Chrystusa.
###### **2Kor 1,3**
 Błogosławiony Bóg i Ojciec Pana naszego Jezusa Chrystusa, Ojciec miłosierdzia i Bóg wszelkiej pociechy,
###### **2Kor 1,4**
 Ten, który nas pociesza w każdym naszym utrapieniu, byśmy sami pocieszać mogli tych, co są w jakiejkolwiek udręce, pociechą, której doznajemy od Boga.
###### **2Kor 1,5**
 Jak bowiem obfitują w nas cierpienia Chrystusa, tak też wielkiej doznajemy przez Chrystusa pociechy.
###### **2Kor 1,6**
 Ale gdy znosimy udręki - to dla pociechy i zbawienia waszego; a gdy pocieszani jesteśmy - to dla waszej pociechy, sprawiającej, że z wytrwałością znosicie te same cierpienia, których i my doznajemy.
###### **2Kor 1,7**
 A nadzieja nasza co do was jest silna, bo wiemy, że jak cierpień jesteście współuczestnikami, tak też i naszej pociechy.
###### **2Kor 1,8**
 Nie chciałbym bowiem, bracia, byście nie wiedzieli o udręce doznanej przez nas w Azji; jak do ostateczności i ponad siły byliśmy doświadczani, tak iż zwątpiliśmy, czy uda się nam wyjść cało z życiem.
###### **2Kor 1,9**
 Lecz właśnie w samym sobie znaleźliśmy wyrok śmierci: aby nie ufać sobie samemu, lecz Bogu, który wskrzesza umarłych.
###### **2Kor 1,10**
 On to ocalił nas tylekroć od śmierci i nadal będzie ocalał. Tak, mamy nadzieję, że nadal będzie nas ratował
###### **2Kor 1,11**
 przy współudziale waszych za nas modlitw, aby w ten sposób wielu dzięki składało za dar dla wielu w nas złożony.
###### **2Kor 1,12**
 Chlubą bowiem jest dla nas świadectwo naszego sumienia, bow prostocie serca i szczerości wobec Boga, a nie według mądrości ciała, lecz według łaski Bożej postępowaliśmy na tym świecie, szczególnie względem was.
###### **2Kor 1,13**
 Nie piszemy wam bowiem czegoś innego niż to, coście czytali i coście zrozumieli. Mam nadzieję, że i do końca będziecie nas rozumieć tak,
###### **2Kor 1,14**
 jak już po części zostaliśmy przez was zrozumiani: mianowicie, że w dzień Pana naszego Jezusa ja będę waszą chlubą, tak jak i wy moją.
###### **2Kor 1,15**
 W tym przeświadczeniu postanowiłem już wcześniej do was przybyć - byście dostąpili powtórnej łaski -
###### **2Kor 1,16**
 następnie udać się do was do Macedonii i z Macedonii znów przyjść do was, po to, byście mnie wyprawili w podróż do Judei.
###### **2Kor 1,17**
 Czyż więc poczynałem sobie lekkomyślnie, wszystko to zamierzając? Albo układając to, czym postanawiał według ciała w ten sposób, iżby 'tak, tak' było u mnie równocześnie 'nie, nie'?
###### **2Kor 1,18**
 Bóg mi świadkiem, że w tym, co do was mówię, nie ma równocześnie 'tak' i 'nie'.
###### **2Kor 1,19**
 Syn Boży, Chrystus Jezus, Ten, którego głosiłem wam ja i Sylwan, i Tymoteusz, nie był 'tak' i 'nie', lecz dokonało się w Nim 'tak'.
###### **2Kor 1,20**
 Albowiem ile tylko obietnic Bożych wszystkie są w Nim 'tak'. Dlatego też przez Niego wypowiada się nasze 'Amen', Bogu na chwałę.
###### **2Kor 1,21**
 Tym zaś, który umacnia nas wespół z wami w Chrystusie i który nas namaścił, jest Bóg.
###### **2Kor 1,22**
 On też wycisnął na nas pieczęć i zostawił zadatek Ducha w sercach naszych.
###### **2Kor 1,23**
 A ja wzywam Boga na świadka mojej duszy, iż tylko aby was oszczędzić, nie przybyłem do Koryntu.
###### **2Kor 1,24**
 Nie żeby okazać nasze władztwo nad wiarą waszą, bo przecież jesteśmy współtwórcami radości waszej: wiarą bowiem stoicie.
# 2Kor 1 WUJ
###### **2Kor 1,1**
 Paweł Apostoł Jezusa Chrystusa, przez wolą Bożą, i Tymoteusz brat: kościołowi Bożemu, który jest w Koryncie, ze wszystkiemi świętemi, którzy są we wszystkiej Achajej.
###### **2Kor 1,2**
 Łaska wam i pokój od Boga Ojca naszego, i Pana Jezusa Chrystusa.
###### **2Kor 1,3**
 Błogosławiony Bóg i Ociec Pana naszego Jezusa Chrystusa, Ociec miłosierdzia, a Bóg wszystkiej pociechy,
###### **2Kor 1,4**
 Który nas cieszy we wszelakiem utrapieniu naszem: abyśmy mogli i sami cieszyć te, którzy są we wszelkim ucisku, przez napominanie, któremu i sami napominani od Boga.
###### **2Kor 1,5**
 Abowiem jako w nas obfitują utrapienia Chrystusowe: tak i przez Chrystusa obfituje pociecha nasza.
###### **2Kor 1,6**
 A choć bywamy utrapieni, dla waszego napominania i zbawienia: choć pocieszeni bywamy, dla waszego pocieszenia: choć napominani bywamy, dla waszego napominania i zbawienia, które sprawuje cierpliwość tegoż utrapienia, które i my cierpiemy:
###### **2Kor 1,7**
 Aby nadzieja nasza mocna była o was: wiedząc, iż jako jesteście towarzysze utrapienia, tak będziecie i pocieszenia.
###### **2Kor 1,8**
 Abowiem nie chcemy, abyście nie wiedzieli bracia, o ucisku naszym, który się stał w Azjej: iżeśmy byli nazbyt obciążeni nad siłę, tak, że nas też tęskno było żyć.
###### **2Kor 1,9**
 Aleśmy sami w sobie mieli wyrok śmierci, abyśmy nie ufali sami w sobie, ale w Bogu, który wzbudza umarłe,
###### **2Kor 1,10**
 Który z tak wielkich niebezpieczeństw wyrwał nas i wyrywa: w którym nadzieję mamy, iż też jeszcze wyrwie,
###### **2Kor 1,11**
 Za pomocą i waszą w modlitwie za nas: aby za ten dar, który w nas jest przez wiele osób, od wielu dzięki były za nas czynione.
###### **2Kor 1,12**
 Abowiem ta jest pochwała nasza, świadectwo sumnienia naszego: iż w prostości serca i szczerości Bożej, a nie w mądrości cielesnej, ale w łasce Bożej obcowaliśmy na tym świecie: a nawięcej u was.
###### **2Kor 1,13**
 Bo nie insze piszemy wam, niźli któreście czytali i poznali. A nadzieję mam, iż aż do końca poznacie:
###### **2Kor 1,14**
 Jakoście też poznali nas poczęści, iż jesteśmy pochwałą waszą, jako i wy naszą, w dzień Pana naszego Jezusa Chrystusa.
###### **2Kor 1,15**
 I z tą ufnością chciałem był iść do was pierwej, abyście wtórą łaskę mieli:
###### **2Kor 1,16**
 I przez was przejść do Macedoniej, i zasię z Macedoniej przyść do was, i od was być doprowadzon do Żydowskiej ziemie.
###### **2Kor 1,17**
 Gdym tedy to chciał, izalim użył lekkomyślności? Abo co myślę, według ciała myślę, aby u mnie było Jest i Nie:
###### **2Kor 1,18**
 Ale wierny Bóg, iż mowa wasza, która była od was, nie jest w niej Jest i Nie.
###### **2Kor 1,19**
 Abowiem Syn Boży Jezus Chrystus, który między wami przez nas był przepowiadany przez mię i Sylwana i Tymotheusza, nie był Jest i Nie: ale Jest w nim było.
###### **2Kor 1,20**
 Bo ile obietnic Bożych są, w nim Jest: przetoż i przezeń Amen Bogu, ku chwale naszej.
###### **2Kor 1,21**
 A który nas potwierdza z wami w Chrystusie, i który nas pomazał, Bóg:
###### **2Kor 1,22**
 Który też zapieczętował nas, i dał zadatek Ducha w sercach naszych.
###### **2Kor 1,23**
 A ja świadkiem wzywam Boga na duszę moję, iż folgując wam nie przyszedłem więcej do Koryntu:
###### **2Kor 1,24**
 Nie że panujemy wierze waszej: ale jesteśmy pomocniki wesela waszego: Abowiem wiarą stoicie.
# 2Kor 1 STERN
###### **2Kor 1,1**
 Sza'ul, z woli Bożej wysłannik Mesjasza Jeszui, i brat Tymoteusz do Bożej Wspólnoty Mesjanicznej w Koryncie, wraz z całym ludem Bożym na obszarze Achai:
###### **2Kor 1,2**
 łaska wam i szalom od Boga, Ojca naszego, i od Pana Jeszui Mesjasza.
###### **2Kor 1,3**
 Niech będzie pochwalony Bóg Pana naszego Jeszui Mesjasza, Ojciec miłosierny, Bóg wszelkiego pokrzepienia i pociechy;
###### **2Kor 1,4**
 który pokrzepia nas we wszelkich naszych przeciwnościach, abyśmy mogli pokrzepiać innych we wszystkich przeciwnościach, jakich doświadczają, tym właśnie pokrzepieniem, którego sami doznaliśmy od Boga.
###### **2Kor 1,5**
 Bo jak cierpienia Mesjasza obfitują w nas, tak przez Mesjasza również nasze pokrzepienie obfituje.
###### **2Kor 1,6**
 Jeśli zatem my doświadczamy przeciwności, to dla waszego pokrzepienia i wyzwolenia; a jeśli my zostajemy pokrzepieni, powinno to pokrzepić i was, gdy musicie znosić cierpienia podobne do naszych.
###### **2Kor 1,7**
 Ponadto niezachwiana jest nasza nadzieja co do was, bo wiemy, że jak macie udział w cierpieniach, tak będziecie też mieć udział w pokrzepieniu.
###### **2Kor 1,8**
 Gdyż chcemy, bracia, abyście wiedzieli o przeciwnościach, jakie nas spotkały w prowincji Azja. Złożono na nas brzemię ponad nasze siły, tak że w rozpaczy zwątpiliśmy nawet, czy to przeżyjemy.
###### **2Kor 1,9**
 Czuliśmy w sercu, że wydano na nas wyrok śmierci. Stało się to jednak po to, aby skłonić nas do polegania nie na sobie samych, ale na Bogu, który wskrzesza umarłych!
###### **2Kor 1,10**
 Ocalił nas On z tak śmiertelnego niebezpieczeństwa - i ocali nas ponownie! Ten, w którym złożyliśmy nadzieję, będzie nam rzeczywiście dalej niósł ocalenie.
###### **2Kor 1,11**
 A i wy musicie pomóc - modlitwą za nas; bo im więcej ludzi się modli, tym więcej ludzi będzie składać dzięki, gdy ich modlitwa za nas zostanie wysłuchana.
###### **2Kor 1,12**
 Bo tym się szczycimy, że według zapewnień naszego sumienia, w swoim zachowaniu względem świata, szczególnie zaś względem was, postępowaliśmy otwarcie i ze zbożną czystością pobudek - nie według mądrości świata, ale zgodnie z daną przez Boga łaską.
###### **2Kor 1,13**
 W naszych listach nie ma żadnej ukrytej treści poza tym, co możecie odczytać i zrozumieć; a mam nadzieję, że zrozumiecie w pełni,
###### **2Kor 1,14**
 jak zresztą już po części nas zrozumieliście; tak że w Dniu naszego Pana Jeszui będziecie mogli być tak dumni z nas, jak my jesteśmy dumni z was.
###### **2Kor 1,15**
 Byłem o tym tak przekonany, że planowałem przybyć do was i ujrzeć was, abyście mogli skorzystać z drugich odwiedzin.
###### **2Kor 1,16**
 Chciałem was odwiedzić w drodze do Macedonii, odwiedzić was jeszcze raz w drodze powrotnej z Macedonii i żebyście mnie wyprawili w drogę do J'hudy.
###### **2Kor 1,17**
 Czy snułem plany zbyt pochopnie? A może snuję plany jak człowiek światowy, gotów bez mrugnięcia okiem rzec i "tak, tak", i "nie, nie"?
###### **2Kor 1,18**
 Jak pewne jest, że wiarygodny jest Bóg, tak i my nie mówimy "tak", gdy chcemy rzec "nie".
###### **2Kor 1,19**
 Bo Syn Boży, Mesjasz Jeszua, który był wśród was głoszony przez nas - czyli przeze mnie, Silę i Tymoteusza - nie był jednocześnie "tak" i "nie"; przeciwnie - u Niego zawsze jest "tak!"
###### **2Kor 1,20**
 Bo ile tylko obietnic złożył Bóg, wszystkie one znajdują swe "tak" w związku z Nim; dlatego przez Niego to mówimy "Amen", gdy oddajemy chwałę Bogu.
###### **2Kor 1,21**
 Ponadto to Bóg daje i nam, i wam trwałą jedność z Mesjaszem; On nas namaścił,
###### **2Kor 1,22**
 zapieczętował i dał nam do serc swego Ducha jako gwarancję na przyszłość.
###### **2Kor 1,23**
 Boga wzywam na świadka - On zna moje życie - że wstrzymałem się z przybyciem do Koryntu ze względu na was!
###### **2Kor 1,24**
 Nie chcemy wam dyktować, jak macie żyć w swej ufności do Mesjasza, bo w ufności waszej trwacie mocno. Lecz współdziałamy z wami z myślą o waszym szczęściu.
# 2Kor 1 TRO
###### **2Kor 1,1**
 **παυλος** *paulos* Paweł – [mały] [[G3972]] [[N-NSM]] **αποστολος** *apostolos* wysłannik [[G652]] [[N-NSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **δια** *dia* przez [[G1223]] [[PREP]] **θεληματος** *thelēmatos* wolę [[G2307]] [[N-GSN]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **τιμοθεος** *timotheos* Tymoteusz – [czczący Boga] [[G5095]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **αδελφος** *adelfos* brat [[G80]] [[N-NSM]] **τη** *tē* [[G3588]] WTT-DSF **εκκλησια** *ekklēsia* zgromadzeniu – (społeczności) wywołanych [[G1577]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **τη** *tē* [[G3588]] WTT-DSF **ουση** *ousē* będącemu [[G5607]] WTV-PXP-DSF **εν** *en* w [[G1722]] [[PREP]] **κορινθω** *korinthō* Koryncie [[G2882]] [[N-DSF]] **συν** *syn* razem ze [[G4862]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPM **αγιοις** *hagiois* świętymi [[G40]] WTA-DPM **πασιν** *pasin* wszystkimi [[G3956]] WTA-DPM **τοις** *tois* [[G3588]] WTT-DPM **ουσιν** *ousin* będącymi [[G5607]] WTV-PXP-DPM **εν** *en* w [[G1722]] [[PREP]] **ολη** *holē* całej [[G3650]] WTA-DSF **τη** *tē* [[G3588]] WTT-DSF **αχαια** *achaia* Achai [[G882]] [[N-DSF]]
###### **2Kor 1,2**
 **χαρις** *charis* łaska [[G5485]] [[N-NSF]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **και** *kai* i [[G2532]] [[CONJ]] **ειρηνη** *eirēnē* pokój [[G1515]] [[N-NSF]] **απο** *apo* od [[G575]] [[PREP]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **πατρος** *patros* Ojca [[G3962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **και** *kai* i [[G2532]] [[CONJ]] **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **2Kor 1,3**
 **ευλογητος** *eulogētos* Błogosławiony – Wysławiony [[G2128]] [[A-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **πατηρ** *patēr* Ojciec [[G3962]] [[N-NSM]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **ο** *ho* [[G3588]] [[T-NSM]] **πατηρ** *patēr* Ojciec [[G3962]] [[N-NSM]] **των** *tōn* [[G3588]] WTT-GPM **οικτιρμων** *oiktirmōn* okazów miłosierdzia – okazów litości [[G3628]] WTN-GPM **και** *kai* i [[G2532]] [[CONJ]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **πασης** *pasēs* każdej [[G3956]] WTA-GSF **παρακλησεως** *paraklēseōs* pociechy – zachęty [[G3874]] [[N-GSF]]
###### **2Kor 1,4**
 **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **παρακαλων** *parakalōn* pocieszający – zachęcający [[G3870]] [[V-PAP-NSM]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **επι** *epi* w [[G1909]] [[PREP]] **παση** *pasē* każdym [[G3956]] WTA-DSF **τη** *tē* [[G3588]] WTT-DSF **θλιψει** *thlipsei* ucisku – utrapieniu [[G2347]] [[N-DSF]] **ημων** *hēmōn* naszym [[G2257]] WTP-1GP **εις** *eis* w [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **δυνασθαι** *dynasthai* móc [[G1410]] WTV-PNN **ημας** *hēmas* nas [[G2248]] WTP-1AP **παρακαλειν** *parakalein* pocieszać – zachęcać [[G3870]] WTV-PAN **τους** *tous* (tych) [[G3588]] WTT-APM **εν** *en* w [[G1722]] [[PREP]] **παση** *pasē* każdym [[G3956]] WTA-DSF **θλιψει** *thlipsei* ucisku – utrapieniu [[G2347]] [[N-DSF]] **δια** *dia* przez [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **παρακλησεως** *paraklēseōs* pocieszanie – zachętę [[G3874]] [[N-GSF]] **ης** *hēs* którą [[G3739]] [[R-GSF]] **παρακαλουμεθα** *parakaloumetha* jesteśmy pocieszani – jesteśmy zachęcani [[G3870]] WTV-PPI-1P **αυτοι** *autoi* sami [[G846]] WTP-NPM **υπο** *hypo* przez [[G5259]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **2Kor 1,5**
 **οτι** *hoti* Gdyż [[G3754]] [[CONJ]] **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **περισσευει** *perisseuei* obfituje (obfitują) [[G4052]] WTV-PAI-3S **τα** *ta* [[G3588]] WTT-NPN **παθηματα** *pathēmata* cierpienia [[G3804]] WTN-NPN **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **εις** *eis* w [[G1519]] [[PREP]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **ουτως** *houtōs* tak [[G3779]] [[ADV]] **δια** *dia* przez [[G1223]] [[PREP]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **περισσευει** *perisseuei* obfituje [[G4052]] WTV-PAI-3S **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **παρακλησις** *paraklēsis* pociecha – zachęta [[G3874]] [[N-NSF]] **ημων** *hēmōn* nasza [[G2257]] WTP-1GP
###### **2Kor 1,6**
 **ειτε** *eite* Czy to [[G1535]] [[CONJ]] **δε** *de* zaś [[G1161]] [[CONJ]] **θλιβομεθα** *thlibometha* jesteśmy uciskani – jesteśmy trapieni [[G2346]] WTV-PPI-1P **υπερ** *hyper* dla [[G5228]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **υμων** *hymōn* waszego [[G5216]] WTP-2GP **παρακλησεως** *paraklēseōs* pocieszenia – zachęty [[G3874]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **σωτηριας** *sōtērias* zbawienia – wyzwolenia [[G4991]] [[N-GSF]] **της** *tēs* [[G3588]] [[T-GSF]] **ενεργουμενης** *energoumenēs* działającego [[G1754]] WTV-PMP-GSF **εν** *en* w [[G1722]] [[PREP]] **υπομονη** *hypomonē* wytrwałości [[G5281]] [[N-DSF]] **των** *tōn* [[G3588]] WTT-GPN **αυτων** *autōn* tych [[G846]] WTP-GPN **παθηματων** *pathēmatōn* cierpień [[G3804]] WTN-GPN **ων** *hōn* które [[G3739]] WTR-GPN **και** *kai* i [[G2532]] [[CONJ]] **ημεις** *hēmeis* my [[G2249]] WTP-1NP **πασχομεν** *paschomen* cierpimy [[G3958]] WTV-PAI-1P
###### **2Kor 1,7**
 **ειτε** *eite* czy to [[G1535]] [[CONJ]] **παρακαλουμεθα** *parakaloumetha* jesteśmy pocieszani – jesteśmy zachęcani [[G3870]] WTV-PPI-1P **υπερ** *hyper* dla [[G5228]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **υμων** *hymōn* waszego [[G5216]] WTP-2GP **παρακλησεως** *paraklēseōs* pocieszenia – zachęty [[G3874]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **σωτηριας** *sōtērias* zbawienia – wyzwolenia [[G4991]] [[N-GSF]] **και** *kai* a [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **ελπις** *elpis* nadzieja [[G1680]] [[N-NSF]] **ημων** *hēmōn* nasza [[G2257]] WTP-1GP **βεβαια** *bebaia* mocna [[G949]] WTA-NSF **υπερ** *hyper* o [[G5228]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **ειδοτες** *eidotes* wiedzący [[G1492]] WTV-RAP-NPM **οτι** *hoti* że [[G3754]] [[CONJ]] **ωσπερ** *hōsper* tak, jak [[G5618]] [[ADV]] **κοινωνοι** *koinōnoi* uczestnicy – wspólnicy [[G2844]] WTA-NPM **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **των** *tōn* [[G3588]] WTT-GPN **παθηματων** *pathēmatōn* cierpień [[G3804]] WTN-GPN **ουτως** *houtōs* tak [[G3779]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **της** *tēs* [[G3588]] [[T-GSF]] **παρακλησεως** *paraklēseōs* pocieszenia – zachęty [[G3874]] [[N-GSF]]
###### **2Kor 1,8**
 **ου** *ou* Nie [[G3756]] [[PRT-N]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **θελομεν** *thelomen* chcemy [[G2309]] WTV-PAI-1P **υμας** *hymas* (aby) wy [[G5209]] WTP-2AP **αγνοειν** *agnoein* nie rozumieć – nie być świadomymi [[G50]] WTV-PAN **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **υπερ** *hyper* o [[G5228]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **θλιψεως** *thlipseōs* ucisku – utrapieniu [[G2347]] [[N-GSF]] **ημων** *hēmōn* naszym [[G2257]] WTP-1GP **της** *tēs* (tym) [[G3588]] [[T-GSF]] **γενομενης** *genomenēs* który stał się [[G1096]] WTV-2ADP-GSF **ημιν** *hēmin* nam [[G2254]] WTP-1DP **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **ασια** *asia* Azji [[G773]] [[N-DSF]] **οτι** *hoti* że [[G3754]] [[CONJ]] **καθ** *kath* w [[G2596]] [[PREP]] **υπερβολην** *hyperbolēn* nadmiarze [[G5236]] WTN-ASF **εβαρηθημεν** *ebarēthēmen* zostaliśmy obciążeni [[G916]] WTV-API-1P **υπερ** *hyper* ponad [[G5228]] [[PREP]] **δυναμιν** *dynamin* moc [[G1411]] WTN-ASF **ωστε** *hōste* tak, że [[G5620]] [[CONJ]] **εξαπορηθηναι** *eksaporēthēnai* zostać zrozpaczonymi – zostać wyzbytymi wyjścia [[G1820]] WTV-APN **ημας** *hēmas* my [[G2248]] WTP-1AP **και** *kai* i [[G2532]] [[CONJ]] **του** *tou* (co do) [[G3588]] WTT-GSM **ζην** *zēn* żyć – pozostać przy życiu [[G2198]] WTV-PAN
###### **2Kor 1,9**
 **αλλα** *alla* Ale [[G235]] [[CONJ]] **αυτοι** *autoi* sami [[G846]] WTP-NPM **εν** *en* w [[G1722]] [[PREP]] **εαυτοις** *heautois* sobie samych [[G1438]] WTF-3DPM **το** *to* [[G3588]] WTT-ASN **αποκριμα** *apokrima* wyrok – odpowiedź [[G610]] WTN-ASN **του** *tou* [[G3588]] WTT-GSM **θανατου** *thanatou* śmierci [[G2288]] [[N-GSM]] **εσχηκαμεν** *eschēkamen* powzięliśmy [[G2192]] WTV-RAI-1P **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **πεποιθοτες** *pepoithotes* pokładający ufności – polegający [[G3982]] WTV-2RAP-NPM **ωμεν** *ōmen* bylibyśmy [[G5600]] WTV-PXS-1P **εφ** *ef* na [[G1909]] [[PREP]] **εαυτοις** *heautois* sobie samych [[G1438]] WTF-3DPM **αλλ** *all* ale [[G235]] [[CONJ]] **επι** *epi* na [[G1909]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **τω** *tō* [[G3588]] WTT-DSM **εγειροντι** *egeironti* wzbudzającym – podnoszącym [[G1453]] WTV-PAP-DSM **τους** *tous* [[G3588]] WTT-APM **νεκρους** *nekrous* martwych [[G3498]] WTA-APM
###### **2Kor 1,10**
 **ος** *hos* który [[G3739]] WTR-NSM **εκ** *ek* z [[G1537]] [[PREP]] **τηλικουτου** *tēlikoutou* tak wielkiej [[G5082]] WTD-GSM **θανατου** *thanatou* śmierci [[G2288]] [[N-GSM]] **ερρυσατο** *errysato* wyratował – wyrwał [[G4506]] WTV-ANI-3S **ημας** *hēmas* nas [[G2248]] WTP-1AP **και** *kai* i [[G2532]] [[CONJ]] **ρυεται** *ryetai* ratuje – wyrywa [[G4506]] WTV-PNI-3S **εις** *eis* w [[G1519]] [[PREP]] **ον** *hon* którym [[G3739]] WTR-ASM **ηλπικαμεν** *ēlpikamen* nabraliśmy nadziei [[G1679]] WTV-RAI-1P **οτι** *hoti* że [[G3754]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **ετι** *eti* jeszcze [[G2089]] [[ADV]] **ρυσεται** *rysetai* wyratuje – wyrwie [[G4506]] WTV-FDI-3S
###### **2Kor 1,11**
 **συνυπουργουντων** *synypourgountōn* współdziałając – współpomagając [[G4943]] WTV-PAP-GPM **και** *kai* i [[G2532]] [[CONJ]] **υμων** *hymōn* was [[G5216]] WTP-2GP **υπερ** *hyper* za [[G5228]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP **τη** *tē* [[G3588]] WTT-DSF **δεησει** *deēsei* prośbą [[G1162]] [[N-DSF]] **ινα** *hina* aby [[G2443]] [[CONJ]] **εκ** *ek* od [[G1537]] [[PREP]] **πολλων** *pollōn* wielu [[G4183]] WTA-GPN **προσωπων** *prosōpōn* twarzy [[G4383]] WTN-GPN **το** *to* (ten) [[G3588]] WTT-NSN **εις** *eis* względem [[G1519]] [[PREP]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **χαρισμα** *charisma* dar łaski [[G5486]] WTN-NSN **δια** *dia* przez [[G1223]] [[PREP]] **πολλων** *pollōn* wielu [[G4183]] WTA-GPN **ευχαριστηθη** *eucharistēthē* otrzymałby dziękczynienie [[G2168]] WTV-APS-3S **υπερ** *hyper* za [[G5228]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP
###### **2Kor 1,12**
 **η** *hē* [[G3588]] [[T-NSF]] **γαρ** *gar* Bo [[G1063]] [[CONJ]] **καυχησις** *kauchēsis* chluba – chełpienie się [[G2746]] [[N-NSF]] **ημων** *hēmōn* nasza [[G2257]] WTP-1GP **αυτη** *hautē* ta [[G3778]] WTD-NSF **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **το** *to* [[G3588]] WTT-NSN **μαρτυριον** *martyrion* świadectwo [[G3142]] WTN-NSN **της** *tēs* [[G3588]] [[T-GSF]] **συνειδησεως** *syneidēseōs* sumienia [[G4893]] [[N-GSF]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **οτι** *hoti* że [[G3754]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **απλοτητι** *haplotēti* prostocie – szczerości [[G572]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **ειλικρινεια** *eilikrineia* szczerości – nieskażoności [[G1505]] [[N-DSF]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εν** *en* w [[G1722]] [[PREP]] **σοφια** *sofia* mądrości [[G4678]] [[N-DSF]] **σαρκικη** *sarkikē* cielesnej [[G4559]] WTA-DSF **αλλ** *all* ale [[G235]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **χαριτι** *chariti* łasce [[G5485]] [[N-DSF]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ανεστραφημεν** *anestrafēmen* postępowaliśmy – zostaliśmy obróceni [[G390]] WTV-2API-1P **εν** *en* na [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **κοσμω** *kosmō* świecie [[G2889]] WTN-DSM **περισσοτερως** *perissoterōs* obficiej [[G4056]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **προς** *pros* przy [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP
###### **2Kor 1,13**
 **ου** *ou* Nie [[G3756]] [[PRT-N]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **αλλα** *alla* inne [[G243]] WTA-APN **γραφομεν** *grafomen* piszemy [[G1125]] WTV-PAI-1P **υμιν** *hymin* wam [[G5213]] WTP-2DP **αλλ** *all* ale [[G235]] [[CONJ]] **η** *ē* lub [[G2228]] WTPRT **α** *ha* które [[G3739]] WTR-APN **αναγινωσκετε** *anaginōskete* czytacie [[G314]] WTV-PAI-2P **η** *ē* lub [[G2228]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **επιγινωσκετε** *epiginōskete* poznajecie – uznajecie [[G1921]] WTV-PAI-2P **ελπιζω** *elpizō* mam nadzieję [[G1679]] WTV-PAI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **οτι** *hoti* że [[G3754]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **εως** *heōs* aż do [[G2193]] [[CONJ]] **τελους** *telous* końca [[G5056]] [[N-GSN]] **επιγνωσεσθε** *epignōsesthe* poznacie – uznacie [[G1921]] WTV-FDI-2P
###### **2Kor 1,14**
 **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **επεγνωτε** *epegnōte* poznaliście – uznaliście [[G1921]] WTV-2AAI-2P **ημας** *hēmas* nas [[G2248]] WTP-1AP **απο** *apo* po [[G575]] [[PREP]] **μερους** *merous* części [[G3313]] [[N-GSN]] **οτι** *hoti* że [[G3754]] [[CONJ]] **καυχημα** *kauchēma* chluba [[G2745]] WTN-NSN **υμων** *hymōn* wasza [[G5216]] WTP-2GP **εσμεν** *esmen* jesteśmy [[G2070]] WTV-PXI-1P **καθαπερ** *kathaper* tak, jak [[G2509]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **ημων** *hēmōn* nasza [[G2257]] WTP-1GP **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **ημερα** *hēmera* dniu [[G2250]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]]
###### **2Kor 1,15**
 **και** *kai* I [[G2532]] [[CONJ]] **ταυτη** *tautē* (w) tym [[G3778]] WTD-DSF **τη** *tē* [[G3588]] WTT-DSF **πεποιθησει** *pepoithēsei* przekonaniu – przeświadczeniu [[G4006]] [[N-DSF]] **εβουλομην** *eboulomēn* chciałem [[G1014]] WTV-INI-1S **προς** *pros* do [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **ελθειν** *elthein* przyjść [[G2064]] [[V-2AAN]] **προτερον** *proteron* wcześniej [[G4386]] [[ADV]] **ινα** *hina* aby [[G2443]] [[CONJ]] **δευτεραν** *deuteran* drugą [[G1208]] WTA-ASF **χαριν** *charin* łaskę [[G5485]] WTN-ASF **εχητε** *echēte* mielibyście [[G2192]] WTV-PAS-2P
###### **2Kor 1,16**
 **και** *kai* i [[G2532]] [[CONJ]] **δι** *di* przez [[G1223]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **διελθειν** *dielthein* przejść [[G1330]] [[V-2AAN]] **εις** *eis* do [[G1519]] [[PREP]] **μακεδονιαν** *makedonian* Macedonii [[G3109]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **παλιν** *palin* znów [[G3825]] [[ADV]] **απο** *apo* z [[G575]] [[PREP]] **μακεδονιας** *makedonias* Macedonii [[G3109]] [[N-GSF]] **ελθειν** *elthein* przyjść [[G2064]] [[V-2AAN]] **προς** *pros* do [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **και** *kai* i [[G2532]] [[CONJ]] **υφ** *hyf* przez [[G5259]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **προπεμφθηναι** *propemfthēnai* zostać wyprawionym – zostać wysłanym dalej [[G4311]] WTV-APN **εις** *eis* do [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **ιουδαιαν** *ioudaian* Judei – [wielbić] [[G2449]] WTN-ASF
###### **2Kor 1,17**
 **τουτο** *touto* To [[G5124]] WTD-ASN **ουν** *oun* więc [[G3767]] [[CONJ]] **βουλευομενος** *bouleuomenos* planując – postanawiając [[G1011]] WTV-PNP-NSM **μη** *mē* czy [[G3361]] [[PRT-N]] **τι** *ti* jakąś [[G5100]] WTX-ASN **αρα** *ara* zatem – mianowicie [[G687]] WTPRT-I **τη** *tē* [[G3588]] WTT-DSF **ελαφρια** *elafria* lekkomyślnością [[G1644]] [[N-DSF]] **εχρησαμην** *echrēsamēn* posłużyłem się – skorzystałem [[G5530]] WTV-ADI-1S **η** *ē* lub [[G2228]] WTPRT **α** *ha* co [[G3739]] WTR-APN **βουλευομαι** *bouleuomai* planuję – postanawiam [[G1011]] WTV-PNI-1S **κατα** *kata* według [[G2596]] [[PREP]] **σαρκα** *sarka* ciała [[G4561]] WTN-ASF **βουλευομαι** *bouleuomai* planuję – postanawiam [[G1011]] WTV-PNI-1S **ινα** *hina* aby [[G2443]] [[CONJ]] **η** *ē* byłoby [[G5600]] WTV-PXS-3S **παρ** *par* u [[G3844]] [[PREP]] **εμοι** *emoi* mnie [[G1698]] WTP-1DS **το** *to* (to) [[G3588]] WTT-NSN **ναι** *nai* tak [[G3483]] WTPRT **ναι** *nai* tak [[G3483]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **ου** *ou* nie [[G3756]] [[PRT-N]] **ου** *ou* nie [[G3756]] [[PRT-N]]
###### **2Kor 1,18**
 **πιστος** *pistos* Wierny [[G4103]] [[A-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **οτι** *hoti* że [[G3754]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **λογος** *logos* Słowo [[G3056]] [[N-NSM]] **ημων** *hēmōn* nasze [[G2257]] WTP-1GP **ο** *ho* [[G3588]] [[T-NSM]] **προς** *pros* do [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εγενετο** *egeneto* stało się [[G1096]] WTV-2ADI-3S **ναι** *nai* tak [[G3483]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]]
###### **2Kor 1,19**
 **ο** *ho* [[G3588]] [[T-NSM]] **γαρ** *gar* Bowiem [[G1063]] [[CONJ]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **υιος** *hyios* Syn [[G5207]] [[N-NSM]] **ιησους** *iēsous* Jezus – [JHWH jest zbawieniem] [[G2424]] [[N-NSM]] **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **ο** *ho* (ten) [[G3588]] [[T-NSM]] **εν** *en* wśród [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **δι** *di* przez [[G1223]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP **κηρυχθεις** *kērychtheis* który został ogłoszony [[G2784]] WTV-APP-NSM **δι** *di* przeze [[G1223]] [[PREP]] **εμου** *emou* mnie [[G1700]] WTP-1GS **και** *kai* i [[G2532]] [[CONJ]] **σιλουανου** *silouanou* Sylwana – [leśny] [[G4610]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **τιμοθεου** *timotheou* Tymoteusza – [czczący Boga] [[G5095]] [[N-GSM]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εγενετο** *egeneto* stał się [[G1096]] WTV-2ADI-3S **ναι** *nai* tak [[G3483]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **αλλα** *alla* ale [[G235]] [[CONJ]] **ναι** *nai* tak [[G3483]] WTPRT **εν** *en* w [[G1722]] [[PREP]] **αυτω** *autō* Nim [[G846]] WTP-DSM **γεγονεν** *gegonen* stało się [[G1096]] WTV-2RAI-3S
###### **2Kor 1,20**
 **οσαι** *hosai* Ile – Jakie [[G3745]] WTK-NPF **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **επαγγελιαι** *epangeliai* obietnice [[G1860]] [[N-NPF]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εν** *en* w [[G1722]] [[PREP]] **αυτω** *autō* Nim [[G846]] WTP-DSM **το** *to* [[G3588]] WTT-NSN **ναι** *nai* tak [[G3483]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **αυτω** *autō* Nim [[G846]] WTP-DSM **το** *to* [[G3588]] WTT-NSN **αμην** *amēn* amen – [zaprawdę] [[G281]] WTHEB **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **προς** *pros* na [[G4314]] [[PREP]] **δοξαν** *doksan* chwałę [[G1391]] WTN-ASF **δι** *di* przez [[G1223]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP
###### **2Kor 1,21**
 **ο** *ho* (Tym) [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **βεβαιων** *bebaiōn* utwierdzającym – umacniającym [[G950]] [[V-PAP-NSM]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **συν** *syn* razem z [[G4862]] [[PREP]] **υμιν** *hymin* wami [[G5213]] WTP-2DP **εις** *eis* w [[G1519]] [[PREP]] **χριστον** *christon* Pomazańcu [[G5547]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **χρισας** *chrisas* który namaścił – który pomazał [[G5548]] WTV-AAP-NSM **ημας** *hēmas* nas [[G2248]] WTP-1AP **θεος** *theos* Bóg [[G2316]] [[N-NSM]]
###### **2Kor 1,22**
 **ο** *ho* [[G3588]] [[T-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **σφραγισαμενος** *sfragisamenos* który opieczętował [[G4972]] WTV-AMP-NSM **ημας** *hēmas* nas [[G2248]] WTP-1AP **και** *kai* i [[G2532]] [[CONJ]] **δους** *dous* który dał [[G1325]] WTV-2AAP-NSM **τον** *ton* [[G3588]] [[T-ASM]] **αρραβωνα** *arrabōna* zadatek – porękę [[G728]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSN **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **εν** *en* w [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **καρδιαις** *kardiais* sercach [[G2588]] WTN-DPF **ημων** *hēmōn* naszych [[G2257]] WTP-1GP
###### **2Kor 1,23**
 **εγω** *egō* Ja [[G1473]] WTP-1NS **δε** *de* zaś [[G1161]] [[CONJ]] **μαρτυρα** *martyra* świadka [[G3144]] [[N-ASM]] **τον** *ton* [[G3588]] [[T-ASM]] **θεον** *theon* Boga [[G2316]] [[N-ASM]] **επικαλουμαι** *epikaloumai* przywołuję sobie [[G1941]] WTV-PMI-1S **επι** *epi* na [[G1909]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **εμην** *emēn* moją [[G1699]] WTS-1ASF **ψυχην** *psychēn* duszę – życie [[G5590]] WTN-ASF **οτι** *hoti* że [[G3754]] [[CONJ]] **φειδομενος** *feidomenos* oszczędzając [[G5339]] WTV-PNP-NSM **υμων** *hymōn* was [[G5216]] WTP-2GP **ουκετι** *ouketi* już nie [[G3765]] [[ADV]] **ηλθον** *ēlthon* przyszedłem [[G2064]] WTV-2AAI-1S **εις** *eis* do [[G1519]] [[PREP]] **κορινθον** *korinthon* Koryntu [[G2882]] WTN-ASF
###### **2Kor 1,24**
 **ουχ** *ouch* Nie [[G3756]] [[PRT-N]] **οτι** *hoti* że [[G3754]] [[CONJ]] **κυριευομεν** *kyrieuomen* panujemy nad [[G2961]] WTV-PAI-1P **υμων** *hymōn* waszą [[G5216]] WTP-2GP **της** *tēs* [[G3588]] [[T-GSF]] **πιστεως** *pisteōs* wiarą [[G4102]] [[N-GSF]] **αλλα** *alla* ale [[G235]] [[CONJ]] **συνεργοι** *synergoi* współpracownicy [[G4904]] WTA-NPM **εσμεν** *esmen* jesteśmy [[G2070]] WTV-PXI-1P **της** *tēs* [[G3588]] [[T-GSF]] **χαρας** *charas* radości [[G5479]] [[N-GSF]] **υμων** *hymōn* waszej [[G5216]] WTP-2GP **τη** *tē* [[G3588]] WTT-DSF **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **πιστει** *pistei* wiarą [[G4102]] [[N-DSF]] **εστηκατε** *hestēkate* stanęliście [[G2476]] WTV-RAI-2P
