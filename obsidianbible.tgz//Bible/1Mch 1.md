# 1Mch 1 BT5
###### **1Mch 1,1**
 Aleksander, syn Filipa, Macedończyk, wyruszył z kraju Kittim, a po zwycięskich walkach pokonał Dariusza, królarsów i Medów, i w jego miejsce objął panowanie najpierw nad Helladą.
###### **1Mch 1,2**
 Prowadził on wiele wojen: zdobył [wiele] warowni i wytracił królów ziem.
###### **1Mch 1,3**
 Dotarł aż na krańce ziemi, a nabrał łupów od mnóstwa narodów. Cała ziemia przed nim zamilkła, jego zaś serce wbiło się w pychę.
###### **1Mch 1,4**
 Zebrał bowiem bardzo liczne wojsko i rządził państwami, narodami i [ich] władcami tak, że płacili mu daniny.
###### **1Mch 1,5**
 A potem padł na łoże i uświadomił sobie, że umiera.
###### **1Mch 1,6**
 Przywołał więc najznamienitszych swoich wodzów, tych, którzy od młodości z nim razem byli wychowywani, i jeszcze za życia rozdzielił swoje królestwo pomiędzy nich.
###### **1Mch 1,7**
 Aleksander panował dwanaście lat i umarł,
###### **1Mch 1,8**
 a jego wodzowie objęli władzę, każdy nad swoim działem.
###### **1Mch 1,9**
 Po jego śmierci wszyscy włożyli sobie na głowy diademy [królewskie] – po nich zaś ich synowie na wiele lat – i dokonali wiele złego na ziemi.
###### **1Mch 1,10**
 Spomiędzy nich wyszedł grzeszny korzeń – Antioch Epifanes, syn króla Antiocha. Przebywał on w Rzymie jako zakładnik, a zaczął panować w sto trzydziestym siódmym roku panowania greckiego.
###### **1Mch 1,11**
 W tym to czasie wystąpili spośród Izraela synowie wiarołomni, którzy podburzyli wielu ludzi, mówiąc: «***Pójdźmy zawrzeć przymierze z narodami, które mieszkają wokoło nas. Wiele złego bowiem spotkało nas od tego czasu, kiedy się od nich oddaliliśmy***».
###### **1Mch 1,12**
 Słowa te w ich mniemaniu uchodziły za dobre.
###### **1Mch 1,13**
 Niektórzy zaś spomiędzy ludu zapalili się do tej sprawy i udali się do króla, a on dał im władzę, żeby wprowadzili pogańskie obyczaje.
###### **1Mch 1,14**
 W Jerozolimie więc wybudowali gimnazjum według pogańskich zwyczajów.
###### **1Mch 1,15**
 Pozbyli się też znaku obrzezania i odpadli od świętego przymierza. Sprzęgli się także z poganami i zaprzedali się [im], aby robić to, co złe.
###### **1Mch 1,16**
 Gdy Antioch uznał, że umocniła się jego władza królewska, powziął zamiar opanowania ziemi egipskiej, by sprawować władzę królewską nad dwoma państwami.
###### **1Mch 1,17**
 Wtargnął więc do Egiptu z wielkim wojskiem i rydwanami, słoniami, konnicą i silną flotą
###### **1Mch 1,18**
 i rozpoczął wojnę przeciwko Ptolemeuszowi, królowi Egiptu. Ptolemeusz wycofał się przed nim i uciekł, a padło wielu zabitych.
###### **1Mch 1,19**
 W Egipcie [wojska Antiocha] zdobyły warowne miasta, a on zgarnął łupy w ziemi egipskiej.
###### **1Mch 1,20**
 Pobiwszy Egipt w sto czterdziestym trzecim roku, Antioch wycofał się i z wielkim wojskiem wyruszył przeciw Izraelowi, i to do Jerozolimy wyruszył.
###### **1Mch 1,21**
 W swojej pysze wtargnął do świątyni i zabrał złoty ołtarz i świecznik, i wszystkie jego sprzęty,
###### **1Mch 1,22**
 stół pokładny, naczynia do ofiar płynnych, czasze, złote kadzielnice, zasłonę; a wieńce, złote ozdoby fasady świątynnej – wszystko zdarł.
###### **1Mch 1,23**
 Zabrał srebro, złoto i kosztowne naczynia; zabrał też ukryte skarby, które odnalazł.
###### **1Mch 1,24**
 Zabrawszy to wszystko, odszedł do swojego kraju, a [w Jerozolimie] uczynił rzeź i przemawiał z ogromną pychą.
###### **1Mch 1,25**
 Na Izraela zaś spadła głęboka żałoba po wszystkich ich siedzibach;
###### **1Mch 1,26**
 narzekali przełożeni i starsi, dziewczęta i młodzieńcy opadli z sił, a piękność niewiast zniknęła.
###### **1Mch 1,27**
 Każdy małżonek począł lamentować, i płakała ta, która siedziała na łożu małżeńskim.
###### **1Mch 1,28**
 Ziemia się zatrzęsła z powodu tych, którzy na niej mieszkali, a cały dom Jakuba okrył się wstydem.
###### **1Mch 1,29**
 Po dwóch latach król posłał do miast judzkich głównego poborcę podatków. Przybył on do Jeruzalem z wielkim wojskiem.
###### **1Mch 1,30**
 W zdradliwy sposób zapewniał ich o pokoju, a oni mu uwierzyli. Wtedy nagle napadł na miasto, zadał im wielką klęskę i spomiędzy Izraela wytracił wielu ludzi.
###### **1Mch 1,31**
 Zgarnął łup z miasta, potem je spalił, a domy jego i mury dokoła zburzył.
###### **1Mch 1,32**
 Kobiety i dzieci wzięli do niewoli, bydło zaś sobie przywłaszczyli.
###### **1Mch 1,33**
 Miasto Dawidowe otoczyli wysokim obronnym murem oraz obronnymi wieżami, tak że stało się ono dla nich zamkiem warownym.
###### **1Mch 1,34**
 Tam osadzili grzeszny naród, ludzi wiarołomnych, a ci się tam obwarowali.
###### **1Mch 1,35**
 Nagromadzili sobie broni i żywności, złożyli tam łupy zdobyte w Jerozolimie, i stali się groźną matnią.
###### **1Mch 1,36**
 [Zamek] stał się dla świątyni zasadzką i złośliwym przeciwnikiem Izraela – w każdym czasie.
###### **1Mch 1,37**
 Dokoła świątyni wylali krew niewinną i samą świątynię zbezcześcili.
###### **1Mch 1,38**
 To przez nich pouciekali mieszkańcy Jeruzalem i stało się ono siedzibą cudzoziemców, dla własnych obywateli stało się obcym miastem i własne dzieci musiały je opuścić.
###### **1Mch 1,39**
 Świątynia spustoszona niczym pustynia, uroczystości przemieniły się w płacz, szabaty jej stały się pośmiewiskiem, a cześć jej w pogardę się obróciła.
###### **1Mch 1,40**
 Jak wielka [była] jej chwała, tak wielkie dokonało się jej upokorzenie, wielkość jej w żałobę się przemieniła.
###### **1Mch 1,41**
 Król napisał [zarządzenie] dla całego swego państwa: «***Wszyscy mają być jednym narodem***
###### **1Mch 1,42**
 ***i niech każdy porzuci swoje obyczaje***». Wszystkie narody przyjęły ten rozkaz królewski,
###### **1Mch 1,43**
 a nawet wielu Izraelitom spodobał się ten kult przez niego nakazany. Składali więc ofiary bożkom i znieważali szabat.
###### **1Mch 1,44**
 Król posłał swoich wysłańców do Jerozolimy i do miast judzkich z pisemnym poleceniem, żeby postępowały według obyczajów, które dla kraju były obce;
###### **1Mch 1,45**
 żeby w świątyni zaprzestano składania całopaleń, ofiar krwawych, a także ofiar płynnych; żeby znieważano szabat i święta
###### **1Mch 1,46**
 i żeby zbezczeszczono świątynię i świętych,
###### **1Mch 1,47**
 żeby [natomiast] sporządzono ołtarze, święte gaje i posągi bożków oraz składano na ofiarę mięso świń i innych nieczystych zwierząt;
###### **1Mch 1,48**
 żeby synów swoich pozostawiali bez obrzezania i żeby dusze swoje brukali wszystkim, co jest nieczyste i światowe.
###### **1Mch 1,49**
 W ten sposób mieli zapomnieć o Prawie i zarzucić wszystkie jego nakazy.
###### **1Mch 1,50**
 Kto by zaś nie postąpił zgodnie z królewskim rozporządzeniem, miał być ukarany śmiercią.
###### **1Mch 1,51**
 Podobne do tego rozkazu pismo wystosował do całego swego królestwa, a nadto nad całym narodem ustanowił nadzorców. Miastom zaś judzkim polecił, aby jedno po drugim składało ofiary [bogom].
###### **1Mch 1,52**
 Spomiędzy narodu wielu przyłączyło się do nich – mianowicie ci wszyscy, którzy porzucili Prawo. Oni to wiele złego dokonali w kraju
###### **1Mch 1,53**
 i byli powodem tego, że Izraelici musieli się kryć w każdym miejscu dostępnym dla ich zbiegów.
###### **1Mch 1,54**
 W dniu piętnastym miesiąca Kislew sto czterdziestego piątego roku na ołtarzu całopalenia wybudowano ohydę spustoszenia, a w okolicznych miastach judzkich pobudowano także ołtarze –
###### **1Mch 1,55**
 ofiary kadzielne składano nawet przed drzwiami domów i na ulicach.
###### **1Mch 1,56**
 Księgi Prawa, które znaleziono, darto w strzępy i palono w ogniu.
###### **1Mch 1,57**
 Wyrok królewski pozbawiał życia tego, u kogo gdziekolwiek znalazła się Księga Przymierza, albo jeżeli ktoś postępował zgodnie z nakazami Prawa.
###### **1Mch 1,58**
 Każdego miesiąca stosowano przemoc wobec Izraela, wobec każdego, kogo udało im się wykryć w miastach.
###### **1Mch 1,59**
 Dnia dwudziestego piątego [każdego] miesiąca składano ofiary na ołtarzu, który wzniesiono na ołtarzu całopalenia.
###### **1Mch 1,60**
 Wtedy to na mocy królewskiego dekretu wymordowano kobiety, które pozwoliły obrzezać swoje dzieci.
###### **1Mch 1,61**
 I powieszono im niemowlęta na szyjach. A także [zabito] domowników i tych, którzy dokonywali na nich obrzezania.
###### **1Mch 1,62**
 Wielu jednak spomiędzy Izraelitów postanowiło sobie, że nie będą jeść nieczystych pokarmów i mocno trzymało się swego postanowienia.
###### **1Mch 1,63**
 Woleli raczej umrzeć, aniżeli skalać się pokarmem i zbezcześcić święte przymierze. Toteż oddali swe życie.
###### **1Mch 1,64**
 Bardzo wielki gniew [Boży] zawisł nad Izraelem.
# 1Mch 1 PAU
###### **1Mch 1,1**
 Wydarzyło się to po ataku Aleksandra, syna Filipa Macedońskiego, który wyszedł z kraju Kittim, pobił Dariusza, króla Persów i Medów, i królował zamiast niego najpierw nad Helladą.
###### **1Mch 1,2**
 Następnie prowadził wiele wojen, zdobył mnóstwo twierdz i zabił wielu królów panujących w ich krajach.
###### **1Mch 1,3**
 Dotarł aż na krańce ziemi i złupił wiele narodów. Ziemia zamilkła przed nim, a jego serce wbiło się w pychę.
###### **1Mch 1,4**
 Zgromadził on bardzo silną armię; rządził krajami i ludami, a ich władców zmusił do płacenia podatku.
###### **1Mch 1,5**
 A potem, złożony ciężką chorobą, zrozumiał, że umiera.
###### **1Mch 1,6**
 Przywołał więc zaufanych towarzyszy, którzy wychowywali się z nim od dzieciństwa, i jeszcze za życia podzielił między nich swoje królestwo.
###### **1Mch 1,7**
 Aleksander zmarł po dwunastu latach królowania.
###### **1Mch 1,8**
 Rządy objęli jego towarzysze, każdy w przydzielonej sobie części.
###### **1Mch 1,9**
 Gdy król umarł, wszyscy oni nałożyli sobie diademy, a po nich także ich synowie - na wiele lat - i uczynili wiele zła na ziemi.
###### **1Mch 1,10**
 Spośród nich wyrósł grzeszny korzeń - Antioch Epifanes, syn króla Antiocha. Był on zakładnikiem w Rzymie, a zaczął królować w sto trzydziestym siódmym roku panowania Greków.
###### **1Mch 1,11**
 W tych dniach pojawili się w Izraelu ludzie nieprawi, którzy zwiedli wielu, mówiąc: „Chodźcie, zawrzyjmy przymierze z narodami mieszkającymi wokół nas, bo od kiedy oddaliliśmy się od nich, spotkały nas liczne nieszczęścia”.
###### **1Mch 1,12**
 Wielu spodobały się te słowa.
###### **1Mch 1,13**
 Niektórzy z ludu powzięli decyzję i udali się do króla, który upoważnił ich do wprowadzania praw obcych narodów.
###### **1Mch 1,14**
 W Jerozolimie wybudowali więc gimnazjon, stosownie do zwyczajów obcych narodów.
###### **1Mch 1,15**
 Wyzbywali się znaku obrzezania i odstąpili od świętego przymierza. Związali się z obcymi narodami i zaprzedali się im, aby móc dopuszczać się zła.
###### **1Mch 1,16**
 Kiedy Antioch utwierdził swoje panowanie, postanowił zawładnąć Egiptem, aby rządzić dwoma królestwami.
###### **1Mch 1,17**
 Wkroczył więc do Egiptu z wielkim wojskiem, rydwanami i słoniami, z jeźdźcami i wielką flotą,
###### **1Mch 1,18**
 i rozpoczął wojnę przeciwko królowi Egiptu Ptolemeuszowi. Ptolemeusz przestraszył się go i uciekł. Padło wielu zabitych.
###### **1Mch 1,19**
 Antioch zdobył warowne miasta egipskie i złupił Egipt.
###### **1Mch 1,20**
 Po pobiciu Egiptu w sto czterdziestym trzecim roku Antioch zawrócił, uderzył na Izraela i z wielkim wojskiem wkroczył do Jerozolimy.
###### **1Mch 1,21**
 Wtargnął zuchwale do świątyni i zrabował złoty ołtarz, świecznik, wszystkie naczynia,
###### **1Mch 1,22**
 stół chlebów poświęconych i kielichy ofiarne, misy i złote kadzielnice, zasłonę i wieńce, a złoty ornament z fasady świętego mieszkania zabrał w całości.
###### **1Mch 1,23**
 Zrabował srebro, złoto i kosztowne naczynia; odnalazł też i zabrał skarby, które były ukryte.
###### **1Mch 1,24**
 Wszystko to zrabował, dokonał rzezi, wygłosił zuchwałe mowy i powrócił do swojego kraju.
###### **1Mch 1,25**
 Nastał wielki płacz w Izraelu, we wszystkich jego posiadłościach.
###### **1Mch 1,26**
 Jęczeli przywódcy i starsi; dziewczęta i chłopcy wzdychali. Zmarniało piękno kobiet.
###### **1Mch 1,27**
 Każdy pan młody podniósł lament, a oblubienica smuciła się na ślubnym łożu.
###### **1Mch 1,28**
 Ziemia wzruszyła się nad swoimi mieszkańcami, a cały dom Jakuba okrył się wstydem.
###### **1Mch 1,29**
 Po dwóch latach król posłał do miast Judy poborcę podatków. Przybył on do Jeruzalem z wielkim wojskiem i
###### **1Mch 1,30**
 zapewniał o pokoju, lecz były to podstępne słowa. Kiedy mu uwierzyli, niespodziewanie napadł na miasto, zadał mu wielką klęskę i zabił wielu Izraelitów.
###### **1Mch 1,31**
 Ograbił i spalił miasto, zburzył domy i mury obronne.
###### **1Mch 1,32**
 Jego ludzie uprowadzili w niewolę kobiety i dzieci; zagarnęli także bydło.
###### **1Mch 1,33**
 Miasto Dawida otoczyli wielkim i mocnym murem oraz potężnymi basztami i uczynili z niego swoją twierdzę.
###### **1Mch 1,34**
 Osiedlili w nim naród grzeszny, ludzi nieprawych, którzy się w nim obwarowali.
###### **1Mch 1,35**
 Zgromadzili tam broń i żywność oraz złożyli łupy zrabowane w Jeruzalem. W ten sposób stali się poważnym zagrożeniem.
###### **1Mch 1,36**
 Sidłem stali się dla świątyni, a dla Izraela przeciwnikiem złowrogim we wszystkim.
###### **1Mch 1,37**
 Wokół świątyni przelali krew niewinną i splądrowali świątynię.
###### **1Mch 1,38**
 Z ich powodu uciekli mieszkańcy Jerozolimy, która stała się mieszkaniem dla cudzoziemców, a dla swego potomstwa miejscem obcym; jej własne dzieci musiały ją opuścić.
###### **1Mch 1,39**
 Jej świątynia spustoszona doszczętnie. Jej święta w płacz zamienione, jej szabaty - w obelgę, cześć jej - we wzgardę.
###### **1Mch 1,40**
 Jej hańba większa niż dawna chwała. Sława jej zamieniona w żałobę.
###### **1Mch 1,41**
 Król wydał polecenie dla całego królestwa, aby wszyscy stali się jednym ludem,
###### **1Mch 1,42**
 by każdy porzucił swoje prawa. Wszystkie narody przyjęły postanowienie króla.
###### **1Mch 1,43**
 Także wielu Izraelitów przyjęło obrzędy nakazane przez króla. Zaczęli oni składać ofiary bożkom i bezcześcić szabat.
###### **1Mch 1,44**
 Następnie król skierował do Jerozolimy i miast Judy posłów z pisemnym zarządzeniem, że mają postępować według praw, które są obce dla kraju;
###### **1Mch 1,45**
 mają zaprzestać składania w świątyni ofiar całopalnych, pokarmowych i płynnych; mają bezcześcić szabaty i święta;
###### **1Mch 1,46**
 profanować świątynię i rzeczy święte;
###### **1Mch 1,47**
 wznosić pogańskie ołtarze, świątynie i posągi; zabijać na ofiarę wieprze i inne nieczyste zwierzęta;
###### **1Mch 1,48**
 zostawiać swoich synów bez obrzezania, plamić swoje dusze wszelką nieczystością i plugastwem;
###### **1Mch 1,49**
 i mają zapomnieć o Prawie oraz zarzucić wszystkie jego nakazy.
###### **1Mch 1,50**
 Ktokolwiek by nie postąpił według rozkazu króla, miał być ukarany śmiercią.
###### **1Mch 1,51**
 Podobne decyzje wydał dla całego swojego królestwa, ustanowił nadzorców nad całym ludem i rozkazał, aby miasta Judy - jedno po drugim - składały ofiary.
###### **1Mch 1,52**
 Wielu z ludu przyłączyło się do nich. Czynił to każdy, kto odstąpił od Prawa. I wyrządzili wiele zła w kraju.
###### **1Mch 1,53**
 Z ich powodu Izraelici musieli się ukrywać we wszystkich miejscach, do których zbiegli.
###### **1Mch 1,54**
 Piętnastego dnia miesiąca Kislew sto czterdziestego piątego roku król zbudował na ołtarzu całopalenia bluźnierczą obrzydliwość, a w okolicznych miastach Judy zbudowano ołtarze.
###### **1Mch 1,55**
 Przed drzwiami domów i na placach składano ofiary kadzielne.
###### **1Mch 1,56**
 Znalezione księgi Prawa rwano na kawałki i wrzucano do ognia.
###### **1Mch 1,57**
 Każdy, u kogo znaleziono Księgę Przymierza lub kto zachowywał Prawo, wyrokiem króla był skazywany na śmierć.
###### **1Mch 1,58**
 I tak przez całe miesiące stosowali przemoc w Izraelu wobec wszystkich, których schwytali w miastach.
###### **1Mch 1,59**
 Dwudziestego piątego dnia miesiąca składano ofiary na ołtarzu wzniesionym na miejscu ołtarza całopaleń.
###### **1Mch 1,60**
 Zgodnie z dekretem skazano na śmierć kobiety, które kazały obrzezać swoje dzieci.
###### **1Mch 1,61**
 Za szyje wieszano niemowlęta, ich domowników oraz tych, którzy je obrzezali.
###### **1Mch 1,62**
 Jednak wielu Izraelitów mocno sobie postanowiło, że nie będą jeść nieczystych potraw.
###### **1Mch 1,63**
 Woleli raczej umrzeć, niż splamić się nieczystymi pokarmami i zbezcześcić święte przymierze. Dlatego ginęli.
###### **1Mch 1,64**
 I tak wybuchnął wielki gniew na Izraela.
# 1Mch 1 BP
###### **1Mch 1,1**
 Działo się to potem, jak Aleksander, syn Filipa Macedońskiego, wyruszywszy z ziemi Kittim pokonał Dariusza, króla Persów i Medów, i zasiadł na tronie zamiast niego; przedtem bowiem panował jedynie nad Grecją.
###### **1Mch 1,2**
 Stoczył wiele bitew, zdobywał twierdze i kazał wymordować wielu władców panujących na ziemi.
###### **1Mch 1,3**
 Dotarł aż na krańce świata i złupił bogactwa wielu narodów. A gdy umilkła przed nim ziemia, jego serce uniosło się pychą.
###### **1Mch 1,4**
 Zebrał potężne wojska i panował nad krajami, narodami oraz władcami, których uzależnił i zmusił do płacenia daniny.
###### **1Mch 1,5**
 Potem złożony ciężką chorobą zrozumiał, że nadchodzi śmierć.
###### **1Mch 1,6**
 Przywołał więc swoich najznakomitszych dowódców, którzy wychowywali się z nim od dzieciństwa, i jeszcze za życia podzielił między nich królestwo.
###### **1Mch 1,7**
 Zmarł więc Aleksander po dwunastu latach panowania.
###### **1Mch 1,8**
 Władzę przejęli jego wodzowie - każdy nad wyznaczoną mu częścią [państwa Aleksandra].
###### **1Mch 1,9**
 Wszyscy po jego śmierci włożyli diademy, a po nich - przez wiele lat - ich synowie, i stali się sprawcami wielu nieszczęść na ziemi.
###### **1Mch 1,10**
 Potomkiem ich był bezbożny Antioch Epifanes, syn króla Antiocha. Był on zakładnikiem w Rzymie, a królem został w roku sto trzydziestym siódmym panowania Greków.
###### **1Mch 1,11**
 W tym czasie wystąpili spośród Izraelitów niektórzy synowie nieprawości i namawiali wielu ludzi tymi słowy: "Spróbujmy zawrzeć przymierze z narodami, które z nami sąsiadują, ponieważ z chwilą oddzielenia się od nich spotkało nas wiele nieszczęść".
###### **1Mch 1,12**
 Słowa te zostały przez ludzi przyjęte życzliwie.
###### **1Mch 1,13**
 Niektórzy z ludu bardzo się do tego zapalili i poszli do króla, który pozwolił im na wprowadzenie zwyczajów narodów pogańskich.
###### **1Mch 1,14**
 Wzorując się na tych zwyczajach zbudowali w Jerozolimie gimnazjum
###### **1Mch 1,15**
 i usuwali ślady obrzezania, sprzeniewierzając się w ten sposób świętemu Przymierzu. Coraz bardziej więc bratali się z narodami pogańskimi i zaprzedawali się po to, aby czynić zło.
###### **1Mch 1,16**
 Kiedy Antioch umocnił swoje panowanie, postanowił podbić Egipt, aby władać dwoma królestwami.
###### **1Mch 1,17**
 Wtargnął tedy do Egiptu z potężnym wojskiem, składającym się z wozów bojowych, słoni, jazdy i potężnej floty.
###### **1Mch 1,18**
 W ten sposób rozpoczął wojnę z Ptolemeuszem, królem Egiptu. Ptolemeusz wycofał się przed nim i uciekł. Padło wielu śmiertelnie rannych.
###### **1Mch 1,19**
 Zdobyto warowne miasta egipskie, a [król] zebrał łupy z ziemi egipskiej.
###### **1Mch 1,20**
 Po zwycięstwie nad Egiptem w roku sto czterdziestym trzecim Antioch zawrócił i wyruszywszy przeciw Izraelowi przybył do Jerozolimy z ogromnym wojskiem.
###### **1Mch 1,21**
 W swym zuchwalstwie wtargnął do Świątyni i zrabował złoty ołtarz oraz świecznik z należącymi do niego przedmiotami.
###### **1Mch 1,22**
 Zabrał też stół chlebów ofiarniczych, naczynia ofiarne, czasze, złote kadzielnice, zasłonę, wieńce i złote ozdoby z frontonu Świątyni. Ze wszystkich tych przedmiotów kazał zedrzeć [złoto].
###### **1Mch 1,23**
 Zrabował również srebro, złoto, kosztowne naczynia oraz to, co znalazł w ukrytych skarbcach.
###### **1Mch 1,24**
 Zabrał więc wszystko, dokonał rzezi i wygłosiwszy butne przemówienia powrócił do swego kraju.
###### **1Mch 1,25**
 Głęboki smutek ogarnął cały kraj Izraela.
###### **1Mch 1,26**
 Biadali przełożeni i starsi, dziewczęta i chłopcy marnieli, niewiasty straciły urodę.
###### **1Mch 1,27**
 Każdy oblubieniec rozpaczał, a oblubienica smuciła się na łożu ślubnym.
###### **1Mch 1,28**
 Ziemia wzdychała nad dolą swych mieszkańców i cały dom Jakuba okrył się wstydem.
###### **1Mch 1,29**
 Po dwóch latach wysłał król do miast judzkich głównego poborcę podatkowego, który przybył do Jerozolimy z wielkim oddziałem.
###### **1Mch 1,30**
 Uwierzyli mu, gdy przemawiając podstępnie zapewniał ich o pokoju. On zaś niespodziewanie napadł na miasto, zniszczył je i wymordował wielu spośród ludu izraelskiego.
###### **1Mch 1,31**
 Ograbił doszczętnie miasto i spalił je. Zburzył też domy i ciągnące się wokoło mury.
###### **1Mch 1,32**
 Kobiety z dziećmi uprowadzili w niewolę. Zagarnęli również bydło.
###### **1Mch 1,33**
 Miasto Dawida obwarowali wielkim i mocnym murem oraz potężnymi wieżami, po czym zamienili na swą twierdzę.
###### **1Mch 1,34**
 Osadzili w nim bezbożny naród - ludzi łamiących Prawo, którzy się tam umocnili.
###### **1Mch 1,35**
 Zgromadzili broń i żywność. Znieśli też łupy zabrane z Jerozolimy. Stali się więc miejscem zagrożenia.
###### **1Mch 1,36**
 Było to zasadzką dla Świątyni a dla Izraela stało się na zawsze diabelskim utrapieniem.
###### **1Mch 1,37**
 Wokół Świątyni przelali niewinną krew i zbezcześcili święty Przybytek.
###### **1Mch 1,38**
 Z ich to powodu uciekli mieszkańcy Jerozolimy, która stała się siedzibą cudzoziemców, miastem obcym dla swoich i własne dzieci musiały ją opuścić.
###### **1Mch 1,39**
 Jej Przybytek święty wyludnił się niczym pustynia, święta zmieniły się w żałobę, święty dzień szabatu w pośmiewisko, jej chwała w pogardę.
###### **1Mch 1,40**
 Jak niegdyś była sławna, tak teraz wzgardzona. Jej wspaniałość obróciła się w smutek.
###### **1Mch 1,41**
 Król zaś rozesłał po całym swym królestwie pismo z rozkazem, aby wszyscy poddam utworzyli jeden naród
###### **1Mch 1,42**
 i porzucili swoje własne zwyczaje. Wszystkie ludy postąpiły zgodnie z wolą króla.
###### **1Mch 1,43**
 Także wielu Izraelitów zgodziło się przyjąć jego boski kult. Składali więc ofiary bałwanom i znieważali szabat.
###### **1Mch 1,44**
 Następnie wysłał król posłów do Jerozolimy i miast judzkich z pisemnym rozkazem, aby przyjęli obce ich ziemi zwyczaje,
###### **1Mch 1,45**
 a zaprzestali całopalenia, składania ofiar krwawych i płynnych w Świątyni, aby znieważali szabat i święta,
###### **1Mch 1,46**
 aby splugawili Przybytek i świętych,
###### **1Mch 1,47**
 wznieśli ołtarze ofiarne, posągi bożków i założyli święte gaje oraz by składali na ofiarę świnie i inne nieczyste zwierzęta.
###### **1Mch 1,48**
 [Żądał], by synów zostawiali bez obrzezania i dusze swe plamili wszystkim, co nieczyste i ohydne,
###### **1Mch 1,49**
 aby w ten sposób zapomnieli o Prawie i odrzucili wszystkie święte przepisy.
###### **1Mch 1,50**
 Ktokolwiek by się nie zastosował do rozkazu króla, miał być karany śmiercią.
###### **1Mch 1,51**
 Takie rozporządzenia wydał w całym swym królestwie. Mianował też zarządców nad całym ludem i polecił miastom judzkim, aby wszystkie po kolei składały ofiary.
###### **1Mch 1,52**
 Wielu spośród ludu przyłączyło się do nich - ci wszyscy, którzy wyrzekli się Prawa. Uczynili w kraju wiele zła
###### **1Mch 1,53**
 i zmusili lud izraelski do ukrywania się we wszelkich niedostępnych miejscach.
###### **1Mch 1,54**
 W dniu piętnastym miesiąca Kasleu roku sto czterdziestego piątego wybudował [król] na ołtarzu całopalenia obrzydliwość spustoszenia, nadto w pobliskich miastach judzkich wzniesiono ołtarze.
###### **1Mch 1,55**
 Ofiary kadzielne składano przed bramami domostw i na ulicach.
###### **1Mch 1,56**
 Znalezione Księgi Prawa darto i rzucano w ogień.
###### **1Mch 1,57**
 Każdy, u kogo znaleziono Księgę Przymierza lub kto trwał wiernie przy Prawie, skazywany był na śmierć wyrokiem królewskim.
###### **1Mch 1,58**
 W taki to sposób miesiąc po miesiącu sprawowali władzę nad Izraelem - nad wszystkimi, których napotkali w miastach.
###### **1Mch 1,59**
 Dnia dwudziestego piątego miesiąca Kasleu składano ofiary na ołtarzu wzniesionym na miejscu ołtarza całopalenia.
###### **1Mch 1,60**
 Kobiety, które pozwoliły obrzezać swe dzieci, mordowano zgodnie z rozkazem królewskim;
###### **1Mch 1,61**
 a na szyjach wieszano im niemowlęta. Wykonywano też wyroki na krewnych i na tych, którzy je obrzezali.
###### **1Mch 1,62**
 Wielu jednak spośród Izraela postanowiło mocno i niezłomnie nie jeść nic nieczystego.
###### **1Mch 1,63**
 Woleli raczej umrzeć, niż skalać się pokarmem i podeptać święte Przymierze - umierali więc.
###### **1Mch 1,64**
 Straszny gniew Boży zawisł nad Izraelem.
# 1Mch 1 BR
###### **1Mch 1,1**
 W owych czasach Macedończyk Aleksander, syn Filipa, nadciągnął z kraju Kittim, pokonał Dariusza, króla Persów i Medów, i jako jego następca został pierwszym władcą Hellady.
###### **1Mch 1,2**
 Prowadził on liczne wojny, zdobył wiele twierdz i pokonał niejednego władcę ziemi.
###### **1Mch 1,3**
 Dotarł aż do krańców świata, złupił wiele narodów i cała ziemia legła bezbronna u jego stóp, a on stawał się coraz bardziej wyniosły i dumny.
###### **1Mch 1,4**
 Miał ogromne wojsko, panował nad wieloma krajami, narodami i ich władcami i wszyscy musieli płacić mu daniny.
###### **1Mch 1,5**
 Aż oto pewnego dnia zasłabł, tak że nie mógł się podnieść ze swego posłania i poczuł, że zbliża się śmierć.
###### **1Mch 1,6**
 Zawołał tedy swoich najwyższych dowódców, tych, którzy razem z nim wzrastali od dzieciństwa, i jeszcze za życia podzielił między nich całe królestwo.
###### **1Mch 1,7**
 Zmarł Aleksander po dwunastu latach swoich rządów.
###### **1Mch 1,8**
 Po śmierci Aleksandra przejęli tedy władzę jego dowódcy, każdy na swoim terenie,
###### **1Mch 1,9**
 i nałożyli sobie na głowy diademy królewskie, a po nich przez dłuższy czas rządzili ich potomkowie i sprowadzali na całą ziemię wiele nieszczęść.
###### **1Mch 1,10**
 To spośród nich wyrosła odrośl szczególnie bezbożna, Antioch Epifanes, syn króla Antiocha. Początkowo przebywał on jako zakładnik w Rzymie, władzę zaś objął w roku sto trzydziestym siódmym panowania greckiego.
###### **1Mch 1,11**
 W tym czasie pojawili się w Izraelu liczni zdrajcy prawa i swoimi słowami wielu doprowadzili do upadku. Mówili bowiem: Powinniśmy zawrzeć przymierza z narodami, które nas otaczają, bo wiedzie się nam coraz gorzej od czasu, kiedyśmy się od nich oddalili.
###### **1Mch 1,12**
 I spodobała się wielu ta rada.
###### **1Mch 1,13**
 Natychmiast też zgłosiło się kilku spośród ludu i udali się do króla, a król pozwolił im, żeby żyli według praw i zwyczajów obcych ludów.
###### **1Mch 1,14**
 Zbudowali więc w Jerozolimie gimnazjon, jakie zwykle urządzają u siebie obce narody.
###### **1Mch 1,15**
 Zaczęli się też pozbywać znaku obrzezania, łamiąc w ten sposób święte przymierze. Mieszali się coraz bardziej z obcymi narodami, aby wspólnie dopuszczać się wszelkiego zła.
###### **1Mch 1,16**
 Kiedy Antioch poczuł się już dostatecznie umocniony w swojej władzy, zapragnął zostać królem także Egiptu, żeby mieć władzę nad dwoma.
###### **1Mch 1,17**
 Wkroczył więc do Egiptu, prowadząc ze sobą bardzo liczne wojsko, rydwany, słonie, konnicę i wiele okrętów.
###### **1Mch 1,18**
 Rozpoczął wojnę przeciwko Ptolemeuszowi, królowi Egiptu, i wkrótce go pokonał. Sam Ptolemeusz zdołał uciec, ale w walce poległo bardzo wielu jego wojowników.
###### **1Mch 1,19**
 Wszystkie warownie egipskie zostały zdobyte, a cały kraj złupiony.
###### **1Mch 1,20**
 Po zwycięstwie nad Egiptem w roku sto czterdziestym trzecim, wyruszył na Izrael i wkrótce się znalazł z licznymi wojskami pod murami Jerozolimy.
###### **1Mch 1,21**
 Zadufany we własne siły wtargnął do świątyni, zabrał złoty ołtarz całopalenia, świecznik z wszystkimi jego przyborami,
###### **1Mch 1,22**
 stół do chlebów pokładnych, naczynia do składania ofiar płynnych, puchary, złote kadzielnice, zasłonę, wieńce, złote ozdoby frontonu świątyni. Z wszystkich przedmiotów kazał odrywać złoto.
###### **1Mch 1,23**
 Zabrawszy następnie srebro, złoto i drogie naczynia oraz wszystko, cokolwiek zdołał znaleźć spośród ukrytych skarbów,
###### **1Mch 1,24**
 kazał przewieźć do swojego kraju. [W Jerozolimie] zaś sprawił rzeź i przemawiał z ogromną butą.
###### **1Mch 1,25**
 Izrael cały pogrążył się w wielkiej żałobie.
###### **1Mch 1,26**
 Jęczeli wszyscy przełożeni i starsi, z sił opadły dziewczęta, osłabli też młodzi ludzie i przeminęła piękność kobiet.
###### **1Mch 1,27**
 Lamentowali wszyscy małżonkowie i rozpaczały oblubienice siedząc samotnie na łożach.
###### **1Mch 1,28**
 Losem swoich mieszkańców wzruszona była cała ziemia, a wszystek dom Jakuba hańba okryła.
###### **1Mch 1,29**
 W dwa lata później wysłał król swojego głównego poborcę podatków do miast judzkich i polecił mu ściągać z nich podatki. Przybył więc ów wysłannik z licznym wojskiem do Jerozolimy
###### **1Mch 1,30**
 i zaczął podstępnie zapewniać mieszkańców miasta, że przybywa w zamiarach pokojowych. Kiedy zaś uwierzono jego zapewnieniom, napadł niespodziewanie na miasto, rozgromił jego mieszkańców, zadając śmierć bardzo wielu Izraelitom.
###### **1Mch 1,31**
 Kazał też złupić całe miasto i puścić z dymem wszystkie domy oraz zburzyć obronne mury miasta.
###### **1Mch 1,32**
 Uprowadzono do niewoli wszystkie kobiety i dzieci, a całe ich mienie podzielono i zabrano jako łup.
###### **1Mch 1,33**
 Dokoła Miasta Dawidowego wzniesiono wysoki mur z potężnymi wieżami obronnymi, żeby mogło im służyć za twierdzę.
###### **1Mch 1,34**
 Twierdza została obsadzona ludźmi, którzy nie szanowali prawa. Gdy się w niej umocnili,
###### **1Mch 1,35**
 zaopatrzyli się w broń i żywność i tam właśnie złożyli łupy, które zabrali z Jerozolimy. Z czasem stanowili oni [dla Żydów] bardzo wielkie zagrożenie.
###### **1Mch 1,36**
 Dla świątyni stali się niebezpieczni z ukrycia, zawsze byli dla Izraela bardzo groźnym wrogiem.
###### **1Mch 1,37**
 Wokół świątyni rozlewali krew ludzi niewinnych i bezcześcili wszystkie miejsca święte.
###### **1Mch 1,38**
 Pouciekali przed nimi mieszkańcy Jeruzalem, a do miasta zaczęli ściągać cudzoziemcy; dla swoich stało się ono miastem obcym, a jego synowie musieli z niego odejść.
###### **1Mch 1,39**
 Świątynia ograbiona była jak pustynia, jej święta zmieniły się w dni żałoby, nikt się nie przejmował jej szabatami, a ona sama zamiast szacunku doznawała pogardy.
###### **1Mch 1,40**
 I jak kiedyś wielka była jej sława, tak wielka teraz stała się jej hańba. Strącona z dawnych wyżyn, leżąc jęczy w smutku.
###### **1Mch 1,41**
 W końcu wydał król dekret, skierowany do całego państwa,
###### **1Mch 1,42**
 żeby wszyscy stanowili jeden naród i nie żyli już każdy według własnych obyczajów. Wszystkie inne narody poddały się temu dekretowi królewskiemu,
###### **1Mch 1,43**
 a służba Boża nakazana przez króla spodobała się także wielu Izraelitom, którzy zaczęli składać ofiary różnym podobiznom bożków i bezcześcić szabat.
###### **1Mch 1,44**
 Król rozesłał swoich ludzi do Jerozolimy i do innych miast judzkich z pisemnym zarządzeniem, żeby wszyscy wprowadzali obyczaje dotychczas nieznane w całym kraju.
###### **1Mch 1,45**
 [Domagał się w tym piśmie], żeby zaprzestano składania w świątyni całopaleń, ofiar krwawych i płynnych; żeby nie obchodzono szabatów i dni świątecznych;
###### **1Mch 1,46**
 żeby przestano otaczać czcią świątynię i jej świętych.
###### **1Mch 1,47**
 Zarządził też, żeby były wznoszone ołtarze, sanktuaria i świątynie dla obcych bożków oraz żeby składano na ofiarę świnie i inne nieczyste zwierzęta.
###### **1Mch 1,48**
 Synowie Izraelitów nie mieli już być poddawani obrzezaniu, przeciwnie: wolno im było kalać się wszystkim, co nieczyste i budzi odrazę.
###### **1Mch 1,49**
 W ten sposób miało dojść do całkowitego zapomnienia prawa i wszystkiego, co ono nakazuje.
###### **1Mch 1,50**
 Ten zaś, kto by nie chciał posłuchać nakazów króla, miał być ukarany śmiercią.
###### **1Mch 1,51**
 Podobne zarządzenia rozesłał [król] po całym swoim państwie. Ustanowił też specjalnych urzędników, którzy mieli czuwać nad wprowadzeniem w życie jego zarządzeń w całym kraju. Wydał także rozkaz, żeby miasta judzkie kolejno składały ofiary na cześć bożków.
###### **1Mch 1,52**
 Wielu spośród narodu izraelskiego poddało się tym zarządzeniom. Odpadli oni od prawa i wyrządzili wiele złego całemu krajowi.
###### **1Mch 1,53**
 [Prawdziwi] Izraelici musieli od nich stronić i jak zbiegowie ukrywać się po różnych miejscach, gdzie mogli znaleźć schronienie.
###### **1Mch 1,54**
 Piętnastego dnia miesiąca Kislew, w sto czterdziestym piątym roku [król] kazał wznieść na ołtarzu całopalenia ohydę spustoszenia. W innych miastach judzkich budowano również ołtarze.
###### **1Mch 1,55**
 Przed drzwiami domów i na placach palono kadzidła.
###### **1Mch 1,56**
 Wszystkie zwyczaje prawa, które odnaleziono, były darte na strzępy i palone.
###### **1Mch 1,57**
 Ten, u kogo znaleziono księgę Przymierza albo stwierdzono, że żyje według przepisów prawa, zgodnie z rozkazem króla był skazywany na śmierć.
###### **1Mch 1,58**
 I tak z miesiąca na miesiąc coraz boleśniej odczuwał Izrael nad sobą obcą władzę. Oni zaś dopuszczali się przemocy wobec wszystkich, których tylko zdołali pochwycić w jakimś mieście.
###### **1Mch 1,59**
 Dnia dwudziestego piątego miesiąca Kislew złożono ofiary na ołtarzu, który został wzniesiony na miejscu ołtarza całopalenia.
###### **1Mch 1,60**
 [Wtedy to] na rozkaz króla zostały wymordowane wszystkie matki, które pozwoliły obrzezać swoje dzieci.
###### **1Mch 1,61**
 Niemowlęta zawieszano na szyjach pomordowanych matek. Pozabijano także tych, którzy mieszkali z nimi w tym samym domu, oraz tych wszystkich, którzy dokonywali obrzezań.
###### **1Mch 1,62**
 Mimo to wielu Izraelitów nie dało się złamać. Nie tknęli tego, co było nieczyste.
###### **1Mch 1,63**
 Woleli raczej umierać niż skalać się nieczystymi pokarmami albo zbezcześcić święte przymierze. Tak więc umierali.
###### **1Mch 1,64**
 [Widać stąd, jak] wielki gniew [Boży] zaciążył nad całym Izraelem.
# 1Mch 1 WUJ
