# Am 3 BT5
###### **Am 3,1**
 Słuchajcie tego słowa, które mówi Pan do was, synowie Izraela, do całego pokolenia, które Ja wyprowadziłem z ziemi egipskiej:
###### **Am 3,2**
 Jedynie was znałem ze wszystkich narodów na ziemi, dlatego was nawiedzę karą za wszystkie wasze winy.
###### **Am 3,3**
 Czyż wędruje dwu razem, jeśli się wzajem nie znają?
###### **Am 3,4**
 Czyż ryczy lew w lesie, nie mając zdobyczy?Czyż lwiątko wydaje głos ze swego legowiska, jeśli niczego nie schwytało?
###### **Am 3,5**
 Czyż spada ptak na ziemię, jeśli nie było [zastawionego] sidła?Czyż się unosi pułapka nad ziemią, zanim coś schwytała?
###### **Am 3,6**
 Czyż dmie się w trąbę w mieście, a lud nie zadrży?Czyż zdarza się w mieście nieszczęście, by Pan tego nie sprawił?
###### **Am 3,7**
 Bo Pan Bóg nie uczyni niczego, nie objawiwszy swej tajemnicy sługom swym, prorokom.
###### **Am 3,8**
 Gdy lew zaryczy, któż się nie ulęknie?Gdy Pan Bóg przemówi, któż nie będzie prorokować?
###### **Am 3,9**
 Głoście w pałacach w Aszdodziei na zamkach w ziemi egipskiej! Mówcie: «***Zbierzcie się na górach Samarii, zobaczcie wielkie w niej zamieszaniei gwałty pośród niej!***»
###### **Am 3,10**
 Nie umieją postępować uczciwie – wyrocznia Pana –gromadzą nieprawość i ucisk w swych pałacach.
###### **Am 3,11**
 Dlatego tak mówi Pan Bóg:Nieprzyjaciel otoczy kraj; zniszczona będzie moc twojai ograbione twoje pałace.
###### **Am 3,12**
 Tak mówi Pan:Jak pasterz z lwiej paszczy ratujetylko dwie nogi albo koniec ucha, tak nieliczni uratowani będą synowie Izraela, siedzący w Samarii w rogu łożai na dywanie z Damaszku.
###### **Am 3,13**
 Słuchajcie i oświadczcie w domu Jakubowym– wyrocznia Pana Boga, Boga Zastępów:
###### **Am 3,14**
 W dzień, kiedy będę karał występki Izraela, ukarzę [również] ołtarze Betel. Odrąbane zostaną rogi ołtarzai upadną na ziemię.
###### **Am 3,15**
 Zburzę zarówno dom zimowy, jak i letni; zniszczeją domy z kości słonioweji rozwalone zostaną domy z hebanu – wyrocznia Pana.
# Am 3 PAU
###### **Am 3,1**
 Słuchajcie tego słowa, które PAN wypowiedział przeciwko wam, Izraelici, przeciwko całemu plemieniu, które wyprowadziłem z ziemi egipskiej:
###### **Am 3,2**
 Jedynie was wybrałem ze wszystkich narodów na ziemi, dlatego będę was karał za wszystkie wasze winy.
###### **Am 3,3**
 Czy mogą iść razem dwie osoby, które się ze sobą nie spotkały?
###### **Am 3,4**
 Czy ryczy lew w lesie, zanim coś zdobędzie? Czy lwiątko wydaje głos ze swojego legowiska, jeśli niczego nie schwytało?
###### **Am 3,5**
 Czy wpada ptak w sidła na ziemi, jeśli sidła nie było? Czy odskoczy sidło od ziemi, dopóki się w nie coś nie złapie?
###### **Am 3,6**
 Czy lud się nie lęka, gdy w mieście zabrzmi trąba? Czy zdarza się w mieście nieszczęście, którego by PAN nie dopuścił?
###### **Am 3,7**
 Bo PAN BÓG nie uczyni niczego, zanim nie objawi swojego zamiaru swoim sługom, prorokom.
###### **Am 3,8**
 Gdy lew zaryczy, któż się nie ulęknie? Gdy PAN BÓG przemówi, któż nie będzie prorokował?
###### **Am 3,9**
 Głoście w pałacach Aszdodu i w pałacach ziemi egipskiej mówcie: Zbierzcie się na górach Samarii, patrzcie, jak wielkie jest w niej zamieszanie i ile w niej przemocy.
###### **Am 3,10**
 Nie potrafią już postępować uczciwie, przemoc i gwałt panują w ich pałacach - wyrocznia PANA.
###### **Am 3,11**
 Dlatego tak mówi PAN BÓG: Nieprzyjaciel oblegnie ten kraj; zniszczona będzie twoja potęga, a twoje pałace oddane grabieży.
###### **Am 3,12**
 Tak mówi PAN: Jak pasterz wyrywa z lwiej paszczy dwie nogi lub koniec ucha, tak będą uratowani tylko nieliczni Izraelici spośród siedzących w Samarii na swoich łożach i na kosztownych dywanach.
###### **Am 3,13**
 Słuchajcie i oznajmijcie domowi Jakuba - wyrocznia PANA BOGA, Boga Zastępów:
###### **Am 3,14**
 W dniu, kiedy będę karał występki Izraela, zniszczę również ołtarze Betel. Odcięte zostaną rogi ołtarza i upadną na ziemię.
###### **Am 3,15**
 Zburzę pałac zimowy i letni, zniszczę komnaty zdobione kością słoniową i runą wielkie pałace- wyrocznia PANA.
# Am 3 BP
###### **Am 3,1**
 Słuchajcie słowa tego, które Jahwe wypowiada przeciw wam, synowie Izraela, przeciw całemu narodowi, który wywiodłem z ziemi egipskiej! Oto co mówi: -
###### **Am 3,2**
 Was tylko upatrzyłem sobie spomiędzy wszystkich ludów ziemi, dlatego na was też dochodzić będę wszystkich nieprawości waszych!
###### **Am 3,3**
 Czy może dwóch kroczyć razem bez uzgodnienia dróg?
###### **Am 3,4**
 Czy lew zaryczy w lesie, gdy nie ma przed sobą zdobyczy? Czy lwiątko wyda głos w swej jaskini, jeśli nic nie ułowiło?
###### **Am 3,5**
 Czy wpadnie ptak w pułapkę na ziemi, jeśli tam nie ma dla niego przynęty? Czy potrzask podskoczy z ziemi, jeśli niczego nie uchwycił.
###### **Am 3,6**
 Gdy w mieście zabrzmi róg, czy lud się nie przestraszy? Czy miastu przydarzy się nieszczęście, którego by nie zesłał Jahwe?
###### **Am 3,7**
 Lecz Jahwe-Pan nie czyni niczego bez objawienia swego zamierzenia swym sługom, prorokom.
###### **Am 3,8**
 Lew zaryczał - któż by się przestraszył? Jahwe-Pan przemówił - któż by nie prorokował?
###### **Am 3,9**
 Rozgłoście to po pałacach Asyrii i po pałacach ziemi egipskiej i mówcie: "Zgromadźcie się na górach Samarii i spójrzcie, jak wielki tam nieporządek i jaki w niej ucisk!"
###### **Am 3,10**
 Nie umieją postępować zgodnie z Prawem - mówi Jahwe - lecz gromadzą w swych pałacach skarby pochodzące z gwałtu i grabieży.
###### **Am 3,11**
 Przeto tak mówi Jahwe-Pan: - Nieprzyjaciel otoczy kraj zewsząd i doprowadzi do upadku twoją potęgę, a twoje pałace zostaną złupione.
###### **Am 3,12**
 Tak mówi Jahwe: - Podobnie jak pasterz zdoła wydrzeć z paszczy lwa [najwyżej] dwie golenie lub kawałek ucha, tak uratuje się [tylko niewielu] sysnów Izraela. Wy, co w Samarii siadacie na wygodnych posłaniach albo na łożach obitych adamaszkiem,
###### **Am 3,13**
 słuchajcie i ogłoście tę wiadomość w domu Jakubowym - mówi Jahwe-Pan, Bóg Zastępów.
###### **Am 3,14**
 W dniu, gdy wymierzę Izraelowi karę za jego występki, nawiedzę też ołtarze w Betel; rogi ołtarza zostaną strącone i spadną na ziemię.
###### **Am 3,15**
 Zburzę pałac zimowy i letni, rozpadną się domy zdobione kością słoniową i znikną wielkie budowle - mówi Jahwe.
# Am 3 BR
###### **Am 3,1**
 Posłuchajcie, synowie Izraela, co Pan powiedział o was i o całym pokoleniu, które Ja z Egiptu wywiodłem.
###### **Am 3,2**
 Was tylko wybrałem spośród wszystkich pokoleń ziemi, dlatego odpowiecie za wszystkie wasze uczynki.
###### **Am 3,3**
 Czy możliwe, żeby dwaj ludzie szli razem, nie zamieniając przy tym ze sobą słowa?
###### **Am 3,4**
 Czy lew ryczy w lesie nie widząc przed sobą zdobyczy? Czy młody lew daje o sobie znać z legowiska, jeśli nie pochwyci czegoś?
###### **Am 3,5**
 Czy znajdzie się ptak na ziemi, jeśli go nikt nie schwyci? Czy pułapka unosi się w górę, jeśli się nic w nią nie złapie?
###### **Am 3,6**
 Czy lud się nie przerazi, gdy ktoś w mieście w róg zadmie? Czy zdarza się w mieście coś złego, czego by Pan nie zrządził?
###### **Am 3,7**
 Niczego zaś Bóg i Pan nie czyni, nie objawiwszy swemu słudze proroków tego, co uczynić zamierza.
###### **Am 3,8**
 Gdy lew zaryczy - czy ktoś jest bez trwogi? Kiedy Pan Bóg przemawia, czy ktoś nie chce być prorokiem?
###### **Am 3,9**
 Ogłoście pałacom w Aszdod, powiadomcie wszystkie zamki w Egipcie! Powiedzcie, by się zgromadzili na górach ciągnących się wokół Samarii. Niech zobaczą, jak wielkie zamieszanie w tym mieście, jak wielki panuje tam ucisk.
###### **Am 3,10**
 Nie uznają żadnego prawa - tak Pan mówi - gromadząc w swych pałacach ogromne bogactwa, posługując się przemocą i gwałtem.
###### **Am 3,11**
 Dlatego mówi nasz Pan Bóg: Wróg zewsząd cały kraj otoczy. W gruz się rozsypie cała twa potęga, ograbione zostaną wszystkie twe pałace.
###### **Am 3,12**
 Oto, co Pan powiedział: Jak pasterz z lwiej paszczęki wydobywa już tylko kosci nóg lub końce uszu, tak też ocaleni zostaną synowie Izraela, zasiadający w Samarii na swoich posłaniach i na dywanach sprowadzanych z Damaszku.
###### **Am 3,13**
 Posłuchajcie o tym i dajcie świadectwo domowi Jakuba- wyrocznia Pana i Boga Zastępów.
###### **Am 3,14**
 Dnia tego, w którym pociągnę Izraela do odpowiedzialności za jego czyny, karę zacznę również wymierzać przy ołtarzach w Betel. Odrąbane zostaną rogi ołtarzy i wszystkie pospadają na ziemię.
###### **Am 3,15**
 Zburzę ponadto pałac zimowy, a także pałac letni. Poznikają również domy z kości słoniowej, taki sam koniec spotka wiele innych domów - wyrocznia Pana.
# Am 3 WUJ
###### **Am 3,1**
 Słuchajcie słowa, które Pan mówił na was synowie Izraelowi, na wszystek rodzaj, którym wywiódł z ziemie Egiptskiej, mówiąc:
###### **Am 3,2**
 Tylkom was poznał ze wszech rodzajów ziemskich: dla tego nawiedzę na was wszystkie nieprawości wasze.
###### **Am 3,3**
 Izali pójdą dwa społem, jeśli się nie zgodzą?
###### **Am 3,4**
 Izali ryknie lew w lesie jeśli obłowu mieć nie będzie? izali szczenię lwie wypuści głos swój z legowiska swego, jeśli czego nie ułapi?
###### **Am 3,5**
 Izali wpadnie ptak do sidła na ziemi bez ptasznika? Izali wezmą sidło z ziemie pierwej niźli co ułapi?
###### **Am 3,6**
 Aza zabrzmi trąba w mieście, a lud się nie zlęknie? aza będzie złe w mieście, którego by Pan nie uczynił?
###### **Am 3,7**
 Bo nie czyni Pan Bóg słowa, jeśliby nie objawił tajemnice swej sługom swoim prorokom.
###### **Am 3,8**
 Lew zaryknie, któż się nie zlęknie? Pan Bóg mówił, któż prorokować nie będzie?
###### **Am 3,9**
 Dajcież słyszeć w domiech Azothu, i w domiech ziemie Egiptskiej, a rzeczcie: Zbierzcie się na góry Samaryi, a obaczcie szaleństwa wielkie w pośrodku jej, i potwarz cierpiące w skrytościach jej.
###### **Am 3,10**
 I nie umieli czynić prawości, mówi Pan, skarbiąc nieprawość i łupieztwo w domach swoich.
###### **Am 3,11**
 Przetoż to mówi Pan Bóg: Będzie uciśniona i okrążana ziemia: i zdarta będzie z ciebie moc twoja, a rozchwyco domy twoje.
###### **Am 3,12**
 To mówi Pan: Jako gdyby wyrwał pasterz z paszczeki lwiej dwie goleni, abo koniec ucha: tak wyrywani będą synowie Izraelowi, którzy mieszkają w Samaryi na stronie łóżka, i na łożu Damaszku.
###### **Am 3,13**
 Słuchajcie, a oświadczajcie w domu Jakóbowym, mówi Pan Bóg zastępów:
###### **Am 3,14**
 Bo w dzień, gdy nawiedzać pocznę przestępstwa Izraelowe, nawiedzę go, i ołtarze Bethel: i obcięte będą rogi ołtarzowe, i upadną na ziemię.
###### **Am 3,15**
 I porażę dom zimny z domem letnym: a zginą domy z kości słoniowej, i będą rozwalone domy mnogie, mówi Pan.
