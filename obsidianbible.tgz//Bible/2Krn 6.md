# 2Krn 6 BT5
###### **2Krn 6,1**
 Wtedy przemówił Salomon:«***Pan powiedział, że będzie mieszkać w czarnej chmurze.***
###### **2Krn 6,2**
 ***A ja Ci wybudowałem dom na mieszkanie, miejsce przebywania Twego na wieki***».
###### **2Krn 6,3**
 Potem król się odwrócił i pobłogosławił całe zgromadzenie Izraela. Całe zaś zgromadzenie Izraela stało.
###### **2Krn 6,4**
 Potem rzekł: «***Błogosławiony Pan, Bóg Izraela, który rękami wypełnił, co zapowiedział ustami ojcu mojemu, Dawidowi, mówiąc:***
###### **2Krn 6,5**
 ***Od tego dnia, w którym wyprowadziłem mój lud z ziemi egipskiej, nie wybrałem ze wszystkich pokoleń Izraela żadnego miasta celem wybudowania [w nim] domu, by imię moje w nim przebywało, i nie obrałem męża, aby był władcą nad moim ludem, Izraelem.***
###### **2Krn 6,6**
 ***Ale wybrałem Jerozolimę, aby tam było moje imię, i obrałem Dawida, aby był nad moim ludem izraelskim.***
###### **2Krn 6,7**
 ***Dawid zaś, mój ojciec, powziął zamiar zbudowania domu dla imienia Pana, Boga Izraela.***
###### **2Krn 6,8**
 ***Wówczas Pan rzekł memu ojcu, Dawidowi: Dobrze postąpiłeś, że powziąłeś zamiar zbudowania domu dla mego imienia, bo wypłynęło to z twego serca.***
###### **2Krn 6,9**
 ***Jednak nie ty będziesz budował ten dom, ale Twój rodzony syn, on zbuduje dom dla mego imienia.***
###### **2Krn 6,10**
 ***Wypełnił właśnie Pan to, co obiecał, bo nastałem po ojcu moim, Dawidzie, i zasiadłem na tronie izraelskim, jak zapowiedział Pan, oraz zbudowałem dom dla imienia Pana, Boga Izraela,***
###### **2Krn 6,11**
 ***i tam też umieściłem arkę, w której znajduje się Przymierze, jakie Pan zawarł z Izraelitami***».
###### **2Krn 6,12**
 Następnie stanął przed ołtarzem Pańskim wobec całego zgromadzenia izraelskiego i wyciągnął ręce.
###### **2Krn 6,13**
 Zbudował bowiem Salomon podwyższenie z brązu i postawił pośrodku dziedzińca. Miało ono pięć łokci długości, pięć łokci szerokości i trzy łokcie wysokości. Wstąpił wówczas na nie, upadł na kolana wobec całego zgromadzenia izraelskiego, a wyciągnąwszy ręce ku niebu,
###### **2Krn 6,14**
 rzekł: «***Panie, Boże Izraela, nie ma takiego Boga, jak Ty, na niebie ani na ziemi, tak dochowującego przymierza i łaski względem Twoich sług, którzy czczą Cię z całego swego serca,***
###### **2Krn 6,15**
 ***bo dotrzymałeś słowa Twemu słudze, Dawidowi, memu ojcu, w tym, coś mu przyrzekł i powiedział swoimi ustami, a co dziś wypełniłeś własną ręką.***
###### **2Krn 6,16**
 ***Więc i teraz, o Panie, Boże Izraela, dotrzymaj słowa Twemu słudze, memu ojcu, Dawidowi, jak mu przyrzekłeś, mówiąc: Nie będzie ci odjęty sprzed mego oblicza potomek na tronie Izraela, jeśli tylko twoi synowie strzec będą swej drogi, postępując wobec Mnie tak, jak ty wobec Mnie postępowałeś.***
###### **2Krn 6,17**
 ***Więc teraz Panie, Boże Izraela, niech się sprawdzi Twoje słowo, które dałeś Twemu słudze, Dawidowi.***
###### **2Krn 6,18**
 ***Czyż jednak naprawdę zamieszka Bóg z człowiekiem na ziemi? Przecież niebo i niebiosa najwyższe nie mogą Cię objąć, a tym mniej ta świątynia, którą zbudowałem.***
###### **2Krn 6,19**
 ***Zważ więc na modlitwę Twego sługi i na jego błaganie, o Panie, Boże mój, i wysłuchaj tego wołania i tej modlitwy, którą Twój sługa zanosi do Ciebie.***
###### **2Krn 6,20**
 ***Niech w dzień i w nocy oczy Twoje patrzą na tę świątynię. Jest to miejsce, w którym zechciałeś umieścić swoje imię, by wysłuchać modlitwę, jaką zanosi Twój sługa na tym miejscu.***
###### **2Krn 6,21**
 ***Dlatego wysłuchaj błagania sługi Twego i Twojego ludu, Izraela, ilekroć modlić się będzie na tym miejscu, wysłuchaj z miejsca Twego przebywania, z niebios. Nie tylko wysłuchaj, ale też i przebacz!***
###### **2Krn 6,22**
 ***Kiedy ktoś zgrzeszy przeciw swemu bliźniemu, a później wezwie go do przysięgi, a on przyjdzie do przysięgi wobec Twego ołtarza w tej świątyni –***
###### **2Krn 6,23**
 ***wtedy Ty wysłuchaj z niebios i racz działać – rozsądź między Twymi sługami, złego skazując na karę, aby na jego głowę [spadła odpowiedzialność] za jego postępowanie, a sprawiedliwego uznając niewinnym za jego uczciwość.***
###### **2Krn 6,24**
 ***Jeśli lud Twój, Izrael, spotka klęska od nieprzyjaciela za to, że zgrzeszył przeciw Tobie, a oni się nawrócą i będą wysławiać Twoje imię oraz błagać i prosić przed Tobą w tej świątyni,***
###### **2Krn 6,25**
 ***wtedy Ty wysłuchaj z niebios i przebacz grzech Twojego ludu, Izraela, i przyprowadź ich z powrotem do kraju, który dałeś im i ich przodkom.***
###### **2Krn 6,26**
 ***Kiedy niebo zostanie zamknięte i nie będzie deszczu, dlatego że zgrzeszyli przeciw Tobie, ale potem będą się modlić [zwróceni] ku temu miejscu i sławić Twe imię oraz odwrócą się od swych grzechów, bo ich upokorzyłeś,***
###### **2Krn 6,27**
 ***wtedy Ty wysłuchaj < z > niebios i przebacz grzech Twoich sług i ludu Twego, Izraela. Ty wskażesz im dobrą drogę, po której iść mają, i ześlesz deszcz na Twoją ziemię, którą dałeś swemu ludowi jako dziedzictwo.***
###### **2Krn 6,28**
 ***Gdy w kraju będzie głód lub zaraza, gdy będzie spiekota, śnieć, szarańcza lub liszki, gdy wróg jego natrze na jedną z jego bram, albo jakakolwiek by była klęska lub jakakolwiek choroba –***
###### **2Krn 6,29**
 ***wszelką modlitwę i każde błaganie poszczególnego człowieka i całego ludu Twego, Izraela – skoro przejęty klęską wyciągnie ręce do tej świątyni –***
###### **2Krn 6,30**
 ***Ty wysłuchaj z niebios, miejsca Twego przebywania, racz się zmiłować i oddać każdemu według jego postępowania, bo Ty znasz jego serce, bo jedynie Ty znasz serca ludzi.***
###### **2Krn 6,31**
 ***Niech zachowają bojaźń wobec Ciebie i chodzą Twoimi drogami po wszystkie dni swego życia na powierzchni ziemi, którą dałeś naszym przodkom.***
###### **2Krn 6,32**
 ***Również i cudzoziemca, który nie jest z Twego ludu, Izraela, a jednak przyjdzie z dalekiego kraju przez wzgląd na Twe wielkie imię, na mocną rękę i ramię wyciągnięte, gdy przyjdzie i będzie się modlić w tej świątyni –***
###### **2Krn 6,33**
 ***Ty z niebios, z miejsca Twego przebywania, wysłuchaj i uczyń to wszystko, o co ten cudzoziemiec będzie do Ciebie wołać. Niech wszystkie narody ziemi poznają Twe imię, by przejąć się bojaźnią wobec Ciebie za przykładem ludu Twego, Izraela. Niech wiedzą, że Twoje imię zostało wezwane nad tą świątynią, którą zbudowałem.***
###### **2Krn 6,34**
 ***Gdy lud Twój wyruszy do walki ze swoimi nieprzyjaciółmi drogą, którą go poślesz, i będzie się modlić do Ciebie, zwracając się ku temu miastu i domowi, który zbudowałem dla Twego imienia,***
###### **2Krn 6,35**
 ***wówczas wysłuchaj z niebios ich modlitwę oraz błaganie i wymierz im sprawiedliwość.***
###### **2Krn 6,36**
 ***Jeśliby zaś zgrzeszyli przeciw Tobie – bo nie ma człowieka, który by nie grzeszył – a Ty za to będziesz na nich zagniewany i dlatego oddasz ich w moc wroga, wskutek czego zaborcy uprowadzą ich do ziemi dalekiej czy bliskiej,***
###### **2Krn 6,37**
 ***oni zaś w kraju, do którego zostaną uprowadzeni, będą żałować, nawrócą się i będą błagać Ciebie o litość w kraju ich zesłania, mówiąc: Zgrzeszyliśmy, zbłądziliśmy, bezbożnie postąpiliśmy,***
###### **2Krn 6,38**
 ***jeśli więc nawrócą się do Ciebie z całego serca i z całej duszy w kraju ich zesłania i będą się modlić zwróceni ku krajowi, który dałeś ich przodkom, ku miastu, które wybrałeś, i ku domowi, który zbudowałem dla Twego imienia –***
###### **2Krn 6,39**
 ***wówczas wysłuchaj z niebios, z miejsca Twego przebywania, ich modlitwę oraz błagania i wymierz im sprawiedliwość. Przebacz łaskawie ludowi Twojemu to, w czym zgrzeszył przeciw Tobie.***
###### **2Krn 6,40**
 ***A teraz, Boże mój, niechże oczy Twe będą otwarte, a uszy Twe uważne na modlitwę w tym miejscu.***
###### **2Krn 6,41**
 ***Teraz zaś powstań, Panie Boże, i zamieszkaj Ty wraz z arką Twej potęgi. Kapłani Twoi, Panie Boże, niech przyobleką się w zbawienie, a czciciele Twoi niechaj się radują szczęściem.***
###### **2Krn 6,42**
 ***Panie Boże, nie odwracaj oblicza od Twego pomazańca, pamiętaj o Twej dobroci wobec Twego sługi, Dawida***».
# 2Krn 6 PAU
###### **2Krn 6,1**
 Wtedy Salomon przemówił: „PAN powiedział, że zamieszka w ciemnym obłoku.
###### **2Krn 6,2**
 Ja wzniosłem dla Ciebie wspaniały dom, miejsce, gdzie możesz zamieszkać na zawsze”.
###### **2Krn 6,3**
 Całe zgromadzenie Izraela stało w oczekiwaniu, gdy król zwrócił się w ich kierunku z błogosławieństwem:
###### **2Krn 6,4**
 „Błogosławiony PAN, Bóg Izraela, który wypełnił to, co przyrzekł memu ojcu Dawidowi, mówiąc:
###### **2Krn 6,5**
 «Od dnia, w którym wyprowadziłem mój lud z Egiptu, nie wybrałem sobie żadnego miasta spośród wszystkich plemion Izraela, aby wybudować w nim dom dla mojego imienia. Nie wybrałem też nikogo, aby uczynić go wodzem mojego ludu, Izraela.
###### **2Krn 6,6**
 Teraz wybrałem sobie Jerozolimę dla mojego imienia i wybrałem Dawida, aby postawić go nad moim ludem, Izraelem».
###### **2Krn 6,7**
 To właśnie w sercu mojego ojca Dawida zrodziła się myśl, aby wybudować dom dla imienia PANA, Boga Izraela.
###### **2Krn 6,8**
 Lecz PAN powiedział do Dawida, ojca mojego: «Postanowienie, które zrodziło się w twoim sercu, aby wybudować dom ku czci mojego imienia, jest dobre, gdyż zrodziło się w twoim sercu.
###### **2Krn 6,9**
 Nie ty go jednak zbudujesz, ale twój syn, który się tobie urodzi. On zbuduje dom dla mojego imienia».
###### **2Krn 6,10**
 PAN spełnił więc swoją obietnicę: oto stałem się następcą mego ojca Dawida, zasiadając na tronie Izraela, jak PAN zapowiedział, i wybudowałem dom dla imienia PANA, Boga Izraela.
###### **2Krn 6,11**
 Umieściłem w nim arkę. W niej znajduje się Przymierze PANA, które zawarł z Izraelitami”.
###### **2Krn 6,12**
 Król stanął przed ołtarzem PANA na czele całego zgromadzenia Izraela i wyciągnął ręce.
###### **2Krn 6,13**
 Salomon zbudował bowiem podwyższenie z brązu i umieścił je na środku wielkiego dziedzińca. Było ono długie i szerokie na pięć łokci i wysokie na trzy łokcie. Kiedy wszedł na nie, ukląkł wobec całego zgromadzenia Izraela i wzniósł ręce ku niebu,
###### **2Krn 6,14**
 mówiąc: „O PANIE, Boże Izraela, nikt Tobie nie dorówna! Ty jesteś Bogiem nieba i ziemi. Ty jesteś wierny przymierzu i okazujesz dobroć swoim sługom, którzy postępują wobec Ciebie w szczerości serca.
###### **2Krn 6,15**
 Dotrzymałeś słowa Twojemu słudze Dawidowi, memu ojcu, i dzisiaj wypełniłeś swoje przyrzeczenie.
###### **2Krn 6,16**
 PANIE, Boże Izraela, dotrzymaj teraz obietnicy, którą dałeś Twojemu słudze, a mojemu ojcu, Dawidowi, mówiąc: «Nie zabraknie ci następcy, który będzie stał przed moim obliczem i zasiadał na tronie Izraela, jeśli twoi potomkowie będą usilnie starali się postępować zgodnie z moim Prawem, tak jak ty postępujesz wobec Mnie».
###### **2Krn 6,17**
 PANIE, Boże Izraela, niech teraz Twoje słowo, które dałeś Twojemu słudze Dawidowi, okaże się niezawodne.
###### **2Krn 6,18**
 Czy jednak naprawdę Bóg zamieszka na ziemi pośród ludzi? Przecież niebo nieogarnione nie może Ciebie objąć, a cóż dopiero ten dom, który zbudowałem.
###### **2Krn 6,19**
 Usłysz moją modlitwę i błaganie, o PANIE, mój Boże, spójrz na modlitwę Twojego sługi i na jego błaganie.
###### **2Krn 6,20**
 Niech Twoje oczy będą zwrócone w dzień i w nocy na ten dom, na miejsce, które wybrałeś dla Twojego imienia. Wysłuchaj modlitwy, którą Twój sługa wznosi w tym miejscu.
###### **2Krn 6,21**
 Wysłuchaj błagania Twego sługi i Twego ludu, Izraela. Ilekroć będą modlić się w tym miejscu, Ty wysłuchaj ich w miejscu, gdzie przebywasz - w niebie. A kiedy wysłuchasz, przebacz.
###### **2Krn 6,22**
 Jeśli ktoś zgrzeszy przeciw swojemu bliźniemu i zostanie zobowiązany do złożenia przysięgi ze złorzeczeniem wobec Twojego ołtarza w tym domu,
###### **2Krn 6,23**
 Ty usłysz w niebie, działaj i osądź swoje sługi. Winnemu wymierz karę, niech poniesie skutki swego postępowania, niewinnego zaś uwolnij od zarzutów, stwierdzając jego niewinność.
###### **2Krn 6,24**
 Jeśli Twój lud, Izrael, po klęsce zadanej mu przez wroga za to, że zgrzeszył przeciwko Tobie, powróci do Ciebie, odda cześć Twojemu imieniu, będzie modlił się i zanosił prośby do Ciebie w tym domu,
###### **2Krn 6,25**
 Ty wysłuchaj z nieba i przebacz grzech Twojego ludu, Izraela. Pozwól im wrócić do kraju, który dałeś im i ich przodkom.
###### **2Krn 6,26**
 Kiedy niebo będzie zamknięte i nie będzie deszczu, ponieważ zgrzeszyli przeciwko Tobie, potem jednak będą modlić się do Ciebie w tym miejscu, oddadzą cześć Twojemu imieniu i odwrócą się od swego grzechu, bo ich dotkniesz nieszczęściem,
###### **2Krn 6,27**
 Ty wysłuchaj z nieba i przebacz grzech Twoich sług i Twego ludu, Izraela, gdyż wskażesz mu właściwą drogę postępowania i ześlesz deszcz na ziemię, którą dałeś Twojemu ludowi na własność.
###### **2Krn 6,28**
 Kiedy kraj zostanie dotknięty głodem lub zarazą, suszą albo rdzą zbożową, plagą szarańczy lub robactwa, kiedy z którejkolwiek strony uderzy na niego nieprzyjaciel albo porazi go jakieś nieszczęście lub choroba,
###### **2Krn 6,29**
 wszystkie modlitwy i błagania zanoszone w tym domu przez każdego z osobna i przez cały Twój lud izraelski, przejęty nieszczęściem i karą,
###### **2Krn 6,30**
 Ty usłysz w niebie, w miejscu Twojego przebywania. Przebacz, działaj, uczyń każdemu według jego postępowania, znasz bowiem jego serce. Tylko Ty przenikasz serce człowieka.
###### **2Krn 6,31**
 Wtedy przez cały czas swego pobytu na ziemi, którą dałeś naszym przodkom, będą żyli w bojaźni przed Tobą, krocząc drogami, które im wskazałeś.
###### **2Krn 6,32**
 Również cudzoziemca, który nie należy do Twojego ludu, Izraela, a który przybędzie z dalekiego kraju ze względu na Twoje wielkie imię, na Twoją mocną rękę i wzniesione ramię, aby się modlić w tym domu,
###### **2Krn 6,33**
 Ty usłysz w niebie, w miejscu Twojego przebywania. Spełnij to, o co ten cudzoziemiec będzie Cię prosił. Niech wszystkie ludy ziemi poznają Twoje imię i niech postępują w bojaźni przed Tobą na wzór Twego ludu, Izraela. Niech się dowiedzą, że dom, który zbudowałem, nosi Twoje imię.
###### **2Krn 6,34**
 Jeśli Twój lud zgodnie z Twoim wskazaniem wyruszy, aby walczyć z nieprzyjaciółmi, i w drodze będzie modlił się do Ciebie, zwracając się ku temu miastu, które wybrałeś, i ku domowi, który zbudowałem dla Twojego imienia,
###### **2Krn 6,35**
 wtedy wysłuchaj z nieba ich modlitwy i błagania, i okaż im sprawiedliwość.
###### **2Krn 6,36**
 Jeśli zgrzeszą przeciwko Tobie, gdyż nikt nie jest wolny od grzechu, a Ty rozgniewasz się na nich i wydasz ich w ręce nieprzyjaciół, którzy wezmą ich w niewolę i przesiedlą do dalekiego lub bliskiego kraju,
###### **2Krn 6,37**
 oni zaś okażą szczerą skruchę w ziemi, do której zostali uprowadzeni, i będą Cię błagać o zmiłowanie w ziemi swoich ciemiężycieli, wyznając: «Zgrzeszyliśmy, zawiniliśmy, popełniliśmy nieprawość»,
###### **2Krn 6,38**
 jeśli więc nawrócą się do Ciebie całym swoim sercem i całą swoją duszą w ziemi, do której zostali uprowadzeni, i będą modlić się, zwracając się ku ziemi, którą dałeś ich przodkom, ku miastu, które wybrałeś, i ku temu domowi, który wybudowałem ku czci Twojego imienia,
###### **2Krn 6,39**
 wtedy wysłuchaj z nieba, z miejsca Twego przebywania, ich modlitwy i okaż im sprawiedliwość. Przebacz swojemu ludowi, który zgrzeszył przeciwko Tobie.
###### **2Krn 6,40**
 Tak więc, mój Boże, niech Twoje oczy będą otwarte, a uszy zasłuchane w modlitwę, jaka wznosi się z tego miejsca.
###### **2Krn 6,41**
 Teraz, PANIE, Boże, wyrusz na miejsce Twojego przebywania wraz z arką Twojej potęgi! Niech Twoi kapłani, PANIE, Boże, ubiorą się w zbawienie, a Twoi wierni niech cieszą się dobrobytem.
###### **2Krn 6,42**
 PANIE, Boże, nie odrzucaj swego pomazańca! Pamiętaj o łaskach, których udzieliłeś swemu słudze, Dawidowi”.
# 2Krn 6 BP
###### **2Krn 6,1**
 I rzekł wtedy Salomon: Jahwe powiedział, że będzie mieszkał w ciemności.
###### **2Krn 6,2**
 A oto ja zbudowałem Dom na mieszkanie dla Ciebie i miejsce, abyś w nim przebywał na wieki.
###### **2Krn 6,3**
 Następnie król odwrócił się i błogosławił całe zgromadzenie Izraela - a całe zgromadzenie Izraela stało -
###### **2Krn 6,4**
 i rzekł: Błogosławiony Jahwe, Bóg Izraela, który ustami swymi przemówił do ojca mego Dawida i własnymi rękoma wypełnił to, [co przyrzekł]. A mówił tak:
###### **2Krn 6,5**
 "Od dnia, w którym to wyprowadziłem lud mój z ziemi egipskiej, nie wybrałem spośród wszystkich pokoleń izraelskich miasta, aby w nim zbudowano Dom, gdzie by przebywało Imię moje, ani też nie obrałem męża, który byłby wodzem mego ludu izraelskiego,
###### **2Krn 6,6**
 lecz wybrałem Jeruzalem, by tam przebywało Imię moje, wybrałem też Dawida, aby przewodził ludowi memu izraelskiemu."
###### **2Krn 6,7**
 Ojciec mój, Dawid, pragnął zbudować Dom dla Imienia Jahwe, Boga Izraela.
###### **2Krn 6,8**
 Ale Jahwe rzekł do Dawida, ojca mego: "Postanowiłeś zbudować Dom dla Imienia mego i dobrze uczyniłeś, żeś powziął to zamierzenie w sercu swoim.
###### **2Krn 6,9**
 Nie ty wszakże będziesz Dom budował, lecz syn, który się z ciebie narodzi, on to zbuduje Dom dla Imienia mego."
###### **2Krn 6,10**
 I spełnił Jahwe zapowiedź swoją, bo oto ja przyszedłem po ojcu moim, Dawidzie, i zasiadłem na tronie Izraela, jak to przyrzekł Jahwe, i zbudowałem Dom dla Imienia Jahwe, Boga Izraela.
###### **2Krn 6,11**
 Umieściłem tam również Arkę, w której znajduje się Przymierze Jahwe, jakie zawarł On z synami Izraela.
###### **2Krn 6,12**
 Następnie stanął Salomon przed ołtarzem Jahwe i wobec całego zgromadzenia Izraela wyciągnął swoje ręce.
###### **2Krn 6,13**
 Zbudował bowiem Salomon podwyższenie ze spiżu, które ustawił pośrodku dziedzińca. Długość jego wynosiła pięć łokci, szerokość pięć łokci, a wysokość trzy łokcie. Wstąpił na nie, upadł na kolana wobec całego zgromadzenia Izraela i wyciągnąwszy ręce ku niebu,
###### **2Krn 6,14**
 rzekł: Jahwe, Boże Izraela, nie ma Boga na niebie i na ziemi podobnego Tobie; dochowujesz Przymierza i obdarzasz łaską sługi swoje, którzy postępują przed Tobą w szczerości swego serca.
###### **2Krn 6,15**
 Dotrzymałeś obietnicy danej słudze Twemu, a mojemu ojcu, Dawidowi: coś przyrzekł ustami, dziś czynem wypełniłeś.
###### **2Krn 6,16**
 Teraz więc, o Jahwe, Boże Izraela, dopełnij tego, coś przyrzekł słudze twemu a mojemu ojcu, Dawidowi, gdyś wyrzekł: "Zawsze będzie zasiadał twój potomek przed moim obliczem na tronie Izraela, jeśli tylko synowie twoi będą przestrzegać sposobu życia i postępowania według prawa mego, tak jak ty postępowałeś wobec mnie."
###### **2Krn 6,17**
 Niechże więc teraz, o Jahwe, Boże Izraela, dopełni się słowo Twoje, któreś wyrzekł do sługi Twego, Dawida.
###### **2Krn 6,18**
 Czyż naprawdę jednak Bóg zamieszka z człowiekiem na ziemi? Oto niebiosa i niebos niebiosa nie mogą Cię ogarnąć, o ileż mniej ten Dom, który ja zbudowałem.
###### **2Krn 6,19**
 Nakłoń ucha na modlitwę sługi Twego i prośbę jego, o Jahwe, Boże mój! Wysłuchaj wołanie i modlitwy, które sługa Twój zanosi do Ciebie.
###### **2Krn 6,20**
 Niechaj oczy Twoje zwrócone będą na ten Dom we dnie i w nocy. Wszak to jest miejsce, o którym powiedziałeś, że tu przebywać będzie Imię Twoje, abyś wysłuchał modlitwy, jaką na tym miejscu będzie zanosił Twój sługa.
###### **2Krn 6,21**
 Wysłuchaj błagania sługi Twego, a także ludu Twego izraelskiego, gdy modlić się będą na tym miejscu. Wysłuchaj z miejsca, które zamieszkujesz w niebiosach, wysłuchaj i przebacz!
###### **2Krn 6,22**
 Gdy zgrzeszy człowiek przeciw bliźniemu swemu i wezwany do złożenia przysięgi stawi się, żeby przysiąc przed Twym ołtarzem w tym Domu,
###### **2Krn 6,23**
 wtedy Ty zechciej wysłuchać z nieba i racz rozsądzić pomiędzy sługami Twymi; potęp bezbożnego oddając mu według postępowania jego, a uniewinnij sprawiedliwego osądzając go według uczciwości jego.
###### **2Krn 6,24**
 Kiedy Twój lud izraelski zostanie rozgromiony przez nieprzyjaciół, ponieważ zgrzeszył przeciw Tobie, ale potem nawróci się i będzie wielbił Imię Twoje, i będzie modlił się i zanosił do Ciebie błagania w tym Domu,
###### **2Krn 6,25**
 wtedy Ty wysłuchaj z nieba i odpuść grzech ludowi Twemu izraelskiemu, i przywróć go do ziemi, którą oddałeś jemu oraz jego ojcom.
###### **2Krn 6,26**
 Kiedy zamknie się niebo i deszcz przestanie padać, dlatego że zgrzeszyli przeciw Tobie, lecz zaczną się modlić na tym miejscu i będą wielbić Imię Twoje, a odwrócą się od swych grzechów, ponieważ ich ukarałeś,
###### **2Krn 6,27**
 Ty zechciej wysłuchać z nieba i odpuść grzech sług Twoich i Twego ludu izraelskiego. Naucz ich drogi prawej, po której mają postępować, i spuść deszcz na Twoją ziemię, którą dałeś w dziedzictwie ludowi swemu.
###### **2Krn 6,28**
 Gdy w kraju głód pocznie się szerzyć, wybuchnie zaraza, gdy będzie [w nim] susza, śnieć [zbożowa], szarańcza lub robactwo, gdy nieprzyjaciel oblegnie [lud] w kraju u jego bramy i we wszelkim nieszczęściu czy chorobie,
###### **2Krn 6,29**
 a jeśli ktokolwiek z ludzi albo też cały naród izraelski zaniesie do Ciebie modlitwę i błaganie i każdy w poczuciu swej klęski i bólu wyciągnie ręce ku temu Domowi,
###### **2Krn 6,30**
 Ty zechciej wysłuchać z nieba, z miejsca, które zamieszkujesz, przebacz i oddaj każdemu według postępowania jego, Ty, który znasz jego serce. Ty jeden bowiem znasz serca synów ludzkich,
###### **2Krn 6,31**
 aby się Ciebie lękali i aby postępowali według dróg Twoich po wszystkie dni życia swego na ziemi, którą dałeś ojcom naszym.
###### **2Krn 6,32**
 Także i cudzoziemiec, który nie należy do Twego ludu izraelskiego, gdy przybędzie z ziemi odległego kraju dla wielkiego Imienia Twego, potężnej ręki Twojej i wyciągniętego ramienia Twego, i modlić się będzie w tym Domu,
###### **2Krn 6,33**
 Ty zechciej wysłuchać z nieba, z miejsca, które zamieszkujesz, i uczynić wszystko, o co wołać będzie do Ciebie ten cudzoziemiec, ażeby wszystkie ludy ziemi poznały Imię Twoje i bały się Ciebie, jako i lud Twój izraelski, i ażeby wiedziały, że Imię Twe było wzywane nad tym Domem, który ja zbudowałem.
###### **2Krn 6,34**
 Kiedy lud Twój wyruszy na wojnę przeciw nieprzyjaciołom swoim drogą, na którą go skierujesz, a będzie się modlił zwrócony ku temu miastu, któreś wybrał, i ku Domowi, który zbudowałem
###### **2Krn 6,35**
 dla Imienia Twego, zechciej wysłuchać z niebios jego modlitwę i błaganie i oddaj mu sprawiedliwość.
###### **2Krn 6,36**
 Gdy zgrzeszą przeciw Tobie - bo przecież nie ma człowieka, który by nie grzeszył - a Ty rozgniewawszy się na nich wydasz ich w ręce wrogów, którzy pojmanych uprowadzą w niewolę do ziemi dalekiej lub bliskiej,
###### **2Krn 6,37**
 oni zaś w ziemi, do której zostali uprowadzeni, zaczną pokutować, a nawróciwszy się będą się modlić do Ciebie w kramie swej niewoli, mówiąc: "Zgrzeszyliśmy, źleśmy uczynili, popełniliśmy czyny bezbożne",
###### **2Krn 6,38**
 i nawrócą się do Ciebie z całego serca swego i z całej duszy swojej w kraju niewoli, dokąd zostali uprowadzeni, i będą się modlić zwróceni do swego kraju, który dałeś ich ojcom, i w stronę miasta, które wybrałeś, oraz Domu, który zbudowałem dla Imienia Twego,
###### **2Krn 6,39**
 racz wtedy wysłuchać z nieba, z miejsca, które zamieszkujesz, modlitwę ich i błaganie. Oddaj im sprawiedliwość i zechciej przebaczyć ludowi Twemu, który zgrzeszył przeciwko Tobie!
###### **2Krn 6,40**
 A teraz proszę, Boże mój, niech oczy Twe będą otwarte, a uszy Twe czułe na modlitwę zanoszoną w tym miejscu.
###### **2Krn 6,41**
 Powstań więc teraz, o Jahwe, Boże, i wejdź do miejsca Twego spoczynku, ty i Arka mocy Twojej. Niech się kapłani Twoi, o Jahwe, Boże, przyobleką w zbawienie, a święci Twoi niech się radują w pomyślności.
###### **2Krn 6,42**
 O Jahwe, Boże, nie odwracaj oblicza od pomazańca Twego, pamiętaj o łaskach [przyrzeczonych] Dawidowi, słudze Twemu!
# 2Krn 6 BR
###### **2Krn 6,1**
 Wtedy powiedział Salomon; Jahwe pragnie zamieszkać w mrokach.
###### **2Krn 6,2**
 A ja zbudowałem Ci dom na zamieszkanie, przygotowałem Ci miejsce, w którym mógłbyś pozostawać na wieki.
###### **2Krn 6,3**
 Potem odwrócił się król i pobłogosławił zgromadzenie synów Izraela. Wszyscy zaś zgromadzeni Izraelici stali.
###### **2Krn 6,4**
 A Salomon mówił: Niech będzie błogosławiony Jahwe, Bóg Izraela, który własnymi przemówił ustami do ojca mojego, Dawida, a potem własnymi rękami wypełnił to, co tak przepowiedział:
###### **2Krn 6,5**
 Od czasu wyprowadzenia mojego ludu z Egiptu nie wyznaczyłem wśród wszystkich pokoleń izraelskich żadnego miasta i nie domagałem się, żeby tam budowano dom dla mojego imienia, ani też nie wybrałem sobie człowieka, który miałby być przywódcą mojego narodu izraelskiego.
###### **2Krn 6,6**
 Tylko Jerozolimę wybrałem na miejsce zamieszkania dla mojego imienia, a Dawida ustanowiłem królem nad całym moim ludem izraelskim.
###### **2Krn 6,7**
 Mój ojciec, Dawid, pragnął zbudować dom dla imienia Jahwe, Boga Izraela.
###### **2Krn 6,8**
 Ale Jahwe powiedział do Dawida: To dobrze, że zapragnąłeś zbudować dom dla mojego imienia.
###### **2Krn 6,9**
 Ale to nie ty zbudujesz mi dom. To twój syn, ten, którego ty zrodzisz, zbuduje dom dla mojego imienia.
###### **2Krn 6,10**
 I tak wypełniły się słowa wypowiedziane kiedyś przez Jahwe: ja nastałem po moim ojcu, Dawidzie, ja zasiadłem na tronie Izraela, zgodnie z tym, co powiedział Jahwe; ja również zbudowałem świątynię dla imienia Jahwe, Boga Izraela.
###### **2Krn 6,11**
 i umieściłem w niej arkę tego przymierza, które Jahwe zawarł z synami Izraela.
###### **2Krn 6,12**
 Potem stanął Salomon przed ołtarzem Jahwe i wyciągnął ręce nad zgromadzonym Izraelem.
###### **2Krn 6,13**
 Wcześniej jeszcze kazał sporządzić podwyższenie z brązu i ustawić je pośrodku dziedzińca. Długość podwyższenia wynosiła pięć łokci, szerokość również pięć łokci, a wysokość trzy łokcie. na to właśnie podwyższenie wstąpił Salomon i upadł na kolana i obecności całego zgromadzenia izraelskiego. Podniósłszy ręce, zaczął się modlić, mówiąc;
###### **2Krn 6,14**
 O Jahwe, Boże Izraela, boga Tobie równego nie ma ani na niebiosach, ani na ziemi. Nikt tak jak Ty nie zachowuje przymierza i nie okazuje miłosierdzia swoim sługom, jeśli tylko z całego serca starają się być blisko Ciebie.
###### **2Krn 6,15**
 Wypełniłeś wszystko, co obiecałeś twojemu słudze, Dawidowi, mojemu ojcu. To, co zapowiedziałeś własnymi ustami, własnymi rękami wypełniłeś, a wszyscy jesteśmy dziś tego świadkami.
###### **2Krn 6,16**
 Racz tedy, o Jahwe, Boże Izraela, uczynić ze względu na ojca mojego, a Twojego sługę, Dawida, wszystko, co mu kiedyś obiecałeś mówiąc: Nigdy nie zabraknie ci wobec Mnie potomka, który będzie zasiadał na tronie izraelskim, jeśli tylko synowie twoi będą chodzili moimi drogami, tak jak Ty kroczyłeś zawsze moja drogą.
###### **2Krn 6,17**
 Niech więc teraz, o Jahwe, Boże Izraela, wypełni się to, co powiedziałeś słudze Swojemu, Dawidowi.
###### **2Krn 6,18**
 Ale czy rzeczywiście Bóg zamieszka z ludźmi na ziemi? Przecież nawet niebiosa i niebiosa niebios nie są w stanie objąć Ciebie, Boże! Czyż więc potrafi Cię pomieścić dom przeze mnie zbudowany?
###### **2Krn 6,19**
 Ale racz, o Jahwe, Boże mój, wysłuchać próśb i błagań Swojego sługi. Niech dotrą do Ciebie słowa błagania, które sługa Twój zanosi do Ciebie.
###### **2Krn 6,20**
 Zechciej mieć we dnie i w nocy oczy zwrócone na ten przybytek oraz na to miejsce, o którym powiedziałeś, że zamieszka tam Twoje imię. Racz też wysłuchać modlitwy, którą Twój sługa będzie do Ciebie zanosił z tego miejsca.
###### **2Krn 6,21**
 Niech dociera do Ciebie głos Twojego sługi oraz całego ludu izraelskiego, gdy będzie zanosić błagania, modląc się na tym miejscu. Wysłuchaj ich z miejsca Swego przebywania w niebie, wysłuchaj i udziel przebaczenia!
###### **2Krn 6,22**
 Kiedy się zdarzy, że ktoś zgrzeszy przeciwko swemu bliźniemu, a ten, który doznał krzywdy, zezna to pod przysięgą tu, w Twoim domu, przed tym ołtarzem,
###### **2Krn 6,23**
 wtedy racz go wysłuchać z niebios i spraw, żeby były wydane słuszne wyroki na Twoje sługi: niech winny zostanie potępiony, niech jego grzech spadnie na jego głowę, a niewinny niech będzie uznany z niewinnego i niech mu się stanie według jego niewinności.
###### **2Krn 6,24**
 Kiedy się zdarzy, że Twój lud izraelski zostanie pokonany przez swoich wrogów, ponieważ sprzeniewierzył się Tobie, wtedy jeśli się tylko opamięta i złoży chwałę Twojemu imieniu, jeśli zacznie zanosić do Ciebie prośby i błagania w tym domu -
###### **2Krn 6,25**
 wysłuchaj go z nieba; przebacz Swojemu ludowi izraelskiemu jego grzechy i sprowadź go znów do kraju, który dałeś w posiadanie jemu oraz jego ojcom.
###### **2Krn 6,26**
 Kiedy się zdarzy, że niebiosa zostaną zamknięte i nie spadnie na nich żadna kropla deszczu, ponieważ sprzeniewierzyli się Tobie, wtedy jeśli zaczną zanosić do Ciebie modły i składać na tym miejscu chwałę Twojemu imieniu, jeśli się odwrócą od swoich występków dlatego, że zsyłałeś na nich dotkliwe kary -
###### **2Krn 6,27**
 racz ich wysłuchać z nieba, przebacz grzechy Swoim sługom i Swojemu ludowi izraelskiemu, wskaż im drogę prawości, którą winni kroczyć, i spraw, żeby deszcz znów spadł na ziemię, którą dałeś w dziedzictwo swojemu ludowi.
###### **2Krn 6,28**
 Kiedy głód nawiedzi kraj, kiedy przyjdzie zaraza, susza, śnieć zbożowa, szarańcza lub chasil, kiedy wróg zacznie oblegać Twój lud, podchodząc pod same bramy jego siedzib, kiedy spadnie nań jakaś inna klęska lub zaraza,
###### **2Krn 6,29**
 wtedy jeśli usłyszysz prośby i błagania pojedynczych ludzi albo całego narodu izraelskiego, jeśli znękany nieszczęściami i bólem zacnie on wyciągać ręce w stronę tego przybytku -
###### **2Krn 6,30**
 racz wysłuchać go z niebios, z miejsca Swojego przebywania, i udziel mu przebaczenia. Oddaj każdemu według dróg jego, Ty, który znasz serce każdego - bo tylko Ty przenikasz tajniki serc ludzkich.
###### **2Krn 6,31**
 Niech zaczną żyć w bojaźni przed Tobą i niech chodzą drogami Twoimi, jak długo żyć będą na tej ziemi, którą niegdyś dałeś ich ojcom.
###### **2Krn 6,32**
 Kiedy się zdarzy, że jakiś cudzoziemiec, czyli człowiek nie należący do Twego ludu izraelskiego, przybędzie z daleka, usłyszawszy o Twoim wielkim imieniu, o Twojej ręce silnej i wyciągniętym ramieniu, kiedy taki przybędzie i zacznie zanosić modły w tym przybytku,
###### **2Krn 6,33**
 wtedy racz go wysłuchać z niebios, z miejsca Swojego przebywania, i uczyń wszystko, o co będzie prosił. W ten sposób wszystkie narody ziemi poznają Twoje imię i zaczną żyć w bojaźni przed Tobą, tak jak Twój naród izraelski; niech się dowiedzą wszyscy, że Twoje imię jest wzywanie w tym świętym domu, który ja zbudowałem dla Ciebie.
###### **2Krn 6,34**
 Kiedy Twój naród wyruszy na wojnę przeciwko swoim wrogom, trzymając się drogi, którą mu wskażesz, i zacznie się modlić do Ciebie, zwracając swoją twarz w stronę miasta, w którym sobie upodobałeś, i ku przybytkowi, zbudowanemu przeze mnie dla Twojego imienia,
###### **2Krn 6,35**
 wtedy racz wysłuchać z niebios ich błagania i prośby i okaż im Swoją sprawiedliwość.
###### **2Krn 6,36**
 Kiedy będą grzeszyć przeciw Tobie - bo przecież nie ma człowieka, który by nie grzeszył - Ty zaś, rozgniewawszy się na nich, wydasz ich w ręce wroga, a wróg ów, zadawszy im klęskę, uprowadzi ich do niewoli, do kraju odległego lub bliskiego,
###### **2Krn 6,37**
 to jeśli oni, zastanowiwszy się nad sobą na miejscu swego uwięzienia, zwrócą się do Ciebie i zaczną Cię błagać ze swego wygnania, mówiąc: Zgrzeszyliśmy, dopuściliśmy się nieprawości, sprzeniewierzyliśmy się Tobie;
###### **2Krn 6,38**
 jeśli nawrócą się ku tobie z całego swojego serca na miejscu swojej niewoli, do której zostali uprowadzeni; jeśli zaczną Cię błagać o pomoc, zwracając swoje oblicze ku krainie, którą dałeś w dziedzictwo ich ojcom, ku temu miastu, w którym sobie upodobałeś, i ku przybytkowi, który zbudowałem dla Twojego imienia -
###### **2Krn 6,39**
 racz wysłuchać z niebios, z miejsca Swojego przebywania, ich prośby i błagania, okaż im swoją sprawiedliwość i przebacz Swojemu ludowi jego wykroczenia przeciw tobie.
###### **2Krn 6,40**
 Niech więc teraz, o Boże, będą otwarte Twoje oczy, a Twoje uszy nadstawione ku błaganiom, które będą zanosić z tego miejsca!
###### **2Krn 6,41**
 Powstań więc, o Jahwe, Boże mój, przybądź na miejsce Swego odpocznienia, Ty sam oraz arka Twojej potęgi. Niech Twoi kapłani, o Jahwe, Boże mój, przyodzieją się w zbawienie, niech Twoi święci radują się szczęściem.
###### **2Krn 6,42**
 O Jahwe, Boże mój, nie odwracaj swojego oblicza od Twego pomazańca. Wspomnij na dobrodziejstwa, którymi obsypałeś sługę Swojego, Dawida.
# 2Krn 6 WUJ
###### **2Krn 6,1**
 Rzekł tedy Salomon: Pan obiecał, że miał mieszkać we mgle:
###### **2Krn 6,2**
 A jam zbudował dom imieniowi jego, aby tam mieszkał na wieki.
###### **2Krn 6,3**
 I obrócił król oblicze swe, i błogosławił wszystkiemu mnóstwu Izraelskiemu (bo wszystka rzesza stała pilnie patrząc) i rzekł:
###### **2Krn 6,4**
 Błogosławiony Pan Bóg Izraelski, który co mówił Dawidowi ojcu memu, skutkiem wypełnił, mówiąc:
###### **2Krn 6,5**
 Ode dnia, któregom wywiódł lud mój z ziemie Egiptskiej, nie obrałem miasta ze wszech pokoleni Izraelskich, aby w niem zbudowano dom imieniowi memu: anim obrał żadnego innego męża, aby był wodzem ludu mego Izraelskiego:
###### **2Krn 6,6**
 Alem obrał Jeruzalem, aby w niem było imię moje: i obrałem Dawida, abym go postanowił nad ludem moim Izraelskim,
###### **2Krn 6,7**
 A gdy była wola Dawida ojca mego, żeby zbudował dom imieniowi Pana Boga Izraelskiego.
###### **2Krn 6,8**
 Rzekł Pan do niego: Iż ta była wola twoja, żebyś zbudował dom imieniowi memu, dobrześ w prawdzie uczynił, żeś miał taką wolą.
###### **2Krn 6,9**
 Ale nie ty zbudujesz ten dom, ale syn twój, który wynidzie z biódr twoich, on zbuduje dom imieniowi memu.
###### **2Krn 6,10**
 Ziścił tedy Pan mowę swoję, którą był powiedział: a jam powstał na miejsce Dawida ojca mego, i usiadłem na stolicy izraelskiej, jako Pan powiedział, i zbudowałem dom imieniowi Pana Boga Izraelskiego.
###### **2Krn 6,11**
 I postawiłem w nim skrzynię, w której jest przymierze Pańskie, które uczynił z synmi Izraelskimi.
###### **2Krn 6,12**
 Stanął tedy przed ołtarzem Pańskim, przeciwko wszemu zgromadzeniu ludu Izraelskiego, i rozciągnął ręce swe.
###### **2Krn 6,13**
 Bo był Salomon sprawił podstawek miedziany, i postawił ji w pośród kościoła mający pięć łokiet wzdłuż a pięć łokiet wszerz, a trzy łokcie wzwyż. I stanął na nim: a po tem poklęknąwszy na kolana ku wszystkiemu mnóstwu Izraelskiemu, i podniósszy ręce ku niebu.
###### **2Krn 6,14**
 Rzekł: Panie Boże Izraelski, niemasz tobie podobnego Boga na niebie i na ziemi: który strzeżesz przymierza i miłosierdzia z sługami twoimi, którzy chodzą przed tobą we wszystkiem sercu swem:
###### **2Krn 6,15**
 Któryś ziścił słudze twemu Dawidowi ojcu memu cokolwiekeś mówił do niego: i coś był usty obiecał skutkiemeś wypełnił, jako i niniejszy czas pokazuje.
###### **2Krn 6,16**
 Teraz tedy Panie Boże Izraelski, spełni słudze twemu Dawidowi ojcu memu, cokolwiekeś rzekł, mówiąc: Nie ustanie z ciebie mąż przedemną, któryby siedział na stolicy Izraelskiej: wszakże tak jeśli strzedz będą synowie twoi dróg swoich, i będą chodzić w zakonie moim, jakoś i ty chodził przedemną.
###### **2Krn 6,17**
 A teraz Panie Boże Izraelski, niech się utwierdzi mowa twoja, którąś powiedział słudze twemu Dawidowi.
###### **2Krn 6,18**
 A więc to podobna rzecz, aby mieszkał Bóg z ludźmi na ziemi? Jeśli niebo i niebiosa nad niebiosy ciebie nie ogarniają, jako daleko więcej ten dom, którym zbudował?
###### **2Krn 6,19**
 Ale na to tylko jest uczyniony, abyś wejrzał na modlitwę sługi twego i na prośbę jego Panie Boże mój, a żebyś wysłuchał prośby, które wylewa sługa twój przed tobą:
###### **2Krn 6,20**
 Abyś otworzył oczy twe nad domem tym we dnie i w nocy, nad miejscem, na któremeś obiecał, że miało być wzywane imię twoje.
###### **2Krn 6,21**
 Ażeś miał wysłuchać modlitwę, którą się sługa twój na niem modli. I abyś wysłuchał prośby sługi twego, i ludu twego Izraelskiego. Ktokolwiek się będzie modlił na tem miejscu, wysłuchaj z mieszkania twego, to jest z niebios, a bądź miłościw.
###### **2Krn 6,22**
 Jeśliby kto zgrzeszył przeciw bliźniemu swemu, a przyszedłby gotów przysiądz przeciw jemu, a obwiązałby się klątwą przed ołtarzem w tym domu:
###### **2Krn 6,23**
 Ty wysłuchasz z nieba, i uczynisz sąd sług twoich, tak, żebyś oddał nieprawemu drogę jego na własną głowę, a żebyś się zemścił sprawiedliwego, oddawając mu według sprawiedliwości jego.
###### **2Krn 6,24**
 Jeśliby zwyciężon był lud twój Izraelski od nieprzyjaciół (boć będą grzeszyć przeciw tobie), a nawróciwszy się czyniliby pokutę, i prosiliby imienia twego, i modlili się na tem miejscu:
###### **2Krn 6,25**
 Ty wysłuchasz z nieba, a bądź miłościw grzechowi ludu twego Izraelskiego, a przywróć je do ziemie, którąś im dał i ojcom ich.
###### **2Krn 6,26**
 Jeśliby za zamknieniem nieba deszcz nie padał, dla grzechów ludu, a odpraszaliby cię na tem miejscu, i wyznawali imieniowi twemu i nawróciliby się od grzechów swoich, gdy je utrapisz,
###### **2Krn 6,27**
 Wysłuchaj z nieba Panie, a odpuść grzechy sługam twoim, i ludu twego Izraelskiego, a naucz ich drogi dobrej, którąby chodzili: a daj deszcz ziemi, którąś dał na osiadłość ludowi twemu.
###### **2Krn 6,28**
 Głód, jeśliby się zaczął w ziemi, i powietrze morowe, rdza i susza, i szarańcza, chrząszcze, i nieprzyjaciele, jeśliby pustoszywszy krainy obiegli bramy miasta, i wszelka plaga i choroba, jeśliby ucisnęła:
###### **2Krn 6,29**
 Jeśliby kto z ludu twego Izraelskiego modlił się, poznawszy karanie i chorobę swoję, a wyciągnąłby ręce swe w tym domu.
###### **2Krn 6,30**
 Ty wysłuchasz z nieba to jest z wysokiego mieszkania twego, a zmiłuj się, i oddaj każdemu według dróg jego, które wiesz, że ma w sercu swojem: (ty bowiem sam znasz serca synów ludzkich).
###### **2Krn 6,31**
 Aby się bali ciebie, i chodzili drogami twemi po wszystkie dni, których żyją na ziemi, którąś dał ojcom naszym.
###### **2Krn 6,32**
 Obcego też, który nie jest z ludu twego Izraelskiego, jeśliby przyszedł z ziemie dalekiej, dla imienia twego wielkiego, i dla mocnej ręki twojej, i wyciągnionego ramienia twego, a pokłoniłby się na tem miejscu:
###### **2Krn 6,33**
 Ty wysłuchasz z nieba mocnego mieszkania twego, i uczynisz wszystko o co cię będzie wzywać on cudzoziemiec: aby poznali wszyscy narodowie ziemie imię twoje, i bali się ciebie, jako i lud twój Izraelski. Ażeby poznali, iż wzywane jest imię twe nad tym domem, którymem zbudował.
###### **2Krn 6,34**
 Jeśliby lud twój wyciągnął na wojnę przeciw nieprzyjaciołom swym drogą, którąbyś je posłał, a kłaniać się będą tobie ku drodze, na której to miasto jest, któreś obrał, i dom, którym zbudował imieniowi twemu.
###### **2Krn 6,35**
 Ty wysłuchasz z nieba modlitwy ich i prośby, a pomści się.
###### **2Krn 6,36**
 A jeśliby zgrzeszyli przeciw tobie (boć niemasz człowieka, któryby nie grzeszył), a rozgniewałbyś się na nie a podałbyś je nieprzyjaciołom i zawiedliby je w niewolą do ziemie dalekiej, albo więc która jest blizko:
###### **2Krn 6,37**
 A nawróciwszy się w sercu swem w ziemi, do której w niewolą zawiedzeni byli, czyniliby pokutę i prosiliby cię w ziemi niewolstwa swego, mówiąc: Zgrzeszyliśmy, niezbożnieśmy czynili, niesprawiedliwieśmy się sprawowali:
###### **2Krn 6,38**
 I nawróciliby się do ciebie we wszystkiem sercu swem i we wszystkiej duszy swej w ziemi niewolej swej, do której zagnani są, będąc się kłaniać ku drodze ziemi swej, którąś dał ojcom ich, i miasta, któreś obrał, i domu, którym zbudował imieniowi twemu.
###### **2Krn 6,39**
 Ty wysłuchasz z nieba, to jest z mocnego mieszkania twego prośby ich, a uczyń sąd, i odpuść ludowi twemu, chocia grzesznemu:
###### **2Krn 6,40**
 Tyś bowiem jest Bóg mój: niechaj, proszę, będą otwarte oczy twe, a uszy twe niech będą gotowe ku słuchaniu modlitwy, która się dzieje na tem miejscu.
###### **2Krn 6,41**
 Teraz tedy powstań Panie Boże ku odpoczynieniu twemu, ty i skrzynia mocy twojej: kapłani twoi Panie Boże niechaj będą obleczeni zbawieniem, a święci twoi niechaj się w dobrach radują:
###### **2Krn 6,42**
 Panie Boże, nie odwracaj oblicza pomazańca twego: pamiętaj na miłosierdzia Dawida sługi twego.
