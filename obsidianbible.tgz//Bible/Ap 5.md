# Ap 5 BT5
###### **Ap 5,1**
 I ujrzałem na prawej dłoni Zasiadającego na tronie Księgę zapisaną wewnątrz i na odwrocie opieczętowaną siedmiu pieczęciami.
###### **Ap 5,2**
 I ujrzałem potężnego anioła, obwieszczającego głosem donośnym: «***Kto godzien jest otworzyć księgę i złamać jej pieczęcie?***»
###### **Ap 5,3**
 A nie mógł nikt – na niebie ani na ziemi, ani pod ziemią – otworzyć księgi ani na nią patrzeć.
###### **Ap 5,4**
 A ja bardzo płakałem, że nie znalazł się nikt godny, by księgę otworzyć ani na nią patrzeć.
###### **Ap 5,5**
 I mówi do mnie jeden ze Starców: «***Przestań płakać! Oto zwyciężył Lew z pokolenia Judy, Odrośl Dawida, tak że otworzy księgę i siedem jej pieczęci***».
###### **Ap 5,6**
 I ujrzałem między tronem z czterema Istotami żyjącymi a kręgiem Starców stojącego Baranka, jakby zabitego, a miał siedem rogów i siedmioro oczu, którymi jest siedem Duchów Boga wysłanych na całą ziemię.
###### **Ap 5,7**
 On poszedł i z prawicy Zasiadającego na tronie wziął < księgę >.
###### **Ap 5,8**
 A kiedy wziął księgę, cztery Istoty żyjące i dwudziestu czterech Starców upadło przed Barankiem, każdy mając harfę i złote czasze pełne kadzideł, którymi są modlitwy świętych.
###### **Ap 5,9**
 I taką nową pieśń śpiewają: «***Godzien jesteś wziąć księgę i jej pieczęcie otworzyć, bo zostałeś zabity i krwią Twoją nabyłeś dla Boga [ludzi] z każdego pokolenia, języka, ludu i narodu,***
###### **Ap 5,10**
***i uczyniłeś ich Bogu naszemu królestwem i kapłanami, a będą królować na ziemi***».
###### **Ap 5,11**
 I ujrzałem, i usłyszałem głos wielu aniołów dokoła tronu i Istot żyjących, i Starców, a liczba ich była miriady miriad i tysiące tysięcy,
###### **Ap 5,12**
 mówiących głosem donośnym: «***Baranek zabity jest godzien otrzymać potęgę i bogactwo, i mądrość, i moc, i cześć, i chwałę, i błogosławieństwo***».
###### **Ap 5,13**
 A wszelkie stworzenie, które jest w niebie i na ziemi, i pod ziemią, i na morzu, i wszystko, co w nich przebywa, usłyszałem, jak mówiło: «***Zasiadającemu na tronie i Barankowi błogosławieństwo i cześć, i chwała, i moc, na wieki wieków!***»
###### **Ap 5,14**
 A cztery Istoty żyjące mówiły: «***Amen***». Starcy zaś upadli i oddali pokłon.
# Ap 5 PAU
###### **Ap 5,1**
 W prawej ręce Siedzącego na tronie zobaczyłem zwój zapisany z obu stron i zapieczętowany siedmioma pieczęciami.
###### **Ap 5,2**
 Zobaczyłem też potężnego anioła wołającego donośnym głosem: „Kto jest godny rozwinąć zwój i złamać jego pieczęcie?”.
###### **Ap 5,3**
 A nikt w niebie ani na ziemi, ani pod ziemią nie mógł otworzyć zwoju i do niego zajrzeć.
###### **Ap 5,4**
 Długo płakałem, że nie znalazł się nikt godny rozwinąć zwój i do niego zajrzeć.
###### **Ap 5,5**
 Aż jeden ze starszych rzekł do mnie: „Nie płacz! Oto zwyciężył Lew z plemienia Judy, potomek Dawida! On otworzy zwój i siedem pieczęci”.
###### **Ap 5,6**
 Na środku tronu, wśród czterech istot żywych i pośród starszych zobaczyłem stojącego Baranka - jakby złożonego w ofierze. Miał On siedem rogów i siedmioro oczu, to jest siedem Duchów Boga posłanych na całą ziemię.
###### **Ap 5,7**
 Podszedł, aby wziąć zwój z prawej ręki Siedzącego na tronie.
###### **Ap 5,8**
 Gdy wziął zwój, cztery istoty żywe i dwudziestu czterech starszych upadło przed Barankiem. Każdy z nich miał cytrę i złotą czaszę napełnioną kadzidłem, to jest modlitwami świętych.
###### **Ap 5,9**
 Śpiewali oni pieśń nową: „Jesteś godny wziąć zwój i złamać jego pieczęcie, bo zostałeś zabity i swoją krwią nabyłeś Bogu ludzi z każdego plemienia, języka, ludu i narodu.
###### **Ap 5,10**
 Uczyniłeś ich królestwem i kapłanami dla naszego Boga, więc będą królować na ziemi”.
###### **Ap 5,11**
 Gdy miałem widzenie, usłyszałem też głos licznych aniołów wokół tronu, istot żywych i starszych. Było ich miriady miriad i tysiące tysięcy.
###### **Ap 5,12**
 Mówili potężnym głosem: „Baranek zabity jest godny przyjąć moc, bogactwo, mądrość, potęgę, cześć, chwałę i uwielbienie”.
###### **Ap 5,13**
 Usłyszałem również, jak całe stworzenie w niebie, na ziemi, pod ziemią i na morzu oraz wszystko, co się w nich znajduje, mówiło: „Siedzącemu na tronie i Barankowi uwielbienie, cześć, chwała i panowanie na wieki wieków”.
###### **Ap 5,14**
 Wówczas cztery istoty żywe powiedziały: „Amen”. Starsi zaś upadli i oddali pokłon.
# Ap 5 BP
###### **Ap 5,1**
 Potem ujrzałem na prawej ręce Zasiadającego na tronie księgę zapisaną wewnątrz i zewnątrz, zapieczętowaną na siedem pieczęci.
###### **Ap 5,2**
 I ujrzałem potężnego anioła, obwieszczającego głosem donośnym: "Kto godzien jest otworzyć księgę i złamać jej pieczęcie?"
###### **Ap 5,3**
 A nie mógł nikt - na niebie ani na ziemi, ani pod ziemią - otworzyć księgi ani na nią patrzeć.
###### **Ap 5,4**
 A ja bardzo płakałem, że nikt nie znalazł się godzien, by otworzyć księgę ani patrzeć na nią.
###### **Ap 5,5**
 I mówi do mnie jeden ze Starców: "Przestań płakać: Oto zwyciężył Lew z pokolenia Judy, Odrośl Dawida, tak że otworzy księgę i siedem jej pieczęci".
###### **Ap 5,6**
 I ujrzałem między tronem z czworgiem Zwierząt a kręgiem Starców stojącego Baranka jakby zabitego. A miał siedem rogów i siedem oczu, to jest siedem Duchów Boga wysłanych na całą ziemię.
###### **Ap 5,7**
 On poszedł i wziął księgę z prawicy zasiadającego na tronie.
###### **Ap 5,8**
 A kiedy wziął księgę, czworo Zwierząt i dwudziestu czterech Starców upadło przed Barankiem, każdy mając harfę i złote czasze pełne kadzideł, są to modlitwy świętych.
###### **Ap 5,9**
 I taką nową pieśń śpiewają: "Godzien jesteś wziąć księgę i otworzyć jej pieczęcie, bo zostałeś zabity i nabyłeś dla Boga swoją krwią ludzi z każdego pokolenia, różnojęzycznych narodów i ludów,
###### **Ap 5,10**
 I uczyniłeś ich dla Boga naszego królestwem i kapłanami, a będą królować na ziemi".
###### **Ap 5,11**
 I ujrzałem, i usłyszałem głos wielu aniołów dokoła tronu i Zwierząt, i Starców, a liczba ich była miriady miriad i tysiące tysięcy.
###### **Ap 5,12**
 Mówili oni głosem donośnym: "Baranek zabity jest godzien wziąć potęgę i bogactwo, i mądrość, i moc, i cześć, i chwałę, i uwielbienie".
###### **Ap 5,13**
 A wszelkie stworzenie, które jest w niebie i na ziemi, i pod ziemią i na morzu, i wszystko, co w nich przebywa, usłyszałem, jak mówiło: "Zasiadającemu na tronie i Barankowi uwielbienie i cześć, i chwała, i moc na wieki wieków".
###### **Ap 5,14**
 A czworo Zwierząt mówiło: "Amen". Starcy zaś upadli i oddali pokłon.
# Ap 5 BR
###### **Ap 5,1**
 I ujrzałem w prawej ręce Sie- dzącego na tronie księgę, zapisaną wewnątrz i na zewnątrz, opieczętowaną siedmioma pieczęciami.
###### **Ap 5,2**
 Zobaczyłem również ogromnego anioła, który wołał głosem donośnym: Kto jest godzien otworzyć księgę i złamać jej pieczęcie?
###### **Ap 5,3**
 Lecz nikt - ani w niebie, ani na ziemi, ani pod ziemią - nie mógł otworzyć księgi i zajrzeć do niej.
###### **Ap 5,4**
 Zacząłem tedy bardzo płakać, że nie znalazł się nikt, kto byłby godzien otworzyć księgę i przyjrzeć się jej.
###### **Ap 5,5**
 Wtedy powiedział do mnie jeden ze Starców: Nie płacz! Popatrz, oto zwyciężył Lew z pokolenia Judy, potomek Dawida. On otworzy księgę i siedem jej pieczęci.
###### **Ap 5,6**
 I ujrzałem przed tronem, otoczonym czworgiem Zwierząt, pośrodku przed Starcami Baranka stojącego [lecz] jakby zabitego. Miał on siedem rogów i posiadał siedmioro oczu, oznaczających siedem Duchów Boga wysłanych na całą ziemię.
###### **Ap 5,7**
 Zbliżył się i wziął księgę, którą trzymał w prawicy Zasiadający na tronie.
###### **Ap 5,8**
 A kiedy odebrał ową księgę, wówczas czworo Zwierząt razem z dwudziestoma czterema Starcami upadło [na kolana] przed Barankiem. Wszyscy mieli harfy i złote czasze pełne kadzideł, oznaczających modlitwy świętych.
###### **Ap 5,9**
 I śpiewali taką oto pieśń nową: Jesteś godzien wziąć księgę i otworzyć jej pieczęcie, bo zostałeś zabity i za cenę krwi Twojej nabyłeś Bogu [na własność] [ludzi] z każdego pokolenia, języka, ludu i narodu.
###### **Ap 5,10**
 I uczyniłeś z nich królestwo kapłanów dla Boga naszego. Odtąd będą królować na ziemi.
###### **Ap 5,11**
 A w dalszym ciągu widzenia usłyszałem głos wielu aniołów stojących dokoła tronu, Zwierząt i Starców. A było ich tam tysiące i dziesiątki tysięcy.
###### **Ap 5,12**
 Wszyscy wołali donośnym głosem: Baranek, który został zabity, godzien jest posiąść potęgę i bogactwo, i mądrość, i moc, i cześć, i chwałę, i błogosławieństwo.
###### **Ap 5,13**
 Wówczas też usłyszałem, jak wszelkie stworzenie, które jest w niebie, na ziemi, pod ziemią, w morzu, i wszystko, co tylko w nich jest, wołało: Temu, który siedzi na tronie, oraz Barankowi - błogosławieństwo, cześć, chwała i moc na wieki wieków.
###### **Ap 5,14**
 Czworo Zwierząt zaś wołało: Amen. A Starcy upadli [na kolana] i złożyli pokłon.
# Ap 5 WUJ
###### **Ap 5,1**
 I widziałem w prawej ręce siedzącego na stolicy księgi napisane wewnątrz i zewnątrz, zapieczętowane siedmią pieczęci.
###### **Ap 5,2**
 I widziałem anioła mocnego, głosem wielkim obwoływającego: Kto jest godzien otworzyć księgi, i rozwiązać pieczęci ich?
###### **Ap 5,3**
 A żaden nie mógł ani w niebie, ani na ziemi, ani pod ziemią otworzyć ksiąg, ani na nie patrzyć.
###### **Ap 5,4**
 A jam wielce płakał, iż żaden nie był nalezion godny otworzyć księgi, ani na nie patrzyć.
###### **Ap 5,5**
 A jeden z starszych rzekł mi: Nie płacz, oto zwyciężył lew z pokolenia Judowego, korzeń Dawidów: aby otworzył księgi, i rozwiązał siedm ich pieczęci.
###### **Ap 5,6**
 I widziałem: a oto w pośród stolice z czworga zwierząt, i w pośrodku starszych, baranek stojący jako zabity, mając siedm rogów i oczy siedm: które są siedm Duchów Bożych, posłanych na wszystkę ziemię.
###### **Ap 5,7**
 I przyszedł, i wziął księgi z prawice siedzącego na stolicy.
###### **Ap 5,8**
 A gdy otworzył księgi: a czworo zwierząt i czterzej a dwadzieścia starszy upadli przed Barankiem, mający każdy cytry, i czasze złote pełne wonności, które są modlitwy świętych:
###### **Ap 5,9**
 I śpiewali nową pieśń, mówiąc: Godzieneś jest Panie wziąć księgi, i otworzyć pieczęci ich, iżeś jest zabit, i odkupiłeś nas Bogu przez krew twoję, ze wszelakiego pokolenia, i języka, i ludu, i narodu:
###### **Ap 5,10**
 I uczyniłeś nas Bogu naszemu królestwem i kapłanami, i będziemy królować na ziemi.
###### **Ap 5,11**
 I widziałem i słyszałem głos wielu aniołów około stolice, i zwierząt, i starszych, a była liczba ich tysiące tysięców,
###### **Ap 5,12**
 Mówiących głosem wielkim: Godzien jest Baranek, który jest zabity, wziąć moc, i bóstwo, i mądrość, i siłę, i cześć, i chwałę, i błogosławieństwo.
###### **Ap 5,13**
 A wszelkie stworzenie, które jest na niebie, i na ziemi, i pod ziemią, i co w morzu jest i co w nim: wszystkie słyszałem mówiące: Siedzącemu na stolicy, i Barankowi, błogosławieństwo, i cześć, i chwała, i moc na wieki wieków.
###### **Ap 5,14**
 A czworo zwierząt mówiło, Amen. A dwadzieścia i czterzej starszy upadli na oblicze swoje, i kłaniali się żywiącemu na wieki wieków.
# Ap 5 STERN
###### **Ap 5,1**
 Potem ujrzałem po prawej ręce Zasiadającego na tronie zwój zapisany po obu stronach i zapieczętowany siedmioma pieczęciami,
###### **Ap 5,2**
 i zobaczyłem potężnego anioła, który ogłaszał donośnym głosem: "Kto jest godzien otworzyć zwój i złamać jego pieczęcie?".
###### **Ap 5,3**
 Ale nikt w niebie, na ziemi ani pod ziemią nie był w stanie otworzyć zwoju i zajrzeć do niego.
###### **Ap 5,4**
 Cały czas płakałem, bo nikt nie okazał się godzien, aby otworzyć zwój i zajrzeć do niego.
###### **Ap 5,5**
 Jeden ze starszych powiedział do mnie: "Nie płacz. Spójrz, Lew z pokolenia J'hudy, Korzeń Dawida, zdobył prawo otwarcia zwoju i jego siedmiu pieczęci".
###### **Ap 5,6**
 I ujrzałem koło tronu i czterech żywych istot, w otoczeniu starszych, stojącego Baranka, który wyglądał na zabitego. Miał siedem rogów i siedmioro oczu, które są siedmiorakim Duchem Bożym posłanym na całą ziemię.
###### **Ap 5,7**
 Przyszedł i wyjął zwój z prawej ręki Zasiadającego na tronie.
###### **Ap 5,8**
 Kiedy wziął zwój, cztery żywe istoty i dwudziestu czterech starszych upadło przed Barankiem. Każdy miał harfę i złote czary napełnione kadzidłem, a są to modlitwy ludu Bożego,
###### **Ap 5,9**
 i śpiewali nową pieśń: "Godzien jesteś wziąć zwój i złamać jego pieczęcie, bo zostałeś zabity, za cenę krwi wykupiłeś dla Boga ludzi z każdego plemienia, języka, ludu i narodu.
###### **Ap 5,10**
 Uczyniłeś ich królestwem, aby władał nim Bóg, kohanim, aby Mu służyli, i będą rządzić ziemią".
###### **Ap 5,11**
 Wtedy spojrzałem i usłyszałem dźwięk ogromnej rzeszy aniołów - tysiące tysięcy i miliony milionów! Wszyscy oni byli wokół tronu, żywych istot i starszych,
###### **Ap 5,12**
 a wołali: "Godzien jest zabity Baranek, aby przyjąć moc, bogactwa, mądrość, siłę, cześć, sławę i chwałę!".
###### **Ap 5,13**
 I słyszałem, jak każde stworzenie w niebie, na ziemi, pod ziemią i na morzu, tak, wszystko, co w nich jest, mówiło: "Do Zasiadającego na tronie i do Baranka należy chwała, cześć, sława i moc na wieki wieków!"
###### **Ap 5,14**
 Cztery żywe istoty mówiły: "Amen!", a starsi upadli i oddawali cześć.
# Ap 5 TRO
###### **Ap 5,1**
 **και** *kai* I [[G2532]] [[CONJ]] **ειδον** *eidon* zobaczyłem [[G1492]] WTV-2AAI-1S **επι** *epi* na [[G1909]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **δεξιαν** *deksian* prawicy [[G1188]] WTA-ASF **του** *tou* [[G3588]] WTT-GSM **καθημενου** *kathēmenou* siedzącego [[G2521]] WTV-PNP-GSM **επι** *epi* na [[G1909]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronie [[G2362]] [[N-GSM]] **βιβλιον** *biblion* zwój [[G975]] WTN-ASN **γεγραμμενον** *gegrammenon* który jest zapisany [[G1125]] WTV-RPP-ASN **εσωθεν** *esōthen* od wewnątrz [[G2081]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **οπισθεν** *opisthen* od tyłu [[G3693]] [[ADV]] **κατεσφραγισμενον** *katesfragismenon* który jest opieczętowany [[G2696]] WTV-RPP-ASN **σφραγισιν** *sfragisin* pieczęciami [[G4973]] WTN-DPF **επτα** *hepta* siedmioma [[G2033]] WTA-NUI
###### **Ap 5,2**
 **και** *kai* I [[G2532]] [[CONJ]] **ειδον** *eidon* zobaczyłem [[G1492]] WTV-2AAI-1S **αγγελον** *angelon* zwiastuna [[G32]] [[N-ASM]] **ισχυρον** *ischyron* mocnego – silnego [[G2478]] WTA-ASM **κηρυσσοντα** *kēryssonta* głoszącego [[G2784]] WTV-PAP-ASM **φωνη** *fōnē* głosem [[G5456]] [[N-DSF]] **μεγαλη** *megalē* wielkim [[G3173]] WTA-DSF **τις** *tis* kto [[G5101]] WTI-NSM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **αξιος** *aksios* godny [[G514]] [[A-NSM]] **ανοιξαι** *anoiksai* otworzyć [[G455]] [[V-AAN]] **το** *to* [[G3588]] WTT-ASN **βιβλιον** *biblion* zwój [[G975]] WTN-ASN **και** *kai* i [[G2532]] [[CONJ]] **λυσαι** *lysai* rozwiązać [[G3089]] [[V-AAN]] **τας** *tas* [[G3588]] WTT-APF **σφραγιδας** *sfragidas* pieczęcie [[G4973]] WTN-APF **αυτου** *autou* jego [[G846]] WTP-GSN
###### **Ap 5,3**
 **και** *kai* I [[G2532]] [[CONJ]] **ουδεις** *oudeis* nikt [[G3762]] [[A-NSM]] **ηδυνατο** *ēdynato* mógł [[G1410]] WTV-INI-3S-ATT **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **ουρανω** *ouranō* niebie [[G3772]] WTN-DSM **ουδε** *oude* ani [[G3761]] [[ADV]] **επι** *epi* na [[G1909]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]] **ουδε** *oude* ani [[G3761]] [[ADV]] **υποκατω** *hypokatō* pod [[G5270]] [[ADV]] **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemią [[G1093]] [[N-GSF]] **ανοιξαι** *anoiksai* otworzyć [[G455]] [[V-AAN]] **το** *to* [[G3588]] WTT-ASN **βιβλιον** *biblion* zwoju [[G975]] WTN-ASN **ουδε** *oude* ani [[G3761]] [[ADV]] **βλεπειν** *blepein* patrzeć [[G991]] WTV-PAN **αυτο** *auto* (na) niego [[G846]] WTP-ASN
###### **Ap 5,4**
 **και** *kai* I [[G2532]] [[CONJ]] **εγω** *egō* ja [[G1473]] WTP-1NS **εκλαιον** *eklaion* płakałem [[G2799]] WTV-IAI-1S **πολλα** *polla* wiele [[G4183]] WTA-APN **οτι** *hoti* że [[G3754]] [[CONJ]] **ουδεις** *oudeis* nikt [[G3762]] [[A-NSM]] **αξιος** *aksios* godny [[G514]] [[A-NSM]] **ευρεθη** *heurethē* został znaleziony [[G2147]] [[V-API-3S]] **ανοιξαι** *anoiksai* otworzyć [[G455]] [[V-AAN]] **και** *kai* i [[G2532]] [[CONJ]] **αναγνωναι** *anagnōnai* przeczytać [[G314]] [[V-2AAN]] **το** *to* [[G3588]] WTT-ASN **βιβλιον** *biblion* zwój [[G975]] WTN-ASN **ουτε** *oute* ani [[G3777]] [[CONJ]] **βλεπειν** *blepein* patrzeć [[G991]] WTV-PAN **αυτο** *auto* (na) niego [[G846]] WTP-ASN
###### **Ap 5,5**
 **και** *kai* I [[G2532]] [[CONJ]] **εις** *heis* jeden [[G1520]] [[A-NSM]] **εκ** *ek* ze [[G1537]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **πρεσβυτερων** *presbyterōn* starszych – starców [[G4245]] WTA-GPM **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **μοι** *moi* mi [[G3427]] WTP-1DS **μη** *mē* nie [[G3361]] [[PRT-N]] **κλαιε** *klaie* płacz [[G2799]] WTV-PAM-2S **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **ενικησεν** *enikēsen* zwyciężył [[G3528]] [[V-AAI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **λεων** *leōn* lew [[G3023]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **ων** *ōn* który jest [[G5607]] [[V-PXP-NSM]] **εκ** *ek* z [[G1537]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **φυλης** *fylēs* plemienia [[G5443]] [[N-GSF]] **ιουδα** *iouda* Judy – [wielbić] [[G2448]] [[N-GSM]] **η** *hē* [[G3588]] [[T-NSF]] **ριζα** *riza* korzeń [[G4491]] [[N-NSF]] **δαβιδ** *dabid* Dawida – [umiłowany] [[G1138]] [[N-PRI]] **ανοιξαι** *anoiksai* (by) otworzyć [[G455]] [[V-AAN]] **το** *to* [[G3588]] WTT-ASN **βιβλιον** *biblion* zwój [[G975]] WTN-ASN **και** *kai* i [[G2532]] [[CONJ]] **λυσαι** *lysai* rozwiązać [[G3089]] [[V-AAN]] **τας** *tas* [[G3588]] WTT-APF **επτα** *hepta* siedem [[G2033]] WTA-NUI **σφραγιδας** *sfragidas* pieczęci [[G4973]] WTN-APF **αυτου** *autou* jego [[G846]] WTP-GSN
###### **Ap 5,6**
 **και** *kai* I [[G2532]] [[CONJ]] **ειδον** *eidon* zobaczyłem [[G1492]] WTV-2AAI-1S **και** *kai* i [[G2532]] [[CONJ]] **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **εν** *en* na [[G1722]] [[PREP]] **μεσω** *mesō* środku [[G3319]] WTA-DSN **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronu [[G2362]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPN **τεσσαρων** *tessarōn* czterech [[G5064]] WTA-GPN **ζωων** *zōōn* istot żywych [[G2226]] WTN-GPN **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **μεσω** *mesō* środku [[G3319]] WTA-DSN **των** *tōn* [[G3588]] WTT-GPM **πρεσβυτερων** *presbyterōn* starszych – starców [[G4245]] WTA-GPM **αρνιον** *arnion* baranek [[G721]] WTN-NSN **εστηκος** *hestēkos* który stoi [[G2476]] WTV-RAP-NSN **ως** *hōs* jak [[G5613]] [[ADV]] **εσφαγμενον** *esfagmenon* który jest zabity brutalnie – który jest zamordowany [[G4969]] WTV-RPP-NSN **εχον** *echon* mający [[G2192]] WTV-PAP-NSN **κερατα** *kerata* rogów [[G2768]] WTN-APN **επτα** *hepta* siedem [[G2033]] WTA-NUI **και** *kai* i [[G2532]] [[CONJ]] **οφθαλμους** *ofthalmous* oczu [[G3788]] [[N-APM]] **επτα** *hepta* siedem [[G2033]] WTA-NUI **οι** *hoi* które [[G3739]] WTR-NPM **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **τα** *ta* [[G3588]] WTT-NPN **επτα** *hepta* siedem [[G2033]] WTA-NUI **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **πνευματα** *pneumata* duchy [[G4151]] WTN-NPN **τα** *ta* [[G3588]] WTT-NPN **απεσταλμενα** *apestalmena* które są wysłane [[G649]] WTV-RPP-NPN **εις** *eis* na [[G1519]] [[PREP]] **πασαν** *pasan* całą [[G3956]] WTA-ASF **την** *tēn* [[G3588]] WTT-ASF **γην** *gēn* ziemię [[G1093]] WTN-ASF
###### **Ap 5,7**
 **και** *kai* I [[G2532]] [[CONJ]] **ηλθεν** *ēlthen* przyszedł [[G2064]] WTV-2AAI-3S **και** *kai* i [[G2532]] [[CONJ]] **ειληφεν** *eilēfen* wziął [[G2983]] WTV-RAI-3S **το** *to* [[G3588]] WTT-ASN **βιβλιον** *biblion* zwój [[G975]] WTN-ASN **εκ** *ek* z [[G1537]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **δεξιας** *deksias* prawicy [[G1188]] WTA-GSF **του** *tou* [[G3588]] WTT-GSM **καθημενου** *kathēmenou* siedzącego [[G2521]] WTV-PNP-GSM **επι** *epi* na [[G1909]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronie [[G2362]] [[N-GSM]]
###### **Ap 5,8**
 **και** *kai* A [[G2532]] [[CONJ]] **οτε** *hote* gdy [[G3753]] [[ADV]] **ελαβεν** *elaben* wziął – odebrał [[G2983]] WTV-2AAI-3S **το** *to* [[G3588]] WTT-ASN **βιβλιον** *biblion* zwój [[G975]] WTN-ASN **τα** *ta* [[G3588]] WTT-NPN **τεσσαρα** *tessara* cztery [[G5064]] WTA-NPN **ζωα** *zōa* istoty żywe [[G2226]] WTN-NPN **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **εικοσιτεσσαρες** *eikositessares* dwudziestu czterech [[G1501]] WTA-NPM **πρεσβυτεροι** *presbyteroi* starszych – starców [[G4245]] WTA-NPM **επεσον** *epeson* upadło [[G4098]] WTV-2AAI-3P **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **του** *tou* [[G3588]] WTT-GSN **αρνιου** *arniou* barankiem [[G721]] [[N-GSN]] **εχοντες** *echontes* mając [[G2192]] WTV-PAP-NPM **εκαστος** *hekastos* każdy [[G1538]] [[A-NSM]] **κιθαρας** *kitharas* cytry – kitary [[G2788]] WTN-APF **και** *kai* i [[G2532]] [[CONJ]] **φιαλας** *fialas* czasze [[G5357]] WTN-APF **χρυσας** *chrysas* złote [[G5552]] WTA-APF **γεμουσας** *gemousas* które są pełne [[G1073]] WTV-PAP-APF **θυμιαματων** *thymiamatōn* kadzenia [[G2368]] WTN-GPN **αι** *hai* które [[G3739]] WTR-NPF **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **αι** *hai* [[G3588]] [[T-NPF]] **προσευχαι** *proseuchai* modlitwy [[G4335]] [[N-NPF]] **των** *tōn* [[G3588]] WTT-GPM **αγιων** *hagiōn* świętych [[G40]] WTA-GPM
###### **Ap 5,9**
 **και** *kai* I [[G2532]] [[CONJ]] **αδουσιν** *adousin* śpiewają [[G103]] WTV-PAI-3P **ωδην** *ōdēn* pieśń [[G5603]] WTN-ASF **καινην** *kainēn* nową [[G2537]] WTA-ASF **λεγοντες** *legontes* mówiąc [[G3004]] WTV-PAP-NPM **αξιος** *aksios* godny [[G514]] [[A-NSM]] **ει** *ei* jesteś [[G1488]] WTV-PXI-2S **λαβειν** *labein* wziąć [[G2983]] [[V-2AAN]] **το** *to* [[G3588]] WTT-ASN **βιβλιον** *biblion* zwój [[G975]] WTN-ASN **και** *kai* i [[G2532]] [[CONJ]] **ανοιξαι** *anoiksai* otworzyć [[G455]] [[V-AAN]] **τας** *tas* [[G3588]] WTT-APF **σφραγιδας** *sfragidas* pieczęć [[G4973]] WTN-APF **αυτου** *autou* jego [[G846]] WTP-GSN **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **εσφαγης** *esfagēs* zostałeś zabity brutalnie – zostałeś zamordowany [[G4969]] WTV-2API-2S **και** *kai* i [[G2532]] [[CONJ]] **ηγορασας** *ēgorasas* kupiłeś [[G59]] WTV-AAI-2S **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **ημας** *hēmas* nas [[G2248]] WTP-1AP **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **αιματι** *haimati* krwi [[G129]] WTN-DSN **σου** *sou* twojej [[G4675]] WTP-2GS **εκ** *ek* z [[G1537]] [[PREP]] **πασης** *pasēs* każdego [[G3956]] WTA-GSF **φυλης** *fylēs* plemienia [[G5443]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **γλωσσης** *glōssēs* języka [[G1100]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **λαου** *laou* ludu [[G2992]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **εθνους** *ethnous* narodu [[G1484]] [[N-GSN]]
###### **Ap 5,10**
 **και** *kai* i [[G2532]] [[CONJ]] **εποιησας** *epoiēsas* uczyniłeś [[G4160]] WTV-AAI-2S **ημας** *hēmas* nas [[G2248]] WTP-1AP **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **ημων** *hēmōn* naszemu [[G2257]] WTP-1GP **βασιλεις** *basileis* królami [[G935]] [[N-APM]] **και** *kai* i [[G2532]] [[CONJ]] **ιερεις** *hiereis* kapłanami [[G2409]] [[N-APM]] **και** *kai* i [[G2532]] [[CONJ]] **βασιλευσομεν** *basileusomen* będziemy królować – będziemy panować [[G936]] WTV-FAI-1P **επι** *epi* na [[G1909]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]]
###### **Ap 5,11**
 **και** *kai* I [[G2532]] [[CONJ]] **ειδον** *eidon* zobaczyłem [[G1492]] WTV-2AAI-1S **και** *kai* i [[G2532]] [[CONJ]] **ηκουσα** *ēkousa* usłyszałem [[G191]] WTV-AAI-1S **φωνην** *fōnēn* głos [[G5456]] WTN-ASF **αγγελων** *angelōn* zwiastunów [[G32]] WTN-GPM **πολλων** *pollōn* wielu [[G4183]] WTA-GPM **κυκλοθεν** *kyklothen* dookoła [[G2943]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronu [[G2362]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPN **ζωων** *zōōn* istot żywych [[G2226]] WTN-GPN **και** *kai* i [[G2532]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPM **πρεσβυτερων** *presbyterōn* starszych – starców [[G4245]] WTA-GPM **και** *kai* i [[G2532]] [[CONJ]] **ην** *ēn* była [[G2258]] [[V-IXI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **αριθμος** *arithmos* liczba [[G706]] [[N-NSM]] **αυτων** *autōn* ich [[G846]] WTP-GPM **μυριαδες** *myriades* dziesiątki tysięcy – miriady [[G3461]] WTA-NPM **μυριαδων** *myriadōn* dziesiątków tysięcy – miriad [[G3461]] WTA-GPM **και** *kai* i [[G2532]] [[CONJ]] **χιλιαδες** *chiliades* tysiące [[G5505]] [[A-NPF]] **χιλιαδων** *chiliadōn* tysięcy [[G5505]] [[A-NPF]]
###### **Ap 5,12**
 **λεγοντες** *legontes* mówiący [[G3004]] WTV-PAP-NPM **φωνη** *fōnē* głosem [[G5456]] [[N-DSF]] **μεγαλη** *megalē* wielkim [[G3173]] WTA-DSF **αξιον** *aksion* godny – zasługujący [[G514]] WTA-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **το** *to* [[G3588]] WTT-NSN **αρνιον** *arnion* baranek [[G721]] WTN-NSN **το** *to* [[G3588]] WTT-NSN **εσφαγμενον** *esfagmenon* który jest zabity brutalnie – który jest zamordowany [[G4969]] WTV-RPP-NSN **λαβειν** *labein* wziąć [[G2983]] [[V-2AAN]] **την** *tēn* [[G3588]] WTT-ASF **δυναμιν** *dynamin* moc [[G1411]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **πλουτον** *plouton* bogactwo [[G4149]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **σοφιαν** *sofian* mądrość [[G4678]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **ισχυν** *ischyn* siłę [[G2479]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **τιμην** *timēn* szacunek – zaszczyt [[G5092]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **δοξαν** *doksan* chwałę [[G1391]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **ευλογιαν** *eulogian* błogosławieństwo – wysławienie [[G2129]] WTN-ASF
###### **Ap 5,13**
 **και** *kai* I [[G2532]] [[CONJ]] **παν** *pan* wszelkie [[G3956]] WTA-ASN **κτισμα** *ktisma* stworzenie [[G2938]] WTN-ASN **ο** *ho* które [[G3739]] WTR-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **ουρανω** *ouranō* niebie [[G3772]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* na [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **γη** *gē* ziemi [[G1093]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **υποκατω** *hypokatō* pod [[G5270]] [[ADV]] **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemią [[G1093]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **επι** *epi* na [[G1909]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **θαλασσης** *thalassēs* morzu [[G2281]] [[N-GSF]] **α** *ha* co [[G3739]] WTR-APN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **εν** *en* w [[G1722]] [[PREP]] **αυτοις** *autois* nich [[G846]] WTP-DPN **παντα** *panta* wszystkie [[G3956]] WTA-APN **ηκουσα** *ēkousa* usłyszałem [[G191]] WTV-AAI-1S **λεγοντας** *legontas* mówiące [[G3004]] WTV-PAP-APM **τω** *tō* [[G3588]] WTT-DSM **καθημενω** *kathēmenō* siedzącemu [[G2521]] WTV-PNP-DSM **επι** *epi* na [[G1909]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronie [[G2362]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **τω** *tō* [[G3588]] WTT-DSN **αρνιω** *arniō* barankowi [[G721]] WTN-DSN **η** *hē* [[G3588]] [[T-NSF]] **ευλογια** *eulogia* błogosławieństwo – wysławianie [[G2129]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **τιμη** *timē* szacunek – zaszczyt [[G5092]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **δοξα** *doksa* chwała [[G1391]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **κρατος** *kratos* moc – siła [[G2904]] WTN-NSN **εις** *eis* na [[G1519]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **αιωνας** *aiōnas* wieki [[G165]] [[N-APM]] **των** *tōn* [[G3588]] WTT-GPM **αιωνων** *aiōnōn* wieków [[G165]] WTN-GPM
###### **Ap 5,14**
 **και** *kai* A [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-NPN **τεσσαρα** *tessara* cztery [[G5064]] WTA-NPN **ζωα** *zōa* istoty żywe [[G2226]] WTN-NPN **ελεγον** *elegon* mówiły [[G3004]] WTV-IAI-3P **αμην** *amēn* amen – [zaprawdę] [[G281]] WTHEB **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **εικοσιτεσσαρες** *eikositessares* dwudziestu czterech [[G1501]] WTA-NPM **πρεσβυτεροι** *presbyteroi* starszych – starców [[G4245]] WTA-NPM **επεσαν** *epesan* upadło [[G4098]] WTV-2AAI-3P **και** *kai* i [[G2532]] [[CONJ]] **προσεκυνησαν** *prosekynēsan* oddało cześć – pokłoniło się [[G4352]] WTV-AAI-3P **ζωντι** *zōnti* żyjącemu [[G2198]] WTV-PAP-DSM **εις** *eis* na [[G1519]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **αιωνας** *aiōnas* wieki [[G165]] [[N-APM]] **των** *tōn* [[G3588]] WTT-GPM **αιωνων** *aiōnōn* wieków [[G165]] WTN-GPM
