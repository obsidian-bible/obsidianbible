# 2Mch 6 BT5
###### **2Mch 6,1**
  Niedługo potem król posłał pewnego starca z Aten, aby zmuszał Żydów do odstępowania od praw ojczystych i do tego, aby nie postępowali według praw Bożych,
###### **2Mch 6,2**
 ale żeby zbezcześcili zarówno świątynię w Jerozolimie, którą mieli przemianować na [świątynię] Zeusa Olimpijskiego, jak i tę na Garizim, którą – jak życzyli sobie mieszkańcy tego miejsca – mieli przemianować na [świątynię] Zeusa Kseniosa.
###### **2Mch 6,3**
 Napór niegodziwości był ciężki i trudny do wytrzymania dla wszystkich.
###### **2Mch 6,4**
 Świątynia była pełna rozpusty i uczt, na których poganie zabawiali się z nierządnicami, a na świętych dziedzińcach zbliżali się do kobiet, ponadto do wnętrza świątyni wnosili to, czego się nie godzi.
###### **2Mch 6,5**
 Ołtarz był pokryty ofiarami niedozwolonymi przez Prawo i niegodziwymi.
###### **2Mch 6,6**
 Nie było wolno ani zachowywać szabatu, ani obchodzić ojczystych świąt, ani nawet przyznawać się, że jest się Żydem.
###### **2Mch 6,7**
 Każdego miesiąca w dniu urodzin króla gorzka konieczność prowadziła każdego do spożywania ofiar, kiedy zaś przyszło święto Dionizjów, zmuszano do tego, aby w bluszczowych wieńcach brać udział w pochodzie ku czci Dionizosa.
###### **2Mch 6,8**
 Za namową Ptolemeusza zostało wydane dla sąsiednich miast greckich rozporządzenie, aby one w stosunku do Żydów tak samo postępowały, zwłaszcza co do uczt obrzędowych,
###### **2Mch 6,9**
 i aby karano śmiercią tych, którzy nie chcieli przejść na grecki sposób postępowania. Można więc było dostrzec, jak wielki nastaje ucisk.
###### **2Mch 6,10**
 Przed sąd przyprowadzono dwie kobiety, gdyż obrzezały swe dzieci. Zawiesiwszy im przy piersiach ich niemowlęta, oprowadzono je publicznie po mieście, a następnie strącono z muru.
###### **2Mch 6,11**
 Inni skryli się w pobliskich grotach, aby w tajemnicy obchodzić szabat. Jednak doniesiono o tym Filipowi i wszyscy zostali spaleni, gdyż przez cześć dla dnia świętego nie odważyli się bronić.
###### **2Mch 6,12**
 Proszę więc tych, którzy będą czytali tę księgę, aby nie wpadali w przygnębienie z powodu tych nieszczęść, lecz by rozważyli, że prześladowania były nie po to, aby zniszczyć, ale aby wychować nasz naród.
###### **2Mch 6,13**
 Znakiem bowiem wielkiego dobrodziejstwa jest to, iż grzesznicy nie są pozostawieni w spokoju przez długi czas, ale że zaraz dosięga ich kara.
###### **2Mch 6,14**
 Nie uważał bowiem Władca, że z nami trzeba postępować tak samo jak z innymi narodami, wobec których pozostaje cierpliwy i nie karze ich tak długo, aż dopełnią miary grzechów.
###### **2Mch 6,15**
 Nie chciał bowiem karać nas na końcu, dopiero wtedy, gdyby grzechy nasze przebrały miarę.
###### **2Mch 6,16**
 A więc nigdy nie cofa On nam swego miłosierdzia; choć wychowuje przez nieszczęście, to jednak nie opuszcza swojego ludu.
###### **2Mch 6,17**
 Niech to będzie powiedziane nam dla przypomnienia. Po tych niewielu słowach trzeba przejść do opowiadania.
###### **2Mch 6,18**
 Niejaki Eleazar, jeden z pierwszych uczonych w Piśmie, mąż już w podeszłym wieku, o bardzo szlachetnej powierzchowności, był przymuszany do otwarcia ust i jedzenia wieprzowiny.
###### **2Mch 6,19**
 On jednak, wybierając raczej chwalebną śmierć aniżeli godne pogardy życie, dobrowolnie szedł na miejsce kaźni,
###### **2Mch 6,20**
 a wypluł mięso, jak powinni postąpić ci, którzy mają odwagę odrzucić to, czego nie wolno jeść nawet przez miłość do życia.
###### **2Mch 6,21**
 Ci, którzy byli wyznaczeni do tej bezbożnej ofiarnej uczty, ze względu na bardzo dawną znajomość z tym mężem, wzięli go na stronę i prosili, aby zjadł przyniesione przez nich i przygotowane mięso, które wolno mu jeść. Niech udaje tylko, że je to, co jest nakazane przez króla, mianowicie mięso z ofiary [pogańskiej].
###### **2Mch 6,22**
 Tak postępując, uniknie śmierci, a ze względu na dawną z nimi przyjaźń skorzysta z miłosierdzia.
###### **2Mch 6,23**
 On jednak powziął szlachetne postanowienie, godne jego wieku, powagi jego starości, okrytych zasługą siwych włosów i postępowania doskonałego od dzieciństwa, przede wszystkim zaś świętego i od Boga pochodzącego prawodawstwa. Dał im jasną odpowiedź, mówiąc, aby go zaraz posłali do Hadesu.
###### **2Mch 6,24**
 «***Udawanie bowiem nie przystoi naszemu wiekowi. Wielu młodych byłoby przekonanych, że Eleazar, który już ma dziewięćdziesiąt lat, przyjął pogańskie obyczaje.***
###### **2Mch 6,25**
 ***Oni to przez moje udawanie, i to dla ocalenia maleńkiej resztki życia, przeze mnie byliby wprowadzeni w błąd, ja zaś hańbą i wstydem okryłbym swoją starość.***
###### **2Mch 6,26**
 ***Jeżeli bowiem teraz uniknę ludzkiej kary, to z rąk Wszechmocnego ani żywy, ani umarły nie umknę.***
###### **2Mch 6,27**
 ***Dlatego jeżeli mężnie teraz zakończę życie, okażę się godny swojej starości,***
###### **2Mch 6,28**
 ***młodym zaś pozostawię rzetelny przykład ochotnej i wspaniałomyślnej śmierci za godne czci i święte prawa***». To powiedziawszy, natychmiast wszedł na miejsce kaźni.
###### **2Mch 6,29**
 Ci, którzy go przyprowadzili, na skutek wypowiedzianych przez niego słów zamienili miłosierdzie na surowość, sądzili bowiem, że były one szaleństwem.
###### **2Mch 6,30**
 Mając już pod ciosami umrzeć, westchnął i powiedział: «***Panu, który ma świętą wiedzę, jest jawne to, że mogłem uniknąć śmierci. Jako biczowany ponoszę wprawdzie boleść na ciele, dusza jednak cierpi to z radością, gdyż Jego się boję***».
###### **2Mch 6,31**
 W ten sposób więc zakończył życie, a swoją śmiercią zostawił nie tylko dla młodzieży, lecz także dla większości narodu przykład szlachetnej odwagi i pomnik cnoty.
# 2Mch 6 PAU
###### **2Mch 6,1**
 Po niedługim czasie król posłał pewnego starego Ateńczyka, aby zmusił Żydów do porzucenia ojczystych praw i niekierowania się prawami Bożymi,
###### **2Mch 6,2**
 oraz do zbezczeszczenia świątyni w Jerozolimie. Mieli ją przeznaczyć dla Zeusa Olimpijskiego, a świątynię na Garizim - dla Zeusa Kseniosa, zgodnie z życzeniem mieszkańców tego miejsca.
###### **2Mch 6,3**
 Natężenie zła stawało się dla wszystkich uciążliwe i nie do zniesienia.
###### **2Mch 6,4**
 Poganie napełnili świątynię rozwiązłością i hulaszczymi pochodami. Na świętych dziedzińcach zabawiali się z kurtyzanami i współżyli z kobietami oraz wnosili tam rzeczy zakazane.
###### **2Mch 6,5**
 Ołtarz napełnili zabronionymi ofiarami, wykluczonymi przez prawa.
###### **2Mch 6,6**
 Nie można było obchodzić szabatów ani zachowywać ojczystych świąt, ani nawet przyznawać się do bycia Żydem.
###### **2Mch 6,7**
 Każdego miesiąca w dzień narodzin króla bezwzględnie zmuszano do spożywania uczty ofiarnej, a gdy nadchodziły święta Dionizjów - do uczestniczenia w procesji na cześć Dionizosa z bluszczowymi wiankami na głowach.
###### **2Mch 6,8**
 Na wniosek mieszkańców Ptolemaidy także w okolicznych miastach greckich wydane zostało zarządzenie, aby Żydów traktować w ten sam sposób, to znaczy zmuszać ich do spożywania uczt ofiarnych
###### **2Mch 6,9**
 i zabijać tych, którzy nie chcieliby przyjąć greckich obyczajów. Można więc było przewidzieć nadchodzące nieszczęście.
###### **2Mch 6,10**
 Dwie kobiety obrzezały swoich synów. Oskarżono je i z dziećmi uwieszonymi przy piersi publicznie przeprowadzono dookoła miasta, a potem strącono z murów.
###### **2Mch 6,11**
 Inni zgromadzili się w pobliskich grotach, aby potajemnie obchodzić dzień siódmy. Doniesiono o tym Filipowi i wszyscy zostali spaleni, ponieważ ze względu na szacunek dla tego uroczystego, czcigodnego dnia uważali, że nie wolno im się bronić.
###### **2Mch 6,12**
 Zachęcam czytających tę księgę, aby nie przerazili się z powodu tych nieszczęść, lecz raczej zważali na to, że celem kary nie jest zniszczenie naszego narodu, ale jego wychowanie.
###### **2Mch 6,13**
 Jest bowiem znakiem wielkiego dobrodziejstwa, gdy bezbożni nie są długo pozostawieni bez kary, lecz są nią natychmiast dotknięci.
###### **2Mch 6,14**
 Wobec innych narodów cierpliwy Władca oczekuje z karą, aż przebiorą miarę w grzechach. Wobec nas postanowił inaczej,
###### **2Mch 6,15**
 aby nie karać nas dopiero wtedy, kiedy osiągniemy szczyt w naszych grzechach.
###### **2Mch 6,16**
 Dlatego nigdy nie cofa nam miłosierdzia, ale wychowując przez przeciwności, nie opuszcza swojego ludu.
###### **2Mch 6,17**
 Tylko tyle niech będzie powiedziane dla przypomnienia. Po tych kilku słowach trzeba bowiem wracać do opowiadania.
###### **2Mch 6,18**
 Niejaki Eleazar, jeden z najznakomitszych nauczycieli Pisma, człowiek w podeszłym już wieku, o bardzo pięknych rysach twarzy, był zmuszany do jedzenia wieprzowego mięsa.
###### **2Mch 6,19**
 On jednak, wybierając raczej śmierć ze sławą aniżeli życie z hańbą, podszedł dobrowolnie do narzędzia tortur
###### **2Mch 6,20**
 i wypluł mięso. Tak powinni postąpić ci, którzy odrzucają pokarmy zabronione, nie jedząc ich nawet dla ocalenia życia.
###### **2Mch 6,21**
 Ci zaś, którzy byli wyznaczeni do przewodniczenia nieprawej uczcie ofiarnej, ponieważ znali tego człowieka od dawnych czasów, wzięli go na bok i zachęcali, aby kazał przynieść sobie mięso, które wolno mu jeść, przyrządzone przez niego samego. Niech tylko udaje, że spożywa mięso z ofiary nakazanej przez króla.
###### **2Mch 6,22**
 Jeśli to zrobi, uniknie śmierci i ze względu na ich dawną przyjaźń będzie potraktowany łaskawie.
###### **2Mch 6,23**
 On jednak podjął uczciwą decyzję, godną powagi sędziwego wieku, szlachetnej siwizny, którą osiągnął, oraz doskonałego postępowania od dziecka, a bardziej jeszcze świętego i przez Boga ustanowionego prawodawstwa, i odpowiedział dobitnie, aby natychmiast posłali go do krainy umarłych:
###### **2Mch 6,24**
 „Udawanie nie jest godne naszego wieku. Wielu młodych mogłoby sądzić, że dziewięćdziesięcioletni Eleazar przyjął obce obyczaje.
###### **2Mch 6,25**
 Moje udawanie dla ocalenia krótkich chwil życia wprowadziłoby ich w błąd, ja zaś na starość okryłbym się wstydem i hańbą.
###### **2Mch 6,26**
 Jeśli nawet w chwili obecnej uniknąłbym kary od ludzi, to przecież z rąk Wszechmocnego ani żywy, ani umarły nie ucieknę.
###### **2Mch 6,27**
 Dlatego teraz mężnie zakończę życie, przez co okażę się godny mojej starości,
###### **2Mch 6,28**
 młodym zaś pozostawię szlachetny przykład, jak należy odważnie i z honorem umierać za czcigodne i święte prawa”. Kiedy to powiedział, natychmiast podszedł do narzędzia tortur.
###### **2Mch 6,29**
 Ci, którzy go prowadzili, zamienili okazywaną mu przed chwilą przychylność na niechęć, ponieważ jego wypowiedź uznali za szaleństwo.
###### **2Mch 6,30**
 On zaś, kiedy już umierał pod uderzeniami, powiedział wśród jęków: „PAN, który posiada świętą wiedzę, wie, że mogłem uniknąć śmierci. Chociaż moje ciało okrutnie cierpi z powodu chłosty, dusza jednak chętnie ją przyjmuje ze względu na bojaźń Pańską”.
###### **2Mch 6,31**
 W ten oto sposób zakończył życie. Swoją śmiercią pozostawił przykład szlachetności i pamiątkę cnoty nie tylko dla młodych, ale również dla większości narodu.
# 2Mch 6 BP
###### **2Mch 6,1**
 Niedługo potem wysłał król pewnego starego Ateńczyka, aby zmuszał Żydów do zaparcia się praw przodków, do tego aby nie przestrzegali w życiu praw Bożych,
###### **2Mch 6,2**
 do zbezczeszczenia Świątyni jerozolimskiej przez poświęcenie jej Zeusowi Olimpijskiemu oraz świątyni na [górze] Garizim, która na prośbę jej mieszkańców miała być nazwana imieniem Zeusa Kseniosa.
###### **2Mch 6,3**
 Rozpanoszenie się tego zła było dla wszystkich przykrą uciążliwością.
###### **2Mch 6,4**
 W Świątyni odbywały się stale rozpustne orgie urządzane przez pogan, którzy zabawiali się z nierządnicami i na świętych dziedzińcach grzeszyli z kobietami; co więcej, wnosili do wnętrza [Świątyni] rzeczy zakazane.
###### **2Mch 6,5**
 Ołtarz pełen był ofiar niedozwolonych i przez Prawo zakazanych.
###### **2Mch 6,6**
 Nie wolno było obchodzić szabatu ani zachowywać świąt naszych ojców, nie można było po prostu przyznać się, że się jest Żydem.
###### **2Mch 6,7**
 Gorzki przymus doprowadził Żydów do tego, że uczestniczyli co miesiąc w uczcie ofiarnej w dzień urodzin króla, a podczas święta Dionizjów uwieńczeni bluszczem musieli uczestniczyć w pochodzie ku czci Dionizosa.
###### **2Mch 6,8**
 Za radą mieszkańców Ptolemaidy wydano zarządzenie dla pobliskich miast greckich, aby postępowano podobnie wzglądem Żydów i urządzano uczty z ofiar.
###### **2Mch 6,9**
 Ci, którzy nie chcieliby przyjąć obyczajów greckich, mieli być skazywani na śmierć; można było więc patrzeć na zbliżające się nieszczęście.
###### **2Mch 6,10**
 Przyprowadzono przed sąd dwie kobiety za to, że obrzezały swoich synów. Zawieszono im dzieci u piersi i oprowadzano na oczach wszystkich po mieście, a następnie strącono z murów.
###### **2Mch 6,11**
 Inni zebrali się w pobliskich grotach, aby potajemnie obchodzić dzień szabatu. Gdy zdradzono [to] Filipowi, zostali wszyscy spaleni, gdyż przez szacunek dla dnia świętego uważali, że nie wolno im się bronić.
###### **2Mch 6,12**
 Upominam jednak tych, którym ta Księga wpadnie w ręce, aby nie tracili ducha z powodu nieszczęść, lecz by wierzyli, że kary te miały na celu nie zagładę narodu, lecz jego poprawę.
###### **2Mch 6,13**
 Jest bowiem znakiem wielkiej łaski, jeśli nie pozostawia się grzeszników w spokoju przez długi czas, lecz karze się ich natychmiast.
###### **2Mch 6,14**
 Gdy chodzi o inne narody, czeka Wszechwładny cierpliwie z karaniem, aż dopełnią miary swych występków, inaczej zaś postępuje z nami,
###### **2Mch 6,15**
 aby nie musiał nas karać dopiero wtedy, gdy posuniemy się w naszych grzechach aż do ostateczności;
###### **2Mch 6,16**
 dlatego nie pozbawia nas nigdy swego miłosierdzia; wychowuje nas przez nieszczęścia, lecz nie opuszcza swego ludu.
###### **2Mch 6,17**
 To trzeba było powiedzieć dla przypomnienia. Po tych kilku uwagach powracamy do opowiadania.
###### **2Mch 6,18**
 Eleazar, jeden z przedniej szych uczonych w Piśmie, mąż w podeszłym już wieku, lecz o pełnym godności obliczu, został przymuszony do otwarcia ust i spożycia mięsa wieprzowego.
###### **2Mch 6,19**
 On jednak wolał umrzeć w chwale, niż żyć w hańbie - wypluł mięso i poszedł dobrowolnie na miejsce męczeństwa.
###### **2Mch 6,20**
 Postąpił zatem tak, jak powinni postąpić wszyscy, którzy mają odwagę odrzucić to, czego im jeść nie wolno z miłości do życia [wiecznego].
###### **2Mch 6,21**
 Ci, którym powierzono nadzór nad zabronioną Prawem ucztą ofiarną, wzięli go na bok i - ponieważ znali tego męża już od dłuższego czasu - namawiali go, aby kazał sobie przynieść mięso, które wolno mu było spożyć, i przygotowane przez siebie zjadł, udając w ten sposób, że wypełnia rozkaz króla i raczy się mięsem z ofiar.
###### **2Mch 6,22**
 Chcieli bowiem ze względu na starą przyjaźń, jaka ich łączyła, wyświadczyć mu dobrodziejstwo, aby to uczyniwszy mógł uchronić się przed śmiercią.
###### **2Mch 6,23**
 On jednak podjął mężne postanowienie. Było ono godne jego wieku, dostojeństwa jego starości, godne siwizny szlachetnej a zasłużonej i wzniosłego życia, jakie prowadził od wczesnej młodości, nade wszystko zaś godne świętych praw ustanowionych przez Boga. Zgodnie z tym odpowiedział natychmiast: - Wyślijcie mnie bez zwłoki do krainy śmierci.
###### **2Mch 6,24**
 Albowiem udawanie nie przystoi naszemu wiekowi - wielu młodych ludzi mogłoby pomyśleć, że dziewięćdziesięcioletni Eleazar przyjął obcą religię.
###### **2Mch 6,25**
 Jeślibym oszukiwał, aby ratować krótkie chwile życia, mógłbym ich wprowadzić w błąd, a sam okryłbym się na starość wstydem i hańbą.
###### **2Mch 6,26**
 Jeżeli nawet uniknę teraz kary ludzkiej, z rąk Wszechmogącego nie ujdę ani żywy, ani martwy.
###### **2Mch 6,27**
 Oddając więc obecnie mężnie swe życie, okażę się godny mej starości,
###### **2Mch 6,28**
 a młodym pozostawię szlachetny przykład, jak odważnie i z godnością powinno się umierać za czcigodne i święte prawa. To rzekłszy poszedł zaraz na miejsce męczeństwa.
###### **2Mch 6,29**
 Życzliwość okazywana mu jeszcze tak niedawno przez tych, którzy go przyprowadzili, zmieniła się na skutek tych słów we wrogość, uważali je bowiem za szaleństwo.
###### **2Mch 6,30**
 Gdy był już skatowany i bliski śmierci, westchnął i rzekł: Pan, który posiada świętą wszechwiedzę, wie dobrze, że chociaż mogłem uniknąć śmierci, ciało moje bite kijami cierpi okrutne męki, dusza jednak chętnie znosi te cierpienia z bojaźni Bożej.
###### **2Mch 6,31**
 Tak zakończył życie zostawiając przez swą śmierć nie tylko młodym, ale i większości narodu przykład odwagi i pamięć cnoty.
# 2Mch 6 BR
###### **2Mch 6,1**
 W jakiś czas potem posłał król pewnego starego Ateńczyka, aby skłonił Żydów do porzucenia prawa ich ojców i nieliczenia się już w życiu z prawem Bożym.
###### **2Mch 6,2**
 Miał ich też skłonić do zbezczeszczenia świątyni jerozolimskiej i przeznaczenia jej dla Zeusa, władcy Olimpu, i do poświęcenia świątyni na górze Garizim Zeusowi Kseniosowi, czyli Opiekunowi Przybyszów, jak sobie tego rzekomo życzyli [gościnni wobec wszystkich] mieszkańcy tej krainy.
###### **2Mch 6,3**
 Napór zła wydał się już wszystkim nie do zniesienia.
###### **2Mch 6,4**
 W Świątyni poganie oddawali się rozpuście i urządzali orgie w czasie których zadawali się z nierządnicami, a do swoich kobiet zbliżali się na świętych dziedzińcach. Do wnętrza świątyni wprowadzali też wiele takich rzeczy, które nigdy nie powinny się tam znajdować.
###### **2Mch 6,5**
 Na ołtarzu całopalenia składano na ofiarę rzeczy nie tylko niedozwolone, lecz wręcz zakazane przez prawo.
###### **2Mch 6,6**
 Nie można już było ani przestrzegać szabatu, ani obchodzić dawnych świąt, co więcej - nie wypadało się nawet przyznawać, że jest się Żydem.
###### **2Mch 6,7**
 Ponadto każdego miesiąca mieszkańcy kraju musieli uczestniczyć - mimo że serca ich zalewała gorycz - z okazji dnia urodzin króla w ucztach ofiarnych na cześć króla, a w święto Dionizjów zmuszano ich, aby przybrani w wieńce z bluszczu, brali udział w pochodach na cześć Dionizosa.
###### **2Mch 6,8**
 Za radą mieszkańców Ptolemaidy, ogłoszono zarządzenie, żeby w sąsiedzkich miastach greckich obchodzono się z Żydami w podobny sposób i zmuszano ich do udziału w ucztach ofiarnych,
###### **2Mch 6,9**
 a tych, którzy by nie chcieli żyć według obyczajów pogańskich, skazywano na śmierć. Można więc sobie wyobrazić ucisk, który zapanował w całym kraju.
###### **2Mch 6,10**
 Pewnego razu postawiono przed sądem dwie matki, które kazały obrzezać swoich synów. Otóż uwiązano im u piersi ich niemowlęta i oprowadzono je tak na oczach wszystkich po całym mieście, a potem strącono z muru w przepaść.
###### **2Mch 6,11**
 Inni zbierali się potajemnie w pobliskich jaskiniach, ażeby obchodzić szabat. Kiedy doniesiono o tym Filipowi, zostali wszyscy żywcem spaleni, gdyż obawiając się znieważyć dzień święty, nie poczynili niczego, żeby siebie ocalić.
###### **2Mch 6,12**
 Czytelników niniejszej księgi pragnę prosić w tym miejscu, żeby z powodu opisywanych tu wydarzeń nie popadali w zwątpienie. Nie wolno bowiem zapominać, że wszystkie owe doświadczenia były zsyłane na nasz naród nie po to, żeby go unicestwić, lecz żeby go skłonić do poprawy.
###### **2Mch 6,13**
 Oznaką bowiem wielkiej dobroci jest, że grzesznicy nie są pozostawiani bezkarnie na długo w swej przewrotności, ale są natychmiast karani.
###### **2Mch 6,14**
 Wobec innych narodów Pan pozostaje cierpliwy tak długo, aż dopełni się miara ich występków. Wtedy zsyła na nich zasłużoną karę. Z nami jednak spodobało Mu się postępować inaczej,
###### **2Mch 6,15**
 a to dlatego, żeby nie musiał nas w końcu skazywać na zagładę wskutek przepełnienia się miary naszych grzechów.
###### **2Mch 6,16**
 Nigdy więc nie pozbawia nas swego miłosierdzia. Ostrzega swój lud, zsyłając na niego różne nieszczęścia, ale nigdy go nie opuszcza.
###### **2Mch 6,17**
 Niech przypomnienie tej prawdy posłuży nam za pokrzepienie. Po tych kilku uwagach wróćmy znów do naszego opowiadania.
###### **2Mch 6,18**
 Wśród najbardziej uczonych w Piśmie znajdował się także Eleazar, mąż podeszłego już wieku i szlachetnego oblicza. Jemu to siłą otwarto usta i zmuszano go do jedzenia wieprzowiny.
###### **2Mch 6,19**
 On jednak wolał ponieść śmierć, która zjednałaby mu szacunek, niż życie w hańbie. Poszedł tedy dobrowolnie na miejsce kaźni,
###### **2Mch 6,20**
 a mięso, które włożono mu do ust, wypluł, pokazując, jak powinni zachować się ci, którzy nie chcą jeść tego, co zakazane, nawet gdyby trzeba było za to zapłacić naszym życiem.
###### **2Mch 6,21**
 Ci, którzy posługiwali na ucztach ofiarnych sprzecznych z prawem i którzy od dawna znali tego męża, wzięli go na stronę i próbowali przekonać, żeby pozwolił sobie przynieść mięsa [dozwolonego do spożycia], które oni mu przygotują, i zachowywał się tak, jakby jadł mięso składane w ofierze, zgodnie z nakazem króla.
###### **2Mch 6,22**
 Postępując tak ocali swe życie, a oni, dawni jego przyjaciele, obejdą się z nim jak najłaskawiej.
###### **2Mch 6,23**
 On jednak powziął szlachetne postanowienie, godne męża jego wieku i powagi, już oszronionego siwizną, męża, który od najwcześniejszej młodości był przykładem dla wszystkich, żywiąc poszanowanie dla świętego prawa otrzymanego od Boga. Dlatego też odpowiedział bez wahania, żeby go raczej zaraz wysłali w zaświaty.
###### **2Mch 6,24**
 Kto jest tak stary jak ja - mówił - powinien być daleki od stwarzania pozorów. Wielu młodych ludzi pomyślałoby, że mając dziewięćdziesiąt lat, zaczynam żyć według pogańskich zwyczajów.
###### **2Mch 6,25**
 Gdybym teraz dla uratowania niewielu pozostałych mi jeszcze lat mojego życia zaczął udawać, wprowadziłbym ich w błąd, a na mój podeszły wiek ściągnąłbym wstyd i hańbę.
###### **2Mch 6,26**
 Może udałoby mi się na razie uniknąć kary z rąk ludzi. Wiem jednak, że nigdy nie zdołałbym - ani za życia, ani po śmierci - ujść z rąk Wszechmocnego.
###### **2Mch 6,27**
 Dlatego też gotów jestem pójść teraz na śmierć i w ten sposób okazać się godnym mojego wieku.
###### **2Mch 6,28**
 Całym pokoleniom młodych zostawię też świetlany przykład, jak to odważnie i z całą gotowością powinno się oddawać życie w obronie czcigodnego i świętego prawa. Po tych słowach udał się prosto na miejsce kaźni.
###### **2Mch 6,29**
 I wtedy w tych, którzy go przyprowadzili surowość wzięła górę nad okazywaną mu jeszcze przed chwilą życzliwością. To, co powiedział, uznali bowiem za szaleństwo.
###### **2Mch 6,30**
 A kiedy go udręczono i był bliski śmierci, wzdychając głęboko powiedział: Wszechwiedzącemu Panu wiadomo, że mogłem uniknąć tej śmierci. Moje ciało odczuwa boleśnie każde uderzenie, ale dusza znosi wszystko z radością, bo żyje w bojaźni Pana.
###### **2Mch 6,31**
 I tak umarł. Przez swoją śmierć zostawił nie tylko pokoleniom młodych, lecz i większości ludu przykład właściwej postawy i jakby pomnik własnej cnoty.
# 2Mch 6 WUJ
