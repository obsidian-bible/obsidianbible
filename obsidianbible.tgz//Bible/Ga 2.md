# Ga 2 BT5
###### **Ga 2,1**
 Potem, po czternastu latach, udałem się ponownie do Jerozolimy wraz z Barnabą, zabierając ze sobą także Tytusa.
###### **Ga 2,2**
 Udałem się zaś w tę stronę na skutek otrzymanego objawienia. I przedstawiłem im Ewangelię, którą głoszę wśród pogan, osobno zaś tym, którzy cieszą się poważaniem, [by stwierdzili], czy nie biegnę lub nie biegłem na próżno.
###### **Ga 2,3**
 Ale nie zmuszono do poddania się obrzezaniu nawet Tytusa, mego towarzysza, mimo że jest Grekiem.
###### **Ga 2,4**
 A było to w związku z tym, że na zebranie weszli bezprawnie fałszywi bracia, którzy przyszli podstępnie wybadać naszą wolność, jaką mamy w Chrystusie Jezusie, aby nas ponownie pogrążyć w niewolę.
###### **Ga 2,5**
 Na żądane przez nich ustępstwo zgoła się jednak nie zgodziliśmy, aby dla waszego dobra przetrwała prawda Ewangelii.
###### **Ga 2,6**
 Co się zaś tyczy stanowiska tych, którzy się cieszą jakimś poważaniem – jakimi oni dawniej byli, jest dla mnie bez znaczenia; u Boga nie ma względu na osobę – otóż ci, co są uznani za powagi, nie polecili mi dodawać czegokolwiek.
###### **Ga 2,7**
 Wręcz przeciwnie, stwierdziwszy, że mnie zostało powierzone głoszenie Ewangelii wśród nieobrzezanych, podobnie jak Piotrowi wśród obrzezanych –
###### **Ga 2,8**
 Ten bowiem, który współdziałał z Piotrem w apostołowaniu obrzezanych, współdziałał i ze mną wśród pogan –
###### **Ga 2,9**
 i uznawszy daną mi łaskę, Jakub, Kefas i Jan, uważani za filary, podali mnie i Barnabie prawicę na znak wspólnoty, byśmy szli do pogan, oni zaś do obrzezanych,
###### **Ga 2,10**
 byleśmy pamiętali o ubogich, co też gorliwie starałem się czynić.
###### **Ga 2,11**
 Gdy następnie Kefas przybył do Antiochii, otwarcie mu się sprzeciwiłem, bo na to zasłużył.
###### **Ga 2,12**
 Zanim jeszcze nadeszli niektórzy z otoczenia Jakuba, brał udział w posiłkach z tymi, którzy pochodzili z pogaństwa. Kiedy jednak oni się zjawili, począł się odsuwać i trzymać z dala, bojąc się tych, którzy pochodzili z obrzezania.
###### **Ga 2,13**
 To jego nieszczere postępowanie podjęli też inni pochodzenia żydowskiego, tak że wciągnięto w to udawanie nawet Barnabę.
###### **Ga 2,14**
 Gdy więc spostrzegłem, że nie idą słuszną drogą, zgodną z prawdą Ewangelii, powiedziałem Kefasowi wobec wszystkich: «***Jeżeli ty, choć jesteś Żydem, żyjesz według obyczajów przyjętych wśród pogan, a nie wśród Żydów, to jak możesz zmuszać pogan do przyjmowania zwyczajów żydowskich?***»
###### **Ga 2,15**
 My jesteśmy Żydami z urodzenia, a nie pogrążonymi w grzechach poganami.
###### **Ga 2,16**
 A jednak przeświadczeni, że człowiek osiąga usprawiedliwienie nie dzięki uczynkom wymaganym przez Prawo, lecz jedynie dzięki wierze w Jezusa Chrystusa, my właśnie uwierzyliśmy w Chrystusa Jezusa, by osiągnąć usprawiedliwienie dzięki wierze w Chrystusa, a nie dzięki uczynkom wymaganym przez Prawo, jako że nikt nie osiągnie usprawiedliwienia dzięki uczynkom wymaganym przez Prawo.
###### **Ga 2,17**
 A jeżeli to, że szukamy usprawiedliwienia w Chrystusie, poczytuje się nam za grzech, to i Chrystusa należałoby uznać za sprawcę grzechu. Żadną miarą!
###### **Ga 2,18**
 A przecież wykazuję, że sam przestępuję [Prawo], gdy na nowo stawiam to, co uprzednio zburzyłem.
###### **Ga 2,19**
 Tymczasem ja dla Prawa umarłem przez Prawo, aby żyć dla Boga: razem z Chrystusem zostałem przybity do krzyża.
###### **Ga 2,20**
 Teraz zaś już nie ja żyję, lecz żyje we mnie Chrystus. Choć nadal prowadzę życie w ciele, jednak obecne życie moje jest życiem wiary w Syna Bożego, który umiłował mnie i samego siebie wydał za mnie.
###### **Ga 2,21**
 Nie mogę odrzucić łaski danej przez Boga. Jeżeli zaś usprawiedliwienie dokonuje się przez Prawo, to Chrystus umarł na darmo.
# Ga 2 PAU
###### **Ga 2,1**
 Następnie, po czternastu latach, znowu poszedłem do Jerozolimy razem z Barnabą, zabierając ze sobą także Tytusa.
###### **Ga 2,2**
 A przybyłem pod wpływem objawienia. I przedstawiłem im Ewangelię, którą głoszę poganom; osobno uczyniłem to wobec tych, którzy cieszą się uznaniem, aby upewnić się, że nie biegnę albo że nie biegłem na próżno.
###### **Ga 2,3**
 Ale nawet towarzyszący mi Tytus, który jest Grekiem, nie został zobowiązany do obrzezania.
###### **Ga 2,4**
 Co się zaś tyczy fałszywych braci, którzy wkradli się, aby naruszyć naszą wolność w Chrystusie Jezusie i pogrążyć nas w niewoli,
###### **Ga 2,5**
 to ani na chwilę nie ustąpiliśmy im, aby prawda Ewangelii pozostała wśród was.
###### **Ga 2,6**
 Również ze strony cieszących się uznaniem - a kim byli niegdyś, nic mnie to nie obchodzi, bo Bóg nie jest stronniczy - oni właśnie, cieszący się uznaniem, niczego mi nie narzucili.
###### **Ga 2,7**
 Wręcz przeciwnie. Gdy zobaczyli, że mnie zostało powierzone głoszenie Ewangelii wśród nieobrzezanych, podobnie jak Piotrowi wśród obrzezanych -
###### **Ga 2,8**
 ponieważ Ten, który działał w Piotrze dla apostołowania wśród obrzezanych, działał i we mnie dla dobra pogan -
###### **Ga 2,9**
 i gdy uznali daną mi łaskę, Jakub, Kefas i Jan, uważani za filary, podali prawą rękę mnie i Barnabie na znak łączności, abyśmy szli do pogan, oni zaś do obrzezanych.
###### **Ga 2,10**
 Mieliśmy tylko pamiętać o ubogich, co też pilnie starałem się czynić.
###### **Ga 2,11**
 Kiedy jednak Kefas przybył do Antiochii, sprzeciwiłem się mu otwarcie, bo postąpił niewłaściwie.
###### **Ga 2,12**
 Zanim przybyli niektórzy z otoczenia Jakuba, brał udział we wspólnych posiłkach z poganami. A gdy tamci przybyli, usunął się i odłączył, obawiając się obrzezanych.
###### **Ga 2,13**
 Razem z nim także inni Żydzi zaczęli się zachowywać nieszczerze i nawet Barnaba został wciągnięty w ich udawanie.
###### **Ga 2,14**
 Kiedy więc zobaczyłem, że nie postępują zgodnie z prawdą Ewangelii, powiedziałem Kefasowi wobec wszystkich: Jeśli ty, będąc Żydem, żyjesz według obyczajów pogan a nie Żydów, jak możesz zobowiązywać pogan do postępowania według obyczajów żydowskich?
###### **Ga 2,15**
 My jesteśmy Żydami z urodzenia, a nie grzesznikami spośród pogan.
###### **Ga 2,16**
 Wiemy jednak, że człowiek nie zostaje usprawiedliwiony dzięki przestrzeganiu Prawa, ale jedynie dzięki wierze w Jezusa Chrystusa. Dlatego my uwierzyliśmy w Jezusa, abyśmy zostali usprawiedliwieni dzięki wierze w Chrystusa, a nie dzięki przestrzeganiu Prawa, ponieważ przez przestrzeganie Prawa nikt nie osiągnie usprawiedliwienia.
###### **Ga 2,17**
 A jeśli szukając usprawiedliwienia w Chrystusie, jesteśmy uważani za grzeszników, to czy Chrystus prowadzi do grzechu? Z pewnością nie!
###### **Ga 2,18**
 Jeśli zaś buduję na nowo to, co zburzyłem, sam przyznaję, że źle postąpiłem.
###### **Ga 2,19**
 Ja przez Prawo umarłem dla Prawa, aby żyć dla Boga. Z Chrystusem zostałem ukrzyżowany.
###### **Ga 2,20**
 Żyję więc już nie ja, ale żyje we mnie Chrystus. A jeśli żyję teraz na świecie, to żyję dzięki wierze w Syna Bożego, który umiłował mnie i samego siebie wydał za mnie.
###### **Ga 2,21**
 Ja nie lekceważę łaski Boga. Jeśli zaś usprawiedliwienie osiąga się dzięki Prawu, to Chrystus umarł na darmo.
# Ga 2 BP
###### **Ga 2,1**
 Po czternastu latach znów udałem się do Jerozolimy z Barnabą, zabierając ze sobą Tytusa.
###### **Ga 2,2**
 Udałem się tam pod wpływem otrzymanego objawienia i otwarcie wszystkim, a na osobności tym, którzy cieszą się szczególnym poważaniem, przedstawiłem treść ewangelii, którą głoszę wśród pogan. Chciałem bowiem, bym przypadkiem - czy to teraz, czy kiedy indziej - nie biegł daremnie.
###### **Ga 2,3**
 Tymczasem nawet mojego współtowarzysza Tytusa, który był Grekiem, nie zmuszano do obrzezania.
###### **Ga 2,4**
 A fałszywi bracia - którzy podstępnie wdarli się do nas, aby podpatrzeć nasz sposób życia, oparty na wolności, jaką mamy dzięki Chrystusowi Jezusowi - chcieli nas uczynić niewolnikami.
###### **Ga 2,5**
 Lecz nie ustąpiliśmy ani przez chwilę ich żądaniu. Chodziło przecież o to, by zachować prawdę ewangelii wśród was.
###### **Ga 2,6**
 Co zaś do tych, którzy cieszą się poważaniem - nie obchodzi mnie, jacy oni kiedyś byli: Bóg nie patrzy na wygląd człowieka - otóż ci, cieszący się poważaniem, żadnych uzupełnień mi nie zlecili.
###### **Ga 2,7**
 Wręcz przeciwnie: widząc, że powierzono mi głoszenie ewangelii wśród pogan, podobnie jak Piotrowi wśród Żydów -
###### **Ga 2,8**
 Ten bowiem, który dał Piotrowi moc sprawowania posłannictwa wśród Żydów, dał ją i mnie wśród pogan -
###### **Ga 2,9**
 i wiedząc o łasce, jaką otrzymałem, Jakub, Kefas i Jan, uważani za filary, podali ręce mnie i Barnabie na znak wspólnoty. Myśmy mieli pójść do pogan, oni natomiast do Żydów.
###### **Ga 2,10**
 Mieliśmy również pamiętać o ubogich, co też skwapliwie czyniłem.
###### **Ga 2,11**
 Kiedy jednak Kefas przybył do Antiochii, sprzeciwiłem się mu otwarcie, ponieważ sobie na to zasłużył.
###### **Ga 2,12**
 Zanim bowiem przybyli pewni ludzie od Jakuba, spożywał posiłki razem z nawróconymi z pogaństwa. Skoro zaś tamci przybyli, zaczął się wycofywać i unikać pogan w obawie przed Żydami.
###### **Ga 2,13**
 Podobnie też zaczęli postępować pozostali Żydzi. Nawet Barnaba nie oparł się temu.
###### **Ga 2,14**
 Kiedy spostrzegłem, że nie postępują zgodnie z prawdą ewangeliczną, powiedziałem Kefasowi wobec wszystkich: Jeżeli ty, będąc Żydem, postępujesz według zwyczaju pogańskiego, a nie żydowskiego, to dlaczego zmuszasz pogan, aby żyli na sposób żydowski?
###### **Ga 2,15**
 My z urodzenia jesteśmy Żydami, a nie grzesznymi poganami.
###### **Ga 2,16**
 Wiemy jednak, że człowiek dostępuje usprawiedliwienie nie przez spełnianie uczynków nakazanych przez Prawo, lecz dzięki wierze w Chrystusa Jezusa. Dlatego myśmy właśnie uwierzyli w Chrystusa Jezusa, aby doznać usprawiedliwienia dzięki wierze w Chrystusa, a nie dzięki spełnianiu uczynków nakazanych przez Prawo. "Żaden człowiek bowiem nie osiągnie usprawiedliwienia" przez spełnianie uczynków nakazanych przez Prawo.
###### **Ga 2,17**
 Jeżeli jednak szukamy usprawiedliwienia w Chrystusie, a mimo wszystko poczytuje się nas za grzeszników, to czyż Chrystus miałby być sługą grzechu? Na pewno nie!
###### **Ga 2,18**
 Jeśli odbudowuję to, co zburzyłem, staję się przestępcą.
###### **Ga 2,19**
 Ja bowiem właśnie dzięki Prawu umarłem dla Prawa, abym żył dla Boga. Z Chrystusem jestem współukrzyżowany.
###### **Ga 2,20**
 Już nie ja żyję, lecz żyje we mnie Chrystus. Żyję teraz na ziemi, żyję w wierze Syna Bożego, który mnie umiłował i ofiarował się za mnie.
###### **Ga 2,21**
 Nie lekceważę łaski Boga. Jeśli bowiem usprawiedliwienie zyskuje się dzięki Prawu, to Chrystus umarł na próżno.
# Ga 2 BR
###### **Ga 2,1**
 Po czternastu latach wróci- łem do Jerozolimy z Barnabą. Był ze mną wtedy również i Tytus.
###### **Ga 2,2**
 Udałem się tam zgodnie z poleceniem, które otrzymałem z góry, i [naprzód wobec wszystkich, a potem] osobno tym, którzy posiadali szczególną władzę, przedstawiłem Ewangelię, głoszoną przeze mnie wśród pogan. Chodziło o to, by się przekonać, czy moje zarówno dawne, jak i obecne głoszenie [Ewangelii] jest zgodne [z ich nauczaniem].
###### **Ga 2,3**
 Otóż okazało się, że nawet nie zmuszano do obrzezania Tytusa, który był Grekiem.
###### **Ga 2,4**
 Sprawa [obrzezania Tytusa] wyłoniła się zresztą w związku z tym, że przedostali się na zebranie fałszywi bracia, usiłujący przekonać się, jaka jest owa wolność nasza, którą się chlubimy w Jezusie Chrystusie. W rzeczywistości chodziło im o to, by nas pozbawić tej wolności.
###### **Ga 2,5**
 Lecz nie zgodziliśmy się na żadne ustępstwo, w trosce o to, by zachować dla was nienaruszoną prawdę Ewangelii.
###### **Ga 2,6**
 Natomiast ci, którzy uchodzili za władzę mających - nie interesuje mnie to, kim byli przedtem, Bóg i tak nie sądzi według pozorów - nie zgłosili żadnych uzupełnień [do mojego nauczania].
###### **Ga 2,7**
 Przeciwnie, skoro stwierdzili, że mnie zostało powierzone głoszenie Ewangelii wśród nie obrzezanych - podobnie jak Piotrowi wśród obrzezanych -
###### **Ga 2,8**
 bo przecież ten sam [Bóg], który współdziałał z Piotrem apostołującym wśród obrzezanych, współdziałał i ze mną, gdy nauczałem nie obrzezanych -
###### **Ga 2,9**
 i gdy przyznali, że Bóg również mnie udzielił łaski [apostołowania], wtedy Jakub, Kefas i Jan, uważani za filary [tamtejszego Kościoła], podali ręce mnie i Barnabie. W ten sposób uzgodniliśmy, że my udamy się do pogan, a oni będą nauczać obrzezanych.
###### **Ga 2,10**
 Zobowiązano nas jedynie do tego, żebyśmy pamiętali o ubogich, co też starałem się czynić z całą gorliwością.
###### **Ga 2,11**
 A kiedy przybył do Antiochii Kefas, wystąpiłem przeciwko niemu całkiem jawnie, ponieważ [rzeczywiście] był w błędzie.
###### **Ga 2,12**
 Dopóki bowiem nie przybyli pewni wysłannicy Jakuba, jadał razem z [tymi, którzy przedtem byli] poganami. Lecz gdy pojawili się owi ludzie, odsunął się od pogan i trzymał się z dala od nich w obawie przed tymi, którzy byli obrzezani.
###### **Ga 2,13**
 Jego obłudne postępowanie poczęli z czasem naśladować także pozostali Żydzi. W końcu nawet Barnaba dał się wciągnąć w to udawanie.
###### **Ga 2,14**
 Kiedy więc zobaczyłem, że nie postępują zgodnie z prawdą Ewangelii, wobec wszystkich powiedziałem Kefasowi: Jeżeli ty sam, mimo że jesteś Żydem, jeszcze do niedawna swoim zachowaniem się przestrzegałeś obyczajów pogańskich, a nie żydowskich, to jakże możesz zmuszać pogan, żeby postępowali jak Żydzi?
###### **Ga 2,15**
 My sami jesteśmy Żydami z urodzenia, a nie poganami pogrążonymi w grzechach.
###### **Ga 2,16**
 Jesteśmy jednak przekonani, że człowiek dostępuje usprawiedliwienia nie przez uczynki płynące z przestrzegania Prawa, lecz przez wiarę w Jezusa Chrystusa. I my uwierzyliśmy w Chrystusa Jezusa, aby osiągnąć usprawiedliwienie dzięki wierze w Chrystusa, a nie wskutek wypełniania tego, co nakazuje Prawo. Wiadomo przecież, że nikt nie osiągnie usprawiedliwienia za to, że dokonywał uczynków nakazanych przez Prawo.
###### **Ga 2,17**
 A jeżeli szukających usprawiedliwienia w Chrystusie uważa się za grzeszników [ponieważ nie przestrzegają Prawa], to Chrystusa należałoby uznać za sprawcę grzechu? Wiadomo, że to niemożliwe.
###### **Ga 2,18**
 Jeżeli na nowo usiłuję zbudować to, co przed chwilą zburzyłem, to sam nie okazuję żadnego szacunku dla Prawa.
###### **Ga 2,19**
 Tymczasem ja właśnie wskutek nakazów i zakazów Prawa stałem się martwy dla Prawa po to, bym mógł żyć tylko dla Boga. Z Chrystusem zostałem przybity do krzyża
###### **Ga 2,20**
 i wskutek tego już nie ja żyję; to Chrystus żyje we mnie. Żyję [co prawda] jeszcze moim doczesnym życiem, lecz jest to życie wiarą w Syna Bożego, który mnie ukochał i wydał siebie samego dla mnie.
###### **Ga 2,21**
 Nie mogę wzgardzić łaską Bożą. A jeżeli usprawiedliwienia miałoby się dostępować przez wypełnianie tego, co nakazuje Prawo, to Chrystus umarł nadaremnie.
# Ga 2 WUJ
###### **Ga 2,1**
 Zatem po czternaście lat, szedłem zasię do Jeruzalem z Barnabaszem, wziąwszy i Tytusa.
###### **Ga 2,2**
 A szedłem wedle objawienia: i zniosłem z niemi Ewanielią, którą przepowiadam między Pogany, a z osobna z temi, którzy się zdali być czem i: abym znać nadaremno nie biegł abo też nie biegał.
###### **Ga 2,3**
 Ale ani Tytus, który zemną był, będąc Poganinem, nie był przymuszon obrzezać się,
###### **Ga 2,4**
 Ale dla pokrycie wprowadzonej fałszywej braciej, którzy się wkradli, aby wyszpiegowali wolność naszę, którą mamy w Chrystusie Jezusie, aby nas w niewolą podbili.
###### **Ga 2,5**
 Którymeśmy ani na godzinę poddanością nie ustąpili, aby prawda Ewanieljej trwała u was.
###### **Ga 2,6**
 A od tych, którzy się zdali być czem, (jakiemi kiedy byli, nic mi na tem. Bóg nie ma względy na osobę człowieczą). Bo którzy się zdali być czem, mnie się niczem nie przyłożyli.
###### **Ga 2,7**
 Ale przeciwnym obyczajem, ujrzawszy, że mi jest zwierzona Ewanielia odrzezku, jako Piotrowi obrzezania,
###### **Ga 2,8**
 Abowiem ten, który skutecznie robił w Piotrze na Apostolstwo obrzezania, skutecznie robił i we mnie między Pogany).
###### **Ga 2,9**
 A gdy poznali łaskę, która mi jest dana, Jakób i Cephas i Jan, którzy się zdali być filarami dali mi i Barnabie prawice towarzystwa, abyśmy my do pogan, a oni do obrzezania:
###### **Ga 2,10**
 Tylko, abyśmy pamiętali na ubogie: o com się też starał, abym to uczynił.
###### **Ga 2,11**
 A gdy przyszedł Gephas do Antyochjej, sprzeciwiłem się mu w twarz, iż był godzien naganienia.
###### **Ga 2,12**
 Abowiem przedtem niż przyszli niektórzy od Jakóba, z Pogany jadał: a gdy przyszli, schraniał i odłączał się bojąc się tych, którzy byli z obrzezania.
###### **Ga 2,13**
 I pomagali mu zmyślania inni Żydowie, tak, iż też i Barnabasz był uwiedzion do onego zmyślania.
###### **Ga 2,14**
 Ale gdym obaczył, iż nie prosto szli według prawdy Ewanieljej, rzekłem Cephasowi przed wszystkiemi: Jeśli ty będąc Żydem po pogańsku żywiesz, a nie po Żydowsku: czemuż Pogany przymuszasz żyć po Żydowsku?
###### **Ga 2,15**
 My z narodu Żydowie, a nie z Poganów grzesznicy.
###### **Ga 2,16**
 Lecz wiedząc, iż nie bywa usprawiedliwiony człowiek z uczynków zakonu, jedno przez wiarę Jezusa Chrystusa: i my w Chrystusa Jezusa wierzymy, abyśmy byli usprawiedliwieni z wiary Chrystusowej, a nie z uczynków zakonu: przeto iż nie będzie usprawiedliwione z uczynków zakonu wszelkie ciało.
###### **Ga 2,17**
 A jeśli szukając, abyśmy byli usprawiedliwieni w Chrystusie, jesteśmy nalezieni i sami grzesznemi: izali Chrystus jest sługą grzechu? Nie daj Boże.
###### **Ga 2,18**
 Abowiem jeśli zasię to buduję com zepsował: czynię siebie przestępcą.
###### **Ga 2,19**
 Bom ja przez zakon zakonowi umarł, abym Bogu żył: z Chrystusem jestem przybity do krzyża.
###### **Ga 2,20**
 A żywię, już nie ja, ale żywie we mnie Chrystus. A co teraz żywię w ciele, w wierze żywię syna Bożego, który mię umiłował, i wydał samego siebie za mię.
###### **Ga 2,21**
 Nie odmiatam łaski Bożej. Bo jeśli przez zakon sprawiedliwość, tedy Chrystus próżno umarł.
# Ga 2 STERN
###### **Ga 2,1**
 Po czternastu latach znów udałem się w górę do Jeruszalaim, tym razem z Bar-Nabbą, a zabrałem ze sobą Tytusa.
###### **Ga 2,2**
 Podążyłem w górę posłuszny objawieniu i wyłuszczyłem im Dobrą Nowinę, tak jak ją głoszę pośród nie-Żydów - ale na boku, uznanym przywódcom. Uczyniłem to z obawy, aby mój obecny bądź miniony trud nie był czasem daremny.
###### **Ga 2,3**
 Nie zmuszali oni jednak towarzyszącego mi nie-Żyda Tytusa do poddania się b'rit-mili.
###### **Ga 2,4**
 Sprawa ta wypłynęła w istocie tylko dlatego, że zakradli się jacyś ludzie udający braci - przedostali się chyłkiem, by wybadać naszą wolność, jaką mamy w Mesjaszu Jeszui, ażeby móc nas usidlić.
###### **Ga 2,5**
 Nie ustąpiliśmy im ani przez moment, aby prawda Dobrej Nowiny została dla was zachowana.
###### **Ga 2,6**
 Ponadto ci, którzy byli uznanymi przywódcami - to, kim byli, jest dla mnie bez różnicy, Bóg nie sądzi po zewnętrznych pozorach - przywódcy owi niczego mi już nie dodali.
###### **Ga 2,7**
 Przeciwnie, spostrzegli, że powierzono mi Dobrą Nowinę dla Nieobrzezanych, tak jak Kefie powierzono ją dla Obrzezanych,
###### **Ga 2,8**
 bo Ten, który działa w Kefie, czyniąc go wysłannikiem do Obrzezanych, zadziałał i we mnie, czyniąc mnie wysłannikiem do nie-Żydów.
###### **Ga 2,9**
 Ujrzawszy zatem, jaka łaska została mi dana, Ja'akow, Kefa i Jochanan, uznane filary wspólnoty, wyciągnęli do mnie i Bar-Nabby prawice na znak jedności, abyśmy my poszli do nie-Żydów, a oni do Obrzezanych.
###### **Ga 2,10**
 Mieli jedynie prośbę, ażebyśmy pamiętali o ubogich - której to sprawie nie szczędziłem wysiłków.
###### **Ga 2,11**
 Ponadto kiedy Kefa przybył do Antiochii, sprzeciwiłem się mu, bo w sposób oczywisty błądził.
###### **Ga 2,12**
 Przed przybyciem bowiem pewnych osób ze wspólnoty kierowanej przez Ja'akowa jadał z nieżydowskimi wierzącymi, kiedy jednak ci przybyli, wycofał się z tego i trzymał się na boku, bo bał się stronnictwa, które opowiadało się za obrzezaniem wierzących nie-Żydów.
###### **Ga 2,13**
 A reszta żydowskich wierzących dołączyła do niego w obłudzie, tak że tej ich hipokryzji dał się zwieść nawet Bar-Nabba.
###### **Ga 2,14**
 Kiedy jednak zobaczyłem, że nie idą prostą drogą, zgodnie z prawdą Dobrej Nowiny, powiedziałem Kefie, i to w obecności wszystkich: "Jeśli ty jako Żyd żyjesz jak goj, a nie jak Żyd, to czemu zmuszasz goim, aby żyli jak Żydzi?
###### **Ga 2,15**
 My jesteśmy rodowitymi Żydami, a nie - jak to mówią - "gojskimi grzesznikami".
###### **Ga 2,16**
 W każdym razie doszliśmy do zrozumienia, że człowiek zostaje uznany przez Boga za sprawiedliwego nie na podstawie legalistycznego przestrzegania nakazów Tory, ale przez ufną wierność Mesjasza Jeszui. Dlatego i my złożyliśmy ufność w Mesjaszu Jeszui i staliśmy się Mu wierni, abyśmy mogli zostać uznani za sprawiedliwych na podstawie ufnej wierności Mesjasza, a nie na podstawie legalistycznego przestrzegania nakazów Tory. Bo na podstawie legalistycznego przestrzegania nakazów Tory nikt nie będzie uznany za sprawiedliwego.
###### **Ga 2,17**
 Jeśli jednak starając się o uznanie za sprawiedliwego przez Boga na mocy naszej jedności z Mesjaszem, sami okazujemy się w istocie grzesznikami, to czy Mesjasz jest pomocnikiem i współwinowajcą grzechu? Nigdy w życiu!
###### **Ga 2,18**
 Przecież jeśli na nowo konstruuję jarzmo legalizmu, które zniszczyłem, to w istocie czynię siebie przestępcą.
###### **Ga 2,19**
 Bo pozwalając, aby Tora mówiła sama za siebie, umarłem dla jej tradycyjnej, legalistycznej, błędnej interpretacji, abym mógł żyć w bezpośrednim związku z Bogiem.
###### **Ga 2,20**
 Kiedy Mesjasz został stracony na palu jak zbrodniarz, i ja zostałem stracony, tak że moje próżne ego nie żyje już. Ale żyje we mnie Mesjasz, i życie, które teraz wiodę w moim ciele, wiodę mocą tej samej ufnej wierności Syna Bożego, który mnie ukochał i oddał siebie za mnie.
###### **Ga 2,21**
 Nie odrzucam łaskawego daru Boga, bo jeśli sprawiedliwość uzyskuje się poprzez legalizm, to śmierć Mesjasza była bezcelowa.
# Ga 2 TRO
###### **Ga 2,1**
 **επειτα** *epeita* Następnie [[G1899]] [[ADV]] **δια** *dia* po [[G1223]] [[PREP]] **δεκατεσσαρων** *dekatessarōn* czternastu [[G1180]] WTA-GPN **ετων** *etōn* latach [[G2094]] WTN-GPN **παλιν** *palin* znowu [[G3825]] [[ADV]] **ανεβην** *anebēn* wszedłem – wstąpiłem [[G305]] WTV-2AAI-1S **εις** *eis* do [[G1519]] [[PREP]] **ιεροσολυμα** *ierosolyma* Jerozolimy – [dziedzictwo pokoju] [[G2414]] WTN-ASF **μετα** *meta* z [[G3326]] [[PREP]] **βαρναβα** *barnaba* Barnabą – [syn pocieszenia] [[G921]] [[N-GSM]] **συμπαραλαβων** *symparalabōn* zabrawszy ze sobą – wziąwszy razem [[G4838]] WTV-2AAP-NSM **και** *kai* i [[G2532]] [[CONJ]] **τιτον** *titon* Tytusa [[G5103]] [[N-ASM]]
###### **Ga 2,2**
 **ανεβην** *anebēn* Wszedłem – Wstąpiłem [[G305]] WTV-2AAI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **κατα** *kata* według [[G2596]] [[PREP]] **αποκαλυψιν** *apokalypsin* objawienia [[G602]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **ανεθεμην** *anethemēn* przedłożyłem – wyłożyłem [[G394]] WTV-2AMI-1S **αυτοις** *autois* im [[G846]] WTP-DPM **το** *to* [[G3588]] WTT-ASN **ευαγγελιον** *euangelion* dobrą nowinę [[G2098]] WTN-ASN **ο** *ho* którą [[G3739]] WTR-ASN **κηρυσσω** *kēryssō* głoszę [[G2784]] WTV-PAI-1S **εν** *en* wśród [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPN **εθνεσιν** *ethnesin* narodów – pogan [[G1484]] WTN-DPN **κατ** *kat* na [[G2596]] [[PREP]] **ιδιαν** *idian* osobności [[G2398]] WTA-ASF **δε** *de* zaś [[G1161]] [[CONJ]] **τοις** *tois* [[G3588]] WTT-DPM **δοκουσιν** *dokousin* którzy są uważani [[G1380]] WTV-PAP-DPM **μηπως** *mēpōs* aby czasem nie – aby nie jakoś [[G3381]] [[CONJ]] **εις** *eis* w [[G1519]] [[PREP]] **κενον** *kenon* próżno – puste [[G2756]] WTA-ASM **τρεχω** *trechō* biegłbym [[G5143]] WTV-PAS-1S **η** *ē* lub [[G2228]] WTPRT **εδραμον** *edramon* pobiegłem [[G5143]] WTV-2AAI-1S
###### **Ga 2,3**
 **αλλ** *all* Ale [[G235]] [[CONJ]] **ουδε** *oude* ani [[G3761]] [[ADV]] **τιτος** *titos* Tytus [[G5103]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **συν** *syn* ze [[G4862]] [[PREP]] **εμοι** *emoi* mną [[G1698]] WTP-1DS **ελλην** *hellēn* Grek [[G1672]] [[N-NSM]] **ων** *ōn* będący [[G5607]] [[V-PXP-NSM]] **ηναγκασθη** *ēnagkasthē* został zmuszony – został postawiony w konieczności [[G315]] [[V-API-3S]] **περιτμηθηναι** *peritmēthēnai* (by) zostać obrzezanym [[G4059]] WTV-APN
###### **Ga 2,4**
 **δια** *dia* z powodu [[G1223]] [[PREP]] **δε** *de* zaś [[G1161]] [[CONJ]] **τους** *tous* [[G3588]] WTT-APM **παρεισακτους** *pareisaktous* wprowadzonych potajemnie [[G3920]] WTA-APM **ψευδαδελφους** *pseudadelfous* fałszywych braci – kłamliwych braci [[G5569]] [[N-APM]] **οιτινες** *hoitines* którzy [[G3748]] WTR-NPM **παρεισηλθον** *pareisēlthon* weszli – wkradli się [[G3922]] WTV-2AAI-3P **κατασκοπησαι** *kataskopēsai* (by) wyszpiegować – na szkodę przyjrzeć się [[G2684]] [[V-AAN]] **την** *tēn* [[G3588]] WTT-ASF **ελευθεριαν** *eleutherian* wolności [[G1657]] WTN-ASF **ημων** *hēmōn* naszej [[G2257]] WTP-1GP **ην** *hēn* którą [[G3739]] WTR-ASF **εχομεν** *echomen* mamy [[G2192]] WTV-PAI-1P **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM **ινα** *hina* aby [[G2443]] [[CONJ]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **καταδουλωσωνται** *katadoulōsōntai* zniewoliliby [[G2615]] WTV-AMS-3P
###### **Ga 2,5**
 **οις** *hois* którym [[G3739]] WTR-DPM **ουδε** *oude* ani [[G3761]] [[ADV]] **προς** *pros* na [[G4314]] [[PREP]] **ωραν** *hōran* godzinę [[G5610]] WTN-ASF **ειξαμεν** *eiksamen* ustąpiliśmy [[G1502]] WTV-AAI-1P **τη** *tē* [[G3588]] WTT-DSF **υποταγη** *hypotagē* w posłuszeństwie – podporządkowaniem się [[G5292]] [[N-DSF]] **ινα** *hina* aby [[G2443]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **αληθεια** *alētheia* prawda [[G225]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSN **ευαγγελιου** *euangeliou* dobrej nowiny [[G2098]] [[N-GSN]] **διαμεινη** *diameinē* przetrwałaby – pozostałby [[G1265]] WTV-AAS-3S **προς** *pros* u [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP
###### **Ga 2,6**
 **απο** *apo* Od [[G575]] [[PREP]] **δε** *de* zaś [[G1161]] [[CONJ]] **των** *tōn* (tych) [[G3588]] WTT-GPM **δοκουντων** *dokountōn* uważających [[G1380]] WTV-PAP-GPM **ειναι** *einai* być [[G1511]] WTV-PXN **τι** *ti* czymś [[G5100]] WTX-NSN **οποιοι** *hopoioi* jakimi [[G3697]] WTA-NPM **ποτε** *pote* dawniej [[G4218]] WTPRT **ησαν** *ēsan* byli [[G2258]] WTV-IXI-3P **ουδεν** *ouden* nic [[G3762]] WTA-NSN **μοι** *moi* mi [[G3427]] WTP-1DS **διαφερει** *diaferei* czyni różnicy [[G1308]] WTV-PAI-3S **προσωπον** *prosōpon* oblicze [[G4383]] WTN-ASN **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ανθρωπου** *anthrōpou* człowieka [[G444]] [[N-GSM]] **ου** *ou* nie [[G3756]] [[PRT-N]] **λαμβανει** *lambanei* bierze – przyjmuje [[G2983]] WTV-PAI-3S **εμοι** *emoi* mnie [[G1698]] WTP-1DS **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **οι** *hoi* (ci) [[G3588]] WTT-NPM **δοκουντες** *dokountes* którzy są uważani [[G1380]] WTV-PAP-NPM **ουδεν** *ouden* nic [[G3762]] WTA-ASN **προσανεθεντο** *prosanethento* dodatkowo nałożyli [[G4323]] WTV-2AMI-3P
###### **Ga 2,7**
 **αλλα** *alla* ale [[G235]] [[CONJ]] **τουναντιον** *tounantion* przeciwnie [[G5121]] [[ADV]]-C **ιδοντες** *idontes* zobaczywszy [[G1492]] WTV-2AAP-NPM **οτι** *hoti* że [[G3754]] [[CONJ]] **πεπιστευμαι** *pepisteumai* jest mi powierzona [[G4100]] WTV-RPI-1S **το** *to* [[G3588]] WTT-ASN **ευαγγελιον** *euangelion* dobra nowina [[G2098]] WTN-ASN **της** *tēs* [[G3588]] [[T-GSF]] **ακροβυστιας** *akrobystias* nieobrzezania [[G203]] [[N-GSF]] **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **πετρος** *petros* Piotr(owi) – [kamyk] [[G4074]] [[N-NSM]] **της** *tēs* [[G3588]] [[T-GSF]] **περιτομης** *peritomēs* obrzezania [[G4061]] [[N-GSF]]
###### **Ga 2,8**
 **ο** *ho* [[G3588]] [[T-NSM]] **γαρ** *gar* Bowiem [[G1063]] [[CONJ]] **ενεργησας** *energēsas* który działał w [[G1754]] WTV-AAP-NSM **πετρω** *petrō* Piotrze – [kamyk] [[G4074]] WTN-DSM **εις** *eis* do [[G1519]] [[PREP]] **αποστολην** *apostolēn* wysłannictwa [[G651]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **περιτομης** *peritomēs* obrzezania [[G4061]] [[N-GSF]] **ενηργησεν** *enērgēsen* działał we [[G1754]] [[V-AAI-3S]] **και** *kai* i [[G2532]] [[CONJ]] **εμοι** *emoi* mnie [[G1698]] WTP-1DS **εις** *eis* do [[G1519]] [[PREP]] **τα** *ta* [[G3588]] WTT-APN **εθνη** *ethnē* narodów – pogan [[G1484]] WTN-APN
###### **Ga 2,9**
 **και** *kai* i [[G2532]] [[CONJ]] **γνοντες** *gnontes* poznawszy [[G1097]] WTV-2AAP-NPM **την** *tēn* [[G3588]] WTT-ASF **χαριν** *charin* łaskę [[G5485]] WTN-ASF **την** *tēn* [[G3588]] WTT-ASF **δοθεισαν** *dotheisan* która została dana [[G1325]] WTV-APP-ASF **μοι** *moi* mi [[G3427]] WTP-1DS **ιακωβος** *iakōbos* Jakub – [pięta] [[G2385]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **κηφας** *kēfas* Kefas – [skała] [[G2786]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ιωαννης** *iōannēs* Jan – [JHWH jest łaskawy] [[G2491]] [[N-NSM]] **οι** *hoi* (ci) [[G3588]] WTT-NPM **δοκουντες** *dokountes* którzy są uważani [[G1380]] WTV-PAP-NPM **στυλοι** *styloi* (za) filary – (za) kolumny [[G4769]] WTN-NPM **ειναι** *einai* być [[G1511]] WTV-PXN **δεξιας** *deksias* prawice [[G1188]] WTA-APF **εδωκαν** *edōkan* dali [[G1325]] WTV-AAI-3P **εμοι** *emoi* mi [[G1698]] WTP-1DS **και** *kai* i [[G2532]] [[CONJ]] **βαρναβα** *barnaba* Barnabie – [syn pocieszenia] [[G921]] WTN-DSM **κοινωνιας** *koinōnias* wspólnoty [[G2842]] [[N-GSF]] **ινα** *hina* aby [[G2443]] [[CONJ]] **ημεις** *hēmeis* my [[G2249]] WTP-1NP **εις** *eis* do [[G1519]] [[PREP]] **τα** *ta* [[G3588]] WTT-APN **εθνη** *ethnē* narodów – pogan [[G1484]] WTN-APN **αυτοι** *autoi* oni [[G846]] WTP-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **εις** *eis* do [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **περιτομην** *peritomēn* obrzezania [[G4061]] WTN-ASF
###### **Ga 2,10**
 **μονον** *monon* jedynie – tylko [[G3440]] [[ADV]] **των** *tōn* (o) [[G3588]] WTT-GPM **πτωχων** *ptōchōn* ubogich [[G4434]] WTA-GPM **ινα** *hina* aby [[G2443]] [[CONJ]] **μνημονευωμεν** *mnēmoneuōmen* pamiętalibyśmy – przypominalibyśmy sobie [[G3421]] WTV-PAS-1P **ο** *ho* co [[G3739]] WTR-ASN **και** *kai* i [[G2532]] [[CONJ]] **εσπουδασα** *espoudasa* pilnie starałem się – wykazałem gorliwość [[G4704]] WTV-AAI-1S **αυτο** *auto* (by) samo [[G846]] WTP-ASN **τουτο** *touto* to [[G5124]] WTD-ASN **ποιησαι** *poiēsai* uczynić [[G4160]] [[V-AAN]]
###### **Ga 2,11**
 **οτε** *hote* Gdy [[G3753]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **ηλθεν** *ēlthen* przyszedł [[G2064]] WTV-2AAI-3S **πετρος** *petros* Piotr – [kamyk] [[G4074]] [[N-NSM]] **εις** *eis* do [[G1519]] [[PREP]] **αντιοχειαν** *antiocheian* Antiochii [[G490]] WTN-ASF **κατα** *kata* w [[G2596]] [[PREP]] **προσωπον** *prosōpon* twarz – oblicze [[G4383]] WTN-ASN **αυτω** *autō* mu [[G846]] WTP-DSM **αντεστην** *antestēn* przeciwstawiłem się – stanąłem przeciw [[G436]] WTV-2AAI-1S **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **κατεγνωσμενος** *kategnōsmenos* który jest obwiniony [[G2607]] WTV-RPP-NSM **ην** *ēn* był [[G2258]] [[V-IXI-3S]]
###### **Ga 2,12**
 **προ** *pro* Przed [[G4253]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ελθειν** *elthein* przyjść [[G2064]] [[V-2AAN]] **τινας** *tinas* ktoś – niektórzy [[G5100]] WTX-APM **απο** *apo* od [[G575]] [[PREP]] **ιακωβου** *iakōbou* Jakuba – [pięta] [[G2385]] [[N-GSM]] **μετα** *meta* z [[G3326]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **εθνων** *ethnōn* poganami – narodami [[G1484]] WTN-GPN **συνησθιεν** *synēsthien* jadł razem [[G4906]] WTV-IAI-3S **οτε** *hote* gdy [[G3753]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **ηλθον** *ēlthon* przyszli [[G2064]] WTV-2AAI-3P **υπεστελλεν** *hypestellen* powstrzymał się – cofnął się [[G5288]] WTV-IAI-3S **και** *kai* i [[G2532]] [[CONJ]] **αφωριζεν** *afōrizen* odłączył – oddzielił [[G873]] WTV-IAI-3S **εαυτον** *heauton* samego siebie [[G1438]] WTF-3ASM **φοβουμενος** *foboumenos* bojąc się – lękając się [[G5399]] WTV-PNP-NSM **τους** *tous* (tych) [[G3588]] WTT-APM **εκ** *ek* z [[G1537]] [[PREP]] **περιτομης** *peritomēs* obrzezania [[G4061]] [[N-GSF]]
###### **Ga 2,13**
 **και** *kai* I [[G2532]] [[CONJ]] **συνυπεκριθησαν** *synypekrithēsan* byli obłudni razem z [[G4942]] WTV-API-3P **αυτω** *autō* nim [[G846]] WTP-DSM **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **λοιποι** *loipoi* pozostali [[G3062]] WTA-NPM **ιουδαιοι** *ioudaioi* Judejczycy – [wielbić] [[G2453]] WTA-NPM **ωστε** *hōste* tak, że [[G5620]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **βαρναβας** *barnabas* Barnaba – [syn pocieszenia] [[G921]] [[N-NSM]] **συναπηχθη** *synapēchthē* dał się razem odprowadzić [[G4879]] [[V-API-3S]] **αυτων** *autōn* ich [[G846]] WTP-GPM **τη** *tē* [[G3588]] WTT-DSF **υποκρισει** *hypokrisei* obłudzie – hipokryzji [[G5272]] [[N-DSF]]
###### **Ga 2,14**
 **αλλ** *all* Ale [[G235]] [[CONJ]] **οτε** *hote* gdy [[G3753]] [[ADV]] **ειδον** *eidon* zobaczyłem [[G1492]] WTV-2AAI-1S **οτι** *hoti* że [[G3754]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ορθοποδουσιν** *orthopodousin* prosto kroczą – uczciwie kroczą [[G3716]] WTV-PAI-3P **προς** *pros* względem [[G4314]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **αληθειαν** *alētheian* prawdy [[G225]] WTN-ASF **του** *tou* [[G3588]] WTT-GSN **ευαγγελιου** *euangeliou* dobrej nowiny [[G2098]] [[N-GSN]] **ειπον** *eipon* powiedziałem [[G2036]] WTV-2AAI-1S **τω** *tō* [[G3588]] WTT-DSM **πετρω** *petrō* Piotrowi – [kamyk] [[G4074]] WTN-DSM **εμπροσθεν** *emprosthen* przed [[G1715]] [[PREP]] **παντων** *pantōn* wszystkimi [[G3956]] WTA-GPM **ει** *ei* jeśli [[G1487]] WTCOND **συ** *sy* ty [[G4771]] WTP-2NS **ιουδαιος** *ioudaios* Judejczyk – [wielbić] [[G2453]] [[A-NSM]] **υπαρχων** *hyparchōn* będąc [[G5225]] [[V-PAP-NSM]] **εθνικως** *ethnikōs* na sposób pogan – na sposób narodów [[G1483]] [[ADV]] **ζης** *zēs* żyjesz [[G2198]] WTV-PAI-2S **και** *kai* i [[G2532]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ιουδαικως** *ioudaikōs* na sposób Judejczyków – na sposób [wielbić] [[G2452]] [[ADV]] **τι** *ti* czemu [[G5101]] WTI-ASN **τα** *ta* [[G3588]] WTT-APN **εθνη** *ethnē* pogan – narodów [[G1484]] WTN-APN **αναγκαζεις** *anagkazeis* zmuszasz – czynisz koniecznym [[G315]] WTV-PAI-2S **ιουδαιζειν** *ioudaizein* (by) żyć na sposób judejski – (by) żyć na sposób [wielbić] [[G2450]] WTV-PAN
###### **Ga 2,15**
 **ημεις** *hēmeis* My [[G2249]] WTP-1NP **φυσει** *fysei* (z) natury [[G5449]] [[N-DSF]] **ιουδαιοι** *ioudaioi* Judejczycy – [wielbić] [[G2453]] WTA-NPM **και** *kai* i [[G2532]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εξ** *eks* z [[G1537]] [[PREP]] **εθνων** *ethnōn* pogan – narodów [[G1484]] WTN-GPN **αμαρτωλοι** *hamartōloi* grzesznicy [[G268]] WTA-NPM
###### **Ga 2,16**
 **ειδοτες** *eidotes* wiedząc [[G1492]] WTV-RAP-NPM **οτι** *hoti* że [[G3754]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **δικαιουται** *dikaioutai* jest uznawany za sprawiedliwego – jest usprawiedliwiany [[G1344]] WTV-PPI-3S **ανθρωπος** *anthrōpos* człowiek [[G444]] [[N-NSM]] **εξ** *eks* z – od [[G1537]] [[PREP]] **εργων** *ergōn* czynów – uczynków [[G2041]] WTN-GPN **νομου** *nomou* Prawa [[G3551]] [[N-GSM]] **εαν** *ean* jeśli [[G1437]] WTCOND **μη** *mē* nie [[G3361]] [[PRT-N]] **δια** *dia* przez [[G1223]] [[PREP]] **πιστεως** *pisteōs* wiarę [[G4102]] [[N-GSF]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **ημεις** *hēmeis* my [[G2249]] WTP-1NP **εις** *eis* w [[G1519]] [[PREP]] **χριστον** *christon* Pomazańca [[G5547]] [[N-ASM]] **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]] **επιστευσαμεν** *episteusamen* uwierzyliśmy [[G4100]] WTV-AAI-1P **ινα** *hina* aby [[G2443]] [[CONJ]] **δικαιωθωμεν** *dikaiōthōmen* zostalibyśmy uznani za sprawiedliwych – zostalibyśmy usprawiedliwieni [[G1344]] WTV-APS-1P **εκ** *ek* z [[G1537]] [[PREP]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εξ** *eks* z [[G1537]] [[PREP]] **εργων** *ergōn* czynów – uczynków [[G2041]] WTN-GPN **νομου** *nomou* Prawa [[G3551]] [[N-GSM]] **διοτι** *dioti* dlatego, że [[G1360]] [[CONJ]] **ου** *hou* nie [[G3756]] [[PRT-N]] **δικαιωθησεται** *dikaiōthēsetai* zostanie uznany za sprawiedliwego – zostanie usprawiedliwiony [[G1344]] WTV-FPI-3S **εξ** *eks* z – od [[G1537]] [[PREP]] **εργων** *ergōn* czynów – uczynków [[G2041]] WTN-GPN **νομου** *nomou* Prawa [[G3551]] [[N-GSM]] **πασα** *pasa* każde – wszelkie [[G3956]] WTA-NSF **σαρξ** *sarks* ciało [[G4561]] [[N-NSF]]
###### **Ga 2,17**
 **ει** *ei* Jeśli [[G1487]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **ζητουντες** *zētountes* szukając [[G2212]] WTV-PAP-NPM **δικαιωθηναι** *dikaiōthēnai* (by) zostać uznanymi za sprawiedliwych – (by) zostać usprawiedliwionymi [[G1344]] WTV-APN **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ευρεθημεν** *heurethēmen* zostaliśmy znalezieni [[G2147]] WTV-API-1P **και** *kai* i [[G2532]] [[CONJ]] **αυτοι** *autoi* sami [[G846]] WTP-NPM **αμαρτωλοι** *hamartōloi* (jako) grzesznicy [[G268]] WTA-NPM **αρα** *ara* czy zatem [[G687]] WTPRT-I **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **αμαρτιας** *hamartias* grzechu [[G266]] [[N-GSF]] **διακονος** *diakonos* sługa [[G1249]] [[N-NSM]] **μη** *mē* nie [[G3361]] [[PRT-N]] **γενοιτο** *genoito* oby stał się [[G1096]] WTV-2ADO-3S
###### **Ga 2,18**
 **ει** *ei* Jeśli [[G1487]] WTCOND **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **α** *ha* co [[G3739]] WTR-APN **κατελυσα** *katelysa* obaliłem [[G2647]] WTV-AAI-1S **ταυτα** *tauta* te [[G5023]] WTD-APN **παλιν** *palin* znowu [[G3825]] [[ADV]] **οικοδομω** *oikodomō* buduję [[G3618]] WTV-PAI-1S **παραβατην** *parabatēn* (jako) przestępcę [[G3848]] [[N-ASM]] **εμαυτον** *emauton* siebie [[G1683]] WTF-1ASM **συνιστημι** *synistēmi* polecam – razem stoję [[G4921]] WTV-PAI-1S
###### **Ga 2,19**
 **εγω** *egō* Ja [[G1473]] WTP-1NS **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **δια** *dia* z powodu [[G1223]] [[PREP]] **νομου** *nomou* Prawa [[G3551]] [[N-GSM]] **νομω** *nomō* Prawu [[G3551]] WTN-DSM **απεθανον** *apethanon* umarłem [[G599]] WTV-2AAI-1S **ινα** *hina* aby [[G2443]] [[CONJ]] **θεω** *theō* Bogu [[G2316]] WTN-DSM **ζησω** *zēsō* żyłbym [[G2198]] WTV-AAS-1S
###### **Ga 2,20**
 **χριστω** *christō* (z) Pomazańcem [[G5547]] WTN-DSM **συνεσταυρωμαι** *synestaurōmai* jestem ukrzyżowany razem [[G4957]] WTV-RPI-1S **ζω** *zō* żyję [[G2198]] WTV-PAI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **ουκετι** *ouketi* już nie [[G3765]] [[ADV]] **εγω** *egō* ja [[G1473]] WTP-1NS **ζη** *zē* żyje [[G2198]] WTV-PAI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **εν** *en* we [[G1722]] [[PREP]] **εμοι** *emoi* mnie [[G1698]] WTP-1DS **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **ο** *ho* co [[G3739]] WTR-ASN **δε** *de* zaś [[G1161]] [[CONJ]] **νυν** *nyn* teraz [[G3568]] [[ADV]] **ζω** *zō* żyję [[G2198]] WTV-PAI-1S **εν** *en* w [[G1722]] [[PREP]] **σαρκι** *sarki* ciele [[G4561]] [[N-DSF]] **εν** *en* w [[G1722]] [[PREP]] **πιστει** *pistei* wierze [[G4102]] [[N-DSF]] **ζω** *zō* żyję [[G2198]] WTV-PAI-1S **τη** *tē* (tej) [[G3588]] WTT-DSF **του** *tou* (w) [[G3588]] WTT-GSM **υιου** *hyiou* Syna [[G5207]] [[N-GSM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **του** *tou* (Tego) [[G3588]] WTT-GSM **αγαπησαντος** *agapēsantos* który umiłował [[G25]] WTV-AAP-GSM **με** *me* mnie [[G3165]] WTP-1AS **και** *kai* i [[G2532]] [[CONJ]] **παραδοντος** *paradontos* który wydał [[G3860]] WTV-2AAP-GSM **εαυτον** *heauton* samego siebie [[G1438]] WTF-3ASM **υπερ** *hyper* za [[G5228]] [[PREP]] **εμου** *emou* mnie [[G1700]] WTP-1GS
###### **Ga 2,21**
 **ουκ** *ouk* Nie [[G3756]] [[PRT-N]] **αθετω** *athetō* unieważniam – odrzucam [[G114]] WTV-PAI-1S-C **την** *tēn* [[G3588]] WTT-ASF **χαριν** *charin* łaski [[G5485]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ει** *ei* jeśli [[G1487]] WTCOND **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **δια** *dia* przez [[G1223]] [[PREP]] **νομου** *nomou* Prawo [[G3551]] [[N-GSM]] **δικαιοσυνη** *dikaiosynē* sprawiedliwość – usprawiedliwienie [[G1343]] [[N-NSF]] **αρα** *ara* zatem [[G686]] WTPRT **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **δωρεαν** *dōrean* darmo – próżno [[G1432]] [[ADV]] **απεθανεν** *apethanen* umarł [[G599]] WTV-2AAI-3S
