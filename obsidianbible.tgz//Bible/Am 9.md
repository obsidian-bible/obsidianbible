# Am 9 BT5
###### **Am 9,1**
 Widziałem Pana stojącego nad ołtarzem, i On rzekł:«***Uderz w głowicę i niech zadrżą wiązania dachu, i niech spadną na głowy wszystkich!Pozabijam mieczem pozostałych, nie umknie z nich żaden, który ucieka, ani nie ocaleje z nich żaden, co się ratuje.
###### **Am 9,2**
 Gdyby się włamali do Szeolu, stamtąd ręka moja ich zabierze; gdyby wstąpili do nieba, stamtąd ich ściągnę;
###### **Am 9,3**
 gdyby schowali się na szczycie Karmelu, i tam ich znajdę i pochwycę. Gdyby się skryli przed mymi oczami w głębokościach morza, i tam nakażę wężowi, aby ich ukąsił.
###### **Am 9,4**
 Gdyby poszli w niewolę przed swymi wrogami, i tam nakażę mieczowi, by ich pozabijał. Skieruję oczy moje na nich, ale dla niedoli, a nie dla ich dobra***».
###### **Am 9,5**
 Pan, Bóg Zastępów, dotyka ziemi, a ona drży, tak że lamentują wszyscy jej mieszkańcy; wzbiera ona jak Nili opada jak Nil egipski.
###### **Am 9,6**
 [Pan] zbudował na niebiosach pałac wysoki, a sklepienie jego oparł o ziemię; zwołuje wody morskiei rozlewa je na powierzchni ziemi, Pan – oto imię Jego.
###### **Am 9,7**
 Czyż nie jesteście dla Mnie jak Kuszyci,wy, synowie Izraela?– wyrocznia Pana. Czyż Izraela nie wyprowadziłem z ziemi egipskiejjak Filistynów z Kaftor, a Aramejczyków z Kir?
###### **Am 9,8**
 Oto oczy moje, Pana Boga, zwrócone są na królestwo grzeszne, i zgładzę je z powierzchni ziemi. Nie zgładzę jednak zupełnie domu Jakuba– wyrocznia Pana.
###### **Am 9,9**
 Gdyż oto Ja rozkażęi przesieję pomiędzy wszystkimi narodami dom Izraela, jak się przetakiem przesiewa, a żadne ziarnko nie upada na ziemię.
###### **Am 9,10**
 Od miecza zginą wszyscy grzesznicy z mego ludu, ci, którzy mówią:«***Nie zbliży się ani nie dotknie nas niedola***».
###### **Am 9,11**
 W tym dniu podniosę szałas Dawidowy, który upada, zamuruję jego szczeliny, ruiny jego podźwignęi jak za dawnych dni go zbuduję,
###### **Am 9,12**
 by posiedli resztę Edomu i wszystkie narody, nad którymi wzywano mojego imienia– wyrocznia Pana, który to uczyni.
###### **Am 9,13**
 Oto nadejdą dni – wyrocznia Pana –gdy będzie postępował żniwiarz [zaraz] za oraczem, a depczący winogrona za siejącym ziarno; z gór moszcz spływać będzie kroplami,a wszystkie pagórki będą w niego opływać.
###### **Am 9,14**
 Uwolnię z niewoli lud mój izraelski –odbudują miasta zburzone i będą w nich mieszkać; zasadzą winnice i pić będą wino; założą ogrody i będą jedli z nich owoce.
###### **Am 9,15**
 Zasadzę ich na ich ziemi, a nigdy nie będą wyrwani z ziemi, którą im dałem –mówi Pan, twój Bóg.
# Am 9 PAU
###### **Am 9,1**
 Widziałem PANA stojącego nad ołtarzem. Powiedział mi: „Uderz w kolumnę, niech zadrżą wiązania dachu i niech spadną na głowy wszystkich! Mieczem pozabijam pozostałych, nikt z nich nie zdoła uciec, żaden nie ocaleje.
###### **Am 9,2**
 Choćby schowali się w krainie umarłych, nawet stamtąd moja ręka ich wyciągnie. Choćby wstąpili do nieba, również stamtąd ich ściągnę.
###### **Am 9,3**
 Choćby schowali się na szczycie Karmelu, znajdę ich tam i pochwycę. Choćby się skryli przed moimi oczami w morskich głębinach, i tam nakażę wężowi, aby ich ukąsił.
###### **Am 9,4**
 Choćby poszli w niewolę, pędzeni przez wrogów, także tam każę mieczowi, by ich pozabijał. Zwrócę na nich moje oczy, dla niedoli, a nie dla ich dobra”.
###### **Am 9,5**
 PAN, BÓG Zastępów, uderza w ziemię, a ona się trzęsie i lamentują wszyscy jej mieszkańcy; cała unosi się jak Nil i opada jak rzeka Egiptu.
###### **Am 9,6**
 On zbudował swój tron na niebiosach, a jego sklepienie oparł o ziemię. Przywołuje wody morskie i rozlewa je po powierzchni ziemi. Nosi On imię PAN!
###### **Am 9,7**
 Wyrocznia PANA: Izraelici! Czy nie jesteście dla Mnie jak Kuszyci? Czyż nie wyprowadziłem Izraela z ziemi egipskiej, Filistynów z Kaftor, a Aramejczyków z Kir?
###### **Am 9,8**
 Oto oczy PANA BOGA zwrócone są przeciw grzesznemu królestwu: zgładzę je z powierzchni ziemi. Nie zgładzę jednak całkowicie domu Jakuba - wyrocznia PANA.
###### **Am 9,9**
 Bo oto Ja rozkażę przesiać dom Izraela wśród wszystkich narodów, jak się przesiewa przetakiem, aby żadne ziarnko nie upadło na ziemię.
###### **Am 9,10**
 Wszyscy grzesznicy z mego ludu zginą od miecza, wszyscy ci, którzy mówili: „Nie dosięgnie nas ani nie dotknie niedola”.
###### **Am 9,11**
 W tym dniu podniosę szałas Dawida, chylący się ku upadkowi. Załatam jego dziury, podźwignę go z upadku i odnowię go jak za dawnych dni.
###### **Am 9,12**
 Posiądą resztę Edomu i wszystkie narody, nad którymi wzywano mojego imienia - wyrocznia PANA, który uczyni to wszystko.
###### **Am 9,13**
 Wyrocznia PANA: Oto nadejdą dni, gdy żniwiarz będzie szedł za oraczem, a depczący winogrona za siejącym ziarno; z gór będzie spływać moszcz, wszystkie pagórki będą nim opływać.
###### **Am 9,14**
 Odmienię los mojego ludu izraelskiego, odbudują zburzone miasta i w nich zamieszkają; zasadzą winnice i pić będą wino; założą ogrody i będą jeść z nich owoce.
###### **Am 9,15**
 I zasadzę ich na ich ziemi, i już nigdy nie będą wyrwani z ziemi, którą im dałem- mówi PAN, twój Bóg.
# Am 9 BP
###### **Am 9,1**
 Widziałem Pana stojącego przy ołtarzu. Powiedział: "Uderz w głowicę, a zatrzęsą się progi, ugódź ich wszystkich w głowę, a pozostałych Ja pozabijam mieczem. Żaden z nich nie zdoła się uratować ucieczką, żaden z nich nie ujdzie z życiem.
###### **Am 9,2**
 Choćby się przedarli do Szeolu, wyciągnie ich stamtąd ręka moja; choćby wstąpili pod samo niebo, ściągnę ich stamtąd w dół;
###### **Am 9,3**
 choćby się chcieli ukryć na szczycie Karmelu, odnajdę ich i pochwycę; choćby się nawet na samym dnie morza schowali przed moim okiem, rozkażę wężowi, aby ich tam kąsał.
###### **Am 9,4**
 Gdy pójdą w niewolę, pędzeni przez swych wrogów, rozkażę mieczowi, by tam ich zabijał. Zwróciłem na nich swe oczy ku ich nieszczęściu, a nie ku ich dobru".
###### **Am 9,5**
 Jahwe, Pan Zastępów! Gdy dotyka ziemi, rozstępuje się i wszyscy jej mieszkańcy pogrążają się w żałobie; podnosi się cała jak Nil i podobnie jak Rzeka Egiptu - opada.
###### **Am 9,6**
 On w niebie zbudował stopnie [swego tronu] i oparł o ziemię swe sklepienie; On przywołuje wody morskie, żeby je rozlać po powierzchni ziemi. Jahwe jest Imię Jego!
###### **Am 9,7**
 Czyż nie znaczycie w moich oczach, o synowie Izraela, tyle właśnie, co Kuszy ci? - mówi Jahwe. Czyż nie wywiodłem Izraela z ziemi egipskiej, a Filistynów z Kaftor i Aramejczyków z Kir?
###### **Am 9,8**
 Oto oczy moje - mówi Jahwe-Pan - zwrócone są na to grzeszne królestwo: wytracę je z powierzchni ziemi! Ale Domu Jakuba nie wytracę bez reszty - mówi Jahwe.
###### **Am 9,9**
 Bo oto wydam rozkaz i każę przesiać Dom Izraela wśród wszystkich narodów, podobnie jak się przesiewa [ziarno] w rzeszocie, tak jednak, że żadne ziarenko nie spadnie na ziemię.
###### **Am 9,10**
 Od miecza poginą wszyscy grzesznicy spośród mego ludu, którzy mówią: "Nie spotka nas żadne nieszczęście ani nas nie dosięgnie".
###### **Am 9,11**
 W owym dniu podźwignę z upadku szałas Dawida, jego szczeliny zasklepię, wzniosę na nowo jego ruiny i odbuduję go, jak za dawnych dni,
###### **Am 9,12**
 by zawładnęli tymi, co się żywi ostali z Edomu oraz wszystkimi narodami, które swą nazwę wywodzić będą od mego Imienia - to mówi Jahwe, który tego dokona.
###### **Am 9,13**
 Oto nastaną dni - mówi Jahwe - kiedy spotykać się będzie oracz ze żniwiarzem, a tłoczący wino z siewcą; z gór będzie spływał moszcz winny, a pagórki będą nim ociekały.
###### **Am 9,14**
 Wtedy odmienię losy ludu mego, Izraela: odbudują zniszczone miasta i zamieszkają w nich; zasadzą winnice i będą pili z nich wino; założą ogrody i będą jedli ich owoce.
###### **Am 9,15**
 Zasadzę ich na ojczystej glebie i nigdy już nie zostaną wyrwani ze swej ziemi, którą im dałem - mówi Jahwe, Bóg twój.
# Am 9 BR
###### **Am 9,1**
 Widziałem Pana stojącego przy ołtarzu i słyszałem, jak mówił do mnie: Uderz w wierzchołek kolumny, tak by się poruszyły wiązania dachu. Ja sam wszystkim roztrzaskam głowy. A jeśli ktoś jeszcze ocaleje, tego mieczem zabiję. Nikt nie zdoła się uratować, nikt nie ucieknie, nikt się nie schowa.
###### **Am 9,2**
 A gdyby się nawet do Szeolu, udali, tam także dosięgnie ich moja ręka. Jeżeli do nieba wstąpić im się uda, sprowadzę ich stamtąd na ziemię.
###### **Am 9,3**
 Gdyby się ukryli na szczycie Karmelu, wytropię ich tam i pochwycę. I choćby uciekli przede Mną na samo dno morza, to wężom morskim nakażę, by ich pokąsały.
###### **Am 9,4**
 A gdyby musieli się udać do wrogiej im niewoli, to i tam każę im wszystkim mieczem pozabijać. Ciągle kieruję na nich swoje oczy, lecz ku ich zagładzie, nie ku ocaleniu.
###### **Am 9,5**
 Bóg i Pan Zastępów gdy tylko dotknie ziemi, ona się w proch rozsypuje, w szystkich jej mieszkańców napełnia trwoga. I cała ziemia jakby Nil się wzburzy a potem znów opadnie jak potężna Egiptu rzeka.
###### **Am 9,6**
 To On pałace sobie na niebie zbudował i oparł na ziemi sklepienia niebieskie. To On wydaje rozkazy wodom oceanów i deszcz obfity zsyła na ziemię (spragnioną). Pan zaś jest imię Jego.
###### **Am 9,7**
 O Izraelici, czyście dla Mnie czymś więcej niż zwykli Kuszyci? - wyrocznia Pana. Wyprowadziłem, co prawda, Izraelitów z Egiptu ale także Filistynów z Kaftor, a z Kiru - Aramejczyków.
###### **Am 9,8**
 Oczy Pana Boga patrzą na królestwo grzeszników. Usunę ich zewsząd, gdzie tylko są na ziemi, lecz nie wygubię całkowicie synów domu Jakuba - wyrocznia Pana.
###### **Am 9,9**
 Otóż Ja sam wydam wkrótce rozkazy, by przesiać dom Izraela pośród wszystkich narodów, jak przetakiem przesiewa się ziarna, tak iż żadne z nich nie spada na ziemię.
###### **Am 9,10**
 Wszyscy ci spośród mego ludu, którzy się dopuszczają grzechów, będą musieli zginąć od miecza, wszyscy ci, którzy się pocieszają, że nie przyjdzie na nich i nie spotka ich żadne nieszczęście.
###### **Am 9,11**
 W dniu owym znowu podniosę przewrócony namiot Dawida, rysy wszystkie zamuruję i jak za dni dawnych odbuduję wieże,
###### **Am 9,12**
 by mogli wziąć w swe władanie resztki Edomitów oraz te wszystkie narody, nad którymi me imię już wzywane było - wyrocznia Pana, który wszystko czyni.
###### **Am 9,13**
 Nadchodzą już dni - wyrocznia Pana - gdy oracz będzie deptał żniwiarzowi po piętach, a ugniatający winogrona szedł będzie tuż za siewcą. Góry winem opływać będą, wino będzie płynąć z pagórków.
###### **Am 9,14**
 I odmienię los Izraela, mego ludu. Odbudują znów swoje miasta i mieszkać w nich będą, winnice zaczną uprawiać, pijąc wino do woli, ogrody założą i będą jeść z nich owoce.
###### **Am 9,15**
 Zasadzę ich na ich ziemi i nikt już ich nigdy nie wyrwie z tego kraju, który sam im kiedyś w posiadanie dałem. Tak mówi Pan i Bóg twój.
# Am 9 WUJ
###### **Am 9,1**
 Widziałem Pana stojącego na ołtarzu, i rzekł: Uderz w zawiasę, i niech się wzruszą napróżniki: bo łakomstwo na głowie wszystkich, a ostatek ich mieczem pobiję; nie będą mogli uciec. Ucieka, a nie będzie zachowań z nich, który uciecze.
###### **Am 9,2**
 Choćby zstąpili aż do piekła, ztamtąd wywiedzie je ręka moja: i choćby wstąpili aż do nieba, ztamtąd je ściągnę.
###### **Am 9,3**
 I choćby się skryli na wierzch Karmela, ztamtąd szperając wezmę je: i choćby się skryli od oczu moich do głębokości morskiej, tam rozkażę wężowi, a będzie je kąsał.
###### **Am 9,4**
 A jeśli pójdą w niewolą przed nieprzyjacioły swemi, tam rozkażę mieczowi, i pobije je: i położę oczy moje na nie, na złe, a nie na dobre.
###### **Am 9,5**
 A Pan Bóg zastępów, który się dotyka ziemie, a zniszczeje, i płakać będą wszyscy mieszkający na niej: i wzbierze jako potok wszelki, a ściecze jako rzeka Egiptska.
###### **Am 9,6**
 Który buduje na niebie wysokie mieszkanie swoje, a snopek swój na ziemi zasadził: który przyzywa wód morskich, i wylewa je na oblicze ziemie: Pan imię jego.
###### **Am 9,7**
 Izali nie jako synowie Murzyńscy, wy jesteście mi synowie Izraelscy, mówi Pan? izali nie Izraela wywiodłem z ziemie Egiptskiej, a Palestyny z Kappadocyi, a Syryany z Cyreny?
###### **Am 9,8**
 Oto oczy Pana Boga na królestwo grzeszące, a zetrę je z oblicza ziemie: wszakoż wygładzając nie wygładzę domu Jakóbowego, mówi Pan.
###### **Am 9,9**
 Bo oto ja rozkażę, i wskrzeszę między wszemi narody dom Izraelów, jako wskrzeszają pszenicę w rzeszecie: a nie wypadnie kamyk na ziemię.
###### **Am 9,10**
 Od miecza pomrą wszyscy grzesznicy ludu mego: którzy mówią: Nie przybliży się, ani przydzie na nas złe.
###### **Am 9,11**
 Onego dnia podniosę przybytek Dawidów, który upadł, i zbuduję znowu rozpadliny murów jego, a co się było obaliło naprawię, i znowu zbuduję ji jako za dni dawnych.
###### **Am 9,12**
 Żeby posiedli ostatek Idumei, i wszystkie narody: przeto iż wzywano imienia mego nad nimi, mówi Pan czyniący to.
###### **Am 9,13**
 Oto dni idą, mówi Pan: i zajmie oracz żeńca, a który depce winne jagody, siejącego nasienie: i kropić będą góry słodkością, a wszystkie pagórki wyprawione będą.
###### **Am 9,14**
 I wrócę pojmanie ludu mego Izraelskiego: a będą budować miasta spustoszone, i będą mieszkać: w nich i będą też sadzić winnice i pić wino ich, i naczynia sadów, a będą jeść owoce ich.
###### **Am 9,15**
 I nasadzę je w ziemię ich, a nie wyrwę ich więcej z ziemie ich, którąm im dał, mówi Pan Bóg twój.1
