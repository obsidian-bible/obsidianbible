# Ap 7 BT5
###### **Ap 7,1**
 Potem ujrzałem czterech aniołów stojących na czterech narożnikach ziemi, jak powstrzymywali cztery wiatry ziemi, aby wiatr nie wiał na ziemi ani na morzu, ani na żadne drzewo.
###### **Ap 7,2**
 I ujrzałem innego anioła, wstępującego od wschodu słońca, mającego pieczęć Boga żywego. Zawołał on donośnym głosem do czterech aniołów, którym dano moc wyrządzić szkodę ziemi i morzu:
###### **Ap 7,3**
 «***Nie wyrządzajcie szkody ziemi ni morzu, ni drzewom, aż opieczętujemy czoła sług Boga naszego***».
###### **Ap 7,4**
I usłyszałem liczbę opieczętowanych: sto czterdzieści cztery tysiące opieczętowanych ze wszystkich pokoleń synów Izraela
###### **Ap 7,5**
 z pokolenia Judy dwanaście tysięcy opieczętowanych, z pokolenia Rubena dwanaście tysięcy, z pokolenia Gada dwanaście tysięcy,
###### **Ap 7,6**
 z pokolenia Asera dwanaście tysięcy, z pokolenia Neftalego dwanaście tysięcy, z pokolenia Manassesa dwanaście tysięcy,
###### **Ap 7,7**
 z pokolenia Symeona dwanaście tysięcy, z pokolenia Lewiego dwanaście tysięcy, z pokolenia Issachara dwanaście tysięcy,
###### **Ap 7,8**
 z pokolenia Zabulona dwanaście tysięcy, z pokolenia Józefa dwanaście tysięcy, z pokolenia Beniamina dwanaście tysięcy opieczętowanych.
###### **Ap 7,9**
 Potem ujrzałem: a oto wielki tłum, którego nie mógł nikt policzyć, z każdego narodu i wszystkich pokoleń, ludów i języków, stojący przed tronem i przed Barankiem. Odziani są w białe szaty, a w ręku ich palmy.
###### **Ap 7,10**
 I głosem donośnym tak wołają:«***Zbawienie w Bogu naszym, Zasiadającym na tronie, i w Baranku***».
###### **Ap 7,11**
 A wszyscy aniołowie stanęli wokół tronu i Starców, i czterech Istot żyjących, i na oblicza swe padli przed tronem, i pokłon oddali Bogu,
###### **Ap 7,12**
 mówiąc:«***Amen. Błogosławieństwo i chwała, i mądrość, i dziękczynienie, i cześć, i moc, i potęga Bogu naszemu na wieki wieków! Amen***».
###### **Ap 7,13**
 A jeden ze Starców odezwał się do mnie tymi słowami:«***Ci przyodziani w białe szatykim są i skąd przybyli?***»
###### **Ap 7,14**
 I powiedziałem do niego:«***Panie, ty wiesz***».I rzekł do mnie:«***To ci, którzy przychodzą z wielkiego ucisku i opłukali swe szaty, i w krwi Baranka je wybielili.***
###### **Ap 7,15**
 ***Dlatego są przed tronem Bogai w Jego świątyni cześć Mu oddają we dnie i w nocy. A Zasiadający na tronie rozciągnie namiot nad nimi.***
###### **Ap 7,16**
  ***Nie będą już łaknąć ani nie będą już pragnąć, i nie porazi ich słońce ani żaden upał,***
###### **Ap 7,17**
 ***bo pasał ich będzie Baranek, który jest pośrodku tronu, i poprowadzi ich do źródeł wód życia: i każdą łzę otrze Bóg z ich oczu***».
# Ap 7 PAU
###### **Ap 7,1**
 Następnie ujrzałem czterech aniołów stojących na czterech narożnikach ziemi. Trzymali oni cztery wiatry ziemi, aby wiatr nie wiał ani na ziemię, ani na morze, ani na żadne drzewo.
###### **Ap 7,2**
 Ujrzałem też innego anioła, który nadchodził od strony wschodu słońca i miał pieczęć żyjącego Boga. Krzyknął on potężnym głosem do czterech aniołów, którym pozwolono zniszczyć ziemię i morze:
###### **Ap 7,3**
 „Nie niszczcie ziemi ani morza, ani drzew, dopóki nie opieczętujemy na czołach sług naszego Boga”.
###### **Ap 7,4**
 I usłyszałem liczbę opieczętowanych: sto czterdzieści cztery tysiące z każdego plemienia synów Izraela.
###### **Ap 7,5**
 Z plemienia Judy - dwanaście tysięcy opieczętowanych. Z plemienia Rubena - dwanaście tysięcy. Z plemienia Gada - dwanaście tysięcy.
###### **Ap 7,6**
 Z plemienia Asera - dwanaście tysięcy. Z plemienia Neftalego - dwanaście tysięcy. Z plemienia Manassesa - dwanaście tysięcy.
###### **Ap 7,7**
 Z plemienia Symeona - dwanaście tysięcy. Z plemienia Lewiego - dwanaście tysięcy. Z plemienia Issachara - dwanaście tysięcy.
###### **Ap 7,8**
 Z plemienia Zabulona - dwanaście tysięcy. Z plemienia Józefa - dwanaście tysięcy. Z plemienia Beniamina - dwanaście tysięcy opieczętowanych.
###### **Ap 7,9**
 Następnie zobaczyłem ogromny tłum, którego nikt nie mógł policzyć, ze wszystkich narodów, plemion, ludów i języków. Stali przed tronem i przed Barankiem ubrani w białe szaty, a w rękach trzymali palmy.
###### **Ap 7,10**
 I wołali potężnym głosem: „Zbawienie u naszego Boga, siedzącego na tronie, i u Baranka”.
###### **Ap 7,11**
 Wszyscy aniołowie, którzy stali wokół tronu, Starszych i czterech Istot żywych, upadli przed tronem i oddali Bogu pokłon,
###### **Ap 7,12**
 mówiąc: „Amen. Uwielbienie, chwała, mądrość, dziękczynienie, cześć, moc i potęga naszemu Bogu na wieki wieków. Amen”.
###### **Ap 7,13**
 Wtedy odezwał się jeden ze Starszych i zapytał mnie: „Kim są ci ubrani w białe szaty i skąd przyszli?”.
###### **Ap 7,14**
 Odpowiedziałem mu: „Panie mój, ty wiesz!”. Odrzekł mi: „To ci, którzy przychodzą z wielkiego ucisku. Wyprali swoje szaty i wybielili je we krwi Baranka.
###### **Ap 7,15**
 Dlatego są przed tronem Boga i służą Mu dniem i nocą w Jego świątyni. Wśród nich zamieszka Siedzący na tronie.
###### **Ap 7,16**
 Już nie zaznają głodu ani pragnienia, już nie porazi ich słońce ani żaden upał,
###### **Ap 7,17**
 bo będzie ich pasł Baranek stojący na środku tronu. On poprowadzi ich do źródeł wody życia, a Bóg otrze z ich oczu każdą łzę”.
# Ap 7 BP
###### **Ap 7,1**
 Potem ujrzałem czterech aniołów stojących na czterech narożnikach ziemi, powstrzymujących cztery wiatry ziemi, aby wiatr nie wiał na ziemi ani na morzu, ani na żadne drzewo.
###### **Ap 7,2**
 I ujrzałem innego anioła wstępującego od wschodu słońca, mającego pieczęć Boga żywego. Zawołał on donośnym głosem do czterech aniołów, którym dano moc szkodzić ziemi i morzu:
###### **Ap 7,3**
 "Nie wyrządzajcie szkody ziemi ani morzu, ani drzewom, aż popieczętujemy na czołach sługi Boga żywego".
###### **Ap 7,4**
 I usłyszałem liczbę pieczętowanych: sto czterdzieści cztery tysiące opieczętowanych ze wszystkich pokoleń synów Izraela:
###### **Ap 7,5**
 z pokolenia Judy dwanaście tysięcy opieczętowanych, z pokolenia Rubena dwanaście tysięcy, z pokolenia Gada dwanaście tysięcy,
###### **Ap 7,6**
 z pokolenia Asera dwanaście tysięcy, z pokolenia Neftalego dwanaście tysięcy, z pokolenia Manassesa dwanaście tysięcy,
###### **Ap 7,7**
 pokolenia Symeona dwanaście tysięcy, z pokolenia Lewiego dwanaście tysięcy, z pokolenia Issachara dwanaście tysięcy,
###### **Ap 7,8**
 z pokolenia Zabulona dwanaście tysięcy, z pokolenia Józefa dwanaście tysięcy, z pokolenia Beniamina dwanaście tysięcy opieczętowanych.
###### **Ap 7,9**
 Potem ujrzałem: A oto wielki tłum, którego nikt nie mógł zliczyć, [ludzie] ze wszystkich narodów, pokoleń i ludów różnojęzycznych, stojący przed tronem i przed Barankiem, odziani w białe szaty, a palmy w ich ręku.
###### **Ap 7,10**
 I głosem donośnym tak wołają: "Zbawienie [u] Boga naszego zasiadającego na tronie i [u] Baranka".
###### **Ap 7,11**
 A wszyscy aniołowie stanęli wokół tronu i Starców, i czworga Zwierząt, i padli na twarz przed tronem, i oddali Bogu pokłon,
###### **Ap 7,12**
 mówiąc: "Amen. Uwielbienie i chwała, i mądrość, i dziękczynienie, i cześć, i moc, i potęga Bogu naszemu na wieki wieków. Amen!"
###### **Ap 7,13**
 A jeden ze Starców odezwał się, mówiąc do mnie tymi słowami: "A ci przyodziani w białe szaty kim są i skąd przybyli?"
###### **Ap 7,14**
 I powiedziałem do niego: "Panie, ty wiesz". I rzekł do mnie: "To ci, którzy przychodzą z wielkiego ucisku i opłukali swoje szaty, i wybielili je w krwi Baranka.
###### **Ap 7,15**
 Dlatego są przed tronem Boga i w Jego świątyni cześć Mu oddają we dnie i w nocy. A Zasiadający na tronie rozciągnie namiot nad nimi.
###### **Ap 7,16**
 Nie będą już łaknąć ani nie będą już pragnąć, i nie porazi ich słońce ani żaden upał,
###### **Ap 7,17**
 bo paść ich będzie Baranek, który jest w pośrodku tronu, i poprowadzi ich do źródeł wód życia, a Bóg każdą łzę otrze z ich oczu".
# Ap 7 BR
###### **Ap 7,1**
 A potem ujrzałem czterech aniołów, którzy stali na czterech krańcach ziemi i powstrzymywali cztery wichry ziemi tak aby nie wiały ani po ziemi, ani po morzu, ani na żadne drzewo.
###### **Ap 7,2**
 Zobaczyłem też innego anioła. Zbliżał się od wschodu słońca i miał pieczęć Boga żywego. On to zwrócił się z takim oto rozkazem do czterech aniołów którzy mieli dokonać spustoszenia na ziemi i na morzu:
###### **Ap 7,3**
 Nie wyrządzajcie szkody ani ziemi, ani morzu, ani drzewom, aż wyciśniemy pieczęci na czołach sług Boga naszego.
###### **Ap 7,4**
 I usłyszałem liczbę opieczętowanych: ze wszystkich pokoleń synów Izraela sto czterdzieści cztery tysiące opieczętowanych.
###### **Ap 7,5**
 Dwanaście tysięcy opieczętowanych z pokolenia Judy, dwanaście tysięcy z pokolenia Rubena, dwanaście tysięcy z pokolenia Gada,
###### **Ap 7,6**
 dwanaście tysięcy z pokolenia Asera, dwanaście tysięcy z pokolenia Neftalego, dwanaście tysięcy z pokolenia Manassesa,
###### **Ap 7,7**
 dwanaście tysięcy z pokolenia Symeona, dwanaście tysięcy z pokolenia Lewiego, dwanaście tysięcy z pokolenia Issachara,
###### **Ap 7,8**
 dwanaście tysięcy z pokolenia Zabulona, dwanaście tysięcy z pokolenia Józefa, dwanaście tysięcy z pokolenia Beniamina.
###### **Ap 7,9**
 A potem ujrzałem tłum tak wielki, że nikt nie mógłby go policzyć; byli tam [przedstawiciele] wszystkich narodów, pokoleń, ludów i języków. Stali przed tronem i przed Barankiem. Byli ubrani w białe szaty, a w rękach mieli palmy.
###### **Ap 7,10**
 I wołali donośnym głosem: Zbawienie [mamy] od Boga naszego siedzącego na tronie i od Baranka.
###### **Ap 7,11**
 Wszyscy zaś aniołowie stali dokoła tronu, wokół Starców i czworga Zwierząt. Padali przed tronem [na twarz] i oddawali Bogu pokłon
###### **Ap 7,12**
 wołając: Amen! Błogosławieństwo i chwała, i mądrość, i dziękczynienie, i cześć, i moc, i potęga Bogu naszemu na wieki wieków. Amen!
###### **Ap 7,13**
 A jeden ze Starców przemówił do mnie w te słowa: Kim są i skąd przybyli ci, którzy są przyodziani w białe szaty?
###### **Ap 7,14**
 Wówczas ja odpowiedziałem mu: Panie, ty wiesz przecież. A on rzekł do mnie: Są to ci, którzy przychodzą z wielkiego ucisku; opłukali swoje szaty i wybielili je w krwi Baranka.
###### **Ap 7,15**
 Dlatego stoją przed tronem Boga, służąc Mu w Jego świątyni we dnie i w nocy. A Ten, który zasiada na tronie, rozciągnie nad nimi swój namiot.
###### **Ap 7,16**
 Odtąd nie będą już łaknąć ani pragnąć i nie porazi ich już żar słoneczny ani upał.
###### **Ap 7,17**
 Będzie ich bowiem strzegł Baranek, który jest pośrodku tronu. On to poprowadzi ich do źródeł wody żywej, a Bóg otrze wszystkie łzy z ich oczu.Otwarcie siódmej pieczęci.
# Ap 7 WUJ
###### **Ap 7,1**
 Potemem widział czterech aniołów stojących na czterech węgłach ziemie, trzymających cztery wiatry ziemie, aby nie wiały na ziemię, ani na morze, ani na żadne drzewo.
###### **Ap 7,2**
 I widziałem drugiego anioła wstępującego od wschodu słońca, mającego pieczęć Boga żywego: i zawołał głosem wielkim do czterech aniołów, którym dano jest szkodzić ziemi i morzu.
###### **Ap 7,3**
 Mówiąc: Nie szkodźcie ziemi i morzu, ani drzewam, aż popieczętujemy sługi Boga naszego na czołach ich.
###### **Ap 7,4**
 I słyszałem liczbę pieczętowanych, sto i czterdzieści i cztery tysiące pieczętowanych ze wszech pokolenia synów Izraelskich.
###### **Ap 7,5**
 Z pokolenia Judowego, dwanaście tysięcy pieczętowani. Z pokolenia Rubenowego, dwanaście tysięcy pieczętowani. Z pokolenia Gad, dwanaście tysięcy pieczętowani.
###### **Ap 7,6**
 Z pokolenia Asser, dwanaście tysięcy pieczętowani. Z pokolenia Nephtalim, dwanaście tysięcy pieczętowani. Z pokolenia Manasse, dwanaście tysięcy pieczętowani.
###### **Ap 7,7**
 Z pokolenia Symeon, dwanaście tysięcy pieczętowani. Z pokolenia Lewi, dwanaście tysięcy pieczętowani. Z pokolenia Izachar, dwanaście tysięcy pieczętowani.
###### **Ap 7,8**
 Z pokolenia Zabulon, dwanaście tysięcy pieczętowani. Z pokolenia Józef, dwanaście tysięcy pieczętowani.Z pokolenia Benjamin, dwanaście tysięcy pieczętowani. Z pokolenia Manasse, dwanaście tysięcy pieczętowani.
###### **Ap 7,9**
 Potemem widział rzeszą wielką, której nie mógł nikt przeliczyć, ze wszech narodów i pokolenia, i łudzi, i języków: stojące przed stolicą, i przed oblicznością baranka, przyobleczeni w szaty białe, a palmy w ręku ich,
###### **Ap 7,10**
 I wołali głosem wielkim mówiąc: Zbawienie Bogu naszemu, który siedzi na stolicy, i barankowi.
###### **Ap 7,11**
 A wszyscy aniołowie stali około stolice i starszych i czworga zwierząt: i padli przed stolicą na oblicza swe, i pokłon uczynili Bogu, mówiąc, Amen.
###### **Ap 7,12**
 Błogosławienie, i chwała, i mądrość, i dziękowanie, cześć i moc, i siła Bogu naszemu na wieki wieków. Amen.
###### **Ap 7,13**
 I odpowiedział jeden z starszych, i rzekł mi: Ci, którzy są obleczeni w szaty białe, którzyż są? zkąd przyszli?
###### **Ap 7,14**
 I rzekłem mu: Panie mój, ty wiesz. I rzekł mi: Ci są, którzy przyszli z ucisku wielkiego, i omyli szaty swoje, i wybielili je we krwi barankowej.
###### **Ap 7,15**
 Dla tego są przed stolicą Bożą, i służą mu we dnie i w nocy w kościele jego: a który siedzi na stolicy, mieszkać będzie nad nimi.
###### **Ap 7,16**
 Nie będą łaknąć ani pragnąć więcej, ani na nie słońce przypadnie, ani żadne gorąco.
###### **Ap 7,17**
 Abowiem baranek, który jest w pośrodku stolice, będzie je rządził, i poprowadzi je do źródeł wód żywota: i otrze Bóg wszelką łzę z oczu ich.
# Ap 7 STERN
###### **Ap 7,1**
 Następnie ujrzałem czterech aniołów stojących na czterech krańcach ziemi, powstrzymujących cztery wichry ziemi, tak aby żaden wiatr nie wiał na ląd, na morze ani na żadne drzewo.
###### **Ap 7,2**
 Zobaczyłem innego anioła, wstępującego od wschodu, z pieczęcią od Boga żywego, i zawołał on do czterech aniołów, którym dano moc wyrządzenia szkody ziemi i morzu:
###### **Ap 7,3**
 "Nie wyrządzajcie szkody ziemi ani morzu, ani drzewom, aż opieczętujemy sługi naszego Boga na ich czołach!".
###### **Ap 7,4**
 Usłyszałem, ilu opieczętowano - sto czterdzieści cztery tysiące, z każdego plemienia ludu Isra'ela:
###### **Ap 7,5**
 z plemienia J'hudy dwanaście tysięcy opieczętowanych, z plemienia Re'uwena - dwanaście tysięcy, z plemienia Gada - dwanaście tysięcy,
###### **Ap 7,6**
 z plemienia Aszera - dwanaście tysięcy, z plemienia Naftalego - dwanaście tysięcy, z plemienia M'naszego - dwanaście tysięcy,
###### **Ap 7,7**
 z plemienia Szim'ona - dwanaście tysięcy, z plemienia L'wiego - dwanaście tysięcy, z plemienia Jissachara - dwanaście tysięcy,
###### **Ap 7,8**
 z plemienia Z'wuluna - dwanaście tysięcy, z plemienia Josefa - dwanaście tysięcy, z plemienia Binjamina - dwanaście tysięcy.
###### **Ap 7,9**
 Następnie spojrzałem, i był przede mną ogromny tłum, zbyt wielki, aby można go policzyć, z każdego narodu, plemienia, ludu i języka. Stali przed tronem i przed Barankiem, odziani w białe szaty, z gałązkami palm w rękach,
###### **Ap 7,10**
 i wołali: "Zwycięstwo naszemu Bogu, który zasiada na tronie, i Barankowi!".
###### **Ap 7,11**
 Wszyscy aniołowie stali wokół tronu, i starsi, i cztery żywe istoty. Upadli oni na twarze przed tronem i wielbili Boga, mówiąc:
###### **Ap 7,12**
 "Amen! Chwała i sława, mądrość i dziękczynienie, cześć i potęga, i moc należą do naszego Boga na wieki wieków! Amen!".
###### **Ap 7,13**
 Jeden ze starszych zapytał mnie: "Ci ludzie odziani w białe szaty - kim są i skąd przyszli?".
###### **Ap 7,14**
 "Panie - odrzekłem - ty wiesz". I powiedział mi: "To są ludzie, którzy wyszli z Wielkiego Prześladowania. Wyprali swe szaty i wybielili je krwią Baranka.
###### **Ap 7,15**
 Dlatego właśnie są przed tronem Bożym. Dzień i noc służą Mu w Jego Świątyni, a Ten, który zasiada na tronie, roztoczy nad nimi swą Sz'chinę.
###### **Ap 7,16**
 Nigdy więcej nie będą głodni, nigdy więcej nie będą spragnieni, słońce ich nie porazi ani żaden palący żar.
###### **Ap 7,17**
 Bo Baranek pośrodku tronu będzie ich pasł, będzie ich prowadził do źródeł żywej wody, a Bóg otrze wszelką łzę z ich oczu".
# Ap 7 TRO
###### **Ap 7,1**
 **και** *kai* A [[G2532]] [[CONJ]] **μετα** *meta* po [[G3326]] [[PREP]] **ταυτα** *tauta* tych [[G5023]] WTD-APN **ειδον** *eidon* zobaczyłem [[G1492]] WTV-2AAI-1S **τεσσαρας** *tessaras* czterech [[G5064]] WTA-APM **αγγελους** *angelous* zwiastunów [[G32]] [[N-APM]] **εστωτας** *hestōtas* stojących [[G2476]] WTV-RAP-APM **επι** *epi* na [[G1909]] [[PREP]] **τας** *tas* [[G3588]] WTT-APF **τεσσαρας** *tessaras* czterech [[G5064]] WTA-APF **γωνιας** *gōnias* narożnikach – rogach [[G1137]] WTN-APF **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]] **κρατουντας** *kratountas* trzymających [[G2902]] WTV-PAP-APM **τους** *tous* [[G3588]] WTT-APM **τεσσαρας** *tessaras* cztery [[G5064]] WTA-APM **ανεμους** *anemous* wiatry [[G417]] [[N-APM]] **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]] **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **πνεη** *pneē* wiałby – dąłby [[G4154]] WTV-PAS-3S **ανεμος** *anemos* wiatr [[G417]] [[N-NSM]] **επι** *epi* na [[G1909]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **γης** *gēs* ziemię [[G1093]] [[N-GSF]] **μητε** *mēte* ani [[G3383]] [[CONJ]] **επι** *epi* na [[G1909]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **θαλασσης** *thalassēs* morze [[G2281]] [[N-GSF]] **μητε** *mēte* ani [[G3383]] [[CONJ]] **επι** *epi* na [[G1909]] [[PREP]] **παν** *pan* wszelkie [[G3956]] WTA-ASN **δενδρον** *dendron* drzewo [[G1186]] WTN-ASN
###### **Ap 7,2**
 **και** *kai* I [[G2532]] [[CONJ]] **ειδον** *eidon* zobaczyłem [[G1492]] WTV-2AAI-1S **αλλον** *allon* innego [[G243]] WTA-ASM **αγγελον** *angelon* zwiastuna [[G32]] [[N-ASM]] **αναβαινοντα** *anabainonta* wchodzącego – wstępującego [[G305]] WTV-PAP-ASM **απο** *apo* od [[G575]] [[PREP]] **ανατολης** *anatolēs* wschodu [[G395]] [[N-GSF]] **ηλιου** *hēliou* słońca [[G2246]] [[N-GSM]] **εχοντα** *echonta* mającego [[G2192]] WTV-PAP-ASM **σφραγιδα** *sfragida* pieczęć [[G4973]] WTN-ASF **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ζωντος** *zōntos* żyjącego [[G2198]] WTV-PAP-GSM **και** *kai* i [[G2532]] [[CONJ]] **εκραξεν** *ekraksen* krzyknął [[G2896]] [[V-AAI-3S]] **φωνη** *fōnē* głosem [[G5456]] [[N-DSF]] **μεγαλη** *megalē* wielkim [[G3173]] WTA-DSF **τοις** *tois* [[G3588]] WTT-DPM **τεσσαρσιν** *tessarsin* czterem [[G5064]] WTA-DPM **αγγελοις** *angelois* zwiastunom [[G32]] WTN-DPM **οις** *hois* którym [[G3739]] WTR-DPM **εδοθη** *edothē* zostało dane [[G1325]] [[V-API-3S]] **αυτοις** *autois* im [[G846]] WTP-DPM **αδικησαι** *adikēsai* uczynić niesprawiedliwość – skrzywdzić [[G91]] [[V-AAN]] **την** *tēn* [[G3588]] WTT-ASF **γην** *gēn* ziemi [[G1093]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **θαλασσαν** *thalassan* morzu [[G2281]] WTN-ASF
###### **Ap 7,3**
 **λεγων** *legōn* mówiąc [[G3004]] [[V-PAP-NSM]] **μη** *mē* nie [[G3361]] [[PRT-N]] **αδικησητε** *adikēsēte* czynilibyście niesprawiedliwości – krzywdzilibyście [[G91]] WTV-AAS-2P **την** *tēn* [[G3588]] WTT-ASF **γην** *gēn* ziemi [[G1093]] WTN-ASF **μητε** *mēte* ani [[G3383]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **θαλασσαν** *thalassan* morzu [[G2281]] WTN-ASF **μητε** *mēte* ani [[G3383]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **δενδρα** *dendra* drzewom [[G1186]] WTN-APN **αχρις** *achris* aż do [[G891]] [[PREP]] **ου** *hou* kiedy [[G3739]] WTR-GSM **σφραγισωμεν** *sfragisōmen* opieczętowalibyśmy [[G4972]] WTV-AAS-1P **τους** *tous* [[G3588]] WTT-APM **δουλους** *doulous* niewolników – sługi [[G1401]] [[N-APM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **επι** *epi* na [[G1909]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **μετωπων** *metōpōn* czołach [[G3359]] WTN-GPN **αυτων** *autōn* ich [[G846]] WTP-GPM
###### **Ap 7,4**
 **και** *kai* I [[G2532]] [[CONJ]] **ηκουσα** *ēkousa* usłyszałem [[G191]] WTV-AAI-1S **τον** *ton* [[G3588]] [[T-ASM]] **αριθμον** *arithmon* liczbę [[G706]] [[N-ASM]] **των** *tōn* [[G3588]] WTT-GPM **εσφραγισμενων** *esfragismenōn* którzy są opieczętowani [[G4972]] WTV-RPP-GPM **ρμδ** *rmd* sto czterdzieści cztery [[G1540]] WTA-NUI-ABB **χιλιαδες** *chiliades* tysiące [[G5505]] [[A-NPF]] **εσφραγισμενοι** *esfragismenoi* którzy są opieczętowani [[G4972]] WTV-RPP-NPM **εκ** *ek* z [[G1537]] [[PREP]] **πασης** *pasēs* każdego [[G3956]] WTA-GSF **φυλης** *fylēs* plemienia [[G5443]] [[N-GSF]] **υιων** *hyiōn* synów [[G5207]] WTN-GPM **ισραηλ** *israēl* Izraela – [ten, który walczył z Bogiem] [[G2474]] [[N-PRI]]
###### **Ap 7,5**
 **εκ** *ek* Z [[G1537]] [[PREP]] **φυλης** *fylēs* plemienia [[G5443]] [[N-GSF]] **ιουδα** *iouda* Judy – [wielbić] [[G2448]] [[N-GSM]] **ιβ** *ib* dwanaście [[G1427]] WTA-NUI-ABB **χιλιαδες** *chiliades* tysięcy [[G5505]] [[A-NPF]] **εσφραγισμενοι** *esfragismenoi* którzy są opieczętowani [[G4972]] WTV-RPP-NPM **εκ** *ek* z [[G1537]] [[PREP]] **φυλης** *fylēs* plemienia [[G5443]] [[N-GSF]] **ρουβην** *roubēn* Rubena – [oto syn] [[G4502]] [[N-PRI]] **ιβ** *ib* dwanaście [[G1427]] WTA-NUI-ABB **χιλιαδες** *chiliades* tysięcy [[G5505]] [[A-NPF]] **εσφραγισμενοι** *esfragismenoi* którzy są opieczętowani [[G4972]] WTV-RPP-NPM **εκ** *ek* z [[G1537]] [[PREP]] **φυλης** *fylēs* plemienia [[G5443]] [[N-GSF]] **γαδ** *gad* Gada – [prawd. fortuna] [[G1045]] [[N-PRI]] **ιβ** *ib* dwanaście [[G1427]] WTA-NUI-ABB **χιλιαδες** *chiliades* tysięcy [[G5505]] [[A-NPF]] **εσφραγισμενοι** *esfragismenoi* którzy są opieczętowani [[G4972]] WTV-RPP-NPM
###### **Ap 7,6**
 **εκ** *ek* Z [[G1537]] [[PREP]] **φυλης** *fylēs* plemienia [[G5443]] [[N-GSF]] **ασηρ** *asēr* Asera – [szczęśliwy] [[G768]] [[N-PRI]] **ιβ** *ib* dwanaście [[G1427]] WTA-NUI-ABB **χιλιαδες** *chiliades* tysięcy [[G5505]] [[A-NPF]] **εσφραγισμενοι** *esfragismenoi* którzy są opieczętowani [[G4972]] WTV-RPP-NPM **εκ** *ek* z [[G1537]] [[PREP]] **φυλης** *fylēs* plemienia [[G5443]] [[N-GSF]] **νεφθαλειμ** *nefthaleim* Neftalego – [nadludzką walkę wiodłam] [[G3508]] [[N-PRI]] **ιβ** *ib* dwanaście [[G1427]] WTA-NUI-ABB **χιλιαδες** *chiliades* tysięcy [[G5505]] [[A-NPF]] **εσφραγισμενοι** *esfragismenoi* którzy są opieczętowani [[G4972]] WTV-RPP-NPM **εκ** *ek* z [[G1537]] [[PREP]] **φυλης** *fylēs* plemienia [[G5443]] [[N-GSF]] **μανασση** *manassē* Manassesa – [pozwolił zapomnieć] [[G3128]] [[N-GSM]] **ιβ** *ib* dwanaście [[G1427]] WTA-NUI-ABB **χιλιαδες** *chiliades* tysięcy [[G5505]] [[A-NPF]] **εσφραγισμενοι** *esfragismenoi* którzy są opieczętowani [[G4972]] WTV-RPP-NPM
###### **Ap 7,7**
 **εκ** *ek* Z [[G1537]] [[PREP]] **φυλης** *fylēs* plemienia [[G5443]] [[N-GSF]] **συμεων** *symeōn* Symeona – [słyszeć] [[G4826]] [[N-PRI]] **ιβ** *ib* dwanaście [[G1427]] WTA-NUI-ABB **χιλιαδες** *chiliades* tysięcy [[G5505]] [[A-NPF]] **εσφραγισμενοι** *esfragismenoi* którzy są opieczętowani [[G4972]] WTV-RPP-NPM **εκ** *ek* z [[G1537]] [[PREP]] **φυλης** *fylēs* plemienia [[G5443]] [[N-GSF]] **λευι** *leui* Lewiego – [przyłączyć] [[G3017]] [[N-PRI]] **ιβ** *ib* dwanaście [[G1427]] WTA-NUI-ABB **χιλιαδες** *chiliades* tysięcy [[G5505]] [[A-NPF]] **εσφραγισμενοι** *esfragismenoi* którzy są opieczętowani [[G4972]] WTV-RPP-NPM **εκ** *ek* z [[G1537]] [[PREP]] **φυλης** *fylēs* plemienia [[G5443]] [[N-GSF]] **ισαχαρ** *isachar* Issachara – [praw. jest nagroda] [[G2466]] [[N-PRI]] **ιβ** *ib* dwanaście [[G1427]] WTA-NUI-ABB **χιλιαδες** *chiliades* tysięcy [[G5505]] [[A-NPF]] **εσφραγισμενοι** *esfragismenoi* którzy są opieczętowani [[G4972]] WTV-RPP-NPM
###### **Ap 7,8**
 **εκ** *ek* Z [[G1537]] [[PREP]] **φυλης** *fylēs* plemienia [[G5443]] [[N-GSF]] **ζαβουλων** *zaboulōn* Zabulona – [mieszkać] [[G2194]] [[N-PRI]] **ιβ** *ib* dwanaście [[G1427]] WTA-NUI-ABB **χιλιαδες** *chiliades* tysięcy [[G5505]] [[A-NPF]] **εσφραγισμενοι** *esfragismenoi* którzy są opieczętowani [[G4972]] WTV-RPP-NPM **εκ** *ek* z [[G1537]] [[PREP]] **φυλης** *fylēs* plemienia [[G5443]] [[N-GSF]] **ιωσηφ** *iōsēf* Józefa – [On powiększył] [[G2501]] [[N-PRI]] **ιβ** *ib* dwanaście [[G1427]] WTA-NUI-ABB **χιλιαδες** *chiliades* tysięcy [[G5505]] [[A-NPF]] **εσφραγισμενοι** *esfragismenoi* którzy są opieczętowani [[G4972]] WTV-RPP-NPM **εκ** *ek* z [[G1537]] [[PREP]] **φυλης** *fylēs* plemienia [[G5443]] [[N-GSF]] **βενιαμιν** *beniamin* Beniamina – [syn prawicy] [[G958]] [[N-PRI]] **ιβ** *ib* dwanaście [[G1427]] WTA-NUI-ABB **χιλιαδες** *chiliades* tysięcy [[G5505]] [[A-NPF]] **εσφραγισμενοι** *esfragismenoi* którzy są opieczętowani [[G4972]] WTV-RPP-NPM
###### **Ap 7,9**
 **μετα** *meta* Po [[G3326]] [[PREP]] **ταυτα** *tauta* tych [[G5023]] WTD-APN **ειδον** *eidon* zobaczyłem [[G1492]] WTV-2AAI-1S **και** *kai* i [[G2532]] [[CONJ]] **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **οχλος** *ochlos* tłum [[G3793]] [[N-NSM]] **πολυς** *polys* wielki [[G4183]] [[A-NSM]] **ον** *hon* którego [[G3739]] WTR-ASM **αριθμησαι** *arithmēsai* policzyć [[G705]] [[V-AAN]] **αυτον** *auton* go [[G846]] WTP-ASM **ουδεις** *oudeis* nikt [[G3762]] [[A-NSM]] **ηδυνατο** *ēdynato* mógł [[G1410]] WTV-INI-3S-ATT **εκ** *ek* z [[G1537]] [[PREP]] **παντος** *pantos* każdego [[G3956]] [[A-GSN]] **εθνους** *ethnous* narodu [[G1484]] [[N-GSN]] **και** *kai* i [[G2532]] [[CONJ]] **φυλων** *fylōn* plemion [[G5443]] WTN-GPF **και** *kai* i [[G2532]] [[CONJ]] **λαων** *laōn* ludzi [[G2992]] WTN-GPM **και** *kai* i [[G2532]] [[CONJ]] **γλωσσων** *glōssōn* języków [[G1100]] WTN-GPF **εστωτες** *hestōtes* stojący [[G2476]] WTV-RAP-NPM **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronem [[G2362]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **του** *tou* [[G3588]] WTT-GSN **αρνιου** *arniou* barankiem [[G721]] [[N-GSN]] **περιβεβλημενοι** *peribeblēmenoi* którzy są okryci – którzy są odziani [[G4016]] WTV-RPP-NPM **στολας** *stolas* długimi szatami [[G4749]] WTN-APF **λευκας** *leukas* białymi [[G3022]] WTA-APF **και** *kai* i [[G2532]] [[CONJ]] **φοινικες** *foinikes* palmy [[G5404]] WTN-NPM **εν** *en* w [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **χερσιν** *chersin* rękach [[G5495]] WTN-DPF **αυτων** *autōn* ich [[G846]] WTP-GPM
###### **Ap 7,10**
 **και** *kai* I [[G2532]] [[CONJ]] **κραζοντες** *krazontes* krzyczący – wołający [[G2896]] WTV-PAP-NPM **φωνη** *fōnē* głosem [[G5456]] [[N-DSF]] **μεγαλη** *megalē* wielkim [[G3173]] WTA-DSF **λεγοντες** *legontes* mówiący [[G3004]] WTV-PAP-NPM **η** *hē* [[G3588]] [[T-NSF]] **σωτηρια** *sōtēria* zbawienie – wyzwolenie [[G4991]] [[N-NSF]] **τω** *tō* (w) [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **ημων** *hēmōn* naszym [[G2257]] WTP-1GP **τω** *tō* [[G3588]] WTT-DSM **καθημενω** *kathēmenō* siedzącym [[G2521]] WTV-PNP-DSM **επι** *epi* na [[G1909]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronie [[G2362]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **τω** *tō* [[G3588]] WTT-DSN **αρνιω** *arniō* barankowi [[G721]] WTN-DSN
###### **Ap 7,11**
 **και** *kai* I [[G2532]] [[CONJ]] **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **οι** *hoi* [[G3588]] WTT-NPM **αγγελοι** *angeloi* zwiastunowie [[G32]] WTN-NPM **εστηκεσαν** *estēkesan* stanęli [[G2476]] WTV-LAI-3P-ATT **κυκλω** *kyklō* wokół [[G2945]] WTN-DSM **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronu [[G2362]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPM **πρεσβυτερων** *presbyterōn* starszych – starców [[G4245]] WTA-GPM **και** *kai* i [[G2532]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPN **τεσσαρων** *tessarōn* czterech [[G5064]] WTA-GPN **ζωων** *zōōn* istot żywych [[G2226]] WTN-GPN **και** *kai* i [[G2532]] [[CONJ]] **επεσον** *epeson* padli [[G4098]] WTV-2AAI-3P **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronem [[G2362]] [[N-GSM]] **επι** *epi* na [[G1909]] [[PREP]] **προσωπον** *prosōpon* oblicze – twarz [[G4383]] WTN-ASN **αυτων** *autōn* ich [[G846]] WTP-GPM **και** *kai* i [[G2532]] [[CONJ]] **προσεκυνησαν** *prosekynēsan* oddali cześć – pokłonili się [[G4352]] WTV-AAI-3P **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM
###### **Ap 7,12**
 **λεγοντες** *legontes* mówiąc [[G3004]] WTV-PAP-NPM **αμην** *amēn* amen – [zaprawdę] [[G281]] WTHEB **η** *hē* [[G3588]] [[T-NSF]] **ευλογια** *eulogia* błogosławieństwo – wysławianie [[G2129]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **δοξα** *doksa* chwała [[G1391]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **σοφια** *sofia* mądrość [[G4678]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **ευχαριστια** *eucharistia* dziękczynienie – wdzięczność [[G2169]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **τιμη** *timē* szacunek – zaszczyt [[G5092]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **δυναμις** *dynamis* moc [[G1411]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **ισχυς** *ischys* siła [[G2479]] [[N-NSF]] **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **ημων** *hēmōn* naszemu [[G2257]] WTP-1GP **εις** *eis* na [[G1519]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **αιωνας** *aiōnas* wieki [[G165]] [[N-APM]] **των** *tōn* [[G3588]] WTT-GPM **αιωνων** *aiōnōn* wieków [[G165]] WTN-GPM **αμην** *amēn* amen – [zaprawdę] [[G281]] WTHEB
###### **Ap 7,13**
 **και** *kai* I [[G2532]] [[CONJ]] **απεκριθη** *apekrithē* odpowiedział [[G611]] WTV-ADI-3S **εις** *heis* jeden [[G1520]] [[A-NSM]] **εκ** *ek* ze [[G1537]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **πρεσβυτερων** *presbyterōn* starszych – starców [[G4245]] WTA-GPM **λεγων** *legōn* mówiąc [[G3004]] [[V-PAP-NSM]] **μοι** *moi* mi [[G3427]] WTP-1DS **ουτοι** *houtoi* ci [[G3778]] WTD-NPM **οι** *hoi* [[G3588]] WTT-NPM **περιβεβλημενοι** *peribeblēmenoi* którzy są okryci – którzy są odziani [[G4016]] WTV-RPP-NPM **τας** *tas* [[G3588]] WTT-APF **στολας** *stolas* długimi szatami [[G4749]] WTN-APF **τας** *tas* [[G3588]] WTT-APF **λευκας** *leukas* białymi [[G3022]] WTA-APF **τινες** *tines* kim [[G5101]] WTI-NPM **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **και** *kai* i [[G2532]] [[CONJ]] **ποθεν** *pothen* skąd [[G4159]] [[ADV]]-I **ηλθον** *ēlthon* przyszli [[G2064]] WTV-2AAI-3P
###### **Ap 7,14**
 **και** *kai* I [[G2532]] [[CONJ]] **ειρηκα** *eirēka* powiedziałem [[G2046]] WTV-RAI-1S-ATT **αυτω** *autō* mu [[G846]] WTP-DSM **κυριε** *kyrie* panie [[G2962]] WTN-VSM **συ** *sy* ty [[G4771]] WTP-2NS **οιδας** *oidas* wiesz [[G1492]] WTV-RAI-2S **και** *kai* i [[G2532]] [[CONJ]] **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **μοι** *moi* mi [[G3427]] WTP-1DS **ουτοι** *houtoi* ci [[G3778]] WTD-NPM **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **οι** *hoi* [[G3588]] WTT-NPM **ερχομενοι** *erchomenoi* przychodzący [[G2064]] WTV-PNP-NPM **εκ** *ek* z [[G1537]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **θλιψεως** *thlipseōs* ucisku – utrapienia [[G2347]] [[N-GSF]] **της** *tēs* [[G3588]] [[T-GSF]] **μεγαλης** *megalēs* wielkiego [[G3173]] WTA-GSF **και** *kai* i [[G2532]] [[CONJ]] **επλυναν** *eplynan* wyprali – opłukali [[G4150]] WTV-AAI-3P **τας** *tas* [[G3588]] WTT-APF **στολας** *stolas* długie szaty [[G4749]] WTN-APF **αυτων** *autōn* ich [[G846]] WTP-GPM **και** *kai* i [[G2532]] [[CONJ]] **ελευκαναν** *eleukanan* wybielili [[G3021]] WTV-AAI-3P **αυτας** *autas* je [[G846]] WTP-APF **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **αιματι** *haimati* krwi [[G129]] WTN-DSN **του** *tou* [[G3588]] WTT-GSN **αρνιου** *arniou* baranka [[G721]] [[N-GSN]]
###### **Ap 7,15**
 **δια** *dia* Dla- [[G1223]] [[PREP]] **τουτο** *touto* tego [[G5124]] WTD-ASN **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronem [[G2362]] [[N-GSM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **λατρευουσιν** *latreuousin* służą [[G3000]] WTV-PAI-3P **αυτω** *autō* Mu [[G846]] WTP-DSM **ημερας** *hēmeras* dniem [[G2250]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **νυκτος** *nyktos* nocą [[G3571]] [[N-GSF]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **ναω** *naō* świątyni – przybytku [[G3485]] WTN-DSM **αυτου** *autou* Jego [[G846]] [[P-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **καθημενος** *kathēmenos* siedzący [[G2521]] WTV-PNP-NSM **επι** *epi* na [[G1909]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronie [[G2362]] [[N-GSM]] **σκηνωσει** *skēnōsei* zamieszka – rozciągnie namiot [[G4637]] WTV-FAI-3S **επ** *ep* nad [[G1909]] [[PREP]] **αυτους** *autous* nimi [[G846]] [[P-APM]]
###### **Ap 7,16**
 **ου** *ou* Nie [[G3756]] [[PRT-N]] **πεινασουσιν** *peinasousin* będą głodować – będą łaknąć [[G3983]] WTV-FAI-3P **ετι** *eti* już [[G2089]] [[ADV]] **ουδε** *oude* ani [[G3761]] [[ADV]] **διψησουσιν** *dipsēsousin* będą pragnąć [[G1372]] WTV-FAI-3P **ετι** *eti* już [[G2089]] [[ADV]] **ουδε** *oude* ani [[G3761]] [[ADV]] **μη** *mē* nie [[G3361]] [[PRT-N]] **πεση** *pesē* padłoby [[G4098]] WTV-2AAS-3S **επ** *ep* na [[G1909]] [[PREP]] **αυτους** *autous* nich [[G846]] [[P-APM]] **ο** *ho* [[G3588]] [[T-NSM]] **ηλιος** *hēlios* słońce [[G2246]] [[N-NSM]] **ουδε** *oude* ani [[G3761]] [[ADV]] **παν** *pan* wszelki [[G3956]] WTA-NSN **καυμα** *kauma* upał [[G2738]] WTN-NSN
###### **Ap 7,17**
 **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **αρνιον** *arnion* baranek [[G721]] WTN-NSN **το** *to* [[G3588]] WTT-NSN **ανα** *ana* po- [[G303]] [[PREP]] **μεσον** *meson* środku [[G3319]] WTA-ASN **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronu [[G2362]] [[N-GSM]] **ποιμανει** *poimanei* będzie pasł [[G4165]] WTV-FAI-3S **αυτους** *autous* ich [[G846]] [[P-APM]] **και** *kai* i [[G2532]] [[CONJ]] **οδηγησει** *hodēgēsei* poprowadzi [[G3594]] WTV-FAI-3S **αυτους** *autous* ich [[G846]] [[P-APM]] **επι** *epi* nad [[G1909]] [[PREP]] **ζωσας** *zōsas* żyjącymi [[G2198]] WTV-PAP-APF **πηγας** *pēgas* źródłami [[G4077]] WTN-APF **υδατων** *hydatōn* wód [[G5204]] WTN-GPN **και** *kai* i [[G2532]] [[CONJ]] **εξαλειψει** *eksaleipsei* zetrze [[G1813]] WTV-FAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **παν** *pan* każdą [[G3956]] WTA-ASN **δακρυον** *dakryon* łzę [[G1144]] WTN-ASN **απο** *apo* z [[G575]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **οφθαλμων** *ofthalmōn* oczu [[G3788]] WTN-GPM **αυτων** *autōn* ich [[G846]] WTP-GPM
