# Ezd 7 BT5
###### **Ezd 7,1**
 Po tych wydarzeniach wystąpił za panowania Artakserksesa, króla perskiego, Ezdrasz, syn Serajasza, syna Azariasza, syna Chilkiasza,
###### **Ezd 7,2**
 syna Szalluma, syna Sadoka, syna Achituba,
###### **Ezd 7,3**
 syna Amariasza, syna Azariasza, syna Jochanana, syna Azariasza, syna Achimaasa, syna Sadoka, syna Achituba, syna Amariasza, syna Merajota,
###### **Ezd 7,4**
 syna Zerachiasza, syna Uzzjego, syna Bukkiego,
###### **Ezd 7,5**
 syna Abiszuy, syna Pinchasa, syna Eleazara, syna Aarona, arcykapłana.
###### **Ezd 7,6**
 Ten to Ezdrasz wyszedł z Babilonu; a był on uczonym, biegłym w Prawie Mojżeszowym, które nadał Pan, Bóg Izraela. A ponieważ ręka Pana, Boga jego, była nad nim, spełnił król wszelkie jego życzenia.
###### **Ezd 7,7**
 Wyszła również w siódmym roku [panowania] króla Artakserksesa gromada Izraelitów, kapłanów, lewitów, śpiewaków, odźwiernych i niewolników świątynnych do Jerozolimy.
###### **Ezd 7,8**
 I przybył Ezdrasz do Jerozolimy w miesiącu piątym – był to siódmy rok [panowania] tego króla:
###### **Ezd 7,9**
 albowiem pierwszego dnia miesiąca pierwszego nastąpił początek podroży z Babilonu, a pierwszego dnia miesiąca piątego przybył Ezdrasz do Jerozolimy, ponieważ łaskawa ręka Boga jego była nad nim.
###### **Ezd 7,10**
 Ezdrasz bowiem postanowił w sercu badać i wykonywać Prawo Pańskie oraz uczyć w Izraelu ustaw i ładu.
###### **Ezd 7,11**
 A oto odpis dokumentu, który król Artakserkses wręczył Ezdraszowi, kapłanowi i uczonemu, znawcy słów przykazań Pana i Jego ustaw dla Izraela.
###### **Ezd 7,12**
 «***Artakserkses, król królów, Ezdraszowi, kapłanowi, znawcy Prawa Boga niebios. Załatwiono. A teraz:***
###### **Ezd 7,13**
 ***Przeze mnie został wydany rozkaz: Każdy z narodu izraelskiego, z kapłanów jego i lewitów w moim państwie, kto ma zamiar iść z tobą do Jerozolimy, niech idzie.***
###### **Ezd 7,14**
 ***Albowiem przez króla i jego siedmiu radców jesteś wysłany, by na podstawie Prawa Boga twego, które posiadasz, zbadać stosunki w Judzie i w Jerozolimie***
###### **Ezd 7,15**
 ***oraz by zanieść srebro i złoto, jakie król i radcy jego dobrowolnie złożyli Bogu Izraela, którego przybytek jest w Jerozolimie,***
###### **Ezd 7,16**
 ***wraz z całym srebrem i złotem, jakie w całej prowincji Babel otrzymasz, razem z darowizną ludu i kapłanów, którą oni dobrowolnie ofiarują dla domu Boga swego w Jerozolimie.***
###### **Ezd 7,17**
 ***Przeto za te pieniądze uczciwie zakupisz cielców, baranów, jagniąt oraz należne ofiary pokarmowe i płynne, aby je złożyć na ołtarzu domu Boga waszego w Jerozolimie.***
###### **Ezd 7,18**
 ***A co ty i bracia twoi zechcecie uczynić z resztą srebra i złota, to czyńcie zgodnie z wolą Boga waszego.***
###### **Ezd 7,19**
 ***I sprzęty, które przekazuje się tobie do [sprawowania] kultu w domu Boga twojego, oddaj przed Bogiem w Jerozolimie.***
###### **Ezd 7,20**
 ***A resztę kosztów na dom Boga twego, jakie wypadnie ci pokryć, pokryjesz ze skarbu królewskiego.***
###### **Ezd 7,21**
 ***I przeze mnie, króla Artakserksesa, został wydany rozkaz do wszystkich skarbników w Transeufratei: Wszystko, czego od was żądać będzie kapłan Ezdrasz, znawca Prawa Boga niebios, ma być dokładnie wykonane –***
###### **Ezd 7,22**
 ***aż do stu talentów srebra, stu kor pszenicy, stu bat wina, stu bat oliwy, a soli bez ograniczenia.***
###### **Ezd 7,23**
 ***Wszystko, co jest z rozkazu Boga niebios, ma być gorliwie dla domu Boga niebios wykonane, aby nie rozgorzał gniew na państwo króla i jego synów.***
###### **Ezd 7,24**
 ***Również ogłasza się wam: Co się odnosi do wszystkich kapłanów, lewitów, śpiewaków, odźwiernych, niewolników świątynnych i sług tego domu Bożego, to nie wolno na nich nakładać podatku, daniny ani cła.***
###### **Ezd 7,25**
 ***A ty, Ezdraszu, ustanów według mądrego Prawa Boga twojego, które posiadasz, urzędników i sędziów, co sądzić będą cały lud w Transeufratei, to jest wszystkich, którzy znają Prawo Boga twojego; a tych, którzy nie znają, macie pouczyć.***
###### **Ezd 7,26**
 ***I każdy, kto nie wykona Prawa Boga twojego albo rozkazu królewskiego, będzie niechybnie skazany na śmierć albo na wygnanie, albo na karę pieniężną, albo na więzienie***».
###### **Ezd 7,27**
  Uwielbiony niech będzie Pan, Bóg ojców naszych, który tak pokierował umysłem króla, by uświetnić dom Pański w Jerozolimie,
###### **Ezd 7,28**
 i który u króla, radców jego i wszystkich możnych dostojników królewskich wyjednał mi życzliwość. A ja, ponieważ ręka Pana, Boga mojego, była nade mną, nabrałem otuchy i zgromadziłem naczelników Izraela, by poszli ze mną.
# Ezd 7 PAU
###### **Ezd 7,1**
 Wiele lat później, za panowania Artakserksesa, króla perskiego, przybył Ezdrasz, syn Serajasza, syna Azariasza, syna Chilkiasza,
###### **Ezd 7,2**
 syna Szalluma, syna Sadoka, syna Achituba,
###### **Ezd 7,3**
 syna Amariasza, syna Azariasza, syna Merajota,
###### **Ezd 7,4**
 Syna Zerachiasza, syna Uzzjego, syna Bukkiego,
###### **Ezd 7,5**
 syna Abiszuy, syna Pinchasa, syna Eleazara, syna Aarona, pierwszego kapłana.
###### **Ezd 7,6**
 Tenże Ezdrasz przybył z Babilonu, a był on pisarzem biegłym w Prawie Mojżesza, które nadał PAN Bóg Izraela. Król spełnił wszystkie jego życzenia, gdyż czuwał nad nim jego PAN Bóg.
###### **Ezd 7,7**
 Razem z nim wyruszyła do Jerozolimy liczna grupa Izraelitów, kapłanów, lewitów, śpiewaków, odźwiernych i sług świątyni. Było to w siódmym roku panowania króla Artakserksesa.
###### **Ezd 7,8**
 Przybył do Jerozolimy w piątym miesiącu, w siódmym roku panowania króla.
###### **Ezd 7,9**
 Ezdrasz rozpoczął podróż z Babilonu w pierwszym dniu pierwszego miesiąca, a do Jerozolimy przybył w pierwszym dniu piątego miesiąca, gdyż jego Bóg czuwał nad nim łaskawie.
###### **Ezd 7,10**
 Ezdrasz bowiem bardzo pilnie badał Prawo PANA, wypełniał je i uczył jego ustaw i przepisów w Izraelu.
###### **Ezd 7,11**
 A oto odpis dokumentu, który król Artakserkses dał Ezdraszowi, kapłanowi i pisarzowi, nauczycielowi przykazań i ustaw PANA dla Izraela:
###### **Ezd 7,12**
 „Artakserkses, król królów, Ezdraszowi, kapłanowi i znawcy Prawa Boga niebios - pozdrowienie”. I dalej:
###### **Ezd 7,13**
 „Wydaję zarządzenie dotyczące wszystkich mieszkańców mego królestwa, którzy należą do ludu Izraela, a także kapłanów i lewitów: jeśli ktoś z nich chce powrócić z tobą do Jerozolimy - niech idzie!
###### **Ezd 7,14**
 Mając na uwadze, że posyła cię król i jego siedmiu doradców, by ocenić sytuację w Judei i Jerozolimie według Prawa Bożego, które posiadasz,
###### **Ezd 7,15**
 i aby zanieść srebro i złoto złożone przez króla i jego doradców Bogu Izraela, który ma swoją siedzibę w Jerozolimie,
###### **Ezd 7,16**
 oraz srebro i złoto, które otrzymasz z całej prowincji Babilonu wraz z dobrowolnymi darami złożonymi przez lud i kapłanów na dom ich Boga w Jerozolimie,
###### **Ezd 7,17**
 ty uczciwie zakupisz za te pieniądze cielce, barany, jagnięta oraz przynależne do nich ofiary pokarmowe i płynne. Złożysz je w ofierze na ołtarzu w domu waszego Boga w Jerozolimie.
###### **Ezd 7,18**
 Co zaś dotyczy reszty srebra i złota, ty i twoi bracia zarządzicie tym według waszego uznania, zgodnie z wolą waszego Boga.
###### **Ezd 7,19**
 Naczynia zaś, które zostały ci przekazane do kultu w domu twojego Boga, złożysz przed Bogiem w Jerozolimie.
###### **Ezd 7,20**
 Resztę kosztów, jakie poniesiesz na dom twojego Boga, pokryjesz ze skarbca królewskiego.
###### **Ezd 7,21**
 Ja, król Artakserkses, wydaję polecenie wszystkim skarbnikom w prowincji za Eufratem: Wszystko, czego zażąda od was Ezdrasz, kapłan i nauczyciel Prawa Boga niebios, ma być bezzwłocznie wykonane
###### **Ezd 7,22**
 w granicach do stu talentów srebra, stu kor pszenicy, stu baryłek wina, stu baryłek oliwy oraz soli bez ograniczeń.
###### **Ezd 7,23**
 Wszystko, co nakazuje Bóg niebios, ma być gorliwie wykonane dla domu Boga niebios, aby Jego gniew nie zapłonął przeciw królestwu, przeciwko królowi i jego synom.
###### **Ezd 7,24**
 Wam również podaję do wiadomości, że nie wolno nakładać podatków, danin ani innych świadczeń na kapłanów, lewitów, śpiewaków, odźwiernych i sprawujących posługi - jednym słowem na nikogo ze sług tego domu Bożego.
###### **Ezd 7,25**
 A ty, Ezdraszu, według mądrości twego Boga, którą posiadasz, ustanów sędziów i urzędników, aby sprawowali sądy nad wszystkimi mieszkańcami Transeufratei, którzy znają Prawo twego Boga, i aby uczyli tych, którzy go nie znają.
###### **Ezd 7,26**
 Każdy, kto nie będzie przestrzegał Prawa twojego Boga i polecenia królewskiego, zostanie surowo ukarany bądź to wyrokiem śmierci, bądź wygnaniem, bądź grzywną pieniężną lub więzieniem”.
###### **Ezd 7,27**
 Niech będzie błogosławiony PAN, Bóg naszych przodków, który usposobił życzliwie ku nam serce władcy, żeby otoczyć chwałą dom PANA w Jerozolimie,
###### **Ezd 7,28**
 a dla mnie zjednał życzliwość króla, jego doradców i wszystkich możnych dostojników królewskich. Dzięki temu, że towarzyszyła mi opieka PANA, mojego Boga, nabrałem otuchy i zgromadziłem starszyznę Izraela, aby ruszyła ze mną w drogę.
# Ezd 7 BP
###### **Ezd 7,1**
 Po tych wydarzeniach za panowania Artakserksesa, króla Persji, wystąpił Ezdrasz, syn Seraj i, syna Azarji, syna Chilkijji,
###### **Ezd 7,2**
 syna Szalluma, syna Cadoka, syna Achituba,
###### **Ezd 7,3**
 syna Amarji, syna Azarji, syna Merajota,
###### **Ezd 7,4**
 syna Zerachji, syna Uzziego, syna Bukkiego,
###### **Ezd 7,5**
 syna Abiszuy, syna Pinchasa, syna Eleazara, syna najwyższego kapłana Aarona.
###### **Ezd 7,6**
 Ten oto Ezdrasz wyruszył z Babilonu, a był on uczonym, biegłym w Prawie Mojżesza, które dał Jahwe, Bóg Izraela. Król dał mu wszystko, czego zażądał, gdyż ręka Jahwe, Boga Izraela, czuwała nad nim.
###### **Ezd 7,7**
 [Razem z nim] wyruszyło do Jeruzalem w siódmym roku panowania Artakserksesa wielu Izraelitów i kapłanów, lewitów, śpiewaków, odźwiernych i niewolników Świątyni.
###### **Ezd 7,8**
 Przybył on do Jeruzalem w miesiącu piątym, a było to w siódmym roku panowania króla.
###### **Ezd 7,9**
 Zarządził on mianowicie na pierwszy dzień pierwszego miesiąca wyjście z Babilonu i pierwszego dnia piątego miesiąca przybył do Jeruzalem dzięki dobrotliwej ręce Boga, która nad nim czuwała.
###### **Ezd 7,10**
 Ezdrasz bowiem przysposobił się do tego zadania, aby badać i wypełniać Prawo Jahwe, a także by nauczać w Izraelu o ustawach i zwyczajach.
###### **Ezd 7,11**
 A oto odpis pisma, które przekazał król Artakserkses Ezdraszowi, kapłanowi i uczonemu, znawcy słów przykazań Jahwe i ustaw dla Izraela: "
###### **Ezd 7,12**
 Artakserkses, król królów, do Ezdrasza, kapłana i rzecznika Prawa Boga niebios itd. A oto
###### **Ezd 7,13**
 mój rozkaz: Każdy, kto w moim państwie należy do narodu izraelskiego, do jego stanu kapłańskiego i lewickiego, i pragnie udać się do Jeruzalem, może razem z tobą wyruszyć.
###### **Ezd 7,14**
 Ty bowiem zostałeś wysłany przez króla i jego siedmiu doradców, abyś na zasadach Prawa twego Boga, które masz w swoim ręku, zbadał stan rzeczy w Judei i w Jeruzalem i
###### **Ezd 7,15**
 abyś przeniósł srebro i złoto ofiarowane z dobrą wolą przez króla i jego doradców dla Boga Izraela, którego Dom znajduje się w Jeruzalem,
###### **Ezd 7,16**
 a także wszystko srebro i złoto, które otrzymasz w całej prowincji Babilonii razem z dobrowolnymi darami ludu i kapłanów, które zechcą oni złożyć w ofierze dla Świątyni ich Boga w Jeruzalem.
###### **Ezd 7,17**
 Ty zaś masz się zatroszczyć o to, by za te pieniądze kupić cielce, barany, jagnięta oraz należne ofiary z pokarmów i wina i złożyć je na ołtarzu Świątyni waszego Boga w Jeruzalem!
###### **Ezd 7,18**
 Z pozostałym zaś srebrem i złotem uczyńcie, co sami uznacie za stosowne, ty i bracia twoi, ale zgodnie z wolą waszego Boga.
###### **Ezd 7,19**
 Złóż także przed twoim Bogiem w Jeruzalem sprzęty, które ci zostaną przekazane [na służbę] w Świątyni twojego Boga.
###### **Ezd 7,20**
 To, co ponadto będzie ci potrzebne do Świątyni twojego Boga, a czego sam dostarczysz, będzie pokryte ze skarbców królewskich.
###### **Ezd 7,21**
 Ja, król Artakserkses, nakazuję to wszystkim skarbnikom krajów za Eufratem. Wszystko, czegokolwiek zażąda od was Ezdrasz, kapłan i znawca Prawa Boga niebios, należy dokładnie wykonać,
###### **Ezd 7,22**
 [a mianowicie] aż do stu talentów srebra, stu kor pszenicy, stu bat wina, stu bat oliwy, a soli bez ograniczenia.
###### **Ezd 7,23**
 Wszystko, co wynika z rozkazania Boga niebios, należy wypełnić z całą gorliwością dla Świątyni Boga niebios, aby gniew nie spadł na królestwo króla i jego synów.
###### **Ezd 7,24**
 Powiadamiamy was również, że nie wolno nakładać podatków, daniny ani cła na żadnego kapłana, lewitę, śpiewaka, odźwiernego, niewolnika Świątyni lub zwykłego sługę tejże Świątyni Boga.
###### **Ezd 7,25**
 Ty zaś, Ezdraszu, na mocy Mądrości twojego Boga, która jest twym udziałem, ustanów urzędników i sędziów, którzy by wymierzali sprawiedliwość ludowi mieszkającemu w kraju za Eufratem, to jest tym wszystkim, którzy znają Prawo twojego Boga. Tych jednak, którzy go nie znają, winniście o nim pouczyć.
###### **Ezd 7,26**
 Przeciwko temu zaś, który dokładnie nie zastosuje się do Prawa twojego Boga i prawa króla, należy wszcząć postępowanie sądowe i skazać albo na śmierć, albo na wygnanie, albo na karę pieniężną, albo też na więzienie."
###### **Ezd 7,27**
 "Niech będzie uwielbiony Jahwe, Bóg ojców naszych, który natchnął serce królewskie [postanowieniem], by uświetnić Świątynię Jahwe w Jeruzalem,
###### **Ezd 7,28**
 i który pozwolił mi znaleźć łaskę u króla, jego doradców i wszystkich możnych urzędników królewskich! Dzięki temu, że ręka Jahwe, mojego Boga, czuwała nade mną, wzmacniałem się na duchu i pozyskałem przywódców rodów spośród Izraelitów, by ze mną wyruszyli."
# Ezd 7 BR
###### **Ezd 7,1**
 Po tych wydarzeniach pojawił się, już za panowania Artakserksesa, króla perskiego, Ezdrasz, syn Serajasza, syna Azariasza, syna Chilkiasza,
###### **Ezd 7,2**
 syna Szalluma, syna Sadoka, syna Achituba,
###### **Ezd 7,3**
 syna Amariasza, syna Azariasza, syna Merajota,
###### **Ezd 7,4**
 syna Zerachiasza, syna Uzziego, syna Bukkiego,
###### **Ezd 7,5**
 syna Abiszuy, syna Pinchasa, syna Eleazara, syna Aarona, arcykapłana.
###### **Ezd 7,6**
 Otóż ów Ezdrasz przybył z Babilonu. Był on uczonym bardzo biegłym w prawie Mojżesza, które zostało przekazane przez Jahwe, Boga Izraela. Ponieważ prawica Jahwe, jego Boga, była nad nim, król zezwalał mu na wszystko, o co tylko poprosił.
###### **Ezd 7,7**
 W siódmym roku panowania króla Artakserksesa wyruszyli do Jerozolimy bardzo liczni synowie Izraela, kapłani i lewici, śpiewacy, odźwierni i pozostali słudzy świątynni.
###### **Ezd 7,8**
 Ezdrasz przybył do Jerozolimy w piątym miesiącu siódmego roku [panowania] króla [Artakserksesa].
###### **Ezd 7,9**
 Wyruszył z Babilonu pierwszego dnia pierwszego miesiąca, a do Jerozolimy przybył pierwszego dnia piątego miesiąca. Dobroczynna prawica jego Boga była zawsze nad nim.
###### **Ezd 7,10**
 Ezdrasz starał się bowiem z całego serca zgłębiać prawo Jahwe i wprowadzać je w życie, przypominając równocześnie całemu Izraelowi przykazania i pouczenia [Pańskie].
###### **Ezd 7,11**
 A oto odpis listu, który król Artakserkses wręczył Ezdraszowi, kapłanowi i uczonemu, biegłemu w przepisach prawa Jahwe oraz w Jego przykazaniach dotyczących Izraela.
###### **Ezd 7,12**
 Artakserkses, król królów - do Ezdrasza, kapłana, uczonego, biegłego w prawie Boga Zastępów niebieskich.
###### **Ezd 7,13**
 Wydałem zarządzenie, na mocy którego wszyscy Izraelici, kapłani i lewici żyjący w moim królestwie mogą - jeśli tylko zechcą razem z tobą wracać do Jerozolimy.
###### **Ezd 7,14**
 Ciebie zaś król i jego siedmiu doradców wysyłają, żebyś był nadzorcą całej ziemi judzkiej i Jerozolimy, zgodnie z prawem Pańskim, które masz w ręku.
###### **Ezd 7,15**
 Ty również zabierzesz ze sobą srebro i złoto, jakie król i jego doradcy dobrowolnie składają w ofierze Bogu Izraela, którego przybytek znajduje się w Jerozolimie.
###### **Ezd 7,16**
 Weźmiesz ze sobą także wszelkie złoto i srebro, jakie zgromadzisz w całej prowincji Babilonu, a nadto dobrowolne datki ludu i kapłanów, przeznaczone na świątynię Pańską w Jerozolimie.
###### **Ezd 7,17**
 Postarasz się, żeby za te pieniądze zakupiono cielce, barany, jagnięta i wszystko, co jest konieczne do składania ofiar z pokarmów i płynów. Wszystko to złożysz w ofierze na ołtarzu w świątyni Pańskiej, która jest w Jerozolimie.
###### **Ezd 7,18**
 Z resztą srebra i złota ty i twoi bracia zrobicie, co będziecie uważali za słuszne, mając na względzie wolę Bożą.
###### **Ezd 7,19**
 Złóż także przed Bogiem w Jerozolimie [święte] naczynia, które ci zostały dane do użytku przy służbie Bożej w świątyni twego Boga.
###### **Ezd 7,20**
 Wszystko, co oprócz tego będzie potrzebne w świątyni twego Boga i co zamierzasz jeszcze zakupić, zakupisz po otrzymaniu pieniędzy ze skarbca królewskiego.
###### **Ezd 7,21**
 Ja zaś, król Artakserkses, wszystkim skarbnikom pełniącym swój urząd na ziemiach poza Rzeką, nakazuję, ażeby starannie czynili zadość każdej prośbie, jaką im przedłoży Ezdrasz, kapłan i uczony, biegły w prawie Boga Zastępów niebieskich,
###### **Ezd 7,22**
 aż do wysokości stu talentów srebra, stu kor zboża, stu batów wina, stu batów oliwy i soli bez ograniczeń.
###### **Ezd 7,23**
 Wszystko, czego tylko zażąda Bóg Zastępów niebieskich dla swej świątyni, winno być natychmiast spełnione, żeby gniew Boży nie zaciążył nad posiadłościami króla i jego synów.
###### **Ezd 7,24**
 Ponadto zarządzamy, ażeby od kapłanów, lewitów, śpiewaków, odźwiernych, od pozostałych sług świątynnych i od wszystkich pełniących jakąkolwiek służbę w świątyni nie pobierano żadnych podatków, danin czy cła.
###### **Ezd 7,25**
 Ty zaś, Ezdraszu, kierując się mądrością Boga, którą posiadasz, ustanów sędziów i urzędników, aby troszczyli się o wymierzanie sprawiedliwości całemu ludowi żyjącemu w kraju za Rzeką i znającemu prawa twojego Boga. I nauczaj owego prawa tych wszystkich, którzy go jeszcze nie znają.
###### **Ezd 7,26**
 Temu natomiast, kto by nie uszanował prawa twego Boga i tych zarządzeń królewskich, niech zostanie wymierzona sprawiedliwość. Niech zostanie skazany na śmierć albo na wygnanie; niech uiści karę pieniężną albo pójdzie do więzienia.
###### **Ezd 7,27**
 Błogosławiony jesteś, o Jahwe, Boże ojców naszych, za to, że nakłoniłeś serce króla do okazania wielkiej troski o chwałę świątyni Jahwe, która jest w Jerozolimie,
###### **Ezd 7,28**
 że ku mnie skierowałeś całą życzliwość króla, jego doradców i wszystkich najznaczniejszych urzędników królewskich. Ja zaś, ponieważ prawica Jahwe, mojego Boga, była nade mną, nabrałem otuchy, zgromadziłem przywódców Izraela i zachęciłem ich, żeby poszli ze mną.
# Ezd 7 WUJ
###### **Ezd 7,1**
 A po tych słowiech za królestwa Artaxerxa króla Perskiego, Ezdrasz syn Saraji, syna Azaryasza, syna Helciasza,
###### **Ezd 7,2**
 Syna Sellum, syna Sadok, syna Achitob,
###### **Ezd 7,3**
 Syna Amaryasza, syna Azaryasza, syna Marajoth,
###### **Ezd 7,4**
 Syna Zarahiasza, syna Ozi, syna Bokci,
###### **Ezd 7,5**
 Syna Abisue, syna Phinees, syna Eleazar, syna Aarona kapłana od początku.
###### **Ezd 7,6**
 Ten Ezdrasz wyszedł z Babilonu, a ten pisarz prędki w zakonie Mojżeszowym, który dał Pan Bóg Izraelowi: dał mu król, według ręki Pana Boga jego nad nim, wszystkę prośbę jego.
###### **Ezd 7,7**
 I wyszło z synów Izrael, i z synów kapłańskich, iż synów Lewitckich, i z śpiewaków, i z odźwiernych, i z Nathynejczyków do Jeruzalem, roku siódmego Artaxerxa króla.
###### **Ezd 7,8**
 I przyszli do Jeruzalem miesiąca piątego, ten jest siódmy rok królewski.
###### **Ezd 7,9**
 Bo pierwszego dnia miesiąca pierwszego począł wychodzić z Babilonu, a pierwszego dnia miesiąca piątego przyszedł do Jeruzalem, według ręki Boga jego dobrej nad nim.
###### **Ezd 7,10**
 Bo Ezdrasz przygotował serce swe, aby szukał zakonu Pańskiego, i czynił i nauczał w Izraelu przykazania i sądu.
###### **Ezd 7,11**
 A wypis listu wyroku ten jest, który dał król Artaxerxes Ezdraszowi kapłanowi, pisarzowi uczonemu w mowiech i w przykazaniach Pańskich i w ceremoniach jego w Izraelu.
###### **Ezd 7,12**
 Artaxerxes król królów Ezdraszowi kapłanowi, pisarzowi prawa Boga niebieskiego wielce uczonemu zdrowia.
###### **Ezd 7,13**
 Odemnie dekret wyszedł, aby komukolwiekby się podobało w królestwie mojem z ludu Izraelskiego, i z kapłanów jego, i z Lewitów iść do Jeruzalem, szedł z tobą.
###### **Ezd 7,14**
 Abowiemeś posłań od króla i od siedmi radnych panów jego, abyś nawiedził Żydowską ziemię i Jeruzalem w zakonie Boga twego, który jest w ręku twoich:
###### **Ezd 7,15**
 Ażebyś niósł srebro, i złoto, które król i rada jego dobrowolnie ofiarowali Bogu Izraelowemu, którego przybytek jest w Jeruzalem.
###### **Ezd 7,16**
 I wszystko srebro i złoto, którebyśkolwiek nalazł we wszystkiej ziemi Babilońskiej, i lud by chciał ofiarować, i z kapłanów coby dobrowolnie ofiarowali domowi Boga swego, który jest w Jeruzalem.
###### **Ezd 7,17**
 Przespiecznie weźmi, i z tych pieniędzy z pilnością nakup cielców, baranów, baranków, i obiat i mokrych ofiar ich, a ofiaruj je na ołtarzu kościoła Boga waszego, który jest w Jeruzalem.
###### **Ezd 7,18**
 Ale i jeśli co tobie i braciej twej będzie się podobało z ostatka srebra i złota uczynić, według woli Boga waszego, czyńcie.
###### **Ezd 7,19**
 Naczynie też, które tobie dają dla służby domu Boga twego, oddaj przed oblicznością Boga w Jeruzalem.
###### **Ezd 7,20**
 Ale i inne rzeczy, którychby było potrzeba w dom Boga twego, ilekolwiek będzie potrzeba, abyś nałożył, będzie dano z skarbu i pieniędzy królewskich,
###### **Ezd 7,21**
 I odemnie: Ja król Artaxerxes postanowiłem i dałem dekret wszystkim stróżom skrzyni pospolitej, którzy są za rzeką, czegokolwiek od was żądać będzie Ezdrasz kapłan, pisarz zakonu Boga niebieskiego, abyście bez omieszkania dali.
###### **Ezd 7,22**
 Aż do sta talentów srebra, i aż do sta korcy pszenice, i aż do sta batów wina, i do sta batów oliwy, a soli bez miary.
###### **Ezd 7,23**
 Wszystko co należy do obrzędu Boga niebieskiego, niech będzie oddano z pilnością w domu Boga niebieskiego: by się snadź nie rozgniewał na królestwo króla, i synów jego.
###### **Ezd 7,24**
 Wam też oznajmujemy o wszystkich kapłaniech i Lewitach, i śpiewakach, i odźwiernych, Nathynejczykach i sługach domu Boga tego, żebyście nie mieli mocy cła, dani, i rocznego obroku wkładać na nie.
###### **Ezd 7,25**
 A ty Ezdraszu według mądrości Boga twego, która jest w ręce twojej, postanów sędzię i urzędniki, żeby sądzili wszystkiemu ludowi, który jest za rzeką, to jest, tym, którzy znają zakon Boga twego, ale i nieumiejętne bezpiecznie nauczajcie.
###### **Ezd 7,26**
 A wszelki, któryby nie pełnił zakonu Boga twego, i zakonu królewskiego pilnie, będzie o nim sąd abo na śmierć, aby na wygnanie, abo na skaranie na majętności jego, abo więc na więzienie.
###### **Ezd 7,27**
 Błogosławiony Pan Bóg ojców naszych, który to dał w serce królewskie, aby wsławił dom Pański, który jest w Jeruzalem,
###### **Ezd 7,28**
 A ku mnie skłonił miłosierdzie swe przed królem i radą jego, i wszystkimi możnemi książęty królewskimi: a ja umocniony ręką Pana Boga mego, która była nademną, zgromadziłem z Izraela przedniejsze, którzyby szli zemną.
