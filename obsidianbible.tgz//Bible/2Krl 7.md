# 2Krl 7 BT5
###### **2Krl 7,1**
 Elizeusz zaś odpowiedział: «***Posłuchajcie słowa Pańskiego! Tak mówi Pan: Jutro o tej samej porze jedna sea najczystszej mąki będzie za jednego sykla, dwie sea jęczmienia też za jednego sykla – w bramie Samarii***».
###### **2Krl 7,2**
 W odpowiedzi na to tarczownik, na którego ramieniu król się wspierał, rzekł do męża Bożego: «***Chociażby nawet Pan zrobił okna w niebiosach, czy mogłoby się spełnić to słowo?***» Odpowiedział [Elizeusz]: «***Ty ujrzysz to na własne oczy, lecz jeść z tego nie będziesz!***»
###### **2Krl 7,3**
 Czterech trędowatych znajdowało się u wejścia do bramy. Jeden do drugiego powiedział: «***Po co tutaj siedzimy, aż pomrzemy?***
###### **2Krl 7,4**
 ***Jeżeli powiemy: Chodźmy do miasta, a w mieście panuje głód, to tam umrzemy. A teraz – szybko – zbiegnijmy do obozu aramejskiego. Jeżeli nas pozostawią przy życiu, to będziemy żyli. Jeżeli zaś nas zabiją, to umrzemy***».
###### **2Krl 7,5**
 Powstali zatem o zmierzchu, aby wejść do obozu aramejskiego. Dotarli aż do krańca obozu aramejskiego: a oto nie było tam nikogo.
###### **2Krl 7,6**
 Pan bowiem sprawił, że w obozie aramejskim usłyszano turkot rydwanów, tętent koni i wrzawę ogromnego wojska, tak iż mówili, jeden do drugiego: «***Oto król izraelski najął przeciwko nam królów chittyckich i królów egipskich, aby ruszyli przeciwko nam***».
###### **2Krl 7,7**
 Powstali więc [Aramejczycy] i uciekli o zmierzchu, zostawiając swoje namioty, swoje konie, swoje osły, obóz jak stał i uciekli, aby ratować życie.
###### **2Krl 7,8**
 Owi trędowaci zaś dotarli aż do krańca obozu, weszli do jakiegoś namiotu, jedli i pili. Następnie wynieśli stamtąd srebro, złoto i ubrania, które poszli ukryć. Potem wrócili, weszli do innego namiotu, wynieśli stamtąd łup, który poszli ukryć.
###### **2Krl 7,9**
 Wtedy powiedział jeden do drugiego: «***Nie postępujemy właściwie. Dzień dzisiejszy jest dniem radosnej nowiny, a my milczymy. Jeżeli będziemy zwlekali aż do brzasku porannego, to spotka nas kara. Dalej, chodźmy teraz i zanieśmy wieść do pałacu królewskiego***».
###### **2Krl 7,10**
 Poszli tam, zawołali na straże miasta i oznajmili im: «***Weszliśmy do obozu aramejskiego, lecz nie ma tam nikogo, nawet nie słychać żadnego głosu ludzkiego, tylko konie na uwięzi, osły na uwięzi i namioty, jak stały***».
###### **2Krl 7,11**
 Strażnicy, nawołując się, zanieśli wieść do wnętrza pałacu królewskiego.
###### **2Krl 7,12**
 Król wstał w nocy i powiedział do sług swoich: «***Chcę wam wyjaśnić, co knują Aramejczycy przeciwko nam. Wiedzą, że głodujemy. Dlatego wyszli z obozu, aby się ukryć na polu, mówiąc: Kiedy wyjdą z miasta, pochwycimy ich żywcem i wtargniemy do miasta***».
###### **2Krl 7,13**
 Jeden ze sług jego odpowiedział: «***Niech wezmą pięć pozostałych koni; z tymi, które tutaj pozostały żywe, będzie tak, jak z całym mnóstwem Izraela, które ginie, poślijmy, a zobaczymy***».
###### **2Krl 7,14**
 Wzięto więc dwa rydwany z końmi, które król wysłał za wojskiem aramejskim, polecając: «***Jedźcie i zbadajcie!***»
###### **2Krl 7,15**
 Ruszyli za nimi aż do Jordanu. Oto cała droga pełna była szat i broni, które Aramejczycy porzucili podczas swej ucieczki. Posłańcy wrócili i powiadomili króla.
###### **2Krl 7,16**
 Wówczas lud wyszedł i złupił obóz aramejski. Wtedy jedna sea najczystszej mąki kosztowała jednego sykla, dwie sea jęczmienia też jednego sykla – według słowa Pańskiego.
###### **2Krl 7,17**
 Król rozkazał, żeby tarczownik, na którego ramieniu się wspierał, sprawował nadzór w bramie. Lecz tłum zadeptał go w bramie na śmierć, tak jak przepowiedział mąż Boży, który mówił w chwili przyjścia króla do niego.
###### **2Krl 7,18**
 Kiedy bowiem mąż Boży powiedział do króla: «***Jutro o tej samej porze dwie sea jęczmienia będą za jednego sykla, a jedna sea najczystszej mąki za jednego sykla – w bramie Samarii***»,
###### **2Krl 7,19**
 Wówczas tarczownik odpowiedział mężowi Bożemu: «***Chociażby nawet Pan zrobił okna w niebiosach, czy mogłoby się spełnić to słowo?***» On zaś rzekł: «***Ty ujrzysz to na własne oczy, lecz jeść z tego nie będziesz***».
###### **2Krl 7,20**
 I tak się z nim stało. Zadeptał go bowiem tłum w bramie na śmierć.
# 2Krl 7 PAU
###### **2Krl 7,1**
 Elizeusz jednak oświadczył: „Słuchajcie słowa PANA! Tak mówi PAN: «Jutro o tej porze na targu w bramach Samarii jedna sea najlepszej mąki będzie za jednego sykla i dwie sea jęczmienia również za jednego sykla»”.
###### **2Krl 7,2**
 Wtedy oficer, na którego ramieniu król się wspierał, odezwał się do człowieka Bożego: „Z pewnością PAN otworzy okna w niebie! Czy możliwe jest coś takiego?”. On zaś odparł: „Ty sam będziesz patrzył na to własnymi oczami, ale jeść z tego nie będziesz!”.
###### **2Krl 7,3**
 Czterech mężczyzn dotkniętych trądem przebywało u wejścia bramy. Rozmawiali między sobą: „Po cóż mamy tu siedzieć i czekać na śmierć?
###### **2Krl 7,4**
 Możemy wejść do miasta, ale w mieście panuje głód, więc tam umrzemy; jeśli zostaniemy tutaj, również umrzemy. Zejdźmy zatem do obozu aramejskiego i poddajmy się: jeśli darują nam życie, będziemy żyli, a jeśli skażą nas na śmierć, to umrzemy”.
###### **2Krl 7,5**
 O zmierzchu więc wyruszyli do obozu aramejskiego. Doszli aż na koniec obozu, ale nie było tam nikogo.
###### **2Krl 7,6**
 Pan bowiem sprawił, że w obozie aramejskim dał się słyszeć turkot rydwanów, tętent koni i wrzawa ogromnego wojska. Wtedy to żołnierze zaczęli mówić jeden do drugiego: „Na pewno król izraelski wynajął przeciw nam królów chetyckich i egipskich, aby nas zaatakowali”.
###### **2Krl 7,7**
 Natychmiast więc o zmierzchu ruszyli do ucieczki, pozostawiając swoje namioty, konie i osły, obóz - tak jak był - aby ratować swoje życie.
###### **2Krl 7,8**
 Kiedy trędowaci dotarli do krańca obozu, weszli do jednego z namiotów i zaczęli jeść i pić. Potem wynieśli stamtąd srebro, złoto i ubrania i poszli je ukryć. Następnie wrócili, weszli do drugiego namiotu i wynieśli stamtąd rzeczy, które znowu poszli schować.
###### **2Krl 7,9**
 Po chwili jednak zaczęli się zastanawiać: „Nie robimy dobrze. Ten dzień jest dniem radosnej nowiny, a my milczymy. Jeżeli będziemy czekać aż do rana, zasłużymy na karę. Chodźmy zanieść tę wiadomość do pałacu króla.
###### **2Krl 7,10**
 Kiedy przyszli, wezwali straż u bram miasta i powiedzieli: „Poszliśmy do obozu aramejskiego, ale tam nie było nikogo - żadnych ludzkich głosów, tylko uwiązane konie i osły oraz namioty pozostawione tak jak były”.
###### **2Krl 7,11**
 Strażnicy podnieśli krzyk, posyłając wiadomość do pałacu króla.
###### **2Krl 7,12**
 Król zaraz wstał w nocy i powiedział do swoich sług: „Powiem wam, co Aramejczycy zamierzyli przeciw nam. Wiedzą, że cierpimy głód. Wyszli więc z obozu, aby się ukryć w polu, planując: «Kiedy wyjdą z miasta, pochwycimy ich żywcem i wtargniemy do miasta»”.
###### **2Krl 7,13**
 Na to odezwał się jeden z jego sług: „Niech kilku ludzi weźmie pięć koni z tych, które tu pozostały: ostatecznie bowiem stanie się z nimi bądź to, co stało się z wieloma Izraelitami, którzy przeżyli, bądź to, co stało się z całym mnóstwem Izraela, które zmarło. Wyślijmy ich, niech zobaczą”.
###### **2Krl 7,14**
 Wyprowadzono więc dwa rydwany, do których zaprzęgnięto konie, i król posłał je za wojskiem aramejskim z rozkazem: „Jedźcie i sprawdźcie!”.
###### **2Krl 7,15**
 Udali się za nimi aż nad Jordan, na całej zaś drodze było pełno ubrań i broń porzucona w pośpiechu przez Aramejczyków. Posłańcy zatem wrócili i powiadomili o tym króla.
###### **2Krl 7,16**
 Natychmiast wyszli ludzie i zaczęli plądrować obóz aramejski. Wtedy sea najlepszej mąki było za jednego sykla i dwie sea jęczmienia również za jednego sykla, zgodnie ze słowem PANA.
###### **2Krl 7,17**
 Król powierzył nadzór nad targowiskiem w bramie swojemu oficerowi, na którego ramieniu się wspierał. Tłum jednak stratował go tam na śmierć, zgodnie z tym, co oświadczył człowiek Boży, gdy król przyszedł do niego.
###### **2Krl 7,18**
 Kiedy bowiem człowiek Boży zapowiedział królowi: „Jutro o tej porze, na targu w bramach Samarii jedna sea najlepszej mąki będzie za jednego sykla i dwie sea jęczmienia również za jednego sykla”,
###### **2Krl 7,19**
 to oficer ten odezwał się do człowieka Bożego: „Z pewnością PAN otworzy okna w niebie! Czy możliwe jest coś takiego?”. On zaś odparł: „Ty sam będziesz patrzył na to własnymi oczami, ale jeść z tego nie będziesz!”.
###### **2Krl 7,20**
 I rzeczywiście tak się z nim stało: tłum stratował go w bramie na śmierć.
# 2Krl 7 BP
###### **2Krl 7,1**
 Elizeusz odpowiedział: Słuchajcie słowa Jahwe: Tak mówi Jahwe: Jutro o tej porze w bramie samaryjskiej za [jednego] sykla [będzie można dostać] sea najprzedniejszej mąki lub dwie sea jęczmienia [...].
###### **2Krl 7,2**
 Giermek, na którego ramieniu wspierał się król, odezwał się do męża Bożego i rzekł: Oto Jahwe zrobi otwory w niebie. Czy tak się spełni to słowo? Odrzekł: Oto ty zobaczysz to na własne oczy, ale jeść z tego nie będziesz.
###### **2Krl 7,3**
 Czterej trędowaci mężczyźni znajdowali się u wejścia do bramy i mówili jeden do drugiego: Po co my tu siedzimy [aby czekać], aż pomrzemy?
###### **2Krl 7,4**
 Jeśli postanowimy wejść do miasta, w mieście jest głód, więc tam zginiemy. Jeśli tu zostaniemy, [również] umrzemy. Teraz więc chodźcie, pójdziemy do obozu Aramejczyków; jeśli zachowają nas przy życiu, będziemy żyć, a jeśli nas zabiją, umrzemy.
###### **2Krl 7,5**
 Powstali tedy o zmierzchu, aby się udać do obozu Aramejczyków. Podeszli aż na skraj obozu aramejskiego i oto nikogo tam nie było.
###### **2Krl 7,6**
 Pan sprawił, że wojsko aramejskie słyszało turkot rydwanów, tętent koni oraz gwar wielkiej armii; i poczęli mówić między sobą: Oto król izraelski najął przeciwko nam królów chittyckich i królów mucryckich, aby na nas napadli.
###### **2Krl 7,7**
 Wstali więc i uciekli o zmierzchu. Pozostawili swoje namioty, konie, osły i obóz, tak jak był, i uciekli [aby ratować] swoje życie.
###### **2Krl 7,8**
 I przyszli owi trędowaci na skraj obozu, weszli do jednego namiotu, zjedli, napili się, zabrali stamtąd srebro, złoto i szaty. Poszli i schowali. Wrócili, weszli do innego namiotu, ograbili go, poszli i schowali.
###### **2Krl 7,9**
 [Ale potem] rzekli jeden do drugiego: Niedobrze czynimy! Dzień ten jest dniem dobrej nowiny, my zaś milczymy. Jeśli będziemy czekać do brzasku poranka, spotka nas kara. Teraz więc chodźcie. Pójdziemy i powiadomimy dom królewski.
###### **2Krl 7,10**
 Przyszli, zawołali na strażników bramy miejskiej i oznajmili im mówiąc: Przyszliśmy do obozu Aramejczyków i oto nie znaleźliśmy tam nikogo, ani głosu ludzkiego, tylko uwiązane konie i uwiązane osty oraz namioty, tak jak były.
###### **2Krl 7,11**
 Strażnicy zaalarmowali i dali znać do pałacu królewskiego wewnątrz.
###### **2Krl 7,12**
 Król wstał w nocy i rzekł do swych poddanych: Pragnę wam oznajmić, co zrobili nam Aramejczycy. Wiedzą, że my głodujemy. Opuścili więc obóz, aby się ukryć w polu mówiąc: gdy wyjdą z miasta, wtedy pochwycimy ich żywych i wejdziemy do miasta.
###### **2Krl 7,13**
 Jeden z jego poddanych odezwał się i rzekł: Niech wezmą pięć z reszty koni, które pozostały, oto ich [los] taki jak całego mnóstwa Izraelitów [...], które ginie, wyślemy i zobaczymy.
###### **2Krl 7,14**
 Wzięto dwa rydwany i konie. Król posłał je za wojskiem aramejskim mówiąc: Idźcie i zobaczcie.
###### **2Krl 7,15**
 Pojechali za nimi aż do Jordanu. A oto cała droga była zasłana szatami i sprzętem, który Aramejczycy porzucili w pośpiechu. Wysłańcy wrócili i oznajmili królowi.
###### **2Krl 7,16**
 Wtedy lud wyszedł i złupili obóz aramejski. I była sea najprzedniejszej mąki [...] lub dwie sea jęczmienia za [jednego] sykla, według słowa Jahwe.
###### **2Krl 7,17**
 Król zlecił pieczę nad bramą giermkowi, na którego ręce się wspierał. Ale lud zadeptał go w bramie i zmarł, tak jak zapowiedział mąż Boży, kiedy mówił, gdy król zszedł do niego.
###### **2Krl 7,18**
 I stało się tak, jak przepowiedział mąż Boży królowi mówiąc: Jutro o tej porze w bramie samaryjskiej będą [sprzedawać] dwie sea jęczmienia [...] lub sea najprzedniejszej mąki za [jednego] sykla.
###### **2Krl 7,19**
 Giermek zaś odezwał się do męża Bożego i rzekł: Oto Jahwe zrobi otwory w niebie. Czy tak się spełni to słowo? Elizeusz rzekł: Oto ty na własne oczy to zobaczysz, ale jeść z tego nie będziesz.
###### **2Krl 7,20**
 I spotkało go [to]. Ludzie go zadeptali w bramie i umarł.
# 2Krl 7 BR
###### **2Krl 7,1**
 Elizeusz zaś powiedział: Posłuchajcie, co mówi Jahwe. Oto jego słowa: Jutro o tej samej porze jedną sea najczystszej mąki można będzie znów otrzymać za jednego sykla; za jednego sykla otrzyma się też [jak dawniej] w bramie Samarii dwie sea jęczmienia.
###### **2Krl 7,2**
 A tarczownik, na którego ramieniu wspierał się król, odpowiedział mężowi Bożemu: Czy byłoby to możliwe, nawet gdyby Jahwe uczynił okna w niebie? Rzekł na to Elizeusz: Zobaczysz to sam na własne oczy, ale jeść z tego nie będziesz.
###### **2Krl 7,3**
 U bramy miasta siedziało czterech trędowatych, którzy tak do siebie mówili: Dlaczego mamy tu siedzieć aż do śmierci?
###### **2Krl 7,4**
 Jeżeli wejdziemy do miasta, w którym panuje taki głód, to pomrzemy. Jeżeli zaś zostaniemy tutaj, także pomrzemy. Chodźmy, wtargnijmy do obozu Aramejczyków, jeżeli darują nam życie, będziemy żyli; jeżeli nas pozabijają, nie będziemy żyli.
###### **2Krl 7,5**
 I wstali o zmierzchu, żeby się udać do obozu Aramejczyków. Ale gdy znaleźli się już koło wejścia do obozu, zobaczyli, że nie było w nim nikogo.
###### **2Krl 7,6**
 Pan bowiem sprawił, że w obozie Aramejczyków dał się słyszeć turkot rydwanów i tętent koni, i wrzawa zbliżania się wielkiej liczby wojowników. Zaczęli tedy [Aramejczycy] mówić do siebie: Zapewne król izraelski wynajął za własne pieniądze władców chetyckich i egipskich, żeby ruszyli przeciwko nam i zaatakowali nas.
###### **2Krl 7,7**
 Zerwali się więc i jeszcze o zmierzchu rzucili się do ucieczki, pozostawiając swoje namioty, konie, osły i obóz z całym wyposażeniem. Uciekli, żeby tylko ratować życie.
###### **2Krl 7,8**
 Kiedy trędowaci przyszli do bramy obozu, [spokojnie] weszli do jednego z namiotów, gdzie najedli się i napili do woli, a wychodząc zabrali ze sobą srebro, złoto oraz szaty, które ukryli. Potem wróciwszy weszli do innego namiotu, zabrali z niego różne przedmioty i też je ukryli.
###### **2Krl 7,9**
 Lecz w pewnej chwili zaczęli sobie mówić: Źle zrobiliśmy! Dziś wypada dzień dobrej nowiny. Jeżeli będziemy milczeli aż do rana, spotka nas słuszna kara. Chodźmy, powiadomimy o wszystkim pałac królewski.
###### **2Krl 7,10**
 Poszli więc, a spotkawszy strażników bram miejskich, powiedzieli im tak: Weszliśmy do obozu Aramejczyków i nie spotkaliśmy tam nikogo: nikogo z ludzi, żadnego ludzkiego głosu. Były tam tylko uwiązane konie i osły oraz namioty z pełnym wyposażeniem.
###### **2Krl 7,11**
 Strażnicy podnieśli alarm i otrzymane wiadomości przekazali do pałacu królewskiego.
###### **2Krl 7,12**
 Król wstał w nocy i powiedział do swoich sług: Chcę wam powiedzieć, co uczynili nam Aramejczycy: Wiedząc, że jesteśmy znękani klęską głodu, opuścili podstępnie swój obóz i ukryli się na pobliskich polach, myśląc sobie zapewne tak: Gdy wyjdą z miasta, pochwycimy ich żywcem i wejdziemy do ich miasta.
###### **2Krl 7,13**
 Zabrał wtedy głos jeden z jego sług i powiedział: Weźmy pięć koni z tych, które jeszcze zostały w mieście - jest z nimi tak jak z całym mnóstwem albo dotąd ocalałych, albo już poległych Izraelitów - i poślijmy tam ludzi na zwiad.
###### **2Krl 7,14**
 Wzięto tedy dwa rydwany zaprzężone i król wysłał ludzi śladami pozostawionymi przez wojsko Aramejczyków. Nakazał im: Idźcie i zobaczcie!
###### **2Krl 7,15**
 Szli więc za nimi aż do Jordanu - drogą zasłaną ubraniami i różnymi przedmiotami, które Aramejczycy, uchodząc pośpiesznie, porzucili. Wróciwszy zwiadowcy o wszystkim opowiedzieli królowi.
###### **2Krl 7,16**
 Tymczasem ludzie wyszli i zaczęli grabić obóz Aramejczyków. Wkrótce można było dostać jedną sea najczystszej mąki za jednego sykla i dwie sea jęczmienia również za jednego sykla, zgodnie z tym, co powiedział Jahwe.
###### **2Krl 7,17**
 Straż przy bramie miasta powierzył król tarczownikowi, na którego ramieniu się zwykle wspierał. Ale [gdy pełnił on swą służbę], tłum stratował go na śmierć, zgodnie z tym, co powiedział mąż Boży, kiedy przyszedł do niego król.
###### **2Krl 7,18**
 Kiedy bowiem mąż Boży mówił do króla: Jutro o tej samej porze za jednego sykla otrzyma się w bramie Samarii dwie sea jęczmienia oraz jedną sea najczystszej mąki również za jednego sykla,
###### **2Krl 7,19**
 to ów tarczownik powiedział: Czy byłoby to możliwe, nawet gdyby Jahwe uczynił okna w niebie? Wtedy to Elizeusz powiedział: Zobaczysz to sam na własne oczy, ale jeść z tego nie będziesz.
###### **2Krl 7,20**
 I oto, co się z nim stało: tłum stratował go w bramie i tarczownik umarł.
# 2Krl 7 WUJ
###### **2Krl 7,1**
 I rzekł Elizeusz: Słuchajcie słowa pańskiego: To mówi Pan: O tem czasie jutro będzie korzec białej mąki za jeden sta ter, a dwa korce jęczmienia za jeden stater, w bramie Samaryjskiej.
###### **2Krl 7,2**
 Odpowiadając jeden z książąt, na którego ręce król się wspierał, człowiekowi Bożemu rzekł: By też Pan podziałał wypusty w niebie, zaż będzie mogło być co powiadasz? Który rzekł: Ujrzysz oczyma twemi, ale z tego jeść nie będziesz.
###### **2Krl 7,3**
 Byli tedy czterej mężowie trędowaci u weścia bramy: którzy rzekli jeden do drugiego: Cóż tu chcemy być aż pomrzemy?
###### **2Krl 7,4**
 Choć że chcemy wniść do miasta, głodem umrzemy: choć też tu zostaniemy, musiem umrzeć: pódźcież tedy, a zbieżmy do obozu Syryjskiego, jeśli nam zfolgują będziem żywi: a jeśli będą chcieli zabić przecie pomrzemy.
###### **2Krl 7,5**
 Wstali tedy w wieczór, aby szli do wojska Syryjskiego. A przyszedszy do przodku obozu Syryjskiego, nikogo tamże nie naleźli.
###### **2Krl 7,6**
 Abowiem Pan dał był słyszeć w oboziech Syryjskich grzmot wozów i koni, i wojska wielkiego: i rzekli jeden do drugiego: Oto król Izraelski najął za pieniądze przeciwko nam króle Hetejskie i Egiptskie, i przyszli na nas.
###### **2Krl 7,7**
 Wstali tedy i uciekli nocą, i zostawili namioty swe i konie i osły w obozie, i uciekli chcąc tylko dusze swe zachować.
###### **2Krl 7,8**
 Gdy tedy przyszli oni trędowaci na przodek obozu, weszli do namiotu jednego, i jedli i pili: i nabrali ztamtąd srebra i złota i szat, szli i pokryli: i zasię wrócili się do drugiego namiotu, i z niego także nabrawszy pokryli.
###### **2Krl 7,9**
 I rzekli jeden ku drugiemu: Nie dobrze czyniemy: ten dzień bowiem dobrej nowiny jest. Jeśli zamilczemy, a nie będziem chcieć powiedzieć aż do zarania, będziem winni grzechu: Pódźcie idźmy, a powiedzmy na dworze królewskim.
###### **2Krl 7,10**
 A gdy przyszli do bramy, miejskiej, powiedzieli im, mówiąc: Szliśmy do obozu Syryjskiego, a żadnegośmy tam człowieka nie naleźli, jedno konie a osły przywiązane, i namioty rozbite.
###### **2Krl 7,11**
 Szli tedy wrotni, i opowiedzieli w pałacu króla wewnątrz.
###### **2Krl 7,12**
 Który wstał w nocy, i rzekł do służebników swoich: Powiadam wam co nam uczynili Syryjczykowie: Wiedzą że głód cierpiemy, i przetoż wyszli z obozu, a pokryli się w polu, mówiąc: Gdy wynidą z miasta, pojmamy je żywo, a potem miasto ubieżeć będziem mogli.
###### **2Krl 7,13**
 I odpowiedział jeden z służebników jego: Weźmiemy pięć koni, które w mieście zostały (bo te tylko są we wszystkiem zgromadzeniu Izrahel, inne bowiem wszystkie strawione są), a posławszy będziem się mogli wywiedzieć.
###### **2Krl 7,14**
 Przywiedziono tedy dwa konie, i posłał król do obozu Syryjskiego, mówiąc: Idźcie a spatrzajcie.
###### **2Krl 7,15**
 Którzy jachali za nimi aż do Jordanu: a oto wszystka droga pełna była szat i naczynia, które porzucali Syryjczykowie, gdy się trwożyli: i wróciwszy się posłowie powiedzieli królowi.
###### **2Krl 7,16**
 I wyszedszy lud rozchwycił obóz Syryjski: i stał się korzec białej mąki po jednym staterze, a dwa korce jęczmienia po staterze jednym, według słowa Pańskiego.
###### **2Krl 7,17**
 A król ono Książę, którego się ręki wspierał, postawił u bramy: którego gmin podeptał w weściu bramy i umarł, wedle tego, jako był powiedział mąż Boży, gdy był król stąpił do niego.
###### **2Krl 7,18**
 I stało się według słowa męża Bożego, które był rzekł królowi, kiedy mówił: Dwa korca jęczmienia będą za jeden stater, a korzec białej mąki za jeden stater, o tymże czasie jutro w bramie Samariiej.
###### **2Krl 7,19**
 Gdy ono Książę odpowiedziało było mężowi Bożemu, i rzekło: by też Pan uczynił upusty w niebie: azaż może się stać co powiadasz? I rzekł mu: Ujrzysz oczyma twemi, ale z tego jeść nie będziesz.
###### **2Krl 7,20**
 Potkało go tedy jako było opowiedziano i podeptał go lud w bramie i umarł.
