# 2Krl 1 BT5
###### **2Krl 1,1**
 Po śmierci Achaba Moab zbuntował się przeciw Izraelowi.
###### **2Krl 1,2**
 Ochozjasz zaś wypadł przez kratę swej górnej komnaty w Samarii i chorował. Wysłał więc posłańców, mówiąc do nich: «***Idźcie, wywiedzcie się u Beelzebuba, boga Ekronu, czy wyzdrowieję z tej mojej choroby***».
###### **2Krl 1,3**
 Lecz anioł Pański powiedział do Eliasza z Tiszbe: «***Wstań, wyjdź naprzeciw posłańców króla Samarii i powiedz im: Czyż nie ma Boga w Izraelu, że wy idziecie wywiadywać się u Beelzebuba, boga Ekronu?***
###### **2Krl 1,4**
 ***Dlatego tak mówi Pan: Z łoża, do którego wszedłeś, już nie zejdziesz, ponieważ umrzesz na pewno!***» I odszedł Eliasz.
###### **2Krl 1,5**
 Kiedy posłańcy wrócili do Ochozjasza, rzekł do nich: «***Czemu już powróciliście?***»
###### **2Krl 1,6**
 Odpowiedzieli mu: «***Jakiś człowiek wyszedł naprzeciw nas i rzekł do nas: Idźcie, wróćcie do króla, który was wysłał, i powiedzcie mu: Tak mówi Pan: Czyż nie ma Boga w Izraelu, że ty polecasz wywiadywać się u Beelzebuba, boga Ekronu? Dlatego z łoża, do którego wszedłeś, już nie zejdziesz, ponieważ umrzesz na pewno!***»
###### **2Krl 1,7**
 On zaś rzekł do nich: «***Jak wyglądał ten człowiek, który wyszedł wam naprzeciw i wypowiedział do was te słowa?***»
###### **2Krl 1,8**
 Odpowiedzieli mu: «***Był to człowiek w płaszczu z sierści, przepasany pasem skórzanym dokoła bioder***». Wtedy zawołał: «***To Eliasz z Tiszbe!***»
###### **2Krl 1,9**
 Posłał zatem po niego pięćdziesiątnika wraz z jego pięćdziesiątką. Przyszedł on więc do Eliasza, gdy [ten] właśnie przebywał na szczycie góry, i powiedział do niego: «***Mężu Boży! Król ci nakazał: Zejdź!***»
###### **2Krl 1,10**
 Odpowiadając, Eliasz rzekł do pięćdziesiątnika: «***Jeżeli ja jestem mężem Bożym, niech spadnie ogień z nieba i pochłonie ciebie wraz z twoją pięćdziesiątką!***» I spadł ogień z nieba, i pochłonął go wraz z jego pięćdziesiątką.
###### **2Krl 1,11**
 Wtedy król powtórnie wysłał po niego innego pięćdziesiątnika wraz z jego pięćdziesiątką. Ten odezwał się i rzekł do niego: «***Mężu Boży! Tak mówi król: Zejdź natychmiast!***»
###### **2Krl 1,12**
 Odpowiadając, Eliasz rzekł do nich: «***Jeżeli ja jestem mężem Bożym, niech spadnie ogień z nieba i pochłonie ciebie wraz z twoją pięćdziesiątką!***» A ogień Boży spadł z nieba i pochłonął go wraz z jego pięćdziesiątką.
###### **2Krl 1,13**
 Wtedy król znowu wysłał trzeciego pięćdziesiątnika wraz z jego pięćdziesiątką. Gdy trzeci pięćdziesiątnik przyszedł, padł na kolana przed Eliaszem i błagał go o miłosierdzie w tych słowach: «***Mężu Boży! Niech życie moje oraz życie tych sług twoich pięćdziesięciu drogie będzie w twoich oczach!***
###### **2Krl 1,14**
 ***Oto ogień spadł z nieba i pochłonął obydwóch poprzednich pięćdziesiątników wraz z ich pięćdziesiątkami. Lecz teraz niech życie moje drogie będzie w twoich oczach!***»
###### **2Krl 1,15**
 Wtedy anioł Pański powiedział do Eliasza: «***Zejdź razem z nim, nie bój się go!***» Eliasz podniósł się i zszedł razem z nim do króla,
###### **2Krl 1,16**
 i powiedział do niego: «***Tak mówi Pan: Ponieważ wysłałeś posłańców, by wywiadywać się u Beelzebuba, boga Ekronu – czyż nie ma Boga w Izraelu, by szukać Jego wyroku? – przeto z łoża, do którego wszedłeś, już nie zejdziesz, ponieważ umrzesz na pewno!***»
###### **2Krl 1,17**
 Umarł więc król według wyroku Pańskiego, który Eliasz oznajmił. A brat jego, Joram, został w jego miejsce królem w drugim roku [panowania] Jorama, syna Jozafata, króla judzkiego, bo [Ochozjasz] nie miał syna.
###### **2Krl 1,18**
 A czyż pozostałe czyny Ochozjasza, których dokonał, nie są opisane w Księdze Kronik Królów Izraela?
# 2Krl 1 PAU
###### **2Krl 1,1**
 Po śmierci Achaba Moab zbuntował się przeciwko Izraelowi.
###### **2Krl 1,2**
 Natomiast Ochozjasz wypadł przez otwór okienny swojej górnej komnaty w Samarii i rozchorował się. Wysłał więc posłańców z poleceniem: „Idźcie do Baalzebuba, boga Ekronu, i zapytajcie, czy wyzdrowieję z tej choroby”.
###### **2Krl 1,3**
 Wtedy anioł PANA powiedział do Eliasza z Tiszbe: „Wyjdź zaraz naprzeciw posłańcom króla Samarii i zapytaj ich: «Czyż nie ma Boga w Izraelu, że idziecie radzić się aż Baalzebuba, boga Ekronu?
###### **2Krl 1,4**
 Dlatego tak mówi PAN: Już nie wstaniesz z łóżka, na które się położyłeś. Na pewno umrzesz!»”. I Eliasz odszedł.
###### **2Krl 1,5**
 Gdy posłańcy wrócili do króla, zapytał ich: „Dlaczego tak szybko wróciliście?”.
###### **2Krl 1,6**
 Odpowiedzieli mu: „Pewien człowiek wyszedł nam naprzeciw i powiedział do nas: «Zawróćcie zaraz do króla, który was wysłał, i powiedzcie mu: Tak mówi PAN: Czyż nie ma Boga w Izraelu, że każesz radzić się Baalzebuba, boga Ekronu? Dlatego już nie wstaniesz z łóżka, na które się położyłeś, lecz na pewno umrzesz!»”.
###### **2Krl 1,7**
 Król zapytał ich: „Jak wyglądał ten człowiek, który wyszedł naprzeciw wam i powiedział wam to wszystko?”.
###### **2Krl 1,8**
 Odpowiedzieli mu: „Był to owłosiony mężczyzna, przepasany skórzanym pasem na biodrach”. Wtedy król zawołał: „To Eliasz z Tiszbe”.
###### **2Krl 1,9**
 Posłał zatem do niego dowódcę z oddziałem pięćdziesięciu ludzi, który wspiął się do niego, gdyż Eliasz siedział właśnie na szczycie góry. Dowódca oddziału zawołał: „Boży człowieku! Z rozkazu króla, zejdź!”.
###### **2Krl 1,10**
 „Jeśli ja jestem człowiekiem Bożym - odpowiedział Eliasz - to niech ogień spadnie z nieba i pochłonie ciebie i twój oddział!”. Zaraz też spadł ogień z nieba i pochłonął go razem z jego oddziałem.
###### **2Krl 1,11**
 Ochozjasz posłał więc znowu do niego innego dowódcę z oddziałem pięćdziesięciu ludzi. Ten zwrócił się do niego z rozkazem: „Boży człowieku! Tak mówi król: «Zejdź natychmiast!»”.
###### **2Krl 1,12**
 „Jeśli ja jestem człowiekiem Bożym - odpowiedział im Eliasz - to niech ogień spadnie z nieba i pochłonie ciebie i twój oddział!”. Zaraz też spadł ogień z nieba i pochłonął go razem z jego oddziałem.
###### **2Krl 1,13**
 Znowu więc Ochozjasz posłał do niego trzeciego dowódcę z oddziałem pięćdziesięciu ludzi. Kiedy ów trzeci dowódca przybył z oddziałem, upadł na kolana przed Eliaszem i błagał go: „Człowieku Boży, miej litość nade mną i nad tymi pięćdziesięcioma twoimi sługami.
###### **2Krl 1,14**
 Bo ogień spadł z nieba i pochłonął dwóch pierwszych dowódców z ich oddziałami po pięćdziesięciu ludzi, lecz teraz miej wzgląd na moje życie”.
###### **2Krl 1,15**
 Anioł PANA polecił wtedy Eliaszowi: „Zejdź z nim, nie bój się go!”. Natychmiast poszedł z nim do króla,
###### **2Krl 1,16**
 któremu oświadczył: „Tak mówi PAN: «Ponieważ wysłałeś posłańców, aby radzić się Baalzebuba, boga Ekronu, jak gdyby nie było Boga w Izraelu, u którego można szukać rady, dlatego już nie wstaniesz z łóżka, na które się położyłeś, gdyż na pewno umrzesz!»”.
###### **2Krl 1,17**
 Ochozjasz umarł więc zgodnie ze słowem PANA, które przepowiedział Eliasz. A ponieważ nie miał on syna, Joram został po nim królem w drugim roku rządów Jorama, syna Jozafata, króla Judy.
###### **2Krl 1,18**
 Pozostałe wydarzenia związane z panowaniem Ochozjasza wraz z tym, czego dokonał, są opisane w kronikach królów Izraela.
# 2Krl 1 BP
###### **2Krl 1,1**
 Po śmierci Achaba Moab zbuntował się przeciw Izraelowi.
###### **2Krl 1,2**
 Ochozjasz wypadł przez balustradę swej górnej komnaty, którą miał w Samarii, i zachorował. Wyprawił posłańców i rzekł do nich: Idźcie i poradźcie się Baal Zebuba, boga Ekronu, czy wyjdę zdrowo z tej choroby.
###### **2Krl 1,3**
 [Tymczasem] anioł Jahwe rzekł do Eliasza Tiszbity: Wstań, wyjdź naprzeciw posłów króla Samarii i powiedz im: Czyż nie ma Boga w Izraelu, że wy idziecie radzić się Baal Zebuba, boga Ekronu?
###### **2Krl 1,4**
 Dlatego tak mówi Jahwe: "Nie zejdziesz z łoża, na które wszedłeś, albowiem na pewno umrzesz". Eliasz się oddalił.
###### **2Krl 1,5**
 Posłańcy wrócili do [króla], a on zaś ich zapytał: Co to? Wróciliście?
###### **2Krl 1,6**
 Odpowiedzieli mu: [Jakiś] człowiek wyszedł naprzeciw nas i powiedział nam: "Idźcie, wróćcie do króla, który was wysłał, i oznajmijcie mu: Tak mówi Jahwe: Czyż nie ma Boga w Izraelu, [że] ty posyłasz, aby się radzić Baal Zebuba, boga Ekronu? - Dlatego nie zejdziesz z łoża, na które wszedłeś, albowiem na pewno umrzesz".
###### **2Krl 1,7**
 A [król] zapytał ich: Jak wyglądał ów człowiek, który wyszedł naprzeciw was i powiedział wam te słowa?
###### **2Krl 1,8**
 Odpowiedzieli mu: Był to mężczyzna [okryty] kożuchem, a biodra miał przepasane skórzanym pasem. Rzekł: On był Eliaszem Tiszbitą.
###### **2Krl 1,9**
 Posłał tedy do niego pięćdziesiątnika oraz jego pięćdziesięciu [ludzi]. [Ten] wyszedł do niego, a siedział właśnie na szczycie góry i powiedział mu: Mężu Boży, król polecił: zstąp!
###### **2Krl 1,10**
 Eliasz zaś odpowiadając pięćdziesiątnikowi rzekł: Jeśli ja jestem mężem Bożym, niech ogień z nieba spadnie i pożre ciebie i twoich pięćdziesięciu. I spadł ogień z nieba, i pożarł go oraz jego pięćdziesięciu.
###### **2Krl 1,11**
 [Król] znowu wysłał do niego innego pięćdziesiątnika oraz jego pięćdziesięciu [ludzi]. [Ten] wyszedł i powiedział mu: Mężu Boży, tak mówi król: zstąp szybko!
###### **2Krl 1,12**
 Eliasz zaś odezwał się do nich i rzekł: Jeśli ja jestem mężem Bożym, niech ogień z nieba spadnie i pochłonie ciebie i twoich pięćdziesięciu. I spadł ogień Boży z nieba, i pochłonął go oraz jego pięćdziesięciu [ludzi].
###### **2Krl 1,13**
 [Król] znowu wysłał trzeciego pięćdziesiątnika oraz jego pięćdziesięciu [ludzi]. Ale trzeci pięćdziesiątnik wyszedł, przybył [na miejsce], upadł na kolana przed Eliaszem, poprosił go i rzekł mu: Mężu Boży, niech moje życie oraz życie tych twoich pięćdziesięciu sług ma [jakąś] wartość w twoich oczach.
###### **2Krl 1,14**
 Oto ogień spadł z nieba i pochłonął dwóch poprzednich pięćdziesiątników oraz ich pięćdziesięciu [ludzi]. Niech teraz moje życie ma [jakąś] wartość w twoich oczach.
###### **2Krl 1,15**
 Anioł Jahwe rzekł do Eliasza: Zstąp z nim. Nie bój się go. Wstał więc, zszedł z nim do króla
###### **2Krl 1,16**
 i powiedział mu: Tak mówi Jahwe: Ponieważ posłałeś posłańców, aby się radzić Baal Zebuba, boga Ekronu, jakby nie było Boga w Izraelu, żeby zasięgnąć Jego słowa, dlatego nie zejdziesz z łoża, na które wszedłeś, albowiem na pewno umrzesz.
###### **2Krl 1,17**
 I umarł według słowa Jahwe, które wygłosił Eliasz. Ponieważ nie miał syna, królował po nim Joram, w drugim roku [panowania] Jorama, syna Jozafata, króla Judy.
###### **2Krl 1,18**
 Reszta dziejów Ochozjasza i to, co zdziałał, czyż te [sprawy] nie są opisane w Księdze Kronik Królów Izraela?
# 2Krl 1 BR
###### **2Krl 1,1**
 Po śmierci Achaba Moab zbuntował się przeciwko Izraelowi.
###### **2Krl 1,2**
 Ochozjasz zaś wypadł przez okno, pomiędzy kratami swego górnego pomieszczenia w Samarii, i doznał ciężkich obrażeń. Wysłał więc swoich ludzi z poleceniem, żeby zapytali Beelzebuba, boga Ekronu, czy wyjdzie z tej choroby.
###### **2Krl 1,3**
 Jednakże w tym samym czasie anioł Pański powiedział do Eliasza z Tiszbe: Wstań, wyjdź na spotkanie wysłannikom króla samarytańskiego i powiedz im tak: Czy już nie ma Boga w Izraelu, że idziecie pytać o radę Beelzebuba, bożka Ekronu?
###### **2Krl 1,4**
 Dlatego też Jahwe kazał powiedzieć: Nie podniesiesz się już z łoża, na którym cię złożono, na pewno umrzesz. Poszedł tedy Eliasz.
###### **2Krl 1,5**
 Tymczasem wrócili wysłannicy Ochozjasza, a on ich zapytał: Dlaczego zawróciliście z drogi?
###### **2Krl 1,6**
 A oni na to: Spotkaliśmy pewnego człowieka, który nam powiedział: Wracajcie do króla, który was wysłał, i powiedzcie mu tak: Oto, co mówi Jahwe: Czy już nie ma Boga w Izraelu, że wysyłasz swoich ludzi, by pytali o radę Beelzebuba, bożka Ekronu? Dlatego nie podniesiesz się już z łoża, na którym cię złożono. Umrzesz z całą pewnością.
###### **2Krl 1,7**
 Spytał Ochozjasz: Jak wyglądał człowiek, który wam wyszedł na spotkanie i powiedział te słowa?
###### **2Krl 1,8**
 A oni odrzekli: Miał na sobie płaszcz z sierści, o dokoła bioder skórzany pas. Rzekł na to Ochozjasz: To Eliasz z Tiszbe.
###### **2Krl 1,9**
 Natychmiast wysłał do niego dowódcę oddziału złożonego z pięćdziesięciu ludzi, a wraz z nim cały jego oddział. Dowódca ów odnalazł Eliasza, który znajdował się na szczycie góry. Powiedział do niego: Mężu Boży, król rozkazuje ci, żebyś zszedł na dół.
###### **2Krl 1,10**
 Lecz Eliasz odpowiedział dowódcy oddziału: Jeżeli ja jestem mężem Bożym, to niech ogień zstąpi z nieba i pochłonie ciebie oraz cały twój oddział liczący pięćdziesięciu ludzi. I zstąpił ogień z nieba, i pochłonął owego dowódcę i jego pięćdziesięciu ludzi.
###### **2Krl 1,11**
 Posłał tedy Ochozjasz innego dowódcę z pięćdziesięcioma ludźmi. Dowódca ten tak powiedział do Eliasza: Mężu Boży, król ci rozkazuje, żebyś co prędzej zszedł na dół.
###### **2Krl 1,12**
 Odpowiedział im na to Eliasz: Jeżeli ja jestem mężem Bożym, to niech ogień z nieba zstąpi i pochłonie ciebie oraz cały twój oddział liczący pięćdziesięciu ludzi. I zstąpił ogień Boży z nieba i pochłonął owego dowódcę i jego pięćdziesięciu ludzi.
###### **2Krl 1,13**
 I po raz trzeci wysłał Ochozjasz dowódcę z pięćdziesięcioma ludźmi. Ów trzeci dowódca, przybywszy do Eliasza, rzucił się przed nim na kolana i zaczął go błagać, mówiąc: Mężu Boży, miłosierdzia! Zechciej darować życie mnie i tym pięćdziesięciu moim sługom!
###### **2Krl 1,14**
 Oto zstąpił ogień z nieba i pochłonął pierwszych dwóch dowódców oraz ich pięćdziesięcioosobowe oddziały. Ale teraz zlituj się nad naszym życiem!
###### **2Krl 1,15**
 Anioł Jahwe powiedział do Eliasza: Zejdź z nim i nie bój się go. Wstał więc Eliasz i zszedł z nim do króla.
###### **2Krl 1,16**
 I rzekł Eliasz do króla: Oto, co mówi Jahwe: Wysłałeś swoich ludzi, by pytali o radę Beelzebuba, bożka Ekronu. Czy oznacza to, że nie ma już w Izraelu Boga, u którego moglibyście zasięgnąć rady? Dlatego też nie podniesiesz się już z łoża, na którym cię złożono. Na pewno umrzesz.
###### **2Krl 1,17**
 I umarł Ochozjasz, tak jak to zapowiedział Jahwe przez Eliasza. Ponieważ nie miał on synów, władzę po nim objął jego brat, Joram. Stało się to w drugim roku panowania Jorama, syna Jozafata, króla judzkiego.
###### **2Krl 1,18**
 Pozostałe dzieje Ochozjasza, wszystkie jego dokonania, opisane są w Księdze Kronik Królów Izraelskich.
# 2Krl 1 WUJ
###### **2Krl 1,1**
 A Moab wykroczył potem przeciw Izraelowi, jako umarł Achab.
###### **2Krl 1,2**
 I spadł Ochoziasz przez kratę z sale swej, którą miał w Samariiej i rozniemógł się: i wyprawił posły, mówiąc do nich: Idźcie, poradźcie się Beelzebuba boga Akkaron, jeśli żyć mogę z tej niemocy mojej.
###### **2Krl 1,3**
 A Anioł Pański rzekł do Eliasza Thesbytczyka, mówiąc: Wstań, a idź przeciwko posłom króla Samaryjskiego, i będziesz mówił do nich: Azaż niemasz Boga w Izraelu, że się idziecie radzić Beelzebuba boga Akkaron?
###### **2Krl 1,4**
 Przetoż tak mówi Pan, z łóżka na któreś wstąpił, nie zstąpisz, ale śmiercią umrzesz. I poszedł Eliasz,
###### **2Krl 1,5**
 I wrócili się posłowie do Ochoziasza. Który im rzekł: Czemuście się wrócili?
###### **2Krl 1,6**
 A oni mu odpowiedzieli: Zabieżał nam mąż, i rzekł do nas: Idźcie a wróćcie się do króla, który was posłał, a powiecie mu: To mówi Pan: Izali że nie było Boga w Izraelu, posyłasz radzić się Beelzebuba boga Akkaron? Przeto z łóżka, na któreś wstąpił nie zstąpisz, ale śmiercią umrzesz.
###### **2Krl 1,7**
 Który im rzekł: Co za osoba i odzienie jest tego męża, który wam zabieżał, i mówił te słowa?
###### **2Krl 1,8**
 A oni odpowiedzieli: Mąż kosmaty i pasem skórzanym na biodrach opasany. Który rzekł: Eliasz Thesbytczyk jest,
###### **2Krl 1,9**
 I posłał do niego rotmistrza pięćdziesiątnika i pięćdziesiąt, którzy byli pod nim. Który poszedł do niego: i siedzącemu na wierzchu góry, rzekł: Człowiecze Boży, król rozkazał, abyś zszedł.
###### **2Krl 1,10**
 A odpowiadając Eliasz rzekł pięćdziesiątnikowi: Jeślim jest człowiek Boży, niech zstąpi ogień z nieba, a niech cię pożrze i pięćdziesiąt twoich. Zstąpił tedy ogień z nieba, i pożarł go, i piącidziesiąt, którzy z nim byli.
###### **2Krl 1,11**
 I powtóre posłał do niego rotmistrza pięćdziesiątnika drugiego, i piącidziesiąt z nim. Który rzekł do niego: Człowiecze Boży, tak mówi król: Pospiesz się, znidź na dół.
###### **2Krl 1,12**
 Odpowiadając Eliasz rzekł: Jeślim ja jest człowiek Boży, niech zstąpi ogień z nieba, a niech cię pożrze i piącidziesiąt twoich. Zstąpił tedy ogień z nieba i pożarł go i piącidziesiąt jego.
###### **2Krl 1,13**
 Znowu posłał rotmistrza piącidziesiątnika trzeciego, i piącidziesiąt, którzy z nim byli. Który przyszedszy poklęknął na kolana przed Eliaszem, i prosił go, i rzekł: Człowiecze Boży, nie chciej gardzić duszą moją, i duszami sług twoich, którzy są ze mną.
###### **2Krl 1,14**
 Oto ogień zstąpił z nieba, i pożarł dwu rotmistrzów pięćdziesiątników pierwszych, i pięćdziesiąt, którzy z nimi byli: ale teraz proszę, abyś się zmiłował nad duszą moją,
###### **2Krl 1,15**
 I rzekł Anioł Pański do Eliasza, mówiąc: Idź z nim, nie bój się, A tak wstał, i poszedł z nim do króla,
###### **2Krl 1,16**
 I rzekł mu: To mówi Pan: Iżeś wysłał posły radzić się Beelzebuba boga Akkaron, jakoby nie było Boga w Izraelu, od którego byś się mowy mógł pytać: przeto z łóżka, na któreś wstąpił nie zstąpisz ale śmiercią umrzesz.
###### **2Krl 1,17**
 Umarł tedy według mowy Pańskiej, którą mówił Eliasz, i królował Joram brat jego miasto niego, roku wtórego Jorama syna Jozaphatowego króla Judzkiego, nie miał bowiem syna,
###### **2Krl 1,18**
 A ostatek słów Ochoziaszowych, które czynił, aza te nie są spisane w księgach mów dni królów Izraelskich?
