# Hi 7 BT5
###### **Hi 7,1**
 ***Czyż nie do bojowania podobny byt człowieka? Dni jego czyż nie są dniami najemnika?***
###### **Hi 7,2**
 ***Jak sługa wzdycha on do cienia, i jak najemnik czeka na zapłatę.***
###### **Hi 7,3**
 ***Tak moim działem miesiące nicości i wyznaczono mi noce udręki.***
###### **Hi 7,4**
 ***Położę się, mówiąc do siebie: Kiedyż zaświta i wstanę? Przedłuża się wieczór, a niepokój mnie syci do świtu.***
###### **Hi 7,5**
 ***Ciało moje okryte robactwem, strupami, skóra mi pęka i ropieje.***
###### **Hi 7,6**
 ***Dni moje lecą jak tkackie czółenko, i kończą się, bo braknie nici.***
###### **Hi 7,7**
 ***Wspomnij, że dni me jak powiew. Ponownie oko me szczęścia nie zazna.***
###### **Hi 7,8**
 ***Nikt już mnie powtórnie nie ujrzy: spojrzysz, a już mnie nie będzie.***
###### **Hi 7,9**
 ***Jak obłok znika i odchodzi, tak schodzący do Szeolu nie wraca do góry,***
###### **Hi 7,10**
 ***by zamieszkać znów w swoim domu: już nie zobaczy go jego miejsce.***
###### **Hi 7,11**
 ***Ja ust ujarzmić nie mogę, w udręce ducha chcę mówić, lamentować w goryczy mej duszy.***
###### **Hi 7,12**
 ***Czy jestem morzem lub smokiem głębiny, że straże nade mną postawiłeś?***
###### **Hi 7,13**
 ***Gdy myślę: Pocieszy mnie moje łoże, posłanie uciszy mą skargę,***
###### **Hi 7,14**
 ***to Ty mnie snami przestraszasz, przerażasz mnie widziadłami.***
###### **Hi 7,15**
 ***Moja dusza wybrałaby uduszenie, raczej śmierć niż te udręki.***
###### **Hi 7,16**
 ***Zginę. Nie będę żył wiecznie. Zostaw mnie – dni moje to tchnienie.***
###### **Hi 7,17**
 ***A kim jest człowiek, abyś go cenił i zwracał ku niemu swe serce?***
###### **Hi 7,18**
 ***Czemu go badasz co ranka, na co doświadczasz co chwilę?***
###### **Hi 7,19**
 ***Czy wzrok swój kiedyś odwrócisz? Pozwól mi choćby ślinę przełknąć.***
###### **Hi 7,20**
 ***Zgrzeszyłem. Cóż mógłbym uczynić Tobie, Stróżu człowieka? Dlaczego na cel mnie wziąłeś? Mam być dla Ciebie ciężarem?***
###### **Hi 7,21**
 ***Czemu mojego grzechu nie zgładzisz, nie zmażesz mej nieprawości? Bo teraz położę się w prochu, nie będzie mnie, choćbyś mnie szukał***».
# Hi 7 PAU
###### **Hi 7,1**
 Czy losem człowieka na ziemi nie jest służba, a jego dni nie są takie same jak dni najemnika?
###### **Hi 7,2**
 Bo jak niewolnik rozgląda się za cieniem, a najemnik oczekuje na zapłatę,
###### **Hi 7,3**
 tak moim udziałem są miesiące rozczarowań, a przeznaczeniem - noce udręk.
###### **Hi 7,4**
 Gdy się układam do snu, mówię: Kiedyż wstanę? Wieczór się przedłuża, a niepokój dręczy mnie do świtu.
###### **Hi 7,5**
 Moje ciało pokrywa proch i robactwo, moja skóra rozkłada się i ropieje.
###### **Hi 7,6**
 Dni moje biegną szybciej niż tkackie czółenko, dobiegają końca, żadnej nie niosąc nadziei.
###### **Hi 7,7**
 Pomyśl, że moje życie jest tylko tchnieniem, nie zaznam więcej szczęścia.
###### **Hi 7,8**
 Oko, które mnie widziało, więcej mnie nie ujrzy, będą mnie wypatrywać twoje oczy, ale mnie nie będzie.
###### **Hi 7,9**
 Chmura zanika i odchodzi, podobnie jest z tym, który schodzi do krainy umarłych i nie wraca.
###### **Hi 7,10**
 Nie powróci do swojego domu, nie ujrzy więcej swego miejsca.
###### **Hi 7,11**
 Ja także nie chcę zamknąć ust, w ucisku mego ducha będę mówił, będę się żalił w goryczy mojej duszy.
###### **Hi 7,12**
 Czyż jestem morzem albo morskim potworem, że postawiłeś straż przy mnie?
###### **Hi 7,13**
 Niekiedy mówię: Ukoi mnie łóżko, posłanie pocieszy mnie w smutku.
###### **Hi 7,14**
 Ty jednak dręczysz mnie snami, przerażasz przywidzeniami.
###### **Hi 7,15**
 Chciałbym zginąć uduszony, wolałbym śmierć niż tak wielkie cierpienie.
###### **Hi 7,16**
 Już zostałem odtrącony, nie mogę żyć wiecznie. Oddal się ode mnie, wszak moje dni są tylko tchnieniem.
###### **Hi 7,17**
 Kimże jest człowiek, że go tak wywyższasz: zwracasz na niego uwagę,
###### **Hi 7,18**
 nękasz go od ranka i badasz co chwilę?
###### **Hi 7,19**
 Czy już nie przestaniesz mnie śledzić? Czy nie dasz mi ulgi, bym choć ślinę przełknął?
###### **Hi 7,20**
 Choćbym zgrzeszył, cóż tobie zrobię, stróżu człowieka? Dlaczego każesz mi przyjmować swe ciosy i być ciężarem dla samego siebie?
###### **Hi 7,21**
 Czemu nie przebaczysz mi przewinienia, nie puścisz w niepamięć mojej winy? Położę się więc teraz w grobie, będziesz mnie szukał, lecz mnie już nie będzie”.
# Hi 7 BP
###### **Hi 7,1**
 Życie człowieka na ziemi - to żołnierska służba, a dni jego bytowania - to dni najemnika.
###### **Hi 7,2**
 Jak niewolnik wzdycha do cienia, jak najemnik oczekuje swej zapłaty,
###### **Hi 7,3**
 tak udziałem moim są miesiące męki, a przeznaczeniem noce [pełne] cierpienia.
###### **Hi 7,4**
 Kładąc się mówię: "Kiedyż dzień nastanie?", a ledwie wstanę, myślę: "Czemu wieczór się opóźnia?" I tak udręka burzy się we mnie aż do zmroku.
###### **Hi 7,5**
 Robactwo i wrzody pokrywają moje ciało, skóra moja pęka i ropieje.
###### **Hi 7,6**
 Dni moje biegną szybciej niż czółenko [tkackie] i kończą się bez nadziei.
###### **Hi 7,7**
 Wspomnij, że życie moje tchnieniem tylko, a oko moje nie wróci już, aby widzieć szczęście,
###### **Hi 7,8**
 oko, które mnie widziało, już mnie nie ujrzy, oczy twoje będą mnie szukać, a mnie już nie będzie.
###### **Hi 7,9**
 Podobnie jak chmura, która przechodzi i znika, kto zstępuje do Szeolu, więcej już nie wraca.
###### **Hi 7,10**
 Nie powróci do swego domu i nie ujrzy już miejsca swojego.
###### **Hi 7,11**
 Dlatego nie zamknę ust moich, będę mówił w bólu mego ducha i w goryczy mojej duszy lamentował będę.
###### **Hi 7,12**
 Czy ja morzem jestem lub potworem morskim, byś mnie wałem otoczył dokoła?
###### **Hi 7,13**
 Kiedy powiem sobie: "Pociechą jest mi łóżko moje, odpoczynek ulży w mym cierpieniu",
###### **Hi 7,14**
 Ty mnie straszysz snami i przerażasz widzeniami.
###### **Hi 7,15**
 Dusza moja wolałaby śmierć przez uduszenie, raczej śmierć niż takie cierpienie.
###### **Hi 7,16**
 Jestem odtrącony, nie chcę żyć wiecznie, odsuń się ode mnie, dni moje są tylko tchnieniem.
###### **Hi 7,17**
 Czymże jest człowiek, żeś go tak wywyższył, i dlaczego to zwracasz na niego uwagę?
###### **Hi 7,18**
 Co dzień rano go nawiedzasz i każdej chwili go doświadczasz.
###### **Hi 7,19**
 Kiedyż wreszcie przestaniesz mnie pilnować, kiedyż mnie zwolnisz, bym mógł przełknąć ślinę?
###### **Hi 7,20**
 Jeślim zgrzeszył, cóż mam teraz robić, stróżu człowieka, czemuś mnie wziął za cel [swych ataków] i czemu mam być dla Ciebie ciężarem?
###### **Hi 7,21**
 Czemu nie wybaczysz mi mego grzechu i nie puścisz w niepamięć mego przewinienia? Wkrótce będę leżał w prochu i będziesz mnie szukał, lecz mnie już nie będzie.
# Hi 7 BR
###### **Hi 7,1**
 Bojowaniem jest życie człowieka na ziemi, podobne do dni zwykłego najemnika.
###### **Hi 7,2**
 Żyje on jak niewolnik szukający cienia, jak najemny robotnik czekający zapłaty.
###### **Hi 7,3**
 Moim dziedzictwem - miesiące pełne złudzeń i noce jeszcze bogatsze w udręki.
###### **Hi 7,4**
 Kładąc się pytam: Kiedy wreszcie wstanę? Gdy wstaję, wzdycham: Kiedy przyjdzie wieczór? I targa mną boleść do samego zmroku.
###### **Hi 7,5**
 W robactwie i strupach całe moje ciało, moja skóra rozdziera się i pęka.
###### **Hi 7,6**
 Dni moje biegną szybciej niż tkackie czółenko i znikają rychło w beznadziejnej dali.
###### **Hi 7,7**
 Nie zapominaj, że me życie jak podmuch wiatru, a moje oko nigdy już nie ujrzy szczęścia.
###### **Hi 7,8**
 Żadne oko nigdy mnie już nie zobaczy, Twój wzrok będzie mnie szukać, lecz mnie już nie będzie.
###### **Hi 7,9**
 Jak obłok, co przechodzi i znika, tak nie wraca też nikt, kto odchodzi w zaświaty.
###### **Hi 7,10**
 Ten już nigdy nie wróci do swego domostwa i nigdy nie zobaczy swojej ojczyzny.
###### **Hi 7,11**
 Nie potrafię już dłużej zamykać ust moich, muszę wykrzyczeć moje utrapienia, muszę się poskarżyć bólem mojej duszy.
###### **Hi 7,12**
 Czy jestem jak otchłań morska albo potwór z głębin, żeś takie straże przeciw mnie wystawił?
###### **Hi 7,13**
 Pocieszałem się, że wypocznę na własnym łóżku, a moje posłanie ulży mi w cierpieniach.
###### **Hi 7,14**
 Ale Ty mnie snami zadręczasz, przerażasz mnie widmami.
###### **Hi 7,15**
 Niech już zatem zostanę uduszony, niech śmierć już zakończy moje udręczenie.
###### **Hi 7,16**
 Już dłużej tak nie mogę, nie chcę żyć na wieki. Zostaw mnie, bo dni moje jako powiew wiatru.
###### **Hi 7,17**
 Bo czymże jest człowiek, byś miał wzgląd na niego i zwracał ku niemu swoje oczy?
###### **Hi 7,18**
 Czy musisz wpatrywać się w niego co rano i nawet na chwilę nie spuszczać go z oczu?
###### **Hi 7,19**
 Czy nigdy nie odwrócisz ode mnie Twego wzroku i nawet śliny przełknąć nie pozwolisz?
###### **Hi 7,20**
 W czym Ci się sprzeniewierzyłem? Co Ci złego zrobiłem, o Stróżu człowieka? Dlaczego wymierzasz we mnie wszystkie Twoje ciosy? Czy jestem dla Ciebie aż takim ciężarem?
###### **Hi 7,21**
 Czemu nie chcesz zgładzić moich grzechów? Dlaczego mi nie chcesz przebaczyć? I tak niebawem położę się w ziemi, będziesz mnie szukał, ale już nie znajdziesz.
# Hi 7 WUJ
###### **Hi 7,1**
 Bojowanie jest żywot człowieczy na ziemi: a jako dni najemnicze dni jego.
###### **Hi 7,2**
 Jako niewolnik pragnie cienia, i jako najemnik czeka końca prace swojej:
###### **Hi 7,3**
 Takem i ja miał miesiące próżne, i nocy pracowite obliczałem sobie.
###### **Hi 7,4**
 Jeśli zasnę, rzekę: kiedyż wstanę? I zasię będę czekał wieczora, i będę napełnion boleści aż do mroku.
###### **Hi 7,5**
 Ciało moje obleczone jest zgniłością i plugastwem prochu, skóra moja zeschła, i pomarszczyła się.
###### **Hi 7,6**
 Dni moje przeminęły prędzej niźli tkacz płótno obrzyna, i wytrawione są bez żadnej nadzieje.
###### **Hi 7,7**
 Wspomni, iż żywot mój wiatrem jest: i oko moje nie wróci się, aby widziało dobra.
###### **Hi 7,8**
 Ani mię ogląda wzrok człowieczy: oczy twoje na mię, a nie będzie mię.
###### **Hi 7,9**
 Jako niszczeje obłok i przemija: tak który zstąpi do piekła, nie wynidzie:
###### **Hi 7,10**
 Ani się wróci więcej do domu swego, ani go dalej pozna miejsce jego.
###### **Hi 7,11**
 Przetoż i ja nie sfolguję ustam moim, mówić będę w udręczeniu ducha mego: będę się rozmawiał z gorzkością dusze mojej.
###### **Hi 7,12**
 I zażem ja jest morze, abo wieloryb, żeś mię obtoczył ciemnicą?
###### **Hi 7,13**
 Jeśli rzekę: Pocieszy mię łóżko moje, i ulży mi się, gdy będę z sobą mówił na pościeli mojej:
###### **Hi 7,14**
 Będziesz mię straszył przez sny, i przez widzenia strachem strzęsiesz.
###### **Hi 7,15**
 A przetoż dusza moja obrała obieszenie a śmierć kości moje.
###### **Hi 7,16**
 Zwątpiłem, już więcej żyć nie będę: Przepuść mi, boć nic nie są dni moje.
###### **Hi 7,17**
 Cóż jest człowiek, iż go wielmożysz? abo co przykładasz ku niemu serce twoje?
###### **Hi 7,18**
 Nawiedzasz go rano i natychmiast doświadczasz go:
###### **Hi 7,19**
 Dokądże mi nie przepuścisz, ani dopuścisz mi, abym przełknął ślinę moję?
###### **Hi 7,20**
 Zgrzeszyłem, cości uczynię o stróżu ludzi: czemuś mię postawił przeciwnym tobie, i stałem się ciężek sam sobie?
###### **Hi 7,21**
 Przecz nie zgładzisz grzechu mego, i czemu nie odejmujesz nieprawości mojej? oto teraz w prochu zasnę: a jeśli mię rano poszukasz, nie będzie mię.
