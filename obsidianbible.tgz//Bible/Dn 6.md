# Dn 6 BT5
###### **Dn 6,1**
 A Dariusz Med, liczący sześćdziesiąt dwa lata, otrzymał królestwo.
###### **Dn 6,2**
 Spodobało się Dariuszowi ustanowić nad państwem stu dwudziestu satrapów, którzy mieli przebywać w całym królestwie,
###### **Dn 6,3**
 nad nimi zaś trzech zwierzchników – jednym z nich był Daniel – którym satrapowie składali sprawozdania, by nie obciążać króla.
###### **Dn 6,4**
 Daniel zaś przewyższał zwierzchników i satrapów, miał bowiem niezwykłego ducha. Król zamierzał ustanowić go nad całym królestwem.
###### **Dn 6,5**
 Wobec tego zwierzchnicy i satrapowie usiłowali znaleźć podstawę do oskarżenia Daniela w sprawach królestwa. Nie mogli jednak znaleźć podstawy ani żadnego wykroczenia, bo był on wierny i nie można było u niego dostrzec żadnego zaniedbania ani błędu.
###### **Dn 6,6**
 Ludzie ci powiedzieli: «***Nie znajdziemy żadnego zarzutu przeciw Danielowi, jeśli nie wysuniemy przeciw niemu oskarżenia związanego z kultem jego Boga***».
###### **Dn 6,7**
 Zwierzchnicy więc i satrapowie pośpieszyli gromadnie do króla i tak do niego powiedzieli: «***Królu Dariuszu, żyj wiecznie!***
###### **Dn 6,8**
 ***Wszyscy zwierzchnicy państwowi, namiestnicy i satrapowie, doradcy i rządcy postanowili, żeby król wydał zarządzenie i ustanowił zakaz: Ktokolwiek w ciągu trzydziestu dni zanosiłby prośbę do jakiegoś boga lub człowieka poza tobą, królu, zostanie wrzucony do jaskini lwów.***
###### **Dn 6,9**
 ***Teraz więc, królu, wydaj zakaz i każ spisać dekret, który byłby nieodwołalny według nienaruszalnego prawa Medów i Persów***».
###### **Dn 6,10**
 Król Dariusz kazał więc spisać dokument i zakaz.
###### **Dn 6,11**
 Gdy Daniel dowiedział się, że spisano dokument, poszedł do swego domu. Miał on w swoim górnym pokoju okna skierowane ku Jerozolimie. Trzy razy dziennie padał na kolana, modląc się i wielbiąc Boga, tak samo jak to czynił przedtem.
###### **Dn 6,12**
 Mężowie ci podbiegli gromadnie i znaleźli Daniela modlącego się i wzywającego Boga.
###### **Dn 6,13**
 Poszli więc i powiedzieli do króla < w sprawie zakazu królewskiego >: «***Czy nie kazałeś, królu, ogłosić dekretu, że ktokolwiek prosiłby w ciągu trzydziestu dni o coś jakiegokolwiek boga lub człowieka poza tobą, ma być wrzucony do jaskini lwów?***» W odpowiedzi król rzekł: «***Sprawę rozstrzygnięto według nienaruszalnego prawa Medów i Persów***».
###### **Dn 6,14**
 Na to odpowiedzieli, zwracając się do króla: «***Daniel, ów mąż spośród uprowadzonych z Judy, nie liczy się z tobą, królu, ani z zakazem wydanym przez ciebie. Trzy razy dziennie odmawia swoje modlitwy***».
###### **Dn 6,15**
 Gdy król usłyszał te słowa, ogarnął go smutek; postanowił uratować Daniela i aż do zachodu słońca usiłował znaleźć sposób, by go ocalić.
###### **Dn 6,16**
 Lecz ludzie ci pośpieszyli gromadnie do króla, mówiąc: «***Wiedz, królu, że zgodnie z prawem Medów i Persów żaden zakaz ani dekret wydany przez króla nie może być odwołany***».
###### **Dn 6,17**
 Wtedy król wydał rozkaz, by sprowadzono Daniela i wrzucono do jaskini lwów. Król zwrócił się do Daniela i rzekł: «***Twój Bóg, któremu tak wytrwale służysz, uratuje cię***».
###### **Dn 6,18**
 Przyniesiono kamień i umieszczono w otworze jaskini lwów. Król opieczętował go swoją pieczęcią i pieczęcią swych możnowładców, aby nic nie uległo zmianie w sprawie Daniela.
###### **Dn 6,19**
 Następnie król odszedł do swego pałacu i pościł przez całą noc, nie kazał wprowadzać do siebie nałożnic, a sen uleciał od niego.
###### **Dn 6,20**
 Król wstał o świcie i udał się śpiesznie do jaskini lwów.
###### **Dn 6,21**
 Gdy był blisko jaskini, zawołał do Daniela głosem pełnym bólu: «***Danielu, sługo Boga żywego, czy Bóg, któremu służysz tak wytrwale, mógł cię wybawić od lwów?***»
###### **Dn 6,22**
 Wtedy Daniel odpowiedział królowi: «***Królu, żyj wiecznie!***
###### **Dn 6,23**
 ***Mój Bóg posłał swego anioła i on zamknął paszcze lwom; nie wyrządziły mi one krzywdy, ponieważ On uznał mnie za niewinnego; a także wobec ciebie nie uczyniłem nic złego***».
###### **Dn 6,24**
 Uradował się z tego król i rozkazał wydobyć Daniela z jaskini lwów; nie znaleziono na nim żadnej rany, bo zaufał swemu Bogu.
###### **Dn 6,25**
 Na rozkaz króla przyprowadzono mężów, którzy oskarżyli Daniela, i wrzucono do jaskini lwów ich samych, ich dzieci i żony. Nim jeszcze spadli na dno jaskini, pochwyciły ich lwy i zmiażdżyły ich kości.
###### **Dn 6,26**
 Król Dariusz napisał do wszystkich narodów, ludów i języków, jakie są na całej ziemi: «***Pełni pokoju wam [życzę]!***
###### **Dn 6,27**
 ***Wydaję niniejszy dekret, by na całym obszarze mojego królestwa odczuwano lęk i drżenie przed Bogiem Daniela. Bo On jest Bogiem żywymi trwa na wieki.***
###### **Dn 6,28**
 ***On ratuje i uwalnia, dokonuje znaków i cudów na niebie i na ziemi. On uratował Daniela z mocy lwów***».
###### **Dn 6,29**
 Ów Daniel zaś zażywał pomyślności za panowania Dariusza i za panowania Persa Cyrusa.
# Dn 6 PAU
###### **Dn 6,1**
 Królestwo objął Dariusz Med, który miał wtedy sześćdziesiąt dwa lata.
###### **Dn 6,2**
 Postanowił on ustanowić nad swoim królestwem stu dwudziestu satrapów i umieścić ich w całym królestwie.
###### **Dn 6,3**
 Nad nimi ustanowił trzech zwierzchników, a jednym z nich był Daniel. Im to satrapowie mieli zdawać sprawę. Król więc nie musiał już słuchać sprawozdań satrapów.
###### **Dn 6,4**
 Daniel zaś wyróżniał się wśród tych zwierzchników i satrapów, gdyż miał w sobie nadzwyczajnego ducha. Dlatego król zamierzał postawić go nad całym królestwem.
###### **Dn 6,5**
 Wyżsi urzędnicy i satrapowie szukali więc pretekstu, aby oskarżyć Daniela o jakieś zaniedbanie w sprawach królestwa. Jednakże nic przeciwko niemu nie mogli znaleźć, bo był sprawiedliwy. Nie znaleźli żadnego zaniedbania ani marnotrawstwa, których by się dopuścił.
###### **Dn 6,6**
 Wtedy mówili między sobą: „Nie znajdziemy przeciw Danielowi niczego! Poszukajmy więc w tym, co wiąże się z kultem jego Boga”.
###### **Dn 6,7**
 Następnie owi zwierzchnicy i satrapowie udali się spiesznie do króla i powiedzieli: „O, Dariuszu, królu, obyś żył wiecznie!
###### **Dn 6,8**
 My wszyscy, zwierzchnicy królestwa, prefekci i satrapowie, doradcy i gubernatorzy, jesteśmy zdania, że powinieneś wydać zarządzenie i ogłosić dekret, iż każdy, kto w przeciągu trzydziestu dni będzie się modlił do jakiegokolwiek innego boga albo człowieka poza tobą, królu, zostanie wrzucony do jaskini lwów.
###### **Dn 6,9**
 Teraz więc, królu, ustanów takie prawo, którego nikt nie może naruszyć, podobnie jak żadnego innego prawa Medów i Persów, i każ je zapisać w dokumencie”.
###### **Dn 6,10**
 Król Dariusz kazał więc sporządzić dokument i go ogłosić.
###### **Dn 6,11**
 Kiedy Daniel dowiedział się, że został sporządzony taki dokument, poszedł do swojego domu, którego okna wychodziły w kierunku Jerozolimy. Tam trzy razy dziennie na kolanach modlił się i wielbił swojego Boga, jak to czynił dotąd.
###### **Dn 6,12**
 Kiedy ci ludzie niespodziewanie tam weszli, zastali modlącego się Daniela, który wzywał swojego Boga.
###### **Dn 6,13**
 Udali się więc do króla w sprawie królewskiego nakazu: „Królu! Czy nie ogłosiłeś dekretu, że każdy, kto w przeciągu trzydziestu dni będzie się modlił do jakiegokolwiek innego boga albo człowieka poza tobą, królu, zostanie wrzucony do jaskini lwów?”. Król powiedział: „Rzecz jest oczywista, zgodnie z niezmiennym prawem Medów i Persów!”.
###### **Dn 6,14**
 Wtedy oni odpowiedzieli królowi: „Daniel, jeden z wygnanych z Judy, nie liczy się z tobą, królu, ani z twoim dekretem, który wydałeś, i trzy razy dziennie odprawia swoje modlitwy”.
###### **Dn 6,15**
 Gdy król usłyszał te słowa, bardzo się zasmucił i myślał o tym, jak uratować Daniela. Aż do zachodu słońca szukał sposobu, by go uratować.
###### **Dn 6,16**
 Jednak ci ludzie przyszli do króla i powiedzieli: „Wiedz, królu, że zgodnie z prawem Medów i Persów żaden zakaz ani wyrok wydany przez króla nie może być naruszony”.
###### **Dn 6,17**
 Wtedy król kazał przyprowadzić Daniela i wrzucić go do jaskini lwów. Król powiedział do Daniela: „Niech cię wyratuje twój Bóg, któremu już tak długo służysz!”.
###### **Dn 6,18**
 Przytoczono kamień i zastawiono nim otwór jaskini. Król zapieczętował go swym własnym sygnetem i sygnetem swoich dostojników, tak iż w sprawie Daniela niczego nie można było już zmienić.
###### **Dn 6,19**
 Odszedł król do swojego pałacu i pościł przez całą noc. Bardzo się smucił i nie mógł spać.
###### **Dn 6,20**
 O świcie wstał i natychmiast poszedł do jaskini lwów.
###### **Dn 6,21**
 Gdy zbliżył się do jaskini, z niepokojem w głosie zawołał do Daniela: „Danielu, sługo Boga Żyjącego, czy twój Bóg, któremu już tak długo służysz, zdołał cię uratować przed lwami?”.
###### **Dn 6,22**
 Wtedy Daniel odpowiedział królowi: „O królu, obyś żył wiecznie!
###### **Dn 6,23**
 Mój Bóg posłał swojego anioła i zamknął paszcze lwom, aby nie wyrządziły mi krzywdy. Skoro przed Nim okazałem się sprawiedliwy, również wobec ciebie, królu, nie jestem winny.
###### **Dn 6,24**
 Wtedy król bardzo się ucieszył i kazał wyciągnąć Daniela z jaskini. Kiedy wyciągnięto Daniela z jaskini, nie było na jego ciele żadnej rany, gdyż zaufał swojemu Bogu.
###### **Dn 6,25**
 Król kazał przyprowadzić tych ludzi, którzy swymi oskarżeniami chcieli zaszkodzić Danielowi. Zostali oni wrzuceni do jaskini lwów wraz ze swoimi synami i żonami. Zanim jeszcze wpadli na dno jaskini, lwy rzuciły się na nich i zmiażdżyły im kości.
###### **Dn 6,26**
 Potem król Dariusz napisał do wszystkich ludów, narodów i języków zamieszkujących całą ziemię: „Pokój wasz niech będzie niezmącony.
###### **Dn 6,27**
 Oto zarządzenie, które wydaję: Niech w całym moim królestwie, w którym panuję, wszyscy odczuwają lęk i drżenie przed Bogiem Daniela. Bo On jest Bogiem żywym i wiecznym. Jego królestwo jest niezniszczalne, a Jego panowanie - nieskończone.
###### **Dn 6,28**
 On ratuje i ocala, czyni znaki i cuda na niebie i na ziemi. On uratował Daniela z paszczy lwów”.
###### **Dn 6,29**
 Danielowi dobrze się powodziło w królestwie Dariusza i w królestwie Cyrusa, Persa.
# Dn 6 BP
###### **Dn 6,1**
 a Dariusz Med objął królestwo mając lat sześćdziesiąt dwa.
###### **Dn 6,2**
 Dariusz uznał za rzecz dobrą ustanowić nad królestwem stu dwudziestu satrapów, którzy byli [rozmieszczeni] po całym królestwie,
###### **Dn 6,3**
 nad nimi zaś trzech ministrów - jednym z nich był Daniel - żeby owi satrapowie zdawali im sprawozdanie, aby król nie był przeciążony.
###### **Dn 6,4**
 Wtedy ów Daniel wysunął się na czoło ministrów i satrapów, ponieważ był w nim duch nadzwyczajny, i król zamierzał ustanowić go nad całym królestwem.
###### **Dn 6,5**
 Wówczas ministrowie i satrapowie starali się znaleźć przeciw Danieiowi powód [oskarżenia] dotyczący [spraw] królestwa, ale nie potrafili znaleźć żadnego zarzutu ani uchybienia, ponieważ był on wierny i żadnego błędu ani uchybienia nie udało się znaleźć przeciw niemu.
###### **Dn 6,6**
 Wtedy owi mężowie rzekli: Nie znaleźliśmy przeciw temu Danielowi żadnego zarzutu, chyba że znajdziemy go przeciw niemu w prawie jego Boga.
###### **Dn 6,7**
 Ministrowie więc owi i satrapowie udali się spiesznie do króla i tak przemówili do niego: Dariuszu, królu, żyj na wieki!
###### **Dn 6,8**
 Wszyscy ministrowie królestwa, naczelnicy, satrapowie, radcy i namiestnicy uradzili, aby król wydał dekret i dał surowy zakaz, że ktokolwiek w przeciągu trzydziestu dni będzie się modlił do któregokolwiek boga lub człowieka, nie zaś do ciebie, królu, zostanie wrzucony do lwiej jamy.
###### **Dn 6,9**
 Teraz więc, królu, wydaj zakaz i daj [go] na piśmie, aby nie mógł być odwołany stosownie do prawa Medów i Persów, które jest niezmienne.
###### **Dn 6,10**
 Zgodnie z tym król Dariusz wydał zakaz na piśmie.
###### **Dn 6,11**
 Gdy Daniel się dowiedział, że pismo zostało podpisane, poszedł do swojego domu. Okna jego górnego pokoju otwierały się w stronę Jerozolimy i trzy razy dziennie na kolanach błogosławił on i chwalił swego Boga, tak jak to czynił przedtem.
###### **Dn 6,12**
 Mężowie owi pobiegli spiesznie i znaleźli Daniela modlącego się i błagającego swego Boga.
###### **Dn 6,13**
 Przyszli więc i wobec króla wypowiedzieli się w sprawie dekretu królewskiego: Czyż nie wydałeś na piśmie zakazu, że każdy człowiek, który w przeciągu trzydziestu dni modliłby się do któregokolwiek boga lub człowieka, nie zaś do ciebie, królu, będzie wrzucony do lwiej jamy? Król odpowiadając rzekł: Na pewno! Sprawa [jest załatwiona] zgodnie z prawem Medów i Persów, które jest niezmienne!
###### **Dn 6,14**
 Wówczas oznajmiając rzekli do króla: Oto Daniel, z uprowadzonych z Judei, nic sobie nie robi, królu, z twojego dekretu oraz z zakazu, który wydałeś na piśmie, ale trzy razy dziennie odmawia swoją modlitwę.
###### **Dn 6,15**
 Gdy król usłyszał [te] słowa, bardzo się zmartwił i postanowił ratować Daniela. Aż do zachodu słońca usiłował go ocalić.
###### **Dn 6,16**
 Mężowie zaś owi udali się spiesznie do króla i powiedzieli: Wiedz, królu, że prawo Medów i Persów [jest takie], iż wszelki zakaz lub dekret, który król wydaje na piśmie, nie może być zmieniony.
###### **Dn 6,17**
 Wówczas król kazał przyprowadzić Daniela i wrzucić do lwiej jamy. Król przemówił i rzekł do Daniela: Twój Bóg, którego nieustannie czcisz, niech On cię ocali.
###### **Dn 6,18**
 przyniesiono jeden kamień i położono na otworze jamy. Król opieczętował go swoim pierścieniem i pierścieniami swoich książąt, aby nie zmieniła się sprawa Daniela.
###### **Dn 6,19**
 Potem król poszedł do swego pałacu, noc spędził poszcząc, nie zezwolił na rozrywkę w swojej obecności i sen odszedł od niego.
###### **Dn 6,20**
 Gdy nastał świt, król wstał i o brzasku spiesznie udał się do lwiej jamy.
###### **Dn 6,21**
 Skoro zbliżył się do jamy, głosem [pełnym] niepokoju zawołał na Daniela. Król odezwał się i przemówił do Daniela: Danielu, sługo Boga żyjącego, czy twój Bóg, którego nieustannie czcisz, potrafił cię ocalić od lwów?
###### **Dn 6,22**
 Daniel rozmawiał z królem: Królu, żyj na wieki!
###### **Dn 6,23**
 Mój Bóg przysłał swego anioła, zamknął paszczę lwom i nie zrobiły mi nic złego, albowiem przed Nim jestem niewinny. Ale również wobec ciebie, królu, nic złego nie uczyniłem.
###### **Dn 6,24**
 Król bardzo się uradował i polecił wyciągnąć Daniela z jamy. Daniel został wyciągnięty z jamy. Nie znaleziono na nim żadnej obrazy [ciała], albowiem ufność położył w swoim Bogu.
###### **Dn 6,25**
 Król rozkazał przyprowadzić owych mężów, którzy Daniela oskarżyli, i wrzucić do lwiej jamy ich, ich synów oraz ich żony. Jeszcze nie osiągnęli dna jamy, a już lwy rzuciły się na nich i zmiażdżyły ich kości.
###### **Dn 6,26**
 Wtedy król Dariusz napisał do wszystkich ludów, narodów i języków, którzy mieszkali na całej ziemi: Niech pokój wasz będzie wielki.
###### **Dn 6,27**
 Wydaję dekret, aby w całym podległym mej władzy królestwie drżano i bano się Boga Daniela. Albowiem On jest Bogiem żyjącym i trwa na wieki. Jego królestwo nie ulegnie zniszczeniu, Jego panowanie będzie trwać do końca.
###### **Dn 6,28**
 On jest tym, który zbawia i ocala, czyni znaki i cuda na niebie i na ziemi. On uwolnił Daniela z mocy lwów.
###### **Dn 6,29**
 Temu to Danielowi dobrze się powodziło za panowania Dariusza i za panowania Cyrusa perskiego.
# Dn 6 BR
###### **Dn 6,1**
 Władzę po nim objął Dariusz, Med - mający wtedy - sześćdziesiąt dwa lata.
###### **Dn 6,2**
 Spodobało się Dariuszowi ustanowić w swoim królestwie stu dwudziestu satrapów, po jednym na każdą część królestwa.
###### **Dn 6,3**
 Pozostawali oni pod nadzorem trzech zwierzchników, z których jednym był Daniel. Satrapowie składali sprawozdania zwierzchnikom. W ten sposób król nie był przeciążony.
###### **Dn 6,4**
 Daniel, dzięki bystrości swego umysłu, przedkładał tak dokładnie sprawozdania dotyczące zwierzchników i satrapów, że król zamierzał postawić go na czele całego swojego królestwa.
###### **Dn 6,5**
 Wtedy zwierzchnicy oraz satrapowie zaczęli szukać jakiegoś powodu, aby zaszkodzić Danielowi. Nie mogli jednak znaleźć żadnej takiej sprawy ani jakiegoś niedopatrzenia, bo Daniel był pod każdym względem bardzo uczciwy. Nie zdołano mu zarzucić żadnego zaniedbania ani wykroczenia w czymkolwiek.
###### **Dn 6,6**
 Powiedzieli więc sobie owi ludzie: Ponieważ nie możemy znaleźć żadnego innego powodu, żeby wnieść oskarżenie przeciwko Danielowi, zajmijmy się sprawą kultu jego Boga.
###### **Dn 6,7**
 Przybyli tedy owi zwierzchnicy i satrapowie do króla i tak mu powiedzieli: królu Dariuszu, żyj wiecznie!
###### **Dn 6,8**
 Zwierzchnicy całego królestwa, namiestnicy i satrapowie, wysocy urzędnicy i zarządcy, wszyscy my jesteśmy zdania, że król powinien ogłosić dekret, w którym znajdowałby się taki zakaz: Ktokolwiek w ciągu najbliższych trzydziestu dni będzie się modlił do jakiegoś boga lub człowieka - wyjąwszy ciebie, o królu - zostanie wrzucony do jaskini, w której znajdują się lwy.
###### **Dn 6,9**
 Spraw, królu, swoim podpisem, żeby ten zakaz stał się prawem, którego nikt nie byłby w stanie odwołać zgodnie z nienaruszalnym prawem Medów i Persów.
###### **Dn 6,10**
 I podpisał król ten zakaz.
###### **Dn 6,11**
 Daniel, dowiedziawszy się o podpisaniu dekretu, poszedł do swojej górnej komnaty, której okna skierowane były ku Jerozolimie. Trzy razy dzienne klękał tam Daniel, modląc się i uwielbiając Boga. Tak zresztą i przedtem zawsze czynił.
###### **Dn 6,12**
 Otóż, gdy owi ludzie przybyli tam w wielkiej liczbie, również spotkali Daniela, jak modlił się i błagał Boga.
###### **Dn 6,13**
 Udali się tedy niezwłocznie do króla i tam mu powiedzieli: Czyż nie wydałeś dekretu, który mówi, że ktokolwiek w ciągu najbliższych trzydziestu dni będzie się modlił do jakiegoś boga lub człowieka - wyjąwszy ciebie, o królu - zostanie wrzucony do jaskini lwów? A król rzekł: Sprawa ta została załatwiona wedle nieodwołalnego prawa Medów i Persów.
###### **Dn 6,14**
 Wówczas odpowiedzieli królowi: Daniel, jeden z tych, co zostali uprowadzeni z ziemi judzkiej, wcale nie szanuje, o królu, ani ciebie, ani zakazu przez ciebie podpisanego: trzy razy każdego dnia odprawia on swoje modły.
###### **Dn 6,15**
 Usłyszawszy te słowa, król zasmucił się bardzo i postanowi ratować Daniela. Aż do zachodu słońca przemyśliwał, jak znaleźć dla niego jakieś wyjście.
###### **Dn 6,16**
 Lecz ci sami ludzie nastawali wciąż na króla mówiąc: Pamiętaj, królu, że według prawa Medów i Persów żaden zakaz lub dekret wydany przez króla, nie może być odwołany.
###### **Dn 6,17**
 Kazał tedy król sprowadzić Daniela i wrzucić go do jaskini lwów. I powiedział król do Daniela: Bóg, któremu służyłeś z taką wytrwałością, niech cię teraz wybawi.
###### **Dn 6,18**
 Potem wielkim kamieniem zastawiono wejście do jamy. Król opieczętował kamień swoją pieczęcią, to samo uczynili jego możnowładcy, tak że nikt już nie mógł nic zmienić w sprawie Daniela.
###### **Dn 6,19**
 Potem wrócił król do swego pałacu, przez całą noc nie jadł nic i nie pił, i nie pozwalał wprowadzać do siebie żadnej konkubiny. Nie mógł też spać,
###### **Dn 6,20**
 a o świtaniu dnia następnego wstał i udał się z pośpiechem do jaskini lwów.
###### **Dn 6,21**
 Przybywszy do samej jamy, głosem pełnym niepokoju, zawołał do Daniela: Danielu, sługo Boga żywego, czy ten Bóg, któremu tak wytrwale służysz, zdołał cię uratować przed lwami?
###### **Dn 6,22**
 A Daniel odpowiedział królowi: Królu, obyś żył wiecznie!
###### **Dn 6,23**
 Mój Bóg przysłał tu swojego anioła, który zamknął paszcze lwom, tak że nie mogły mi uczynić nic złego, bo okazałem się niewinnym w Jego oczach. I wobec ciebie również, o królu, jestem niewinny.
###### **Dn 6,24**
 Uradował się tym król bardzo i kazał wyprowadzić Daniela z lwiej jamy. Wyprowadzono więc Daniela z jamy, w której nie stało mu się nic złego, ponieważ zaufał swojemu Bogu.
###### **Dn 6,25**
 Potem kazał król sprowadzić ludzi, którzy oczernili Daniela i wtrącił do lwiej jaskini ich samych, ich żony i dzieci. I nim jeszcze wpadli do jaskini, lwy rzuciły się na nich i zmiażdżyły im kości.
###### **Dn 6,26**
 I napisał król Dariusz do wszystkich ludów, narodów i języków na całej ziemi: Pokój wam w obfitości!
###### **Dn 6,27**
 Oto rozkaz, który wam wydaję: W całym królestwie, które pozostaje pod moim panowaniem, niech wszyscy odczuwają lęk i drżenie przed Bogiem Daniela. Jest to bowiem Bóg, który żyje i trwa na wieki. Jego królestwa nikt nigdy nie pomniejszy, a Jego panowanie nie będzie mieć końca.
###### **Dn 6,28**
 On ocala i uwalnia, czyni znaki i cuda tak w niebie, jak i na ziemi. To On ocalił Daniela, który był między lwami.
###### **Dn 6,29**
 Od tego czasu wiodło się Danielowi dobrze pod rządami zarówno Dariusza, jak i Cyrusa Persa.
# Dn 6 WUJ
###### **Dn 6,1**
 Podobało się Daryuszowi, i postanowił nad królestwem sto i dwadzieścia panów, aby byli we wszystkiem królestwie jego.
###### **Dn 6,2**
 A nad nimi troje książąt, z których był jednym Daniel: aby im panowie czynili liczbę, a król nie miał trudności.
###### **Dn 6,3**
 A tak Daniel przewyższał wszystkie książęta i pany: bo duch Boży duższy był w nim.
###### **Dn 6,4**
 A król myślił go postanowić nad wszystkiem królestwem: dla czego książęta i panowie szukali przyczyny, aby naleźli na Daniela z strony króla, a żadnej przyczyny ani podejrzenia naleźć nie mogli, ponieważ był wierny, a żadna wina, ani podejrzenie nie najdowało się w nim.
###### **Dn 6,5**
 Rzekli tedy mężowie oni: Nie najdziemy na Daniela tego żadnej przyczyny, chyba snać w zakonie Boga jego.
###### **Dn 6,6**
 Tedy książęta i panowie podchwycili króla, i tak mu rzekli: Daryuszu, królu, żyj na wieki:
###### **Dn 6,7**
 Uradziły wszystkie książęta królestwa twego, urzędnicy i panowie, rada i sędziowie, aby wyszedł dekret i wyrok królewski: Aby każdy, ktoby prosił jakiej prośby od któregożkolwiek Boga abo człowieka, aż do trzydziestu dni, jedno ciebie królu, był wrzucon do dołu lwiego.
###### **Dn 6,8**
 A tak teraz królu potwierdź wyrok, a napisz dekret: aby się nie odmieniło co jest postanowiono od Medów i Persów, ani się godziło przestąpić nikomu.
###### **Dn 6,9**
 Król tedy Daryusz wydał dekret i postanowił.
###### **Dn 6,10**
 Czego gdy się Daniel dowiedział, to jest, iż prawo postanowione, wszedł do domu swego: a otworzywszy w dzień klękał na kolana swoje i chwalił, i wyznawał przed Bogiem swoim, jako i przedtem był zwykł czynić.
###### **Dn 6,11**
 Tedy mężowie oni dworniej się wywiadując naleźli Daniela modlącego się i proszącego Boga swego.
###### **Dn 6,12**
 I przystąpiwszy mówili królowi o wyrok: królu, azaś nie postanowił, aby każdy człowiek, któryby prosił którego z bogów i z ludzi aż do trzydzieści dni, oprócz ciebie królu, był wrzucon do lwiego dołu: którym odpowiadając król rzekł: Prawdziwa jest mowa, według dekretu Medów i Persów, którego się przestąpić nie godzi.
###### **Dn 6,13**
 Tedy odpowiadając rzekli przed królem: Daniel z synów pojmania Judzkiego nie dbał na twój dekret i na wyrok, któryś postanowił: ale trzech czasów na dzień modli się modlitwą swoją.
###### **Dn 6,14**
 Które słowo król usłyszawszy, zasmucił się barzo: i usadził serce za Danielem, żeby go wyzwolił, i aż do zachodu słońca starał się, aby go wybawił.
###### **Dn 6,15**
 Ale mężowie oni zrozumiawszy króla, rzekli mu: wiedz królu, że prawo jest Medów i Persów, aby żadnego wyroku, który król postanowi, nie godziło się odmienić.
###### **Dn 6,16**
 Tedy król rozkazał: i przywiedziono Daniela, i wrzucono go do lwiego dołu. I rzekł król Danielowi: Bóg twój, którego zawsze chwalisz, ten cię wybawi.
###### **Dn 6,17**
 I przyniesiono kamień jeden i położono ji na dziurze dołu: który król zapieczętował sygnetem swym, i sygnetem przednich panów swych, żeby czego nie uczyniono przeciw Danielowi.
###### **Dn 6,18**
 I poszedł król do domu swego, i spał niewieczerzawszy, i potraw przedeń nie noszono, nadto i sen odstąpił od niego.
###### **Dn 6,19**
 Tedy król barzo rano poszedł skwapliwie do lwiego dołu:
###### **Dn 6,20**
 A przybliżywszy się do dołu, zawołał na Daniela płaczliwym głosem: Danielu, sługo Boga żywego, Bóg twój, któremu ty za wżdy służysz, co mniemasz mógł cię ode lwów wybawić?
###### **Dn 6,21**
 A Daniel odpowiadając królowi rzekł: królu żyj na wieki:
###### **Dn 6,22**
 Bóg mój posłał anioła swego, i zamknął paszczęki lwom, i nie zaszkodzili mi, ponieważ przed nim sprawiedliwość naleziona jest we mnie: lecz i przed tobą królu występku nie uczyniłem.
###### **Dn 6,23**
 Tedy król barzo się uradował z tego, i kazał Daniela wyciągnąć z dołu: i wyciągniono Daniela z dołu, a żadnego obrażenia nie naleziono na nim, iż wierzył Bogu swemu.
###### **Dn 6,24**
 A z rozkazania królewskiego przywiedziono one męże, którzy byli oskarżyli Daniela, i wrzucono je do lwiego dołu, same, i syny, i żony ich: a nie dolecieli aż do dna dołu, gdy je lwi pochwycili, i wszystkie kości ich podruzgotali.
###### **Dn 6,25**
 Tedy Darius król pisał do wszech narodów, do pokolenia, i do języków mieszkających po wszystkiej ziemi: POKÓJ wam niech będzie rozmnożony.
###### **Dn 6,26**
 Odemnie postanowiony jest dekret, aby po wszem państwie i królestwie mojem drżeli i lękali się Boga Danielowego: bo on jest Bóg żywy, i wieczny na wieki: i królestwo jego nie skazi się, a władza jego aż na wieki.
###### **Dn 6,27**
 Ten wybawiciel i zbawiciel, czyniący znaki i dziwy na niebie i na ziemi: który wybawił Daniela ze lwiego dołu.
###### **Dn 6,28**
 A Daniel trwał aż do królestwa Dariusza, i do królestwa Cyrusa Persy.
