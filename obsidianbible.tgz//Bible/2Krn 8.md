# 2Krn 8 BT5
###### **2Krn 8,1**
 Po upływie dwudziestu lat, w ciągu których Salomon zbudował świątynię Pańską i pałac dla siebie,
###### **2Krn 8,2**
 odbudował także te miasta, które Huram dał Salomonowi, i osiedlił tam Izraelitów.
###### **2Krn 8,3**
 Udał się też Salomon do Chamat Soby i zdobył je.
###### **2Krn 8,4**
 Odbudował ponadto Tadmor na pustyni i wszystkie miasta spichlerzy, które zbudował w Chamat.
###### **2Krn 8,5**
 Odbudował także Bet-Choron górne i Bet-Choron dolne – warowne miasta umocnione murami, bramami i zaworami,
###### **2Krn 8,6**
 Baalat i wszystkie miasta spichlerzy, które należały do Salomona, i wszystkie miasta rydwanów oraz miasta konnicy, wszystko to, co podobało się Salomonowi wybudować w Jerozolimie i na Libanie oraz w każdym kraju będącym pod jego władzą.
###### **2Krn 8,7**
 A całą ludność pozostałą z Chittytów, Amorytów, Peryzzytów, Chiwwitów, Jebusytów, która nie pochodzi z Izraela,
###### **2Krn 8,8**
 stanowiąc potomstwo pozostałe w kraju po tych, których Izraelici nie wytępili, Salomon zaciągnął do robót przymusowych, po dziś dzień.
###### **2Krn 8,9**
 Z Izraelitów zaś nikogo nie przeznaczył Salomon do prac niewolniczych, gdyż oni byli jego wojownikami, wodzami przybocznymi, dowódcami jego rydwanów oraz konnicy.
###### **2Krn 8,10**
 Król Salomon miał dwustu pięćdziesięciu wyższych urzędników, którzy nadzorowali lud.
###### **2Krn 8,11**
 Sprowadził też Salomon córkę faraona z Miasta Dawidowego do pałacu, który dla niej zbudował. mówił bowiem: «***Nie powinna moja żona przebywać w domu Dawida, króla izraelskiego, bo jest to miejsce święte, ponieważ weszła do niego Arka Pańska***».
###### **2Krn 8,12**
 Wówczas kazał Salomon składać Panu w ofierze całopalenia na ołtarzu Pańskim, który postawił przed sienią,
###### **2Krn 8,13**
 aby zgodnie z porządkiem każdego dnia według nakazu Mojżesza składać ofiary w dni szabatu, dni nowiu księżyca i w trzy uroczystości roku: w Święto Przaśników, w Święto Tygodni i w Święto Namiotów.
###### **2Krn 8,14**
 Ustanowił też, według rozkładu ustalonego przez swego ojca, Dawida, zmiany kapłanów w ich służbie i lewitów w ich obowiązkach, aby śpiewali hymny pochwalne i służyli kapłanom zgodnie z porządkiem każdego dnia. Również [ustanowił] odźwiernych według ich zmian dla każdej bramy, bo takie było zarządzenie męża Bożego, Dawida.
###### **2Krn 8,15**
 Nie zostały zaniedbane pod żadnym względem nakazy króla odnoszące się do kapłanów i lewitów oraz do skarbów.
###### **2Krn 8,16**
 W ten sposób zostały dokończone wszystkie dzieła Salomona od dnia założenia fundamentów domu Pańskiego aż do całkowitego jego ukończenia.
###### **2Krn 8,17**
 Wówczas to udał się Salomon do Esjon-Geber i do Elat nad brzeg morza w kraju Edomu.
###### **2Krn 8,18**
 Wysłał mu wtedy Huram za pośrednictwem swoich sług okręty i załogę znającą morze, tak iż razem ze sługami Salomona dotarli do Ofiru, wzięli stamtąd czterysta pięćdziesiąt talentów złota i przywieźli je królowi Salomonowi.
# 2Krn 8 PAU
###### **2Krn 8,1**
 Po upływie dwudziestu lat, które Salomon poświęcił na budowę domu PANA i pałacu,
###### **2Krn 8,2**
 podjął się przebudowy miast przekazanych mu przez Hirama i osiedlił w nich Izraelitów.
###### **2Krn 8,3**
 Wyruszył także przeciwko Chamat oraz Soba i zdobył je.
###### **2Krn 8,4**
 Odbudował również Tadmor na pustyni i wszystkie miasta-spichlerze, które zbudował w Chamat.
###### **2Krn 8,5**
 Zbudował górne Bet-Choron i dolne Bet-Choron, miasta otoczone murami o wzmocnionych bramach.
###### **2Krn 8,6**
 Salomon umocnił także Baalat i wszystkie swoje miasta-spichlerze. Ponadto zbudował garnizony, w których rozmieszczono rydwany i konie. Zrealizował wszystkie swoje plany budowlane w Jerozolimie, w Libanie oraz na całym obszarze podległym jego panowaniu.
###### **2Krn 8,7**
 Wszystkich ocalałych Chetytów, Amorytów, Peryzzytów, Chiwwitów i Jebusytów, którzy nie byli Izraelitami
###### **2Krn 8,8**
 i których Izraelici nie wyniszczyli do końca, Salomon zobowiązał do robót publicznych. Tak jest po dziś dzień.
###### **2Krn 8,9**
 Nikogo z Izraelitów - mężczyzn ani kobiet - Salomon nie zmuszał do robót publicznych. Byli oni żołnierzami, wodzami, oficerami oraz dowódcami rydwanów i jeźdźców.
###### **2Krn 8,10**
 Było również dwustu pięćdziesięciu nadzorców, którzy w imieniu króla Salomona sprawowali władzę nad ludem.
###### **2Krn 8,11**
 Dla swojej żony, córki faraona, Salomon zbudował osobny pałac i tam przeniósł ją z Miasta Dawida. Mówił bowiem: „Moja żona nie może mieszkać w pałacu Dawida, króla Izraela, gdyż miejsce, na które przyniesiono Arkę PANA, jest święte”.
###### **2Krn 8,12**
 Wtedy Salomon składał PANU ofiary całopalne na ołtarzu PANA, który zbudował przed przedsionkiem świątyni.
###### **2Krn 8,13**
 Zgodnie z nakazem Mojżesza dotyczącym każdego dnia, składał je w soboty, w dzień nowiu i w trzy doroczne święta: Przaśników, Tygodni i Namiotów.
###### **2Krn 8,14**
 Zgodnie z zaleceniami swojego ojca Dawida ustanowił oddziały kapłanów według ich funkcji liturgicznych. Ustanowił także oddziały lewitów według ich obowiązków, aby każdego dnia wychwalali PANA i pomagali kapłanom w ich codziennej posłudze. Ustanowił także oddziały strażników poszczególnych bram, gdyż tak nakazał Dawid, człowiek Boży.
###### **2Krn 8,15**
 Nie przekroczył żadnego rozporządzenia królewskiego odnoszącego się do kapłanów, lewitów oraz wszystkich spraw i skarbców.
###### **2Krn 8,16**
 W ten sposób zostało dokończone dzieło Salomona trwające od dnia, w którym położono fundamenty pod dom PANA, aż do pomyślnego zakończenia budowy domu PANA.
###### **2Krn 8,17**
 Następnie Salomon udał się do Esjon-Geber i do Elat położonego nad brzegiem morza w kraju Edomu.
###### **2Krn 8,18**
 Hiram przesłał mu kilka statków wraz z doświadczonymi żeglarzami, którzy razem z poddanymi Salomona popłynęli do Ofiru, gdzie załadowali czterysta pięćdziesiąt talentów złota i przywieźli je do króla Salomona.
# 2Krn 8 BP
###### **2Krn 8,1**
 Po upływie dwudziestu lat, w czasie których zbudował Salomon Świątynię Jahwe i swój pałac,
###### **2Krn 8,2**
 odbudował też miasta, które Chiram dał Salomonowi, i oddał je na mieszkanie synom Izraela.
###### **2Krn 8,3**
 Potem wyruszył Salomon przeciw Chamat-Coba i zdobył je.
###### **2Krn 8,4**
 Następnie odbudował Tadmor na pustyni i wszystkie miasta, w których miał składy, a które założył w Chamat.
###### **2Krn 8,5**
 Odbudował też Bet-Choron Górne i Bet-Choron Dolne, miasta obronne, obwarowane murami, bramami i zaworami.
###### **2Krn 8,6**
 Również Baalat i wszystkie miasta, w których Salomon miał składy, miasta rydwanów wojennych i konnicy, i wszystko, co tylko zechciał, wybudował Salomon w Jeruzalem i na Libanie, i w każdym kraju, który znajdował się pod jego panowaniem.
###### **2Krn 8,7**
 Resztę ludności pozostałej z Chittytów, Amorytów, Peryzzytów, Chiwwitów i Jebuzytów, która nie należała do Izraela,
###### **2Krn 8,8**
 a stanowiła potomstwo pozostałe w kraju z tymi, których nie wytracili synowie Izraela, poddał Salomon przymusowej pracy, [co trwa] aż po dzień dzisiejszy.
###### **2Krn 8,9**
 Spośród Izraelitów Salomon nie przeznaczył nikogo do prac niewolniczych, gdyż oni byli jego wojownikami, dowódcami jego straży przybocznej, dowódcami jego rydwanów bojowych i konnicy.
###### **2Krn 8,10**
 Wyższych urzędników miał król Salomon dwustu pięćdziesięciu i oni sprawowali rządy nad ludem.
###### **2Krn 8,11**
 Sprowadził też Salomon córkę faraona z Miasta Dawidowego do pałacu, który dla niej zbudował; mówił bowiem: "Nie godzi się, by niewiasta miała mieszkać w domu Dawida, króla Izraela, miejsce to bowiem, na którym spoczęła Arka Jahwe - święte jest".
###### **2Krn 8,12**
 Złożył wówczas Salomon dla Jahwe ofiarę całopalną na ołtarzu Jahwe, który wzniósł przed przedsionkiem,
###### **2Krn 8,13**
 aby każdego dnia zgodnie z przepisami Mojżesza składać nakazane ofiary w szabaty, na nowiu księżyca i w uroczyste święta trzy razy do roku: w Święto Przaśników, Święto Tygodni i w Święto Namiotów.
###### **2Krn 8,14**
 Ustanowił też, według podziału dokonanego przez ojca swego Dawida, zmiany kapłanów w ich czynnościach i lewitów w ich obowiązkach, by sławili [Boga] i pomagali kapłanom według ustalonego na każdy dzień porządku. [Ustanowił również] zgodnie z rozporządzeniem męża Bożego, Dawida, odźwiernych przy każdej bramie według ich zmian.
###### **2Krn 8,15**
 I nie odstąpiono od nakazów króla, które odnosiły się do kapłanów, lewitów, skrybów i wszystkich [innych] spraw.
###### **2Krn 8,16**
 Tak dokonane zostało wszelkie dzieło Salomona od dnia, w którym położono podwaliny Świątyni Jahwe, aż do zupełnego jej ukończenia.
###### **2Krn 8,17**
 Udał się następnie Salomon do Ecjon Geber i do Elat położonych na wybrzeżu morskim w krainie Edom.
###### **2Krn 8,18**
 Chiram za pośrednictwem sług swoich posłał mu okręty i doświadczonych żeglarzy morskich. Razem ze sługami Salomona popłynęli oni do Ofiru, przywieźli stamtąd czterysta pięćdziesiąt talentów złota i oddali królowi Salomonowi.
# 2Krn 8 BR
###### **2Krn 8,1**
 Po upływie dwudziestu lat, w ciągu których została ukończona budowa świątyni oraz pałacu królewskiego,
###### **2Krn 8,2**
 Salomon odbudował wszystkie miasta przekazane mu kiedyś przez Hurama i osiedlił w nich Izraelitów.
###### **2Krn 8,3**
 Potem wyruszył na Chamat Soba i zdobył je.
###### **2Krn 8,4**
 Odbudował także Tadmor na pustyni i wszystkie miasta, które służyły mu za składy zboża, a które (już wcześniej) zbudował w kraju Chamat.
###### **2Krn 8,5**
 Odbudował również Bet-Choron górne i Bet-Choron dolne, miasta warowne, otoczone murami obronnymi, zaopatrzone w specjalne bramy i zawory.
###### **2Krn 8,6**
 Ponadto odbudował Salomon Baalat i wszystkie okoliczne miasta, służące za składnice: miasta, w których były zgromadzone rydwany; miasta przeznaczone dla konnicy. Budował Salomon wszystko, co uznał za wskazane, w Jerozolimie, w Libanie i na wszystkich ziemiach, które podlegały jego władzy.
###### **2Krn 8,7**
 Wszystkie zaś narody nie należące do Izraela, a więc ci, co pozostali z Chetytów, Amorytów, Peryzzytów, Chiwwitów, Jebusytów, dokładniej mówiąc:
###### **2Krn 8,8**
 ich potomkowie, którzy ocaleli na ziemi izraelskiej i nie zostali wyniszczeni przez synów Izraela - wszyscy zostali zatrudnieni przez Salomona przy robotach przymusowych, które wykonują po dzień dzisiejszy.
###### **2Krn 8,9**
 Natomiast nikogo spośród synów Izraela nie zmuszał Salomon do tych prac. Wszyscy oni bowiem byli wojownikami, dowódcami jego oddziałów przybocznych, dowódcami rydwanów i oddziałów konnych.
###### **2Krn 8,10**
 Samych wyższych urzędników miał król Salomon dwustu pięćdziesięciu. Oni to przekazywali ludowi królewskie rozkazy.
###### **2Krn 8,11**
 Córkę faraona sprowadził Salomon z Miasta Dawidowego do pałacu, który specjalnie dla niej zbudował. Powiedział bowiem tak: Moja żona nie będzie mieszkać w pałacu Dawida, króla izraelskiego, bo święte są miejsca, na których była arka Jahwe.
###### **2Krn 8,12**
 Salomon złożył na cześć Jahwe ofiary całopalenia na ołtarzu Jahwe, zbudowanym przez niego przed przedsionkiem świątyni.
###### **2Krn 8,13**
 Zgodnie z tym, co nakazał Mojżesz, ofiary składano każdego dnia, we wszystkie szabaty, we wszystkie nowie księżyca i w trzy doroczne święta: w Święto Przaśników, w Święto Tygodni oraz w Święto Namiotów.
###### **2Krn 8,14**
 Wprowadził również, co było postanowione już przez jego ojca, Dawida, różne klasy kapłanów, spełniających posługi świątynne: lewitów, którzy mieli śpiewać pieśni pochwalne na cześć Jahwe i wspierać kapłanów w ich codziennej posłudze; odźwiernych, podzielonych na specjalne grupy stosownie do liczby bram. Tak bowiem zarządził mąż Boży Dawid.
###### **2Krn 8,15**
 Nie zaniedbywano żadnych nakazów królewskich co do kapłanów, lewitów oraz innych spraw, a zwłaszcza troski o skarbce.
###### **2Krn 8,16**
 W ten sposób całe dzieło Salomona było starannie dokonywane od dnia rozpoczęcia aż do zakończenia budowy świątyni Jahwe. I tak budowa świątyni Jahwe została ukończona.
###### **2Krn 8,17**
 Wtedy to udał się Salomon do Esjon-Geber i do Elat nad brzegiem morza w krainie edomickiej.
###### **2Krn 8,18**
 Huram przez swoje sługi przysłał mu tam okręty i doświadczonych żeglarzy, którzy razem ze sługami Salomona poprowadzili okręty do Ofiru, gdzie załadowali czterysta pięćdziesiąt talentów złota, a następnie dostarczyli je Salomonowi.
# 2Krn 8 WUJ
###### **2Krn 8,1**
 A gdy wyszło dwadzieścia lat potem jako zbudował Salomon dom Pański i dom swój:
###### **2Krn 8,2**
 Miasta, które był dał Hiram Salomonowi, pobudował, i dał tam mieszkanie synom Izraelskim.
###### **2Krn 8,3**
 Ciągnął też do Emath Suba i wziął ją.
###### **2Krn 8,4**
 I zbudował Palmirę na puszczy, i inne miasta barzo obronne pobudował w Emath.
###### **2Krn 8,5**
 I zbudował Bethoron wyższe, i Bethoron niższe, miasta murowane, mające i bramy i zawory i zamki.
###### **2Krn 8,6**
 Baalath też i wszystkie miasta mocne, które były Salomonowe, i wszystkie miasta poczwórnych wozów, i miasta jezdnych. Wszystko co chciał Salomon, i umyślił, zbudował w Jeruzalem i w Libanie, i we wszystkiej ziemi władzy swej.
###### **2Krn 8,7**
 Wszystek lud, który pozostał z Hethejczyków i z Amorre jeżyków, i z Pherezejczyków, i z Hewejczyków, i z Jebuzejczyków, którzy nie byli z pokolenia Izraelskiego:
###### **2Krn 8,8**
 Z synów tych i z potomków, których byli nie wygubili synowie Izraelscy, podbił Salomon na hołdowniki aż do dnia tego.
###### **2Krn 8,9**
 Ale z synów Izraelskich nie postawił, aby służyli w robotach królewskich: bo oni byli mężowie waleczni, i przedniejszy hetmani, i przełożeni nad wozmi jego, i nad jezdnymi jego.
###### **2Krn 8,10**
 A wszystkich przełożonych nad wojskiem króla Salomona było dwieście i pięćdziesiąt, którzy ćwiczyli lud.
###### **2Krn 8,11**
 A córkę Pharaonowę przeniósł z miasta Dawidowego do domu, który jej zbudował. Bo mówił król: Nie będzie mieszkała żona moja w domu Dawida króla Izraelskiego, przeto, iż poświęcony jest: bo do niego weszła skrzynia Pańska.
###### **2Krn 8,12**
 Tedy ofiarował Salomon całopalenia Panu na ołtarzu Pańskim, który był zbudował przed przysionkiem,
###### **2Krn 8,13**
 Aby na każdy dzień ofiarowano na nim według przykazania Mojżeszowego, w Sabathy, i w pierwsze dni miesiąca, i w dni święte, trzykroć przez rok, to jest w święto przaśników, w święto tygodniów, i w święto kuczek.
###### **2Krn 8,14**
 I postanowił według rozrządzenia Dawida ojca swego urzędy kapłanów w posługowaniu ich: i Lewity w porządku ich, aby chwalili i służyli przed kapłany według obrzędu każdego dnia: i odźwierne w rozdzialech ich przy bramie i bramie: bo tak był przykazał Dawid człowiek Boży.
###### **2Krn 8,15**
 I nie przestąpili z rozkazania królewskiego, tak kapłani jako i Lewitowie, ze wszystkiego co przykazał, i w strażach skarbów.
###### **2Krn 8,16**
 Wszystkie nakłady miał gotowe Salomon, od onego dnia, którego założył fundamenty domu Pańskiego, aż do dnia którego dokonał.
###### **2Krn 8,17**
 Jachał tedy Salomon do Asiongaber, i do Ailath, nad brzegiem morza Czerwonego, który jest w ziemi Edomskiej.
###### **2Krn 8,18**
 I posłał mu Hiram przez ręce sług swych okręty, i żeglarzów świadomych morza, i jachali z sługami Salomonowymi do Ophir, i przywieźli ztamtąd czterysta pięćdziesiąt talentów złota, i przynieśli do króla Salomona.
