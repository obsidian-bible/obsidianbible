# Hbr 8 BT5
###### **Hbr 8,1**
 Sedno zaś wywodów stanowi prawda: takiego mamy arcykapłana, który zasiadł po prawicy tronu Majestatu w niebiosach,
###### **Hbr 8,2**
 jako sługa świątyni i prawdziwego przybytku zbudowanego przez Pana, a nie przez człowieka.
###### **Hbr 8,3**
 Każdy bowiem arcykapłan ustanawiany jest do składania darów i ofiar, przeto trzeba, aby Ten także miał coś, co by ofiarował.
###### **Hbr 8,4**
 Gdyby więc był na ziemi, to nawet nie byłby kapłanem, gdyż są tu inni, którzy składają ofiary według postanowień Prawa.
###### **Hbr 8,5**
 Usługują oni obrazowi i cieniowi rzeczywistości niebieskich. Gdy bowiem Mojżesz miał zbudować przybytek, został w ten sposób pouczony przez Boga: Bacz – powiada bowiem: abyś uczynił wszystko według wzoru, jaki ci został ukazany na górze.
###### **Hbr 8,6**
 Teraz zaś otrzymał w udziale o tyle wznioślejszą służbę, o ile też stał się [Chrystus] pośrednikiem lepszego przymierza, które oparte zostało na lepszych obietnicach.
###### **Hbr 8,7**
 Gdyby bowiem owo pierwsze było bez zarzutu, nie szukano by miejsca na drugie [przymierze].
###### **Hbr 8,8**
 Albowiem ganiąc ich, zapowiada:Oto nadchodzą dni, mówi Pan, a zawrę z domem Izraelai z domem Judy przymierze nowe.
###### **Hbr 8,9**
 Nie takie jednak przymierze, jakie zawarłem z ich domemw dniu, gdy ich wziąłem za rękę, by wyprowadzić ich z ziemi egipskiej. Ponieważ oni nie wytrwali w moim przymierzu, przeto i Ja przestałem dbać o nich, mówi Pan.
###### **Hbr 8,10**
 Takie jest przymierze, które zawrę z domem Izraelapo owych dniach, mówi Pan. Nadam prawa moje w ich myśli, i wypiszę je na ich sercach, i będę im Bogiem, a oni będą Mi ludem.
###### **Hbr 8,11**
 I nikt nie będzie uczył swojego rodakaani nikt swego brata, mówiąc:Poznaj Pana!Bo wszyscy Mnie poznają, od małego aż do wielkiego.
###### **Hbr 8,12**
 Ponieważ ulituję się nad ich nieprawością, a na ich grzechy więcej już nie wspomnę.
###### **Hbr 8,13**
 Skoro zaś mówi o nowym, pierwsze uznał za przestarzałe; a to, co się przedawnia i starzeje, bliskie jest zniszczenia.
# Hbr 8 PAU
###### **Hbr 8,1**
 Tak dochodzimy do sedna sprawy: mamy takiego najwyższego kapłana, który zasiadł po prawej stronie tronu Majestatu w niebie.
###### **Hbr 8,2**
 Jest On sługą świątyni, prawdziwego namiotu zbudowanego przez Pana, a nie przez człowieka.
###### **Hbr 8,3**
 Każdy najwyższy kapłan jest ustanawiany dla składania darów i ofiar. Trzeba więc, aby i Ten miał co ofiarować.
###### **Hbr 8,4**
 Gdyby miał pozostać na ziemi, to nie byłby nawet kapłanem. Są tam bowiem inni, którzy składają dary zgodnie z Prawem.
###### **Hbr 8,5**
 Służą oni jednak wizerunkowi i cieniowi rzeczywistości niebiańskiej. Gdy Mojżesz zamierzał wykonać namiot, otrzymał od Boga taką wskazówkę: Bądź uważny i postaraj się wykonać wszystko zgodnie ze wzorem, który widziałeś na górze!
###### **Hbr 8,6**
 Zatem Jezus pełni służbę tym wznioślejszą, im jest pośrednikiem lepszego przymierza, opartego na wspanialszych obietnicach.
###### **Hbr 8,7**
 Gdyby bowiem to pierwsze było nienaganne, to Bóg nie szukałby drugiego w jego miejsce.
###### **Hbr 8,8**
 Tymczasem, ganiąc ich, mówi: Oto nadchodzą dni - mówi Pan - gdy dopełnię z domem Izraela i z domem Judy nowe przymierze.
###### **Hbr 8,9**
 Będzie się ono różnić od przymierza, które zawarłem z ich przodkami w dniu, gdy ich ująłem za rękę, aby ich wyprowadzić z ziemi egipskiej. Ponieważ oni nie wytrwali w przymierzu ze Mną, Ja także ich opuściłem - mówi Pan.
###### **Hbr 8,10**
 Lecz takie będzie przymierze, które zawrę z domem Izraela po tych dniach - mówi Pan: Moje prawa umieszczę w ich umysłach i wypiszę je na ich sercach. Będę dla nich Bogiem, a oni będą dla Mnie ludem.
###### **Hbr 8,11**
 I nikt już nie będzie pouczał swego rodaka ani swego brata: „Poznaj Pana!”, bo wszyscy będą Mnie znali, od najmniejszego do największego.
###### **Hbr 8,12**
 Wtedy odpuszczę ich winy, a ich grzechów nie będę już pamiętał.
###### **Hbr 8,13**
 Mówiąc o nowym Przymierzu, uznał to pierwsze za przedawnione. To zaś, co się przedawnia i starzeje, zanika.
# Hbr 8 BP
###### **Hbr 8,1**
 Z tego, co mówimy, najważniejsze jest to: Mamy arcykapłana, który zasiadł na prawicy Majestatu, na Jego tronie w niebie.
###### **Hbr 8,2**
 On spełnia służbę w świątyni, to jest w namiocie prawdziwym, jaki zbudował Pan, a nie człowiek.
###### **Hbr 8,3**
 Otóż każdy arcykapłan ustanawiany bywa po to, ażeby składał ofiary bezkrwawe i krwawe; trzeba zatem, żeby i On miał co ofiarować.
###### **Hbr 8,4**
 Jeśli zaś byłby na ziemi, nie byłby nawet kapłanem, skoro są ci, którzy składają ofiary zgodnie z Prawem.
###### **Hbr 8,5**
 Oni spełniają swą służbę w świątyni, która jest tylko obrazem i cieniem świątyni niebieskiej, o czym został pouczony Mojżesz, gdy miał zbudować namiot. "Patrz - zatem powiada [Bóg] - masz zrobić wszystko według wzoru, jaki był ci pokazany na górze".
###### **Hbr 8,6**
 Obecnie zaś otrzymał zaszczytniejsze posługiwanie, bo też jest poręczycielem lepszego Przymierza, które uprawomocnione zostało mocniejszymi obietnicami.
###### **Hbr 8,7**
 Jeśli bowiem owo pierwsze byłoby w pełni doskonałe, nie miałoby sensu szukanie drugiego.
###### **Hbr 8,8**
 Ganiąc ich wszakże, powiada: "Oto nadchodzą dni, mówi Pan, a zawrę ostatecznie z domem Izraela i z domem Judy Nowe Przymierze.
###### **Hbr 8,9**
 Nie takie jak Przymierze, jakie zawarłem z ich ojcami w dniu, kiedy wziąłem ich za rękę, aby ich wyprowadzić z ziemi egipskiej. Ponieważ oni nie wytrwali w Przymierzu ze mną, i ja zaniedbałem ich, powiada Pan.
###### **Hbr 8,10**
 Takie oto będzie Przymierze, które zawrę z domem Izraela: Po owych dniach - powiada Pan - wyryję moje Prawa w ich myślach i napiszę je na ich sercach, będę ich Bogiem, a oni będą moim ludem.
###### **Hbr 8,11**
 Nikt już nie będzie pouczał swojego rodaka ani swego brata, mówiąc: Poznaj Pana! Albowiem wszyscy będą mnie znali, od najmłodszego do najstarszego.
###### **Hbr 8,12**
 Będę wyrozumiały dla ich wykroczeń i nie będę pamiętał ich grzechów".
###### **Hbr 8,13**
 Skoro mówi "nowe", to uważa, że poprzednie się zestarzało; a to, co jest przedawnione i przestarzałe, nadaje się do usunięcia.
# Hbr 8 BR
###### **Hbr 8,1**
 To, co teraz mówimy, sprowadza się ostatecznie do następującej prawdy: Mamy takiego arcykapłana, który zasiadł po prawej stronie Majestatu [Boga] w niebie:
###### **Hbr 8,2**
 Jest On sługą w świątyni i w przybytku prawdziwym, zbudowanym przez Pana, a nie przez człowieka.
###### **Hbr 8,3**
 Każdy arcykapłan jest bowiem ustanowiony po to, aby składać dary i ofiary. Wypadało więc, żeby On również miał coś do złożenia w ofierze.
###### **Hbr 8,4**
 Gdyby zaś był na ziemi, nie mógłby być kapłanem, gdyż byli tam już inni, którzy składali ofiary zgodnie z wymaganiami Prawa.
###### **Hbr 8,5**
 Lecz ich posługiwanie jest zaledwie obrazem i cieniem tego, co dzieje się w niebie. Dlatego już Mojżesz, gdy zabierał się do budowy przybytku, otrzymał takie oto polecenie od Boga: Staraj się wykonać wszystko według tego wzoru, który ci został ukazany na górze.
###### **Hbr 8,6**
 Otóż [Jezus] otrzymał w udziale posługiwanie o tyle wznioślejsze, o ile doskonalsze było przymierze, którego stał się pośrednikiem i które było oparte na lepszych obietnicach.
###### **Hbr 8,7**
 Gdyby owo pierwsze przymierze było w pełni doskonałe, nie byłoby potrzeby zastępowania go drugim.
###### **Hbr 8,8**
 Tymczasem Bóg karcąc swój lud zapowiada: Oto nadchodzą dni - mówi Pan kiedy to zawrę nowe przymierze z domem Izraela i z domem Judy.
###### **Hbr 8,9**
 Będzie to przymierze inne niż tamto które zawarłem z ich ojcami; w dniu, kiedy to ująwszy ich za rękę, wyprowadziłem wszystkich z ziemi egipskiej. Ponieważ jednak oni nie wytrwali w moim przymierzu, wobec tego Ja również nie troszczyłem się więcej o nich - mówi Pan.
###### **Hbr 8,10**
 A oto jakie będzie to przymierze, które zawrę w owych dniach z domem Izraela: Prawem moim wypełnię ich myśli - mówi Pan - wypiszę je na ich sercach. Ja będę ich Bogiem, a oni będą moim ludem.
###### **Hbr 8,11**
 I nikt już nie będzie pouczał swego rodaka ani nie będzie mówił do brata swego: Poznaj Pana. Wszyscy bowiem - od najmniejszego do największego - będą Mnie znać.
###### **Hbr 8,12**
 Wybaczę im ich nieprawości i nie będę już więcej wspominał ich grzechów.
###### **Hbr 8,13**
 Ponieważ mówi [Pan] o nowym [przymierzu], wynika z tego, że pierwsze [przymierze] uznał za przestarzałe. Otóż to, co się już przedawnia i starzeje, niebawem przestanie istnieć.
# Hbr 8 WUJ
###### **Hbr 8,1**
 A summa tego co się mówi, takiego mamy nawyższego kapłana, który usiadł na prawicy stolice wielmożnóści na niebiesiech:
###### **Hbr 8,2**
 Sługa świątnice, a prawdziwego przybytku, który postanowił Pan a nie człowiek.
###### **Hbr 8,3**
 Abowiem wszelki nawyższy kapłan bywa postanowion ku ofiarowaniu darów i ofiar: Zaczem potrzeba jest, aby i ten nieco miał coby ofiarował.
###### **Hbr 8,4**
 Jeśliby tedy był na ziemi, aniby kapłanem był, gdyżby byli, którzyby według zakonu dary ofiarowali,
###### **Hbr 8,5**
 Którzy służą wizerunkowi i cieniowi rzeczy niebieskich Jako odpowiedziano jest Mojżeszowi, gdy miał dokończyć przybytku: Patrzaj (prawi) czyń wszystko według wizerunku, który jest tobie na górze okazan.
###### **Hbr 8,6**
 A teraz dostał tem lepszego posługowania, i lepszego testamentu jest pośrednikiem, który w lepszych obietnicach jest postanowiony.
###### **Hbr 8,7**
 Abowiem, jeśliby on pierwszy był bez przygany: zaisteby wtóremu miejsca nie szukano.
###### **Hbr 8,8**
 Abowiem ganiąc je, mówi: Oto dni przyjdą, mówi Pan, a wykonam nad domem Izraelskim, i nad domem Juda testament nowy,
###### **Hbr 8,9**
 Nie według testamentu, którym uczynił ojcom ich w dzień, w którym ujął rękę ich, abym je wywiódł z ziemie Egiptskiej: abowiem oni nie wytrwali w moim testamencie: a jam ich zaniedbał, mówi Pan.
###### **Hbr 8,10**
 Bo ten jest testament, który uczynię domowi Izraelskiemu po onych dniach, mówi Pan: Podając prawa moje w umysł ich, i na sercu ich napiszę je: i będę im Bogiem, a oni mnie będą ludem:
###### **Hbr 8,11**
 I nie będzie uczył każdy bliźniego swego, i każdy brata swego, mówiąc: Poznaj Pana. Abowiem wszyscy mię poznają od mniejszego aż do więtszego z nich.
###### **Hbr 8,12**
 Abowiem będę miłościw nieprawościam ich: i grzechów ich już nie wspomionę.
###### **Hbr 8,13**
 A gdy mówi Nowy: pierwszy wiotchym uczynił. A to co wietszeje i starzeje się: blizko jest zginienia.
# Hbr 8 STERN
###### **Hbr 8,1**
 W tym tkwi istota tego wszystkiego, o czym mówimy: mamy naprawdę takiego właśnie kohena gadola, jak opisaliśmy. I naprawdę zasiada On po prawicy Ha-G'dula w niebie.
###### **Hbr 8,2**
 Służy On tam w Miejscu Świętym, czyli w prawdziwym Namiocie Spotkania, wzniesionym nie przez ludzi, ale przez Adonai.
###### **Hbr 8,3**
 Bo każdego kohena gadola wyznacza się, aby składał zarówno dary, jak i ofiary; tak również i ten kohen gadol musi mieć coś, co może ofiarować.
###### **Hbr 8,4**
 Otóż jeśli byłby On na ziemi, wcale nie byłby kohenem, gdyż są już tu kohanim składający dary wymagane przez Torę.
###### **Hbr 8,5**
 Jednak służą oni tylko jako kopia i cień niebieskiego pierwowzoru; bo gdy Mosze miał wznieść Namiot, Bóg ostrzegł go: "Dopilnuj, żeby zrobić wszystko według wzoru, jaki ci pokazano na górze".
###### **Hbr 8,6**
 Lecz teraz dzieło, które powierzono do wykonania Jeszui, znacznie przewyższa ich dzieło, tak jak lepsze jest przymierze, którego On jest pośrednikiem. Bo przymierze to zostało uczynione Torę na podstawie lepszych obietnic.
###### **Hbr 8,7**
 Zaiste, gdyby pierwsze przymierze nie dało podstaw do znajdowania wad, to nie byłoby potrzebne drugie przymierze.
###### **Hbr 8,8**
 Bo Bóg rzeczywiście znajduje wady u ludu, gdy mówi: "Spójrzcie! Nadchodzą dni - mówi Adonai - gdy ustanowię nad domem Izraela i nad domem J'hudy nowe przymierze.
###### **Hbr 8,9**
 Nie będzie ono jak to przymierze, które zawarłem z ich ojcami w dniu, gdy wziąłem ich za rękę i wyprowadziłem z ziemi egipskiej; gdyż oni ze swej strony nie pozostali wierni memu przymierzu; toteż ja ze swej strony przestałem się o nich troszczyć - mówi Adonai.
###### **Hbr 8,10**
 Bo takie oto przymierze zawrę z domem Isra'ela po tych dniach - mówi Adonai. - Włożę moja Torę w ich umysły i wypiszę ją na ich sercach; ja będę ich Bogiem, a oni będą moim ludem.
###### **Hbr 8,11**
 Żaden z nich nie będzie pouczał współobywatela ani brata swego, mówiąc: "Poznaj Adonai!". Bo wszyscy znać mnie będą, od najmniejszego z nich do największego,
###### **Hbr 8,12**
 gdyż okażę miłosierdzie ich niegodziwości, a o ich grzechach nie będę już pamiętał".
###### **Hbr 8,13**
 Używszy określenia "nowe", uczynił pierwsze przymierze "starym", a coś, co robi się stare, co podlega procesowi starzenia się, zmierza ku całkowitemu zanikowi.
# Hbr 8 TRO
###### **Hbr 8,1**
 **κεφαλαιον** *kefalaion* Główne [[G2774]] WTN-NSN **δε** *de* zaś [[G1161]] [[CONJ]] **επι** *epi* w [[G1909]] [[PREP]] **τοις** *tois* (tym) [[G3588]] WTT-DPN **λεγομενοις** *legomenois* co jest mówione [[G3004]] WTV-PPP-DPN **τοιουτον** *toiouton* takiego [[G5108]] WTD-ASM **εχομεν** *echomen* mamy [[G2192]] WTV-PAI-1P **αρχιερεα** *archierea* arcykapłana [[G749]] [[N-ASM]] **ος** *hos* który [[G3739]] WTR-NSM **εκαθισεν** *ekathisen* usiadł [[G2523]] [[V-AAI-3S]] **εν** *en* po [[G1722]] [[PREP]] **δεξια** *deksia* prawej stronie – prawicy [[G1188]] WTA-DSF **του** *tou* [[G3588]] WTT-GSM **θρονου** *thronou* tronu [[G2362]] [[N-GSM]] **της** *tēs* [[G3588]] [[T-GSF]] **μεγαλωσυνης** *megalōsynēs* Wielkości – Majestatu [[G3172]] [[N-GSF]] **εν** *en* w [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPM **ουρανοις** *ouranois* niebiosach [[G3772]] WTN-DPM
###### **Hbr 8,2**
 **των** *tōn* [[G3588]] WTT-GPN **αγιων** *hagiōn* świętych [[G39]] WTA-GPN **λειτουργος** *leitourgos* publiczny sługa [[G3011]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **της** *tēs* [[G3588]] [[T-GSF]] **σκηνης** *skēnēs* namiotu – przybytku [[G4633]] [[N-GSF]] **της** *tēs* [[G3588]] [[T-GSF]] **αληθινης** *alēthinēs* prawdziwego [[G228]] WTA-GSF **ην** *hēn* który [[G3739]] WTR-ASF **επηξεν** *epēksen* rozbił – zatknął [[G4078]] [[V-AAI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **και** *kai* a [[G2532]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ανθρωπος** *anthrōpos* człowiek [[G444]] [[N-NSM]]
###### **Hbr 8,3**
 **πας** *pas* Każdy [[G3956]] [[A-NSM]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **αρχιερευς** *archiereus* arcykapłan [[G749]] [[N-NSM]] **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **προσφερειν** *prosferein* przynosić – ofiarować [[G4374]] WTV-PAN **δωρα** *dōra* dary – dary ofiarne [[G1435]] WTN-APN **τε** *te* zarówno – także [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **θυσιας** *thysias* ofiary [[G2378]] WTN-APF **καθισταται** *kathistatai* jest ustanawiany [[G2525]] WTV-PPI-3S **οθεν** *hothen* dlatego – stąd [[G3606]] [[ADV]] **αναγκαιον** *anagkaion* konieczne – niezbędne [[G316]] WTA-NSN **εχειν** *echein* (by) mieć [[G2192]] WTV-PAN **τι** *ti* coś [[G5100]] WTX-ASN **και** *kai* i [[G2532]] [[CONJ]] **τουτον** *touton* Ten [[G5126]] WTD-ASM **ο** *ho* co [[G3739]] WTR-ASN **προσενεγκη** *prosenegkē* przyniósłby – ofiarowałby [[G4374]] WTV-AAS-3S
###### **Hbr 8,4**
 **ει** *ei* Jeśli [[G1487]] WTCOND **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **επι** *epi* na [[G1909]] [[PREP]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]] **ουδ** *oud* ani [[G3761]] [[ADV]] **αν** *an* (kiedy)kolwiek [[G302]] WTPRT **ην** *ēn* byłby [[G2258]] [[V-IXI-3S]] **ιερευς** *hiereus* kapłan [[G2409]] [[N-NSM]] **οντων** *ontōn* będących [[G5607]] WTV-PXP-GPM **των** *tōn* [[G3588]] WTT-GPM **ιερεων** *hiereōn* kapłanami [[G2409]] WTN-GPM **των** *tōn* [[G3588]] WTT-GPM **προσφεροντων** *prosferontōn* przynoszący – ofiarujący [[G4374]] WTV-PAP-GPM **κατα** *kata* według [[G2596]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **νομον** *nomon* Prawa [[G3551]] [[N-ASM]] **τα** *ta* [[G3588]] WTT-APN **δωρα** *dōra* dary – dary ofiarne [[G1435]] WTN-APN
###### **Hbr 8,5**
 **οιτινες** *hoitines* którzy [[G3748]] WTR-NPM **υποδειγματι** *hypodeigmati* przykładowi – postaci [[G5262]] WTN-DSN **και** *kai* i [[G2532]] [[CONJ]] **σκια** *skia* cieniowi [[G4639]] [[N-DSF]] **λατρευουσιν** *latreuousin* służą [[G3000]] WTV-PAI-3P **των** *tōn* (tych) [[G3588]] WTT-GPN **επουρανιων** *epouraniōn* niebiańskich [[G2032]] WTA-GPN **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **κεχρηματισται** *kechrēmatistai* otrzymał wyrocznię – otrzymał ostrzeżenie [[G5537]] WTV-RPI-3S **μωσης** *mōsēs* Mojżesz – [wyciągnąć] [[G3475]] [[N-NSM]] **μελλων** *mellōn* zamierzając [[G3195]] [[V-PAP-NSM]] **επιτελειν** *epitelein* wykonać – kończyć [[G2005]] WTV-PAN **την** *tēn* [[G3588]] WTT-ASF **σκηνην** *skēnēn* namiot – przybytek [[G4633]] WTN-ASF **ορα** *hora* patrz – uważaj [[G3708]] WTV-PAM-2S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **φησιν** *fēsin* mówi [[G5346]] WTV-PXI-3S **ποιησης** *poiēsēs* uczyniłbyś [[G4160]] WTV-AAS-2S **παντα** *panta* wszystkie [[G3956]] WTA-APN **κατα** *kata* według [[G2596]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **τυπον** *typon* wzoru – typu [[G5179]] [[N-ASM]] **τον** *ton* [[G3588]] [[T-ASM]] **δειχθεντα** *deichthenta* który został pokazany [[G1166]] WTV-APP-ASM **σοι** *soi* ci [[G4671]] WTP-2DS **εν** *en* na [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **ορει** *orei* górze [[G3735]] WTN-DSN
###### **Hbr 8,6**
 **νυνι** *nyni* teraz [[G3570]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **διαφορωτερας** *diaforōteras* różniejszej [[G1313]] WTA-GSF-C **τετευχεν** *teteuchen* dostępuje [[G5177]] WTV-RAI-3S **λειτουργιας** *leitourgias* publicznego dzieła – publicznej służby [[G3009]] [[N-GSF]] **οσω** *hosō* o ile – jak wiele [[G3745]] WTK-DSN **και** *kai* i [[G2532]] [[CONJ]] **κρειττονος** *kreittonos* lepszego – znaczniejszego [[G2909]] WTA-GSF **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **διαθηκης** *diathēkēs* przymierza [[G1242]] [[N-GSF]] **μεσιτης** *mesitēs* pośrednik [[G3316]] [[N-NSM]] **ητις** *hētis* które [[G3748]] WTR-NSF **επι** *epi* na [[G1909]] [[PREP]] **κρειττοσιν** *kreittosin* lepszych – znaczniejszych [[G2909]] WTA-DPF **επαγγελιαις** *epangeliais* obietnicach [[G1860]] WTN-DPF **νενομοθετηται** *nenomothetētai* ma otrzymane Prawo – ma ustanowione Prawo [[G3549]] WTV-RPI-3S
###### **Hbr 8,7**
 **ει** *ei* Jeśli [[G1487]] WTCOND **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **πρωτη** *prōtē* pierwsze [[G4413]] WTA-NSF **εκεινη** *ekeinē* to [[G1565]] WTD-NSF **ην** *ēn* było [[G2258]] [[V-IXI-3S]] **αμεμπτος** *amemptos* nienaganne [[G273]] WTA-NSF **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **αν** *an* (kiedy)kolwiek [[G302]] WTPRT **δευτερας** *deuteras* drugiego [[G1208]] WTA-GSF **εζητειτο** *ezēteito* było szukane [[G2212]] WTV-IPI-3S **τοπος** *topos* miejsce [[G5117]] [[N-NSM]]
###### **Hbr 8,8**
 **μεμφομενος** *memfomenos* zarzucając – obwiniając [[G3201]] WTV-PNP-NSM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **αυτοις** *autois* im [[G846]] WTP-DPM **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **ημεραι** *hēmerai* dni [[G2250]] [[N-NPF]] **ερχονται** *erchontai* przychodzą [[G2064]] WTV-PNI-3P **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **συντελεσω** *syntelesō* spełnię [[G4931]] WTV-FAI-1S **επι** *epi* na [[G1909]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **οικον** *oikon* dom [[G3624]] [[N-ASM]] **ισραηλ** *israēl* Izraela – [ten, który walczył z Bogiem] [[G2474]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **επι** *epi* na [[G1909]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **οικον** *oikon* dom [[G3624]] [[N-ASM]] **ιουδα** *iouda* Judy – [wielbić] [[G2448]] [[N-GSM]] **διαθηκην** *diathēkēn* przymierze [[G1242]] WTN-ASF **καινην** *kainēn* nowe [[G2537]] WTA-ASF
###### **Hbr 8,9**
 **ου** *ou* nie [[G3756]] [[PRT-N]] **κατα** *kata* według [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **διαθηκην** *diathēkēn* przymierza [[G1242]] WTN-ASF **ην** *hēn* które [[G3739]] WTR-ASF **εποιησα** *epoiēsa* uczyniłem [[G4160]] WTV-AAI-1S **τοις** *tois* [[G3588]] WTT-DPM **πατρασιν** *patrasin* ojcom [[G3962]] WTN-DPM **αυτων** *autōn* ich [[G846]] WTP-GPM **εν** *en* w [[G1722]] [[PREP]] **ημερα** *hēmera* dniu [[G2250]] [[N-DSF]] **επιλαβομενου** *epilabomenou* chwyciwszy [[G1949]] WTV-2ADP-GSM **μου** *mou* mi [[G3450]] WTP-1GS **της** *tēs* [[G3588]] [[T-GSF]] **χειρος** *cheiros* rękę [[G5495]] [[N-GSF]] **αυτων** *autōn* ich [[G846]] WTP-GPM **εξαγαγειν** *eksagagein* (by) wyprowadzić [[G1806]] [[V-2AAN]] **αυτους** *autous* ich [[G846]] [[P-APM]] **εκ** *ek* z [[G1537]] [[PREP]] **γης** *gēs* ziemi [[G1093]] [[N-GSF]] **αιγυπτου** *aigyptou* egipskiej – [lud Nilu] [[G125]] [[N-GSF]] **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **αυτοι** *autoi* oni [[G846]] WTP-NPM **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ενεμειναν** *enemeinan* wytrwali [[G1696]] WTV-AAI-3P **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **διαθηκη** *diathēkē* przymierzu [[G1242]] [[N-DSF]] **μου** *mou* moim [[G3450]] WTP-1GS **καγω** *kagō* i ja [[G2504]] WTP-1NS-C **ημελησα** *ēmelēsa* zaniedbałem – zlekceważyłem [[G272]] WTV-AAI-1S **αυτων** *autōn* ich [[G846]] WTP-GPM **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]]
###### **Hbr 8,10**
 **οτι** *hoti* Gdyż [[G3754]] [[CONJ]] **αυτη** *hautē* to [[G3778]] WTD-NSF **η** *hē* [[G3588]] [[T-NSF]] **διαθηκη** *diathēkē* przymierze [[G1242]] [[N-NSF]] **ην** *hēn* które [[G3739]] WTR-ASF **διαθησομαι** *diathēsomai* zawrę – ułożę sobie [[G1303]] WTV-FDI-1S **τω** *tō* (dla) [[G3588]] WTT-DSM **οικω** *oikō* domu [[G3624]] WTN-DSM **ισραηλ** *israēl* Izraela – [ten, który walczył z Bogiem] [[G2474]] [[N-PRI]] **μετα** *meta* po [[G3326]] [[PREP]] **τας** *tas* [[G3588]] WTT-APF **ημερας** *hēmeras* dniach [[G2250]] WTN-APF **εκεινας** *ekeinas* tych [[G1565]] WTD-APF **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **διδους** *didous* dając [[G1325]] [[V-PAP-NSM]] **νομους** *nomous* Prawo [[G3551]] [[N-APM]] **μου** *mou* moje [[G3450]] WTP-1GS **εις** *eis* do [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **διανοιαν** *dianoian* myśli – umysłu [[G1271]] WTN-ASF **αυτων** *autōn* ich [[G846]] WTP-GPM **και** *kai* i [[G2532]] [[CONJ]] **επι** *epi* na [[G1909]] [[PREP]] **καρδιας** *kardias* sercach [[G2588]] WTN-APF **αυτων** *autōn* ich [[G846]] WTP-GPM **επιγραψω** *epigrapsō* napiszę [[G1924]] WTV-FAI-1S **αυτους** *autous* je [[G846]] [[P-APM]] **και** *kai* i [[G2532]] [[CONJ]] **εσομαι** *esomai* będę [[G2071]] WTV-FXI-1S **αυτοις** *autois* im [[G846]] WTP-DPM **εις** *eis* za [[G1519]] [[PREP]] **θεον** *theon* Boga [[G2316]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **αυτοι** *autoi* oni [[G846]] WTP-NPM **εσονται** *esontai* będą [[G2071]] WTV-FXI-3P **μοι** *moi* Mi [[G3427]] WTP-1DS **εις** *eis* za [[G1519]] [[PREP]] **λαον** *laon* lud [[G2992]] [[N-ASM]]
###### **Hbr 8,11**
 **και** *kai* I [[G2532]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **μη** *mē* [[G3361]] [[PRT-N]] **διδαξωσιν** *didaksōsin* nauczałby [[G1321]] WTV-AAS-3P **εκαστος** *hekastos* każdy [[G1538]] [[A-NSM]] **τον** *ton* [[G3588]] [[T-ASM]] **πλησιον** *plēsion* bliźni – tuż obok [[G4139]] [[ADV]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **εκαστος** *hekastos* każdy [[G1538]] [[A-NSM]] **τον** *ton* [[G3588]] [[T-ASM]] **αδελφον** *adelfon* brat [[G80]] [[N-ASM]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **λεγων** *legōn* mówiąc [[G3004]] [[V-PAP-NSM]] **γνωθι** *gnōthi* poznaj [[G1097]] WTV-2AAM-2S **τον** *ton* [[G3588]] [[T-ASM]] **κυριον** *kyrion* Pana [[G2962]] [[N-ASM]] **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **ειδησουσιν** *eidēsousin* będą znać [[G1492]] WTV-FAI-3P **με** *me* Mnie [[G3165]] WTP-1AS **απο** *apo* od [[G575]] [[PREP]] **μικρου** *mikrou* małego [[G3398]] WTA-GSM **αυτων** *autōn* (z) nich [[G846]] WTP-GPM **εως** *heōs* aż do [[G2193]] [[CONJ]] **μεγαλου** *megalou* wielkiego [[G3173]] WTA-GSM **αυτων** *autōn* (z) nich [[G846]] WTP-GPM
###### **Hbr 8,12**
 **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **ιλεως** *hileōs* życzliwy – łaskawy [[G2436]] [[A-NSM]]-ATT **εσομαι** *esomai* będę [[G2071]] WTV-FXI-1S **ταις** *tais* (dla) [[G3588]] WTT-DPF **αδικιαις** *adikiais* niesprawiedliwości – okazów bezprawia [[G93]] WTN-DPF **αυτων** *autōn* ich [[G846]] WTP-GPM **και** *kai* i [[G2532]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPF **αμαρτιων** *hamartiōn* grzechów [[G266]] WTN-GPF **αυτων** *autōn* ich [[G846]] WTP-GPM **και** *kai* i [[G2532]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPF **ανομιων** *anomiōn* bezprawia – nieprawości [[G458]] WTN-GPF **αυτων** *autōn* ich [[G846]] WTP-GPM **ου** *ou* nie [[G3756]] [[PRT-N]] **μη** *mē* [[G3361]] [[PRT-N]] **μνησθω** *mnēsthō* zostałby przypomniany (zostałyby przypomniane) [[G3415]] WTV-APS-1S **ετι** *eti* już [[G2089]] [[ADV]]
###### **Hbr 8,13**
 **εν** *en* Podczas [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **λεγειν** *legein* mówić [[G3004]] WTV-PAN **καινην** *kainēn* nowe [[G2537]] WTA-ASF **πεπαλαιωκεν** *pepalaiōken* uznaje za przestarzałe – uczynił starym [[G3822]] WTV-RAI-3S **την** *tēn* [[G3588]] WTT-ASF **πρωτην** *prōtēn* pierwsze [[G4413]] WTA-ASF **το** *to* [[G3588]] WTT-NSN **δε** *de* zaś [[G1161]] [[CONJ]] **παλαιουμενον** *palaioumenon* które jest uznane za przestarzałe – które jest czynione starym [[G3822]] WTV-PPP-NSN **και** *kai* i [[G2532]] [[CONJ]] **γηρασκον** *gēraskon* starzejące się [[G1095]] WTV-PAP-NSN **εγγυς** *engys* blisko [[G1451]] [[ADV]] **αφανισμου** *afanismou* zaniknięcia [[G854]] [[N-GSM]]
