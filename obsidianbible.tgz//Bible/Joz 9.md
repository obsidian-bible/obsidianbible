# Joz 9 BT5
###### **Joz 9,1**
 Gdy dowiedzieli się o tym królowie zamieszkali za Jordanem, na wzgórzu, na nizinie i wzdłuż brzegu Wielkiego Morza aż do Libanu: Chittyci, Amoryci, Kananejczycy, Peryzzyci, Chiwwici i Jebusyci,
###### **Joz 9,2**
 sprzymierzyli się ze sobą, by walczyć wspólnie przeciw Jozuemu i Izraelitom.
###### **Joz 9,3**
 Również mieszkańcy Gibeonu dowiedzieli się, co Jozue uczynił z miastami Jerychem i Aj,
###### **Joz 9,4**
 i postanowili użyć podstępu. Wybrali się w drogę i zaopatrzyli się w zapasy podróżne, i wzięli na swoje osły stare wory i zużyte bukłaki na wino, podarte i powiązane.
###### **Joz 9,5**
 Na nogach mieli zdarte i połatane sandały, a na sobie – znoszone szaty. Cały ich chleb, który mieli na pożywienie, był suchy i pokruszony.
###### **Joz 9,6**
 W takim stanie przybyli do Jozuego i do obozu w Gilgal i rzekli do niego i do mężów izraelskich: «***Przybywamy z dalekiego kraju; zawrzyjcie z nami przymierze***».
###### **Joz 9,7**
 Lecz mężowie izraelscy odpowiedzieli Chiwwitom: «***A może wśród nas mieszkacie? Czyż więc możemy zawierać przymierze z wami?***»
###### **Joz 9,8**
 Oni zaś odpowiedzieli Jozuemu: «***Jesteśmy twoimi sługami***». Jozue zapytał ich: «***Kim jesteście i skąd przybywacie?***»
###### **Joz 9,9**
 Oni odrzekli: «***Z ziemi bardzo dalekiej przybywają twoi słudzy, w imię Pana, Boga twojego. Usłyszeliśmy bowiem o Jego sławie i wszystkim, co uczynił w Egipcie,***
###### **Joz 9,10**
 ***oraz o wszystkim, co uczynił dwom królom amoryckim panującym za Jordanem, Sichonowi, królowi Cheszbonu, i Ogowi, królowi Baszanu w Asztarot.***
###### **Joz 9,11**
 ***Wobec tego nasza starszyzna i wszyscy mieszkańcy naszego kraju powiedzieli nam: Weźcie ze sobą żywność na drogę, wyjdźcie im naprzeciw i powiedzcie do nich: Jesteśmy waszymi sługami, zawrzyjcie więc z nami przymierze.***
###### **Joz 9,12**
 ***Oto nasz chleb: był jeszcze ciepły, gdy braliśmy go z domów naszych na drogę, w dniu, w którym wyszliśmy, by was spotkać, a oto teraz suchy i pokruszony.***
###### **Joz 9,13**
 ***A te bukłaki na wino były nowe, gdyśmy je napełniali, a oto popękały; nasze szaty i nasze sandały zupełnie się zdarły w dalekiej podroży***».
###### **Joz 9,14**
 Mężowie spróbowali ich zapasów podróżnych, lecz wyroczni Pana nie pytali.
###### **Joz 9,15**
 Zgodził się więc Jozue na pokój z nimi i zawarł z nimi przymierze, zapewniając im życie, a książęta społeczności potwierdzili je przysięgą.
###### **Joz 9,16**
 Trzy dni upłynęły od zawarcia tego przymierza, gdy usłyszano, że byli ludem sąsiednim i mieszkali wśród Izraela.
###### **Joz 9,17**
 Wyruszyli synowie Izraela z obozu i po trzech dniach przybyli do ich miast. Miastami ich były: Gibeon, Kefira, Beerot i Kiriat-Jearim.
###### **Joz 9,18**
 Izraelici nie natarli na nich, ponieważ książęta społeczności przysięgli im na Pana, Boga Izraela. Ale cała społeczność szemrała przeciw książętom.
###### **Joz 9,19**
 Wszyscy książęta oświadczyli wobec całej społeczności: «***Skoro złożyliśmy im przysięgę na Pana, Boga Izraela, przeto nie możemy im uczynić krzywdy.***
###### **Joz 9,20**
 ***Tak więc chcemy z nimi postąpić: musimy darować im życie, aby nie spadł na nas gniew z powodu przysięgi, którą im złożyliśmy***».
###### **Joz 9,21**
 Wtedy zapewnili ich książęta, że zostaną przy życiu, ale będą rąbać drzewa i nosić wodę dla całej społeczności. Gdy książęta im to oświadczyli,
###### **Joz 9,22**
 zawezwał ich Jozue i rzekł im: «***Dlaczego oszukaliście nas, mówiąc: Mieszkamy od was bardzo daleko – podczas gdy mieszkacie wśród nas?***
###### **Joz 9,23**
 ***Dlatego będziecie przeklęci i dlatego nikt z was nie przestanie być niewolnikiem, drwalem i noszącym wodę dla domu Boga mojego***».
###### **Joz 9,24**
 Wtedy dali Jozuemu taką odpowiedź: «***Słudzy twoi dokładnie się dowiedzieli o tym, co rozkazał Pan, Bóg twój, swemu słudze, Mojżeszowi: oddanie wam całej tej ziemi i wytracenie wszystkich mieszkańców kraju sprzed waszego oblicza. Obawiając się więc bardzo o nasze życie, postąpiliśmy w ten właśnie sposób.***
###### **Joz 9,25**
 ***Jesteśmy teraz w twoim ręku: uczyń z nami to, co wydaje ci się dobre i słuszne***».
###### **Joz 9,26**
 I Jozue tak postąpił z nimi. Wybawił ich z rąk Izraelitów, żeby ich nie pozbawili życia.
###### **Joz 9,27**
 Wówczas uczynił ich Jozue drwalami i noszącymi wodę dla całej społeczności i dla ołtarza Pańskiego, aż po dzień dzisiejszy, na każdym miejscu, które [Pan] wybierze.
# Joz 9 PAU
###### **Joz 9,1**
 Gdy się o tym dowiedzieli wszyscy królowie zamieszkali za Jordanem, w okolicach górzystych, nizinnych i na całym wybrzeżu Wielkiego Morza aż po Liban: Chetyci, Amoryci, Kananejczycy, Peryzzyci, Chiwwici i Jebusyci,
###### **Joz 9,2**
 połączyli się, aby wspólnie walczyć przeciwko Jozuemu i Izraelowi.
###### **Joz 9,3**
 Kiedy więc mieszkańcy Gabaonu dowiedzieli się, co Jozue zrobił z miastami Jerycho i Aj,
###### **Joz 9,4**
 uciekli się do podstępu. Wybrali się w drogę, zaopatrując się w żywność. Włożyli na osły stare wory i zużyte worki skórzane na wino, podarte i połatane.
###### **Joz 9,5**
 Na nogach mieli zniszczone i połatane sandały, na sobie stare ubrania, a cały zapas chleba, w który byli zaopatrzeni, był suchy i pokruszony.
###### **Joz 9,6**
 Przybyli do Jozuego, do obozu w Gilgal, i powiedzieli do niego i do Izraelitów: „Przybywamy z dalekiego kraju. Zawrzyjcie teraz z nami przymierze”.
###### **Joz 9,7**
 Izraelici odpowiedzieli Chiwwitom: „A może wy mieszkacie wśród nas? Jakże więc mamy zawrzeć z wami przymierze?”.
###### **Joz 9,8**
 Odpowiedzieli Jozuemu: „Jesteśmy twoimi sługami”. Jozue ich zapytał: „Kim jesteście i skąd przybywacie?”.
###### **Joz 9,9**
 Odpowiedzieli mu: „Twoi słudzy przybywają z bardzo dalekiego kraju, ze względu na imię PANA, Boga twojego. Dotarła bowiem do nas wieść o Nim, o wszystkim, co uczynił w Egipcie,
###### **Joz 9,10**
 i o tym, co zrobił obydwu królom amoryckim za Jordanem: Sichonowi, królowi Cheszbonu, i Ogowi, królowi Baszanu, który mieszkał w Asztarot.
###### **Joz 9,11**
 Starsi i wszyscy mieszkańcy naszego kraju polecili nam: «Zaopatrzcie się w żywność na drogę i idźcie im naprzeciw. Powiedzcie im: Jesteśmy waszymi sługami. Zawrzyjcie teraz z nami przymierze».
###### **Joz 9,12**
 Zapas chleba, który wzięliśmy z naszych domów, był jeszcze ciepły, gdyśmy do was wyruszali. A oto teraz jest suchy i pokruszony.
###### **Joz 9,13**
 Worki skórzane na wino, gdy je napełnialiśmy, były nowe, a teraz są podarte. Także nasze ubrania i sandały zniszczyły się podczas bardzo długiej podróży”.
###### **Joz 9,14**
 Wtedy mężczyźni przyjęli od nich zapasy, lecz nie radzili się PANA.
###### **Joz 9,15**
 Jozue zapewnił im pokój i zawarł z nimi przymierze, gwarantując im życie. Także przywódcy zgromadzenia potwierdzili im to przysięgą.
###### **Joz 9,16**
 Po upływie trzech dni od zawarcia z nimi przymierza dowiedzieli się, że oni są sąsiednim ludem i mieszkają wśród nich.
###### **Joz 9,17**
 Wtedy Izraelici wyruszyli i po trzech dniach przybyli do ich miast, którymi były: Gabaon, Kefira, Beerot i Kiriat-Jearim.
###### **Joz 9,18**
 Izraelici nie wytracili ich, ponieważ przywódcy zgromadzenia złożyli im przysięgę na PANA, Boga Izraela. Jednakże całe zgromadzenie narzekało na przywódców.
###### **Joz 9,19**
 Wtedy wszyscy przywódcy powiedzieli do całego zgromadzenia: „Złożyliśmy im przysięgę na PANA, Boga Izraela, dlatego teraz nie możemy ich nawet tknąć.
###### **Joz 9,20**
 Postąpimy z nimi tak: darujemy im życie, aby nie dosięgnął nas gniew z powodu przysięgi, którą im złożyliśmy”.
###### **Joz 9,21**
 Przywódcy zadecydowali więc: „Niech pozostaną przy życiu”. Mieli natomiast rąbać drzewo i nosić wodę dla całego zgromadzenia, zgodnie z tym, co im zlecili przywódcy.
###### **Joz 9,22**
 Jozue wezwał ich i zapytał: „Dlaczego oszukaliście nas, mówiąc: «Mieszkamy od was bardzo daleko», gdy przecież mieszkacie pośród nas?
###### **Joz 9,23**
 Dlatego odtąd będziecie przeklęci. Nigdy nie przestaniecie być niewolnikami do rąbania drzewa i noszenia wody dla domu mojego Boga”.
###### **Joz 9,24**
 Odpowiedzieli Jozuemu: „Twoim sługom dokładnie opowiedziano, że PAN, twój Bóg, polecił Mojżeszowi, swojemu słudze, dać wam cały ten kraj i zgładzić przed wami wszystkich jego mieszkańców. Z waszego powodu bardzo baliśmy się o nasze życie i dlatego tak właśnie postąpiliśmy.
###### **Joz 9,25**
 Teraz jesteśmy w twoich rękach. Uczyń z nami to, co uważasz za dobre i słuszne”.
###### **Joz 9,26**
 Postąpił z nimi w ten sposób, że uwolnił ich z rąk Izraelitów, dlatego ich nie zabili.
###### **Joz 9,27**
 Tego dnia przeznaczył ich Jozue do rąbania drzewa i noszenia wody dla zgromadzenia i na potrzeby ołtarza PANA - w miejscu, które On sobie wybierze. I tak czynią oni do dziś.
# Joz 9 BP
###### **Joz 9,1**
 Gdy dowiedzieli się o tym wszyscy królowie mieszkający za Jordanem w górach, na równinie i na całym wybrzeżu Wielkiego Morza aż po Liban, a mianowicie: Chittyci, Amoryci, Kananejczycy, Peryzzyci, Chiwwici i Jebuzyci,
###### **Joz 9,2**
 połączyli się razem, by walczyć zgodnie przeciw Jozuemu i Izraelowi.
###### **Joz 9,3**
 Również i mieszkańcy Gibeonu dowiedzieli się o tym, jak postąpił Jozue z Jerychem i Aj
###### **Joz 9,4**
 i ze swej strony również uciekli się do podstępu. Wyruszyli w drogę zaopatrując się w żywność. Włożyli na osły stare wory i również stare i połatane bukłaki z winem.
###### **Joz 9,5**
 Na nogach mieli zniszczone i połatane sandały, stare odzienie na sobie, a wszystek chleb stanowiący pożywienie w czasie drogi był suchy i pokruszony.
###### **Joz 9,6**
 Przybyli do Jozuego, do obozu w Gilgal, i zwrócili się do niego i do mężów izraelskich tymi słowy: Przychodzimy z dalekiego kraju; zawrzyjcie z nami przymierze.
###### **Joz 9,7**
 Mężowie izraelscy oświadczyli jednak Chiwwitom: Któż to wie, czy nie mieszkacie w pobliżu nas, jakże więc możemy zawierać z wami przymierze?
###### **Joz 9,8**
 Odpowiedzieli na to Jozuemu: Jesteśmy twoimi sługami. Zapytał ich Jozue: Kim jesteście i skąd przybywacie?
###### **Joz 9,9**
 Odpowiedzieli mu: Z bardzo odległego kraju przybyli słudzy twoi dla Imienia Jahwe, twojego Boga. Doszła do nas bowiem wieść o Jego sławie i o wszystkim, czego dokonał w Egipcie,
###### **Joz 9,10**
 oraz o tym, co uczynił dwom amoryckim królom z tamtej strony Jordanu: Sichonowi, królowi Cheszbonu, i Ogowi, królowi Baszanu, który przebywał w Asztarot.
###### **Joz 9,11**
 Rzekli więc do nas starsi i wszyscy mieszkańcy ziemi naszej: "Weźcie ze sobą żywność na drogę, a idźcie naprzeciw nich i powiedzcie: "Sługami waszymi jesteśmy - zawrzyjcie z nami przymierze!
###### **Joz 9,12**
 Oto chleb nasz; gdyśmy go brali z domu jako zapas na drogę w dniu, w którym wyruszyliśmy do was, był jeszcze ciepły, a oto teraz jest suchy i pokruszony.
###### **Joz 9,13**
 Również te bukłaki na wino były zupełnie nowe, gdyśmy je napełniali, teraz zaś są podarte, a nasza odzież i sandały zupełnie się zniszczyły z powodu długiej drogi"".
###### **Joz 9,14**
 Przyjęli od nich mężowie nieco z zapasów żywności nie zwracając się o radę do Jahwe.
###### **Joz 9,15**
 Zgodził się więc Jozue na pokój i zawarł z nimi przymierze zapewniając im życie, a naczelnicy zgromadzenia potwierdzili to przysięgą.
###### **Joz 9,16**
 Po trzech dniach od zawarcia z nimi przymierza wyszło na jaw, że pochodzili oni z pobliskich stron i [właściwie] pośrodku nich zamieszkiwali.
###### **Joz 9,17**
 Ruszyli tedy Izraelici w drogę i na trzeci dzień dotarli do ich miast; a były to: Gibeon, Kefira, Beerot i Kirjat-Jearim.
###### **Joz 9,18**
 Nie wytracili ich z powodu przysięgi, którą na Jahwe, Boga Izraela, złożyli przełożeni zgromadzenia, ale cała społeczność szemrała przeciw przełożonym.
###### **Joz 9,19**
 I rzekli wszyscy przełożeni do całego zgromadzenia: "Ponieważ przysięgliśmy im na Jahwe, Boga Izraela, nie możemy ich teraz tknąć,
###### **Joz 9,20**
 ale tak z nimi postąpimy: zostawimy ich przy życiu i nie spadnie na nas gniew [Jahwe] z powodu przysięgi, którą im złożyliśmy".
###### **Joz 9,21**
 Oświadczyli im więc naczelnicy, że zostaną przy życiu. Będą jednak na potrzeby całej społeczności rąbać drzewo i nosić wodę. Gdy im to przełożeni zgromadzenia oznajmili,
###### **Joz 9,22**
 wezwał ich Jozue i rzekł do nich: Czemuście nas oszukali mówiąc: Bardzo daleko od was mieszkamy, gdy pośród nas przecież macie swoje siedziby?
###### **Joz 9,23**
 Dlatego jesteście przeklęci i na zawsze pozostaniecie niewolnikami rąbiącymi drzewo i noszącymi wodę dla Domu Boga mojego.
###### **Joz 9,24**
 Odpowiedzieli Jozuemu tymi słowy: Oznajmiono dokładnie sługom twoim, że Jahwe, twój Bóg, nakazał swojemu słudze Mojżeszowi dać wam cały kraj i wytracić przed wami wszystkich jego mieszkańców. Ogarnął nas wielki strach przed wami i dlatego tak postąpiliśmy.
###### **Joz 9,25**
 Teraz jednak jesteśmy w twojej mocy, postąp z nami tak, jak to sam uznasz za dobre i sprawiedliwe.
###### **Joz 9,26**
 Postąpił więc z nimi w ten sposób: uwolnił ich z rąk Izraelitów, tak że ich nie wymordowali.
###### **Joz 9,27**
 Od tego dnia jednak przeznaczył ich Jozue do rąbania drzewa i noszenia wody dla całej społeczności i na [potrzeby] ołtarza Jahwe na miejscu, które On sam wyznaczy. I tak czynią po dzień dzisiejszy.
# Joz 9 BR
###### **Joz 9,1**
 Na wieść o tych wydarzeniach wszyscy królowie po drugiej stronie Jordanu, z gór i okolic nizinnych, a zwłaszcza z krajów nadmorskich, położonych naprzeciw Libanu, czyli Chetyci, Amoryci, Kananejczycy, Peryzzyci, Chiwwici oraz Jebuzyci,
###### **Joz 9,2**
 połączyli się i zawarli układ, aby walczyć przeciwko Jozuemu i synom Izraela.
###### **Joz 9,3**
 Mieszkańcy Gibeonu, dowiedziawszy się, jak Jozue postąpił pod Jerycho i Aj,
###### **Joz 9,4**
 posłużyli się pewnym podstępem. Wyprawili się mianowicie w [rzekomo długą] podróż, biorąc ze sobą zapasy żywności. Na swoje osły załadowali stare worki oraz zużyte już, podziurawione bukłaki na wino.
###### **Joz 9,5**
 Na nogi założyli stare, połatane sandały, a na siebie bardzo znoszone już ubrania. Chleb, który ze sobą mieli i który służył im za jedyne pożywienie, był wyschnięty i pokruszony.
###### **Joz 9,6**
 Stawili się przed Jozuem w obozie w Gilgal i oświadczyli jemu oraz wszystkim synom Izraela: Przychodzimy do was z bardzo odległej krainy i chcielibyśmy zawrzeć z wami przymierze.
###### **Joz 9,7**
 Na to Izraelici odpowiedzieli Chiwwitom: A może wy mieszkacie wśród nas [ w naszym kraju]? Jakże więc moglibyśmy zawierać z wami przymierze?
###### **Joz 9,8**
 Rzekli tedy do Jozuego: Jesteśmy twoimi sługami. Zapytał ich więc Jozue: Kim [naprawdę] jesteście i skąd przychodzicie?
###### **Joz 9,9**
 A oni odpowiedzieli: Z bardzo odległej krainy przychodzą twoi słudzy ze względu na imię Jahwe, twojego Boga. Wiele bowiem słyszeliśmy o Nim;
###### **Joz 9,10**
 o tym, co uczynił w Egipcie i jak postąpił z dwoma królami amoryckimi po drugiej stronie Jordanu, to znaczy z Sichonem, królem Cheszbonu, i z Ogiem, królem Baszanu, w Asztarot.
###### **Joz 9,11**
 Nasi starsi i wszyscy mieszkańcy naszego kraju postanowili, żebyśmy się zaopatrzyli na drogę, przyszli do was i powiedzieli wam: Jesteśmy waszymi sługami i chcielibyśmy zawrzeć z wami przymierze.
###### **Joz 9,12**
 Oto nasz chleb: kiedy w naszych domach przygotowywaliśmy się do drogi, aby wyruszyć wam na spotkanie, był jeszcze gorący; teraz się zsechł i zamienił w okruchy.
###### **Joz 9,13**
 Podobnie i te bukłaki na wino, kiedyśmy je napełniali, były całkiem nowe, a teraz są już podarte. Nasze ubrania i sandały zużyły się już całkowicie wskutek tej długiej podróży.
###### **Joz 9,14**
 Przyjęli tedy Izraelici coś z ich zapasów podróżnych, lecz nie zapytali przedtem o radę Jahwe.
###### **Joz 9,15**
 Jozue zgodził się też na pokój i zawarł z nimi przymierze, przyrzekając darowanie im życia. Przełożeni całego zgromadzenia potwierdzili to przysięgą.
###### **Joz 9,16**
 W trzy dni po zawarciu przymierza synowie Izraela dowiedzieli się, że tamci są ich sąsiadami i że mieszkają wśród nich.
###### **Joz 9,17**
 Wyruszyli tedy synowie Izraela w drogę i trzeciego dnia dotarli do ich miast. Były to: Gibeon, Kefira, Beerot i Kiriat-Jearim.
###### **Joz 9,18**
 Nie zaatakowali ich mieczem, pamiętając o przysiędze, którą - w imieniu Jahwe, Boga Izraela - złożyli przełożeni zgromadzenia. Ale całe zgromadzenie zaczęło szemrać przeciwko przełożonym.
###### **Joz 9,19**
 Wtedy wszyscy przełożeni powiedzieli tak do całego zgromadzenia: Daliśmy im przyrzeczenie, przysięgając na Jahwe, Boga Izraela, i dlatego nie możemy ich teraz tknąć.
###### **Joz 9,20**
 Musimy ich zatem zostawić przy życiu, jeśli nie chcemy na nas samych ściągnąć gniewu Jahwe ze względu na złożoną przysięgę.
###### **Joz 9,21**
 Niech więc żyją - powiedzieli przełożeni zgromadzenia. I zatrudniono ich przy ścinaniu drzewa i czerpaniu wody dla całego zgromadzenia zgodnie z poleceniem przełożonych.
###### **Joz 9,22**
 Wezwał Jozue Gibeonitów i tak do nich przemówił: Dlaczego nas oszukaliście, mówiąc, że przychodzicie z bardzo daleka, a tymczasem mieszkacie wśród nas?
###### **Joz 9,23**
 Od tej chwili będziecie przeklęci. Każdy z was będzie niewolnikiem pracującym przy wycinaniu drzew i czerpaniu wody dla domu Boga.
###### **Joz 9,24**
 Na to oni odrzekli Jozuemu: Sługom twoim doniesiono, że według rozkazu, jaki Jahwe, twój Bóg, wydał słudze swojemu, Mojżeszowi, cały ten kraj został oddany w wasze ręce, a wszyscy mieszkańcy żyjący tu przed wami, są skazani na wytracenie. Kiedyście się do nas zbliżali, zaczęliśmy drżeć o nasze życie. I dlatego postąpiliśmy w taki sposób.
###### **Joz 9,25**
 Teraz jesteśmy w twoich rękach. Postąp z nami tak, jak uznasz za dobre i sprawiedliwe.
###### **Joz 9,26**
 I postąpił z nimi Jozue tak, jak zapowiedział: uwolnił ich z rąk synów Izraela, żeby nie musieli zginąć.
###### **Joz 9,27**
 Przeznaczył ich [jednak] Jozue od tego dnia do pracy przy ścinaniu drzew i czerpaniu wody dla całego zgromadzenia i dla ołtarza Jahwe w miejscach, które wybrał sobie Jahwe, co też czynią jeszcze dzisiaj.
# Joz 9 WUJ
###### **Joz 9,1**
 Co gdy usłyszeli, wszyscy królowie za Jordanem, którzy mieszkali po górach i po polach na pomorzu i brzegu wielkiego morza, ci też którzy mieszkali przy Libanie, Hetejczyk i Amorrejczyk, Chananejczyk, Pherezejczyk i Hewejczyk, i Jebuzejczyk,
###### **Joz 9,2**
 Zebrali się pospołu, aby walczyli przeciw Jozuemu i Izraelowi jednem sercem i jedną wolą.
###### **Joz 9,3**
 Ale ci, którzy mieszkali w Gabaonie, słysząc wszystko co uczynił Jozue, Jerycho i Hay:
###### **Joz 9,4**
 I chytrze myśląc nabrali sobie żywności, stare wory na osły włożywszy, i łagwice skórzane winne podarte i pozszywane,
###### **Joz 9,5**
 I boty barzo wiotche, które na znak starości łatami zszyte były, obleczeni w odzienie stare: chleb też, który na podróżną strawę nieśli, był twardy, i w kęsy podrobiony:
###### **Joz 9,6**
 I przyszli do Jozuego, który na ten czas mieszkał w obozie w Galgali, i rzekli mu i społem wszystkiemu Izraelowi: Z dalekiej ziemie przyszliśmy, pokój z wami uczynić pragnąc. I odpowiedzieli mężowie Izraelscy do nich i rzekli:
###### **Joz 9,7**
 Byście snać w ziemi, która nam losem należy nie mieszkali, i niemoglibyśmy z wami przymierza uczynić.
###### **Joz 9,8**
 A oni do Jozuego: Słudzy, pry, twoi jesteśmy. Którym rzekł Jozue: Coście wy wżdy zacz? i zkądeście przyszli?
###### **Joz 9,9**
 Odpowiedzieli: Z ziemie barzo dalekiej przyszli słudzy twoi do ciebie w imię Pana Boga twego: Bośmy słyszeli sławę mocy jego, wszystko co uczynił w Egiptcie.
###### **Joz 9,10**
 I dwiema królom Amorrejczyków, którzy byli za Jordanem, Sehonowi królowi Hesebon, i Og królowi Bazan, który był w Astaroth:
###### **Joz 9,11**
 I rzekli nam starszy i wszyscy obywatele ziemie naszej: Weźmicie w ręce żywności dla barzo dalekiej drogi, a zabieżcie im i mówcie: Słudzy waszy jesteśmy, uczyńcie z nami przymierze.
###### **Joz 9,12**
 Oto chleb, gdyśmy wyszli z domów naszych, żebyśmy szli do was, ciepłyśmy wzięli, teraz się zsechł i pokruszył się od wielkiej starości.
###### **Joz 9,13**
 Łagwice winne noweśmy napełnili, teraz się popękały, i popruły szaty, i boty któreśmy oblekli, i które na nogach mamy, dla dalekości dłuższej drogi wytarły się, a ledwie nie obleciały.
###### **Joz 9,14**
 Przyjęli tedy z żywności ich, a ust się Pańskich nie pytali.
###### **Joz 9,15**
 I uczynił Jozue z nimi pokój, i postanowiwszy przymierze obiecał, że nie mieli być pobici: Książęta też ludu przysięgli im.
###### **Joz 9,16**
 A po trzech dniach po uczynieniu przymierza, usłyszeli, że blizko mieszkali, a między nimi być mieli.
###### **Joz 9,17**
 I ruszyli obóz synowie Izraelscy, i przyciągnęli do ich miast trzeciego dnia, których te są imiona: Gabaon, i Kaphira, i Beroth, i Kariathiarim.
###### **Joz 9,18**
 I niepobili ich, przeto, że im byli przysięgli książęta ludu w imię Pana Boga Izraelskiego. Szemrał tedy wszystek gmin przeciw książętom.
###### **Joz 9,19**
 Którzy im odpowiedzieli: Przysięgliśmy im w imię Pana Boga Izraelowego, a przeto się ich tknąć nie możemy.
###### **Joz 9,20**
 Ale to im uczynimy: Niech zachowani będą, aby żyli, by się na nas gniew Pański nie wzruszył, jeślibyśmy krzywoprzysięgli:
###### **Joz 9,21**
 Ale tak, niech żywo zostaną, aby na potrzeby wszystkiego pospólstwa drwa rąbali i wodę nosili. A gdy to mówili,
###### **Joz 9,22**
 Zawołał Jozue Gabaonczyków, i rzekł im: Czemuście nas zdradą oszukać chcieli, żeście powiedzieli: barzo daleko od was mieszkamy, gdyż w pośrodku nas jesteście?
###### **Joz 9,23**
 A przetoż pod przeklęctwem będziecie, a nie ustanie z narodu waszego drwa rąbiący, i wodę noszący do domu Boga mego.
###### **Joz 9,24**
 Którzy odpowiedzieli: Oznajmiono nam sługom twoim, że obiecał Pan Bóg twój Mojżeszowi słudze swemu, żeby podał wam wszystkę ziemię, i wytracił wszystkie obywatele jej. Zlękliśmy się tedy barzo, i opatrzyliśmy dusze nasze, waszym strachem przypędzeni, i rady użyli.
###### **Joz 9,25**
 A teraz w ręce twojej jesteśmy, coć się zda dobrego i słusznego, czyń z nami.
###### **Joz 9,26**
 Uczynił tedy Jozue jako był rzekł, i wybawił je z ręku synów Izraelowych, żeby ich nie pobito.
###### **Joz 9,27**
 I postanowił onego dnia, aby oni byli na posłudze wszystkiego ludu i ołtarza Pańskiego, rąbiąc drwa i wodę nosząc, aż do teraźniejszego czasu, na miejscu któreby był Pan obrał.
