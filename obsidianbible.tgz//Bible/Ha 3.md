# Ha 3 BT5
###### **Ha 3,1**
 Modlitwa błagalna proroka Habakuka, na wzór lamentacji.
###### **Ha 3,2**
 Usłyszałem, o Panie, Twoje orędzie, uląkłem się, o Panie, Twego dzieła.W pośrodku lat niech one żyją, w pośrodku lat pozwól nam je poznać, w czasie niepokojów pomnij na swą litość!
###### **Ha 3,3**
 Bóg przychodzi z Temanu, Święty z góry Paran. <Sela <Majestat Jego okrywa niebiosa, a ziemia pełna jest Jego chwały.
###### **Ha 3,4**
 Wspaniałość Jego podobna do światła, promienie z rąk Jego tryskają, w nich to ukryta moc Jego.
###### **Ha 3,5**
 Przed Nim idzie zaraza, w ślad za Nim gorączka śmiertelna.
###### **Ha 3,6**
 Stanął i porozdzielał ziemię,spojrzał i sprawił, że zadrżały narody; rozpadają się góry prastare, zapadają pagórki odwieczne, te ścieżki Jego od pradawnych czasów.
###### **Ha 3,7**
 Widziałem klęską dotknięte mieszkania Kuszanu, chwiejące się namioty w ziemi Madian.
###### **Ha 3,8**
 Czy na rzeki rozgniewałeś się, Panie?Czy Twój gniew [wybuchł] na rzeki?Czy na morze – Twoja zapalczywość, że wsiadasz na swoje konie, na swe rydwany zwycięskie?
###### **Ha 3,9**
 Łuk Twój obnażony, a słowa [Twojej] przysięgi – to strzały, Seladla rzek otwierasz ziemię.
###### **Ha 3,10**
 Ujrzały cię góry, zadrżały. Trąba wodna się przewaliła. Wielka zaryczała Otchłań, wysoko uniosła swe ręce.
###### **Ha 3,11**
 Słońce i księżyc stoją w swoim miejscuz powodu blasku lecących Twych strzałi jasnego lśnienia Twej dzidy.
###### **Ha 3,12**
 Rozgniewany kroczysz po ziemi, w zapalczywości swej depczesz narody.
###### **Ha 3,13**
 Wyszedłeś, aby swój lud ocalić, aby wybawić swego pomazańca.Zburzyłeś dom bezbożnego, odsłoniłeś fundament aż do nagiej skały. Sela
###### **Ha 3,14**
 Przeszyłeś ich własnymi strzałami wodza ich wojska, gdy naciera, aby mnie rozproszyć. Triumf ich – jak tego, co potajemnie niszczy biedaka.
###### **Ha 3,15**
 W morze wdeptałeś jego konie, w kipiącą topiel wód mnogich.
###### **Ha 3,16**
 Usłyszałem, i łono moje zadrżało, na głos ten zadrżały me wargi, przeniknęła trwoga me kości, kroki się moje zachwiały.W spokoju jednak wyglądam dnia utrapienia, który nadchodzi na lud, co nas gnębi.
###### **Ha 3,17**
 Wprawdzie figowiec nie rozwija pąków, nie przynoszą plonu winnice, zawiódł owoc oliwek, a pola nie dają żywności, choć trzody owiec znikają z owczarnii nie ma wołów w zagrodach.
###### **Ha 3,18**
 Ja mimo to w Panu będę się radować, weselić się będę w Bogu, moim Zbawicielu.
###### **Ha 3,19**
 Pan Bóg – moją siłą; uczyni nogi moje podobne nogom jelenia, wprowadzi mnie na wyżyny.Habakuka Kierownikowi chóru. Na instrumenty strunowe.
# Ha 3 PAU
###### **Ha 3,1**
 Modlitwa proroka Habakuka na wzór lamentacji.
###### **Ha 3,2**
 Usłyszałem, PANIE, Twoje orędzie, ujrzałem, PANIE, Twoje dzieło. Spraw, by się spełniło w nadchodzących latach, daj nam je poznać w jak najbliższym czasie, a gdy się gniewasz, wspomnij na swoje miłosierdzie!
###### **Ha 3,3**
 Bóg przybywa z Temanu. Święty nadchodzi od gór Paran. Jego majestat okrywa niebiosa, a Jego chwała napełnia ziemię. Sela
###### **Ha 3,4**
 Jaśnieje On blaskiem słońca, z Jego rąk wychodzą promienie, w nich Jego moc jest ukryta.
###### **Ha 3,5**
 Przed Nim idzie zaraza, a za Nim pomór śmiertelny.
###### **Ha 3,6**
 Kiedy On wstaje - ziemia się trzęsie, a kiedy spojrzy - drżą przed Nim narody. Prastare góry się rozsypują, zapadają się odwieczne wzgórza, a Jego drogi trwają od pradawnych czasów.
###### **Ha 3,7**
 Ujrzałem powalone namioty Kuszanu, drżące szałasy ziemi Madianu.
###### **Ha 3,8**
 Czy przeciw rzekom wybuchł gniew Twój, PANIE, czy przeciw morzu - Twoje oburzenie, że swoich koni dosiadasz i wstępujesz na rydwan zwycięski?
###### **Ha 3,9**
 Dobyłeś bowiem swojego łuku, a kołczan napełniłeś strzałami. Ziemia pęka i wzbierają rzeki.
###### **Ha 3,10**
 Ujrzały Cię góry i zadrżały, lunął deszcz rzęsisty. Otchłań wód swój głos wydała, podniosła w górę swoje ręce.
###### **Ha 3,11**
 Nie było widać słońca ani księżyca, przyćmionych blaskiem strzał Twoich, straszliwym błyskiem Twojego oszczepu.
###### **Ha 3,12**
 Pełen gniewu kroczysz przez ziemię, w swoim oburzeniu tratujesz narody.
###### **Ha 3,13**
 Wyruszyłeś, by swój lud ratować, aby ocalić swojego pomazańca. Zburzyłeś dom bezbożnika, odsłoniłeś fundamenty aż do skały. Sela
###### **Ha 3,14**
 Przeszyłeś strzałami dowódcę wojska, gdy nacierało, aby nas wyniszczyć, gdy się cieszyło, pełne zuchwalstwa, jak ten, co w ukryciu pożera biednego.
###### **Ha 3,15**
 Twoje konie przeprowadziłeś przez morze, przez spienioną topiel wód ogromnych.
###### **Ha 3,16**
 Gdy to usłyszałem, struchlało we mnie serce, na ten głos zadrżały moje wargi, trwoga przeniknęła me kości, nogi ugięły się pode mną. Spokojnie jednak czekam na dzień klęski, która spadnie na lud, co nas gnębi.
###### **Ha 3,17**
 Chociaż figowiec nie kwitnie i nie ma co zbierać w winnicach; chociaż oliwki nie mają owoców, pola uprawne nie dają żywności; choć w owczarniach pusto, brak owiec i nie ma wołów w zagrodach -
###### **Ha 3,18**
 ja mimo to będę się radował w PANU i weselił się w Bogu, moim Zbawcy.
###### **Ha 3,19**
 PAN BÓG, który jest moją siłą, uczyni me nogi podobnymi do nóg jelenia i na wyżyny mnie wprowadzi! Kierownikowi chóru, na instrumenty strunowe.
# Ha 3 BP
###### **Ha 3,1**
 Modlitwa proroka Habakuka. Na sposób trenów.
###### **Ha 3,2**
 Jahwe, usłyszałem Twoją zapowiedź i lęk mnie ogarnął, o Jahwe, przed dziełem Twoim. Zechciej je ziścić w nadchodzących latach, objaw je w latach najbliższych; w gniewie swym [jednak] pomnij na miłosierdzie.
###### **Ha 3,3**
 Bóg przychodzi od strony Temanu, Święty od strony gór Paran. Pauza Majestat Jego okrywa niebiosa, ziemia jest pełna jego chwały.
###### **Ha 3,4**
 Bije od Niego blask jak jasność słońca, otaczają Go promienie, w których się kryje jego moc.
###### **Ha 3,5**
 Wyprzedza Go pomór, a w ślad za Jego krokami idzie zaraza.
###### **Ha 3,6**
 Przystaje, by zmierzyć [wzrokiem] ziemię; spojrzenie Jego lękiem napawa narody. Kruszą się góry wieczyste, zapadają się prastare wzgórza wzdłuż odwiecznych Jego dróg.
###### **Ha 3,7**
 Powalone leżą namioty w Kuszan, chwieją się szałasy w Midian.
###### **Ha 3,8**
 Czyś zapłonął gniewem, o Jahwe, na nurty wód, czy zapalczywość Twoja zwraca się przeciw odmętom morskim, że pędzisz na swych rumakach, na swych zwycięskich rydwanach?
###### **Ha 3,9**
 Łuk Twój odsłonięty, kołczan Twój napełniony strzałami. Pauza Rozrywasz ziemię rzekami,
###### **Ha 3,10**
 góry drżą na Twój widok. Chmury wylewają strugi wód, odwieczna toń rozbrzmiewa szumem i wyciąga wysoko ramiona.
###### **Ha 3,11**
 Słońce i księżyc zostają w swej siedzibie wobec błysku twych strzał pędzących, wobec blasku Twej błyszczącej włóczni.
###### **Ha 3,12**
 W gniewie swym depczesz ziemię, w zapalczywości swej miażdżysz narody.
###### **Ha 3,13**
 Wyruszyłeś, by nieść pomoc swemu ludowi, by ratować swego pomazańca. Rozwalasz dom bezbożnika, odsłaniasz fundamenty aż do samej opoki. Pauza
###### **Ha 3,14**
 Strzałami swymi przeszywasz jego głowę; rozpierzchli się jak plewy jego książęta, którzy się cieszyli, gdy mnie ścigali, gdy pożerali nieszczęśnika w [swej] kryjówce.
###### **Ha 3,15**
 Wpędziłeś jego konie w morze, w błoto wielkich wód.
###### **Ha 3,16**
 Usłyszałem to - i zadrżałem na całym ciele; na wieść tę usta moje poruszyły się niespokojnie, słabość ogarnęła me członki, a nogi pode mną się zachwiały. W spokoju jednak wyczekuję dnia nieszczęścia, jaki nadchodzi dla narodu, który nas ciemięży.
###### **Ha 3,17**
 Drzewo figowe nie zakwitło, winnice nie mają owoców, zbiory z drzew oliwnych zawiodły, rola nie dostarcza żadnej żywności; z zagród znikły trzody, w oborach nie ma bydła.
###### **Ha 3,18**
 Mimo to jednak będę się radował w Panu, będę się weselił w Bogu, zbawieniu moim!
###### **Ha 3,19**
 Jahwe-Pan jest moją mocą; On nogom moim użyczy chyżości nóg jelenich i pozwoli mi stąpać po wyżynach. [Uwaga] dla kierownika chóru: na instrumenty strunowe.
# Ha 3 BR
###### **Ha 3,1**
 Modlitwa proroka Habakuka wyśpiewana na melodię lamentacji.
###### **Ha 3,2**
 Panie, słyszę wszystko, co Ty mówisz, widzę to, co już wcześniej uczyniłeś. Niech za dni naszych to wszystko odżyje, okaż to wszystko nam, już w naszych czasach!
###### **Ha 3,3**
 Bóg przychodzi z Temanu, Najświętszy zbliża się od wzniesień Paranu. Jego majestat sięga samych niebios, a chwała Jego wypełnia ziemię. (Sela)
###### **Ha 3,4**
 Świeci On blaskiem samego słońca, otacza Go ze stron wszystkich świetlany wieniec, w promieniach światła kryje się moc Jego.
###### **Ha 3,5**
 Groźna zaraza posuwa się przed Nim, gorączka krok w krok idzie za Nim.
###### **Ha 3,6**
 Gdy On nadchodzi, trzęsie się cała ziemia, gdy On spogląda, drżą wszystkie narody. Rozpadają się również góry stojące od wieków, chwieją się prastare wzniesienia. (Tędy wiodą jego szlaki od dawna).
###### **Ha 3,7**
 Widzę wielkie nieszczęścia w namiotach Kuszanu, chwieją się również namioty Madianu.
###### **Ha 3,8**
 Panie, czyś zapłonął gniewem przeciw rzekom? Czy rzeczywiście na rzeki się gniewasz? Czyś zapalczywość skierował przeciw morzu i atakujesz je swymi rumakami, i w ich stronę kierujesz zwycięskie rydwany?
###### **Ha 3,9**
 Już łuku dobyłeś z ukrycia i strzały do kołczana włożyłeś. (Sela) Ziemię podzieliłeś całą i jej szczelinami płyną już strumienie.
###### **Ha 3,10**
 Góry z drżeniem spoglądają w Twą stronę, deszcze ulewne spadają na ziemię. Otchłań bezdenna głos swój wydaje i jakby w górę unosi swe ręce.
###### **Ha 3,11**
 Słońce i księżyc tkwią na swoim miejscu, ale pierzchają przed Twoich strzał blaskiem i przed światłem Twojej lśniącej włóczni.
###### **Ha 3,12**
 Kroczysz przez ziemię pełen zagniewania i w swej zapalczywości miażdżysz całe narody.
###### **Ha 3,13**
 Wyruszasz, aby Twój własny lud ocalić i aby przyjść z pomocą pomazańcowi Twemu. Dach zerwałeś z domu bezbożnika, odsłoniłeś jego fundamenty aż do samej skały (Sela)
###### **Ha 3,14**
 Strzałami przeszyłeś dowódcę ich wojska, co do walki stanęło, aby nas wygubić, i już się raduje w swojej wyniosłości,że w ukryciu swym może zniszczyć całkiem biednego.
###### **Ha 3,15**
 Rumakami szlaki poprzez morza wytknąłeś, poprzez głębokie i wzburzone wody.
###### **Ha 3,16**
 Zadrżałem na całym ciele, kiedym to usłyszał, łzy we mnie wezbrały i zaczęłem krzyczeć. Bezwład ogarnął moje kości i nogi mi się zachwiały. Lecz w spokoju czekałem na ów dzień ucisku, który miał przyjść na naród, co nas tak ciemięży.
###### **Ha 3,17**
 Drzewo figowe kwitnąć już przestało, nie ma też wcale jagód winnych do zbioru, nic się nie rodzi na drzewie oliwnym, na polach uprawnych żadne zboże nie rośnie. W zagrodzie nie ma ani jednej owcy, żadnego bydła w oborze.
###### **Ha 3,18**
 Ja jednak mimo to raduję się w Panu i cieszę się w Bogu, Zbawicielu moim.
###### **Ha 3,19**
 Bóg i Pan jest moją mocą! To On sprawił, że biegam tak szybko jak jeleń i mogę się wspinać na różne wzniesienia.
# Ha 3 WUJ
###### **Ha 3,1**
 Modlitwa Habakuka. Proroka za niewiadomości.
###### **Ha 3,2**
 Panie słyszałem słuch twój, i ulękłem się. Panie dzieło twoje w pośrodku lat ożyw je: W pośrodku lat oznajmisz: gdy się rozgniewasz, wspomnisz na miłosierdzie.
###### **Ha 3,3**
 Bóg od południa przydzie: a święty z góry Pharan. Okryła niebiosa chwała jego, a wysławiania jego pełna jest ziemia.
###### **Ha 3,4**
 Blask jego jako światłość będzie: rogi w ręku jego. Tam jest zakryta moc jego.
###### **Ha 3,5**
 Przed obliczem jego pójdzie śmierć. I wynidzie djabeł przed nogami jego.
###### **Ha 3,6**
 Stanął i rozmierzył ziemię. Pojrzał, i narody, rozwiązał i skruszone są góry wieku. Zniżyły się pagórki świata, przed drogami wieczności jego.
###### **Ha 3,7**
 Dla nieprawości widziałem namioty Murzyńskie strwożą się skóry ziemie Madian.
###### **Ha 3,8**
 Izali na rzeki rozgniewałeś się Panie? abo na rzeki zapalczywość twoja? abo na morze rozgniewanie twoje? Który wsiędziesz na konie twoje, a poczwórne twoje zbawienie.
###### **Ha 3,9**
 Wzbudzając wzbudzisz łuk twój, przysięgi pokoleniam, któreś rzekł. Rzeki przerwiesz ziemie:
###### **Ha 3,10**
 Widziały cię i bolały góry: nawałność wód przeminęła. Wydała przepaść głos swój: wysokość podniosła ręce swoje.
###### **Ha 3,11**
 Słońce i księżyc stanęły w mieszkaniu swojem, w światłości strzał twoich, pójdą w blasku błyskającej się włócznie twojej.
###### **Ha 3,12**
 W zagniewaniu podepcesz ziemię, w zapalczywości uczynisz zdumiałe narody.
###### **Ha 3,13**
 Wyszedłeś na zbawienie ludu twego: na zbawienie z Chrystusem twoim. Zbiłeś głowę z domu niezbożnego: obnażyłeś grunt jego aż do szyje.
###### **Ha 3,14**
 Przekląłeś berła jego, głowę waleczników jego, przychodzących jako wicher, aby mię rozprószyli. Radość ich jako tego, który pożera ubogiego w skrytości.
###### **Ha 3,15**
 Uczyniłeś w morzu drogę koniom twoim, na błocie wód wielkich.
###### **Ha 3,16**
 Usłyszałem, a wzruszył się żywot mój, od głosu zadrżały wargi moje. Niech wnidzie zgniłość w kości moje, a podemną niech się zamnoży. Abych odpoczął w dzień utrapienia, abych wstąpił do ludu naszego przepasanego.
###### **Ha 3,17**
 Abowiem figa nie zakwitnie, a nie będzie owoców w winnicach. Omyli robota oliwy, i pola nie dadzą żywności. Odcięty będzie z owczarniej drób: a nie będzie skotu u żłobów.
###### **Ha 3,18**
 A ja będę się w Panu radował, i będę się weselił w Bogu Jezusie moim.
###### **Ha 3,19**
 Pan Bóg jest moc moja: i postawi jako jeleń nogi moje. I po wysokościach moich poprowadzi mię zwycięzca psalmy śpiewającego.1
