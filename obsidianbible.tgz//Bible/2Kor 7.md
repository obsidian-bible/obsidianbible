# 2Kor 7 BT5
###### **2Kor 7,1**
 Mając przeto takie obietnice, najmilsi, oczyśćmy się z wszelkich brudów ciała i ducha, dopełniając uświęcenia naszego w bojaźni Bożej.
###### **2Kor 7,2**
 Otwórzcie się dla nas! Nikogośmy nie skrzywdzili, nikogo nie przywiedli do upadku, nikogo nie oszukali.
###### **2Kor 7,3**
 Nie mówię tego, żeby was potępiać. Powiedziałem już, że pozostajecie w sercach naszych na wspólną śmierć i wspólne z nami życie.
###### **2Kor 7,4**
 Z wielką ufnością odnoszę się do was, chlubię się wami bardzo. Pełen jestem pociechy, opływam w radość mimo wielkich naszych ucisków.
###### **2Kor 7,5**
 Kiedy przybyliśmy do Macedonii, nasze ciało nie doznało żadnej ulgi, lecz zewsząd byliśmy dręczeni: zewnątrz walki, wewnątrz obawy.
###### **2Kor 7,6**
 Lecz Pocieszyciel pokornych, Bóg, podniósł i nas na duchu przybyciem Tytusa.
###### **2Kor 7,7**
 Nie tylko zresztą jego przybyciem, ale i pociechą, jakiej doznał wśród was, gdy nam opowiadał o waszej tęsknocie, o waszych łzach, o waszym zabieganiu o mnie, tak że radowałem się jeszcze bardziej.
###### **2Kor 7,8**
 A chociaż może i zasmuciłem was moim listem, to nie żałuję tego; nawet zresztą gdybym i żałował, widząc, że list ów napełnił was na pewien czas smutkiem,
###### **2Kor 7,9**
 to teraz raduję się – nie dlatego, żeście się zasmucili, ale że się zasmuciliście ku nawróceniu. Zasmuciliście się bowiem po Bożemu, tak iż nie ponieśliście przez nas żadnej szkody.
###### **2Kor 7,10**
 Bo smutek, który jest z Boga, dokonuje zbawiennego nawrócenia, i tego się nie żałuje, smutek zaś tego świata powoduje śmierć.
###### **2Kor 7,11**
 To bowiem, że zasmuciliście się po Bożemu – jakąż wzbudziło w was gorliwość, obronę, oburzenie, bojaźń, tęsknotę, zapał i potrzebę wymierzenia kary! We wszystkim okazaliście się bez zarzutu.
###### **2Kor 7,12**
 Dlatego też, choć napisałem wam tak, to nie z powodu tego, który dopuścił się niesprawiedliwości, ani też przez wzgląd na pokrzywdzonego, lecz by okazać nasze wobec Boga zatroskanie o was.
###### **2Kor 7,13**
 Tak więc doznaliśmy pociechy. A radość nasza spotęgowała się jeszcze bardziej przez tę radość, jakiej doznał Tytus, przez was wszystkich podniesiony na duchu.
###### **2Kor 7,14**
 Przeto jeśli się wami chlubiłem przed nim, nie doznałem zawstydzenia. Podobnie jak wszystko mówiliśmy wam zgodnie z prawdą, tak też prawdziwa jest nasza chluba wobec Tytusa.
###### **2Kor 7,15**
 Serce zaś jego jeszcze bardziej lgnie ku wam, gdy wspomina wasze posłuszeństwo i to, jak przyjęliście go z bojaźnią i drżeniem.
###### **2Kor 7,16**
 Cieszę się, że we wszystkim mogę wam ufać.
# 2Kor 7 PAU
###### **2Kor 7,1**
 Umiłowani, skoro posiadamy takie obietnice, oczyśćmy się ze wszystkiego, co zanieczyszcza nasze ciało i ducha, i przez bojaźń Bożą doprowadźmy do końca dzieło uświęcenia.
###### **2Kor 7,2**
 Zróbcie nam miejsce w swoich sercach! Przecież nikogo nie traktowaliśmy niesprawiedliwie, nikomu nie zaszkodziliśmy, nikogo nie wykorzystaliśmy.
###### **2Kor 7,3**
 Mówię tak nie po to, by was potępiać. Powiedziałem już przedtem, że jesteście w naszych sercach na śmierć i życie.
###### **2Kor 7,4**
 Mam do was wielkie zaufanie, jestem z was bardzo dumny. Pomimo wszelkiego utrapienia napełniony jestem pocieszeniem i obfituję w radość.
###### **2Kor 7,5**
 Gdy przybyliśmy do Macedonii, nie zaznaliśmy odpoczynku, lecz utrapień z każdej strony: na zewnątrz walki, wewnątrz lęki.
###### **2Kor 7,6**
 Ale Bóg, który przychodzi z pociechą pokornym, dodał nam otuchy przez przybycie Tytusa.
###### **2Kor 7,7**
 I to nie tylko przez jego przybycie, ale także przez pocieszenie, jakiego doznał od was. Opowiedział nam o waszej tęsknocie, o waszym płaczu, o waszej trosce o mnie, sprawiając mi jeszcze większą radość.
###### **2Kor 7,8**
 Nawet jeśli zasmuciłem was moim listem, nie żałuję tego. A jeśli nawet żałowałem - gdyż widzę, że ten list zasmucił was na jakiś czas -
###### **2Kor 7,9**
 to teraz się cieszę; nie dlatego jednak, że byliście smutni, ale że ten smutek skłonił was do nawrócenia. Smuciliście się bowiem zgodnie z Bożą wolą, tak że w niczym nie ponieśliście szkody z naszej strony.
###### **2Kor 7,10**
 Smutku zgodnego z Bożą wolą nie trzeba żałować, bo prowadzi on przez nawrócenie do zbawienia. Smutek świata sprowadza śmierć,
###### **2Kor 7,11**
 natomiast ten smutek, który był zgodny z wolą Bożą, pobudził was do niezwykłej gorliwości, obrony, oburzenia, bojaźni, tęsknoty, troski, wymierzenia kary. Pod każdym względem okazaliście się nienaganni w tej sprawie.
###### **2Kor 7,12**
 Jeśli więc napisałem do was, to nie ze względu na tego, który wyrządził krzywdę, ani ze względu na tego, który jej doznał, ale aby wobec Boga ukazała się wasza gorliwość o nas.
###### **2Kor 7,13**
 Dlatego doznaliśmy teraz pocieszenia. Jeszcze bardziej ucieszyliśmy się z radości Tytusa, którego ducha wy wszyscy pokrzepiliście.
###### **2Kor 7,14**
 Nie musiałem się bowiem wstydzić, że nieco wcześniej chlubiłem się wami przed nim. Ale tak jak wszystko, o czym wam mówiliśmy, było zgodne z prawdą, tak i nasza chluba przed Tytusem okazała się prawdziwa.
###### **2Kor 7,15**
 Jego serce jeszcze bardziej lgnie do was, gdy wspomina wasze posłuszeństwo oraz jak przyjęliście go z bojaźnią i szacunkiem.
###### **2Kor 7,16**
 Cieszę się, że mogę na was całkowicie polegać.
# 2Kor 7 BP
###### **2Kor 7,1**
 Mając zatem, najmilsi, takie obietnice, oczyszczajmy się z wszelkiego brudu ciała i duszy i do końca doprowadźmy dzieło uświęcenia w bojaźni Bożej.
###### **2Kor 7,2**
 Zróbcie nam więcej miejsca [w swoich sercach]! Nikogo przecież nie skrzywdziliśmy, nikogo nie zrujnowaliśmy, nikogo nie oszukaliśmy.
###### **2Kor 7,3**
 Nie mówię tego, aby was potępiać. Już powiedziałem kiedyś, że w naszych sercach jesteście z nami złączeni na śmierć i na życie.
###### **2Kor 7,4**
 Mam do was wielkie zaufanie. Wy jesteście moją największą chlubą. Jesteście moją największą pociechą i radością w każdym utrapieniu.
###### **2Kor 7,5**
 Gdy przybyliśmy do Macedonii, nie zaznaliśmy spokoju, lecz pod każdym względem przeżywaliśmy udręki. Od zewnątrz walki, a wewnątrz obawy.
###### **2Kor 7,6**
 Lecz Bóg, pocieszający pokornych, pocieszył nas przybyciem Tytusa.
###### **2Kor 7,7**
 Zresztą sprawił to nie tylko przez jego przybycie, ale i przez pociechę, jaką sprawiliście jemu. Opowiadał mi o waszej tęsknocie, o waszym płaczu, o waszym oddaniu dla mnie tak, że jeszcze bardziej się radowałem.
###### **2Kor 7,8**
 Może i zasmuciłem was swoim listem, lecz nie żałuję tego. Jeżeli nawet żałowałem, widząc, że ów list zasmucił was na pewien czas,
###### **2Kor 7,9**
 to obecnie się raduję. Nie z tego, że zasmuciliście się, lecz z tego, że smutek skłonił was do zmiany usposobienia. Znieśliście ten smutek po Bożemu i dlatego nie wyrządziliśmy wam żadnej szkody.
###### **2Kor 7,10**
 Smutek bowiem, znoszony po Bożemu, dokonuje zbawiennej zmiany usposobienia, czego się nigdy nie żałuje. Natomiast światowy smutek powoduje śmierć.
###### **2Kor 7,11**
 Oto jaką gorliwość spowodował wśród was ten smutek znoszony po Bożemu. Nie tylko gorliwość spowodował, lecz również obronę, oburzenie, bojaźń, tęsknotę, żarliwość i potrzebę wymierzenia kary. Dowiedliście pod każdym względem, że w tej sprawie jesteście czyści.
###### **2Kor 7,12**
 Jeżeli więc napisałem do was, to nie z powodu tego, który wyrządził krzywdę, ani tego, który jej doznał, lecz aby okazać wam przed Bogiem naszą troskę o was.
###### **2Kor 7,13**
 Dlatego doznaliśmy pociechy, a ta nasza pociecha spotęgowała się jeszcze bardziej przez radość, jakiej doznaliśmy na widok radości Tytusa z tego, żeście go wszyscy pokrzepili na duchu.
###### **2Kor 7,14**
 Jeżeli nawet chlubiłem się wami przed nim, to nie doznałem wstydu. A jak wszystko powiedzieliśmy wam zgodnie z prawdą, tak też chlubne świadectwo, jakie wydaliśmy o was Tytusowi, okazało się prawdziwe.
###### **2Kor 7,15**
 Jego uczucia do was są bardzo głębokie, kiedy wspomina wasze posłuszeństwo oraz to, jak przyjęliście go z bojaźnią i drżeniem.
###### **2Kor 7,16**
 Cieszę się, że mogę wam we wszystkim zaufać.
# 2Kor 7 BR
###### **2Kor 7,1**
 Mając przeto takie obietnice, najmilsi, oczyśćmy się z wszelkich brudów ciała i ducha, dopełniając uświęcenia naszego w bojaźni Bożej.
###### **2Kor 7,2**
 Otwórzcie się dla nas! Nikogośmy nie skrzywdzili, nikogo nie przywiedli do upadku, nikogo nie oszukali.
###### **2Kor 7,3**
 Nie mówię tego, żeby was potępiać. Powiedziałem już, że pozostajecie w sercu naszym na wspólną śmierć i wspólne z nami życie.
###### **2Kor 7,4**
 Z wielką ufnością odnoszę się do was, chlubię się wami bardzo. Pełen jestem pociechy, opływam w radość mimo wielkich naszych ucisków.
###### **2Kor 7,5**
 Kiedyśmy przybyli do Macedonii, nasze ciało nie doznało żadnej ulgi, lecz zewsząd byliśmy dręczeni: zewnątrz walki, wewnątrz obawy.
###### **2Kor 7,6**
 Lecz Pocieszyciel pokornych, Bóg, podniósł i nas na duchu przybyciem Tytusa.
###### **2Kor 7,7**
 Nie tylko zresztą jego przybyciem, ale i pociechą, jakiej doznał wśród was, gdy nam opowiadał o waszej tęsknocie, o waszych łzach, o waszym zabieganiu o mnie, tak że radowałem się jeszcze bardziej.
###### **2Kor 7,8**
 A chociaż może i zasmuciłem was moim listem, to nie żałuję tego; nawet zresztą gdybym i żałował, widząc, że list ów napełnił was na pewien czas smutkiem,
###### **2Kor 7,9**
 to teraz raduję się - nie dlatego, żeście się zasmucili, ale żeście się zasmucili ku nawróceniu. Zasmuciliście się bowiem po Bożemu, tak iż nie ponieśliście przez nas żadnej szkody.
###### **2Kor 7,10**
 Bo smutek, który jest z Boga, dokonuje zbawiennego nawrócenia, i tego się nie żałuje, smutek zaś tego świata sprawia śmierć.
###### **2Kor 7,11**
 To bowiem, że zasmuciliście się po Bożemu - jakąż wzbudziło w was gorliwość, obronę, oburzenie, bojaźń, tęsknotę, zapał i potrzebę wymierzenia kary! We wszystkim okazaliście się bez nagany.
###### **2Kor 7,12**
 Dlatego też choć napisałem wam tak, to nie z powodu tego, który dopuścił się niesprawiedliwości, ani nie przez wzgląd na pokrzywdzonego, lecz by okazać nasze wobec Boga zatroskanie o was.
###### **2Kor 7,13**
 Tak więc doznaliśmy pociechy. A radość nasza spotęgowała się jeszcze bardziej tą radością, jakiej doznał Tytus, przez was wszystkich podniesiony na duchu.
###### **2Kor 7,14**
 Przeto jeśli się wami chlubiłem przed nim, nie doznałem zawstydzenia. Podobnie jak wszystko mówiliśmy wam zgodnie z prawdą, tak też prawdziwą jest nasza chluba wobec Tytusa.
###### **2Kor 7,15**
 Serce zaś jego jeszcze bardziej lgnie ku wam, gdy wspomina wasze posłuszeństwo i to, jak przyjęliście go z bojaźnią i drżeniem.
###### **2Kor 7,16**
 Cieszę się, że we wszystkim mogę wam ufać.
# 2Kor 7 WUJ
###### **2Kor 7,1**
 Mając tedy, namilejsi, te obietnice: oczyszczajmyż się od wszelakiej zmazy ciała i ducha, wykonywając poświącenie w bojaźni Bożej.
###### **2Kor 7,2**
 Przyjmicie nas. Żadnegośmy nie ukrzywdzili, żadnegośmy nie skazili, żadnegośmy nie oszukali.
###### **2Kor 7,3**
 Nie ku potępieniu naszemu mówię, bośmy przedtem powiedzieli, iż w sercach naszych jesteście, żebyśmy spół umarli, i spół żyli.
###### **2Kor 7,4**
 Mam wielką ufność u was, mam wielką pochwałę z was: pełenem pociechy, nader obfituję weselem w każdem utrapieniu naszem.
###### **2Kor 7,5**
 Abowiem i gdyśmy przyszli do Macedoniej, ciało nasze żadnego odpoczynienia nie miało, aleśmy ucierpieli wszelkie utrapienie: zewnątrz, walki, a wewnątrz, strachy.
###### **2Kor 7,6**
 Ale który cieszy uniżone, pocieszył nas Bóg, przyściem Tytusowem.
###### **2Kor 7,7**
 A nietylko przyściem jego, ale też pociechą, którą ucieszony jest z was: oznajmując nam chęć waszę, plącz wasz, wasze za się zastawiania: tak żem się więcej weselił.
###### **2Kor 7,8**
 Iż chociam was zasmucił w liście, nie żal mi: a chociabym też żałował, widząc, iż on list (chociaż na godzinę) zasmucił was:
###### **2Kor 7,9**
 Teraz raduję się: nie iżeście się zasmucili, ale iżeście się zasmucili ku pokucie. Abowiem byliście zasmuceni wedle Boga, żebyście w niczem nie szkodowali z nas.
###### **2Kor 7,10**
 Bo smutek, który jest wedle Boga, pokutę ku zbawieniu nieodmienną sprawuje: lecz smutek świecki śmierć sprawuje.
###### **2Kor 7,11**
 Abowiem o to samo, żeście wedle Boga byli zasmuceni, jako wielką pilność w was sprawuje: owszem obronę, owszem zagniewanie, owszem bojaźń, owszem pragnienie, owszem żarliwość, owszem pomstę. We wszystkiem stawiliście się, abyście byli nie pokalanymi w sprawie.
###### **2Kor 7,12**
 A tak chociażem do was pisał, nie dla tego, który krzywdę uczynił, ani dla tego, który cierpiał: ale przed żeby się pokazało pilne staranie nasze, które mamy o was Bogiem,
###### **2Kor 7,13**
 Dla tegośmy się ucieszyli. A w naszem pocieszeniu, tem więcejeśmy się radowali z wesela Tytusowego, iż ochłodzon jest duch jego od was wszystkich
###### **2Kor 7,14**
 I jeślim u niego z was się w czem przechwalał, nie zawstydziłem się: ale jakośmy wam wszystko w prawdzie mówili, tak też przechwalanie nasze, które było przed Tytusem, prawdą się stało:
###### **2Kor 7,15**
 A wnętrzności jego obficiej są ku wam, gdy wspomina na posłuszeństwo wszystkich was, jakoście go z bojaźnią i ze drżeniem przyjęli.
###### **2Kor 7,16**
 Raduję się, iż wam we wszystkiem dufam.
# 2Kor 7 STERN
###### **2Kor 7,1**
 Dlatego, drodzy przyjaciele, skoro mamy te obietnice, oczyśćmy się ze wszystkiego, co może kalać ciało albo ducha, i z bojaźni przed Bogiem dążmy do pełnej świętości.
###### **2Kor 7,2**
 Zróbcie nam miejsce w swoich sercach - nikogo nie skrzywdziliśmy, nikogo nie skalaliśmy, nikogo nie wykorzystaliśmy.
###### **2Kor 7,3**
 Nie mówię tego, aby was obwiniać, bo powiedziałem już, że macie miejsce w naszych sercach, czy żyjemy razem, czy razem umieramy;
###### **2Kor 7,4**
 że mam co do was wielkie zaufanie; że jestem z was bardzo dumny; że napełniliście mnie otuchą i że pomimo wszystkich naszych ucisków przepełnia mnie radość.
###### **2Kor 7,5**
 Bo rzeczywiście, kiedy przybyliśmy do Macedonii, nasze ciała nie zaznały odpoczynku. Przeciwnie, stanęliśmy wobec najrozmaitszych ucisków - zwady na zewnątrz, niepokoje w środku.
###### **2Kor 7,6**
 Lecz Bóg, który pokrzepia przygnębionych, pokrzepił nas przybyciem Tytusa!
###### **2Kor 7,7**
 Nie tylko jednak jego przybycie nas pokrzepiło, ale i to, jak pokrzepiony był on co do was, że opowiadał nam, jak pragniecie mnie ujrzeć, jak trapicie się moim położeniem, jak z zapałem stajecie w mojej obronie - ta wieść uszczęśliwiła mnie jeszcze bardziej!
###### **2Kor 7,8**
 Jeśli swoim listem sprawiłem wam ból, nie żałuję tego. Nawet jeśli przedtem żałowałem - bo naprawdę widzę, że was ten list zmartwił, choć tylko na krótko -
###### **2Kor 7,9**
 to teraz raduję się, nie dlatego, żeście doznawali bólu, ale że ten ból przywiódł was z powrotem do Boga. Bo podeszliście do bólu na sposób Boży, tak że nie doznaliście od nas żadnej krzywdy.
###### **2Kor 7,10**
 Ból, do którego podejdzie się na sposób Boży, rodzi zwrócenie się od grzechu do Boga, co prowadzi do zbawienia, w tym zaś nie ma czego żałować! Lecz ból, do którego podejdzie się na sposób świata, rodzi tylko śmierć.
###### **2Kor 7,11**
 Bo spójrzcie, co zrodziło się w was przez podejście do tego bólu na sposób Boży! Jaka gorliwa pilność, jaka żarliwość, żeby się oczyścić, jaki gniew, jaki lęk, jakie pragnienie, jaki zapał, jaka gotowość, aby wszystko naprawić! We wszystkim okazaliście się bez zarzutu w tej sprawie.
###### **2Kor 7,12**
 Choć zatem napisałem do was, nie było to ze względu ani na tego, który postąpił źle, ani na skrzywdzonego, lecz abyście przed Bogiem sami zobaczyli, jak głębokie jest wasze oddanie dla nas.
###### **2Kor 7,13**
 Dlatego doznaliśmy pokrzepienia. Poza naszym własnym pokrzepieniem zaznaliśmy jeszcze większej radości, widząc, jak szczęśliwy jest Tytus, bo wszyscyście go uspokoili.
###### **2Kor 7,14**
 Trochę się bowiem przed nim wami chwaliłem i teraz nie wyszedłem na głupca. Przeciwnie, jak wszystko, co wam powiedzieliśmy, jest prawdą, tak i prawdą okazało się nasze chlubienie się przed Tytusem.
###### **2Kor 7,15**
 A jego uczucie do was jest jeszcze gorętsze, gdy wspomina waszą gotowość do posłuszeństwa i jak go przyjęliście z czcią i szacunkiem.
###### **2Kor 7,16**
 Cieszę się, że mogę mogę mieć do was tak pełne zaufanie.
# 2Kor 7 TRO
###### **2Kor 7,1**
 **ταυτας** *tautas* Te [[G3778]] WTD-APF **ουν** *oun* więc [[G3767]] [[CONJ]] **εχοντες** *echontes* mając [[G2192]] WTV-PAP-NPM **τας** *tas* [[G3588]] WTT-APF **επαγγελιας** *epangelias* obietnice [[G1860]] WTN-APF **αγαπητοι** *agapētoi* umiłowani [[G27]] WTA-VPM **καθαρισωμεν** *katharisōmen* oczyścilibyśmy [[G2511]] WTV-AAS-1P **εαυτους** *heautous* siebie [[G1438]] WTF-3APM **απο** *apo* od [[G575]] [[PREP]] **παντος** *pantos* każdego [[G3956]] WTA-GSM **μολυσμου** *molysmou* splamienia – zmazy [[G3436]] [[N-GSM]] **σαρκος** *sarkos* ciała [[G4561]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **πνευματος** *pneumatos* ducha [[G4151]] [[N-GSN]] **επιτελουντες** *epitelountes* wypełniający – spełniający [[G2005]] WTV-PAP-NPM **αγιωσυνην** *hagiōsynēn* poświęcenie – uświęcenie [[G42]] WTN-ASF **εν** *en* w [[G1722]] [[PREP]] **φοβω** *fobō* strachu – bojaźni [[G5401]] WTN-DSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **2Kor 7,2**
 **χωρησατε** *chōrēsate* Zróbcie miejsce [[G5562]] WTV-AAM-2P **ημας** *hēmas* (dla) nas [[G2248]] WTP-1AP **ουδενα** *oudena* nikogo [[G3762]] WTA-ASM **ηδικησαμεν** *ēdikēsamen* nie uczyniliśmy niesprawiedliwości – nie skrzywdziliśmy [[G91]] WTV-AAI-1P **ουδενα** *oudena* nikogo [[G3762]] WTA-ASM **εφθειραμεν** *eftheiramen* psuliśmy – niszczyliśmy [[G5351]] WTV-AAI-1P **ουδενα** *oudena* nikogo [[G3762]] WTA-ASM **επλεονεκτησαμεν** *epleonektēsamen* oszukaliśmy – okazaliśmy zachłanności [[G4122]] WTV-AAI-1P
###### **2Kor 7,3**
 **ου** *hou* nie [[G3756]] [[PRT-N]] **προς** *pros* dla [[G4314]] [[PREP]] **κατακρισιν** *katakrisin* potępienia – zasądzenia [[G2633]] WTN-ASF **λεγω** *legō* mówię [[G3004]] WTV-PAI-1S **προειρηκα** *proeirēka* przepowiedziałem – wcześniej powiedziałem [[G4280]] WTV-RAI-1S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **οτι** *hoti* że [[G3754]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **καρδιαις** *kardiais* sercach [[G2588]] WTN-DPF **ημων** *hēmōn* naszych [[G2257]] WTP-1GP **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **εις** *eis* ku [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **συναποθανειν** *synapothanein* umrzeć razem [[G4880]] [[V-2AAN]] **και** *kai* i [[G2532]] [[CONJ]] **συζην** *syzēn* razem żyć [[G4800]] WTV-PAN
###### **2Kor 7,4**
 **πολλη** *pollē* Wielka [[G4183]] WTA-NSF **μοι** *moi* mi [[G3427]] WTP-1DS **παρρησια** *parrēsia* śmiałość [[G3954]] [[N-NSF]] **προς** *pros* do [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **πολλη** *pollē* wielka [[G4183]] WTA-NSF **μοι** *moi* mi [[G3427]] WTP-1DS **καυχησις** *kauchēsis* chluba – chełpienie się [[G2746]] [[N-NSF]] **υπερ** *hyper* za [[G5228]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **πεπληρωμαι** *peplērōmai* jestem wypełniony [[G4137]] WTV-RPI-1S **τη** *tē* [[G3588]] WTT-DSF **παρακλησει** *paraklēsei* pociechą – zachętą [[G3874]] [[N-DSF]] **υπερπερισσευομαι** *hyperperisseuomai* aż nazbyt obfituję [[G5248]] WTV-PMI-1S **τη** *tē* [[G3588]] WTT-DSF **χαρα** *chara* radością [[G5479]] [[N-DSF]] **επι** *epi* w [[G1909]] [[PREP]] **παση** *pasē* całym [[G3956]] WTA-DSF **τη** *tē* [[G3588]] WTT-DSF **θλιψει** *thlipsei* ucisku – utrapieniu [[G2347]] [[N-DSF]] **ημων** *hēmōn* naszym [[G2257]] WTP-1GP
###### **2Kor 7,5**
 **και** *kai* A [[G2532]] [[CONJ]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ελθοντων** *elthontōn* przyszedłszy [[G2064]] WTV-2AAP-GPM **ημων** *hēmōn* nam [[G2257]] WTP-1GP **εις** *eis* do [[G1519]] [[PREP]] **μακεδονιαν** *makedonian* Macedonii [[G3109]] WTN-ASF **ουδεμιαν** *oudemian* żadnej [[G3762]] WTA-ASF **εσχηκεν** *eschēken* miało [[G2192]] WTV-RAI-3S **ανεσιν** *anesin* ulgi – wytchnienia [[G425]] WTN-ASF **η** *hē* [[G3588]] [[T-NSF]] **σαρξ** *sarks* ciało [[G4561]] [[N-NSF]] **ημων** *hēmōn* nasze [[G2257]] WTP-1GP **αλλ** *all* ale [[G235]] [[CONJ]] **εν** *en* we [[G1722]] [[PREP]] **παντι** *panti* wszystkim [[G3956]] WTA-DSN **θλιβομενοι** *thlibomenoi* którzy są uciskani – którzy są trapieni [[G2346]] WTV-PPP-NPM **εξωθεν** *eksōthen* z zewnątrz [[G1855]] [[ADV]] **μαχαι** *machai* walki [[G3163]] [[N-NPF]] **εσωθεν** *esōthen* wewnątrz [[G2081]] [[ADV]] **φοβοι** *foboi* strachy – bojaźnie [[G5401]] WTN-NPM
###### **2Kor 7,6**
 **αλλ** *all* Ale [[G235]] [[CONJ]] **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **παρακαλων** *parakalōn* pocieszający – zachęcający [[G3870]] [[V-PAP-NSM]] **τους** *tous* [[G3588]] WTT-APM **ταπεινους** *tapeinous* pokornych – uniżonych [[G5011]] WTA-APM **παρεκαλεσεν** *parekalesen* pocieszył – zachęcił [[G3870]] [[V-AAI-3S]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **εν** *en* przez [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **παρουσια** *parousia* przyjście [[G3952]] [[N-DSF]] **τιτου** *titou* Tytusa [[G5103]] [[N-GSM]]
###### **2Kor 7,7**
 **ου** *ou* Nie [[G3756]] [[PRT-N]] **μονον** *monon* jedynie – tylko [[G3440]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **εν** *en* przez [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **παρουσια** *parousia* przyjście [[G3952]] [[N-DSF]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **αλλα** *alla* ale [[G235]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* przez [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **παρακλησει** *paraklēsei* pociechę – zachętę [[G3874]] [[N-DSF]] **η** *hē* którą [[G3739]] WTR-DSF **παρεκληθη** *pareklēthē* został pocieszony – został zachęcony [[G3870]] [[V-API-3S]] **εφ** *ef* u – wśród [[G1909]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **αναγγελλων** *anangellōn* oznajmiając – ogłaszając [[G312]] [[V-PAP-NSM]] **ημιν** *hēmin* nam [[G2254]] WTP-1DP **την** *tēn* [[G3588]] WTT-ASF **υμων** *hymōn* waszą [[G5216]] WTP-2GP **επιποθησιν** *epipothēsin* tęsknotę – upragnienie [[G1972]] WTN-ASF **τον** *ton* [[G3588]] [[T-ASM]] **υμων** *hymōn* wasze [[G5216]] WTP-2GP **οδυρμον** *odyrmon* biadolenie – zawodzenie [[G3602]] [[N-ASM]] **τον** *ton* [[G3588]] [[T-ASM]] **υμων** *hymōn* waszą [[G5216]] WTP-2GP **ζηλον** *zēlon* żarliwość – zapał [[G2205]] [[N-ASM]] **υπερ** *hyper* o [[G5228]] [[PREP]] **εμου** *emou* mnie [[G1700]] WTP-1GS **ωστε** *hōste* tak, że [[G5620]] [[CONJ]] **με** *me* ja [[G3165]] WTP-1AS **μαλλον** *mallon* bardziej [[G3123]] [[ADV]] **χαρηναι** *charēnai* uradować się – ucieszyć się [[G5463]] WTV-2AON
###### **2Kor 7,8**
 **οτι** *hoti* Gdyż [[G3754]] [[CONJ]] **ει** *ei* jeśli [[G1487]] WTCOND **και** *kai* i [[G2532]] [[CONJ]] **ελυπησα** *elypēsa* zasmuciłem [[G3076]] WTV-AAI-1S **υμας** *hymas* was [[G5209]] WTP-2AP **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **επιστολη** *epistolē* liście [[G1992]] [[N-DSF]] **ου** *ou* nie [[G3756]] [[PRT-N]] **μεταμελομαι** *metamelomai* żałuję – zmieniam zdania [[G3338]] WTV-PNI-1S **ει** *ei* jeśli [[G1487]] WTCOND **και** *kai* i [[G2532]] [[CONJ]] **μετεμελομην** *metemelomēn* żałowałem – zmieniłem zdanie [[G3338]] WTV-INI-1S **βλεπω** *blepō* widzę [[G991]] WTV-PAI-1S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **οτι** *hoti* że [[G3754]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **επιστολη** *epistolē* list [[G1992]] [[N-NSF]] **εκεινη** *ekeinē* ten [[G1565]] WTD-NSF **ει** *ei* jeśli [[G1487]] WTCOND **και** *kai* i [[G2532]] [[CONJ]] **προς** *pros* na [[G4314]] [[PREP]] **ωραν** *hōran* godzinę – porę [[G5610]] WTN-ASF **ελυπησεν** *elypēsen* zasmucił [[G3076]] [[V-AAI-3S]] **υμας** *hymas* was [[G5209]] WTP-2AP
###### **2Kor 7,9**
 **νυν** *nyn* Teraz [[G3568]] [[ADV]] **χαιρω** *chairō* raduję się – cieszę się [[G5463]] WTV-PAI-1S **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **οτι** *hoti* że [[G3754]] [[CONJ]] **ελυπηθητε** *elypēthēte* zostaliście zasmuceni [[G3076]] WTV-API-2P **αλλ** *all* ale [[G235]] [[CONJ]] **οτι** *hoti* że [[G3754]] [[CONJ]] **ελυπηθητε** *elypēthēte* zostaliście zasmuceni [[G3076]] WTV-API-2P **εις** *eis* w [[G1519]] [[PREP]] **μετανοιαν** *metanoian* nawróceniu – zmianie myślenia [[G3341]] WTN-ASF **ελυπηθητε** *elypēthēte* zostaliście zasmuceni [[G3076]] WTV-API-2P **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **κατα** *kata* według [[G2596]] [[PREP]] **θεον** *theon* Boga [[G2316]] [[N-ASM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **μηδενι** *mēdeni* niczym [[G3367]] WTA-DSN **ζημιωθητε** *zēmiōthēte* doznalibyście straty [[G2210]] WTV-APS-2P **εξ** *eks* od [[G1537]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP
###### **2Kor 7,10**
 **η** *hē* (Ten) [[G3588]] [[T-NSF]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **κατα** *kata* według [[G2596]] [[PREP]] **θεον** *theon* Boga [[G2316]] [[N-ASM]] **λυπη** *lypē* smutek [[G3077]] [[N-NSF]] **μετανοιαν** *metanoian* nawrócenie – zmianę myślenia [[G3341]] WTN-ASF **εις** *eis* ku [[G1519]] [[PREP]] **σωτηριαν** *sōtērian* zbawieniu – wyzwoleniu [[G4991]] WTN-ASF **αμεταμελητον** *ametamelēton* nieżałowanemu [[G278]] WTA-ASF **κατεργαζεται** *katergazetai* sprawuje [[G2716]] WTV-PNI-3S **η** *hē* (ten) [[G3588]] [[T-NSF]] **δε** *de* zaś [[G1161]] [[CONJ]] **του** *tou* [[G3588]] WTT-GSM **κοσμου** *kosmou* świata [[G2889]] [[N-GSM]] **λυπη** *lypē* smutek [[G3077]] [[N-NSF]] **θανατον** *thanaton* śmierć [[G2288]] [[N-ASM]] **κατεργαζεται** *katergazetai* sprawia [[G2716]] WTV-PNI-3S
###### **2Kor 7,11**
 **ιδου** *idou* Oto [[G2400]] WTV-2AAM-2S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **αυτο** *auto* samo [[G846]] WTP-NSN **τουτο** *touto* to [[G5124]] WTD-NSN **το** *to* [[G3588]] WTT-NSN **κατα** *kata* według [[G2596]] [[PREP]] **θεον** *theon* Boga [[G2316]] [[N-ASM]] **λυπηθηναι** *lypēthēnai* zostać zasmuconym [[G3076]] WTV-APN **υμας** *hymas* wasze [[G5209]] WTP-2AP **ποσην** *posēn* jak wielką [[G4214]] WTQ-ASF **κατειργασατο** *kateirgasato* sprawiło [[G2716]] WTV-ADI-3S **υμιν** *hymin* wam [[G5213]] WTP-2DP **σπουδην** *spoudēn* gorliwość – zapał [[G4710]] WTN-ASF **αλλα** *alla* ale [[G235]] [[CONJ]] **απολογιαν** *apologian* obronę [[G627]] WTN-ASF **αλλα** *alla* ale [[G235]] [[CONJ]] **αγανακτησιν** *aganaktēsin* oburzenie – rozdrażnienie [[G24]] WTN-ASF **αλλα** *alla* ale [[G235]] [[CONJ]] **φοβον** *fobon* strach – bojaźń [[G5401]] [[N-ASM]] **αλλα** *alla* ale [[G235]] [[CONJ]] **επιποθησιν** *epipothēsin* tęsknotę – upragnienie [[G1972]] WTN-ASF **αλλα** *alla* ale [[G235]] [[CONJ]] **ζηλον** *zēlon* żarliwość – zapał [[G2205]] [[N-ASM]] **αλλ** *all* ale [[G235]] [[CONJ]] **εκδικησιν** *ekdikēsin* ukaranie – pomstę [[G1557]] WTN-ASF **εν** *en* we [[G1722]] [[PREP]] **παντι** *panti* wszystkim [[G3956]] WTA-DSN **συνεστησατε** *synestēsate* poleciliście – stanęliście [[G4921]] WTV-AAI-2P **εαυτους** *heautous* siebie [[G1438]] WTF-3APM **αγνους** *hagnous* czystymi – nieskalanymi [[G53]] WTA-APM **ειναι** *einai* być [[G1511]] WTV-PXN **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* (tej) [[G3588]] WTT-DSN **πραγματι** *pragmati* sprawie [[G4229]] WTN-DSN
###### **2Kor 7,12**
 **αρα** *ara* Zatem [[G686]] WTPRT **ει** *ei* jeśli [[G1487]] WTCOND **και** *kai* i [[G2532]] [[CONJ]] **εγραψα** *egrapsa* napisałem [[G1125]] WTV-AAI-1S **υμιν** *hymin* wam [[G5213]] WTP-2DP **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **εινεκεν** *heineken* ze względu na [[G1752]] [[ADV]] **του** *tou* (tego) [[G3588]] WTT-GSM **αδικησαντος** *adikēsantos* który uczynił niesprawiedliwość – który skrzywdził [[G91]] WTV-AAP-GSM **ουδε** *oude* ani [[G3761]] [[ADV]] **εινεκεν** *heineken* ze względu na [[G1752]] [[ADV]] **του** *tou* (tego) [[G3588]] WTT-GSM **αδικηθεντος** *adikēthentos* który doznał niesprawiedliwości – który został skrzywdzony [[G91]] WTV-APP-GSM **αλλ** *all* ale [[G235]] [[CONJ]] **εινεκεν** *heineken* ze względu na [[G1752]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **φανερωθηναι** *fanerōthēnai* zostać objawioną – zostać uczynioną widoczną [[G5319]] WTV-APN **την** *tēn* [[G3588]] WTT-ASF **σπουδην** *spoudēn* gorliwość – zapał [[G4710]] WTN-ASF **ημων** *hēmōn* naszą [[G2257]] WTP-1GP **την** *tēn* (tą) [[G3588]] WTT-ASF **υπερ** *hyper* za [[G5228]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **προς** *pros* do [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Bogiem [[G2316]] [[N-GSM]]
###### **2Kor 7,13**
 **δια** *dia* Przez [[G1223]] [[PREP]] **τουτο** *touto* to [[G5124]] WTD-ASN **παρακεκλημεθα** *parakeklēmetha* jesteśmy zachęcani [[G3870]] WTV-RPI-1P **επι** *epi* w [[G1909]] [[PREP]] **τη** *tē* (tej) [[G3588]] WTT-DSF **παρακλησει** *paraklēsei* pociesze – zachęcie [[G3874]] [[N-DSF]] **υμων** *hymōn* waszej [[G5216]] WTP-2GP **περισσοτερως** *perissoterōs* obficiej [[G4056]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **μαλλον** *mallon* bardziej [[G3123]] [[ADV]] **εχαρημεν** *echarēmen* uradowaliśmy się – ucieszyliśmy się [[G5463]] WTV-2AOI-1P **επι** *epi* z powodu [[G1909]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **χαρα** *chara* radości [[G5479]] [[N-DSF]] **τιτου** *titou* Tytusa [[G5103]] [[N-GSM]] **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **αναπεπαυται** *anapepautai* doznał odświeżenia – jest pokrzepiony [[G373]] WTV-RPI-3S **το** *to* [[G3588]] WTT-NSN **πνευμα** *pneuma* duch [[G4151]] WTN-NSN **αυτου** *autou* jego [[G846]] [[P-GSM]] **απο** *apo* przez [[G575]] [[PREP]] **παντων** *pantōn* wszystkich [[G3956]] WTA-GPM **υμων** *hymōn* was [[G5216]] WTP-2GP
###### **2Kor 7,14**
 **οτι** *hoti* Gdyż [[G3754]] [[CONJ]] **ει** *ei* jeśli [[G1487]] WTCOND **τι** *ti* coś [[G5100]] WTX-NSN **αυτω** *autō* jemu [[G846]] WTP-DSM **υπερ** *hyper* o [[G5228]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **κεκαυχημαι** *kekauchēmai* chlubiliśmy się – chełpiliśmy się [[G2744]] WTV-RNI-1S **ου** *ou* nie [[G3756]] [[PRT-N]] **κατησχυνθην** *katēschynthēn* zostałem zawstydzony – zostałem zhańbiony [[G2617]] WTV-API-1S **αλλ** *all* ale [[G235]] [[CONJ]] **ως** *hōs* jak [[G5613]] [[ADV]] **παντα** *panta* wszystkie [[G3956]] WTA-APN **εν** *en* w [[G1722]] [[PREP]] **αληθεια** *alētheia* prawdzie [[G225]] [[N-DSF]] **ελαλησαμεν** *elalēsamen* powiedzieliśmy [[G2980]] WTV-AAI-1P **υμιν** *hymin* wam [[G5213]] WTP-2DP **ουτως** *houtōs* tak [[G3779]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **καυχησις** *kauchēsis* chluba – chełpienie się [[G2746]] [[N-NSF]] **ημων** *hēmōn* nasza [[G2257]] WTP-1GP **η** *hē* [[G3588]] [[T-NSF]] **επι** *epi* przed [[G1909]] [[PREP]] **τιτου** *titou* Tytusem [[G5103]] [[N-GSM]] **αληθεια** *alētheia* prawda [[G225]] [[N-NSF]] **εγενηθη** *egenēthē* stała się [[G1096]] [[V-AOI-3S]]
###### **2Kor 7,15**
 **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-NPN **σπλαγχνα** *splagchna* głębokie uczucia – wnętrzności [[G4698]] WTN-NPN **αυτου** *autou* jego [[G846]] [[P-GSM]] **περισσοτερως** *perissoterōs* jeszcze obficiej [[G4056]] [[ADV]] **εις** *eis* do [[G1519]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **αναμιμνησκομενου** *anamimnēskomenou* przypominając sobie [[G363]] WTV-PMP-GSM **την** *tēn* [[G3588]] WTT-ASF **παντων** *pantōn* wszystkich [[G3956]] WTA-GPM **υμων** *hymōn* was [[G5216]] WTP-2GP **υπακοην** *hypakoēn* posłuszeństwo [[G5218]] WTN-ASF **ως** *hōs* jak [[G5613]] [[ADV]] **μετα** *meta* ze [[G3326]] [[PREP]] **φοβου** *fobou* strachem – bojaźnią [[G5401]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **τρομου** *tromou* drżeniem [[G5156]] [[N-GSM]] **εδεξασθε** *edeksasthe* przyjęliście [[G1209]] WTV-ADI-2P **αυτον** *auton* go [[G846]] WTP-ASM
###### **2Kor 7,16**
 **χαιρω** *chairō* Raduję się – Cieszę się [[G5463]] WTV-PAI-1S **ουν** *oun* więc [[G3767]] [[CONJ]] **οτι** *hoti* że [[G3754]] [[CONJ]] **εν** *en* we [[G1722]] [[PREP]] **παντι** *panti* wszystkim [[G3956]] WTA-DSN **θαρρω** *tharrō* wykazuję śmiałość – wykazuję odwagę [[G2292]] WTV-PAI-1S-C **εν** *en* w [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP
