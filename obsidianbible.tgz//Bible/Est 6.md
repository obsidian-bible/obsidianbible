# Est 6 BT5
###### **Est 6,1**
 A tej nocy sen odbiegł króla i polecił on, aby przyniesiono księgę pamiątkową kronik i czytano ją przed królem.
###### **Est 6,2**
 Tam znaleziono zapisane to, co opowiedział Mardocheusz o Bigtanie i Tereszu, dwóch eunuchach królewskich spomiędzy "stróżów progu", którzy usiłowali podnieść rękę na króla Aswerusa.
###### **Est 6,3**
 I rzekł król: «***Co uczyniono, aby uczcić i wsławić za to Mardocheusza?***» Odpowiedzieli królowi dworzanie, którzy mu usługiwali: «***Nie uczyniono dla niego zupełnie nic***».
###### **Est 6,4**
 Na to rzekł król: «***Kto jest na dziedzińcu?***» A na zewnętrzny dziedziniec pałacu królewskiego przyszedł Haman powiedzieć królowi, żeby powieszono Mardocheusza na drzewie, które przygotował dla niego.
###### **Est 6,5**
 A młodzi słudzy króla powiedzieli mu: «***Oto Haman stoi na dziedzińcu***». Król rzekł: «***Niech wejdzie!***»
###### **Est 6,6**
 I Haman przyszedł, a król rzekł do niego: «***Co należy uczynić mężowi, którego król chce uczcić?***» A Haman mówił sam do siebie: Kogóż by król chciał uczcić bardziej niż mnie?
###### **Est 6,7**
 I powiedział Haman królowi: «***Mężowi, którego król chce uczcić,***
###### **Est 6,8**
 ***niech dostarczą szatę królewską, w którą król się ubiera, i konia, na którym jeździ król, i niech mu włożą na głowę koronę królestwa.***
###### **Est 6,9**
 ***Oddając zaś szatę i konia do rąk jednego spośród najznakomitszych książąt króla, niech ubiorą męża, którego król chce uczcić, i niech go obwożą na koniu po placu miejskim, i niech wołają przed nim: Tak się dzieje z mężem, którego król chce uczcić!***»
###### **Est 6,10**
 I rzekł król do Hamana: «***Szybko weź szatę i konia i jak powiedziałeś, tak uczyń Żydowi Mardocheuszowi, który siedzi w Bramie Królewskiej. Niczego nie pomiń z tego wszystkiego, co powiedziałeś!***»
###### **Est 6,11**
 Wziął więc Haman szatę i konia i ubrał Mardocheusza, obwoził go po placu miejskim, i wołał przed nim: «***Tak się dzieje z mężem, którego król chce uczcić***».
###### **Est 6,12**
 Potem Mardocheusz powrócił do Bramy Królewskiej, a Haman pośpieszył do swego domu smutny, z zakrytą głową.
###### **Est 6,13**
 I opowiedział Haman żonie swojej, Zeresz, oraz wszystkim swoim przyjaciołom o wszystkim, co go spotkało. I odpowiedzieli mu doradcy jego i żona jego, Zeresz: «***Jeżeli Mardocheusz jest z narodu żydowskiego, a ty zacząłeś przed nim padać, to nie przemożesz go, raczej całkiem przed nim upadniesz***».
###### **Est 6,14**
 A gdy oni jeszcze z nim rozmawiali, nadeszli eunuchowie, by śpiesznie zaprowadzić Hamana na ucztę, którą przygotowała Estera.
# Est 6 PAU
###### **Est 6,1**
 Tamtej nocy PAN sprawił, że król nie mógł zasnąć, dlatego kazał swemu nauczycielowi przynieść kroniki, aby mu je czytano jako lekturę.
###### **Est 6,2**
 A natrafiono na księgi opowiadające o tym, jak to Mardocheusz doniósł królowi na dwóch eunuchów królewskich, którzy stali na straży i zamierzali zabić Artakserksesa.
###### **Est 6,3**
 Król zapytał: „Jakimi zaszczytami lub nagrodami obsypaliśmy Mardocheusza?”. Służba królewska odpowiedziała: „Nie uczyniłeś dla niego nic!”.
###### **Est 6,4**
 Gdy król rozpytywał jeszcze o lojalność Mardocheusza, na dziedzińcu królewskim pojawił się Haman. Król zapytał: „Kto jest na dziedzińcu?”. A Haman przyszedł na dziedziniec prosić króla, aby kazał powiesić Mardocheusza na szubienicy, którą przygotował.
###### **Est 6,5**
 Służba królewska odpowiedziała królowi: „Na dziedzińcu stoi Haman”. Rzekł król: „Wezwijcie go!”.
###### **Est 6,6**
 A potem zapytał Hamana: „Co należałoby uczynić człowiekowi, którego chciałbym uczcić?”. Haman pomyślał: „Kogóż innego chciałby król uczcić, jeśli nie mnie?”.
###### **Est 6,7**
 Odpowiedział zatem królowi: „Człowiekowi, którego król chce uczcić,
###### **Est 6,8**
 niech słudzy przyniosą delikatną szatę, w jaką ubiera się sam król, oraz przyprowadzą konia, na którym jeździ król.
###### **Est 6,9**
 Niech dadzą to jednemu z dostojnych przyjaciół króla, a on niech włoży szatę na człowieka, którego król miłuje i posadzi go na konia, a następnie głosi na placach miasta: «Tak postąpi się z każdym człowiekiem, którego król chce uczcić»”.
###### **Est 6,10**
 Wtedy król rzekł do Hamana: „Jak powiedziałeś, tak uczyń Żydowi Mardocheuszowi siedzącemu na dziedzińcu, a nie pomiń niczego z tego, o czym mówiłeś”.
###### **Est 6,11**
 Zatem Haman wziął strój królewski i konia, przystroił Mardocheusza, posadził go na konia, a potem, idąc główną ulicą miasta, głosił: „Tak postąpi się z każdym człowiekiem, którego król chce uczcić”.
###### **Est 6,12**
 Potem Mardocheusz wrócił na dziedziniec, a Haman do swego domu, ponury i ze zwieszoną głową.
###### **Est 6,13**
 Haman opowiedział o tym, co mu się przydarzyło, swojej żonie Zosarze oraz przyjaciołom. Na to jego przyjaciele i żona powiedzieli: „Jeśli Mardocheusz pochodzi z narodu żydowskiego, to jest to dopiero początek twojego upokorzenia. Nie zdołasz się bowiem obronić przed nim, gdyż jest z nim Bóg żyjący”.
###### **Est 6,14**
 Gdy oni jeszcze rozmawiali, przyszli eunuchowie z zaproszeniem dla Hamana na ucztę, którą przygotowała Estera.
# Est 6 BP
###### **Est 6,1**
 A tej nocy król nie mógł usnąć. Polecił więc, aby przyniesiono księgę upamiętniającą zdarzenia historyczne i by mu je odczytywano.
###### **Est 6,2**
 Natrafiono tam na opis tego, jak to Mardocheusz złożył doniesienie na Bigtana i Teresza, dwóch eunuchów królewskich spośród "strażników progu", którzy zamierzali podnieść rękę na króla Achaszwerosza.
###### **Est 6,3**
 Król zapytał: Jakiego zaszczytu i wyniesienia dostąpił za to Mardocheusz? Dworzanie królewscy, pełniący przy nim służbę, odpowiedzieli: Nie dano mu żadnego wynagrodzenia.
###### **Est 6,4**
 Spytał król: Kto jest na dziedzińcu? A był to Haman, który wszedł aż na dziedziniec zewnętrzny pałacu królewskiego, aby zapytać króla, czy może powiesić Mardocheusza na szubienicy, którą dla niego przygotował.
###### **Est 6,5**
 Dworzanie królewscy odpowiedzieli mu: To Haman znajduje się na dziedzińcu. Rzekł król: Niech wejdzie.
###### **Est 6,6**
 A gdy Haman wszedł, zapytał go król: Co należy uczynić dla męża, którego król pragnie uczcić? Pomyślał Haman: A kogóż to innego chciałby król uczcić, jeśli nie mnie?
###### **Est 6,7**
 Odpowiedział więc Haman królowi: Dla męża, którego król pragnie uczcić,
###### **Est 6,8**
 niech przyniosą szatę królewską, którą król przywdziewa, i konia, którego król dosiada, i niech przyniosą mu koronę królewską na głowę.
###### **Est 6,9**
 Szatę i konia niech podadzą do rąk jednemu z książąt królewskich, aby on ubrał owego męża, którego król pragnie uczcić, i niech prowadzą go na koniu po ulicach miasta i niech wołają przed nim: "Oto co się czyni dla tego, którego król pragnie uczcić!"
###### **Est 6,10**
 Rzekł król do Hamana: Weź natychmiast szatę i konia, jak to sam powiedziałeś! Uczyń to wszystko dla Żyda Mardocheusza, który pełni straż przy bramie Królewskiej. A nie pomiń niczego z tego, coś sam powiedział.
###### **Est 6,11**
 I wziąwszy suknię i konia, musiał Haman przyodziać w nią Mardocheusza, oprowadzać go [siedzącego na koniu] po ulicach miasta i wołać przed nim: Oto co się czyni dla męża, którego król pragnie uczcić!
###### **Est 6,12**
 Następnie powrócił Mardocheusz do bramy Królewskiej, przygnębiony zaś Haman z twarzą zakrytą czym prędzej podążył do swego domu.
###### **Est 6,13**
 Opowiadał swojej żonie Zeresz i wszystkim przyjaciołom swoim o tym, co go spotkało. Mędrcy i jego żona Zeresz odrzekli mu: Jeżeli Mardocheusz, od którego rozpoczął się twój upadek, wywodzi się istotnie z rodu żydowskiego, nie będziesz go mógł przemóc, ale sam niezawodnie upadniesz przez niego.
###### **Est 6,14**
 Jeszcze podczas tej rozmowy przybyli dworzanie królewscy, aby śpiesznie zaprowadzić Hamana na ucztę, przygotowaną przez Esterę.
# Est 6 BR
###### **Est 6,1**
 Tej nocy król nie mógł zasnąć. Kazał więc przynieść sobie i czytać pamiątkową Księgę Kronik.
###### **Est 6,2**
 Natrafiono tam na opowieść Mardocheusza o dwóch eunuchach królewskich, odźwiernych: Bigtanie i Tereszu, którzy przygotowywali zamach na króla Aswerusa.
###### **Est 6,3**
 Zapytał tedy król: Jaką nagrodę i wyróżnienie otrzymał Mardocheusz za przekazanie tej wiadomości? A znajdujący się tam słudzy królewscy odpowiedzieli: Nic za to nie otrzymał.
###### **Est 6,4**
 Król zapytał: Kto tam stoi teraz na dziedzińcu? Akurat wtedy przyszedł na dziedziniec pałacu królewskiego Haman, który udawał się do króla, by mu powiedzieć, że Mardocheusz ma być powieszony na dopiero zbudowanej szubienicy.
###### **Est 6,5**
 Słudzy odpowiedzieli: Haman jest na dziedzińcu. Powiedział tedy król: Niech tu wejdzie!
###### **Est 6,6**
 Kiedy Haman wszedł, król go zapytał: Co powinno się uczynić człowiekowi, któremu król chciałby wyrazić swoje szczególne uznanie? Haman pomyślał sobie natychmiast: Kogóż król chciałby wyróżnić bardziej niż mnie?
###### **Est 6,7**
 Dlatego bez wahania powiedział do króla: Jeżeli król pragnie wyrazić swoje szczególne uznanie jakiemuś człowiekowi,
###### **Est 6,8**
 to niech mu pozwoli ubrać się w swoje królewskie szaty, te same, które kiedy indziej nosi sam król; niech [człowiek ten] dosiądzie konia, na którym zwykle jeździ król, i niech koń będzie po królewsku przybrany.
###### **Est 6,9**
 Szaty i koń niech będą przekazane jednemu z najznakomitszych książąt królewskich. On to niech sam ubierze w królewskie szaty męża, którego król pragnie wyróżnić, a konia, na którego on wsiądzie, niech wprowadzi na plac miejski wołając: Oto człowiek, któremu król pragnie wyrazić swoje szczególne uznanie.
###### **Est 6,10**
 Rzekł na to król do Haman: Niech dostarczą tu natychmiast szaty królewskie i konia, a ty wszystko to, co przed chwilą powiedziałeś, uczynisz Żydowi Mardocheuszowi, który siedzi teraz przy wejściu do pałacu. Pamiętaj tylko, żebyś nie pominął niczego z tego, co mówiłeś.
###### **Est 6,11**
 Wziął tedy Haman szaty królewskie i konia, ubrał Mardocheusza, wprowadził na plac miejski konia, na którym siedział Mardocheusz, i wołał głośno: Oto człowiek, któremu król pragnie wyrazić swoje szczególne uznanie.
###### **Est 6,12**
 Potem Mardocheusz znów usiadł przy wejściu do pałacu, a Haman wrócił pośpiesznie do swego domu, bardzo zaniepokojony, ze spuszczoną głową.
###### **Est 6,13**
 A kiedy o wszystkim, co mu się przydarzyło opowiedział, swojej żonie Zeresz i swoim przyjaciołom, powiedzieli jego mądrzy doradcy i żona Zeresz tak: Jeżeli Mardocheusz, który już zaczął gotować ci zgubę, pochodzi z rodu żydowskiego, to nic już nie wskórasz przeciwko niemu. To zapewne on sprowadzi na ciebie zagładę.
###### **Est 6,14**
 Kiedy to jeszcze mówili, nadbiegli eunuchowie królewscy, aby prędzej odprowadzić Hamana na ucztę, którą przygotowała Estera.
# Est 6 WUJ
###### **Est 6,1**
 Onej nocy król spać nie mógł, i kazał sobie przynieść historiej kroniki przeszłych czasów. Które gdy przed nim czytano,
###### **Est 6,2**
 Przyszło do onego miejsca, gdzie było napisano jako Mardocheusz oznajmił zdradę Bagathan i Thares rzezańców, którzy króla Asswerusa zabić chcieli.
###### **Est 6,3**
 Co król usłyszawszy, rzekł: Co za czci i nagrody za tę wierność dostąpił Mardocheusz? Odpowiedzieli mu dworzanie i słudzy jego: Żadnej zgoła nagrody nie odniósł.
###### **Est 6,4**
 I wnet król rzekł: Kto jest w sieni? Bo Aman wszedł był do sieni we wnętrznej domu królewskiego, aby namienił królowi, i kazał obiesić Mardocheusza na szubienicy, która mu była nagotowana.
###### **Est 6,5**
 Odpowiedzieli służebnicy: Aman stoi w sieni. I rzekł król: Niech wnidzie.
###### **Est 6,6**
 A gdy wszedł, rzekł kniemu: Co ma być uczyniono mężowi, którego król chce uczcić? A Aman myśląc w sercu swoim, i rozumiejąc, że król nikogo innego nie chciał uczcić oprócz niego,
###### **Est 6,7**
 Odpowiedział: człowiek, którego król chce uczcić,
###### **Est 6,8**
 Ma być obleczon w szaty królewskie, i wsadzon na konia, który pod siodłem królewskim chodzi, i wziąć koronę królewską na głowę swą,
###### **Est 6,9**
 A pierwszy z książąt i panów królewskich niech dzierży konia jego, a po ulicy miejskiej idąc niech woła i mówi:
###### **Est 6,10**
 I rzekł mu król: Pospiesz się, a wziąwszy szatę i konia, uczyń jakoś powiedział Mardocheuszowi Żydowi, który siedzi przede drzwiami pałacu. Strzeż, abyś nic z tego coś mówił nie opuścił.
###### **Est 6,11**
 A tak wziął Aman szatę królewską i konia, i ubranego Mardocheusza na ulicy miejskiej, i wsadzonego na konia, uprzedzał i wołał. Tej czci godzien jest, kogokolwiek będzie chciał król uczcić.
###### **Est 6,12**
 I wrócił się Mardocheusz do drzwi pałacu: a Aman pokwapił się iść do domu swego żałując i okrywszy głowę.
###### **Est 6,13**
 I powiedział Zares żenie swej, i przyjaciołom wszystko co mu się przydało. Któremu odpowiedzieli mędrcy, które miał w radzie, i żona jego: Jeślić Mardocheusz jest z nasienia Żydowskiego, przed którymeś począł upadać: nie będziesz mu się mógł oprzeć, ale upadniesz przed oczyma jego.
###### **Est 6,14**
 Gdy jeszcze oni mówili, przyszli rzezańcy królewscy i przymusili że co rychlej szedł na ucztę, którą była królowa zgotowała.
