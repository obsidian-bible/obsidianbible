# 2Tes 1 BT5
###### **2Tes 1,1**
 Paweł, Sylwan i Tymoteusz do Kościoła Tesaloniczan w Bogu, Ojcu naszym, i Panu Je-zusie Chrystusie.
###### **2Tes 1,2**
 Łaska wam i pokój od Boga, Ojca naszego, i Pana Jezusa Chrystusa!
###### **2Tes 1,3**
 Bracia, zawsze winniśmy Bogu za was dziękować, co jest rzeczą słuszną, bo wiara wasza bardzo wzrasta, a miłość wzajemna u każdego z was się pomnaża,
###### **2Tes 1,4**
 i to tak, że my sami chlubimy się wami w Kościołach Bożych z powodu waszej cierpliwości i wiary we wszystkich waszych prześladowaniach i uciskach, które znosicie.
###### **2Tes 1,5**
 Są one zapowiedzią sprawiedliwego sądu Boga; celem jego jest uznanie was za godnych królestwa Bożego, dla którego też cierpicie.
###### **2Tes 1,6**
 Bo przecież jest rzeczą słuszną u Boga odpłacić uciskiem tym, którzy was uciskają,
###### **2Tes 1,7**
 a wam, uciśnionym, dać odpoczynek z nami, gdy z nieba objawi się Pan Jezus z aniołami swojej potęgi
###### **2Tes 1,8**
 w płomieniach ognia, wymierzając karę tym, którzy Boga nie uznają i nie są posłuszni Ewangelii Pana naszego, Jezusa.
###### **2Tes 1,9**
 Poniosą oni karę wiecznej zagłady [z dala] od oblicza Pańskiego i od potężnego majestatu Jego
###### **2Tes 1,10**
 w owym dniu, kiedy przyjdzie, aby być uwielbionym w świętych swoich i okazać się godnym podziwu tych wszystkich, którzy uwierzyli, bo wy daliście wiarę naszemu świadectwu.
###### **2Tes 1,11**
 Dlatego modlimy się stale za was, aby Bóg nasz uczynił was godnymi swego wezwania i aby z mocą wypełnił w was wszelkie pragnienie dobra oraz działanie wiary.
###### **2Tes 1,12**
 Aby w was zostało uwielbione imię Pana naszego, Jezusa Chrystusa – a wy w Nim – za łaską Boga naszego i Pana Jezusa Chrystusa.
# 2Tes 1 PAU
###### **2Tes 1,1**
 Paweł, Sylwan i Tymoteusz do Kościoła Tesaloniczan w Bogu, naszym Ojcu, i Panu Jezusie Chrystusie:
###### **2Tes 1,2**
 łaska wam i pokój od Boga, naszego Ojca, i od Pana Jezusa Chrystusa.
###### **2Tes 1,3**
 Bracia, powinniśmy zawsze dziękować za was Bogu. Jest to słuszne, gdyż wasza wiara ogromnie wzrasta, a wzajemna miłość pomnaża się u każdego z was.
###### **2Tes 1,4**
 My sami pośród innych Kościołów Bożych jesteśmy dumni z powodu waszej wytrwałości i wiary, jaką okazujecie, znosząc wszelkie prześladowania i utrapienia.
###### **2Tes 1,5**
 Jest to dowód, że zbliża się sprawiedliwy sąd Boga. Sąd ten wykaże, czy jesteście godni królestwa Bożego, za które cierpicie.
###### **2Tes 1,6**
 Bóg sprawiedliwie odpłaci utrapieniem tym, którzy wam zadali utrapienie.
###### **2Tes 1,7**
 Natomiast wam, cierpiącym, a także nam, przyniesie ulgę, gdy Pan Jezus z nieba objawi się w otoczeniu aniołów Jego mocy.
###### **2Tes 1,8**
 On płomieniem ognia będzie karać tych, którzy nie poznali Boga i nie są posłuszni Ewangelii naszego Pana, Jezusa.
###### **2Tes 1,9**
 Zostaną oni ukarani wieczną zagładą - pozbawieni oglądania Boga i blasku Jego potęgi.
###### **2Tes 1,10**
 W tym dniu Pan przyjdzie, aby zostać uwielbionym przez swoich świętych i być podziwianym przez wszystkich, którzy uwierzyli. Wy właśnie przyjęliście z wiarą nasze świadectwo.
###### **2Tes 1,11**
 Dlatego zawsze modlimy się za was, aby nasz Bóg uczynił was godnymi powołania, aby z mocą spełnił każde dobre pragnienie i doprowadził do końca dzieło wiary.
###### **2Tes 1,12**
 W ten sposób będzie uwielbione imię naszego Pana, Jezusa, w was, a wy w Nim dzięki łasce naszego Boga i Pana, Jezusa Chrystusa.
# 2Tes 1 BP
###### **2Tes 1,1**
 Paweł, Sylwan i Tymoteusz przesyłają pozdrowienia Kościołowi Tesaloniczan w Bogu, Ojcu naszym, i Panu Jezusie Chrystusie.
###### **2Tes 1,2**
 Łaska wam i pokój od Boga Ojca i Pana Jezusa Chrystusa.
###### **2Tes 1,3**
 Słuszną jest rzeczą, bracia, abyśmy nieustannie składali Bogu dzięki za was, gdyż wiara wasza bardzo wzrasta i pogłębia się miłość wzajemna,
###### **2Tes 1,4**
 tak że chlubimy się w Kościołach Bożych waszą wytrwałą wiarą i cierpliwością, z jaką znosicie wszystkie przeciwności i uciski
###### **2Tes 1,5**
 z myślą o sprawiedliwym sądzie Bożym, który uzna was za godnych królestwa Bożego, dla którego cierpicie.
###### **2Tes 1,6**
 Będzie to sprawiedliwe, że Bóg odpłaci uciskiem tym, którzy was uciskają,
###### **2Tes 1,7**
 a wam, uciśnionym, da odpoczynek razem z nami w dniu objawienia, gdy Pan Jezus zstąpi z nieba w płomieniach ognia, z aniołami, zwiastunami swej mocy.
###### **2Tes 1,8**
 Wymierzy On zapłatę tym, którzy nie chcą uznać Boga i nie są posłuszni ewangelii Pana naszego Jezusa.
###### **2Tes 1,9**
 Poniosą oni karę wiecznego odrzucenia od oblicza Pana i od Jego potężnego majestatu
###### **2Tes 1,10**
 w dniu, w którym przyjdzie, aby być uwielbiony w swoich świętych i podziwiany przez wszystkich wierzących w Niego.
###### **2Tes 1,11**
 A wy uwierzyliście naszemu świadectwu i dlatego nieustannie modlimy się za was. Niech Bóg nasz uczyni was godnymi powołania i swoją mocą spełni wszystkie wasze dobre pragnienia - dzieło wiary waszej.
###### **2Tes 1,12**
 Aby było w was uwielbione imię Pana naszego Jezusa Chrystusa, a wy w Nim, za łaską Boga naszego i Pana Jezusa Chrystusa.
# 2Tes 1 BR
###### **2Tes 1,1**
 Paweł, Sylwan i Tymoteusz do Kościoła tesalonickiego, który stanowi jedno z Bogiem Ojcem naszym i Panem Jezusem Chrystusem.
###### **2Tes 1,2**
 Bóg Ojciec i Pan Jezus Chrystus niech was obdarzą łaską i pokojem.
###### **2Tes 1,3**
 Bracia, powinniśmy nieustannie dziękować Bogu za was, gdyż jest to ze wszech miar słuszne. Wasza wiara bowiem staje się coraz silniejsza, a miłość jednych ku drugim obfituje tak bardzo,
###### **2Tes 1,4**
 że chlubimy się wami w Kościołach Bożych. Radujemy się waszą cierpliwością i wytrwałością wiary mimo prześladowań i ucisków.
###### **2Tes 1,5**
 Są one zapowiedzią sprawiedliwego sądu Bożego, a ich znoszenie sprawia, że stajecie się godnymi królestwa Bożego, dla którego cierpicie.
###### **2Tes 1,6**
 Bóg okaże bowiem kiedyś swoją sprawiedliwość, zsyłając cierpienia na tych, którzy są teraz sprawcami waszych cierpień.
###### **2Tes 1,7**
 Wam zaś cierpiącym obecnie ucisk - i nam również - ześle ulgę, gdy Pan Jezus objawi się na niebie,
###### **2Tes 1,8**
 w ogniu płomienistym z aniołami w całej swej potędze, by wymierzyć karę tym, którzy nie uznają Boga i nie słuchają Ewangelii Pana naszego Jezusa.
###### **2Tes 1,9**
 Spotka ich za to kara w postaci wiecznej zagłady oraz odrzucenia od oblicza Pańskiego i Jego potężnego majestatu
###### **2Tes 1,10**
 w owym dniu, kiedy to przyjdzie On, aby być uwielbionym przez tych, którzy do Niego należą, i być podziwianym przez swoich wyznawców. Z ich liczby jesteście również wy, dlatego że uwierzyliście nauce przez nas głoszonej.
###### **2Tes 1,11**
 Dlatego modlimy się za was nieustannie, aby Bóg nasz uczynił was godnymi swego wezwania, aby potęgował w was coraz bardziej wszelkie pragnienie dobra i pomnażał uczynki wypływające z wiary.
###### **2Tes 1,12**
 W ten sposób będzie w was uwielbione imię Pana naszego Jezusa, a w Nim wy także za łaską Boga i Pana naszego Jezusa Chrystusa.
# 2Tes 1 WUJ
###### **2Tes 1,1**
 Paweł i Sylwan i Tymoteusz: kościołowi Thessalonickiemu w Bogu Ojcu naszym i w Panie Jezusie Chrystusie.
###### **2Tes 1,2**
 Łaska wam i pokój od Boga Ojca naszego i Pana Jezusa Chrystusa.
###### **2Tes 1,3**
 Powinniśmy Bogu zawsze dziękować za was bracia, tak jako się godzi, iż barzo roście wiara wasza, i obfituje miłość każdego z was przeciw drugim.
###### **2Tes 1,4**
 Tak iż i my sami przechwalamy się z was w kościelech Bożych, z cierpliwości waszej, i wiary, i we wszelkiem prześladowaniu waszem i w uciskach, które odnosicie.
###### **2Tes 1,5**
 Na przykład sprawiedliwego sądu Bożego, abyście byli godni poczytani w królestwie Bożem, dla którego i cierpicie.
###### **2Tes 1,6**
 Jeśli jedno sprawiedliwa jest u Boga, żeby oddał uciśnienie tym, którzy was uciskają:
###### **2Tes 1,7**
 A wam, którzy uciśnieni jesteście, odpoczynienie znami w objawieniu Pana Jezusa z nieba z anioły możności swojej,
###### **2Tes 1,8**
 W płomieniu ognistym oddawającego pomstę tym, którzy Boga nie znają, i którzy nie są posłuszni Ewanieljej Pana naszego Jezusa Chrystusa.
###### **2Tes 1,9**
 Którzy kaźni odniosą w zatraceniu wieczne od obliczności Pańskiej, i od chwały mocy jego:
###### **2Tes 1,10**
 Gdy przyjdzie, aby był uwielbion w świętych swoich, i dziwnym się stał we wszystkich, którzy uwierzyli. Iż wiara jest dana świadectwu naszemu i was w on dzień.
###### **2Tes 1,11**
 Dla czego też modlimy się zawsze za was: aby was Bóg nasz uczynił godnymi wezwania swego, i wypełnił wszystkę wolą dobrotliwości, i sprawę wiary w mocy,
###### **2Tes 1,12**
 Aby było rozsławione imię Pana naszego Jezusa Chrystusa w was, a wy w nim podług łaski Boga naszego, i Pana Jezusa Chrystusa.
# 2Tes 1 STERN
###### **2Tes 1,1**
 Sza'ul, Sila i Tymoteusz do Wspólnoty Mesjanicznej w Tesalonice, zjednoczonej z Bogiem, naszym Ojcem, i Panem Jeszuą Mesjaszem:
###### **2Tes 1,2**
 łaska wam i szalom od Boga Ojca i Pana Jeszui Mesjasza.
###### **2Tes 1,3**
 Musimy nieustannie dziękować zawsze za was Bogu, bracia, co godzi się czynić, bo wasza ufność wciąż wzrasta, a miłość, jaką żywicie do siebie nawzajem, nadal się pomnaża.
###### **2Tes 1,4**
 Dlatego szczycimy się wami w zgromadzeniach Bożych z powodu waszej wytrwałości i ufności pomimo wszystkich prześladowań i kłopotów, jakich doznajecie.
###### **2Tes 1,5**
 To jasny dowód, że sąd Boży jest sprawiedliwy, a po wszystkim zostaniecie uznani za godnych Królestwa Bożego, za które cierpicie.
###### **2Tes 1,6**
 Bo sprawiedliwe jest, aby Bóg odpłacił podwójnie tym, którzy was dręczą,
###### **2Tes 1,7**
 i aby wraz z nami dał wytchnienie wam, udręczonym, kiedy objawi się z nieba Pan Jeszua ze swoimi potężnymi aniołami
###### **2Tes 1,8**
 w ognistym płomieniu. Ukarze On wtedy tych, którzy nie znają Boga, czyli tych, którzy nie słuchają Dobrej Nowiny naszego Pana Jeszui i nie są jej posłuszni.
###### **2Tes 1,9**
 Poniosą sprawiedliwą karę wiecznej zagłady, z dala od oblicza Pana i od chwały Jego potęgi.
###### **2Tes 1,10**
 W owym Dniu, kiedy przyjdzie On, aby być wielbionym przez swój lud święty i podziwianym przez wszystkich, którzy zaufali, wy będziecie wśród nich, bo zaufaliście złożonemu przez nas świadectwu.
###### **2Tes 1,11**
 Mając to na względzie, zawsze modlimy się za was, aby nasz Bóg uczynił was godnymi Jego powołania i przez swą moc wypełnił każdy wasz dobry zamysł i każdy czyn płynący z waszej ufności.
###### **2Tes 1,12**
 W ten sposób imię naszego Pana Jeszui będzie uwielbione w was, a wy w Nim, zgodnie z łaską naszego Boga i Pana Jeszui Mesjasza.
# 2Tes 1 TRO
###### **2Tes 1,1**
 **παυλος** *paulos* Paweł – [mały] [[G3972]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **σιλουανος** *silouanos* Sylwan – [leśny] [[G4610]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **τιμοθεος** *timotheos* Tymoteusz – [czczący Boga] [[G5095]] [[N-NSM]] **τη** *tē* [[G3588]] WTT-DSF **εκκλησια** *ekklēsia* zgromadzeniu – (społeczności) wywołanych [[G1577]] [[N-DSF]] **θεσσαλονικεων** *thessalonikeōn* Tesaloniczan [[G2331]] WTN-GPM **εν** *en* w [[G1722]] [[PREP]] **θεω** *theō* Bogu [[G2316]] WTN-DSM **πατρι** *patri* Ojcu [[G3962]] WTN-DSM **ημων** *hēmōn* naszym [[G2257]] WTP-1GP **και** *kai* i [[G2532]] [[CONJ]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM
###### **2Tes 1,2**
 **χαρις** *charis* łaska [[G5485]] [[N-NSF]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **και** *kai* i [[G2532]] [[CONJ]] **ειρηνη** *eirēnē* pokój [[G1515]] [[N-NSF]] **απο** *apo* od [[G575]] [[PREP]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **πατρος** *patros* Ojca [[G3962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **και** *kai* i [[G2532]] [[CONJ]] **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **2Tes 1,3**
 **ευχαριστειν** *eucharistein* Dziękować [[G2168]] WTV-PAN **οφειλομεν** *ofeilomen* powinniśmy [[G3784]] WTV-PAI-1P **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **παντοτε** *pantote* zawsze – w każdej chwili [[G3842]] [[ADV]] **περι** *peri* za [[G4012]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **αξιον** *aksion* słuszne – godne [[G514]] WTA-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **οτι** *hoti* gdyż – że [[G3754]] [[CONJ]] **υπεραυξανει** *hyperauksanei* niezmiernie wzrasta [[G5232]] WTV-PAI-3S **η** *hē* [[G3588]] [[T-NSF]] **πιστις** *pistis* wiara [[G4102]] [[N-NSF]] **υμων** *hymōn* wasza [[G5216]] WTP-2GP **και** *kai* i [[G2532]] [[CONJ]] **πλεοναζει** *pleonazei* obfituje [[G4121]] WTV-PAI-3S **η** *hē* [[G3588]] [[T-NSF]] **αγαπη** *agapē* miłość [[G26]] [[N-NSF]] **ενος** *henos* jednego [[G1520]] WTA-GSM **εκαστου** *hekastou* każdego [[G1538]] WTA-GSM **παντων** *pantōn* (ze) wszystkich [[G3956]] WTA-GPM **υμων** *hymōn* was [[G5216]] WTP-2GP **εις** *eis* ku [[G1519]] [[PREP]] **αλληλους** *allēlous* jedni drugim [[G240]] WTC-APM
###### **2Tes 1,4**
 **ωστε** *hōste* tak, że [[G5620]] [[CONJ]] **ημας** *hēmas* nam [[G2248]] WTP-1AP **αυτους** *autous* samym [[G846]] [[P-APM]] **εν** *en* przez [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **καυχασθαι** *kauchasthai* chlubić się – chełpić się [[G2744]] WTV-PNN **εν** *en* w [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **εκκλησιαις** *ekklēsiais* zgromadzeniach – (społecznościach) wywołanych [[G1577]] WTN-DPF **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **υπερ** *hyper* dla [[G5228]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **υπομονης** *hypomonēs* wytrwałości [[G5281]] [[N-GSF]] **υμων** *hymōn* waszej [[G5216]] WTP-2GP **και** *kai* i [[G2532]] [[CONJ]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **εν** *en* we [[G1722]] [[PREP]] **πασιν** *pasin* wszystkich [[G3956]] WTA-DPM **τοις** *tois* [[G3588]] WTT-DPM **διωγμοις** *diōgmois* prześladowaniach [[G1375]] WTN-DPM **υμων** *hymōn* waszych [[G5216]] WTP-2GP **και** *kai* i [[G2532]] [[CONJ]] **ταις** *tais* [[G3588]] WTT-DPF **θλιψεσιν** *thlipsesin* uciskach – utrapieniach [[G2347]] WTN-DPF **αις** *hais* które [[G3739]] WTR-DPF **ανεχεσθε** *anechesthe* znosicie [[G430]] WTV-PNI-2P
###### **2Tes 1,5**
 **ενδειγμα** *endeigma* dowód – wykazanie [[G1730]] WTN-NSN **της** *tēs* [[G3588]] [[T-GSF]] **δικαιας** *dikaias* sprawiedliwego [[G1342]] WTA-GSF **κρισεως** *kriseōs* sądu [[G2920]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εις** *eis* w [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **καταξιωθηναι** *kataksiōthēnai* zostać uznanymi za godnych [[G2661]] WTV-APN **υμας** *hymas* wam [[G5209]] WTP-2AP **της** *tēs* [[G3588]] [[T-GSF]] **βασιλειας** *basileias* Królestwa [[G932]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **υπερ** *hyper* dla [[G5228]] [[PREP]] **ης** *hēs* którego [[G3739]] [[R-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **πασχετε** *paschete* cierpicie [[G3958]] WTV-PAI-2P
###### **2Tes 1,6**
 **ειπερ** *eiper* jeśli tylko – jeśli w ogóle [[G1512]] WTCOND **δικαιον** *dikaion* sprawiedliwe [[G1342]] WTA-NSN **παρα** *para* u [[G3844]] [[PREP]] **θεω** *theō* Boga [[G2316]] WTN-DSM **ανταποδουναι** *antapodounai* odpłacić – oddać w zamian [[G467]] [[V-2AAN]] **τοις** *tois* [[G3588]] WTT-DPM **θλιβουσιν** *thlibousin* uciskającym – trapiącym [[G2346]] WTV-PAP-DPM **υμας** *hymas* was [[G5209]] WTP-2AP **θλιψιν** *thlipsin* uciskiem – utrapieniem [[G2347]] WTN-ASF
###### **2Tes 1,7**
 **και** *kai* i [[G2532]] [[CONJ]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **τοις** *tois* [[G3588]] WTT-DPM **θλιβομενοις** *thlibomenois* którzy jesteście uciskani – którzy jesteście trapieni [[G2346]] WTV-PPP-DPM **ανεσιν** *anesin* ulgę – wytchnienie [[G425]] WTN-ASF **μεθ** *meth* z [[G3326]] [[PREP]] **ημων** *hēmōn* nami [[G2257]] WTP-1GP **εν** *en* podczas [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **αποκαλυψει** *apokalypsei* objawienia się [[G602]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **απ** *ap* z [[G575]] [[PREP]] **ουρανου** *ouranou* nieba [[G3772]] [[N-GSM]] **μετ** *met* ze [[G3326]] [[PREP]] **αγγελων** *angelōn* zwiastunami [[G32]] WTN-GPM **δυναμεως** *dynameōs* mocy [[G1411]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **2Tes 1,8**
 **εν** *en* w [[G1722]] [[PREP]] **πυρι** *pyri* ogniu [[G4442]] WTN-DSN **φλογος** *flogos* płomienia [[G5395]] [[N-GSF]] **διδοντος** *didontos* dającego [[G1325]] WTV-PAP-GSM **εκδικησιν** *ekdikēsin* ukaranie [[G1557]] WTN-ASF **τοις** *tois* [[G3588]] WTT-DPM **μη** *mē* nie [[G3361]] [[PRT-N]] **ειδοσιν** *eidosin* znającym [[G1492]] WTV-RAP-DPM **θεον** *theon* Boga [[G2316]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **τοις** *tois* [[G3588]] WTT-DPM **μη** *mē* nie [[G3361]] [[PRT-N]] **υπακουουσιν** *hypakouousin* którzy są posłuszni [[G5219]] WTV-PAP-DPM **τω** *tō* [[G3588]] WTT-DSN **ευαγγελιω** *euangeliō* dobrej nowinie [[G2098]] WTN-DSN **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **2Tes 1,9**
 **οιτινες** *hoitines* którzy [[G3748]] WTR-NPM **δικην** *dikēn* sprawiedliwość [[G1349]] WTN-ASF **τισουσιν** *tisousin* zapłacą [[G5099]] WTV-FAI-3P **ολεθρον** *olethron* zagładą – ruiną [[G3639]] [[N-ASM]] **αιωνιον** *aiōnion* wieczną [[G166]] WTA-ASM **απο** *apo* z dala od [[G575]] [[PREP]] **προσωπου** *prosōpou* oblicza – twarzy [[G4383]] [[N-GSN]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **απο** *apo* od [[G575]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **δοξης** *doksēs* chwały [[G1391]] [[N-GSF]] **της** *tēs* [[G3588]] [[T-GSF]] **ισχυος** *ischyos* siły [[G2479]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **2Tes 1,10**
 **οταν** *hotan* kiedy [[G3752]] [[CONJ]] **ελθη** *elthē* przyszedłby [[G2064]] WTV-2AAS-3S **ενδοξασθηναι** *endoksasthēnai* zostać wychwalonym [[G1740]] WTV-APN **εν** *en* wśród [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPM **αγιοις** *hagiois* świętych [[G40]] WTA-DPM **αυτου** *autou* Jego [[G846]] [[P-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **θαυμασθηναι** *thaumasthēnai* zostać podziwianym [[G2296]] WTV-APN **εν** *en* wśród [[G1722]] [[PREP]] **πασιν** *pasin* wszystkich [[G3956]] WTA-DPM **τοις** *tois* [[G3588]] WTT-DPM **πιστευουσιν** *pisteuousin* wierzących [[G4100]] WTV-PAP-DPM **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **επιστευθη** *episteuthē* znalazło wiarę [[G4100]] [[V-API-3S]] **το** *to* [[G3588]] WTT-NSN **μαρτυριον** *martyrion* świadectwo [[G3142]] WTN-NSN **ημων** *hēmōn* nasze [[G2257]] WTP-1GP **εφ** *ef* przed [[G1909]] [[PREP]] **υμας** *hymas* wami [[G5209]] WTP-2AP **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **ημερα** *hēmera* dniu [[G2250]] [[N-DSF]] **εκεινη** *ekeinē* tym [[G1565]] WTD-DSF
###### **2Tes 1,11**
 **εις** *eis* O [[G1519]] [[PREP]] **ο** *ho* co [[G3739]] WTR-ASN **και** *kai* i [[G2532]] [[CONJ]] **προσευχομεθα** *proseuchometha* modlimy się [[G4336]] WTV-PNI-1P **παντοτε** *pantote* zawsze – w każdej chwili [[G3842]] [[ADV]] **περι** *peri* za [[G4012]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **ινα** *hina* aby [[G2443]] [[CONJ]] **υμας** *hymas* was [[G5209]] WTP-2AP **αξιωση** *aksiōsē* uznałby za godnych [[G515]] WTV-AAS-3S **της** *tēs* [[G3588]] [[T-GSF]] **κλησεως** *klēseōs* powołania [[G2821]] [[N-GSF]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ημων** *hēmōn* nasz [[G2257]] WTP-1GP **και** *kai* i [[G2532]] [[CONJ]] **πληρωση** *plērōsē* wypełniłby [[G4137]] WTV-AAS-3S **πασαν** *pasan* całe [[G3956]] WTA-ASF **ευδοκιαν** *eudokian* upodobanie [[G2107]] WTN-ASF **αγαθωσυνης** *agathōsynēs* dobroci [[G19]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **εργον** *ergon* dzieło [[G2041]] WTN-ASN **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **εν** *en* przez [[G1722]] [[PREP]] **δυναμει** *dynamei* moc [[G1411]] [[N-DSF]]
###### **2Tes 1,12**
 **οπως** *hopōs* żeby [[G3704]] [[ADV]] **ενδοξασθη** *endoksasthē* zostałoby wychwalone [[G1740]] WTV-APS-3S **το** *to* [[G3588]] WTT-NSN **ονομα** *onoma* imię [[G3686]] WTN-NSN **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **εν** *en* w [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **και** *kai* i [[G2532]] [[CONJ]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **εν** *en* w [[G1722]] [[PREP]] **αυτω** *autō* Nim [[G846]] WTP-DSM **κατα** *kata* według [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **χαριν** *charin* łaski [[G5485]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **και** *kai* i [[G2532]] [[CONJ]] **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
