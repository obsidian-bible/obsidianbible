# Ef 2 BT5
###### **Ef 2,1**
 I wy byliście umarłymi na skutek waszych występków i grzechów,
###### **Ef 2,2**
 w których żyliście niegdyś według doczesnego sposobu tego świata, według sposobu Władcy mocarstwa powietrza, to jest ducha, który działa teraz w synach buntu.
###### **Ef 2,3**
 Pośród nich także my wszyscy niegdyś postępowaliśmy według żądz naszego ciała, spełniając zachcianki ciała i myśli zdrożnych. I byliśmy potomstwem z natury zasługującym na gniew, jak i wszyscy inni.
###### **Ef 2,4**
 A Bóg, będąc bogaty w miłosierdzie, przez wielką swą miłość, jaką nas umiłował,
###### **Ef 2,5**
 i to nas, umarłych na skutek występków, razem z Chrystusem przywrócił do życia – łaską [bowiem] jesteście zbawieni –
###### **Ef 2,6**
 razem też wskrzesił i razem posadził na wyżynach niebieskich – w Chrystusie Jezusie,
###### **Ef 2,7**
 aby w nadchodzących wiekach przeogromne bogactwo swej łaski okazać przez dobroć względem nas, w Chrystusie Jezusie.
###### **Ef 2,8**
 Łaską bowiem jesteście zbawieni przez wiarę. A to pochodzi nie od was, lecz jest darem Boga:
###### **Ef 2,9**
 nie z uczynków, aby się nikt nie chlubił.
###### **Ef 2,10**
 Jesteśmy bowiem Jego dziełem, stworzeni w Chrystusie Jezusie do dobrych czynów, które Bóg z góry przygotował, abyśmy je pełnili.
###### **Ef 2,11**
 Dlatego pamiętajcie, że niegdyś wy – poganie co do ciała, zwani "nieobrzezanymi" przez tych, którzy zowią się "obrzezanymi" od znaku dokonanego ręką na ciele –
###### **Ef 2,12**
 w owym czasie byliście poza Chrystusem, obcy względem społeczności Izraela i bez udziału w przymierzach obietnicy, nie mający nadziei ani Boga na tym świecie.
###### **Ef 2,13**
 Ale teraz w Chrystusie Jezusie wy, którzy niegdyś byliście daleko, staliście się bliscy przez krew Chrystusa.
###### **Ef 2,14**
 On bowiem jest naszym pokojem. On, który obie części [ludzkości] uczynił jednością, bo zburzył rozdzielający je mur – wrogość. W swym ciele
###### **Ef 2,15**
 pozbawił On mocy Prawo przykazań, wyrażone w zarządzeniach, aby z dwóch [rodzajów ludzi] stworzyć w sobie jednego nowego człowieka, wprowadzając pokój,
###### **Ef 2,16**
 i [w ten sposób] jednych, jak i drugich znów pojednać z Bogiem, w jednym Ciele przez krzyż, w sobie zadawszy śmierć wrogości.
###### **Ef 2,17**
 A przyszedłszy, zwiastował pokój wam, którzyście daleko, i pokój tym, którzy są blisko,
###### **Ef 2,18**
 bo przez Niego jedni i drudzy w jednym Duchu mamy przystęp do Ojca.
###### **Ef 2,19**
 A więc nie jesteście już obcymi i przybyszami, ale jesteście współobywatelami świętych i domownikami Boga –
###### **Ef 2,20**
 zbudowani na fundamencie apostołów i proroków, gdzie głowicą węgła jest sam Chrystus Jezus.
###### **Ef 2,21**
 W Nim zespalana cała budowla rośnie na świętą w Panu świątynię,
###### **Ef 2,22**
 w Nim i wy także wznosicie się we wspólnym budowaniu, by stanowić mieszkanie Boga przez Ducha.
# Ef 2 PAU
###### **Ef 2,1**
 Także wy byliście umarli z powodu waszych występków i grzechów,
###### **Ef 2,2**
 które popełnialiście wtedy, gdy postępowaliście zgodnie z zasadami tego świata, w posłuszeństwie temu, który panuje nad mocą, powietrzem, duchem działającym obecnie w synach buntu.
###### **Ef 2,3**
 Wśród nich także my wszyscy ulegaliśmy niegdyś żądzom naszego ciała, poddając się zachciankom ciała i myśli. Dlatego, jak inni, byliśmy z natury dziećmi gniewu.
###### **Ef 2,4**
 Bóg jednak, bogaty w miłosierdzie, dzięki swej wielkiej miłości, którą obdarzył nas,
###### **Ef 2,5**
 umarłych z powodu występków, przywrócił nas do życia z Chrystusem. Łaską jesteście zbawieni!
###### **Ef 2,6**
 On w Chrystusie Jezusie ożywił nas i posadził na wyżynach niebieskich,
###### **Ef 2,7**
 aby w nadchodzących czasach ukazać niezwykłe bogactwo swojej łaski poprzez dobroć, jaką darzy nas w Chrystusie Jezusie.
###### **Ef 2,8**
 Łaską bowiem jesteście zbawieni przez wiarę! Nie jest to więc waszą zasługą, lecz darem Boga.
###### **Ef 2,9**
 Nie za dokonane czyny, aby nikt się nie chełpił.
###### **Ef 2,10**
 Jesteśmy Jego dziełem, stworzeni w Chrystusie Jezusie dla dobrych czynów, które Bóg dla nas przygotował, abyśmy zgodnie z nimi postępowali.
###### **Ef 2,11**
 Dlatego pamiętajcie, że niegdyś wy, poganie - nazywani nieobrzezanymi przez tych, którzy siebie nazywają obrzezanymi, z racji znaku dokonanego ludzką ręką -
###### **Ef 2,12**
 w tamtym czasie żyliście bez Chrystusa. Byliście wyłączeni ze społeczności Izraela i nie mieliście udziału w przymierzach z obietnicą. Brakowało wam nadziei i bez Boga żyliście na świecie.
###### **Ef 2,13**
 Lecz teraz wy, którzy niegdyś byliście daleko, w Chrystusie Jezusie staliście się bliscy dzięki Jego krwi.
###### **Ef 2,14**
 On bowiem jest naszym pokojem. On w swoim ciele z dwóch części uczynił jedno i obalił dzielący je mur wrogości.
###### **Ef 2,15**
 Uchylił Prawo przykazań zawartych w przepisach, aby z dwóch części stworzyć w sobie jednego nowego człowieka i wprowadzić pokój.
###### **Ef 2,16**
 On pojednał z Bogiem obie części w jednym ciele przez krzyż, zabijając tę wrogość w sobie.
###### **Ef 2,17**
 Przyszedł ogłosić dobrą nowinę: pokój wam, którzy byliście daleko i pokój tym, którzy byli blisko.
###### **Ef 2,18**
 Dzięki Niemu jedni i drudzy mamy dostęp do Ojca w jednym Duchu.
###### **Ef 2,19**
 Tak więc nie jesteście już obcymi i przybyszami, ale współobywatelami na równi ze świętymi i domownikami Boga.
###### **Ef 2,20**
 Jesteście zbudowani na fundamencie apostołów i proroków, a kamieniem węgielnym jest sam Chrystus Jezus.
###### **Ef 2,21**
 W Nim złączona cała budowla wzrasta, aby stać się świętą w Panu świątynią.
###### **Ef 2,22**
 W Nim także wy wspólnie budujecie, aby być mieszkaniem Boga w Duchu.
# Ef 2 BP
###### **Ef 2,1**
 I wyście umarli wskutek występków i grzechów,
###### **Ef 2,2**
 w których niegdyś żyliście za przykładem tego świata, według władcy sfer powietrza, to jest ducha, który teraz działa w buntownikach.
###### **Ef 2,3**
 Dawniej i myśmy wszyscy na równi z nimi żyli w pożądliwościach cielesnych, spełniając zachcianki ciała i zdrożnych myśli. I podobnie jak inni byliśmy z natury zasługującymi na gniew,
###### **Ef 2,4**
 lecz Bóg w ogromie miłosierdzia i swojej wielkiej miłości, jaką nas umiłował, przywrócił nam życie
###### **Ef 2,5**
 razem z Chrystusem, chociaż przez grzechy byliśmy pogrążeni w śmierci. Wasze zbawienie z łaski zostało dokonane.
###### **Ef 2,6**
 Wskrzesił nas z martwych w Chrystusie Jezusie i razem [z Nim] umieścił w niebie.
###### **Ef 2,7**
 Tak w przyszłych wiekach na przykładzie wyświadczonej nam dobroci w Chrystusie Jezusie chciał ukazać niewyczerpane bogactwo swej łaski.
###### **Ef 2,8**
 Przez łaskę bowiem jesteście zbawieni mocą wiary. Nie pochodzi to z waszej zasługi, lecz z daru Bożego.
###### **Ef 2,9**
 Nie z uczynków, aby się nikt nie przechwalał.
###### **Ef 2,10**
 Dziełem Jego jesteśmy, stworzeni w Chrystusie Jezusie dla dobrych czynów, które Bóg od dawna określił, abyśmy je spełniali.
###### **Ef 2,11**
 Pamiętajcie zatem, że ci, którzy uważają się za obrzezanych na skutek znaku wykonywanego ręką na ciele, nazywali niegdyś nie obrzezanymi was, którzy z urodzenia byliście poganami.
###### **Ef 2,12**
 W tym czasie bowiem żyliście bez Chrystusa, wykluczeni ze społeczności Izraela, bez udziału w przymierzach obietnicy, bez nadziei i bez Boga w świecie.
###### **Ef 2,13**
 Ale wy [chociaż] kiedyś byliście daleko, teraz jesteście blisko przez łączność z Chrystusem Jezusem i dzięki Jego Krwi.
###### **Ef 2,14**
 On jest naszym pokojem. On wyprowadził jedność w rozdartą ludzkość, ponieważ usunął mur, który ją odgradzał i dzielił. On w swoim ciele
###### **Ef 2,15**
 pozbawił mocy Prawo [z jego] przepisami i nakazami. Przywrócił pokój, tworząc w swojej osobie z dwóch [nieprzyjaznych] stron jednego nowego człowieka.
###### **Ef 2,16**
 Obydwie strony, złączywszy w jedno ciało, przez krzyż pojednał z Bogiem i w sobie położył kres wrogości.
###### **Ef 2,17**
 A przyszedłszy ogłosił ewangelię pokoju wam, będącym daleko, oraz pokój tym, co są blisko.
###### **Ef 2,18**
 Przez Niego mamy jedni i drudzy dostęp do Ojca w jednym Duchu.
###### **Ef 2,19**
 A zatem nie jesteście już obcymi i przychodniami, ale współobywatelami świętych i domownikami Boga.
###### **Ef 2,20**
 Zbudowani jesteście na fundamencie apostołów i proroków, gdzie kamieniem węgielnym jest sam Chrystus Jezus.
###### **Ef 2,21**
 W Nim cała budowla zespolona rozrasta się w świętą w Panu świątynię,
###### **Ef 2,22**
 aby przez Ducha przygotować mieszkanie Boga.
# Ef 2 BR
###### **Ef 2,1**
 Wy również byliście umarłymi [duchowo] z powodu waszych występków i grzechów,
###### **Ef 2,2**
 w których żyliście zgodnie z doczesnymi wymogami tego świata; ulegaliście władzy mocy duchowych w przestworzach, to jest [poddawaliście się] temu duchowi, który działa teraz poprzez ludzi buntujących się przeciw Bogu.
###### **Ef 2,3**
 Zresztą, podobnie jak oni, my wszyscy żyliśmy według pożądliwości naszego ciała, ulegając jego skłonnościom i godząc się na zdrożne myśli. I byliśmy pokoleniem z natury zasługującym na gniew [Boży], podobnie jak wszyscy inni.
###### **Ef 2,4**
 Lecz Bóg jest przebogaty w swoim miłosierdziu, a Jego wielka miłość, którą nas umiłował, sprawiła,
###### **Ef 2,5**
 iż właśnie wtedy, gdy byliśmy umarli z powodu naszych występków, przywrócił nas razem z Chrystusem do życia. [Tylko] dzięki łasce Bożej zostaliśmy ocaleni.
###### **Ef 2,6**
 Razem z Nim również wskrzesił nas i pozwolił współzasiadać na wyżynach niebieskich nam, stanowiącym jedno z Chrystusem Jezusem.
###### **Ef 2,7**
 Wszystko zaś to uczynił, aby okazać po wszystkie czasy bezmiar swej łaski udzielonej nam w Jezusie Chrystusie.
###### **Ef 2,8**
 Jesteście bowiem zbawieni mocą łaski przez wiarę. Tak więc jest to dar Boży, a nie wasze dzieło.
###### **Ef 2,9**
 Nie zawdzięczacie go własnym wysiłkom i dlatego nikt z was nie może się nim chlubić.
###### **Ef 2,10**
 Jesteśmy bowiem dziełem Bożym; to Bóg w Chrystusie Jezusie stworzył nas, byśmy pełnili dobre uczynki, przygotowane zresztą u Boga od dawna do spełniania przez nas.
###### **Ef 2,11**
 Tak więc wy, poganie z urodzenia, zwani nie obrzezanymi przez tych, którzy - ze względu na znak uczyniony ludzką ręką na ich ciele - zowią się obrzezanymi, pamiętajcie,
###### **Ef 2,12**
 że kiedyś byliście poza Chrystusem; uchodziliście za obcych względem społeczności izraelskiej; nie mieliście też udziału w obietnicach przymierzy; byliście pozbawieni i nadziei, i Boga na tym świecie.
###### **Ef 2,13**
 Lecz teraz, zjednoczeni z Chrystusem Jezusem, wy, którzy niegdyś byliście daleko, staliście się bliscy przez krew Chrystusa.
###### **Ef 2,14**
 Chrystus bowiem jest dla nas uosobieniem pokoju przez to, że z Żydów i nie-Żydów, burząc istniejący między nimi mur wrogości, uczynił w swoim ciele jeden lud [Boży].
###### **Ef 2,15**
 Pozbawił również mocy Prawo żydowskie razem z jego przykazaniami i zaleceniami po to, by z dwóch różnych narodów utworzyć jeden lud nowy. W ten sposób wprowadził [prawdziwy] pokój i
###### **Ef 2,16**
 w jednym ciele, przez krzyż, będący w Nim samym zniweczeniem wszelkiej nienawiści, jednych i drugich znów pogodził z Bogiem.
###### **Ef 2,17**
 Tak więc Chrystus przyszedł, by zwiastować Dobrą Nowinę pokoju zarówno tym, którzy są daleko [od Boga], jak i wam, którzy jesteście blisko [Niego].
###### **Ef 2,18**
 Przez Chrystusa bowiem wszyscy my [Żydzi i nie-Żydzi], korzystając z pomocy tego samego Ducha, mamy dostęp do Ojca.
###### **Ef 2,19**
 Zatem wy również [ongiś poganie] nie jesteście już cudzoziemcami i przychodniami z daleka lecz współobywatelami świętych i domownikami Boga.
###### **Ef 2,20**
 [Wy również] jesteście budowlą wzniesioną na fundamencie, który tworzą apostołowie i prorocy, wsparci o ten kamień węgielny, którym jest sam Jezus Chrystus.
###### **Ef 2,21**
 To dzięki Niemu cała budowla zespolona wznosi się coraz bardziej ku górze jako wspaniała świątynia w Panu.
###### **Ef 2,22**
 Stanowiąc jedność z Nim, wy również razem z innymi jesteście częścią budowli mającej stać się domem, w którym zamieszka przez Ducha swojego sam Bóg.
# Ef 2 WUJ
###### **Ef 2,1**
 I was, którzyście byli umarli przez występki i grzechy wasze,
###### **Ef 2,2**
 (W którycheście niekiedy chodzili wedle wieku świata tego, według książęcia władzy powietrza tego, Ducha, który teraz moc pokazuje w synach niewierności).
###### **Ef 2,3**
 Między którymi i my wszyscy obcowaliśmy niekiedy w pożądliwościach ciała naszego, czyniąc wolą ciała i myśli, i byliśmy z przyrodzenia synami gniewu jako i drudzy.
###### **Ef 2,4**
 Lecz Bóg (który jest bogatym w miłosierdziu) dla zbytniej miłości swojej, którą nas umiłował,
###### **Ef 2,5**
 I gdyśmy byli umarłymi przez grzechy, ożywił nas społem w Chrystusie (którego łaską jesteście zbawieni).
###### **Ef 2,6**
 I wzbudził pospołu, i wespółek posadził na niebiesiech w Chrystusie Jezusie,
###### **Ef 2,7**
 Aby okazał w nadchodzących wiekach obfite bogactwa łaski swojej, w dobrotliwości przeciwko nam w Chrystusie Jezusie.
###### **Ef 2,8**
 Abowiem łaską jesteście zbawieni przez wiarę (i to nie z was, bo dar Boży jest)
###### **Ef 2,9**
 Nie z uczynków, aby się kto nie chlubił.
###### **Ef 2,10**
 Abowiem stworzeniem jego jesteśmy, stworzeni w Chrystusie Jezusie na uczynki dobre, które przedtem Bóg zgotował, abyśmy w nich chodzili.
###### **Ef 2,11**
 Przetoż pamiętajcie, żeście niekiedy wy Pogani w ciele, którzy nazwani jesteście odrzeskiem, od tego, które zowią obrzezaniem na ciele rękoma uczynionem:
###### **Ef 2,12**
 Którzyście byli na on czas bez Chrystusa, oddaleni od obcowania z Izraelem, i obcemi od testamentów obietnice nadzieje nie mający, i bez Boga na tym świecie.
###### **Ef 2,13**
 A teraz w Chrystusie Jezusie wy, którzyście niekiedy byli daleko, staliście się blizko we krwi Chrystusowej.
###### **Ef 2,14**
 Abowiem on jest pokojem naszym, który oboje jednem uczynił, i średnią ścianę przegrody rozwalił nieprzyjaźń w ciele swojem:
###### **Ef 2,15**
 I zakon przykazania wyrokami skaziwszy: aby dwu stworzył w samym sobie w jednego nowego człowieka, czyniąc pokój.
###### **Ef 2,16**
 I pojednał obudwu w jednem ciele z Bogiem przez krzyż, umorzywszy nieprzyjaźni w samym sobie.
###### **Ef 2,17**
 I przyszedszy opowiedział pokój wam, którzyście byli daleko, i pokój tym, którzy blizko.
###### **Ef 2,18**
 Abowiem przezeń mamy przystęp obój w jednym Duchu do Ojca.
###### **Ef 2,19**
 A przeto już nie jesteście goście i przychodnie: aleście mieszczanie z świętemi i domownicy Boży,
###### **Ef 2,20**
 Wybudowani na fundamencie Apostołów i Proroków, gdzie głównym węgielnym kamieniem sam Jezus Chrystus:
###### **Ef 2,21**
 Na którym wszystko budowanie wywiedzione, roście w kościół święty w Panu:
###### **Ef 2,22**
 Na którym też i wy pospołu budujecie się na mieszkanie Boże w Duchu.
# Ef 2 STERN
###### **Ef 2,1**
 Byliście niegdyś martwi z powodu swoich grzechów i aktów nieposłuszeństwa.
###### **Ef 2,2**
 Chodziliście drogami 'olam haze i byliście posłuszni Władcy Mocy Powietrznych, który wciąż działa wśród nieposłusznych.
###### **Ef 2,3**
 Zresztą wszyscyśmy kiedyś żyli w ten sposób - podążając za namiętnościami swej starej natury i ulegając zachciankom swej starej natury i własnych myśli. W naszym naturalnym stanie byliśmy skazani na gniew Boży, jak wszyscy.
###### **Ef 2,4**
 Lecz Bóg tak bogaty jest w miłosierdzie i żywi do nas miłość tak głęboką,
###### **Ef 2,5**
 że nawet gdy byliśmy jeszcze martwi z powodu swoich aktów nieposłuszeństwa, przywrócił nas On do życia wraz z Mesjaszem - łaską zostaliście wyzwoleni.
###### **Ef 2,6**
 Bóg zatem wskrzesił nas z Mesjaszem Jeszuą i posadził wraz z Nim w niebie,
###### **Ef 2,7**
 aby w nadchodzących wiekach ukazać, jak nieskończenie bogata jest Jego łaska, jak wielka jest Jego dobroć ku nam, zjednoczonym z Mesjaszem Jeszuą.
###### **Ef 2,8**
 Bo zostaliście wyzwoleni łaską poprzez ufanie, i nawet ono nie jest waszym osiągnięciem, ale darem Bożym.
###### **Ef 2,9**
 Nie zostaliście wyzwoleni za sprawą własnych czynów, nikt więc nie powinien się chełpić.
###### **Ef 2,10**
 Jesteśmy bowiem Bożym dziełem, stworzeni w jedności z Mesjaszem Jeszuą do życia dobrych czynów, już przygotowanych przez Boga dla nas do wykonania.
###### **Ef 2,11**
 Dlatego pamiętajcie o swoim poprzednim położeniu: wy, rodowici nie-Żydzi - zwani Nieobrzezanymi przez tych, którzy tylko z powodu pewnego zabiegu na ciele zwani są Obrzezanymi -
###### **Ef 2,12**
 w owym czasie nie mieliście Mesjasza. Byliście wyłączeni z życia narodowego Israela. Byliście obcy przymierzom ucieleśniającym obietnicę Bożą. Byliście w tym świecie bez nadziei i bez Boga.
###### **Ef 2,13**
 Lecz teraz wy, niegdyś dalecy, zostaliście przywiedzeni blisko, za sprawą przelania krwi Mesjasza.
###### **Ef 2,14**
 Gdyż On sam jest naszym szalomem - On uczynił z nas dwojga jedno i zburzył dzielącą nas m'chicę,
###### **Ef 2,15**
 niszcząc w swoim własnym ciele wrogość spowodowaną przez Torę i jej nakazy wyrażone w formie rozporządzeń. Uczynił to, aby w jedności z sobą stworzyć z tych dwóch grup jedną nową ludzkość i w ten sposób zaprowadzić szalom
###### **Ef 2,16**
 i aby zostawszy straconym na palu jak zbrodniarz i w ten sposób zgładziwszy w sobie tę wrogość, pojednać z Bogiem jednych i drugich w jednym ciele.
###### **Ef 2,17**
 A kiedy przyszedł, ogłosił jako Dobrą Nowinę szalom wam, którzyście daleko, i szalom tym, którzy są blisko,
###### **Ef 2,18**
 wieść o tym, że przez Niego jedni i drudzy mamy przystęp w jednym Duchu do Ojca.
###### **Ef 2,19**
 Nie jesteście już więc cudzoziemcami i obcymi. Przeciwnie, jesteście współobywatelami ludu Bożego i członkami Bożej rodziny.
###### **Ef 2,20**
 Wznosicie budowlę na fundamencie wysłanników i proroków, a kamieniem węgielnym jest sam Jeszua Mesjasz.
###### **Ef 2,21**
 W jedności z Nim cała budowla trzyma się spójnie i rośnie w święty przybytek w jedności z Panem.
###### **Ef 2,22**
 Tak, w jedności z Nim wy sami stajecie się razem częścią budowli duchowego mieszkania dla Boga!
# Ef 2 TRO
###### **Ef 2,1**
 **και** *kai* A [[G2532]] [[CONJ]] **υμας** *hymas* was [[G5209]] WTP-2AP **οντας** *ontas* będących [[G5607]] WTV-PXP-APM **νεκρους** *nekrous* martwymi [[G3498]] WTA-APM **τοις** *tois* (dla) [[G3588]] WTT-DPN **παραπτωμασιν** *paraptōmasin* upadków – występków [[G3900]] WTN-DPN **και** *kai* i [[G2532]] [[CONJ]] **ταις** *tais* (dla) [[G3588]] WTT-DPF **αμαρτιαις** *hamartiais* grzechów [[G266]] WTN-DPF
###### **Ef 2,2**
 **εν** *en* w [[G1722]] [[PREP]] **αις** *hais* których [[G3739]] WTR-DPF **ποτε** *pote* niegdyś [[G4218]] WTPRT **περιεπατησατε** *periepatēsate* postępowaliście – chodziliście [[G4043]] WTV-AAI-2P **κατα** *kata* według [[G2596]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **αιωνα** *aiōna* wieku [[G165]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **κοσμου** *kosmou* świata [[G2889]] [[N-GSM]] **τουτου** *toutou* tego [[G5127]] WTD-GSM **κατα** *kata* według [[G2596]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **αρχοντα** *archonta* przywódcy – przełożonego [[G758]] [[N-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **εξουσιας** *eksousias* władcy [[G1849]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **αερος** *aeros* powietrza [[G109]] [[N-GSM]] **του** *tou* [[G3588]] WTT-GSN **πνευματος** *pneumatos* ducha [[G4151]] [[N-GSN]] **του** *tou* [[G3588]] WTT-GSN **νυν** *nyn* teraz [[G3568]] [[ADV]] **ενεργουντος** *energountos* działającego [[G1754]] WTV-PAP-GSN **εν** *en* w [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPM **υιοις** *hyiois* synach [[G5207]] WTN-DPM **της** *tēs* [[G3588]] [[T-GSF]] **απειθειας** *apeitheias* nieposłuszeństwa – nieuległości [[G543]] [[N-GSF]]
###### **Ef 2,3**
 **εν** *en* wśród [[G1722]] [[PREP]] **οις** *hois* których [[G3739]] WTR-DPM **και** *kai* i [[G2532]] [[CONJ]] **ημεις** *hēmeis* my [[G2249]] WTP-1NP **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **ανεστραφημεν** *anestrafēmen* postępowaliśmy – zostaliśmy obróceni [[G390]] WTV-2API-1P **ποτε** *pote* niegdyś [[G4218]] WTPRT **εν** *en* w [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **επιθυμιαις** *epithymiais* pożądaniach – żądzach [[G1939]] WTN-DPF **της** *tēs* [[G3588]] [[T-GSF]] **σαρκος** *sarkos* ciała [[G4561]] [[N-GSF]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ποιουντες** *poiountes* czyniąc [[G4160]] WTV-PAP-NPM **τα** *ta* [[G3588]] WTT-APN **θεληματα** *thelēmata* wolę [[G2307]] WTN-APN **της** *tēs* [[G3588]] [[T-GSF]] **σαρκος** *sarkos* ciała [[G4561]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPF **διανοιων** *dianoiōn* myśli – umysłów [[G1271]] WTN-GPF **και** *kai* i [[G2532]] [[CONJ]] **ημεν** *ēmen* byliśmy [[G1510]] WTV-IXI-1P **τεκνα** *tekna* dzieci [[G5043]] WTN-NPN **φυσει** *fysei* pod względem natury [[G5449]] [[N-DSF]] **οργης** *orgēs* gniewu [[G3709]] [[N-GSF]] **ως** *hōs* jak [[G5613]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **λοιποι** *loipoi* pozostali [[G3062]] WTA-NPM
###### **Ef 2,4**
 **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **πλουσιος** *plousios* bogaty [[G4145]] [[A-NSM]] **ων** *ōn* będąc [[G5607]] [[V-PXP-NSM]] **εν** *en* w [[G1722]] [[PREP]] **ελεει** *eleei* miłosierdzie – litość [[G1656]] WTN-DSN **δια** *dia* przez [[G1223]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **πολλην** *pollēn* wielką [[G4183]] WTA-ASF **αγαπην** *agapēn* miłość [[G26]] WTN-ASF **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ην** *hēn* którą [[G3739]] WTR-ASF **ηγαπησεν** *ēgapēsen* umiłował [[G25]] [[V-AAI-3S]] **ημας** *hēmas* nas [[G2248]] WTP-1AP
###### **Ef 2,5**
 **και** *kai* i [[G2532]] [[CONJ]] **οντας** *ontas* będących [[G5607]] WTV-PXP-APM **ημας** *hēmas* nas [[G2248]] WTP-1AP **νεκρους** *nekrous* martwymi [[G3498]] WTA-APM **τοις** *tois* (dla) [[G3588]] WTT-DPN **παραπτωμασιν** *paraptōmasin* upadków – występków [[G3900]] WTN-DPN **συνεζωοποιησεν** *synezōopoiēsen* współożywił z [[G4806]] [[V-AAI-3S]] **τω** *tō* [[G3588]] WTT-DSM **χριστω** *christō* Pomazańcem [[G5547]] WTN-DSM **χαριτι** *chariti* łaską [[G5485]] [[N-DSF]] **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **σεσωσμενοι** *sesōsmenoi* którzy są zbawieni – którzy są uratowani [[G4982]] WTV-RPP-NPM
###### **Ef 2,6**
 **και** *kai* i [[G2532]] [[CONJ]] **συνηγειρεν** *synēgeiren* współobudził [[G4891]] [[V-AAI-3S]] **και** *kai* i [[G2532]] [[CONJ]] **συνεκαθισεν** *synekathisen* współposadził [[G4776]] [[V-AAI-3S]] **εν** *en* w [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPN **επουρανιοις** *epouraniois* niebiosach [[G2032]] WTA-DPN **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM
###### **Ef 2,7**
 **ινα** *hina* aby [[G2443]] [[CONJ]] **ενδειξηται** *endeiksētai* ukazałby – wykazałby [[G1731]] WTV-AMS-3S **εν** *en* w [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPM **αιωσιν** *aiōsin* wiekach [[G165]] WTN-DPM **τοις** *tois* [[G3588]] WTT-DPM **επερχομενοις** *eperchomenois* przychodzących [[G1904]] WTV-PNP-DPM **τον** *ton* [[G3588]] [[T-ASM]] **υπερβαλλοντα** *uperballonta* przewyższające [[G5235]] WTV-PAP-ASM **πλουτον** *plouton* bogactwo [[G4149]] [[N-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **χαριτος** *charitos* łaski [[G5485]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **εν** *en* w [[G1722]] [[PREP]] **χρηστοτητι** *chrēstotēti* dobroć – łagodność [[G5544]] [[N-DSF]] **εφ** *ef* dla [[G1909]] [[PREP]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM
###### **Ef 2,8**
 **τη** *tē* [[G3588]] WTT-DSF **γαρ** *gar* Bowiem [[G1063]] [[CONJ]] **χαριτι** *chariti* łaską [[G5485]] [[N-DSF]] **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **σεσωσμενοι** *sesōsmenoi* którzy są zbawieni – którzy są uratowani [[G4982]] WTV-RPP-NPM **δια** *dia* przez [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **πιστεως** *pisteōs* wiarę [[G4102]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **τουτο** *touto* to [[G5124]] WTD-NSN **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εξ** *eks* z [[G1537]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **θεου** *theou* Boga [[G2316]] [[N-GSM]] **το** *to* (to) [[G3588]] WTT-NSN **δωρον** *dōron* dar – dar ofiarny [[G1435]] WTN-NSN
###### **Ef 2,9**
 **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εξ** *eks* z [[G1537]] [[PREP]] **εργων** *ergōn* dzieł – uczynków [[G2041]] WTN-GPN **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **τις** *tis* ktoś [[G5100]] WTX-NSM **καυχησηται** *kauchēsētai* chlubiłby się – chełpiłby się [[G2744]] WTV-ADS-3S
###### **Ef 2,10**
 **αυτου** *autou* Jego [[G846]] [[P-GSM]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εσμεν** *esmen* jesteśmy [[G2070]] WTV-PXI-1P **ποιημα** *poiēma* czyn [[G4161]] WTN-NSN **κτισθεντες** *ktisthentes* którzy zostaliśmy stworzeni [[G2936]] WTV-APP-NPM **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM **επι** *epi* w [[G1909]] [[PREP]] **εργοις** *ergois* dziełach [[G2041]] WTN-DPN **αγαθοις** *agathois* dobrych [[G18]] WTA-DPN **οις** *hois* które [[G3739]] WTR-DPN **προητοιμασεν** *proētoimasen* wcześniej przygotował [[G4282]] [[V-AAI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **αυτοις** *autois* nich [[G846]] WTP-DPN **περιπατησωμεν** *peripatēsōmen* chodzilibyśmy – postępowalibyśmy [[G4043]] WTV-AAS-1P
###### **Ef 2,11**
 **διο** *dio* Dlatego [[G1352]] [[CONJ]] **μνημονευετε** *mnēmoneuete* pamiętajcie – przypominajcie sobie [[G3421]] WTV-PAM-2P **οτι** *hoti* że [[G3754]] [[CONJ]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **ποτε** *pote* niegdyś [[G4218]] WTPRT **τα** *ta* [[G3588]] WTT-NPN **εθνη** *ethnē* poganie – narody [[G1484]] WTN-NPN **εν** *en* w [[G1722]] [[PREP]] **σαρκι** *sarki* ciele [[G4561]] [[N-DSF]] **οι** *hoi* [[G3588]] WTT-NPM **λεγομενοι** *legomenoi* którzy są nazywani [[G3004]] WTV-PPP-NPM **ακροβυστια** *akrobystia* nieobrzezany (nieobrzezanymi) [[G203]] [[N-NSF]] **υπο** *hypo* przez [[G5259]] [[PREP]] **της** *tēs* (tego) [[G3588]] [[T-GSF]] **λεγομενης** *legomenēs* który jest nazywany [[G3004]] WTV-PPP-GSF **περιτομης** *peritomēs* obrzezanym [[G4061]] [[N-GSF]] **εν** *en* w [[G1722]] [[PREP]] **σαρκι** *sarki* ciele [[G4561]] [[N-DSF]] **χειροποιητου** *cheiropoiētou* ręką uczynionych [[G5499]] WTA-GSF
###### **Ef 2,12**
 **οτι** *hoti* że [[G3754]] [[CONJ]] **ητε** *ēte* byliście [[G2258]] WTV-IXI-2P **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **καιρω** *kairō* porze [[G2540]] WTN-DSM **εκεινω** *ekeinō* tej [[G1565]] WTD-DSM **χωρις** *chōris* bez [[G5565]] [[ADV]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **απηλλοτριωμενοι** *apēllotriōmenoi* którzy są obcy – którzy są wyobcowani [[G526]] WTV-RPP-NPM **της** *tēs* [[G3588]] [[T-GSF]] **πολιτειας** *politeias* obywatelstwu [[G4174]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSM **ισραηλ** *israēl* Izraela – [ten, który walczył z Bogiem] [[G2474]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **ξενοι** *ksenoi* obcy – cudzoziemcy [[G3581]] WTA-NPM **των** *tōn* [[G3588]] WTT-GPF **διαθηκων** *diathēkōn* przymierzom [[G1242]] WTN-GPF **της** *tēs* [[G3588]] [[T-GSF]] **επαγγελιας** *epangelias* obietnicy [[G1860]] [[N-GSF]] **ελπιδα** *elpida* nadziei [[G1680]] WTN-ASF **μη** *mē* nie [[G3361]] [[PRT-N]] **εχοντες** *echontes* mający [[G2192]] WTV-PAP-NPM **και** *kai* i [[G2532]] [[CONJ]] **αθεοι** *atheoi* bezbożni [[G112]] WTA-NPM **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **κοσμω** *kosmō* świecie [[G2889]] WTN-DSM
###### **Ef 2,13**
 **νυνι** *nyni* Teraz [[G3570]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM **υμεις** *hymeis* wy [[G5210]] WTP-2NP **οι** *hoi* [[G3588]] WTT-NPM **ποτε** *pote* niegdyś [[G4218]] WTPRT **οντες** *ontes* będący [[G5607]] WTV-PXP-NPM **μακραν** *makran* daleko [[G3112]] [[ADV]] **εγγυς** *engys* blisko [[G1451]] [[ADV]] **εγενηθητε** *egenēthēte* staliście się [[G1096]] WTV-AOI-2P **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **αιματι** *haimati* krwi [[G129]] WTN-DSN **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **Ef 2,14**
 **αυτος** *autos* On [[G846]] WTP-NSM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **η** *hē* [[G3588]] [[T-NSF]] **ειρηνη** *eirēnē* pokój [[G1515]] [[N-NSF]] **ημων** *hēmōn* nasz [[G2257]] WTP-1GP **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **ποιησας** *poiēsas* który uczynił [[G4160]] WTV-AAP-NSM **τα** *ta* [[G3588]] WTT-APN **αμφοτερα** *amfotera* obie [[G297]] WTA-APN **εν** *hen* jednym [[G1520]] WTA-ASN **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-ASN **μεσοτοιχον** *mesotoichon* leżący pośrodku mur [[G3320]] WTN-ASN **του** *tou* [[G3588]] WTT-GSM **φραγμου** *fragmou* odgrodzenia – płotu [[G5418]] [[N-GSM]] **λυσας** *lysas* który zniszczył – który złamał [[G3089]] WTV-AAP-NSM
###### **Ef 2,15**
 **την** *tēn* [[G3588]] WTT-ASF **εχθραν** *echthran* Wrogość – Nieprzyjaźń [[G2189]] WTN-ASF **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **σαρκι** *sarki* ciele [[G4561]] [[N-DSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **τον** *ton* [[G3588]] [[T-ASM]] **νομον** *nomon* Prawem [[G3551]] [[N-ASM]] **των** *tōn* [[G3588]] WTT-GPF **εντολων** *entolōn* przykazań [[G1785]] WTN-GPF **εν** *en* w [[G1722]] [[PREP]] **δογμασιν** *dogmasin* postanowieniach – rozporządzeniach [[G1378]] WTN-DPN **καταργησας** *katargēsas* które uznał za bezużyteczne [[G2673]] WTV-AAP-NSM **ινα** *hina* aby [[G2443]] [[CONJ]] **τους** *tous* (tych) [[G3588]] WTT-APM **δυο** *dyo* dwóch [[G1417]] WTA-NUI **κτιση** *ktisē* stworzyłby [[G2936]] WTV-AAS-3S **εν** *en* w [[G1722]] [[PREP]] **εαυτω** *heautō* sobie [[G1438]] WTF-3DSM **εις** *eis* ku [[G1519]] [[PREP]] **ενα** *hena* jednemu [[G1520]] WTA-ASM **καινον** *kainon* nowemu [[G2537]] WTA-ASM **ανθρωπον** *anthrōpon* człowiekowi [[G444]] [[N-ASM]] **ποιων** *poiōn* czyniąc [[G4160]] [[V-PAP-NSM]] **ειρηνην** *eirēnēn* pokój [[G1515]] WTN-ASF
###### **Ef 2,16**
 **και** *kai* i [[G2532]] [[CONJ]] **αποκαταλλαξη** *apokatallaksē* pojednałby z powrotem – pogodziłby z powrotem [[G604]] WTV-AAS-3S **τους** *tous* [[G3588]] WTT-APM **αμφοτερους** *amfoterous* obu [[G297]] WTA-APM **εν** *en* w [[G1722]] [[PREP]] **ενι** *heni* jednym [[G1520]] WTA-DSN **σωματι** *sōmati* ciele [[G4983]] WTN-DSN **τω** *tō* (dla) [[G3588]] WTT-DSM **θεω** *theō* Boga [[G2316]] WTN-DSM **δια** *dia* przez [[G1223]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **σταυρου** *staurou* krzyż [[G4716]] [[N-GSM]] **αποκτεινας** *apokteinas* zabiwszy [[G615]] WTV-AAP-NSM **την** *tēn* (tę) [[G3588]] WTT-ASF **εχθραν** *echthran* wrogość – nieprzyjaźń [[G2189]] WTN-ASF **εν** *en* w [[G1722]] [[PREP]] **αυτω** *autō* Nim [[G846]] WTP-DSM
###### **Ef 2,17**
 **και** *kai* i [[G2532]] [[CONJ]] **ελθων** *elthōn* przyszedłszy [[G2064]] WTV-2AAP-NSM **ευηγγελισατο** *euēngelisato* ogłosił dobrą nowinę [[G2097]] WTV-AMI-3S **ειρηνην** *eirēnēn* pokój [[G1515]] WTN-ASF **υμιν** *hymin* wam [[G5213]] WTP-2DP **τοις** *tois* (tym) [[G3588]] WTT-DPM **μακραν** *makran* daleko [[G3112]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **τοις** *tois* (tym) [[G3588]] WTT-DPM **εγγυς** *engys* blisko [[G1451]] [[ADV]]
###### **Ef 2,18**
 **οτι** *hoti* bo [[G3754]] [[CONJ]] **δι** *di* przez [[G1223]] [[PREP]] **αυτου** *autou* Niego [[G846]] [[P-GSM]] **εχομεν** *echomen* mamy [[G2192]] WTV-PAI-1P **την** *tēn* [[G3588]] WTT-ASF **προσαγωγην** *prosagōgēn* dostęp – zbliżenie się [[G4318]] WTN-ASF **οι** *hoi* [[G3588]] WTT-NPM **αμφοτεροι** *amfoteroi* jedni i drudzy [[G297]] WTA-NPM **εν** *en* w [[G1722]] [[PREP]] **ενι** *heni* jednym [[G1520]] WTA-DSN **πνευματι** *pneumati* Duchu [[G4151]] WTN-DSN **προς** *pros* do [[G4314]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **πατερα** *patera* Ojca [[G3962]] [[N-ASM]]
###### **Ef 2,19**
 **αρα** *ara* Zatem [[G686]] WTPRT **ουν** *oun* więc [[G3767]] [[CONJ]] **ουκετι** *ouketi* już nie [[G3765]] [[ADV]] **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **ξενοι** *ksenoi* obcy – cudzoziemcy [[G3581]] WTA-NPM **και** *kai* i [[G2532]] [[CONJ]] **παροικοι** *paroikoi* przechodnie – mieszkający obok [[G3941]] WTA-NPM **αλλα** *alla* ale [[G235]] [[CONJ]] **συμπολιται** *sympolitai* współobywatele [[G4847]] WTN-NPM **των** *tōn* [[G3588]] WTT-GPM **αγιων** *hagiōn* świętych [[G40]] WTA-GPM **και** *kai* i [[G2532]] [[CONJ]] **οικειοι** *oikeioi* domownicy [[G3609]] WTA-NPM **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **Ef 2,20**
 **εποικοδομηθεντες** *epoikodomēthentes* którzy zostali zbudowanymi – którzy zostali nadbudowani [[G2026]] WTV-APP-NPM **επι** *epi* na [[G1909]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **θεμελιω** *themeliō* fundamencie [[G2310]] WTN-DSM **των** *tōn* [[G3588]] WTT-GPM **αποστολων** *apostolōn* wysłanników [[G652]] WTN-GPM **και** *kai* i [[G2532]] [[CONJ]] **προφητων** *profētōn* proroków [[G4396]] WTN-GPM **οντος** *ontos* będący [[G5607]] WTV-PXP-GSM **ακρογωνιαιου** *akrogōniaiou* (kamieniem) węgielnym – (kamieniem) narożnym [[G204]] WTA-GSM **αυτου** *autou* jego [[G846]] [[P-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **Ef 2,21**
 **εν** *en* w [[G1722]] [[PREP]] **ω** *hō* którym [[G3739]] WTR-DSM **πασα** *pasa* cała [[G3956]] WTA-NSF **η** *hē* [[G3588]] [[T-NSF]] **οικοδομη** *oikodomē* budowla [[G3619]] [[N-NSF]] **συναρμολογουμενη** *synarmologoumenē* która jest spajana – która jest zespalana [[G4883]] WTV-PPP-NSF **αυξει** *auksei* wzrasta [[G837]] WTV-PAI-3S **εις** *eis* w [[G1519]] [[PREP]] **ναον** *naon* świątynię – przybytek [[G3485]] [[N-ASM]] **αγιον** *hagion* świętą [[G40]] WTA-ASM **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM
###### **Ef 2,22**
 **εν** *en* w [[G1722]] [[PREP]] **ω** *hō* którym [[G3739]] WTR-DSM **και** *kai* i [[G2532]] [[CONJ]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **συνοικοδομεισθε** *synoikodomeisthe* jesteście razem budowani – jesteście wspólnie budowani [[G4925]] WTV-PPI-2P **εις** *eis* w [[G1519]] [[PREP]] **κατοικητηριον** *katoikētērion* mieszkanie [[G2732]] WTN-ASN **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εν** *en* w [[G1722]] [[PREP]] **πνευματι** *pneumati* Duchu [[G4151]] WTN-DSN
