# Ba 2 BT5
###### **Ba 2,1**
 Wypełnił Pan słowa, które wypowiedział przeciwko nam, przeciw sędziom naszym sądzącym Izraela, przeciw królom i zwierzchnikom naszym, przeciw każdemu z Izraela i Judy.
###### **Ba 2,2**
 Nigdzie pod niebem nie spełniły się one tak, jak je spełnił w Jeruzalem, zgodnie z tym, co było napisane w Prawie Mojżeszowym,
###### **Ba 2,3**
 że ktoś z nas będzie jadł ciało swojego syna, a inny córki.
###### **Ba 2,4**
 Dał ich [Bóg] za niewolników wszystkim królestwom, które są dokoła, na pośmiewisko i szyderstwo narodom, między którymi Pan nas rozproszył.
###### **Ba 2,5**
 Stali się oni jak poddani, nie jak panujący, dlatego że zgrzeszyliśmy przeciw Panu, Bogu naszemu, że nie byliśmy posłuszni Jego głosowi.
###### **Ba 2,6**
 Panu, Bogu naszemu, [należna jest] sprawiedliwość, a nam i przodkom naszym dzisiaj rumieniec wstydu na twarzy.
###### **Ba 2,7**
 Cała niedola, którą Pan zamierzył względem nas, spadła na nas.
###### **Ba 2,8**
 Nie staraliśmy się przebłagać oblicza Pana odwróceniem się każdego [z nas] od zamysłów swojego złego serca.
###### **Ba 2,9**
 Czuwał Pan nad tym, by sprowadzić niedolę na nas, bo jest sprawiedliwy we wszystkich dziełach swoich, które nam nakazał.
###### **Ba 2,10**
 Nie słuchaliśmy Jego głosu, by postępować według przykazań Pana, które nam dał.
###### **Ba 2,11**
 A teraz, Panie, Boże Izraela, który wyprowadziłeś lud swój z ziemi egipskiej ręką potężną wśród znaków i cudów, wielką mocą, ramieniem wyciągniętym w górę i zdobyłeś sobie imię, aż po dzień dzisiejszy –
###### **Ba 2,12**
 zgrzeszyliśmy bezbożnie i niegodziwie postąpiliśmy, Panie, Boże nasz, wobec wszystkich sprawiedliwych rozporządzeń Twoich.
###### **Ba 2,13**
 Niech się odwróci od nas zapalczywość Twoja, bo mało nas ocalało między narodami, wśród których nas rozproszyłeś.
###### **Ba 2,14**
 Wysłuchaj, Panie, modlitw i próśb naszych, wybaw nas przez wzgląd na siebie samego! Wyjednaj nam łaskę przed obliczem tych, co nas uprowadzili,
###### **Ba 2,15**
 aby poznała cała ziemia, że Ty jesteś Pan, Bóg nasz, że imię Twoje jest wzywane nad Izraelem i nad narodem jego.
###### **Ba 2,16**
 Panie, spojrzyj ze świętego przybytku swego i pomyśl o nas! Nakłoń, Panie, ucha swego i wysłuchaj!
###### **Ba 2,17**
 Otwórz, Panie, swe oczy i zobacz, że to nie umarli przebywający w Otchłani, którym tchnienie ich wnętrza odjęto, oddadzą Ci chwałę i uwielbienie,
###### **Ba 2,18**
 lecz dusza zasmucona z powodu ogromu [niedoli], ten, kto chodzi pochylony i zbolały, oczy niedomagające, dusza przymierająca głodem oddadzą Ci chwałę i sprawiedliwość, Panie!
###### **Ba 2,19**
 Albowiem nie na sprawiedliwych czynach przodków ani królów naszych się opieramy, gdy prosimy Cię o miłosierdzie nad nami, Panie, Boże nasz!
###### **Ba 2,20**
 Zesłałeś bowiem zapalczywość i gniew swój na nas, jak to ogłosiłeś przez proroków, sługi swoje:
###### **Ba 2,21**
 Tak mówi Pan: Pochylcie swe karki i służcie królowi babilońskiemu, a mieszkać będziecie na ziemi, którą dałem przodkom waszym.
###### **Ba 2,22**
 A jeżeli nie posłuchacie głosu Pana, aby służyć królowi babilońskiemu,
###### **Ba 2,23**
 zabiorę z miast Judy i z Jeruzalem głos radości i wesela, głos oblubieńca i oblubienicy, a cała ziemia będzie bezludnym pustkowiem.
###### **Ba 2,24**
 Nie posłuchaliśmy jednak głosu Twego, by służyć królowi babilońskiemu, więc wypełniłeś słowa, które wypowiadałeś przez proroków, sługi swoje, że będą usunięte kości królów i przodków naszych ze swego miejsca.
###### **Ba 2,25**
 A oto są porzucone na skwar dnia i ziąb nocy. Pomarli oni z powodu okropnej nędzy, głodu, miecza i zarazy.
###### **Ba 2,26**
 Uczyniłeś z domem, gdzie wzywano imienia Twojego, to, co jest obecnie, z powodu złości domu Izraela i domu Judy.
###### **Ba 2,27**
 Postąpiłeś jednak względem nas, Panie, Boże nasz, według całej swej łagodności i wielkiego miłosierdzia swego,
###### **Ba 2,28**
 stosownie do słów wypowiedzianych przez sługę Twego, Mojżesza, w dniu, kiedy kazałeś mu pisać Prawo Twoje przed obliczem synów Izraela, mówiąc:
###### **Ba 2,29**
 Jeżeli nie będziecie posłuszni głosowi mojemu, ten wielki i liczny tłum stanie się mały między narodami, gdzie go rozproszę.
###### **Ba 2,30**
 Wiem, że nie posłuchają Mnie, bo są ludem o twardym karku, wejdą jednak w siebie w ziemi wygnania.
###### **Ba 2,31**
 Poznają wówczas, że Ja jestem ich Panem i Bogiem. Dam im serce i uszy otwarte,
###### **Ba 2,32**
 chwalić Mnie będą w ziemi wygnania swego i pamiętać o imieniu moim.
###### **Ba 2,33**
 Odwrócą się od swojej zatwardziałości i od złych czynów swoich, ponie-waż przypomną sobie los przodków, którzy grzeszyli przed Panem.
###### **Ba 2,34**
 Sprowadzę ich do ziemi, którą poprzysiągłem ich ojcom: Abrahamowi, Izaakowi i Jakubowi. Będą panować nad nią, rozmnożę ich, nie zostaną w małej liczbie.
###### **Ba 2,35**
 Zawrę z nimi przymierze wieczne, Ja będę Bogiem ich, a oni będą ludem moim. Nie usunę więcej ludu mego, Izraela, z ziemi, którą im dałem.
# Ba 2 PAU
###### **Ba 2,1**
 Wypełnił więc PAN swoje słowo, które wypowiedział przeciw nam i przeciw naszym sędziom, którzy rządzili Izraelem, przeciw naszym królom i książętom, przeciw każdemu człowiekowi z Izraela i Judy.
###### **Ba 2,2**
 Nigdzie pod niebem nie spełniło się ono tak, jak w Jeruzalem, zgodnie z zapisem Prawa Mojżeszowego,
###### **Ba 2,3**
 że ludzie będą jedli ciała swych synów i córek.
###### **Ba 2,4**
 Dlatego oddał ich PAN wszystkim sąsiednim królestwom w niewolę, na pośmiewisko i urąganie sąsiadów, wśród których nas rozproszył.
###### **Ba 2,5**
 I choć niegdyś byli panującymi, stali się poddanymi. A wszystko dlatego, że zgrzeszyliśmy przeciwko PANU, BOGU naszemu, nie słuchając Jego głosu.
###### **Ba 2,6**
 PANU, BOGA naszemu, należy się sprawiedliwość, nam zaś wspólnie z przodkami wstyd, jak to się dzieje dzisiaj.
###### **Ba 2,7**
 Spadło na nas to wszystko, co zapowiedział PANA, cała ta niedola,
###### **Ba 2,8**
 bo nie błagaliśmy PANA, aby nas powstrzymał od złych zamysłów serc.
###### **Ba 2,9**
 Czuwał więc PAN, gotów sprowadzić na nas niedolę, bo jest sprawiedliwy we wszystkim, co nam nakazał.
###### **Ba 2,10**
 Lecz my nie słuchaliśmy Jego głosu i nie postępowaliśmy według przykazań PANA, które nam dał.
###### **Ba 2,11**
 O PANIE, Boże Izraela, który wyprowadziłeś swój lud z ziemi egipskiej wśród znaków i cudów potężną ręką, wielką mocą i podniesionym ramieniem i zdobyłeś sobie sławę aż po dziś dzień!
###### **Ba 2,12**
 PANIE, nasz Boże, zgrzeszyliśmy, postępując bezbożnie i przekraczając wszystkie Twoje przykazania.
###### **Ba 2,13**
 Niech się odwróci od nas Twój gniew, gdyż niewielu nas ocalało wśród narodów pogańskich, dokąd nas rozproszyłeś.
###### **Ba 2,14**
 Wysłuchaj, PANIE, naszych modlitw i błagań, wybaw nas ze względu na siebie samego. Udziel nam łaski na oczach tych, którzy nas uprowadzili,
###### **Ba 2,15**
 aby cała ziemia poznała, że Ty jesteś PANEM, naszym Bogiem, a Twoje imię nosi Izrael i jego potomstwo.
###### **Ba 2,16**
 PANIE, spojrzyj ze swojego świętego mieszkania i wspomnij na nas! PANIE, nakłoń swego ucha i wysłuchaj!
###### **Ba 2,17**
 PANIE, otwórz oczy i zobacz, że to nie umarli przebywający w grobie i pozbawieni oddechu głoszą Twoją chwałę i sprawiedliwość,
###### **Ba 2,18**
 lecz ludzie bardzo udręczeni, przybici i słabi, ledwie widzący i przymierający głodem będą głosić Twoją chwałę i sprawiedliwość, o PANIE!
###### **Ba 2,19**
 PANIE, nasz Boże! Naszej prośby o miłosierdzie nie opieramy na zasługach naszych przodków i królów.
###### **Ba 2,20**
 Srogo się bowiem na nas zagniewałeś, zgodnie z zapowiedzią Twoich sług, proroków:
###### **Ba 2,21**
 «Tak mówi PAN: Pochylcie wasze karki i służcie królowi babilońskiemu, a zamieszkacie w ziemi, którą dałem waszym przodkom.
###### **Ba 2,22**
 Jeżeli jednak nie usłuchacie głosu PANA i nie będziecie służyć królowi babilońskiemu,
###### **Ba 2,23**
 sprawię, że ucichnie w miastach Judy i w Jeruzalem głos radości i wesela, głos pana młodego i panny młodej, a cały kraj obróci się w pustkowie pozbawione mieszkańców».
###### **Ba 2,24**
 Ale my nie usłuchaliśmy Twego głosu i nie służyliśmy królowi babilońskiemu. Wypełniłeś więc swoje słowa, wypowiedziane przez Twoje sługi, proroków, że kości naszych królów i kości naszych przodków zostaną wyrzucone z grobów.
###### **Ba 2,25**
 I oto rzeczywiście rzucono je na pastwę skwaru dnia i nocnego chłodu. Zginęli oni w okropnych mękach od głodu, miecza i zarazy.
###### **Ba 2,26**
 Z powodu grzechu ludu Izraela i Judy uczyniłeś domowi, w którym wzywano Twego imienia, to, co trwa aż po dziś dzień.
###### **Ba 2,27**
 PANIE, nasz Boże! Mimo to postąpiłeś względem nas z całą łagodnością, według Twego wielkiego miłosierdzia,
###### **Ba 2,28**
 tak jak zapowiedziałeś przez sługę Twego Mojżesza, gdy nakazałeś mu spisać Twoje Prawo w obecności synów Izraela:
###### **Ba 2,29**
 «Jeżeli nie usłuchacie mojego głosu, to naprawdę ten sławny i liczny lud stanie się mały wśród narodów, dokąd go rozproszę.
###### **Ba 2,30**
 Wiem jednak, że nie posłuchają Mnie, gdyż są ludem o twardym karku. Jednakże w kraju swego wygnania szczerze się nawrócą
###### **Ba 2,31**
 i uznają, że Ja jestem ich PANEM i Bogiem. Dam im serce i uszy otwarte.
###### **Ba 2,32**
 I będą Mnie wysławiać w kraju swego wygnania oraz przypomną sobie moje imię.
###### **Ba 2,33**
 Odwrócą się od swej zatwardziałości i od swoich złych czynów, gdyż przypomną sobie los swych przodków, którzy grzeszyli przeciw PANU.
###### **Ba 2,34**
 Sprowadzę ich ponownie do ziemi, którą przysiągłem ich przodkom: Abrahamowi, Izaakowi oraz Jakubowi, i będą panować nad nią. Rozmnożę ich i nie będą już małym narodem.
###### **Ba 2,35**
 Zawrę też z nimi wieczne przymierze. Ja będę ich Bogiem, a oni będą moim ludem. I nie wypędzę więcej mego ludu, Izraela, z ziemi, którą im dałem».
# Ba 2 BP
###### **Ba 2,1**
 I Pan wypełnił swoje słowo, które wyrzekł przeciwko nam i naszym sędziom, którzy sądzili Izraela, przeciwko naszym królom i zwierzchnikom oraz przeciwko mężom Izraela i Judei.
###### **Ba 2,2**
 Nigdy jeszcze pod całym niebem nie zdarzyło się to, co się dokonało w Jeruzalem zgodnie z tym, co zostało zapisane w Prawie Mojżeszowym,
###### **Ba 2,3**
 ze każdy z nas będzie zjadał ciało własnego syna i ciało własnej córki.
###### **Ba 2,4**
 Poddał ich w moc wszystkich otaczających nas królestw, aby stali się przedmiotem hańby i wzgardy wszystkich ludów dokoła, pomiędzy których Pan ich rozproszył.
###### **Ba 2,5**
 I stali się sługami zamiast być panami, bo zgrzeszyli przeciwko Panu, Bogu naszemu, nie słuchając Jego głosu.
###### **Ba 2,6**
 Do Pana, Boga naszego, należy sprawiedliwość, a do nas i ojców naszych zawstydzenie oblicza, jak to jest dzisiaj.
###### **Ba 2,7**
 Wszelkie zło, które Pan nam zapowiedział, przyszło na nas.
###### **Ba 2,8**
 A myśmy nie ułagodzili oblicza Pańskiego, odwracając się każdy od skłonności swego złego serca.
###### **Ba 2,9**
 Dlatego Pan czuwał nad nieszczęściami i sprowadził je na nas, jest On bowiem sprawiedliwy we wszystkich swych zamierzeniach, które nam wyznaczył.
###### **Ba 2,10**
 A my nie słuchaliśmy Jego głosu, by postępować według Jego przykazań, które nam podał.
###### **Ba 2,11**
 A teraz, Panie, Boże Izraela, któryś wyprowadził swój lud z ziemi egipskiej potężną ręką, przez znaki i cuda, z wielką mocą i wyciągniętym ramieniem, i [przez to] ustanowiłeś sobie Imię aż po dzień dzisiejszy,
###### **Ba 2,12**
 zgrzeszyliśmy, postępowaliśmy bezbożnie i popełnialiśmy nieprawość, Panie Boże nasz, naruszając wszystkie Twoje przykazania.
###### **Ba 2,13**
 Niech Twój gniew odwróci się od nas, gdyż tylko mała garstka pozostała nas wśród narodów, pomiędzy które nas rozproszyłeś!
###### **Ba 2,14**
 Panie, wysłuchaj naszej modlitwy i naszego błagania: wybaw nas przez wzgląd na siebie samego! Pozwól, abyśmy znaleźli łaskę przed obliczem tych, którzy nas uprowadzili,
###### **Ba 2,15**
 aby cała ziemia poznała, żeś Ty jest Panem, Bogiem naszym, Twoim imieniem bowiem został nazwany Izrael i jego ród.
###### **Ba 2,16**
 O Panie, wejrzyj z Twego świętego mieszkania i wspomnij na nas! Nakłoń, o Panie, swego ucha i słuchaj;
###### **Ba 2,17**
 otwórz, o Panie, swe oczy i patrz! To nie umarli w Hadesie, z których wnętrzności został duch wyrwany, będą Ci oddawali chwałę i sprawiedliwość,
###### **Ba 2,18**
 lecz człowiek żyjący, przygnębiony wielkością [zła], ten, który chodzi przygięty i bezsilny: to oczy osłabione i dusza zgłodniała, one będą Ci oddawały chwałę i sprawiedliwość, o Panie.
###### **Ba 2,19**
 Nie przez wzgląd na sprawiedliwość naszych ojców i naszych królów bowiem zanosimy nasze modły o zmiłowanie do Ciebie, o Panie, Boże nasz!
###### **Ba 2,20**
 Zesłałeś bowiem na nas swoją zapalczywość i swój gniew, jak to zapowiedziałeś za pośrednictwem sług Twoich, Proroków, mówiąc:
###### **Ba 2,21**
 Tak mówi Pan: "Ugnijcie swego karku i służcie królowi babilońskiemu, a będziecie mieszkać w ziemi, którą dałem waszym ojcom.
###### **Ba 2,22**
 Jeżeli jednak nie usłuchacie głosu Pana, służąc królowi babilońskiemu,
###### **Ba 2,23**
 sprawię, że w miastach judzkich i na ulicach Jeruzalem ucichnie głos radości i głos wesela, głos oblubieńca i głos oblubienicy, a cały kraj zamieni się w pustkowie pozbawione mieszkańców".
###### **Ba 2,24**
 Myśmy jednak nie usłuchali Twojego głosu, [nakazującego nam], abyśmy służyli królowi babilońskiemu, i Tyś wypełnił swoje słowo, któreś zapowiedział przez Twoje sługi, Proroków, że kości naszych królów i kości naszych ojców zostaną wyrzucone z miejsca swego [spoczynku].
###### **Ba 2,25**
 I zaprawdę, zostali oni wyrzuceni i [wydani] na upał dnia i chłód nocy; pomarli wśród straszliwych cierpień od głodu, miecza i zarazy.
###### **Ba 2,26**
 Dom, w którym wzywano Twojego Imienia, doprowadziłeś do tego stanu, w którym znajduje się dziś, a to dla przewrotności Domu Izraela i Domu Jakuba.
###### **Ba 2,27**
 Postępowałeś z nami, Panie, Boże nasz, z całą swoją dobrocią i z wielkim miłosierdziem,
###### **Ba 2,28**
 tak właśnie, jak to zapowiedziałeś za pośrednictwem sługi swego Mojżesza w dniu, w którym poleciłeś mu spisać swe Prawo w obecności synów Izraela mówiąc:
###### **Ba 2,29**
 "Jeżeli nie będziecie słuchać głosu mego, wielki ten i liczny lud stanie się nader mały wśród narodów, pomiędzy które ich rozproszę.
###### **Ba 2,30**
 Wiem Ja bowiem, że mnie nie usłuchają, gdyż są ludem o opornym karku. Jednak w kraju swego wygnania wejdą w siebie
###### **Ba 2,31**
 i poznają, żem Ja jest Pan, Bóg ich, a Ja dam im serce i uszy zdolne do słuchania.
###### **Ba 2,32**
 I będą mnie wielbili w ziemi swego wygnania, i wspomną znów na moje Imię.
###### **Ba 2,33**
 I przestaną być [ludem] o opornym karku, i odwrócą się od swych przewrotnych uczynków, gdyż wspomną na los swoich ojców, którzy zgrzeszyli przeciwko Panu.
###### **Ba 2,34**
 Przywiodę ich znowu do ziemi, którą pod przysięgą przyrzekłem ich ojcom, Abrahamowi, Izaakowi i Jakubowi, i będą jej panami. Rozmnożę ich i nie będą się umniejszać.
###### **Ba 2,35**
 Ustanowię z nimi wieczne Przymierze, abym był ich Bogiem i aby oni byli moim ludem: i nigdy już nie wypędzę mojego ludu izraelskiego z ziemi, którą im dałem".
# Ba 2 BR
###### **Ba 2,1**
 Dlatego wypełniły się słowa, które Pan wypowiedział o nas samych, o naszych sędziach, rządzących kiedyś Izraelem, o naszych królach i urzędnikach oraz o wszystkich mieszkańcach Izraela i Judy.
###### **Ba 2,2**
 Nigdy dotychczas i nigdzie pod słońcem nie stało się coś takiego jak to, co Pan sprowadza teraz na Jerozolimę; dokładnie według tego, co zostało napisane w Prawie Mojżeszowym:
###### **Ba 2,3**
 że oto jeden żywi się ciałem własnego syna, a drugi je ciało swojej rodzonej córki.
###### **Ba 2,4**
 Powydawał ich Pan w ręce różnych władców dokoła i uczynił ich pośmiewiskiem i znakiem przekleństwa dla wszystkich okolicznych ludów, wśród których zostali rozproszeni.
###### **Ba 2,5**
 I tak z panujących stali się poddanymi, cierpiącymi ucisk. Ciężkośmy bowiem grzeszyli przeciwko Panu, naszemu Bogu, nie słuchając Jego głosu.
###### **Ba 2,6**
 Sprawiedliwy jest Pan i Bóg nasz, wstyd zaś po dzień dzisiejszy okrywa oblicze nam samym oraz ojcom naszym.
###### **Ba 2,7**
 Spadły na nas wszystkie te nieszczęścia, którymi Pan nam groził.
###### **Ba 2,8**
 Wcale nie staraliśmy się przebłagać Pana i nie odwracaliśmy się od upodobań naszych serc przewrotnych.
###### **Ba 2,9**
 Ale Pan czuwał i zesłał na nas wszystkie te nieszczęścia; bo sprawiedliwy jest Pan w tym wszystkim, co nam nakazuje.
###### **Ba 2,10**
 Myśmy jednak głosu Jego nie słuchali i nie wypełnialiśmy przykazań, które nam dawał.
###### **Ba 2,11**
 Panie i Boże Izraela, to Ty - silną prawicą, wśród znaków i cudów oraz potęgą niezwykłą swego wyciągniętego ramienia - wyprowadziłeś swój lud z Egiptu i zyskałeś sobie przez to imię, którym cieszysz się do dzisiaj!
###### **Ba 2,12**
 Panie i Boże nasz, zgrzeszyliśmy, postępowaliśmy bezbożnie i niesprawiedliwie względem wszystkich Twoich postanowień.
###### **Ba 2,13**
 Racz wreszcie odwrócić od nas Twoje zagniewanie, bo już tak niewiele nas ocalało między narodami, pośród których zostaliśmy rozproszeni.
###### **Ba 2,14**
 Panie, wysłuchaj nasze prośby i błagania! Przez wzgląd na Twoją świętą wolę - wybaw nas! Spraw, żebyśmy znaleźli łaskę u tych, którzy nas uprowadzili z naszej własnej ojczyzny.
###### **Ba 2,15**
 Niech pozna cały świat, że Ty jesteś naszym Panem i Bogiem, a Twoje imię jest wzywane nad Izraelem i nad wszystkimi jego pokoleniami.
###### **Ba 2,16**
 Panie, spojrzyj na nas z wysokości Twojego świętego zamieszkania i nawiedź nas! Nakłoń ku nam swego ucha i wysłuchaj nas!
###### **Ba 2,17**
 Otwórz, o Panie swe oczy i popatrz na nas! To nie z zaświatów umarli, których ciała już są pozbawione ożywczego tchnienia, cześć Ci oddają i wysławiają sprawiedliwość Twoją, o Panie!
###### **Ba 2,18**
 Są to ludzie żyjący w wielkim ucisku, przygnębieni i bezsilni, na oczy już ledwie patrzący, ludzie nękani głodem. Lecz oni cześć Ci składają i wysławiają Twoją sprawiedliwość, o Panie!
###### **Ba 2,19**
 Bo nie liczymy na zasługi nasze lub naszych ojców albo królów, gdy Ciebie, Panie nasz i Boże, tak o miłosierdzie błagamy.
###### **Ba 2,20**
 Wymierzyłeś w nas ostrze swego gniewu, tak jak zapowiedziałeś przez służących Tobie i proroków.
###### **Ba 2,21**
 Tak bowiem powiedział Pan: ugnijcie wasze karki i bądźcie poddani królowi babilońskiemu, bo tylko wtedy będziecie mogli pozostać w kraju, który Ja dałem ojcom waszym.
###### **Ba 2,22**
 Lecz jeśli nie posłuchacie polecenia Pańskiego i nie poddacie się królowi babilońskiemu,
###### **Ba 2,23**
 to sprawię, że zarówno w miastach Judy, jak i na ulicach Jerozolimy zamilkną wszystkie okrzyki radosne oraz przyjacielskie nawoływania, głosy oblubieńców i oblubienic, a cały kraj zamieni się w bezludną pustynię.
###### **Ba 2,24**
 Ale myśmy nie usłuchali poleceń Twoich i nie chcieliśmy się poddać królowi babilońskiemu. Wówczas Ty wypełniłeś wszystkie te słowa, którymi nas przestrzegałeś przez sługi swoje, proroków, mówiąc, że będą wywleczone z grobów kości naszych królów oraz kości ojców naszych.
###### **Ba 2,25**
 I rzeczywiście zostały wyrzucone i leżą w upale dnia i w zimnie nocy. Poginęli oni kiedyś wśród najokrutniejszych udręczeń z głodu, od miecza i od zarazy.
###### **Ba 2,26**
 Z powodu zaś przewrotności Domu Izraela i Domu Judy z Domem, w którym było kiedyś wzywane Twoje Imię, uczyniłeś to właśnie, czym jest dzisiaj.
###### **Ba 2,27**
 Ale Ty, Panie nasz i Boże, postąpiłeś z nami według wielkiej dobroci Twojej i według wielkiego miłosierdzia Twego,
###### **Ba 2,28**
 tak jak to przepowiedziałeś przez Twojego sługę, Mojżesza, wtedy kiedy mu poleciłeś przekazać Twoje pouczenie dla narodu Izraelskiego, mówiąc:
###### **Ba 2,29**
 Jeżeli nie posłuchacie mojego głosu, to ta wielka, niezliczona rzesza ludzi stanie się malutką garstką pośród innych narodów, między którymi żyć będziecie w rozproszeniu.
###### **Ba 2,30**
 Ja wiem, że oni nie posłuchają Mnie, bo są narodem o twardym karku. Dopiero w krainie swojego wygnania wezmą to sobie do serca.
###### **Ba 2,31**
 Wtedy poznają, że Ja jestem Panem i Bogiem ich. Wtedy dam im też serce wszystko rozumiejące i uszy zdolne do słuchania.
###### **Ba 2,32**
 Na ziemi swojego wygnania będą Mnie wysławiać i czcić moje Imię.
###### **Ba 2,33**
 Odwrócą się od swojej zatwardziałości i od swoich złych czynów. I wtedy też przypomną sobie to wszystko, co przydarzyło się ich ojcom, kiedy zgrzeszyli przeciwko Panu.
###### **Ba 2,34**
 A Ja sprowadzę ich wówczas znów do krainy, którą przyobiecałem pod przysięgą ojcom ich: Abrahamowi, Izaakowi i Jakubowi. I znów wezmą tę krainę w swoje posiadanie. I rozmnożę ich bardzo i nigdy już potem nie pomniejszy się ich liczba.
###### **Ba 2,35**
 I zawrę z nimi wiecznotrwałe Przymierze: Ja będę ich Bogiem, a oni będą moim ludem. I nigdy już nie dopuszczę, żeby mój lud izraelski musiał uchodzić z kraju, który im dałem.
# Ba 2 WUJ
