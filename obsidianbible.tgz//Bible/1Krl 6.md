# 1Krl 6 BT5
###### **1Krl 6,1**
 W roku czterysta osiemdziesiątym po wyjściu Izraelitów z ziemi egipskiej, w miesiącu Ziw, to jest drugim, czwartego roku panowania Salomona nad Izraelem, rozpoczął on budowę domu dla Pana.
###### **1Krl 6,2**
 Dom, który Salomon zbudował dla Pana, miał sześćdziesiąt łokci długości, dwadzieścia szerokości i trzydzieści wysokości.
###### **1Krl 6,3**
 Sień zaś przed główną budowlą świątyni miała dwadzieścia łokci długości, stosownie do szerokości świątyni, i dziesięć łokci szerokości, w kierunku długości świątyni.
###### **1Krl 6,4**
 Świątynię zaopatrzył w okna o zakratowanych wnękach.
###### **1Krl 6,5**
 Na murze świątyni dokoła poprowadził nadbudowę z pięter < wzdłuż murów świątyni > wokół głównej budowli i sanktuarium oraz zrobił dokoła boczne pomieszczenia.
###### **1Krl 6,6**
 Piętro dolne – szerokości pięciu łokci, średnie – szerokości sześciu łokci, a trzecie – szerokości siedmiu łokci, gdyż zaopatrzył dom na zewnątrz w skarpy dokoła, aby pomieszczeń bocznych nie podtrzymywały mury świątyni.
###### **1Krl 6,7**
 Dom zaś przy wznoszeniu go został zbudowany z kamieni, których po wydobyciu już nie obrabiano. Dlatego nie słyszano w domu, przy jego budowie, ani młota, ani siekiery, ani żadnego narzędzia żelaznego.
###### **1Krl 6,8**
 Drzwi do średniego pomieszczenia bocznego były przy prawym skrzydle domu, przez które po krętych schodach wstępowano do średniego, a ze średniego do trzeciego.
###### **1Krl 6,9**
 Tak więc zbudował tę świątynię i wykańczając, opatrzył ją < wklęsłym stropem > cedrowym.
###### **1Krl 6,10**
 Nadbudowę wzniósł nad całą świątynią na pięć łokci wysoko i połączył ze świątynią drewnem cedrowym.
###### **1Krl 6,11**
 Potem Pan skierował do Salomona te słowa:
###### **1Krl 6,12**
 «***Jeżeli będziesz postępował według moich praw i wypełniał moje nakazy oraz przestrzegał wszystkich moich poleceń, postępując według nich, to wypełnię na tobie moją obietnicę daną Dawidowi, twemu ojcu, i w świątyni tej, którą Mi budujesz,***
###### **1Krl 6,13**
 ***zamieszkam pośród Izraelitów i nie opuszczę mego ludu izraelskiego***».
###### **1Krl 6,14**
 A oto tak zbudował Salomon i wykończył tę świątynię.
###### **1Krl 6,15**
 Mury domu obłożył wewnątrz deskami cedrowymi od podłogi domu aż do belek sufitu, < wnętrze pokrył drewnem >, a podłogę świątyni wyłożył deskami cyprysowymi.
###### **1Krl 6,16**
 Ponadto od tylnej strony świątyni zbudował z desek cedrowych od podłogi aż do belek [ścianę na] dwadzieścia łokci, aby oddzielić od świątyni sanktuarium, to jest Miejsce Najświętsze.
###### **1Krl 6,17**
 Czterdzieści łokci długości miała świątynia przed [sanktuarium].
###### **1Krl 6,18**
 Cedrowe wnętrze świątyni zdobiły rzeźby rozchylonych kielichów kwiatowych i girlandy kwiecia. Wszystko było cedrowe. Kamienia nie było widać.
###### **1Krl 6,19**
 Sanktuarium urządził wewnątrz, w środku budowli, by tam umieścić Arkę Przymierza Pańskiego.
###### **1Krl 6,20**
 Sanktuarium było dwadzieścia łokci długie, dwadzieścia łokci szerokie i dwadzieścia łokci wysokie. Wyłożył je czystym złotem. Wyłożył też ołtarz cedrowy.
###### **1Krl 6,21**
 Wnętrze świątyni Salomon wyłożył również czystym złotem i założył złote łańcuchy przed sanktuarium, które wyłożył złotem.
###### **1Krl 6,22**
 Tak więc pokrył złotem całą świątynię, dokładnie całą świątynię, i również pokrył złotem cały ołtarz, który był przed sanktuarium.
###### **1Krl 6,23**
 W sanktuarium wykonał dwa cheruby dziesięciołokciowej wysokości z drew na oliwkowego.
###### **1Krl 6,24**
 Jedno skrzydło cheruba miało pięć łokci i drugie skrzydło cheruba miało też pięć łokci. Więc od końca do końca jego skrzydeł było dziesięć łokci.
###### **1Krl 6,25**
 Drugi cherub miał ten sam rozmiar dziesięciu łokci, i obydwa cheruby miały takie same kształty.
###### **1Krl 6,26**
 Wysokość jednego i drugiego cheruba wynosiła dziesięć łokci.
###### **1Krl 6,27**
 Gdy umieścił te cheruby w głębi wnętrza świątyni, to rozpościerały swe skrzydła tak, że skrzydło jednego dotykało jednej ściany, a skrzydło drugiego cheruba dotykało drugiej ściany. Skrzydła zaś ich skierowane do środka świątyni dotykały się wzajemnie.
###### **1Krl 6,28**
 Cheruby te pokrył złotem.
###### **1Krl 6,29**
 Ponadto na wszystkich ścianach świątyni dokoła wyrył jako płaskorzeźby podobizny cherubów i palm oraz girlandy kwiatów, wewnątrz i na zewnątrz.
###### **1Krl 6,30**
 Podłogę świątyni również pokrył złotem, wewnątrz i na zewnątrz.
###### **1Krl 6,31**
 Wejście zaś do sanktuarium zaopatrzył w podwoje z drewna oliwkowego. A filary były pięciokątne.
###### **1Krl 6,32**
 Na tych zaś podwojach z drewna oliwkowego też wyrzeźbił podobizny cherubów, palm i girlandy kwiatów oraz pokrył złotem i obił nim owe cheruby i palmy.
###### **1Krl 6,33**
 Również wejście do świątyni zaopatrzył w czworokątne odrzwia z drewna oliwkowego
###### **1Krl 6,34**
 i podwójne drzwi z drewna cyprysowego. Dwie obracające się deski tworzyły jedno skrzydło, i dwie obracające się deski – drugie.
###### **1Krl 6,35**
 Na nich wyrzeźbił cheruby, palmy, girlandy kwiatów oraz pokrył te płaskorzeźby cienkim złotem.
###### **1Krl 6,36**
 Ponadto obudował dziedziniec wewnętrzny trzema rzędami ciosowych kamieni i rzędem ociosanych belek cedrowych.
###### **1Krl 6,37**
 Fundament domu Pańskiego został założony w miesiącu Ziw roku czwartego.
###### **1Krl 6,38**
 W roku zaś jedenastym, w miesiącu Bul, < który jest ósmy >, ukończył świątynię we wszystkich szczegółach i z całym jej urządzeniem. A więc budował ją siedem lat.
# 1Krl 6 PAU
###### **1Krl 6,1**
 Czterysta osiemdziesiąt lat po wyjściu Izraelitów z Egiptu, w czwartym roku swojego panowania nad Izraelem, w drugim miesiącu tego roku, to jest w miesiącu Ziw, Salomon rozpoczął budowę domu dla PANA.
###### **1Krl 6,2**
 Dom, który zbudował dla PANA król Salomon, miał sześćdziesiąt łokci długości, dwadzieścia łokci szerokości i trzydzieści łokci wysokości.
###### **1Krl 6,3**
 Przedsionek domu był szeroki na dwadzieścia łokci, tak jak główna część domu, a wystawał przed dom na dziesięć łokci.
###### **1Krl 6,4**
 Zrobił również okna w domu.
###### **1Krl 6,5**
 Zbudował mury domu i jego wewnętrznej części, wznosząc po obu ich stronach piętrowe skrzydła z bocznymi pomieszczeniami.
###### **1Krl 6,6**
 Dolne piętro miało pięć łokci szerokości, środkowe - sześć łokci szerokości, a górne - siedem łokci szerokości, gdyż na zewnątrz domu zbudował dokoła ściany oporowe, aby belki nośne przybudówki nie wchodziły w mury domu.
###### **1Krl 6,7**
 Wznoszono dom z bloków skalnych, sprowadzanych prosto z kamieniołomów. Podczas budowy domu nie słyszano ani młotka, ani siekiery, ani żadnego innego narzędzia z żelaza.
###### **1Krl 6,8**
 Drzwi do dolnego piętra przybudówki znajdowały się po prawej stronie domu. Kręte schody prowadziły na środkowe piętro, a ze środkowego na górne.
###### **1Krl 6,9**
 Kiedy ukończono budowę domu, wnętrze wyłożono drewnem cedrowym.
###### **1Krl 6,10**
 Wznosząc przybudówkę, której każde piętro miało pięć łokci wysokości, związał ją z głównym budynkiem domu cedrowymi belkami.
###### **1Krl 6,11**
 Wówczas PAN powiedział do Salomona:
###### **1Krl 6,12**
 „Oto budujesz dom! Jeśli więc będziesz postępował według moich praw i wykonywał moje wyroki oraz wiernie zachowywał wszystkie przykazania, wtedy spełnię wobec ciebie obietnicę, którą dałem twemu ojcu, Dawidowi:
###### **1Krl 6,13**
 Zamieszkam wśród Izraelitów i nie opuszczę mojego ludu Izraela”.
###### **1Krl 6,14**
 Kiedy Salomon zakończył budowę domu,
###### **1Krl 6,15**
 wyłożył jego wewnętrzne ściany od podłogi aż do sufitu drewnem cedrowym, natomiast podłogę domu wykonał z drewna cyprysowego.
###### **1Krl 6,16**
 Tylną część domu o długości dwudziestu łokci oddzielił ścianą z drewna cedrowego, sięgającą od podłogi do sufitu, i przeznaczył na najbardziej wewnętrzne miejsce domu, to jest miejsce najświętsze.
###### **1Krl 6,17**
 Czterdzieści łokci długości miała główna część domu.
###### **1Krl 6,18**
 W cedrowym wnętrzu domu wyrzeźbiono pąki i kielichy kwiatowe. Wszystko było cedrowe; kamienia nie było widać.
###### **1Krl 6,19**
 Następnie urządził najbardziej wewnętrzne miejsce domu, aby w nim umieścić Arkę Przymierza PANA.
###### **1Krl 6,20**
 Miało ono dwadzieścia łokci długości, dwadzieścia łokci szerokości i dwadzieścia łokci wysokości. Pokrył je - podobnie jak cedrowy ołtarz - czystym złotem.
###### **1Krl 6,21**
 Także wnętrze głównej części domu Salomon pokrył czystym złotem, zawieszając przed jego najbardziej wewnętrznym miejscem pozłacane łańcuchy.
###### **1Krl 6,22**
 Tak więc pokrył on złotem cały dom i ołtarz, znajdujący się w jego najbardziej wewnętrznym miejscu.
###### **1Krl 6,23**
 Wykonał w nim także dwóch cherubów z drewna oliwkowego, z których każdy miał po dziesięć łokci wysokości.
###### **1Krl 6,24**
 Każde z dwóch skrzydeł cheruba miało pięć łokci. Od końca jednego skrzydła do końca drugiego było więc dziesięć łokci.
###### **1Krl 6,25**
 Podobnie rozmiar drugiego cheruba wynosił dziesięć łokci. Obaj cherubowie mieli ten sam rozmiar i kształt:
###### **1Krl 6,26**
 jeden i drugi miał dziesięć łokci wysokości.
###### **1Krl 6,27**
 Umieścił ich następnie wewnątrz domu. Cherubowie mieli skrzydła rozpostarte. Skrzydło jednego dotykało jednej ściany, a skrzydło drugiego dotykało drugiej ściany. Dwa pozostałe skrzydła dotykały się wzajemnie na środku domu.
###### **1Krl 6,28**
 Cherubów także pokrył złotem.
###### **1Krl 6,29**
 Na wszystkich ścianach domu, zarówno wewnętrznych, jak i zewnętrznych, wyrył postacie cherubów, palmy i kielichy kwiatowe.
###### **1Krl 6,30**
 Również podłogę domu, tak w wewnętrznym pomieszczeniu, jak i w zewnętrznym, pokrył złotem.
###### **1Krl 6,31**
 W wejściu do najbardziej wewnętrznego miejsca wykonał podwójne drzwi z drewna oliwkowego, przymocowane do futryny o kształcie pięciokątnym.
###### **1Krl 6,32**
 Na tych drzwiach wykonanych z drewna oliwkowego wyrzeźbił postacie cherubów, palmy i kielichy kwiatowe, które pokrył złotem, natomiast płaskorzeźby cherubów i palm obił blachą ze złota.
###### **1Krl 6,33**
 Tak samo w wejściu do głównej części wykonał czworokątną futrynę z drewna oliwkowego
###### **1Krl 6,34**
 oraz podwójne drzwi z drewna cyprysowego. Każde z jego skrzydeł obracało się na dwóch zawiasach.
###### **1Krl 6,35**
 Wyrzeźbił na nich cherubów, palmy i kielichy kwiatowe, pokrywając je cienką warstwą złota.
###### **1Krl 6,36**
 Następnie obudował wewnętrzny dziedziniec trzema warstwami ociosanych kamieni i warstwą belek cedrowych.
###### **1Krl 6,37**
 W czwartym roku, w miesiącu Ziw położono fundamenty domu PANA,
###### **1Krl 6,38**
 a w roku jedenastym, w miesiącu Bul, który jest miesiącem ósmym, ukończono budowę domu we wszystkich jej częściach, zgodnie z jej szczegółowym planem. Budowa trwała siedem lat.
# 1Krl 6 BP
###### **1Krl 6,1**
 W roku czterysta osiemdziesiątym po wyjściu synów Izraela z ziemi egipskiej, w czwartym roku panowania nad Izraelem, w miesiącu Ziw - miesiąc ten jest drugi - Salomon rozpoczął budować Świątynię dla Jahwe.
###### **1Krl 6,2**
 Świątynia, którą król Salomon budował dla Jahwe, miała sześćdziesiąt łokci długości, dwadzieścia szerokości i trzydzieści łokci wysokości.
###### **1Krl 6,3**
 Przedsionek przed miejscem Świętym Świątyni był dwadzieścia łokci długi, [idąc] wzdłuż szerokości Świątyni, i dziesięć łokci szeroki, [mierząc] w kierunku przedłużenia Świątyni.
###### **1Krl 6,4**
 Wykonał dla Świątyni okna z zakratowanymi wnękami.
###### **1Krl 6,5**
 Przy murze Świątyni zbudował przybudówkę wokół ścian Świątyni, [to jest] wokół miejsca Świętego i miejsca Najświętszego, i porobił cele wokoło.
###### **1Krl 6,6**
 Najniższa część przybudówki miała pięć łokci szerokości, środkowa sześć łokci szerokości, a trzecia siedem łokci szerokości, albowiem [w murach] Świątyni na zewnątrz wokoło zostawił uskoki, aby nie wkuwać się w ściany Świątyni.
###### **1Krl 6,7**
 Gdy budowano Świątynię, używano kamienia nietkniętego [żelazem po wydobyciu] z kamieniołomu, [toteż] w czasie budowy Świątyni nie było słychać ani młotów, ani topora, ani żadnego narzędzia żelaznego.
###### **1Krl 6,8**
 Wejście do celi najniższej [części przybudówki] znajdowało się po prawej stronie z boku Świątyni. Kręte schody prowadziły do [kondygnacji] środkowej, a ze środkowej do trzeciej.
###### **1Krl 6,9**
 Budował więc [Salomon] Świątynię, ukończył ją i położył sufit na Świątyni z belek i desek cedrowych.
###### **1Krl 6,10**
 Przybudówkę wysoką na pięć łokci zbudował poza całą Świątynią i związał [ją] ze Świątynią drzewem cedrowym.
###### **1Krl 6,11**
 Jahwe przemówił do Salomona tymi słowami:
###### **1Krl 6,12**
 [Ze względu na] tę właśnie Świątynię, którą budujesz, jeśli będziesz postępował według moich przepisów i będziesz wypełniał moje zarządzenia oraz przestrzegał wszystkich moich nakazów, stosując się do nich, spełnię na tobie moją obietnicę, którą dałem Dawidowi, twojemu ojcu,
###### **1Krl 6,13**
 zamieszkam pośród synów Izraela i nie opuszczę ludu mego izraelskiego.
###### **1Krl 6,14**
 Salomon zbudował Świątynię i wykończył ją.
###### **1Krl 6,15**
 Wewnętrzne ściany Świątyni wyłożył deskami cedrowymi od podłogi po belki sufitu. Podłogę Świątyni pokrył deskami cyprysowymi.
###### **1Krl 6,16**
 [Przestrzeń] dwudziestu łokci, [licząc] od tylnej ściany Świątyni, wyłożył deskami cedrowymi od podłogi aż po belki [sufitu] i urządził tam Debir, Święte Świętych.
###### **1Krl 6,17**
 [Przestrzeń] czterdziestu łokci stanowiła Świątynię, był to Hekal, przed [miejscem Najświętszym].
###### **1Krl 6,18**
 Wnętrze Świątyni [było pokryte drzewem] cedrowym, rzeźbionym w [kształcie] liści kolokwintu i otwartych kielichów kwiatowych. Wszystko było pokryte drzewem cedrowym, [tak że] kamienia nie było widać.
###### **1Krl 6,19**
 Miejsce Najświętsze urządził w środku Świątyni [w części] wewnętrznej, by tam złożyć Arkę Przymierza Jahwe.
###### **1Krl 6,20**
 [...] Miejsce Najświętsze miało dwadzieścia łokci długości, dwadzieścia łokci szerokości i dwadzieścia łokci wysokości. [Salomon] pokrył je czystym złotem. Sporządził [też] ołtarz cedrowy
###### **1Krl 6,21**
 przed miejscem Najświętszym i wyłożył go złotem. Salomon pokrył czystym złotem wnętrze Świątyni. Przed miejscem Najświętszym, [które] pokrył złotem, umieścił zloty łańcuch.
###### **1Krl 6,22**
 Całą Świątynię pokrył złotem, dosłownie całą Świątynię i cały ołtarz, który stał przed miejscem Najświętszym, wyłożył złotem.
###### **1Krl 6,23**
 Dla miejsca Najświętszego wykonał dwa cheruby z drzewa oliwnego na dziesięć łokci wysokie.
###### **1Krl 6,24**
 Pięć łokci miało jedno skrzydło cheruba i pięć łokci miało drugie skrzydło cheruba. Dziesięć łokci było od końca [jednego] skrzydła do końca [drugiego] jego skrzydła.
###### **1Krl 6,25**
 Dziesięć łokci miał drugi cherub. Ten sam wymiar i ten sam kształt miały oba cheruby.
###### **1Krl 6,26**
 Wysokość jednego cheruba wynosiła dziesięć łokci i tyleż drugiego cheruba.
###### **1Krl 6,27**
 Cheruby [te] postawił w środku wewnętrznej Świątyni. Cheruby rozpościerały skrzydła [w ten sposób, że] skrzydło jednego dotykało [jednej] ściany, skrzydło zaś drugiego cheruba dotykało drugiej ściany, oraz [że] w środku Świątyni dotykały się ich skrzydła - skrzydło ze skrzydłem.
###### **1Krl 6,28**
 Cheruby pokrył złotem.
###### **1Krl 6,29**
 Wszystkie dookoła ściany Świątyni wewnątrz i na zewnątrz ozdobił płaskorzeźbami w kształcie cherubów, palm i otwartych kielichów kwiatowych.
###### **1Krl 6,30**
 Podłogę Świątyni pokrył złotem wewnątrz i na zewnątrz.
###### **1Krl 6,31**
 U wejścia do miejsca Najświętszego wykonał podwoje z drzewa oliwnego. Filary i odrzwia [zajmowały] piątą część [wejścia].
###### **1Krl 6,32**
 Obydwa skrzydła drzwi były z drzewa oliwnego. Ozdobił je płaskorzeźbami cherubów, palm i otwartych kielichów kwiatowych i obłożył złotem. Na cherubów i na palmy nałożył złoto.
###### **1Krl 6,33**
 Tak [również] wykonał wejście do miejsca Świętego. Odrzwia z drzewa oliwnego [zajmowały] czwartą część [wejścia].
###### **1Krl 6,34**
 Obydwa skrzydła drzwi były [wykonane] z drzewa cyprysowego. Dwie listwy tworzyły jedno skrzydło i dwie listwy ruchome tworzyły drugie skrzydło.
###### **1Krl 6,35**
 Wykonał płaskorzeźby cherubów, palm i otwartych kielichów kwiatowych i pokrył złotem, dokładnie nałożonym na płaskorzeźbę.
###### **1Krl 6,36**
 Zbudował dziedziniec wewnętrzny, [którego mur stanowiły] trzy warstwy kamienia ciosanego i jedna warstwa belek cedrowych.
###### **1Krl 6,37**
 W czwartym roku, w miesiącu Ziw, rozpoczął budować Świątynię [dla] Jahwe,
###### **1Krl 6,38**
 a w jedenastym roku, w miesiącu Bul - jest to miesiąc ósmy - ukończył [budowę] świątyni we wszystkich szczegółach i ze wszystkimi jej wymogami. Budował ją siedem lat.
# 1Krl 6 BR
###### **1Krl 6,1**
 W roku czterysta osiemdziesiątym po wyjściu synów Izraela z Egiptu, w czwartym roku panowania Salomona nad całym Izraelem, w miesiącu Ziw, czyli w drugim miesiącu roku, rozpoczął Salomon budowę świątyni dla Jahwe.
###### **1Krl 6,2**
 Świątynia, którą król Salomon budował dla Jahwe, miała sześćdziesiąt łokci długości, dwadzieścia szerokości i trzydzieści wysokości.
###### **1Krl 6,3**
 Przedsionek przed świątynią liczył dwadzieścia łokci długości, tyle ile frontowa ściana świątyni, do której przylegał, i dziesięć łokci szerokości, wystając przed świątynię.
###### **1Krl 6,4**
 W oknach kazał król na stałe umieścić ramy z kratami.
###### **1Krl 6,5**
 Wzdłuż murów świątyni, a także wokół Miejsca Świętego i Świętego Świętych wzniesiono piętrową budowlę. Wykonano również boczne pomieszczenia dokoła [całej świątyni].
###### **1Krl 6,6**
 Piętro dolne miało pięć łokci, a trzecie [górne] - siedem łokci. Dokoła całej świątyni, na zewnątrz jej murów, usypano bowiem skarpy, żeby mury nie uległy uszkodzeniu [gdyby miały podtrzymywać pomieszczenia boczne].
###### **1Krl 6,7**
 Kiedy zaczęto budowę, mury wznoszono z bloków kamiennych przygotowanych w kamieniołomach. W ten sposób przy budowie świątyni nie było słychać uderzeń ani młotów, ani siekier, ani żadnych innych narzędzi żelaznych.
###### **1Krl 6,8**
 Wejście na piętro środkowe znajdowało się z prawej strony świątyni. Stamtąd kręconymi schodami wchodziło się na piętro środkowe, a z niego - na piętro trzecie [czyli górne].
###### **1Krl 6,9**
 Kiedy zakończono budowę [murów] świątyni, nakryto całą budowlę stropem wykonanym z belek i desek cedrowych.
###### **1Krl 6,10**
 Nad całą świątynią wzniesiono nadbudowę wysoką na pięć łokci i połączoną za pomocą desek cedrowych z samą świątynią.
###### **1Krl 6,11**
 I przemówił Jahwe do Salomona w te słowa:
###### **1Krl 6,12**
 Tak więc budujesz świątynię! Jeżeli będziesz przestrzegał moich praw, jeżeli będziesz wprowadzał w życie moje zarządzenia, jeżeli będziesz posłuszny wszystkim moim wskazaniom i według nich postępował, to sprawdzą się na tobie słowa, które wypowiedziałem o tobie do twego ojca Dawida.
###### **1Krl 6,13**
 Ja sam zaś zamieszkam pośrodku synów Izraela i nigdy nie opuszczę ludu mojego izraelskiego.
###### **1Krl 6,14**
 I tak zbudował Salomon świątynię i wykończył ją.
###### **1Krl 6,15**
 Od strony wewnętrznej obito ściany świątyni deskami cedrowymi, od samego dołu aż po belki sufitowe. Podłogę świątyni zaś pokryto deskami cyprysowymi.
###### **1Krl 6,16**
 W głębi świątyni zbudowano z desek cedrowych ścianę wysoką na dwadzieścia łokci. Ściana, postawiona na podłodze, sięgała aż do belek sufitowych, oddzielając w ten sposób Święte Świętych [od reszty świątyni].
###### **1Krl 6,17**
 [Do Świętego Świętych] długość świątyni wynosiła czterdzieści łokci.
###### **1Krl 6,18**
 Na deskach cedrowych, pokrywających ściany świątyni od wewnątrz, znajdowały się rzeźbione kwiaty i girlandy, wszystko wykonane z drewna cedrowego. Kamienia wcale nie było widać.
###### **1Krl 6,19**
 W tylnej części świątyni przygotował Salomon miejsce na Święte Świętych i tam miała stanąć arka Boża.
###### **1Krl 6,20**
 Długość Świętego Świętych po stronie wewnętrznej wynosiła dwadzieścia łokci, dwadzieścia łokci szerokość i dwadzieścia łokci wysokość. Całość była wyłożona szczerym złotem. Złotem obity był również cedrowy ołtarz.
###### **1Krl 6,21**
 Wnętrze całej świątyni było także wyłożone szczerym złotem, umocowano złote łańcuchy.
###### **1Krl 6,22**
 Tak więc cała świątynia od strony wewnętrznej była wyłożona złotem. Złotem był również pokryty ołtarz, który znajdował się przed Świętym Świętych.
###### **1Krl 6,23**
 W Świętym Świętych ustawiono dwa cheruby wykonane z drewna oliwkowego, każdy wysoki na dziesięć łokci.
###### **1Krl 6,24**
 Skrzydła cherubów miały po pięć łokci długości, a od końca jednego skrzydła do końca drugiego było dziesięć łokci.
###### **1Krl 6,25**
 Obydwa cheruby miały taki sam kształt i takie same wszystkie rozmiary.
###### **1Krl 6,26**
 Wysokość jednego cheruba wynosiła dziesięć łokci; tak samo wysoki był drugi.
###### **1Krl 6,27**
 Obydwa cheruby z rozpostartymi skrzydłami kazał Salomon umieścić wewnątrz świątyni, w samym jej środku. Jedno skrzydło jednego cheruba dotykało jednej ściany, a jedno skrzydło drugiego dochodziło do drugiej ściany. Drugimi skrzydłami obydwa cheruby dotykały się nawzajem pośrodku świątyni.
###### **1Krl 6,28**
 Cheruby też kazał Salomon pokryć złotem.
###### **1Krl 6,29**
 Wszystkie ściany świątyni polecił ozdobić tak wewnątrz, jak i na zewnątrz płaskorzeźbami przedstawiającymi cherubów, palmy oraz girlandy kwiatów.
###### **1Krl 6,30**
 Podłogę świątyni, zarówno przednią, jak i tylną jej część, także kazał pokryć złotem.
###### **1Krl 6,31**
 U wejścia do Świętego Świętych znajdowały się dwuskrzydłowe drzwi z drewna oliwkowego. Podtrzymujące je węgary miały kształt pięciokątny.
###### **1Krl 6,32**
 Obydwa skrzydła drzwi z drewna oliwkowego były pokryte płaskorzeźbami przedstawiającymi cherubów, palmy i girlandy kwiatów. Wszystko było również pokryte złotem, także cheruby i palmy.
###### **1Krl 6,33**
 U wejścia do Miejsca Świętego znajdowały się węgary z drewna oliwkowego, czworokątne.
###### **1Krl 6,34**
 Obydwa skrzydła drzwi były wykonane z drewna cyprysowego. Dwie ruchome deski tworzyły jedno skrzydło drzwi, dwie ruchome deski - drugie.
###### **1Krl 6,35**
 Na obydwu skrzydłach drzwi znajdowały się płaskorzeźby przedstawiające cheruby, palmy i girlandy kwiatów. Wszystko zostało pokryte cienką warstwą złota.
###### **1Krl 6,36**
 Wykonano również dziedziniec wewnętrzny, [otoczony murem] z trzema rzędami ciosanych kamieni i jednym rzędem belek cedrowych.
###### **1Krl 6,37**
 W roku czwartym, w miesiącu Ziw, położono fundamenty pod świątynię Jahwe.
###### **1Krl 6,38**
 Natomiast w roku jedenastym, w miesiącu Bul, czyli ósmego miesiąca roku, zakończono budowę i wyposażanie wszystkich części świątyni. Tak więc cała budowa trwała siedem lat.
# 1Krl 6 WUJ
###### **1Krl 6,1**
 Stało się tedy roku czterysetnego i ośmdziesiątego wyścia synów Izraelowych z ziemie Egiptskiej, roku czwartego miesiąca Zyja (ten jest miesiąc wtóry) królowania Salomonowego nad Izraelem, poczęto budować dom Panu.
###### **1Krl 6,2**
 A dom, który budował król Salomon Panu, miał sześćdziesiąt łokci wzdłuż, a dwadzieścia a trzydzieści łoko na zwyż.
###### **1Krl 6,3**
 A przysionek był przed kościołem dwadzieścia łokiet w zdłuż, według miary szerokości kościoła: a miał dziesięć łokiet w szerz przed kościołem.
###### **1Krl 6,4**
 I poczynił w kościele okna pochodziste,
###### **1Krl 6,5**
 I zbudował na ścianie kościelnej gmachy w około, na ścianach domu koło kościoła i koło wyroczaice, i uczynił pobocznice w około.
###### **1Krl 6,6**
 Gmach, który niższy był, miał pięć łokiet w szerz, a średni gmach, sześć łokiet w szerz, a trzeci gmach miał siedm łokiet w szerz. Tramy lepak położył w domu około z nadworza, aby nie przylegały do murów kościelnych.
###### **1Krl 6,7**
 A gdy dom budowano, budowano go z kamienia ciosanego i wyrobionego: a młota i siekiery i wszelakiego naczynia żelaznego nie słychać było w domu, gdy go budowano.
###### **1Krl 6,8**
 Drzwi średniego boku na stronie były domu prawej ręki: a po okrągłym wschodzie wstępowano na gmach średni, a z średniego na trzeci.
###### **1Krl 6,9**
 I budował dom i dokończył go: i przykrył dom połapem Cedrowym.
###### **1Krl 6,10**
 I zbudował piętro na wszystkim domie, pięć łokiet w zwyż, i pokrył dom drzewem Cedrowem.
###### **1Krl 6,11**
 I stało się słowo Pańskie do Salomona, rzekąc.
###### **1Krl 6,12**
 Dom ten, który budujesz, jeśli będziesz chodził w przykazaniach moich i sądy moje czynić będziesz, i zachowasz wszystkie rozkazania moje, chodząc w nich: utwierdzę mowę moję tobie, którąm mówił do Dawida ojca twego.
###### **1Krl 6,13**
 I będę mieszkał w pośrodku synów Izraelowych, i nie opuszczę ludu mego Izraelskiego.
###### **1Krl 6,14**
 A tak budował Salomon dom i dokonał go.
###### **1Krl 6,15**
 I zbudował ściany domu wewnątrz deskami Cedrowemi, ode tła domu aż do wierzchu ścian, i aż do stropu okrył ściany drzewem Cedrowem wewnątrz: a tło domu położył tarcicami Jodłowemi.
###### **1Krl 6,16**
 I zbudował na dwudziestu łokiet w tył, kościoła gmachy Cedrowe, ode tła aż ku wierzchu: i uczynił wnętrzny dom wyrocznice na święte świętych.
###### **1Krl 6,17**
 Ale sam kościół był na czterdzieści łokiet przededrzwiami wyrocznice.
###### **1Krl 6,18**
 A wszystek dom wewnątrz był Cedrem oprawiony, mając toczenia fugowania swe barzo foremne, i rzezania wysadzające się: wszystko Cedrowemi deskami było okryto: i zgoła żaden kamień nie mógł być widziany w ścienie.
###### **1Krl 6,19**
 Lecz wyrocznice w pośrodku domu we wnętrznej stronie był nagotował, aby tam postawił skrzynię przymierza Pańskiego.
###### **1Krl 6,20**
 A wyrocznica miała dwadzieścia łokiet w zdłuż i dwadzieścia łokiet w szerz, i dwadzieścia łokiet w zwyż: i okrył ją. I odział szczerem złotem: ale i ołtarz osadził Cedrem.
###### **1Krl 6,21**
 Dom też przed wyrocznicą okrył szczerem złotem, i przybił blachy gwoździami złotemi.
###### **1Krl 6,22**
 I nie było niczego w kościele, czegoby złotem nie okryto: ale i wszystek ołtarz wyrocznice powlókł złotem.
###### **1Krl 6,23**
 I uczynił w wyrocznicy dwa Cheruby z drzewa oliwnego, dziesięć łokci na zwyż,
###### **1Krl 6,24**
 Pięć łokci jedno skrzydło Cheruba, a pięć łokci drugie skrzydło Cheruba: to jest, dziesięć łokci mające od końca skrzydła jednego aż do końca skrzydła drugiego.
###### **1Krl 6,25**
 Dziesięć też łokci był Cherub drugi, w równej mierze, i robota jedna była we dwu Cherubach,
###### **1Krl 6,26**
 To jest wysokość Cheruba jednego, była na dziesiąci łokci, i także Cheruba drugiego.
###### **1Krl 6,27**
 I postawił Cherubiny w pośrodku kościoła wnętrznego: ale rozciągali skrzydła swe Cherubowie, i dosięgało skrzydła jedno ściany, a skrzydło Cheruba drugiego dosięgało ściany drugiej: a drugie skrzydła w pośrodku kościoła dotykały się jedno drugiego.
###### **1Krl 6,28**
 Powlókł też Cheruby złotem.
###### **1Krl 6,29**
 A wszystkie ściany kościelne w około wyrzezał rozmaitem rzezaniem i toczeniem: i poczynił na nich Cheruby, i palmy, i kwiaty rozmaite, jakoby się wydające z ściany i wychodzące.
###### **1Krl 6,30**
 Lecz i tło domu położył złotem wewnątrz i zewnątrz.
###### **1Krl 6,31**
 A na weściu wyrocznice uczynił drzwiczki z drzewa oliwnego, a podwoje były na pięć grani.
###### **1Krl 6,32**
 A dwoje drzwi z drzewa oliwnego: i wyrył na nich malowanie Cherubim, i figury palm, i rzezania barzo wydatne: i powlókł je złotem: i oprawił złotem tak Cheruby jako i palmy, i inne rzeczy.
###### **1Krl 6,33**
 I uczynił w weściu kościoła podwoje z drzewa oliwnego na cztery granie:
###### **1Krl 6,34**
 A dwoje drzwi z drzewa Jodłowego we wnątrz ku sobie: a oboje drzwi dwoiste były, i społu się dzierżąc otwierały się.
###### **1Krl 6,35**
 I wyrzezał Cheruby i palmy, i rzezania barzo wydatnie, i powlókł wszystko blachami złotemi robotą granowitą pod prawidło.
###### **1Krl 6,36**
 I zbudował sień wnętrzną trzema rzędoma kamienia ciosanego, a jednym rzędem drzewa Cedrowego.
###### **1Krl 6,37**
 Roku czwartego jest założon dom Pański, miesiąca Zyja,
###### **1Krl 6,38**
 A roku jedenastego miesiąca Bul (ten jest ósmy miesiąc) dokonan jest dom ze wszystką robotą swą, i ze wszystkiem naczyniem jego: a budował ji siedm lat.
