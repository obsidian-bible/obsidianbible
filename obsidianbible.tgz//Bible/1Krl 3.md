# 1Krl 3 BT5
###### **1Krl 3,1**
 Salomon został zięciem faraona, króla egipskiego, gdyż wziął za żonę córkę faraona i sprowadził ją do Miasta Dawidowego, zanim dokończył budowy swego pałacu oraz świątyni Pańskiej, jak też murów okalających Jerozolimę.
###### **1Krl 3,2**
 Lud jednak składał ofiary na wyżynach, gdyż do tego czasu jeszcze nie została zbudowana świątynia ku czci Pana.
###### **1Krl 3,3**
 Chociaż Salomon umiłował Pana, naśladując obyczaje ojca swego, Dawida, jednak i on składał ofiary i palił kadzidło na wyżynach.
###### **1Krl 3,4**
 Król udał się do Gibeonu, aby tam złożyć ofiarę, bo była tam wielka wyżyna. Salomon złożył na owym ołtarzu tysiąc ofiar całopalnych.
###### **1Krl 3,5**
 W Gibeonie Pan ukazał się Salomonowi w nocy, we śnie. Wtedy Bóg rzekł: «***Proś o to, co mam ci dać***».
###### **1Krl 3,6**
 A Salomon odrzekł: «***Tyś okazywał Twemu słudze, Dawidowi, memu ojcu, wielką łaskę, bo postępował wobec Ciebie szczerze, sprawiedliwie i w prostocie serca. Ponadto zachowałeś dla niego tę wielką łaskę, że dałeś mu syna zasiadającego na jego tronie po dziś dzień.***
###### **1Krl 3,7**
 ***Teraz więc, o Panie, Boże mój, Tyś ustanowił królem Twego sługę w miejsce Dawida, mego ojca, a ja jestem bardzo młody i nie umiem rządzić.***
###### **1Krl 3,8**
 ***Ponadto Twój sługa jest pośród Twego ludu, który wybrałeś, ludu mnogiego, którego nie da się zliczyć ani też spisać z powodu jego mnóstwa.***
###### **1Krl 3,9**
 ***Racz więc dać Twemu słudze serce rozumne do sądzenia Twego ludu i rozróżniania dobra od zła, bo któż zdoła sądzić ten lud Twój tak liczny?***»
###### **1Krl 3,10**
 Spodobało się Panu, że właśnie o to Salomon poprosił.
###### **1Krl 3,11**
 Bóg więc mu powiedział: «***Ponieważ poprosiłeś o to, a nie poprosiłeś dla siebie o długie życie ani też o bogactwa, i nie poprosiłeś o zgubę twoich nieprzyjaciół, ale prosiłeś dla siebie o umiejętność rozstrzygania spraw sądowych,***
###### **1Krl 3,12**
 ***oto spełniam twoje pragnienie i daję ci serce mądre i pojętne, takie, że podobnego tobie przed tobą nie było i po tobie nie będzie.***
###### **1Krl 3,13**
***I choć nie prosiłeś, daję ci ponadto bogactwo i sławę, tak iż < za twoich dni > podobnego tobie nie będzie wśród królów.***
###### **1Krl 3,14**
 ***Jeśli zaś będziesz postępować moimi drogami, zachowując moje prawa i polecenia za przykładem twego ojca, Dawida, to przedłużę twoje życie***».
###### **1Krl 3,15**
 Gdy Salomon się obudził, uświadomił sobie, że to był sen. Udał się do Jerozolimy i stanąwszy przed Arką Przymierza Pańskiego, ofiarował całopalenia i złożył ofiary pojednania oraz wyprawił ucztę wszystkim swoim sługom.
###### **1Krl 3,16**
 Potem dwie nierządnice przyszły do króla i stanęły przed nim.
###### **1Krl 3,17**
 Jedna z kobiet powiedziała: «***Litości, panie mój! Ja i ta kobieta mieszkamy w jednym domu. Ja urodziłam, kiedy ona była w domu.***
###### **1Krl 3,18**
 ***A trzeciego dnia po moim porodzie ta kobieta również urodziła. Byłyśmy razem. Nikogo innego z nami w domu nie było, tylko my dwie.***
###### **1Krl 3,19**
 ***Syn tej kobiety zmarł w nocy, bo położyła się na nim.***
###### **1Krl 3,20**
 ***Wtedy pośród nocy wstała i zabrała mojego syna od mego boku, kiedy twoja służebnica spała, i przyłożyła go do swoich piersi, położywszy przy mnie swego zmarłego syna.***
###### **1Krl 3,21**
 ***Kiedy rano wstałam, aby nakarmić mojego syna, patrzę, a oto on martwy! Gdy mu się przyjrzałam przy świetle, rozpoznałam, że to nie był mój syn, którego urodziłam***».
###### **1Krl 3,22**
 Na to odparła druga kobieta: «***Wcale nie, bo mój syn żyje, a twój syn zmarł***». Tamta zaś mówi: «***Właśnie że nie, bo twój syn zmarł, a mój syn żyje***». I tak wykrzykiwały wobec króla.
###### **1Krl 3,23**
 Wówczas król powiedział: «***Ta mówi: To mój syn żyje, a twój zmarł; tamta zaś mówi: Nie, bo twój syn zmarł, a mój syn żyje***».
###### **1Krl 3,24**
 Następnie król rzekł: «***Przynieście mi miecz!***» Niebawem przyniesiono miecz królowi.
###### **1Krl 3,25**
 A wtedy król rozkazał: «***Rozetnijcie to żywe dziecko na dwoje i dajcie połowę jednej i połowę drugiej!***»
###### **1Krl 3,26**
 Wówczas kobietę, której syn był żywy, zdjęła litość nad swoim synem i zawołała: «***Litości, panie mój! Niech dadzą jej dziecko żywe, abyście tylko go nie zabijali!***» Tamta zaś mówiła: «***Niech nie będzie ani moje, ani twoje! Rozetnijcie!***»
###### **1Krl 3,27**
 Na to król zabrał głos i powiedział: «***Dajcie tamtej to żywe dziecko i nie zabijajcie go! Ona jest jego matką***».
###### **1Krl 3,28**
 Kiedy o tym wyroku sądowym króla dowiedział się cały Izrael, czcił króla, bo przekonał się, że jest obdarzony mądrością Bożą do sprawowania sądów.
# 1Krl 3 PAU
###### **1Krl 3,1**
 Salomon zawarł układ z faraonem, królem Egiptu, żeniąc się z jego córką. Wprowadził ją do Miasta Dawida przed ukończeniem budowy swojego pałacu, a także domu PANA oraz murów dokoła Jerozolimy.
###### **1Krl 3,2**
 Lud musiał składać ofiary na wzniesieniach kultowych, gdyż do tego czasu nie wybudowano jeszcze domu dla imienia PANA.
###### **1Krl 3,3**
 Salomon miłował PANA i postępował według wskazań swojego ojca Dawida. Ale wciąż na wzniesieniach kultowych składał ofiary i palił kadzidło.
###### **1Krl 3,4**
 Król zatem udał się do Gabaonu, aby złożyć ofiarę, gdyż tam znajdowało się najważniejsze wzniesienie kultowe. Złożył tam na ołtarzu tysiąc ofiar całopalnych.
###### **1Krl 3,5**
 Właśnie w Gabaonie PAN ukazał się Salomonowi, w nocy. Podczas snu Bóg przemówił: „Proś o to, co mam ci dać”.
###### **1Krl 3,6**
 Wtedy Salomon odpowiedział: „Ty okazałeś swojemu słudze, Dawidowi, mojemu ojcu, wielką miłość, gdyż w swoim postępowaniu wobec Ciebie okazał się wierny, sprawiedliwy i szczery. Zachowałeś tę wielką miłość dla niego, dając mu syna, który dzisiaj zasiada na jego tronie.
###### **1Krl 3,7**
 A teraz Ty, o PANIE, Boże mój, ustanowiłeś swojego sługę królem w miejsce mojego ojca, Dawida, a ja przecież jestem jeszcze młody: nie mam doświadczenia w rządzeniu.
###### **1Krl 3,8**
 Twój sługa znajduje się wśród wybranego przez Ciebie ludu tak bardzo licznego, że nie da się go spisać.
###### **1Krl 3,9**
 Daj więc twemu słudze rozum, aby potrafił wysłuchać stron sporu i wydawać sprawiedliwe wyroki. Któż bowiem może rządzić Twoim ludem, tak wielkim?”.
###### **1Krl 3,10**
 Spodobało się Panu, że Salomon o to prosił.
###### **1Krl 3,11**
 Bóg zatem oświadczył mu: „Ponieważ o to właśnie prosiłeś, a nie poprosiłeś dla siebie o długie życie ani o bogactwa, ani też o śmierć twoich wrogów, lecz prosiłeś dla siebie o zdolność rozstrzygania spraw po wysłuchaniu stron,
###### **1Krl 3,12**
 dlatego spełniam twoją prośbę: daję ci rozum i przenikliwość. Podobnego tobie nie było i nie będzie.
###### **1Krl 3,13**
 Dam ci także to, o co nie prosiłeś: bogactwo i sławę, jakich nie posiada żaden z królów, panujących w twoich czasach.
###### **1Krl 3,14**
 A jeśli będziesz chodził drogami, które ci wskazałem, oraz przestrzegał moich praw i przykazań, podobnie jak twój ojciec, Dawid, to obdarzę cię długim życiem”.
###### **1Krl 3,15**
 Potem Salomon się obudził: był to sen! Wrócił więc do Jerozolimy i stanął przed Arką Przymierza PANA. Złożył wtedy ofiary całopalne i ofiary wspólnotowe oraz wyprawił ucztę wszystkim swoim sługom.
###### **1Krl 3,16**
 Wtedy przyszły do króla dwie nierządnice i stanęły przed nim.
###### **1Krl 3,17**
 Głos zabrała pierwsza z nich: „Litości, panie mój! Ja i ta właśnie kobieta mieszkamy w jednym domu. Gdy rodziłam, byłam sama z nią w mieszkaniu.
###### **1Krl 3,18**
 Po trzech dniach od mojego porodu urodziła również ta kobieta. Byłyśmy razem, nikogo innego nie było z nami w domu, tylko my dwie.
###### **1Krl 3,19**
 W nocy umarł syn tej kobiety, gdyż przygniotła go sobą.
###### **1Krl 3,20**
 Wstała więc w środku nocy i zabrała mojego syna od mojego boku, kiedy ja, twoja służebnica, spałam, i przyłożyła go do swoich piersi, a swojego zmarłego syna przyłożyła do moich.
###### **1Krl 3,21**
 Kiedy wstałam wczesnym rankiem, żeby nakarmić mojego syna, patrzę, a on jest martwy! Przyjrzałam mu się uważnie: ależ to nie mój syn, którego urodziłam!”.
###### **1Krl 3,22**
 Druga kobieta zaprzeczyła: „Nie! To mój syn żyje, a twój jest martwy!”. Pierwsza twierdziła: „Nie! To twój jest martwy, a mój żyje!”. Tak się sprzeczały przed królem.
###### **1Krl 3,23**
 Wtedy król powiedział: „Ta mówi: «Moim synem jest żywe dziecko, a twoim synem martwe!». Tamta zaś mówi: «Nie! To twój syn jest martwy, a mój syn żyje!»”.
###### **1Krl 3,24**
 Król zatem polecił: „Przynieście mi miecz!”. Przyniesiono miecz królowi.
###### **1Krl 3,25**
 Król rozkazał: „Rozetnijcie dziecko żywe na dwie części i dajcie połowę jednej i połowę drugiej”.
###### **1Krl 3,26**
 Wówczas kobieta, której syn był żywy, zdjęta litością nad swoim synem, zaczęła usilnie prosić króla: „Błagam cię, panie! Oddajcie jej żywe niemowlę, obyście go tylko nie zabijali!”. Natomiast tamta zawołała: „Niech nie będzie ani moje, ani twoje! Rozetnijcie!”.
###### **1Krl 3,27**
 Wtedy król ogłosił wyrok: „Oddajcie tej żywe niemowlę i nie zabijajcie go! Ona jest jego matką”.
###### **1Krl 3,28**
 Kiedy cały Izrael usłyszał o wyroku, który król wydał, nabrał wielkiego szacunku do króla, gdyż widział, że posiada on Bożą mądrość do rozstrzygania spraw sądowych.
# 1Krl 3 BP
###### **1Krl 3,1**
 Salomon został zięciem faraona, króla Egiptu, poślubił bowiem córkę faraona. Sprowadził ją do Miasta Dawidowego, gdy skończył budować swój pałac, Świątynię Jahwe i mury wokół Jerozolimy.
###### **1Krl 3,2**
 Lud wszakże składał ofiary krwawe na wyżynach, albowiem aż do owego czasu nie została jeszcze zbudowana Świątynia dla Imienia Jahwe.
###### **1Krl 3,3**
 Salomon miłował Jahwe, idąc za wskazaniami Dawida, swego ojca. Ale on [także] składał ofiary krwawe i palił kadzidło na wyżynach.
###### **1Krl 3,4**
 Król udał się do Gibeonu, aby tam złożyć ofiary krwawe, była to bowiem wielka wyżyna. Salomon ofiarował tysiąc żertw całopalnych na tym ołtarzu.
###### **1Krl 3,5**
 Jahwe ukazał się Salomonowi w Gibeonie w nocy we śnie. Bóg rzekł [do niego]: Proś! Co mam ci dać?
###### **1Krl 3,6**
 Salomon odpowiedział: Tyś okazał wielką łaskawość Twojemu słudze Dawidowi, mojemu ojcu, ponieważ kierował się wobec Ciebie prawdą, sprawiedliwością i prawością serca. Zachowałeś dla niego tę wielką łaskę, iż dałeś mu syna, który obecnie zasiada na jego tronie.
###### **1Krl 3,7**
 Teraz więc o Jahwe, Boże mój, Ty ustanowiłeś królem Twego sługę po Dawidzie, moim ojcu, a ja jestem młodym człowiekiem i nie wiem, jak postępować.
###### **1Krl 3,8**
 Sługa Twój znajduje się wśród Twojego ludu, który wybrałeś, ludu mnogiego, którego z powodu wielkiej liczby nie można ani policzyć, ani spisać.
###### **1Krl 3,9**
 Daj Twojemu słudze serce pojętne, aby mógł sądzić Twój lud, rozpoznać między tym, co jest dobre, a tym, co złe, bo któż może sądzić ten Twój wielki naród.
###### **1Krl 3,10**
 Spodobało się Panu [to] słowo, iż Salomon zaniósł tę właśnie prośbę.
###### **1Krl 3,11**
 Rzekł więc Bóg do niego: Ponieważ zaniosłeś tę właśnie prośbę, a nie błagałeś dla siebie o długie życie, nie wypraszałeś sobie bogactwa, nie domagałeś się życia twoich wrogów, ale prosiłeś dla siebie o umiejętność rozstrzygania spraw sądowych,
###### **1Krl 3,12**
 oto spełnię twoją prośbę i dam ci serce mądre i rozumne [w takim stopniu], że takiego, jakim ty będziesz, nie było przed tobą, i taki, jak ty, nie zjawi się po tobie.
###### **1Krl 3,13**
 A nadto dam ci to, o co nie prosiłeś, a więc takie bogactwo i sławę, że żaden z królów nie będzie się mógł z tobą równać po wszystkie dni twoje.
###### **1Krl 3,14**
 A jeśli będziesz chodził drogami moimi, przestrzegając mojego Prawa i moich nakazów, jak postępował Dawid, ojciec twój, przedłużę ci twoje dni.
###### **1Krl 3,15**
 Salomon przebudził się i oto [uświadomił sobie, że to] był sen. Wrócił więc do Jerozolimy, stanął przed Arką Przymierza Pańskiego i złożył całopalenia oraz ofiarę zjednoczenia i wyprawił ucztę wszystkim swoim dworzanom.
###### **1Krl 3,16**
 Pewnego dnia przyszły do króla dwie kobiety lekkich obyczajów i stanęły przed nim.
###### **1Krl 3,17**
 Jedna z [tych] kobiet rzekła: Proszę cię, panie mój. Ja i ta kobieta mieszkamy w tym samym domu. Porodziłam u niej w domu.
###### **1Krl 3,18**
 I stało się, że w trzecim dniu po moim rozwiązaniu porodziła również ta kobieta. Byłyśmy razem, nikogo obcego nie było z nami w domu. W domu byłyśmy tylko my obie.
###### **1Krl 3,19**
 W nocy zmarł syn tej właśnie kobiety, ponieważ go przygniotła [w czasie snu].
###### **1Krl 3,20**
 Wstała więc wśród nocy i podczas gdy służebnica twoja spała, wzięła mojego syna od mego boku i ułożyła go na swym łonie, a swego zmarłego syna położyła na moim łonie.
###### **1Krl 3,21**
 Wstałam rano, aby dać pierś mojemu synowi, ale oto był martwy. Przyjrzałam się mu więc uważnie [w świetle] poranka i oto [spostrzegłam, że] nie był to mój syn, którego urodziłam.
###### **1Krl 3,22**
 Ale druga kobieta zaprzeczyła: Nie! Moim synem jest ten żywy, a twoim synem jest ten umarły. Na to ta [pierwsza] odpowiedziała: Nie! Twoim synem jest ten umarły, a moim synem jest ten żywy. I spierały się wobec króla.
###### **1Krl 3,23**
 Wtedy król rzekł: Ta mówi: Moim synem jest ten żywy, a twoim synem jest ten umarły. [Tamta] zaś twierdzi: Nie, twoim synem jest ten umarły, a moim synem jest ten żywy.
###### **1Krl 3,24**
 Zawołał więc król: Przynieście mi miecz! I przyniesiono miecz przed króla.
###### **1Krl 3,25**
 Król rozkazał: Rozetnijcie żywego chłopca na dwoje. Połowę dajcie jednej, połowę zaś drugiej.
###### **1Krl 3,26**
 Wtedy ta kobieta, której syn żył, zdjęta litością nad swoim synem zawołała do króla, prosząc: Litości, panie mój! Dajcie jej żywe dziecię! Nie zabijajcie go! A tamta zawołała: Nie będzie ani moje, ani twoje. Rozetnijcie.
###### **1Krl 3,27**
 Wtedy zabrał głos król i powiedział: Oddajcie tej żywe dziecię a nie zabijajcie go. Ona jest jego matką.
###### **1Krl 3,28**
 Cały Izrael usłyszał o wyroku, jaki król wydał. I lękano się króla, albowiem widziano, że była w nim mądrość Boża do sprawowania sądu.
# 1Krl 3 BR
###### **1Krl 3,1**
 Salomon stał się powinowatym z faraonem, królem Egiptu, gdyż wziął sobie za żonę jego córkę. Sprowadził ją do Miasta Dawidowego, zanim jeszcze ukończono budowę pałacu królewskiego, świątyni Jahwe oraz murów okalających całą Jerozolimę.
###### **1Krl 3,2**
 Ofiary składali ludzie na wyżynach, bo ciągle jeszcze nie był gotowy przybytek ku czci imienia Jahwe.
###### **1Krl 3,3**
 Salomon kochał Boga, postępował według wskazań swego ojca, Dawida. Ale i on składał ofiary na wyżynach i palił tam kadzidła.
###### **1Krl 3,4**
 Pewnego razu król udał się do Gibeonu, aby złożyć ofiarę. Tam bowiem było wysoko położone miejsce. Na ołtarzu, który się tam znajdował, złożył Salomon tysiąc ofiar całopalnych.
###### **1Krl 3,5**
 W Gibeonie ukazał się Salomonowi nocą we śnie Jahwe. Wówczas to Bóg tak odezwał się do Salomona: Powiedz, co chcesz, żebym ci dał.
###### **1Krl 3,6**
 A Salomon odpowiedział: Raczyłeś okazać wielką życzliwość słudze Twojemu, ojcu mojemu, Dawidowi, za to, że był Ci wierny i sprawiedliwy w prostocie swego serca. Ponadto wyświadczyłeś mu także tę wielką łaskę, że obdarzyłeś go synem, który obecnie zasiada na jego tronie.
###### **1Krl 3,7**
 To Ty również, Jahwe, Boże mój, władzę po ojcu moim, Dawidzie, przekazałeś mnie, Twojemu słudze. A ja jestem jeszcze całkiem młody i nie bardzo wiem, jak postępować.
###### **1Krl 3,8**
 Żyje Twój sługa wśród ludu, w którym Ty sobie upodobałeś. Jest to naród wielki; nie sposób go ani zliczyć, ani ocenić, tak jest wielki.
###### **1Krl 3,9**
 Zechciej tedy dać słudze Twemu serce pełne mądrości, aby mógł rozsądzać sprawy Twojego ludu, starannie odróżniając dobro od zła. Jakże tu bowiem rozsądzać sprawy Twojego ludu tak licznego?
###### **1Krl 3,10**
 I podobało się Panu, że Salomon właśnie o to Go prosił.
###### **1Krl 3,11**
 Powiedział mu tedy Bóg: Ponieważ taką przedstawiłeś Mi prośbę, a nie pragnąłeś ani długiego życia dla siebie, ani żadnych bogactw; nie domagałeś się również zguby twoich nieprzyjaciół, a prosiłeś jedynie o mądrość potrzebną do sprawiedliwego rządzenia,
###### **1Krl 3,12**
 oto czynię zadość twojej prośbie: daję ci serce mądre i przenikliwe, takie, jakiego nie miał jeszcze nikt przed tobą i nikt w przyszłości mieć nie będzie.
###### **1Krl 3,13**
 Co więcej, dam ci także i to, o co Mnie wcale nie prosiłeś: bogactwo i sławę, tak iż wśród obecnie sprawujących władzę nie będziesz miał sobie równego przez cały czas twojego panowania.
###### **1Krl 3,14**
 A jeśli będziesz się trzymał moich dróg, jeśli będziesz przestrzegał moich praw i nakazów, tak jak to czynił ojciec twój, Dawid, to przedłużę również dni twojego życia.
###### **1Krl 3,15**
 Obudziwszy się, Salomon zrozumiał, że to był sen. Wrócił do Jerozolimy i zaraz udał się przed arkę Bożą, gdzie złożył ofiary całopalne tudzież ofiary pojednania. Wszystkim zaś swoim sługom wyprawił wielką ucztę.
###### **1Krl 3,16**
 Pewnego dnia przyszły do króla dwie nierządnice, stanęły przed nim
###### **1Krl 3,17**
 i jedna z nich powiedziała: Litości, panie mój! Ta oto kobieta i ja mieszkamy pod jednym dachem. Ja, przebywając w pobliżu niej, urodziłam dziecko.
###### **1Krl 3,18**
 W trzy dni po urodzeniu dziecka przeze mnie ta kobieta również wydała na świat dziecko. Byłyśmy razem tylko we dwie, nikogo oprócz nas nie było w domu. W całym domu byłyśmy tylko my dwie.
###### **1Krl 3,19**
 Otóż w nocy zmarło dziecko tej kobiety, ponieważ przygniotła je we śnie.
###### **1Krl 3,20**
 Wtedy wstała w środku nocy, wzięła moje dziecko ode mnie, gdy służebnica twoja spała, i położyła je na własnym łonie, natomiast swoje nieżywe dziecko położyła przy mnie.
###### **1Krl 3,21**
 Kiedy wstałam rano i chciałam nakarmić moje dziecko, zobaczyłam, że było martwe. Ale potem, przyglądając mu się dokładniej, spostrzegłam, że to nie było dziecko, które ja urodziłam.
###### **1Krl 3,22**
 Wtedy druga kobieta zawołała: Nie, to moje dziecko żyje, a nieżywe jest twoje. Lecz pierwsza na to: Ależ nigdy, to twoje nie żyje, moje zaś żyje. I tak spierały się w obecności króla.
###### **1Krl 3,23**
 Powiedział tedy król: Jedna z was twierdzi: Dziecko, które żyje jest moje, natomiast to, które nie żyje, jest twoje. Druga zaś mówi: Żadną miarą! To, które nie żyje, jest twoje; moje dziecko jest to, które żyje.
###### **1Krl 3,24**
 Zarządził więc król: Przynieście mi tu miecz. Kiedy przyniesiono królowi miecz, powiedział:
###### **1Krl 3,25**
 Przetnijcie mieczem to żywe dziecko na połowy i dajcie jedną połowę jednej kobiecie, a drugą - drugiej.
###### **1Krl 3,26**
 Wtedy jednak kobieta, której dziecko żyło, wzruszyła się do głębi nad własnym dzieckiem i powiedziała do króla: Ach, panie mój! Niech już ona weźmie to żywe dziecko, byleby go nie zabijano. Tymczasem ta druga się na to nie zgadzała, tylko mówiła: Niech nie mam ani ja, ani ona! Przecinajcie je!
###### **1Krl 3,27**
 Rozkazał tedy król: Żyjące dziecko oddajcie tej pierwszej kobiecie. Nie zabijajcie dziecka! Ona jest jego matką.
###### **1Krl 3,28**
 Gdy dowiedziano się w Izraelu o wyroku wydanym przez króla, zaczęto się go bać, bo wiedziano, że rozstrzyga sprawy według mądrości Bożej.
# 1Krl 3 WUJ
###### **1Krl 3,1**
 Utwierdziło się tedy Królestwo w ręce Salomonowej, i spowinowacił się z Pharaonem Królem Egiptskim: bo pojął córkę jego, i przyniósł do miasta Dawidowego, ażby był skończył budując dom swój, i dom Pański, i mur Jerozolimski w około.
###### **1Krl 3,2**
 Wszakoż lud ofiarował na wyżynach: bo nie był obudowany kościół imieniowi Pańskiemu aż do dnia onego.
###### **1Krl 3,3**
 I miłował Salomon Pana, chodząc w przykazaniach Dawida ojca swego, wyjąwszy iż na wyżynach ofiarował, i zapalał kadzidło.
###### **1Krl 3,4**
 Szedł tedy do Gabaon, aby tam ofiarował: bo ta była wyżyna nawiętsza: tysiąc ofiar na całopalenie ofiarował Salomon na onym ołtarzu w Gabaon.
###### **1Krl 3,5**
 I ukazał się Pan Salomonowi przez sen w nocy, mówiąc: Proś czego chcesz żeć dam.
###### **1Krl 3,6**
 I rzekł Salomon. Tyś uczynił z sługą swoim Dawidem ojcem moim miłosierdzie wielkie, jako chodził przed oczyma twemi, w prawdzie i w sprawiedliwości, i prostem sercem z tobą: zachowałeś mu miłosierdzie twoje wielkie, i dałeś mu syna siedzącego na stolicy jego, jako jest dzisia.
###### **1Krl 3,7**
 A teraz Panie Boże, tyś uczynił królem sługę twego miasto Dawida ojca mego, a jam jest pacholę małe, a nieznające wyścia i weścia mego.
###### **1Krl 3,8**
 A sługa twój jest w pośrodku ludu, któryś obrał, ludu niezliczonego, który prze mnóstwo nie może być policzony, ani porachowany,
###### **1Krl 3,9**
 A przeto daj słudze twemu serce rozumne, aby mógł twój lud sądzić, i rozeznać między złem a dobrem, bo któż może sądzić lud ten, lud ten twój wielki?
###### **1Krl 3,10**
 Podobała się tedy mowa przed Panem, że Salomon prosił takiej rzeczy.
###### **1Krl 3,11**
 I rzekł Pan Salomonowi: Żeś słowa tego prosił, a nie żądałeś sobie dni wiela, ani bogactw, abo dusz nieprzyjaciół twoich: aleś prosił sobie o mądrość dla rozeznaniu sądu:
###### **1Krl 3,12**
 Otożem ci uczynił według mowy twojej, i dałem ci serce mądre i rozumne, tak iż żaden przed tobą nie był podobny tobie, ani po tobie powstanie.
###### **1Krl 3,13**
 Lecz i to czegoś nie żądał, dałem tobie, to jest bogactwa i sławę, że żaden z królów nie był podobny tobie wszystkich przeszłych czasów.
###### **1Krl 3,14**
 A będziesz li chodził drogami moimi, i strzegł przykazań moich i ustaw moich, jako twój ociec chodził, przedłużę dni twoje.
###### **1Krl 3,15**
 Ocucił się tedy Salomon, i porozumiał że był sen: i przyjachawszy do Jeruzalem, stanął przed skrzynią przymierza Pańskiego, i ofiarował całopalenia, i uczynił ofiary zapokojne, i wielką ucztę na wszystkie sługi swoje.
###### **1Krl 3,16**
 I przyszły dwie niewieście wszetecznice do króla, i stanęły przed nim.
###### **1Krl 3,17**
 Z których jedna rzekła: Proszę mój panie: ja i ta niewiasta mieszkaliśmy w jednym domu, i zległam u niej w komorze.
###### **1Krl 3,18**
 A trzeciego dnia potem jakom porodziła, zległa też i ta: i byłyśmy pospołu, a żaden inny nie był z nami w domu, oprócz nas dwojga.
###### **1Krl 3,19**
 I umarł syn tej niewiasty w nocy: bo go śpiąc przyległa.
###### **1Krl 3,20**
 I wstawszy o północy, wzięła syna mego od boku mnie służebnice twojej śpiącej, i położyła go na łonie swojem: a syna swego, który był umarł położyła na łonie mojem.
###### **1Krl 3,21**
 A gdym wstała rano, chcąc dać mleka synowi memu, nalazłam umarłego: któremu przypatrując się pilniej w jasny dzień, poznałam, że nie był mój któregom porodziła.
###### **1Krl 3,22**
 I odpowiedziała druga niewiasta: Nie jest tak jak powiadasz: ale syn twój umarł, a mój żyw. Przeciwnym zaś obyczajem ona mówiła: Nieprawdę mówisz: bo syn mój żyw, a syn twój umarł. I tak się spierały przed Królem.
###### **1Krl 3,23**
 Tedy król rzekł: Ta mówi, syn mój żyw, a syn twój umarł. A ta odpowiada: Nie, ale syn twój umarł, a mój żyw.
###### **1Krl 3,24**
 I rzekł król: Przynieście mi miecza. A gdy przyniesiono miecz przed króla,
###### **1Krl 3,25**
 Rozdzielcie, pry, dziecię żywe na dwie części, a dajcie połowicę jednej a połowicę drugiej,
###### **1Krl 3,26**
 I rzekła niewiasta, której syn był żywy, do króla: (bo się poruszyły wnętrzności jej nad synem swoim). Proszę panie, dajcie jej dziecię żywe, a nie zabijajcie go. Przeciwnym obyczajem owa mówiła: Niech nie będzie ani mnie ani tobie, ale niech je rozdzielą.
###### **1Krl 3,27**
 Odpowiedział król, i rzekł: Dajcie tej dziecię żywe, a nie zabijajcie go: bo ta jest matka jego.
###### **1Krl 3,28**
 I usłyszał wszystek lud Izraelski sąd, który król osądził, i bali się króla, widząc że mądrość Boża była w nim ku czynieniu sądu.
