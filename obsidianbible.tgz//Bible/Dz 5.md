# Dz 5 BT5
###### **Dz 5,1**
 Ale pewien człowiek, imieniem Ananiasz, z żoną swoją, Safirą, sprzedał posiadłość
###### **Dz 5,2**
 i za wiedzą żony odłożył sobie część zapłaty, a jakąś część przyniósł i złożył u stóp Apostołów.
###### **Dz 5,3**
 «***Ananiaszu***» – powiedział Piotr – «***dlaczego szatan zawładnął twym sercem, że skłamałeś Duchowi Świętemu i odłożyłeś sobie część zapłaty za ziemię?***
###### **Dz 5,4**
 ***Czy przed sprzedażą nie była twoją własnością, a po sprzedaniu czyż nie mogłeś rozporządzać tym, coś za nią otrzymał? Jakże mogłeś dopuścić myśl o takim uczynku? Nie ludziom skłamałeś, lecz Bogu***».
###### **Dz 5,5**
 Słysząc te słowa, Ananiasz padł i wyzionął ducha. A wszystkich, którzy tego słuchali, ogarnął wielki strach.
###### **Dz 5,6**
 Młodsi zaś mężczyźni wstali, owinęli go, wynieśli i pogrzebali.
###### **Dz 5,7**
 Mniej więcej po trzech godzinach weszła także jego żona, nie wiedząc, co się stało.
###### **Dz 5,8**
 «***Powiedz mi***» – zapytał ją Piotr – «***czy za tyle sprzedaliście ziemię?***» «***Tak, za tyle***» – odpowiedziała.
###### **Dz 5,9**
 A Piotr do niej: «***Dlaczego umówiliście się, aby wystawiać na próbę Ducha Pańskiego? Oto stoją w progu ci, którzy pochowali twego męża. Wyniosą też ciebie***».
###### **Dz 5,10**
 A ona upadła natychmiast u jego stóp i skonała. Gdy młodzieńcy weszli, znaleźli ją martwą. Wynieśli ją więc i pochowali obok męża.
###### **Dz 5,11**
 Strach wielki ogarnął cały Kościół i wszystkich, którzy o tym słyszeli.
###### **Dz 5,12**
 Wiele znaków i cudów działo się wśród ludu przez ręce Apostołów. Trzymali się wszyscy razem w krużganku Salomona.
###### **Dz 5,13**
 A z obcych nikt nie miał odwagi dołączyć się do nich, lud zaś ich wychwalał.
###### **Dz 5,14**
 Coraz bardziej też rosła liczba mężczyzn i kobiet przyjmujących wiarę w Pana.
###### **Dz 5,15**
 Wynoszono też chorych na ulice i kładziono na łożach i noszach, aby choć cień przechodzącego Piotra padł na któregoś z nich.
###### **Dz 5,16**
 Także z miast sąsiednich zbiegały się wielkie rzesze do Jeruzalem, znosząc chorych i dręczonych przez duchy nieczyste, a wszyscy doznawali uzdrowienia.
###### **Dz 5,17**
 Wówczas arcykapłan i wszyscy jego zwolennicy, należący do stronnictwa saduceuszów, pełni zawiści,
###### **Dz 5,18**
 zatrzymali Apostołów i wtrącili ich do publicznego więzienia.
###### **Dz 5,19**
 Ale w nocy anioł Pański otworzył bramy więzienia i wyprowadziwszy ich, powiedział:
###### **Dz 5,20**
 «***Idźcie i głoście w świątyni ludowi wszystkie słowa o tym życiu!***»
###### **Dz 5,21**
 Usłuchawszy tego, weszli o świcie do świątyni i nauczali. Tymczasem arcykapłan i jego stronnicy zwołali Sanhedryn i całą starszyznę synów Izraela. Posłali do więzienia, aby ich przyprowadzono.
###### **Dz 5,22**
 Lecz kiedy słudzy przyszli, nie znaleźli ich w więzieniu. Powrócili więc i oznajmili:
###### **Dz 5,23**
 «***Znaleźliśmy więzienie bardzo starannie zamknięte i strażników stojących przed drzwiami. Po otwarciu jednak nie znaleźliśmy wewnątrz nikogo***».
###### **Dz 5,24**
 Kiedy dowódca straży świątynnej i arcykapłani usłyszeli te słowa, nie mogli pojąć, co się z tamtymi stało.
###### **Dz 5,25**
 Wtem nadszedł ktoś i oznajmił im: «***Ci ludzie, których wtrąciliście do więzienia, znajdują się w świątyni i nauczają lud***».
###### **Dz 5,26**
 Wtedy dowódca straży poszedł ze sługami i przyprowadził ich, ale bez użycia siły, bo obawiali się ludu, by ich samych nie ukamienował.
###### **Dz 5,27**
 Przyprowadziwszy ich, stawili przed Sanhedrynem, a arcykapłan zapytał:
###### **Dz 5,28**
 «***Surowo wam zakazaliśmy nauczać w to imię, a oto napełniliście Jeruzalem waszą nauką i chcecie ściągnąć na nas [odpowiedzialność za] krew tego człowieka***».
###### **Dz 5,29**
 «***Trzeba bardziej słuchać Boga niż ludzi***» – odpowiedział Piotr, a także Apostołowie.
###### **Dz 5,30**
 «***Bóg naszych ojców wskrzesił Jezusa, którego wy straciliście, zawiesiwszy na drzewie.***
###### **Dz 5,31**
 ***Bóg wywyższył Go na [miejscu] po prawicy swojej jako Władcę i Zbawiciela, aby zapewnić Izraelowi nawrócenie i odpuszczenie grzechów.***
###### **Dz 5,32**
 ***Dajemy temu świadectwo my właśnie oraz Duch Święty, którego Bóg udzielił tym, którzy Mu są posłuszni***».
###### **Dz 5,33**
 Gdy to usłyszeli, wpadli w gniew i chcieli ich zabić.
###### **Dz 5,34**
 Lecz pewien faryzeusz, imieniem Gamaliel, uczony w Prawie i poważany przez cały lud, kazał na chwilę usunąć Apostołów i zabrał głos w Radzie:
###### **Dz 5,35**
 «***Mężowie izraelscy***» – przemówił do nich – «***zastanówcie się dobrze, co macie uczynić z tymi ludźmi.***
###### **Dz 5,36**
 ***Bo niedawno temu wystąpił Teudas, podając się za kogoś niezwykłego. Przyłączyło się do niego około czterystu ludzi, został on zabity, a wszyscy jego zwolennicy zostali rozproszeni i ślad po nich zaginął.***
###### **Dz 5,37**
 ***Potem podczas spisu ludności wystąpił Judasz Galilejczyk i pociągnął lud za sobą. Zginął sam, i wszyscy jego zwolennicy zostali rozproszeni.***
###### **Dz 5,38**
 ***Więc i teraz wam mówię: Zostawcie tych ludzi i puśćcie ich! Jeżeli bowiem od ludzi pochodzi ta myśl czy sprawa, rozpadnie się,***
###### **Dz 5,39**
 ***a jeżeli rzeczywiście od Boga pochodzi, nie potraficie ich zniszczyć, i oby się nie okazało, że walczycie z Bogiem***». Usłuchali go.
###### **Dz 5,40**
 A przywoławszy Apostołów, kazali ich ubiczować i zabronili im przemawiać w imię Jezusa, a potem zwolnili.
###### **Dz 5,41**
 A oni odchodzili sprzed Sanhedrynu i cieszyli się, że stali się godni cierpieć dla Imienia < Jezusa >.
###### **Dz 5,42**
 Nie przestawali też co dzień nauczać w świątyni i po domach i głosić Dobrą Nowinę o Jezusie Chrystusie.
# Dz 5 PAU
###### **Dz 5,1**
 Ale pewien człowiek, imieniem Ananiasz, którego żoną była Safira, sprzedał posiadłość,
###### **Dz 5,2**
 lecz w porozumieniu z żoną zatrzymał dla siebie część zapłaty. Resztę przyniósł i złożył przed apostołami.
###### **Dz 5,3**
 Wtedy Piotr mu powiedział: „Ananiaszu! Dlaczego uległeś podszeptom szatana, aby zachować część pieniędzy za sprzedany majątek? Okłamałeś Ducha Świętego.
###### **Dz 5,4**
 Czyż posiadłość nie była twoją własnością, podobnie jak pieniądze za nią uzyskane? Dlaczego dopuściłeś się tego czynu? Nie ludzi okłamałeś, ale Boga!”.
###### **Dz 5,5**
 Gdy Ananiasz to usłyszał, padł martwy. Wszyscy zaś, którzy o tym się dowiedzieli, przerazili się.
###### **Dz 5,6**
 Młodzieńcy wstali, owinęli go w prześcieradło, wynieśli i pochowali.
###### **Dz 5,7**
 Po upływie trzech godzin, nie wiedząc, co się stało, przyszła jego żona.
###### **Dz 5,8**
 Zapytał ją Piotr: „Powiedz, czy właśnie za tyle sprzedaliście posiadłość?”. Ona odpowiedziała: „Tak jest, za tyle!”.
###### **Dz 5,9**
 Wtedy Piotr powiedział do niej: „Dlaczego zmówiliście się, aby wystawić na próbę Ducha Pańskiego? Oto są już przy wejściu ci, którzy pochowali twojego męża. Wyniosą także ciebie”.
###### **Dz 5,10**
 I natychmiast upadła przed nimi i skonała. Gdy weszli młodzieńcy, znaleźli ją martwą. Wynieśli ją więc i pochowali obok męża.
###### **Dz 5,11**
 A wielkie przerażenie ogarnęło cały Kościół oraz wszystkich, którzy o tym słyszeli.
###### **Dz 5,12**
 Apostołowie dokonywali wśród ludu wiele znaków i cudów. Zbierali się wszyscy razem w krużganku Salomona,
###### **Dz 5,13**
 a nikt z obcych nie miał odwagi przyłączyć się do nich. Lud natomiast ich wychwalał.
###### **Dz 5,14**
 Coraz większa liczba mężczyzn i kobiet przyłączała się do tych, którzy wierzyli w Pana.
###### **Dz 5,15**
 Na ulice wynoszono chorych, kładziono na łóżkach i noszach, aby na któregoś z nich padł choć cień przechodzącego Piotra.
###### **Dz 5,16**
 Do Jeruzalem schodziło się także wielu ludzi z sąsiednich miejscowości. Przynosili oni chorych i tych, których dręczyły duchy nieczyste. I wszyscy odzyskiwali zdrowie.
###### **Dz 5,17**
 Wówczas najwyższy kapłan i wszyscy jego zwolennicy ze stronnictwa saduceuszów, pełni zawiści,
###### **Dz 5,18**
 zatrzymali apostołów i wtrącili ich do publicznego więzienia.
###### **Dz 5,19**
 Ale w nocy anioł Pański otworzył bramy więzienia i wyprowadził ich stamtąd. Powiedział do nich:
###### **Dz 5,20**
 „Idźcie do świątyni i głoście ludowi wszystkie słowa życia”.
###### **Dz 5,21**
 Usłuchali go i o świcie weszli do świątyni i tam nauczali. A najwyższy kapłan oraz jego zwolennicy zwołali Wysoką Radę i wszystkich starszych Izraela. Posłali też do więzienia, aby przyprowadzono zatrzymanych.
###### **Dz 5,22**
 Lecz strażnicy nie znaleźli ich w więzieniu. Wrócili więc i oznajmili:
###### **Dz 5,23**
 „Zastaliśmy więzienie starannie zamknięte i strażników stojących przed drzwiami, ale w środku nie znaleźliśmy nikogo”.
###### **Dz 5,24**
 Kiedy dowódca straży świątynnej i wyżsi kapłani usłyszeli to, nie mogli zrozumieć, co się stało.
###### **Dz 5,25**
 Wtedy ktoś przyszedł i powiedział im: „Mężczyźni, których uwięziliście, znajdują się w świątyni i nauczają lud”.
###### **Dz 5,26**
 Wówczas poszedł dowódca wraz ze strażnikami i przyprowadził ich, ale bez użycia siły, gdyż bali się ludu, aby ich nie obrzucili kamieniami.
###### **Dz 5,27**
 Przyprowadzili ich przed Wysoką Radę i wtedy najwyższy kapłan powiedział do nich:
###### **Dz 5,28**
 „Surowo zabroniliśmy wam nauczać w to imię. Tymczasem wasze nauczanie rozlega się w całym Jeruzalem. Czy w ten sposób chcecie ściągnąć na nas krew tego Człowieka?”.
###### **Dz 5,29**
 Piotr i apostołowie odpowiedzieli: „Bardziej trzeba słuchać Boga niż ludzi.
###### **Dz 5,30**
 Bóg naszych przodków wskrzesił Jezusa, którego pojmaliście i zawiesiliście na drzewie.
###### **Dz 5,31**
 Bóg wywyższył Go swoją prawą ręką jako Wodza i Zbawiciela, aby dać Izraelowi nawrócenie i odpuszczenie grzechów.
###### **Dz 5,32**
 Dajemy temu świadectwo my właśnie i Duch Święty, którego Bóg udzielił wszystkim, którzy są Mu posłuszni”.
###### **Dz 5,33**
 Gdy to usłyszeli, wpadli w gniew i postanowili ich zabić.
###### **Dz 5,34**
 Lecz w czasie posiedzenia Wysokiej Rady wystąpił pewien faryzeusz imieniem Gamaliel. Był znawcą Prawa, a wszyscy ludzie go szanowali. Kazał, aby na chwilę wyprowadzić apostołów.
###### **Dz 5,35**
 Potem powiedział: „Izraelici, zastanówcie się dobrze nad tym, co zamierzacie uczynić z tymi ludźmi.
###### **Dz 5,36**
 Nie tak dawno wystąpił Teodas. Twierdził, że jest kimś niezwykłym. Przyłączyło się do niego około czterystu mężczyzn. Zabito go jednak, a wszyscy, którzy dali mu się przekonać, rozproszyli się i słuch o nich zaginął.
###### **Dz 5,37**
 Potem w czasie spisu ludności wystąpił Judasz Galilejczyk. On również pociągnął za sobą ludzi. Ale i on zginął, a wszyscy, którzy dali mu się przekonać, rozproszyli się.
###### **Dz 5,38**
 Dlatego radzę wam: Zostawcie tych ludzi w spokoju i uwolnijcie ich. Bo jeśli jest to sprawa i wymysł ludzki, pójdzie w zapomnienie.
###### **Dz 5,39**
 Jeśli jednak rzeczywiście pochodzi od Boga, nie zdołacie ich zniszczyć, a z czasem może się okazać, że walczyliście z Bogiem”. I usłuchali go.
###### **Dz 5,40**
 Przywołali apostołów i kazali ich wychłostać. Potem zabronili im przemawiać w imię Jezusa i uwolnili.
###### **Dz 5,41**
 Oni opuścili więc miejsce posiedzeń Wysokiej Rady i cieszyli się, że mogli cierpieć z powodu tego imienia.
###### **Dz 5,42**
 Codziennie nauczali w świątyni i po domach, głosząc Ewangelię o Chrystusie Jezusie.
# Dz 5 BP
###### **Dz 5,1**
 Człowiek, który nazywał się Ananiasz, wspólnie ze swoją żoną sprzedał posiadłość.
###### **Dz 5,2**
 Część pieniędzy za wiedzą żony zatrzymał dla siebie, a resztę przyniósł i złożył u stóp apostołów.
###### **Dz 5,3**
 Piotr zaś powiedział: "Ananiaszu, dlaczego szatan zawładnął tobą? Usiłowałeś oszukać Ducha Świętego, zatrzymując część zapłaty za posiadłość.
###### **Dz 5,4**
 Czyż nie twoją własnością była posiadłość i czyż nie twoje były pieniądze z jej sprzedaży? Czemu w sercu twoim zrodziła się myśl o tym czynie? Nie ludzi oszukałeś, lecz Boga".
###### **Dz 5,5**
 Po tych słowach Ananiasz upadł i skonał, wszystkich zaś słuchających ogarnął wielki strach.
###### **Dz 5,6**
 Wstali młodzi ludzie, przykryli go, wynieśli i pochowali.
###### **Dz 5,7**
 Po upływie około trzech godzin przyszła jego żona nie wiedząc, co się stało.
###### **Dz 5,8**
 Piotr odezwał się do niej: "Powiedz mi, czy za tyle sprzedaliście posiadłość? Ona odpowiedziała: "Tak, za tyle".
###### **Dz 5,9**
 Piotr zaś do niej: "Czemu zmówiliście się, by wystawić na próbę Ducha Pańskiego? Oto w drzwiach ci, którzy wynieśli i pochowali męża twego. Wyniosą też ciebie".
###### **Dz 5,10**
 Upadła nagle u jego stóp i skonała, a gdy weszli młodzieńcy, znaleźli ją martwą, wynieśli i pochowali obok jej męża.
###### **Dz 5,11**
 A cały Kościół i wszystkich, którzy tego słuchali, ogarnął wielki strach.
###### **Dz 5,12**
 Apostołowie czynili wiele zdumiewających znaków wśród ludu. Wszyscy razem przebywali w portyku Salomona.
###### **Dz 5,13**
 Nikt z obcych nie miał odwagi przyłączyć się do nich, a lud ich wychwalał.
###### **Dz 5,14**
 Liczba wierzących w Pana, mężczyzn i kobiet, coraz bardziej wzrastała.
###### **Dz 5,15**
 Wynoszono nawet na ulice chorych i kładziono na łożach i lektykach, aby choć cień przechodzącego Piotra padł na którego z nich.
###### **Dz 5,16**
 Przychodziło też wielu ludzi z miast położonych wokół Jerozolimy, przynosząc chorych i dręczonych przez duchy nieczyste, a wszyscy zostali uzdrowieni.
###### **Dz 5,17**
 Arcykapłan, a razem z nim wszyscy należący do stronnictwa saduceuszów zapałali gniewem,
###### **Dz 5,18**
 zatrzymali apostołów i wtrącili ich do więzienia.
###### **Dz 5,19**
 A w nocy anioł Pański otworzył bramy więzienia i wyprowadzając ich powiedział:
###### **Dz 5,20**
 "Idźcie do świątyni i głoście ludowi całą naukę o tym życiu".
###### **Dz 5,21**
 Kiedy to usłyszeli, weszli o świcie do świątyni i nauczali. Tymczasem arcykapłan i jego otoczenie zwołali sanhedryn i radę starszych Izraela, nakazując przyprowadzić ich z więzienia.
###### **Dz 5,22**
 Słudzy poszli, ale nie znaleźli ich w więzieniu. Wrócili wtedy i oznajmili:
###### **Dz 5,23**
 "Więzienie zastaliśmy zamknięte i dobrze zabezpieczone, straże stały przed bramami, a gdyśmy je otworzyli, nie znaleźliśmy nikogo".
###### **Dz 5,24**
 Gdy się o tym dowiedzieli dowódca straży świątynnej i arcykapłani, nie mogli pojąć, jak to się stało.
###### **Dz 5,25**
 Wtedy przyszedł ktoś i oznajmił: "Ludzie, których wtrąciliście do więzienia, znajdują się w świątyni i nauczają lud".
###### **Dz 5,26**
 Wówczas poszedł dowódca straży ze sługami i przyprowadził ich, nie stosując przemocy, obawiali się bowiem, by lud ich nie ukamienował.
###### **Dz 5,27**
 Przyprowadzili ich i stawili przed sanhedrynem. Zabierając głos arcykapłan
###### **Dz 5,28**
 powiedział: "Czyż nie zabroniliśmy wam surowo nauczania w to imię? Wy jednak dalej głosicie waszą naukę w całej Jerozolimie i chcecie ściągnąć na nas krew tego człowieka".
###### **Dz 5,29**
 Piotr i apostołowie odpowiedzieli na to: "Bardziej trzeba słuchać Boga niż ludzi.
###### **Dz 5,30**
 Bóg ojców naszych wskrzesił Jezusa, którego straciliście przez ukrzyżowanie.
###### **Dz 5,31**
 Bóg wywyższył Go jako Władcę i Zbawiciela po swojej prawicy, dając Izraelowi możność nawrócenia i odpuszczenia grzechów.
###### **Dz 5,32**
 My właśnie jesteśmy tego świadkami, jak i Duch Święty, którego Pan dał tym, którzy Mu są posłuszni".
###### **Dz 5,33**
 Kiedy oni to usłyszeli, rozgniewali się bardzo i chcieli ich zabić.
###### **Dz 5,34**
 Wtedy [na posiedzeniu] sanhedrynu zabrał głos pewien faryzeusz imieniem Gamaliel, nauczyciel Prawa szanowany przez cały lud; polecił na chwilę wyprowadzić apostołów,
###### **Dz 5,35**
 a do nich powiedział: "Izraelici, zastanówicie się, zanim postanowicie uczynić coś z tymi ludźmi.
###### **Dz 5,36**
 Niedawno temu wystąpił Teudas, podając się za kogoś niezwykłego, i przyłączyło się do niego około czterystu ludzi. Został zabity i wszyscy jego zwolennicy rozproszyli się, i nikt z nich nie został.
###### **Dz 5,37**
 Potem w czasie spisu pojawił się Judasz z Galilei i także pociągnął za sobą lud, a kiedy zginął, wszyscy jego zwolennicy również się rozproszyli.
###### **Dz 5,38**
 Wobec tego mówię wam, zostawcie tych ludzi i zwolnijcie ich.
###### **Dz 5,39**
 Jeżeli to jest wymysł czy dzieło czysto ludzkie, rozpadnie się, a jeżeli pochodzi od Boga, nie zdołacie go zniszczyć, a może się okazać, że walczycie z Bogiem".
###### **Dz 5,40**
 Zgodzili się z nim. Wezwali apostołów, ukarali chłostą nakazując, aby nie przemawiali w imię Jezusa, i wypuścili ich.
###### **Dz 5,41**
 Z radością wychodzili z [posiedzenia] sanhedrynu, że godni byli znosić zniewagę dla imienia Pana.
###### **Dz 5,42**
 Nie przestawali codziennie nauczać w świątyni i w domach, głosząc dobrą nowinę o Jezusie Chrystusie.
# Dz 5 BR
###### **Dz 5,32**
 Świadczymy o tym właśnie my oraz Duch Święty, którego Bóg udziela tym, co są Mu posłuszni.
###### **Dz 5,33**
 Gdy to usłyszeli, unieśli się wielkim gniewem i chcieli ich pozabijać.
###### **Dz 5,26**
 Poszedł tedy przywódca straży świątynnej ze sługami i przyprowadził ich, nie używając przy tym jednak żadnej przemocy w obawie, aby lud ich samych nie ukamienował.
###### **Dz 5,27**
 Kiedy już znaleźli się przed Sanhedrynem, powiedział do nich arcykapłan:
###### **Dz 5,28**
 Nakazaliśmy wam przecież wyraźnie, żebyście przestali głosić jakiekolwiek nauki, odwołując się do tego imienia. Tymczasem od waszego nauczania głośno już w całej Jerozolimie. Najwyraźniej chcecie ściągnąć na nas krew tego Człowieka.
###### **Dz 5,29**
 Na to odpowiedział Piotr, a z nim także inni apostołowie: Trzeba przecież bardziej słuchać Boga niż ludzi.
###### **Dz 5,30**
 A to właśnie Bóg ojców naszych zmartwychwskrzesił Jezusa, którego wyście zgładzili przybiwszy do krzyża.
###### **Dz 5,31**
 Bóg też posadził Go po swojej prawicy jako Władcę i Zbawiciela, aby umożliwić Izraelowi nawrócenie i osiągnięcie odpuszczenia grzechów.
###### **Dz 5,1**
 Lecz pewien człowiek imieniem Ananiasz - jego żona nazywała się Safira - sprzedał swoją posiadłość
###### **Dz 5,2**
 i za wiedzą żony część otrzymanych pieniędzy zachował dla siebie, a tylko część przyniósł i złożył u stóp apostołów.
###### **Dz 5,3**
 Ale Piotr rzekł do niego: Czemu dopuściłeś, żeby szatan zawładnął twoim sercem i nakłonił cię, żebyś skłamał Duchowi Świętemu, zachowując dla siebie część pieniędzy otrzymanych ze sprzedaży ziemi?
###### **Dz 5,4**
 Przecież była twoją własnością, a gdy ją już sprzedałeś, czyż nie mogłeś dowolnie rozporządzać tym, co za nią otrzymałeś? Jak mogłeś zdecydować się na tak niecny czyn? Przecież nie ludzi okłamałeś, tylko Boga!
###### **Dz 5,5**
 Usłyszawszy te słowa Ananiasz padł martwy. A wszystkich, którzy przypadkiem również słuchali tych słów, ogarnęło przerażenie.
###### **Dz 5,6**
 Młodsi spośród zebranych wstali, owinęli go [w prześcieradło], wynieśli i pochowali.
###### **Dz 5,7**
 Mniej więcej trzy godziny potem weszła również jego żona, nie wiedząc nic o tym, co się stało.
###### **Dz 5,8**
 A Piotr zapytał ją: Powiedz mi, czy za tyle to a tyle sprzedaliście waszą ziemię? A ona odpowiedziała: Tak za tyle!
###### **Dz 5,9**
 Na to Piotr do niej: Czemuż to nawet umówiliście się między sobą, aby prowokować do gniewu Ducha Pańskiego? Oto jeszcze stoją u progu ci, co pochowali twego męża. Zaraz wyniosą i ciebie.
###### **Dz 5,10**
 A ona upadła natychmiast u jego stóp i skonała. Gdy wrócili owi młodzi ludzie, zastali ją już martwą. Wynieśli ją więc i pochowali obok jej męża.
###### **Dz 5,11**
 Przerażenie wielkie ogarnęło wtedy cały Kościół i wszystkich, którzy o tym słyszeli.
###### **Dz 5,12**
 Apostołowie zaś dokonywali wśród ludu wiele znaków i cudów. A wierni trzymali się razem w krużganku Salomona.
###### **Dz 5,13**
 Spośród obcych zaś nikt nie śmiał dołączyć się do nich, a u ludzi cieszyli się wielkim poważaniem.
###### **Dz 5,14**
 Z dniem każdym powiększała się liczba mężczyzn i kobiet przyjmujących wiarę w Pana.
###### **Dz 5,15**
 Na ulice wynoszono chorych i kładziono ich na łożach i noszach, licząc na to, że może choć cień przechodzącego Piotra padnie na któregoś z nich.
###### **Dz 5,16**
 Wiele ludzi przychodziło również z miast sąsiednich do Jerozolimy, sprowadzając ze sobą chorych i dręczonych przez duchy nieczyste. I wszyscy odzyskiwali zdrowie.
###### **Dz 5,17**
 Patrząc na to arcykapłan i jego zwolennicy spośród saduceuszów zapłonęli zazdrością.
###### **Dz 5,18**
 Pojmali też wkrótce apostołów i wtrącili ich do publicznego więzienia.
###### **Dz 5,19**
 Lecz nocą anioł Pański otworzył bramy więzienia i wypuściwszy ich na wolność powiedział:
###### **Dz 5,20**
 Idźcie do świątyni i głoście ludowi naukę o nowym życiu!
###### **Dz 5,21**
 Usłyszawszy tedy ten nakaz, o świcie już przyszli do świątyni i poczęli nauczać. Wtedy arcykapłan i jego stronnicy zwołali Sanhedryn i wszystkich starszych Izraela, a potem kazali ich sprowadzić z więzienia.
###### **Dz 5,22**
 Lecz kiedy słudzy przyszli, nie znaleźli ich już w więzieniu. Powróciwszy więc powiedzieli:
###### **Dz 5,23**
 Zastaliśmy więzienie bardzo starannie zamknięte i strażników czuwających u wejścia. Kiedyśmy jednak weszli do wnętrza, nie znaleźliśmy tam już nikogo.
###### **Dz 5,24**
 Gdy przywódca straży świątynnej i arcykapłani usłyszeli te słowa, nie mogli pojąć, co się z nimi stało.
###### **Dz 5,25**
 Lecz oto przybiegł nagle ktoś i powiedział: Ludzie, których wtrąciliście do więzienia, znajdują się w świątyni i spokojnie nauczają.
###### **Dz 5,34**
 Lecz wtedy pewien faryzeusz, imieniem Gamaliel, uczony w Prawie, człowiek cieszący się wielkim poważaniem u ludu, kazał wyprowadzić na chwilę apostołów i zwrócił się w ten sposób do całej Rady:
###### **Dz 5,35**
 Izraelici - powiedział - zastanówcie się dobrze, co zamierzacie zrobić z tymi ludźmi.
###### **Dz 5,36**
 Pojawił się niedawno pewien Teodas, twierdząc, że jest kimś niezwykłym. Zdołał sobie zwerbować około czterystu ludzi, lecz został zabity, a wszyscy jego zwolennicy rozpierzchli się i tak wszelki ślad po nim zaginął.
###### **Dz 5,37**
 Potem, podczas spisu ludności, pojawił się niejaki Judasz Galilejczyk. Pociągnął on również za sobą wielu, ale w końcu zginął sam, a wszyscy jego zwolennicy zostali rozproszeni.
###### **Dz 5,38**
 Radziłbym wam więc i w tym przypadku odstąpić od tych ludzi i wypuścić ich na wolność. Jeżeli się okaże, że mamy tu do czynienia z zamysłem i sprawą czysto ludzką, to wszystko samo się rozpadnie.
###### **Dz 5,39**
 A jeżeli rzeczywiście Boża to sprawa, to nie zdołacie usunąć tych ludzi, przeciwnie, okaże się nawet po pewnym czasie, że walczycie z samym Bogiem. I usłuchano go.
###### **Dz 5,40**
 Przyprowadzili tedy apostołów i kazali ich ubiczować, a potem, zabroniwszy im przemawiać w imię Jezusa, wypuścili ich na wolność.
###### **Dz 5,41**
 A oni, opuszczając Sanhedryn, cieszyli się, że byli godni cierpieć dla imienia [Jezusa].
###### **Dz 5,42**
 I nie przestawali codziennie nauczać w świątyni oraz po domach, głosząc Dobrą Nowinę o Jezusie
# Dz 5 WUJ
###### **Dz 5,1**
 A niektóry mąż imieniem Ananiasz, z Saphirą żoną swą przedał rolą:
###### **Dz 5,2**
 I ujął z pieniędzy za rolą, z wiadomością żony swej: a przyniósszy część niektórą, położył przed nogi Apostolskie.
###### **Dz 5,3**
 I rzekł Piotr: Ananiaszu, przeczże szatan skusił serce twe, iżbyś skłamał Duchowi świętemu, i ujął z zapłaty rolej?
###### **Dz 5,4**
 Azaż zostawając nie tobie zostawało, a przędawszy nie w mocy twej było? Czemuś tę rzecz do serca twego przypuścił? Nie skłamałeś ludziom, ale Bogu.
###### **Dz 5,5**
 A słysząc słowa te Ananiasz, padł, i umarł. I przyszedł strach wielki na wszystkie, którzy tego słuchali.
###### **Dz 5,6**
 A wstawszy młodzieńcy, znieśli go na stronę, a wyniósszy pogrzebli.
###### **Dz 5,7**
 I stało się, jakoby we trzy godziny, żona też jego, niewiedząc co się było stało, weszła.
###### **Dz 5,8**
 I rzekł jej Piotr: Powiedz mi niewiasto, jeśliście za to przedali rolą? A ona rzekła: Iście, za to,
###### **Dz 5,9**
 A Piotr do niej: Cóż to, żeście się zmówili, abyście kusili Ducha Pańskiego? Oto nogi tych, którzy pogrzebli męża twego, u drzwi, i wyniosą cię.
###### **Dz 5,10**
 Natychmiast padła u nóg jego, i skonała. A wszedszy młodzieńcy naleźli ją umarłą: i wynieśli, i pogrzebli podle męża jej.
###### **Dz 5,11**
 I padł wielki strach na wszystek kościół, i na wszystkie, którzy to słyszeli.
###### **Dz 5,12**
 A przez ręce Apostolskie działo się wiele znaków i cudów między ludem. A byli wszyscy jednomyślnie w krudżganku Salomonowym.
###### **Dz 5,13**
 A z innych żaden nie śmiał się do nich przyłączyć: ale je lud wysławiał.
###### **Dz 5,14**
 I więcej przybywało mnóstwa wierzących w Panu, mężów i niewiast:
###### **Dz 5,15**
 Tak, iż na ulice wynaszali niemocne, i kładli na łożach i łóżkach: aby, gdy Piotr chodził, przynajmniej cień jego zaćmił którego z nich: a byli uzdrowieni od niemocy swoich.
###### **Dz 5,16**
 Zbiegało się też mnóstwo blizkich miast do Jeruzalem, nosząc niemocne i nagabane od duchów nieczystych: którzy wszyscy byli uzdrowieni.
###### **Dz 5,17**
 A powstawszy Nawyższy kapłan i wszyscy, którzy z nim byli (to jest sekta Sadduceuszów ), napełnieni są zazdrością.
###### **Dz 5,18**
 I pojmali Apostoły, i wsadzili je do więzienia pospolitego.
###### **Dz 5,19**
 Lecz Anioł Pański w nocy otworzywszy drzwi ciemnice, a wywiódszy je rzekł:
###### **Dz 5,20**
 Idźcież: a stanąwszy powiadajcie ludowi w kościele wszystkie słowa żywota tego.
###### **Dz 5,21**
 Którzy usłyszawszy, weszli na świtaniu do kościoła, i uczyli. A przyszedszy Nawyższy kapłan i którzy z nim byli, zwołali Radę, i wszystkie starsze synów Izraelskich: i posłali do ciemnice, aby je przywiedziono.
###### **Dz 5,22**
 A gdy przyszli słudzy, i otworzywszy ciemnicę, nie naleźli ich: wróciwszy się oznajmili,
###### **Dz 5,23**
 Mówiąc: ciemnicęśmy naleźli zamknioną ze wszystką pilnością, i stróże stojące przede drzwiami: lecz otworzywszy żadnegośmy w niej nie naleźli.
###### **Dz 5,24**
 A gdy te słowa usłyszeli, urząd kościelny i przedniejszy kapłani, wątpili o nich coby było.
###### **Dz 5,25**
 A przyszedszy ktoś powiedział im: Iż oto mężowie, któreście wsadzili do więzienia, są w kościele stojąc i ucząc lud.
###### **Dz 5,26**
 Tedy poszedł urząd z służebnikami i przywiódł je bez gwałtu: bo się ludu bali, by ich nie ukamionował.
###### **Dz 5,27**
 A przywiódszy je postawili przed Radą. I pytał ich Nawyższy kapłan,
###### **Dz 5,28**
 Mówiąc: Rozkazując rozkazaliśmy, abyście w imię to nie uczyli: a oto napełniliście Jeruzalem nauką waszą, i chcecie na nas przywieść krew człowieka tego.
###### **Dz 5,29**
 A odpowiadając Piotr i Apostołowie, rzekli: Więcej trzeba słuchać Boga a niż ludzi.
###### **Dz 5,30**
 Bóg ojców naszych wzbudził Jezusa, któregoście wy zabili, zawiesiwszy na drzewie.
###### **Dz 5,31**
 Tego Książęcia i zbawiciela wywyższył Bóg prawicą swoją, aby dał pokutę Izraelowi i odpuszczenie grzechów.
###### **Dz 5,32**
 A myśmy są świadkowie tych słów: i Duch ś., którego dał Bóg wszystkim, którzy mu są posłuszni.
###### **Dz 5,33**
 To usłyszawszy, krajali się, i myślili je zabić.
###### **Dz 5,34**
 Lecz wstawszy w radzie niektóry Faryzeusz imieniem Gamaliel, Doktor zakonny, w poważeniu u wszego ludu, rozkazał na mały czas ludziom wystąpić.
###### **Dz 5,35**
 I rzekł do nich: Mężowie Izraelscy, miejcie się na baczeniu z strony tych ludzi, cobyście mieli czynić.
###### **Dz 5,36**
 Abowiem przed temi dni powstał Theodas, powiadając się być czym, do którego przystała liczba mężów około czterech set: który zabit jest: a wszyscy, którzy mu wierzyli, rozproszeni są, i wniwecz się obrócili.
###### **Dz 5,37**
 Potem powstał Judas Galilejczyk we dni popisu, i uwiódł lud za sobą: i on zginął, i wszyscy, i co ich kolwiek z nim przestawało, są rozproszeni.
###### **Dz 5,38**
 Przetoż i teraz powiadam wam, odstąpcie od tych ludzi, i zaniechajcie ich: abowiem jeślić jest z ludzi ta rada abo sprawa, rozchwieje się:
###### **Dz 5,39**
 Lecz jeśli jest z Boga, nie będziecie mogli ich zepsować: byście snać nie naleźli się z Bogiem walczyć. I usłuchali go.
###### **Dz 5,40**
 I wezwawszy Apostołów, ubiwszy je, zakazali, aby zgoła nie mówili w imię Jezusowe: i puścili je.
###### **Dz 5,41**
 A oni szli od obliczności rady, radując się, iż się stali godnemi dla imienia Jezusowego zelżywość cierpieć.
###### **Dz 5,42**
 I nie przestawali każdy dzień w kościele i po domiech nauczać i opowiadać Jezusa Chrystusa.
# Dz 5 STERN
###### **Dz 5,1**
 Ale był człowiek imieniem Chanania, który wraz ze swą żoną Szappirą sprzedał jakąś posiadłość
###### **Dz 5,2**
 i za wiedzą żony zatrzymał sobie część dochodu, choć część przyniósł wysłannikom.
###### **Dz 5,3**
 Wtedy Kefa powiedział: "Czemu Przeciwnik tak opanował twoje serce, żeś skłamał Ruach Ha-Kodesz i zatrzymał część pieniędzy, jakie dostałeś za ziemię?
###### **Dz 5,4**
 Zanim go sprzedałeś, majątek był twój, a gdyś go sprzedał, pieniądze były do twego dowolnego użytku. Co więc cię skłoniło, żeby zrobić coś podobnego? Skłamałeś nie ludziom, ale Bogu!".
###### **Dz 5,5**
 Słysząc te słowa, Chanania padł martwy; a każdy, kto o tym usłyszał, przeraził się.
###### **Dz 5,6**
 Wstali młodzi ludzie, owinęli jego ciało całunem, wynieśli i pochowali.
###### **Dz 5,7**
 Jakieś trzy godziny później weszła jego żona, nieświadoma tego, co zaszło.
###### **Dz 5,8**
 Kefa postawił jej pytanie: "Powiedz mi, czy to prawda, że sprzedaliście ziemię za tyle i tyle?". "Tak - odrzekła - tyle nam za nią zapłacono".
###### **Dz 5,9**
 Lecz Kefa odparł jej na to: "Czemu więc uknuliście, żeby wystawić na próbę Ducha Pańskiego? Posłuchaj! Ludzie, którzy pochowali twojego męża, są pod drzwiami. Ciebie też wyniosą!".
###### **Dz 5,10**
 W jednej chwili upadła u jego stóp i umarła. Weszli młodzi ludzie, znaleźli ją tam nieżywą, wynieśli i pogrzebali obok męża.
###### **Dz 5,11**
 Wskutek tego wielki strach padł na całą Wspólnotę Mesjaniczną i na wszystkich, którzy o tym słyszeli.
###### **Dz 5,12**
 Tymczasem za pośrednictwem wysłanników nadal działo się wśród ludu wiele znaków i cudów. Jednej myśli i jednego zamiaru, wierzący zbierali się w Kolumnadzie Szlomo;
###### **Dz 5,13**
 a nikt inny nie ośmielał się do nich dołączyć. Mimo to lud nadal miał ich w wielkim poważaniu
###### **Dz 5,14**
 i tłumy nowych wierzących przychodziły do Pana, mężczyźni i kobiety.
###### **Dz 5,15**
 Doszło już do tego, że wynoszono chorych na ulice i kładziono na matach i noszach, aby padł na nich choć cień przechodzącego Kefy.
###### **Dz 5,16**
 Zbierały się też tłumy z okolicznych miast wokół Jeruszalaim, przynosząc chorych i dręczonych przez duchy nieczyste, a każdy z nich zostawał uzdrowiony.
###### **Dz 5,17**
 Lecz kohena hagadola i jego otoczenie, które należało do stronnictwa c'dukim, trawiła zazdrość.
###### **Dz 5,18**
 Pochwycili wysłanników i wtrącili ich do publicznego więzienia.
###### **Dz 5,19**
 Ale w nocy anioł Adonai otworzył drzwi więzienia, wyprowadził ich i rzekł:
###### **Dz 5,20**
 "Idźcie, stańcie na dziedzińcu świątynnym i dalej mówcie ludziom o tym nowym życiu!".
###### **Dz 5,21**
 Usłyszawszy to, weszli około brzasku na teren Świątyni i zaczęli nauczać. A kohen hagadol i jego zwolennicy przyszli i zwołali posiedzenie Sanhedrinu (czyli całego zgromadzenia starszych Israela), i posłali do więzienia, aby ich przyprowadzić.
###### **Dz 5,22**
 Ale słudzy, którzy poszli, nie znaleźli ich w więzieniu. Wrócili więc i donieśli:
###### **Dz 5,23**
 "Drzwi więzienia zastaliśmy zabezpieczone i strażników przed drzwiami, ale kiedyśmy je otwarli, nikogo w środku nie znaleźliśmy!"
###### **Dz 5,24**
 Gdy dowódca straży świątynnej i główni kohanim to usłyszeli, stropili się, nie wiedząc, co się teraz stanie.
###### **Dz 5,25**
 Wtedy przyszedł ktoś i doniósł: "Słuchajcie! Ci ludzie, których nakazaliście zamknąć w więzieniu, stoją na dziedzińcu świątynnym i nauczają lud!"
###### **Dz 5,26**
 Dowódca i jego ludzie poszli i przywiedli ich, ale nie siłą, bo bali się ukamienowania przez lud.
###### **Dz 5,27**
 Odeskortowali ich do Sanhedrinu, a tam kohen hagadol zapytał ich ostro:
###### **Dz 5,28**
 "Przykazaliśmy wam surowo nie nauczać w tym imieniu! I proszę! W całym Jeruszalaim pełno waszej nauki, co więcej, postanowiliście sobie nas obarczyć winą za śmierć tego człowieka!".
###### **Dz 5,29**
 Kefa i pozostali wysłannicy odrzekli: "Musimy słuchać Boga, nie ludzi.
###### **Dz 5,30**
 Bóg naszych ojców wskrzesił Jeszuę, ale wasi ludzie zabili Go, wieszając Go na palu.
###### **Dz 5,31**
 Tego człowieka Bóg wywyższył po swojej prawicy jako Władcę i Zbawiciela, aby Israel mógł czynić t'szuwę i dostąpić odpuszczenia grzechów.
###### **Dz 5,32**
 Jesteśmy świadkami tych rzeczy, tak samo jak Ruach Ha-Kodesz, którego Bóg dał tym, którzy są Mu posłuszni".
###### **Dz 5,33**
 Słysząc to, członkowie Sanhedrinu wpadli w szał i chcieli zabić wysłanników.
###### **Dz 5,34**
 Ale powstał jeden z członków Sanhedrinu, parusz imieniem Gamliel, nauczyciel Tory, wielce poważany przez cały lud. Polecił ich na chwilę wyprowadzić,
###### **Dz 5,35**
 po czym zwrócił się do sądu: "Mężowie Israela, uważajcie, jak postępujecie z tymi ludźmi.
###### **Dz 5,36**
 Jakiś czas temu wybuchł bunt pod przywództwem Tody, który podawał się za kogoś szczególnego, i zebrała się wokół niego pewna liczba ludzi, ze czterystu. Ale gdy go stracono, wszyscy jego stronnicy rozpierzchli się i nic z tego nie wyszło.
###### **Dz 5,37**
 Potem J'huda ha-G'lili stanął na czele kolejnego powstania - było to w czasie spisu na podatek rzymski - i niektórych za sobą pociągnął. Ale zabito go, a wszyscy jego zwolennicy poszli z rozsypkę.
###### **Dz 5,38**
 Toteż w obecnym przypadku doradzam wam, aby nie stawać tym ludziom na drodze, ale zostawić ich w spokoju. Bo jeśli ta idea i ten ruch ma źródło ludzkie, to upadnie.
###### **Dz 5,39**
 Ale jeśli pochodzi od Boga, to nie będziecie w stanie go powstrzymać, a może się jeszcze okazać, że wy sami walczycie z Bogiem!". Posłuchali jego rady.
###### **Dz 5,40**
 Po wezwaniu wysłanników i wychłostaniu ich przykazali im nie przemawiać w imieniu Jeszui i puścili ich wolno.
###### **Dz 5,41**
 Wysłannicy wyszli z Sanhedrinu rozradowani, że zostali uznani za godnych znoszenia upokorzeń ze względu na Niego.
###### **Dz 5,42**
 I ani na jeden dzień - na dziedzińcu świątynnym i po domach - nie przestali nauczać i głosić Dobrej Nowiny, że Jeszua jest Mesjaszem.
# Dz 5 TRO
###### **Dz 5,31**
 **τουτον** *touton* Tego [[G5126]] WTD-ASM **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **αρχηγον** *archēgon* Początek i Wodza – Sprawcę [[G747]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **σωτηρα** *sōtēra* Zbawiciela – Wybawcę [[G4990]] [[N-ASM]] **υψωσεν** *hypsōsen* wywyższył [[G5312]] [[V-AAI-3S]] **τη** *tē* [[G3588]] WTT-DSF **δεξια** *deksia* prawicą [[G1188]] WTA-DSF **αυτου** *autou* Jego [[G846]] [[P-GSM]] **δουναι** *dounai* dać [[G1325]] [[V-2AAN]] **μετανοιαν** *metanoian* nawrócenie – zmianę myślenia [[G3341]] WTN-ASF **τω** *tō* [[G3588]] WTT-DSM **ισραηλ** *israēl* Izraelowi – [ten, który walczył z Bogiem] [[G2474]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **αφεσιν** *afesin* uwolnienie – wyzwolenie [[G859]] WTN-ASF **αμαρτιων** *hamartiōn* (od) grzechów [[G266]] WTN-GPF
###### **Dz 5,32**
 **και** *kai* I [[G2532]] [[CONJ]] **ημεις** *hēmeis* my [[G2249]] WTP-1NP **εσμεν** *esmen* jesteśmy [[G2070]] WTV-PXI-1P **αυτου** *autou* Jego [[G846]] [[P-GSM]] **μαρτυρες** *martyres* świadkowie [[G3144]] WTN-NPM **των** *tōn* [[G3588]] WTT-GPN **ρηματων** *rēmatōn* wypowiedzi [[G4487]] WTN-GPN **τουτων** *toutōn* tych [[G5130]] WTD-GPN **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-ASN **πνευμα** *pneuma* Ducha [[G4151]] WTN-ASN **δε** *de* zaś [[G1161]] [[CONJ]] **το** *to* [[G3588]] WTT-ASN **αγιον** *hagion* Świętego [[G40]] WTA-ASN **ο** *ho* którego [[G3739]] WTR-ASN **εδωκεν** *edōken* dał [[G1325]] [[V-AAI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **τοις** *tois* [[G3588]] WTT-DPM **πειθαρχουσιν** *peitharchousin* którzy są posłuszni – słuchającymi władzy [[G3980]] WTV-PAP-DPM **αυτω** *autō* Mu [[G846]] WTP-DSM
###### **Dz 5,33**
 **οι** *hoi* (Ci) [[G3588]] WTT-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **ακουσαντες** *akousantes* usłyszawszy [[G191]] WTV-AAP-NPM **διεπριοντο** *dieprionto* byli rozpiłowani – byli przerzynani piłą [[G1282]] WTV-IPI-3P **και** *kai* i [[G2532]] [[CONJ]] **εβουλευοντο** *ebouleuonto* zaplanowali – postanowili [[G1011]] WTV-INI-3P **ανελειν** *anelein* zabić – znieść [[G337]] [[V-2AAN]] **αυτους** *autous* ich [[G846]] [[P-APM]]
###### **Dz 5,34**
 **αναστας** *anastas* Wstawszy – Podniósłszy się [[G450]] WTV-2AAP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **τις** *tis* ktoś – pewien [[G5100]] WTX-NSM **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **συνεδριω** *synedriō* sanhedrynie – radzie [[G4892]] WTN-DSN **φαρισαιος** *farisaios* faryzeusz – [oddzielony] [[G5330]] [[N-NSM]] **ονοματι** *onomati* imieniem [[G3686]] WTN-DSN **γαμαλιηλ** *gamaliēl* Gamaliel – [zapłata Boga] [[G1059]] [[N-PRI]] **νομοδιδασκαλος** *nomodidaskalos* nauczyciel Prawa [[G3547]] [[N-NSM]] **τιμιος** *timios* szacowny – poważany [[G5093]] [[A-NSM]] **παντι** *panti* każdemu [[G3956]] WTA-DSM **τω** *tō* [[G3588]] WTT-DSM **λαω** *laō* ludowi [[G2992]] WTN-DSM **εκελευσεν** *ekeleusen* rozkazał [[G2753]] [[V-AAI-3S]] **εξω** *eksō* na zewnątrz – poza [[G1854]] [[ADV]] **βραχυ** *brachy* (na) krótko [[G1024]] WTA-ASN **τι** *ti* ktoś – jakiś [[G5100]] WTX-ASN **τους** *tous* (z) [[G3588]] WTT-APM **αποστολους** *apostolous* wysłanników [[G652]] [[N-APM]] **ποιησαι** *poiēsai* uczynić [[G4160]] [[V-AAN]]
###### **Dz 5,35**
 **ειπεν** *eipen* Powiedział [[G2036]] WTV-2AAI-3S **τε** *te* zarówno – także [[G5037]] WTPRT **προς** *pros* do [[G4314]] [[PREP]] **αυτους** *autous* nich [[G846]] [[P-APM]] **ανδρες** *andres* mężowie [[G435]] WTN-VPM **ισραηλιται** *israēlitai* Izraelici – [ten, który walczył z Bogiem] [[G2475]] WTN-VPM **προσεχετε** *prosechete* zważcie – zwróćcie uwagę [[G4337]] WTV-PAM-2P **εαυτοις** *heautois* wy sami [[G1438]] WTF-3DPM **επι** *epi* nad [[G1909]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPM **ανθρωποις** *anthrōpois* ludźmi [[G444]] WTN-DPM **τουτοις** *toutois* tymi [[G5125]] WTD-DPM **τι** *ti* co [[G5101]] WTI-ASN **μελλετε** *mellete* macie [[G3195]] WTV-PAI-2P **πρασσειν** *prassein* robić – czynić [[G4238]] WTV-PAN
###### **Dz 5,1**
 **ανηρ** *anēr* Mąż [[G435]] [[N-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **τις** *tis* pewien – jakiś [[G5100]] WTX-NSM **ανανιας** *hananias* Ananiasz – [JH przyjął] [[G367]] [[N-NSM]] **ονοματι** *onomati* imieniem [[G3686]] WTN-DSN **συν** *syn* z [[G4862]] [[PREP]] **σαπφειρη** *sapfeirē* Safirą – [szafir] [[G4551]] [[N-DSF]] **τη** *tē* [[G3588]] WTT-DSF **γυναικι** *gynaiki* żoną – kobietą [[G1135]] [[N-DSF]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **επωλησεν** *epōlēsen* sprzedał [[G4453]] [[V-AAI-3S]] **κτημα** *ktēma* posiadłość [[G2933]] WTN-ASN
###### **Dz 5,2**
 **και** *kai* i [[G2532]] [[CONJ]] **ενοσφισατο** *enosfisato* oddzielił sobie – wykradł [[G3557]] WTV-AMI-3S **απο** *apo* z [[G575]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **τιμης** *timēs* oszacowania – wartości [[G5092]] [[N-GSF]] **συνειδυιας** *syneidyias* będąca skonsultowaną – będąca wtajemniczoną [[G4894]] WTV-RAP-GSF **και** *kai* i [[G2532]] [[CONJ]] **της** *tēs* [[G3588]] [[T-GSF]] **γυναικος** *gynaikos* żona – kobieta [[G1135]] [[N-GSF]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **ενεγκας** *enegkas* przyniósłszy [[G5342]] WTV-AAP-NSM **μερος** *meros* część [[G3313]] WTN-ASN **τι** *ti* jakąś [[G5100]] WTX-ASN **παρα** *para* przy [[G3844]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **ποδας** *podas* stopach [[G4228]] [[N-APM]] **των** *tōn* [[G3588]] WTT-GPM **αποστολων** *apostolōn* wysłanników [[G652]] WTN-GPM **εθηκεν** *ethēken* położył [[G5087]] [[V-AAI-3S]]
###### **Dz 5,3**
 **ειπεν** *eipen* Powiedział [[G2036]] WTV-2AAI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **πετρος** *petros* Piotr – [kamyk] [[G4074]] [[N-NSM]] **ανανια** *hanania* Ananiaszu – [JH przyjął] [[G367]] WTN-VSM **δια** *dia* przez [[G1223]] [[PREP]] **τι** *ti* co [[G5101]] WTI-ASN **επληρωσεν** *eplērōsen* wypełnił [[G4137]] [[V-AAI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **σατανας** *satanas* szatan – [przeciwnik] [[G4567]] [[N-NSM]] **την** *tēn* [[G3588]] WTT-ASF **καρδιαν** *kardian* serce [[G2588]] WTN-ASF **σου** *sou* twoje [[G4675]] WTP-2GS **ψευσασθαι** *pseusasthai* (by) okłamać [[G5574]] WTV-ADN **σε** *se* ty [[G4571]] WTP-2AS **το** *to* [[G3588]] WTT-ASN **πνευμα** *pneuma* Ducha [[G4151]] WTN-ASN **το** *to* [[G3588]] WTT-ASN **αγιον** *hagion* Świętego [[G40]] WTA-ASN **και** *kai* i [[G2532]] [[CONJ]] **νοσφισασθαι** *nosfisasthai* oddzielić sobie – wykraść [[G3557]] WTV-AMN **απο** *apo* z [[G575]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **τιμης** *timēs* oszacowania – wartości [[G5092]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSN **χωριου** *chōriou* terenu – pola [[G5564]] [[N-GSN]]
###### **Dz 5,4**
 **ουχι** *ouchi* Czyż nie [[G3780]] WTPRT-I **μενον** *menon* pozostając – trwając [[G3306]] WTV-PAP-NSN **σοι** *soi* tobie [[G4671]] WTP-2DS **εμενεν** *emenen* pozostawał – trwał [[G3306]] WTV-IAI-3S **και** *kai* i [[G2532]] [[CONJ]] **πραθεν** *prathen* zostawszy sprzedanym [[G4097]] WTV-APP-NSN **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **ση** *sē* twojej [[G4674]] WTS-2DSF **εξουσια** *eksousia* władzy [[G1849]] [[N-DSF]] **υπηρχεν** *hypērchen* był [[G5225]] WTV-IAI-3S **τι** *ti* dlaczego [[G5101]] WTI-ASN **οτι** *hoti* po co [[G3754]] [[CONJ]] **εθου** *ethou* położyłeś [[G5087]] WTV-2AMI-2S **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **καρδια** *kardia* sercu [[G2588]] [[N-DSF]] **σου** *sou* twoim [[G4675]] WTP-2GS **το** *to* [[G3588]] WTT-ASN **πραγμα** *pragma* sprawę [[G4229]] WTN-ASN **τουτο** *touto* tę [[G5124]] WTD-ASN **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εψευσω** *epseusō* skłamałeś [[G5574]] WTV-ADI-2S **ανθρωποις** *anthrōpois* ludziom [[G444]] WTN-DPM **αλλα** *alla* ale [[G235]] [[CONJ]] **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM
###### **Dz 5,5**
 **ακουων** *akouōn* Słuchając [[G191]] [[V-PAP-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **ανανιας** *hananias* Ananiasz – [JH przyjął] [[G367]] [[N-NSM]] **τους** *tous* [[G3588]] WTT-APM **λογους** *logous* słów [[G3056]] [[N-APM]] **τουτους** *toutous* tych [[G5128]] WTD-APM **πεσων** *pesōn* upadłszy [[G4098]] WTV-2AAP-NSM **εξεψυξεν** *eksepsyksen* wydał ostatnie tchnienie – wyzionął ducha [[G1634]] [[V-AAI-3S]] **και** *kai* i [[G2532]] [[CONJ]] **εγενετο** *egeneto* stał się [[G1096]] WTV-2ADI-3S **φοβος** *fobos* strach – bojaźń [[G5401]] [[N-NSM]] **μεγας** *megas* wielki [[G3173]] [[A-NSM]] **επι** *epi* na [[G1909]] [[PREP]] **παντας** *pantas* wszystkich [[G3956]] WTA-APM **τους** *tous* [[G3588]] WTT-APM **ακουοντας** *akouontas* słuchających [[G191]] WTV-PAP-APM **ταυτα** *tauta* tych [[G5023]] WTD-APN
###### **Dz 5,6**
 **ανασταντες** *anastantes* Wstawszy – Podniósłszy się [[G450]] WTV-2AAP-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **νεωτεροι** *neōteroi* młodsi [[G3501]] WTA-NPM-C **συνεστειλαν** *synesteilan* spowili – włożyli razem [[G4958]] WTV-AAI-3P **αυτον** *auton* go [[G846]] WTP-ASM **και** *kai* i [[G2532]] [[CONJ]] **εξενεγκαντες** *eksenegkantes* wyniósłszy [[G1627]] WTV-AAP-NPM **εθαψαν** *ethapsan* pogrzebali [[G2290]] WTV-AAI-3P
###### **Dz 5,7**
 **εγενετο** *egeneto* Stał się [[G1096]] WTV-2ADI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **ως** *hōs* jak [[G5613]] [[ADV]] **ωρων** *hōrōn* godzin [[G5610]] WTN-GPF **τριων** *triōn* trzech [[G5140]] WTA-GPF **διαστημα** *diastēma* odstęp [[G1292]] WTN-NSN **και** *kai* i [[G2532]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **γυνη** *gynē* żona – kobieta [[G1135]] [[N-NSF]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **μη** *mē* nie [[G3361]] [[PRT-N]] **ειδυια** *eidyia* wiedząc [[G1492]] WTV-RAP-NSF **το** *to* [[G3588]] WTT-ASN **γεγονος** *gegonos* co stało się [[G1096]] WTV-2RAP-ASN **εισηλθεν** *eisēlthen* weszła [[G1525]] WTV-2AAI-3S
###### **Dz 5,8**
 **απεκριθη** *apekrithē* Odpowiedział [[G611]] WTV-ADI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **αυτη** *autē* jej [[G846]] WTP-DSF **ο** *ho* [[G3588]] [[T-NSM]] **πετρος** *petros* Piotr – [kamyk] [[G4074]] [[N-NSM]] **ειπε** *eipe* powiedz [[G2036]] WTV-2AAM-2S **μοι** *moi* mi [[G3427]] WTP-1DS **ει** *ei* czy [[G1487]] WTCOND **τοσουτου** *tosoutou* (za) tak wiele – (za) tyle [[G5118]] WTD-GSN **το** *to* [[G3588]] WTT-ASN **χωριον** *chōrion* teren – pole [[G5564]] WTN-ASN **απεδοσθε** *apedosthe* oddaliście [[G591]] WTV-2AMI-2P **η** *hē* (ona) [[G3588]] [[T-NSF]] **δε** *de* zaś [[G1161]] [[CONJ]] **ειπεν** *eipen* powiedziała [[G2036]] WTV-2AAI-3S **ναι** *nai* tak [[G3483]] WTPRT **τοσουτου** *tosoutou* (za) tak wiele – (za) tyle [[G5118]] WTD-GSN
###### **Dz 5,9**
 **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **πετρος** *petros* Piotr – [kamyk] [[G4074]] [[N-NSM]] **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S **προς** *pros* do [[G4314]] [[PREP]] **αυτην** *autēn* niej [[G846]] [[P-ASF]] **τι** *ti* dlaczego [[G5101]] WTI-NSN **οτι** *hoti* po co [[G3754]] [[CONJ]] **συνεφωνηθη** *synefōnēthē* zostałaś umówiona (zostaliście umówieni) – uzgodniłaś (uzgodniliście) [[G4856]] [[V-API-3S]] **υμιν** *hymin* wy [[G5213]] WTP-2DP **πειρασαι** *peirasai* doświadczyć – próbować [[G3985]] [[V-AAN]] **το** *to* [[G3588]] WTT-ASN **πνευμα** *pneuma* Ducha [[G4151]] WTN-ASN **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **οι** *hoi* [[G3588]] WTT-NPM **ποδες** *podes* stopy [[G4228]] WTN-NPM **των** *tōn* (tych) [[G3588]] WTT-GPM **θαψαντων** *thapsantōn* którzy pogrzebali [[G2290]] WTV-AAP-GPM **τον** *ton* [[G3588]] [[T-ASM]] **ανδρα** *andra* męża [[G435]] [[N-ASM]] **σου** *sou* twojego [[G4675]] WTP-2GS **επι** *epi* przed [[G1909]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **θυρα** *thyra* drzwiami [[G2374]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **εξοισουσιν** *eksoisousin* wyniosą [[G1627]] WTV-FAI-3P **σε** *se* ciebie [[G4571]] WTP-2AS
###### **Dz 5,10**
 **επεσεν** *epesen* Padła [[G4098]] WTV-2AAI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **παραχρημα** *parachrēma* od razu – natychmiast [[G3916]] [[ADV]] **παρα** *para* przy [[G3844]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **ποδας** *podas* stopach [[G4228]] [[N-APM]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **εξεψυξεν** *eksepsyksen* wydała ostatnie tchnienie – wyzionęła ducha [[G1634]] [[V-AAI-3S]] **εισελθοντες** *eiselthontes* wszedłszy [[G1525]] WTV-2AAP-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **νεανισκοι** *neaniskoi* młodzieńcy [[G3495]] WTN-NPM **ευρον** *heuron* znaleźli [[G2147]] WTV-2AAI-3P **αυτην** *autēn* ją [[G846]] [[P-ASF]] **νεκραν** *nekran* martwą [[G3498]] WTA-ASF **και** *kai* i [[G2532]] [[CONJ]] **εξενεγκαντες** *eksenegkantes* wyniósłszy [[G1627]] WTV-AAP-NPM **εθαψαν** *ethapsan* pogrzebali [[G2290]] WTV-AAI-3P **προς** *pros* przy [[G4314]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **ανδρα** *andra* mężu [[G435]] [[N-ASM]] **αυτης** *autēs* jej [[G846]] [[P-GSF]]
###### **Dz 5,11**
 **και** *kai* I [[G2532]] [[CONJ]] **εγενετο** *egeneto* stał się [[G1096]] WTV-2ADI-3S **φοβος** *fobos* strach – bojaźń [[G5401]] [[N-NSM]] **μεγας** *megas* wielki [[G3173]] [[A-NSM]] **εφ** *ef* na [[G1909]] [[PREP]] **ολην** *holēn* całe [[G3650]] WTA-ASF **την** *tēn* [[G3588]] WTT-ASF **εκκλησιαν** *ekklēsian* zgromadzenie – (społeczność) wywołanych [[G1577]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **επι** *epi* na [[G1909]] [[PREP]] **παντας** *pantas* wszystkich [[G3956]] WTA-APM **τους** *tous* [[G3588]] WTT-APM **ακουοντας** *akouontas* słuchających [[G191]] WTV-PAP-APM **ταυτα** *tauta* tych [[G5023]] WTD-APN
###### **Dz 5,12**
 **δια** *dia* Przez [[G1223]] [[PREP]] **δε** *de* zaś [[G1161]] [[CONJ]] **των** *tōn* [[G3588]] WTT-GPF **χειρων** *cheirōn* ręce [[G5495]] WTN-GPF **των** *tōn* [[G3588]] WTT-GPM **αποστολων** *apostolōn* wysłanników [[G652]] WTN-GPM **εγινετο** *egineto* stawał się (stawały się) [[G1096]] WTV-INI-3S **σημεια** *sēmeia* znaki [[G4592]] WTN-NPN **και** *kai* i [[G2532]] [[CONJ]] **τερατα** *terata* cuda [[G5059]] WTN-NPN **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **λαω** *laō* ludzie [[G2992]] WTN-DSM **πολλα** *polla* liczne – wiele [[G4183]] WTA-NPN **και** *kai* i [[G2532]] [[CONJ]] **ησαν** *ēsan* byli [[G2258]] WTV-IXI-3P **ομοθυμαδον** *homothymadon* jednomyślnie – jednogłośnie [[G3661]] [[ADV]] **απαντες** *hapantes* wszyscy [[G537]] WTA-NPM **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **στοα** *stoa* Portyku [[G4745]] [[N-DSF]] **σολομωντος** *solomōntos* Salomona – [człowiek pokoju] [[G4672]] [[N-GSM]]
###### **Dz 5,13**
 **των** *tōn* [[G3588]] WTT-GPM **δε** *de* zaś [[G1161]] [[CONJ]] **λοιπων** *loipōn* (z) pozostałych [[G3062]] WTA-GPM **ουδεις** *oudeis* nikt [[G3762]] [[A-NSM]] **ετολμα** *etolma* ośmielał się – odważał się [[G5111]] WTV-IAI-3S **κολλασθαι** *kollasthai* być przyłączonym [[G2853]] WTV-PPN **αυτοις** *autois* (z) nimi [[G846]] WTP-DPM **αλλ** *all* ale [[G235]] [[CONJ]] **εμεγαλυνεν** *emegalynen* uczynił wielkim – wywyższał [[G3170]] WTV-IAI-3S **αυτους** *autous* ich [[G846]] [[P-APM]] **ο** *ho* [[G3588]] [[T-NSM]] **λαος** *laos* lud [[G2992]] [[N-NSM]]
###### **Dz 5,14**
 **μαλλον** *mallon* Coraz bardziej [[G3123]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **προσετιθεντο** *prosetithento* zostali przyłączani – zostali dodani [[G4369]] WTV-IPI-3P **πιστευοντες** *pisteuontes* wierzący [[G4100]] WTV-PAP-NPM **τω** *tō* [[G3588]] WTT-DSM **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **πληθη** *plēthē* mnóstwo – mnogość [[G4128]] WTN-NPN **ανδρων** *andrōn* mężów [[G435]] WTN-GPM **τε** *te* zarówno – także [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **γυναικων** *gynaikōn* kobiet [[G1135]] WTN-GPF
###### **Dz 5,15**
 **ωστε** *hōste* tak, że [[G5620]] [[CONJ]] **κατα** *kata* na [[G2596]] [[PREP]] **τας** *tas* [[G3588]] WTT-APF **πλατειας** *plateias* place – ulice [[G4113]] WTN-APF **εκφερειν** *ekferein* wynosić [[G1627]] WTV-PAN **τους** *tous* [[G3588]] WTT-APM **ασθενεις** *astheneis* słabych – bezsilnych [[G772]] WTA-APM **και** *kai* i [[G2532]] [[CONJ]] **τιθεναι** *tithenai* kłaść [[G5087]] WTV-PAN **επι** *epi* na [[G1909]] [[PREP]] **κλινων** *klinōn* łożach – posłaniach [[G2825]] WTN-GPF **και** *kai* i [[G2532]] [[CONJ]] **κραββατων** *krabbatōn* matach – posłaniach [[G2895]] WTN-GPM **ινα** *hina* aby [[G2443]] [[CONJ]] **ερχομενου** *erchomenou* przechodzącego [[G2064]] WTV-PNP-GSM **πετρου** *petrou* Piotra – [kamyk] [[G4074]] [[N-GSM]] **καν** *kan* i jeśli [[G2579]] WTCOND-C **η** *hē* [[G3588]] [[T-NSF]] **σκια** *skia* cień [[G4639]] [[N-NSF]] **επισκιαση** *episkiasē* ocieniłby [[G1982]] WTV-AAS-3S **τινι** *tini* kogoś [[G5100]] WTX-DSM **αυτων** *autōn* (z) nich [[G846]] WTP-GPM
###### **Dz 5,16**
 **συνηρχετο** *synērcheto* Schodziło [[G4905]] WTV-INI-3S **δε** *de* zaś [[G1161]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **πληθος** *plēthos* mnóstwo – mnogość [[G4128]] WTN-NSN **των** *tōn* [[G3588]] WTT-GPF **περιξ** *periks* dookoła – wkoło [[G4038]] [[ADV]] **πολεων** *poleōn* miast [[G4172]] WTN-GPF **εις** *eis* w [[G1519]] [[PREP]] **ιερουσαλημ** *ierousalēm* Jeruzalem – [dziedzictwo pokoju] [[G2419]] [[N-PRI]] **φεροντες** *ferontes* niosąc [[G5342]] WTV-PAP-NPM **ασθενεις** *astheneis* słabych – bezsilnych [[G772]] WTA-APM **και** *kai* i [[G2532]] [[CONJ]] **οχλουμενους** *ochloumenous* którzy są trapieni – którzy są męczeni [[G3791]] WTV-PPP-APM **υπο** *hypo* przez [[G5259]] [[PREP]] **πνευματων** *pneumatōn* duchy [[G4151]] WTN-GPN **ακαθαρτων** *akathartōn* nieczyste [[G169]] WTA-GPN **οιτινες** *hoitines* którzy [[G3748]] WTR-NPM **εθεραπευοντο** *etherapeuonto* byli uleczani [[G2323]] WTV-IPI-3P **απαντες** *hapantes* wszyscy [[G537]] WTA-NPM
###### **Dz 5,17**
 **αναστας** *anastas* Wstawszy – Podniósłszy się [[G450]] WTV-2AAP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **αρχιερευς** *archiereus* arcykapłan [[G749]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **οι** *hoi* (ci) [[G3588]] WTT-NPM **συν** *syn* razem z [[G4862]] [[PREP]] **αυτω** *autō* nim [[G846]] WTP-DSM **η** *hē* (ci) [[G3588]] [[T-NSF]] **ουσα** *ousa* będący [[G5607]] WTV-PXP-NSF **αιρεσις** *hairesis* stronnictwo [[G139]] [[N-NSF]] **των** *tōn* [[G3588]] WTT-GPM **σαδδουκαιων** *saddoukaiōn* saduceuszów – [sprawiedliwy] [[G4523]] WTN-GPM **επλησθησαν** *eplēsthēsan* zostali napełnieni [[G4130]] WTV-API-3P **ζηλου** *zēlou* zazdrością – żarliwością [[G2205]] [[N-GSM]]
###### **Dz 5,18**
 **και** *kai* I [[G2532]] [[CONJ]] **επεβαλον** *epebalon* położyli – narzucili [[G1911]] WTV-2AAI-3P **τας** *tas* [[G3588]] WTT-APF **χειρας** *cheiras* ręce [[G5495]] WTN-APF **αυτων** *autōn* ich [[G846]] WTP-GPM **επι** *epi* na [[G1909]] [[PREP]] **τους** *tous* [[G3588]] WTT-APM **αποστολους** *apostolous* wysłanników [[G652]] [[N-APM]] **και** *kai* i [[G2532]] [[CONJ]] **εθεντο** *ethento* umieścili [[G5087]] WTV-2AMI-3P **αυτους** *autous* ich [[G846]] [[P-APM]] **εν** *en* w [[G1722]] [[PREP]] **τηρησει** *tērēsei* strzeżeniu [[G5084]] [[N-DSF]] **δημοσια** *dēmosia* publicznym [[G1219]] WTA-DSF
###### **Dz 5,19**
 **αγγελος** *angelos* Zwiastun [[G32]] [[N-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **δια** *dia* przez [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **νυκτος** *nyktos* noc [[G3571]] [[N-GSF]] **ηνοιξεν** *ēnoiksen* otworzył [[G455]] [[V-AAI-3S]] **τας** *tas* [[G3588]] WTT-APF **θυρας** *thyras* drzwi [[G2374]] WTN-APF **της** *tēs* [[G3588]] [[T-GSF]] **φυλακης** *fylakēs* strażnicy – więzienia [[G5438]] [[N-GSF]] **εξαγαγων** *eksagagōn* wyprowadziwszy [[G1806]] WTV-2AAP-NSM **τε** *te* zarówno – także [[G5037]] WTPRT **αυτους** *autous* ich [[G846]] [[P-APM]] **ειπεν** *eipen* powiedział [[G2036]] WTV-2AAI-3S
###### **Dz 5,20**
 **πορευεσθε** *poreuesthe* Idźcie [[G4198]] WTV-PNM-2P **και** *kai* i [[G2532]] [[CONJ]] **σταθεντες** *stathentes* zostawszy postawionymi [[G2476]] WTV-APP-NPM **λαλειτε** *laleite* mówcie [[G2980]] WTV-PAM-2P **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **ιερω** *hierō* świątyni [[G2411]] WTN-DSN **τω** *tō* [[G3588]] WTT-DSM **λαω** *laō* ludowi [[G2992]] WTN-DSM **παντα** *panta* wszystkie [[G3956]] WTA-APN **τα** *ta* [[G3588]] WTT-APN **ρηματα** *rēmata* wypowiedzi [[G4487]] WTN-APN **της** *tēs* [[G3588]] [[T-GSF]] **ζωης** *zōēs* życia [[G2222]] [[N-GSF]] **ταυτης** *tautēs* tego [[G3778]] WTD-GSF
###### **Dz 5,21**
 **ακουσαντες** *akousantes* Usłyszawszy [[G191]] WTV-AAP-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **εισηλθον** *eisēlthon* weszli [[G1525]] WTV-2AAI-3P **υπο** *hypo* od [[G5259]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **ορθρον** *orthron* wczesnego ranku – brzasku [[G3722]] [[N-ASM]] **εις** *eis* do [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **ιερον** *hieron* świątyni [[G2411]] WTN-ASN **και** *kai* i [[G2532]] [[CONJ]] **εδιδασκον** *edidaskon* nauczali [[G1321]] WTV-IAI-3P **παραγενομενος** *paragenomenos* przybywszy [[G3854]] WTV-2ADP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **αρχιερευς** *archiereus* arcykapłan [[G749]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* (ci) [[G3588]] WTT-NPM **συν** *syn* razem z [[G4862]] [[PREP]] **αυτω** *autō* nim [[G846]] WTP-DSM **συνεκαλεσαν** *synekalesan* zwołali [[G4779]] WTV-AAI-3P **το** *to* [[G3588]] WTT-ASN **συνεδριον** *synedrion* sanhedryn – radę [[G4892]] WTN-ASN **και** *kai* i [[G2532]] [[CONJ]] **πασαν** *pasan* cały [[G3956]] WTA-ASF **την** *tēn* [[G3588]] WTT-ASF **γερουσιαν** *gerousian* starszyznę – radę starszych [[G1087]] WTN-ASF **των** *tōn* [[G3588]] WTT-GPM **υιων** *hyiōn* synów [[G5207]] WTN-GPM **ισραηλ** *israēl* Izraela – [ten, który walczył z Bogiem] [[G2474]] [[N-PRI]] **και** *kai* i [[G2532]] [[CONJ]] **απεστειλαν** *apesteilan* wysłali [[G649]] WTV-AAI-3P **εις** *eis* do [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **δεσμωτηριον** *desmōtērion* więzienia [[G1201]] WTN-ASN **αχθηναι** *achthēnai* zostać przyprowadzonymi [[G71]] WTV-APN **αυτους** *autous* oni [[G846]] [[P-APM]]
###### **Dz 5,22**
 **οι** *hoi* [[G3588]] WTT-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **υπηρεται** *hypēretai* podwładni – pomocnicy [[G5257]] WTN-NPM **παραγενομενοι** *paragenomenoi* przybywszy [[G3854]] WTV-2ADP-NPM **ουχ** *ouch* nie [[G3756]] [[PRT-N]] **ευρον** *heuron* znaleźli [[G2147]] WTV-2AAI-3P **αυτους** *autous* ich [[G846]] [[P-APM]] **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **φυλακη** *fylakē* strażnicy – więzieniu [[G5438]] [[N-DSF]] **αναστρεψαντες** *anastrepsantes* obróciwszy się [[G390]] WTV-AAP-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **απηγγειλαν** *apēngeilan* oznajmili – poinformowali [[G518]] WTV-AAI-3P
###### **Dz 5,23**
 **λεγοντες** *legontes* mówiąc [[G3004]] WTV-PAP-NPM **οτι** *hoti* że [[G3754]] [[CONJ]] **το** *to* [[G3588]] WTT-ASN **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **δεσμωτηριον** *desmōtērion* więzienie [[G1201]] WTN-ASN **ευρομεν** *heuromen* znaleźliśmy [[G2147]] WTV-2AAI-1P **κεκλεισμενον** *kekleismenon* które jest zamknięte [[G2808]] WTV-RPP-ASN **εν** *en* w [[G1722]] [[PREP]] **παση** *pasē* całej [[G3956]] WTA-DSF **ασφαλεια** *asfaleia* niezawodności [[G803]] [[N-DSF]] **και** *kai* i [[G2532]] [[CONJ]] **τους** *tous* [[G3588]] WTT-APM **φυλακας** *fylakas* strażników [[G5441]] [[N-APM]] **εξω** *eksō* na zewnątrz – poza [[G1854]] [[ADV]] **εστωτας** *hestōtas* stojących [[G2476]] WTV-RAP-APM **προ** *pro* przed [[G4253]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPF **θυρων** *thyrōn* drzwiami [[G2374]] WTN-GPF **ανοιξαντες** *anoiksantes* otworzywszy [[G455]] WTV-AAP-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **εσω** *esō* wewnątrz [[G2080]] [[ADV]] **ουδενα** *oudena* nikogo [[G3762]] WTA-ASM **ευρομεν** *heuromen* znaleźliśmy [[G2147]] WTV-2AAI-1P
###### **Dz 5,24**
 **ως** *hōs* Jak [[G5613]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **ηκουσαν** *ēkousan* usłyszeli [[G191]] WTV-AAI-3P **τους** *tous* [[G3588]] WTT-APM **λογους** *logous* słowa [[G3056]] [[N-APM]] **τουτους** *toutous* te [[G5128]] WTD-APM **ο** *ho* [[G3588]] [[T-NSM]] **τε** *te* zarówno – także [[G5037]] WTPRT **ιερευς** *hiereus* kapłan [[G2409]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **στρατηγος** *stratēgos* dowódca straży – komendant [[G4755]] [[N-NSM]] **του** *tou* [[G3588]] WTT-GSN **ιερου** *hierou* świątyni [[G2411]] [[N-GSN]] **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **αρχιερεις** *archiereis* arcykapłani [[G749]] WTN-NPM **διηπορουν** *diēporoun* byli w niepokoju – byli w niepewności [[G1280]] WTV-IAI-3P **περι** *peri* co do [[G4012]] [[PREP]] **αυτων** *autōn* nich [[G846]] WTP-GPM **τι** *ti* co- [[G5101]] WTI-NSN **αν** *an* kolwiek [[G302]] WTPRT **γενοιτο** *genoito* oby stało się [[G1096]] WTV-2ADO-3S **τουτο** *touto* to [[G5124]] WTD-NSN
###### **Dz 5,25**
 **παραγενομενος** *paragenomenos* Przybywszy [[G3854]] WTV-2ADP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **τις** *tis* ktoś [[G5100]] WTX-NSM **απηγγειλεν** *apēngeilen* oznajmił – poinformował [[G518]] [[V-AAI-3S]] **αυτοις** *autois* im [[G846]] WTP-DPM **λεγων** *legōn* mówiąc [[G3004]] [[V-PAP-NSM]] **οτι** *hoti* że [[G3754]] [[CONJ]] **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **οι** *hoi* [[G3588]] WTT-NPM **ανδρες** *andres* mężowie [[G435]] WTN-NPM **ους** *hous* których [[G3739]] WTR-APM **εθεσθε** *ethesthe* umieściliście [[G5087]] WTV-2AMI-2P **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **φυλακη** *fylakē* strażnicy – więzieniu [[G5438]] [[N-DSF]] **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **ιερω** *hierō* świątyni [[G2411]] WTN-DSN **εστωτες** *hestōtes* stojąc [[G2476]] WTV-RAP-NPM **και** *kai* i [[G2532]] [[CONJ]] **διδασκοντες** *didaskontes* nauczając [[G1321]] WTV-PAP-NPM **τον** *ton* [[G3588]] [[T-ASM]] **λαον** *laon* lud [[G2992]] [[N-ASM]]
###### **Dz 5,26**
 **τοτε** *tote* Wtedy [[G5119]] [[ADV]] **απελθων** *apelthōn* odszedłszy [[G565]] WTV-2AAP-NSM **ο** *ho* [[G3588]] [[T-NSM]] **στρατηγος** *stratēgos* dowódca straży – komendant [[G4755]] [[N-NSM]] **συν** *syn* razem z [[G4862]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPM **υπηρεταις** *hypēretais* podwładnymi – pomocnikami [[G5257]] WTN-DPM **ηγαγεν** *ēgagen* poprowadził [[G71]] WTV-2AAI-3S **αυτους** *autous* ich [[G846]] [[P-APM]] **ου** *ou* nie [[G3756]] [[PRT-N]] **μετα** *meta* z [[G3326]] [[PREP]] **βιας** *bias* gwałtem – przemocą [[G970]] [[N-GSF]] **εφοβουντο** *efobounto* bali się [[G5399]] WTV-INI-3P **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **τον** *ton* [[G3588]] [[T-ASM]] **λαον** *laon* ludu [[G2992]] [[N-ASM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **λιθασθωσιν** *lithasthōsin* zostaliby ukamienowani [[G3034]] WTV-APS-3P
###### **Dz 5,27**
 **αγαγοντες** *agagontes* Przyprowadziwszy [[G71]] WTV-2AAP-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **αυτους** *autous* ich [[G846]] [[P-APM]] **εστησαν** *hestēsan* postawili [[G2476]] WTV-2AAI-3P **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **συνεδριω** *synedriō* sanhedrynie – radzie [[G4892]] WTN-DSN **και** *kai* i [[G2532]] [[CONJ]] **επηρωτησεν** *epērōtēsen* dopytywał [[G1905]] [[V-AAI-3S]] **αυτους** *autous* ich [[G846]] [[P-APM]] **ο** *ho* [[G3588]] [[T-NSM]] **αρχιερευς** *archiereus* arcykapłan [[G749]] [[N-NSM]]
###### **Dz 5,28**
 **λεγων** *legōn* mówiąc [[G3004]] [[V-PAP-NSM]] **ου** *ou* nie [[G3756]] [[PRT-N]] **παραγγελια** *parangelia* nakazem – pouczeniem [[G3852]] [[N-DSF]] **παρηγγειλαμεν** *parēngeilamen* nakazaliśmy [[G3853]] WTV-AAI-1P **υμιν** *hymin* wam [[G5213]] WTP-2DP **μη** *mē* aby nie [[G3361]] [[PRT-N]] **διδασκειν** *didaskein* nauczać [[G1321]] WTV-PAN **επι** *epi* w [[G1909]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **ονοματι** *onomati* imieniu [[G3686]] WTN-DSN **τουτω** *toutō* tym [[G5129]] WTD-DSN **και** *kai* i [[G2532]] [[CONJ]] **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **πεπληρωκατε** *peplērōkate* wypełniliście [[G4137]] WTV-RAI-2P **την** *tēn* [[G3588]] WTT-ASF **ιερουσαλημ** *ierousalēm* Jeruzalem – [dziedzictwo pokoju] [[G2419]] [[N-PRI]] **της** *tēs* [[G3588]] [[T-GSF]] **διδαχης** *didachēs* nauką – nauczaniem [[G1322]] [[N-GSF]] **υμων** *hymōn* waszą [[G5216]] WTP-2GP **και** *kai* i [[G2532]] [[CONJ]] **βουλεσθε** *boulesthe* chcecie [[G1014]] WTV-PNI-2P **επαγαγειν** *epagagein* sprowadzić [[G1863]] [[V-2AAN]] **εφ** *ef* na [[G1909]] [[PREP]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **το** *to* [[G3588]] WTT-ASN **αιμα** *haima* krew [[G129]] WTN-ASN **του** *tou* [[G3588]] WTT-GSM **ανθρωπου** *anthrōpou* człowieka [[G444]] [[N-GSM]] **τουτου** *toutou* tego [[G5127]] WTD-GSM
###### **Dz 5,29**
 **αποκριθεις** *apokritheis* Odpowiedziawszy [[G611]] WTV-AOP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **πετρος** *petros* Piotr – [kamyk] [[G4074]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **αποστολοι** *apostoloi* wysłannicy [[G652]] WTN-NPM **ειπον** *eipon* powiedzieli [[G2036]] WTV-2AAI-3P **πειθαρχειν** *peitharchein* być posłusznym władzy – słuchać władzy [[G3980]] WTV-PAN **δει** *dei* trzeba – jest konieczne [[G1163]] WTV-PQI-3S **θεω** *theō* Bogu [[G2316]] WTN-DSM **μαλλον** *mallon* bardziej [[G3123]] [[ADV]] **η** *ē* niż [[G2228]] WTPRT **ανθρωποις** *anthrōpois* ludziom [[G444]] WTN-DPM
###### **Dz 5,30**
 **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **των** *tōn* [[G3588]] WTT-GPM **πατερων** *paterōn* ojców [[G3962]] WTN-GPM **ημων** *hēmōn* naszych [[G2257]] WTP-1GP **ηγειρεν** *ēgeiren* wzbudził – podniósł [[G1453]] [[V-AAI-3S]] **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]] **ον** *hon* (na) którego [[G3739]] WTR-ASM **υμεις** *hymeis* wy [[G5210]] WTP-2NP **διεχειρισασθε** *diecheirisasthe* położyliście ręce – wzięliście w swoje ręce [[G1315]] WTV-AMI-2P **κρεμασαντες** *kremasantes* powiesiwszy [[G2910]] WTV-AAP-NPM **επι** *epi* na [[G1909]] [[PREP]] **ξυλου** *ksylou* drzewie [[G3586]] [[N-GSN]]
###### **Dz 5,36**
 **προ** *pro* Przed [[G4253]] [[PREP]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **τουτων** *toutōn* tymi [[G5130]] WTD-GPF **των** *tōn* [[G3588]] WTT-GPF **ημερων** *hēmerōn* dniami [[G2250]] WTN-GPF **ανεστη** *anestē* powstał – podniósł się [[G450]] WTV-2AAI-3S **θευδας** *theudas* Teodas [[G2333]] [[N-NSM]] **λεγων** *legōn* mówiąc [[G3004]] [[V-PAP-NSM]] **ειναι** *einai* być [[G1511]] WTV-PXN **τινα** *tina* kimś [[G5100]] WTX-ASM **εαυτον** *heauton* on sam [[G1438]] WTF-3ASM **ω** *hō* (do) którego [[G3739]] WTR-DSM **προσεκολληθη** *prosekollēthē* została przyłączona [[G4347]] [[V-API-3S]] **αριθμος** *arithmos* liczba [[G706]] [[N-NSM]] **ανδρων** *andrōn* mężów [[G435]] WTN-GPM **ωσει** *hōsei* jakby [[G5616]] [[ADV]] **τετρακοσιων** *tetrakosiōn* czterystu [[G5071]] WTA-GPN **ος** *hos* który [[G3739]] WTR-NSM **ανηρεθη** *anērethē* został zabity – został zniesiony [[G337]] [[V-API-3S]] **και** *kai* i [[G2532]] [[CONJ]] **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **οσοι** *hosoi* ilu – jacy [[G3745]] WTK-NPM **επειθοντο** *epeithonto* zostali przekonani [[G3982]] WTV-IPI-3P **αυτω** *autō* (przez) niego [[G846]] WTP-DSM **διελυθησαν** *dielythēsan* zostali rozproszeni – zostali rozłączeni [[G1262]] WTV-API-3P **και** *kai* i [[G2532]] [[CONJ]] **εγενοντο** *egenonto* stali się [[G1096]] WTV-2ADI-3P **εις** *eis* ku [[G1519]] [[PREP]] **ουδεν** *ouden* niczemu [[G3762]] WTA-ASN
###### **Dz 5,37**
 **μετα** *meta* Po [[G3326]] [[PREP]] **τουτον** *touton* tym [[G5126]] WTD-ASM **ανεστη** *anestē* powstał – podniósł się [[G450]] WTV-2AAI-3S **ιουδας** *ioudas* Judasz – [wielbić] [[G2455]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **γαλιλαιος** *galilaios* Galilejczyk – [przesunąć] [[G1057]] [[N-NSM]] **εν** *en* w [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **ημεραις** *hēmerais* dniach [[G2250]] WTN-DPF **της** *tēs* [[G3588]] [[T-GSF]] **απογραφης** *apografēs* spisu [[G582]] [[N-GSF]] **και** *kai* i [[G2532]] [[CONJ]] **απεστησεν** *apestēsen* odstąpił – odszedł [[G868]] [[V-AAI-3S]] **λαον** *laon* lud [[G2992]] [[N-ASM]] **ικανον** *hikanon* dość liczny [[G2425]] WTA-ASM **οπισω** *opisō* za [[G3694]] [[ADV]] **αυτου** *autou* nim [[G846]] [[P-GSM]] **κακεινος** *kakeinos* i ten [[G2548]] WTD-NSM-C **απωλετο** *apōleto* zginął [[G622]] WTV-2AMI-3S **και** *kai* i [[G2532]] [[CONJ]] **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **οσοι** *hosoi* ilu – jacy [[G3745]] WTK-NPM **επειθοντο** *epeithonto* zostali przekonani [[G3982]] WTV-IPI-3P **αυτω** *autō* (przez) niego [[G846]] WTP-DSM **διεσκορπισθησαν** *dieskorpisthēsan* zostali rozproszeni [[G1287]] WTV-API-3P
###### **Dz 5,38**
 **και** *kai* I [[G2532]] [[CONJ]] **τα** *ta* (o tych) [[G3588]] WTT-APN **νυν** *nyn* teraz [[G3568]] [[ADV]] **λεγω** *legō* mówię [[G3004]] WTV-PAI-1S **υμιν** *hymin* wam [[G5213]] WTP-2DP **αποστητε** *apostēte* odstąpcie – odejdźcie [[G868]] WTV-2AAM-2P **απο** *apo* od [[G575]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPM **ανθρωπων** *anthrōpōn* ludzi [[G444]] WTN-GPM **τουτων** *toutōn* tych [[G5130]] WTD-GPM **και** *kai* i [[G2532]] [[CONJ]] **εασατε** *easate* zaniechajcie [[G1439]] WTV-AAM-2P **αυτους** *autous* ich [[G846]] [[P-APM]] **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **εαν** *ean* jeśli [[G1437]] WTCOND **η** *ē* byłoby [[G5600]] WTV-PXS-3S **εξ** *eks* z [[G1537]] [[PREP]] **ανθρωπων** *anthrōpōn* ludzi [[G444]] WTN-GPM **η** *hē* [[G3588]] [[T-NSF]] **βουλη** *boulē* postanowienie – rada [[G1012]] [[N-NSF]] **αυτη** *hautē* to [[G3778]] WTD-NSF **η** *ē* lub [[G2228]] WTPRT **το** *to* [[G3588]] WTT-NSN **εργον** *ergon* dzieło [[G2041]] WTN-NSN **τουτο** *touto* to [[G5124]] WTD-NSN **καταλυθησεται** *katalythēsetai* zostanie obalone – zostanie zwalone [[G2647]] WTV-FPI-3S
###### **Dz 5,39**
 **ει** *ei* jeśli [[G1487]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **εκ** *ek* z [[G1537]] [[PREP]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ου** *ou* nie [[G3756]] [[PRT-N]] **δυνασθε** *dynasthe* możecie [[G1410]] WTV-PNI-2P **καταλυσαι** *katalysai* obalić [[G2647]] [[V-AAN]] **αυτο** *auto* ich [[G846]] WTP-ASN **μηποτε** *mēpote* by czasem nie [[G3379]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **θεομαχοι** *theomachoi* walczącymi przeciw Bogu [[G2314]] WTA-NPM **ευρεθητε** *heurethēte* zostalibyście znalezieni [[G2147]] WTV-APS-2P
###### **Dz 5,40**
 **επεισθησαν** *epeisthēsan* Zostali przekonani [[G3982]] WTV-API-3P **δε** *de* zaś [[G1161]] [[CONJ]] **αυτω** *autō* (przez) niego [[G846]] WTP-DSM **και** *kai* i [[G2532]] [[CONJ]] **προσκαλεσαμενοι** *proskalesamenoi* przywoławszy – wezwawszy [[G4341]] WTV-ADP-NPM **τους** *tous* [[G3588]] WTT-APM **αποστολους** *apostolous* wysłanników [[G652]] [[N-APM]] **δειραντες** *deirantes* wychłostawszy – pobiwszy [[G1194]] WTV-AAP-NPM **παρηγγειλαν** *parēngeilan* nakazali [[G3853]] WTV-AAI-3P **μη** *mē* nie [[G3361]] [[PRT-N]] **λαλειν** *lalein* mówić [[G2980]] WTV-PAN **επι** *epi* w [[G1909]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **ονοματι** *onomati* imieniu [[G3686]] WTN-DSN **του** *tou* [[G3588]] WTT-GSM **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **απελυσαν** *apelysan* uwolnili – wypuścili [[G630]] WTV-AAI-3P **αυτους** *autous* ich [[G846]] [[P-APM]]
###### **Dz 5,41**
 **οι** *hoi* (Ci) [[G3588]] WTT-NPM **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **ουν** *oun* więc [[G3767]] [[CONJ]] **επορευοντο** *eporeuonto* poszli [[G4198]] WTV-INI-3P **χαιροντες** *chairontes* radując się – ciesząc się [[G5463]] WTV-PAP-NPM **απο** *apo* od [[G575]] [[PREP]] **προσωπου** *prosōpou* oblicza – twarzy [[G4383]] [[N-GSN]] **του** *tou* [[G3588]] WTT-GSN **συνεδριου** *synedriou* sanhedrynu – rady [[G4892]] [[N-GSN]] **οτι** *hoti* że [[G3754]] [[CONJ]] **υπερ** *hyper* dla [[G5228]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **ονοματος** *onomatos* imienia [[G3686]] [[N-GSN]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **κατηξιωθησαν** *katēksiōthēsan* zostali uznani za godnych [[G2661]] WTV-API-3P **ατιμασθηναι** *atimasthēnai* zostać znieważonymi – nie okazać im szacunku [[G818]] WTV-APN
###### **Dz 5,42**
 **πασαν** *pasan* Każdego [[G3956]] WTA-ASF **τε** *te* zarówno – także [[G5037]] WTPRT **ημεραν** *hēmeran* dnia [[G2250]] WTN-ASF **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **ιερω** *hierō* świątyni [[G2411]] WTN-DSN **και** *kai* i [[G2532]] [[CONJ]] **κατ** *kat* w [[G2596]] [[PREP]] **οικον** *oikon* domu [[G3624]] [[N-ASM]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **επαυοντο** *epauonto* powstrzymywali się [[G3973]] WTV-IMI-3P **διδασκοντες** *didaskontes* nauczając [[G1321]] WTV-PAP-NPM **και** *kai* i [[G2532]] [[CONJ]] **ευαγγελιζομενοι** *euangelizomenoi* głosząc dobrą nowinę [[G2097]] WTV-PMP-NPM **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]] **τον** *ton* [[G3588]] [[T-ASM]] **χριστον** *christon* Pomazańca [[G5547]] [[N-ASM]]
