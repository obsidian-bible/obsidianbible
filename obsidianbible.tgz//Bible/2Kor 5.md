# 2Kor 5 BT5
###### **2Kor 5,1**
 Wiemy bowiem, że kiedy nawet zniszczeje nasz przybytek doczesnego zamieszkania, będziemy mieli mieszkanie od Boga, dom nie ręką uczyniony, lecz wiecznie trwały w niebie.
###### **2Kor 5,2**
 Tak przeto teraz wzdychamy, pragnąc przyodziać się w nasz niebieski przybytek,
###### **2Kor 5,3**
  jeśli tylko odziani, a nie nadzy będziemy.
###### **2Kor 5,4**
 Dlatego właśnie udręczeni wzdychamy, pozostając w tym przybytku, bo nie chcielibyśmy go utracić, lecz przywdziać nań nowe odzienie, aby to, co śmiertelne, wchłonięte zostało przez życie.
###### **2Kor 5,5**
 A Bóg, który nas do tego przeznaczył, daje nam Ducha jako zadatek.
###### **2Kor 5,6**
 Tak więc, mając tę ufność, wiemy, że jak długo pozostajemy w ciele, jesteśmy pielgrzymami, z daleka od Pana.
###### **2Kor 5,7**
 Albowiem według wiary, a nie dzięki widzeniu postępujemy.
###### **2Kor 5,8**
 Mamy jednak nadzieję... i chcielibyśmy raczej opuścić nasze ciało i stanąć w obliczu Pana.
###### **2Kor 5,9**
 Dlatego też staramy się Jemu podobać, czy to gdy z Nim, czy gdy z daleka od Niego jesteśmy.
###### **2Kor 5,10**
 Wszyscy bowiem musimy stanąć przed trybunałem Chrystusa, aby każdy otrzymał zapłatę za uczynki dokonane w ciele, złe lub dobre.
###### **2Kor 5,11**
 Tak więc, przejęci bojaźnią Pana, przekonujemy ludzi, wobec Boga zaś wszystko w nas jest odkryte. Mam zresztą nadzieję, że i dla waszych sumień nie ma w nas nic zakrytego.
###### **2Kor 5,12**
 Mówimy to, nie żeby znów wam siebie polecać, lecz by dać wam sposobność do chlubienia się nami, żebyście w ten sposób mogli odpowiedzieć tym, którzy chlubią się swą powierzchownością, a nie wnętrzem własnego serca.
###### **2Kor 5,13**
 Jeśli bowiem odchodzimy od zmysłów – to ze względu na Boga, jeżeli przytomni jesteśmy – to ze względu na was.
###### **2Kor 5,14**
 Albowiem miłość Chrystusa przynagla nas, pomnych na to, że skoro Jeden umarł za wszystkich, to wszyscy pomarli.
###### **2Kor 5,15**
 A właśnie za wszystkich umarł < Chrystus > po to, aby ci, co żyją, już nie żyli dla siebie, lecz dla Tego, który za nich umarł i zmartwychwstał.
###### **2Kor 5,16**
 Tak więc i my odtąd już nikogo nie znamy według ciała; a jeśli nawet według ciała poznaliśmy Chrystusa, to już więcej nie znamy Go w ten sposób.
###### **2Kor 5,17**
 Jeżeli więc ktoś [pozostaje] w Chrystusie, jest nowym stworzeniem. To, co dawne, minęło, a oto < wszystko > stało się nowe.
###### **2Kor 5,18**
 Wszystko zaś to pochodzi od Boga, który pojednał nas ze sobą przez Chrystusa i zlecił nam posługę jednania.
###### **2Kor 5,19**
 Albowiem w Chrystusie Bóg jednał ze sobą świat, nie poczytując ludziom ich grzechów, nam zaś przekazując słowo jednania.
###### **2Kor 5,20**
 Tak więc w imieniu Chrystusa spełniamy posłannictwo jakby Boga samego, który przez nas udziela napomnień. W imię Chrystusa prosimy: pojednajcie się z Bogiem!
###### **2Kor 5,21**
 On to dla nas grzechem uczynił Tego, który nie znał grzechu, abyśmy się stali w Nim sprawiedliwością Bożą.
# 2Kor 5 PAU
###### **2Kor 5,1**
 Wiemy, że kiedy namiot, w którym mieszkamy tu na ziemi, zostanie zwinięty, otrzymamy od Boga jako mieszkanie budowlę niewzniesioną rękami, lecz wieczną, w niebie.
###### **2Kor 5,2**
 Dlatego teraz wzdychamy, pragnąc ubrać się w nasze mieszkanie z nieba,
###### **2Kor 5,3**
 o ile tylko po zdjęciu ziemskiego ubrania nie okażemy się nadzy.
###### **2Kor 5,4**
 Będąc bowiem w obecnym namiocie, wzdychamy i uginamy się jak pod ciężarem, ponieważ nie chcemy zdjąć go z siebie, ale na niego staramy się nałożyć następne ubranie, aby to, co śmiertelne, zostało wchłonięte przez życie.
###### **2Kor 5,5**
 Bóg nas do tego uzdolnił, dając nam Ducha jako poręczyciela.
###### **2Kor 5,6**
 Ufamy więc zawsze, wiedząc, że jak długo przebywamy w ciele, tułamy się z dala od Pana,
###### **2Kor 5,7**
 gdyż wciąż jeszcze chodzimy w wierze, a nie w widzeniu.
###### **2Kor 5,8**
 Jesteśmy jednak pełni ufności i wolelibyśmy raczej opuścić ciało, a przebywać blisko Pana.
###### **2Kor 5,9**
 Dlatego ze wszystkich sił staramy się Jemu podobać zarówno wtedy, gdy przebywamy blisko, jak i wtedy, gdy tułamy się z dala.
###### **2Kor 5,10**
 Wszyscy bowiem musimy stawić się przed sądem Chrystusa, aby każdy otrzymał odpłatę za dokonane w ciele czyny, zarówno dobre, jak i złe.
###### **2Kor 5,11**
 Świadomi, czym jest bojaźń Pańska, staramy się przekonywać ludzi. Przed Bogiem zaś wszystko w nas jest jawne. Mam nadzieję, że również w ocenie waszego sumienia wszystko w nas jest jawne.
###### **2Kor 5,12**
 Nie staramy się znowu o wasze względy, lecz chcemy być dla was powodem do chluby, abyście wskazując na nas, mogli przeciwstawić się tym, których chlubą są rzeczy zewnętrzne, a nie to, co w sercu.
###### **2Kor 5,13**
 Jeśli traciliśmy rozum - to ze względu na Boga; jeśli zachowujemy rozsądek - to ze względu na was.
###### **2Kor 5,14**
 Miłość Chrystusa przynagla nas, ponieważ przekonaliśmy się, że Jeden umarł za wszystkich, a więc wszyscy umarli.
###### **2Kor 5,15**
 On umarł za wszystkich, aby ci, którzy żyją, żyli już nie dla siebie, ale dla Tego, który za nich umarł i zmartwychwstał.
###### **2Kor 5,16**
 Odtąd więc już nie znamy nikogo według ludzkiej oceny. I chociaż w ten sposób poznaliśmy Chrystusa, teraz już nie tak Go poznajemy.
###### **2Kor 5,17**
 Jeśli ktoś jest w Chrystusie, jest nowym stworzeniem. To, co dawne, przeminęło, a nastało nowe.
###### **2Kor 5,18**
 Wszystko to jest z Boga, który przez Chrystusa pojednał nas ze sobą i zlecił nam posługę pojednania.
###### **2Kor 5,19**
 To właśnie Bóg w Chrystusie pojednał świat ze sobą. On nie poczytał ludziom ich grzechów i w nas złożył słowo pojednania.
###### **2Kor 5,20**
 Jesteśmy więc posłani w zastępstwie Chrystusa jako przedstawiciele Boga, który przez nas zachęca. W zastępstwie Chrystusa prosimy więc: Pojednajcie się z Bogiem!
###### **2Kor 5,21**
 On Tego, który nie znał grzechu, za nas uczynił grzechem, abyśmy stali się w Nim sprawiedliwością Bożą.
# 2Kor 5 BP
###### **2Kor 5,1**
 Wiemy bowiem, że kiedy nasz namiot, w którym na ziemi przebywamy, ulegnie zniszczeniu, otrzymamy od Boga dom w niebie, wieczny i nie zbudowany ręką ludzką.
###### **2Kor 5,2**
 Dlatego wzdychamy, pragnąc przyodziać to mieszkanie z nieba na obecne,
###### **2Kor 5,3**
 o ile jednak będziemy przyodziani, a nie pozbawieni okrycia.
###### **2Kor 5,4**
 Przebywając więc w tym namiocie wzdychamy uciśnieni, ponieważ nie chcielibyśmy go rozebrać, lecz tylko przyodziać na niego mieszkanie z nieba, aby to, co śmiertelne, zostało wchłonięte przez życie.
###### **2Kor 5,5**
 Bóg, który nas do tego przeznaczył, dał nam Ducha jako zadatek.
###### **2Kor 5,6**
 Ufamy więc zawsze i wiemy, że jak długo przebywamy w ciele, jesteśmy pielgrzymami z daleka od Pana.
###### **2Kor 5,7**
 W postępowaniu kierujemy się wiarą, a nie widzeniem.
###### **2Kor 5,8**
 Ufamy. Chcielibyśmy raczej opuścić ciało i przebywać przy Panu.
###### **2Kor 5,9**
 Dlatego obojętnie, czy przebywamy z Nim, czy też jesteśmy od Niego oddaleni, staramy się usilnie Jemu podobać.
###### **2Kor 5,10**
 Wszyscy bowiem musimy stanąć przed trybunałem Chrystusa, aby każdy otrzymał zapłatę, na jaką zasłużył za życia w ciele, dobrą lub złą.
###### **2Kor 5,11**
 Wiedząc, co to jest bojaźń Pańska, staramy się ludzi przekonywać - dla Boga wszystko w nas jest jawne. Mam też nadzieję, że i dla was jest jawne.
###### **2Kor 5,12**
 Nie mamy zamiaru ponownie polecać wam siebie, lecz tylko pragniemy dać wam okazję do chlubienia się nami, abyście mogli odpowiedzieć tym, którzy chlubę widzą w zewnętrznej powierzchowności, a nie w sercu.
###### **2Kor 5,13**
 Jeżeli postępujemy jak szaleni, to dla Boga, a jeżeli z umiarem, to dla was.
###### **2Kor 5,14**
 Przynagla nas bowiem miłość Chrystusa. Doszliśmy do przekonania, że jeżeli jeden umarł za wszystkich, to wszyscy umarli.
###### **2Kor 5,15**
 A za wszystkich umarł Chrystus po to, aby ci, którzy żyją, już więcej nie żyli dla siebie, lecz dla Tego, który za nich umarł i zmartwychwstał.
###### **2Kor 5,16**
 Tak więc odtąd nie kierujemy się w ocenie czysto ludzkimi względami. Jeżeli nawet kiedyś ocenialiśmy w ten sposób Chrystusa, to obecnie już Go tak nie oceniamy.
###### **2Kor 5,17**
 Kto jest w łączności z Chrystusem, ten staje się nowym stworzeniem. Stare przeminęło, a powstało nowe.
###### **2Kor 5,18**
 Wszystko to pochodzi od Boga, który pojednał nas ze sobą za pośrednictwem Chrystusa, a nam zlecił posługę pojednywania.
###### **2Kor 5,19**
 Bóg pojednał w Chrystusie świat ze sobą, nie pamięta o grzechach ludzi, a nam nakazał głosić pojednanie.
###### **2Kor 5,20**
 Jesteśmy zatem wysłańcami Chrystusa i sam Bóg przez nas upomina. W imieniu Chrystusa prosimy: pojednajcie się z Bogiem!
###### **2Kor 5,21**
 On dla nas zrzucił winę na Tego, który nie popełnił żadnego grzechu, abyśmy w Nim osiągnęli sprawiedliwość Bożą.
# 2Kor 5 BR
###### **2Kor 5,1**
 Wiemy bowiem, że kiedy zniszczeje nasz przybytek doczesnego zamieszkania, będziemy mieli mieszkanie od Boga, dom nie ręką uczyniony, lecz wiecznie trwały w niebie.
###### **2Kor 5,2**
 Tak przeto teraz wzdychamy, pragnąc przyodziać się w nasz niebieski przybytek,
###### **2Kor 5,3**
 jeśli tylko odziani, a nie nadzy będziemy.
###### **2Kor 5,4**
 Dlatego właśnie udręczeni wzdychamy, pozostając w tym przybytku, bo nie chcielibyśmy go utracić, lecz przywdziać nań nowe odzienie, aby to, co śmiertelne, wchłonięte zostało przez życie.
###### **2Kor 5,5**
 A Bóg, który nas do tego przeznaczył, daje nam Ducha jako zadatek.
###### **2Kor 5,6**
 Tak więc, mając tę ufność, wierzymy, że jak długo pozostajemy w ciele, jesteśmy pielgrzymami z daleka od Pana.
###### **2Kor 5,7**
 Albowiem według wiary, a nie dzięki widzeniu postępujemy.
###### **2Kor 5,8**
 Mamy jednak nadzieję... i chcielibyśmy raczej opuścić nasze ciało i stanąć w obliczu Pana.
###### **2Kor 5,9**
 Dlatego też staramy się Jemu podobać, czy to gdy z Nim, czy gdy z daleka od Niego jesteśmy.
###### **2Kor 5,10**
 Wszyscy bowiem musimy stanąć przed trybunałem Chrystusa, aby każdy otrzymał zapłatę za uczynki dokonane w ciele, złe lub dobre.
###### **2Kor 5,11**
 Tak więc, przejęci bojaźnią Pana, przekonujemy ludzi, wobec Boga zaś wszystko w nas odkryte. Mam zresztą nadzieję, że i dla waszych sumień nie ma w nas nic zakrytego.
###### **2Kor 5,12**
 Mówimy to, nie żeby znów wam siebie zalecać, lecz by dać wam sposobność do chlubienia się nami, iżbyście w ten sposób mogli odpowiedzieć tym, którzy przechwalają się swą powierzchownością, a nie wnętrzem własnego serca.
###### **2Kor 5,13**
 Jeśli bowiem odchodzimy od zmysłów - to ze względu na Boga, jeżeli przytomni jesteśmy - to ze względu na was.
###### **2Kor 5,14**
 Albowiem miłość Chrystusa przynagla nas, pomnych na to, że skoro jeden umarł za wszystkich, to wszyscy pomarli.
###### **2Kor 5,15**
 A właśnie za wszystkich umarł [Chrystus] po to, aby ci, co żyją, już nie żyli dla siebie, lecz dla Tego, który za nich umarł i zmartwychwstał.
###### **2Kor 5,16**
 Tak więc i my odtąd już nikogo nie znamy według ciała; a jeśli nawet wedlug ciała poznaliśmy Chrystusa, to już więcej nie znamy Go w ten sposób.
###### **2Kor 5,17**
 Jeżeli więc ktoś pozostaje w Chrystusie, jest nowym stworzeniem. To, co dawne, minęło, a oto wszystko stało się nowe.
###### **2Kor 5,18**
 Wszystko zaś to pochodzi od Boga, który pojednał nas z sobą przez Chrystusa i zlecił nam posługę jednania.
###### **2Kor 5,19**
 Albowiem w Chrystusie Bóg jednał ze sobą świat, nie poczytując ludziom ich grzechów, nam zaś przekazując słowo jednania.
###### **2Kor 5,20**
 Tak więc w imieniu Chrystusa spełniamy posłannictwo jakby Boga samego, który przez nas udziela napomnień. W imię Chrystusa prosimy: pojednajcie się z Bogiem.
###### **2Kor 5,21**
 On to dla nas grzechem uczynił Tego, który nie znał grzechu, abyśmy się stali w Nim sprawiedliwością Bożą.
# 2Kor 5 WUJ
###### **2Kor 5,1**
 Bo wiemy, że jeśliby ziemski dom nasz tego mieszkania był zepsowany, iż budowanie mamy od Boga, dom nie rękoma robiony wiekuisty w niebiesiech.
###### **2Kor 5,2**
 Abowiem w tem wzdychamy, żądając być przyobleczeni mieszkaniem naszem, które jest z nieba:
###### **2Kor 5,3**
 Jeśliż jedno obleczonemi, a nie nagiemi będziemy nalezieni.
###### **2Kor 5,4**
 Bo i którzy jesteśmy w tem przybytku, wzdychamy obciążeni: przeto że nie żądamy być zwleczeni, ale przyobleczeni: aby pożarte było co śmiertelne jest od żywota.
###### **2Kor 5,5**
 A który nas na toż sprawuje. Bóg który nam dał zadatek Ducha.
###### **2Kor 5,6**
 Śmiemy tedy zawsze, wiedząc, że pókiśmy w ciele, pielgrzymujemy od Pana.
###### **2Kor 5,7**
 (Abowiem przez wiarę chodzimy, a nie przez widzenie).
###### **2Kor 5,8**
 A śmiemy, i dobrą wolą mamy pielgrzymować raczej od ciała, a przytomnemi być Panu.
###### **2Kor 5,9**
 I dla tego usiłujemy, chociaż odległymi, chociaż przytomnymi, jemu się podobać.
###### **2Kor 5,10**
 Bo się wszyscy my musiemy okazać przed stolicą Chrystusową, aby każdy odniósł własne sprawy ciała, według tego co uczynił, lub dobre, lub złe.
###### **2Kor 5,11**
 Wiedząc tedy strach Pański ludzie namawiamy: lecz Bogu jawnemi jesteśmy. A spodziewam się, iż też w sumieniach waszych jesteśmy jawnemi.
###### **2Kor 5,12**
 Nie znowu sami siebie wam zalecamy, ale wam dajemy przyczynę, abyście się chlubili z nas, żebyście mieli przeciwko tym, którzy się zalecają zwierzchu, a nie w sercu.
###### **2Kor 5,13**
 Bo choć od siebie odchodzimy, Bogu: choć przy baczeniu jesteśmy, wam.
###### **2Kor 5,14**
 Abowiem miłość Chrystusowa przyciska nas: uważających to, iż jeśli jeden za wszystkie umarł, tedy wszyscy umarli.
###### **2Kor 5,15**
 A za wszystkie umarł Chrystus, aby i którzy żywią, już nie sami sobie żyli, ale temu, który za nie umarł i zmartwychwstał.
###### **2Kor 5,16**
 A tak my, od tychmiast nikogo nie znamy wedle ciała. A jeśliśmy znali Chrystusa wedle ciała: ale już teraz nie znamy.
###### **2Kor 5,17**
 Jeśli tedy, które w Chrystusie nowe stworzenie, stare rzeczy przeminęły, oto się wszystkie nowe stały.
###### **2Kor 5,18**
 A wszystko z Boga, który nas z sobą pojednał przez Chrystusa: i dał nam urząd jednania.
###### **2Kor 5,19**
 Abowiem Bóg był w Chrystusie świat z sobą jednając, nie przyczytając im grzechów ich: i włożył na nas słowo zjednania.
###### **2Kor 5,20**
 Miasto Chrystusa tedy poselstwo sprawujemy, jakoby Bóg przez nas napominał: Prosiemy miasto Chrystusa, pojednajcie się z Bogiem.
###### **2Kor 5,21**
 Tego, który nie znał grzechu, uczynił grzechem za nas: abyśmy my się stali sprawiedliwością Bożą w nim.
# 2Kor 5 STERN
###### **2Kor 5,1**
 Wiemy, że gdy zużyje się ten namiot, w którym mieszkamy tu na ziemi, będziemy mieli trwały budynek od Boga, budynek wykonany nie rękami ludzkimi, w którym zamieszkamy w niebie.
###### **2Kor 5,2**
 Bo w tym namiocie, naszym ziemskim ciele, wzdychamy, pragnąc mieć wokół siebie ten dom z nieba, który nam przypadnie.
###### **2Kor 5,3**
 Bo będąc w nim, nie okażemy się nadzy.
###### **2Kor 5,4**
 Tak jest, kiedy jesteśmy w tym ciele, wzdychamy, odczuwając ucisk: nie chodzi o to, że chcielibyśmy coś z siebie zrzucić, lecz że chcielibyśmy coś na to przywdziać; tak aby to, co musi umrzeć, zostało wchłonięte przez życie.
###### **2Kor 5,5**
 A przygotował nas do tego właśnie Bóg i dał nam swego Ducha jako zadatek.
###### **2Kor 5,6**
 Zawsze więc jesteśmy ufni - wiemy, że póki mamy dom w tym ciele, jesteśmy poza naszym domem u Pana;
###### **2Kor 5,7**
 bo żyjemy ufnością, a nie tym, co widzimy.
###### **2Kor 5,8**
 Mamy zatem ufność i daleko bardziej wolelibyśmy opuścić nasz dom w ciele i pójść do naszego domu u Pana.
###### **2Kor 5,9**
 Dlatego czy w domu, czy poza domem, robimy, co w naszej mocy, aby się Mu podobać;
###### **2Kor 5,10**
 wszyscy bowiem musimy stanąć przed trybunałem Mesjasza, gdzie każdy poniesie dobre lub złe skutki tego, co robił, gdy był w ciele.
###### **2Kor 5,11**
 Mając zatem bojaźń Pana przed oczami, staramy się przekonywać ludzi. Ponadto Bóg zna nas takimi, jakimi naprawdę jesteśmy; a mam nadzieję, że w swoim sumieniu wy też znacie nas takimi, jakimi naprawdę jesteśmy.
###### **2Kor 5,12**
 Nie zachwalamy wam ponownie samych siebie, ale podajemy wam powód, dla którego możecie być z nas dumni, abyście potrafili odpowiedzieć tym, którzy chlubią się raczej wyglądem człowieka niż jego wewnętrznymi cechami.
###### **2Kor 5,13**
 Jeśliśmy postradali zmysły, to ze względu na Boga; a jeśli przy zdrowych zmysłach jesteśmy, to ze względu na was.
###### **2Kor 5,14**
 Bo miłość Mesjasza pochwyciła nas, jesteśmy bowiem przekonani, że jeden człowiek umarł za całą ludzkość (co oznacza, że cała ludzkość już nie żyła)
###### **2Kor 5,15**
 i że umarł za wszystkich, ażeby ci, którzy żyją, nie żyli już dla samych siebie, ale dla Tego, kto za nich umarł i został wskrzeszony.
###### **2Kor 5,16**
 Odtąd więc nie patrzymy na nikogo tak, jak patrzy świat. Nawet jeśli kiedyś patrzyliśmy na Mesjasza tak, jak patrzy świat, to już tego nie robimy.
###### **2Kor 5,17**
 Jeśli kto zatem jest jedno z Mesjaszem, nowym jest stworzeniem - stare przeminęło; i spójrzcie: to, co nastało, jest świeże i nowe!
###### **2Kor 5,18**
 A to wszystko jest od Boga, który poprzez Mesjasza pojednał nas ze sobą i dał nam dzieło tego pojednania,
###### **2Kor 5,19**
 to znaczy, Bóg w Mesjaszu jednał ze sobą ludzkość, nie licząc jej grzechów, a nam powierzając orędzie pojednania.
###### **2Kor 5,20**
 Dlatego jesteśmy przedstawicielstwem Mesjasza; rzeczywiście przez nas przedstawia Bóg swe wezwanie. Otóż wzywamy w imieniu Mesjasza: "Pojednajcie się z Bogiem!
###### **2Kor 5,21**
 Tego bezgrzesznego człowieka uczynił Bóg ofiarą za grzech złożoną za nas, ażebyśmy w jedności z Nim mogli w pełni uczestniczyć w Bożej sprawiedliwości".
# 2Kor 5 TRO
###### **2Kor 5,1**
 **οιδαμεν** *oidamen* Wiemy [[G1492]] WTV-RAI-1P **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **οτι** *hoti* że [[G3754]] [[CONJ]] **εαν** *ean* jeśli [[G1437]] WTCOND **η** *hē* [[G3588]] [[T-NSF]] **επιγειος** *epigeios* ziemski [[G1919]] WTA-NSF **ημων** *hēmōn* nasz [[G2257]] WTP-1GP **οικια** *oikia* dom [[G3614]] [[N-NSF]] **του** *tou* (ten) [[G3588]] WTT-GSN **σκηνους** *skēnous* namiot – przybytek [[G4636]] [[N-GSN]] **καταλυθη** *katalythē* zostałby zwalony – zostałby obalony [[G2647]] WTV-APS-3S **οικοδομην** *oikodomēn* budowlę [[G3619]] WTN-ASF **εκ** *ek* od [[G1537]] [[PREP]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εχομεν** *echomen* mamy [[G2192]] WTV-PAI-1P **οικιαν** *oikian* dom [[G3614]] WTN-ASF **αχειροποιητον** *acheiropoiēton* nie ręką uczyniony [[G886]] WTA-ASF **αιωνιον** *aiōnion* wieczny [[G166]] WTA-ASF **εν** *en* w [[G1722]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPM **ουρανοις** *ouranois* niebiosach [[G3772]] WTN-DPM
###### **2Kor 5,2**
 **και** *kai* A [[G2532]] [[CONJ]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **τουτω** *toutō* tym [[G5129]] WTD-DSN **στεναζομεν** *stenazomen* wzdychamy – jęczymy [[G4727]] WTV-PAI-1P **το** *to* [[G3588]] WTT-ASN **οικητηριον** *oikētērion* mieszkanie [[G3613]] WTN-ASN **ημων** *hēmōn* nasze [[G2257]] WTP-1GP **το** *to* (to) [[G3588]] WTT-ASN **εξ** *eks* z [[G1537]] [[PREP]] **ουρανου** *ouranou* nieba [[G3772]] [[N-GSM]] **επενδυσασθαι** *ependysasthai* przyoblec się – przywdziać na siebie [[G1902]] WTV-AMN **επιποθουντες** *epipothountes* tęskniąc – pragnąc [[G1971]] WTV-PAP-NPM
###### **2Kor 5,3**
 **ειγε** *eige* Jeśli oczywiście – Jeśli rzeczywiście [[G1489]] WTCOND **και** *kai* i [[G2532]] [[CONJ]] **ενδυσαμενοι** *endysamenoi* którzy zostali przyobleczeni – którzy zostali odziani [[G1746]] WTV-AMP-NPM **ου** *ou* nie [[G3756]] [[PRT-N]] **γυμνοι** *gymnoi* nadzy [[G1131]] WTA-NPM **ευρεθησομεθα** *heurethēsometha* zostaniemy znalezieni [[G2147]] WTV-FPI-1P
###### **2Kor 5,4**
 **και** *kai* A [[G2532]] [[CONJ]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **οντες** *ontes* będąc [[G5607]] WTV-PXP-NPM **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* (tym) [[G3588]] WTT-DSN **σκηνει** *skēnei* namiocie – przybytku [[G4636]] WTN-DSN **στεναζομεν** *stenazomen* wzdychamy – jęczymy [[G4727]] WTV-PAI-1P **βαρουμενοι** *baroumenoi* będąc obciążonymi [[G916]] WTV-PPP-NPM **εφ** *ef* z powodu [[G1909]] [[PREP]] **ω** *hō* tego [[G3739]] WTR-DSN **ου** *ou* nie [[G3756]] [[PRT-N]] **θελομεν** *thelomen* chcemy [[G2309]] WTV-PAI-1P **εκδυσασθαι** *ekdysasthai* zdjąć – zewlec z siebie [[G1562]] WTV-AMN **αλλ** *all* ale [[G235]] [[CONJ]] **επενδυσασθαι** *ependysasthai* przyoblec się – przywdziać na siebie [[G1902]] WTV-AMN **ινα** *hina* aby [[G2443]] [[CONJ]] **καταποθη** *katapothē* zostałoby pochłonięte [[G2666]] WTV-APS-3S **το** *to* (to) [[G3588]] WTT-NSN **θνητον** *thnēton* śmiertelne – umieralne [[G2349]] WTA-NSN **υπο** *hypo* przez [[G5259]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **ζωης** *zōēs* życie [[G2222]] [[N-GSF]]
###### **2Kor 5,5**
 **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **κατεργασαμενος** *katergasamenos* sprawiwszy sobie – przygotowawszy sobie [[G2716]] WTV-ADP-NSM **ημας** *hēmas* nas [[G2248]] WTP-1AP **εις** *eis* do [[G1519]] [[PREP]] **αυτο** *auto* tego [[G846]] WTP-ASN **τουτο** *touto* takiego [[G5124]] WTD-ASN **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ο** *ho* (Ten) [[G3588]] [[T-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **δους** *dous* który dał [[G1325]] WTV-2AAP-NSM **ημιν** *hēmin* nam [[G2254]] WTP-1DP **τον** *ton* [[G3588]] [[T-ASM]] **αρραβωνα** *arrabōna* zadatek – porękę [[G728]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSN **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]]
###### **2Kor 5,6**
 **θαρρουντες** *tharrountes* Wykazując śmiałość – Mając odwagę [[G2292]] WTV-PAP-NPM **ουν** *oun* więc [[G3767]] [[CONJ]] **παντοτε** *pantote* zawsze – każdej chwili [[G3842]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **ειδοτες** *eidotes* wiedząc [[G1492]] WTV-RAP-NPM **οτι** *hoti* że [[G3754]] [[CONJ]] **ενδημουντες** *endēmountes* będąc w domu – będąc obywatelami [[G1736]] WTV-PAP-NPM **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **σωματι** *sōmati* ciele [[G4983]] WTN-DSN **εκδημουμεν** *ekdēmoumen* jesteśmy poza domem – jesteśmy poza obywatelstwem [[G1553]] WTV-PAI-1P **απο** *apo* od [[G575]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]]
###### **2Kor 5,7**
 **δια** *dia* Przez [[G1223]] [[PREP]] **πιστεως** *pisteōs* wiarę [[G4102]] [[N-GSF]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **περιπατουμεν** *peripatoumen* chodzimy – postępujemy [[G4043]] WTV-PAI-1P **ου** *ou* nie [[G3756]] [[PRT-N]] **δια** *dia* przez [[G1223]] [[PREP]] **ειδους** *eidous* widzenie – postrzeganie [[G1491]] [[N-GSN]]
###### **2Kor 5,8**
 **θαρρουμεν** *tharroumen* Wykazujemy śmiałość – Jesteśmy odważni [[G2292]] WTV-PAI-1P **δε** *de* zaś [[G1161]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **ευδοκουμεν** *eudokoumen* mamy upodobanie [[G2106]] WTV-PAI-1P **μαλλον** *mallon* raczej [[G3123]] [[ADV]] **εκδημησαι** *ekdēmēsai* znaleźć się poza domem – znaleźć się poza obywatelstwem [[G1553]] [[V-AAN]] **εκ** *ek* od [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **σωματος** *sōmatos* ciała [[G4983]] [[N-GSN]] **και** *kai* i [[G2532]] [[CONJ]] **ενδημησαι** *endēmēsai* być w domu – zostać obywatelami [[G1736]] [[V-AAN]] **προς** *pros* przy [[G4314]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **κυριον** *kyrion* Panu [[G2962]] [[N-ASM]]
###### **2Kor 5,9**
 **διο** *dio* Dlatego [[G1352]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **φιλοτιμουμεθα** *filotimoumetha* uważamy za szacowne [[G5389]] WTV-PNI-1P **ειτε** *eite* czy to [[G1535]] [[CONJ]] **ενδημουντες** *endēmountes* będąc w domu – będąc obywatelami [[G1736]] WTV-PAP-NPM **ειτε** *eite* czy to [[G1535]] [[CONJ]] **εκδημουντες** *ekdēmountes* będąc poza domem – będąc poza obywatelstwem [[G1553]] WTV-PAP-NPM **ευαρεστοι** *euarestoi* bardzo podobającymi się [[G2101]] WTA-NPM **αυτω** *autō* Jemu [[G846]] WTP-DSM **ειναι** *einai* być [[G1511]] WTV-PXN
###### **2Kor 5,10**
 **τους** *tous* [[G3588]] WTT-APM **γαρ** *gar* Bowiem [[G1063]] [[CONJ]] **παντας** *pantas* wszystkim [[G3956]] WTA-APM **ημας** *hēmas* nam [[G2248]] WTP-1AP **φανερωθηναι** *fanerōthēnai* zostać objawionymi – zostać uczyniony widocznymi [[G5319]] WTV-APN **δει** *dei* trzeba – jest konieczne [[G1163]] WTV-PQI-3S **εμπροσθεν** *emprosthen* przed [[G1715]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **βηματος** *bēmatos* trybuną – krzesłem sędziowskim [[G968]] [[N-GSN]] **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **κομισηται** *komisētai* dostałby – odebrałby [[G2865]] WTV-AMS-3S **εκαστος** *hekastos* każdy [[G1538]] [[A-NSM]] **τα** *ta* [[G3588]] WTT-APN **δια** *dia* poprzez [[G1223]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **σωματος** *sōmatos* ciało [[G4983]] [[N-GSN]] **προς** *pros* ze względu na [[G4314]] [[PREP]] **α** *ha* które [[G3739]] WTR-APN **επραξεν** *epraksen* zrobił – uczynił [[G4238]] [[V-AAI-3S]] **ειτε** *eite* czy to [[G1535]] [[CONJ]] **αγαθον** *agathon* dobre [[G18]] WTA-ASN **ειτε** *eite* czy to [[G1535]] [[CONJ]] **κακον** *kakon* złe [[G2556]] WTA-ASN
###### **2Kor 5,11**
 **ειδοτες** *eidotes* Znając [[G1492]] WTV-RAP-NPM **ουν** *oun* więc [[G3767]] [[CONJ]] **τον** *ton* [[G3588]] [[T-ASM]] **φοβον** *fobon* strach – bojaźń [[G5401]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ανθρωπους** *anthrōpous* ludzi [[G444]] [[N-APM]] **πειθομεν** *peithomen* przekonujemy [[G3982]] WTV-PAI-1P **θεω** *theō* Bogu [[G2316]] WTN-DSM **δε** *de* zaś [[G1161]] [[CONJ]] **πεφανερωμεθα** *pefanerōmetha* jesteśmy objawionymi – jesteśmy uczynieni widocznymi [[G5319]] WTV-RPI-1P **ελπιζω** *elpizō* mam nadzieję [[G1679]] WTV-PAI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **συνειδησεσιν** *syneidēsesin* sumieniach [[G4893]] WTN-DPF **υμων** *hymōn* waszych [[G5216]] WTP-2GP **πεφανερωσθαι** *pefanerōsthai* być objawionym – być uczyniony widocznym [[G5319]] WTV-RPN
###### **2Kor 5,12**
 **ου** *ou* Nie [[G3756]] [[PRT-N]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **παλιν** *palin* znowu [[G3825]] [[ADV]] **εαυτους** *heautous* siebie samych [[G1438]] WTF-3APM **συνιστανομεν** *synistanomen* polecamy [[G4921]] WTV-PAI-1P **υμιν** *hymin* wam [[G5213]] WTP-2DP **αλλα** *alla* ale [[G235]] [[CONJ]] **αφορμην** *aformēn* okazję [[G874]] WTN-ASF **διδοντες** *didontes* dając [[G1325]] WTV-PAP-NPM **υμιν** *hymin* wam [[G5213]] WTP-2DP **καυχηματος** *kauchēmatos* chluby [[G2745]] [[N-GSN]] **υπερ** *hyper* za [[G5228]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP **ινα** *hina* aby [[G2443]] [[CONJ]] **εχητε** *echēte* mielibyście [[G2192]] WTV-PAS-2P **προς** *pros* przeciw [[G4314]] [[PREP]] **τους** *tous* (tym) [[G3588]] WTT-APM **εν** *en* na [[G1722]] [[PREP]] **προσωπω** *prosōpō* twarzy – obliczu [[G4383]] WTN-DSN **καυχωμενους** *kauchōmenous* chlubiącym się – chełpiącym się [[G2744]] WTV-PNP-APM **και** *kai* a [[G2532]] [[CONJ]] **ου** *hou* nie [[G3756]] [[PRT-N]] **καρδια** *kardia* sercu [[G2588]] [[N-DSF]]
###### **2Kor 5,13**
 **ειτε** *eite* Czy to [[G1535]] [[CONJ]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εξεστημεν** *eksestēmen* doprowadziliśmy się do szału – stanęliśmy poza sobą [[G1839]] WTV-2AAI-1P **θεω** *theō* (dla) Boga [[G2316]] WTN-DSM **ειτε** *eite* czy to [[G1535]] [[CONJ]] **σωφρονουμεν** *sōfronoumen* zachowujemy rozsądek – jesteśmy przy zdrowych zmysłach [[G4993]] WTV-PAI-1P **υμιν** *hymin* (dla) was [[G5213]] WTP-2DP
###### **2Kor 5,14**
 **η** *hē* [[G3588]] [[T-NSF]] **γαρ** *gar* Bowiem [[G1063]] [[CONJ]] **αγαπη** *agapē* miłość [[G26]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **συνεχει** *synechei* przynagla – obejmuje [[G4912]] WTV-PAI-3S **ημας** *hēmas* nas [[G2248]] WTP-1AP **κριναντας** *krinantas* osądziwszy [[G2919]] WTV-AAP-APM **τουτο** *touto* to [[G5124]] WTD-ASN **οτι** *hoti* że [[G3754]] [[CONJ]] **ει** *ei* jeśli [[G1487]] WTCOND **εις** *heis* Jeden [[G1520]] [[A-NSM]] **υπερ** *hyper* za [[G5228]] [[PREP]] **παντων** *pantōn* wszystkich [[G3956]] WTA-GPM **απεθανεν** *apethanen* umarł [[G599]] WTV-2AAI-3S **αρα** *ara* zatem [[G686]] WTPRT **οι** *hoi* [[G3588]] WTT-NPM **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **απεθανον** *apethanon* umarli [[G599]] WTV-2AAI-3P
###### **2Kor 5,15**
 **και** *kai* A [[G2532]] [[CONJ]] **υπερ** *hyper* za [[G5228]] [[PREP]] **παντων** *pantōn* wszystkich [[G3956]] WTA-GPM **απεθανεν** *apethanen* umarł [[G599]] WTV-2AAI-3S **ινα** *hina* aby [[G2443]] [[CONJ]] **οι** *hoi* (ci) [[G3588]] WTT-NPM **ζωντες** *zōntes* żyjący [[G2198]] WTV-PAP-NPM **μηκετι** *mēketi* już więcej nie [[G3371]] [[ADV]] **εαυτοις** *heautois* (dla) siebie samych [[G1438]] WTF-3DPM **ζωσιν** *zōsin* żyliby [[G2198]] WTV-PAS-3P **αλλα** *alla* ale [[G235]] [[CONJ]] **τω** *tō* (dla Tego) [[G3588]] WTT-DSM **υπερ** *hyper* za [[G5228]] [[PREP]] **αυτων** *autōn* nich [[G846]] WTP-GPM **αποθανοντι** *apothanonti* który umarł [[G599]] WTV-2AAP-DSM **και** *kai* i [[G2532]] [[CONJ]] **εγερθεντι** *egerthenti* który został wzbudzony – który został podniesiony [[G1453]] WTV-APP-DSM
###### **2Kor 5,16**
 **ωστε** *hōste* Tak, że [[G5620]] [[CONJ]] **ημεις** *hēmeis* my [[G2249]] WTP-1NP **απο** *apo* od [[G575]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **νυν** *nyn* teraz [[G3568]] [[ADV]] **ουδενα** *oudena* nikogo [[G3762]] WTA-ASM **οιδαμεν** *oidamen* znamy [[G1492]] WTV-RAI-1P **κατα** *kata* według [[G2596]] [[PREP]] **σαρκα** *sarka* ciała [[G4561]] WTN-ASF **ει** *ei* jeśli [[G1487]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **εγνωκαμεν** *egnōkamen* poznaliśmy [[G1097]] WTV-RAI-1P **κατα** *kata* według [[G2596]] [[PREP]] **σαρκα** *sarka* ciała [[G4561]] WTN-ASF **χριστον** *christon* Pomazańca [[G5547]] [[N-ASM]] **αλλα** *alla* ale [[G235]] [[CONJ]] **νυν** *nyn* teraz [[G3568]] [[ADV]] **ουκετι** *ouketi* już nie [[G3765]] [[ADV]] **γινωσκομεν** *ginōskomen* znamy [[G1097]] WTV-PAI-1P
###### **2Kor 5,17**
 **ωστε** *hōste* Tak, że [[G5620]] [[CONJ]] **ει** *ei* jeśli [[G1487]] WTCOND **τις** *tis* ktoś [[G5100]] WTX-NSM **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **καινη** *kainē* nowe [[G2537]] WTA-NSF **κτισις** *ktisis* stworzenie [[G2937]] [[N-NSF]] **τα** *ta* [[G3588]] WTT-NPN **αρχαια** *archaia* dawne [[G744]] WTA-NPN **παρηλθεν** *parēlthen* przeminęło – przeszło [[G3928]] WTV-2AAI-3S **ιδου** *idou* oto [[G2400]] WTV-2AAM-2S **γεγονεν** *gegonen* stało się [[G1096]] WTV-2RAI-3S **καινα** *kaina* nowe [[G2537]] WTA-NPN **τα** *ta* [[G3588]] WTT-NPN **παντα** *panta* wszystkie [[G3956]] WTA-NPN
###### **2Kor 5,18**
 **τα** *ta* (To) [[G3588]] WTT-NPN **δε** *de* zaś [[G1161]] [[CONJ]] **παντα** *panta* wszystkie [[G3956]] WTA-NPN **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **του** *tou* [[G3588]] WTT-GSM **καταλλαξαντος** *katallaksantos* który pojednał – który pogodził [[G2644]] WTV-AAP-GSM **ημας** *hēmas* nas [[G2248]] WTP-1AP **εαυτω** *heautō* (z) sobą samym [[G1438]] WTF-3DSM **δια** *dia* przez [[G1223]] [[PREP]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **δοντος** *dontos* który dał [[G1325]] WTV-2AAP-GSM **ημιν** *hēmin* nam [[G2254]] WTP-1DP **την** *tēn* [[G3588]] WTT-ASF **διακονιαν** *diakonian* posługę – służbę [[G1248]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **καταλλαγης** *katallagēs* pojednania [[G2643]] [[N-GSF]]
###### **2Kor 5,19**
 **ως** *hōs* Jako [[G5613]] [[ADV]] **οτι** *hoti* że [[G3754]] [[CONJ]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ην** *ēn* był [[G2258]] [[V-IXI-3S]] **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **κοσμον** *kosmon* świat [[G2889]] [[N-ASM]] **καταλλασσων** *katallassōn* pojednujący – godzący [[G2644]] [[V-PAP-NSM]] **εαυτω** *heautō* (z) sobą samym [[G1438]] WTF-3DSM **μη** *mē* nie [[G3361]] [[PRT-N]] **λογιζομενος** *logizomenos* liczący [[G3049]] WTV-PNP-NSM **αυτοις** *autois* im [[G846]] WTP-DPM **τα** *ta* [[G3588]] WTT-APN **παραπτωματα** *paraptōmata* upadków – występków [[G3900]] WTN-APN **αυτων** *autōn* ich [[G846]] WTP-GPM **και** *kai* i [[G2532]] [[CONJ]] **θεμενος** *themenos* (Tym), który umieścił – (Tym), który położył [[G5087]] WTV-2AMP-NSM **εν** *en* w [[G1722]] [[PREP]] **ημιν** *hēmin* nas [[G2254]] WTP-1DP **τον** *ton* [[G3588]] [[T-ASM]] **λογον** *logon* Słowo [[G3056]] [[N-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **καταλλαγης** *katallagēs* pojednania [[G2643]] [[N-GSF]]
###### **2Kor 5,20**
 **υπερ** *hyper* W imieniu – Za [[G5228]] [[PREP]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **ουν** *oun* więc [[G3767]] [[CONJ]] **πρεσβευομεν** *presbeuomen* jesteśmy posłani – sprawujemy poselstwo [[G4243]] WTV-PAI-1P **ως** *hōs* jako [[G5613]] [[ADV]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **παρακαλουντος** *parakalountos* proszącego – zachęcającego [[G3870]] WTV-PAP-GSM **δι** *di* przez [[G1223]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP **δεομεθα** *deometha* prosimy [[G1189]] WTV-PNI-1P **υπερ** *hyper* w imieniu – za [[G5228]] [[PREP]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **καταλλαγητε** *katallagēte* zostańcie pojednanymi – zostańcie pogodzonymi [[G2644]] WTV-2APM-2P **τω** *tō* (z) [[G3588]] WTT-DSM **θεω** *theō* Bogiem [[G2316]] WTN-DSM
###### **2Kor 5,21**
 **τον** *ton* (Tego) [[G3588]] [[T-ASM]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **γνοντα** *gnonta* który poznał [[G1097]] WTV-2AAP-ASM **αμαρτιαν** *hamartian* grzechu [[G266]] WTN-ASF **υπερ** *hyper* za [[G5228]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP **αμαρτιαν** *hamartian* grzechem [[G266]] WTN-ASF **εποιησεν** *epoiēsen* uczynił [[G4160]] [[V-AAI-3S]] **ινα** *hina* aby [[G2443]] [[CONJ]] **ημεις** *hēmeis* my [[G2249]] WTP-1NP **γινωμεθα** *ginōmetha* stawalibyśmy się [[G1096]] WTV-PNS-1P **δικαιοσυνη** *dikaiosynē* sprawiedliwość [[G1343]] [[N-NSF]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εν** *en* w [[G1722]] [[PREP]] **αυτω** *autō* Nim [[G846]] WTP-DSM
