# 2Krl 6 BT5
###### **2Krl 6,1**
 Synowie proroccy powiedzieli do Elizeusza: «***Oto miejsce, w którym z tobą mieszkamy, jest za ciasne dla nas.***
###### **2Krl 6,2**
 ***Chcemy iść nad Jordan, i niech każdy stamtąd weźmie jedną belkę, abyśmy urządzili sobie schronienie, gdzie moglibyśmy zamieszkać!***» Odpowiedział: «***Idźcie!***»
###### **2Krl 6,3**
 Ktoś odezwał się: «***Racz, proszę, iść razem ze sługami twoimi***». Odpowiedział: «***Pójdę***»,
###### **2Krl 6,4**
 i poszedł z nimi. Przyszedłszy nad Jordan, ścinali drzewa.
###### **2Krl 6,5**
 Wówczas jednemu przy ścinaniu pnia siekiera wpadła do wody i on zawołał: «***Ach, panie! i to jeszcze pożyczona***».
###### **2Krl 6,6**
 Lecz mąż Boży zapytał: «***Gdzie wpadła?***» On zaś wskazał mu miejsce. Wtedy odłupał kawał drewna, wrzucił tam i sprawił, że siekiera wypłynęła.
###### **2Krl 6,7**
 I powiedział: «***Wyjmij [ją] sobie!***» On zaś wyciągnąwszy rękę, chwycił ją.
###### **2Krl 6,8**
 Król Aramu wojował z Izraelem. Odbył naradę ze swoimi sługami, oświadczając, że chce rozbić obóz w określonym miejscu.
###### **2Krl 6,9**
 Wtedy mąż Boży polecił powiedzieć królowi izraelskiemu: «***Strzeż się przechodzić przez owo miejsce, bo tamtędy schodzą Aramejczycy***».
###### **2Krl 6,10**
 Król izraelski posyłał [zwiadowcę] na to miejsce, które mąż Boży wskazywał mu wyraźnie, by tam był na czatach, i to wielokrotnie.
###### **2Krl 6,11**
 Przeraziło się serce króla Aramu z tego powodu. Zwołał więc sługi swoje i zapytał ich: «***Czemu nie wskazujecie mi, kto zdradza nas przed królem izraelskim?***»
###### **2Krl 6,12**
 Odpowiedział mu jeden ze sług jego: «***Nie jest tak, panie mój, królu! To Elizeusz, który jest prorokiem w Izraelu, oznajmia królowi izraelskiemu słowa, które ty wymawiasz w swoim pokoju sypialnym***».
###### **2Krl 6,13**
 Król zaś powiedział: «***Idźcie i zobaczcie, gdzie on się znajduje, a każę go ująć***». Doniesiono mu: «***Oto jest w Dotan***».
###### **2Krl 6,14**
 Wtedy wysłał tam konie, rydwany i silny oddział wojska. Wyruszyli w nocy i otoczyli miasto.
###### **2Krl 6,15**
 Kiedy sługa męża Bożego wstał rano i wyszedł, oto wojsko razem z końmi i rydwanami otaczało miasto. Wtedy sługa jego powiedział do niego: «***Ach, panie! Co zrobimy?***»
###### **2Krl 6,16**
 Odpowiedział: «***Nie lękaj się, bo liczniejsi są ci, co są z nami, aniżeli ci, którzy są z nimi***».
###### **2Krl 6,17**
 Potem Elizeusz modlił się tymi słowami: «***Panie! Racz otworzyć jego oczy, aby widział***». Pan otworzył oczy sługi, a on zobaczył: oto góra pełna była ognistych rumaków i rydwanów otaczających Elizeusza.
###### **2Krl 6,18**
 Kiedy [Aramejczycy] schodzili do niego, Elizeusz modlił się do Pana tymi słowami: «***Dotknij, proszę, tych ludzi ślepotą!***» I dotknął ich Pan ślepotą, zgodnie z prośbą Elizeusza.
###### **2Krl 6,19**
 Wtedy Elizeusz odezwał się do nich: «***To nie ta droga, to nie to miasto. Chodźcie za mną, a zaprowadzę was do człowieka, którego szukacie***». I zaprowadził ich do Samarii.
###### **2Krl 6,20**
 Kiedy weszli do Samarii, Elizeusz powiedział: «***Panie! Otwórz im oczy, aby widzieli***». Pan otworzył im oczy i zobaczyli, że są właśnie pośrodku Samarii.
###### **2Krl 6,21**
 Gdy tylko król izraelski ujrzał ich, powiedział do Elizeusza: «***Czy mam ich zabić, mój ojcze?***»
###### **2Krl 6,22**
 Odpowiedział: «***Nie zabijaj! Czy zabijasz tych, których pojmałeś swoim mieczem i swoim łukiem? Daj im chleba i wody, aby jedli i pili, a następnie wrócili do swego pana***».
###### **2Krl 6,23**
 Wtedy [król] zgotował im wielką ucztę. Kiedy się najedli i napili, odprawił ich, i odeszli do swojego pana. Odtąd już oddziały aramejskie nie robiły wypadów do kraju Izraela.
###### **2Krl 6,24**
 Potem Ben-Hadad, król Aramu, ściągnął całe wojsko, wyruszył i oblegał Samarię.
###### **2Krl 6,25**
 Powstał zatem wielki głód w Samarii. Bo oto nieprzyjaciele oblegali ją, tak iż głowa osła kosztowała osiemdziesiąt srebrnych syklów, a ćwiartka kaba dzikiej cebuli – pięć syklów srebra.
###### **2Krl 6,26**
 Kiedy król izraelski przechodził po murze, pewna kobieta zawołała do niego: «***Wspomóż mnie, panie mój, królu!***»
###### **2Krl 6,27**
 Odpowiedział: «***Pan ciebie nie wspomaga, z czego ja mam ciebie wspomóc? Czy z klepiska lub z tłoczni?***»
###### **2Krl 6,28**
 Następnie król rzekł do niej: «***Co ci jest?***» Odpowiedziała: «***Ta oto kobieta powiedziała mi: Daj twojego syna, a zjemy go dzisiaj, mojego zaś syna zjemy jutro.***
###### **2Krl 6,29**
 ***Ugotowałyśmy więc mojego syna i zjadłyśmy go. Następnego dnia powiedziałam do niej: Daj twego syna, żebyśmy go zjadły, lecz ona ukryła swojego syna***».
###### **2Krl 6,30**
 Kiedy król usłyszał słowa kobiety, rozdarł swoje szaty. Gdy zaś przechadzał się po murze, lud widział, że pod spodem nosił wór na swoim ciele.
###### **2Krl 6,31**
 Oświadczył wtedy: «***To niech mi uczyni Bóg i tamto dorzuci, jeżeli głowa Elizeusza, syna Szafata, ostanie się na nim dzisiaj!***»
###### **2Krl 6,32**
 Kiedy Elizeusz przebywał w swoim domu, a starszyzna siedziała razem z nim, król wysłał przed sobą człowieka. Lecz zanim posłaniec wszedł do Elizeusza, ten odezwał się do starszyzny: «***Czy widzicie, że ten syn zabójcy posłał [człowieka] po moją głowę? Uważajcie! W chwili gdy posłaniec będzie wchodził, zamknijcie drzwi i powstrzymajcie go nimi. Czyż za nim nie słychać odgłosów kroków jego pana?***»
###### **2Krl 6,33**
 Gdy jeszcze rozmawiał z nimi, oto król przystąpił do niego i powiedział: «***Patrz! To nieszczęście pochodzi od Pana. Dlaczego mam jeszcze nadzieję pokładać w Panu?***»
# 2Krl 6 PAU
###### **2Krl 6,1**
 Uczniowie proroków zwrócili się do Elizeusza z prośbą: „Miejsce, w którym mieszkamy i spotykamy się z tobą, jest dla nas za ciasne.
###### **2Krl 6,2**
 Pozwól, byśmy udali się nad Jordan. Każdy z nas weźmie tam jedną belkę i zbudujemy tam sobie bardziej odpowiednie mieszkanie”. Zgodził się na to, mówiąc: „Idźcie”.
###### **2Krl 6,3**
 Wtedy jeden z nich poprosił: „Czy nie zechciałbyś pójść ze swoimi sługami?”. On zaś odpowiedział: „Dobrze, pójdę”.
###### **2Krl 6,4**
 Udał się więc z nimi. Kiedy przybyli nad Jordan, zaczęli ścinać drzewa.
###### **2Krl 6,5**
 Wówczas jednemu z nich przy ścinaniu pnia siekiera wpadła do wody. „Ach, mój panie! - krzyknął. - Ona jest pożyczona!”.
###### **2Krl 6,6**
 Zapytał go człowiek Boży: „Gdzie wpadła?”. Pokazał mu to miejsce. On zaś odłupał kawałek drewna i rzucając go tam, spowodował wypłynięcie siekiery.
###### **2Krl 6,7**
 Wówczas rozkazał: „Wyjmij ją sobie”. Tamten wyciągnął rękę i złapał siekierę.
###### **2Krl 6,8**
 Król Aramu prowadził wojnę z Izraelem. Podczas narady ze swymi dowódcami postanowił: „W tym i tym miejscu będzie mój obóz”.
###### **2Krl 6,9**
 Ale człowiek Boży ostrzegł króla izraelskiego: „Trzymaj się z dala od tego miejsca, gdyż Aramejczycy mogą tam zaatakować”.
###### **2Krl 6,10**
 Król Izraela polecił sprawdzić to miejsce, o którym powiedział mu Boży człowiek i trzymał się od niego z daleka. Powtórzyło się to nie raz i nie dwa.
###### **2Krl 6,11**
 Taki obrót sprawy doprowadził króla Aramu do wściekłości. Zwołał swoich dowódców i zapytał ich: „Czy nie powiecie mi, kto z nas jest po stronie króla izraelskiego?”.
###### **2Krl 6,12**
 Odpowiedział jeden z oficerów: „Nie, mój panie, królu! To Elizeusz, prorok z Izraela, jest tym, który oznajmia królowi izraelskiemu wszystko, o czym mówisz nawet w swoim pokoju sypialnym”.
###### **2Krl 6,13**
 Rozkazał więc: „Idźcie i dowiedźcie się, gdzie on jest, a każę go schwytać”. Doniesiono królowi: „Znajduje się właśnie w Dotan”.
###### **2Krl 6,14**
 Wtedy wysłał tam silny oddział wojska, wyposażony w konie i rydwany. Przybyli tam w nocy i otoczyli miasto.
###### **2Krl 6,15**
 Kiedy sługa człowieka Bożego wstał wcześnie rano, zobaczył, że miasto otoczone jest wojskiem z końmi i rydwanami. Zawołał więc do niego: „Ach, panie mój, cóż teraz zrobimy?”.
###### **2Krl 6,16**
 Człowiek Boży odpowiedział jednak: „Nie bój się, gdyż tych, którzy są z nami, jest więcej od nich!”.
###### **2Krl 6,17**
 Elizeusz prosił w modlitwie: „PANIE, otwórz jego oczy, niech zobaczy!”. PAN otworzył oczy sługi i zobaczył górę pełną ognistych koni i rydwanów otaczających Elizeusza.
###### **2Krl 6,18**
 Gdy zaczęli zbliżać się do niego, Elizeusz modlił się do PANA: „Niech twoje dotknięcie oślepi ten lud!”. I rzeczywiście poraził ich ślepotą, zgodnie z prośbą Elizeusza.
###### **2Krl 6,19**
 A wtedy Elizeusz odezwał się do nich: „To nie ta droga ani nie to miasto! Chodźcie za mną, a zaprowadzę was do człowieka, którego szukacie”. I zaprowadził ich do Samarii.
###### **2Krl 6,20**
 Kiedy już weszli do Samarii, Elizeusz prosił PANA: „Otwórz oczy tych ludzi, niech zobaczą!”. I rzeczywiście PAN otworzył ich oczy i zobaczyli, że są w samym środku Samarii.
###### **2Krl 6,21**
 Gdy król izraelski ich zobaczył, zapytał Elizeusza: „Czy mam ich zabić, mój ojcze?”.
###### **2Krl 6,22**
 Odpowiedział: „Nie zabijaj! Czy to ty własnym mieczem lub łukiem wziąłeś ich do niewoli, abyś miał ich zabić? Daj im jeść i pić, niech się posilą, a potem odejdą do swojego pana”.
###### **2Krl 6,23**
 Przygotował więc dla nich wielką ucztę. A kiedy się najedli i napili, odesłał ich, a oni wrócili do swojego pana. Odtąd Aramejczycy przestali urządzać wyprawy do kraju Izraela.
###### **2Krl 6,24**
 Po jakimś czasie Ben-Hadad, król Aramu, zebrał całe swoje wojsko i wyruszył oblegać Samarię.
###### **2Krl 6,25**
 W Samarii nastał wtedy wielki głód. Z powodu przedłużającego się oblężenia doszło do tego, że głowa osła kosztowała aż osiemdziesiąt syklów srebra, a ćwierć kaba gołębiego nawozu - pięć syklów srebra.
###### **2Krl 6,26**
 Gdy któregoś razu król izraelski przechadzał się po murach obronnych, pewna kobieta zaczęła go błagać: „Pomóż mi, panie mój, królu!”.
###### **2Krl 6,27**
 On jednak odpowiedział: „Skoro PAN cię nie wspomaga, jak ja mam ci dopomóc? Z pustego klepiska lub tłoczni?”.
###### **2Krl 6,28**
 Zapytał ją król: „Co się stało?”. Odrzekła: „Oto ta kobieta powiedziała do mnie: «Zjedzmy dzisiaj twojego syna, a mojego syna zjemy jutro».
###### **2Krl 6,29**
 Ugotowałyśmy więc mojego syna i zjadłyśmy go. Następnego dnia powiedziałam do niej: «Daj teraz twojego syna, abyśmy go zjadły». Ona jednak ukryła swojego syna”.
###### **2Krl 6,30**
 Kiedy król usłyszał historię tej kobiety, rozdarł swoje szaty. Gdy król przechodził po murach obronnych, lud zobaczył, że nosi on pod spodem wór pokutny na gołym ciele.
###### **2Krl 6,31**
 Król poprzysiągł wówczas: „Niech Bóg mnie ciężko ukarze, jeśli głowa Elizeusza, syna Szafata, jeszcze dzisiaj nie zostanie ścięta!”.
###### **2Krl 6,32**
 Elizeusz natomiast siedział razem ze starszymi w swoim domu. Król zaś wysłał przed sobą jednego ze swoich urzędników. Zanim jednak posłaniec przybył do niego, Elizeusz rzekł do starszych: „Czy widzicie? Ten syn zabójcy posłał po moją głowę. Uważajcie, kiedy przyjdzie posłaniec, zamknijcie drzwi i nie dajcie mu wejść. Ale czyż nie słychać odgłosu kroków jego pana za nim?”.
###### **2Krl 6,33**
 Gdy jeszcze z nimi rozmawiał, posłaniec przybył do niego i powiedział: „Skoro to nieszczęście pochodzi od PANA, czy mogę nadal w PANU pokładać nadzieję?”.
# 2Krl 6 BP
###### **2Krl 6,1**
 Synowie proroków rzekli do Elizeusza: Oto miejsce, na którym my wraz z tobą mieszkamy, jest zbyt ciasne dla nas.
###### **2Krl 6,2**
 Pozwól, że pójdziemy aż nad Jordan, weźmiemy stamtąd każdy po jednej belce i zrobimy sobie tam miejsce na mieszkanie. Odpowiedział: Idźcie.
###### **2Krl 6,3**
 Ktoś poprosił: Racz pójść ze swoimi sługami. Odpowiedział: Ja pójdę.
###### **2Krl 6,4**
 I poszedł z nimi. Przyszli nad Jordan i ścinali drzewa.
###### **2Krl 6,5**
 I zdarzyło się, że jednemu [przy] ścinaniu belki siekiera wpadła do wody. Zaczął więc biadać i wołać: Ach! Panie mój... ona była pożyczona.
###### **2Krl 6,6**
 Mąż Boży zapytał: Gdzie wpadła? Wskazał mu miejsce. Uciął tedy [kawałek] drewna i rzucił tam. Żelazo wypłynęło.
###### **2Krl 6,7**
 [Wówczas] rzekł: Wyjmij [ją] sobie. Wyciągnął rękę i wziął ją.
###### **2Krl 6,8**
 Król Aramu prowadził wojnę z Izraelem. Naradził się ze swoimi podwładnymi mówiąc: W tym a w tym miejscu urządzę zasadzkę.
###### **2Krl 6,9**
 [Tymczasem] mąż Boży posłał do króla izraelskiego oznajmiając: Strzeż się przechodzić przez to miejsce, albowiem usadowili się tam Aramejczycy.
###### **2Krl 6,10**
 Król izraelski posłał [zwiadowcę] na to miejsce, o którym mówił mu mąż Boży, ostrzegając go i działał tam ostrożnie nie raz nie dwa.
###### **2Krl 6,11**
 Wzburzyło się serce króla Aramu na taki [obrót] sprawy, zawołał [przeto] swoich podwładnych i rzekł im: Czy nie wyjawicie mi, kto z naszych trzyma z królem izraelskim?
###### **2Krl 6,12**
 Jeden z jego podwładnych rzekł: Nie! Panie mój, królu. To Elizeusz, Prorok, który jest w Izraelu, oznajmia królowi izraelskiemu o tych sprawach, o których mówisz w swoim sypialnym pokoju.
###### **2Krl 6,13**
 Polecił więc: Idźcie i zobaczcie, gdzie on jest, a poślę i pojmę go. I dano mu znać mówiąc: Oto jest w Dotan.
###### **2Krl 6,14**
 Posłał więc tam konie, rydwany i silny [oddział] wojska. Przyszli w nocy i otoczyli miasto.
###### **2Krl 6,15**
 Sługa męża Bożego wstał rano i wyszedł. I oto [zobaczył] wojsko otaczające miasto, konie i rydwany. [Wówczas] sługa jego zawołał na niego: Ach! Panie mój, co zrobimy?
###### **2Krl 6,16**
 Odpowiedział: Nie bój się, bo więcej jest tych, którzy są z nami, niż [tych], którzy są z nimi.
###### **2Krl 6,17**
 Elizeusz pomodlił się i rzekł: Jahwe, otwórz jego oczy, aby zobaczył. Jahwe otwarł oczy chłopca i oto ujrzał górę pełną koni i ognistych rydwanów wokół Elizeusza.
###### **2Krl 6,18**
 Gdy [Aramejczycy] zeszli do niego, Elizeusz pomodlił się do Jahwe i rzekł: Dotknij tych ludzi ślepotą. I dotknął ich ślepotą według prośby Elizeusza.
###### **2Krl 6,19**
 Elizeusz rzekł im: To nie ta droga i nie to miasto. Chodźcie ze mną, a zaprowadzę was do tego męża, którego szukacie. I zaprowadził ich do Samarii.
###### **2Krl 6,20**
 Gdy weszli do Samarii, Elizeusz rzekł: Jahwe, otwórz ich oczy, aby zobaczyli. Jahwe otworzył ich oczy i oto ujrzeli, że są w środku Samarii.
###### **2Krl 6,21**
 Skoro król izraelski ich ujrzał, spytał Elizeusza: Czy mam ich zgładzić, mój ojcze?
###### **2Krl 6,22**
 Odpowiedział mu: Nie zabijaj! Czy wziąłeś ich w niewolę twoim mieczem i twoim łukiem, [abyś] ty zabijał? Połóż przed nimi chleb i wodę, aby się posilili, ugasili pragnienie i wrócili do swego pana.
###### **2Krl 6,23**
 Sprawił im więc wielką ucztę. A [gdy] zjedli i napili się, odprawił ich i poszli do swego pana. Bandy aramejskie przestały odtąd napadać na kraj Izraelitów.
###### **2Krl 6,24**
 Zdarzyło się potem, że Ben-Hadad, król Aramu, zebrał swoje wojsko, wyruszył i obległ Samarię.
###### **2Krl 6,25**
 W Samarii nastał wielki głód. Oto oblężenie jej stało się tak [dotkliwe], że głowa osła [kosztowała] osiemdziesiąt [syklów] srebra, a jedna czwarta kab bulwy pięć [syklów] srebra.
###### **2Krl 6,26**
 I stało się, gdy król izraelski obchodził mury, że [pewna] kobieta zawołała nań, prosząc: Panie mój, królu, ratuj!
###### **2Krl 6,27**
 Rzekł: Jahwe cię nie ratuje, czym ja cię poratuję, klepiskiem czy tłocznią?
###### **2Krl 6,28**
 I spytał jej król: O co ci [chodzi]? Odpowiedziała: Ta oto kobieta powiedziała mi: Daj twego syna, abyśmy go zjadły dzisiaj. Mojego syna zjemy jutro.
###### **2Krl 6,29**
 Ugotowałyśmy więc mojego syna i zjadłyśmy go. Następnego dnia rzekłam do niej: Daj twojego syna, zjemy go. Ale [ona] ukryła swojego syna.
###### **2Krl 6,30**
 Gdy król usłyszał słowa kobiety, rozdarł swoje szaty - obchodził on mury i lud zauważył, że oto pod spodem [nosi] wór na swoim ciele -
###### **2Krl 6,31**
 i rzekł: Niech mnie Bóg bardzo ciężko ukarze, jeśli głowa Elizeusza, syna Szafata ostoi się dzisiaj.
###### **2Krl 6,32**
 Elizeusz przebywał w swoim domu i starsi siedzieli z nim. [Król] posłał przed sobą człowieka. Zanim [ów] posłaniec wszedł do niego, rzekł on do starszych: Czy widzicie, że ten syn mężobójcy posłał, aby mi uciąć głowę? Patrzcie! Gdy nadejdzie posłaniec, zamknijcie drzwi i zatrzymajcie go przed drzwiami. Czyż nie [słychać] za nim kroków jego pana?
###### **2Krl 6,33**
 Jeszcze on mówił do nich, a oto król zszedł do niego i rzekł: Oto nieszczęście to pochodzi od Jahwe. Czegóż więcej mogę oczekiwać od Jahwe?
# 2Krl 6 BR
###### **2Krl 6,1**
 Uczniowie proroków powiedzieli do Elizeusza: Okazuje się, że miejsce, na którym zbieramy się wokół ciebie, jest dla nas za małe.
###### **2Krl 6,2**
 Przenieśmy się nad Jordan. Każdy wytnie tam przynajmniej jedno drzewo i zbudujemy sobie pomieszczenia, w których będziemy mogli mieszkać. Rzekł na to Elizeusz: Dobrze, idźcie!
###### **2Krl 6,3**
 A ktoś z nich powiedział: Zechciej i ty pójść ze swymi sługami! Odpowiedział: Dobrze, pójdę.
###### **2Krl 6,4**
 I poszedł z nimi. Kiedy przybyli nad Jordan, zaczęli ścinać drzewa.
###### **2Krl 6,5**
 W pewnej chwili jednemu ze ścinających drzewo siekiera [wymknęła się z ręki i] wpadła do wody. A on zawołał przerażony: Biada mi, panie mój! [Ta siekiera] była pożyczona!
###### **2Krl 6,6**
 Wtedy mąż Boży zapytał: Gdzie wpadła? A on wskazał miejsce. Odłupał tedy Elizeusz kawałek drzewa, wrzucił w to miejsce i oto siekiera wypłynęła na wierzch.
###### **2Krl 6,7**
 Powiedział Elizeusz: Weź ją sobie! A on wyciągnął rękę i wziął ją.
###### **2Krl 6,8**
 Król Aramejczyków prowadził wojnę z Izraelem. Pewnego razu, naradziwszy się ze swymi sługami, powiedział: Mój obóz będzie w tym a tym miejscu.
###### **2Krl 6,9**
 Lecz mąż Boży posłał kogoś do króla izraelskiego z ostrzeżeniem: Nie waż się przechodzić przez tę okolicę, bo tam właśnie udają się Aramejczycy!
###### **2Krl 6,10**
 Posłał tedy król izraelski swoich ludzi na miejsce wskazane przez męża Bożego, nakazując im, żeby się tam mieli ciągle na baczności.
###### **2Krl 6,11**
 Bardzo to zaniepokoiło króla Aramu. Zwołał więc ponownie wszystkie swoje sługi i zapytał: Powiedzcie mi, proszę, kto z was jest za królem izraelskim.
###### **2Krl 6,12**
 Na to jeden ze sług odpowiedział: Nikt, królu mój i panie. To Elizeusz, prorok izraelski, powtórzył królowi izraelskiemu to, co ty powiedziałeś w twojej sypialni.
###### **2Krl 6,13**
 Powiedział tedy król: Idźcie, dowiedzcie się, gdzie on jest, a ja wydam rozkaz, żeby go schwytano. I doniesiono mu wkrótce, że jest w Dotan.
###### **2Krl 6,14**
 Wysłał więc natychmiast konie, rydwany i silny oddział wojska, który dotarłszy nocą na miejsce, otoczył całe miasto.
###### **2Krl 6,15**
 Sługa męża Bożego wstał tego dnia wczesnym rankiem, a gdy wyszedł na zewnątrz, zobaczył całe miasto otoczone wojskiem, końmi i rydwanami. I powiedział sługa do Elizeusza: Ach, panie mój! Co my teraz zrobimy?
###### **2Krl 6,16**
 A on odpowiedział: Nie bój się wcale! Ci, co są z nami, są o wiele liczniejsi niż ci, co są z nimi.
###### **2Krl 6,17**
 I tak Elizeusz zaczął się modlić: Jahwe, otwórz mu oczy, żeby dobrze widział. I otworzył Jahwe oczy owego sługi, który zobaczył nagle, że na górze było pełno koni i rydwanów ognistych, a pośród nich znajdował się Elizeusz.
###### **2Krl 6,18**
 Kiedy Aramejczycy zbliżali się do męża Bożego, Elizeusz tak modlił się do Jahwe: Racz porazić ślepotą cały ten naród! I zesłał Jahwe na nich ślepotę, zgodnie ze słowami Elizeusza.
###### **2Krl 6,19**
 Elizeusz zaś im powiedział: To nie ta droga i nie to miasto. Chodźcie za mną, a ja was zaprowadzę do męża Bożego, którego szukacie. I zaprowadził ich do Samarii.
###### **2Krl 6,20**
 Kiedy zaś przyszli do Samarii, Elizeusz powiedział: Jahwe, otwórz oczy tym ludziom, żeby dobrze widzieli! I otworzył Jahwe ich oczy, i zobaczyli, że oto są w samym środku Samarii.
###### **2Krl 6,21**
 A król izraelski zobaczywszy ich zapytał Elizeusza: Czy mam ich zaatakować, ojcze mój? Czy mam na nich uderzyć?
###### **2Krl 6,22**
 Elizeusz zaś odpowiedział: Nie atakuj ich! Nie będziesz zabijał tych, których za pomocą miecza i łuku bierzesz do niewoli. Daj im chleba i wody, niech się najedzą i napiją, a potem niech wracają do swojego pana.
###### **2Krl 6,23**
 Urządził więc im król izraelski wielką ucztę, a gdy się najedli, pozwolił im odejść w spokoju. I udali się do swojego pana. Żadne zbrojne oddziały Aramejczyków nie zapuszczały się już więcej na ziemię izraelską.
###### **2Krl 6,24**
 W jakiś czas potem Ben-Hadad, król Aramejczyków, zebrał wszystkie swoje wojska, wyruszył na wojnę i rozpoczął oblężenie Samarii.
###### **2Krl 6,25**
 W Samarii zapanował wtedy wielki głód. Oblężenie bowiem było tak srogie, że za głowę osła dawano osiemdziesiąt sykli srebra, a za ćwierć kaba dzikiej cebuli - pięć sykli srebra.
###### **2Krl 6,26**
 Kiedy pewnego razu król obchodził mury, jakaś kobieta zaczęła wołać do niego:
###### **2Krl 6,27**
 Ratuj mnie, królu mój! A on odpowiedział: Jeżeli nawet Jahwe nie przychodzi ci na pomoc, to jakże ja mogę cię uratować? [Zbożem] z klepiska czy [oliwą] z tłoczni?
###### **2Krl 6,28**
 I zapytał król: Co ci jest? A ona odrzekła: Ta kobieta powiedziała, żebym dała na dziś do zjedzenia mojego syna, a jutro żebyśmy zjadły jej dziecko.
###### **2Krl 6,29**
 Ugotowałyśmy więc i zjadłyśmy mojego syna. Następnego dnia powiedziałam do niej, żeby dała do zjedzenia swoje dziecko. Ona jednak swojego syna ukryła.
###### **2Krl 6,30**
 Usłyszawszy to, co powiedziała kobieta, król rozdarł swoje szaty. Gdy król obchodził mury, ludzie widzieli, że miał on na sobie pod wierzchnią szatą wór pokutny.
###### **2Krl 6,31**
 Król zaś powiedział: Niech Bóg ześle na mnie wszystko, co najgorsze, jeżeli Elizeusz, syn Szafata, nie straci jeszcze dziś swojej głowy.
###### **2Krl 6,32**
 Tymczasem Elizeusz wraz ze starszymi, którzy siedzieli wokół niego, przebywał we własnym domu. Nagle pojawił się u niego wysłannik królewski. Zanim jednak przybył do niego wysłannik samego króla, Elizeusz powiedział do starszych: Czy wiecie, że ten syn mordercy posłał tu kogoś, żeby mnie pozbawił głowy? Miejcie się na baczności! Kiedy ów wysłannik przyjdzie, zamknijcie drzwi i nie wpuszczajcie go do domu. Ale za nim już można posłyszeć kroki jego pana.
###### **2Krl 6,33**
 Jeszcze im to mówił, gdy sam król stanął koło niego i powiedział: Patrz, wszystkie nieszczęścia pochodzą od Jahwe. Czyż mogę spodziewać się jeszcze czegoś dobrego od Jahwe?
# 2Krl 6 WUJ
###### **2Krl 6,1**
 I rzekli synowie proroccy do Elizeusza: Oto miejsce, na którem mieszkamy przed tobą, ciasne jest na nas.
###### **2Krl 6,2**
 Idźmy aż do Jordanu, a niechaj weźmie każdy z lasu po jednem drzewie, że tam sobie zbudujemy miejsce ku mieszkaniu. Który rzekł: Idźcie.
###### **2Krl 6,3**
 I rzekł jeden z nich: Pódźże i ty z sługami twemu Odpowiedział: Ja pójdę,
###### **2Krl 6,4**
 I poszedł z nimi. A gdy przyszli do Jordanu, rąbali drzewo.
###### **2Krl 6,5**
 I przydało się, iż gdy jeden rąbał drzewo, spadło żelazo z siekiery w wodę: a on zawołał, i rzekł: Ach, Ach, Ach, panie mój, i tegom samego był pożyczył.
###### **2Krl 6,6**
 I rzekł mąż Boży: Gdzie upadło? A on mu miejsce ukazał. Uciął tedy drewno i wpuścił tam: i wspłynęło żelazo.
###### **2Krl 6,7**
 I rzekł: Weźmisz. Który ściągnął rękę i wziął je.
###### **2Krl 6,8**
 A król Syryjski walczył przeciw Izraelowi, i naradził się z sługami swemi, rzekąc: Na tem a na tem miejscu połóżmy zasadzki.
###### **2Krl 6,9**
 Posłał tedy mąż Boży do króla Izraelskiego, mówiąc: Strzeż się, abyś nie przyszedł na ono miejsce: bo tam Syryanie są na zasadzce.
###### **2Krl 6,10**
 Posłał tedy król Izraelski na miejsce, które mu powiedział mąż Boży, i ubieżał je, i ostrzegł się tam nie raz ani dwa.
###### **2Krl 6,11**
 I zatrwożyło się serce króla Syryjskiego o tę rzecz: a zwoławszy sług swoich, rzekł im: Przecz mi nie powiecie kto zdrajcą moim jest u króla Izraelskiego?
###### **2Krl 6,12**
 I rzekł jeden z służebników jego: Nie, panie mój królu: ale Elizeusz prorok, który jest w Izraelu, oznajmuje królowi Izraelskiemu wszystkie słowa, którekolwiek mówisz na pokoju twoim.
###### **2Krl 6,13**
 I rzekł im: Idźcie a dowiedzcie się gdzieby był: że poślę a pojmam go. I powiedzieli mu, rzekąc: Oto jest w Dothan.
###### **2Krl 6,14**
 A tak posłał tam konie i wozy i siłę wojska: którzy, gdy przyjachali w nocy, obtoczyli miasto.
###### **2Krl 6,15**
 A wstawszy rano sługa męża Bożego, wyszedszy ujrzał wojsko około miasta i konie i wozy: i powiedział mu, rzekąc: Ach, ach, ach, panie mój, co uczyniemy?
###### **2Krl 6,16**
 A on odpowiedział: Nie bój się: bo więcej ich jest z nami, niźli z nimi.
###### **2Krl 6,17**
 A gdy się modlił Elizeusz, mówił: Panie otwórz oczy tego, że ujrzy. I otworzył Pan oczy służebnika i ujrzał, a ono góra pełna koni, i wozów ognistych około Elizeusza.
###### **2Krl 6,18**
 A nieprzyjaciele szli ku niemu, a Elizeusz modlił się do Pana mówiąc: Zaraź proszę ten lud ślepotą. I zaraził je Pan, aby nie widzieli według słowa Elizeuszowego.
###### **2Krl 6,19**
 I rzekł do nich Elizeusz: Nie taś jest droga, ani to jest miasto: Pódźcie za mną: a ukażę wammęża, którego szukacie. Wwiódł je tedy do Samariiej.
###### **2Krl 6,20**
 A gdy weszli do Samariiej, rzekł Elizeusz: Panie otwórz oczy tych, aby przejrzeli. I otworzył oczy ich, i ujrzeli, że byli w pośrodku Samariiej.
###### **2Krl 6,21**
 I rzekł król Izraelski do Elizeusza, ujrzawszy je: Mamże je pobić, ojcze mój?
###### **2Krl 6,22**
 A on rzekł: Nie pobijesz: boś ich nie pojmał mieczem i łukiem twoim, abyś miał pobić, ale połóż chleb i wodę przed nie, aby jedli i pili, i szli do pana swego.
###### **2Krl 6,23**
 I położono przed nimi potraw wielkie przygotowanie i jedli i pili, i puścił je, i poszli do pana swego: i nie przyszli więcej łotrowie Syryjscy do ziemie Izraelskiej.
###### **2Krl 6,24**
 I stało się potem, zebrał Benadad król Syryjski wszystko wojsko swe, i wyciągnął, a obiegł Samaryą.
###### **2Krl 6,25**
 I był głód wielki w Samariiej: i tak długo była w oblężeniu, aż przędąwano głowę oślą po ośmdziesiąt srebrników, a czwarta część miary gnoju gołębiego po piąci srebrników.
###### **2Krl 6,26**
 A gdy król Izraelski szedł po murze, zawołała nań jedna niewiasta mówiąc: Ratuj mię panie mój królu.
###### **2Krl 6,27**
 Który rzekł: Nie ratuje cię Pan, zkąd ciebie ratować mogę? z gumna abo z prasy? I rzekł do niej król: Czegóż chcesz? Która odpowiedziała:
###### **2Krl 6,28**
 Ta niewiasta mówiła mi: Daj syna twego, że go zjemy dzisia, a syna mego zjemy jutro.
###### **2Krl 6,29**
 A tak uwarzyliśmy syna mego, i zjedliśmy. I rzekłam jej nazajutrz: Daj syna twego, że go zjemy. Która skryła syna swego.
###### **2Krl 6,30**
 Co gdy król usłyszał, rozdarł szaty swoje, i szedł po murze: i widział wszystek lud włosiennicę, którą odziany był na ciele od spodku.
###### **2Krl 6,31**
 I rzekł król: To mi niech Bóg uczyni i to niech przyczyni, jeśli się zostoi głowa Elizeusza syna Saphat dzisia na nim.
###### **2Krl 6,32**
 A Elizeusz siedział w domu swym, i starcy siedzieli z nim. Przesłał tedy męża: a pierwej niż on poseł przyszedł, rzekł do starców: A wiecież, że ten syn mężobójce posłał, aby ucięto głowę moję? A tak patrzcie, gcly przyjdzie posłaniec, zamkniecie drzwi, a nie dajcie mu wnijść: bo oto tętnanie nóg pana jego jest za nim.
###### **2Krl 6,33**
 A gdy jeszcze mówił do nich, ukazał się posłaniec, który szedł do niego. I rzekł: Oto tak wielkie złe od Pana jest: Czegóż mam więcej czekać od Pana?
