# Ga 5 BT5
###### **Ga 5,1**
 Ku wolności wyswobodził nas Chrystus. A zatem trwajcie w niej i nie poddawajcie się na nowo pod jarzmo niewoli!
###### **Ga 5,2**
 Oto ja, Paweł, mówię wam: Jeżeli poddacie się obrzezaniu, Chrystus wam się na nic nie przyda.
###### **Ga 5,3**
 I raz jeszcze oświadczam każdemu człowiekowi, który poddaje się obrzezaniu: jest on zobowiązany zachować wszystkie przepisy Prawa.
###### **Ga 5,4**
 Zerwaliście z Chrystusem wszyscy, którzy szukacie usprawiedliwienia w Prawie; wypadliście z łaski.
###### **Ga 5,5**
 My zaś z pomocą Ducha dzięki wierze wyczekujemy spodziewanej sprawiedliwości.
###### **Ga 5,6**
 Albowiem w Chrystusie Jezusie ani obrzezanie, ani jego brak nie mają żadnego znaczenia, tylko wiara, która działa przez miłość.
###### **Ga 5,7**
 Biegliście tak wspaniale! Kto wam przeciął drogę trwania przy prawdzie?
###### **Ga 5,8**
 Wpływ ten nie pochodzi od Tego, który was powołuje.
###### **Ga 5,9**
 Trochę kwasu zakwasza całe ciasto.
###### **Ga 5,10**
 Mam co do was ufność w Panu, że innego zdania niż ja nie będziecie. A na tym, który sieje między wami zamęt, zaciąży wyrok potępienia, kimkolwiek by on był.
###### **Ga 5,11**
 Co do mnie zaś, bracia, jeśli nadal głoszę obrzezanie, to dlaczego w dalszym ciągu jestem prześladowany? Przecież wtedy ustałoby zgorszenie krzyża.
###### **Ga 5,12**
 Bodajby się do końca okaleczyli ci, którzy was podburzają.
###### **Ga 5,13**
 Wy zatem, bracia, powołani zostaliście do wolności. Tylko nie [bierzcie] tej wolności jako zachęty do [hołdowania] ciału, wręcz przeciwnie, miłością ożywieni służcie sobie wzajemnie.
###### **Ga 5,14**
 Bo całe Prawo wypełnia się w tym jednym nakazie: Będziesz miłował bliźniego swego jak siebie samego.
###### **Ga 5,15**
 A jeśli u was jeden drugiego kąsa i pożera, baczcie, byście się wzajemnie nie zjedli.
###### **Ga 5,16**
 Oto, czego uczę: postępujcie według ducha, a nie spełnicie pożądania ciała.
###### **Ga 5,17**
 Ciało bowiem do czego innego dąży niż duch, a duch do czego innego niż ciało, i stąd nie ma między nimi zgody, tak że nie czynicie tego, co chcecie.
###### **Ga 5,18**
 Jeśli jednak pozwolicie się prowadzić duchowi, nie będziecie podlegać Prawu.
###### **Ga 5,19**
  Jest zaś rzeczą wiadomą, jakie uczynki rodzą się z ciała: nierząd, nieczystość, wyuzdanie,
###### **Ga 5,20**
 bałwochwalstwo, czary, nienawiść, spory, zawiść, gniewy, pogoń za zaszczytami, niezgoda, rozłamy,
###### **Ga 5,21**
 zazdrość, pijaństwo, hulanki i tym podobne. Co do nich zapowiadam wam, jak to już zapowiedziałem: ci, którzy się takich rzeczy dopuszczają, królestwa Bożego nie odziedziczą.
###### **Ga 5,22**
 Owocem zaś Ducha jest: miłość, radość, pokój, cierpliwość, uprzejmość, dobroć, wierność,
###### **Ga 5,23**
 łagodność, opanowanie. Przeciw takim [cnotom] nie ma Prawa.
###### **Ga 5,24**
 A ci, którzy należą do Chrystusa Jezusa, ukrzyżowali ciało swoje z jego namiętnościami i pożądaniami.
###### **Ga 5,25**
 Mając życie od Ducha, do Ducha się też stosujmy.
###### **Ga 5,26**
 Nie szukajmy próżnej chwały, jedni drugich drażniąc i wzajemnie sobie zazdroszcząc.
# Ga 5 PAU
###### **Ga 5,1**
 Chrystus nas wyzwolił, abyśmy byli wolni. Bądźcie mocni i nie dajcie sobie na nowo nałożyć jarzma niewoli.
###### **Ga 5,2**
 Mówię wam ja - Paweł: Jeśli poddacie się obrzezaniu, Chrystus na nic się wam nie przyda.
###### **Ga 5,3**
 Jeszcze raz powiadam każdemu, kto poddaje się obrzezaniu: jest zobowiązany zachować wszystkie przepisy Prawa.
###### **Ga 5,4**
 Wy, którzy szukacie usprawiedliwienia w Prawie, odstąpiliście od Chrystusa i utraciliście łaskę.
###### **Ga 5,5**
 Natomiast my w Duchu spodziewamy się usprawiedliwienia dzięki wierze.
###### **Ga 5,6**
 Bo w Chrystusie Jezusie ani obrzezanie nic nie znaczy, ani nieobrzezanie, ale wiara wyrażająca się w miłości.
###### **Ga 5,7**
 Biegliście tak wspaniale! Kto wam przeszkodził w podążaniu za prawdą?
###### **Ga 5,8**
 Taki wpływ nie pochodzi od Tego, który was powołał.
###### **Ga 5,9**
 Odrobina zaczynu zakwasza całe ciasto.
###### **Ga 5,10**
 Mam ufność w Panu, że nie będziecie innego zdania niż ja. Ten zaś, kto sieje wśród was zamęt, kimkolwiek jest, zostanie osądzony.
###### **Ga 5,11**
 Bracia, jeśli ja nadal głoszę obrzezanie, to dlaczego jestem prześladowany? Przecież krzyż nie byłby wtedy powodem sprzeciwu!
###### **Ga 5,12**
 Niechby do końca okaleczyli się ci, co sieją wśród was zamęt.
###### **Ga 5,13**
 Wy zatem, bracia, zostaliście powołani do wolności. Tylko nie pojmujcie tej wolności jako zachęty do hołdowania ciału, lecz służcie sobie nawzajem z miłością.
###### **Ga 5,14**
 Przecież całe Prawo zawiera się w tym jednym nakazie: Miłuj bliźniego jak siebie samego.
###### **Ga 5,15**
 Jeśli natomiast jeden drugiego kąsa i pożera, uważajcie, abyście się wzajemnie nie zjedli.
###### **Ga 5,16**
 Otóż powiadam: Postępujcie według Ducha, a nie będziecie spełniali pożądań ciała.
###### **Ga 5,17**
 Gdyż ciało pożąda wbrew Duchowi, natomiast Duch przeciwko ciału. Jedno przeciwstawia się drugiemu, tak że czynicie nie to, co chcecie.
###### **Ga 5,18**
 Jeśli jednak Duch was prowadzi, nie jesteście pod Prawem.
###### **Ga 5,19**
 Uczynki ciała są wiadome: cudzołóstwo, nieczystość, rozwiązłość,
###### **Ga 5,20**
 bałwochwalstwo, czary, nienawiść, kłótnie, zazdrość, gniew, chorobliwa ambicja, waśnie, rozłamy,
###### **Ga 5,21**
 zawiść, pijaństwo, hulanki i tym podobne. Dlatego powtarzam to, o czym mówiłem już wcześniej: Ci, co tak postępują, nie posiądą królestwa Bożego.
###### **Ga 5,22**
 Natomiast owocem Ducha jest: miłość, radość, pokój, cierpliwość, dobroć, życzliwość, wierność,
###### **Ga 5,23**
 łagodność, opanowanie. Prawo tu nie jest potrzebne.
###### **Ga 5,24**
 A ci, którzy należą do Chrystusa Jezusa, ukrzyżowali swoje ciało razem z namiętnościami i pożądliwościami.
###### **Ga 5,25**
 Skoro więc żyjemy mocą Ducha, postępujmy według Ducha.
###### **Ga 5,26**
 Nie szukajmy próżnej chwały, kłócąc się i zazdroszcząc sobie nawzajem.
# Ga 5 BP
###### **Ga 5,1**
 Chrystus wyprowadził nas z niewoli na wolność. Trwajcie więc w niej i nie pozwólcie ponownie nałożyć sobie jarzma niewoli.
###### **Ga 5,2**
 Oto ja, Paweł, mówię wam: jeśli teraz pozwolicie się obrzezać, Chrystus nic wam nie pomoże.
###### **Ga 5,3**
 Ponownie oświadczam każdemu człowiekowi, który pozwala się obrzezać: Jest on zobowiązany zachować wszystkie przepisy Prawa.
###### **Ga 5,4**
 Nie macie nic wspólnego z Chrystusem, wy wszyscy, którzy usiłujecie szukać usprawiedliwienia w Prawie. Utraciliście łaskę.
###### **Ga 5,5**
 My bowiem dzięki Duchowi przez wiarę wyczekujemy spodziewanego usprawiedliwienia.
###### **Ga 5,6**
 W Chrystusie Jezusie bowiem nie ma znaczenia ani obrzezanie, ani jego brak, lecz liczy się wiara ujawniająca swą moc dzięki miłości.
###### **Ga 5,7**
 Biegliście pięknie! Któż wam przeszkodził trwać w posłuszeństwie wobec prawdy?
###### **Ga 5,8**
 Wpływ ten nie pochodzi od Tego, który was wzywa.
###### **Ga 5,9**
 Mała ilość kwasu zakwasza całe ciasto.
###### **Ga 5,10**
 Ja ufam w Panu, że wy wcale inaczej nie myślicie. Ten zaś, kto rozsiewa zamęt wśród was - kimkolwiek on jest - poniesie zasłużoną karę.
###### **Ga 5,11**
 Ja natomiast, bracia, jeżeli rzekomo głoszę obrzezanie, to dlaczego jestem jeszcze prześladowany? Przecież ustałoby wówczas zgorszenie płynące z krzyża.
###### **Ga 5,12**
 Oby już całkowicie okaleczyli się ci, którzy was podburzają!
###### **Ga 5,13**
 Wy bowiem, bracia, do wolności zostaliście powołani, ale nie do tej wolności, która służy naturalnym skłonnościom ludzkim, lecz która - ożywiona miłością - każe wzajemnie sobie usługiwać.
###### **Ga 5,14**
 Całe bowiem Prawo wypełnia się w tym jednym nakazie: "Będziesz miłował bliźniego twego jak siebie samego".
###### **Ga 5,15**
 Jeśli bowiem wzajemnie się kąsacie i pożeracie, to uważajcie, abyście się nawzajem nie zjedli.
###### **Ga 5,16**
 I powiadam: Postępujcie zgodnie z duchem i nie schlebiajcie pragnieniom ciała.
###### **Ga 5,17**
 Ciało bowiem żywi pragnienia przeciwne duchowi, duch natomiast pragnie czego innego niż ciało - tak bardzo są sobie przeciwstawne - i dlatego czynicie to, czego nie chcecie.
###### **Ga 5,18**
 Jeżeli jednak duch wami kieruje, nie jesteście pod panowaniem Prawa.
###### **Ga 5,19**
 Czyny wywodzące się z ciała są znane: cudzołóstwo, nieczystość, rozpusta,
###### **Ga 5,20**
 bałwochwalstwo, magia, nienawiść, kłótnia, zawiść, gniewy, ambicje, niezgody, rozłamy,
###### **Ga 5,21**
 zazdrości, pijaństwo, hulanki i tym podobne. Zapowiadam wam, jak to już dawniej czyniłem, że ci, którzy takie czyny popełniają, królestwa Bożego nie odziedziczą.
###### **Ga 5,22**
 Owoc zaś wywodzący się z ducha to: miłość radość, pokój, cierpliwość, dobroć, życzliwość, wierność,
###### **Ga 5,23**
 łagodność, opanowanie. Dla tych, którzy to wszystko czynią, Prawo nie istnieje.
###### **Ga 5,24**
 Ci zaś, którzy stanowią jedność z Chrystusem Jezusem, ukrzyżowali ciało razem z namiętnościami i pożądaniami.
###### **Ga 5,25**
 Jeśli żyjemy dzięki Duchowi, postępujemy również zgodnie ze wskazaniami Ducha.
###### **Ga 5,26**
 Nie ubiegajmy się o próżną chwałę, wzajemnie się zwalczając i wzajemnie sobie zazdroszcząc.
# Ga 5 BR
###### **Ga 5,1**
 Chrystus nas oswobodził po to, żebyśmy byli rzeczywiście wolni. Trwajcie więc w tej wolności i uważajcie, żeby nie popaść na nowo w niewolę.
###### **Ga 5,2**
 Słuchajcie, co wam powiem ja, Paweł: jeżeli poddacie się obrzezaniu, to [będzie znaczyło, że] Chrystus na nic wam się nie przyda.
###### **Ga 5,3**
 Jeszcze raz powtarzam: Każdy, kto poddaje się obrzezaniu, tym samym jest obowiązany przestrzegać wszystkich przepisów Prawa.
###### **Ga 5,4**
 Zerwaliście więzy z Chrystusem wy wszyscy, którzy pragnęliście osiągnąć usprawiedliwienie przez wypełnianie nakazów Prawa; sami pozbawiacie się łaski Bożej.
###### **Ga 5,5**
 My natomiast, wspierani przez Ducha, ufamy, że dzięki naszej wierze dostąpimy usprawiedliwienia.
###### **Ga 5,6**
 Jeżeli bowiem stanowimy jedno z Jezusem Chrystusem, to ani obrzezanie, ani jego brak nie mają żadnego znaczenia. Liczy się jedynie wiara, owocująca czynami miłości.
###### **Ga 5,7**
 Rozpoczęliście tak pięknie wasze nowe życie! Któż to zabrania wam iść za głosem prawdy?
###### **Ga 5,8**
 Na pewno nie Ten, który was powołuje.
###### **Ga 5,9**
 [A wiecie przecież, że] odrobina kwasu może zakwasić wielką masę ciasta.
###### **Ga 5,10**
 Mimo wszystko Pan umacnia mnie w przekonaniu, że nie będziecie innego zdania niż ja. Na tego zaś, który próbuje siać między wami zamieszanie, spadnie wyrok potępienia, bez względu na to, kim by on był.
###### **Ga 5,11**
 Gdy zaś chodzi o mnie, to dlaczego jestem prześladowany, bracia, jeśli twierdzę [jak mnie o to oskarżają], że obrzezanie jest nadal konieczne do usprawiedliwienia? Wobec tego głoszona przeze mnie nauka o krzyżu nie powinna już budzić żadnego zgorszenia.
###### **Ga 5,12**
 Wypadałoby, żeby się już do końca okaleczyli ci, którzy sieją między wami zamęt.
###### **Ga 5,13**
 Natomiast wy, bracia, zostaliście powołani do wolności. Lecz niech wam ta wolność nie służy za pretekst do ulegania pożądaniom waszego ciała. Przeciwnie, ożywieni miłością służcie jedni drugim.
###### **Ga 5,14**
 Wszystkie bowiem nakazy Prawa streszczają się w tym jednym przykazaniu: Będziesz miłował bliźniego swego jak siebie samego.
###### **Ga 5,15**
 Ale jeżeli wy gryziecie się nawzajem i pożeracie jedni drugich, to uważajcie, byście się nie doprowadzili do całkowitej zguby.
###### **Ga 5,16**
 A teraz posłuchajcie, co wam powiem: Starajcie się, by Duch [Boży] kierował waszym postępowaniem, a nie ulegajcie pożądaniom ciała.
###### **Ga 5,17**
 Pożądania naszego ciała są bowiem sprzeczne z tym, czego żąda od nas Duch; to zaś, czego żąda Duch, wyklucza pożądanie ciała; tak więc Duch pozostaje w ustawicznej sprzeczności z tym, do czego odczuwa pociąg ciało. I dlatego nie możecie czynić czegoś [jedynie] dlatego, że odczuwacie ku temu pociąg.
###### **Ga 5,18**
 Jeżeli zaś postępowaniem waszym kieruje Duch [Święty], to już nie znajdujecie się w niewoli Prawa.
###### **Ga 5,19**
 Wiadomo przecież powszechnie, jakie to uczynki wywodzą się z pożądliwości ciała: nierząd, nieczystość, wszelkie wyuzdanie,
###### **Ga 5,20**
 bałwochwalstwo i czary, nienawiść jednych do drugich, spory, zawiści, brak opanowania, pycha, niezgoda, rozłamy,
###### **Ga 5,21**
 zazdrości, pijaństwo, hulatyki i tym podobne. Otóż ostrzegam was tak samo stanowczo, jak już to kiedyś czyniłem: nikt z tych, którzy dopuszczają się tych występków, nie otrzyma w nagrodę królestwa Bożego.
###### **Ga 5,22**
 Z ulegania zaś Duchowi [Świętemu] rodzi się: miłość, radość, pokój, cierpliwość, łaskawość, dobroć, wierność,
###### **Ga 5,23**
 łagodność, opanowanie. Rzecz jasna, że temu wszystkiemu nie sprzeciwia się [żadne] Prawo.
###### **Ga 5,24**
 Ci, którzy przynależą do Jezusa Chrystusa, sprawiają, że wszystkie pożądliwości i grzeszne pragnienia ich ciała są niejako współprzybijane [z ciałem Jezusa] do krzyża.
###### **Ga 5,25**
 Jeżeli Duch [Boży] jest dawcą naszego życia, to powinniśmy postępować zgodnie z wymaganiami Ducha.
###### **Ga 5,26**
 Nie szukajmy tedy próżnej chwały, przestańmy drażnić się nawzajem i zazdrościć jedni drugim.
# Ga 5 WUJ
###### **Ga 5,1**
 Stójcie: a nie bądźcie znowu pod jarzmem niewolej.
###### **Ga 5,2**
 Oto ja Paweł powiadam wam, iż jeśli będziecie obrzezani, Chrystus wam nic nie pomoże.
###### **Ga 5,3**
 A oświadczam się zasię każdemu człowiekowi obrzezującemu się, iż powinien jest wszystek zakon pełnić.
###### **Ga 5,4**
 Wyniszczeni jesteście z Chrystusa, którzy w zakonie się usprawiedliwiacie, z łaskiście wypadli.
###### **Ga 5,5**
 Abowiem my Duchem, z wiary, nadzieje sprawiedliwości oczekawamy.
###### **Ga 5,6**
 Bo w Chrystusie Jezusa nic nie waży ani obrzezanie, ani odrzezek, ale wiara, która przez miłość działa.
###### **Ga 5,7**
 Bieżeliście dobrze: kto wam przekaził, abyście nie byli posłusznymi prawdzie?
###### **Ga 5,8**
 Namowa ta nie jest z tego, który was wzywa.
###### **Ga 5,9**
 Trocha kwasu wszystko ciasto kwasi.
###### **Ga 5,10**
 Ja dufam o was w Panie, iż nic inszego rozumieć nie będziecie: a ten, który wami trwoży, odniesie sąd, któryżkolwiek on jest.
###### **Ga 5,11**
 A ja bracia, jeśli jeszcze obrzezanie opowiadam: czemuż jeszcze prześladowanie cierpię? Tedy wyniszczone jest zgorszenie krzyżowe.
###### **Ga 5,12**
 Bodajże i odcięci byli, którzy was wzruszają.
###### **Ga 5,13**
 Abowiem wy wezwani jesteście ku wolności bracia: tylko ażebyście wolności nie obracali na pobudkę ciału: ale przez miłość ducha służcie jeden drugiemu.
###### **Ga 5,14**
 Bo wszystek zakon w jednej się mowie wypełnia: Będziesz miłował bliźniego twego jako samego siebie.
###### **Ga 5,15**
 Lecz jeśli jeden drugiego kąsacie i jecie, patrzcie, aby jeden drugiego nie zjadł.
###### **Ga 5,16**
 A mówię: Duchem chodźcie, a pożądliwości ciała nie wypełnicie.
###### **Ga 5,17**
 Abowiem ciało pożąda przeciwko duchowi, a duch przeciw ciału. Bo te się sobie wzajem sprzeciwiają: abyście nie cokolwiek chcecie to czynili.
###### **Ga 5,18**
 A jeśli duchem bywacie rządzeni, nie jesteście pod zakonem.
###### **Ga 5,19**
 A jawne są uczynki ciała, które są, porubstwo, nieczystość, niewstydliwość, wszeteczeństwo:
###### **Ga 5,20**
 Bałwochwalstwo czarowania, nieprzyjaźni, swary, zawiści, gniewy, niesnaski, rozterki, kacerstwa:
###### **Ga 5,21**
 Zazdrości, mężobójstwa, pijaństwa, biesiady, i tym podobne. O których opowiadam wam, jakom przedtem opowiedział, iż którzy takowe rzeczy czynią, królestwa Bożego nie dostąpią.
###### **Ga 5,22**
 A owoc Ducha jest, miłość, wesele, pokój, cierpliwość, dobrotliwość, dobroć, nieskwapliwość,
###### **Ga 5,23**
 Cichość, wiara, skromność, wstrzemięźliwość, czystość. Przeciwko takowym nie masz zakonu.
###### **Ga 5,24**
 A którzy są Chrystusowi, ciało swe ukrzyżowali z namiętnościami i z pożądliwościami.
###### **Ga 5,25**
 Jeśli żywiemy duchem, duchem i postępujmy.
###### **Ga 5,26**
 Nie stawajmy się chciwi próżnej chwały, jedni drugich drażniąc, jedni drugim zajrząc.
# Ga 5 STERN
###### **Ga 5,1**
 Mesjasz wyswobodził nas do wolności! Dlatego trwajcie niewzruszenie i nie pozwólcie na nowo spętać się jarzmem niewoli.
###### **Ga 5,2**
 Zważcie na moje słowa - ja, Sza'ul, powiadam wam, że jeśli poddacie się b'rit-mili, to Mesjasz nie przyniesie wam żadnej korzyści!
###### **Ga 5,3**
 Ostrzegam was ponownie: każdy, kto poddaje się b'rit-mili, jest zobowiązany zachowywać całą Torę!
###### **Ga 5,4**
 Wy, którzy przez legalizm usiłujecie dostąpić tego, aby was Bóg ogłosił sprawiedliwymi, oderwaliście się od Mesjasza! Odpadliście od Bożej łaski!
###### **Ga 5,5**
 Gdyż to mocą Ducha, który działa w nas, bo ufamy i jesteśmy wierni, z pełnym zaufaniem wyczekujemy spełnienia naszej nadziei dostąpienia sprawiedliwości.
###### **Ga 5,6**
 Kiedy jesteśmy zjednoczeni z Mesjaszem Jeszuą, nie liczy się ani obrzezanie, ani nieobrzezanie - liczy się ufna wierność, wyrażająca się przez miłość.
###### **Ga 5,7**
 Dobrze biegliście w wyścigach - kto zahamował wasze podążanie za prawdą?
###### **Ga 5,8**
 Wszelkie środki perswazji, jakich użył, nie pochodziły od Tego, który was powołuje.
###### **Ga 5,9**
 "Do zakwaszenia całej partii ciasta wystarczy odrobina chamecu".
###### **Ga 5,10**
 Ufam, że ponieważ jesteście zjednoczeni z Panem, nie będziecie innego zdania, i ufam, że ten, kto was niepokoi, kimkolwiek jest, będzie musiał ponieść karę.
###### **Ga 5,11**
 Co zaś do mnie, bracia, jeśli nadal głoszę, że obrzezanie jest konieczne, to czemu nadal jestem prześladowany? Bo gdyby tak było, moje głoszenie o palu egzekucyjnym nie wywołałoby żadnego zgoła zgorszenia.
###### **Ga 5,12**
 Niechby ci, którzy was niepokoją, poszli tą drogą do końca i wykastrowali się!
###### **Ga 5,13**
 Gdyż, bracia, zostaliście powołani do wolności. Tylko nie pozwólcie, żeby ta wolność stała się pretekstem do folgowania waszej starej naturze. Natomiast służcie sobie nawzajem w miłości.
###### **Ga 5,14**
 Bo cała Tora streszcza się w tym jednym zdaniu: "Kochaj bliźniego jak samego siebie";
###### **Ga 5,15**
 ale jeśli warczycie na siebie i rozszarpujecie się na strzępy, to uważajcie, żebyście się wzajemnie nie zgubili!
###### **Ga 5,16**
 Chcę przez to rzec, co następuje: żyjcie według Ducha. Wtedy nie będziecie robić tego, czego chce wasza stara natura.
###### **Ga 5,17**
 Bo to, czego chce stara natura, sprzeciwia się Duchowi, a to, czego chce Duch, sprzeciwia się starej naturze. Te dwie rzeczy są sobie przeciwne, tak że nie jesteście w stanie realizować swoich dobrych zamiarów.
###### **Ga 5,18**
 Jeśli jednak prowadzi was Duch, to nie jesteście poddani systemowi, który rodzi się z wypaczenia Tory w legalizm.
###### **Ga 5,19**
 Aż nadto zaś oczywiste jest, co robi stara natura. Wyraża się ona w rozwiązłości, nieczystości i nieprzyzwoitości,
###### **Ga 5,20**
 w kulcie bożków i nadużywaniu narkotyków w związku z okultyzmem, w sporach, walkach, zazdrości i gniewie, w samolubnej ambicji, podziałach, intrygach
###### **Ga 5,21**
 i zawiści, w pijaństwie, orgiach i tym podobnych rzeczach. Ostrzegam was, jak ostrzegłem już wcześniej: ci, co robią takie rzeczy, nie będą mieć udziału w Królestwie Bożym!
###### **Ga 5,22**
 Ale owocem Ducha jest miłość, radość, pokój, cierpliwość, łagodność, dobroć, wierność,
###### **Ga 5,23**
 pokora, wstrzemięźliwość. Takim rzeczom nic się w Torze nie sprzeciwia.
###### **Ga 5,24**
 Ponadto ci, którzy należą do Mesjasza Jeszui, uśmiercili swoją starą naturę na palu, wraz z jej namiętnościami i pragnieniami.
###### **Ga 5,25**
 Ponieważ to przez Ducha mamy Życie, również nasze życie na co dzień prowadźmy przez Ducha.
###### **Ga 5,26**
 Nie nadymajmy się, drażniąc jeden drugiego i zazdroszcząc sobie nawzajem.
# Ga 5 TRO
###### **Ga 5,1**
 **τη** *tē* (Do) [[G3588]] WTT-DSF **ελευθερια** *eleutheria* wolności [[G1657]] [[N-DSF]] **ουν** *oun* więc [[G3767]] [[CONJ]] **η** *hē* (do) której [[G3739]] WTR-DSF **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **ηλευθερωσεν** *ēleutherōsen* wyzwolił – uwolnił [[G1659]] [[V-AAI-3S]] **στηκετε** *stēkete* stójcie – trwajcie [[G4739]] WTV-PAM-2P **και** *kai* i [[G2532]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **παλιν** *palin* znowu [[G3825]] [[ADV]] **ζυγω** *zygō* jarzmu [[G2218]] WTN-DSM **δουλειας** *douleias* niewoli [[G1397]] [[N-GSF]] **ενεχεσθε** *enechesthe* dawajcie się trzymać – bądźcie ujarzmiani [[G1758]] WTV-PPM-2P
###### **Ga 5,2**
 **ιδε** *ide* Oto [[G1492]] WTV-AAM-2S **εγω** *egō* ja [[G1473]] WTP-1NS **παυλος** *paulos* Paweł – [mały] [[G3972]] [[N-NSM]] **λεγω** *legō* mówię [[G3004]] WTV-PAI-1S **υμιν** *hymin* wam [[G5213]] WTP-2DP **οτι** *hoti* że [[G3754]] [[CONJ]] **εαν** *ean* jeśli [[G1437]] WTCOND **περιτεμνησθε** *peritemnēsthe* dawalibyście się obrzezać – bylibyście obrzezywanymi [[G4059]] WTV-PPS-2P **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **υμας** *hymas* wam [[G5209]] WTP-2AP **ουδεν** *ouden* nic [[G3762]] WTA-ASN **ωφελησει** *ōfelēsei* pomoże [[G5623]] WTV-FAI-3S
###### **Ga 5,3**
 **μαρτυρομαι** *martyromai* Świadczę [[G3143]] WTV-PNI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **παλιν** *palin* znowu [[G3825]] [[ADV]] **παντι** *panti* każdemu [[G3956]] WTA-DSM **ανθρωπω** *anthrōpō* człowiekowi [[G444]] WTN-DSM **περιτεμνομενω** *peritemnomenō* dającemu się obrzezać – który jest obrzezywany [[G4059]] WTV-PPP-DSM **οτι** *hoti* że [[G3754]] [[CONJ]] **οφειλετης** *ofeiletēs* zobowiązany – winny [[G3781]] [[N-NSM]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ολον** *holon* całe [[G3650]] WTA-ASM **τον** *ton* [[G3588]] [[T-ASM]] **νομον** *nomon* Prawo [[G3551]] [[N-ASM]] **ποιησαι** *poiēsai* uczynić [[G4160]] [[V-AAN]]
###### **Ga 5,4**
 **κατηργηθητε** *katērgēthēte* Zostaliście uznani za bezużytecznych – Zostaliście unieważnieni [[G2673]] WTV-API-2P **απο** *apo* z daleka [[G575]] [[PREP]] **του** *tou* (od) [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **οιτινες** *hoitines* którzy [[G3748]] WTR-NPM **εν** *en* w [[G1722]] [[PREP]] **νομω** *nomō* Prawie [[G3551]] WTN-DSM **δικαιουσθε** *dikaiousthe* jesteście uznani za sprawiedliwych – jesteście usprawiedliwiani [[G1344]] WTV-PPI-2P **της** *tēs* (z) [[G3588]] [[T-GSF]] **χαριτος** *charitos* łaski [[G5485]] [[N-GSF]] **εξεπεσατε** *eksepesate* wypadliście [[G1601]] WTV-AAI-2P
###### **Ga 5,5**
 **ημεις** *hēmeis* My [[G2249]] WTP-1NP **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **πνευματι** *pneumati* Duchem [[G4151]] WTN-DSN **εκ** *ek* z [[G1537]] [[PREP]] **πιστεως** *pisteōs* wiary [[G4102]] [[N-GSF]] **ελπιδα** *elpida* nadziei [[G1680]] WTN-ASF **δικαιοσυνης** *dikaiosynēs* sprawiedliwości – usprawiedliwienia [[G1343]] [[N-GSF]] **απεκδεχομεθα** *apekdechometha* wyczekujemy – oczekujemy [[G553]] WTV-PNI-1P
###### **Ga 5,6**
 **εν** *en* W [[G1722]] [[PREP]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM **ουτε** *oute* ani [[G3777]] [[CONJ]] **περιτομη** *peritomē* obrzezanie [[G4061]] [[N-NSF]] **τι** *ti* coś [[G5100]] WTX-ASN **ισχυει** *ischyei* jest silne [[G2480]] WTV-PAI-3S **ουτε** *oute* ani [[G3777]] [[CONJ]] **ακροβυστια** *akrobystia* nieobrzezanie [[G203]] [[N-NSF]] **αλλα** *alla* ale [[G235]] [[CONJ]] **πιστις** *pistis* wiara [[G4102]] [[N-NSF]] **δι** *di* przez [[G1223]] [[PREP]] **αγαπης** *agapēs* miłość [[G26]] [[N-GSF]] **ενεργουμενη** *energoumenē* działająca [[G1754]] WTV-PMP-NSF
###### **Ga 5,7**
 **ετρεχετε** *etrechete* Biegliście [[G5143]] WTV-IAI-2P **καλως** *kalōs* dobrze – pięknie [[G2573]] [[ADV]] **τις** *tis* kto [[G5101]] WTI-NSM **υμας** *hymas* wam [[G5209]] WTP-2AP **ανεκοψεν** *anekopsen* przeszkodził [[G1465]] [[V-AAI-3S]] **τη** *tē* [[G3588]] WTT-DSF **αληθεια** *alētheia* prawdzie [[G225]] [[N-DSF]] **μη** *mē* nie [[G3361]] [[PRT-N]] **πειθεσθαι** *peithesthai* być przekonanym – być posłusznym [[G3982]] WTV-PPN
###### **Ga 5,8**
 **η** *hē* (To) [[G3588]] [[T-NSF]] **πεισμονη** *peismonē* namawianie – przekonywanie [[G3988]] [[N-NSF]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εκ** *ek* od [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **καλουντος** *kalountos* wzywającego [[G2564]] WTV-PAP-GSM **υμας** *hymas* was [[G5209]] WTP-2AP
###### **Ga 5,9**
 **μικρα** *mikra* Mały [[G3398]] WTA-NSF **ζυμη** *zymē* kwas – zaczyn [[G2219]] [[N-NSF]] **ολον** *holon* całe [[G3650]] WTA-ASN **το** *to* [[G3588]] WTT-ASN **φυραμα** *fyrama* ciasto [[G5445]] WTN-ASN **ζυμοι** *zymoi* zakwasza – zaczynia [[G2220]] WTV-PAI-3S
###### **Ga 5,10**
 **εγω** *egō* Ja [[G1473]] WTP-1NS **πεποιθα** *pepoitha* jestem przekonany – pokładam ufność [[G3982]] WTV-2RAI-1S **εις** *eis* co do [[G1519]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **οτι** *hoti* że [[G3754]] [[CONJ]] **ουδεν** *ouden* nic [[G3762]] WTA-ASN **αλλο** *allo* innego [[G243]] WTA-ASN **φρονησετε** *fronēsete* będziecie myśleć – będziecie rozumieć [[G5426]] WTV-FAI-2P **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **ταρασσων** *tarassōn* poruszający – trwożący [[G5015]] [[V-PAP-NSM]] **υμας** *hymas* was [[G5209]] WTP-2AP **βαστασει** *bastasei* poniesie [[G941]] WTV-FAI-3S **το** *to* [[G3588]] WTT-ASN **κριμα** *krima* sąd – wyrok [[G2917]] WTN-ASN **οστις** *hostis* kim- [[G3748]] WTR-NSM **αν** *an* kolwiek [[G302]] WTPRT **η** *ē* byłby [[G5600]] WTV-PXS-3S
###### **Ga 5,11**
 **εγω** *egō* Ja [[G1473]] WTP-1NS **δε** *de* zaś [[G1161]] [[CONJ]] **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **ει** *ei* jeśli [[G1487]] WTCOND **περιτομην** *peritomēn* obrzezanie [[G4061]] WTN-ASF **ετι** *eti* jeszcze [[G2089]] [[ADV]] **κηρυσσω** *kēryssō* głoszę [[G2784]] WTV-PAI-1S **τι** *ti* dlaczego [[G5101]] WTI-ASN **ετι** *eti* jeszcze [[G2089]] [[ADV]] **διωκομαι** *diōkomai* jestem prześladowany – jestem ścigany [[G1377]] WTV-PPI-1S **αρα** *ara* zatem – mianowicie [[G686]] WTPRT **κατηργηται** *katērgētai* jest uznane za bezużyteczne – traci na znaczeniu [[G2673]] WTV-RPI-3S **το** *to* [[G3588]] WTT-NSN **σκανδαλον** *skandalon* zgorszenie [[G4625]] WTN-NSN **του** *tou* [[G3588]] WTT-GSM **σταυρου** *staurou* krzyża [[G4716]] [[N-GSM]]
###### **Ga 5,12**
 **οφελον** *ofelon* Oby [[G3785]] WTINJ **και** *kai* i [[G2532]] [[CONJ]] **αποκοψονται** *apokopsontai* odcięli sobie [[G609]] WTV-FMI-3P **οι** *hoi* [[G3588]] WTT-NPM **αναστατουντες** *anastatountes* burzący – czyniący niepokój [[G387]] WTV-PAP-NPM **υμας** *hymas* was [[G5209]] WTP-2AP
###### **Ga 5,13**
 **υμεις** *hymeis* Wy [[G5210]] WTP-2NP **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **επ** *ep* do [[G1909]] [[PREP]] **ελευθερια** *eleutheria* wolności [[G1657]] [[N-DSF]] **εκληθητε** *eklēthēte* zostaliście wezwani [[G2564]] WTV-API-2P **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **μονον** *monon* jedynie – tylko [[G3440]] [[ADV]] **μη** *mē* nie [[G3361]] [[PRT-N]] **την** *tēn* (tę) [[G3588]] WTT-ASF **ελευθεριαν** *eleutherian* wolność [[G1657]] WTN-ASF **εις** *eis* w [[G1519]] [[PREP]] **αφορμην** *aformēn* skłonności – możności [[G874]] WTN-ASF **τη** *tē* [[G3588]] WTT-DSF **σαρκι** *sarki* ciała [[G4561]] [[N-DSF]] **αλλα** *alla* ale [[G235]] [[CONJ]] **δια** *dia* przez [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **αγαπης** *agapēs* miłość [[G26]] [[N-GSF]] **δουλευετε** *douleuete* bądźcie niewolnikami – służcie [[G1398]] WTV-PAM-2P **αλληλοις** *allēlois* jedni drugim [[G240]] WTC-DPM
###### **Ga 5,14**
 **ο** *ho* [[G3588]] [[T-NSM]] **γαρ** *gar* Bowiem [[G1063]] [[CONJ]] **πας** *pas* całe [[G3956]] [[A-NSM]] **νομος** *nomos* Prawo [[G3551]] [[N-NSM]] **εν** *en* w [[G1722]] [[PREP]] **ενι** *heni* jednym [[G1520]] WTA-DSM **λογω** *logō* słowie [[G3056]] WTN-DSM **πληρουται** *plēroutai* jest wypełnione [[G4137]] WTV-PPI-3S **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* (tym) [[G3588]] WTT-DSM **αγαπησεις** *agapēseis* będziesz miłował [[G25]] WTV-FAI-2S **τον** *ton* (tego) [[G3588]] [[T-ASM]] **πλησιον** *plēsion* bliźniego – tuż obok [[G4139]] [[ADV]] **σου** *sou* twojego [[G4675]] WTP-2GS **ως** *hōs* jak [[G5613]] [[ADV]] **εαυτον** *heauton* siebie [[G1438]] WTF-3ASM
###### **Ga 5,15**
 **ει** *ei* jeśli [[G1487]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **αλληλους** *allēlous* jedni drugich [[G240]] WTC-APM **δακνετε** *daknete* kąsacie – gryziecie [[G1143]] WTV-PAI-2P **και** *kai* i [[G2532]] [[CONJ]] **κατεσθιετε** *katesthiete* pożeracie [[G2719]] WTV-PAI-2P **βλεπετε** *blepete* uważajcie – patrzcie [[G991]] WTV-PAM-2P **μη** *mē* aby nie [[G3361]] [[PRT-N]] **υπο** *hypo* przez [[G5259]] [[PREP]] **αλληλων** *allēlōn* jedni drugich [[G240]] WTC-GPM **αναλωθητε** *analōthēte* zostalibyście zniszczeni – zostalibyście strawieni [[G355]] WTV-APS-2P
###### **Ga 5,16**
 **λεγω** *legō* Mówię [[G3004]] WTV-PAI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **πνευματι** *pneumati* (w) Duchu [[G4151]] WTN-DSN **περιπατειτε** *peripateite* chodźcie – postępujcie [[G4043]] WTV-PAM-2P **και** *kai* a [[G2532]] [[CONJ]] **επιθυμιαν** *epithymian* pożądania [[G1939]] WTN-ASF **σαρκος** *sarkos* ciała [[G4561]] [[N-GSF]] **ου** *ou* nie [[G3756]] [[PRT-N]] **μη** *mē* [[G3361]] [[PRT-N]] **τελεσητε** *telesēte* dopełnialibyście [[G5055]] WTV-AAS-2P
###### **Ga 5,17**
 **η** *hē* [[G3588]] [[T-NSF]] **γαρ** *gar* Bowiem [[G1063]] [[CONJ]] **σαρξ** *sarks* ciało [[G4561]] [[N-NSF]] **επιθυμει** *epithymei* pożąda [[G1937]] WTV-PAI-3S **κατα** *kata* przeciw [[G2596]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **πνευματος** *pneumatos* Duchowi [[G4151]] [[N-GSN]] **το** *to* [[G3588]] WTT-NSN **δε** *de* zaś [[G1161]] [[CONJ]] **πνευμα** *pneuma* Duch [[G4151]] WTN-NSN **κατα** *kata* przeciw [[G2596]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **σαρκος** *sarkos* ciału [[G4561]] [[N-GSF]] **ταυτα** *tauta* te [[G5023]] WTD-NPN **δε** *de* zaś [[G1161]] [[CONJ]] **αντικειται** *antikeitai* jest przeciwne [[G480]] WTV-PNI-3S **αλληλοις** *allēlois* jedno drugiemu [[G240]] WTC-DPN **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **α** *ha* co- [[G3739]] WTR-APN **αν** *an* kolwiek [[G302]] WTPRT **θελητε** *thelēte* chcielibyście [[G2309]] WTV-PAS-2P **ταυτα** *tauta* te [[G5023]] WTD-APN **ποιητε** *poiēte* czynilibyście [[G4160]] WTV-PAS-2P
###### **Ga 5,18**
 **ει** *ei* Jeśli [[G1487]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **πνευματι** *pneumati* Duchowi – (przez) Ducha [[G4151]] WTN-DSN **αγεσθε** *agesthe* jesteście prowadzeni [[G71]] WTV-PPI-2P **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **υπο** *hypo* pod [[G5259]] [[PREP]] **νομον** *nomon* Prawem [[G3551]] [[N-ASM]]
###### **Ga 5,19**
 **φανερα** *fanera* Jawne – Widoczne [[G5318]] WTA-NPN **δε** *de* zaś [[G1161]] [[CONJ]] **εστιν** *estin* jest (są) [[G2076]] WTV-PXI-3S **τα** *ta* [[G3588]] WTT-NPN **εργα** *erga* czyny [[G2041]] WTN-NPN **της** *tēs* [[G3588]] [[T-GSF]] **σαρκος** *sarkos* ciała [[G4561]] [[N-GSF]] **ατινα** *hatina* którymi [[G3748]] WTR-NPN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **μοιχεια** *moicheia* cudzołóstwo [[G3430]] [[N-NSF]] **πορνεια** *porneia* nierząd – wszeteczeństwo [[G4202]] [[N-NSF]] **ακαθαρσια** *akatharsia* nieczystość [[G167]] [[N-NSF]] **ασελγεια** *aselgeia* rozpusta – rozpasanie [[G766]] [[N-NSF]]
###### **Ga 5,20**
 **ειδωλολατρεια** *eidōlolatreia* bałwochwalstwo – czczenie wizerunków [[G1495]] [[N-NSF]] **φαρμακεια** *farmakeia* czar – gusła [[G5331]] [[N-NSF]] **εχθραι** *echthrai* wrogości – nieprzyjaźnie [[G2189]] [[N-NPF]] **ερεις** *ereis* kłótnie – spory [[G2054]] [[N-NPF]] **ζηλοι** *zēloi* zazdrości – żarliwości [[G2205]] WTN-NPM **θυμοι** *thymoi* wzburzenia – szały [[G2372]] WTN-NPM **εριθειαι** *eritheiai* niesnaski – podjudzania [[G2052]] [[N-NPF]] **διχοστασιαι** *dichostasiai* poróżnienia – podziały [[G1370]] [[N-NPF]] **αιρεσεις** *haireseis* stronnictwa [[G139]] [[N-NPF]]
###### **Ga 5,21**
 **φθονοι** *fthonoi* zawiści – zazdrości [[G5355]] WTN-NPM **φονοι** *fonoi* morderstwa [[G5408]] WTN-NPM **μεθαι** *methai* pijaństwa [[G3178]] [[N-NPF]] **κωμοι** *kōmoi* biesiady – hulanki [[G2970]] WTN-NPM **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-NPN **ομοια** *homoia* podobne [[G3664]] WTA-NPN **τουτοις** *toutois* tym [[G5125]] WTD-DPN **α** *ha* (o) których [[G3739]] WTR-APN **προλεγω** *prolegō* wcześniej mówię [[G4302]] WTV-PAI-1S **υμιν** *hymin* wam [[G5213]] WTP-2DP **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **προειπον** *proeipon* wcześniej powiedziałem [[G4277]] WTV-2AAI-1S **οτι** *hoti* że [[G3754]] [[CONJ]] **οι** *hoi* [[G3588]] WTT-NPM **τα** *ta* [[G3588]] WTT-APN **τοιαυτα** *toiauta* takich [[G5108]] WTD-APN **πρασσοντες** *prassontes* robiący – czyniący [[G4238]] WTV-PAP-NPM **βασιλειαν** *basileian* Królestwa [[G932]] WTN-ASF **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ου** *ou* nie [[G3756]] [[PRT-N]] **κληρονομησουσιν** *klēronomēsousin* odziedziczą – dostaną w udziale [[G2816]] WTV-FAI-3P
###### **Ga 5,22**
 **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **καρπος** *karpos* owoc [[G2590]] [[N-NSM]] **του** *tou* [[G3588]] WTT-GSN **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **αγαπη** *agapē* miłość [[G26]] [[N-NSF]] **χαρα** *chara* radość [[G5479]] [[N-NSF]] **ειρηνη** *eirēnē* pokój [[G1515]] [[N-NSF]] **μακροθυμια** *makrothymia* cierpliwość – wyrozumiałość [[G3115]] [[N-NSF]] **χρηστοτης** *chrēstotēs* uprzejmość – łagodność [[G5544]] [[N-NSF]] **αγαθωσυνη** *agathōsynē* dobroć [[G19]] [[N-NSF]] **πιστις** *pistis* wierność [[G4102]] [[N-NSF]]
###### **Ga 5,23**
 **πραοτης** *praotēs* łagodność – uprzejmość [[G4236]] [[N-NSF]] **εγκρατεια** *egkrateia* opanowanie – wstrzemięźliwość [[G1466]] [[N-NSF]] **κατα** *kata* przeciw [[G2596]] [[PREP]] **των** *tōn* [[G3588]] WTT-GPN **τοιουτων** *toioutōn* takim [[G5108]] WTD-GPN **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **νομος** *nomos* Prawo [[G3551]] [[N-NSM]]
###### **Ga 5,24**
 **οι** *hoi* (ci) [[G3588]] WTT-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **την** *tēn* [[G3588]] WTT-ASF **σαρκα** *sarka* ciało [[G4561]] WTN-ASF **εσταυρωσαν** *estaurōsan* ukrzyżowali [[G4717]] WTV-AAI-3P **συν** *syn* z [[G4862]] [[PREP]] **τοις** *tois* [[G3588]] WTT-DPN **παθημασιν** *pathēmasin* namiętnościami – doznaniami [[G3804]] WTN-DPN **και** *kai* i [[G2532]] [[CONJ]] **ταις** *tais* [[G3588]] WTT-DPF **επιθυμιαις** *epithymiais* pożądaniami – żądzami [[G1939]] WTN-DPF
###### **Ga 5,25**
 **ει** *ei* Jeśli [[G1487]] WTCOND **ζωμεν** *zōmen* żyjemy [[G2198]] WTV-PAI-1P **πνευματι** *pneumati* Duchowi [[G4151]] WTN-DSN **πνευματι** *pneumati* Duchowi [[G4151]] WTN-DSN **και** *kai* i [[G2532]] [[CONJ]] **στοιχωμεν** *stoichōmen* szlibyśmy w szeregu [[G4748]] WTV-PAS-1P
###### **Ga 5,26**
 **μη** *mē* nie [[G3361]] [[PRT-N]] **γινωμεθα** *ginōmetha* stawalibyśmy się [[G1096]] WTV-PNS-1P **κενοδοξοι** *kenodoksoi* żądni pustej chwały – chciwi pustej chwały [[G2755]] WTA-NPM **αλληλους** *allēlous* jedni drugich [[G240]] WTC-APM **προκαλουμενοι** *prokaloumenoi* prowokując [[G4292]] WTV-PMP-NPM **αλληλοις** *allēlois* jedni drugim [[G240]] WTC-DPM **φθονουντες** *fthonountes* zazdroszcząc – czując zawiść [[G5354]] WTV-PAP-NPM
