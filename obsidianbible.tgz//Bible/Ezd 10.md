# Ezd 10 BT5
###### **Ezd 10,1**
 Gdy Ezdrasz, płacząc i klęcząc przed domem Bożym, modlił się i wyznawał grzechy, zebrał się dokoła niego bardzo wielki tłum z Izraela: mężczyzn, kobiet i dzieci, przy czym lud płakał rzewnymi łzami.
###### **Ezd 10,2**
 Wtedy do Ezdrasza odezwał się Szekaniasz, syn Jechila z synów Elama, i rzekł: «***My popełniliśmy przestępstwo przeciw Bogu naszemu, bo wzięliśmy za żony kobiety obcoplemienne spośród narodów tej krainy. Ale mimo to jest jeszcze nadzieja dla Izraela.***
###### **Ezd 10,3**
 ***Toteż teraz zawrzyjmy z Bogiem naszym przymierze, zobowiązując się, że odprawimy te wszystkie nasze żony obcoplemienne i to, co się z nich narodziło, za radą pana mojego i tych, co ze czcią się odnoszą do przykazania Boga naszego. Niechaj się stanie zgodnie z Prawem.***
###### **Ezd 10,4**
 ***Powstań, gdyż do ciebie ta sprawa należy. My stoimy przy tobie. Bądź odważny i działaj!***»
###### **Ezd 10,5**
 Wtedy powstał Ezdrasz i zaprzysiągł przywódców kapłanów, lewitów i całego Izraela, by tak postąpili, jak powiedziano. I przysięgli.
###### **Ezd 10,6**
 Potem odszedł Ezdrasz od domu Bożego i udał się do komnaty Jochanana, syna Eliasziba, i tam spędził noc, chleba nie jedząc i wody nie pijąc, gdyż smucił się wiarołomstwem wygnańców.
###### **Ezd 10,7**
 Następnie ogłoszono w Judzie i Jerozolimie wszystkim wygnańcom, by się zebrali w Jerozolimie.
###### **Ezd 10,8**
 Jeśli zaś chodzi o każdego, kto wbrew poleceniu przywódców i starszyzny w ciągu trzech dni nie przybędzie, to cały dobytek jego będzie podlegał klątwie, a on wykluczony będzie ze społeczności powracających z wygnania.
###### **Ezd 10,9**
 I w ciągu owych trzech dni zebrali się wszyscy mężczyźni z Judy i Beniamina w Jerozolimie dwudziestego dnia miesiąca – był to miesiąc dziewiąty; i cały lud rozsiadł się na dziedzińcu domu Bożego, drżąc z powodu sprawy i z powodu deszczów.
###### **Ezd 10,10**
 Wtedy powstał kapłan Ezdrasz i rzekł do nich: «***Wy popełniliście przestępstwo, że za żony wzięliście kobiety obcoplemienne, powiększając przez to winę Izraela.***
###### **Ezd 10,11**
 ***A teraz wyznajcie wykroczenie swoje wobec Pana, Boga ojców waszych, i spełnijcie wolę Jego, mianowicie: odłączcie się od narodów tego kraju i od kobiet obcoplemiennych!***»
###### **Ezd 10,12**
 I całe zgromadzenie odpowiedziało głośno: «***Według orzeczenia twego powinniśmy postąpić.***
###### **Ezd 10,13**
 ***Ale lud jest liczny, a pora deszczowa, tak że nie można pozostać na dworze; a sprawa ta nie na dzień jeden ani dwa, gdyż wielu z nas w tej sprawie zawiniło.***
###### **Ezd 10,14**
 ***Niech nasi przywódcy zastąpią całą społeczność; i wszyscy w miastach naszych, którzy wzięli za żony kobiety obcoplemienne, niech w ustalonych terminach się zjawią, a z nimi starszyzna poszczególnych miast wraz z ich sędziami, aby odwrócić od nas srogi gniew Boga naszego z powodu tej sprawy***».
###### **Ezd 10,15**
 Tylko Jonatan, syn Asahela, i Jachzejasz, syn Tikwy, sprzeciwili się temu, a Meszullam i lewita Szabbetaj ich poparli.
###### **Ezd 10,16**
 Natomiast uczynili tak wygnańcy; i kapłan Ezdrasz dobrał sobie, jako odpowiednich mężów dla poszczególnych rodów, naczelników ich i to każdego imiennie. A oni zasiedli do zbadania tej sprawy pierwszego dnia miesiąca dziesiątego.
###### **Ezd 10,17**
 I owi mężowie do pierwszego dnia miesiąca pierwszego dokonali wszystkiego w sprawie tych, którzy wzięli za żony kobiety obcoplemienne.
###### **Ezd 10,18**
 I ustalono, że tymi ze stanu kapłańskiego, którzy poślubili kobiety obcoplemienne, byli: spośród synów Jozuego, syna Josadaka, i braci jego: Maasejasz, Eliezer, Jarib i Gedaliasz;
###### **Ezd 10,19**
 oni zaręczyli, że odprawią swoje żony, a ofiarą zadośćuczynienia za ich winę będzie baran;
###### **Ezd 10,20**
 a z synów Immera: Chanani i Zebadiasz;
###### **Ezd 10,21**
 a z synów Charima: Maasejasz, Eliasz, Szemajasz, Jechiel i Ozjasz;
###### **Ezd 10,22**
 a z synów Paszchura: Elioenaj, Maasejasz, Izmael, Netaneel, Jozabad i Elasa.
###### **Ezd 10,23**
 A spośród lewitów: Jozabad, Szimi, Kelajasz, czyli Kelita, Petachiasz, Juda i Eliezer.
###### **Ezd 10,24**
 A spośród śpiewaków: Eliaszib. A spośród odźwiernych: Szallum, Telem i Uri.
###### **Ezd 10,25**
 A z Izraela, spośród synów Parosza: Ramiasz, Jizzijasz, Malkiasz, Mijjamin, Eleazar, Chaszabiasz i Benajasz;
###### **Ezd 10,26**
 a spośród synów Elama: Mattaniasz, Zachariasz, Jechiel, Abdi, Jeremot i Eliasz;
###### **Ezd 10,27**
 a spośród synów Zattua: Elioenaj, Eliaszib, Mattaniasz, Jeremot, Zabad i Aziza;
###### **Ezd 10,28**
 a spośród synów Bebaja: Jochanan, Chananiasz, Zabbaj, Atlaj;
###### **Ezd 10,29**
 A spośród synów Bigwaja: Meszullam, Malluk, Jedajasz, Jaszub, Jiszal, Jeremot;
###### **Ezd 10,30**
 a spośród synów Pachat-Moaba: Adna, Kelal, Benajasz, Maasejasz, Mattaniasz, Besalel, Binnuj i Manasses;
###### **Ezd 10,31**
 a spośród synów Charima: Eliezer, Jiszszijasz, Malkiasz, Szemajasz, Szymon,
###### **Ezd 10,32**
 Beniamin, Malluk, Szemariasz;
###### **Ezd 10,33**
 a spośród synów Chaszuma: Mattenaj, Mattatta, Zabad, Elifelet, Jeremaj, Manasses, Szimi;
###### **Ezd 10,34**
 a spośród synów Baniego: Maadaj, Amram i Uel,
###### **Ezd 10,35**
 Benajasz, Bediasz, Kelajasz,
###### **Ezd 10,36**
 Waniasz, Meremot, Eliaszib,
###### **Ezd 10,37**
 Mattaniasz, Mattenaj i Jaasaj;
###### **Ezd 10,38**
 a spośród synów Binnuja: Szimi,
###### **Ezd 10,39**
 Szelemiasz, Natan i Adajasz;
###### **Ezd 10,40**
 a spośród synów Zacheusza: Szaszaj, Szaraj,
###### **Ezd 10,41**
 Azarel, Szelemiasz, Szemariasz,
###### **Ezd 10,42**
 Szallum, Amariasz, Józef;
###### **Ezd 10,43**
 spośród synów Nebo: Jejel, Mattitiasz, Zabad, Zebina, Jaddaj, Joel, Benajasz.
###### **Ezd 10,44**
 Oni wszyscy wzięli za żony kobiety obcoplemienne. A byli między nimi tacy, którzy zgłosili żony i zgłosili synów.
# Ezd 10 PAU
###### **Ezd 10,1**
 Gdy Ezdrasz tak się modlił i wyznawał grzechy, płacząc i leżąc na ziemi przed domem Bożym, zgromadził się wokół niego bardzo wielki tłum Izraelitów, mężczyzn, kobiet i dzieci, którzy płakali i zanosili się wielkim szlochem.
###### **Ezd 10,2**
 Wówczas przemówił Szekaniasz, syn Jechiela z rodu Elama, i rzekł do Ezdrasza: „Tak, to my popełniliśmy wiarołomstwo wobec Boga naszego, biorąc za żony cudzoziemki spośród narodów zamieszkujących tę ziemię. Ale mimo to jest jeszcze nadzieja dla Izraela.
###### **Ezd 10,3**
 Teraz więc zobowiążmy się przymierzem z Bogiem naszym, że odprawimy te wszystkie żony i dzieci z nich zrodzone, zgodnie z zamiarem mojego pana i tych, którzy są posłuszni przykazaniom Boga naszego. W ten sposób stanie się zadość Prawu.
###### **Ezd 10,4**
 Przystąp więc do działania, gdyż do ciebie należy decyzja, a my będziemy z tobą! Bądź mężny i działaj!”.
###### **Ezd 10,5**
 Wówczas Ezdrasz wstał i zażądał przysięgi od przywódców kapłanów, lewitów i całego Izraela, że w ten sposób uczynią. I oni złożyli przysięgę.
###### **Ezd 10,6**
 Następnie Ezdrasz opuścił dziedziniec przed domem Bożym i udał się do komnaty Jochanana, syna Eliasziba, i spędził tam noc, nie jedząc chleba i nie pijąc wody, ogarnięty smutkiem z powodu wiarołomstwa repatriantów.
###### **Ezd 10,7**
 Tymczasem rozesłano wiadomości do wszystkich repatriantów w Judzie i Jerozolimie, żeby zgromadzili się w Jerozolimie.
###### **Ezd 10,8**
 Tym, którzy nie stawiliby się w ciągu trzech dni od otrzymania rozkazu przywódców i starszych, zagrożono obłożeniem klątwą ich całego dobytku i wykluczeniem ich ze wspólnoty repatriantów.
###### **Ezd 10,9**
 W ciągu trzech dni zgromadzili się w Jerozolimie wszyscy mężczyźni z Judy i Beniamina, a było to dwudziestego dnia dziewiątego miesiąca. Cały lud usiadł na dziedzińcu domu Bożego przerażony tą sprawą i drżący z zimna.
###### **Ezd 10,10**
 Wtedy powstał kapłan Ezdrasz i tak do nich przemówił: „Wy popełniliście wiarołomstwo, biorąc za żony cudzoziemki. Powiększyliście w ten sposób winę Izraela.
###### **Ezd 10,11**
 Teraz więc oddajcie chwałę PANU, Bogu waszych przodków, i wypełnijcie Jego wolę: odłączcie się od obcych ludów tej ziemi i od żon pogańskich!”.
###### **Ezd 10,12**
 Na to całe zgromadzenie odpowiedziało donośnie: „Zrobimy tak, jak powiedziałeś!
###### **Ezd 10,13**
 Jednakże jest nas wielu, a z powodu obecnej pory deszczowej nie sposób przebywać długo na dworze. Ponadto sprawa ta nie jest do załatwienia w jeden czy dwa dni, gdyż wielu z nas jest w nią zamieszanych.
###### **Ezd 10,14**
 Niechże więc wszystkich nas zastąpią nasi przywódcy. Niech w wyznaczonych terminach zgłaszają się ci wszyscy, którzy w naszych miastach wzięli za żony cudzoziemki, i wraz z nimi niech przychodzi starszyzna miasta i jego sędziowie tak długo, dopóki nie uśmierzymy srogiego gniewu naszego Boga z powodu tej sprawy”.
###### **Ezd 10,15**
 Przeciwko tej decyzji wystąpili tylko Jonatan, syn Asahela, i Jachzejasz, syn Tikwy, a poparli ich Meszullam i lewita Szabbetaj.
###### **Ezd 10,16**
 Natomiast wszyscy repatrianci zgodzili się na to i kapłan Ezdrasz dobrał sobie przywódców poszczególnych rodów, wszystkich imiennie i według gałęzi rodowych. Rozpoczęli oni osądzanie wszystkich spraw w pierwszym dniu dziesiątego miesiąca.
###### **Ezd 10,17**
 Trwało to aż do pierwszego dnia pierwszego miesiąca. Roztrząsali wszystkie przypadki mężczyzn, którzy wzięli cudzoziemki za żony.
###### **Ezd 10,18**
 Stwierdzono następujące wypadki: Wśród kapłanów, którzy poślubili cudzoziemki, byli: z potomków Jozuego, syna Josadaka, i jego braci: Maasejasz, Eliezer, Jarib i Gedaliasz.
###### **Ezd 10,19**
 Ci zaręczyli, że odprawią swoje żony i złożą barana jako ofiarę wynagradzającą za swoją winę.
###### **Ezd 10,20**
 Z rodu Immera: Chanani i Zebadiasz;
###### **Ezd 10,21**
 z rodu Charima: Maasejasz, Eliasz, Szemajasz, Jechiel i Ozjasz;
###### **Ezd 10,22**
 z rodu Paszchura: Elioenaj, Maasejasz, Izmael, Netaneel, Jozabad i Elasa.
###### **Ezd 10,23**
 Wśród lewitów: Jozabad, Szimi, Kelajasz zwany Kelitą, Petachiasz, Juda i Eliezer.
###### **Ezd 10,24**
 Wśród śpiewaków: Eliaszib. Wśród odźwiernych: Szallum, Telem i Uri.
###### **Ezd 10,25**
 Wśród Izraelitów: z rodu Parosza: Ramiasz, Jezjasz, Malkiasz, Mijjamin, Eleazar, Malachiasz i Benajasz;
###### **Ezd 10,26**
 z rodu Elama: Mattaniasz, Zachariasz, Jechiel, Abdi, Jeremot i Eliasz;
###### **Ezd 10,27**
 z rodu Zattu: Elioenaj, Eliaszib, Mattaniasz, Jeremot, Zabad i Aziza;
###### **Ezd 10,28**
 z rodu Bebaja: Jochanan, Chananiasz, Zabbaj i Atlaj;
###### **Ezd 10,29**
 z rodu Baniego: Meszullam, Malluk, Adajasz, Jaszub, Jeszal i Jeremot;
###### **Ezd 10,30**
 z rodu Pachat-Moaba: Adna, Kelal, Benajasz, Maasejasz, Mattaniasz, Besalel, Binnuj, Manasses;
###### **Ezd 10,31**
 z rodu Charima: Eliezer, Iszszijasz, Malkiasz, Szemajasz, Szymon,
###### **Ezd 10,32**
 Beniamin, Malluk i Szemariasz;
###### **Ezd 10,33**
 z rodu Chaszuma: Mattenaj, Mattatta, Zabad, Elifelet, Jeremaj, Manasses i Szimi;
###### **Ezd 10,34**
 z rodu Baniego: Maadaj, Amram i Uel,
###### **Ezd 10,35**
 Benajasz, Bediasz, Kelajasz,
###### **Ezd 10,36**
 Waniasz, Meremot, Eliaszib,
###### **Ezd 10,37**
 Mattaniasz, Mattenaj i Jaasaj;
###### **Ezd 10,38**
 z rodu Binnuja: Szimi,
###### **Ezd 10,39**
 Szelemiasz, Natan, Adajasz;
###### **Ezd 10,40**
 z rodu Zachariasza: Szaszaj, Szaraj,
###### **Ezd 10,41**
 Azarel, Szelemiasz, Szemariasz,
###### **Ezd 10,42**
 Szallum, Amariasz i Józef;
###### **Ezd 10,43**
 z rodu Nebo: Jejel, Mattitiasz, Zabad, Zebina, Jaddaj, Joel i Benajasz.
###### **Ezd 10,44**
 Ci wszyscy wzięli za żony cudzoziemki. Wszyscy też odesłali je wraz z ich dziećmi.
# Ezd 10 BP
###### **Ezd 10,1**
 Gdy więc Ezdrasz płacząc i leżąc przed Przybytkiem Boga modlił się i wyznawał przewiny, zgromadził się wokół niego ogromny tłum Izraelitów: mężowie, kobiety i dzieci, a wszystek lud płakał z żalu.
###### **Ezd 10,2**
 Szekanja, syn Jechiela, spośród synów Elama, zabrał głos, mówiąc do Ezdrasza: Sprzeniewierzyliśmy się naszemu Bogu, bośmy pobrali obce żony spośród ludności tej ziemi. Ale jest jeszcze nadzieja dla Izraela.
###### **Ezd 10,3**
 Podejmijmy oto uroczyste zobowiązanie wobec naszego Boga, że odprawimy wszystkie [obce] żony i dzieci z nich zrodzone, zgodnie z radą mojego Pana i wszystkich tych, którzy mają w poszanowaniu przykazania naszego Boga. Niech się stanie Prawu zadość!
###### **Ezd 10,4**
 Powstań więc! Ty zajmiesz się tą sprawą, ale my będziemy stali przy tobie. Odwagi więc i do dzieła.
###### **Ezd 10,5**
 Ezdrasz powstał i rozkazał przysiąc przełożonym kapłanów, lewitom i całemu Izraelowi, że postąpią tak, jak to było powiedziane. I złożyli przysięgę.
###### **Ezd 10,6**
 Odszedł tedy Ezdrasz sprzed Przybytku Boga i udał się do mieszkania Jochanana, syna Eljasziba. Tam spędził noc nie pożywając chleba ani nie pijąc wody. Był bowiem pogrążony w smutku z powodu niewierności tych, którzy powrócili z niewoli.
###### **Ezd 10,7**
 Następnie polecono obwieścić wszystkim w Judzie i w Jeruzalem, którzy powrócili z wygnania, aby się zgromadzili w Jeruzalem.
###### **Ezd 10,8**
 Ktokolwiek nie stawi się w przeciągu trzech dni [na wezwanie], ten zgodnie z postanowieniem przełożonych i starszych zostanie pozbawiony całego mienia, sam zaś będzie wykluczony ze społeczności wygnańców.
###### **Ezd 10,9**
 Wszyscy mężowie [z pokolenia Judy] i Beniamina w ciągu trzech dni zgromadzili się w Jeruzalem. Był to dzień dwudziesty miesiąca dziewiątego. Wszystek lud siedział na dziedzińcu Przybytku Boga, drżąc z powodu wezwania i z powodu deszczu.
###### **Ezd 10,10**
 Wówczas wystąpił kapłan Ezdrasz i oznajmił im: Popełniliście wiarołomstwo, pojmując obce niewiasty za żony i przez to też pomnożyliście winę Izraela.
###### **Ezd 10,11**
 Złóżcie teraz wyznanie grzechu przed Jahwe, Bogiem ojców naszych, i spełnijcie Jego wolę! Odłączcie się od pogańskiej ludności tego kraju i od obcych niewiast!
###### **Ezd 10,12**
 Odpowiedziało całe zgromadzenie, wołając donośnym głosem: Tak, musimy postąpić tak, jak powiedziałeś.
###### **Ezd 10,13**
 Ale lud jest liczny, a czas deszczowy. Nie sposób wytrzymać na otwartym polu. Ponadto sprawy tej nie można załatwić w przeciągu jednego lub dwóch dni, gdyż wielu spośród nas zawiniło pod tym względem.
###### **Ezd 10,14**
 Niech nasi przywódcy zastąpią całe zgromadzenie; wszyscy zaś, którzy w naszych miastach pojęli żony cudzoziemskie, niech się stawią na czas oznaczony wraz ze starszymi każdego miasta i jego sędziami, byśmy mogli odwrócić od nas płomień gniewu naszego Boga z powodu tej sprawy.
###### **Ezd 10,15**
 Tylko Jonatan, syn Asaela, i Jachzeja, syn Tikwy, wystąpili przeciwko temu, poparci przez Meszullama i lewitę Szabbetaja.
###### **Ezd 10,16**
 Wygnańcy postąpili jednak tak, jak to im powiedziano. Kapłan Ezdrasz dobrał sobie [do pomocy] mężów, mianowicie przełożonych poszczególnych rodów. Wszyscy oni zostali [wezwani] imiennie. Pierwszego dnia dziesiątego miesiąca zebrali się, aby tę rzecz rozważyć,
###### **Ezd 10,17**
 i do dnia pierwszego miesiąca pierwszego zakończyli sprawę z tymi wszystkimi mężami, którzy pojęli żony cudzoziemskie.
###### **Ezd 10,18**
 Wśród synów kapłańskich ustalono następujących, którzy pojęli obce żony: spośród synów Jozuego, syna Jocadaka, i jego braci byli to: Maaseja, Eliezer, Jarib i Gedaija.
###### **Ezd 10,19**
 Zobowiązali się oni pod przysięgą, że żony swoje odprawią, a jako ofiarę zadośćuczynienia za grzech złożą jednego barana.
###### **Ezd 10,20**
 Spośród synów Immera [jako winnych ustalono]: Chananiego i Zebadję;
###### **Ezd 10,21**
 spośród synów Charima: Maaseję, Elijję, Szemaję, Jechiela i Uzijję;
###### **Ezd 10,22**
 spośród synów Paszchura: Eljoenaja, Maaseję, Iszmaela, Netaneela, Jozabada i Eleasę;
###### **Ezd 10,23**
 spośród lewitów: Jozabada, Szimiego, Kelaję, to jest Kelitę, Petachję, Judę i Eliezera;
###### **Ezd 10,24**
 spośród śpiewaków: Eljasziba; spośród odźwiernych: Szalluma, Telema i Uriego;
###### **Ezd 10,25**
 spośród Izraelitów, a mianowicie spośród synów Parosza: Ramję, Jizijję, Malkijję, Mijjamina, Eleazara, Malkijję i Benję;
###### **Ezd 10,26**
 spośród synów Elama: Mattanję, Zekarję, Jechiela, Abdiego, Jeromota i Elijję;
###### **Ezd 10,27**
 spośród synów Zattua: Eljoenaja, Eliasziba, Mattanję, Jeremota, Zebada i Azizę;
###### **Ezd 10,28**
 spośród synów Bebaja: Jechonana, Chananję, Zabbaja i Atlaja;
###### **Ezd 10,29**
 spośród synów Baniego: Meszullama, Malluka, Adaję, Jaszuba, Jiszala i Jeremota;
###### **Ezd 10,30**
 spośród synów Pachat-Moaba: Adnę, Kelala, Benaję, Maaseję, Mattanję, Becaleela, Binnuja i Menaszszego;
###### **Ezd 10,31**
 spośród synów Charima: Eliezera, Jiszszijję, Malkijję, Szemaję, Symeona,
###### **Ezd 10,32**
 Beniamina, Malluka i Szemarję;
###### **Ezd 10,33**
 spośród synów Chaszuma: Mataja, Mattattę, Zabada, Elifeleta, Jeremaja, Menaszszego i Szimiego;
###### **Ezd 10,34**
 spośród synów Bigwaja: Maadaja, Amrama, Uela,
###### **Ezd 10,35**
 Benaję, Bedię, Keluhiego,
###### **Ezd 10,36**
 Waniję, Meremota, Eliasziba,
###### **Ezd 10,37**
 Mattanję, Matnaja, Jaasaja,
###### **Ezd 10,38**
 Baniego, Binnuja, Szimiego,
###### **Ezd 10,39**
 Szelemję, Natana, Adaję;
###### **Ezd 10,40**
 spośród synów Zakkaja: Maknadbaja, Szaszaja, Szaraja,
###### **Ezd 10,41**
 Azareela, Szelemijaha, Szemarję,
###### **Ezd 10,42**
 Szalluma, Amarję i Józefa;
###### **Ezd 10,43**
 spośród synów Nebo: Jeiela, Mattitję, Zabada, Zebinę, Jaddaja, Joela i Benaję.
###### **Ezd 10,44**
 Ci wszyscy pojęli cudzoziemskie żony, a niektórzy mieli z nimi synów.
# Ezd 10 BR
###### **Ezd 10,1**
 Kiedy Ezdrasz, głośno płacząc, leżał przed świątynią Pańską, modlił się i wyznawał grzechy, zebrało się wokół niego bardzo wielu Izraelitów - mężczyzn, kobiet i dzieci. I cały lud zanosił się od płaczu.
###### **Ezd 10,2**
 Wtedy niejaki Szekaniasz, syn Jechiela z synów Elama, odezwał się do Ezdrasza tymi słowami: Zgrzeszyliśmy przeciwko naszemu Bogu, biorąc sobie za żony kobiety obce, należące do narodów mieszkających na tej ziemi. lecz oto teraz jest jeszcze [raz] nadzieja dla Izraela.
###### **Ezd 10,3**
 Zechciejmy zawrzeć z Bogiem naszym przymierze, idąc za radą mojego pana i tych wszystkich, którzy z bojaźnią troszczą się o przykazania naszego Boga, i zobowiążmy się oddalić od nas wszystkie kobiety [cudzoziemskie], a także wszystkie zrodzone z nich dzieci. Niech się stanie zadość wymaganiu prawa.
###### **Ezd 10,4**
 Wstań, bo to ty właśnie musisz wziąć w swoje ręce tę sprawę, a my będziemy z tobą. Odwagi wiec i do dzieła!
###### **Ezd 10,5**
 Powstał tedy Ezdrasz i wszystkim przełożonym kapłanów i lewitów oraz przywódcom całego Izraela kazał złożyć przysięgę, że postąpią tak, jak zostało powiedziane. I złożyli taką przysięgę.
###### **Ezd 10,6**
 Potem Ezdrasz odszedł sprzed świątyni Pańskiej i wszedł do mieszkania Jochanana, syna Eliasziba. Znalazłszy się tam, przestał przyjmować pokarmy i napoje, gdyż postanowił trwać w żałobie z powodu grzechów, których dopuszczali się ci, co wrócili z wygnania.
###### **Ezd 10,7**
 Wezwano tedy wszystkich, którzy po powrocie z wygnania zamieszkali w Judzie i w Jerozolimie, żeby przybyli do Jerozolimy.
###### **Ezd 10,8**
 Zgodnie z zarządzeniem przełożonych i starszyzny tym, którzy by nie przybyli na spotkanie w ciągu trzech dni, zagrożono, ze zostaną pozbawieni całego mienia i wykluczeni ze społeczności byłych wygnańców.
###### **Ezd 10,9**
 Zgromadzili się więc w ciągu trzech dni w Jerozolimie wszyscy mężowie z Judy i Beniamina. Nadszedł dwudziesty dzień dziewiątego miesiąca. Cały lud znajdował się na dziedzińcu przed świątynią pańską, drżąc z przerażenia i z powodu deszczu.
###### **Ezd 10,10**
 Wstał kapłan Ezdrasz i tak przemówił: Zgrzeszyliście, biorąc sobie za żony cudzoziemki i powiększając przez to winy Izraela.
###### **Ezd 10,11**
 Wyznajcie więc teraz wasze grzechy przed Jahwe, Bogiem waszych ojców, i poddajcie się Jego woli. Nie miejcie nic wspólnego z ludami tej ziemi, oddalcie od siebie kobiety cudzoziemskie.
###### **Ezd 10,12**
 A całe zgromadzenie odpowiedziało donośnym głosem: Zrobimy wszystko tak, jak powiedziałeś.
###### **Ezd 10,13**
 Teraz jednak popatrz: Ludzi jest bardzo dużo, a deszcz ciągle pada. Nie możemy tak stać na dworze. A przecież nie jest to sprawa do załatwienia w ciągu jednego dnia albo dwóch. Wiemy, że wielu z nas dopuściło się w tym względzie ciężkich wykroczeń.
###### **Ezd 10,14**
 Niech tedy zostaną na tym miejscu jako przedstawiciele całego zgromadzenia nasi przełożeni, wszyscy zaś, którzy mają w swoich domach kobiety cudzoziemskie, niech się tu zgłaszają w oznaczonym dniu razem ze starszymi miasta i sędziami tak długo, aż Bóg nasz odwróci od nas płomień swego zagniewania, któreśmy przez to na siebie ściągnęli.
###### **Ezd 10,15**
 Tylko Jonatan, syn Asahela, oraz Jachzejasz, syn Tikwy, byli innego zdania, a poparli ich Meszullam oraz lewita Szabbetaj.
###### **Ezd 10,16**
 Natomiast wszyscy ci, którzy wrócili z wygnania, postąpili tak, jak było powiedziane. Kapłan Ezdrasz oraz niektórzy mężowie, przywódcy rodów, według ich poszczególnych domów, wyznaczeni imiennie, zasiedli na oddzielnym miejscu pierwszego dnia dziesiątego miesiąca, żeby zbadać całą sprawę.
###### **Ezd 10,17**
 Swoją pracę zakończyli pierwszego dnia pierwszego miesiąca, przebadawszy dokładnie sprawy tych wszystkich, którzy mieli u siebie kobiety cudzoziemskie.
###### **Ezd 10,18**
 Oto lista synów kapłańskich, którzy pojęli sobie za żony kobiety cudzoziemskie: Maasejasz, Eliezer, Jarib i Gedaliasz - spośród synów Jozuego, syna Josadaka, i jego braci.
###### **Ezd 10,19**
 Wszyscy oni przyrzekli oddalić swoje żony i złożyć jako zadośćuczynienie za swoje winy ofiarę z jednego barana.
###### **Ezd 10,20**
 Chanani i Zebadiasz - spośród synów Immera;
###### **Ezd 10,21**
 Maasejasz, Eliasz, Szemajasz, Jechiel i Ozjasz z synów Charima;
###### **Ezd 10,22**
 Elioenaj, Maasejasz, Izmael, Netaneel, Jozabad i Elasa - spośród synów Paszchura.
###### **Ezd 10,23**
 Spośród lewitów byli tam: Jozabad, Szimi, Kelajasz, czyli Kelita, Petachiasz, Juda i Eliezer,
###### **Ezd 10,24**
 spośród śpiewaków zaś Eliaszib; wreszcie spośród odźwiernych Szallum, Tellem i Uri.
###### **Ezd 10,25**
 A oto pozostali Izraelici: Ramiasz, Jizzijasz, Malkiasz, Mijjamin, Eleazar, Chaszabiasz i Benajasz - wszyscy spośród synów Parosza;
###### **Ezd 10,26**
 Mattaniasz, Zachariasz, Jechiel, Abdi, Jeremot i Eliasz - wszyscy spośród synów Elama;
###### **Ezd 10,27**
 Elioenaj, Eliaszib, Mattaniasz, Jeremot, Zabad i Aziza - wszyscy spośród synów Zattusza;
###### **Ezd 10,28**
 Jochanan, Chananiasz, Zabbaj, Atlaj - wszyscy spośród synów Bebaja;
###### **Ezd 10,29**
 Meszullam, Malluk, Jedajasz, Jaszub, Jiszal, Jeremot - wszyscy spośród synów Bigwaja;
###### **Ezd 10,30**
 Adna, Kelal, Benajasz, Maasejasz, Mattaniasz, Besalel, Binnuj i Manasses - wszyscy spośród synów Pachat-Moaba;
###### **Ezd 10,31**
 Eliezer, Jiszszijasz, Malkiasz, Szemajasz, Szymon,
###### **Ezd 10,32**
 Beniamin, Malluk, Szemariasz - wszyscy spośród synów Charima;
###### **Ezd 10,33**
 Mattenaj, Mattatta, Zabad, Elifelet, Jeremaj, Manasses, Szimi - wszyscy spośród synów Chaszuma;
###### **Ezd 10,34**
 Maadaj, Amram, Uel,
###### **Ezd 10,35**
 Benajasz, Bediasz, Kelajasz,
###### **Ezd 10,36**
 Waniasz, Meremot, Eliaszib,
###### **Ezd 10,37**
 Mattaniasz, Mattenaj i Jaasaj - wszyscy spośród synów Baniego;
###### **Ezd 10,38**
 Szimi,
###### **Ezd 10,39**
 Szelemiasz, Natan i Adajasz - spośród synów Binnuja;
###### **Ezd 10,40**
 Szaszaj, Szaraj,
###### **Ezd 10,41**
 Azarel, Szelemiasz, Szemariasz,
###### **Ezd 10,42**
 Szallum, Amariasz, Józef - wszyscy spośród synów Zacheusza,
###### **Ezd 10,43**
 Jejel, Mattitiasz, Zabad, Zebina, Jaddaj, Joel, Benajasz - wszyscy spośród synów Nebo.
###### **Ezd 10,44**
 Wszyscy ci wzięli sobie kiedyś za żony kobiety cudzoziemskie. Wśród nich byli też tacy, którzy zgłosili nie tylko swoje żony, ale i synowe.
# Ezd 10 WUJ
###### **Ezd 10,1**
 Tak tedy, gdy się modlił Ezdrasz, i gdy wzywał płacząc, i leżał przed kościołem Bożym: zebrało się do niego z Izraelczyków zgromadzenie barzo wielkie mężów i niewiast i dzieci, i płakał lud płaczem wielkim.
###### **Ezd 10,2**
 I odpowiedział Secheniasz syn Iehiel: z synów Aelam, i rzekł Ezdraszowi: Myśmy wystąpili przeciw Bogu naszemu, i spojmowaliśmy żony obce z ludu ziemie: a teraz jeśli jest za to pokuta w Izraelu.
###### **Ezd 10,3**
 Uczyńmy przymierze z Panem Bogiem naszym że porzucimy wszystkie żony, i te, którzy z tych się urodzili, według wolej Pańskiej i tych, którzy się boją przykazania Pana Boga naszego: niechaj będzie według zakonu.
###### **Ezd 10,4**
 Wstańże: na cię należy stanowić, a my będziem z tobą: zmocni się, a my będziem z tobą: zmocni się, a czyń.
###### **Ezd 10,5**
 Wstał tedy Ezdrasz, i poprzysiągł książęta kapłańskie, i Lewitskie, i wszystkiego Izraela, żeby uczynili wedle tego słowa, i przysięgli.
###### **Ezd 10,6**
 I wstał Ezdrasz, przed domem Bożym, i szedł do komory Johanana syna Eliasib i wszedł tam, chleba nie jadł, i wody nie pił: bo żałował przestępstwa tych, którzy się byli z niewoli wrócili.
###### **Ezd 10,7**
 I puszczono głos w Judzie i w Jeruzalem do wszystkich synów przeprowadzenia, aby się zgromadzili do Jeruzalem:
###### **Ezd 10,8**
 A wszelki, któryby nie przyszedł za trzy dni, według uradzenia książąt i starszych, będzie wzięta wszystka majętność jego, i sam będzie wyrzucon z gromady przeprowadzenia.
###### **Ezd 10,9**
 Zeszli się tedy wszyscy mężowie Judzcy i Benjaminowi do Jeruzalem za trzy dni, ten jest miesiąc dziewiąty, dwudziestego dnia miesiąca: i siedział wszystek lud na placu domu Bożego, drżąc dla grzechu i dla dżdżów.
###### **Ezd 10,10**
 I wstał Ezdrasz kapłan, i rzekł do nich: Wyście wystąpili, i spojmowaliście żony obce, abyście przydali do grzechu Izrael.
###### **Ezd 10,11**
 A teraz dajcie wyznanie Panu Bogu ojców, waszych, a uczyńcie upodobanie jego, a odłączcie się od narodów ziemie, i od żon obcych.
###### **Ezd 10,12**
 I odpowiedziało wszystko zgromadzenie, i rzekło głosem wielkim: Według słowa twego do nas, tak się niechaj stanie.
###### **Ezd 10,13**
 Ale jednak iż lud wielki jest, i czas dżdżysty, a nie możemy stać na dworze, a sprawa nie jest jednego dnia albo dwu (bośmy barzo zgrzeszyli w tej mowie)
###### **Ezd 10,14**
 Niechaj będą postanowieni przełożeni we wszystkiem zgromadzeniu: a wszyscy w mieściech naszych, którzy pojęli żony obce, niech przychodzą na czas postanowiony, a z nimi starszy po mieście i mieście, i sędziowie jego, aż się odwróci gniew Boga naszego od nas dla tego grzechu.
###### **Ezd 10,15**
 Jonathan tedy syn Azahel, i Jazia syn Thekue, byli na to wysadzeni: a Messolam i Sebethaj Lewit pomagali im:
###### **Ezd 10,16**
 I uczynili tak synowie przeniesienia. I poszli Ezdrasz kapłan, i mężowie przełożeni familij do domów ojców swoich, i wszyscy po imionach swoich. I zasiedli pierwszego dnia miesiąca dziesiątego, aby się o rzeczy pytali:
###### **Ezd 10,17**
 I odprawili się wszyscy mężowie, którzy byli pojęli żony obce, aż do pierwszego dnia miesiąca pierwszego.
###### **Ezd 10,18**
 I naleźli się z synów kapłańskich, którzy byli pojęli żony obce, z synów Jozue syna Josedek, i bracia jego, Maasia, i Eliezer, i Jarib, i Godolia.
###### **Ezd 10,19**
 I dali ręce swe, że mieli odrzucić żony swe a za występ swój barana z owiec ofiarować.
###### **Ezd 10,20**
 A z synów Emmer, Hanani, i Zebedia.
###### **Ezd 10,21**
 A z synów Harim, Maasia, i Elia, i Semeja, i Jehiel, i Oziasz.
###### **Ezd 10,22**
 A z synów Pheshur, Elioenaj, Maasia, Ismael, Nathanael, Jozabed, i Elasa.
###### **Ezd 10,23**
 I z synów Lewitów, Jozabed, i Semei, i Celaja (ten jest Kalito) Phataja, Juda, i Eliezer.
###### **Ezd 10,24**
 A z śpiewaków, Eliasib. A z odźwiernych, Sellum, i Telem, i Uri.
###### **Ezd 10,25**
 I z Izraela, z synów Pharos, Remeja, i Jezia, i Melchia, i Miamin, i Eliezer, i Melchia i Banea.
###### **Ezd 10,26**
 A z synów Aelam, Mathania, Zacharyasz, i Jehiel, i Abdy, i Jerimoth, i Elia.
###### **Ezd 10,27**
 A z synów Zethua, Elioenaj, Eliasib, Mathania, i Jerimuth, i Zabad, i Aziza,
###### **Ezd 10,28**
 A z synów Bebai, Johanan, Hanania, Zabbaj, Athalaj.
###### **Ezd 10,29**
 A z synów Bani, Mosollam, i Melluch, i Adaja, Jasub, i Saalj i Ramoth.
###### **Ezd 10,30**
 A z synów Phahath Moab, Edna, i Chalad, Banajas, i Maasias, Mathanias, Beseleel, Bennui, i Manasse.
###### **Ezd 10,31**
 A z synów Herem, Eliezer, Jozue, Melchias, Semejas, Simeon,
###### **Ezd 10,32**
 Benjamin, Maloch, Samarias.
###### **Ezd 10,33**
 A z synów Hasom, Mathanaj, Mathathia, Zabad, Elipheleth, Bermaj, Manasse, Semei.
###### **Ezd 10,34**
 Z synów Bani, Maaddi, Amram, i Uel,
###### **Ezd 10,35**
 Baneas, i Badajas, Chelian,
###### **Ezd 10,36**
 Uania, Marimuth, i Eliasib,
###### **Ezd 10,37**
 Mathanias, Mathanaj, i Jasi,
###### **Ezd 10,38**
 I Bani, i Bennuy, Semei,
###### **Ezd 10,39**
 I Salmias, i Nathan, i Adajas,
###### **Ezd 10,40**
 I Mechnedebaj, Sesaj, Saraj,
###### **Ezd 10,41**
 Ezrel, i Selemiau, Semeria,
###### **Ezd 10,42**
 Sellum, Amaria, Joseph,
###### **Ezd 10,43**
 Z synów Nebo, Jehiel, Mathathias, Zabad, Zabina, Jeddu, i Joel, i Banaja.
###### **Ezd 10,44**
 Ci wszyscy wzięli byli żony obce, a były z nich niewiasty, które były porodziły syny.1
