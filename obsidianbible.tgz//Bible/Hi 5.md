# Hi 5 BT5
###### **Hi 5,1**
 ***Wołaj! Czy ktoś ci odpowie? Do kogo ze świętych się zwrócisz?***
###### **Hi 5,2**
 ***Nierozsądnych zabija smutek, a gniew uśmierca niemądrych.***
###### **Hi 5,3**
 ***Patrzałem, jak głupiec zapuszczał korzenie, a przekląłem jego siedzibę;***
###### **Hi 5,4**
 ***od jego synów dalekie ocalenie, uciśnieni w bramie są bez obrońcy.***
###### **Hi 5,5***
 ***Ich żniwo zjada głodny lub do kryjówek zanosi; chciwi bogactwa ich pragną.***
###### **Hi 5,6**
 ***Wszak boleść nie z roli wyszła, ni z ziemi cierpienie wyrosło.***
###### **Hi 5,7**
 ***To człowiek się rodzi na cierpienie jak iskra, by unieść się w górę.***
###### **Hi 5,8**
 ***Lecz ja bym się zwrócił do Boga, Bogu przedstawiłbym sprawę.***
###### **Hi 5,9**
 ***On czyni niezmierne dziwy, a cudów Jego bez liku:***
###### **Hi 5,10**
 ***On udziela glebie deszczu, posyła wody na powierzchnię ziemi,***
###### **Hi 5,11**
 ***wysoko podnosi zgnębionych, smutni się szczęściem weselą.***
###### **Hi 5,12**
 ***Udaremnia zamysły przebiegłych: dzieło ich rąk – nieskuteczne;***
###### **Hi 5,13**
 ***mądrych On chwyta w ich przebiegłości, przepadają knowania podstępnych.***
###### **Hi 5,14**
 ***Za dnia popadają w ciemność, w południe idą omackiem jak w nocy.***
###### **Hi 5,15**
 ***Od miecza ich ust On ocala, a biedaka z przemocy możnego.***
###### **Hi 5,16**
 ***Dla ubogiego to będzie nadzieją, gdy nieprawość zamknie swe usta.***
###### **Hi 5,17**
 ***Oto szczęśliwy mąż, którego Bóg poprawia, więc nie odrzucaj nagan Wszechmocnego.***
###### **Hi 5,18**
 ***On zrani, On także uleczy, skaleczy – i ręką swą własną uzdrowi.***
###### **Hi 5,19**
 ***Od sześciu cię nieszczęść uwolni, w siedmiu – zło cię nie dotknie.***
###### **Hi 5,20**
 ***Podczas głodu od śmierci zachowa, a na wojnie – od mocy miecza.***
###### **Hi 5,21**
 ***Unikniesz chłosty języka, nie strwoży cię nieszczęście, gdy spadnie;***
###### **Hi 5,22**
 ***będziesz się śmiał z suszy i głodu, nie zadrżysz przed dzikim zwierzęciem,***
###### **Hi 5,23**
 ***bo zawrzesz przymierze z polnymi kamieniami i przyjaźń – z polną zwierzyną.***
###### **Hi 5,24**
 ***Ujrzysz twój namiot spokojny, mieszkanie zastaniesz bez braków.***
###### **Hi 5,25**
 ***Poznasz, że twe potomstwo jest liczne, a twoich dzieci – jak trawy na łące.***
###### **Hi 5,26**
 ***W pełni wieku zejdziesz do grobu, jak snopy zbierane w swym czasie.***
###### **Hi 5,27**
 ***Oto, cośmy zbadali, i jest tak; posłuchaj i sam to chciej pojąć!***»
# Hi 5 PAU
###### **Hi 5,1**
 Zawołaj! Któż ci odpowie? Do którego ze świętych się zwrócisz?
###### **Hi 5,2**
 Bo głupca zabija troska, a nierozumnego uśmierca zajadłość.
###### **Hi 5,3**
 Widziałem, jak głupiec zapuszczał korzenie, i zaraz przekląłem jego siedzibę.
###### **Hi 5,4**
 Jego synowie sami pozbawiają się ratunku, w bramie miejskiej nikt ich nie popiera i giną.
###### **Hi 5,5**
 Człowiek głodny zje jego zbiory, wydobędzie je nawet spod cierni, a chciwiec zagrabi majętność.
###### **Hi 5,6**
 A przecież nieszczęście nie rośnie na polu ani udręka nie wyrasta z ziemi.
###### **Hi 5,7**
 Bo człowiek rodzi się, by cierpieć, inaczej niż iskry, które lecą w górę.
###### **Hi 5,8**
 Ale ja bym się zwrócił do Boga i Bogu powierzył moją sprawę.
###### **Hi 5,9**
 On czyni rzeczy wielkie i niezgłębione, przedziwne i niepoliczone.
###### **Hi 5,10**
 On zsyła deszcz na całą ziemię i wodą podlewa pola uprawne.
###### **Hi 5,11**
 Poniżonych wywyższa, a smutnym niesie wybawienie.
###### **Hi 5,12**
 Udaremnia zamiary przebiegłych, ich ręce pracują bez skutku.
###### **Hi 5,13**
 Mędrców wikła w ich własną przebiegłość, a radę chytrych udaremnia.
###### **Hi 5,14**
 W jasny dzień ogarnie ich ciemność, w południe będą błądzić jak w nocy.
###### **Hi 5,15**
 Od miecza ich słów On wybawia, ubogiego wyrywa z ręki silniejszych.
###### **Hi 5,16**
 Biedny umacnia się nadzieją, a niegodziwość zamyka usta.
###### **Hi 5,17**
 Jakże szczęśliwy jest człowiek, którego Bóg upomina, nie gardź więc karceniem Wszechmocnego.
###### **Hi 5,18**
 Bo On zrani, ale i opatrzy, uderzy, lecz także uzdrowi dotknięciem ręki.
###### **Hi 5,19**
 Sześć razy cię wesprze w nieszczęściu, za siódmym zło cię nie dotknie.
###### **Hi 5,20**
 W czasie głodu uratuje cię od śmierci, a w bitwie - od ciosu miecza.
###### **Hi 5,21**
 Zasłoni cię przed biczem języka, nie ulękniesz się nadciągającej zagłady.
###### **Hi 5,22**
 Będziesz śmiał się z klęski i głodu, nie przestraszysz się dzikiego zwierzęcia.
###### **Hi 5,23**
 Bo sprzymierzysz się z kamieniami na ziemi, a dzikie zwierzęta będą żyć z tobą w zgodzie.
###### **Hi 5,24**
 Przekonasz się, że pokój panuje w twoim namiocie, obejrzysz swą siedzibę i nie dostrzeżesz braków.
###### **Hi 5,25**
 Zobaczysz, jak liczne będzie twe potomstwo, a twoje latorośle - jak trawa na polu.
###### **Hi 5,26**
 W sędziwym wieku zejdziesz do grobu, jak snopy zebrane we właściwym czasie.
###### **Hi 5,27**
 Zbadaliśmy to wszystko, tak jest rzeczywiście. Posłuchaj tego i sam to rozważ”.
# Hi 5 BP
###### **Hi 5,1**
 Wołaj że, czy ci kto odpowie, i do którego ze świętych ty się zwrócisz?
###### **Hi 5,2**
 Zaiste zgryzota zabija bezrozumnego, a gniew uśmierca nierozsądnego.
###### **Hi 5,3**
 Widziałem, jak głupiec zapuszczał korzenie, lecz bez namysłu przekląłem jego mieszkanie.
###### **Hi 5,4**
 Synowie jego są pozbawieni pomocy, zginą przy bramie i nikt ich nie uratuje.
###### **Hi 5,5**
 Tym, co on nagromadził, pożywi się głodny i ci, którzy pośród cierni szukają pożywienia; chciwi rozgrabiają jego dobra.
###### **Hi 5,6**
 Bo nieszczęście nie powstaje z prochu ani cierpienie nie wyrasta z ziemi.
###### **Hi 5,7**
 Tak to człowiek rodzi się, by cierpiał, podobnie jak iskry, by wzlatywały ku górze.
###### **Hi 5,8**
 Ja bym się wszakże zwrócił do Boga i Bogu przedstawiłbym moją sprawę.
###### **Hi 5,9**
 On czyni wielkie i niepojęte rzeczy i cuda nieprzeliczone, których zliczyć się nie da.
###### **Hi 5,10**
 On ziemię deszczem zrasza i zsyła wody na uprawne pola.
###### **Hi 5,11**
 On poniżonych wywyższa, a udręczonym przynosi wybawienie.
###### **Hi 5,12**
 Wniwecz obraca zamysły przebiegłych, tak aby ręce ich nie działały skutecznie.
###### **Hi 5,13**
 Mędrców chwyta w ich własne sidła i udaremnia rady przewrotnych.
###### **Hi 5,14**
 W jasny dzień ogarną ich ciemności, a w pełne południe po omacku stąpać będą.
###### **Hi 5,15**
 [Bóg] wybawi od ostrza ich języka, a ubogiego z ręki możnego.
###### **Hi 5,16**
 Tak to uciśniony żyć będzie nadzieją, a niegodziwość zamknie swe usta.
###### **Hi 5,17**
 Jakże szczęśliwy człowiek, którego Bóg doświadcza. Nie gardź więc dopustem Wszechmocnego.
###### **Hi 5,18**
 On bowiem rani, ale też ranę przewiązuje, uderza, ale i ręką swą uzdrawia.
###### **Hi 5,19**
 Od sześciu plag cię uwolni, siódme zło ciebie nie dosięże.
###### **Hi 5,20**
 W czasie głodu On ciebie wybawi od śmierci, a w bitwie od uderzeń miecza.
###### **Hi 5,21**
 On cię osłoni przed biczem języka i nie ulękniesz się klęski, gdy nadejdzie.
###### **Hi 5,22**
 Będziesz się śmiał ze spustoszenia i głodu i nie ulękniesz się dzikiego zwierza,
###### **Hi 5,23**
 bo z kamieniami na polu zawrzesz przymierze i dzikie zwierzęta żyć będą z tobą w pokoju.
###### **Hi 5,24**
 Przekonasz się, jak bezpieczny jest twój namiot, a kiedy dom twój odwiedzisz, nie znajdziesz w nim braków.
###### **Hi 5,25**
 Przekonasz się, jak rozmnaża się twoje potomstwo, a latorośl twoja jak trawa na polu.
###### **Hi 5,26**
 Zstąpisz do grobu w sędziwej starości, jak snopy zebrane we właściwym czasie.
###### **Hi 5,27**
 Oto wszystko, cośmy przemyśleli. Tak jest. Słuchaj tego uważnie i rozważ dla własnego dobra.
# Hi 5 BR
###### **Hi 5,1**
 Wołaj więc, ale czy ktoś ci odpowie? Ku któremu się zwrócisz ze świętych?
###### **Hi 5,2**
 Głupiego gniew zabija, wzburzenie unicestwia szaleńca.
###### **Hi 5,3**
 Widziałem wprawdzie, jak głupiec już zapuszczał korzenie, lecz oto musiał nagle zniknąć ze swojego miejsca.
###### **Hi 5,4**
 Jego dzieci, pozbawione opieki, będą ginąć w bramie, a nikt ich nie wesprze.
###### **Hi 5,5**
 Głodni wykradną mu zapasy, a sam zbierze plony spośród cierni, chciwi wyciągną rękę po jego bogactwa.
###### **Hi 5,6**
 Nieszczęście nie rodzi się z pyłu ziemi ani z pola uprawnego cierpienie.
###### **Hi 5,7**
 To człowiek rodzi się do cierpienia jak płomień ognia do tego, by wznieść się ku górze.
###### **Hi 5,8**
 A ja bym do Boga się zwrócił, Jemu bym rzecz moją przedłożył.
###### **Hi 5,9**
 Bo On czyni rzeczy wielkie i niezbadane i cuda, których nikt nie zliczy.
###### **Hi 5,10**
 To On zsyła deszcz na ziemię, rozlewa wodę po szerokich równinach,
###### **Hi 5,11**
 aby to, co poniżone, wywyższyć, a smutnych napełnić szczęściem.
###### **Hi 5,12**
 To On niweczy knowania przebiegłych, a ich czynom odbiera wszelką skuteczność.
###### **Hi 5,13**
 Mędrców chwyta w ich własne pułapki, aby unicestwić ich przewrotne plany.
###### **Hi 5,14**
 Za dnia białego grzęzną w ciemności, w południe chodzą po omacku jak w nocy.
###### **Hi 5,15**
 Biedaka osłania przed mieczem i z rąk mocarzy uwalnia.
###### **Hi 5,16**
 Maluczkich, napełnia nadzieją, a przewrotnym zamyka usta.
###### **Hi 5,17**
 Szczęśliwy mąż doświadczony przez Boga, nie odtrącaj więc upomnień Najwyższego.
###### **Hi 5,18**
 On wprawdzie rani, ale też leczy, uderza, ale i własną ręką uzdrowi.
###### **Hi 5,19**
 W sześciu nieszczęściach ześle ci ratunek, w siódmym - zło od ciebie oddali.
###### **Hi 5,20**
 Uratuje cię od śmierci w czasie klęski głodu, osłoni przed mieczem, gdy przyjdą dni wojny.
###### **Hi 5,21**
 Uchroni cię przed jadem języka, nie zmartwisz się w obliczu nieszczęścia.
###### **Hi 5,22**
 Będziesz drwił i z suszy, i z głodu, nie przerazi cię wcale żadne dzikie zwierzę.
###### **Hi 5,23**
 Zawrzesz przymierze z kamieniami na polu, z dzikimi zwierzętami będziesz żył w przyjaźni.
###### **Hi 5,24**
 W swoim namiocie będziesz spał bezpiecznie, nie zabraknie w twym domu niczego.
###### **Hi 5,25**
 Będziesz patrzył na twe liczne latorośle, na twoje dzieci, których tyle co trawy na łące.
###### **Hi 5,26**
 Do grobu zstąpisz w wieku już dojrzałym jak zbiera się snopy, gdy ich czas nadejdzie.
###### **Hi 5,27**
 Wszystko to zbadane i tak jest naprawdę, myśmy to słyszeli i ty sam w to uwierz.
# Hi 5 WUJ
###### **Hi 5,1**
 Wołajże tedy, jeśli jest kto, być odpowiedział, a obróć się do którego z świętych.
###### **Hi 5,2**
 Zaiste gniew zabija głupiego, a zawiść umarza malutkiego.
###### **Hi 5,3**
 Jam widział głupiego mocnie wkorzenionego, i wnetem złorzeczył ozdobie jego.
###### **Hi 5,4**
 Daleko będą synowie jego od zbawienia, i starci będą w bramie, i nie będzie ktoby wyrwał.
###### **Hi 5,5**
 Którego żniwo głodny zje, a samego porwie zbrojny, a pragnący będą pić bogactwa jego,
###### **Hi 5,6**
 Nic się na ziemi bez przyczyny nie dzieje, a z ziemie nie wschodzi boleść.
###### **Hi 5,7**
 Człowiek się rodzi na pracą, a ptak na latanie,
###### **Hi 5,8**
 Przetoż ja będę prosił Pana, a u Boga przełożę mowę moję:
###### **Hi 5,9**
 Który czyni wielkie rzeczy i nie wybadane, i dziwne bez liczby:
###### **Hi 5,10**
 Który dawa deszcz na ziemię, i polewa wodami wszystkie rzeczy:
###### **Hi 5,11**
 Który pokorne kładzie wysoko, a smętne wywyższa zdrowiem.
###### **Hi 5,12**
 Który rozprasza myśli złośliwych, aby ręce ich nie mogły dokonać co były poczęły.
###### **Hi 5,13**
 Który chwyta mądre w ich chytrości, a radę przewrotnych rozsypuje.
###### **Hi 5,14**
 We dnie wbieżą w ciemności, a jakoby w nocy tak będą macać w południe.
###### **Hi 5,15**
 Ale zachowa ubogiego od miecza ust ich, a z ręki gwałtownika niedostatecznego.
###### **Hi 5,16**
 I będzie nadzieja ubogiemu, a nieprawość stuli gębę swoję.
###### **Hi 5,17**
 Błogosławiony człowiek, którego Bóg karze: karania tedy Pańskiego nie odrzucaj:
###### **Hi 5,18**
 Bo on zrania i leczy: uderza i ręce jego uzdrowią.
###### **Hi 5,19**
 W sześciu ucisków wybawi cię, a w siódmym nie tknie cię złe.
###### **Hi 5,20**
 Wybawi cię od śmierci czasu głodu, a na wojnie z ręki miecza.
###### **Hi 5,21**
 Od bicza języka zakryt będziesz, i nie ulękniesz się nieszczęścia, gdy przyjdzie.
###### **Hi 5,22**
 Będziesz się śmiał w spustoszeniu i w głodzie, i nie będziesz się bał zwierząt ziemskich.
###### **Hi 5,23**
 Ale z kamieńmi pól przymierze twoje, a bestie ziemne spokojneć będą.
###### **Hi 5,24**
 I poznasz, że ma pokój przybytek twój, a nawiedzając ozdobę twoję nie zgrzeszysz.
###### **Hi 5,25**
 Doznasz też, iż rozliczne będzie nasienie twoje, i potomstwo twe jako ziele ziemie.
###### **Hi 5,26**
 Wnidziesz w dostatku do grobu, jako wnoszą kopę pszenice czasu swego.
###### **Hi 5,27**
 Oto jakośmy tego doszli, takci jest: co usłyszawszy umysłem rozbieraj.
