# 1Kor 3 BT5
###### **1Kor 3,1**
 A ja nie mogłem, bracia, przemawiać do was jako do ludzi duchowych, lecz jako do cielesnych, jako do niemowląt w Chrystusie.
###### **1Kor 3,2**
 Mleko wam dawałem, a nie pokarm stały, bo byliście słabi; zresztą i nadal nie jesteście mocni.
###### **1Kor 3,3**
 Ciągle przecież jeszcze jesteście cieleśni. Jeżeli bowiem jest między wami zawiść i niezgoda, to czyż nie jesteście cieleśni i nie postępujecie tylko po ludzku?
###### **1Kor 3,4**
 Skoro jeden mówi: «***Ja jestem Pawła***», a drugi: «***Ja jestem Apollosa***», to czyż nie postępujecie tylko po ludzku?
###### **1Kor 3,5**
 Kimże jest Apollos? Albo kim jest Paweł? Sługami, przez których uwierzyliście według tego, co każdemu dał Pan.
###### **1Kor 3,6**
 Ja siałem, Apollos podlewał, lecz Bóg dał wzrost.
###### **1Kor 3,7**
 Otóż nic nie znaczy ten, który sieje, ani ten, który podlewa, tylko Ten, który daje wzrost – Bóg.
###### **1Kor 3,8**
 Ten, który sieje, i ten, który podlewa, stanowią jedno; każdy według własnego trudu otrzyma należną mu zapłatę.
###### **1Kor 3,9**
 My bowiem jesteśmy pomocnikami Boga, wy zaś – uprawną rolą Bożą i Bożą budowlą.
###### **1Kor 3,10**
 Według danej mi łaski Bożej, jako roztropny budowniczy, położyłem fundament, ktoś inny zaś wznosi budynek. Niech każdy jednak baczy na to, jak buduje.
###### **1Kor 3,11**
 Fundamentu bowiem nikt nie może położyć innego, jak ten, który jest położony, a którym jest Jezus Chrystus.
###### **1Kor 3,12**
 I tak jak ktoś na tym fundamencie buduje: ze złota, ze srebra, z drogich kamieni, z drewna, z trawy lub ze słomy,
###### **1Kor 3,13**
 tak też jawne się stanie dzieło każdego: odsłoni je dzień [Pański]; okaże się bowiem w ogniu, który je wypróbuje, jakie jest.
###### **1Kor 3,14**
 Ten, którego budowla wzniesiona na fundamencie przetrwa, otrzyma zapłatę;
###### **1Kor 3,15**
 ten zaś, którego dzieło spłonie, poniesie szkodę: sam wprawdzie ocaleje, lecz tak jakby przez ogień.
###### **1Kor 3,16**
 Czyż nie wiecie, że jesteście świątynią Boga i że Duch Boży mieszka w was?
###### **1Kor 3,17**
 Jeżeli ktoś zniszczy świątynię Boga, tego zniszczy Bóg. Świątynia Boga jest święta, a wy nią jesteście.
###### **1Kor 3,18**
 Niechaj się nikt nie łudzi. Jeśli ktoś spośród was mniema, że jest mądry na tym świecie, niech się stanie głupim, by posiadł mądrość.
###### **1Kor 3,19**
 Mądrość bowiem tego świata jest głupstwem u Boga. Zresztą jest napisane: On udaremnia zamysły przebiegłych
###### **1Kor 3,20**
 lub także: Wie Pan, że próżne są zamysły mędrców.
###### **1Kor 3,21**
 Niech się przeto nie chełpi nikt z powodu ludzi! Wszystko bowiem jest wasze:
###### **1Kor 3,22**
 czy to Paweł, czy Apollos, czy Kefas; czy to świat, czy życie, czy śmierć, czy to rzeczy teraźniejsze, czy przyszłe, wszystko jest wasze,
###### **1Kor 3,23**
 wy zaś Chrystusa, a Chrystus – Boga.
# 1Kor 3 PAU
###### **1Kor 3,1**
 Bracia! Co do mnie, nie mogłem przemawiać do was jak do ludzi duchowych, ale jak do cielesnych, jak do niemowląt w Chrystusie.
###### **1Kor 3,2**
 Karmiłem was mlekiem, nie zwyczajnym pokarmem, ponieważ do tego nie dorośliście. Zresztą, teraz też do tego nie dorastacie.
###### **1Kor 3,3**
 Jeszcze jesteście zbyt cieleśni. Jeśli bowiem wśród was jest zazdrość i niezgoda, to czyż nie jesteście cieleśni i nie postępujecie tylko po ludzku?
###### **1Kor 3,4**
 Gdy ktoś mówi: „Ja jestem Pawła”, a inny: „Ja Apollosa”, to czy nie jesteście tylko ludźmi cielesnymi?
###### **1Kor 3,5**
 Kim jest Apollos? Kim jest Paweł? Są oni tylko sługami, dzięki którym uwierzyliście. A każdy z nich pracował na tyle, na ile dał mu Pan.
###### **1Kor 3,6**
 Ja sadziłem, Apollos podlewał, ale Bóg dawał wzrost!
###### **1Kor 3,7**
 Nieważny jest ten, który sadzi, ani ten, który podlewa, ale Ten, który daje wzrost - Bóg!
###### **1Kor 3,8**
 Ten, który sadzi, i ten, który podlewa, tworzą jedno. Każdy też otrzyma zapłatę stosownie do własnego wysiłku.
###### **1Kor 3,9**
 Jesteśmy bowiem współpracownikami Boga, a wy jesteście Bożą rolą i budowlą Boga.
###### **1Kor 3,10**
 Według danej mi łaski Boga, jako wprawny architekt położyłem fundament, a ktoś inny na nim buduje. Każdy niech więc zważa, jak buduje:
###### **1Kor 3,11**
 Nikt bowiem nie może położyć innego fundamentu oprócz tego, który już jest położony, a którym jest Jezus Chrystus.
###### **1Kor 3,12**
 A czy ktoś na tym fundamencie buduje ze złota, srebra, szlachetnych kamieni, drewna, siana lub słomy,
###### **1Kor 3,13**
 to okaże się w dniu, w którym wyjdzie na jaw dzieło każdego. Objawi się to w ogniu, gdy każdy czyn przejdzie próbę ognia.
###### **1Kor 3,14**
 Jeśli jakaś budowla wytrzyma, budowniczy dostanie zapłatę.
###### **1Kor 3,15**
 Ten, którego budowla spłonie, poniesie stratę, sam jednak ocaleje, ale tak, jakby przeszedł przez ogień.
###### **1Kor 3,16**
 Czy nie wiecie, że jesteście świątynią Boga i że Duch Boży w was mieszka?
###### **1Kor 3,17**
 Jeśli ktoś zniszczy świątynię Boga, tego zniszczy Bóg. Świątynia Boga jest święta i wy nią jesteście!
###### **1Kor 3,18**
 Nie oszukujcie samych siebie! Jeśli ktoś z was uważa się za mądrego na tym świecie, niech się stanie głupim, aby stać się mądrym.
###### **1Kor 3,19**
 Mądrość bowiem tego świata jest głupstwem u Boga, gdyż napisano: Usidla Bóg mędrców mimo ich przebiegłości.
###### **1Kor 3,20**
 I znowu: Bóg wie, że zamysły mędrców są czcze.
###### **1Kor 3,21**
 Niech więc nikt nie szuka uznania u ludzi, bo i tak wszystko jest wasze:
###### **1Kor 3,22**
 i Paweł, i Apollos, i Kefas, i świat, i życie, i śmierć, i teraźniejszość, i przyszłość. Wszystko jest wasze,
###### **1Kor 3,23**
 wy Chrystusa, a Chrystus Boga.
# 1Kor 3 BP
###### **1Kor 3,1**
 Bracia! Nie mogłem przemawiać do was jak do ludzi kierujących się Duchem, lecz jak do tych, którzy ulegają swoim ludzkim słabościom, jak do niemowląt w Chrystusie.
###### **1Kor 3,2**
 Nakarmiłem was mlekiem, a nie stałym pokarmem, ponieważ nie mogliście go jeszcze przyjąć. Zresztą i teraz jeszcze nie możecie,
###### **1Kor 3,3**
 ponieważ ulegacie swoim ludzkim słabościom. Jeżeli bowiem panuje między wami zazdrość i niezgoda, to czy nie kierujecie się swoimi ludzkimi słabościami i czy nie postępujecie tylko po ludzku?
###### **1Kor 3,4**
 Skoro bowiem ktoś mówi: "Ja należę do Pawła", a inny: "Ja do Apollosa", to czy nie okazujecie się tylko ludźmi?
###### **1Kor 3,5**
 Kim bowiem jest Apollos, kim jest Paweł? Sługami, dzięki którym uwierzyliście, a każdy z nich działał w taki sposób, na jaki pozwolił mu Pan.
###### **1Kor 3,6**
 Ja zasadziłem, Apollos podlewał, lecz Bóg powodował wzrost.
###### **1Kor 3,7**
 Przeto nie liczy się ani ten, który sadzi, ani ten, który podlewa, lecz tylko ten, który daje wzrost, czyli Bóg.
###### **1Kor 3,8**
 I ten, kto sadzi, i ten, kto podlewa, mają jednakową wartość, a każdy z nich otrzyma nagrodę odpowiednią do własnego trudu.
###### **1Kor 3,9**
 Jesteśmy bowiem współpracownikami Boga, a wy jesteście uprawną ziemią Bożą, budowlą Boga.
###### **1Kor 3,10**
 Dzięki udzielonej mi przez Boga łasce położyłem fundament jako zręczny architekt, ale buduje ktoś inny. Niech każdy jednak patrzy na to, jak buduje.
###### **1Kor 3,11**
 Nikt bowiem nie może położyć innego fundamentu, oprócz tego, który już został położony, a jest nim Jezus Chrystus.
###### **1Kor 3,12**
 Czy ktoś buduje na tym fundamencie złotem, srebrem czy drogimi kamieniami, czy też drzewem, sianem lub słomą,
###### **1Kor 3,13**
 okaże się w dzień sądu, który ujawni dzieło każdego. Objawi się on w ogniu, a ogień ten wypróbuje, jakie jest dzieło każdego.
###### **1Kor 3,14**
 Jeżeli czyjeś dzieło ostoi się, to budowniczy otrzyma nagrodę.
###### **1Kor 3,15**
 Jeżeli zaś spłonie, to utraci on nagrodę, choć sam ocaleje, lecz będzie podobny do tego, kto przeszedł przez ogień.
###### **1Kor 3,16**
 Czy nie wiecie, że jesteście świątynią Boga, a Duch Boży mieszka w was.
###### **1Kor 3,17**
 Jeżeli ktoś niszczy świątynię Boga, tego i Bóg zniweczy, ponieważ jest ona święta. Wy właśnie jesteście tą świątynią.
###### **1Kor 3,18**
 Niech nikt nie zwodzi samego siebie. Jeśli komuś z was wydaje się, że jest mędrcem w pojęciu tego świata, niech uważa się za głupca, a wówczas stanie się mądrym.
###### **1Kor 3,19**
 Mądrość bowiem tego świata jest u Boga głupotą, bo napisano, że: "Bóg zaskoczy mędrców mimo ich chytrości".
###### **1Kor 3,20**
 A w innym miejscu: "Pan zna zamysły mędrców i wie, że są bez wartości".
###### **1Kor 3,21**
 Przeto niechaj nikt nie chlubi się ludźmi, bo do was należy wszystko:
###### **1Kor 3,22**
 Paweł, Apollos czy Piotr, świat, życie i śmierć, teraźniejszość i przyszłość. Wszystko jest wasze.
###### **1Kor 3,23**
 Wy zaś należycie do Chrystusa, a Chrystus do Boga.
# 1Kor 3 BR
###### **1Kor 3,1**
 A ja nie mogłem, bracia, przemawiać do was jako do ludzi duchowych, lecz jako do cielesnych, jak do niemowląt w Chrystusie.
###### **1Kor 3,2**
 Mleko wam dawałem, a nie pokarm stały, boście byli słabi; zresztą i nadal nie jesteście mocni.
###### **1Kor 3,3**
 Ciągle przecież jeszcze jesteście cieleśni. Jeżeli bowiem jest między wami zawiść i niezgoda, to czyż nie jesteście cieleśni i nie postępujecie tylko po ludzku?
###### **1Kor 3,4**
 Skoro jeden mówi: 'Ja jestem Pawła', a drugi: 'Ja jestem Apollosa', to czyż nie postępujecie tylko po ludzku?
###### **1Kor 3,5**
 Kimże jest Apollos? Albo kim jest Paweł? Sługami, przez których uwierzyliście według tego, co każdemu dał Pan.
###### **1Kor 3,6**
 Ja siałem, Apollos podlewał, lecz Bóg dał wzrost.
###### **1Kor 3,7**
 Otóż nic nie znaczy ten, który sieje, ani ten, który podlewa, tylko Ten, który daje wzrost-Bóg.
###### **1Kor 3,8**
 Ten, który sieje, i ten, który podlewa, stanowią jedno; każdy według własnego trudu otrzyma należną mu zapłatę.
###### **1Kor 3,9**
 My bowiem jesteśmy pomocnikami Boga, wy zaś - uprawną rolą Bożą i Bożą budowlą.
###### **1Kor 3,10**
 Według danej mi łaski Bożej, jako roztropny budowniczy, położyłem fundament, ktoś inny zaś wznosi budynek. Niech każdy jednak baczy na to, jak buduje.
###### **1Kor 3,11**
 Fundamentu bowiem nikt nie może położyć innego, jak ten, który jest położony, a którym jest Jezus Chrystus.
###### **1Kor 3,12**
 I tak jak ktoś na tym fundamencie buduje: ze złota, ze srebra, z drogich kamieni, z drzewa, z trawy lub ze słomy,
###### **1Kor 3,13**
 tak też jawne się stanie dzieło każdego: odsłoni je dzień [Pański]; okaże się bowiem w ogniu, który je wypróbuje, jakie jest.
###### **1Kor 3,14**
 Ten, którego budowla wzniesiona na fundamencie przetrwa, otrzyma zapłatę;
###### **1Kor 3,15**
 ten zaś, którego dzieło spłonie, poniesie szkodę; sam wprawdzie ocaleje, lecz tak jakby przez ogień.
###### **1Kor 3,16**
 Czyż nie wiecie, żeście świątynią Boga i że Duch Boży mieszka w was?
###### **1Kor 3,17**
 Jeżeli ktoś zniszczy świątynię Boga, tego zniszczy Bóg. Świątynia Boga jest święta, a wy nią jesteście.
###### **1Kor 3,18**
 Niechaj się nikt nie łudzi. Jeśli ktoś spośród was mniema, że jest mądry na tym świecie, niech się stanie głupim, by posiadł mądrość.
###### **1Kor 3,19**
 Mądrość bowiem tego świata jest głupstwem u Boga. Zresztą jest napisane: On udaremnia zamysły przebiegłych
###### **1Kor 3,20**
 lub także: Wie Pan, że próżne są zamysły mędrców.
###### **1Kor 3,21**
 Niech się przeto nie chełpi nikt z powodu ludzi. Wszystko bowiem jest wasze:
###### **1Kor 3,22**
 czy to Paweł, czy Apollos, czy Kefas; czy to świat, czy życie, czy śmierć, czy to rzeczy teraźniejsze, czy przyszłe; wszystko jest wasze,
###### **1Kor 3,23**
 wy zaś Chrystusa, a Chrystus - Boga.
# 1Kor 3 WUJ
###### **1Kor 3,1**
 I ja bracia nie mogłem wam mówić jako duchownym ale jako cielesnym. Jako malutkim w Chrystusie,
###### **1Kor 3,2**
 Dałem wam mleko na napój, nie pokarm: boście jeszcze nie mogli: ale ani teraz jeszcze możecie: bo jeszcze cieleśni jesteście.
###### **1Kor 3,3**
 Abowiem gdyż między wami jest zazdrość i swar: azażeście nie cieleśni, i według człowieka chodzicie?
###### **1Kor 3,4**
 Abowiem gdy kto mówi: Jam jest Pawłów, a drugi: Ja Apollów: azażeście nie ludźmi? Cóż tedy jest Apollo? a co Paweł?
###### **1Kor 3,5**
 Słudzy tego, któremuście uwierzyli, a jako każdemu Pan dał.
###### **1Kor 3,6**
 Jam szczepił, Apollo polewał: ale Bóg dał pomnożenie.
###### **1Kor 3,7**
 A tak ani który szczepi jest czem, ani który polewa: ale Bóg który pomnożenie dawa.
###### **1Kor 3,8**
 A który szczepi, i który polewą, jedno są. A każdy własną zapłatę weźmie według prace swojej.
###### **1Kor 3,9**
 Abowiem jesteśmy pomocnikami Bożemi: rolą Bożą zoraną jesteście budowanim Bożem jesteście.
###### **1Kor 3,10**
 Wedle łaski Bożej, która mi jest dana, jako mądry budowniczy założyłem fundament: a drugi na nim buduje. Lecz każdy niech baczy jako na nim buduje.
###### **1Kor 3,11**
 Abowiem fundamentu innego nikt założyć nie może, okrom tego, który założon jest, który jest Chrystus Jezus.
###### **1Kor 3,12**
 A jeśli kto na tym, fundamencie buduje złoto srebro kamienie drogie, drwa, siano, słomę:
###### **1Kor 3,13**
 Każdego robota jawna będzie: Bo dzień Pański pokaże: bo się w ognia objawi: a każdego roboty jaka jest, ogień sprobuje.
###### **1Kor 3,14**
 Jeśli którego robota zostanie którą nabudował, zapłatę weźmie.
###### **1Kor 3,15**
 Jeśli kótórego robota zgore, szkodę odniesie: lecz sam będzie zbawion, wszakże tak jako przez ogień.
###### **1Kor 3,16**
 Nie wiecie, iżeście kościołem Bożym, a Duch Boży mieszka w was?
###### **1Kor 3,17**
 A jeśli kto kościół Boży zgwałci, zatraci go Bóg. Abowiem kościół Boży święty jest, którym wy jesteście.
###### **1Kor 3,18**
 Niech się żaden nie zwodzi. Jeśli kto zda się być mądrym między wami na tym świecie, niech się stanie głupim, aby był mądrym.
###### **1Kor 3,19**
 Albowiem mądrość świata tego, głupstwem jest u Boga. Bo napisano jest: Pojmam mędrce w chytrości ich.
###### **1Kor 3,20**
 (19b) I zasię: Pan, zna myśli mędrców, iż są próżne.
###### **1Kor 3,21**
 A tak niech się nie chełpi żaden w ludziach. Abowiem wszystko jest wasze:
###### **1Kor 3,22**
 Bądź Paweł, bądź Apollo, bądź Cephas, bądź świat, bądź żywot, bądź śmierć, bądź teraźniejsze rzeczy, bądź przyszłe: bo wszystko wasze jest:
###### **1Kor 3,23**
 A wy Chrystusowi: a Chrystus Boży.
# 1Kor 3 STERN
###### **1Kor 3,1**
 Co do mnie, bracia, nie mogłem do was mówić jak do ludzi duchowych, ale jak do ludzi z tego świata, jak do niemowląt, jeśli idzie o doświadczenia z Mesjaszem.
###### **1Kor 3,2**
 Dałem wam mleko, a nie stały pokarm, bo nie byliście jeszcze na niego gotowi. Ale i teraz nie jesteście na niego gotowi!
###### **1Kor 3,3**
 Bo nadal jesteście tacy jak świat! Czyż nie widać tego po całej tej zazdrości i kłótniach między wami, że postępujecie jak świat i żyjecie według czysto ludzkich zasad?
###### **1Kor 3,4**
 Bo kiedy jeden mówi: "Ja jestem z Sza'ulem", a drugi: "Ja jestem z Apollosem", to czyż nie zachowujecie się czysto po ludzku?
###### **1Kor 3,5**
 Bo kim jest Apollos? Kim jest Sza'ul? Są tylko sługami, za sprawą których zaufaliście. Bo przecież to Pan przywiódł was do ufności za sprawą tego czy innego z nas.
###### **1Kor 3,6**
 Ja zasiałem ziarno, Apollos je podlewał, ale to Bóg sprawił, że urosło.
###### **1Kor 3,7**
 Nie liczy się więc ani ten, kto posiał, ani ten, kto podlewał, tylko Bóg, który daje wzrost -
###### **1Kor 3,8**
 ten, który sieje, i ten, który podlewa, są jednym. Każdy jednak będzie wynagrodzony stosownie do swej pracy.
###### **1Kor 3,9**
 Bo jesteśmy Bożymi współpracownikami; wy jesteście Bożym polem, Bożą budowlą.
###### **1Kor 3,10**
 Korzystając z łaski, którą Bóg mi dał, położyłem fundament jak biegły mistrz budowlany a inny na nim buduje. Lecz niech każdy uważa, jak buduje.
###### **1Kor 3,11**
 Bo nikt nie może położyć fundamentu innego niż ten, który już położono, a którym jest Jeszua Mesjasz.
###### **1Kor 3,12**
 Budując na tym fundamencie niektórzy użyją złota, srebra lub drogich kamieni, inni zaś użyją drewna, trawy bądź słomy.
###### **1Kor 3,13**
 Ale jakie jest dzieło każdego, to się pokaże; odkryje je Dzień, będzie ono bowiem odsłonięte przez ogień - ogień wypróbuje jakość dzieła każdego.
###### **1Kor 3,14**
 Jeśli dzieło, które ktoś wzniósł na fundamencie, przetrwa, otrzyma on nagrodę;
###### **1Kor 3,15**
 jeśli spłonie, będzie musiał ponieść stratę: ujdzie wprawdzie z życiem, ale tak jakby uszedł przez ogień.
###### **1Kor 3,16**
 Czyż nie wiecie, że jesteście Bożą świątynią i że Duch Boży w was mieszka?
###### **1Kor 3,17**
 Jeśli zatem ktoś zniszczy Bożą świątynię, Bóg zniszczy jego. Bo świątynia Boża jest święta, a świątynią tą wy jesteście.
###### **1Kor 3,18**
 Niech nikt się nie łudzi. Jeśli ktoś sądzi, że jest mądry, niech się stanie "głupi", żeby się mógł stać naprawdę mądry.
###### **1Kor 3,19**
 Bo jeśli idzie o Boga, mądrość tego świata jest absurdem; jak powiada Tanach: "Usidla mądrych własną ich przebiegłością",
###### **1Kor 3,20**
 i znów: "Wie Adonai, że bez wartości są myśli mądrych".
###### **1Kor 3,21**
 Niech nikt się więc nie przechwala co do ludzi, bo wszystko jest wasze -
###### **1Kor 3,22**
 czy Sza'ul, czy Apollos, czy Kefa, czy świat, czy życie, czy śmierć, czy teraźniejszość, czy przyszłość: wszystko to do was należy,
###### **1Kor 3,23**
 a wy należycie do Mesjasza, Mesjasz zaś należy do Boga.
# 1Kor 3 TRO
###### **1Kor 3,1**
 **και** *kai* A [[G2532]] [[CONJ]] **εγω** *egō* ja [[G1473]] WTP-1NS **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ηδυνηθην** *ēdynēthēn* mogłem [[G1410]] WTV-AOI-1S-ATT **λαλησαι** *lalēsai* powiedzieć [[G2980]] [[V-AAN]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **ως** *hōs* jak [[G5613]] [[ADV]] **πνευματικοις** *pneumatikois* duchowym [[G4152]] WTA-DPM **αλλ** *all* ale [[G235]] [[CONJ]] **ως** *hōs* jak [[G5613]] [[ADV]] **σαρκικοις** *sarkikois* cielesnym [[G4559]] WTA-DPM **ως** *hōs* jak [[G5613]] [[ADV]] **νηπιοις** *nēpiois* niemowlętom [[G3516]] WTA-DPM **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM
###### **1Kor 3,2**
 **γαλα** *gala* Mleko [[G1051]] WTN-ASN **υμας** *hymas* wam [[G5209]] WTP-2AP **εποτισα** *epotisa* dałem pić [[G4222]] WTV-AAI-1S **και** *kai* i [[G2532]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **βρωμα** *brōma* pokarm [[G1033]] WTN-ASN **ουπω** *oupō* jeszcze nie [[G3768]] [[ADV]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ηδυνασθε** *ēdynasthe* mogliście [[G1410]] WTV-INI-2P-ATT **αλλ** *all* ale [[G235]] [[CONJ]] **ουτε** *oute* ani [[G3777]] [[CONJ]] **ετι** *eti* jeszcze [[G2089]] [[ADV]] **νυν** *nyn* teraz [[G3568]] [[ADV]] **δυνασθε** *dynasthe* możecie [[G1410]] WTV-PNI-2P
###### **1Kor 3,3**
 **ετι** *eti* jeszcze [[G2089]] [[ADV]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **σαρκικοι** *sarkikoi* cieleśni [[G4559]] WTA-NPM **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **οπου** *hopou* kiedy [[G3699]] [[ADV]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **ζηλος** *zēlos* zazdrość – żarliwość [[G2205]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **ερις** *eris* kłótnia – spór [[G2054]] [[N-NSF]] **και** *kai* i [[G2532]] [[CONJ]] **διχοστασιαι** *dichostasiai* poróżnienia – podziały [[G1370]] [[N-NPF]] **ουχι** *ouchi* czyż nie [[G3780]] WTPRT-I **σαρκικοι** *sarkikoi* cieleśni [[G4559]] WTA-NPM **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **και** *kai* i [[G2532]] [[CONJ]] **κατα** *kata* według [[G2596]] [[PREP]] **ανθρωπον** *anthrōpon* człowieka [[G444]] [[N-ASM]] **περιπατειτε** *peripateite* postępujecie – chodzicie [[G4043]] WTV-PAI-2P
###### **1Kor 3,4**
 **οταν** *hotan* Kiedy [[G3752]] [[CONJ]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **λεγη** *legē* mówiłby [[G3004]] WTV-PAS-3S **τις** *tis* ktoś [[G5100]] WTX-NSM **εγω** *egō* ja [[G1473]] WTP-1NS **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **ειμι** *eimi* jestem [[G1510]] WTV-PXI-1S **παυλου** *paulou* Pawła – [mały] [[G3972]] [[N-GSM]] **ετερος** *heteros* inny [[G2087]] [[A-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **εγω** *egō* ja [[G1473]] WTP-1NS **απολλω** *apollō* Apollosa [[G625]] [[N-GSM]] **ουχι** *ouchi* czyż nie [[G3780]] WTPRT-I **σαρκικοι** *sarkikoi* cieleśni [[G4559]] WTA-NPM **εστε** *este* jesteście [[G2075]] WTV-PXI-2P
###### **1Kor 3,5**
 **τις** *tis* Kim [[G5101]] WTI-NSM **ουν** *oun* więc [[G3767]] [[CONJ]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **παυλος** *paulos* Paweł – [mały] [[G3972]] [[N-NSM]] **τις** *tis* kim [[G5101]] WTI-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **απολλως** *apollōs* Apollos [[G625]] [[N-NSM]] **αλλ** *all* ale [[G235]] [[CONJ]] **η** *hē* czy [[G2228]] WTPRT **διακονοι** *diakonoi* słudzy [[G1249]] WTN-NPM **δι** *di* przez [[G1223]] [[PREP]] **ων** *hōn* których [[G3739]] WTR-GPM **επιστευσατε** *episteusate* uwierzyliście [[G4100]] WTV-AAI-2P **και** *kai* i [[G2532]] [[CONJ]] **εκαστω** *hekastō* każdemu [[G1538]] WTA-DSM **ως** *hōs* jak [[G5613]] [[ADV]] **ο** *ho* [[G3588]] [[T-NSM]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **εδωκεν** *edōken* dał [[G1325]] [[V-AAI-3S]]
###### **1Kor 3,6**
 **εγω** *egō* Ja [[G1473]] WTP-1NS **εφυτευσα** *efyteusa* zasadziłem [[G5452]] WTV-AAI-1S **απολλως** *apollōs* Apollos [[G625]] [[N-NSM]] **εποτισεν** *epotisen* dał pić [[G4222]] [[V-AAI-3S]] **αλλ** *all* ale [[G235]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ηυξανεν** *ēuksanen* dał wzrost [[G837]] WTV-IAI-3S
###### **1Kor 3,7**
 **ωστε** *hōste* tak, że [[G5620]] [[CONJ]] **ουτε** *oute* ani [[G3777]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **φυτευων** *fyteuōn* sadzący [[G5452]] [[V-PAP-NSM]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **τι** *ti* czymś [[G5100]] WTX-NSN **ουτε** *oute* ani [[G3777]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **ποτιζων** *potizōn* dający pić [[G4222]] [[V-PAP-NSM]] **αλλ** *all* ale [[G235]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **αυξανων** *auksanōn* dający wzrost [[G837]] [[V-PAP-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]]
###### **1Kor 3,8**
 **ο** *ho* [[G3588]] [[T-NSM]] **φυτευων** *fyteuōn* Sadzący [[G5452]] [[V-PAP-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **ποτιζων** *potizōn* dający pić [[G4222]] [[V-PAP-NSM]] **εν** *hen* jeden [[G1520]] WTA-NSN **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **εκαστος** *hekastos* każdy [[G1538]] [[A-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **τον** *ton* [[G3588]] [[T-ASM]] **ιδιον** *idion* własną [[G2398]] WTA-ASM **μισθον** *misthon* zapłatę [[G3408]] [[N-ASM]] **ληψεται** *lēpsetai* otrzyma [[G2983]] WTV-FDI-3S **κατα** *kata* według [[G2596]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **ιδιον** *idion* własnego [[G2398]] WTA-ASM **κοπον** *kopon* trudu [[G2873]] [[N-ASM]]
###### **1Kor 3,9**
 **θεου** *theou* Boga [[G2316]] [[N-GSM]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εσμεν** *esmen* jesteśmy [[G2070]] WTV-PXI-1P **συνεργοι** *synergoi* współpracownicy [[G4904]] WTA-NPM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **γεωργιον** *geōrgion* rola [[G1091]] WTN-NSN **θεου** *theou* Boga [[G2316]] [[N-GSM]] **οικοδομη** *oikodomē* budowla [[G3619]] [[N-NSF]] **εστε** *este* jesteście [[G2075]] WTV-PXI-2P
###### **1Kor 3,10**
 **κατα** *kata* Według [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **χαριν** *charin* łaski [[G5485]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **την** *tēn* (tej) [[G3588]] WTT-ASF **δοθεισαν** *dotheisan* która została dana [[G1325]] WTV-APP-ASF **μοι** *moi* mi [[G3427]] WTP-1DS **ως** *hōs* jak [[G5613]] [[ADV]] **σοφος** *sofos* mądry [[G4680]] [[A-NSM]] **αρχιτεκτων** *architektōn* architekt – mistrz budowlany [[G753]] [[N-NSM]] **θεμελιον** *themelion* fundament [[G2310]] [[N-ASM]] **τεθεικα** *tetheika* położyłem [[G5087]] WTV-RAI-1S **αλλος** *allos* inny [[G243]] [[A-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **εποικοδομει** *epoikodomei* nadbudowuje [[G2026]] WTV-PAI-3S **εκαστος** *hekastos* każdy [[G1538]] [[A-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **βλεπετω** *blepetō* niech uważa – niech patrzy [[G991]] WTV-PAM-3S **πως** *pōs* jak [[G4459]] [[ADV]] **εποικοδομει** *epoikodomei* nadbudowuje [[G2026]] WTV-PAI-3S
###### **1Kor 3,11**
 **θεμελιον** *themelion* fundamentu [[G2310]] [[N-ASM]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **αλλον** *allon* innego [[G243]] WTA-ASM **ουδεις** *oudeis* nikt [[G3762]] [[A-NSM]] **δυναται** *dynatai* może [[G1410]] WTV-PNI-3S **θειναι** *theinai* położyć [[G5087]] [[V-2AAN]] **παρα** *para* obok [[G3844]] [[PREP]] **τον** *ton* (tego) [[G3588]] [[T-ASM]] **κειμενον** *keimenon* leżącego [[G2749]] WTV-PNP-ASM **ος** *hos* który [[G3739]] WTR-NSM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ιησους** *iēsous* Jezus – [JHWH jest zbawieniem] [[G2424]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]]
###### **1Kor 3,12**
 **ει** *ei* Czy [[G1487]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **τις** *tis* ktoś [[G5100]] WTX-NSM **εποικοδομει** *epoikodomei* nadbudowuje [[G2026]] WTV-PAI-3S **επι** *epi* na [[G1909]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **θεμελιον** *themelion* fundamencie [[G2310]] [[N-ASM]] **τουτον** *touton* tym [[G5126]] WTD-ASM **χρυσον** *chryson* złotem [[G5557]] [[N-ASM]] **αργυρον** *argyron* srebrem [[G696]] [[N-ASM]] **λιθους** *lithous* kamieniami [[G3037]] [[N-APM]] **τιμιους** *timious* drogimi – cennymi [[G5093]] WTA-APM **ξυλα** *ksyla* drzewami [[G3586]] WTN-APN **χορτον** *chorton* sianem – trawą [[G5528]] [[N-ASM]] **καλαμην** *kalamēn* słomą [[G2562]] WTN-ASF
###### **1Kor 3,13**
 **εκαστου** *hekastou* każdego [[G1538]] WTA-GMS **το** *to* [[G3588]] WTT-NSN **εργον** *ergon* dzieło – czyn [[G2041]] WTN-NSN **φανερον** *faneron* widoczny – jawny [[G5318]] WTA-NSN **γενησεται** *genēsetai* stanie się [[G1096]] WTV-FDI-3S **η** *hē* [[G3588]] [[T-NSF]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ημερα** *hēmera* dzień [[G2250]] [[N-NSF]] **δηλωσει** *dēlōsei* pokaże – ukaże [[G1213]] WTV-FAI-3S **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **πυρι** *pyri* ogniu [[G4442]] WTN-DSN **αποκαλυπτεται** *apokalyptetai* jest objawiane [[G601]] WTV-PPI-3S **και** *kai* i [[G2532]] [[CONJ]] **εκαστου** *hekastou* każdego [[G1538]] WTA-GSM **το** *to* [[G3588]] WTT-NSN **εργον** *ergon* dzieło – czyn [[G2041]] WTN-NSN **οποιον** *hopoion* jaki [[G3697]] WTA-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **το** *to* [[G3588]] WTT-NSN **πυρ** *pyr* ogień [[G4442]] WTN-NSN **δοκιμασει** *dokimasei* wypróbuje – doświadczy [[G1381]] WTV-FAI-3S
###### **1Kor 3,14**
 **ει** *ei* Jeśli [[G1487]] WTCOND **τινος** *tinos* czyjeś [[G5100]] WTX-GSM **το** *to* [[G3588]] WTT-NSN **εργον** *ergon* dzieło – czyn [[G2041]] WTN-NSN **μενει** *menei* zostaje – trwa [[G3306]] WTV-PAI-3S **ο** *ho* który [[G3739]] WTR-ASN **επωκοδομησεν** *epōkodomēsen* nadbudował [[G2026]] [[V-AAI-3S]] **μισθον** *misthon* zapłatę [[G3408]] [[N-ASM]] **ληψεται** *lēpsetai* otrzyma [[G2983]] WTV-FDI-3S
###### **1Kor 3,15**
 **ει** *ei* Jeśli [[G1487]] WTCOND **τινος** *tinos* czyjeś [[G5100]] WTX-GSM **το** *to* [[G3588]] WTT-NSN **εργον** *ergon* dzieło – czyn [[G2041]] WTN-NSN **κατακαησεται** *katakaēsetai* zostanie spalone [[G2618]] WTV-2FPI-3S **ζημιωθησεται** *zēmiōthēsetai* poniesie stratę – dozna straty [[G2210]] WTV-FPI-3S **αυτος** *autos* on [[G846]] WTP-NSM **δε** *de* zaś [[G1161]] [[CONJ]] **σωθησεται** *sōthēsetai* zostanie zbawiony – zostanie uratowany [[G4982]] WTV-FPI-3S **ουτως** *houtōs* tak [[G3779]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **ως** *hōs* jak [[G5613]] [[ADV]] **δια** *dia* przez [[G1223]] [[PREP]] **πυρος** *pyros* ogień [[G4442]] [[N-GSN]]
###### **1Kor 3,16**
 **ουκ** *ouk* Nie [[G3756]] [[PRT-N]] **οιδατε** *oidate* wiecie [[G1492]] WTV-RAI-2P **οτι** *hoti* że [[G3754]] [[CONJ]] **ναος** *naos* świątynia – przybytek [[G3485]] [[N-NSM]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **πνευμα** *pneuma* Duch [[G4151]] WTN-NSN **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **οικει** *oikei* mieszka [[G3611]] WTV-PAI-3S **εν** *en* w [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP
###### **1Kor 3,17**
 **ει** *ei* Jeśli [[G1487]] WTCOND **τις** *tis* ktoś [[G5100]] WTX-NSM **τον** *ton* [[G3588]] [[T-ASM]] **ναον** *naon* świątynię – przybytek [[G3485]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **φθειρει** *ftheirei* niszczy [[G5351]] WTV-PAI-3S **φθερει** *ftherei* zniszczy [[G5351]] WTV-FAI-3S **τουτον** *touton* tego [[G5126]] WTD-ASM **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ναος** *naos* świątynia – przybytek [[G3485]] [[N-NSM]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **αγιος** *hagios* święta [[G40]] [[A-NSM]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **οιτινες** *hoitines* którzy [[G3748]] WTR-NPM **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **υμεις** *hymeis* wy [[G5210]] WTP-2NP
###### **1Kor 3,18**
 **μηδεις** *mēdeis* Nikt – Żaden [[G3367]] [[A-NSM]] **εαυτον** *heauton* siebie samego [[G1438]] WTF-3ASM **εξαπατατω** *eksapatatō* niech zwodzi – niech oszukuje [[G1818]] WTV-PAM-3S **ει** *ei* jeśli [[G1487]] WTCOND **τις** *tis* ktoś [[G5100]] WTX-NSM **δοκει** *dokei* uważa [[G1380]] WTV-PAI-3S **σοφος** *sofos* mądry [[G4680]] [[A-NSM]] **ειναι** *einai* być [[G1511]] WTV-PXN **εν** *en* wśród [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **αιωνι** *aiōni* wieku [[G165]] WTN-DSM **τουτω** *toutō* tym [[G5129]] WTD-DSM **μωρος** *mōros* głupi [[G3474]] [[A-NSM]] **γενεσθω** *genesthō* niech stanie się [[G1096]] WTV-2ADM-3S **ινα** *hina* aby [[G2443]] [[CONJ]] **γενηται** *genētai* stałby się [[G1096]] WTV-2ADS-3S **σοφος** *sofos* mądry [[G4680]] [[A-NSM]]
###### **1Kor 3,19**
 **η** *hē* [[G3588]] [[T-NSF]] **γαρ** *gar* Bowiem [[G1063]] [[CONJ]] **σοφια** *sofia* mądrość [[G4678]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSM **κοσμου** *kosmou* świata [[G2889]] [[N-GSM]] **τουτου** *toutou* tego [[G5127]] WTD-GSM **μωρια** *mōria* głupstwo [[G3472]] [[N-NSF]] **παρα** *para* u [[G3844]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Boga [[G2316]] WTN-DSM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **γεγραπται** *gegraptai* jest napisane [[G1125]] WTV-RPI-3S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **δρασσομενος** *drassomenos* który chwyta – łapiący [[G1405]] WTV-PNP-NSM **τους** *tous* [[G3588]] WTT-APM **σοφους** *sofous* mądrych [[G4680]] WTA-APM **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **πανουργια** *panourgia* przebiegłości – przewrotności [[G3834]] [[N-DSF]] **αυτων** *autōn* ich [[G846]] WTP-GPM
###### **1Kor 3,20**
 **και** *kai* i [[G2532]] [[CONJ]] **παλιν** *palin* znowu [[G3825]] [[ADV]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **γινωσκει** *ginōskei* zna [[G1097]] WTV-PAI-3S **τους** *tous* [[G3588]] WTT-APM **διαλογισμους** *dialogismous* rozważania – zamysły [[G1261]] [[N-APM]] **των** *tōn* [[G3588]] WTT-GPM **σοφων** *sofōn* mądrych [[G4680]] WTA-GPM **οτι** *hoti* że [[G3754]] [[CONJ]] **εισιν** *eisin* są [[G1526]] WTV-PXI-3P **ματαιοι** *mataioi* próżne – czcze [[G3152]] WTA-NPM
###### **1Kor 3,21**
 **ωστε** *hōste* Tak, że [[G5620]] [[CONJ]] **μηδεις** *mēdeis* nikt [[G3367]] [[A-NSM]] **καυχασθω** *kauchasthō* niech chlubi się – niech chełpi się [[G2744]] WTV-PNM-3S **εν** *en* w [[G1722]] [[PREP]] **ανθρωποις** *anthrōpois* ludziach [[G444]] WTN-DPM **παντα** *panta* wszystkie [[G3956]] WTA-NPN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **υμων** *hymōn* wasze [[G5216]] WTP-2GP **εστιν** *estin* jest [[G2076]] WTV-PXI-3S
###### **1Kor 3,22**
 **ειτε** *eite* Czy to [[G1535]] [[CONJ]] **παυλος** *paulos* Paweł – [mały] [[G3972]] [[N-NSM]] **ειτε** *eite* czy to [[G1535]] [[CONJ]] **απολλως** *apollōs* Apollos [[G625]] [[N-NSM]] **ειτε** *eite* czy to [[G1535]] [[CONJ]] **κηφας** *kēfas* Kefas – [skała] [[G2786]] [[N-NSM]] **ειτε** *eite* czy to [[G1535]] [[CONJ]] **κοσμος** *kosmos* świat [[G2889]] [[N-NSM]] **ειτε** *eite* czy to [[G1535]] [[CONJ]] **ζωη** *zōē* życie [[G2222]] [[N-NSF]] **ειτε** *eite* czy to [[G1535]] [[CONJ]] **θανατος** *thanatos* śmierć [[G2288]] [[N-NSM]] **ειτε** *eite* czy to [[G1535]] [[CONJ]] **ενεστωτα** *enestōta* które nastaje [[G1764]] WTV-RAP-NPN **ειτε** *eite* czy to [[G1535]] [[CONJ]] **μελλοντα** *mellonta* mające nastąpić [[G3195]] WTV-PAP-NPN **παντα** *panta* wszystkie [[G3956]] WTA-NPN **υμων** *hymōn* wasze [[G5216]] WTP-2GP **εστιν** *estin* jest [[G2076]] WTV-PXI-3S
###### **1Kor 3,23**
 **υμεις** *hymeis* wy [[G5210]] WTP-2NP **δε** *de* zaś [[G1161]] [[CONJ]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **θεου** *theou* Boga [[G2316]] [[N-GSM]]
