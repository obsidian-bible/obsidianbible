# 2Kor 3 BT5
###### **2Kor 3,1**
 Czyż ponownie zaczniemy samych siebie polecać? Albo czy potrzebujemy, jak niektórzy, listów polecających do was lub od was?
###### **2Kor 3,2**
 Wy jesteście naszym listem, pisanym w sercach naszych, listem, który znają i czytają wszyscy ludzie.
###### **2Kor 3,3**
 Powszechnie o was wiadomo, że jesteście listem Chrystusowym dzięki naszemu posługiwaniu, listem napisanym nie atramentem, lecz Duchem Boga żywego; nie na kamiennych tablicach, lecz na żywych tablicach serc.
###### **2Kor 3,4**
 A jeżeli dzięki Chrystusowi taką ufność w Bogu pokładamy,
###### **2Kor 3,5**
 to nie dlatego, żebyśmy uważali, iż jesteśmy w stanie pomyśleć coś sami z siebie, lecz wiemy, że ta możność nasza jest z Boga.
###### **2Kor 3,6**
 On też sprawił, że mogliśmy stać się sługami Nowego Przymierza, przymierza nie litery, lecz Ducha; litera bowiem zabija, Duch zaś ożywia.
###### **2Kor 3,7**
 Ale jeśli posługiwanie śmierci, utrwalone literami w kamieniu, dokonywało się w chwale, tak iż synowie Izraela nie mogli spoglądać na oblicze Mojżesza z powodu blasku jego oblicza, który miał przeminąć,
###### **2Kor 3,8**
 to o ileż bardziej pełne chwały będzie posługiwanie Ducha?
###### **2Kor 3,9**
 Jeżeli bowiem posługiwanie potępieniu jest chwałą, to o ileż bardziej będzie obfitować w chwałę posługiwanie sprawiedliwości.
###### **2Kor 3,10**
 Wobec przeogromnej chwały okazało się w ogóle bez chwały to, co miało chwałę tylko częściową.
###### **2Kor 3,11**
 Jeżeli zaś to, co przemijające, było w chwale, daleko więcej cieszy się chwałą to, co trwa.
###### **2Kor 3,12**
 Żywiąc przeto taką nadzieję, z jawną swobodą postępujemy,
###### **2Kor 3,13**
 a nie tak jak Mojżesz, który zakrywał sobie twarz, ażeby synowie Izraela nie patrzyli na kres tego, co było przemijające.
###### **2Kor 3,14**
 Ale stępiały ich umysły. I tak aż do dnia dzisiejszego, gdy czytają Stare Przymierze, pozostaje [nad nimi] ta sama zasłona, bo odsłania się ona w Chrystusie.
###### **2Kor 3,15**
 I aż po dzień dzisiejszy, gdy czytają Mojżesza, zasłona spoczywa na ich sercach.
###### **2Kor 3,16**
 A kiedy ktoś zwraca się do Pana, zasłona opada.
###### **2Kor 3,17**
 Pan zaś – to Duch, a gdzie jest Duch Pański – tam wolność.
###### **2Kor 3,18**
 My wszyscy z odsłoniętą twarzą wpatrujemy się w jasność Pańską jakby w zwierciadle; za sprawą Ducha Pańskiego, coraz bardziej jaśniejąc, upodabniamy się do Jego obrazu.
# 2Kor 3 PAU
###### **2Kor 3,1**
 Czyż znowu zaczynamy samych siebie polecać? A może potrzebujemy - jak niektórzy - listów polecających do was lub od was?
###### **2Kor 3,2**
 Wy jesteście naszym listem, napisanym w naszych sercach, który znają i czytają wszyscy ludzie.
###### **2Kor 3,3**
 Wiadomo, że jesteście listem Chrystusa dzięki naszemu posługiwaniu. Listem napisanym nie atramentem, lecz Duchem Boga żywego, nie na kamiennych tablicach, lecz na tablicach, którymi są serca z ciała.
###### **2Kor 3,4**
 Taką ufność mamy do Boga dzięki Chrystusowi
###### **2Kor 3,5**
 nie dlatego, że sami uważamy się za godnych, jakby pochodziło to od nas, ale ponieważ nasza zdolność pochodzi od Boga.
###### **2Kor 3,6**
 On nas uzdolnił, byśmy byli sługami Nowego Przymierza, które nie opiera się już na literze, lecz na Duchu. Litera bowiem zabija, a Duch ożywia.
###### **2Kor 3,7**
 Jeśli zaś posługa śmierci, wyryta literami na kamieniach, cieszyła się taką chwałą, że Izraelici nie mogli wpatrywać się w oblicze Mojżesza z powodu chwały jego oblicza, zresztą przemijającej,
###### **2Kor 3,8**
 to o ileż bardziej godna chwały będzie posługa Ducha!
###### **2Kor 3,9**
 Jeśli godna chwały była posługa prowadząca do potępienia, to o wiele bardziej chwalebna jest posługa zmierzająca do usprawiedliwienia!
###### **2Kor 3,10**
 To bowiem, co było obdarzone częściową chwałą, traci swój blask w zestawieniu z niezwykłą obfitością chwały.
###### **2Kor 3,11**
 Jeśli to, co przemija, uznawane było za chwalebne, to o ile bardziej cieszy się chwałą to, co trwa!
###### **2Kor 3,12**
 Mając taką nadzieję, postępujemy z ufną odwagą.
###### **2Kor 3,13**
 Nie tak, jak Mojżesz, który zasłaniał sobie twarz, aby Izraelici nie patrzyli na kres tego, co przemijało.
###### **2Kor 3,14**
 Ich umysły jednak stępiały i po dziś dzień, kiedy czytają Stare Przymierze, okrywa ich ta sama zasłona. Nie zostaje ona zdjęta, gdyż przemija ona w Chrystusie.
###### **2Kor 3,15**
 Do dzisiaj, gdy czytają Mojżesza, zasłona zakrywa ich serca,
###### **2Kor 3,16**
 chociaż on, kiedy zwracał się do Pana, zdejmował zasłonę.
###### **2Kor 3,17**
 Pan jest Duchem, a gdzie jest Duch Pana, tam jest wolność.
###### **2Kor 3,18**
 My wszyscy odzwierciedlamy w naszej odkrytej twarzy chwałę Pana i jesteśmy przemieniani na ten sam obraz, zyskując coraz większą chwałę, za sprawą Pana, który jest Duchem.
# 2Kor 3 BP
###### **2Kor 3,1**
 Czy ponownie zaczynamy sami siebie polecać? Albo czy potrzebujemy, jak inni, listów polecających do was lub od was?
###### **2Kor 3,2**
 Wy jesteście naszym listem polecającym, napisanym w sercach naszych, a znanym i czytanym przez wszystkich ludzi.
###### **2Kor 3,3**
 Wiadomo, że jesteście listem Chrystusa napisanym przez naszą posługę. Listem napisanym nie atramentem, lecz Duchem Boga żywego, nie na tablicach kamiennych, lecz na żywych tablicach serc.
###### **2Kor 3,4**
 Takie zaufanie mamy do Boga dzięki Chrystusowi.
###### **2Kor 3,5**
 Sami z siebie nie jesteśmy zdolni nawet niczego pomyśleć, bo nasze uzdolnienie pochodzi od Boga.
###### **2Kor 3,6**
 On też uzdolnił nas do posługiwania Nowemu Przymierzu, które nie polega na literze, lecz na Duchu. Litera bowiem zabija, Duch zaś ożywia.
###### **2Kor 3,7**
 Jeżeli służba śmierci, czyli Prawu wyrytemu literami na kamieniach, była otaczana chwałą, tak że synowie Izraela nie mogli przypatrywać się obliczu Mojżesza z powodu chwały, która promieniowała z jego oblicza, a która przeminęła,
###### **2Kor 3,8**
 to o ileż bardziej otoczona będzie chwałą służba Ducha?
###### **2Kor 3,9**
 Jeżeli posługiwanie prowadzące na potępienie było otoczone chwałą, to o ileż bardziej obfituje w chwałę służba sprawiedliwości.
###### **2Kor 3,10**
 Wobec przeogromnej chwały Nowego Przymierza częściowa chwała Starego w ogóle nie wygląda na chwałę.
###### **2Kor 3,11**
 Jeżeli bowiem to, co przemijające, miało chwałę, o wiele bardziej będzie otoczone chwałą to, co trwa.
###### **2Kor 3,12**
 Mając zatem taką nadzieję, korzystamy z wielkiej swobody działania.
###### **2Kor 3,13**
 Nie postępujemy tak jak Mojżesz, który "kładł zasłonę na swoje oblicze", aby synowie Izraela nie przypatrywali się zanikaniu chwały, które było symbolem przemijania jego posługi.
###### **2Kor 3,14**
 Stępiały ich umysły, ponieważ aż do dnia dzisiejszego ta sama zasłona okrywa ich podczas czytania Starego Przymierza. Nie została ona z nich zdjęta, ponieważ usuwa ją dopiero Chrystus.
###### **2Kor 3,15**
 I tak aż do dnia dzisiejszego zasłona spoczywa na ich sercach, kiedy czytają Mojżesza.
###### **2Kor 3,16**
 Skoro jednak ktoś nawraca się do Pana, zasłona opada.
###### **2Kor 3,17**
 Pan zaś jest Duchem, a gdzie jest Duch Pana, tam jest i wolność.
###### **2Kor 3,18**
 My wszyscy natomiast z odsłoniętym obliczem oglądamy jak w zwierciadle chwałę Pana i przemieniamy się w ten sam obraz, osiągając coraz większy stopień chwały, a sprawcą tego jest Pan - Duch.
# 2Kor 3 BR
###### **2Kor 3,1**
 Czyż ponownie zaczniemy samych siebie zalecać? Albo czy potrzebujemy, jak niektórzy, listów polecających do was lub od was?
###### **2Kor 3,2**
 Wy jesteście naszym listem, pisanym w sercach naszych, listem, który znają i czytają wszyscy ludzie.
###### **2Kor 3,3**
 Powszechnie o was wiadomo, żeście listem Chrystusowym dzięki naszemu posługiwaniu, listem napisanym nie atramentem, lecz Duchem Boga żywego; nie na kamiennych tablicach, lecz na żywych tablicach serc.
###### **2Kor 3,4**
 A jeżeli dzięki Chrystusowi taką ufność w Bogu pokładamy,
###### **2Kor 3,5**
 to nie dlatego, żebyśmy uważali, że jesteśmy w stanie pomyśleć coś sami z siebie, lecz [wiemy, że] ta możność nasza jest z Boga.
###### **2Kor 3,6**
 On też sprawił, że mogliśmy stać się sługami Nowego Przymierza, przymierza nie litery, lecz Ducha; litera bowiem zabija, Duch zaś ożywia.
###### **2Kor 3,7**
 Lecz jeśli posługiwanie śmierci, utrwalone literami w kamieniu, dokonywało się w chwale, tak iż synowie Izraela nie mogli spoglądać na oblicze Mojżesza z powodu blasku jego oblicza, który miał przeminąć,
###### **2Kor 3,8**
 to o ileż bardziej pełne chwały będzie posługiwanie Ducha?
###### **2Kor 3,9**
 Jeżeli bowiem posługiwanie potępieniu jest chwałą, to o ileż bardziej będzie obfitować w chwałę posługiwanie sprawiedliwości.
###### **2Kor 3,10**
 Wobec przeogromnej chwały okazało się w ogóle bez chwały to, co miało chwałę tylko częściową.
###### **2Kor 3,11**
 Jeżeli zaś to, co przemijające, było w chwale, daleko więcej cieszy się chwałą to, co trwa.
###### **2Kor 3,12**
 Żywiąc przeto taką nadzieję, z jawną swobodą postępujemy,
###### **2Kor 3,13**
 a nie tak jak Mojżesz, który zakrywał sobie twarz, ażeby synowie Izraela nie patrzyli na kres tego, co było przemijające.
###### **2Kor 3,14**
 Ale stępiały ich umysły. I tak aż do dnia dzisiejszego, gdy czytają Stare Przymierze, pozostaje [nad nimi) ta sama zasłona, bo odsłania się ona w Chrystusie.
###### **2Kor 3,15**
 I aż po dzień dzisiejszy, gdy czytają Mojżesza, zasłona spoczywa na ich sercach.
###### **2Kor 3,16**
 A kiedy ktoś zwraca się do Pana, zasłona opada.
###### **2Kor 3,17**
 Pan zaś jest Duchem, a gdzie jest Duch Pański - tam wolność.
###### **2Kor 3,18**
 My wszyscy z odsłoniętą twarzą wpatrujemy się w jasność Pańską jakby w zwierciadle; za sprawą Ducha Pańskiego, coraz bardziej jaśniejąc, upodabniamy się do Jego obrazu.
# 2Kor 3 WUJ
###### **2Kor 3,1**
 Poczynamy zasię zalecać samych siebie? abo czy potrzebujemy (jako niektórzy) listów zaletnych do was, abo od was?
###### **2Kor 3,2**
 Listem naszym wy jesteście, napisanym na sercach naszych, który znają i czytają wszyscy ludzie:
###### **2Kor 3,3**
 Oznajmieni, że jesteście listem Chrystusowym, od nas sprawionym, i napisanym nie inkaustem, ale Duchem Boga żywego: nie na tablicach kamiennych, ale na tablicach serca cielesnych.
###### **2Kor 3,4**
 I mamy takie ufanie ku Bogu przez Chrystusa:
###### **2Kor 3,5**
 Nie iżebyśmy byli dostateczni sami z siebie co myślić jako sami z siebie: ale dostateczność nasza z Boga jest.
###### **2Kor 3,6**
 Który też uczynił nas godnymi sługami nowego Testamentu, nie literą ale Duchem. Bo litera zabija: a Duch ożywia.
###### **2Kor 3,7**
 A jeślić posługowanie śmierci literami wyrażone na kamieniach, było w chwale: tak iż Izraelowi synowie nie mogli patrzyć na oblicze Mojżeszowe, dla chwały oblicza jego, która niszczeje:
###### **2Kor 3,8**
 Jakoż nie więcej posługowanie ducha w chwale będzie?
###### **2Kor 3,9**
 Bo jeśli posługowanie potępienia, jest chwałą: daleko więcej posługowanie sprawiedliwości obfituje w chwale.
###### **2Kor 3,10**
 Abowiem ani uwielbiono jest, co było uwielbiono w tej mierze, dla przewyższającej chwały.
###### **2Kor 3,11**
 Bo jeśliż co niszczeje w chwale jest: daleko więcej co trwa, jest w chwale.
###### **2Kor 3,12**
 Mając tedy taką nadzieję, wielkiej ufności używamy:
###### **2Kor 3,13**
 A nie jako Mojżesz kładł zasłonę, na oblicze swoje, aby synowie Izraelowi nie patrzyli na twarz jego co niszczeje:
###### **2Kor 3,14**
 Ale stępiały zmysły ich. Abowiem aż do dzisiejszego dnia taż zasłona w czytaniu starego Testamentu trwa nie odkryta (ponieważ w Chrystusie niszczeje):
###### **2Kor 3,15**
 Ale aż do dzisiejszego dnia, gdy Mojżesza czytają, zasłona leży na sercu ich.
###### **2Kor 3,16**
 A gdy się nawróci do Pana, będzie odjęta zasłona.
###### **2Kor 3,17**
 A Pan jest Duch. A gdzie Duch Pański, tam wolność.
###### **2Kor 3,18**
 A my wszyscy, odkrytem obliczem na chwałę Pańską w zwierciedle patrząc, w toż wyobrażenie przemienieni bywamy z jasności w jasność, jako od Ducha Pańskiego.
# 2Kor 3 STERN
###### **2Kor 3,1**
 Czy znów zaczynamy samych siebie zachwalać? A może - jak niektórzy - potrzebujemy listów polecających do was lub od was?
###### **2Kor 3,2**
 Wy sami jesteście naszym listem polecającym, wypisanym na naszych sercach, znanym wszystkim i czytanym przez każdego.
###### **2Kor 3,3**
 Nie kryjecie, że jesteście listem od Mesjasza powierzonym naszej pieczy, napisanym nie atramentem, ale duchem Boga żywego, nie na kamiennych tablicach, lecz na ludzkich sercach.
###### **2Kor 3,4**
 Taką mamy pewność przez Mesjasza ku Bogu.
###### **2Kor 3,5**
 Nie jakobyśmy sami z siebie byli zdolni i jakoby można uznać, że cokolwiek pochodzi od nas; przeciwnie, nasza zdolność pochodzi od Boga.
###### **2Kor 3,6**
 On uzdolnił nas nawet do działania w służbie Nowego Przymierza, którego istotą nie jest tekst pisany, ale Duch. Bo tekst pisany sprowadza śmierć, ale Duch daje życie.
###### **2Kor 3,7**
 A skoro to, co działało na rzecz śmierci za sprawą pisanego tekstu wyrytego na kamiennych tablicach, przyszło w chwale - takiej chwale, że lud Israela nie mógł znieść spoglądania na twarz Moszego z powodu jej jasności, mimo że jasność ta już zanikała -
###### **2Kor 3,8**
 to czyż działaniu Ducha nie będzie towarzyszyć chwała jeszcze większa?
###### **2Kor 3,9**
 Bo jeśli była chwała w tym, co działało na rzecz uznawania ludzi za winnych, o ileż bardziej musi obfitować chwała w tym, co działa na rzecz uznania ludzi za niewinnych!
###### **2Kor 3,10**
 W porównaniu z tą większą chwałą to, co było przedtem chwalebne, w istocie teraz nie ma już chwały.
###### **2Kor 3,11**
 Bo jeśli była chwała w tym, co zanikało, o ileż więcej musi być chwały w tym, co trwa.
###### **2Kor 3,12**
 Dlatego, z taką właśnie nadzieją, występujemy bardzo otwarcie -
###### **2Kor 3,13**
 w odróżnieniu od Moszego, który zakrył twarz zasłoną, aby lud Israela nie widział kresu gasnącej jasności.
###### **2Kor 3,14**
 Co więcej, umysły ich stały się jak kamień; bo po dziś dzień ta sama zasłona pozostaje nad nimi, gdy czytają Stare Przymierze; nie została odsłonięta, bo tylko przez Mesjasza zasłona zostaje usunięta.
###### **2Kor 3,15**
 Tak jest, aż do dziś, ilekroć czytają Moszego, zasłona leży na ich sercu.
###### **2Kor 3,16**
 "Lecz - jak powiada Tora - ilekroć ktoś zwraca się do Adonai, zasłona zostaje usunięta".
###### **2Kor 3,17**
 A "Adonai" w tym tekście oznacza Ducha. A gdzie Duch Adonai, tam jest wolność.
###### **2Kor 3,18**
 My wszyscy więc, z twarzą odsłoniętą, jak w zwierciadle widzimy chwałę Pana; nieustannie przemieniani na obraz Jego samego, z jednego stopnia chwały na następny, przez Adonai Ducha.
# 2Kor 3 TRO
###### **2Kor 3,1**
 **αρχομεθα** *archometha* Zaczynamy [[G756]] WTV-PMI-1P **παλιν** *palin* znowu [[G3825]] [[ADV]] **εαυτους** *heautous* siebie samych [[G1438]] WTF-3APM **συνιστανειν** *synistanein* polecać [[G4921]] WTV-PAN **η** *ē* czy [[G2228]] WTPRT **μη** *mē* nie [[G3361]] [[PRT-N]] **χρηζομεν** *chrēzomen* potrzebujemy [[G5535]] WTV-PAI-1P **ως** *hōs* jak [[G5613]] [[ADV]] **τινες** *tines* niektórzy [[G5100]] WTX-NPM **συστατικων** *systatikōn* polecających [[G4956]] WTA-GPM **επιστολων** *epistolōn* listów [[G1992]] WTN-GPF **προς** *pros* do [[G4314]] [[PREP]] **υμας** *hymas* was [[G5209]] WTP-2AP **η** *ē* lub [[G2228]] WTPRT **εξ** *eks* od [[G1537]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **συστατικων** *systatikōn* polecających [[G4956]] WTA-GPM
###### **2Kor 3,2**
 **η** *hē* [[G3588]] [[T-NSF]] **επιστολη** *epistolē* List [[G1992]] [[N-NSF]] **ημων** *hēmōn* nasz [[G2257]] WTP-1GP **υμεις** *hymeis* wy [[G5210]] WTP-2NP **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **εγγεγραμμενη** *engegrammenē* który jest wypisany [[G1449]] WTV-RPP-NSF **εν** *en* w [[G1722]] [[PREP]] **ταις** *tais* [[G3588]] WTT-DPF **καρδιαις** *kardiais* sercach [[G2588]] WTN-DPF **ημων** *hēmōn* naszych [[G2257]] WTP-1GP **γινωσκομενη** *ginōskomenē* który jest znany [[G1097]] WTV-PPP-NSF **και** *kai* i [[G2532]] [[CONJ]] **αναγινωσκομενη** *anaginōskomenē* który jest czytany [[G314]] WTV-PPP-NSF **υπο** *hypo* przez [[G5259]] [[PREP]] **παντων** *pantōn* wszystkich [[G3956]] WTA-GPM **ανθρωπων** *anthrōpōn* ludzi [[G444]] WTN-GPM
###### **2Kor 3,3**
 **φανερουμενοι** *faneroumenoi* Którzy są objawieni – Którzy są uczynieni widocznymi [[G5319]] WTV-PPP-NPM **οτι** *hoti* że [[G3754]] [[CONJ]] **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **επιστολη** *epistolē* list [[G1992]] [[N-NSF]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **διακονηθεισα** *diakonētheisa* który został wysłużony – który został sporządzony przez usługę [[G1247]] WTV-APP-NSF **υφ** *hyf* przez [[G5259]] [[PREP]] **ημων** *hēmōn* nas [[G2257]] WTP-1GP **εγγεγραμμενη** *engegrammenē* który jest wypisany [[G1449]] WTV-RPP-NSF **ου** *ou* nie [[G3756]] [[PRT-N]] **μελανι** *melani* atramentem [[G3188]] WTA-DSN **αλλα** *alla* ale [[G235]] [[CONJ]] **πνευματι** *pneumati* Duchem [[G4151]] WTN-DSN **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ζωντος** *zōntos* żyjącego [[G2198]] WTV-PAP-GSM **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εν** *en* na [[G1722]] [[PREP]] **πλαξιν** *plaksin* tablicach – płytach [[G4109]] WTN-DPF **λιθιναις** *lithinais* kamiennych [[G3035]] WTA-DPF **αλλ** *all* ale [[G235]] [[CONJ]] **εν** *en* na [[G1722]] [[PREP]] **πλαξιν** *plaksin* tablicach – płytach [[G4109]] WTN-DPF **καρδιας** *kardias* serca [[G2588]] [[N-GSF]] **σαρκιναις** *sarkinais* cielesnych [[G4560]] WTA-DPF
###### **2Kor 3,4**
 **πεποιθησιν** *pepoithēsin* Przekonanie – Przeświadczenie [[G4006]] WTN-ASF **δε** *de* zaś [[G1161]] [[CONJ]] **τοιαυτην** *toiautēn* takie [[G5108]] WTD-ASF **εχομεν** *echomen* mamy [[G2192]] WTV-PAI-1P **δια** *dia* przez [[G1223]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **προς** *pros* względem – ku [[G4314]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **θεον** *theon* Boga [[G2316]] [[N-ASM]]
###### **2Kor 3,5**
 **ουχ** *ouch* Nie [[G3756]] [[PRT-N]] **οτι** *hoti* że [[G3754]] [[CONJ]] **ικανοι** *hikanoi* zdolni – odpowiedni [[G2425]] WTA-NPM **εσμεν** *esmen* jesteśmy [[G2070]] WTV-PXI-1P **αφ** *af* od [[G575]] [[PREP]] **εαυτων** *heautōn* siebie samych [[G1438]] WTF-3GPM **λογισασθαι** *logisasthai* liczyć sobie [[G3049]] WTV-ADN **τι** *ti* coś [[G5100]] WTX-ASN **ως** *hōs* jak [[G5613]] [[ADV]] **εξ** *eks* z [[G1537]] [[PREP]] **εαυτων** *heautōn* siebie samego [[G1438]] WTF-3GPM **αλλ** *all* ale [[G235]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **ικανοτης** *hikanotēs* zdolność – sposobność [[G2426]] [[N-NSF]] **ημων** *hēmōn* nasza [[G2257]] WTP-1GP **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **2Kor 3,6**
 **ος** *hos* który [[G3739]] WTR-NSM **και** *kai* i [[G2532]] [[CONJ]] **ικανωσεν** *hikanōsen* uzdolnił – uczynił dość dużymi [[G2427]] [[V-AAI-3S]] **ημας** *hēmas* nas [[G2248]] WTP-1AP **διακονους** *diakonous* sługami [[G1249]] [[N-APM]] **καινης** *kainēs* nowego [[G2537]] WTA-GSF **διαθηκης** *diathēkēs* przymierza [[G1242]] [[N-GSF]] **ου** *ou* nie [[G3756]] [[PRT-N]] **γραμματος** *grammatos* pisma – litery [[G1121]] [[N-GSN]] **αλλα** *alla* ale [[G235]] [[CONJ]] **πνευματος** *pneumatos* ducha [[G4151]] [[N-GSN]] **το** *to* [[G3588]] WTT-NSN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **γραμμα** *gramma* pismo – litera [[G1121]] WTN-NSN **αποκτεινει** *apokteinei* zabija [[G615]] WTV-PAI-3S **το** *to* [[G3588]] WTT-NSN **δε** *de* zaś [[G1161]] [[CONJ]] **πνευμα** *pneuma* duch [[G4151]] WTN-NSN **ζωοποιει** *zōopoiei* ożywia [[G2227]] WTV-PAI-3S
###### **2Kor 3,7**
 **ει** *ei* Jeśli [[G1487]] WTCOND **δε** *de* zaś [[G1161]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **διακονια** *diakonia* posługa – służba [[G1248]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSM **θανατου** *thanatou* śmierci [[G2288]] [[N-GSM]] **εν** *en* w [[G1722]] [[PREP]] **γραμμασιν** *grammasin* literach – pismach [[G1121]] WTN-DPN **εντετυπωμενη** *entetypōmenē* które jest wyryte (które są wyryte) [[G1795]] WTV-RPP-NSF **εν** *en* na [[G1722]] [[PREP]] **λιθοις** *lithois* kamieniach [[G3037]] WTN-DPM **εγενηθη** *egenēthē* stał się (stały się) [[G1096]] [[V-AOI-3S]] **εν** *en* w [[G1722]] [[PREP]] **δοξη** *doksē* chwale [[G1391]] [[N-DSF]] **ωστε** *hōste* tak, że [[G5620]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **δυνασθαι** *dynasthai* móc [[G1410]] WTV-PNN **ατενισαι** *atenisai* spojrzeć – skierować wprost wzrok [[G816]] [[V-AAN]] **τους** *tous* [[G3588]] WTT-APM **υιους** *hyious* synowie [[G5207]] [[N-APM]] **ισραηλ** *israēl* Izraela – [ten, który walczył z Bogiem] [[G2474]] [[N-PRI]] **εις** *eis* na [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **προσωπον** *prosōpon* oblicze – twarz [[G4383]] WTN-ASN **μωσεως** *mōseōs* Mojżesza – [wyciągnąć] [[G3475]] [[N-GSM]] **δια** *dia* z powodu [[G1223]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **δοξαν** *doksan* chwały [[G1391]] WTN-ASF **του** *tou* [[G3588]] WTT-GSN **προσωπου** *prosōpou* oblicza – twarzy [[G4383]] [[N-GSN]] **αυτου** *autou* jego [[G846]] [[P-GSM]] **την** *tēn* [[G3588]] WTT-ASF **καταργουμενην** *katargoumenēn* tracącej na znaczeniu – która jest uznawana za bezużyteczną [[G2673]] WTV-PPP-ASF
###### **2Kor 3,8**
 **πως** *pōs* jak [[G4459]] [[ADV]]-I **ουχι** *ouchi* nie [[G3780]] WTPRT-I **μαλλον** *mallon* bardziej [[G3123]] [[ADV]] **η** *hē* [[G3588]] [[T-NSF]] **διακονια** *diakonia* posługa – służba [[G1248]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSN **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **εσται** *estai* będzie [[G2071]] WTV-FXI-3S **εν** *en* w [[G1722]] [[PREP]] **δοξη** *doksē* chwale [[G1391]] [[N-DSF]]
###### **2Kor 3,9**
 **ει** *ei* Jeśli [[G1487]] WTCOND **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **η** *hē* [[G3588]] [[T-NSF]] **διακονια** *diakonia* posługa – służba [[G1248]] [[N-NSF]] **της** *tēs* [[G3588]] [[T-GSF]] **κατακρισεως** *katakriseōs* potępienia – zasądzenia [[G2633]] [[N-GSF]] **δοξα** *doksa* chwała [[G1391]] [[N-NSF]] **πολλω** *pollō* wiele [[G4183]] WTA-DSM **μαλλον** *mallon* bardziej [[G3123]] [[ADV]] **περισσευει** *perisseuei* obfituje [[G4052]] WTV-PAI-3S **η** *hē* [[G3588]] [[T-NSF]] **διακονια** *diakonia* posługa – służba [[G1248]] [[N-NSF]] **της** *tēs* [[G3588]] [[T-GSF]] **δικαιοσυνης** *dikaiosynēs* sprawiedliwości [[G1343]] [[N-GSF]] **εν** *en* w [[G1722]] [[PREP]] **δοξη** *doksē* chwale [[G1391]] [[N-DSF]]
###### **2Kor 3,10**
 **και** *kai* A [[G2532]] [[CONJ]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ουδε** *oude* ani [[G3761]] [[ADV]] **δεδοξασται** *dedoksastai* jest obdarzone chwałą [[G1392]] WTV-RPI-3S **το** *to* (to) [[G3588]] WTT-NSN **δεδοξασμενον** *dedoksasmenon* które jest obdarzone chwałą [[G1392]] WTV-RPP-NSN **εν** *en* w [[G1722]] [[PREP]] **τουτω** *toutō* tej [[G5129]] WTD-DSN **τω** *tō* [[G3588]] WTT-DSN **μερει** *merei* części [[G3313]] WTN-DSN **ενεκεν** *heneken* ze względu na – z powodu [[G1752]] [[ADV]] **της** *tēs* (tej) [[G3588]] [[T-GSF]] **υπερβαλλουσης** *hyperballousēs* przewyższającej [[G5235]] WTV-PAP-GSF **δοξης** *doksēs* chwały [[G1391]] [[N-GSF]]
###### **2Kor 3,11**
 **ει** *ei* Jeśli [[G1487]] WTCOND **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **καταργουμενον** *katargoumenon* które traci na znaczeniu – które jest uznawane za bezużyteczne [[G2673]] WTV-PPP-NSN **δια** *dia* przez [[G1223]] [[PREP]] **δοξης** *doksēs* chwałę [[G1391]] [[N-GSF]] **πολλω** *pollō* wiele [[G4183]] WTA-DSM **μαλλον** *mallon* bardziej [[G3123]] [[ADV]] **το** *to* (to) [[G3588]] WTT-NSN **μενον** *menon* trwające – pozostające [[G3306]] WTV-PAP-NSN **εν** *en* w [[G1722]] [[PREP]] **δοξη** *doksē* chwale [[G1391]] [[N-DSF]]
###### **2Kor 3,12**
 **εχοντες** *echontes* Mając [[G2192]] WTV-PAP-NPM **ουν** *oun* więc [[G3767]] [[CONJ]] **τοιαυτην** *toiautēn* taką [[G5108]] WTD-ASF **ελπιδα** *elpida* nadzieję [[G1680]] WTN-ASF **πολλη** *pollē* wielką [[G4183]] WTA-DSF **παρρησια** *parrēsia* śmiałością – otwartością [[G3954]] [[N-DSF]] **χρωμεθα** *chrōmetha* posługujemy się – używamy [[G5530]] WTV-PNI-1P
###### **2Kor 3,13**
 **και** *kai* A [[G2532]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **καθαπερ** *kathaper* tak, jak [[G2509]] [[ADV]] **μωσης** *mōsēs* Mojżesz – [wyciągnąć] [[G3475]] [[N-NSM]] **ετιθει** *etithei* kładł [[G5087]] WTV-IAI-3S **καλυμμα** *kalymma* zasłonę [[G2571]] WTN-ASN **επι** *epi* na [[G1909]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **προσωπον** *prosōpon* oblicze – twarz [[G4383]] WTN-ASN **εαυτου** *heautou* swoje [[G1438]] WTF-3GSM **προς** *pros* ku [[G4314]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **μη** *mē* nie [[G3361]] [[PRT-N]] **ατενισαι** *atenisai* spojrzeć – skierować wprost wzrok [[G816]] [[V-AAN]] **τους** *tous* [[G3588]] WTT-APM **υιους** *hyious* synowie [[G5207]] [[N-APM]] **ισραηλ** *israēl* Izraela – [ten, który walczył z Bogiem] [[G2474]] [[N-PRI]] **εις** *eis* na [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **τελος** *telos* koniec [[G5056]] WTN-ASN **του** *tou* (tego) [[G3588]] WTT-GSN **καταργουμενου** *katargoumenou* które traci na znaczeniu – które jest uznawane za bezużyteczne [[G2673]] WTV-PPP-GSN
###### **2Kor 3,14**
 **αλλ** *all* Ale [[G235]] [[CONJ]] **επωρωθη** *epōrōthē* zostało skamieniałe (zostały skamieniałe) – został zatwardzony (zostały zatwardzone) [[G4456]] [[V-API-3S]] **τα** *ta* [[G3588]] WTT-NPN **νοηματα** *noēmata* myśli – pomyślenia [[G3540]] WTN-NPN **αυτων** *autōn* ich [[G846]] WTP-GPM **αχρι** *achri* aż do [[G891]] [[PREP]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **της** *tēs* [[G3588]] [[T-GSF]] **σημερον** *sēmeron* dzisiaj [[G4594]] [[ADV]] **το** *to* (ta) [[G3588]] WTT-NSN **αυτο** *auto* sama [[G846]] WTP-NSN **καλυμμα** *kalymma* zasłona [[G2571]] WTN-NSN **επι** *epi* przy [[G1909]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **αναγνωσει** *anagnōsei* odczytywaniu [[G320]] [[N-DSF]] **της** *tēs* [[G3588]] [[T-GSF]] **παλαιας** *palaias* starego [[G3820]] WTA-GSF **διαθηκης** *diathēkēs* przymierza [[G1242]] [[N-GSF]] **μενει** *menei* pozostaje – trwa [[G3306]] WTV-PAI-3S **μη** *mē* nie [[G3361]] [[PRT-N]] **ανακαλυπτομενον** *anakalyptomenon* która jest odsłaniana – która jest odkrywana [[G343]] WTV-PPP-NSN **ο** *ho* która [[G3739]] WTR-ASN **τι** *ti* jakoś [[G5100]] WTX-NSN **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **καταργειται** *katargeitai* traci na znaczeniu – jest uznawana za bezużyteczną [[G2673]] WTV-PPI-3S
###### **2Kor 3,15**
 **αλλ** *all* Ale [[G235]] [[CONJ]] **εως** *heōs* aż do [[G2193]] [[CONJ]] **σημερον** *sēmeron* dzisiaj [[G4594]] [[ADV]] **ηνικα** *hēnika* ilekroć [[G2259]] [[ADV]] **αναγινωσκεται** *anaginōsketai* jest czytany [[G314]] WTV-PPI-3S **μωσης** *mōsēs* Mojżesz – [wyciągnąć] [[G3475]] [[N-NSM]] **καλυμμα** *kalymma* zasłona [[G2571]] WTN-NSN **επι** *epi* na [[G1909]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **καρδιαν** *kardian* sercu [[G2588]] WTN-ASF **αυτων** *autōn* ich [[G846]] WTP-GPM **κειται** *keitai* leży [[G2749]] WTV-PNI-3S
###### **2Kor 3,16**
 **ηνικα** *hēnika* Kiedy- [[G2259]] [[ADV]] **δ** *d* zaś [[G1161]] [[CONJ]] **αν** *an* kolwiek [[G302]] WTPRT **επιστρεψη** *epistrepsē* nawróciłby się – zawróciłby [[G1994]] WTV-AAS-3S **προς** *pros* do [[G4314]] [[PREP]] **κυριον** *kyrion* Pana [[G2962]] [[N-ASM]] **περιαιρειται** *periaireitai* jest zdejmowana – jest zrzucona [[G4014]] WTV-PPI-3S **το** *to* [[G3588]] WTT-NSN **καλυμμα** *kalymma* zasłona [[G2571]] WTN-NSN
###### **2Kor 3,17**
 **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **κυριος** *kyrios* Pan [[G2962]] [[N-NSM]] **το** *to* [[G3588]] WTT-NSN **πνευμα** *pneuma* Duch [[G4151]] WTN-NSN **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **ου** *hou* gdzie [[G3757]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **πνευμα** *pneuma* Duch [[G4151]] WTN-NSN **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **εκει** *ekei* tam [[G1563]] [[ADV]] **ελευθερια** *eleutheria* wolność [[G1657]] [[N-NSF]]
###### **2Kor 3,18**
 **ημεις** *hēmeis* My [[G2249]] WTP-1NP **δε** *de* zaś [[G1161]] [[CONJ]] **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **ανακεκαλυμμενω** *anakekalymmenō* które jest odsłonięte – które jest odkryte [[G343]] WTV-RPP-DSN **προσωπω** *prosōpō* oblicze – twarz [[G4383]] WTN-DSN **την** *tēn* [[G3588]] WTT-ASF **δοξαν** *doksan* chwałę [[G1391]] WTN-ASF **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **κατοπτριζομενοι** *katoptrizomenoi* odbijając – odzwierciedlając [[G2734]] WTV-PMP-NPM **την** *tēn* (na ten) [[G3588]] WTT-ASF **αυτην** *autēn* sam [[G846]] [[P-ASF]] **εικονα** *eikona* obraz [[G1504]] WTN-ASF **μεταμορφουμεθα** *metamorfoumetha* jesteśmy przeobrażani – jesteśmy przemieniani [[G3339]] WTV-PPI-1P **απο** *apo* z [[G575]] [[PREP]] **δοξης** *doksēs* chwały [[G1391]] [[N-GSF]] **εις** *eis* w – ku [[G1519]] [[PREP]] **δοξαν** *doksan* chwałę [[G1391]] WTN-ASF **καθαπερ** *kathaper* tak, jak [[G2509]] [[ADV]] **απο** *apo* od [[G575]] [[PREP]] **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]]
