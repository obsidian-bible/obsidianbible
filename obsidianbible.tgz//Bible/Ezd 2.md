# Ezd 2 BT5
###### **Ezd 2,1**
 A oto mieszkańcy tego okręgu, którzy przybyli z niewoli na obczyźnie; uprowadził ich na wygnanie do Babilonii Nabuchodonozor, król babiloński, lecz powrócili oni do Jerozolimy i Judy – każdy do swego miasta.
###### **Ezd 2,2**
 Przyszli oni z Zorobabelem, Jozuem, Nehemiaszem, Serajaszem, Reelajaszem, Nachamanim, Mardocheuszem, Bilszanem, Misparem, Bigwajem, Rechumem, Baaną. Liczba mężów ludu izraelskiego:
###### **Ezd 2,3**
 synów Pareosza – dwa tysiące stu siedemdziesięciu dwu;
###### **Ezd 2,4**
 synów Szefatiasza – trzystu siedemdziesięciu dwu;
###### **Ezd 2,5**
 synów Aracha – siedmiuset siedemdziesięciu pięciu;
###### **Ezd 2,6**
 synów Pachat-Moaba z linii synów Jozuego i Joaba – dwa tysiące ośmiuset dwunastu;
###### **Ezd 2,7**
 synów Elama – tysiąc dwustu pięćdziesięciu czterech;
###### **Ezd 2,8**
 synów Zattu – dziewięciuset czterdziestu pięciu;
###### **Ezd 2,9**
 synów Zacheusza – siedmiuset sześćdziesięciu;
###### **Ezd 2,10**
 synów Baniego – sześciuset czterdziestu dwu;
###### **Ezd 2,11**
 synów Bebaja – sześciuset dwudziestu trzech;
###### **Ezd 2,12**
 synów Azgada – tysiąc dwustu dwudziestu dwu;
###### **Ezd 2,13**
 synów Adonikama – sześciuset sześćdziesięciu sześciu;
###### **Ezd 2,14**
 synów Bigwaja – dwa tysiące pięćdziesięciu sześciu;
###### **Ezd 2,15**
 synów Adina – czterystu pięćdziesięciu czterech;
###### **Ezd 2,16**
 synów Atera z linii Ezechiasza – dziewięćdziesięciu ośmiu; synów Azzura – czterystu trzydziestu dwu; synów Hodiasza – stu jeden;
###### **Ezd 2,17**
 synów Besaja – trzystu dwudziestu trzech;
###### **Ezd 2,18**
 synów Charifa – stu dwunastu;
###### **Ezd 2,19**
 synów Chaszuma – dwustu dwudziestu trzech;
###### **Ezd 2,20**
 synów Gibbara – dziewięćdziesięciu pięciu;
###### **Ezd 2,21**
 mężów z Betlejem – stu dwudziestu trzech;
###### **Ezd 2,22**
 mężów z Netofy – pięćdziesięciu sześciu;
###### **Ezd 2,23**
 mężów z Anatot – stu dwudziestu ośmiu;
###### **Ezd 2,24**
 mężów z Bet-Azmawet – czterdziestu dwu;
###### **Ezd 2,25**
 mężów z Kiriat-Jearim, Kefiry i Beerot – siedmiuset czterdziestu trzech;
###### **Ezd 2,26**
 mężów z Rama i Geba – sześciuset dwudziestu jeden;
###### **Ezd 2,27**
 mężów z Mikmas – stu dwudziestu dwu;
###### **Ezd 2,28**
 mężów z Betel i Aj – dwustu dwudziestu trzech;
###### **Ezd 2,29**
 mężów z Nebo – pięćdziesięciu dwu;
###### **Ezd 2,30**
 potomków Magbisza – stu pięćdziesięciu sześciu;
###### **Ezd 2,31**
 potomków drugiego Elama – tysiąc dwustu pięćdziesięciu czterech;
###### **Ezd 2,32**
 potomków Charima – trzystu dwudziestu;
###### **Ezd 2,33**
 mężów z Lod, Chadid i Ono – siedmiuset dwudziestu pięciu;
###### **Ezd 2,34**
 mężów z Jerycha – trzystu czterdziestu pięciu;
###### **Ezd 2,35**
 potomków Senai – trzy tysiące sześciuset trzydziestu.
###### **Ezd 2,36**
 Kapłani: potomków Jedajasza z domu Jozuego – dziewięciuset siedemdziesięciu trzech;
###### **Ezd 2,37**
 potomków Immera – tysiąc pięćdziesięciu dwu;
###### **Ezd 2,38**
 potomków Paszchura – tysiąc dwustu czterdziestu siedmiu;
###### **Ezd 2,39**
 potomków Charima – tysiąc siedemnastu.
###### **Ezd 2,40**
 Lewici: potomków Jozuego z linii Kadmiela, Binnuja, Hodawiasza – siedemdziesięciu czterech.
###### **Ezd 2,41**
 Śpiewacy: potomków Asafa – stu dwudziestu ośmiu.
###### **Ezd 2,42**
 Odźwierni: potomków Szalluma, potomków Atera, potomków Talmona, potomków Akkuba, potomków Chatity, potomków Szobaja – wszystkich razem stu trzydziestu dziewięciu.
###### **Ezd 2,43**
 Niewolnicy świątynni: potomkowie Sichy, potomkowie Chasufy, potomkowie Tabbaota,
###### **Ezd 2,44**
 potomkowie Kerosa, potomkowie Sii, potomkowie Padona,
###### **Ezd 2,45**
 potomkowie Lebany, potomkowie Chagaby, potomkowie Akkuba,
###### **Ezd 2,46**
 potomkowie Chagaba, potomkowie Szamlaja, potomkowie Chanana,
###### **Ezd 2,47**
 potomkowie Giddela, potomkowie Gachara, potomkowie Reajasza,
###### **Ezd 2,48**
 potomkowie Resina, potomkowie Nekody, potomkowie Gazzama,
###### **Ezd 2,49**
 potomkowie Uzzy, potomkowie Paseacha, potomkowie Besaja,
###### **Ezd 2,50**
 potomkowie Asny, potomkowie Meunitów, potomkowie Nefisytów,
###### **Ezd 2,51**
 potomkowie Bakbuka, potomkowie Chakufy, potomkowie Charchura,
###### **Ezd 2,52**
 potomkowie Basluta, potomkowie Mechidy, potomkowie Charszy,
###### **Ezd 2,53**
 potomkowie Barkosa, potomkowie Sisery, potomkowie Temacha,
###### **Ezd 2,54**
 potomkowie Nesjacha, potomkowie Chatify.
###### **Ezd 2,55**
 Potomkowie niewolników Salomona: potomkowie Sotaja, potomkowie Hassofereta, potomkowie Perudy,
###### **Ezd 2,56**
 potomkowie Jaali, potomkowie Darkona, potomkowie Giddela,
###### **Ezd 2,57**
 potomkowie Szefatiasza, potomkowie Chattila, potomkowie Pocheret-Hassebajima, potomkowie Amiego.
###### **Ezd 2,58**
 Wszystkich niewolników świątynnych i potomków niewolników Salomona – trzystu dziewięćdziesięciu dwu.
###### **Ezd 2,59**
 A oto ci, którzy wyszli z Tel-Melach, Tel-Charsza, Kerub, Addan, Immer, lecz nie mogli udowodnić, że rod ich i pochodzenie wywodzi się z Izraela:
###### **Ezd 2,60**
 potomków Delajasza, potomków Tobiasza, potomków Nekody – sześciuset pięćdziesięciu dwu.
###### **Ezd 2,61**
 A z kapłanów: potomkowie Chobajasza, potomkowie Hakkosa, potomkowie Barzillaja, który wziął za żonę jedną z córek Barzillaja Gileadyty i przybrał jego imię.
###### **Ezd 2,62**
 Ci szukali swego rodowodu, lecz go nie odnaleziono; toteż zostali oni jako nieczyści wykluczeni z kapłaństwa,
###### **Ezd 2,63**
 a namiestnik zakazał im spożywać z pokarmów najświętszych, aż się zjawi kapłan dla urim i tummim.
###### **Ezd 2,64**
 Cała ta wyprawa razem liczyła czterdzieści dwa tysiące trzysta sześćdziesiąt osób,
###### **Ezd 2,65**
 oprócz ich niewolników i niewolnic; tych było siedem tysięcy trzysta trzydzieści siedem; mieli oni też dwustu śpiewaków i śpiewaczek.
###### **Ezd 2,66**
 Koni mieli oni siedemset trzydzieści sześć, mułów – dwieście czterdzieści pięć,
###### **Ezd 2,67**
 wielbłądów – czterysta trzydzieści pięć, osłów – sześć tysięcy siedemset dwadzieścia.
###### **Ezd 2,68**
 A niektórzy z naczelników rodów – przy wejściu swym do domu Pańskiego w Jerozolimie – złożyli dary dla domu Bożego, aby odbudowano go na dawnym miejscu.
###### **Ezd 2,69**
 Według zamożności swej dali do skarbca na rzecz kultu: sześćdziesiąt jeden tysięcy drachm złota, pięć tysięcy min srebra oraz sto szat kapłańskich.
###### **Ezd 2,70**
  Kapłani, lewici i część ludu osiedlili się w Jerozolimie, a śpiewacy, odźwierni i niewolnicy świątynni – w miastach swoich; również cała reszta Izraela osiedliła się w swoich miastach.
# Ezd 2 PAU
###### **Ezd 2,1**
 Oto mieszkańcy prowincji, którzy powrócili z wygnania - z Babilonii, dokąd uprowadził ich Nabuchodonozor, król babiloński. Wrócili oni do Jerozolimy i do Judei, każdy do swojego miasta.
###### **Ezd 2,2**
 Przybyli z Zorobabelem, Jozuem, Nehemiaszem, Serajaszem, Reelajaszem, Nachamanim, Mardocheuszem, Bilszanem, Misparem, Bigwajem, Rechumem, Baaną. Liczba Izraelitów była następująca:
###### **Ezd 2,3**
 z rodu Parosza - dwa tysiące stu siedemdziesięciu dwóch,
###### **Ezd 2,4**
 z rodu Szefatiasza - trzystu siedemdziesięciu dwóch,
###### **Ezd 2,5**
 z rodu Aracha - siedmiuset siedemdziesięciu pięciu,
###### **Ezd 2,6**
 z rodu Pachat-Moaba: potomkowie Jozuego i Joaba - dwa tysiące ośmiuset dwunastu,
###### **Ezd 2,7**
 z rodu Elama - tysiąc dwustu pięćdziesięciu czterech,
###### **Ezd 2,8**
 z rodu Zattua - dziewięciuset czterdziestu pięciu,
###### **Ezd 2,9**
 z rodu Zacheusza - siedmiuset sześćdziesięciu,
###### **Ezd 2,10**
 z rodu Baniego - sześciuset czterdziestu dwóch,
###### **Ezd 2,11**
 z rodu Bebaja - sześciuset dwudziestu trzech,
###### **Ezd 2,12**
 z rodu Azgada - tysiąc dwustu dwudziestu dwóch,
###### **Ezd 2,13**
 z rodu Adonikama - sześciuset sześćdziesięciu sześciu,
###### **Ezd 2,14**
 z rodu Bigwaja - dwa tysiące pięćdziesięciu sześciu,
###### **Ezd 2,15**
 z rodu Adina - czterystu pięćdziesięciu czterech,
###### **Ezd 2,16**
 z rodu Atera: potomkowie Ezechiasza - dziewięćdziesięciu ośmiu,
###### **Ezd 2,17**
 z rodu Besaja - trzystu dwudziestu trzech,
###### **Ezd 2,18**
 z rodu Joraha - stu dwunastu,
###### **Ezd 2,19**
 z rodu Chaszuma - dwustu dwudziestu trzech,
###### **Ezd 2,20**
 z rodu Gibbara - dziewięćdziesięciu pięciu;
###### **Ezd 2,21**
 mieszkańców Betlejem - stu dwudziestu trzech,
###### **Ezd 2,22**
 mieszkańców Netofy - pięćdziesięciu sześciu,
###### **Ezd 2,23**
 mieszkańców Anatot - stu dwudziestu ośmiu,
###### **Ezd 2,24**
 mieszkańców Azmawet - czterdziestu dwóch,
###### **Ezd 2,25**
 mieszkańców Kiriat-Jearim, Kefiry i Beerot - siedmiuset czterdziestu trzech,
###### **Ezd 2,26**
 mieszkańców Rama i Geba - sześciuset dwudziestu jeden,
###### **Ezd 2,27**
 mieszkańców Mikmas - stu dwudziestu dwóch,
###### **Ezd 2,28**
 mieszkańców Betel i Aj - dwustu dwudziestu trzech;
###### **Ezd 2,29**
 z rodu Nebo - pięćdziesięciu dwóch,
###### **Ezd 2,30**
 z rodu Magbisza - stu pięćdziesięciu sześciu,
###### **Ezd 2,31**
 z rodu Elama - tysiąc dwustu pięćdziesięciu czterech,
###### **Ezd 2,32**
 z rodu Charima - trzystu dwudziestu,
###### **Ezd 2,33**
 mieszkańców Lod, Chadid i Ono - siedmiuset dwudziestu pięciu,
###### **Ezd 2,34**
 mieszkańców Jerycha - trzystu czterdziestu pięciu,
###### **Ezd 2,35**
 z rodu Senai - trzy tysiące sześciuset trzydziestu.
###### **Ezd 2,36**
 Kapłani: z rodu Jedajasza, potomkowie Jozuego - dziewięciuset siedemdziesięciu trzech,
###### **Ezd 2,37**
 z rodu Immera - tysiąc pięćdziesięciu dwóch,
###### **Ezd 2,38**
 z rodu Paszchura - tysiąc dwustu czterdziestu siedmiu,
###### **Ezd 2,39**
 z rodu Charima - tysiąc siedemnastu.
###### **Ezd 2,40**
 Lewici: z rodu Jozuego, potomkowie Kadmiela, Binnuja i Hodawiasza - siedemdziesięciu czterech.
###### **Ezd 2,41**
 Śpiewacy: z rodu Asafa - stu dwudziestu ośmiu.
###### **Ezd 2,42**
 Odźwierni: z rodu Szalluma, z rodu Atera, z rodu Talmona, z rodu Akkuba, z rodu Chatify, z rodu Szobaja, wszystkich razem - stu trzydziestu dziewięciu.
###### **Ezd 2,43**
 Słudzy świątyni: z rodu Sichy, z rodu Chasufy, z rodu Tabbaota,
###### **Ezd 2,44**
 z rodu Kerosa, z rodu Sijacha, synowie Padona,
###### **Ezd 2,45**
 z rodu Lebany, z rodu Chagaby, z rodu Akkuba,
###### **Ezd 2,46**
 z rodu Chagaba, z rodu Szamlaja, z rodu Chanana,
###### **Ezd 2,47**
 z rodu Giddela, z rodu Gachara, z rodu Reajasza,
###### **Ezd 2,48**
 z rodu Resina, z rodu Nekody, z rodu Gazzama,
###### **Ezd 2,49**
 z rodu Uzzy, z rodu Paseacha, z rodu Besaja,
###### **Ezd 2,50**
 z rodu Asny, z rodu Meunitów, z rodu Nefisytów,
###### **Ezd 2,51**
 z rodu Bakbuka, z rodu Chakufy, z rodu Charchura,
###### **Ezd 2,52**
 z rodu Basluta, z rodu Mechidy, z rodu Charszy,
###### **Ezd 2,53**
 z rodu Barkosa, z rodu Sisery, z rodu Temacha,
###### **Ezd 2,54**
 z rodu Nesjacha, z rodu Chatify.
###### **Ezd 2,55**
 Potomkowie sług Salomona: z rodu Sotaja, z rodu Hassofereta, z rodu Perudy,
###### **Ezd 2,56**
 z rodu Jaali, z rodu Darkona, z rodu Giddela,
###### **Ezd 2,57**
 z rodu Szefatiasza, z rodu Chattila, z rodu Pocheret-Hassebajima, z rodu Amiego,
###### **Ezd 2,58**
 wszystkich razem sług świątyni i potomków sług Salomona - trzystu dziewięćdziesięciu dwóch.
###### **Ezd 2,59**
 Oto ci, którzy przybyli z Tel-Melach, Tel-Charsza, Kerub, Addan, Immer, lecz nie mogli wykazać się rodowodem i pochodzeniem izraelskim:
###### **Ezd 2,60**
 z rodu Delajasza, z rodu Tobiasza, z rodu Nekody - sześciuset pięćdziesięciu dwóch.
###### **Ezd 2,61**
 Spośród kapłanów byli to: potomkowie z rodu Chobajasza, z rodu Hakkosa i z rodu Barzillaja, który ożenił się z jedną z córek Barzillaja Gileadyty i przybrał jego imię.
###### **Ezd 2,62**
 Szukali oni swoich rodowodów, ale ich nie znaleźli. Dlatego jako nieczyści zostali wykluczeni ze sprawowania funkcji kapłańskich.
###### **Ezd 2,63**
 Namiestnik zakazał im jedzenia najświętszych pokarmów, dopóki nie pojawi się kapłan do urim i tummim.
###### **Ezd 2,64**
 Ogółem ta grupa repatriantów liczyła czterdzieści dwa tysiące trzysta sześćdziesiąt osób,
###### **Ezd 2,65**
 nie licząc ich sług i służebnic, których było siedem tysięcy trzysta trzydzieści siedem. Mieli także dwustu śpiewaków i śpiewaczek,
###### **Ezd 2,66**
 ponadto siedemset trzydzieści sześć koni, dwieście czterdzieści pięć mułów
###### **Ezd 2,67**
 oraz czterysta trzydzieści pięć wielbłądów i sześć tysięcy siedemset dwadzieścia osłów.
###### **Ezd 2,68**
 Gdy przybyli do domu PANA w Jerozolimie, wielu przywódców rodów złożyło dary na odbudowę domu Bożego na jego dawnym miejscu.
###### **Ezd 2,69**
 Według swoich możliwości złożyli oni do skarbca na potrzeby kultu sześćdziesiąt jeden tysięcy drachm złota, pięć tysięcy min srebra i sto szat kapłańskich.
###### **Ezd 2,70**
 Kapłani, lewici i część ludu osiedliła się w Jerozolimie, śpiewacy, odźwierni i słudzy świątyni w swoich osadach, a cała reszta Izraela w swoich miastach.
# Ezd 2 BP
###### **Ezd 2,1**
 Oto są synowie kraju [Judy], którzy powrócili z niewoli i wygnania, uprowadzeni tam przez Nebukadnezara, króla Babilonu, i którzy powrócili do Jeruzalem i Judei, każdy do swego miasta.
###### **Ezd 2,2**
 Przybyli razem z Zorobabelem, Jozuem, Nehemiaszem, Serają, Reelają, Nachamanim, Mordokajem, Bilszanem, Misparem, Bigwajem, Rechumem i Baaną. Oto wykaz mężów ludu izraelskiego:
###### **Ezd 2,3**
 Synów Parosza - 2172.
###### **Ezd 2,4**
 synów Szefatji - 372.
###### **Ezd 2,5**
 synów Aracha - 775.
###### **Ezd 2,6**
 synów Pachat-Moaba z linii Jozuego i Joaba - 2812.
###### **Ezd 2,7**
 synów Elama - 1254.
###### **Ezd 2,8**
 synów Zattua - 945.
###### **Ezd 2,9**
 synów Zakkaja - 760.
###### **Ezd 2,10**
 synów Baniego - 642.
###### **Ezd 2,11**
 synów Bebaja - 623.
###### **Ezd 2,12**
 synów Azgada - 1222.
###### **Ezd 2,13**
 synów Adonikama - 666.
###### **Ezd 2,14**
 synów Bigwaja - 2056.
###### **Ezd 2,15**
 synów Adina - 454.
###### **Ezd 2,16**
 synów Atera z linii Ezechiasza - 98. synów Azura - 432. synów Hodji - 101.
###### **Ezd 2,17**
 synów Becaja - 323.
###### **Ezd 2,18**
 synów Jory - 112.
###### **Ezd 2,19**
 synów Chaszuma - 223.
###### **Ezd 2,20**
 synów Gibbara - 95.
###### **Ezd 2,21**
 mężów z Betlejem - 123.
###### **Ezd 2,22**
 mężów z Netofa - 56.
###### **Ezd 2,23**
 mężów z Anatot - 128.
###### **Ezd 2,24**
 synów z Bet-Azmawet - 42.
###### **Ezd 2,25**
 z Kirjat-Jearim, Kefira i Beerot - 743.
###### **Ezd 2,26**
 z Rama i Gęba - 621.
###### **Ezd 2,27**
 mężów z Mikmas - 122.
###### **Ezd 2,28**
 mężów z Betel i Aj - 223.
###### **Ezd 2,29**
 synów Nebo - 52.
###### **Ezd 2,30**
 synów Magbisza - 156.
###### **Ezd 2,31**
 synów drugiego Elama - 1254.
###### **Ezd 2,32**
 synów Charima - 320.
###### **Ezd 2,33**
 mężów z Lod, Chadid i Ono - 725.
###### **Ezd 2,34**
 z Jerycha - 345.
###### **Ezd 2,35**
 synów Senai - 3630.
###### **Ezd 2,36**
 [A oto wykaz] kapłanów: synów Jedaji z domu Jozuego - 973.
###### **Ezd 2,37**
 synów Immera - 1052.
###### **Ezd 2,38**
 synów Paszchura - 1247.
###### **Ezd 2,39**
 synów Charima - 1017.
###### **Ezd 2,40**
 Spośród lewitów [wrócili] synowie Jozuego z linii Kadmiela, Binnuja, Hodawji - 74.
###### **Ezd 2,41**
 spośród śpiewaków - 120 synów Asafa.
###### **Ezd 2,42**
 Spośród odźwiernych [wrócili] synowie Szalluma, synowie Atera, synowie Talmona, synowie Akkuba, synowie Chatity i synowie Szobaja - wszystkich razem 139.
###### **Ezd 2,43**
 Spośród niewolników Świątyni [wrócili] synowie Cichy, synowie Chasufy, synowie Tabbaota,
###### **Ezd 2,44**
 synowie Kerosa, synowie Sii, synowie Fadona,
###### **Ezd 2,45**
 synowie Lebany, synowie Chagaba, synowie Akkuba,
###### **Ezd 2,46**
 synowie Chagaba, synowie Szamlaja, synowie Chanana,
###### **Ezd 2,47**
 synowie Giddela, synowie Gach ara, synowie Reaji,
###### **Ezd 2,48**
 synowie Recina, synowie Nekody, synowie Gazzama,
###### **Ezd 2,49**
 synowie Uzzy, synowie Fasecha, synowie Besaja,
###### **Ezd 2,50**
 synowie Asny, synowie Meunitów, synowie Nefisytów,
###### **Ezd 2,51**
 synowie Bakkuka, synowie Chakufy, synowie Charchura,
###### **Ezd 2,52**
 synowie Baciuta, synowie Mechidy, synowie Charszy,
###### **Ezd 2,53**
 synowie Barkosa, synowie Sisery, synowie Tamacha,
###### **Ezd 2,54**
 synowie Necijacha i synowie Chatify.
###### **Ezd 2,55**
 Spośród synów niewolników Salomona [wrócili] synowie Sotaja, synowie Hassofereta, synowie Ferudy,
###### **Ezd 2,56**
 synowie Jaali, synowie Darkona, synowie Giddela,
###### **Ezd 2,57**
 synowie Szefatji, synowie Chattiia, synowie Pokeret-Haccebajima i synowie Amiego.
###### **Ezd 2,58**
 Ogólna liczba niewolników Świątyni i synów niewolników Salomona wynosiła 392.
###### **Ezd 2,59**
 Następujący [mężowie] przybyli z Tell Melach, Tell Charsza, Kerub, Addan i Immer, lecz nie byli w stanie wykazać, czy ród ich i pochodzenie wywodziły się z Izraela:
###### **Ezd 2,60**
 synowie Delaji, synowie Tobijji i synowie Nekody - razem 652.
###### **Ezd 2,61**
 Spośród kapłanów zaś: synowie Chobajji, synowie Hakkoca i synowie Barzillaja, tego, który pojął sobie za żonę jedną z córek Barzillaja z Gilead i przybrał jego imię.
###### **Ezd 2,62**
 Szukali oni swego rodowodu, ale ponieważ go [tam] nie znaleziono, wykluczono ich jako nieczystych ze służby kapłańskiej.
###### **Ezd 2,63**
 Tirszata zakazał im spożywać pokarmy święte, dopóki się nie zjawi kapłan dla Urim i Tummim.
###### **Ezd 2,64**
 Cała społeczność [liczyła] razem 42 360 ludzi,
###### **Ezd 2,65**
 nie wliczając w to niewolników i niewolnic, których było 7337. Znajdowało się też między nimi 200 śpiewaków i śpiewaczek.
###### **Ezd 2,66**
 [posiadali oni] 736 koni, 245 mułów,
###### **Ezd 2,67**
 wielbłądów i 6720 osłów.
###### **Ezd 2,68**
 Niektórzy spośród przywódców rodów, przybywszy do Świątyni Jahwe w Jeruzalem, przynieśli dobrowolne dary dla Domu Boga, aby można go było znowu odbudować na dawnym miejscu.
###### **Ezd 2,69**
 Zależnie od swych możliwości złożyli oni do skarbca na odbudowę 61 tysięcy darkemonów złota, 5 tysięcy min srebra i sto szat kapłańskich.
###### **Ezd 2,70**
 Kapłani, lewici i niektórzy spośród ludu zamieszkali w Jeruzalem, a śpiewacy, odźwierni i niewolnicy Świątyni - w swoich miastach. W ten sposób cały Izrael znalazł się w swoich miastach.
# Ezd 2 BR
###### **Ezd 2,1**
 A oto wykaz ludzi, mieszkańców ziemi judzkiej, wracających z niewoli babilońskiej, do której zostali uprowadzeni kiedyś przez Nabuchodonozora, króla Babilonu. Wrócili teraz do Jerozolimy i do ziemi judzkiej, każdy do swego miasta,
###### **Ezd 2,2**
 a na ich czele stali: Zorobabel, Jozue, Nehemiasz, Serajasz, Reelajasz, Nachamani, Mardocheusz, Bilszan, Mispar, Bigwaj, Rechum i Baana. Łącznie wracających synów ludu izraelskiego było:
###### **Ezd 2,3**
 dwa tysiące stu siedemdziesięciu dwóch synów Pareosza;
###### **Ezd 2,4**
 trzystu siedemdziesięciu dwóch synów Szefatiasza;
###### **Ezd 2,5**
 siedmiuset siedemdziesięciu pięciu synów Aracha;
###### **Ezd 2,6**
 dwa tysiące ośmiuset dwunastu synów Pachat-Moaba z linii synów Jozuego i Joaba;
###### **Ezd 2,7**
 tysiąc dwustu pięćdziesięciu czterech synów Elama;
###### **Ezd 2,8**
 dziewięciuset czterdziestu pięciu synów Zattu;
###### **Ezd 2,9**
 siedmiuset sześćdziesięciu synów Zacheusza;
###### **Ezd 2,10**
 sześciuset czterdziestu dwóch synów Baniego;
###### **Ezd 2,11**
 sześciuset dwudziestu trzech synów Bebaja;
###### **Ezd 2,12**
 tysiąc dwustu dwudziestu dwóch synów Azgada;
###### **Ezd 2,13**
 sześciuset sześćdziesięciu sześciu synów Adonikama;
###### **Ezd 2,14**
 dwa tysiące pięćdziesięciu sześciu synów Bigwaja;
###### **Ezd 2,15**
 czterystu pięćdziesięciu czterech synów Adina;
###### **Ezd 2,16**
 dziewięćdziesięciu ośmiu synów Atera w linii Ezechiasza; czterystu trzydziestu dwóch synów Azzura; stu jeden synów Hodiasza;
###### **Ezd 2,17**
 trzystu dwudziestu trzech synów Besaja;
###### **Ezd 2,18**
 stu dwunastu synów Charifa;
###### **Ezd 2,19**
 dwustu dwudziestu trzech synów Chaszuma;
###### **Ezd 2,20**
 dziewięćdziesięciu pięciu synów Gibbara.
###### **Ezd 2,21**
 Poza tym stu dwudziestu trzech mężów z Betlejem;
###### **Ezd 2,22**
 pięćdziesięciu sześciu mężów z Netofy;
###### **Ezd 2,23**
 stu dwudziestu ośmiu mężów z Anatot;
###### **Ezd 2,24**
 czterdziestu dwóch mężów z Bet-Azmawet;
###### **Ezd 2,25**
 siedmiuset czterdziestu trzech mężów z Kiriat-Jearim, z Kefiry i Beerot;
###### **Ezd 2,26**
 sześciuset dwudziestu jeden mężów z Rama i Geba;
###### **Ezd 2,27**
 stu dwudziestu dwóch mężów z Mikmas;
###### **Ezd 2,28**
 dwustu dwudziestu trzech mężów z Betel i Aj.
###### **Ezd 2,29**
 [Było także] pięćdziesięciu dwóch synów Nebo;
###### **Ezd 2,30**
 stu pięćdziesięciu sześciu synów Magbisza;
###### **Ezd 2,31**
 tysiąc dwustu pięćdziesięciu czterech synów drugiego Elama;
###### **Ezd 2,32**
 trzystu dwudziestu synów Charima;
###### **Ezd 2,33**
 siedmiuset dwudziestu pięciu mężów z Lod, Chadid i Ono;
###### **Ezd 2,34**
 trzystu czterdziestu pięciu mężów z Jerycha
###### **Ezd 2,35**
 oraz trzy tysiące sześciuset trzydziestu synów Senai.
###### **Ezd 2,36**
 A oto wykaz kapłanów: dziewięciuset siedemdziesięciu trzech synów Jedajasza z domu Jozuego;
###### **Ezd 2,37**
 tysiąc pięćdziesięciu dwóch synów Immera;
###### **Ezd 2,38**
 tysiąc dwustu czterdziestu siedmiu synów Paszchura;
###### **Ezd 2,39**
 tysiąc siedemnastu synów Charima.
###### **Ezd 2,40**
 Lewitów, synów Jozuego z linii Kadmiela, Binnuja i Hodawiasza, było siedemdziesięciu czterech.
###### **Ezd 2,41**
 Śpiewaków, synów Asafa, było stu dwudziestu ośmiu.
###### **Ezd 2,42**
 Odźwiernych, synów Szalluma, Atera, Talmona, Akkuba, Chatity, Szobaja, było razem stu trzydziestu dziewięciu.
###### **Ezd 2,43**
 Spośród sług świątyni byli: synowie Sichy, synowie Chasufy, synowie Tabbaota,
###### **Ezd 2,44**
 synowie Kerosa, synowie Sii, synowie Padona,
###### **Ezd 2,45**
 synowie Lebany, synowie Chagaby, synowie Akkuba,
###### **Ezd 2,46**
 synowie Chagaba, synowie Szamlaja, synowie Chanana,
###### **Ezd 2,47**
 synowie Giddela, synowie Gachara, synowie Reajasza,
###### **Ezd 2,48**
 synowie Resina, synowie Nekody, synowie Gazzama,
###### **Ezd 2,49**
 synowie Uzzy, synowie Paseacha, synowie Besaja,
###### **Ezd 2,50**
 synowie Asny, synowie Meunitów, synowie Nefisytów,
###### **Ezd 2,51**
 synowie Bakbuka, synowie Chakufy, synowie Charchura,
###### **Ezd 2,52**
 synowie Basluta, synowie Mechidy, synowie Charszy,
###### **Ezd 2,53**
 synowie Barkosa, synowie Sisery, synowie Temacha,
###### **Ezd 2,54**
 synowie Nesjacha, synowie Chatify.
###### **Ezd 2,55**
 A oto potomkowie sług Salomona: synowie Sotaja, synowie Hassofereta, synowie Perudy,
###### **Ezd 2,56**
 synowie Jaali, synowie Darkona, synowie Giddela,
###### **Ezd 2,57**
 synowie Szefatiasza, synowie Ghattila, synowie Pocheret-Hassebajima, synowie Amiego.
###### **Ezd 2,58**
 Wszystkich sług świątyni oraz synów sług Salomona było trzystu dziewięćdziesięciu dwóch.
###### **Ezd 2,59**
 Wśród tych, którzy wyruszyli z Tel-Melach, Tel-Charsza, Kerub, Addan i Immer, znajdowali się i tacy, którzy nie byli w stanie udowodnić, że przez swoje pochodzenie i rody należą do narodu izraelskiego.
###### **Ezd 2,60**
 Było takich sześciuset pięćdziesięciu dwóch spośród synów Delajasza, Tobiasza i Nekody,
###### **Ezd 2,61**
 a spośród kapłanów - synowie Chobajasza, synowie Hakkosa, synowie Barzillaja, który wziął za żonę jedną z córek Barzillaja Gileadyty i przybrał sobie jego imię.
###### **Ezd 2,62**
 Wszyscy oni szukali początków swego rodowodu, ale bez skutku. Uznano ich tedy za nieczystych i usunięto z szeregów kapłańskich.
###### **Ezd 2,63**
 Zarządca [świątyni] zakazał im spożywania pokarmów składanych na ofiary. Tak miało być do czasu pojawienia się kapłana, który będzie mógł zasięgnąć rady u urim i tummim.
###### **Ezd 2,64**
 Wszystkich ludzi wracających [z wygnania] było czterdzieści dwa tysiące trzysta sześćdziesiąt osób.
###### **Ezd 2,65**
 Prócz tego wracało siedem tysięcy trzysta trzydzieści siedem osób spośród sług i służebnic; wreszcie dwieście osób liczyła grupa śpiewaków i śpiewaczek.
###### **Ezd 2,66**
 Mieli wszyscy razem siedemset trzydzieści sześć koni, dwieście czterdzieści pięć mułów,
###### **Ezd 2,67**
 czterysta trzydzieści pięć wielbłądów oraz sześć tysięcy siedemset dwadzieścia osłów.
###### **Ezd 2,68**
 Przybywając do znajdującej się w Jerozolimie świątyni Jahwe, wielu przywódców rodów składało dobrowolne ofiary na dom Boży, aby mógł być wzniesiony co rychlej na dawnym miejscu.
###### **Ezd 2,69**
 Złożyli na to dzieło, każdy według własnych możliwości, sześćdziesiąt jeden tysięcy drachm złota, pięć tysięcy min srebra oraz sto szat kapłańskich.
###### **Ezd 2,70**
 W ten sposób osiedlili się ponownie w swoich miastach kapłani, lewici, lud prosty, śpiewacy i odźwierni oraz [inni] słudzy świątyni. I cały Izrael zamieszkał znów w swoich miastach.
# Ezd 2 WUJ
###### **Ezd 2,1**
 A synowie krainy ci są, którzy wyszli z pojmania, które był przeniósł Nabuchodonozor, król Babiloński do Babilonu, i wrócili się do Jeruzalem i Judy, każdy do miasta swego.
###### **Ezd 2,2**
 Którzy przyszli z Zorobabelem, Jozue, Nehemia, Saraja, Rahelaja, Mardochaj, Belsan, Mesphar, Begwaj, Rehum, Baana. Poczet mężów ludu Izraelskiego:
###### **Ezd 2,3**
 Synów Pharos, dwa tysiąca sto siedmdziesiąt dwa.
###### **Ezd 2,4**
 Synów Sephatia, trzy sta siedmdziesiąt dwa.
###### **Ezd 2,5**
 Synów Area, siedm set siedmdziesiąt i pięć.
###### **Ezd 2,6**
 Synów Phahath Moab, synów Jozue: Joab, dwa tysiąca ośm set dwanaście.
###### **Ezd 2,7**
 Synów Elam, tysiąc dwieście pięćdziesiąt czterzej.
###### **Ezd 2,8**
 Synów Zethua, dziewięć set czterdzieści pięć.
###### **Ezd 2,9**
 Synów Zachai, siedm set sześćdziesiąt.
###### **Ezd 2,10**
 Synów Bani, sześć set czterdzieści dwa.
###### **Ezd 2,11**
 Synów Bebai, sześć set dwadzieścia trzej.
###### **Ezd 2,12**
 Synów Azgad, tysiąc dwieście dwadzieścia dwa.
###### **Ezd 2,13**
 Synów Adonikam, sześć set sześćdziesiąt sześć.
###### **Ezd 2,14**
 Synów Begwai, dwa tysiące pięćdziesiąt sześć.
###### **Ezd 2,15**
 Synów Adin, cztery sta pięćdziesiąt czterzej.
###### **Ezd 2,16**
 Synów Ather, którzy byli z Ezechiasza, dziewięćdziesiąt ośm.
###### **Ezd 2,17**
 Synów Bezai, trzy sta dwadzieścia trzej.
###### **Ezd 2,18**
 Synów Jora, sto dwanaście.
###### **Ezd 2,19**
 Synów Hasum, dwieście dwadzieścia trzej.
###### **Ezd 2,20**
 Synów Gebbar, dziewięćdziesiąt pięć.
###### **Ezd 2,21**
 Synów Bethlehem, sto dwadzieścia trzej.
###### **Ezd 2,22**
 Mężów Netupha, pięćdziesiąt i sześć.
###### **Ezd 2,23**
 Mężów Anathoth, sto dwadzieścia i ośm.
###### **Ezd 2,24**
 Synów Azmaweth, czterdzieści dwa,
###### **Ezd 2,25**
 Synów Kariathiarim, Cephira, i Beroth, siedm set czterdzieści trzej.
###### **Ezd 2,26**
 Synów Ramath, i Gabaa, sześć set dwadzieścia jeden.
###### **Ezd 2,27**
 Mężów Machma, sto dwadzieścia dwa.
###### **Ezd 2,28**
 Mężów Bethel, i Haj, dwieście dwadzieścia trzej.
###### **Ezd 2,29**
 Synów Nebo, pięćdziesiąt dwa.
###### **Ezd 2,30**
 Synów Megbis, sto pięćdziesiąt sześć.
###### **Ezd 2,31**
 Synów Elam drugiego, tysiąc dwieście pięćdziesiąt czterzej.
###### **Ezd 2,32**
 Synów Har, trzy sta dwadzieścia.
###### **Ezd 2,33**
 Synów Lod Hadid, i Ono, siedm set dwadzieścia pięć.
###### **Ezd 2,34**
 Synów Jericho, trzy sta czterdzieści pięć.
###### **Ezd 2,35**
 Synów Senaa, trzy tysiące sześć set trzydzieści.
###### **Ezd 2,36**
 Kapłanów: Synów Jadaja w domu Jozue, dziewięć set siedmdziesiąt trzej.
###### **Ezd 2,37**
 Synów Emmer, tysiąc pięćdziesiąt dwa.
###### **Ezd 2,38**
 Synów Pheshur, tysiąc dwieście czterdzieści siedm.
###### **Ezd 2,39**
 Synów Harim, tysiąc siedmnaście.
###### **Ezd 2,40**
 Lewitów: Synów Jozue, i Cedmichel, synów Odowiasza, siedmdziesiąt czterzej.
###### **Ezd 2,41**
 Śpiewaków: Synów Asaph, sto dwadzieścia ośm,
###### **Ezd 2,42**
 Synowie wrótnych: Synowie Sellum, synowie Ater, synowie Telmon, synowie Akkub, synowie Hatita, synowie Sobai, wszystkich sto trzydzieści dziewięć.
###### **Ezd 2,43**
 Nathinejczycy: Synowie Siha, synowie Hasupha, synowie Tabbaoth,
###### **Ezd 2,44**
 Synowie Ceros, synowie Siaa, synowie Phadon,
###### **Ezd 2,45**
 Synowie Lebana, synowie Hagaba, synowie Akkub,
###### **Ezd 2,46**
 Synowie Hagab, synowie Semlai, synowie Hanan.
###### **Ezd 2,47**
 Synowie Gaddel, synowie Gaher, synowie Raaja,
###### **Ezd 2,48**
 Synowie Rasin synowie Nekoda, synowie Gazam,
###### **Ezd 2,49**
 Synowie Aza, synowie Phasea, synowie Besee,
###### **Ezd 2,50**
 Synowie Asena, synowie Munim, synowie Nephusim,
###### **Ezd 2,51**
 Synowie Bakbuk, synowie Hakupha, synowie Harhur,
###### **Ezd 2,52**
 Synowie Befluth, synowie Mahida, synowie Harsa,
###### **Ezd 2,53**
 Synowie Berkos, synowie Sisara, synowie Thema,
###### **Ezd 2,54**
 Synowie Nasia, synowie Hatipha,
###### **Ezd 2,55**
 Synowie sług Salomonowych, synowie Sotai, synowie Sophereth, synowie Pharuda,
###### **Ezd 2,56**
 Synowie Jala, synowie Derkon, synowie Geddel,
###### **Ezd 2,57**
 Synowie Saphatia, synowie Hatil, synowie Phochereth, którzy byli z Asebaim, synowie Ami.
###### **Ezd 2,58**
 Wszystkich Nathinejczyków, i synów sług Salomonowych, trzysta dziewięćdziesiąt dwa,
###### **Ezd 2,59**
 A ci, którzy wyszli z Thelmala, Thelharsa, Cherub, i Adon, i Emer: i nie mogli pokazać domów ojców swoich, i nasienia swego, jeśli z Izraela byli.
###### **Ezd 2,60**
 Synów Dalaja, synów Tobia, synów Nekoda, sześć set pięćdziesiąt dwa.
###### **Ezd 2,61**
 A synów kapłańskich: Synowie Hobia, synowie Akkos, synowie Berzellai, który pojął z córek Berzellai Galaadczyka żonę, i przezwano go ich imieniem:
###### **Ezd 2,62**
 Ci szukali pisma rodu swego, i nie naleźli, i wyrzuceni są z kapłaństwa.
###### **Ezd 2,63**
 I rzekł im Athersata, aby nie jedli z świętego świętych, ażby powstał kapłan uczony i doskonały.
###### **Ezd 2,64**
 Wszystko mnóstwo jako jeden czterdzieści dwa tysiąca trzy sta sześćdziesiąt:
###### **Ezd 2,65**
 Oprócz sług ich i służebnic, których było siedm tysięcy trzy sta trzydzieści siedm: a między nimi śpiewaków i śpiewaczek dwieście.
###### **Ezd 2,66**
 Koni ich siedm set trzydzieści sześć: mułów ich, dwieście czterdzieści pięć:
###### **Ezd 2,67**
 Wielbłądów ich, czterzy sta trzydzieści pięć: osłów ich, sześć tysięcy siedm set dwadzieścia.
###### **Ezd 2,68**
 A z przedniejszych ojców, gdy wchodzili do kościoła Pańskiego, który jest w Jeruzalem, dobrowolnie ofiarowali na dom Boży, aby ji postawili na miejscu jego.
###### **Ezd 2,69**
 Według przemożenia swego dali nakład na budowanie, złota czerwonych złotych sześćdziesiąt tysięcy i tysiąc, srebra grzywien pięć tysięcy, i sto szat kapłańskich.
###### **Ezd 2,70**
 Mieszkali tedy kapłani i Lewitowie, i z ludu, i śpiewacy, i wrótni, i Nathinejczycy w mieściech swych, i wszystek Izrael w mieściech swych.
