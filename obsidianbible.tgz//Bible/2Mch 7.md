# 2Mch 7 BT5
###### **2Mch 7,1**
 Siedmiu braci razem z matką również zostało schwytanych. Bito ich biczami i rzemieniami, gdyż król chciał ich zmusić, aby skosztowali wieprzowiny zakazanej przez Prawo.
###### **2Mch 7,2**
 Jeden z nich, przemawiając w imieniu wszystkich, tak powiedział: «***O co masz zamiar pytać i jakie zdobywać od nas wiadomości? Jesteśmy bowiem gotowi raczej zginąć, aniżeli przekroczyć ojczyste prawa***».
###### **2Mch 7,3**
 Rozgniewał się na to król i kazał rozpalić patelnie i kotły.
###### **2Mch 7,4**
 Skoro tylko się rozpaliły, rozkazał temu, który przemawiał w imieniu wszystkich, obciąć język, ściągnąć skórę z głowy i obciąć końce członków, na oczach pozostałych braci i matki.
###### **2Mch 7,5**
 Gdy był on już całkiem bezwładny, rozkazał go sprowadzić do ognia, bo jeszcze oddychał, i smażyć na patelni. Gdy zaś swąd z patelni szeroko się rozchodził, [pozostali bracia] wzajemnie razem z matką napominali się, aby mężnie oddać życie. Mówili tak:
###### **2Mch 7,6**
 «***Pan Bóg widzi i naprawdę ma litość nad nami, zgodnie z tym, co Mojżesz jasno wobec wszystkich przepowiedział w pieśni, która o tym świadczy w słowach: Litość okaże swym sługom***».
###### **2Mch 7,7**
 Kiedy pierwszy w ten sposób zakończył życie, prowadzono drugiego na miejsce kaźni. Gdy ściągnięto mu skórę z głowy razem z włosami, zapytano go: «***Czy będziesz jadł, zanim ciało, członek po członku, będzie poddane kaźni?***»
###### **2Mch 7,8**
 On zaś odpowiedział ojczystą mową: «***Nie!***» Dlatego i on z kolei został poddany katuszom, jak pierwszy.
###### **2Mch 7,9**
 W chwili, gdy oddawał ostatnie tchnienie, powiedział: «***Ty zbrodniarzu, odbierasz nam to obecne życie. Król świata jednak nas, którzy umieramy za Jego prawa, wskrzesi i ożywi do życia wiecznego***».
###### **2Mch 7,10**
 Po nim był męczony trzeci. Na żądanie natychmiast wysunął język, a ręce wyciągnął bez obawy
###### **2Mch 7,11**
 i mężnie powiedział: «***Z Nieba je otrzymałem, ale dla Jego praw nimi gardzę, a spodziewam się, że od Niego ponownie je otrzymam***».
###### **2Mch 7,12**
 Nawet sam król i całe jego otoczenie zdumiewali się odwagą młodzieńca, jak za nic miał cierpienia.
###### **2Mch 7,13**
 Gdy ten już zakończył życie, takim samym katuszom poddawano czwartego.
###### **2Mch 7,14**
 Konając, tak powiedział: «***Lepiej jest tym, którzy giną z rąk ludzkich, [bo mogą] pokładać nadzieję w Bogu, że znów przez Niego zostaną wskrzeszeni. Dla ciebie bowiem nie będzie zmartwychwstania do życia***».
###### **2Mch 7,15**
 Następnie przyprowadzono piątego i poddano katuszom.
###### **2Mch 7,16**
 On zaś, wpatrując się w króla, powiedział: «***Choć masz władzę nad ludźmi i czynisz, co zechcesz, jesteś śmiertelny. Nie myśl jednak, że nasz naród jest opuszczony przez Boga.***
###### **2Mch 7,17**
 ***Ty jednak poczekaj, a zobaczysz wielką Jego moc, jak ciebie i twoje potomstwo podda katuszom***».
###### **2Mch 7,18**
 Po nim prowadzono szóstego, ten zaś, konając, powiedział: «***Nie łudź na darmo sam siebie! My bowiem z własnej winy cierpimy, bo grzeszyliśmy przeciwko naszemu Bogu. Dlatego nastały te przedziwne [nieszczęścia].***
###### **2Mch 7,19**
 ***Ty jednak nie sądź, że pozostaniesz bez kary, skoro odważyłeś się walczyć z Bogiem***».
###### **2Mch 7,20**
 Przede wszystkim zaś godna podziwu i trwałej pamięci była matka. Przyglądała się ona w ciągu jednego dnia śmierci siedmiu synów i zniosła to mężnie. Nadzieję bowiem pokładała w Panu.
###### **2Mch 7,21**
 Pełna szlachetnych myśli, zagrzewając swoje kobiece usposobienie męską odwagą, każdego z nich upominała w ojczystym języku. Mówiła do nich:
###### **2Mch 7,22**
 «***Nie wiem, w jaki sposób znaleźliście się w moim łonie, nie ja wam dałam tchnienie i życie, a członki każdego z was nie ja ułożyłam.***
###### **2Mch 7,23**
 ***Stwórca świata bowiem, który ukształtował człowieka i zamyślił początek wszechrzeczy, w swojej litości ponownie odda wam tchnienie i życie, dlatego że wy gardzicie sobą teraz dla Jego praw***».
###### **2Mch 7,24**
 Antioch był przekonany, że nim gardzono, i dopatrywał się obelgi w tych słowach. Ponieważ zaś najmłodszy był jeszcze przy życiu, nie tylko dał mu ustną obietnicę, ale nawet pod przysięgą zapewnił go, że jeżeli odwróci się od ojczystych praw, uczyni go bogatym i szczęśliwym, a nawet mianuje go przyjacielem i powierzy mu ważne zadania.
###### **2Mch 7,25**
 Kiedy zaś młodzieniec nie zwracał na to żadnej uwagi, król przywołał matkę i namawiał ją, aby chłopcu udzieliła zbawiennej rady.
###### **2Mch 7,26**
 Po długich namowach zgodziła się nakłonić syna.
###### **2Mch 7,27**
 Kiedy jednak nachyliła się nad nim, wtedy wyśmiewając okrutnego tyrana, tak powiedziała w języku ojczystym: «***Synu, zlituj się nade mną! W łonie nosiłam cię przez dziewięć miesięcy, karmiłam cię mlekiem przez trzy lata, wyżywiłam cię i wychowałam aż do tych lat.***
###### **2Mch 7,28**
 ***Proszę cię, synu, spojrzyj na niebo i na ziemię, a mając na oku wszystko, co jest na nich, zwróć uwagę na to, że z niczego stworzył je Bóg i że ród ludzki powstał w ten sam sposób.***
###### **2Mch 7,29**
 ***Nie obawiaj się tego oprawcy, ale bądź godny braci swoich i przyjmij śmierć, abym w [godzinie] zmiłowania odnalazła cię razem z braćmi***».
###### **2Mch 7,30**
 Zaledwie ona skończyła mówić, młodzieniec powiedział: «***Na co czekacie? Jestem posłuszny nie nakazowi króla, ale słucham nakazu Prawa, które przez Mojżesza było dane naszym ojcom.***
###### **2Mch 7,31**
 ***Ty zaś, przyczyno wszystkich nieszczęść Hebrajczyków, nie umkniesz z rąk Bożych.***
###### **2Mch 7,32**
 ***My bowiem cierpimy za nasze własne grzechy.***
###### **2Mch 7,33**
 ***Jeżeli zaś żyjący Król nasz rozgniewał się na krótki czas, aby nas ukarać i poprawić, to znów pojedna się ze swoimi sługami.***
###### **2Mch 7,34**
 ***Ty zaś, bezbożny i spośród wszystkich ludzi najbardziej nikczemny, nie wynoś się na próżno, łudząc się zwodniczymi nadziejami. Nie podnoś ręki na niebieskie sługi.***
###### **2Mch 7,35**
 ***Jeszcze bowiem nie uciekłeś przed sądem wszechmogącego i widzącego z góry Boga.***
###### **2Mch 7,36**
 ***Teraz bowiem nasi bracia, którzy przetrwali krótkie cierpienie ze względu na życie wieczne, stali się uczestnikami [obietnic] przymierza Bożego. Ty zaś na sądzie Bożym poniesiesz sprawiedliwą karę za pychę.***
###### **2Mch 7,37**
 ***Ja, tak samo jak moi bracia, i ciało, i duszę oddaję za ojczyste prawa. Proszę przy tym Boga, aby wnet zmiłował się nad narodem, a ciebie doświadczeniami i karami zmusił do wyznania, że On jest jedynym Bogiem.***
###### **2Mch 7,38**
 ***Na mnie i na braciach moich niech zatrzyma się gniew Wszechmogącego, który sprawiedliwie spadł na cały nasz naród***».
###### **2Mch 7,39**
 Wtedy król rozgniewał się i kazał go poddać straszniejszym męczarniom niż innych. Gorzkie mu bowiem były wyrzuty.
###### **2Mch 7,40**
 Tak więc i ten zakończył życie czysty i pełen ufności w Panu.
###### **2Mch 7,41**
 Ostatnia po synach zmarła matka.
###### **2Mch 7,42**
 Tyle niech wystarczy podać o ucztach ofiarnych i niezmiernych katuszach.
# 2Mch 7 PAU
###### **2Mch 7,1**
 Zdarzyło się też, że siedmiu braci zostało schwytanych razem z ich matką. Król chciał ich zmusić do jedzenia zakazanego mięsa wieprzowego, chłoszcząc ich biczami i rzemieniami.
###### **2Mch 7,2**
 Jeden z nich w imieniu wszystkich tak powiedział: „O co chciałbyś zapytać i czego chciałbyś się od nas dowiedzieć? Gotowi jesteśmy raczej umrzeć, niż przekroczyć ojczyste prawa”.
###### **2Mch 7,3**
 Król rozgniewał się i rozkazał rozpalić ogień pod patelniami i kotłami.
###### **2Mch 7,4**
 Skoro tylko zostały rozgrzane, temu, który przemawiał w imieniu wszystkich, rozkazał uciąć język, ściągnąć skórę z głowy i obciąć kończyny. Pozostali bracia i matka musieli się temu przyglądać.
###### **2Mch 7,5**
 Kiedy on był już całkowicie bezwładny, lecz jeszcze oddychał, król rozkazał przywlec go do ognia i smażyć na patelni. Podczas gdy z patelni unosił się gęsty dym, pozostali bracia i matka dodawali sobie odwagi, by umrzeć z honorem. Mówili:
###### **2Mch 7,6**
 „PAN Bóg to widzi i na pewno zmiłuje się nad nami. Mojżesz wyraźnie zaświadczył o tym w swojej pieśni: I zmiłuje się nad swoimi sługami”.
###### **2Mch 7,7**
 Kiedy w ten sposób pierwszy zakończył życie, przyprowadzili drugiego, aby go publicznie torturować. Gdy mu zdarli skórę z głowy razem z włosami, zapytali: „Będziesz jadł, zanim twoje ciało zostanie umęczone kawałek po kawałku?”.
###### **2Mch 7,8**
 On zaś odpowiedział w ojczystym języku: „Nie!”. Dlatego i on zaraz został umęczony, podobnie jak pierwszy.
###### **2Mch 7,9**
 Gdy wydawał ostatni oddech, powiedział: „Ty, zbrodniarzu, odbierasz nam doczesne życie, ale Król świata wskrzesi nas do życia trwającego wiecznie, ponieważ umieramy za Jego prawa”.
###### **2Mch 7,10**
 Po nim szydzono z trzeciego. Kiedy tego zażądano, natychmiast wysunął język i śmiało wyciągnął ręce,
###### **2Mch 7,11**
 mówiąc odważnie: „Niebo mi je dało, ale z powodu Jego praw nimi gardzę i mam nadzieję od Niego otrzymać je ponownie”.
###### **2Mch 7,12**
 Nawet sam król i jego otoczenie byli pełni podziwu dla odwagi tego chłopca, który za nic miał cierpienia.
###### **2Mch 7,13**
 Kiedy i ten zakończył życie, podobnym torturom poddano czwartego.
###### **2Mch 7,14**
 Będąc już u kresu, powiedział: „Bóg dał nam nadzieję, że będziemy przez Niego ponownie ożywieni. Tego właśnie oczekujemy, wybierając śmierć z ręki człowieka. Ty natomiast nie będziesz wskrzeszony do życia”.
###### **2Mch 7,15**
 Zaraz po nim przyprowadzono i maltretowano piątego.
###### **2Mch 7,16**
 On zaś, patrząc na króla, powiedział: „Mając władzę nad ludźmi, robisz, co zechcesz, chociaż jesteś śmiertelnikiem. Nie myśl jednak, że nasz naród został opuszczony przez Boga.
###### **2Mch 7,17**
 Poczekaj tylko, a zobaczysz Jego wielką potęgę, gdy umęczy ciebie i twoje potomstwo”.
###### **2Mch 7,18**
 Po nim przyprowadzono szóstego. Kiedy umierał, powiedział: „Łudzisz się na próżno. My bowiem cierpimy z własnej winy, gdyż zgrzeszyliśmy przeciwko naszemu Bogu. Dlatego dzieją się te zdumiewające rzeczy.
###### **2Mch 7,19**
 Ty zaś nie sądź, że będziesz bezkarny, skoro usiłujesz walczyć z Bogiem”.
###### **2Mch 7,20**
 Nadzwyczaj godna podziwu i trwałej pamięci była matka. W jednym dniu widziała śmierć swoich siedmiu synów i zniosła to mężnie dzięki nadziei pokładanej w PANU.
###### **2Mch 7,21**
 Każdemu z nich nawet dodawała otuchy w ojczystym języku. Pełna wzniosłych myśli, kobiece rozumowanie umacniała męską odwagą. Mówiła do nich:
###### **2Mch 7,22**
 „Nie wiem, jak pojawiliście się w moim łonie. Nie ja dałam wam ducha i życie i nie ja ukształtowałam wasze ciała.
###### **2Mch 7,23**
 Dlatego Stwórca świata, który dał początek ludzkości i wszystkiemu, co istnieje, w swoim miłosierdziu odda wam ducha i życie. Wy bowiem teraz gardzicie samymi sobą dla Jego praw”.
###### **2Mch 7,24**
 Antioch zaś sądził, że został obrażony, i podejrzewał, że jej wypowiedź była obelżywa. Gdy najmłodszy z braci jeszcze żył, zaczął go zachęcać, a nawet złożył przysięgę, że uczyni go bogatym i szczęśliwym, jeśli tylko porzuci ojczyste obyczaje; uczyni go nawet swoim przyjacielem oraz powierzy mu urzędy.
###### **2Mch 7,25**
 Ponieważ młodzieniec nie zwracał na to żadnej uwagi, król przywołał matkę i zachęcał ją, aby nakłaniała chłopca do ocalenia życia.
###### **2Mch 7,26**
 Po jego wielu prośbach zgodziła się przekonać syna.
###### **2Mch 7,27**
 Pochyliła się nad nim i drwiąc z okrutnego tyrana, powiedziała w języku ojczystym: „Synu, zlituj się nade mną! Nosiłam cię w łonie przez dziewięć miesięcy, karmiłam cię mlekiem przez trzy lata. Żywiłam cię, wychowywałam i utrzymywałam aż do tego czasu.
###### **2Mch 7,28**
 Proszę cię, synu, spójrz na niebo i na ziemię, i na wszystko, co jest na nich. Wiedz, że Bóg uczynił je z niczego i że rodzaj ludzki powstał w ten sam sposób.
###### **2Mch 7,29**
 Nie bój się tego kata, ale bądź godny swoich braci i przyjmij śmierć, abym w czasie miłosierdzia razem z twoimi braćmi odzyskała ciebie”.
###### **2Mch 7,30**
 Gdy ona jeszcze mówiła, młodzieniec powiedział: „Na co czekacie? Nie jestem posłuszny nakazowi króla, ale słucham nakazu Prawa, które zostało dane naszym ojcom za pośrednictwem Mojżesza.
###### **2Mch 7,31**
 Ty jednak, sprawco wszelkiego zła przeciwko Hebrajczykom, nie uciekniesz z rąk Boga.
###### **2Mch 7,32**
 My bowiem cierpimy z powodu własnych grzechów
###### **2Mch 7,33**
 i nawet jeśli nasz żyjący PAN na krótko się rozgniewał, aby nas ukarać i wychować, to jednak znów pojedna się ze swoimi sługami.
###### **2Mch 7,34**
 Ty zaś, bezbożniku najbardziej zepsuty ze wszystkich ludzi, wynosisz się na próżno, żywiąc bezpodstawne nadzieje i podnosząc rękę przeciwko dzieciom Nieba.
###### **2Mch 7,35**
 Nie uciekniesz przed sądem wszechmocnego i czuwającego Boga!
###### **2Mch 7,36**
 Teraz bowiem nasi bracia po krótkim cierpieniu osiągnęli życie wieczne w przymierzu z Bogiem. Ty natomiast na sądzie Bożym zostaniesz sprawiedliwie skazany za swoją pychę.
###### **2Mch 7,37**
 A ja, podobnie jak bracia, oddaję ciało i duszę za ojczyste prawa. Błagam Boga, aby rychło okazał się łaskawy dla naszego narodu, a ciebie nakłonił przy pomocy doświadczeń i plag do wyznania, że On jest Bogiem jedynym.
###### **2Mch 7,38**
 Niech gniew, którym Wszechmocny sprawiedliwie dotknął cały nasz naród, zatrzyma się na mnie i na moich braciach”.
###### **2Mch 7,39**
 Słysząc gorzkie szyderstwo, król rozgniewał się i postąpił z nim jeszcze okrutniej niż z tamtymi.
###### **2Mch 7,40**
 Tak więc i on czysty zakończył życie, całkowicie ufając PANU.
###### **2Mch 7,41**
 Ostatnia po synach umarła matka.
###### **2Mch 7,42**
 O ucztach ofiarnych i strasznych prześladowaniach niech tyle wystarczy.
# 2Mch 7 BP
###### **2Mch 7,1**
 Zdarzyło się także, że schwytano siedmiu braci wraz z matką. Bito ich biczami i rzemieniami, ponieważ król chciał ich zmusić do zjedzenia wieprzowego mięsa zakazanego przez Prawo.
###### **2Mch 7,2**
 Jeden z nich wystąpił w imieniu [wszystkich] i powiedział: O co chcesz zapytać i czego pragniesz się od nas dowiedzieć? Gotowi jesteśmy raczej umrzeć, niż przekroczyć prawa ojców.
###### **2Mch 7,3**
 Wówczas król rozgniewał się i polecił rozpalić patelnie i kotły.
###### **2Mch 7,4**
 Skoro tylko rozgrzały się, kazał na oczach braci i matki temu, który przemawiał, uciąć język, zedrzeć skórę z głowy i odciąć kończyny.
###### **2Mch 7,5**
 Gdy już został tak całkowicie okaleczony, rozkazał żyjącego jeszcze przywlec do ognia i piec na patelni. Podczas gdy swąd z patelni coraz dalej rozchodził się, oni tymi słowami nawzajem dodawali sobie wraz z matką otuchy, aby po bohatersku umrzeć:
###### **2Mch 7,6**
 Pan Bóg widzi to i zaprawdę lituje się nad nami, jak to wyraźnie przepowiedział Mojżesz w pieśni tymi słowy: Zlituje się nad sługami swymi.
###### **2Mch 7,7**
 Gdy pierwszy zakończył w ten sposób życie, przyprowadzono na męki drugiego. Zdarli mu z głowy skórę wraz z włosami i zapytali: Czy będziesz jadł [mięso wieprzowe] zanim każdą część [twego] ciała poddamy torturom?
###### **2Mch 7,8**
 On zaś odpowiedział w swojej ojczystej mowie: Nie. Dlatego i ten z kolei umęczony został tak jak pierwszy.
###### **2Mch 7,9**
 W chwili śmierci odezwał się: Ty, zbrodniarzu, odbierasz nam życie doczesne, lecz Król świata powoła nas do życia wiecznego, bo umieramy za Jego prawa.
###### **2Mch 7,10**
 Po nim znęcano się nad trzecim. Na żądanie natychmiast wyciągnął język i odważnie podał ręce,
###### **2Mch 7,11**
 po czym śmiało przemówił: Otrzymałem je z Nieba i dla [zachowania] Jego praw chętnie je oddaję, mam bowiem nadzieję, że od Niego otrzymam je z powrotem.
###### **2Mch 7,12**
 Nawet król i jego otoczenie byli pełni podziwu dla odwagi młodzieńca, który nie lękał się męczarni.
###### **2Mch 7,13**
 Po jego śmierci tak samo katowali i męczyli czwartego.
###### **2Mch 7,14**
 A gdy był już bliski śmierci, rzekł: My, którzy ponosimy śmierć z rąk ludzkich, znajdujemy pociechę w nadziei danej przez Boga, że przywróci nas znowu do życia. Dla ciebie zaś wskrzeszenia do życia [wiecznego] nie będzie.
###### **2Mch 7,15**
 Zaraz potem przywiedli piątego i torturowali go.
###### **2Mch 7,16**
 On zaś patrząc na króla rzekł: Chociaż jesteś śmiertelny, masz władzę nad ludźmi i możesz [z nimi] czynić, co tylko zechcesz. Nie sądź jednak, że Bóg opuścił nasz naród.
###### **2Mch 7,17**
 Poczekaj tylko cierpliwie, a doświadczysz Jego wielkiej mocy, jak ciebie i twoje potomstwo surowo ukarze.
###### **2Mch 7,18**
 Po nim przyprowadzono szóstego. Ten zaś konając rzekł: Nie łudź się daremnie, my bowiem cierpimy za własne winy, ponieważ zgrzeszyliśmy przeciwko naszemu Bogu, chociaż działy się rzeczy przedziwne.
###### **2Mch 7,19**
 Nie licz jednak na to, że ujdziesz bezkarnie. Ty, który ośmieliłeś się walczyć z Bogiem.
###### **2Mch 7,20**
 Nade wszystko jednak godna, aby ją podziwiać i ze czcią wspominać, była matka, która widząc, jak w jednym dniu zginęło jej siedmiu synów, zniosła to z wielkim spokojem dzięki ufności pokładanej w Panu.
###### **2Mch 7,21**
 Pełna szlachetnych uczuć, każdego z nich napominała w mowie ojczystej i [słaby] kobiecy charakter wzmacniała męską odwagą. Mówiła do nich:
###### **2Mch 7,22**
 Nie wiem, jak powstaliście w moim łonie, nie ja obdarzyłam was tchnieniem i życiem ani ja nie spoiłam w całość członków waszych ciał.
###### **2Mch 7,23**
 To Stwórca świata daje początek człowiekowi i powołuje do istnienia wszystkie rzeczy. On zwróci wam w swym miłosierdziu tchnienie i życie, którego nie szczędzicie teraz [dla zachowania] Jego praw.
###### **2Mch 7,24**
 Antioch sądził, że drwiono z niego, i podejrzewał w tych słowach obrazę; a ponieważ najmłodszy pozostał jeszcze przy życiu, starał się go przejednać nie tylko słowami, lecz nadto zaręczał mu przysięgami, że uczyni go bogatym i szczęśliwym, jeżeli tylko odstąpi od obyczajów ojców. [Mówił], że uważać go będzie za swego przyjaciela i powierzy mu wysokie urzędy.
###### **2Mch 7,25**
 Skoro jednak młodzieniec nie zwracał na to żadnej uwagi, przywołał król matkę i nakłaniał ją, aby przekonała chłopca i uratowała mu życie.
###### **2Mch 7,26**
 Dopiero po długich naleganiach zgodziła się nakłonić syna.
###### **2Mch 7,27**
 Pochyliwszy się jednak nad nim szydziła z okrutnego tyrana i tak rzekła w mowie ojczystej: Synu, ulituj się nade mną. Przez dziewięć miesięcy nosiłam cię w łonie, przez trzy lata ssałeś moją pierś, pielęgnowałam cię, wychowałam i doprowadziłam do tego wieku.
###### **2Mch 7,28**
 Zaklinam cię, dziecko moje, spojrzyj na niebo i ziemię, a obejmując wzrokiem wszystko, co na nich się znajduje, pomyśl, że Bóg stworzył to z niczego, podobnie też powstał ród ludzki.
###### **2Mch 7,29**
 Nie lękaj się tego kata, ale okaż się godnym twoich braci i przyjmij śmierć, abym odzyskała cię wraz z nimi w dniu miłosierdzia [Bożego].
###### **2Mch 7,30**
 Ledwo skończyła mówić, gdy odezwał się młodzieniec: Na cóż czekacie? Nie słucham rozkazów króla, lecz nakazów Prawa, które ojcowie nasi otrzymali od Mojżesza.
###### **2Mch 7,31**
 Ty zaś, sprawco wszystkich nieszczęść Hebrajczyków, nie wymkniesz się z rąk Bożych.
###### **2Mch 7,32**
 Cierpimy bowiem za nasze grzechy
###### **2Mch 7,33**
 i jeżeli nasz wiecznie żyjący Pan rozgniewał się na krótko, aby [nas] ukarać i wychować, to znowu pojedna się ze swymi sługami.
###### **2Mch 7,34**
 Lecz ty, bezbożniku, najniegodziwszy ze wszystkich ludzi, kierowany zwodną nadzieją nie unoś się próżną pychą, ponieważ podnosisz rękę na dzieci Nieba,
###### **2Mch 7,35**
 albowiem jeszcze nie uszedłeś przed sądem Wszechmocnego Boga, który wszystko widzi.
###### **2Mch 7,36**
 Bracia nasi doznawszy chwilowych cierpień otrzymali teraz życie wieczne jako uczestnicy przymierza z Bogiem. A ty na sądzie Bożym poniesiesz słuszną karę za swą pychę.
###### **2Mch 7,37**
 Ja zaś, podobnie jak i bracia moi za prawa ojców, oddaję ciało oraz duszę, błagając Boga, aby wnet ulitował się nad swym ludem, a ciebie mękami i karami przywiódł do wyznania, że tylko On jest Bogiem.
###### **2Mch 7,38**
 Niech gniew Wszechmogącego, który sprawiedliwie zaciążył nad całym naszym narodem, zatrzyma się na mnie i na moich braciach.
###### **2Mch 7,39**
 Wówczas król uniesiony gniewem kazał go męczyć jeszcze okrutniej niż tamtych, gdyż rozdrażniony był tymi szyderstwami.
###### **2Mch 7,40**
 I tak nieskalany poniósł śmierć całkowicie zaufawszy Panu.
###### **2Mch 7,41**
 Po synach ostatnia zmarła matka.
###### **2Mch 7,42**
 Tyle wystarczy o ucztach ofiarnych i strasznych torturach.
# 2Mch 7 BR
###### **2Mch 7,1**
 Innym razem pochwycono siedmiu braci i ich matkę. Król chciał ich zmusić - wbrew Bożemu prawu - do spożywania wieprzowiny i dlatego kazał ich chłostać rzemieniami i biczami.
###### **2Mch 7,2**
 W pewnej chwili jeden z nich, przemawiając w imieniu wszystkich, powiedział: O co chcesz nas zapytać? Czego chciałbyś się od nas dowiedzieć? Jesteśmy gotowi raczej umrzeć niż przekroczyć prawa naszych ojców.
###### **2Mch 7,3**
 Rozgniewał się tedy król i rozkazał rozpalić ogień pod patelniami i kotłami.
###### **2Mch 7,4**
 Gdy tylko dobrze się rozgrzały, wydał rozkaz, ażeby temu, który przed chwilą przemawiał, odcięto język, ściągnięto - tak jak to czynią Scytowie - skórę z głowy, a także obcięto nos, uszy, ręce i palce stóp. Wszystko to działo się na oczach pozostałych braci oraz ich matki.
###### **2Mch 7,5**
 Ledwie już żywego, lecz oddychającego jeszcze, kazał król przywlec do ognia i smażyć na patelni. Kiedy swąd z patelni zaczął się rozchodzić na wszystkie strony, wszyscy jego bracia i ich matka dodawali sobie wzajemnie odwagi i zachęcali się do mężnej śmierci. Mówili tak:
###### **2Mch 7,6**
 Pan Bóg patrzy na nas i zapewne ulituje się nad nami. Mojżesz powiedział przecież wyraźnie w owej oskarżającej lud pieśni: I ulituje się nad swoimi sługami.
###### **2Mch 7,7**
 Kiedy pierwszy z braci zginął w taki oto sposób, sprowadzono na miejsce kaźni drugiego. Najpierw zdarto mu skórę z głowy razem z włosami i zapytano go: czy będziesz jadł [wieprzowinę], zanim zaczniemy ciąć na kawałki twoje ciało?
###### **2Mch 7,8**
 A on odpowiedział w swojej ojczystej mowie: Nie! Został tedy zamęczony tak samo jak pierwszy.
###### **2Mch 7,9**
 Kiedy już wydał ostatnie tchnienie, powiedział: Odbierasz nam ty, istoto nieludzka, nasze doczesne życie, ale Król świata zmartwychwskrzesi nas do nowego, wiecznego życia, dlatego że oddajemy życie za Jego prawo.
###### **2Mch 7,10**
 Potem wzięli na męki trzeciego. Kiedy zażądano, by wystawił język, zrobił to natychmiast i odważnie wyciągnął ręce,
###### **2Mch 7,11**
 i śmiało powiedział: Dały mi je same Niebiosa, lecz ze względu na prawa tych samych Niebios wcale nie troszczę się o ich posiadanie, bo wiem, że kiedyś znów je od Nich otrzymam.
###### **2Mch 7,12**
 Nawet król i jego ludzie podziwiali odwagę tego młodego człowieka, który tak dzielnie znosił wszystkie cierpienia.
###### **2Mch 7,13**
 Kiedy ten już skonał, zaczęto się w taki sam sposób znęcać nad czwartym.
###### **2Mch 7,14**
 Tuż przed śmiercią powiedział on tak: lepiej jest nam, którzy giniemy z rąk ludzi, w Bogu pokładając nadzieję, że On nas zmartwychwskrzesi, niż tobie [o królu], dla którego nie będzie już żadnego zmartwychwstania do życia.
###### **2Mch 7,15**
 Zaraz potem przystąpiono do piątego i zaczęto go dręczyć.
###### **2Mch 7,16**
 A on, zobaczywszy króla, powiedział: Jesteś tylko nędznym człowiekiem, ale masz władzę czynić z ludźmi, co ci się podoba. Nie sądź jednak, że Bóg całkowicie opuścił już nasz naród.
###### **2Mch 7,17**
 Rób tak dalej, a niebawem przekonasz się, z jaką siłą wystąpi On przeciwko tobie i twoim potomkom.
###### **2Mch 7,18**
 Potem przyprowadzono szóstego, a on konając powiedział: Nie próbuj oszukiwać samego siebie! My idziemy na cierpienia sami, ponieważ zgrzeszyliśmy przeciwko naszemu Bogu. Dlatego spadły na nas te wszystkie nieszczęścia.
###### **2Mch 7,19**
 Ale nie sądź, że tobie uda się ujść kary. Odważyłeś się bowiem rozpocząć walkę z samym Bogiem.
###### **2Mch 7,20**
 Szczególnie godną podziwu okazała się matka i zasłużyła sobie na to, żeby wspominać ją z najwyższym szacunkiem. Patrzyła bowiem, jak w ciągu jednego dnia umierało siedmiu jej synów, jeden po drugim, i mężnie to zniosła, bo zaufała Panu.
###### **2Mch 7,21**
 Pełna najwznioślejszych pragnień, męską odwagą umacniała swoją kobiecą delikatność. Do każdego zaś ze swoich synów tak mówiła w ich ojczystym języku:
###### **2Mch 7,22**
 Nie wiem, jak powstawaliście z mojego ciała; nie ja też dałam wam i tchnienie, i życie, a członki każdego z was nie ja ułożyłam w całość.
###### **2Mch 7,23**
 To sam Stwórca wszechświata nadaje kształt każdemu nowo powstającemu człowiekowi, on to daje początek wszystkiemu. On też ulituje się nad wami i znów da wam kiedyś i tchnienie, i życie, dlatego że wy teraz, nie zważając na siebie, stajecie w obronie Jego prawa.
###### **2Mch 7,24**
 Tymczasem Antioch był przekonany, że wszystko to powiedziała z pogardy dla niego, że chce go w ten sposób poniżyć i obrazić. Spośród zaś siedmiu braci został jeszcze najmłodszy. Do niego nie tylko przemawiał król łagodnie, ale pod uroczystą przysięgą przyobiecał mu nawet, że uczyni go bogatym i szczęśliwym, jeśli tylko odstąpi od obyczajów swoich przodków. Powiedział również, że zaliczy go do grona swoich przyjaciół i uczyni jednym ze swoich najwyższych urzędników.
###### **2Mch 7,25**
 Kiedy zaś młodzieniec nie zwrócił na to wszystko uwagi, wezwał król do siebie jego matkę i zaczął ją namawiać, by przemówiła do syna i skłoniła go do ocalenia życia.
###### **2Mch 7,26**
 Po długich przekonywaniach zgodziła się wreszcie przemówić do syna.
###### **2Mch 7,27**
 Pochyliła się nisko nad nim i drwiąc sobie z okrutnego tyrana, tak powiedziała do niego w ich ojczystym języku: Synu mój, miej litość nade mną. Przez dziewięć miesięcy nosiłam cię w moim łonie, przez trzy lata karmiłam cię własną piersią, żywiłam cię i wychowywałam, i troszczyłam się o ciebie, aż wyrosłeś na młodzieńca.
###### **2Mch 7,28**
 Popatrz, synu mój, na niebo i na ziemię! Przyjrzyj się dokładnie wszystkiemu, co je wypełnia, i pomyśl sobie, że Bóg stworzył to wszystko z niczego. Tak też powołał do życia i ludzi.
###### **2Mch 7,29**
 Nie lękaj się tego oprawcy, okaż się godny twoich braci i idź na śmierć odważnie, abym kiedyś, w czasie zmiłowania Bożego, mogła cię posiąść na nowo razem z twoimi braćmi.
###### **2Mch 7,30**
 Gdy tylko skończyła mówić, młodzieniec zawołał: Na co czekacie? Ja słucham nie rozkazów króla, lecz nakazów prawa, które zostało dane przez Mojżesza ojcom naszym.
###### **2Mch 7,31**
 Ale ty, który się dopuszczasz tych wszystkich zbrodni na Hebrajczykach, nie zdołasz wyrwać się z rąk Boga.
###### **2Mch 7,32**
 My bowiem cierpimy tylko dlatego, żeśmy zgrzeszyli.
###### **2Mch 7,33**
 I choć Król życia rozgniewał się na jakiś czas na nas, aby swoimi karami sprowadzić nas na drogę poprawy, to jednak nadejdzie czas, gdy pojedna się On ze swoimi sługami.
###### **2Mch 7,34**
 Ale ty, bezbożniku, największy ze wszystkich ludzi, przestań unosić się pychą i nie próbuj już w czymkolwiek pokładać nadziei, gdyż podniosłeś twoją rękę na synów Nieba.
###### **2Mch 7,35**
 Nie uda ci się bowiem uniknąć sądu Wszechmocnego i wszystko widzącego Boga.
###### **2Mch 7,36**
 Nasi bracia po krótkich cierpieniach zeszli z tego świata, ale z zapewnieniem Bożym że posiądą życie wieczne. Ty zaś na sądzie Bożym otrzymasz słuszną karę za twoją pychę.
###### **2Mch 7,37**
 Podobnie jak moi bracia, ja również oddaję moje ciało i życie w obronie praw moich ojców i modlę się do Boga, by zechciał się zlitować co rychlej nad swoim ludem, a na tobie doświadczeniami i karami wymógł wyznanie, że tylko On jest Bogiem.
###### **2Mch 7,38**
 Obyż na mnie i na moich braciach wypełniły się dni gniewu Najwyższego, gniewu, który sprawiedliwie został wylany na nasz naród.
###### **2Mch 7,39**
 [Po tych słowach] król bardzo się rozgniewał i obszedł się z nim jeszcze okrutniej niż z innymi, bo poczuł się dotknięty w swojej pysze.
###### **2Mch 7,40**
 Tak więc i ten najmłodszy umierał z czystym sercem, całą ufność pokładając w Bogu.
###### **2Mch 7,41**
 W końcu, już po wszystkich, zgładzono także ich matkę.
###### **2Mch 7,42**
 Niech to już wystarczy w związku z owymi ucztami ofiarnymi i męczarniami [Żydów].
# 2Mch 7 WUJ
