# Ba 3 BT5
###### **Ba 3,1**
 Panie wszechwładny, Boże Izraela, dusza w ucisku i duch zgnębiony woła do Ciebie.
###### **Ba 3,2**
 Wysłuchaj, Panie, zmiłuj się, ponieważ zgrzeszyliśmy przeciw Tobie.
###### **Ba 3,3**
 Ty trwasz na wieki, a my nic nie znaczymy.
###### **Ba 3,4**
 Panie wszechwładny, Boże Izraela, wysłuchaj modlitwy umarłych Izraela i synów tych, którzy grzeszyli przeciw Tobie, którzy nie słuchali głosu Pana, Boga swego. Dlatego przylgnęły do nas te nieszczęścia.
###### **Ba 3,5**
 Nie pamiętaj o grzechach przodków naszych, lecz pomnij obecnie na ramię Twe i imię Twoje.
###### **Ba 3,6**
 Tak, bo Ty jesteś Panem i Bogiem naszym, przeto chwalić Cię będziemy, Panie!
###### **Ba 3,7**
 Dlatego bowiem dałeś bojaźń Twą sercom naszym, abyśmy wzywali imienia Twego. Będziemy Cię chwalili na wygnaniu naszym, ponieważ odwracamy od serc naszych wszelką niegodziwość przodków, którzy grzeszyli przeciw Tobie.
###### **Ba 3,8**
 Oto my dzisiaj na wygnaniu, gdzie rozproszyłeś nas na szyderstwo, przekleństwo i potępienie za wszystkie niegodziwości przodków, którzy odstąpili od Pana, Boga naszego.
###### **Ba 3,9**
 Bądź posłuszny, Izraelu, przykazaniom życio-dajnym, nakłoń ucha, by poznać mądrość.
###### **Ba 3,10**
 Cóż się to stało, Izraelu, że jesteś w kraju nieprzyjaciół, wynędzniały w ziemi obcej,
###### **Ba 3,11**
 uważany za nieczystego na równi z umarłymi, zaliczony do tych, co schodzą do Otchłani?
###### **Ba 3,12**
 Opuściłeś źródło mądrości.
###### **Ba 3,13**
 Gdybyś chodził po drodze Bożej, mieszkałbyś w pokoju na wieki.
###### **Ba 3,14**
 Naucz się, gdzie jest mądrość, gdzie jest siła i rozum, a poznasz równocześnie, gdzie jest długie i szczęśliwe życie, gdzie jest światłość dla oczu i pokój.
###### **Ba 3,15**
 Lecz któż znalazł jej miejscelub kto wszedł do jej skarbców?
###### **Ba 3,16**
 Gdzież są zwierzchnicy narodówi panujący nad zwierzętami, co są na ziemi,
###### **Ba 3,17**
 ci, co igrają z ptakami podniebnymi, ci, co gromadzą srebro i złoto, w których ludzie pokładali ufność, a nie ma końca nabywaniu tych rzeczy,
###### **Ba 3,18**
 [gdzież są ci,] którzy obrabiają srebro,trudzą się tak, że prawie nie widać końca ich pracy?
###### **Ba 3,19**
 Zniknęli i do Otchłani zstąpili, a inni stanęli na ich miejsce.
###### **Ba 3,20**
 Młodsi ujrzeli światłoi zamieszkali na ziemi, ale drogi mądrości nie pojęli,
###### **Ba 3,21**
 nie poznali jej ścieżekani jej nie uchwycili, a synowie od drogi ich daleko odeszli.
###### **Ba 3,22**
 Nie słyszano o niej w Kanaanieani w Temanie jej nie widziano.
###### **Ba 3,23**
 Synowie Hagar ubiegają się o mądrość tej ziemi, kupcy z Merranu i Temanu, bajarze i poszukiwacze wiedzynie znają drogi mądrościani nie pamiętają o jej ścieżkach.
###### **Ba 3,24**
 O Izraelu, jakże wielki jest dom Boga, jakże rozległy obszar Jego posiadłości!
###### **Ba 3,25**
 Wielki i nie mający końca, wysoki i niezmierzony.
###### **Ba 3,26**
 Tam urodzili się olbrzymi, sławni od początku, wielcy, biegli w walce.
###### **Ba 3,27**
 Ale nie tych wybrał Bógi nie im wskazał drogę do mądrości.
###### **Ba 3,28**
 Zginęli dlatego, że mądrości nie mieli, zginęli z powodu swej nierozwagi.
###### **Ba 3,29**
 Któż wstąpił do nieba, aby ją wziąć, któż ją z obłoków sprowadził?
###### **Ba 3,30**
 Któż przeprawił się przez morze, a znalazł jąi przywiózł w zamian za najlepsze złoto?
###### **Ba 3,31**
 Nie ma nikogo, kto by znał jej drogęi kto by rozpoznał jej ścieżkę;
###### **Ba 3,32**
 lecz zna ją Wszechwiedzącyi zbadał ją swoim rozumem. Ten, który na czas bezkresny urządził ziemięi napełnił ją stworzeniami czworonożnymi,
###### **Ba 3,33**
 wysłał światło, i poszło, wezwał je, a ono posłuchało Go z drżeniem.
###### **Ba 3,34**
 Gwiazdy radośnie świecą na swoich strażnicach.
###### **Ba 3,35**
 Wezwał je. Odpowiedziały: «***Jesteśmy***».Z radością świecą swemu Stwórcy.
###### **Ba 3,36**
 On jest Bogiem naszym. I żaden inny nie możez Nim się równać.
###### **Ba 3,37**
 Zbadał wszystkie drogi mądrościi dał ją słudze swemu, Jakubowi, i Izraelowi, umiłowanemu swojemu.
###### **Ba 3,38**
 Potem ukazała się ona na ziemii zaczęła przebywać wśród ludzi.
# Ba 3 PAU
###### **Ba 3,1**
 PANIE wszechwładny, Boże Izraela! Do Ciebie woła dusza uciśniona i duch zgnębiony.
###### **Ba 3,2**
 Wysłuchaj, PANIE, zmiłuj się, bo zgrzeszyliśmy przeciw Tobie!
###### **Ba 3,3**
 Ty trwasz na wieki, a nam grozi wieczna zagłada.
###### **Ba 3,4**
 PANIE wszechwładny, Boże Izraela! Wysłuchaj modlitwy Izraela bliskiego śmierci, synów tych, którzy grzeszyli przeciw Tobie. Nie słuchali oni głosu PANA, swego Boga, i dlatego spadły na nas te nieszczęścia.
###### **Ba 3,5**
 Nie pamiętaj nieprawości naszych przodków, lecz wspomnij teraz na rękę i na imię Twoje!
###### **Ba 3,6**
 Przecież Ty jesteś PANEM, naszym Bogiem i Ciebie chcemy wielbić, PANIE!
###### **Ba 3,7**
 Po to właśnie wlałeś Twą bojaźń w nasze serca, abyśmy wzywali Twego imienia. Także na wygnaniu chcemy Cię chwalić, dlatego wyrzucamy z naszych serc wszelką nieprawość przodków, którzy grzeszyli przeciw Tobie.
###### **Ba 3,8**
 Oto dzisiaj jesteśmy tu, na wygnaniu, gdzie nas rozproszyłeś na pośmiewisko, przekleństwo i karę za wszystkie nieprawości naszych przodków, którzy odstąpili od PANA, Boga naszego”.
###### **Ba 3,9**
 Słuchaj, Izraelu, przykazań niosących życie, nakłoń ucha, aby poznać mądrość.
###### **Ba 3,10**
 Cóż się to stało, Izraelu, że znalazłeś się w kraju nieprzyjaciół, zestarzałeś się w obcej ziemi,
###### **Ba 3,11**
 stałeś się nieczysty na równi z umarłymi, zaliczony zostałeś do tych, co schodzą do krainy umarłych?
###### **Ba 3,12**
 Opuściłeś źródło mądrości!
###### **Ba 3,13**
 Gdybyś chodził Bożą drogą, mieszkałbyś w pokoju na wieki.
###### **Ba 3,14**
 Dowiedz się wreszcie, gdzie jest mądrość, gdzie siła i gdzie zrozumienie. Poznaj zarazem, gdzie długowieczność i szczęśliwe życie, gdzie światłość dla oczu i pokój.
###### **Ba 3,15**
 Któż jednak znalazł jej miejsce i kto wszedł do jej skarbców?
###### **Ba 3,16**
 Gdzie są władcy ludów i pogromcy dzikich zwierząt,
###### **Ba 3,17**
 ci, co się bawią ptactwem powietrznym, ci, co gromadzą srebro i złoto, w których ludzie pokładają ufność i które bez końca nabywają?
###### **Ba 3,18**
 Gdzie są ci, co srebro kują, ci, którzy tak się trudzą, że nie znajdują wytchnienia?
###### **Ba 3,19**
 Zniknęli i zstąpili do krainy umarłych, a ich miejsce zajęli inni.
###### **Ba 3,20**
 Ich następcy ujrzeli światło i zasiedlili ziemię. Nie poznali jednak drogi mądrości,
###### **Ba 3,21**
 nie pojęli jej ścieżek ani się jej nie trzymali. Zaś ich synowie zboczyli z drogi ojców.
###### **Ba 3,22**
 W Kanaanie nikt o niej nie słyszał ani w Temanie nikt jej nie widział.
###### **Ba 3,23**
 Podobnie synowie Hagar, szukający mądrości na ziemi, kupcy Merranu i Temanu, ci, co opowiadają baśnie i szukają wiedzy -oni wszyscy drogi mądrości nie znają ani nie pamiętają jej ścieżek.
###### **Ba 3,24**
 O Izraelu, jakże wielki jest dom Boga i jak rozległa Jego posiadłość!
###### **Ba 3,25**
 Wielka i bezkresna, wysoka i niezmierzona.
###### **Ba 3,26**
 Tam zostali zrodzeni olbrzymi, sławni od początku, ogromni i sprawni w walce.
###### **Ba 3,27**
 Nie tych jednak Bóg sobie wybrał i nie im powierzył drogę mądrości.
###### **Ba 3,28**
 Zginęli właśnie dlatego, że nie mieli mądrości, zginęli z braku rozsądku.
###### **Ba 3,29**
 Któż wstąpił do nieba, aby ją zdobyć, kto ją sprowadził z obłoków?
###### **Ba 3,30**
 Któż się przeprawił przez morze i ją znalazł, kto ją sprowadził, płacąc szczerym złotem?
###### **Ba 3,31**
 Nikt nie zna jej drogi, nikt nie odkrył jej ścieżki.
###### **Ba 3,32**
 Zna ją jedynie Wszechwiedzący i odkrył ją swoim rozumem. On umocnił ziemię po wieczne czasy i napełnił czworonożnymi stworzeniami.
###### **Ba 3,33**
 On wysyła światło, a ono mknie, wzywa je, a ono z drżeniem Go słucha.
###### **Ba 3,34**
 Gwiazdy zaś radośnie świecą na swoich strażnicach.
###### **Ba 3,35**
 Wezwał je, a one odpowiedziały: „Jesteśmy”. I zaświeciły swemu Stwórcy z radością.
###### **Ba 3,36**
 On właśnie jest naszym Bogiem. Nikt inny nie może się z Nim równać.
###### **Ba 3,37**
 On zbadał wszystkie drogi mądrości. Dał ją Jakubowi, swemu słudze, Izraelowi, swemu umiłowanemu.
###### **Ba 3,38**
 Potem ukazała się sama na ziemi i zamieszkała wśród ludzi.
# Ba 3 BP
###### **Ba 3,1**
 "Wszechmocny Panie, Boże Izraela! Dusza uciśniona i duch niespokojny woła do Ciebie!
###### **Ba 3,2**
 Wysłuchaj, Panie, i ulituj się, bo zgrzeszyliśmy przeciw Tobie.
###### **Ba 3,3**
 Ty bowiem trwasz na wieki, a my mielibyśmy zginąć na zawsze?
###### **Ba 3,4**
 Panie Wszechmocny, Boże Izraela! Wysłuchaj przeto modlitwy umarłych Izraela i synów tych, którzy zgrzeszyli przeciwko Tobie, którzy nie słuchali głosu Pana, swego Boga, i dlatego to przylgnęły do nas te nieszczęścia.
###### **Ba 3,5**
 Nie pamiętaj już o niesprawiedliwościach naszych ojców! Pomnij teraz raczej o swej potędze i swoim Imieniu.
###### **Ba 3,6**
 Tyś bowiem Panem, Bogiem naszym, i Ciebie, o Panie wysławiać będziemy.
###### **Ba 3,7**
 Dlatego włożyłeś w nasze serca bojaźń Twoją przed Tobą, abyśmy wzywali Twojego Imienia. Tak, będziemy Cię wielbili na naszym wygnaniu, gdyż odrzuciliśmy z naszych serc wszelką nieprawość naszych ojców, którzy zgrzeszyli przeciw Tobie.
###### **Ba 3,8**
 Oto jesteśmy dziś na naszym wygnaniu, dokąd nas rozproszyłeś na wzgardę, przekleństwo i na karę [jako odpłatę] za wszystkie nieprawości naszych ojców, którzy odwrócili się od Pana, Boga naszego".
###### **Ba 3,9**
 Słuchaj, Izraelu, przykazań życia, nakłoń ucha, byś poznał roztropność!
###### **Ba 3,10**
 Jak to się stało, Izraelu, jak? - żeś się znalazł w kraju nieprzyjaciół, żeś się zestarzał w ziemi obcej,
###### **Ba 3,11**
 że się plamisz umarłymi i żeś jest zaliczony między tych, co zeszli do podziemia?
###### **Ba 3,12**
 Opuściłeś źródło mądrości !
###### **Ba 3,13**
 Gdybyś był postępował drogą Bożą, mieszkałbyś w pokoju na wieki.
###### **Ba 3,14**
 Uczże się, gdzie jest roztropność, gdzie siła, gdzie mądrość, a poznasz równocześnie, gdzie jest długowieczność i życie, gdzie światłość oczu i pokój.
###### **Ba 3,15**
 Któż odkrył miejsce [mądrości] i któż dotarł do jej skarbów?
###### **Ba 3,16**
 Gdzież są władcy narodów i pogromcy zwierząt żyjących na ziemi,
###### **Ba 3,17**
 ci, co z ptakami niebieskimi się bawią, co srebro i złoto gromadzą, w których ludzie pokładają swą ufność i których gromadzeniu nie ma końca?
###### **Ba 3,18**
 [Gdzież są ci], którzy z mozołem wytapiają srebro, a śladu nie zostaje z ich dzieł?
###### **Ba 3,19**
 Zniknęli i zstąpili do Szeolu, a inni powstali zamiast nich.
###### **Ba 3,20**
 Nowe pokolenie ujrzało światłość i zamieszkało na ziemi, lecz i ono nie poznało drogi mądrości,
###### **Ba 3,21**
 ścieżek jej nie odkryło. Nie pojęli jej również ich synowie, pozostali daleko od jej drogi.
###### **Ba 3,22**
 Nie słychać, by mówiono o niej w Kanaanie, nie widziano jej w Teman.
###### **Ba 3,23**
 I synowie Agar, poszukujący mądrości, która jest z tej ziemi, kupcy z Merry i Teman, tłumacze przypowieści i poszukiwacze wiedzy nie poznali drogi mądrości, a nawet zapomnieli o jej ścieżkach.
###### **Ba 3,24**
 O Izraelu, jak wielki jest Dom Boga i jak obszerne miejsce Jego posiadłości!
###### **Ba 3,25**
 Wielkie i bezgraniczne, wyniosłe i niezmierzone!
###### **Ba 3,26**
 Tam niegdyś urodzili się giganci, sławni od początku, rośli i doświadczeni w boju.
###### **Ba 3,27**
 Nie ich jednak wybrał sobie Bóg i nie ich pouczył o drodze mądrości.
###### **Ba 3,28**
 Zginęli, bo nie mieli roztropności, zginęli z powodu swej głupoty.
###### **Ba 3,29**
 Któż wstąpił na niebiosa i posiadł ją, i sprowadził z obłoków?
###### **Ba 3,30**
 Któż przeprawił się przez morze, a znalazłszy ją sprowadził za cenę najczystszego złota?
###### **Ba 3,31**
 Nikt nie zna jej drogi, nikt nie pojął jej ścieżki.
###### **Ba 3,32**
 Lecz Ten, który wie wszystko, zna ją, On odkrył ją swoim rozumem! Ten, który utwierdził ziemię po wieczny czas i napełnił ją czworonożnymi zwierzętami;
###### **Ba 3,33**
 który spuszcza błyskawicę, a idzie; który przywołuje ją, a ona drżąc jest Mu posłuszna!
###### **Ba 3,34**
 Gwiazdy świecą na swych posterunkach i radują się!
###### **Ba 3,35**
 On je woła, a one odpowiadają: "Jesteśmy!" Świecą radośnie Temu, który je stworzył.
###### **Ba 3,36**
 To On jest Bogiem naszym, a inne [bóstwa] są niczym wobec Niego.
###### **Ba 3,37**
 On odnalazł wszystkie drogi mądrości i udzielił jej swojemu słudze Jakubowi i Izraelowi, swemu umiłowanemu.
###### **Ba 3,38**
 Po czym pojawiła się na ziemi i przebywała pośród ludzi.
# Ba 3 BR
###### **Ba 3,1**
 Panie, Wszechmogący, Boże Izraela! Woła do Ciebie dusza pełna zalęknienia i ucisku.
###### **Ba 3,2**
 Wysłuchaj nas, o Panie, i zmiłuj się nad nami, bo zgrzeszyliśmy przeciwko Tobie.
###### **Ba 3,3**
 Twoje panowanie trwa na wieki, a nam grozi wieczna zagłada.
###### **Ba 3,4**
 Panie, Wszechmocny Boże Izraela! Wysłuchaj błagania skazanego na śmierć Izraela, synów tych, którzy zgrzeszyli przeciwko Tobie i nie chcieli słuchać głosu Pana ich i Boga. I tak spadły na nas te nieszczęścia.
###### **Ba 3,5**
 Racz nie pamiętać już o złych czynach ojców naszych, a wspomnij raczej na Twoje silne ramię i na Imię Twoje!
###### **Ba 3,6**
 Ty jesteś przecież Panem i Bogiem naszym, a my wysławiać Cię będziemy, o Panie!
###### **Ba 3,7**
 Dlatego bowiem napełniasz nasze serca bojaźnią przed Tobą, abyśmy wzywali Twojego Imienia. Na wygnaniu naszym też chcemy Cię wysławiać. Odwróciliśmy już nasze serca od wszelkiego zła ojców naszych, którzy grzeszyli przeciwko Tobie.
###### **Ba 3,8**
 Popatrz, po dzień dzisiejszy żyjemy w krainach naszego wygnania, którym Ty nas pokarałeś na pogardę, przekleństwo i pośmiewisko według wszystkich złych uczynków ojców naszych, którzy odeszli daleko od Pana i Boga naszego.
###### **Ba 3,9**
 Wypełniaj, Izraelu, przykazania życia i zabiegaj o to, żeby mądrość posiadać.
###### **Ba 3,10**
 A czemuż to, Izraelu, czemuż żyjesz w krainie twoich wrogów? Czemu upływają ci lata na obcej ziemi?
###### **Ba 3,11**
 Czemu musiałeś stać się nieczystym i do trupa podobnym, i jak ci, co odchodzą w zaświaty?
###### **Ba 3,12**
 Bo odszedłeś od źródła mądrości.
###### **Ba 3,13**
 Gdybyś chodził drogami Bożymi, mieszkałbyś w pokoju po wsze czasy.
###### **Ba 3,14**
 Teraz więc dowiaduj się, gdzie można znaleźć mądrość, siłę i rozsądek. Wtedy dowiesz się też, gdzie będziesz mógł żyć długo i szczęśliwie, gdzie będziesz mógł znaleźć światło dla twoich oczu i spokój.
###### **Ba 3,15**
 Ale kto znalazł miejsce, gdzie przebywa mądrość? Kto zdołał się już dostać do jej przybytków?
###### **Ba 3,16**
 Gdzież są owi zwierzchnicy całych narodów i panujący również nad zwierzętami całej ziemi?
###### **Ba 3,17**
 Ci, co igrają z ptactwem powietrznym, gromadzą srebro i złoto, w którym ludzie pokładają taką ufność, a żądza ich posiadania nie ma żadnych granic?
###### **Ba 3,18**
 Gdzie są ci, którzy wykonują ze srebra przedmioty tak mozolnie, że praca nad nimi nie ma końca?
###### **Ba 3,19**
 Znikli już, odeszli w zaświaty, a na ich miejsce przyszli inni.
###### **Ba 3,20**
 Inni dostrzegli światło i zamieszkali na ziemi, ale też nie rozpoznali drogi mądrości,
###### **Ba 3,21**
 nie zrozumieli jej szlaków, nie odkryli jej śladów. Ich synowie zaś ze swojej drogi zeszli bardzo daleko.
###### **Ba 3,22**
 Nikt nie słyszał o niej w Kanaanie, nikt też nie widział jej w Temanie.
###### **Ba 3,23**
 Synowie Hagar szukający mądrości i po całej ziemi, kupcy z Madianu i Temanu, różni opowiadacze bajek i poszukujący wiedzy - oni też nie rozpoznali drogi mądrości i nie odkryli jej ścieżek.
###### **Ba 3,24**
 O Izraelu, jakże ogromna jest świątynia Pana, jak daleko sięgają granice królestwa Jego!
###### **Ba 3,25**
 Nieskończenie daleko i niezmiernie wysoko.
###### **Ba 3,26**
 Tam przyszli na świat olbrzymi, sławni owi mężowie pradawni, ogromni wzrostem i niezwykle waleczni.
###### **Ba 3,27**
 A jednak nie ich Bóg wybrał i nie im ukazał drogę mądrości.
###### **Ba 3,28**
 Zginęli, bo byli pozbawieni rozsądku; spotkała ich zagłada, bo mądrości im nie stało.
###### **Ba 3,29**
 Któż wstąpił na wyżyny niebieskie, znalazł tam mądrość i przyniósł ją z obłoków na ziemię?
###### **Ba 3,30**
 Kto, powędrowawszy za morza, odnalazł ją tam i za cenę najszczerszego złota przywiózł do siebie?
###### **Ba 3,31**
 Nikt nie zna jej drogi, nikt nie potrafi odkryć jej ścieżek.
###### **Ba 3,32**
 Lecz zna je Wszystkowiedzący. On odkrył je w swojej mądrości. To On na zawsze osadził mocno ziemię i napełnił ją zwierzętami.
###### **Ba 3,33**
 To On wysyła promienie światła, które pomknęło daleko. Gdy wzywa je z powrotem do siebie, ono drżąc do Niego wraca.
###### **Ba 3,34**
 Radośnie świecą gwiazdy trwając na swoich miejscach.
###### **Ba 3,35**
 Kiedy je woła, odpowiadają natychmiast: Tu jesteśmy! I świecą radośnie na cześć swego Stwórcy.
###### **Ba 3,36**
 Taki jest nasz Bóg i oprócz Niego nie ma żadnego, który by Mu dorównał.
###### **Ba 3,37**
 To On znalazł drogę mądrości i ukazał ją słudze swojemu, Jakubowi, oraz Izraelowi, umiłowanemu swemu.
###### **Ba 3,38**
 Potem sama ukazała się ona na ziemi i pozostała między ludźmi.
# Ba 3 WUJ
