# Am 7 BT5
###### **Am 7,1**
 To mi ukazał Pan Bóg: oto tworzy szarańczę na początku odrastania potrawu, a był to potraw po sianokosach królewskich;
###### **Am 7,2**
 i gdy ona [już miała] zjeść doszczętnie trawę na ziemi, prosiłem:«***Panie Boże, przebacz, jakże się ostoi Jakub? Przecież jest taki mały***».
###### **Am 7,3**
 Zmiłował się Pan nad nim:«***To się nie stanie***» – rzekł Pan.
###### **Am 7,4**
 To mi ukazał Pan Bóg:Pan Bóg powołał jako narzędzie sądu ogieńi strawił on Wielką Otchłań, i strawił część pola.
###### **Am 7,5**
 I prosiłem: «***Panie Boże, przestań, jakże się ostoi Jakub? Przecież jest taki mały***».
###### **Am 7,6**
 Zmiłował się Pan nad nim: «***Również i to się nie stanie***» – rzekł Pan Bóg.
###### **Am 7,7**
 To mi ukazał:oto Pan stoi na murze i w ręku Jego pion ołowiany.
###### **Am 7,8**
 I zapytał mnie Pan: «***Co widzisz, Amosie?***» Odpowiedziałem: «***Pion ołowiany***».I rzekł Pan: «***Oto opuszczę pion pośrodku ludu mego, Izraela. Już mu więcej nie przepuszczę.***
###### **Am 7,9**
 ***Spustoszone będą wyżyny Izaaka i świątynie Izraela – zniszczone. Wystąpię z mieczem przeciwko domowi Jeroboama***».
###### **Am 7,10**
 Posłał Amazjasz, kapłan z Betel, do Jeroboama, króla izraelskiego, aby mu powiedzieć: «***Spiskuje przeciw tobie Amos pośród domu Izraela. Nie może ziemia znieść wszystkich słów jego,***
###### **Am 7,11**
 ***gdyż tak rzekł Amos: Od miecza umrze Jeroboam i Izrael będzie uprowadzony ze swojej ziemi***».
###### **Am 7,12**
 I rzekł Amazjasz do Amosa: «***"Widzący", idź sobie, uciekaj do ziemi Judy! I tam jedz chleb, i tam prorokuj!***
###### **Am 7,13**
 ***A w Betel więcej nie prorokuj, bo jest ono królewską świątynią i królewską budowlą***».
###### **Am 7,14**
 I odpowiedział Amos Amazjaszowi: «***Nie jestem ja prorokiem ani nie jestem synem proroków, gdyż jestem pasterzem i tym, który nacina sykomory.***
###### **Am 7,15**
 ***Od trzody bowiem wziął mnie Pan i rzekł do mnie Pan: "Idź, prorokuj do narodu mego, izraelskiego!"***
###### **Am 7,16**
 ***A teraz słuchaj słowa Pańskiego!Tyś mówił: Nie prorokuj przeciwko Izraelowi ani nie przepowiadaj przeciwko domowi Izaaka!***
###### **Am 7,17**
 ***Dlatego tak rzekł Pan: "Żona twoja w mieście będzie nierządnicą.Synowie zaś i córki twoje od miecza poginą. Ziemię twoją sznurem podzielą. Ty umrzesz na ziemi nieczystej, a Izrael zostanie ze swej ziemi uprowadzony"***».
# Am 7 PAU
###### **Am 7,1**
 To mi ukazał PAN BÓG: Tworzy On rój szarańczy w czasie odrastania trawy, po sianokosach królewskich.
###### **Am 7,2**
 Kiedy już pożarła trawę w całym kraju, powiedziałem: PANIE BÓŻE, przebacz! Jakże ostoi się Jakub? Przecież jest taki mały.
###### **Am 7,3**
 Zmiłował się PAN nad nim. „Nie stanie się tak” - powiedział PAN.
###### **Am 7,4**
 To mi ukazał PAN BÓG: PAN BÓG przywołał ogień jako narzędzie kary, spalił on wielką otchłań i strawił pola.
###### **Am 7,5**
 I prosiłem: „PANIE BÓŻE, zaniechaj tego, jakże ostoi się Jakub? Przecież jest taki mały”.
###### **Am 7,6**
 PAN zmiłował się nad nim. „Również i to się nie stanie” - powiedział PAN BÓG.
###### **Am 7,7**
 Potem to mi ukazał: Oto Pan stał na murze i trzymał w ręku pion ołowiany.
###### **Am 7,8**
 I zapytał mnie PAN: „Co widzisz, Amosie?”. Odpowiedziałem: „Pion ołowiany”. PAN powiedział do mnie: „Oto spuszczam pion w środek mego ludu, Izraela. Już więcej mu nie przebaczę.
###### **Am 7,9**
 Spustoszone będą wzniesienia kultowe Izaaka i zniszczone święte miejsca Izraela, gdy wystąpię z mieczem przeciwko domowi Jeroboama”.
###### **Am 7,10**
 Amazjasz, kapłan Betel, wysłał posłańca do Jeroboama, króla izraelskiego, aby mu powiedzieć: „Amos spiskuje przeciw tobie wśród Izraelitów. Kraj nie może znieść wszystkich jego mów,
###### **Am 7,11**
 gdyż tak mówi Amos: «Jeroboam zginie od miecza, a Izrael na pewno zostanie uprowadzony ze swojego kraju»”.
###### **Am 7,12**
 I powiedział Amazjasz do Amosa: „Idź stąd, widzący, uciekaj do kraju Judy! Tam jedz chleb i tam prorokuj!
###### **Am 7,13**
 A w Betel nie prorokuj więcej, bo jest ono świątynią króla i sanktuarium królestwa”.
###### **Am 7,14**
 Lecz Amos odpowiedział Amazjaszowi: „Nie jestem prorokiem ani uczniem proroków, lecz jestem pasterzem i tym, który nacina sykomory.
###### **Am 7,15**
 To PAN wziął mnie od owiec i PAN powiedział do mnie: «Idź prorokować mojemu ludowi izraelskiemu!».
###### **Am 7,16**
 Teraz więc słuchaj słowa PANA! Ty mówisz: «Nie prorokuj przeciwko Izraelowi ani nie przepowiadaj przeciwko domowi Izaaka!».
###### **Am 7,17**
 Dlatego tak powiedział PAN: «Twoja żona będzie nierządnicą w mieście, a twoi synowie i córki zginą od miecza. Twoją ziemię podzielą sznurem, a ty umrzesz na nieczystej ziemi, Izrael zaś na pewno zostanie uprowadzony ze swojego kraju»”.
# Am 7 BP
###### **Am 7,1**
 To mi ukazał Jahwe-Pan: Oto stworzył szarańczę, w czasie gdy zaczynał wschodzić potraw, mianowicie potraw po kośbie królewskiej.
###### **Am 7,2**
 Gdy tedy miała pożreć całą roślinność kraju, rzekłem: "O Jahwe, Panie, zechciej przebaczyć! Jakże się Jakub ostoi? Jest przecież taki mały!"
###### **Am 7,3**
 Więc ulitował się Jahwe. "Nie stanie się to" - powiedział Jahwe.
###### **Am 7,4**
 To mi ukazał Jahwe-Pan: Oto (Jahwe-Pan) wezwał płomień ognisty, który wchłonął wielką otchłań wód, a potem zaczął pochłaniać pola.
###### **Am 7,5**
 Wtedy rzekłem: "O Jahwe, Panie, racz tego zaniechać! Jakże się Jakub ostoi? Jest przecież taki mały!"
###### **Am 7,6**
 Więc ulitował się Jahwe. "I to się nie stanie" - powiedział Jahwe-Pan.
###### **Am 7,7**
 To mi ukazał [Jahwe-] Pan: Oto stał na (prostym) murze z ołowianym pionem w ręku.
###### **Am 7,8**
 Rzekł do mnie Jahwe: "Co widzisz, Amosie?" Odrzekłem: "Pion ołowiany". Wtedy powiedział Jahwe: "Oto przyłożę pion do ludu mego, Izraela; nie będę mu już dłużej pobłażał.
###### **Am 7,9**
 Wyżyny Izaaka będą spustoszone, świątynie Izraela będą zburzone, a przeciw domowi Jeroboama powstanę z mieczem".
###### **Am 7,10**
 Amazjasz, kapłan w Betel, posłał do Jeroboama, króla izraelskiego, i kazał mu powiedzieć: Spiskuje przeciwko tobie Amos pośród Domu Izraela. Kraj nie może znieść tego wszystkiego, co on mówi.
###### **Am 7,11**
 Bo Amos głosi: "Jeroboam zginie od miecza, a Izrael pójdzie na wygnanie, daleko od swej ojczyzny".
###### **Am 7,12**
 Do Amosa zaś powiedział Amazjasz: Odejdź stąd, jasnowidzu, uciekaj do Judei! Tam jedz [swój] chleb i tam sobie prorokuj!
###### **Am 7,13**
 Ale w Betel nie będziesz już dłużej prorokował, bo to jest świątynia królewska i dom Królestwa!
###### **Am 7,14**
 Amos odrzekł na to Amazjaszowi: Nie jestem prorokiem [z zawodu] ani uczniem prorockim; jestem pasterzem i hodowcą sykomor.
###### **Am 7,15**
 To Jahwe wezwał mnie od trzody i powiedział do mnie: "Idź, prorokuj ludowi memu izraelskiemu!"
###### **Am 7,16**
 Posłuchaj teraz słowa Jahwe! Ty powiadasz: "Nie będziesz prorokował przeciw Izraelowi i nie będziesz mówił przeciw Domowi Izaaka!"
###### **Am 7,17**
 A oto co mówi Jahwe: "Żona twoja stanie się nierządnicą w mieście, twoi synowie i twoje córki padną od miecza, posiadłość twoją podzielą sznurem, ty zaś umrzesz w ziemi nieczystej; a Izrael pójdzie na wygnanie, daleko od swej ojczyzny".
# Am 7 BR
###### **Am 7,1**
 Oto, co ukazał mi Pan w pewnym widzeniu: Pojawiło się bardzo wiele szarańczy, kiedy zaczął rosnąć pierwszy potraw, (pierwszy potraw wyrasta po sianokosach królewskich).
###### **Am 7,2**
 Otóż szarańcza pochłonęła wszystko, co tylko było zielone w całym kraju. Wtedy zawołałem: Boże mój i Panie, przebacz nam! Jakże wytrzyma to wszystko Jakub? Przecież jest taki mały!
###### **Am 7,3**
 ulitował się tedy Pan i powiedział: Nie przyjdzie nań to wszystko.
###### **Am 7,4**
 A oto, co pokazał mi Pan Bóg w innym widzeniu: Wezwał Pan Bóg ogień, żeby pokarał ludzi. I wypełniła się ogniem cała otchłań i miał zgotować zagładę całej ziemi Jakuba.
###### **Am 7,5**
 Wtedy zawołałem: Boże mój i Panie, racz nie czynić tego! Jakże wytrzyma to wszystko Jakub? Przecież jest taki mały!
###### **Am 7,6**
 Ulitował się tedy Pan i powiedział: Nie przyjdzie nań to wszystko.
###### **Am 7,7**
 A oto, co pokazał mi Pan Bóg w innym widzeniu: Stał On na murze i trzymał w ręku pion z ołowiu.
###### **Am 7,8**
 Potem zapytał mnie: Co widzisz, Amosie? A ja odpowiedziałem: Pion z ołowiu. Wtedy Pan powiedział: Za pomocą tego pionu doświadczam mój lud izraelski. Tym razem już mu nie przebaczę.
###### **Am 7,9**
 Spustoszone zostaną wszystkie wyżyny Izaaka, zburzone będą wszystkie przybytki Izraela. Z mieczem w ręku wyruszę na dom Jeroboama.
###### **Am 7,10**
 Amazjasz, kapłan z Betel, taką wiadomość przesłał królowi izraelskiemu, Jeroboamowi: W samym środku domu Izraela Amos nawołuje wszystkich do buntu przeciwko tobie. To, co on mówi, jest nie do zniesienia dla twojego kraju.
###### **Am 7,11**
 Amos tak bowiem mówi: Jeroboam zginie od miecza, cały Izrael musi opuścić swój kraj i udać się na wygnanie.
###### **Am 7,12**
 Do samego zaś Amosa tak powiedział Amazjasz: Idź sobie stąd, jasnowidzu! Wynoś się do ziemi judzkiej! Tam spożywaj swój chleb i tam występuj jako prorok.
###### **Am 7,13**
 W Betel nie wolno ci już prorokować. Jest to bowiem królewska świątynia i przybytek króla.
###### **Am 7,14**
 Wtedy Amos tak odpowiedział Amazjaszowi: Nie jestem prorokiem ani nawet uczniem proroków. Ja tylko pilnuję bydła na pastwisku i doglądam sykomor.
###### **Am 7,15**
 To sam Pan wziął mnie od mojej trzody i powiedział: Idź i przemawiaj jako prorok do mojego ludu izraelskiego!
###### **Am 7,16**
 A teraz ty posłuchaj, co mówi Pan: Powiedziałeś mi, żebym nie wygłaszał proroctw przeciwko Izraelowi ani przeciwko domowi Izaaka.
###### **Am 7,17**
 Dlatego Pan każe ci donieść: Twoja własna żona będzie się zachowywać w mieście jak zwykła nierządnica, twoi synowie i córki zginą od miecza, twoje pola zostaną podzielone, a ty sam umrzesz w kraju nieczystym. Cały zaś Izrael musi opuścić swójk kraj i udać się na wygnanie.
# Am 7 WUJ
###### **Am 7,1**
 To mi ukazał Pan Bóg: a oto twórca szarańczej na początku wyrastających rzeczy ode dżdżu pozdnego, a oto pozdny po postrzyżeniu królewskiem.
###### **Am 7,2**
 I stało się gdy dokonała jeść trawy ziemie, rzekłem: Panie Boże bądź miłościw proszę: któż wzniesie Jakóba, bo jest maluczki.
###### **Am 7,3**
 Zmiłował się Pan nad tem: Nie będzie, rzekł Pan.
###### **Am 7,4**
 To mi ukazał Pan Bóg: a oto wołał sądu do ognia PAN Bóg: i pożarł przepaść wielką, i zjadł część pospołu.
###### **Am 7,5**
 I rzekłem: Panie Boże przestań, proszę: kto wzniesie Jakóba, bo maluczki jest?
###### **Am 7,6**
 Zmiłował się Pan nad tem: Lecz i to nie będzie, rzekł Pan Bóg.
###### **Am 7,7**
 To mi ukazał Pan: A oto Pan stojący na murze potynkowanym, a w ręce jego kielnia murarska.
###### **Am 7,8**
 I rzekł Pan do mnie: Co ty widzisz Amos? i rzekłem, kielnia murarską. I rzekł Pan: Oto ja położę kielnia w pośrodku ludu mego Izraelskiego: nie przydam więcej tynkować go.
###### **Am 7,9**
 I obalone będą wyżyny bałwańskie, a świątynie Izraelowe spustoszone będą, i powstanę na dom Jeroboama z mieczem.
###### **Am 7,10**
 I posłał Amazyasz kapłan Bethel do Jeroboama króla Izrael, mówiąc: powstał przeciw tobie Amos w pośrodku domu Izraelowego: nie będzie mogła ziemia znieść wszystkich mów jego.
###### **Am 7,11**
 Bo to mówi Amos: Od miecza umrze Jeroboam, a Izrael pojmany przeprowadzi się z ziemie swej.
###### **Am 7,12**
 I rzekł Amaziasz do Amos: Który widzisz idź, uciecz do ziemie Judzkiej, a jedz tam chleb, i tam prorokuj.
###### **Am 7,13**
 A w Bethel nie przyczyniaj więcej prorokować: bo świątynią jest królewską, i domem królestwa jest.
###### **Am 7,14**
 Odpowiedział Amos, i rzekł do Amazyasza: Nie jestem prorokiem, i nie jestem synem proroka: alem ja skotarz obrywający leśne figi.
###### **Am 7,15**
 I wziął mię Pan, gdym chodził za bydłem: i rzekł Pan do mnie: Idź prorokuj do ludu mego Izraelskiego.
###### **Am 7,16**
 A teraz słuchaj słowa Pańskiego: Ty mówisz: Nie będziesz prorokował na Izraela, a nie będziesz kropił na dom bałwana.
###### **Am 7,17**
 Przetoż to mówi Pan: Żona twoja w mieście nierząd płodzić będzie: a synowie twoi, i córki twoje od miecza polęgą: a ziemia twoja sznurem pomierzona będzie: a ty w ziem splugawionej umrzesz, a Izrael pojmany przeniesie się z ziemie swej.
