# Ez 3 BT5
###### **Ez 3,1**
 A On rzekł do mnie: «***Synu człowieczy, zjedz to, co masz przed sobą. Zjedz ten zwój i idź przemawiać do Izraelitów!***»
###### **Ez 3,2**
 Otworzyłem więc usta, a On dał mi zjeść ów zwój,
###### **Ez 3,3**
 mówiąc do mnie: «***Synu człowieczy, nasyć żołądek i napełnij wnętrzności swoje tym zwojem, który ci podałem***». Zjadłem go, a w ustach moich był słodki jak miód.
###### **Ez 3,4**
 Potem rzekł do mnie: «***Synu człowieczy, udaj się do domu Izraela i przemawiaj do nich moimi słowami.
###### **Ez 3,5**
 Jesteś bowiem posłany nie do ludu o mowie niezrozumiałej lub trudnym języku, ale do domu Izraela;
###### **Ez 3,6**
 nie do wielu narodów o niezrozumiałej mowie i o trudnym języku, których słów byś nie rozumiał. Chociaż gdybym cię do nich posłał, usłuchaliby ciebie.
###### **Ez 3,7**
 Jednakże dom Izraela nie zechce cię posłuchać, ponieważ i Mnie słuchać nie chce. Cały bowiem dom Izraela ma oporne czoło i zatwardziałe serce.
###### **Ez 3,8**
 Oto Ja uczyniłem twarz twoją oporną jak ich twarze i czoło twoje twardym jak ich czoła,
###### **Ez 3,9**
 dałem ci czoło jak diament, twardszy od krzemienia. Nie bój się ich, nie lękaj się ich oblicza, chociaż są ludem opornym***».
###### **Ez 3,10**
 Wreszcie powiedział mi: «***Synu człowieczy, weź sobie do serca wszystkie słowa, które wyrzekłem do ciebie, i przyjmij je do swoich uszu!
###### **Ez 3,11**
 Udasz się do zesłańców, do twoich rodaków i powiesz im: Tak mówi Pan Bóg, czy będą słuchać, czy też nie***».
###### **Ez 3,12**
 Wówczas podniósł mnie duch i usłyszałem za sobą odgłos ogromnego huku, gdy chwała Pańska unosiła się z miejsca, w którym przebywała.
###### **Ez 3,13**
 Ten ogromny huk – to szum uderzających o siebie skrzydeł Istot żyjących i odgłos kół obok nich.
###### **Ez 3,14**
 A duch podniósł mnie i zabrał. I poszedłem zgorzkniały, z podnieceniem w duszy, a mocna ręka Pańska spoczywała nade mną.
###### **Ez 3,15**
 Przybyłem do zesłańców, do Tell-Abib, osiedlonych nad rzeką Kebar, <tam gdzie oni mieszkali, < i w osłupieniu pozostawałem tam przez siedem dni wśród nich.
###### **Ez 3,16**
 A gdy upłynęło siedem dni, Pan skierował do mnie to słowo:
###### **Ez 3,17**
 «***Synu człowieczy, ustanowiłem cię stróżem nad pokoleniami izraelskimi. Gdy usłyszysz słowo z ust moich, upomnisz ich w moim imieniu.
###### **Ez 3,18**
 Jeśli powiem bezbożnemu: Z pewnością umrzesz, a ty go nie upomnisz, aby go odwieść od jego bezbożnej drogi i ocalić mu życie, to bezbożny ów umrze z powodu swego grzechu, natomiast Ja ciebie uczynię odpowiedzialnym za jego krew.
###### **Ez 3,19**
 Ale jeślibyś upomniał bezbożnego, a on by się nie odwrócił od swej bezbożności i od swej bezbożnej drogi, to chociaż on umrze z powodu swojego grzechu, ty jednak ocalisz samego siebie.
###### **Ez 3,20**
 Gdyby zaś sprawiedliwy odstąpił od swej prawości i dopuścił się grzechu, i gdybym zesłał na niego jakieś doświadczenie, to on umrze, bo go nie upomniałeś, z powodu jego grzechu; sprawiedliwości, którą czynił, nie będzie mu się pamiętać, ciebie jednak uczynię odpowiedzialnym za jego krew.
###### **Ez 3,21**
 Jeśli jednak upomnisz sprawiedliwego, by sprawiedliwy nie grzeszył, i jeśli nie popełni grzechu, to z pewnością pozostanie przy życiu, ponieważ przyjął upomnienie, ty zaś ocalisz samego siebie***».
###### **Ez 3,22**
 Spoczęła tam nade mną ręka Pana; a On rzekł do mnie: «***Wstań, idź na równinę, tam będę do ciebie mówił***».
###### **Ez 3,23**
 Wstałem więc i poszedłem na równinę, a oto była tam chwała Pańska, taka jak chwała, którą widziałem nad rzeką Kebar. I upadłem na twarz.
###### **Ez 3,24**
 Wstąpił jednak we mnie duch i postawił mnie na nogi. Rozmawiał On następnie ze mną i powiedział mi:«***Idź, zamknij się w swoim domu!
###### **Ez 3,25**
 Oto, synu człowieczy, włożone są na ciebie powrozy i związany jesteś nimi tak, że nie będziesz mógł udać się do nich.
###### **Ez 3,26**
  Ja sprawię, że język przylgnie ci do podniebienia i będziesz niemy. I nie będziesz dla nich mężem strofującym, są bowiem ludem buntowniczym.
###### **Ez 3,27**
 Gdy Ja będę mówił do ciebie, otworzę ci usta i powiesz im: Tak mówi Pan Bóg. Kto chce słuchać, niech słucha, a kto zaprzestanie, niech zaprzestanie – bo to lud oporny.
# Ez 3 PAU
###### **Ez 3,1**
 I powiedział do mnie: „Synu człowieczy, zjedz to, co widzisz przed sobą. Zjedz ten zwój i idź przemawiać do ludu izraelskiego”.
###### **Ez 3,2**
 Otworzyłem usta, a On dał mi zwój do zjedzenia.
###### **Ez 3,3**
 Powiedział też do mnie: „Synu człowieczy, nakarm swoje ciało i napełnij swoje wnętrzności tym zwojem, który ci daję”. Zjadłem go, a w moich ustach był słodki jak miód.
###### **Ez 3,4**
 Potem rzekł do mnie: „Synu człowieczy, idź do ludu izraelskiego. Mów do nich moimi słowami,
###### **Ez 3,5**
 bo jesteś posłany nie do ludu o niezrozumiałej mowie lub trudnym języku, lecz do ludu izraelskiego;
###### **Ez 3,6**
 nie do wielu narodów o niezrozumiałej mowie i trudnym języku, którego słów byś nie rozumiał - chociaż gdybym cię do nich posłał, usłuchaliby ciebie.
###### **Ez 3,7**
 Lud Izraela jednak nie będzie chciał cię słuchać, bo i Mnie nie chce słuchać. Cały lud izraelski jest bezczelny i uparty.
###### **Ez 3,8**
 Dlatego Ja czynię ciebie równie nieustępliwym i twardym jak oni.
###### **Ez 3,9**
 Będziesz twardy jak diament, bardziej nieugięty niż krzemień. Nie bój się ich i nie drżyj przed nimi, chociaż są narodem buntowniczym”.
###### **Ez 3,10**
 Powiedział jeszcze do mnie: „Synu człowieczy, weź sobie do serca wszystkie moje słowa, które kieruję do ciebie, i zapamiętaj je.
###### **Ez 3,11**
 Idź do uprowadzonych, do twoich rodaków, przemów do nich i powiedz im: Tak mówi PAN BÓG - czy będą słuchać, czy też nie”.
###### **Ez 3,12**
 Wtedy duch uniósł mnie i usłyszałem za sobą potężny huk: „Błogosławiona niech będzie chwała PANA na swoim miejscu”.
###### **Ez 3,13**
 A był to szum skrzydeł istot żywych, gdy uderzały jedno o drugie, a wraz z nimi odgłos kół i potężny łoskot.
###### **Ez 3,14**
 Duch uniósł mnie i porwał ze sobą. Szedłem posępny z duchem rozpalonym, a PAN mnie umacniał.
###### **Ez 3,15**
 Przyszedłem do uprowadzonych mieszkających w Tell-Abib nad rzeką Kebar. Tam osłupiały przebywałem wśród nich przez siedem dni.
###### **Ez 3,16**
 Po upływie siedmiu dni PAN powiedział do mnie:
###### **Ez 3,17**
 „Synu człowieczy, ustanawiam cię stróżem ludu izraelskiego. Ilekroć usłyszysz słowo z moich ust, ostrzeż ich w moim imieniu.
###### **Ez 3,18**
 Gdy powiem bezbożnemu: Na pewno umrzesz, a ty mu tego nie przekażesz, aby go odwieść od bezbożnego postępowania i aby dzięki temu mógł ocalić życie, to on umrze z własnej winy, ale ty odpowiesz za jego krew.
###### **Ez 3,19**
 Gdy jednak upomnisz bezbożnego, a on nie porzuci swoich bezbożnych uczynków i bezbożnego postępowania, umrze z własnej winy, ty natomiast zachowasz swoje życie.
###### **Ez 3,20**
 Jeśli człowiek prawy przestanie postępować w sposób prawy i dopuści się bezprawia, gdy zostanie przeze Mnie poddany próbie, wówczas umrze. Jeślibyś go nie upomniał, gdy trwał w swoim grzechu, umrze i nie będzie się pamiętać o jego prawych uczynkach, ale to ty odpowiesz za jego krew.
###### **Ez 3,21**
 Jeśli jednak upomnisz człowieka prawego, żeby nie grzeszył i on nie zgrzeszy, to na pewno będzie żył, ponieważ był upomniany, ty natomiast zachowasz swoje życie”.
###### **Ez 3,22**
 Potem spoczęła tam na mnie ręka PANA i powiedział do mnie: „Wstań, idź na równinę, tam będę mówił do ciebie”.
###### **Ez 3,23**
 Wstałem więc i wyszedłem na równinę. A oto była tam chwała PANA - taka, jaką widziałem nad rzeką Kebar. Upadłem na twarz.
###### **Ez 3,24**
 Wtedy wstąpił we mnie duch, postawił mnie na nogi i przemówił w ten sposób: „Idź, zamknij się w swoim domu.
###### **Ez 3,25**
 Synu człowieczy, oto nałożą tobie pęta, zwiążą cię nimi tak, że nie będziesz mógł wyjść do ludu.
###### **Ez 3,26**
 Sprawię, że język przylgnie ci do podniebienia. Staniesz się niemy i nie będziesz mógł ich upominać - są bowiem narodem buntowniczym.
###### **Ez 3,27**
 Gdy przemówię do ciebie, otworzę twoje usta i wtedy im powiesz: Tak mówi PAN BÓG. Kto chce słuchać, niech słucha, a kto nie chce, niech nie słucha - są bowiem narodem buntowniczym”.
# Ez 3 BP
###### **Ez 3,1**
 I rozkazał mi: Synu człowieczy, spożyj to, co masz przed sobą. Zjedz ten zwój i idź, przemawiaj do Domu Izraela.
###### **Ez 3,2**
 Otworzyłem więc me usta i sprawił, że spożyłem ten zwój.
###### **Ez 3,3**
 I powiedział mi: Synu człowieczy, nasyć się i napełnij twoje wnętrzności tym zwojem, który ci daję. Zjadłem go, a był w moich ustach słodki jak miód.
###### **Ez 3,4**
 Wtedy polecił mi: Synu człowieczy, idź, udaj się do Domu Izraela. Przemawiaj do nich moimi słowami,
###### **Ez 3,5**
 bo nie jesteś posłany do ludu o niezrozumiałej mowie lub trudnym języku, ale do Domu Izraela.
###### **Ez 3,6**
 Nie do licznych narodów o niezrozumiałej mowie i trudnym języku, których mowy nie słyszałeś - gdybym cię do nich posłał, oni by cię słuchali.
###### **Ez 3,7**
 Ale Dom Izraela nie zechce cię słuchać, bo mnie nie chcą słuchać, gdyż cały Dom Izraela twarde ma czoło i zawzięte serce.
###### **Ez 3,8**
 Oto uczyniłem twoje oblicze równie nieugięte jak ich oblicza, a twoje czoło tak twarde jak ich czoła.
###### **Ez 3,9**
 Uczyniłem twoje czoło jak diament, twardsze od krzemienia. Nie bój się ich, niech cię nie przeraża ich oblicze, bo są oni Domem buntowniczym.
###### **Ez 3,10**
 I powiedział mi: Synu człowieczy, weź sobie do serca i przyjmij w uszy swoje wszystkie moje słowa, które do ciebie kieruję.
###### **Ez 3,11**
 I idź, udaj się do wygnańców, do synów twego narodu, przemów do nich i powiedz im: Tak mówi Pan, Jahwe - czy będą słuchać, czy tego nie uczynią.
###### **Ez 3,12**
 Duch uniósł mię i usłyszałem za sobą huk potężnego trzęsienia [ziemi]. - Błogosławiona Chwała Jahwe [odeszła] z miejsca swego. -
###### **Ez 3,13**
 Był to łopot skrzydeł istot żywych, które uderzały jedno o drugie, wraz z nim turkot kół i odgłos potężnego trzęsienia [ziemi].
###### **Ez 3,14**
 Duch uniósł mię. Zabrał mię i szedłem pełen goryczy w podnieceniu ducha mojego, a ręka Jahwe mocno na mnie spoczywała.
###### **Ez 3,15**
 Przyszedłem do Tel Abib, do wygnańców mieszkających nad rzeką Kebar, i osiadłem tam, gdzie oni mieszkali. Przebywałem tam wśród nich przerażony przez siedem dni.
###### **Ez 3,16**
 Po upływie siedmiu dni przemówił do mnie Jahwe w te słowa:
###### **Ez 3,17**
 Synu człowieczy, ustanowiłem cię stróżem Domu Izraela. Skoro usłyszysz słowo z ust moich, masz obowiązek przestrzec ich w moim imieniu,
###### **Ez 3,18**
 Jeśli powiem grzesznikowi: "Na pewno umrzesz", a nie upomnisz go i nie przemówisz do niego, żeby go przestrzec co do jego bezbożnego postępowania, aby żył, grzesznik ten umrze w swej nieprawości, ale jego krwi będę dochodził na tobie.
###### **Ez 3,19**
 Jeżeli [jednak] tyś upomniał grzesznika, on zaś nie odwrócił się od swej niegodziwości i od swego bezbożnego postępowania, on umrze w swej nieprawości, a ty ocaliłeś swoje życie.
###### **Ez 3,20**
 Jeśli sprawiedliwy odwróci się od swej sprawiedliwości i popełni nieprawość, gdyż poddałem go próbie, on umrze. Jeślibyś go nie upomniał, [gdy trwał] w swoim grzechu, umrze i nie będzie się liczyć jego sprawiedliwości, którą pełnił, ale krwi jego będę dochodził na tobie.
###### **Ez 3,21**
 Jeżeli wszakże ty upomniałeś sprawiedliwego, aby nie grzeszył, i on nie zgrzeszył, na pewno będzie żył, ponieważ został napomniany, a ty ocaliłeś życie swoje.
###### **Ez 3,22**
 Ręka Jahwe spoczęła tam na mnie i rzekł do mnie: Wstań, wyjdź na równinę, tam chcę z tobą mówić.
###### **Ez 3,23**
 Wstałem więc i wyszedłem na równinę. A oto tam stała Chwała Jahwe, jak Chwała, którą widziałem nad rzeką Kebar. Upadłem tedy na twarz.
###### **Ez 3,24**
 I wstąpił we mnie duch, postawił mię na nogi, przemówił do mnie i rzekł mi: Idź, zamknij się w swym domu.
###### **Ez 3,25**
 Oto na ciebie, synu człowieczy, nałożą pęta i zwiążą cię nimi, i nie będziesz mógł wyjść do nich.
###### **Ez 3,26**
 Sprawię, że język twój przylgnie do podniebienia. Będziesz niemy i nie będziesz dla nich człowiekiem, który ostrzega, bo oni są Domem buntowniczym.
###### **Ez 3,27**
 A gdy przemówię do ciebie, wówczas otworzę twoje usta i oznajmisz im: "Tak mówi Pan, Jahwe". Kto będzie słuchał, niechaj słucha, a kto tego nie uczyni, niech nie czyni, bo oni są Domem buntowniczym.
# Ez 3 BR
###### **Ez 3,1**
 I powiedział do mnie: Synu człowieczy, zjedz to, co widzisz przed sobą. Spożyj ten zwój, a potem idź i mów do całego Domu Izraela!
###### **Ez 3,2**
 Otworzyłem więc usta, a On dał mi ten zwój do zjedzenia.
###### **Ez 3,3**
 I powiedział: Synu człowieczy, napełnij swój żołądek, niech całe twoje wnętrze wypełni się tym zwojem, który ci daję. Zjadłem więc ten zwój. A był w moich ustach słodki jak miód.
###### **Ez 3,4**
 Potem powiedział do mnie: Synu człowieczy, udaj się do Domu Izraela i powtórz wszystkie moje słowa!
###### **Ez 3,5**
 Jesteś posłany nie do narodu o języku obcym i niezrozumiałej mowie, ale do Domu Izraela.
###### **Ez 3,6**
 Nie pójdziesz do wielu narodów o językach obcych i niezrozumiałej mowie, ze słowami tobie nie znanymi. Gdybym cię do nich posłał, pewnie by cię wysłuchały.
###### **Ez 3,7**
 Ale nie usłucha cię Dom Izraela. Nie okażą dobrej woli, żeby Mnie słuchać. Wszyscy bowiem z Domu Izraela mają twarde czoła i zbuntowane serca.
###### **Ez 3,8**
 A Ja oblicze twoje uczynię tak twardym jak ich oblicza i czoło twoje tak twardym jak ich czoła.
###### **Ez 3,9**
 Uczynię twoje czoło twardym jak diament i twardszym niż kamień. Nie bój się więc ich, nie drżyj na ich widok, choć są oni ludem bardzo opornym.
###### **Ez 3,10**
 I powiedział im także: Synu człowieczy, weź sobie do serca to wszystko, co do ciebie mówię, zatrzymaj w swoich uszach!
###### **Ez 3,11**
 Udaj się do wygnańców, do synów twojego ludu, i czy zechcą cię słuchać, czy nie, powiedz im tak: Oto, co mówi Pan Bóg.
###### **Ez 3,12**
 Potem uniósł mnie duch, a ja posłyszałem za sobą szum i potężne grzmoty Chwały Pańskiej, unoszącej się z miejsca, na którym przebywała,
###### **Ez 3,13**
 a także szelest dotykających się nawzajem skrzydeł istot żywych i odgłosy kół toczących się obok. Wszystko razem słychać było jak potężne, gwałtowne grzmoty.
###### **Ez 3,14**
 Duch zaś, który mnie porwał do góry, zabrał mnie z tamtego miejsca. Odchodziłem pełen goryczy i z drżeniem serca, odczuwając na sobie bardzo ciężar ręki Pańskiej.
###### **Ez 3,15**
 I tak przybyłem do wygnańców, mieszkających w Tell-Abib nad rzeką Kebar. Zaskoczony tym wszystkim, co się stało, pozostawałem tam wśród nich przez siedem dni.
###### **Ez 3,16**
 Pod koniec owego czasu siedmiu dni Pan tak przemówił do mnie:
###### **Ez 3,17**
 synu człowieczy, czynię cię stróżem całego Domu Izraela. Ilekroć usłyszysz jakieś słowo z ust moich, musisz ich o tym powiadomić w moim imieniu.
###### **Ez 3,18**
 Jeżeli powiem jakiemuś złoczyńcy, że musi umrzeć, a ty nie powtórzysz mu tego, aby go skłonić do zejścia ze złej drogi, iżby mógł ocalić swoje życie, to złoczyńca ów będzie musiał umrzeć z powodu swoich występków, ale na ciebie spadnie wina za jego krew.
###### **Ez 3,19**
 Jeżeli jednak ostrzeżesz złoczyńcę, a on mimo to nie odwróci się od swoich występków i nie zejdzie ze złej drogi, to będzie on musiał umrzeć z powodu swoich występków, ale ty ocalisz swoje życie.
###### **Ez 3,20**
 Kiedy zaś jakiś sprawiedliwy przestanie żyć uczciwie i zacznie się dopuszczać występków, Ja sprowadzę na niego zgubę. Będzie musiał umrzeć właśnie dlatego, że ty go nie upomniałeś. Umrze z powodu swoich występków, a o jego dawnych dobrych uczynkach nikt już nie będzie pamiętał. Ale za jego krew ty będziesz musiał odpowiedzieć przede Mną.
###### **Ez 3,21**
 Jeżeli jednak ostrzeżesz sprawiedliwego, żeby nie schodził na drogę nieprawości, i on rzeczywiście powstrzyma się od grzechów, to ocaleje właśnie dlatego, że został upomniany, i ty również uratujesz swoje życie.
###### **Ez 3,22**
 Potem znów spoczęła na mnie ręka Pańska. Pan powiedział do mnie: Wstań i udaj się na równinę. Chcę ci tam coś powiedzieć!
###### **Ez 3,23**
 Powstałem więc i udałem się na równinę. I oto zobaczyłem tam Chwałę Bożą. Była taka jak ta, którą widziałem nad rzeką Kebar. I upadłem na twarz.
###### **Ez 3,24**
 Ale duch wstąpił we mnie i postawił mnie na nogi. Zaczął ze mną rozmawiać, wydając mi polecenie: Wejdź do swego domu i zamknij się od środka!
###### **Ez 3,25**
 Tam, synu człowieczy, zostaniesz skrępowany powrozami tak, że nie będziesz mógł udać się do ludu.
###### **Ez 3,26**
 Ja sam sprawię, że język przywrze ci do podniebienia. Stracisz mowę i nie będziesz mógł w moim imieniu udzielać napomnień, jest to bowiem lud bardzo oporny.
###### **Ez 3,27**
 A kiedy Ja znów do ciebie przemówię, otworzę twoje usta. Wtedy im powiesz: Tak oto mówi Pan Bóg: Kto chce słuchać, niech słucha, kto zaś nie chce, niech nie słucha. Jest to bowiem lud bardzo oporny.
# Ez 3 WUJ
###### **Ez 3,1**
 I rzekł do mnie: Synu człowieczy, cokolwiek najdziesz zjedz, zjedz te księgi, a szedszy mów do synów Izraelowych.
###### **Ez 3,2**
 I otworzyłem usta moje, i nakarmił mię onemi księgami:
###### **Ez 3,3**
 I rzekł do mnie: Synu człowieczy, brzuch twój jeść będzie, a trzewa twoje napełnią się temi księgami, które ja daję tobie, i zjadłem je, a były w uściech moich jako miód słodkie.
###### **Ez 3,4**
 I rzekł do mnie: Synu człowieczy, idź do domu Izraelowego, a będziesz mówił słowa moje do nich.
###### **Ez 3,5**
 Bo nie do ludu głębokiej mowy, a nie znajomego języka, posyłają cię: do domu Izraelskiego.
###### **Ez 3,6**
 Ani do narodów mnogich głębokiej mowy, i nieznajomego języka, których byś mów słyszeć nie mógł: i choćbyś do nich był posłany, oniby cię usłuchali.
###### **Ez 3,7**
 Lecz dom Izraelów nie chcą cię słuchać: iż mnie słuchać nie chcą: bo wszystek dom Izraelów jest przetartego czoła, i twardego serca.
###### **Ez 3,8**
 Otóż dałem twarz twoją duszą niż twarze ich, i czoło twoje twardsze niż czoła ich.
###### **Ez 3,9**
 Jako dyament i jako krzemień dałem twarz twoję: nie bój się ich, ani się lękaj twarzy ich: Bo dom drażniący jest.
###### **Ez 3,10**
 I rzekł do mnie: Synu człowieczy, wszystkie mowy moje, które ja mówię do ciebie, bierz do serca swego, a słuchaj uszyma swemi:
###### **Ez 3,11**
 A idź wnidź do zaprowadzenia, do synów lutwego, a rzeczesz do nich, i powiesz im: To mówi Pan Bóg: jeśli snać usłyszą, a przestaną.
###### **Ez 3,12**
 I wziął mię duch, i usłyszałem za sobą głos wzruszenia wielkiego: Błogosławiona chwała Pańska z miejsca jego,
###### **Ez 3,13**
 I głos skrzydeł zwierząt tłukących jedno o drugie, i głos kół idących za zwierzęty, i głos wzruszenia wielkiego.
###### **Ez 3,14**
 Duch też podniósł mię, i wziął mię: i poszedłem z gorzkością w rozgniewaniu ducha mego: bo ręka Pańska była ze mną posilając mię.
###### **Ez 3,15**
 I przyszedłem do zaprowadzenia, do stogu nowego zboża, do tych, którzy mieszkali nad rzeką Chobar, i siadłem, gdzie oni siedzieli: i mieszkałem tam siedm dni, smęcąc się w pośrodku ich.
###### **Ez 3,16**
 A gdy minęło siedm dni, stało się słowo Pańskie do mnie, mówiąc:
###### **Ez 3,17**
 Synu człowieczy, dałem cię stróżem domowi Izraelowemu: i będziesz słuchał z ust moich słowa, i powiesz im odemnie.
###### **Ez 3,18**
 Jeśli, gdy ja rzeknę niezbożnemu, śmiercią umrzesz: nie opowiesz mu, ani mu rzeczesz, aby się odwrócił od drogi swej niezbożnej, i żył: on niezbożny w niezbożności swej umrze: a krwie jego z ręki twej szukać będę.
###### **Ez 3,19**
 A jeśli ty opowiesz niezbożnemu, a on się nie nawróci od niezbożności swojej, i od drogi swej niezbożnej: on w nieprawości swej umrze, a ty wybawiłeś duszę swoję.
###### **Ez 3,20**
 Lecz i sprawiedliwy, jeśli się wróci od sprawiedliwości swej, a będzie czynił nieprawość: położę zawadę przed nim, onci umrze, żeś mu nie opowiedział, w grzechu swoim umrze, a nie będą w pamięci sprawiedliwości jego, które czynił: lecz krwie jego z ręki twej szukać będę.
###### **Ez 3,21**
 Ale jeśli ty opowiesz sprawiedliwemu, żeby nie grzeszył sprawiedliwy, a on nie będzie grzeszył: żywiąc żyć będzie, żeś mu powiedział, a tyś wyzwolił duszę swoję.
###### **Ez 3,22**
 I stała się nademną ręka Pańska, i rzekł do mnie:
###### **Ez 3,23**
 Wstawszy wynidź na pole, a oto tam stała chwała Pańska, jako chwała, którąm widział nad rzeką Chobar: i padłem na oblicze moje.
###### **Ez 3,24**
 I wstąpił w mię duch, i postawił mię na nogach moich: i mówił ze mną, i rzekł mi: Wnidź, a zamkni się w pośrodku domu twego.
###### **Ez 3,25**
 A ty synu człowieczy, oto dane są na cię powrozy, i zwiążą cię nimi: i nie wynidziesz z pośrodku ich.
###### **Ez 3,26**
 A uczynię, że język twój przylnie do podniebienia twego, i będziesz niemy, a nie jako mąż strofujący: bo dom drażniący jest.
###### **Ez 3,27**
 A gdy z tobą mówić będę, otworzę usta twoje, i rzeczesz do nich: To mówi Pan Bóg, kto słucha, niech słucha: a kto zaniechawa, niech zaniechawa: bo dom drażniący jest.
