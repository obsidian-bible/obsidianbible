# Hi 3 BT5
###### **Hi 3,1**
 Wreszcie Hiob otworzył usta i przeklinał swój dzień.
###### **Hi 3,2**
 Hiob zabrał głos i tak mówił:
###### **Hi 3,3**
 «***Niech przepadnie dzień mego urodzenia   
i noc, gdy powiedziano: "Poczęty został mężczyzna."***
###### **Hi 3,4**
 ***Niech dzień ten zamieni się w ciemność, niech nie dba o niego Bóg w górze. Niechaj nie świeci mu światło,***
###### **Hi 3,5**
 ***niechaj pochłoną go mrok i ciemności. Niechaj się chmurą zasępi, niech targnie się nań nawałnica.***
###### **Hi 3,6**
 ***Niech noc tę praciemność ogarnie, i niech do dni roku nie wejdzie ani do liczby miesięcy!***
###### **Hi 3,7**
  ***O, niech ta noc bezpłodną się stanie i niechaj nie zazna wesela!***
###### **Hi 3,8**
 ***Niech ją przeklną złorzeczący dniowi, którzy są zdolni obudzić Lewiatana.***
###### **Hi 3,9**
 ***Niech zgasną jej gwiazdy wieczorne, by próżno czekała jutrzenki i źrenic nowego dnia nie ujrzała;***
###### **Hi 3,10**
 ***bo nie zamknęła mi drzwi życia, by zasłonić przede mną mękę.***
###### **Hi 3,11**
 ***Dlaczego nie umarłem po wyjściu z łona, nie wyszedłem z wnętrzności, by skonać?***
###### **Hi 3,12**
 ***Po cóż mnie przyjęły kolana, a piersi podały mi pokarm?***
###### **Hi 3,13**
 ***Teraz bym spał, wypoczywał, odetchnąłbym w śnie pogrążony***
###### **Hi 3,14**
 ***z królami, ziemskimi władcami, co sobie stawiali grobowce,***
###### **Hi 3,15**
 ***wśród wodzów w złoto zasobnych, których domy pełne są srebra.***
###### **Hi 3,16**
 ***Nie żyłbym jak płód poroniony lub jak dziecię, co światła nie znało.***
###### **Hi 3,17**
 ***Tam niegodziwcy nie krzyczą, spokojni, zużyli już siły.***
###### **Hi 3,18**
 ***Tam wszyscy więźniowie bez lęku, nie słyszą już głosu strażnika;***
###### **Hi 3,19**
 ***tam razem i mały, i wielki, tam sługa jest wolny od pana.***
###### **Hi 3,20**
  ***Po co się daje życie strapionym, istnienie złamanym na duchu,***
###### **Hi 3,21**
 ***co śmierci czekają na próżno, szukają jej usilniej niż skarbu;***
###### **Hi 3,22**
 ***cieszą się, skaczą z radości, weselą się, że doszli do grobu.***
###### **Hi 3,23**
 ***Człowiek swej drogi jest nieświadomy, Bóg sam ją przed nim zamyka.***
###### **Hi 3,24**
 ***Płacz stał mi się pożywieniem, jęki moje płyną jak woda,***
###### **Hi 3,25**
 ***bo spotkało mnie, czegom się lękał, bałem się, a jednak to przyszło.***
###### **Hi 3,26**
 ***Nie znam spokoju ni ciszy, nim spocznę, już wrzawa przychodzi***».
# Hi 3 PAU
###### **Hi 3,1**
 Później Hiob otworzył usta i przeklinał dzień swoich narodzin.
###### **Hi 3,2**
 Hiob zaczął krzyczeć:
###### **Hi 3,3**
 „Niech przepadnie dzień, w którym się narodziłem, i noc, która oznajmiła: «Począł się chłopiec!».
###### **Hi 3,4**
 Niech ten dzień stanie się ciemnością, niech Bóg z wysokości nie troszczy się o niego i niech nie rozbłyśnie nad nim dzienne światło.
###### **Hi 3,5**
 Niech go pochłonie mrok i ciemność, niech go okryje gęsta chmura i niech go przerazi zaćmienie słońca.
###### **Hi 3,6**
 Niech tę noc wchłonie ciemność, niech nie znajdzie miejsca pomiędzy dniami roku i niech jej nie będzie w liczbie miesięcy.
###### **Hi 3,7**
 Niech się ta noc stanie bezpłodna i niech nie rozbrzmiewa okrzykami radości.
###### **Hi 3,8**
 Niech jej złorzeczą ci, którzy i dzień przeklinają i którzy usiłują poskromić Lewiatana.
###### **Hi 3,9**
 Niech się zaćmi jej wschodząca gwiazda, niech daremnie wyczekuje światła i niech nie ogląda promieni zorzy.
###### **Hi 3,10**
 Bo nie zamknęła przede mną bramy łona ani nie usunęła udręki sprzed moich oczu.
###### **Hi 3,11**
 Dlaczego nie umarłem przy narodzeniu i nie skonałem po wyjściu z łona matki?
###### **Hi 3,12**
 Czemu przyjęły mnie kolana i piersi podały pokarm?
###### **Hi 3,13**
 Teraz leżałbym spokojnie, spałbym i odpoczywał,
###### **Hi 3,14**
 razem z królami i ich doradcami, z tymi, którzy wznieśli sobie grobowce,
###### **Hi 3,15**
 albo z książętami, którzy gromadzą złoto i w domach mają pełno srebra.
###### **Hi 3,16**
 Albo czemu nie stałem się martwym płodem, jak niemowlęta, które nie widziały światła?
###### **Hi 3,17**
 Tam bezbożnicy są już niegroźni, odpoczywają pozbawieni siły.
###### **Hi 3,18**
 Tam są bezpieczni także więźniowie, nie muszą słuchać głosu strażnika.
###### **Hi 3,19**
 Tam wielki i mały są sobie równi i niewolnik jest wolny przy swoim panu.
###### **Hi 3,20**
 Po co dane jest światło nieszczęśliwym i życie zgorzkniałym na duszy?
###### **Hi 3,21**
 Z tęsknotą wypatrują oni śmierci, lecz nie nadchodzi, szukają jej gorliwiej niż ukrytych skarbów.
###### **Hi 3,22**
 Na pewno krzyczeliby z radości i bardzo by się cieszyli, że grób znaleźli.
###### **Hi 3,23**
 Dlaczego droga człowieka jest przed nim ukryta i Bóg zewsząd go osaczył?
###### **Hi 3,24**
 Bo łzy się stały moim chlebem, a mój jęk rozlewa się jak woda.
###### **Hi 3,25**
 Bo opanowało mnie przerażenie i spadło na mnie to, czego się bałem.
###### **Hi 3,26**
 Nie mam chwili spokoju ani wytchnienia, jeszcze nie ochłonąłem, a znów zjawia się udręka”.
# Hi 3 BP
###### **Hi 3,1**
 W końcu Job otworzył swe usta i przeklinał dzień swego narodzenia.
###### **Hi 3,2**
 Zabrał głos i przemówił:
###### **Hi 3,3**
 Niech zginie dzień, w którym się urodziłem, i noc, podczas której powiedziano: "Począł się człowiek".
###### **Hi 3,4**
 Niech ten dzień stanie się ciemnością, niech się o niego nie troszczy Bóg z wysokości i niechaj światłość nad nim nie świeci.
###### **Hi 3,5**
 Niech się o niego upomną noc i ciemności, niech go ogarnie gęsta chmura, niech go porazi szalejąca burza.
###### **Hi 3,6**
 Niech noc tę pochłonie ciemność, by jej nie liczono pośród dni roku ani by nie wchodziła w rachubę miesięcy.
###### **Hi 3,7**
 Niech ta noc pozostanie głucha, aby nie było w niej radosnych śpiewów.
###### **Hi 3,8**
 Niech ją przeklną ci, którzy dniom złorzeczą, ci, którzy poskramiają lewiatana.
###### **Hi 3,9**
 Niech jej gwiazdy zaćmią się o zmroku, by próżno czekała na ich światło, i niech nigdy nie ujrzy promieni jutrzenki,
###### **Hi 3,10**
 bo nie zamknęła przede mną łona ani nie usunęła udręki sprzed moich oczu.
###### **Hi 3,11**
 Czemu nie umarłem w łonie matki albo nie zginąłem, gdym wyszedł z jej łona?
###### **Hi 3,12**
 Czemu przyjęły mnie dwa kolana i dwie piersi, aby mnie wykarmić?
###### **Hi 3,13**
 Teraz leżałbym i trwałbym w spokoju, spałbym i odpoczywałbym sobie
###### **Hi 3,14**
 wraz z królami i wielkimi tej ziemi, z tymi, którzy wznosili dla siebie grobowce,
###### **Hi 3,15**
 albo z książętami, którzy mają pełno złota i srebrem napełniają swe domy.
###### **Hi 3,16**
 Albo czemuż nie byłem jak płód bez życia lub jak niemowlęta, które nie widziały światła.
###### **Hi 3,17**
 Tam bezbożni już się nie srożą i pozbawieni siły odpoczywają.
###### **Hi 3,18**
 Również i więźniowie trwają w spokoju, nie słyszą już krzyków dozorcy.
###### **Hi 3,19**
 Wielki i mały są tam sobie równi i niewolnik wolny od swojego pana.
###### **Hi 3,20**
 Po cóż dawać światło nieszczęśliwym i życie rozgoryczonym w sercu?
###### **Hi 3,21**
 Tym, którzy wzdychają do śmierci, lecz ona nie przychodzi, i gorliwiej jej szukają aniżeli skarbu?
###### **Hi 3,22**
 Cieszyliby się bez końca i radowali, gdyby grób znaleźli.
###### **Hi 3,23**
 Tak to zakryta jest droga przed człowiekiem, Bóg sam mu ją zamknął dookoła.
###### **Hi 3,24**
 Albowiem przed posiłkiem wzdycham, a skargi moje jak wody się rozlewają;
###### **Hi 3,25**
 spotkało mnie wszystko, czegom się obawiał i czegom się lękał - to mnie nawiedziło.
###### **Hi 3,26**
 Nie ma dla mnie spokoju ani ukojenia, jeszczem nie zdołał odetchnąć, a już nadeszło utrapienie.
# Hi 3 BR
###### **Hi 3,1**
 Potem otworzył Hiob usta i zaczął przeklinać dzień swego narodzenia.
###### **Hi 3,2**
 Przemówił Hiob w takie oto słowa:
###### **Hi 3,3**
 Obyż nigdy nie było dnia, w którym na świat przyszedłem, ani nocy, w czasie której oznajmiono, że człowiek został poczęty.
###### **Hi 3,4**
 Niech dzień ten zamieni się w ciemność i niech na niebie Bóg o nim zapomni, niech nie zaświeci nad nim nigdy dzienne światło!
###### **Hi 3,5**
 Niech zaginie w mrokach i ciemności, niech go pokryją obłoki, niech straszny będzie ów dzień wskutek nawałnicy.
###### **Hi 3,6**
 I noc owa niech zginie w ciemnościach, niech wypadnie spośród wszystkich dni roku i niech nie wejdzie do liczby miesięcy.
###### **Hi 3,7**
 Niech będzie ta noc bezpłodna, niech żadna nie rozbrzmiewa weselem.
###### **Hi 3,8**
 Niech i ją przeklną ci, co dniowi złorzeczą, ci, co potrafią zbudzić nawet Lewiatana.
###### **Hi 3,9**
 Niech znikną jej gwiazdy wieczorne, niech daremnie czeka na światło jutrzenki, niech nigdy nie ujrzy brzasku dnia nowego!
###### **Hi 3,10**
 Bo nie zamknęła łona mojej matki, a moim oczom nie oszczędziła widoku cierpienia.
###### **Hi 3,11**
 Dlaczego nie umarłem jeszcze w łonie matki, czemu nie zginąłem wychodząc z jej ciała?
###### **Hi 3,12**
 Dlaczego znalazłem się na jej kolanach, dlaczego karmiły mnie jej piersi?
###### **Hi 3,13**
 Leżałbym sobie teraz i odpoczywał, spał i zażywał spokoju,
###### **Hi 3,14**
 obok królów i możnych tej ziemi, którzy zbudowali sobie grobowce,
###### **Hi 3,15**
 albo obok książąt bogatych w złoto, którzy mają domy pełne srebra.
###### **Hi 3,16**
 Nie żyłbym - jak nie żyje płód poroniony lub dziecko, co nie widziało światła.
###### **Hi 3,17**
 Tam już nie podnoszą głosu niegodziwcy, przestali nareszcie, wyczerpawszy swe siły.
###### **Hi 3,18**
 Tam nie troszczą się już o nic więźniowie, nie napełnia ich lękiem głos strażników.
###### **Hi 3,19**
 Razem już pozostają wielcy i mali, a sługa uwolni się nareszcie od pana.
###### **Hi 3,20**
 Po cóż na światło dzienne wydawać strapionych, po co obdarzać życiem tych, co są pełni goryczy?
###### **Hi 3,21**
 Czekają na śmierć, która nie przychodzi, szukają jej bardziej niż ukrytych skarbów.
###### **Hi 3,22**
 Cieszy ich widok mogiły, a znalazłszy grób, czują się szczęśliwi.
###### **Hi 3,23**
 Bo po co nam światło na drodze zgubionej, zewsząd zamkniętej przez Boga samego?
###### **Hi 3,24**
 Nim do stołu zasiądę, ogarnia mnie smutek, jak strumień płyną moje narzekania.
###### **Hi 3,25**
 Spada na mnie wszystko, co mnie przeraża, przed czym uciekałem, to mnie spotykało.
###### **Hi 3,26**
 Nie miałem spokoju, ani odpoczynku, wciąż nowe udręki nie dają mi wytchnienia.
# Hi 3 WUJ
###### **Hi 3,1**
 Potem Job otworzył usta swe, i złorzeczył dniowi swemu,
###### **Hi 3,2**
 I mówił:
###### **Hi 3,3**
 Niech zginie dzień, któregom się urodził, i noc, w którą rzeczono: Począł się człowiek.
###### **Hi 3,4**
 Dzień on niech się obróci w ciemności, niech się o nim nie pyta Bóg z wysoka, i niech nie będzie oświecon światłością.
###### **Hi 3,5**
 Niech go zaćmią ciemności, i cień śmierci, niech go osiędzie mrok, a niech będzie ogarnion gorzkością.
###### **Hi 3,6**
 Noc onę ciemny wicher niech osiędzie, niech nie idzie w liczbę dni rocznych, i niech nie będzie policzona w miesiącach.
###### **Hi 3,7**
 Noc ona niech nie będzie opuściała, ani chwały godna:
###### **Hi 3,8**
 Niech jej złorzeczą, którzy złorzeczą dniowi, którzy są gotowi wzruszyć Lewiathan.
###### **Hi 3,9**
 Niech się zaćmią gwiazdy mrokiem jej: niechaj czeka światła a nie ogląda, ani weszcia wstawającej zorze:
###### **Hi 3,10**
 Iż nie zawarła drzwi żywota, który mię nosił, ani odjęła złego od oczu moich.
###### **Hi 3,11**
 Czemum w żywocie nie umarł, wyszedszy z żywota wnet nie zginął?
###### **Hi 3,12**
 Przecz przyjęty na kolana? Czemu karmiony piersiami?
###### **Hi 3,13**
 Teraz bowiem śpiąc milczałbym, i odpoczywałbym snem moim:
###### **Hi 3,14**
 Z królmi i radami ziemie, którzy sobie budują pustynie.
###### **Hi 3,15**
 Abo z książęty, którzy mają złoto, i napełniają domy swe srebrem.
###### **Hi 3,16**
 Abo jako martwy płód skryty, nie byłbych, abo którzy poczęci nie oglądali światłości.
###### **Hi 3,17**
 Tam niezbożnicy przestali od trwogi, i tam odpoczynęli spracowani siłą.
###### **Hi 3,18**
 I niegdy społem związani bez przykrości, nie usłyszeli głosu wycięgacza.
###### **Hi 3,19**
 Mały i wielki tam są, i niewolnik wolen od pana swego.
###### **Hi 3,20**
 Przecz nędznemu dana jest światłość, a żywot tym, którzy są w gorzkości dusze?
###### **Hi 3,21**
 Którzy czekają śmierci, a nie przychodzi: jako wykopywający skarb.
###### **Hi 3,22**
 I barzo się weselą, gdy najdą grób.
###### **Hi 3,23**
 Mężowi, którego droga skryta jest, i ogarnął go Bóg ciemnościami.
###### **Hi 3,24**
 Pierwej niźli jem, wzdycham: a jako wzbierające wody, tak ryczenie moje.
###### **Hi 3,25**
 Bo strach, któregom się lękał, przyszedł na mię, a czegom się obawiał, przydało się.
###### **Hi 3,26**
 Azam mimo się nie puszczał? zażem nie milczał? zażem nie był spokojny? a przyszło na mię zagniewanie.
