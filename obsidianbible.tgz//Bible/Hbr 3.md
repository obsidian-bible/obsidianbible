# Hbr 3 BT5
###### **Hbr 3,1**
 Dlatego, bracia święci, uczestnicy powołania niebieskiego, zwróćcie uwagę na Apostoła i Arcykapłana naszego wyznania, Jezusa,
###### **Hbr 3,2**
 bo On jest wierny Temu, który Go uczynił, tak jak i Mojżesz w całym Jego domu.
###### **Hbr 3,3**
 O tyle nawet większej czci godzien jest niż Mojżesz, o ile większą cześć niż dom odbiera jego budowniczy.
###### **Hbr 3,4**
 Każdy bowiem dom jest przez kogoś zbudowany, a Tym, który zbudował wszystko, jest Bóg.
###### **Hbr 3,5**
 I Mojżesz wprawdzie [był] wierny w całym Jego domu, ale jako sługa, na świadectwo tego, co miało być powiedziane;
###### **Hbr 3,6**
 Chrystus zaś, jako Syn, [jest] nad swoim domem. Jego domem my jesteśmy, jeśli ufność i chwalebną nadzieję aż do końca wytrwale zachowamy.
###### **Hbr 3,7**
 Dlatego, jak mówi Duch Święty:Dziś, jeśli głos Jego usłyszycie,
###### **Hbr 3,8**
 nie zatwardzajcie serc waszych jak podczas buntu, w dzień kuszenia na pustyni,
###### **Hbr 3,9**
 gdzie kusili Mnie ojcowie wasi, wystawiając na próbę, chociaż widzieli dzieła moje przez lat czterdzieści.
###### **Hbr 3,10**
 Rozgniewałem się przeto na to pokoleniei powiedziałem: Zawsze błądzą w sercu. Oni zaś nie poznali dróg moich,
###### **Hbr 3,11**
 toteż przysiągłem w swym gniewie:Nie wejdą do mego odpoczynku.
###### **Hbr 3,12**
 Baczcie, bracia, aby nie było w kimś z was przewrotnego serca niewiary, której skutkiem jest odstąpienie od Boga żywego,
###### **Hbr 3,13**
 lecz zachęcajcie się wzajemnie każdego dnia, póki trwa to, co zwie się dziś, aby ktoś z was nie uległ zatwardziałości przez oszustwo grzechu.
###### **Hbr 3,14**
 Jesteśmy bowiem współuczestnikami Chrystusa, jeśli pierwotną nadzieję do końca zachowamy silną.
###### **Hbr 3,15**
 W tym, co jest powiedziane:Dziś, jeśli głos Jego usłyszycie, nie zatwardzajcie serc waszych jak podczas buntu,
###### **Hbr 3,16**
 kim rzeczywiście są ci, którzy usłyszawszy, zbuntowali się? Czyż to nie ci wszyscy, którzy wyszli z Egiptu pod wodzą Mojżesza?
###### **Hbr 3,17**
 Na kogo to gniewał się przez lat czterdzieści? Czy nie na tych, którzy zgrzeszyli, a których trupy rozrzucił po pustyni?
###### **Hbr 3,18**
 Którym to zaś poprzysiągł, że nie wejdą do Jego odpoczynku, jeśli nie tym, którzy nie byli posłuszni?
###### **Hbr 3,19**
 Widzimy zatem, iż nie mogli wejść z powodu niedowiarstwa.
# Hbr 3 PAU
###### **Hbr 3,1**
 A zatem, bracia święci, których łączy to samo niebiańskie powołanie, wpatrujcie się w Jezusa, apostoła Bożego i najwyższego kapłana naszego wyznania.
###### **Hbr 3,2**
 U Tego, który Go ustanowił, jest On wiarygodny, tak jak Mojżesz, w całym Jego domu.
###### **Hbr 3,3**
 A należy Mu się nawet większa chwała niż Mojżeszowi, skoro budowniczy domu odbiera większą cześć niż zbudowany przez niego dom.
###### **Hbr 3,4**
 Każdy bowiem dom jest przez kogoś zbudowany, a budowniczym wszystkiego jest Bóg.
###### **Hbr 3,5**
 Wprawdzie i Mojżesz był wiarygodny w całym Jego domu, jako sługa, na świadectwo tego, co miało być powiedziane.
###### **Hbr 3,6**
 Ale Chrystus jako Syn jest nad całym Jego domem! Tym domem my jesteśmy, jeśli tylko zachowamy pełną ufność i chlubną nadzieję.
###### **Hbr 3,7**
 Toteż, jak mówi Duch Święty: Dzisiaj, jeśli głos Jego usłyszycie,
###### **Hbr 3,8**
 nie zatwardzajcie serc waszych jak w rozgoryczeniu, jak w dniu próby na pustyni,
###### **Hbr 3,9**
 gdy Mnie kusili wasi ojcowie, doświadczali Mnie, choć widzieli moje dzieła
###### **Hbr 3,10**
 przez czterdzieści lat. Dlatego budziło we Mnie odrazę to pokolenie i powiedziałem: Zawsze błądzą w sercu! Oto oni nie poznali dróg moich.
###### **Hbr 3,11**
 Toteż przysiągłem zagniewany, że nie wejdą do mego odpoczynku!
###### **Hbr 3,12**
 Uważajcie, bracia, aby żaden z was przez niewierność złego serca nie odstąpił od Boga żywego!
###### **Hbr 3,13**
 Natomiast zachęcajcie się wzajemnie każdego dnia, póki mówi się o tym dzisiaj, aby nikt z was nie był zatwardziały przez oszustwo grzechu.
###### **Hbr 3,14**
 Mamy bowiem udział w losie Chrystusa, jeśli zdecydowanie aż do końca zachowamy naszą pierwotną postawę,
###### **Hbr 3,15**
 zgodnie ze słowami: Dzisiaj, jeśli głos Jego usłyszycie, nie zatwardzajcie serc waszych jak w rozgoryczeniu.
###### **Hbr 3,16**
 Którzy to bowiem ze słuchających ulegli rozgoryczeniu? Czy nie ci, którzy dzięki Mojżeszowi wyszli z Egiptu?
###### **Hbr 3,17**
 A kto budził odrazę przez czterdzieści lat? Czy nie ci, którzy zgrzeszyli i których zwłoki legły na pustyni?
###### **Hbr 3,18**
 Komu wreszcie przysiągł, że nie wejdzie do Jego odpoczynku, jeśli nie tym, którzy okazali się nieposłuszni?
###### **Hbr 3,19**
 Widzimy więc, że nie mogli wejść z powodu niewiary.
# Hbr 3 BP
###### **Hbr 3,1**
 Przeto, święci bracia, uczestnicy niebieskiego powołania, rozważcie, że Jezus, apostoł i arcykapłan naszego wyznania,
###### **Hbr 3,2**
 wierny jest Temu, który Go ustanowił, jak "Mojżesz w całym Jego domu".
###### **Hbr 3,3**
 On przy tym godzien jest o tyle większej chwały niż Mojżesz, o ile większą czcią cieszy się budowniczy niż jego dom.
###### **Hbr 3,4**
 Każdy bowiem dom bywa przez kogoś zbudowany, a tym, który wszystko zbudował, jest Bóg.
###### **Hbr 3,5**
 I Mojżesz wprawdzie był wierny w całym Jego domu, zarządzając i przekazując to, co miało być głoszone,
###### **Hbr 3,6**
 ale Chrystus [wierny] był [mając władzę] nad Jego domem jako Syn. Tym domem zaś my jesteśmy, jeśli zachowamy niezłomną ufność i chlubną nadzieję.
###### **Hbr 3,7**
 Dlatego, jak powiada Duch Święty: "Dzisiaj, gdy usłyszycie głos Jego,
###### **Hbr 3,8**
 nie znieczulajcie serc waszych, jak w "Rozgoryczeniu" w dniu pokusy na pustyni,
###### **Hbr 3,9**
 gdzie prowokowali mnie ojcowie wasi, doświadczając mnie, a poznawali dzieła moje przez czterdzieści lat.
###### **Hbr 3,10**
 Przeto obrzydziłem sobie to pokolenie i rzekłem: Zawsze zwodzi ich serce. Oto oni nie poznali mych dróg.
###### **Hbr 3,11**
 Przeto przysiągłem w gniewie: Na pewno nie wejdą do mego odpoczynku!"
###### **Hbr 3,12**
 Uważajcie, bracia, żeby wśród was nie było jakiegoś zepsutego przez niewiarę serca, które by odeszło od Boga żywego,
###### **Hbr 3,13**
 ale zachęcajcie się co dzień wzajemnie, dopóki trwa owo "dzisiaj", ażeby ktoś z was zwiedziony przez grzech nie stał się nieczuły [na Boga].
###### **Hbr 3,14**
 Jesteśmy bowiem współtowarzyszami Chrystusa, jeśli tylko zachowamy aż do końca niewzruszoną nadzieję, jaką mieliśmy od początku.
###### **Hbr 3,15**
 Skoro powiedziano: "Dzisiaj, gdy usłyszycie głos Jego, nie znieczulajcie serc waszych jak w "Rozgoryczeniu"",[trzeba by zapytać],
###### **Hbr 3,16**
 którzy to, gdy usłyszeli, doznali rozgoryczenia? Czy nie wszyscy, którzy wyszli z Egiptu pod wodzą Mojżesza?
###### **Hbr 3,17**
 Kogo zaś "obrzydził sobie przez czterdzieści lat"? Czyż nie tych, co zgrzeszyli, których "zwłoki legły na pustyni"?
###### **Hbr 3,18**
 A komu "przysiągł, że nie wejdą do Jego odpoczynku", jeśli nie tym, którzy okazali się nieposłuszni?
###### **Hbr 3,19**
 Widzimy zatem, że nie mogli [tam] wejść z powodu niewiary.
# Hbr 3 BR
###### **Hbr 3,1**
 Dlatego, bracia, uświęceni [przez chrzest] i powołani przez Boga, przypatrujcie się Jezusowi, wysłannikowi Boga, arcykapłanowi wiary, którą wyznajemy.
###### **Hbr 3,2**
 Pozostał On bowiem wierny Bogu, który Go powołał na ten urząd, podobnie jak wiernym był kiedyś Mojżesz w całym [swoim posługiwaniu dla] Jego domu.
###### **Hbr 3,3**
 Nadto godzien jest Jezus czci tym większej niż Mojżesz, im większą cześć niż sam dom powinien odbierać budowniczy.
###### **Hbr 3,4**
 Każdy dom jest bowiem przez kogoś zbudowany. Otóż Bóg jest tym, który zbudował wszystko.
###### **Hbr 3,5**
 Mojżesz też okazał się wiernym w całym domu Jego; był sługą powołanym do świadczenia o tym wszystkim, co miał powiedzieć Bóg.
###### **Hbr 3,6**
 Natomiast Chrystus był wiernym, ale jako Syn, który ma pieczę nad całym swoim domem. Domem tym zaś my będziemy, jeśli tylko zachowamy ufną i chwalebną nadzieję tego wszystkiego, czego się spodziewamy.
###### **Hbr 3,7**
 Dlatego - jak mówi Duch Święty - Dziś, gdy usłyszycie głos Jego,
###### **Hbr 3,8**
 nie zamykajcie serc waszych, jak w chwilach waszego buntu przeciw Bogu, jak wtedy, kiedy byliście kuszeni na pustyni,
###### **Hbr 3,9**
 kiedy to kusili Mnie ojcowie wasi i wystawiali na próbę, chociaż przez lat czterdzieści oglądali moje dzieła.
###### **Hbr 3,10**
 Dlatego rozgniewałem się na to pokolenie i powiedziałem: Ludzie ci ciągle błądzą w swych myślach, nigdy nie poznali dróg moich.
###### **Hbr 3,11**
 Zapłonąłem tedy jeszcze większym gniewem i poprzysiągłem, że nigdy nie wejdą tam, gdzie mogliby odpocząć razem ze Mną.
###### **Hbr 3,12**
 Uważajcie, bracia, by wasze serca nie były wypełnione przewrotną niewiarą, która prowadzi do odstępstwa od Boga żywego.
###### **Hbr 3,13**
 Każdego dnia udzielajcie sobie napomnień jedni drugim, jak długo trwa dziś waszego życia, aby żaden z was nie dal się uwieść przez grzech i nie popadł w zatwardziałość serca.
###### **Hbr 3,14**
 Będziemy bowiem uczestniczyli w dobrach Chrystusa, jeśli wytrwamy do końca w tej samej, zawsze niezachwianej nadziei.
###### **Hbr 3,15**
 Oto bowiem, co mówi Pismo: Dziś, gdy usłyszycie głos Jego, nie zamykajcie serc waszych, jak w chwilach waszego buntu.
###### **Hbr 3,16**
 A kimże właściwie byli ci, którzy usłyszawszy głos Jego zbuntowali się? Czyż nie byli to ci wszyscy właśnie, których Mojżesz wyprowadził z Egiptu?
###### **Hbr 3,17**
 A na kogóż to gniewał się [Bóg] przez lat czterdzieści? Czyż nie na tych właśnie, którzy dopuścili się grzechu i wskutek tego ich martwe ciała zaległy pustynię?
###### **Hbr 3,18**
 Komuż to wreszcie oświadczył uroczyście przysięgając, że nie wejdą nigdy tam, gdzie mogliby odpocząć wspólnie z Nim, jeśli nie tym właśnie, którzy byli nieposłuszni?
###### **Hbr 3,19**
 Tak więc widzimy, że nie mogli wejść do owego odpocznienia z powodu swego niedowiarstwa.
# Hbr 3 WUJ
###### **Hbr 3,1**
 Ztąd bracia święci, uczestnicy wezwania niebieskiego, obaczcie Apostoła i nawyższego kapłana wyznania naszego Jezusa:
###### **Hbr 3,2**
 Który wiernym jest temu, który go uczynił, jako i Mojżesz we wszystkim domu jego.
###### **Hbr 3,3**
 Abowiem więtszej chwały ten godny jest miany niźli Mojżesz: im więtszą cześć ma niż dom, ten który ji zbudował.
###### **Hbr 3,4**
 Bo każdy dom bywa budowan od kogo: a który wszystko stworzył, Bóg jest.
###### **Hbr 3,5**
 A Mojżesz wprawdzie wiernym był we wszystkim domu jego jako sługa na świadectwo tego co miało być mówiono:
###### **Hbr 3,6**
 Ale Chrystus jako syn w domu swym: który dom my jesteśmy, jeśliże ufność i chwałę nadzieje aż do końca mocną zachowamy.
###### **Hbr 3,7**
 Przeto jako mówi Duch święty: Dziś jeślibyście głos jego usłyszeli,
###### **Hbr 3,8**
 Nie zatwardzajcież serc waszych jako w rozdrażnieniu wedle dnia kuszenia na puszczy,
###### **Hbr 3,9**
 Gdzie mię kusili ojcowie waszy: doświadczyli, i widzieli sprawy moje.
###### **Hbr 3,10**
 Przez czterdzieści lat. I dla tegoż gniewałem się na ten naród, i rzekłem: Zawsze błądzą, sercem. A oni nie poznali dróg moich.
###### **Hbr 3,11**
 Jakom przysiągł w gniewie moim, jeśli wnidą do odpoczynienia mojego.
###### **Hbr 3,12**
 Patrzcież bracia, iżby snadź nie było w którym z was serce złe, niedowiarstwa, ku odstąpieniu od Boga żywego:
###### **Hbr 3,13**
 (12b) ale napominajcie sami siebie na każdy dzień, póki się Dzisia nazywa: iżby który z was nie był zatwardzon oszukaniem grzechu.
###### **Hbr 3,14**
 Abowiem staliśmy się uczestnikami Chrystusowemi: Jeśli tylko początek istności jego aż do końca mocny zachowamy.
###### **Hbr 3,15**
 Póki bywa mówiono, Dziś jeślibyście głos jego usłyszeli, nie zatwardzajcie serc waszych jako w onem rozdraźnieniu.
###### **Hbr 3,16**
 (14b) Abowiem, niektórzy usłyszawszy rozdraźnili: ale nie wszyscy, którzy wyszli z Egiptu przez Mojżesza.
###### **Hbr 3,17**
 A na któreż się rozgniewał przez czterdzieści lat? Izali nie na te, którzy zgrzeszyli: których trupy poległy na puszczy?
###### **Hbr 3,18**
 A którymże przysiągł, iż nie mieli wniść do odpoczynienia jego: jedno tym, którzy niewierni byli?
###### **Hbr 3,19**
 I widzimy, że nie mogli wniść dla niedowiarstwa.
# Hbr 3 STERN
###### **Hbr 3,1**
 Dlatego, bracia, których Bóg sobie zastrzegł, którzy macie udział w wezwaniu z nieba, pomyślcie uważnie o Jeszui, w którym publicznie uznajemy Bożego wysłannika i kohena gadola.
###### **Hbr 3,2**
 Był On wierny Bogu, który Go wyznaczył, tak jak i "Mosze był wierny w całym domu Bożym".
###### **Hbr 3,3**
 Jeszua jednak zasługuje na cześć większą niż Mosze, tak jak budowniczy domu zasługuje na cześć większą niż ów dom.
###### **Hbr 3,4**
 Bo każdy dom został przez kogoś zbudowany, lecz tym, który zbudował wszystko, jest Bóg.
###### **Hbr 3,5**
 Poza tym Mosze był wierny w całym domu Bożym, jako sługa, dający świadectwo o tym, co Bóg miał wyjawić później.
###### **Hbr 3,6**
 Mesjasz jednak, jako Syn, był wierny nad domem Bożym. A tym Jego domem my jesteśmy, jeśli tylko mocno trwamy w odwadze i śmiałości płynących z tego, na co mamy nadzieję.
###### **Hbr 3,7**
 Dlatego, jak mówi Ruach Ha-Kodesz: "Dzisiaj, jeśli usłyszycie głos Boży,
###### **Hbr 3,8**
 nie zatwardzajcie swoich serc, jak to uczyniliście w Gorzkiej Kłótni owego dnia na Pustyni, kiedyście wystawiali Boga na próbę.
###### **Hbr 3,9**
 Zaiste, ojcowie wasi na próbę mnie wystawiali, kusili mnie, a przez czterdzieści lat oglądali moje dzieło!
###### **Hbr 3,10**
 Dlategom sobie obrzydził owo pokolenie -Rzekłem: "Serca ich zawsze błądzą, nie pojęli, jak postępuję";
###### **Hbr 3,11**
 w gniewie poprzysiągłem, że nie wejdą do odpoczynku mego".
###### **Hbr 3,12**
 Uważajcie, bracia, żeby nie było w kimś z was nikczemnego serca, któremu brak ufności, co mogłoby was doprowadzić do odstąpienia od żywego Boga!
###### **Hbr 3,13**
 Za to wytrwale napominajcie jeden drugiego co dnia, dopóki jeszcze zwie się on Dzisiaj, aby żaden z was nie stał się zatwardziały wskutek podstępności grzechu.
###### **Hbr 3,14**
 Bo staliśmy się uczestnikami Mesjasza, pod warunkiem jednak, że będziemy mocno trzymać się tego przekonania, od którego wyszliśmy, i to aż do chwili osiągnięcia celu.
###### **Hbr 3,15**
 Co zaś do słów: "Dzisiaj, jeśli usłyszycie głos Boży, nie zatwardzajcie swoich serc, jak to uczyniliście w Gorzkiej Kłótni",
###### **Hbr 3,16**
 to kim byli ludzie, którzy gdy usłyszeli, kłócili się tak gorzko? To ci wszyscy, których Mosze wyprowadził z Egiptu.
###### **Hbr 3,17**
 A kogo sobie Bóg obrzydził przez czterdzieści lat? Tych, którzy zgrzeszyli - i oto padli na Pustyni!
###### **Hbr 3,18**
 A komu to poprzysiągł, że nie wejdą do odpoczynku Jego? Tym, którzy byli nieposłuszni.
###### **Hbr 3,19**
 Widzimy zatem, że nie byli w stanie wejść z powodu braku ufności.
# Hbr 3 TRO
###### **Hbr 3,1**
 **οθεν** *hothen* Skąd [[G3606]] [[ADV]] **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **αγιοι** *hagioi* święci [[G40]] WTA-VPM **κλησεως** *klēseōs* powołania [[G2821]] [[N-GSF]] **επουρανιου** *epouraniou* niebiańskiego [[G2032]] WTA-GSF **μετοχοι** *metochoi* uczestnicy – towarzysze [[G3353]] WTA-NPM **κατανοησατε** *katanoēsate* przyjrzyjcie się – dostrzeżcie [[G2657]] WTV-AAM-2P **τον** *ton* (tego) [[G3588]] [[T-ASM]] **αποστολον** *apostolon* Wysłannika – Posłańca [[G652]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **αρχιερεα** *archierea* Arcykapłana [[G749]] [[N-ASM]] **της** *tēs* [[G3588]] [[T-GSF]] **ομολογιας** *homologias* wyznania – przyznania [[G3671]] [[N-GSF]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **χριστον** *christon* Pomazańca [[G5547]] [[N-ASM]] **ιησουν** *iēsoun* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-ASM]]
###### **Hbr 3,2**
 **πιστον** *piston* wierny – godny wiary [[G4103]] WTA-ASM **οντα** *onta* będący [[G5607]] WTV-PXP-ASM **τω** *tō* [[G3588]] WTT-DSM **ποιησαντι** *poiēsanti* który uczynił [[G4160]] WTV-AAP-DSM **αυτον** *auton* Go [[G846]] WTP-ASM **ως** *hōs* jak [[G5613]] [[ADV]] **και** *kai* i [[G2532]] [[CONJ]] **μωσης** *mōsēs* Mojżesz – [wyciągnąć] [[G3475]] [[N-NSM]] **εν** *en* w [[G1722]] [[PREP]] **ολω** *holō* całym [[G3650]] WTA-DSM **τω** *tō* [[G3588]] WTT-DSM **οικω** *oikō* domu [[G3624]] WTN-DSM **αυτου** *autou* Jego [[G846]] [[P-GSM]]
###### **Hbr 3,3**
 **πλειονος** *pleionos* Większej [[G4119]] WTA-GSF-C **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **δοξης** *doksēs* chwały [[G1391]] [[N-GSF]] **ουτος** *houtos* Ten [[G3778]] WTD-NSM **παρα** *para* od [[G3844]] [[PREP]] **μωσην** *mōsēn* Mojżesza – [wyciągnąć] [[G3475]] [[N-ASM]] **ηξιωται** *ēksiōtai* jest uznany za godnego [[G515]] WTV-RPI-3S **καθ** *kath* na [[G2596]] [[PREP]] **οσον** *hoson* ile [[G3745]] WTK-ASN **πλειονα** *pleiona* większy [[G4119]] WTA-ASF-C **τιμην** *timēn* szacunek – zaszczyt [[G5092]] WTN-ASF **εχει** *echei* ma [[G2192]] WTV-PAI-3S **του** *tou* (od) [[G3588]] WTT-GSM **οικου** *oikou* domu [[G3624]] [[N-GSM]] **ο** *ho* (ten) [[G3588]] [[T-NSM]] **κατασκευασας** *kataskeuasas* który zbudował [[G2680]] WTV-AAP-NSM **αυτον** *auton* go [[G846]] WTP-ASM
###### **Hbr 3,4**
 **πας** *pas* Każdy [[G3956]] [[A-NSM]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **οικος** *oikos* dom [[G3624]] [[N-NSM]] **κατασκευαζεται** *kataskeuazetai* jest budowany [[G2680]] WTV-PPI-3S **υπο** *hypo* przez [[G5259]] [[PREP]] **τινος** *tinos* kogoś [[G5100]] WTX-GSM **ο** *ho* (Tym) [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **παντα** *panta* wszystkie [[G3956]] WTA-APN **κατασκευασας** *kataskeuasas* który zbudował [[G2680]] WTV-AAP-NSM **θεος** *theos* Bóg [[G2316]] [[N-NSM]]
###### **Hbr 3,5**
 **και** *kai* I [[G2532]] [[CONJ]] **μωσης** *mōsēs* Mojżesz – [wyciągnąć] [[G3475]] [[N-NSM]] **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **πιστος** *pistos* wierny [[G4103]] [[A-NSM]] **εν** *en* w [[G1722]] [[PREP]] **ολω** *holō* całym [[G3650]] WTA-DSM **τω** *tō* [[G3588]] WTT-DSM **οικω** *oikō* domu [[G3624]] WTN-DSM **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ως** *hōs* jak [[G5613]] [[ADV]] **θεραπων** *therapōn* sługa – obsługujący [[G2324]] [[N-NSM]] **εις** *eis* do [[G1519]] [[PREP]] **μαρτυριον** *martyrion* świadectwa [[G3142]] WTN-ASN **των** *tōn* (o tym) [[G3588]] WTT-GPN **λαληθησομενων** *lalēthēsomenōn* co miało zostać powiedziane [[G2980]] WTV-FPP-GPN
###### **Hbr 3,6**
 **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **ως** *hōs* jak [[G5613]] [[ADV]] **υιος** *hyios* Syn [[G5207]] [[N-NSM]] **επι** *epi* nad – w [[G1909]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **οικον** *oikon* domem [[G3624]] [[N-ASM]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ου** *hou* którego [[G3739]] WTR-GSM **οικος** *oikos* dom [[G3624]] [[N-NSM]] **εσμεν** *esmen* jesteśmy [[G2070]] WTV-PXI-1P **ημεις** *hēmeis* my [[G2249]] WTP-1NP **εανπερ** *eanper* jeśli [[G1437]] WTCOND **την** *tēn* [[G3588]] WTT-ASF **παρρησιαν** *parrēsian* śmiałość [[G3954]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-ASN **καυχημα** *kauchēma* chlubę [[G2745]] WTN-ASN **της** *tēs* [[G3588]] [[T-GSF]] **ελπιδος** *elpidos* nadziei [[G1680]] [[N-GSF]] **μεχρι** *mechri* aż do [[G3360]] [[ADV]] **τελους** *telous* końca [[G5056]] [[N-GSN]] **βεβαιαν** *bebaian* mocną [[G949]] WTA-ASF **κατασχωμεν** *kataschōmen* zatrzymalibyśmy – zachowalibyśmy [[G2722]] WTV-2AAS-1P
###### **Hbr 3,7**
 **διο** *dio* Dlatego [[G1352]] [[CONJ]] **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **το** *to* [[G3588]] WTT-NSN **πνευμα** *pneuma* Duch [[G4151]] WTN-NSN **το** *to* [[G3588]] WTT-NSN **αγιον** *hagion* Święty [[G40]] WTA-NSN **σημερον** *sēmeron* dzisiaj [[G4594]] [[ADV]] **εαν** *ean* jeśli [[G1437]] WTCOND **της** *tēs* [[G3588]] [[T-GSF]] **φωνης** *fōnēs* głos [[G5456]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ακουσητε** *akousēte* usłyszelibyście [[G191]] WTV-AAS-2P
###### **Hbr 3,8**
 **μη** *mē* nie [[G3361]] [[PRT-N]] **σκληρυνητε** *sklērynēte* zatwardzalibyście – czynilibyście twardym [[G4645]] WTV-PAS-2P **τας** *tas* [[G3588]] WTT-APF **καρδιας** *kardias* serc [[G2588]] WTN-APF **υμων** *hymōn* waszych [[G5216]] WTP-2GP **ως** *hōs* jak [[G5613]] [[ADV]] **εν** *en* podczas [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **παραπικρασμω** *parapikrasmō* buntu – rozdrażnienia [[G3894]] WTN-DSM **κατα** *kata* w [[G2596]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **ημεραν** *hēmeran* dniu [[G2250]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **πειρασμου** *peirasmou* próby – doświadczenia [[G3986]] [[N-GSM]] **εν** *en* na [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **ερημω** *erēmō* pustkowiu [[G2048]] WTA-DSF
###### **Hbr 3,9**
 **ου** *hou* gdzie [[G3757]] [[ADV]] **επειρασαν** *epeirasan* wystawiali na próbę [[G3985]] WTV-AAI-3P **με** *me* Mnie [[G3165]] WTP-1AS **οι** *hoi* [[G3588]] WTT-NPM **πατερες** *pateres* ojcowie [[G3962]] WTN-NPM **υμων** *hymōn* wasi [[G5216]] WTP-2GP **εδοκιμασαν** *edokimasan* wystawiali na próbę – doświadczali [[G1381]] WTV-AAI-3P **με** *me* Mnie [[G3165]] WTP-1AS **και** *kai* i [[G2532]] [[CONJ]] **ειδον** *eidon* zobaczyli [[G1492]] WTV-2AAI-3P **τα** *ta* [[G3588]] WTT-APN **εργα** *erga* dzieła [[G2041]] WTN-APN **μου** *mou* moje [[G3450]] WTP-1GS **τεσσαρακοντα** *tessarakonta* (przez) czterdzieści [[G5062]] WTA-NUI **ετη** *etē* lat [[G2094]] WTN-APN
###### **Hbr 3,10**
 **διο** *dio* Dlatego [[G1352]] [[CONJ]] **προσωχθισα** *prosōchthisa* byłem zagniewany [[G4360]] WTV-AAI-1S **τη** *tē* (ku) [[G3588]] WTT-DSF **γενεα** *genea* pokoleniu [[G1074]] [[N-DSF]] **εκεινη** *ekeinē* temu [[G1565]] WTD-DSF **και** *kai* i [[G2532]] [[CONJ]] **ειπον** *eipon* powiedziałem [[G2036]] WTV-2AAI-1S **αει** *aei* zawsze [[G104]] [[ADV]] **πλανωνται** *planōntai* są wprowadzani w błąd – dają się zwieść [[G4105]] WTV-PPI-3P **τη** *tē* (w) [[G3588]] WTT-DSF **καρδια** *kardia* sercu [[G2588]] [[N-DSF]] **αυτοι** *autoi* oni [[G846]] WTP-NPM **δε** *de* zaś [[G1161]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εγνωσαν** *egnōsan* poznali [[G1097]] WTV-2AAI-3P **τας** *tas* [[G3588]] WTT-APF **οδους** *hodous* dróg [[G3598]] WTN-APF **μου** *mou* moich [[G3450]] WTP-1GS
###### **Hbr 3,11**
 **ως** *hōs* Jak [[G5613]] [[ADV]] **ωμοσα** *ōmosa* przysiągłem [[G3660]] WTV-AAI-1S **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **οργη** *orgē* gniewie [[G3709]] [[N-DSF]] **μου** *mou* moim [[G3450]] WTP-1GS **ει** *ei* jeśli [[G1487]] WTCOND **εισελευσονται** *eiseleusontai* wejdą [[G1525]] WTV-FDI-3P **εις** *eis* do [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **καταπαυσιν** *katapausin* odpoczynku – odpocznienia [[G2663]] WTN-ASF **μου** *mou* mojego [[G3450]] WTP-1GS
###### **Hbr 3,12**
 **βλεπετε** *blepete* Uważajcie – Patrzcie [[G991]] WTV-PAM-2P **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **μηποτε** *mēpote* by czasem nie [[G3379]] [[ADV]] **εσται** *estai* będzie [[G2071]] WTV-FXI-3S **εν** *en* w [[G1722]] [[PREP]] **τινι** *tini* kimś [[G5100]] WTX-DSM **υμων** *hymōn* (z) was [[G5216]] WTP-2GP **καρδια** *kardia* serce [[G2588]] [[N-NSF]] **πονηρα** *ponēra* niegodziwe – złe [[G4190]] WTA-NSF **απιστιας** *apistias* niewiary – niewiernego [[G570]] [[N-GSF]] **εν** *en* ku [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **αποστηναι** *apostēnai* odstąpić – odejść [[G868]] [[V-2AAN]] **απο** *apo* od [[G575]] [[PREP]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ζωντος** *zōntos* żyjącego [[G2198]] WTV-PAP-GSM
###### **Hbr 3,13**
 **αλλα** *alla* ale [[G235]] [[CONJ]] **παρακαλειτε** *parakaleite* zachęcajcie [[G3870]] WTV-PAM-2P **εαυτους** *heautous* siebie samych [[G1438]] WTF-3APM **καθ** *kath* w [[G2596]] [[PREP]] **εκαστην** *hekastēn* każdym [[G1538]] WTA-ASF **ημεραν** *hēmeran* dniu [[G2250]] WTN-ASF **αχρις** *achris* aż do [[G891]] [[PREP]] **ου** *hou* kiedy [[G3739]] WTR-GSM **το** *to* [[G3588]] WTT-ASN **σημερον** *sēmeron* dzisiaj [[G4594]] [[ADV]] **καλειται** *kaleitai* jest nazywane – jest zwane [[G2564]] WTV-PPI-3S **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **σκληρυνθη** *sklērynthē* dałby uczynić twardym [[G4645]] WTV-APS-3S **τις** *tis* ktoś [[G5100]] WTX-NSM **εξ** *eks* z [[G1537]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **απατη** *apatē* oszustwa – zwiedzenia [[G539]] [[N-DSF]] **της** *tēs* [[G3588]] [[T-GSF]] **αμαρτιας** *hamartias* grzechu [[G266]] [[N-GSF]]
###### **Hbr 3,14**
 **μετοχοι** *metochoi* uczestnicy – towarzysze [[G3353]] WTA-NPM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **γεγοναμεν** *gegonamen* staliśmy się [[G1096]] WTV-2RAI-1P **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **εανπερ** *eanper* jeśli [[G1437]] WTCOND **την** *tēn* [[G3588]] WTT-ASF **αρχην** *archēn* początek [[G746]] WTN-ASF **της** *tēs* [[G3588]] [[T-GSF]] **υποστασεως** *hypostaseōs* zrozumienia – założenia [[G5287]] [[N-GSF]] **μεχρι** *mechri* aż do [[G3360]] [[ADV]] **τελους** *telous* końca [[G5056]] [[N-GSN]] **βεβαιαν** *bebaian* mocny [[G949]] WTA-ASF **κατασχωμεν** *kataschōmen* zatrzymalibyśmy – zachowalibyśmy [[G2722]] WTV-2AAS-1P
###### **Hbr 3,15**
 **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **λεγεσθαι** *legesthai* być mówionym [[G3004]] WTV-PPN **σημερον** *sēmeron* dzisiaj [[G4594]] [[ADV]] **εαν** *ean* jeśli [[G1437]] WTCOND **της** *tēs* [[G3588]] [[T-GSF]] **φωνης** *fōnēs* głos [[G5456]] [[N-GSF]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ακουσητε** *akousēte* usłyszelibyście [[G191]] WTV-AAS-2P **μη** *mē* nie [[G3361]] [[PRT-N]] **σκληρυνητε** *sklērynēte* zatwardzalibyście – czynilibyście twardym [[G4645]] WTV-PAS-2P **τας** *tas* [[G3588]] WTT-APF **καρδιας** *kardias* serc [[G2588]] WTN-APF **υμων** *hymōn* waszych [[G5216]] WTP-2GP **ως** *hōs* jak [[G5613]] [[ADV]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **παραπικρασμω** *parapikrasmō* buncie – rozdrażnieniu [[G3894]] WTN-DSM
###### **Hbr 3,16**
 **τινες** *tines* którzy [[G5100]] WTX-NPM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ακουσαντες** *akousantes* usłyszawszy [[G191]] WTV-AAP-NPM **παρεπικραναν** *parepikranan* zbuntowali się – rozdrażnili się [[G3893]] WTV-AAI-3P **αλλ** *all* ale [[G235]] [[CONJ]] **ου** *ou* (czy) nie [[G3756]] [[PRT-N]] **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **οι** *hoi* [[G3588]] WTT-NPM **εξελθοντες** *ekselthontes* którzy wyszli [[G1831]] WTV-2AAP-NPM **εξ** *eks* z [[G1537]] [[PREP]] **αιγυπτου** *aigyptou* Egiptu – [lud Nilu] [[G125]] [[N-GSF]] **δια** *dia* przez [[G1223]] [[PREP]] **μωσεως** *mōseōs* Mojżesza – [wyciągnąć] [[G3475]] [[N-GSM]]
###### **Hbr 3,17**
 **τισιν** *tisin* Komu [[G5101]] WTI-DPM **δε** *de* zaś [[G1161]] [[CONJ]] **προσωχθισεν** *prosōchthisen* okazywał gniew [[G4360]] [[V-AAI-3S]] **τεσσαρακοντα** *tessarakonta* (przez) czterdzieści [[G5062]] WTA-NUI **ετη** *etē* lat [[G2094]] WTN-APN **ουχι** *ouchi* czyż nie [[G3780]] WTPRT-I **τοις** *tois* (na tych) [[G3588]] WTT-DPM **αμαρτησασιν** *hamartēsasin* którzy zgrzeszyli [[G264]] WTV-AAP-DPM **ων** *hōn* których [[G3739]] WTR-GPM **τα** *ta* [[G3588]] WTT-NPN **κωλα** *kōla* zwłoki – trupy [[G2966]] WTN-NPN **επεσεν** *epesen* padły [[G4098]] WTV-2AAI-3S **εν** *en* na [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **ερημω** *erēmō* pustkowiu [[G2048]] WTA-DSF
###### **Hbr 3,18**
 **τισιν** *tisin* Komu [[G5101]] WTI-DPM **δε** *de* zaś [[G1161]] [[CONJ]] **ωμοσεν** *ōmosen* przysiągł [[G3660]] [[V-AAI-3S]] **μη** *mē* nie [[G3361]] [[PRT-N]] **εισελευσεσθαι** *eiseleusesthai* wejść [[G1525]] WTV-FDN **εις** *eis* do [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **καταπαυσιν** *katapausin* odpoczynku – odpocznienia [[G2663]] WTN-ASF **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ει** *ei* jeśli [[G1487]] WTCOND **μη** *mē* nie [[G3361]] [[PRT-N]] **τοις** *tois* (tym) [[G3588]] WTT-DPM **απειθησασιν** *apeithēsasin* którzy byli nieposłuszni – którzy nie ulegli [[G544]] WTV-AAP-DPM
###### **Hbr 3,19**
 **και** *kai* i [[G2532]] [[CONJ]] **βλεπομεν** *blepomen* widzimy [[G991]] WTV-PAI-1P **οτι** *hoti* że [[G3754]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **ηδυνηθησαν** *ēdynēthēsan* mogli [[G1410]] WTV-AOI-3P-ATT **εισελθειν** *eiselthein* wejść [[G1525]] [[V-2AAN]] **δι** *di* z powodu [[G1223]] [[PREP]] **απιστιαν** *apistian* niewiary – niedowiarstwa [[G570]] WTN-ASF
