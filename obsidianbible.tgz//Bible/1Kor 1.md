# 1Kor 1 BT5
###### **1Kor 1,1**
 Paweł, z woli Bożej powołany na apostoła Jezusa Chrystusa, i Sostenes, brat,
###### **1Kor 1,2**
 do Kościoła Bożego w Koryncie, do tych, którzy zostali uświęceni w Jezusie Chrystusie i powołani do świętości wespół ze wszystkimi, co na każdym miejscu wzywają imienia Pana naszego, Jezusa Chrystusa, ich i naszego [Pana].
###### **1Kor 1,3**
 Łaska wam i pokój od Boga Ojca naszego i Pana Jezusa Chrystusa!
###### **1Kor 1,4**
 Bogu mojemu dziękuję wciąż za was, za łaskę daną wam w Chrystusie Jezusie.
###### **1Kor 1,5**
 W Nim to bowiem zostaliście wzbogaceni we wszystko: we wszelkie słowo i wszelkie poznanie,
###### **1Kor 1,6**
 bo świadectwo Chrystusowe utrwaliło się w was.
###### **1Kor 1,7**
 Nie doznajecie tedy braku żadnej łaski, oczekując objawienia się Pana naszego, Jezusa Chrystusa.
###### **1Kor 1,8**
 On też będzie umacniał was aż do końca, abyście byli bez zarzutu w dzień Pana naszego, Jezusa Chrystusa.
###### **1Kor 1,9**
 Wierny jest Bóg, który powołał was do współuczestnictwa z Synem swoim, Jezusem Chrystusem, Panem naszym.
###### **1Kor 1,10**
 Przeto upominam was, bracia, w imię Pana naszego, Jezusa Chrystusa, abyście żyli w zgodzie i by nie było wśród was rozłamów; abyście byli jednego ducha i jednej myśli.
###### **1Kor 1,11**
 Doniesiono mi bowiem o was, bracia moi, przez ludzi Chloe, że zdarzają się między wami spory.
###### **1Kor 1,12**
 Myślę o tym, co każdy z was mówi: «***Ja jestem od Pawła, a ja od Apollosa; ja jestem Kefasa, a ja Chrystusa***».
###### **1Kor 1,13**
 Czyż Chrystus jest podzielony? Czyż Paweł został za was ukrzyżowany? Czyż w imię Pawła zostaliście ochrzczeni?
###### **1Kor 1,14**
 Dziękuję Bogu, że prócz Kryspusa i Gajusa nikogo z was nie ochrzciłem.
###### **1Kor 1,15**
 Nikt przeto nie może powiedzieć, że w imię moje został ochrzczony.
###### **1Kor 1,16**
 Zresztą, prawda, ochrzciłem dom Stefanasa. Poza tym nie wiem, czy ochrzciłem jeszcze kogoś.
###### **1Kor 1,17**
 Nie posłał mnie Chrystus, abym chrzcił, lecz abym głosił Ewangelię, i to nie w mądrości słowa, by nie zniweczyć Chrystusowego krzyża.
###### **1Kor 1,18**
 Nauka bowiem krzyża głupstwem jest dla tych, co idą na zatracenie, mocą Bożą zaś dla nas, którzy dostępujemy zbawienia.
###### **1Kor 1,19**
 Napisane jest bowiem: Wytracę mądrość mędrców, a przebiegłość przebiegłych zniweczę.
###### **1Kor 1,20**
 Gdzie jest mędrzec? Gdzie uczony? Gdzie badacz tego świata? Czyż nie uczynił Bóg mądrości świata głupstwem?
###### **1Kor 1,21**
 Skoro bowiem świat przez mądrość nie poznał Boga w mądrości Bożej, spodobało się Bogu przez głupstwo głoszenia słowa zbawiać wierzących.
###### **1Kor 1,22**
 Tak więc, gdy Żydzi żądają znaków, a Grecy szukają mądrości,
###### **1Kor 1,23**
 my głosimy Chrystusa ukrzyżowanego, który jest zgorszeniem dla Żydów, a głupstwem dla pogan,
###### **1Kor 1,24**
 dla tych zaś, którzy są powołani, tak spośród Żydów, jak i spośród Greków – Chrystusem, mocą Bożą i mądrością Bożą.
###### **1Kor 1,25**
 To bowiem, co jest głupstwem u Boga, przewyższa mądrością ludzi, a co jest słabe u Boga, przewyższa mocą ludzi.
###### **1Kor 1,26**
 Przeto przypatrzcie się, bracia, powołaniu waszemu! Według oceny ludzkiej niewielu [tam] mędrców, niewielu możnych, niewielu szlachetnie urodzonych.
###### **1Kor 1,27**
 Bóg wybrał właśnie to, co głupie w oczach świata, aby zawstydzić mędrców, wybrał, co niemocne, aby mocnych poniżyć;
###### **1Kor 1,28**
 i to, co nieszlachetnie urodzone według świata oraz wzgardzone, i to, co [w ogóle] nie jest, wyróżnił Bóg, by to, co jest, unicestwić,
###### **1Kor 1,29**
 tak by się żadne stworzenie nie chełpiło wobec Boga.
###### **1Kor 1,30**
 Przez Niego bowiem jesteście w Chrystusie Jezusie, który stał się dla nas mądrością od Boga i sprawiedliwością, i uświęceniem, i odkupieniem,
###### **1Kor 1,31**
 aby jak to jest napisane, w Panu się chlubił ten, kto się chlubi.
# 1Kor 1 PAU
###### **1Kor 1,1**
 Paweł, z woli Boga powołany na apostoła Chrystusa Jezusa, i brat Sostenes
###### **1Kor 1,2**
 do Kościoła Bożego w Koryncie, do świętych w Chrystusie Jezusie, powołanych do świętości wraz z tymi wszystkimi, którzy na każdym miejscu wzywają imienia Pana naszego, Jezusa Chrystusa, ich i naszego Pana:
###### **1Kor 1,3**
 łaska wam i pokój od Boga, naszego Ojca, i od Pana Jezusa Chrystusa.
###### **1Kor 1,4**
 Nieustannie dziękuję za was mojemu Bogu, za łaskę Bożą, którą otrzymaliście dzięki Chrystusowi Jezusowi.
###### **1Kor 1,5**
 W Nim zostaliście wzbogaceni we wszystko, w każde słowo i wszelką wiedzę,
###### **1Kor 1,6**
 ponieważ świadectwo Chrystusa utrwaliło się w was.
###### **1Kor 1,7**
 W ten sposób nie brakuje wam żadnego daru, lecz jedynie oczekujecie objawienia się Pana naszego, Jezusa Chrystusa.
###### **1Kor 1,8**
 On będzie was umacniał aż do końca, abyście byli bez zarzutu na Dzień Pana naszego Jezusa Chrystusa.
###### **1Kor 1,9**
 Godny wiary jest Bóg, który powołał was do wspólnoty ze swoim Synem, Jezusem Chrystusem, naszym Panem!
###### **1Kor 1,10**
 W imię Pana naszego, Jezusa Chrystusa, wzywam was, bracia, byście byli zgodni we wszystkim, by nie było wśród was podziałów, lecz jedność w myśleniu i poznaniu.
###### **1Kor 1,11**
 Otrzymałem bowiem, bracia moi, wieści od ludzi Chloe, że spieracie się między sobą.
###### **1Kor 1,12**
 Mam na myśli to, że jeden mówi: „Ja jestem Pawła”, drugi: „Ja jestem Apollosa”, inny: „Ja jestem Kefasa” lub jeszcze inny: „Ja jestem Chrystusa”!
###### **1Kor 1,13**
 Czy można dzielić Chrystusa? Czy Paweł za was został ukrzyżowany? Czy w imię Pawła zostaliście ochrzczeni?
###### **1Kor 1,14**
 Dziękuję Bogu, że nie ochrzciłem nikogo z was prócz Kryspusa i Gajusza.
###### **1Kor 1,15**
 Nikt nie może więc powiedzieć, że w moje imię został ochrzczony.
###### **1Kor 1,16**
 Owszem, ochrzciłem rodzinę Stefanasa, ale poza tym nie przypominam sobie, bym jeszcze kogoś ochrzcił.
###### **1Kor 1,17**
 Chrystus przecież nie posłał mnie, abym chrzcił, lecz abym głosił Ewangelię i to nie przez mądre wywody, by nie został umniejszony krzyż Chrystusa.
###### **1Kor 1,18**
 Nauka o krzyżu jest głupstwem dla tych, którzy są na drodze do zagłady, ale dla nas, będących na drodze do zbawienia, jest mocą Bożą.
###### **1Kor 1,19**
 Jest napisane: Wyniszczę mądrość mędrców i udaremnię roztropność roztropnych.
###### **1Kor 1,20**
 Gdzie jest mądry? Gdzie uczony? Gdzie ten, co wnika w sprawy świata? Czyż Bóg nie uczynił głupstwem mądrości świata?
###### **1Kor 1,21**
 Skoro bowiem świat przeniknięty mądrością Bożą nie poznał Boga za pomocą tej mądrości, spodobało się Bogu zbawić tych, którzy wierzą, przez głupstwo głoszenia nauki.
###### **1Kor 1,22**
 I tak, gdy Żydzi żądają znaków, a Grecy szukają mądrości,
###### **1Kor 1,23**
 my głosimy Chrystusa ukrzyżowanego. On jest dla Żydów powodem upadku, a dla pogan głupstwem,
###### **1Kor 1,24**
 jednakże dla powołanych, tak Żydów, jak i Greków, jest Chrystusem - mocą i mądrością Bożą.
###### **1Kor 1,25**
 Bo to, co głupie u Boga, mądrzejsze jest od ludzi, a co uchodzi za słabe u Boga, mocniejsze jest od ludzi.
###### **1Kor 1,26**
 Bracia! Przypatrzcie się waszemu powołaniu! Według osądu ludzkiego niewielu wśród was jest mądrych, niewielu wpływowych i niewielu szlachetnie urodzonych.
###### **1Kor 1,27**
 Tymczasem Bóg wybrał właśnie to, co dla świata jest głupie, aby zawstydzić mądrych, i to, co słabe w oczach świata, aby zawstydzić mocnych.
###### **1Kor 1,28**
 Bóg wybrał właśnie to, co w ocenie świata nie jest szlachetnie urodzone, co jest wzgardzone, i to, co nie jest, aby unicestwić to, co jest.
###### **1Kor 1,29**
 W ten sposób nikt nie może wynosić się wobec Boga.
###### **1Kor 1,30**
 On zjednoczył nas z Chrystusem Jezusem, który stał się dla nas Bożą mądrością, sprawiedliwością, uświęceniem i odkupieniem,
###### **1Kor 1,31**
 aby jak to jest napisane: Kto chce się chlubić, niech się chlubi Panem.
# 1Kor 1 BP
###### **1Kor 1,1**
 Paweł, z woli Bożej powołany na apostoła Jezusa Chrystusa, oraz brat Sostenes
###### **1Kor 1,2**
 do Kościoła Bożego w Koryncie, do tych, którzy zostali uświęceni w Jezusie Chrystusie i powołani do świętości wraz ze wszystkimi, którzy na każdym miejscu wzywają imienia Pana naszego Jezusa Chrystusa, zarówno ich jak i naszego Pana.
###### **1Kor 1,3**
 Łaska wam i pokój od Boga, Ojca naszego, i od Pana Jezusa Chrystusa.
###### **1Kor 1,4**
 Zawsze dziękuję Bogu mojemu za was z powodu udzielenia wam łaski Bożej w Jezusie Chrystusie.
###### **1Kor 1,5**
 W Nim zostaliście bowiem wzbogaceni pod każdym względem we wszelkie słowo i wszelkie poznanie,
###### **1Kor 1,6**
 ponieważ zostało wśród was utwierdzone świadectwo o Jezusie Chrystusie.
###### **1Kor 1,7**
 Z tych względów nie brakuje żadnego daru Bożego wam, oczekującym objawienia się Pana naszego Jezusa Chrystusa.
###### **1Kor 1,8**
 On będzie was utwierdzał aż do końca, abyście okazali się nienaganni w dniu Pana naszego Jezusa Chrystusa.
###### **1Kor 1,9**
 Wierny jest Bóg, który powołał was do wspólnoty ze swoim Synem Jezusem Chrystusem, Panem naszym.
###### **1Kor 1,10**
 Błagam was, bracia, w imię Pana naszego Jezusa Chrystusa, abyście wszyscy mówili to samo i aby nie było wśród was rozłamów. Żyjcie w zgodzie, bądźcie wszyscy tej samej myśli i tego samego zdania.
###### **1Kor 1,11**
 Bracia moi! Powiadomili mię o was ludzie Chloe, że są wśród was spory.
###### **1Kor 1,12**
 Mam na myśli to, że każdy z was mówi: "Ja jestem po stronie Pawła", "Ja Apollosa", "Ja należę do Piotra", a "Ja do Chrystusa".
###### **1Kor 1,13**
 Czy Chrystus może być rozdzielony? Czy Paweł został za was ukrzyżowany? Czy ochrzczono was w imię Pawła?
###### **1Kor 1,14**
 Dziękuję Bogu, że poza Kryspusem i Gajusem nikogo z was nie ochrzciłem.
###### **1Kor 1,15**
 Nikt nie może więc powiedzieć, że został ochrzczony w imię moje.
###### **1Kor 1,16**
 Wprawdzie ochrzciłem jeszcze rodzinę Stefanasa, ale poza tym nie pamiętam, czy jeszcze kogoś ochrzciłem.
###### **1Kor 1,17**
 Chrystus bowiem nie posłał mię, abym chrzcił, lecz abym głosił dobrą nowinę, nie opierając się na uczonych wywodach, które mogą pozbawić mocy krzyż Chrystusa.
###### **1Kor 1,18**
 Nauka o krzyżu wydaje się głupotą tym, którzy kroczą drogą zatracenia. Natomiast jest mocą Bożą dla nas, których udziałem jest zbawienie.
###### **1Kor 1,19**
 Napisano bowiem: "Zniszczę mądrość mędrców, a roztropność roztropnych zniweczę".
###### **1Kor 1,20**
 Gdzie zatem jest mędrzec? Gdzie uczony w Piśmie? Gdzie badacz tego świata? Czy Bóg nie zamienił mądrości świata w głupotę?
###### **1Kor 1,21**
 Skoro bowiem świat za pomocą swojej mądrości nie poznał Boga w całej Jego mądrości, wówczas spodobało się Bogu zbawić tych, którzy wierzą, przez głoszenie nauki uważanej przez świat za głupotę.
###### **1Kor 1,22**
 I tak, Żydzi domagają się znaków, a Grecy szukają mądrości,
###### **1Kor 1,23**
 my głosimy Chrystusa ukrzyżowanego. Wywołuje to zgorszenie u Żydów, poganom wydaje się głupotą.
###### **1Kor 1,24**
 Natomiast tym, którzy są powołani zarówno spośród Żydów jak i Greków, głosimy Chrystusa jako moc i mądrość Bożą.
###### **1Kor 1,25**
 Ponieważ to, co w postępowaniu Boga wygląda na głupotę, jest mądrzejsze od ludzi, a to, co na słabość, silniejsze od ludzi.
###### **1Kor 1,26**
 Bracia! Przypatrzcie się waszemu powołaniu. Niewielu wśród was mądrych w pojęciu ludzkim, niewielu wpływowych i szlachetnie urodzonych.
###### **1Kor 1,27**
 Bóg wybrał bowiem to, co głupie według świata, aby zawstydzić mądrych, i co słabe według świata wybrał Bóg, aby zawstydzić to, co mocne.
###### **1Kor 1,28**
 Bóg wybrał również to, co świat ma za nic i uważa za nieszlachetnie urodzone oraz godne pogardy, aby unicestwić to, co czymś jest,
###### **1Kor 1,29**
 w tym celu, aby nikt z ludzi nie chlubił się przed Bogiem.
###### **1Kor 1,30**
 Dzięki Niemu jesteście w łączności z Chrystusem Jezusem, który stał się dla nas mądrością od Boga, sprawiedliwością, uświęceniem i odkupieniem,
###### **1Kor 1,31**
 aby zgodnie z tym, co zostało napisane: "w Panu chlubił się ten, kto się chlubi".
# 1Kor 1 BR
###### **1Kor 1,1**
 Paweł, z woli Bożej powołany na apostoła Jezusa Chrystusa, i Sostenes, brat,
###### **1Kor 1,2**
 do Kościoła Bożego w Koryncie, do tych, którzy zostali uświęceni w Jezusie Chrystusie i powołani do świętości wespół ze wszystkimi, co na każdym miejscu wzywają imienia Pana naszego Jezusa Chrystusa, ich i naszego [Pana].
###### **1Kor 1,3**
 Łaska wam i pokój od Boga Ojca naszego i od Pana Jezusa Chrystusa.
###### **1Kor 1,4**
 Bogu mojemu dziękuję wciąż za was, za łaskę daną wam w Chrystusie Jezusie.
###### **1Kor 1,5**
 W Nim to bowiem zostaliście wzbogaceni we wszystko: we wszelkie słowo i wszelkie poznanie,
###### **1Kor 1,6**
 bo świadectwo Chrystusowe utrwaliło się w was.
###### **1Kor 1,7**
 Nie doznajecie tedy braku żadnej łaski, oczekując objawienia się Pana naszego Jezusa Chrystusa.
###### **1Kor 1,8**
 On też będzie umacniał was aż do końca, abyście byli bez zarzutu w dzień Pana naszego Jezusa Chrystusa.
###### **1Kor 1,9**
 Wierny jest Bóg, który powołał was do wspólnoty z Synem swoim Jezusem Chrystusem, Panem naszym.
###### **1Kor 1,10**
 Przeto upominam was, bracia, w imię Pana naszego Jezusa Chrystusa, abyście żyli w zgodzie i by nie było wśród was rozłamów; abyście byli jednego ducha i jednej myśli.
###### **1Kor 1,11**
 Doniesiono mi bowiem o was, bracia moi, przez ludzi Chloe, że zdarzają się między wami spory.
###### **1Kor 1,12**
 Myślę o tym, co każdy z was mówi: Ja jestem od Pawła, ja od Apollosa; ja jestem Kefasa, a ja Chrystusa.
###### **1Kor 1,13**
 Czyż Chrystus jest podzielony? Czyż Paweł został za was ukrzyżowany? Czyż w imię Pawła zostaliście ochrzczeni?
###### **1Kor 1,14**
 Dziękuję Bogu, że prócz Kryspusa i Gajusa nikogo z was nie ochrzciłem.
###### **1Kor 1,15**
 Nikt przeto nie może powiedzieć, że w imię moje został ochrzczony.
###### **1Kor 1,16**
 Zresztą, prawda, ochrzciłem dom Stefanasa. Poza tym nie wiem, czym ochrzcił jeszcze kogoś.
###### **1Kor 1,17**
 Nie posłał mnie Chrystus, abym chrzcił, lecz abym głosił Ewangelię, i to nie w mądrości słowa, by nie zniweczyć Chrystusowego krzyża.
###### **1Kor 1,18**
 Nauka bowiem krzyża głupstwem jest dla tych, co idą na zatracenie, mocą Bożą zaś dla nas, którzy dostępujemy zbawienia.
###### **1Kor 1,19**
 Napisane jest bowiem: Wytracę mądrość mędrców, a przebiegłość przebiegłych zniweczę.
###### **1Kor 1,20**
 Gdzie jest mędrzec? Gdzie uczony? Gdzie badacz tego świata? Czyż nie uczynił Bóg mądrości świata głupstwem?
###### **1Kor 1,21**
 Skoro bowiem świat przez mądrość nie poznał Boga w mądrości Bożej, spodobało się Bogu przez głupstwo głoszenia słowa zbawiać wierzących.
###### **1Kor 1,22**
 Tak więc, gdy Żydzi żądają znaków, a Grecy szukają mądrości,
###### **1Kor 1,23**
 my głosimy Chrystusa ukrzyżowanego, który jest zgorszeniem dla Żydów, a głupstwem dla pogan;
###### **1Kor 1,24**
 dla tych zaś, którzy są powołani, tak spośród Żydów, jak i spośród Greków - Chrystusem, mocą i mądrością Bożą.
###### **1Kor 1,25**
 To bowiem, co jest głupstwem u Boga, przewyższa mądrością ludzi, a co jest słabe u Boga, przewyższa mocą ludzi.
###### **1Kor 1,26**
 Przeto przypatrzcie się, bracia, powołaniu waszemu! Według oceny ludzkiej niewielu tam mędrców, niewielu możnych, niewielu szlachetnie urodzonych.
###### **1Kor 1,27**
 Bóg wybrał właśnie to, co głupie w oczach świata, aby zawstydzić mędrców; upodobał sobie w tym, co niemocne, aby mocnych poniżyć,
###### **1Kor 1,28**
 i to, co nie jest szlachetnie urodzone według świata i wzgardzone, i to, co [w ogóle] nie jest, wyróżnił Bóg, by to, co jest, unicestwić,
###### **1Kor 1,29**
 tak by się żadne stworzenie nie chełpiło wobec Boga.
###### **1Kor 1,30**
 Przez Niego bowiem jesteście w Chrystusie Jezusie, który stał się dla nas mądrością od Boga i sprawiedliwością, i uświęceniem, i odkupieniem,
###### **1Kor 1,31**
 aby jak to jest napisane, w Panu się chlubił ten, kto się chlubi.
# 1Kor 1 WUJ
###### **1Kor 1,1**
 Paweł powołany Apostoł Jezusa Chrystusa, przez wolą Bożą, i Sosthenes brat.
###### **1Kor 1,2**
 Kościołowi Bożemu, który jest w Koryncie, poświęconym w Chrystusie Jezusie, powołanym świętym, ze wszystkiemi, którzy wzywają imienia pana naszego Jezusa, Chrystusa na wszelkim miejscu ich, i naszem.
###### **1Kor 1,3**
 Łaska wam i pokój od Boga Ojca naszego i Pana Jezusa Chrystusa.
###### **1Kor 1,4**
 Dziękuję Bogu mojemu zawsze za was z łaski Bożej, która jest wam dana w Chrystusie Jezusie,
###### **1Kor 1,5**
 Iż we wszystkiem staliście się bogatemi w nim, we wszelkiem słowie i we wszelkiej umiejętności,
###### **1Kor 1,6**
 Jako świadectwo Chrystusowe utwierdzone jest w was,
###### **1Kor 1,7**
 Tak, iż wam na żadnej łasce nie schodzi, oczekawającym objawienia Pana naszego Jezusa Chrystusa.
###### **1Kor 1,8**
 Który też was umocni aż do końca bez winy w dzień przyszycia Pana naszego Jezusa Chrystusa.
###### **1Kor 1,9**
 Wierny Bóg: przez którego jesteście wezwani w towarzystwo Syna jego Jezusa Chrystusa Pana naszego.
###### **1Kor 1,10**
 Lecz proszę was bracia, przez imię Pana naszego Jezusa Chrystusa, abyście toż mówili wszyscy, a iżby nie było między wami rozerwania: ale bądzcie doskonali w jednem rozumieniu i w jednej nauce.
###### **1Kor 1,11**
 Albowiem dano mi znać o was bracia moi, od tych, którzy są Chlojej, iż poswarki są między wami.
###### **1Kor 1,12**
 A to wam powiadam, iż każdy z was mówi: Jam jest Pawłów, a ja Apollów, a ja Cepchy, a ja Chrystusów.
###### **1Kor 1,13**
 Rozdzielony jest Chrystus? Azaż Paweł jest za was ukrzyżowan? abo w imię Pawłowe jesteście ochrzczeni?
###### **1Kor 1,14**
 Dziękuję Bogu, iżem żadnego a was nie chrzcił, jedno Kryspa i Gajusa:
###### **1Kor 1,15**
 Aby kto nie mówił, żeście w imię moje ochrzczeni.
###### **1Kor 1,16**
 Ochrzciłem też i dom Stephany. Nadto nie wiem, jeślim kogo drugiego ochrzcił.
###### **1Kor 1,17**
 Boć Chrystus nie posłał mię chrzcić, ale Ewangelią przepowiadać: nie w mądrości słowa, aby się nie stał próżnym krzyż Chrystusów.
###### **1Kor 1,18**
 Abowiem słowo krzyża, tym, którzy giną, jest głupstwem: lecz tym, którzy zbawienia dostępują, to jest nam, jest mocą Bożą.
###### **1Kor 1,19**
 bo jest napisano: Zagubię mądrość mądrych: a roztropność roztropnych odrzucę.
###### **1Kor 1,20**
 Gdzież mądry? gdzież Doktor? gdzież badacz świata tego? Izali nie głupią uczynił Bóg Mądrość świata tego?
###### **1Kor 1,21**
 Abowiem, iż w mądrości Bożej świat nie poznał Boga przez mądrość: podobało się Bogu przez głupstwo przepowiadania zbawić wierzące.
###### **1Kor 1,22**
 Ponieważ i Żydowie cudów się domagają, i Grekowi mądrości szukają:
###### **1Kor 1,23**
 A my przepowiadamy Chrystusa ukrzyżowanego, Żydom w prawdzie zgorszeniem, a Grekom głupstwem,
###### **1Kor 1,24**
 Lecz samym wezwanym i Żydom i Grekom Chrystusa mocą Bożą i mądrością Bożą.
###### **1Kor 1,25**
 Ponieważ głupstwo Boże, jest mądrzejsze nad ludzi: a mdłość Boża, jest mądrzejsza nad ludzi.
###### **1Kor 1,26**
 Bo przypatrzcie się, bracia, waszemu powołaniu, iż nie wiele mądrych wedle ciała, nie wiele możnych, nie wiele zacnych:
###### **1Kor 1,27**
 Ale wybrał Bug głupstwa świata, aby zawstydził mądre: a mdłe świata wybrał, aby zawstydzić mocne:
###### **1Kor 1,28**
 I podłe świata i wzgardzone wybrał Bóg i te których mniemasz, aby zniszczył te które są:
###### **1Kor 1,29**
 Aby się żadne ciało przed oczyma jego nie chlubiło.
###### **1Kor 1,30**
 Ale z niego wy jesteście Jezusie Chrystusie: który się nam stał mądrością od Boga i sprawiedliwością, i poświęceniem, i odkupieniem:
###### **1Kor 1,31**
 Aby, jako jest napisano: Kto się chlubi, w panu się chlubił.
# 1Kor 1 STERN
###### **1Kor 1,1**
 Sza'ul, powołany z woli Bożej na wysłannika Mesjasza Jeszui, i brat Sostenes
###### **1Kor 1,2**
 do Bożej Wspólnoty Mesjanicznej w Koryncie, złożonej z tych, którzy zostali zastrzeżeni przez Jeszuę Mesjasza i powołani, aby być Bożym ludem świętym, wraz z każdym na każdym miejscu, kto wzywa imienia naszego Pana Jeszui Mesjasza, Pana ich jak też i naszego:
###### **1Kor 1,3**
 łaska wam i szalom od Boga, Ojca naszego, i od Pana Jeszui Mesjasza.
###### **1Kor 1,4**
 Dziękuję Bogu memu za was zawsze ze względu na miłość i dobroć Bożą daną wam przez Mesjasza Jeszuę,
###### **1Kor 1,5**
 zostaliście w Nim bowiem wzbogaceni tak różnorako, zwłaszcza w moc mowy i głębię poznania.
###### **1Kor 1,6**
 Zaiste, świadectwo o Mesjaszu zostało w was mocno ugruntowane,
###### **1Kor 1,7**
 tak że nie brak wam żadnego daru duchowego i żarliwie wyczekujecie objawienia się naszego Pana Jeszui Mesjasza.
###### **1Kor 1,8**
 On was uzdolni, abyście wytrwali aż do końca, byli zatem bez zarzutu w Dzień Pana naszego Jeszui Mesjasza -
###### **1Kor 1,9**
 Bóg jest godny zaufania: to On was powołał do wspólnoty ze swym Synem, Jeszuą Mesjaszem, naszym Panem.
###### **1Kor 1,10**
 Mimo to, bracia, wzywam was w imię Pana naszego Jeszui Mesjasza, abyście byli wszyscy zgodni w tym, co mówicie, i nie trwali w podziałach, lecz powrócili do jednomyślności i wspólnego zamysłu.
###### **1Kor 1,11**
 Bo niektórzy z ludzi Chloe wyjawili mi, bracia, że są kłótnie wśród was.
###### **1Kor 1,12**
 Mówię to, bo jeden z was powiada: "Ja jestem z Sza'ulem", inny powiada: "Ja jestem z Apollosem", inny: "Ja jestem z Kefą", a jeszcze inny mówi: "Ja jestem z Mesjaszem!".
###### **1Kor 1,13**
 Czy Mesjasz został podzielony na kawałki? Czy to Sza'ula zabito za was na palu? W imię Sza'ula zostaliście zanurzeni?
###### **1Kor 1,14**
 Dziękuję Bogu, żem nie zanurzył nikogo z was, wyjąwszy Kryspa i Gajusza,
###### **1Kor 1,15**
 w przeciwnym razie jeszcze by kto powiedział, że w moje imię zostaliście zanurzeni.
###### **1Kor 1,16**
 (Owszem, zanurzyłem jeszcze Stefanasa i jego dom, a poza tym nie przypominam sobie, żebym jeszcze kogoś zanurzył).
###### **1Kor 1,17**
 Bo Mesjasz nie posłał mnie, bym zanurzał, ale abym głosił Dobrą Nowinę i czynił to, nie opierając się na "mądrości" polegającej na zwykłej retoryce, ażeby nie odbierać Mesjaszowemu palowi egzekucyjnemu jego mocy.
###### **1Kor 1,18**
 Bo nauka o palu egzekucyjnym to absurd dla tych, którzy giną, ale dla nas, podlegających zbawieniu, jest ono mocą Bożą.
###### **1Kor 1,19**
 Bo Tanach mówi: "Zniszczę mądrość mądrych i pokrzyżuję zamysły zmyślnych".
###### **1Kor 1,20**
 Gdzie w tej sytuacji jest filozof, nauczyciel Tory czy któryś z dzisiejszych myślicieli? Czyż nie sprawił Bóg, że mądrość tego świata prezentuje się dość niedorzecznie?
###### **1Kor 1,21**
 Bo mądrość Boga postanowiła, że świat za pomocą własnej mądrości nie pozna Go. Dlatego Bóg zdecydował użyć "absurdu" tego, co głosimy, jako narzędzia zbawienia tych, którzy temu zaufają.
###### **1Kor 1,22**
 Z tej właśnie przyczyny, że Żydzi proszą o znaki, a Grecy próbują znaleźć mądrość,
###### **1Kor 1,23**
 my ciągle głosimy Mesjasza straconego na palu jak zbrodniarz! Dla Żydów to zawada, a dla Greków absurd;
###### **1Kor 1,24**
 dla tych jednak, którzy są powołani, i dla Żydów, i dla Greków, ten właśnie Mesjasz jest Bożą mocą i Bożą mądrością!
###### **1Kor 1,25**
 Bo Boży "absurd" jest mądrzejszy niż ludzka "mądrość". A Boża "słabość" jest silniejsza niż ludzka "siła".
###### **1Kor 1,26**
 Spójrzcie na siebie, bracia, spójrzcie na tych, których Bóg powołał! Niewielu wśród was mądrych według miary tego świata, niewielu dysponuje władzą czy może się poszczycić szlachetnym urodzeniem.
###### **1Kor 1,27**
 Ale to, co świat uznaje za absurd, Bóg wybrał, aby zawstydzić mądrych; to, co świat uznaje za słabe, Bóg wybrał, aby zawstydzić silnych;
###### **1Kor 1,28**
 i wybrał Bóg to, co świat ma za pospolite albo za nic uważa, aby unicestwić to, co świat uznaje za ważne;
###### **1Kor 1,29**
 tak aby nikt nie chełpił się przed Bogiem.
###### **1Kor 1,30**
 To za Jego sprawą jesteście jedno z Mesjaszem Jeszuą. On stał się dla nas mądrością od Boga i sprawiedliwością, i świętością, a także odkupieniem.
###### **1Kor 1,31**
 Dlatego - jak rzecze Tanach - "niech każdy, kto chce się chlubić, chlubi się Adonai".
# 1Kor 1 TRO
###### **1Kor 1,1**
 **παυλος** *paulos* Paweł – [mały] [[G3972]] [[N-NSM]] **κλητος** *klētos* powołany [[G2822]] [[A-NSM]] **αποστολος** *apostolos* wysłannik [[G652]] [[N-NSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **δια** *dia* przez [[G1223]] [[PREP]] **θεληματος** *thelēmatos* wolę [[G2307]] [[N-GSN]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **σωσθενης** *sōsthenēs* Sostenes – [bezpieczny w sile] [[G4988]] [[N-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **αδελφος** *adelfos* brat [[G80]] [[N-NSM]]
###### **1Kor 1,2**
 **τη** *tē* [[G3588]] WTT-DSF **εκκλησια** *ekklēsia* zgromadzeniu – (społeczności) wywołanych [[G1577]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **τη** *tē* [[G3588]] WTT-DSF **ουση** *ousē* będącemu [[G5607]] WTV-PXP-DSF **εν** *en* w [[G1722]] [[PREP]] **κορινθω** *korinthō* Koryncie [[G2882]] [[N-DSF]] **ηγιασμενοις** *hēgiasmenois* którzy są poświęceni – którzy są uświęceni [[G37]] WTV-RPP-DPM **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM **κλητοις** *klētois* powołanym [[G2822]] WTA-DPM **αγιοις** *hagiois* świętym [[G40]] WTA-DPM **συν** *syn* ze [[G4862]] [[PREP]] **πασιν** *pasin* wszystkimi [[G3956]] WTA-DPM **τοις** *tois* [[G3588]] WTT-DPM **επικαλουμενοις** *epikaloumenois* przywołującymi [[G1941]] WTV-PMP-DPM **το** *to* [[G3588]] WTT-ASN **ονομα** *onoma* imię [[G3686]] WTN-ASN **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **εν** *en* w [[G1722]] [[PREP]] **παντι** *panti* każdym [[G3956]] WTA-DSM **τοπω** *topō* miejscu [[G5117]] WTN-DSM **αυτων** *autōn* ich [[G846]] WTP-GPM **τε** *te* zarówno – także [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **ημων** *hēmōn* naszym [[G2257]] WTP-1GP
###### **1Kor 1,3**
 **χαρις** *charis* Łaska [[G5485]] [[N-NSF]] **υμιν** *hymin* wam [[G5213]] WTP-2DP **και** *kai* i [[G2532]] [[CONJ]] **ειρηνη** *eirēnē* pokój [[G1515]] [[N-NSF]] **απο** *apo* od [[G575]] [[PREP]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **πατρος** *patros* Ojca [[G3962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **και** *kai* i [[G2532]] [[CONJ]] **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **1Kor 1,4**
 **ευχαριστω** *eucharistō* Dziękuję [[G2168]] WTV-PAI-1S **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **μου** *mou* mojemu [[G3450]] WTP-1GS **παντοτε** *pantote* zawsze – każdej chwili [[G3842]] [[ADV]] **περι** *peri* o – za [[G4012]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **επι** *epi* z powodu [[G1909]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **χαριτι** *chariti* łaski [[G5485]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **τη** *tē* (tej) [[G3588]] WTT-DSF **δοθειση** *dotheisē* która została dana [[G1325]] WTV-APP-DSF **υμιν** *hymin* wam [[G5213]] WTP-2DP **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM
###### **1Kor 1,5**
 **οτι** *hoti* że [[G3754]] [[CONJ]] **εν** *en* we [[G1722]] [[PREP]] **παντι** *panti* wszystkim [[G3956]] WTA-DSN **επλουτισθητε** *eploutisthēte* zostaliście ubogaceni [[G4148]] WTV-API-2P **εν** *en* w [[G1722]] [[PREP]] **αυτω** *autō* Nim [[G846]] WTP-DSM **εν** *en* we [[G1722]] [[PREP]] **παντι** *panti* wszelkim – każdym [[G3956]] WTA-DSM **λογω** *logō* słowie [[G3056]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **παση** *pasē* wszelkim – każdym [[G3956]] WTA-DSF **γνωσει** *gnōsei* poznaniu – wiedzy [[G1108]] [[N-DSF]]
###### **1Kor 1,6**
 **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **το** *to* [[G3588]] WTT-NSN **μαρτυριον** *martyrion* świadectwo [[G3142]] WTN-NSN **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **εβεβαιωθη** *ebebaiōthē* zostało utwierdzone – zostało umocnione [[G950]] [[V-API-3S]] **εν** *en* w [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP
###### **1Kor 1,7**
 **ωστε** *hōste* tak, że [[G5620]] [[CONJ]] **υμας** *hymas* wam [[G5209]] WTP-2AP **μη** *mē* nie [[G3361]] [[PRT-N]] **υστερεισθαι** *hystereisthai* być w niedostatku [[G5302]] WTV-PPN **εν** *en* w [[G1722]] [[PREP]] **μηδενι** *mēdeni* żadnym [[G3367]] WTA-DSN **χαρισματι** *charismati* darze łaski [[G5486]] WTN-DSN **απεκδεχομενους** *apekdechomenous* oczekujący – wyczekujący [[G553]] WTV-PNP-APM **την** *tēn* [[G3588]] WTT-ASF **αποκαλυψιν** *apokalypsin* objawienia [[G602]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **1Kor 1,8**
 **ος** *hos* który [[G3739]] WTR-NSM **και** *kai* i [[G2532]] [[CONJ]] **βεβαιωσει** *bebaiōsei* utwierdzi – umocni [[G950]] WTV-FAI-3S **υμας** *hymas* was [[G5209]] WTP-2AP **εως** *heōs* aż do [[G2193]] [[CONJ]] **τελους** *telous* końca [[G5056]] [[N-GSN]] **ανεγκλητους** *anegklētous* nienagannych – nieobwinionych [[G410]] WTA-APM **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **ημερα** *hēmera* dniu [[G2250]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **1Kor 1,9**
 **πιστος** *pistos* Wierny – Godny wiary [[G4103]] [[A-NSM]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **δι** *di* przez [[G1223]] [[PREP]] **ου** *hou* którego [[G3739]] WTR-GSM **εκληθητε** *eklēthēte* zostaliście wezwani [[G2564]] WTV-API-2P **εις** *eis* do [[G1519]] [[PREP]] **κοινωνιαν** *koinōnian* wspólnoty [[G2842]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **υιου** *hyiou* Syna [[G5207]] [[N-GSM]] **αυτου** *autou* Jego [[G846]] [[P-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP
###### **1Kor 1,10**
 **παρακαλω** *parakalō* Proszę – Zachęcam [[G3870]] WTV-PAI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **υμας** *hymas* was [[G5209]] WTP-2AP **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **δια** *dia* przez [[G1223]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **ονοματος** *onomatos* imię [[G3686]] [[N-GSN]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **το** *to* (to) [[G3588]] WTT-ASN **αυτο** *auto* samo [[G846]] WTP-ASN **λεγητε** *legēte* mówilibyście [[G3004]] WTV-PAS-2P **παντες** *pantes* wszyscy [[G3956]] WTA-NPM **και** *kai* i [[G2532]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **η** *ē* byłoby (byłyby) [[G5600]] WTV-PXS-3S **εν** *en* w [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **σχισματα** *schismata* rozdarcia – rozłamy [[G4978]] WTN-NPN **ητε** *ēte* (aby) bylibyście [[G5600]] WTV-PXS-2P **δε** *de* zaś [[G1161]] [[CONJ]] **κατηρτισμενοι** *katērtismenoi* którzy są wydoskonaleni – którzy są umocnieni [[G2675]] WTV-RPP-NPM **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* (tej) [[G3588]] WTT-DSM **αυτω** *autō* samej [[G846]] WTP-DSM **νοι** *noi* myśli – rozumie [[G3563]] WTN-DSM **και** *kai* i [[G2532]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* (tym) [[G3588]] WTT-DSF **αυτη** *autē* samym [[G846]] WTP-DSF **γνωμη** *gnōmē* mniemaniu – opinii [[G1106]] [[N-DSF]]
###### **1Kor 1,11**
 **εδηλωθη** *edēlōthē* Zostało ujawnione – Zostało oznajmione [[G1213]] [[V-API-3S]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **μοι** *moi* mi [[G3427]] WTP-1DS **περι** *peri* o [[G4012]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **μου** *mou* moi [[G3450]] WTP-1GS **υπο** *hypo* przez [[G5259]] [[PREP]] **των** *tōn* (tych) [[G3588]] WTT-GPM **χλοης** *chloēs* Chloe – [młode liście] [[G5514]] [[N-GSF]] **οτι** *hoti* że [[G3754]] [[CONJ]] **εριδες** *erides* kłótnie – spory [[G2054]] [[N-NPF]] **εν** *en* wśród – w [[G1722]] [[PREP]] **υμιν** *hymin* was [[G5213]] WTP-2DP **εισιν** *eisin* są [[G1526]] WTV-PXI-3P
###### **1Kor 1,12**
 **λεγω** *legō* Mówię [[G3004]] WTV-PAI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **τουτο** *touto* to [[G5124]] WTD-ASN **οτι** *hoti* że [[G3754]] [[CONJ]] **εκαστος** *hekastos* każdy [[G1538]] [[A-NSM]] **υμων** *hymōn* (z) was [[G5216]] WTP-2GP **λεγει** *legei* mówi [[G3004]] WTV-PAI-3S **εγω** *egō* ja [[G1473]] WTP-1NS **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **ειμι** *eimi* jestem [[G1510]] WTV-PXI-1S **παυλου** *paulou* Pawła – [mały] [[G3972]] [[N-GSM]] **εγω** *egō* ja [[G1473]] WTP-1NS **δε** *de* zaś [[G1161]] [[CONJ]] **απολλω** *apollō* Apollosa [[G625]] [[N-GSM]] **εγω** *egō* ja [[G1473]] WTP-1NS **δε** *de* zaś [[G1161]] [[CONJ]] **κηφα** *kēfa* Kefasa – [skała] [[G2786]] [[N-GSM]] **εγω** *egō* ja [[G1473]] WTP-1NS **δε** *de* zaś [[G1161]] [[CONJ]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **1Kor 1,13**
 **μεμερισται** *memeristai* Jest podzielony – Jest rozczłonkowany [[G3307]] WTV-RPI-3S **ο** *ho* [[G3588]] [[T-NSM]] **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **μη** *mē* nie [[G3361]] [[PRT-N]] **παυλος** *paulos* Paweł – [mały] [[G3972]] [[N-NSM]] **εσταυρωθη** *estaurōthē* został ukrzyżowany [[G4717]] [[V-API-3S]] **υπερ** *hyper* za [[G5228]] [[PREP]] **υμων** *hymōn* was [[G5216]] WTP-2GP **η** *ē* lub [[G2228]] WTPRT **εις** *eis* w [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **ονομα** *onoma* imię [[G3686]] WTN-ASN **παυλου** *paulou* Pawła – [mały] [[G3972]] [[N-GSM]] **εβαπτισθητε** *ebaptisthēte* zostaliście zanurzeni [[G907]] WTV-API-2P
###### **1Kor 1,14**
 **ευχαριστω** *eucharistō* Dziękuję [[G2168]] WTV-PAI-1S **τω** *tō* [[G3588]] WTT-DSM **θεω** *theō* Bogu [[G2316]] WTN-DSM **οτι** *hoti* że [[G3754]] [[CONJ]] **ουδενα** *oudena* nikogo [[G3762]] WTA-ASM **υμων** *hymōn* (z) was [[G5216]] WTP-2GP **εβαπτισα** *ebaptisa* zanurzyłem [[G907]] WTV-AAI-1S **ει** *ei* jeśli [[G1487]] WTCOND **μη** *mē* nie [[G3361]] [[PRT-N]] **κρισπον** *krispon* Kryspusa [[G2921]] [[N-ASM]] **και** *kai* i [[G2532]] [[CONJ]] **γαιον** *gaion* Gajusa [[G1050]] [[N-ASM]]
###### **1Kor 1,15**
 **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **τις** *tis* ktoś [[G5100]] WTX-NSM **ειπη** *eipē* powiedziałby [[G2036]] WTV-2AAS-3S **οτι** *hoti* że [[G3754]] [[CONJ]] **εις** *eis* w [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **εμον** *emon* moje [[G1699]] WTS-1ASN **ονομα** *onoma* imię [[G3686]] WTN-ASN **εβαπτισα** *ebaptisa* zanurzyłem [[G907]] WTV-AAI-1S
###### **1Kor 1,16**
 **εβαπτισα** *ebaptisa* Zanurzyłem [[G907]] WTV-AAI-1S **δε** *de* zaś [[G1161]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **τον** *ton* [[G3588]] [[T-ASM]] **στεφανα** *stefana* Stefana – [ukoronowany] [[G4734]] [[N-GSM]] **οικον** *oikon* dom [[G3624]] [[N-ASM]] **λοιπον** *loipon* w końcu [[G3063]] WTA-ASN **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **οιδα** *oida* wiem [[G1492]] WTV-RAI-1S **ει** *ei* czy [[G1487]] WTCOND **τινα** *tina* kogoś [[G5100]] WTX-ASM **αλλον** *allon* innego [[G243]] WTA-ASM **εβαπτισα** *ebaptisa* zanurzyłem [[G907]] WTV-AAI-1S
###### **1Kor 1,17**
 **ου** *ou* nie [[G3756]] [[PRT-N]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **απεστειλεν** *apesteilen* wysłał [[G649]] [[V-AAI-3S]] **με** *me* mnie [[G3165]] WTP-1AS **χριστος** *christos* Pomazaniec [[G5547]] [[N-NSM]] **βαπτιζειν** *baptizein* zanurzać [[G907]] WTV-PAN **αλλ** *all* ale [[G235]] [[CONJ]] **ευαγγελιζεσθαι** *euangelizesthai* głosić dobrą nowinę [[G2097]] WTV-PMN **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εν** *en* w [[G1722]] [[PREP]] **σοφια** *sofia* mądrości [[G4678]] [[N-DSF]] **λογου** *logou* słowa [[G3056]] [[N-GSM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **κενωθη** *kenōthē* zostałby uczyniony pustym – pozbawiłbym znaczenia [[G2758]] WTV-APS-3S **ο** *ho* [[G3588]] [[T-NSM]] **σταυρος** *stauros* krzyż [[G4716]] [[N-NSM]] **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **1Kor 1,18**
 **ο** *ho* [[G3588]] [[T-NSM]] **λογος** *logos* Słowo [[G3056]] [[N-NSM]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **του** *tou* [[G3588]] WTT-GSM **σταυρου** *staurou* krzyża [[G4716]] [[N-GSM]] **τοις** *tois* (dla) [[G3588]] WTT-DPM **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **απολλυμενοις** *apollymenois* którzy giną [[G622]] WTV-PEP-DPM **μωρια** *mōria* głupota [[G3472]] [[N-NSF]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **τοις** *tois* [[G3588]] WTT-DPM **δε** *de* zaś [[G1161]] [[CONJ]] **σωζομενοις** *sōzomenois* którzy są zbawiani – którzy są ratowani [[G4982]] WTV-PPP-DPM **ημιν** *hēmin* nas [[G2254]] WTP-1DP **δυναμις** *dynamis* moc [[G1411]] [[N-NSF]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **εστιν** *estin* jest [[G2076]] WTV-PXI-3S
###### **1Kor 1,19**
 **γεγραπται** *gegraptai* Jest napisane [[G1125]] WTV-RPI-3S **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **απολω** *apolō* zniszczę – zgubię [[G622]] WTV-FAI-1S **την** *tēn* [[G3588]] WTT-ASF **σοφιαν** *sofian* mądrość [[G4678]] WTN-ASF **των** *tōn* [[G3588]] WTT-GPM **σοφων** *sofōn* mądrych [[G4680]] WTA-GPM **και** *kai* i [[G2532]] [[CONJ]] **την** *tēn* [[G3588]] WTT-ASF **συνεσιν** *synesin* zrozumienie [[G4907]] WTN-ASF **των** *tōn* [[G3588]] WTT-GPM **συνετων** *synetōn* rozumnych – inteligentnych [[G4908]] WTA-GPM **αθετησω** *athetēsō* odrzucę – unieważnię [[G114]] WTV-FAI-1S
###### **1Kor 1,20**
 **που** *pou* Gdzie [[G4226]] WTPRT-I **σοφος** *sofos* mądry [[G4680]] [[A-NSM]] **που** *pou* gdzie [[G4226]] WTPRT-I **γραμματευς** *grammateus* znawca Pisma – uczony w Piśmie [[G1122]] [[N-NSM]] **που** *pou* gdzie [[G4226]] WTPRT-I **συζητητης** *syzētētēs* badacz [[G4804]] [[N-NSM]] **του** *tou* [[G3588]] WTT-GSM **αιωνος** *aiōnos* wieku [[G165]] [[N-GSM]] **τουτου** *toutou* tego [[G5127]] WTD-GSM **ουχι** *ouchi* czyż nie [[G3780]] WTPRT-I **εμωρανεν** *emōranen* uczynił głupią [[G3471]] [[V-AAI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **την** *tēn* [[G3588]] WTT-ASF **σοφιαν** *sofian* mądrość [[G4678]] WTN-ASF **του** *tou* [[G3588]] WTT-GSM **κοσμου** *kosmou* świata [[G2889]] [[N-GSM]] **τουτου** *toutou* tego [[G5127]] WTD-GSM
###### **1Kor 1,21**
 **επειδη** *epeidē* skoro zaś – jako, że [[G1894]] [[CONJ]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **σοφια** *sofia* mądrości [[G4678]] [[N-DSF]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εγνω** *egnō* poznał [[G1097]] WTV-2AAI-3S **ο** *ho* [[G3588]] [[T-NSM]] **κοσμος** *kosmos* świat [[G2889]] [[N-NSM]] **δια** *dia* przez [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **σοφιας** *sofias* mądrość [[G4678]] [[N-GSF]] **τον** *ton* [[G3588]] [[T-ASM]] **θεον** *theon* Boga [[G2316]] [[N-ASM]] **ευδοκησεν** *eudokēsen* miał upodobanie [[G2106]] [[V-AAI-3S]] **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **δια** *dia* przez [[G1223]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **μωριας** *mōrias* głupotę [[G3472]] [[N-GSF]] **του** *tou* [[G3588]] WTT-GSN **κηρυγματος** *kērygmatos* ogłaszania [[G2782]] [[N-GSN]] **σωσαι** *sōsai* zbawić – uratować [[G4982]] [[V-AAN]] **τους** *tous* [[G3588]] WTT-APM **πιστευοντας** *pisteuontas* wierzących [[G4100]] WTV-PAP-APM
###### **1Kor 1,22**
 **επειδη** *epeidē* skoro zaś – jako, że [[G1894]] [[CONJ]] **και** *kai* i [[G2532]] [[CONJ]] **ιουδαιοι** *ioudaioi* Judejczycy – [wielbić] [[G2453]] WTA-NPM **σημειον** *sēmeion* znaku [[G4592]] WTN-ASN **αιτουσιν** *aitousin* proszą – domagają się [[G154]] WTV-PAI-3P **και** *kai* i [[G2532]] [[CONJ]] **ελληνες** *hellēnes* Grecy [[G1672]] WTN-NPM **σοφιαν** *sofian* mądrości [[G4678]] WTN-ASF **ζητουσιν** *zētousin* szukają [[G2212]] WTV-PAI-3P
###### **1Kor 1,23**
 **ημεις** *hēmeis* my [[G2249]] WTP-1NP **δε** *de* zaś [[G1161]] [[CONJ]] **κηρυσσομεν** *kēryssomen* głosimy [[G2784]] WTV-PAI-1P **χριστον** *christon* Pomazańca [[G5547]] [[N-ASM]] **εσταυρωμενον** *estaurōmenon* który jest ukrzyżowany [[G4717]] WTV-RPP-ASM **ιουδαιοις** *ioudaiois* (dla) Judejczyków – [wielbić] [[G2453]] WTA-DPM **μεν** *men* wprawdzie – prawdziwie [[G3303]] WTPRT **σκανδαλον** *skandalon* zgorszenie [[G4625]] WTN-ASN **ελλησιν** *hellēsin* (dla) Greków [[G1672]] WTN-DPM **δε** *de* zaś [[G1161]] [[CONJ]] **μωριαν** *mōrian* głupotę [[G3472]] WTN-ASF
###### **1Kor 1,24**
 **αυτοις** *autois* (dla) samych [[G846]] WTP-DPM **δε** *de* zaś [[G1161]] [[CONJ]] **τοις** *tois* [[G3588]] WTT-DPM **κλητοις** *klētois* powołanych [[G2822]] WTA-DPM **ιουδαιοις** *ioudaiois* Judejczyków – [wielbić] [[G2453]] WTA-DPM **τε** *te* zarówno [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **ελλησιν** *hellēsin* Greków [[G1672]] WTN-DPM **χριστον** *christon* Pomazańca [[G5547]] [[N-ASM]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **δυναμιν** *dynamin* mocą [[G1411]] WTN-ASF **και** *kai* i [[G2532]] [[CONJ]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **σοφιαν** *sofian* mądrością [[G4678]] WTN-ASF
###### **1Kor 1,25**
 **οτι** *hoti* gdyż [[G3754]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **μωρον** *mōron* głupie [[G3474]] WTA-NSN **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **σοφωτερον** *sofōteron* mądrzejsze [[G4680]] WTA-NSN-C **των** *tōn* (od) [[G3588]] WTT-GPM **ανθρωπων** *anthrōpōn* ludzi [[G444]] WTN-GPM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S **και** *kai* i [[G2532]] [[CONJ]] **το** *to* [[G3588]] WTT-NSN **ασθενες** *asthenes* słabe – bezsilne [[G772]] WTA-NSN **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]] **ισχυροτερον** *ischyroteron* mocniejsze od – silniejsze od [[G2478]] WTA-NSN-C **των** *tōn* [[G3588]] WTT-GPM **ανθρωπων** *anthrōpōn* ludzi [[G444]] WTN-GPM **εστιν** *estin* jest [[G2076]] WTV-PXI-3S
###### **1Kor 1,26**
 **βλεπετε** *blepete* Przyglądacie się – Patrzycie [[G991]] WTV-PAI-2P **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **την** *tēn* (na) [[G3588]] WTT-ASF **κλησιν** *klēsin* powołanie [[G2821]] WTN-ASF **υμων** *hymōn* wasze [[G5216]] WTP-2GP **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **οτι** *hoti* że [[G3754]] [[CONJ]] **ου** *ou* nie [[G3756]] [[PRT-N]] **πολλοι** *polloi* liczni – wielu [[G4183]] WTA-NPM **σοφοι** *sofoi* mądrzy [[G4680]] WTA-NPM **κατα** *kata* według [[G2596]] [[PREP]] **σαρκα** *sarka* ciała [[G4561]] WTN-ASF **ου** *ou* nie [[G3756]] [[PRT-N]] **πολλοι** *polloi* liczni – wielu [[G4183]] WTA-NPM **δυνατοι** *dynatoi* mocni – możni [[G1415]] WTA-NPM **ου** *ou* nie [[G3756]] [[PRT-N]] **πολλοι** *polloi* liczni – wielu [[G4183]] WTA-NPM **ευγενεις** *eugeneis* szlachetnie urodzeni – dobrze urodzeni [[G2104]] WTA-NPM
###### **1Kor 1,27**
 **αλλα** *alla* ale [[G235]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **μωρα** *mōra* głupie [[G3474]] WTA-APN **του** *tou* [[G3588]] WTT-GSM **κοσμου** *kosmou* świata [[G2889]] [[N-GSM]] **εξελεξατο** *ekseleksato* wybrał [[G1586]] WTV-AMI-3S **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **τους** *tous* [[G3588]] WTT-APM **σοφους** *sofous* mądrych [[G4680]] WTA-APM **καταισχυνη** *kataischynē* zawstydzałby – hańbiłby [[G2617]] WTV-PAS-3S **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **ασθενη** *asthenē* słabych – bezsilnych [[G772]] WTA-APN **του** *tou* [[G3588]] WTT-GSM **κοσμου** *kosmou* świata [[G2889]] [[N-GSM]] **εξελεξατο** *ekseleksato* wybrał [[G1586]] WTV-AMI-3S **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ινα** *hina* aby [[G2443]] [[CONJ]] **καταισχυνη** *kataischynē* zawstydzałby – hańbiłby [[G2617]] WTV-PAS-3S **τα** *ta* [[G3588]] WTT-APN **ισχυρα** *ischyra* mocne – silne [[G2478]] WTA-APN
###### **1Kor 1,28**
 **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **αγενη** *agenē* niskiego rodu – nieurodzone [[G36]] WTA-APN **του** *tou* [[G3588]] WTT-GSM **κοσμου** *kosmou* świata [[G2889]] [[N-GSM]] **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **εξουθενημενα** *eksouthenēmena* które jest wzgardzone – które jest za nic miane [[G1848]] WTV-RPP-APN **εξελεξατο** *ekseleksato* wybrał [[G1586]] WTV-AMI-3S **ο** *ho* [[G3588]] [[T-NSM]] **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **μη** *mē* nie [[G3361]] [[PRT-N]] **οντα** *onta* istniejące [[G5607]] WTV-PXP-APN **ινα** *hina* aby [[G2443]] [[CONJ]] **τα** *ta* (to, co) [[G3588]] WTT-APN **οντα** *onta* istniejące [[G5607]] WTV-PXP-APN **καταργηση** *katargēsē* mógłby unieważnić – uznałby za bezużyteczne [[G2673]] WTV-AAS-3S
###### **1Kor 1,29**
 **οπως** *hopōs* tak aby [[G3704]] [[ADV]] **μη** *mē* nie [[G3361]] [[PRT-N]] **καυχησηται** *kauchēsētai* chlubiłoby się – chełpiłoby się [[G2744]] WTV-ADS-3S **πασα** *pasa* każde [[G3956]] WTA-NSF **σαρξ** *sarks* ciało [[G4561]] [[N-NSF]] **ενωπιον** *enōpion* przed [[G1799]] [[ADV]] **αυτου** *autou* Nim [[G846]] [[P-GSM]]
###### **1Kor 1,30**
 **εξ** *eks* Przez – Dzięki [[G1537]] [[PREP]] **αυτου** *autou* Niego [[G846]] [[P-GSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **υμεις** *hymeis* wy [[G5210]] WTP-2NP **εστε** *este* jesteście [[G2075]] WTV-PXI-2P **εν** *en* w [[G1722]] [[PREP]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM **ος** *hos* który [[G3739]] WTR-NSM **εγενηθη** *egenēthē* stał się [[G1096]] [[V-AOI-3S]] **ημιν** *hēmin* (dla) nas [[G2254]] WTP-1DP **σοφια** *sofia* mądrość [[G4678]] [[N-NSF]] **απο** *apo* od – z [[G575]] [[PREP]] **θεου** *theou* Boga [[G2316]] [[N-GSM]] **δικαιοσυνη** *dikaiosynē* sprawiedliwość [[G1343]] [[N-NSF]] **τε** *te* zarówno [[G5037]] WTPRT **και** *kai* i [[G2532]] [[CONJ]] **αγιασμος** *hagiasmos* poświęcenie – uświęcenie [[G38]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **απολυτρωσις** *apolytrōsis* odkupienie [[G629]] [[N-NSF]]
###### **1Kor 1,31**
 **ινα** *hina* aby [[G2443]] [[CONJ]] **καθως** *kathōs* tak, jak [[G2531]] [[ADV]] **γεγραπται** *gegraptai* jest napisane [[G1125]] WTV-RPI-3S **ο** *ho* [[G3588]] [[T-NSM]] **καυχωμενος** *kauchōmenos* chlubiący się – chełpiący się [[G2744]] WTV-PNP-NSM **εν** *en* w [[G1722]] [[PREP]] **κυριω** *kyriō* Panu [[G2962]] WTN-DSM **καυχασθω** *kauchasthō* niech chlubi się – niech chełpi się [[G2744]] WTV-PNM-3S
