# 2Krl 3 BT5
###### **2Krl 3,1**
 Joram, syn Achaba, objął władzę nad Izraelem w Samarii w osiemnastym roku [panowania] Jozafata, króla judzkiego, i królował dwanaście lat.
###### **2Krl 3,2**
 Czynił on to, co jest złe w oczach Pana, jednakże nie tak bardzo, jak jego ojciec i jego matka, ponieważ usunął stelę Baala, którą sporządził jego ojciec.
###### **2Krl 3,3**
 Przylgnął jednak do grzechu, do którego doprowadził Izraela Jeroboam, syn Nebata, i nie zerwał z nim.
###### **2Krl 3,4**
 Mesza, król Moabu, był hodowcą trzód i dostarczał królowi izraelskiemu sto tysięcy owiec i wełnę ze stu tysięcy baranów.
###### **2Krl 3,5**
 Lecz po śmierci Achaba król Moabu zbuntował się przeciwko królowi izraelskiemu.
###### **2Krl 3,6**
 W tym samym czasie król Joram wyszedł z Samarii i dokonywał przeglądu całego Izraela.
###### **2Krl 3,7**
 Podróżując, polecił oświadczyć Jozafatowi, królowi judzkiemu: «***Król Moabu zbuntował się przeciwko mnie. Czy zechcesz wyruszyć ze mną na wojnę przeciw Moabowi?***» Odpowiedział: «***Wyruszę; ja tak, jak i ty, lud mój, jak i twój lud, konie moje, jak i twoje konie***».
###### **2Krl 3,8**
 A on jeszcze zapytał: «***Którą drogą wyruszymy?***» Odpowiedział: «***Drogą przez pustynię Edomu***».
###### **2Krl 3,9**
 Zatem wyruszyli w drogę: król izraelski, król judzki i król Edomu. Kiedy zaś krążyli po drogach siedem dni, zabrakło wody dla wojska obozującego i dla bydła, które szło za nimi.
###### **2Krl 3,10**
 Wtedy król izraelski zawołał: «***Biada! Albowiem Pan zwołał tych trzech królów, by ich wydać w ręce Moabu***».
###### **2Krl 3,11**
 Jozafat zaś odrzekł: «***Czy tu nie ma proroka Pańskiego, byśmy przez niego mogli zapytać się Pana?***» Odpowiedział jeden ze sług króla izraelskiego: «***Jest tu Elizeusz, syn Szafata, który polewał wodą ręce Eliasza***».
###### **2Krl 3,12**
 Jozafat zaś powiedział: «***Jest z nim słowo Pańskie***». Więc król izraelski, Jozafat, i król Edomu poszli do niego.
###### **2Krl 3,13**
 Elizeusz zaś rzekł do króla izraelskiego: «***Cóż mi do ciebie, a tobie do mnie? Idź do proroków ojca twego i do proroków twojej matki!***» Odpowiedział mu król Izraela: «***Nie! Czyż Pan zwołał tych trzech królów, aby ich wydać w ręce Moabu?***»
###### **2Krl 3,14**
 Elizeusz odrzekł: «***Na życie Pana Zastępów, przed którego obliczem stoję! Gdybym nie miał względu na Jozafata, króla judzkiego, to ani bym na ciebie nie zważał, ani bym na ciebie nie spojrzał.***
###### **2Krl 3,15**
 ***Teraz jednak przyprowadźcie mi harfiarza***». Kiedy zaś harfiarz grał na strunach, spoczęła na Elizeuszu ręka Pańska
###### **2Krl 3,16**
 i powiedział: «***Tak mówi Pan: Wykopcie w tym wąwozie rów przy rowie.***
###### **2Krl 3,17**
 ***Bo tak mówi Pan: Nie zobaczycie wiatru, nie zobaczycie deszczu, a przecież wąwóz ten napełni się wodą i pić będziecie wy, wasze stada i wasze bydło.***
###### **2Krl 3,18**
 ***Lecz jeszcze tego jest mało w oczach Pana, ponieważ wyda On Moab w wasze ręce.***
###### **2Krl 3,19**
 ***Zburzycie wszystkie miasta obwarowane < i wszystkie znaczniejsze miasta >. Wytniecie wszystkie drzewa użyteczne. Zasypiecie wszystkie źródła wód. Wszystkie zaś pola uprawne spustoszycie, narzucając kamieni***».
###### **2Krl 3,20**
 Rano więc – w porze składania ofiar pokarmowych – oto napłynęła woda drogą od strony Edomu, tak iż okolica wypełniła się wodą.
###### **2Krl 3,21**
 Skoro wszyscy Moabici dowiedzieli się, że królowie wyruszyli, aby stoczyć z nimi bitwę, zwołali wszystkich zdolnych do noszenia broni i stanęli na granicy.
###### **2Krl 3,22**
 Kiedy rano wstali, a słońce rozbłysło nad wodami, Moabici ujrzeli z oddali wodę czerwoną jak krew.
###### **2Krl 3,23**
 Powiedzieli więc: «***To krew! Z pewnością królowie powycinali się nawzajem, uderzywszy jeden na drugiego. A teraz, Moabie – po łupy!***»
###### **2Krl 3,24**
 Kiedy przyszli pod obóz Izraela, Izraelici powstali i uderzyli na Moabitów, tak iż ci przed nimi rzucili się do ucieczki. Oni zaś szli naprzód i bili Moabitów.
###### **2Krl 3,25**
 Burzyli miasta. Każdy rzucał kamienie na wszelkie pola uprawne, aby je nimi pokryć. Zasypywali wszystkie źródła wody. Wycinali wszelkie drzewa użyteczne. Wreszcie pozostało tylko Kir-Chareszet. Osaczyli je procarze i rzucali w nie kamieniami.
###### **2Krl 3,26**
 Kiedy król Moabu ujrzał, że nie może sprostać bitwie, wziął ze sobą siedmiuset mężów dobywających miecza, aby przebić się do króla Edomu, lecz nie zdołał.
###### **2Krl 3,27**
 Wtedy wziął swego syna pierworodnego, który miał po nim panować, i złożył go jako ofiarę całopalną na murze. Wówczas wielki gniew nastał u Izraela, tak iż odeszli od niego i wrócili do swojego kraju.
# 2Krl 3 PAU
###### **2Krl 3,1**
 Joram, syn Achaba, został królem Izraela w Samarii w osiemnastym roku rządów Jozafata, króla Judy, i panował dwanaście lat.
###### **2Krl 3,2**
 Czynił on to, co nie podobało się PANU, chociaż nie tak jak jego ojciec i matka. Usunął bowiem posąg Baala, który polecił wykonać jego ojciec.
###### **2Krl 3,3**
 Przylgnął jednak do grzechów Jeroboama, syna Nebata, który nakłonił do grzechów Izraelitów, i nie odstąpił od nich.
###### **2Krl 3,4**
 Mesza, król Moabu, był hodowcą owiec. Składał daninę królowi Izraela w postaci stu tysięcy jagniąt i wełny ze stu tysięcy baranów.
###### **2Krl 3,5**
 Ale po śmierci Achaba król Moabu zbuntował się przeciwko królowi izraelskiemu.
###### **2Krl 3,6**
 Król Joram wyruszył wtedy z Samarii, aby dokonać przeglądu całego Izraela.
###### **2Krl 3,7**
 Przesłał również wiadomość do Jozafata, króla Judy: „Król Moabu zbuntował się przeciwko mnie. Czy pójdziesz ze mną na wojnę przeciw Moabowi?”. „Pójdę!” - odpowiedział. „Postąpię tak jak ty, mój lud jak twój lud, moje konie jak twoje konie.
###### **2Krl 3,8**
 Lecz którą drogą pójdziemy?” - zapytał. „Drogą przez pustynię Edomu” - odparł.
###### **2Krl 3,9**
 Wyruszyli zatem: król Izraela, król Judy i król Edomu. Kiedy po prawie siedmiu dniach marszu zabrakło wody dla wojska i bydła,
###### **2Krl 3,10**
 król Izraela zawołał: „Biada nam! To sam PAN chyba zwołał tych trzech królów, aby ich wydać w ręce Moabitów!”.
###### **2Krl 3,11**
 „Czy nie ma tutaj jakiegoś proroka PANA, przez którego moglibyśmy poradzić się PANA?” - zapytał Jozafat. „Jest tutaj Elizeusz, syn Szafata, który usługiwał Eliaszowi” - odpowiedział jeden ze sług króla izraelskiego.
###### **2Krl 3,12**
 „Ma on słowo PANA” - stwierdził Jozafat. Zatem król Izraela, Jozafat i król Edomu udali się do niego.
###### **2Krl 3,13**
 Elizeusz zaś tak odpowiedział królowi izraelskiemu: „Co ja mam wspólnego z tobą? Idź raczej do proroków twojego ojca i twojej matki”. Na to odparł mu król Izraela: „Nie! Gdyż sam PAN chyba zwołał tych trzech królów, aby ich wydać w ręce Moabitów!”.
###### **2Krl 3,14**
 Elizeusz oświadczył wtedy: „Przysięgam na PANA Zastępów, któremu służę: Gdybym nie miał względu na Jozafata, króla Judy, nawet bym na ciebie nie spojrzał ani nie zwrócił uwagi.
###### **2Krl 3,15**
 A teraz przyprowadźcie mi harfiarza”. Kiedy więc harfiarz grał na instrumencie, moc PANA owładnęła Elizeuszem
###### **2Krl 3,16**
 i zaczął przepowiadać: „Tak mówi PAN: «Zróbcie w tym wąwozie dół obok dołu».
###### **2Krl 3,17**
 Tak bowiem mówi PAN: «Nie zobaczycie wiatru ani deszczu, a ten wąwóz napełni się wodą. I będziecie pić wy, wasze bydło i trzody».
###### **2Krl 3,18**
 Dla PANA jednak jest to sprawa błaha. Dlatego wyda On także w wasze ręce Moabitów.
###### **2Krl 3,19**
 Zburzycie wszystkie większe i obwarowane miasta, zetniecie każde drzewo owocowe, zasypiecie wszystkie źródła wód i zniszczycie pola uprawne, rzucając na nie kamienie”.
###### **2Krl 3,20**
 Rankiem, w porze składania ofiary pokarmowej, ujrzeli, jak wody zaczęły napływać od strony Edomu i cała okolica wypełniła się wodą.
###### **2Krl 3,21**
 Kiedy cały Moab dowiedział się, że królowie wyruszyli na wojnę z nimi, zwołali wszystkich mężczyzn zdolnych do noszenia broni, od najmłodszych do najstarszych, i stanęli na granicy.
###### **2Krl 3,22**
 Następnego ranka wstali bardzo wcześnie. A gdy słońce wzeszło nad wodami, Moabici zobaczyli przed sobą wodę czerwoną jak krew.
###### **2Krl 3,23**
 „To krew” - zawołali. „Na pewno królowie polegli, zabijając jeden drugiego. Teraz więc po łupy, Moabie!”.
###### **2Krl 3,24**
 Kiedy jednak podeszli pod obóz Izraela, Izraelici zaraz ruszyli do ataku na Moabitów, którzy zaczęli uciekać. Wdarli się do Moabu, siejąc w nim spustoszenie:
###### **2Krl 3,25**
 burzyli miasta, każdy kawałek ziemi uprawnej pokryli kamieniami, wszystkie źródła wód zasypali i ścięli każde drzewo owocowe. Pozostały jedynie mury Kir-Chareszet. Ale i ono zostało otoczone i obrzucone kamieniami z proc.
###### **2Krl 3,26**
 Kiedy król Moabu zobaczył, że losy bitwy przechylają się na jego niekorzyść, wziął ze sobą siedmiuset żołnierzy uzbrojonych w miecze, aby przedrzeć się do króla Edomu, ale im się to nie udało.
###### **2Krl 3,27**
 Wtedy wziął swojego syna pierworodnego, który miał być po nim królem, i złożył go na murach obronnych w ofierze całopalnej. Wybuchł wtedy wielki gniew przeciw Izraelitom, którzy odstąpili od króla Moabu i wrócili do swojego kraju.
# 2Krl 3 BP
###### **2Krl 3,1**
 Joram, syn Achaba, został królem Izraela w Samarii w osiemnastym roku [panowania] Jozafata, króla Judy, i panował dwanaście lat.
###### **2Krl 3,2**
 Czynił to, co było złe w oczach Jahwe, chociaż nie tak jak jego ojciec i jego matka. Usunął stelę Baala, którą zrobił jego ojciec.
###### **2Krl 3,3**
 Jednakowoż trwał w grzechach Jeroboama, syna Nebata, który przywiódł Izraela do grzechu, i nie odstąpił od nich.
###### **2Krl 3,4**
 Mesza, król Moabu, był pasterzem. Płacił królowi Izraela [daninę]: sto tysięcy jagniąt oraz sto tysięcy [bogatych] w wełnę baranów.
###### **2Krl 3,5**
 Gdy umarł Achab, król Moabu zbuntował się przeciw królowi Izraela.
###### **2Krl 3,6**
 W owym dniu więc król Joram opuścił Samarię, zrobił przegląd całego Izraela
###### **2Krl 3,7**
 i wyruszył. Posłał [też] do Jozafata, króla Judy, mówiąc: Król Moabu zbuntował się przeciwko mnie. Czy wyruszysz ze mną na wojnę do Moabu? Odpowiedział: Wyruszę. [Jesteśmy jednej myśli] tak ja, jak i ty. Tak mój lud, jak i twój lud, tak moje konie, jak i twoje konie.
###### **2Krl 3,8**
 I zapytał: Którą drogą pójdziemy? [Jozafat] odpowiedział: Drogą edomskiej pustyni.
###### **2Krl 3,9**
 Ruszyli więc, król Izraela, król Judy i król Edomu. Byli w drodze siedem dni i zabrakło wody dla wojska i dla bydła, które szło za nimi.
###### **2Krl 3,10**
 Narzekał więc król Izraela: Ach! Oto Jahwe zwołał tych trzech królów, aby ich wydać w ręce Moabu.
###### **2Krl 3,11**
 Jozafat spytał: Czy nie ma tu proroka Jahwe, abyśmy przez niego zasięgnęli rady Jahwe? Odpowiadając jeden ze sług króla izraelskiego rzekł: Jest tu Elizeusz, syn Szafata, który polewał wodą ręce Eliasza.
###### **2Krl 3,12**
 Jozafat rzekł: On ma słowo Jahwe. I zstąpili do niego: król Izraela, Jozafat i król Edomu.
###### **2Krl 3,13**
 Elizeusz rzekł do króla izraelskiego: Co nas z sobą [łączy]? Idź do proroków twojego ojca i do wieszczków twojej matki. Król zaś Izraela odpowiedział mu: Nie! Oto Jahwe zwołał tych trzech królów, aby ich wydać w ręce Moabu.
###### **2Krl 3,14**
 Elizeusz odparł: Na żyjącego Jahwe Zastępów, któremu służę, gdybym nie zważał na Jozafata, króla Judy, nie spojrzałbym na ciebie, nie widziałbym cię.
###### **2Krl 3,15**
 A teraz przyprowadźcie mi harfiarza. I stało się, gdy harfiarz grał, że spoczęła na nim ręka Jahwe
###### **2Krl 3,16**
 i rzekł: Tak mówi Jahwe: Wykopcie w tym potoku dużo rowów.
###### **2Krl 3,17**
 Albowiem nie zauważycie wiatru, nie zobaczycie deszczu, a potok ten napełni się wodą. Zaspokoicie pragnienie wy, wasze wojsko i wasze bydło.
###### **2Krl 3,18**
 Ale to mało w oczach Jahwe. [On] wyda Moab w wasze ręce.
###### **2Krl 3,19**
 Zburzycie wszystkie warowne miasta i wszystkie znaczniejsze osiedla. Wytniecie wszelkie drzewo dobre, zasypiecie wszystkie źródła wód i spustoszycie każde lepsze pole [narzuciwszy nań] kamieni.
###### **2Krl 3,20**
 I oto rano, w porze składania ofiary pokarmów, od strony Edomu przypłynęła woda. Kraina napełniła się wodą.
###### **2Krl 3,21**
 Wszyscy Moabici usłyszeli, że królowie wyruszyli, aby z nimi walczyć. Zebrali się więc wszyscy zdolni do noszenia broni oraz starsi i obstawiono granice.
###### **2Krl 3,22**
 Wstali rano, gdy słońce wzeszło nad wodami. Moabici zobaczyli z naprzeciwka wodę czerwoną jak krew
###### **2Krl 3,23**
 i zawołali: To jest krew. Na pewno królowie wszczęli walkę i wymordowali jeden drugiego. Teraz więc po łupy, Moabie!
###### **2Krl 3,24**
 Przybyli do obozu izraelskiego, a Izraelici powstali i pobili Moabitów. Poczęli więc uciekać przed nimi. [Izraelici] weszli do ich [kraju] bijąc Moabitów.
###### **2Krl 3,25**
 Zburzyli miasta. Wszystkie lepsze pola obrzucili kamieniami i zasłali je [nimi]. Zasypali wszystkie źródła wód i powalili wszystkie dobre drzewa. Pozostało tylko warowne Kir Chareszet, ale procarze otoczyli je i natarli nań.
###### **2Krl 3,26**
 Gdy król Moabu zobaczył, że nie podoła walce, wziął ze sobą siedmiuset ludzi, uzbrojonych w miecze, aby się przebić do króla Edomu, ale nie mogli.
###### **2Krl 3,27**
 Wziął więc swego pierworodnego syna, który miał po nim panować, i ofiarował go jako całopalenie na murach. Izraelitów ogarnęło wielkie oburzenie. Odstąpili od niego i wrócili do kraju.
# 2Krl 3 BR
###### **2Krl 3,1**
 W osiemnastym roku rządów Jozafata, króla judzkiego, królem izraelskim w Samarii został Joram, syn Achaba. Sprawował władzę przez lat dwanaście.
###### **2Krl 3,2**
 Czynił wszystko, co złe w oczach Jahwe, ale nie aż tak jak jego ojciec i matka; doprowadził on nawet do tego, że usunięto stelę, którą ustawił jego ojciec na cześć Baala.
###### **2Krl 3,3**
 Jednakże naśladował występki syna Nebata, Jeroboama, który cały Izrael doprowadził do grzechów i nie schodził z tej drogi przewrotności.
###### **2Krl 3,4**
 Król Moabu Mesza miał liczne stada i płacił królowi izraelskiemu daninę w postaci stu tysięcy baranów oraz wełny ze stu tysięcy owiec.
###### **2Krl 3,5**
 Po śmierci Achaba król Moabu zbuntował się przeciwko królowi izraelskiemu.
###### **2Krl 3,6**
 Wyszedł tedy z Samarii król Joram i dokonał przeglądu wszystkich sił Izraela.
###### **2Krl 3,7**
 Wyruszywszy w drogę, wysłał swoich ludzi do króla judzkiego, Jozafata, i kazał powiedzieć mu: Król moabicki zbuntował się przeciwko mnie. Czy pójdziesz ze mną na wojnę z Moabem? A Jozafat odpowiedział: Dobrze, pójdę! Chodzi przecież tak o mnie, jak i o ciebie, tak o mój, jak i o twój lud, tak o moje, jak i o twoje konie.
###### **2Krl 3,8**
 I zapytał: Którą drogą ruszamy? A Joram odpowiedział: Drogą na pustynię Edom.
###### **2Krl 3,9**
 Ruszyli zatem: król Izraela, król Judy i król Edomu. Po siedmiu dniach marszu zabrakło wody dla wojska, a także dla wszystkich zwierząt, które szły za wojskiem.
###### **2Krl 3,10**
 Powiedział wtedy król izraelski: Biada nam! Jahwe powołał tych trzech królów, żeby ich wydać w ręce Moabitów!
###### **2Krl 3,11**
 Na to Jozafat rzekł: Czy nie ma tu gdzieś jakiegoś proroka Bożego, żebyśmy mogli zapytać go o radę? Wtedy odezwał się jeden ze sług króla izraelskiego: Jest tu Elizeusz, syn Szafata, który polewał wodą dłonie Eliasza.
###### **2Krl 3,12**
 Powiedział tedy Jozafat: Słowo Jahwe jest z nim. I przyszli do niego: król izraelski, król judzki oraz król Edomu.
###### **2Krl 3,13**
 Zapytał Elizeusz króla izraelskiego: Czego chcesz ode mnie? Idź do proroków twego ojca i do proroków twojej matki! Rzekł mu na to król izraelski: Nie! Widzę bowiem, że Jahwe wezwał tych trzech królów, żeby ich wydać w ręce Moabitów.
###### **2Krl 3,14**
 Powiedział tedy Elizeusz: Na życie Jahwe Zastępów, któremu służę! Gdybym nie miał względu na Jozafata, króla judzkiego, nie zwracałbym żadnej uwagi na ciebie: nawet bym na ciebie nie spojrzał!
###### **2Krl 3,15**
 Przyprowadźcie mi tu zaraz jakiegoś harfiarza. Kiedy harfiarz zaczął grać, ukazała się prawica Jahwe nad Elizeuszem,
###### **2Krl 3,16**
 który powiedział: Oto, co mówi Jahwe: Wykopcie w tej dolinie rów przy rowie.
###### **2Krl 3,17**
 Jahwe mówi bowiem dalej: Nie będziecie czuli ani wichury, ani deszczu, tymczasem ta dolina wypełni się wodą i będziecie pić wy sami, wasze trzody i wszystkie wasze zwierzęta.
###### **2Krl 3,18**
 Ale to jeszcze zbyt mało w oczach Jahwe. On sprawi nadto, że Moabici dostaną się w wasze ręce.
###### **2Krl 3,19**
 Zburzycie wszystkie miasta warowne i co najpiękniejsze osiedla, zniszczycie wszystkie drzewa wydające owoce, zasypiecie wszystkie źródła wód i spustoszycie wszystkie uprawne pola, zarzucając je kamieniami.
###### **2Krl 3,20**
 I rzeczywiście rano, w czasie przeznaczonym na składanie ofiary pokarmowej, drogą od strony Edomu zaczęła płynąć woda, zalewając powoli cały kraj.
###### **2Krl 3,21**
 Tymczasem Moabici, dowiedziawszy się, że królowie zmierzają w ich stronę, żeby ich zaatakować, zwołali wszystkich ludzi zdolnych do noszenia broni i ustawili ich wzdłuż granicy.
###### **2Krl 3,22**
 Wczesnym rankiem, kiedy słońce zaczęło już świecić nad wodą, Moabici zauważyli, że rozlewająca się przed nimi woda jest czerwona jak krew.
###### **2Krl 3,23**
 Zaczęli więc mówić [jedni do drugich]: To przecież krew! Pewnie królowie powybijali się nawzajem! Moabici, ruszajmy po łupy!
###### **2Krl 3,24**
 I udali się w stronę obozu Izraelitów. A wtedy Izraelici powstali i uderzyli na Moabitów, którzy rzucili się do ucieczki, i zapuszczając się coraz dalej w głąb kraju, nękali Moabitów.
###### **2Krl 3,25**
 Burzyli ich miasta, zarzucali kamieniami najżyźniejsze pola, zasypywali wszystkie źródła wody, wycinali drzewa rodzące owoce, tak że na całym obszarze kraju ostał się jedynie Kir-Chareszet. Ci, którzy posługiwali się procami, otoczyli miasto i razili je kamieniami.
###### **2Krl 3,26**
 Kiedy król Moabu zobaczył, że bitwa jest przegrana, wziął ze sobą siedmiuset wojowników, chwycił obnażony miecz i usiłował przedrzeć się do króla Edomu. Zamiar ten jednak się nie powiódł.
###### **2Krl 3,27**
 Wziął tedy swego pierworodnego syna, który miał po nim objąć władzę, i złożył go w ofierze całopalenia na murach [miasta]. Wywołało to wielkie oburzenie wśród Izraelitów. Odstąpili więc od [miasta] króla Moabu i wrócili do swego kraju.
# 2Krl 3 WUJ
###### **2Krl 3,1**
 A Joram syn Achabów królował nad Izraelem w Samariiej roku ośmnastego Jozaphata króla Judzkiego. I królował dwanaście lat.
###### **2Krl 3,2**
 I uczynił złość przed Panem, wszakże nie jako ociec jego i matka: wyrzucił bowiem słupy Baalowe, które był poczynił ociec jego.
###### **2Krl 3,3**
 Wszakoż tkwiał w grzechach Jeroboama syna Nabatowego, który przywiódł w grzech Izraela, ani ich odstąpił.
###### **2Krl 3,4**
 A Mesa król Moab chował wiele bydła, i płacił królowi Izraelskiemu sto tysięcy jagniąt, i sto tysięcy baranów z wełną ich.
###### **2Krl 3,5**
 A gdy umarł Achab, złamał przymierze, które miał z królem Izraelskim.
###### **2Krl 3,6**
 Wyszedł tedy król Joram dnia onego z Samariiej, i popisał wszystkiego Izraela.
###### **2Krl 3,7**
 I posłał do Jozaphata króla Judzkiego, mówiąc: Król Moab odstąpił odemnie, pojedź ze mną przeciw jemu na wojnę. Który odpowiedział: Pojadę: Kto mój jest twój jest: lud mój lud twój, i konie moje konie twoje.
###### **2Krl 3,8**
 I rzekł: Którą drogą pociągniemy? A on odpowiedział: Przez puszczę Idumejską.
###### **2Krl 3,9**
 Ciągnęli tedy król Izraelski i król Judzki, i król Edomski, i krążyli drogą siedmiu dni: a nie było wody dla wojska i dla bydląt, które za nimi szły.
###### **2Krl 3,10**
 I rzekł król Izraelski: Ach, Ach, Ach, zgromadził nas Pan trzech królów, aby wydał w ręce Moab.
###### **2Krl 3,11**
 I rzekł Jozaphat. Jest li tu prorok Pański, żebyśmy prosili Pana przezeń? i odpowiedział jeden z sług króla Izraelskiego: Jest tu Elizeusz syn Saphat: który nalewał wody na ręce Eliaszowe.
###### **2Krl 3,12**
 I rzekł Jozaphat: Jest u niego słowo Pańskie. I stąpił do niego król Izraelski i Jozaphat król Judzki i król Edom.
###### **2Krl 3,13**
 I rzekł Elizeusz do króla Izraelskiego: Co mnie i tobie jest? Idź do proroków ojca twego, i matki twojej. I rzekł mu król Izraelski: Czemu Pan zgromadził tych trzech królów, aby je dał w ręce Moabskie?
###### **2Krl 3,14**
 I rzekł do niego Elizeusz: Żywie Pan zastępów, przed którego oczyma stoję, iż gdybym się oblicza Jozaphata króla Judzkiego, nie wstydał, nie dbałbych o cię, anibych się obejrzał.
###### **2Krl 3,15**
 Lecz teraz przywiedźcie mi gracza. I gdy grał gracz, stała się nad nim ręka Pańska, i rzekł:
###### **2Krl 3,16**
 To mówi Pan: Poczyńcie łoże potoku tego doły i doły.
###### **2Krl 3,17**
 Abowiem to mówi Pan: Nie ujrzycie wiatru ani deszczu: a łoże to napełni się wody, i będziecie pić wy, i czeladź wasza, i bydlęta wasze.
###### **2Krl 3,18**
 A mało to jeszcze w oczach Pańskich: nad to da też Moab w ręce wasze.
###### **2Krl 3,19**
 I zburzycie wszelkie miasto obronne, i wszelkie miasto wyborne, a wszelkie drzewo pożyteczne porąbiecie, i wszystkie źródła wód zatkacie i wszelką rolą wyborną kamieniem okryjecie.
###### **2Krl 3,20**
 I stało się rano, gdy jest zwyczaj ofiarę sprawować, alić oto wody przychodziły drogą Edomską, i napełniła się ziemia wodami.
###### **2Krl 3,21**
 A wszyscy Moabitowie, usłyszawszy iż ciągnęli królowie walczyć przeciwko im, zwołali wszystkie pasem rycerskim przepasane po wierzchu, i stanęli na granicach.
###### **2Krl 3,22**
 A wstawszy barzo rano, i gdy już słońce weszło przeciwko wodom, ujrzeli Moabitowie na przeciwko wody czerwone jako krew,
###### **2Krl 3,23**
 I rzekli: Krew miecza jest: stoczyli bitwę przeciw sobie królowie i pobici są jeden od drugiego: teraz bież do korzyścią Moab.
###### **2Krl 3,24**
 I przyszli do obozu Izraelskiego: a wstawszy Izrael poraził Moab: a oni uciekli przed nimi: Przyszli tedy, którzy byli zwyciężyli, i porazili Moabity,
###### **2Krl 3,25**
 I miasta zburzyli: i wszelką rolą co lepszą, ciskając każdy kamienie napełnili: i wszystkie źródła wód zatkali: i wszystkie drzewa pożyteczne wycięli, tak, iż tylko mury gliniane zostały: i obtoczone jest miasto od procników i po wielkiej części zburzone.
###### **2Krl 3,26**
 Co gdy ujrzał król Moabski, to jest, że nieprzyjaciele przemogli, wziął z sobą siedmset mężów miecza dobywających: aby się przebili do króla Edom, a nie mogli:
###### **2Krl 3,27**
 I porwawszy syna swego pierworodnego, który miał królować miasto niego, ofiarował całopalenie na murze: i stało się zagniewanie wielkie w Izraelu, i zaraz odciągnęli od niego, i wrócili się do ziemie swojej.
