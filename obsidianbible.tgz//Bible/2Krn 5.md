# 2Krn 5 BT5
###### **2Krn 5,1**
 Tak ukończono całą robotę, której dokonał Salomon w świątyni Pańskiej. Potem Salomon przyniósł i umieścił w skarbcu domu Bożego święte dary swego ojca, Dawida: srebro, złoto i wszystkie sprzęty.
###### **2Krn 5,2**
 Wtedy też Salomon zwołał starszyznę Izraela i wszystkich naczelników pokoleń, przywódców rodów Izraelitów, do Jerozolimy, na przeniesienie Arki Przymierza Pańskiego z Miasta Dawidowego, czyli z Syjonu.
###### **2Krn 5,3**
 Zebrali się więc u króla wszyscy Izraelici na święto, siódmego miesiąca.
###### **2Krn 5,4**
 Kiedy przyszła cała starszyzna Izraela, lewici wzięli arkę
###### **2Krn 5,5**
 i wnieśli ją oraz Namiot Spotkania i wszystkie święte sprzęty, jakie były w namiocie. Przenieśli je kapłani oraz lewici.
###### **2Krn 5,6**
 Król zaś Salomon i cała społeczność Izraela, zgromadzona przy nim przed arką, składali w ofierze drobne i większe bydło, którego nie rachowano i nie obliczono z powodu wielkiej ilości.
###### **2Krn 5,7**
 Następnie kapłani wnieśli Arkę Przymierza Pańskiego na jej miejsce do sanktuarium świątyni, to jest do Miejsca Najświętszego, pod skrzydła cherubów,
###### **2Krn 5,8**
 a cheruby miały tak rozpostarte skrzydła nad miejscem zajmowanym przez arkę, że okrywały arkę i jej drążki z wierzchu.
###### **2Krn 5,9**
 Drążki te były tak długie, że ich końce były widoczne przed sanktuarium spoza arki, z zewnątrz jednak nie były widoczne. Pozostają one tam aż do dnia dzisiejszego.
###### **2Krn 5,10**
 W arce zaś nie było nic oprócz dwóch tablic, które Mojżesz tam złożył pod Horebem, gdy Pan zawarł przymierze z Izraelitami w czasie ich wyjścia z Egiptu.
###### **2Krn 5,11**
 Kiedy wyszli kapłani z Miejsca Świętego – gdyż wszyscy znajdujący się [tam] kapłani oczyścili się, nie przestrzegając podziału na zmiany –
###### **2Krn 5,12**
 wszyscy lewici śpiewający: Asaf, Heman, Jedutun, ich synowie i bracia, ubrani w bisior, stali na wschód od ołtarza, [grając] na cymbałach, harfach i cytrach, a z nimi stu dwudziestu kapłanów grających na trąbach –
###### **2Krn 5,13**
 kiedy tak zgodnie, wszyscy jak jeden, trąbili i śpiewali, tak iż słychać było tylko jeden głos wysławiający majestat Pana, kiedy podnieśli głos wysoko przy wtórze trąb, cymbałów i instrumentów muzycznych, chwaląc Pana, że jest dobry i że na wieki Jego łaska, świątynia napełniła się obłokiem chwały Pańskiej,
###### **2Krn 5,14**
 tak iż nie mogli kapłani tam pozostać i pełnić swej służby z powodu tego obłoku, bo chwała Pańska wypełniła świątynię Bożą.
# 2Krn 5 PAU
###### **2Krn 5,1**
 W ten sposób zostało dokończone dzieło budowy domu PANA podjęte przez Salomona. Następnie Salomon polecił przynieść poświęcone przedmioty ofiarowane przez jego ojca Dawida, ponadto srebro, złoto oraz sprzęty liturgiczne i złożył je w skarbcu domu Bożego.
###### **2Krn 5,2**
 Wtedy Salomon wezwał do Jerozolimy starszych Izraela, wszystkich przywódców plemion i głowy rodzin izraelskich, aby uczestniczyli w przeniesieniu Arki Przymierza PANA z Miasta Dawida, to jest z Syjonu.
###### **2Krn 5,3**
 W siódmym miesiącu roku zgromadzili się wszyscy Izraelici u króla, aby razem z nim obchodzić święto.
###### **2Krn 5,4**
 Kiedy przybyli wszyscy starsi Izraela, lewici wzięli arkę
###### **2Krn 5,5**
 i razem z kapłanami przenieśli zarówno arkę, jak i Namiot Spotkania oraz wszystkie święte przedmioty, znajdujące się w Namiocie.
###### **2Krn 5,6**
 Król Salomon wraz z całą wspólnotą Izraela, zgromadzoną wokół niego przed arką, składał w ofierze owce i woły, których w ogóle nie liczono z powodu ogromnej ich liczby.
###### **2Krn 5,7**
 Następnie kapłani wnieśli arkę Przymierza PANA na przygotowane dla niej miejsce w najbardziej wewnętrznej części domu, to jest w miejscu najświętszym, pod skrzydła cherubów.
###### **2Krn 5,8**
 Skrzydła cherubów były rozpostarte nad miejscem, gdzie postawiono arkę, tak że okrywały z góry zarówno arkę, jak i drążki do jej przenoszenia.
###### **2Krn 5,9**
 Same drążki były tak długie, że można było zobaczyć ich końce z miejsca świętego tuż przed miejscem najświętszym, ale z zewnątrz nie były widoczne. Są one tam do dnia dzisiejszego.
###### **2Krn 5,10**
 W arce nie było nic prócz dwóch tablic, które Mojżesz włożył do niej na Horebie, gdzie PAN zawarł z Izraelitami przymierze po ich wyjściu z Egiptu.
###### **2Krn 5,11**
 Kapłani wyszli z miejsca świętego. Niezależnie od przynależności do oddziałów, wszyscy znajdujący się tam kapłani oczyścili się.
###### **2Krn 5,12**
 Obecni byli wszyscy lewici śpiewacy: Asaf, Heman, Jedutun i ich synowie oraz członkowie ich rodów. Ubrani w szaty z bisioru, trzymając cymbały, cytry i liry, stali po wschodniej stronie ołtarza razem ze stu dwudziestoma kapłanami, którzy dęli w trąby.
###### **2Krn 5,13**
 Grali i śpiewali, wysławiając i wychwalając PANA jednym głosem. Gdy wznieśli swój głos przy wtórze trąb, cymbałów i innych instrumentów, wychwalając PANA, bo jest dobry, bo Jego miłosierdzie trwa na wieki, wtedy obłok wypełnił dom PANA.
###### **2Krn 5,14**
 Kapłani nie mogli więc dalej spełniać swojej posługi ze względu na obłok, gdyż chwała PANA wypełniła Boży dom.
# 2Krn 5 BP
###### **2Krn 5,1**
 I tak dobiegły końca wszelkie prace, jakie wykonał Salomon dla Domu Jahwe. Następnie przyniósł on i złożył w skarbcu Domu Bożego wszystkie święte dary, które ofiarował jego ojciec, Dawid: złoto, srebro i przeróżne naczynia.
###### **2Krn 5,2**
 Zwołał następnie Salomon do Jeruzalem starszyznę Izraela, wszystkich naczelników pokoleń i przełożonych rodów izraelskich, na [uroczystość] przeniesienia Arki Przymierza Jahwe z Miasta Dawidowego, czyli z Syjonu.
###### **2Krn 5,3**
 W uroczyste święto siódmego miesiąca zgromadzili się przy królu wszyscy Izraelici.
###### **2Krn 5,4**
 Gdy zebrała się cała starszyzna Izraela, lewici wzięli Arkę.
###### **2Krn 5,5**
 Kapłani i lewici przenieśli więc Arkę, Namiot Zjednocznia i wszystkie święte przedmioty, jakie były w Namiocie.
###### **2Krn 5,6**
 Król Salomon wraz z całą społecznością Izraela, która zebrała się przy nim przed Arką, złożył w ofierze owce i woły w takiej ilości, że nie można ich było zliczyć ani opisać.
###### **2Krn 5,7**
 Wnieśli więc kapłani Arkę Przymierza Jahwe na jej miejsce do Przybytku Domu Świętego, do miejsca Najświętszego, pod skrzydła cherubów.
###### **2Krn 5,8**
 Cheruby bowiem rozpościerały skrzydła nad miejscem Arki i nakrywały z góry Arkę oraz jej drążki.
###### **2Krn 5,9**
 Owe drążki były tak długie, że końce ich widać było z miejsca Świętego przed miejscem Najświętszym, ale z zewnątrz nie były widoczne. Pozostają tam aż po dzień dzisiejszy.
###### **2Krn 5,10**
 W Arce nie było nic oprócz dwóch tablic, które w niej złożył Mojżesz na Chorebie, gdy Jahwe zawierał Przymierze z synami Izraela po ich wyjściu z Egiptu.
###### **2Krn 5,11**
 Gdy kapłani wyszli z miejsca Świętego - wszyscy bowiem kapłani, którzy tylko byli obecni, poświęcili się, nie przestrzegając podziału na zmiany -
###### **2Krn 5,12**
 a wszyscy lewici-śpiewacy: Asaf, Heman i Jedutun, ich synowie i bracia odziani w bisior stali po wschodniej stronie ołtarza [grając] na cymbałach, harfach i cytrach, a z nimi było stu dwudziestu kapłanów grających na trąbach -
###### **2Krn 5,13**
 taka zaś zgodność panowała między tymi, co grali na trąbach, a tymi, co śpiewali, że słychać było jakby jeden głos sławiący i wychwalający Jahwe - gdy jeszcze głośniej grali na trąbach, cymbałach oraz innych instrumentach muzycznych i chwalili Jahwe, że jest dobry, że na wieki [trwa] miłosierdzie Jego, Świątynia napełniała się obłokiem Chwały Jahwe.
###### **2Krn 5,14**
 I nie mogli tam pozostać kapłani, by dopełnić swej służby, z powodu obłoku, gdyż Chwała Jahwe wypełniała Dom Boży.
# 2Krn 5 BR
###### **2Krn 5,1**
 I tak zostały zakończone wszystkie prace, które Salomon podjął w świątyni Jahwe. Przyniósł też Salomon to wszystko. co ofiarował na świątynię jego ojciec, Dawid, a także wszelkie srebro, złoto oraz wszystkie naczynia. Wszystko to umieszczono w skarbcach świątynnych.
###### **2Krn 5,2**
 Zwołał wtedy Salomon do Jerozolimy starszych Izraela i wszystkich przywódców pokoleń oraz naczelników rodów izraelskich, żeby przenieść arkę Jahwe z Miasta Dawidowego, to jest z Syjonu (do świątyni).
###### **2Krn 5,3**
 Zgromadzili się więc wszyscy synowie Izraela u króla, żeby wziąć udział w uroczystościach, które zostały wyznaczone na miesiąc siódmy.
###### **2Krn 5,4**
 Gdy już przyszli na miejsce, synowie Lewiego przystąpili do przenoszenia arki.
###### **2Krn 5,5**
 Niesiono samą arkę, a prócz tego Namiot Spotkania i wszystkie święte sprzęty znajdujące się w namiocie. Nieśli to wszystko kapłani i lewici.
###### **2Krn 5,6**
 Na samym przedzie, przed arką, szedł król Salomon oraz wszyscy synowie Izraela zebrani wokół niego. Składali oni tak wiele ofiar z owiec i cielców, że nikt nie był w stanie ich policzyć.
###### **2Krn 5,7**
 Kapłani przynieśli Arkę Przymierza Jahwe do świątyni, wprowadzili do Świętego Świętych i umieścili pod skrzydłami cherubów.
###### **2Krn 5,8**
 Cheruby miały skrzydła rozpostarte nad miejscem przeznaczonym dla arki i okrywały nimi zarówno arkę, jak i drążki do jej przenoszenia.
###### **2Krn 5,9**
 Drążki były tak długie, że ich końce wystawały poza Święte Świętych; z zewnątrz jednak nie było ich widać. Pozostają tam aż do dnia dzisiejszego.
###### **2Krn 5,10**
 W arce nie było nic oprócz dwóch tablic, które złożył w niej Mojżesz, gdy na górze Horeb Jahwe zawarł przymierze z synami Izraela po ich wyjściu z Egiptu.
###### **2Krn 5,11**
 Potem kapłani wyszli ze Świętego Świętych (wszyscy tam weszli), bo wszyscy, nie przestrzegając podziału na klasy poddali się oczyszczeniu.
###### **2Krn 5,12**
 Wszyscy zaś lewici-śpiewacy: Asaf, Heman, Jedutun, ich synowie i bracia, ubrani w bisior, stali z cymbałami, cytrami i harfami po wschodniej stronie ołtarza. Obok nich znajdowało się stu dwudziestu kapłanów, którzy grali na trąbach.
###### **2Krn 5,13**
 Kiedy tylko zabrzmiały ich trąby i dał się słyszeć śpiew zestrojony w jeden głos wdzięczności i chwały na cześć Jahwe, dołączyły do tego inne trąby, cymbały i pozostałe instrumenty muzyczne. Wszyscy uwielbiali Jahwe, wołając: Dobry jest, a miłosierdzie Jego na wieki. I w jednej chwili świątynię Jahwe wypełnił obłok chwały Pańskiej.
###### **2Krn 5,14**
 Kapłani nie mogli już dłużej pozostać wewnątrz, żeby sprawować swoją służbę, bo wszystko przenikał obłok. Chwała Jahwe wypełniła bowiem całą świątynię Bożą.
# 2Krn 5 WUJ
###### **2Krn 5,1**
 Wniósł tedy Salomon wszystko co był ślubował Dawid ociec jego, srebro i złoto, i wszystkie naczynia włożył do skarbu domu Bożego.
###### **2Krn 5,2**
 Potem zebrał starsze z Izraela, i wszystkie książęta pokolenia, i głowy domów z synów Izraelskich do Jeruzalem, aby przeprowadzili skrzynię przymierza Pańskiego z miasta Dawidowego, które jest Sion.
###### **2Krn 5,3**
 Przyszli tedy do króla wszyscy mężowie Izraelscy w święto uroczyste miesiąca siódmego.
###### **2Krn 5,4**
 A gdy przyszli wszyscy starszy Izraelscy, nieśli Lewitowie skrzynię.
###### **2Krn 5,5**
 I wnieśli ją i wszystko zgotowanie przybytku. I naczynie świątnice, które były w przybytku, nieśli kapłani z Lewitami.
###### **2Krn 5,6**
 A król Salomon, i wszystko zgromadzenie Izraelskie, i wszyscy, którzy byli zgromadzeni przed skrzynię, ofiarowali barany, i woły, bez wszelkiej liczby: bo tak wielkie było mnóstwo ofiar.
###### **2Krn 5,7**
 I wnieśli kapłani skrzynię przymierza Pańskiego na miejsce jej, to jest do wyrocznice kościelnej, do świętego świętych, pod skrzydła Cherubim:
###### **2Krn 5,8**
 Tak iż Cherubim rozciągali skrzydła swe nad miejscem, na którem była postawiona skrzynia, i samę skrzynię okrywali z drążkami jej.
###### **2Krn 5,9**
 A drążków, na których noszono skrzynię, iż przy dłuższym były końce, widać było przed wyrocznicą: a jeśli kto maluczko był zewnątrz, widzieć ich nie mógł. Była tedy tam skrzynia aż do dnia tego.
###### **2Krn 5,10**
 A w skrzyni nic inszego nie było, jedno dwie tablice, które był włożył Mojżesz na Horeb, gdy Pan dał zakon synom Izraelowym wychodzącym z Egiptu.
###### **2Krn 5,11**
 A gdy wyszli kapłani z świątnice (bo wszyscy kapłani, którzy się tam naleźć mogli poświęceni byli: i jeszcze na on czas, przemiany i porządek posług między nimi nie był podzielony).
###### **2Krn 5,12**
 Tak Lewitowie jako i śpiewacy, to jest i ci, którzy pod Asaph byli, i którzy pod Emon i którzy pod Idithun, synowie i bracia ich, obleczeni w szaty bisiorowe, na cymbalech, na arfach, i na cytrach grali, stojąc na wschodnią stronę u ołtarza, a przy nich kapłanów sto i dwadzieścia trąbiących w trąby.
###### **2Krn 5,13**
 Gdy tedy wszyscy pospołu i na trąbach i głosem, i na cymbalech, i na organach, i rozmaici muzycy grali, i głos wysoko podnosili, dźwięk daleko słychać było, tak, iż gdy poczęli Pana chwalić i mówić: Wyznawajcie Panu, iż dobry, iż na wieki miłosierdzie jego: dom Boży napełnion był obłokiem,
###### **2Krn 5,14**
 I nie mogli kapłani stać i służyć przede mgłą. Abowiem chwała Pańska napełniła była dom Boży.
