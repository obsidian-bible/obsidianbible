# Ga 6 BT5
###### **Ga 6,1**
 Bracia, a gdyby komuś przydarzył się jakiś upadek, wy, którzy pozostajecie pod działaniem Ducha, w duchu łagodności sprowadźcie takiego na właściwą drogę. Bacz jednak, abyś i ty nie uległ pokusie.
###### **Ga 6,2**
 Jeden drugiego brzemiona noście i tak wypełniajcie prawo Chrystusowe.
###### **Ga 6,3**
 Bo kto uważa, że jest czymś, gdy jest niczym, ten zwodzi samego siebie.
###### **Ga 6,4**
 Niech każdy bada własne postępowanie, a wtedy powód do chluby znajdzie tylko w sobie samym, a nie w drugim.
###### **Ga 6,5**
 Każdy bowiem poniesie własny ciężar.
###### **Ga 6,6**
 Ten, kto pobiera naukę, niech użycza ze wszystkich swoich dóbr temu, kto go naucza.
###### **Ga 6,7**
 Nie łudźcie się:
###### **Ga 6,8**
 Bóg nie pozwoli z siebie szydzić. A co człowiek sieje, to i żąć będzie: kto sieje w ciele swoim, jako plon ciała zbierze zagładę; kto sieje w duchu, jako plon ducha zbierze życie wieczne.
###### **Ga 6,9**
 W czynieniu dobra nie ustawajmy, bo gdy pora nadejdzie, będziemy zbierać plony, o ile w pracy nie ustaniemy.
###### **Ga 6,10**
 A zatem, dopóki mamy czas, czyńmy dobrze wszystkim, zwłaszcza zaś naszym braciom w wierze.
###### **Ga 6,11**
 Przypatrzcie się, jak wielkie litery własnoręcznie stawiam ze względu na was.
###### **Ga 6,12**
 O ludzkie względy ubiegają się ci wszyscy, którzy was zmuszają do obrzezania; chcą mianowicie uniknąć prześladowania z powodu krzyża Chrystusowego.
###### **Ga 6,13**
 Bo ci zwolennicy obrzezania zgoła się nie troszczą o zachowanie Prawa, a o wasze obrzezanie zabiegają tylko dlatego, by się móc pochwalić waszym ciałem.
###### **Ga 6,14**
 Co do mnie, to nie daj Boże, bym się miał chlubić z czego innego, jak tylko z krzyża Pana naszego, Jezusa Chrystusa, dzięki któremu świat stał się ukrzyżowany dla mnie, a ja dla świata.
###### **Ga 6,15**
 Bo ani obrzezanie nic nie znaczy, ani nieobrzezanie, tylko nowe stworzenie.
###### **Ga 6,16**
 Na wszystkich tych, którzy się tej zasady trzymać będą, i na Izraela Bożego [niech zstąpi] pokój i miłosierdzie!
###### **Ga 6,17**
 Odtąd niech już nikt nie sprawia mi przykrości: przecież ja na ciele swoim noszę blizny, znamię przynależności do Jezusa.
###### **Ga 6,18**
 Łaska Pana naszego, Jezusa Chrystusa, niech będzie z duchem waszym, bracia! Amen.
# Ga 6 PAU
###### **Ga 6,1**
 Bracia, nawet jeśli ktoś popadnie w grzech, wy, którzy trwacie w Duchu, podźwignijcie go z całą łagodnością. Uważaj jednak, abyś i ty nie uległ pokusie.
###### **Ga 6,2**
 Jedni drugim noście brzemiona, a tak wypełnicie prawo Chrystusa.
###### **Ga 6,3**
 Jeśli ktoś sądzi, że jest kimś ważnym, podczas gdy nim nie jest, sam siebie oszukuje.
###### **Ga 6,4**
 Każdy niech osądza swoje czyny i w sobie niech znajduje powód do chluby, a nie w porównywaniu się z innymi.
###### **Ga 6,5**
 Każdy bowiem poniesie swój własny ciężar.
###### **Ga 6,6**
 Uczący się Ewangelii niech się dzieli wszelkim dobrem z nauczycielem.
###### **Ga 6,7**
 Nie łudźcie się! Bóg nie pozwoli z siebie szydzić! Co człowiek posieje, to będzie zbierać.
###### **Ga 6,8**
 Kto sieje w ciele, zbierze to, co przynosi ciało - zagładę. Kto natomiast sieje w Duchu, zbierze to, co daje Duch - życie wieczne.
###### **Ga 6,9**
 Nie ustawajmy w czynieniu dobra. W odpowiednim czasie zbierzemy plon, jeśli teraz niczego nie zaniedbamy.
###### **Ga 6,10**
 Dopóki mamy okazję, czyńmy dobrze wszystkim, zwłaszcza tym, którzy są nam bliscy w wierze.
###### **Ga 6,11**
 Popatrzcie, jak wielkimi literami własnoręcznie napisałem do was.
###### **Ga 6,12**
 Ci, którzy pragną podobać się przez zewnętrzne znaki przestrzegania Prawa, zobowiązują was do obrzezania, aby tylko uniknąć prześladowań z powodu krzyża Chrystusa.
###### **Ga 6,13**
 Jako obrzezani sami nie zachowują Prawa, ale domagają się waszego obrzezania, aby się mogli chlubić waszym ciałem.
###### **Ga 6,14**
 Co do mnie, obym nie chlubił się niczym innym, jak tylko krzyżem Pana naszego Jezusa Chrystusa, przez którego świat jest ukrzyżowany dla mnie, a ja dla świata.
###### **Ga 6,15**
 Obrzezanie bowiem nic nie znaczy ani nieobrzezanie, tylko nowe stworzenie.
###### **Ga 6,16**
 Na tych, którzy tej zasady będą się trzymać, i na Izraela Bożego niech zstąpi pokój i miłosierdzie.
###### **Ga 6,17**
 Na przyszłość niech nikt nie dodaje mi udręk, ponieważ na swoim ciele noszę znaki przynależności do Jezusa.
###### **Ga 6,18**
 Bracia! Łaska naszego Pana Jezusa Chrystusa niech będzie z waszym duchem. Amen.
# Ga 6 BP
###### **Ga 6,1**
 Bracia, a jeśli ktoś niebacznie popełni jakieś wykroczenie, wówczas wy, obdarzeni łaską Ducha, sprowadźcie takiego na prawą drogę w duchu łagodności. Uważaj jednak sam, byś nie uległ pokusie.
###### **Ga 6,2**
 Dźwigajcie jedni drugich ciężary, a w ten sposób wypełnicie prawo Chrystusa.
###### **Ga 6,3**
 Jeśli bowiem ktoś sądzi, że coś znaczy - choć niczym nie jest - ten okłamuje samego siebie.
###### **Ga 6,4**
 Niech każdy osądza swoje własne dzieło, a wówczas tylko sobą samym chlubić się będzie, a nie kimś innym.
###### **Ga 6,5**
 Każdy bowiem poniesie własny ciężar.
###### **Ga 6,6**
 Otrzymujący zaś naukę niech dzieli się wszystkimi dobrami z tym, który go naucza.
###### **Ga 6,7**
 Nie łudźcie się, Bóg pozwala szydzić z siebie. Co człowiek posieje, to będzie zbierał.
###### **Ga 6,8**
 Bo kto wsiewa w rolę ciała swego, z ciała tego zbierać będzie zgubę. Kto zaś wsiewa w rolę ducha, z ducha tego zbierać będzie życie wieczne.
###### **Ga 6,9**
 Czyniąc dobrze nie zniechęcajmy się. Nie ulegając bowiem zniechęceniu, będziemy zbierać owoc we właściwym czasie.
###### **Ga 6,10**
 Dopóki więc mamy czas, czyńmy dobrze wszystkim, a szczególnie braciom tej samej wiary.
###### **Ga 6,11**
 Zobaczcie, jak wielkimi literami napisałem do was - moją własną ręką.
###### **Ga 6,12**
 Ci, którzy pragną przypodobać się ludziom, zmuszają was do obrzezania po to, aby nie cierpieć prześladowania z powodu krzyża Chrystusa.
###### **Ga 6,13**
 Zwolennicy obrzezania nie troszczą się o zachowanie Prawa, lecz dlatego chcą was poddać obrzezaniu, aby się chlubić waszym ciałem.
###### **Ga 6,14**
 Ja natomiast chcę jedynie chlubić się krzyżem naszego Pana, Jezusa Chrystusa, dzięki któremu świat stał się dla mnie ukrzyżowany, a ja dla świata.
###### **Ga 6,15**
 Ani bowiem obrzezanie nic nie znaczy, ani brak jego. Liczy się jedynie nowe stworzenie.
###### **Ga 6,16**
 A na tych, którzy tą normą się kierują, i na Izraela, naród Boga, niech zstąpi pokój i miłosierdzie.
###### **Ga 6,17**
 Niech odtąd nikt nie wyrządza mi przykrości, bo ja noszę w sobie znamiona Jezusa!
###### **Ga 6,18**
 Bracia, niech łaska naszego Pana, Jezusa Chrystusa, będzie z duchem waszym. Amen.
# Ga 6 BR
###### **Ga 6,1**
 Bracia, gdy przydarzy się komuś jakiś upadek, to wy, którzy pozostajecie pod działaniem Ducha [Świętego], w duchu łagodności zechciejcie sprowadzić takiego na właściwą drogę. Niech każdy jednak uważa, żeby i sam nie uległ pokusie.
###### **Ga 6,2**
 Jedni drugich ciężary noście, bo tak postępując wypełnicie nakazy Chrystusa.
###### **Ga 6,3**
 Jeżeli ktoś sądzi, że jest kimś [niezwykłym], podczas gdy w rzeczywistości jest niczym, to oszukuje siebie samego.
###### **Ga 6,4**
 Niech każdy bada własne postępowanie; jeśli znajdzie jakiś powód do chluby, to tylko wobec siebie samego, a nie wobec drugich.
###### **Ga 6,5**
 Każdy bowiem poniesie [kiedyś] własny ciężar.
###### **Ga 6,6**
 Ten, kto naucza, ma prawo uczestniczyć w dobrach materialnych swoich uczniów.
###### **Ga 6,7**
 Nie łudźcie się: Bóg nie pozwoli, by z Niego szydzono. Co człowiek sobie zasieje, to też będzie zbierał.
###### **Ga 6,8**
 Kto sieje to, co odpowiada pożądliwościom jego ciała, temu pożądliwości zgotują żniwo w postaci śmierci. Lecz jeśli będzie siał to, co podoba się Duchowi [Świętemu], w czasie żniwa Duch da mu w nagrodę życie wieczne.
###### **Ga 6,9**
 Nie ustawajmy w czynieniu dobra, jeżeli bowiem nie zaniechamy naszych trudów, to gdy nadejdzie czas żniwa, będziemy zbierali plony.
###### **Ga 6,10**
 Tak więc póki jeszcze mamy czas, czyńmy dobrze wszystkim, a zwłaszcza naszym braciom w wierze.
###### **Ga 6,11**
 A teraz przypatrzcie się, jakie to wielkie litery kreślę sam własnoręcznie ze względu na was!
###### **Ga 6,12**
 [Jeszcze raz powtarzam:] o ludzkie względy jedynie zabiegają ci, którzy pragną was nakłonić do obrzezania. Ostatecznie zaś chodzi im o to, żeby uniknąć prześladowań z powodu krzyża Chrystusowego.
###### **Ga 6,13**
 Tymczasem ludzie, którzy poddają się obrzezaniu, sami nie przestrzegają Prawa. O wasze obrzezanie zaś zabiegają tylko dlatego, żeby mogli się chełpić przed innymi, że tak oto naznaczyli wasze ciała.
###### **Ga 6,14**
 Lecz ja nie pragnę się chlubić niczym poza krzyżem Pana naszego Jezusa Chrystusa. Na Jego krzyżu świat został ukrzyżowany dla mnie, a ja dla świata.
###### **Ga 6,15**
 Nie ma bowiem żadnego znaczenia to, czy się jest obrzezanym, czy nie. Ważne jest jedynie to, żeby być nowym stworzeniem.
###### **Ga 6,16**
 Na wszystkich tych, którzy będą się trzymać powyższego stwierdzenia - na nich i na całego Izraela Bożego - niech zstąpi pokój i miłosierdzie.
###### **Ga 6,17**
 Niech mi już na przyszłość nikt nie wyrządza żadnych przykrości: przecież na ciele moim noszę blizny [i one najlepiej świadczą o moim przynależeniu do] Jezusa.
###### **Ga 6,18**
 Łaska Pana naszego Jezusa Chrystusa niech będzie z duchem waszym, bracia! Amen.
# Ga 6 WUJ
###### **Ga 6,1**
 Bracia, jeśliby też człowiek ubieżony był w jakim upadku, wy, którzy duchowni jesteście, nauczajcie takiego w duchu cichości: obaczając samego siebie, abyś i ty nie był kuszon.
###### **Ga 6,2**
 Jeden drugiego brzemiona noście: a tak wypełnicie zakon Chrystusów.
###### **Ga 6,3**
 Abowiem, jeśli kto mniema, żeby czem był, gdyż niczem nie jest, sam siebie oszukawa.
###### **Ga 6,4**
 A Każdy niech sprawy swojej doświadcza, a tak w samym sobie tylko przechwalanie mieć będzie: a nie we drugim.
###### **Ga 6,5**
 Bo każdy własne brzemię poniesie.
###### **Ga 6,6**
 A niech użycza wszystkich dóbr ten, który bywa nauczan w słowie, temu, który go naucza.
###### **Ga 6,7**
 Nie błądźcie: nie da się Bóg z siebie naśmiewać. Abowiem co będzie siał człowiek, to też będzie żął.
###### **Ga 6,8**
 Bo kto sieje na swem ciele, z ciała też żąć będzie skażanie: a kto sieje na duchu, z ducha żąć będzie żywot wieczny.
###### **Ga 6,9**
 A dobrze czyniąc nie ustawajmy: abowiem czasu swego żąć będziemy, nie ustawając.
###### **Ga 6,10**
 A przeto póki czas mamy, czyńmy dobrze wszystkim, a nawięcej domownikom wiary.
###### **Ga 6,11**
 Baczcie jakim wam list pisał ręką moją.
###### **Ga 6,12**
 Abowiem którzykolwiek chcą się podobać w ciele, ci was przymuszają obrzezować się, tylko, aby krzyża, Chrystusowego prześladowania nie cierpieli.
###### **Ga 6,13**
 Abowiem ani którzy się obrzezają, zakonu nie zachowywają. Ale chcą, abyście się wy obrzezali: żeby się z ciała waszego chlubili.
###### **Ga 6,14**
 A ja nie daj Boże, abym się chlubić miał, jeden w krzyżu Pana naszego Jezusa Chrystusa, przez którego mnie świat jest ukrzyżowan, a ja światu.
###### **Ga 6,15**
 Abowiem w Chrystusie Jezusie nic nie waży, ani obrzezanie, ani odrzezek, ale nowe stworzenie.
###### **Ga 6,16**
 A którzykołwiek tego prawidła dzierżeć się będą, pokój nad nimi, i miłosierdzie, i nad Izraelem Bożym.
###### **Ga 6,17**
 Nawet niech mi się żaden nie przykrzy. Abowiem ja piątna Pana Jezusowe na ciele mojem noszę.
###### **Ga 6,18**
 Łaska Pana naszego Jezusa Chrystusa, z duchem waszym bracia, Amen.1
# Ga 6 STERN
###### **Ga 6,1**
 Bracia, przypuśćmy, że przyłapano kogoś na czymś złym. Wy, którzy macie Ducha, powinniście sprowadzić go na dobrą drogę, ale w duchu pokory, uważając na samych siebie, żebyście i wy nie byli kuszeni.
###### **Ga 6,2**
 Noście wzajemnie swoje ciężary - w ten właśnie sposób będziecie wypełniać prawdziwy sens Tory, któremu moc nadaje Mesjasz.
###### **Ga 6,3**
 Bo jeśli ktoś sądzi, że jest czymś, a w istocie jest niczym, to sam siebie mami.
###### **Ga 6,4**
 Niech więc każdy z was analizuje swoje postępowanie. A wtedy jeśli faktycznie znajdziecie coś, czym można się pochwalić, to przynajmniej to chwalenie się oprze się na tym, co naprawdę zrobiliście, a nie tylko na przeświadczeniu, że jesteście lepsi niż kto inny;
###### **Ga 6,5**
 bo każdy poniesie własny ciężar.
###### **Ga 6,6**
 Ten, którego naucza Słowo, powinien dzielić się wszelkim dobrem ze swym nauczycielem.
###### **Ga 6,7**
 Nie zwodźcie sami siebie - nie sposób okpić Boga! Człowiek zbiera to, co zasiał.
###### **Ga 6,8**
 Ci, którzy sieją na gruncie swojej starej natury, aby zaspokoić swoje pragnienia, koniec końców zbiorą zniszczenie; lecz ci, którzy wytrwale sieją na polu Ducha, zbiorą z Ducha życie wieczne.
###### **Ga 6,9**
 Niestrudzenie więc czyńmy to, co dobre, bo jeśli nie ustaniemy, w stosownym czasie zbierzemy plon.
###### **Ga 6,10**
 Dlatego gdy pojawi się okazja, czyńmy dobrze każdemu, a zwłaszcza domownikom tych, którzy są ufnie wierni.
###### **Ga 6,11**
 Spójrzcie, jakie wielkie litery stawiam, kończąc moim własnym pismem.
###### **Ga 6,12**
 To ci, którzy chcą na zewnątrz wyglądać dobrze, usiłują was zmusić do obrzezania. A robią to tylko po to, aby uniknąć prześladowania za głoszenie o palu egzekucyjnym Mesjasza.
###### **Ga 6,13**
 Bo nawet ci, którzy dają się obrzezać, nie zachowują Tory. Przeciwnie, chcą, żebyście się obrzezali, bo chcą się chełpić, że pozyskali was dla siebie.
###### **Ga 6,14**
 Co do mnie jednak, to nigdy w życiu nie będę się chełpił czymkolwiek, wyjąwszy pał egzekucyjny naszego Pana Jeszui Mesjasza! Przez Niego dla mnie świat został uśmiercony na palu i przez Niego ja dla świata zostałem uśmiercony na palu.
###### **Ga 6,15**
 Bo nie liczy się ani obrzezanie, ani brak obrzezania; liczy się to, że ktoś jest nowym stworzeniem.
###### **Ga 6,16**
 A wszyscy, którzy prowadzą swe życie według tej zasady - niech będzie szalom nad nimi i miłosierdzie, a także nad Israelem Bożym!
###### **Ga 6,17**
 Odtąd nie chcę już, żeby mi kto przydawał tsuris, bo mam na swoim ciele blizny, które dowodzą, że należę do Jeszui!
###### **Ga 6,18**
 Łaska naszego Pana Jeszui Mesjasza niech będzie z waszym duchem, bracia. Amen.1
# Ga 6 TRO
###### **Ga 6,1**
 **αδελφοι** *adelfoi* Bracia [[G80]] WTN-VPM **εαν** *ean* jeśli [[G1437]] WTCOND **και** *kai* i [[G2532]] [[CONJ]] **προληφθη** *prolēfthē* wcześniej zostałby wzięty – zostałby uprzedzony [[G4301]] WTV-APS-3S **ανθρωπος** *anthrōpos* człowiek [[G444]] [[N-NSM]] **εν** *en* w [[G1722]] [[PREP]] **τινι** *tini* jakimś [[G5100]] WTX-DSN **παραπτωματι** *paraptōmati* upadku – występku [[G3900]] WTN-DSN **υμεις** *hymeis* wy [[G5210]] WTP-2NP **οι** *hoi* [[G3588]] WTT-NPM **πνευματικοι** *pneumatikoi* duchowi [[G4152]] WTA-NPM **καταρτιζετε** *katartizete* poprawiajcie – wydoskonalajcie [[G2675]] WTV-PAM-2P **τον** *ton* [[G3588]] [[T-ASM]] **τοιουτον** *toiouton* takiego [[G5108]] WTD-ASM **εν** *en* w [[G1722]] [[PREP]] **πνευματι** *pneumati* duchu [[G4151]] WTN-DSN **πραοτητος** *praotētos* łagodności – uprzejmości [[G4236]] [[N-GSF]] **σκοπων** *skopōn* bacząc – przyglądając się [[G4648]] [[V-PAP-NSM]] **σεαυτον** *seauton* (na) siebie [[G4572]] WTF-2ASM **μη** *mē* aby nie [[G3361]] [[PRT-N]] **και** *kai* i [[G2532]] [[CONJ]] **συ** *sy* ty [[G4771]] WTP-2NS **πειρασθης** *peirasthēs* zostałbyś doświadczony – zostałbyś wypróbowany [[G3985]] WTV-APS-2S
###### **Ga 6,2**
 **αλληλων** *allēlōn* Jedni drugich [[G240]] WTC-GPM **τα** *ta* [[G3588]] WTT-APN **βαρη** *barē* ciężary – brzemiona [[G922]] WTN-APN **βασταζετε** *bastazete* noście [[G941]] WTV-PAM-2P **και** *kai* i [[G2532]] [[CONJ]] **ουτως** *houtōs* tak [[G3779]] [[ADV]] **αναπληρωσατε** *anaplērōsate* wypełnijcie [[G378]] WTV-AAM-2P **τον** *ton* [[G3588]] [[T-ASM]] **νομον** *nomon* Prawo [[G3551]] [[N-ASM]] **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]]
###### **Ga 6,3**
 **ει** *ei* Jeśli [[G1487]] WTCOND **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **δοκει** *dokei* uważa [[G1380]] WTV-PAI-3S **τις** *tis* ktoś [[G5100]] WTX-NSM **ειναι** *einai* być [[G1511]] WTV-PXN **τι** *ti* czymś [[G5100]] WTX-NSN **μηδεν** *mēden* niczym [[G3367]] WTA-NSN **ων** *ōn* będąc [[G5607]] [[V-PXP-NSM]] **εαυτον** *heauton* siebie samego [[G1438]] WTF-3ASM **φρεναπατα** *frenapata* zwodzi w umyśle [[G5422]] WTV-PAI-3S
###### **Ga 6,4**
 **το** *to* [[G3588]] WTT-ASN **δε** *de* zaś [[G1161]] [[CONJ]] **εργον** *ergon* czyn [[G2041]] WTN-ASN **εαυτου** *heautou* swój [[G1438]] WTF-3GSM **δοκιμαζετω** *dokimazetō* niech bada [[G1381]] WTV-PAM-3S **εκαστος** *hekastos* każdy [[G1538]] [[A-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **τοτε** *tote* wtedy [[G5119]] [[ADV]] **εις** *eis* w [[G1519]] [[PREP]] **εαυτον** *heauton* sobie samym [[G1438]] WTF-3ASM **μονον** *monon* jedyny – sam [[G3441]] WTA-ASM **το** *to* [[G3588]] WTT-ASN **καυχημα** *kauchēma* chlubę [[G2745]] WTN-ASN **εξει** *eksei* będzie mieć [[G2192]] WTV-FAI-3S **και** *kai* i [[G2532]] [[CONJ]] **ουκ** *ouk* nie [[G3756]] [[PRT-N]] **εις** *eis* w [[G1519]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **ετερον** *heteron* innym [[G2087]] WTA-ASM
###### **Ga 6,5**
 **εκαστος** *hekastos* Każdy [[G1538]] [[A-NSM]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **το** *to* [[G3588]] WTT-ASN **ιδιον** *idion* własny [[G2398]] WTA-ASM **φορτιον** *fortion* ciężar [[G5413]] WTN-ASN **βαστασει** *bastasei* poniesie [[G941]] WTV-FAI-3S
###### **Ga 6,6**
 **κοινωνειτω** *koinōneitō* Niech będzie wspólnikiem [[G2841]] WTV-PAM-3S **δε** *de* zaś [[G1161]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **κατηχουμενος** *katēchoumenos* który jest pouczony [[G2727]] [[V-PPP-NSM]] **τον** *ton* (o) [[G3588]] [[T-ASM]] **λογον** *logon* słowie [[G3056]] [[N-ASM]] **τω** *tō* (dla) [[G3588]] WTT-DSM **κατηχουντι** *katēchounti* pouczającego [[G2727]] WTV-PAP-DSM **εν** *en* we [[G1722]] [[PREP]] **πασιν** *pasin* wszystkich [[G3956]] WTA-DPN **αγαθοις** *agathois* dobrach [[G18]] WTA-DPN
###### **Ga 6,7**
 **μη** *mē* Nie [[G3361]] [[PRT-N]] **πλανασθε** *planasthe* dajcie się zwieść – dajcie się wprowadzić w błąd [[G4105]] WTV-PPM-2P **θεος** *theos* Bóg [[G2316]] [[N-NSM]] **ου** *ou* nie [[G3756]] [[PRT-N]] **μυκτηριζεται** *myktērizetai* pozwala szydzić z siebie [[G3456]] WTV-PPI-3S **ο** *ho* co [[G3739]] WTR-ASN **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **εαν** *ean* jeśli [[G1437]] WTCOND **σπειρη** *speirē* zasiałby [[G4687]] WTV-PAS-3S **ανθρωπος** *anthrōpos* człowiek [[G444]] [[N-NSM]] **τουτο** *touto* to [[G5124]] WTD-ASN **και** *kai* i [[G2532]] [[CONJ]] **θερισει** *therisei* będzie żąć [[G2325]] WTV-FAI-3S
###### **Ga 6,8**
 **οτι** *hoti* bo [[G3754]] [[CONJ]] **ο** *ho* [[G3588]] [[T-NSM]] **σπειρων** *speirōn* siejący [[G4687]] [[V-PAP-NSM]] **εις** *eis* w [[G1519]] [[PREP]] **την** *tēn* [[G3588]] WTT-ASF **σαρκα** *sarka* ciało [[G4561]] WTN-ASF **εαυτου** *heautou* swoje [[G1438]] WTF-3GSM **εκ** *ek* z [[G1537]] [[PREP]] **της** *tēs* [[G3588]] [[T-GSF]] **σαρκος** *sarkos* ciała [[G4561]] [[N-GSF]] **θερισει** *therisei* będzie żąć [[G2325]] WTV-FAI-3S **φθοραν** *fthoran* zniszczenie – zepsucie [[G5356]] WTN-ASF **ο** *ho* [[G3588]] [[T-NSM]] **δε** *de* zaś [[G1161]] [[CONJ]] **σπειρων** *speirōn* siejący [[G4687]] [[V-PAP-NSM]] **εις** *eis* w [[G1519]] [[PREP]] **το** *to* [[G3588]] WTT-ASN **πνευμα** *pneuma* Ducha [[G4151]] WTN-ASN **εκ** *ek* z [[G1537]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **πνευματος** *pneumatos* Ducha [[G4151]] [[N-GSN]] **θερισει** *therisei* będzie żąć [[G2325]] WTV-FAI-3S **ζωην** *zōēn* życie [[G2222]] WTN-ASF **αιωνιον** *aiōnion* wieczne [[G166]] WTA-ASF
###### **Ga 6,9**
 **το** *to* [[G3588]] WTT-NSN **δε** *de* zaś [[G1161]] [[CONJ]] **καλον** *kalon* dobro – piękno [[G2570]] WTA-ASN **ποιουντες** *poiountes* czyniąc [[G4160]] WTV-PAP-NPM **μη** *mē* nie [[G3361]] [[PRT-N]] **εκκακωμεν** *ekkakōmen* zniechęcalibyśmy się – stalibyśmy się słabi [[G1573]] WTV-PAS-1P **καιρω** *kairō* porą [[G2540]] WTN-DSM **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **ιδιω** *idiō* swoją [[G2398]] WTA-DSM **θερισομεν** *therisomen* będziemy żąć [[G2325]] WTV-FAI-1P **μη** *mē* nie [[G3361]] [[PRT-N]] **εκλυομενοι** *eklyomenoi* którzy są osłabiani – którzy są strudzeni [[G1590]] WTV-PPP-NPM
###### **Ga 6,10**
 **αρα** *ara* Zatem [[G686]] WTPRT **ουν** *oun* więc [[G3767]] [[CONJ]] **ως** *hōs* jak [[G5613]] [[ADV]] **καιρον** *kairon* porę [[G2540]] [[N-ASM]] **εχομεν** *echomen* mamy [[G2192]] WTV-PAI-1P **εργαζωμεθα** *ergazōmetha* czynilibyśmy [[G2038]] WTV-PNS-1P **το** *to* [[G3588]] WTT-ASN **αγαθον** *agathon* dobro [[G18]] WTA-ASN **προς** *pros* względem [[G4314]] [[PREP]] **παντας** *pantas* wszystkich [[G3956]] WTA-APM **μαλιστα** *malista* najbardziej [[G3122]] [[ADV]] **δε** *de* zaś [[G1161]] [[CONJ]] **προς** *pros* względem [[G4314]] [[PREP]] **τους** *tous* (tych) [[G3588]] WTT-APM **οικειους** *oikeious* domowych [[G3609]] WTA-APM **της** *tēs* (we) [[G3588]] [[T-GSF]] **πιστεως** *pisteōs* wierze [[G4102]] [[N-GSF]]
###### **Ga 6,11**
 **ιδετε** *idete* Zobaczcie [[G1492]] WTV-2AAM-2P **πηλικοις** *pēlikois* jak wielkimi [[G4080]] WTA-DPN **υμιν** *hymin* wam [[G5213]] WTP-2DP **γραμμασιν** *grammasin* literami [[G1121]] WTN-DPN **εγραψα** *egrapsa* napisałem [[G1125]] WTV-AAI-1S **τη** *tē* [[G3588]] WTT-DSF **εμη** *emē* moją [[G1699]] WTS-1DSF **χειρι** *cheiri* rękę [[G5495]] [[N-DSF]]
###### **Ga 6,12**
 **οσοι** *hosoi* Ilu [[G3745]] WTK-NPM **θελουσιν** *thelousin* chcą [[G2309]] WTV-PAI-3P **ευπροσωπησαι** *euprosōpēsai* podobać się [[G2146]] [[V-AAN]] **εν** *en* w [[G1722]] [[PREP]] **σαρκι** *sarki* ciele [[G4561]] [[N-DSF]] **ουτοι** *houtoi* ci [[G3778]] WTD-NPM **αναγκαζουσιν** *anagkazousin* zmuszają – czynią koniecznym [[G315]] WTV-PAI-3P **υμας** *hymas* was [[G5209]] WTP-2AP **περιτεμνεσθαι** *peritemnesthai* być obrzezanymi [[G4059]] WTV-PPN **μονον** *monon* jedynie – tylko [[G3440]] [[ADV]] **ινα** *hina* aby [[G2443]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **τω** *tō* (dla) [[G3588]] WTT-DSM **σταυρω** *staurō* krzyża [[G4716]] WTN-DSM **του** *tou* [[G3588]] WTT-GSM **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **διωκωνται** *diōkōntai* byliby prześladowani – byliby ścigani [[G1377]] WTV-PPS-3P
###### **Ga 6,13**
 **ουδε** *oude* ani [[G3761]] [[ADV]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **οι** *hoi* (ci) [[G3588]] WTT-NPM **περιτεμνομενοι** *peritemnomenoi* którzy są obrzezani [[G4059]] WTV-PPP-NPM **αυτοι** *autoi* sami [[G846]] WTP-NPM **νομον** *nomon* Prawa [[G3551]] [[N-ASM]] **φυλασσουσιν** *fylassousin* strzegą [[G5442]] WTV-PAI-3P **αλλα** *alla* ale [[G235]] [[CONJ]] **θελουσιν** *thelousin* chcą [[G2309]] WTV-PAI-3P **υμας** *hymas* (aby) wy [[G5209]] WTP-2AP **περιτεμνεσθαι** *peritemnesthai* być obrzezanymi [[G4059]] WTV-PPN **ινα** *hina* aby [[G2443]] [[CONJ]] **εν** *en* w [[G1722]] [[PREP]] **τη** *tē* [[G3588]] WTT-DSF **υμετερα** *hymetera* waszym [[G5212]] WTS-2DPF **σαρκι** *sarki* ciele [[G4561]] [[N-DSF]] **καυχησωνται** *kauchēsōntai* chlubiliby się – chełpiliby się [[G2744]] WTV-ADS-3P
###### **Ga 6,14**
 **εμοι** *emoi* Mnie [[G1698]] WTP-1DS **δε** *de* zaś [[G1161]] [[CONJ]] **μη** *mē* nie [[G3361]] [[PRT-N]] **γενοιτο** *genoito* oby stało się [[G1096]] WTV-2ADO-3S **καυχασθαι** *kauchasthai* chlubić się – chełpić się [[G2744]] WTV-PNN **ει** *ei* jeśli [[G1487]] WTCOND **μη** *mē* nie [[G3361]] [[PRT-N]] **εν** *en* w [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSM **σταυρω** *staurō* krzyżu [[G4716]] WTN-DSM **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **δι** *di* przez [[G1223]] [[PREP]] **ου** *hou* którego [[G3739]] WTR-GSM **εμοι** *emoi* (dla) mnie [[G1698]] WTP-1DS **κοσμος** *kosmos* świat [[G2889]] [[N-NSM]] **εσταυρωται** *estaurōtai* jest ukrzyżowany [[G4717]] WTV-RPI-3S **καγω** *kagō* i ja [[G2504]] WTP-1NS-C **τω** *tō* (dla) [[G3588]] WTT-DSM **κοσμω** *kosmō* świata [[G2889]] WTN-DSM
###### **Ga 6,15**
 **εν** *en* W [[G1722]] [[PREP]] **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **χριστω** *christō* Pomazańcu [[G5547]] WTN-DSM **ιησου** *iēsou* Jezusie – [JHWH jest zbawieniem] [[G2424]] WTN-DSM **ουτε** *oute* ani [[G3777]] [[CONJ]] **περιτομη** *peritomē* obrzezanie [[G4061]] [[N-NSF]] **τι** *ti* czymś [[G5100]] WTX-ASN **ισχυει** *ischyei* jest silne [[G2480]] WTV-PAI-3S **ουτε** *oute* ani [[G3777]] [[CONJ]] **ακροβυστια** *akrobystia* nieobrzezanie [[G203]] [[N-NSF]] **αλλα** *alla* ale [[G235]] [[CONJ]] **καινη** *kainē* nowe [[G2537]] WTA-NSF **κτισις** *ktisis* stworzenie [[G2937]] [[N-NSF]]
###### **Ga 6,16**
 **και** *kai* A [[G2532]] [[CONJ]] **οσοι** *hosoi* ilu [[G3745]] WTK-NPM **τω** *tō* (z) [[G3588]] WTT-DSM **κανονι** *kanoni* normą – zasadą [[G2583]] WTN-DSM **τουτω** *toutō* tą [[G5129]] WTD-DSM **στοιχησουσιν** *stoichēsousin* pójdą w szeregu [[G4748]] WTV-FAI-3P **ειρηνη** *eirēnē* pokój [[G1515]] [[N-NSF]] **επ** *ep* na [[G1909]] [[PREP]] **αυτους** *autous* nich [[G846]] [[P-APM]] **και** *kai* i [[G2532]] [[CONJ]] **ελεος** *eleos* miłosierdzie – litość [[G1656]] [[N-NSM]] **και** *kai* i [[G2532]] [[CONJ]] **επι** *epi* na [[G1909]] [[PREP]] **τον** *ton* [[G3588]] [[T-ASM]] **ισραηλ** *israēl* Izraela – [ten, który walczył z Bogiem] [[G2474]] [[N-PRI]] **του** *tou* [[G3588]] WTT-GSM **θεου** *theou* Boga [[G2316]] [[N-GSM]]
###### **Ga 6,17**
 **του** *tou* [[G3588]] WTT-GSN **λοιπου** *loipou* Odtąd – W końcu [[G3064]] [[A-GSN]] **κοπους** *kopous* trudów [[G2873]] [[N-APM]] **μοι** *moi* mi [[G3427]] WTP-1DS **μηδεις** *mēdeis* nikt [[G3367]] [[A-NSM]] **παρεχετω** *parechetō* niech podaje [[G3930]] WTV-PAM-3S **εγω** *egō* ja [[G1473]] WTP-1NS **γαρ** *gar* bowiem [[G1063]] [[CONJ]] **τα** *ta* [[G3588]] WTT-APN **στιγματα** *stigmata* piętna – znaki [[G4742]] WTN-APN **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **εν** *en* na [[G1722]] [[PREP]] **τω** *tō* [[G3588]] WTT-DSN **σωματι** *sōmati* ciele [[G4983]] WTN-DSN **μου** *mou* moim [[G3450]] WTP-1GS **βασταζω** *bastazō* noszę [[G941]] WTV-PAI-1S
###### **Ga 6,18**
 **η** *hē* [[G3588]] [[T-NSF]] **χαρις** *charis* Łaska [[G5485]] [[N-NSF]] **του** *tou* [[G3588]] WTT-GSM **κυριου** *kyriou* Pana [[G2962]] [[N-GSM]] **ημων** *hēmōn* naszego [[G2257]] WTP-1GP **ιησου** *iēsou* Jezusa – [JHWH jest zbawieniem] [[G2424]] [[N-GSM]] **χριστου** *christou* Pomazańca [[G5547]] [[N-GSM]] **μετα** *meta* z [[G3326]] [[PREP]] **του** *tou* [[G3588]] WTT-GSN **πνευματος** *pneumatos* duchem [[G4151]] [[N-GSN]] **υμων** *hymōn* waszym [[G5216]] WTP-2GP **αδελφοι** *adelfoi* bracia [[G80]] WTN-VPM **αμην** *amēn* amen – [zaprawdę] [[G281]] WTHEB **προς** *pros* do [[G4314]] [[PREP]] **γαλατας** *galatas* Galacjan [[G1052]] [[N-ASM]] **εγραφη** *egrafē* został napisany [[G1125]] WTV-2API-3S **απο** *apo* z [[G575]] [[PREP]] **ρωμης** *rōmēs* Rzymu [[G4516]] [[N-GSF]]
